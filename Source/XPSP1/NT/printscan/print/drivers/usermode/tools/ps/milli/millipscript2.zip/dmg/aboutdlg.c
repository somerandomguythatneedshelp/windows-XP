/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ABOUTDLG.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for the About Dialog      */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_DIALOGSSEG)

#define BUFFERSIZE  1024

void NEAR PASCAL InitAboutDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    LPSTR lpStr;
    LPPRINTERINFO lpPrinterInfo = 
                (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    int   iLen;                
                
    lpStr = (LPSTR)GlobalAllocPtr(GHND, BUFFERSIZE);
    if (!lpStr)
        return;

    // Set the version number and files
    iLen = LoadString(ghDriverMod, IDS_DRIVERFILES, lpStr, BUFFERSIZE);
    if (!iLen)
        return;

        
    if (lpPrinterInfo->PCFileName.dword)
    {
       // Get the PPD or SPD file name from the registry instead of from the 
       // *PCFileName. Because some of the SPD files have .PPD file extension 
       // for this field
       char    szModelName[64];
       char    szPPDFileName[64], szDriverName[64];
       LPSTR   lpModelName;
       DWORD   dwType, dwNeeded;

       lpModelName = (LPSTR) szModelName;
       lpModelName[0] = '\0';                /* Null intialize it */
       if (DrvGetPrinterData(lpDrvInfo->pDev.lpPSExtDevmode->dm.dm.dmDeviceName, 
                             (LPSTR)INT_PD_PRINTER_MODEL, &dwType, lpModelName, 
                             CCHDEVICENAME, &dwNeeded) != ERROR_SUCCESS)
       {
          /* Unknown model - use default printer. */
          LoadString(ghDriverMod, IDS_DEFAULTPRINTER, lpModelName, CCHDEVICENAME);
       }    
       GetDriverNameFromModelName(lpModelName, szDriverName, sizeof(szDriverName));
       GetPPDNameFromModelName(lpModelName, szPPDFileName, sizeof(szPPDFileName));
       lstrcat(lpStr, szDriverName);
       lstrcat(lpStr, ", ");
       lstrcat(lpStr, szPPDFileName); 
    }
    else
    {   
        /* WPD file was used */
        LoadString(ghDriverMod, IDS_WIN31WPDFILE, lpStr+iLen, BUFFERSIZE-iLen);
    }                              
    SetDlgItemText(hDlg, ID_DRIVERFILES, lpStr);

    GlobalFreePtr(lpStr);
}


/*****************************************************************************/
/*                 fnAboutDlg                                                */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the About dialog box                              */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL fnAboutDlg(HWND         hDlg,
                                   unsigned     imsg,
                                   WORD         wParam,
                                   LONG         lParam)
{
  LPDRIVERINFO lpDrvInfo;

#ifdef USEHOOKPROC
  /* Process hook function stuff -John Kwan */
  if(lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
  {
    if(DrvProcessHookProc(&(lpDrvInfo->pDev),hDlg,imsg,wParam,lParam,
        "HookAbout"))
    {
      return TRUE;
    }
  }
#endif  


  switch (imsg)
    {
    case  WM_INITDIALOG:
      /***** Center the Dialog *****/
#ifdef USEHOOKPROC
      SetWindowLong(hDlg,DWL_USER,lParam);
#endif
      lpDrvInfo=(LPDRIVERINFO)lParam;
      InitAboutDlg(hDlg, lpDrvInfo);
//      CenterPopup( hDlg, GetParent(hDlg) );
      break;

   case WM_COMMAND:
     switch (wParam)
       {
       case  IDOK:                           /* OK button                 */
       case  IDCANCEL:                       /* System Menu Close command */
         EndDialog(hDlg, IDOK);
         break;

       default:
         return FALSE;
         break;

       } /* switch(wParam) */
     break;

   default:
     return FALSE;
     break;
   } /* switch(imsg) */

  return TRUE;
} /* End fnAboutDlg */

#if 0
/*****************************************************************************/
/*                 CallHelpFile                                              */
/* Purpose:                                                                  */
/*   Checks to see if the help file is present -- displays a message         */
/*   if the file is not found.                                               */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hWnd - Handle to parent window                                     */
/*   WORD wResID - resource ID to string for help context                    */
/*   LPDRIVERINFO lpDrvInfo - pointer to DRIVERINFO structure                */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE  => if file loaded                                                 */
/*   FALSE => if file not loaded                                             */
/*****************************************************************************/

BOOL NEAR PASCAL CallHelpFile(HANDLE       hWnd,
                              WORD         wResID,
                              LPDRIVERINFO lpDrvInfo)
{
    if(!(lpDrvInfo->fHelp))
    {
        OFSTRUCT of;

        if(HFILE_ERROR==OpenFile(szHelpFile,&of,OF_EXIST))
        {
            char  buf[260];
            char  outmess[400];

            LoadString(ghDriverMod, DLGS_szMissingHelp, buf, sizeof(buf));
            wsprintf(outmess, (LPSTR)buf, (LPSTR)szHelpFile,(LPSTR)"");
            MessageBox(hWnd,(LPSTR)outmess,(LPSTR)NULL,MB_OK);
            goto CHF_exit;
        }
    }

    if(wResID)
    {
        char tmpString[50];

        if(LoadString(ghDriverMod,wResID,tmpString,sizeof(tmpString)))
        {
            if(WinHelp(hWnd,szHelpFile, HELP_KEY,
                (DWORD)(LPSTR)tmpString))
            {
                lpDrvInfo->fHelp=TRUE;
            }
        }
    }
    else if(IDM_HELP_NO_TOPIC != lpDrvInfo->pDev.iHelpContext)
    {
        if(WinHelp(hWnd, szHelpFile, HELP_CONTEXT,
            (DWORD)lpDrvInfo->pDev.iHelpContext))
        {
            lpDrvInfo->fHelp=TRUE;
        }
    }

CHF_exit:

    return lpDrvInfo->fHelp;
}
#endif

