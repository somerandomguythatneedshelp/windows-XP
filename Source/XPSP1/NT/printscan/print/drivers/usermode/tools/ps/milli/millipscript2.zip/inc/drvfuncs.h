/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DRVFUNCS.H                                                   */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/



LPSTR FAR PASCAL DriverAToF( LPSTR, LPFLOAT );


