//  devmode2.h  -  declarations


// remove this when it gets defined in the subsystem.
#define ENV_MODEL  1

short  FAR  PASCAL  scale(
short  mul1,
short  mul2,
short  divisor) ;


BOOL UsePropertySheet(void);

short _loadds FAR PASCAL DeviceMode(HWND hWnd,HANDLE hInst,LPSTR lpzDevice, 
                                    LPSTR lpzPort);



void FAR PASCAL InitializeDrvVariables(LPPSEXTDEVMODE lpPSExtDevmode) ;

typedef enum {
    MERGE_USEDEFAULTS,
    MERGE_PUBLICDM,
    MERGE_DOCRESTRICTED,
    MERGE_CACHEDRESTRICTED,
    MERGE_DOC,
    MERGE_FULL,
} MERGETYPE;

MERGETYPE FAR PASCAL GetMergeType(
LPWPXBLOCKS    lpWPXblock, 
LPPSEXTDEVMODE lpPSExtDevmode) ;


BOOL  FAR  PASCAL  UpdatePublicDevmode(
LPWPXBLOCKS   lpWPXblock, 
LPPSEXTDEVMODE  lpExtDevMode) ;

int FAR PASCAL DefaultPaperSize(LPPSEXTDEVMODE, LPWPXBLOCKS);


BOOL    FAR  PASCAL  InitDefaultDevmode(
LPWPXBLOCKS   lpWPXblock, 
LPPSEXTDEVMODE  lpExtDevMode,
LPBYTE   friendlyName ) ;

BOOL NEAR DEVMODESEG PASCAL  MergeDevmode(
LPWPXBLOCKS   lpWPXblock, 
LPPSEXTDEVMODE  lpdmCurrent, 
LPPSEXTDEVMODE  lpdmInput, 
MERGETYPE  mergeType);


short _loadds FAR PASCAL ExtDeviceMode(HWND hWnd, HANDLE hInst, 
                                       LPDEVMODE lpdmOutput,
   LPSTR lpDevName, LPSTR lpPort, LPDEVMODE lpdmInput, LPSTR lpProfile,
   WORD wMode) ;


short NEAR PASCAL EnterDevMode(
HWND                 hWnd, 
HANDLE               hInst, 
LPPSEXTDEVMODE       lpdmOutput,
LPSTR                lpDevName,   // PPD modelname
LPSTR                lpPort,
LPPSEXTDEVMODE       lpdmInput,   // app supplied devmode
LPSTR                lpProfile,
LPFNADDPROPSHEETPAGE lpfnAdd,     // Callback for adding property pages
LPARAM               lParam,      // data for callback
WORD                 wMode,
WORD                 wFrom);


UINT _loadds FAR PASCAL PropPageCallback(HWND hWnd,UINT uMsg,LPPROPSHEETPAGE lpPSP);

void FAR PASCAL PsExtDevmodeMerge(LPPSEXTDEVMODE lpCurDevmode,
                                  LPPSEXTDEVMODE lpNewDevmode,
                                  LPSTR          lpszDevice,
                                  LPSTR          lpszFriendly,
                                  BOOL           bInitialize);
