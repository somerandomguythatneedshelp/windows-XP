/* CM_VerSion ossyslib.h atm05 1.5 10076.eco sum= 37276 */
/* CM_VerSion ossyslib.h atm04 1.6 07558.eco sum= 48090 */
/*
  ossyslib.h

Copyright (c) 1991 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of
Adobe Systems Incorporated.  Many of the intellectual and
technical concepts contained herein are proprietary to Adobe,
are protected as trade secrets, and are made available only to
Adobe licensees for their internal use.  Any reproduction or
dissemination of this software is strictly forbidden unless
prior written permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks of
Adobe Systems Incorporated.

Original version: unknown
Edit History:
Craig Rublee: Fri May 31 11:35:53 1991
Paul Haahr: Tue Nov 26 10:21:07 1991
End Edit History.

Revision History

  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/OSSYSLIB.H_V  $
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:07:24   unknown
 *- |Initial revision.
  Revision 1.1  91/11/13  11:18:49  rublee
  Initial revision

  Revision 6.1  91/10/07  18:22:46  rublee



End Revision History.
*/

/* Declarations for system library routines on unix machines */
#ifndef OSSYSLIB_H
#define OSSYSLIB_H

#if OS == os_mach	/* next machines */
#include <libc.h>
/* These are defined in <string.h>--but not for ANSI (don't ask me why) */
#define bcopy(from,to,len) ((void)memmove(to,from,len))
#define bzero(b,len) memset(b,0,len)
#endif

#if OS == os_mpw	/* Macintosh */
#define bcopy(from,to,len) ((void)memmove(to,from,len))
#define bzero(b,len) memset(b,0,len)
#endif


#if OS == os_sun

PUBLIC procedure printf ARGDECLV1(char *, fmt);
PUBLIC procedure fprintf ARGDECLV2(FILE *, fp, char *, fmt);
PUBLIC size_t	fwrite ARGDECLV4( void *, ptr, size_t,  size, size_t,  nmemb, FILE *, f );
PUBLIC size_t	fread ARGDECLV4( void *, ptr, size_t,  size, size_t,  nmemb, FILE *, f );
PUBLIC int	fclose ARGDECLV1( FILE *, f );
PUBLIC int	fflush ARGDECLV1( FILE *, f );
PUBLIC int	fscanf ARGDECLV2( FILE *, f, const char *, format);
PUBLIC time_t   time ARGDECLV1( time_t *, t);
PUBLIC int	_flsbuf ARGDECLV2( unsigned char, c, FILE *, fp); /* couldn't find this anywhere on the SUN */
PUBLIC char    *memset ARGDECLV2(void *, s, size_t, n);
PUBLIC char    *strchr ARGDECLV2(const char *, s, int, c);
PUBLIC char    *strncmp ARGDECLV3(const char *, s1, const char *, s2, size_t, n);
PUBLIC char    *strncpy ARGDECLV3(const char *, s1, const char *, s2, size_t, n);

/*PUBLIC int read ARGDECLV3( int, fd, char *, buf, int, buflen);*/
/* PUBLIC int open ARGDECLV2( char *, file, int, mode); */
/* PUBLIC int close ARGDECL1( int, fd); */

PUBLIC int atoi ARGDECL1(char *, s);
PUBLIC long atol ARGDECL1(char *, s);

/* PUBLIC procedure _flsbuf(); -- prevents sun cc from compiling putc() */
PUBLIC int _filbuf();
#ifdef __GNUC__
/*PUBLIC volatile procedure exit ARGDECL1(int, status);*/

#else
/* PUBLIC procedure exit ARGDECL1(int, status); */

/* These definitions were moved out of the gcc path because they conflict */
PUBLIC char *malloc ARGDECL1(unsigned long, size);
PUBLIC char *realloc ARGDECL2(void *, p, unsigned long, size);
#endif
/*PUBLIC procedure abort ARGDECL0();*/
PUBLIC long strtol ARGDECL3(char *, s, char **, endp, int, radix);

#endif	/* OS == os_sun */

#endif  /* OSSYSLIB_H */
