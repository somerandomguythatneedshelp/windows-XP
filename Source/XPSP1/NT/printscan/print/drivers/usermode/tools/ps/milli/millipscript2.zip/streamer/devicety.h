/*
  device.h

Copyright (c) 1991 Adobe Systems Incorporated.
All rights reserved.

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript is a registered trademark of Adobe Systems Incorporated.
Display PostScript is a trademark of Adobe Systems Incorporated.

Original version: 
Edit History:
End Edit History.

Revision History
  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/DEVICETY.H_V  $
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:07:14   unknown
 *- |Initial revision.
  Revision 6.2  91/11/13  11:23:31  rublee
  Changed name of file from device.h to devicetypes.h to correspond to
  name used in ps development environment.
  
  Revision 6.1  91/10/07  18:22:30  rublee
   
  
  
End Revision History.

*/
/* output structures */

#ifndef	DEVICE_H
#define DEVICE_H

typedef Int16 DevShort;
typedef Int32 DevFixed;

typedef struct {
  DevShort l;
  DevShort g;
  } DevInterval;

typedef struct {
  DevInterval x;
  DevInterval y;
  } DevBounds;

typedef struct {
  DevBounds bounds;
  Card16 datalen;
  DevShort *data;
  DevShort *indx;
  } DevRun, *PDevRun;

typedef struct {
  DevShort xl;
  DevShort xg;
  DevFixed ix;
  DevFixed dx;
  } DevTrapEdge;

typedef struct {
  DevInterval y;
  DevTrapEdge l;
  DevTrapEdge g;
  } DevTrap, *PDevTrap;

typedef struct {
  DevShort x;
  DevShort y;
  } DevCd, *PDevCd;
  
typedef struct {
  DevCd bl;
  DevCd tr;
  } DevBBoxRec, *PDevBBox;


#endif	/* DEVICE_H */
