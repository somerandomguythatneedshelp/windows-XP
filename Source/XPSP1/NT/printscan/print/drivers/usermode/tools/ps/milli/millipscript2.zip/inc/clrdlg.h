/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: colordlg.H                                             */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHColorDlg(HWND hDlg, unsigned imsg,
                                   WORD wParam, LONG lParam);

BOOL _loadds FAR PASCAL ProfilePropertiesDlg(HWND hDlg, unsigned imsg,
                                             WORD wParam, LONG lParam);

void FAR PASCAL RestoreColorDlgDefaults(LPPSEXTDEVMODE lpPSExtDevmode);

#define ENUMICMP_INSERT  0
#define ENUMICMP_MATCH   1
DWORD FAR PASCAL HashString( LPSTR str, WORD len );
BOOL FAR PASCAL EnumICMProfile( WORD action, HWND hDlg, DWORD n,
            LPSTR lpszProfile, int size );
