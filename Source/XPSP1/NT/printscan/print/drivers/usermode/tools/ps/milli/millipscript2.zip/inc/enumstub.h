#include "fonthdr.h"
#if 0
/* Function prototypes */

extern BOOL FAR PASCAL IsEnumeratorPresent(void);
extern void FAR PASCAL Enum_AddFonts(LPSTR, LPSTR, LPFONTLIST, WORD, LPBYTE);
extern void FAR PASCAL Enum_InstallPrinter(LPSTR, LPSTR, LPSTR);
extern WORD FAR PASCAL Enum_EnumerateFonts(LPSTR, LPSTR, FONTSOURCE, ENUMTYPE, LPSTR, 
					   FARPROC, LP);


#endif
