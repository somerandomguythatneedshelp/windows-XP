/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: STRETCHD.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for ...                   */
/*                                                                           */
/* Change History:                                                           */
/* L3_MASK -- Support level3 transparent image.  9/19/96   jjia              */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_DIBSEG)

#define NOTSRCAND   0x00220326

/***********************************************************************
*                          StretchDIB
*
*  function  : This function maps a DIB from a source rectangle
*              of one size into a destination rectangle of( perhaps) a
*              different size.
*
*              May be called anytime between StartDoc and EndDoc.
*              May be disabled.  May change state to ST_MARKED_PAGE.
*
*  called : SHORT FAR PASCAL StretchDIB(lpDevice,GetSet,DestX,DestY,DestXE,DestYE,
*                                        SrcX,SrcY,SrcXE,SrcYE,lpBits,lpBitmapInfo,
*                                        ConversionInfo,rop,lpPBrush,lpdm,lpClip);
*
*
*  parameters: LP           lpDevice       --  PDEVICE structure
*              WORD         GetSet         --  Specifies whether the data is put/get
*              WORD         DestX          --  Destination rectangle
*              WORD         DestY          --          :
*              WORD         DestXE         --          :
*              WORD         DestYE         --          :
*              WORD         SrcX           --  Source rectangle
*              WORD         SrcY           --          :
*              WORD         SrcXE          --          :
*              WORD         SrcYE          --          :
*              LP           lpBits         --  Pointer to the data bits
*              LPBITMAPINFO lpBitmapInfo   --  Housekeeping data - Height,width,etc.
*              LPSTR        ConversionInfo --  Not used
*              DWORD        rop            --  Raster operation code
*              LPPBRUSH     lpPBrush       --  Pointer to the physical brush structure
*              LPDRAWMODE   lpdm           --  Pointer to the drawmode structure
*              LPRECT       lpClip         --  Pointer to the clipping rectangle
*
*  returns   : sRC = +1 Success
*                  =  0 Failure
*                  = -1 GDI should simulate
************************************************************************/
SHORT _loadds FAR PASCAL StretchDIB(LP lpDevice,WORD GetSet,
                                    WORD DestX,WORD DestY,WORD DestXE,
                                    WORD DestYE, WORD SrcX ,WORD SrcY ,
                                    WORD SrcXE ,WORD SrcYE ,
                                    LP   lpBits,
                                    LPBITMAPINFO lpBitmapInfo, // pointer to DIBitmap info Block
                                    LPSTR ConversionInfo,DWORD rop,
                                    LPPBRUSH lpPBrush,
                                    LPDRAWMODE lpdm,LPRECT lpClip)
{
    SHORT     sRC;
    LPPDEVICE lppd;
    DWORD     Style    = lpBitmapInfo->bmiHeader.biCompression;
    SHORT     BitCount = lpBitmapInfo->bmiHeader.biBitCount;
    DWORD     Width    = (DWORD)lpBitmapInfo->bmiHeader.biWidth;

    lppd     = (LPPDEVICE)lpDevice;
    sRC      = 0;       // failure
    
    // we now process BI_RGB, BI_BITFIELDS and RLE(4/8) format 

    if((lppd->sMagic == 0) ||            // Dest = Memory
       (GetSet != 0) ||               // Not Set operation
     //  !((Style == BI_RGB) || (Style == BI_BITFIELDS))||   // RLE format
       !((rop == SRCCOPY) || (rop == SRCINVERT)))          // have GDI simulate this operation
    { 
          sRC = -1;
    }
    else if ((lppd->sMagic == LUCAS) &&
             (lppd->job.bfInStretchDib == FALSE) &&
             (lppd->job.bfInWriteSpool == FALSE))
    {
        // Fix bug 192129.  jjia 12/2/97
        // Block nested StretchDib calls. 
        lppd->job.bfInStretchDib = TRUE;

        if (!fInDocLppd(lppd))
        {
            /* It isn't between StartDoc and EndDoc.  Return an error. */
            sRC = 0;            // Return failure
        }else if (fDisableGDILppd(lppd))
        {
            /* It's OK to call us, but GDI is disabled, so this is a NOP. */
            sRC = SrcYE;        // Return success
        }else if (!fChangeStateLppdSt(lppd, ST_MARKED_PAGE))
        {
            /*
             * For some reason, the state machine can't move to the 
             * proper state.  Return failure.
             */
            sRC = 0;            // Return failure
        }else
        {
            sRC = SrcYE;
            
            /*
             * don't try buffering, output it now
             * case 1: should be at the end of the bitmap
             * case 2: let StretchBlt handle it
             */
            if (lppd->GlobalBuffer.handleBitmapNow)
            {
                doStretchDIB(lpDevice,
                             DestX, DestY, DestXE, DestYE,
                             SrcX, SrcY, SrcXE, SrcYE,
                             lpBits, lpBitmapInfo,
                             rop, lpPBrush,
                             lpdm, lpClip);
            }
            else
            {
                if (!BufferBitmap(lpDevice,
                                  DestX, DestY, DestXE, DestYE,
                                  SrcX, SrcY, SrcXE, SrcYE,
                                  lpBits, lpBitmapInfo, NULL,
                                  rop, lpPBrush, lpdm, lpClip))
                {
                    sRC = 0;
                }
            }
        }   /* if !fInDoc... else if ... else if ... else */
        lppd->job.bfInStretchDib = FALSE;    // Fix bug 192129.

    }  /* if (lppd->sMagic ... */
              

    return(sRC);
}

/***********************************************************************
*                          BufferBitmap
*
*  function  : This function buffers the bitmap for later output.
*              Most applications output bitmap all at once.
*              But a few applications (so far only from ZSoft and Lotus),
*              split up the bitmap into segments for some unknown
*              reason.  This is an attempt to buffer them
*              back together and output it just once.
*              See bug 445, 458, 366 for more details.
*
*  parameters: LP           lpDevice       --  PDEVICE structure
*              LONG         DestX          --  Destination rectangle
*              LONG         DestY          --          :
*              LONG         DestXE         --          :
*              LONG         DestYE         --          :
*              LONG         SrcX           --  Source rectangle
*              LONG         SrcY           --          :
*              LONG         SrcXE          --          :
*              LONG         SrcYE          --          :
*              LP           lpBits         --  DIB pointer to the data bits
*              LPBITMAPINFO lpBitmapInfo   --  DIB housekeeping data - Height,width,etc.
*              LPBITMAP  lpDevBitmap    --  Device bitmap data
*              DWORD        rop            --  Raster operation code
*              LPPBRUSH     lpPBrush       --  Pointer to the physical brush structure
*              LPDRAWMODE   lpdm           --  Pointer to the drawmode structure
*              LPRECT       lpClip         --  Pointer to the clipping rectangle
*
*  returns   : FALSE if something failed
************************************************************************/
BOOL NEAR PASCAL BufferBitmap(LP lpDevice,
                  LONG DestX, LONG DestY, LONG DestXE, LONG DestYE,
                  LONG SrcX, LONG SrcY, LONG SrcXE, LONG SrcYE,
                  LP lpBits, LPBITMAPINFO lpBitmapInfo,
                  LPBITMAP lpDevBitmap, DWORD rop, LPPBRUSH lpPBrush,
                  LPDRAWMODE lpdm, LPRECT lpClip)
{
    LPBITMAPBUFFER lpBitmapBf = ((LPPDEVICE)lpDevice)->GlobalBuffer.lpBitmapBf;
    BOOL result = TRUE;
    WORD newBitCount, oldBitCount;
    BOOL bMergeDIB = TRUE;
    
    // is there a buffer already
    if (((LPPDEVICE)lpDevice)->GlobalBuffer.hBitmapBf && lpBitmapBf)
    {
        if (lpBitmapInfo)
        {
            newBitCount = lpBitmapInfo->bmiHeader.biBitCount;
        }
        else
        {
            newBitCount = lpDevBitmap->bmBitsPixel;
        }
        if (lpBitmapBf->dib)
        {
       oldBitCount = lpBitmapBf->bitmapInfo.biBitCount;
        }
        else
        {
            oldBitCount = lpBitmapBf->devBitmap.bmBitsPixel;
        }

        // Fix bug 199245. jjia   3/19/97
        // When merging two DIBs, we also need to verrify the color table.
        if ((lpBitmapInfo && lpBitmapBf->dib) &&
            (oldBitCount == newBitCount) &&
            ((newBitCount == 4) || (newBitCount == 8)))
        {
            LPDWORD  lppalNew = (LPDWORD)((LPSTR)lpBitmapInfo +
                                  lpBitmapInfo->bmiHeader.biSize);
            LPDWORD  lppalOld = (LPDWORD)((LPSTR)&(lpBitmapBf->bitmapInfo) +
                                  lpBitmapBf->bitmapInfo.biSize);
            WORD     TableLen = (WORD)(1 << newBitCount);

            bMergeDIB = FALSE;
            if ((lppalNew[0] == lppalOld[0]) &&
                (lppalNew[TableLen - 1] == lppalOld[TableLen - 1]) &&
                (lppalNew[TableLen / 2] == lppalOld[TableLen / 2]))
            {
                bMergeDIB = TRUE;
            }
        }
        // check if bitmap is a continuation of the one buffered
        if ((DestX == lpBitmapBf->destX) &&
            (DestXE == lpBitmapBf->destXE) &&
            ((DestY == lpBitmapBf->destY + lpBitmapBf->destYE) ||
             (DestY + DestYE == lpBitmapBf->destY)) && 
            (newBitCount == oldBitCount) &&
            (SrcXE == lpBitmapBf->srcXE) &&                  // bug #232361
            ((lpBitmapInfo && lpBitmapBf->dib) && bMergeDIB ||
             (!lpBitmapInfo && !lpBitmapBf->dib)) &&
            (rop == lpBitmapBf->rop))
        {
            // continue buffering the bitmap
            if (!bufferBitmapData(lpDevice,
                                  DestX, DestY, DestXE, DestYE,
                                  SrcX, SrcY, SrcXE, SrcYE,
                                  lpBits, lpBitmapInfo, lpDevBitmap,
                                  rop, lpPBrush, lpdm, lpClip))
            {
                // cannot buffer bitmap for some reason
                // flush the buffered bitmap
                // then buffer the new bitmap
                if (!flushBufferedBitmap(lpDevice))
                {
                    result = FALSE;
                }
                if (!bufferBitmapData(lpDevice,
                                      DestX, DestY, DestXE, DestYE,
                                      SrcX, SrcY, SrcXE, SrcYE,
                                      lpBits, lpBitmapInfo, lpDevBitmap,
                                      rop, lpPBrush, lpdm, lpClip))
                {
                    // fail again, just do it now
                    doBitmapNow(lpDevice,
                                DestX, DestY, DestXE, DestYE,
                                SrcX, SrcY, SrcXE, SrcYE,
                                lpBits, lpBitmapInfo, lpDevBitmap,
                                rop, lpPBrush, lpdm, lpClip);
                }
            }
        }
        else
        {
            // flush the buffered bitmap
            // then buffer the new bitmap
            if (!flushBufferedBitmap(lpDevice))
            {
                result = FALSE;
            }
            if (!bufferBitmapData(lpDevice,
                                  DestX, DestY, DestXE, DestYE,
                                  SrcX, SrcY, SrcXE, SrcYE,
                                  lpBits, lpBitmapInfo, lpDevBitmap,
                                  rop, lpPBrush, lpdm, lpClip))
            {
                // cannot buffer, just do it now
                doBitmapNow(lpDevice,
                            DestX, DestY, DestXE, DestYE,
                            SrcX, SrcY, SrcXE, SrcYE,
                            lpBits, lpBitmapInfo, lpDevBitmap,
                            rop, lpPBrush, lpdm, lpClip);
            }
        }
    }
    else
    {
        // new buffer
        if (!bufferBitmapData(lpDevice,
                              DestX, DestY, DestXE, DestYE,
                              SrcX, SrcY, SrcXE, SrcYE,
                              lpBits, lpBitmapInfo, lpDevBitmap,
                              rop, lpPBrush, lpdm, lpClip))
        {
            // cannot buffer, just do it now
            doBitmapNow(lpDevice,
                        DestX, DestY, DestXE, DestYE,
                        SrcX, SrcY, SrcXE, SrcYE,
                        lpBits, lpBitmapInfo, lpDevBitmap,
                        rop, lpPBrush, lpdm, lpClip);
        }
    }
    return(result);
}



/***********************************************************************
*                          doStretchDIB
*
*  function  : This function maps a DIB from a source rectangle
*              of one size into a destination rectangle of( perhaps) a
*              different size.
*
*              Only called when state is ST_MARKED_PAGE.
*
*  parameters: LP           lpDevice       --  PDEVICE structure
*              WORD         DestX          --  Destination rectangle
*              WORD         DestY          --          :
*              WORD         DestXE         --          :
*              WORD         DestYE         --          :
*              WORD         SrcX           --  Source rectangle
*              WORD         SrcY           --          :
*              WORD         SrcXE          --          :
*              WORD         SrcYE          --          :
*              LP           lpBits         --  Pointer to the data bits
*              LPBITMAPINFO lpBitmapInfo   --  Housekeeping data - Height,width,etc.
*              DWORD        rop            --  Raster operation code
*              LPPBRUSH     lpPBrush       --  Pointer to the physical brush structure
*              LPDRAWMODE   lpdm           --  Pointer to the drawmode structure
*              LPRECT       lpClip         --  Pointer to the clipping rectangle
*
*  returns   : none
************************************************************************/
static VOID NEAR PASCAL doStretchDIB(LP lpDevice,
                         WORD DestX,WORD DestY,WORD DestXE,WORD DestYE,
                         WORD SrcX ,WORD SrcY ,WORD SrcXE ,WORD SrcYE ,
                         LP   lpBits,LPBITMAPINFO lpBitmapInfo,
                         DWORD rop,LPPBRUSH lpPBrush,
                         LPDRAWMODE lpdm,LPRECT lpClip)
{
    RECT      srcRect, dstRect;
    SHORT     newDestY;
    SHORT     newDestYE;
    BITMAP    devBitmap;
    DWORD     scanWidth;
    LPBITMAP  lpDevBitmap;

    LPPDEVICE   lppd     = (LPPDEVICE)lpDevice;
    DWORD     style    = lpBitmapInfo->bmiHeader.biCompression;
    SHORT     bitCount = lpBitmapInfo->bmiHeader.biBitCount;
    DWORD     width    = (DWORD)lpBitmapInfo->bmiHeader.biWidth;
   
    if( bitCount == 1 ) 
    {
        RGBQUAD FAR *lpColors;
        DWORD     FGColor, BGColor;
        DWORD     FGSaved, BGSaved;
        RGBQUAD   Col;
        BYTE      Red, Green, Blue;
        SHORT     BKModeSaved;
        DWORD     NewRop = rop;

        // Get the foreground and background colors
        //  Fixed  31-Mar-1995  -by-  [olegsher]

      lpColors = (RGBQUAD FAR *)lpBitmapInfo;
      lpColors = (RGBQUAD FAR *)((DWORD)lpColors + lpBitmapInfo->bmiHeader.biSize);
      MemCopy( (LP)&Col, (LP)&(lpColors[0]), sizeof(Col));
      Red   = Col.rgbRed   ;
      Green = Col.rgbGreen ;
      Blue  = Col.rgbBlue  ;
      FGColor = RGB( Red, Green, Blue );
      
      MemCopy( (LP)&Col, (LP)&(lpColors[1]), sizeof(Col));
      Red   = Col.rgbRed   ;
      Green = Col.rgbGreen ;
      Blue  = Col.rgbBlue  ;
      BGColor = RGB( Red, Green, Blue );
      // This section is taken from adobeps 3.1 source, need to justify to
      // activate it.
/*
      if ( ( (FGColor == 0x00FFFFFFL) &&
            (BGColor == 0x00000000L)    ) ||
          ( (FGColor == 0x00000000L) &&
            (BGColor == 0x00FFFFFFL)    )  )
      {

         if ( FGColor == 0x00000000L)
         {
            switch(rop)
            {
               case NOTSRCCOPY:
                  rop = SRCCOPY ;
                  break;

               case SRCCOPY:          // case added to fix bug 405. 
                  rop = NOTSRCCOPY ; // since NOTSRCCOPY is not default any more, we need this
                  break;
                  
               case SRCAND:
                  rop = NOTSRCAND ;
                  break;
                  
               case NOTSRCAND:
                  rop = SRCAND ;
                  break;
                  
               default:
                  rop = NOTSRCAND;  // was NOTSRCCOPY ; fix bug 405. be consistent with PScript 3.58
                  break;
            }
         }
      }
*/
        // ScanWidth is the width of one scan line. DIB scanlines are
        // multiples of DWORDs.
        //
        // 1.  Width[pixels] * BitCount[bits/pixel]       
        //             => Total number of bits in image line
        // 2.  Width * BitCount + 31[bits]                
        //             => Round up to nearest DWORD boundary
        // 3. (Width * BitCount + 31)/32[bits/DWORD]      
        //             => Total number of DWORDS
        // 4.((Width * BitCount + 31)/32) * 4[byts/DWORD] 
        //             => Total number of bytes in a line

        scanWidth = ((width*bitCount + 31)/32) * 4    ;
        
        devBitmap.bmType         = (int)0;
        devBitmap.bmWidth        = (int)lpBitmapInfo->bmiHeader.biWidth;
        devBitmap.bmHeight       = ABS((int)lpBitmapInfo->bmiHeader.biHeight);
        devBitmap.bmWidthBytes   = (int)scanWidth;
        devBitmap.bmPlanes       = (BYTE)lpBitmapInfo->bmiHeader.biPlanes;
        devBitmap.bmBitsPixel    = (BYTE)1;
        devBitmap.bmBits         = (LPSTR)lpBits;
        devBitmap.bmSegmentIndex    = (SHORT)0;
        devBitmap.bmScanSegment     = (SHORT)0;
        
        // DIB data has its origin at the lower left while Bitmap data
        // has its origin at the upper left. Therefore we must transform
        // the origin and the destination extent to account for the
        // difference.
        
        lpDevBitmap  = (LPBITMAP) &devBitmap;
        
        newDestY  = DestY + DestYE;
        newDestYE = -(SHORT)DestYE;
        
        // Replace the colors in DRAWMODE to correctly hadle DIB
        //  Fixed  31-Mar-1995  -by-   [olegsher]
        FGSaved = lpdm->TextColor;
        BGSaved = lpdm->bkColor;
        BKModeSaved = lpdm->bkMode;
        lpdm->TextColor = FGColor;
        lpdm->bkColor = BGColor;

        // Since we call StretchBlt to print 1-bit DIB,
        // There are some combinations here:
        //      COLOR            TRANSPARANCE     ROP
        //--------------------------------------------------
        // bkColor == BGColor        ON          SRCCOPY
        // bkColor == FGColoe        ON          NOTSRCCOPY
        // bkColor != F(B)GColor     OFF         SRCCOPY

        if ((lpdm->bkMode == TRANSPARENT) &&
            ((lppd->lpPSExtDevmode->dm.bL2MaskedImage) &&
             (lppd->lpPSExtDevmode->dm2.useLanguageLevel == 2) ||
             (lppd->lpPSExtDevmode->dm.bL3MaskedImage) &&
             (lppd->lpPSExtDevmode->dm2.useLanguageLevel >= 3)
            ))
        {
            if (BGSaved == FGColor)      // Mask FGColor
            {
                NewRop = NOTSRCCOPY;
                lpdm->TextColor = BGColor;
                lpdm->bkColor = FGColor;
            }
            else if ((BGSaved != BGColor) && (BGSaved != FGColor))
            {
                lpdm->bkMode = OPAQUE;   // No match
            }
        }
        DoDevStretchBlt(lpDevice,DestX,newDestY,DestXE,newDestYE,
                      lpDevBitmap,SrcX ,SrcY ,SrcXE ,SrcYE,
                      NewRop,lpPBrush,lpdm,lpClip);
        lpdm->TextColor = FGSaved;
        lpdm->bkColor = BGSaved;
        lpdm->bkMode = BKModeSaved;
    }else
    {
      // Filxed interesting ICM bug -
      //   ClipRect uses --gsave--, and if we first use CClipRect and then
      //   CICMColor, the colorspace defined will be valid within
      //   --gsave-- --grestore-- brackets.
      //   fixed  14-Jul-1995  -by-  [olegsher]
        if( lpdm  &&
            ( ((WORD)lpdm->ICMCXform != (WORD)lppd->graphics.hCMTransform ) ||
              (lpdm->ICMCXform) ||
              (lppd->graphics.hCMTransform ) ||
              (lpdm->ICMCXform == NULL) && (lppd->graphics.hDefCMTransform)
            )
          )
        {
            // ALWAYS_ICM
            if ((lpdm->ICMCXform == NULL) &&
                (lppd->graphics.hDefCMTransform))
            {
                if ((WORD)lppd->graphics.hDefCMTransform != (WORD)lppd->graphics.hCMTransform)
                    CICMColor(lppd, lppd->graphics.hDefCMTransform);
            }
            else
            {
                CICMColor(lppd, lpdm->ICMCXform );
            }
        }

        if (lpClip != NULL)
            CClipRect(lppd,lpClip, NULL, 0);

        SetRect(&dstRect,DestX,DestY,DestX+DestXE,DestY+DestYE);
        SetRect(&srcRect,SrcX ,SrcY ,SrcX+SrcXE, SrcY+SrcYE );
//      ColorOrGrayToDevice(lppd,&dstRect,&srcRect,lpBits,lpBitmapInfo);
//      L3_MASK
        ColorOrGrayToDevice(lppd,lpdm,&dstRect,&srcRect,lpBits,lpBitmapInfo);
        
        if (lpClip != NULL)
            CClipEnd(lppd);                   // Remove clipping rectangle.
    }
}

/***********************************************************************
*                          doBitmapNow
*
*  function  : This function call the appropriate routine to output the
*            bitmap now.
*
*  parameters: LP           lpDevice       --  PDEVICE structure
*              LONG         DestX          --  Destination rectangle
*              LONG         DestY          --          :
*              LONG         DestXE         --          :
*              LONG         DestYE         --          :
*              LONG         SrcX           --  Source rectangle
*              LONG         SrcY           --          :
*              LONG         SrcXE          --          :
*              LONG         SrcYE          --          :
*              LP           lpBits         --  DIB pointer to the data bits
*              LPBITMAPINFO lpBitmapInfo   --  DIB housekeeping data - Height,width,etc.
*              LPBITMAP  lpDevBitmap    --  Device bitmap data
*              DWORD        rop            --  Raster operation code
*              LPPBRUSH     lpPBrush       --  Pointer to the physical brush structure
*              LPDRAWMODE   lpdm           --  Pointer to the drawmode structure
*              LPRECT       lpClip         --  Pointer to the clipping rectangle
*
*  returns   : none
************************************************************************/
static VOID NEAR PASCAL doBitmapNow(LP lpDevice,
                        LONG DestX, LONG DestY, LONG DestXE, LONG DestYE,
                        LONG SrcX, LONG SrcY, LONG SrcXE, LONG SrcYE,
                        LP lpBits, LPBITMAPINFO lpBitmapInfo,
                        LPBITMAP lpDevBitmap, DWORD rop, LPPBRUSH lpPBrush,
                        LPDRAWMODE lpdm,LPRECT lpClip)
{
    if (lpDevBitmap)
    {
        DoDevStretchBlt(lpDevice,
                        (SHORT)DestX, (SHORT)DestY, (SHORT)DestXE, 
                        (SHORT)DestYE, lpDevBitmap,
                        (SHORT)SrcX, (SHORT)SrcY, (SHORT)SrcXE, (SHORT)SrcYE,
                        rop, lpPBrush, lpdm, lpClip);
    }
    else
    {
        doStretchDIB(lpDevice,
                     (WORD)DestX, (WORD)DestY, (WORD)DestXE, (WORD)DestYE,
                     (WORD)SrcX, (WORD)SrcY, (WORD)SrcXE, (WORD)SrcYE,
                     lpBits, lpBitmapInfo,
                     rop, lpPBrush, lpdm, lpClip);
    }
}

/***********************************************************************
*                          flushBufferedBitmap
*
*  function  : This function flush any buffered bitmap.
*            This is a local routine usually called in cases
*            like buffering failed.
*
*  parameters: none
*
*  returns   : TRUE if succeed, FALSE otherwise
************************************************************************/
static BOOL NEAR PASCAL flushBufferedBitmap(LP lpDevice)
{
    LPBITMAPBUFFER lpBitmapBf = ((LPPDEVICE)lpDevice)->GlobalBuffer.lpBitmapBf;
    BOOL result = FALSE;
    BYTE huge *lpBits;
    LPPBRUSH lpPBrush;
    LPDRAWMODE lpdm;
    LPRECT lpClip;
    
    // is there something buffered, if so, output it now
    if (((LPPDEVICE)lpDevice)->GlobalBuffer.hBitmapBf && lpBitmapBf)
    {
        lpBits = MGLock((LPPDEVICE)lpDevice, lpBitmapBf->hBits, FALSE);
        if (lpBits)
        {
            ((LPPDEVICE)lpDevice)->GlobalBuffer.bFlushInProgress = TRUE;

            lpPBrush = (lpBitmapBf->nullPBrush ? NULL
                        : &lpBitmapBf->pBrush);
            lpdm = (lpBitmapBf->nullDM ? NULL
                    : &lpBitmapBf->dm);

            // Fix bug 195632. jjia  2/20/97
            // Clear lppd in lpICMI data structure.
            if (lpdm && (lpdm->ICMCXform))
            {
                LPICMINFO  lpICMI;
                lpICMI = (LPICMINFO)GlobalLock((HANDLE)lpdm->ICMCXform);
                if (lpICMI)
                { 
                    lpICMI->lppd = NULL;
                    GlobalUnlock((HANDLE)lpdm->ICMCXform);
                }
            }


            lpClip = (lpBitmapBf->nullClip ? NULL
                      : &lpBitmapBf->clip);
            if (lpBitmapBf->dib)
            {
                doStretchDIB(lpDevice,
                             (WORD)lpBitmapBf->destX, (WORD)lpBitmapBf->destY,
                             (WORD)lpBitmapBf->destXE, (WORD)lpBitmapBf->destYE,
                             (WORD)lpBitmapBf->srcX, (WORD)lpBitmapBf->srcY,
                             (WORD)lpBitmapBf->srcXE, (WORD)lpBitmapBf->srcYE,
              lpBits, (BITMAPINFO FAR *)(&lpBitmapBf->bitmapInfo),
              lpBitmapBf->rop, lpPBrush, lpdm, lpClip);
            }
            else
            {
                lpBitmapBf->devBitmap.bmBits = lpBits;
                DoDevStretchBlt(lpDevice,
                                (SHORT)lpBitmapBf->destX, 
                                (SHORT)lpBitmapBf->destY,
                                (SHORT)lpBitmapBf->destXE, 
                                (SHORT)lpBitmapBf->destYE,
                                &lpBitmapBf->devBitmap,
                                (SHORT)lpBitmapBf->srcX, 
                                (SHORT)lpBitmapBf->srcY,
                                (SHORT)lpBitmapBf->srcXE, 
                                (SHORT)lpBitmapBf->srcYE,
                                lpBitmapBf->rop, lpPBrush, lpdm, lpClip);
            }
            ((LPPDEVICE)lpDevice)->GlobalBuffer.bFlushInProgress = FALSE;
        }
        MGUnlockFree((LPPDEVICE)lpDevice, lpBitmapBf->hBits, FALSE);
        result = TRUE;
    }
    if (((LPPDEVICE)lpDevice)->GlobalBuffer.hBitmapBf)
        MGUnlockFree((LPPDEVICE)lpDevice, 
                     ((LPPDEVICE)lpDevice)->GlobalBuffer.hBitmapBf, FALSE);
    ((LPPDEVICE)lpDevice)->GlobalBuffer.hBitmapBf = NULL;
    ((LPPDEVICE)lpDevice)->GlobalBuffer.lpBitmapBf = NULL;
    return(result);
}

/***********************************************************************
*                          bufferBitmapData
*
*  function  : This function buffers the bitmap data.
*            Most applications output bitmap all at once.
*            But a few applications (so far only from ZSoft),
*            split up the bitmap into segments for some unknown
*            reason.  This is an attempt to buffere them
*            back together and output it just once.
*            See bug 445, 458, 366 for more details.
*
*  parameters: LP           lpDevice       --  PDEVICE structure
*              LONG         DestX          --  Destination rectangle
*              LONG         DestY          --          :
*              LONG         DestXE         --          :
*              LONG         DestYE         --          :
*              LONG         SrcX           --  Source rectangle
*              LONG         SrcY           --          :
*              LONG         SrcXE          --          :
*              LONG         SrcYE          --          :
*              LP           lpBits         --  DIB pointer to the data bits
*              LPBITMAPINFO lpBitmapInfo   --  DIB housekeeping data - Height,width,etc.
*              LPBITMAP  lpDevBitamp    --  Device bitmap data
*              DWORD        rop            --  Raster operation code
*              LPPBRUSH     lpPBrush       --  Pointer to the physical brush structure
*              LPDRAWMODE   lpdm           --  Pointer to the drawmode structure
*              LPRECT       lpClip         --  Pointer to the clipping rectangle
*
*  returns   : none
************************************************************************/
static BOOL NEAR PASCAL bufferBitmapData(LP lpDevice,
                             LONG DestX, LONG DestY, LONG DestXE, LONG DestYE,
                             LONG SrcX, LONG SrcY, LONG SrcXE, LONG SrcYE,
                             LP lpBits, LPBITMAPINFO lpBitmapInfo,
                             LPBITMAP lpDevBitmap,
                             DWORD rop, LPPBRUSH lpPBrush,
                             LPDRAWMODE lpdm, LPRECT lpClip)
{
    LPPDEVICE      lppd = (LPPDEVICE)lpDevice;
    LPBITMAPBUFFER lpBitmapBf = lppd->GlobalBuffer.lpBitmapBf;
    BYTE huge      *lpBitsBf;
    BYTE huge      *newLpBitsBf;
    BYTE huge      *lpBitsSrc;

    DWORD          size, newSize, copySize;
    DWORD          width;
    DWORD          scanLines; 
    
    WORD           bitCount;
    WORD           bitmapInfoSize;
    
    HANDLE          hBitsOld;
    BYTE huge      *lpBitsOld;
    BOOL           topDown;
    WORD           i;       // Loop counter    
    DWORD          BitCompressed;
   
    scanLines = SrcYE; 
//    BitCompressed = lpBitmapInfo->bmiHeader.biCompression;

    // find out the byte size of this bitmap
    // check which bitmap type: device or device independent
    if (lpDevBitmap)
    {
        width = lpDevBitmap->bmWidthBytes;
    }
    else
    {
        // must be DWORD align
        bitCount = lpBitmapInfo->bmiHeader.biBitCount;
        width = ((lpBitmapInfo->bmiHeader.biWidth * bitCount + 31) / 32) * 4;

    }
    size  = width * scanLines;
    
    // is there something buffered already
    if (lppd->GlobalBuffer.hBitmapBf && lpBitmapBf)
    {
        // add to current buffer
        newSize = size + lpBitmapBf->bitmapInfo.biSizeImage;

        // flush buffer if the buffer is too big.
        // Fix Acrobat huge EMF printing bug. jjia  8/596
        // Fix MS Photo Editor slow return to application problem (YCT)
        if (newSize > 256000)  
            return (FALSE);

        // need to handle buffering differently based on which
        // way the bitmap is coming in
        topDown = ((DestYE > 0 &&
                    (DestY == lpBitmapBf->destY + lpBitmapBf->destYE)) ||
                   ((DestYE < 0 &&
                     (DestY + DestYE == lpBitmapBf->destY))));
        
        
        // device independent bitmap has a different origin than
        // device dependent bitmap, lower left and upper left respectively


        hBitsOld = lpBitmapBf->hBits;
        if ((lpBitmapBf->dib && topDown) || (!lpBitmapBf->dib && !topDown))
        {
            /* the new bitmap goes at the beginning so don't do a realloc */
            lpBitsOld = MGLock(lppd, hBitsOld, FALSE);
            if (lpBitsOld == NULL)
            {
                return(FALSE);
            }

            lpBitsBf = MGAllocLock(lppd, &lpBitmapBf->hBits, newSize, 
                                   GHND, FALSE);
            if (!lpBitsBf)     // Fix Acrobat huge EMF printing bug. jjia  8/596
            {
                lpBitmapBf->hBits = hBitsOld;
                return(FALSE);
            }
        }
        else
        {
            // the new bitmap goes at the end
            lpBitmapBf->hBits = MGReAlloc(lppd, lpBitmapBf->hBits,
                                          newSize, GHND, FALSE);
            if (lpBitmapBf->hBits == NULL)  // Fix Acrobat huge EMF printing bug. jjia  8/596
            {
                lpBitmapBf->hBits = hBitsOld;
                return(FALSE);
            }
            lpBitsBf = MGLock(lppd, lpBitmapBf->hBits, FALSE);
        }
        
        if (lpBitsBf)
        {
            // update the source and destination to include the new bitmap
            lpBitmapBf->destYE += DestYE;
            lpBitmapBf->srcYE += SrcYE;
            if (topDown)
            {
                if (DestYE < 0)
                    lpBitmapBf->destY = DestY;
            }
            else
            {
                if (DestYE > 0)
                    lpBitmapBf->destY = DestY;
            }
            
            if ((lpBitmapBf->dib && topDown) || (!lpBitmapBf->dib && !topDown))
            {
                // the new bitmap need to be at the beginning
                // move the old ones to the end
                newLpBitsBf = lpBitsBf + size;
                copySize = (DWORD)lpBitmapBf->bitmapInfo.biSizeImage;
                MemCopy(newLpBitsBf, lpBitsOld, copySize);
                MGUnlockFree(lppd, hBitsOld, FALSE);
            }
            else
            {
                // the new bitmap goes at the end
                lpBitsBf += (DWORD)lpBitmapBf->bitmapInfo.biSizeImage;
            }
            
            // store info
            newLpBitsBf = lpBitsBf;
            if (lpBits)
            {
                // find beginning of device independent data bits
                lpBitsSrc = (BYTE huge *)lpBits;
                lpBitsSrc += (width * SrcY);

                // perform RLE4/RLE8 decompression

                BitCompressed = lpBitmapInfo->bmiHeader.biCompression;
                if ( BitCompressed == BI_RLE4 || BitCompressed == BI_RLE8)
                {
                    DeCompressedRLE4OrRLE8DIB(lppd, width, newLpBitsBf,  lpBitsSrc, lpBitmapInfo);
                }
                else
                {
                // find beginning of device independent data bits
                copySize = size;
                MemCopy(newLpBitsBf, lpBitsSrc, copySize);
                }
            }
            else
            {
                for ( i = 0 ; i < scanLines; i++ )
                {
                    // find the beginning of device data bits
                    lpBitsSrc = (BYTE huge *) GetByteAddress( lpDevBitmap,
                                                             (WORD)0, 
                                                             (WORD)( SrcY + i));
                    MemCopy(lpBitsBf, lpBitsSrc, width);
                    lpBitsBf += width ;
                }
            }
            
            // update size of bitmap
            if (lpBitmapBf->dib)
            {
                // Account for upside down DIBs
                if ((int)lpBitmapInfo->bmiHeader.biHeight < 0)
                    lpBitmapBf->bitmapInfo.biHeight -= scanLines;
                else
                    lpBitmapBf->bitmapInfo.biHeight += scanLines;
            }
            else
            {
                lpBitmapBf->devBitmap.bmHeight += (WORD) scanLines;
            }

                lpBitmapBf->bitmapInfo.biSizeImage = newSize;
            
            // update clipping
            if (lpClip && !lpBitmapBf->nullClip)
            {
                if (topDown)
                {
                    lpBitmapBf->clip.bottom = lpClip->bottom;
                }
                else
                {
                    lpBitmapBf->clip.top = lpClip->top;
                }
            }
            MGUnlock(lpBitmapBf->hBits);
        }
        else
        {
            return(FALSE);
        }
    }
    else
    {
        // new buffer
        // figure out size of buffer needed
        if (lpBitmapInfo && (bitCount <= 8) )
        {
            // need to store color table for 1, 4 and 8 bit
            bitmapInfoSize = ((WORD)lpBitmapInfo->bmiHeader.biSize
               - sizeof(BITMAPINFOHEADER)
               + sizeof(RGBQUAD) * (1 << bitCount));
     
            lppd->GlobalBuffer.lpBitmapBf = lpBitmapBf = 
                     (LPBITMAPBUFFER)MGAllocLock(lppd,
                                                 &lppd->GlobalBuffer.hBitmapBf,
                                                 sizeof(BITMAPBUFFER) + 
                                                 bitmapInfoSize,
                                                 GHND, FALSE);
       bitmapInfoSize += sizeof(BITMAPINFOHEADER);
        }
        else
        {
            if (lpBitmapInfo)
            {
                bitmapInfoSize = (WORD)lpBitmapInfo->bmiHeader.biSize
                                 - sizeof(BITMAPINFOHEADER);
                if (bitmapInfoSize == 0)
                {
                    if (lpBitmapInfo->bmiHeader.biCompression == BI_BITFIELDS)
                        bitmapInfoSize += 3 * sizeof(DWORD);
                }
            }
            else
                bitmapInfoSize = 0;

            lppd->GlobalBuffer.lpBitmapBf = lpBitmapBf = 
                     (LPBITMAPBUFFER)MGAllocLock(lppd, 
                                                 &lppd->GlobalBuffer.hBitmapBf,
                   sizeof(BITMAPBUFFER) +
                                                 bitmapInfoSize,
                                                 GHND, FALSE);
       bitmapInfoSize += sizeof(BITMAPINFOHEADER);
        }
        if (lpBitmapBf)
        {

            lpBitsBf = MGAllocLock(lppd, &lpBitmapBf->hBits, size,
                                   GHND, FALSE);
            if (lpBitsBf)
            {
                // store info
                lpBitmapBf->destX = DestX;
                lpBitmapBf->destY = DestY;
                lpBitmapBf->destXE = DestXE;
                lpBitmapBf->destYE = DestYE;
                lpBitmapBf->srcX =   SrcX;
                lpBitmapBf->srcY =   0;
                lpBitmapBf->srcXE = SrcXE;
                lpBitmapBf->srcYE = SrcYE;
                
                if (lpBits)
                {
                    // find the beginning of device independent data bits
                    lpBitsSrc = (BYTE huge *)lpBits;
                    lpBitsSrc += (width * SrcY);
                    // perform RLE4/RLE8 decompression
                   BitCompressed = lpBitmapInfo->bmiHeader.biCompression;
                   if ( BitCompressed == BI_RLE4 || BitCompressed == BI_RLE8)
                      DeCompressedRLE4OrRLE8DIB(lppd, width, lpBitsBf,  lpBitsSrc, lpBitmapInfo);
                   else
                   {
                       copySize = size;
                       MemCopy(lpBitsBf, lpBitsSrc, copySize);
                   }
                }
                else
                {
                    for ( i = 0 ; i < scanLines; i++ )
                    {
                        // find the beginning of device data bits
                        lpBitsSrc = (BYTE huge *)GetByteAddress(lpDevBitmap,
                                                                (WORD)0, 
                                                                (WORD)(SrcY+i));
                        MemCopy(lpBitsBf, lpBitsSrc, width);
                        lpBitsBf += width ;
                    }
                }
                
                if (lpBitmapInfo)
                {
                  WORD  CopySize ;
                  WORD  wColorTable = (WORD) lpBitmapInfo->bmiHeader.biClrUsed ;
                  // DDK page 460 -  if biClrUsed == 0 --> use maximum
                  if( wColorTable == 0)
                  {
                      wColorTable = (1 << bitCount);
                  }  
        if( bitCount <= 8 )
                     CopySize = sizeof(RGBQUAD) * wColorTable +
            (WORD)lpBitmapInfo->bmiHeader.biSize;
                  else
                     CopySize = bitmapInfoSize ;


                    MemCopy((LP) &lpBitmapBf->bitmapInfo, (LP)lpBitmapInfo,
                            CopySize);
                    // Account for upside down DIBs
                    if ((int)lpBitmapInfo->bmiHeader.biHeight < 0)
                        lpBitmapBf->bitmapInfo.biHeight = -(int)scanLines;
                    else
                        lpBitmapBf->bitmapInfo.biHeight = scanLines;
                    
                    lpBitmapBf->dib= TRUE;
                }
                else
                {
                    MemCopy((LP) &lpBitmapBf->devBitmap, (LP) lpDevBitmap,
                            sizeof(BITMAP));
                    lpBitmapBf->devBitmap.bmBits = NULL;
                    lpBitmapBf->devBitmap.bmSegmentIndex = 0;
                    lpBitmapBf->devBitmap.bmScanSegment = 0;
                    lpBitmapBf->devBitmap.bmHeight = (WORD) scanLines;
                    
                    lpBitmapBf->dib = FALSE;
                }
                
                lpBitmapBf->bitmapInfo.biSizeImage = size;
                lpBitmapBf->rop = rop;
                if (lpPBrush)
                {
                    MemCopy((LP) &lpBitmapBf->pBrush, (LP) lpPBrush, 
                            sizeof(PBRUSH));
                    lpBitmapBf->nullPBrush = FALSE;
                }
                else
                {
                    lpBitmapBf->nullPBrush = TRUE;
                }
                if (lpdm)
                {
                    // Fix bug 195632. jjia  2/20/97
                    // Save lppd in lpICMI data structure so that we can
                    // find the cached bitmap from lpICMI data structure.
                    if (lpdm->ICMCXform)
                    {
                        LPICMINFO  lpICMI;
                        lpICMI = (LPICMINFO)GlobalLock((HANDLE)lpdm->ICMCXform);
                        if (lpICMI)
                        { 
                            lpICMI->lppd = (LPSTR)lppd;
                            GlobalUnlock((HANDLE)lpdm->ICMCXform);
                        }
                    }
                    MemCopy((LP) &lpBitmapBf->dm, (LP) lpdm, sizeof(DRAWMODE));
                    lpBitmapBf->nullDM = FALSE;
                }
                else
                {
                    lpBitmapBf->nullDM = TRUE;
                }
                if (lpClip)
                {
                    MemCopy((LP) &lpBitmapBf->clip, (LP) lpClip, sizeof(RECT));
                    lpBitmapBf->nullClip = FALSE;
                }
                else
                {
                    lpBitmapBf->nullClip = TRUE;
                }
                MGUnlock(lpBitmapBf->hBits);
            }
            else
            {
                MGUnlockFree(lppd, lppd->GlobalBuffer.hBitmapBf, FALSE);
                lppd->GlobalBuffer.lpBitmapBf = NULL;
                lppd->GlobalBuffer.hBitmapBf = NULL;
                return(FALSE);
            }
        }
        else
        {
            lppd->GlobalBuffer.hBitmapBf = NULL;
            return(FALSE);
        }
    }
    return(TRUE);
} // bufferBitmap


/***********************************************************************
*                          DeCompressedRLE4OrRLE8DIB
*
*  function  : This function decompress a RLE DIB from a source rectangle
*              to a destination rectangle 
*     
*
*  Called : SHORT NEAR PASCAL DeCompressedRLE4OrRLE8DIB(lppd,DstRect,SrcRect,lpBits,lpBitmapInfo)
*
*  parameters:
*              PDEVICE      lppd
*              DWORD        width
*              LPRECT       DstRect      -- Destination rectangle
*              LPRECT       SrcRect      -- Source rectangle
*              LPBITMAPINFO lpBitmapInfo -- Housekeeping data - Height,width,etc.
*
*  returns   : RC_ok
************************************************************************/

VOID NEAR PASCAL DeCompressedRLE4OrRLE8DIB(LPPDEVICE lppd, DWORD width, 
                                      BYTE huge *lpNewBitsBf, BYTE huge *lpBitsSrc ,LPBITMAPINFO lpBitmapInfo)
{
   SHORT     BitCount  = (SHORT)lpBitmapInfo->bmiHeader.biBitCount;
   DWORD     BitCompressed  = (DWORD)lpBitmapInfo->bmiHeader.biCompression;
   DWORD     dibSize;
   BYTE      leadByte, countByte, hiByte, lowByte, tempByte;
   BOOL      bEndDib = FALSE;
   BOOL      bNibble = FALSE;
   long      offs,offd;
   LPBYTE    lpBufLine;  // construct one line at a time
   BYTE      horoffset, veroffset;
   BYTE huge *lpDestDib;
   BYTE huge *lpSrcDib;
   int i;
   BYTE      adjustByte = 0;

   // allocate the width size temp buffer for RLE4 or RLE8
   // 

   dibSize = (DWORD)lpBitmapInfo->bmiHeader.biSizeImage;

   lpBufLine = (BYTE *)GlobalAllocPtr(GHND|GMEM_SHARE, width);
   MemSet((BYTE *)lpBufLine, 0 , width);

   lpDestDib = lpNewBitsBf;
   lpSrcDib = lpBitsSrc;
   offs = offd = 0;
   if (BitCompressed == BI_RLE8)
   {
       
     while(!bEndDib)
     {
        if (lpSrcDib[offs++] == 0)
        { // absolute mode
           leadByte = lpSrcDib[offs++];
           if ( leadByte >= 3)
     {
             for (i = 0; i < leadByte; i++)
             {
         lpBufLine[offd++] = lpSrcDib[offs+i];
        }
             offs += i;
             // if offs not in word boundry, advance one byte
        // Make sure the padding 0 for WORD boundry
        // if offs is even number, it is on odd WORD boundry
        if ( i % 2) // even number 
           offs++; // advanced to word boundry
         
           }
      else
         {
          switch(leadByte)
          {
         case 0: 
            //  end of line
            MemCopy( lpDestDib, lpBufLine, width);    
                  lpDestDib += width;
            offd = 0; // reset index
            MemSet((BYTE *)lpBufLine, 0 , width);
            break;
         case 1:  // end of bitmap
            bEndDib = TRUE;
            break;
         case 2:  // delta value 
            // move current postion right and down
            horoffset = lpSrcDib[offs++];
            veroffset = lpSrcDib[offs++];
            // move to the current point
            offd += (unsigned int)horoffset;
            if ( veroffset == 1)
            {
               // move the current line
              MemCopy( lpDestDib, lpBufLine, width);
              lpDestDib += width;
              MemSet((BYTE *)lpBufLine, 0 , width);
            }
            if (veroffset > 1)
            { 
               // move some empty line
               
               for ( i = 0 ; i < (int)veroffset-1; i++)
               {
                   MemSet((BYTE *)lpBufLine, 0 , width);
                   MemCopy( lpDestDib, lpBufLine, width);
                         lpDestDib += width;
               }
            }
            // offd is the current line offset
            break;
          }   // end switch
         }     // end else
        }     // end absolute mode
        else  // Encoded mode
        {
           countByte = lpSrcDib[offs-1];  // first byte is the count
        
           for (i = 0; i < countByte; i++)
           {
              lpBufLine[offd++] = lpSrcDib[offs];
                }
           offs++;
        }   
     }  //end while
   
   } else if (BitCompressed == BI_RLE4)
        { 
          while(!bEndDib)
          {
           if ( lpSrcDib[offs++] == 0)
           { // absolute mode
             leadByte = lpSrcDib[offs++];
            if ( leadByte >= 3)
            {
            countByte = leadByte;
            for (i = 0; i < leadByte; i++) // each count is one nibble ......
            {
                 if ((i+1) % 2)
                     {
                  lowByte = (BYTE)lpSrcDib[offs+i/2] & 0x0F;
                  hiByte = (BYTE)((lpSrcDib[offs+i/2] & 0xF0) >> 4);
            }
            if (bNibble) // start with high byte
            {
                  lpBufLine[offd] |= hiByte & 0x0F;
                  offd++;           // if offd > 18 break out for loop
               i++;
               if (i < leadByte)
                     lpBufLine[offd] |= lowByte & 0x0F;
               else 
               {
                  bNibble = FALSE;
                  continue;      // this is word boundry last nibble
               }
                           if ((i+1) == leadByte)
                     break;         // finish in nibble
                  else
                     continue;

            }  
            if (i % 2) 
            {
                  lpBufLine[offd] |= (lowByte & 0x0F);
                  offd++;
            }
            else
                  lpBufLine[offd] = (hiByte << 4) & 0xF0;
            }
            // if odd size  fill the other nibble ?

            if (leadByte % 2)  // if odd size, add one word
                leadByte++;
            offs += leadByte/2;
                 // if offs not in word boundry, advance one byte
            // Make sure the padding 0 for WORD boundry
            // if offs is even number, it is on odd WORD boundry
            if (offs % 2) // even number 
               offs++; // advanced to word boundry
         
         } else                  
         { 
      switch(leadByte)
         {
          case 0: 
         // add end of line
             MemCopy( lpDestDib, lpBufLine, width);
             lpDestDib += width;
             offd = 0;
             MemSet((BYTE *)lpBufLine, 0 , width);
             bNibble = FALSE;
             break;
         case 1:  // may not need to output the last chunk
            bEndDib = TRUE;
            break;
          case 2:
         // move current postion right and down
            horoffset = lpSrcDib[offs++];
            veroffset = lpSrcDib[offs++];
            // move to the current point
            offd += (unsigned int)horoffset;
            if ( veroffset == 1)
            {
               // move the current line
              MemCopy( lpDestDib, lpBufLine, width);
              lpDestDib += width;
              MemSet((BYTE *)lpBufLine, 0 , width);
            }
            if (veroffset > 1)
            { 
               // move some empty line
               
               for ( i = 0 ; i < (int)veroffset-1; i++)
               {
                   MemSet((BYTE *)lpBufLine, 0 , width);
                   MemCopy( lpDestDib, lpBufLine, width);
                         lpDestDib += width;
               }
            }
            // offd is the current line offset
              
            break;
       }  // end switch
     }    // end else
       }
       else {  // encoded mode 

         countByte = lpSrcDib[offs-1];
                lowByte = (BYTE)lpSrcDib[offs] & 0x0F;
                hiByte = (BYTE)((lpSrcDib[offs] & 0xF0) >> 4);
          
           for (i = 0; i < countByte; i++)
           {
         if (bNibble) // start with high byte
                   {
                  lpBufLine[offd] |= hiByte & 0x0F;
             offd++;          // if offd > 18 break out for loop
             bNibble = FALSE;
                         // switch low and hi byte value
                       tempByte = hiByte;
                  hiByte = lowByte;
             lowByte = tempByte;
                       // the countByte start with number -1
                       countByte--; //if countByte == 0, should break out the for loop
             if (countByte == 0)
             break;
         }  

                  // output alternate hi and low nibble byte
                  if (i % 2)  // even number      
                  {
               lpBufLine[offd] |= lowByte & 0x0F;
               offd++;
                  }
              else
                      lpBufLine[offd]= (hiByte << 4) & 0xF0;
                 }
       if (countByte % 2) // if odd number  on hign nibble is filled
               bNibble = TRUE;
         offs++;  
       }
     } // end while
   }

   if (lpBufLine)
        GlobalFreePtr(lpBufLine);
 
}
