/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: GETCHARW.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for  ...                  */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_REALIZESEG)


/*****************************************************************************/
/*                 DevGetCharWidth                                           */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   LP        -- lpdevice                                                   */
/*   LPSHORT   -- lpsCharWidth                                               */
/*   short     -- sFirstChar                                                 */
/*   short     -- sLastChar                                                  */
/*   LPPSFONTINFO -- lpFontInfo                                                */
/*   LPDRAWMOD  -- lpDrawMode                                                */
/*   LPTEXTXFORM -- lpTextXForm                                              */
/*                                                                           */
/* Returns: Short                                                            */
/*****************************************************************************/

short _loadds FAR PASCAL DevGetCharWidth(LP lpDevice,LPSHORT lpsCharWidth,
        WORD sFirstChar,WORD sLastChar,LPPSFONTINFO lpFontInfo,LPDRAWMODE lpDrawMode,
        LPTEXTXFORM lpTextXForm)
{
   LPSHORT     CharWidthTbl                          ;
   short       sDefCharWidth                         ;
   WORD       ch                                    ;
   LPPDEVICE   lppd;
   short       sRC             =  1                  ;
   LPFONTEXTRA lpFontExtra     = (LPFONTEXTRA)BUMPFAR (lpFontInfo,lpFontInfo->dfDriverInfo);
   LPTTFONTINFO lpTTFontInfo   = (LPTTFONTINFO)((LPSTR)lpFontInfo + lpFontInfo->dfBitsOffset);
   WORD       FontDefaultChar = (WORD)lpFontInfo->dfDefaultChar;
   WORD       FontFirstChar   = (WORD)lpFontInfo->dfFirstChar  ;
   WORD       FontLastChar    = (WORD)lpFontInfo->dfLastChar   ;
   BOOL bDBCSCharSet;
   BOOL bDBCSChar;

   lppd =  (LPPDEVICE)lpDevice;

   /* If double byte character's lead byte is different between sFirstChar
    * and sLastChar return error.
    */
   if (  (bDBCSCharSet = IsDBCSCharSet(lpFontInfo->dfCharSet) )
      && ( (0xFF00 & sFirstChar) != (0xFF00 & sLastChar )     ) ) 
      sRC = 0;
   else
   if (LOBYTE(sLastChar) < LOBYTE(sFirstChar))
   {
      sRC = 0;    // impossible
   }
   else if (lppd->sMagic == LUCAS)
   {
      if (!(lpFontInfo->dfType & TYPE_TRUETYPE))
      {
         lpFontExtra = (LPFONTEXTRA) BUMPFAR (lpFontInfo, lpFontInfo->dfDriverInfo);
         sRC = 1;

         bDBCSChar = bDBCSCharSet && (0xFF00 & sFirstChar);

         if(lpFontInfo->dfExtentTable && !lpFontExtra->dwWidths)
            ScaleDevCharWidths(lppd, lpFontInfo) ;  // initialize tables.

         if(lpFontExtra->dwWidths)
         {
            CharWidthTbl=(LPSHORT)BUMPFAR (lpFontInfo, lpFontExtra->dwWidths);

            // get a scaled copy of the default character width

            sDefCharWidth= *(CharWidthTbl + FontDefaultChar);
         }
         else
         {
            sDefCharWidth = lpFontInfo->dfAvgWidth;
         }

         // set the widths of characters in the valid range
         if( bDBCSChar )
         {
            sFirstChar = LOBYTE(sFirstChar);
            sLastChar = LOBYTE(sLastChar);
         }
         for (ch=sFirstChar; ch<sLastChar+1; ch++)
         {
            if((ch < FontFirstChar) || (ch > FontLastChar))
            {
               *lpsCharWidth=sDefCharWidth  ;
            }
            else
            {
               if(lpFontInfo->dfPitchAndFamily & 1)
               {
                  // proportional font
                  if( bDBCSChar )
                     *lpsCharWidth= lpFontInfo->dfMaxWidth;
                  else
                  *lpsCharWidth= *(CharWidthTbl+(ch - FontFirstChar));
               }
               else
               {
                  // fixed pitch font...no need to scale this because
                  // it is already scaled
                  //
                  if( bDBCSChar )
                     *lpsCharWidth= lpFontInfo->dfMaxWidth;
                  else
                  *lpsCharWidth=lpFontInfo->dfAvgWidth;
               }
            }
            lpsCharWidth++;       // get ready for the next one
         }  // for(..)
      }
      else  // if TrueType
      {
         LOGFONT LogFont ;
         LPPSFONTINFO  lpActualFI;    // points to FontInfo actually used.

         lpActualFI = lpFontInfo ;
         LogFont = lpTTFontInfo->lfCopy ;
         sRC = 1;

         if(LogFont.lfEscapement || LogFont.lfOrientation)
         {
            if(lpTTFontInfo->zeroEscapementFont)
               lpActualFI = lpTTFontInfo->zeroEscapementFont ;
            else
            {
               //  we need to create the zeroEscapementFont
         
               TEXTXFORM   txfCopy ;
               WORD        cb, wSize, flags ;

               if(lpFontInfo->dfType & PF_GLYPH_INDEX)
                  flags = 0 ;
               else
                  flags = 0x0001 ;



               /* make font as unhinted with 0 escapment with rest of 
                  LOGFONT same  */
               LogFont.lfEscapement = LogFont.lfOrientation = 0;

               /* allocate space for new font */

               if (lpFontInfo->dfType & TYPE_ATMFONT)
               {
                   wSize = EngineRealizeFont((LPLOGFONT) &LogFont,
                                       (LPTEXTXFORM) NULL ,
                                       (LPPSFONTINFO) NULL);
               
               }
               else
               {
                   wSize = (WORD)EngineRealizeFontExt(lppd->hdc, (LPLOGFONT) &LogFont,
                                       (LPTEXTXFORM) NULL ,
                                       (LPPSFONTINFO) NULL, flags );
               }
               
               lpActualFI = lpTTFontInfo->zeroEscapementFont = 
                     GlobalAllocPtr(GHND|GMEM_DDESHARE, wSize) ;
               if (!lpActualFI)
                   return 0; // fail
                   
               if (lpFontInfo->dfType & TYPE_ATMFONT)
               {
                   cb = EngineRealizeFont((LPLOGFONT) &LogFont,
                                       (LPTEXTXFORM) &txfCopy,
                                       (LPPSFONTINFO)lpActualFI);
               }
               else
               {
                   cb = (WORD)EngineRealizeFontExt(lppd->hdc, (LPLOGFONT) &LogFont,
                                       (LPTEXTXFORM) &txfCopy,
                                       (LPPSFONTINFO)lpActualFI, flags);
               }
               
               if(!cb)
               {
                  GlobalFreePtr(lpActualFI) ;
                  lpTTFontInfo->zeroEscapementFont = NULL ;
                  return(0);  // failed
               }
            }
         }


         if(lpFontInfo->dfType & PF_GLYPH_INDEX)
         {
            EngineGetCharWidthEx((LPPSFONTINFO)lpActualFI, sFirstChar, sLastChar, 
                        lpsCharWidth);
         }
         else
            EngineGetCharWidth((LPPSFONTINFO)lpActualFI, sFirstChar, sLastChar, 
                        lpsCharWidth);
      }
   }
   return(sRC);
}

