/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: FONTS.H                                                      */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHFontsDlg(HWND hdlg, unsigned msg, WORD wParam, 
                                   LONG lParam);

BOOL _loadds FAR PASCAL CHFontSubstitutionDlg(HWND hdlg, unsigned msg, 
                                              WORD wParam, LONG lParam);
BOOL _loadds FAR PASCAL CHSendAsDlg(HWND hdlg, unsigned msg, WORD wParam,
                                    LONG lParam);

void FAR PASCAL RestoreFontsDefaults(LPPSEXTDEVMODE lpPSExtDevmode, LPPDEVICE lppd);
void FAR PASCAL RestoreSendAsDefaults(LPPSEXTDEVMODE lpPSExtDevmode,  LPWPXBLOCKS lpWPXBlock);
int FAR PASCAL GetTTSendAsDefault(LPPSEXTDEVMODE lpPSExtDevmode, LPWPXBLOCKS lpWPXBlock);



