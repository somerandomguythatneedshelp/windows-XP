/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: TRUETYPE.H                                             */
/*                                                                           */
/* Description: This include contains the prototype for TRUETYPE.C           */
/*                                                                           */
/*****************************************************************************/

// high byte of dfType defines

#define TYPE_TRUETYPE       0x0100      // font is truetype
#define TYPE_TTRESIDENT     0x0200      // font is resident TrueType font
#define TYPE_HAVEWIDTHS     0x0400      // width table has been generated
#define TYPE_SETCONTEXT     0x0800      // remember to set font context
#define TYPE_OUTLINE        0x1000      // Type 1 outline
#define TYPE_SUBSTITUTED    0x2000      // TrueType substituted
#define TYPE_ATMFONT        0x4000      // ATM realized this font

// download flags
#define TTFLAGS_HEADERDOWN     0x0001   // header has been downloaded


#define TT_SEND_SEL_TYPE1       0
#define TT_SEND_SEL_TYPE3       1
#define TT_SEND_SEL_TYPE42      2
#define TT_SEND_SEL_TRUEIMAGE   2 /* Chicago */
#define TT_SEND_SEL_NONE_NO_TT  2
#define TT_SEND_SEL_NONE_TT     3

/* Chicago Begin */
#define RASTERIZER_ERROR     -1
#define RASTERIZER_NORMAL     1
#define RASTERIZER_TYPE42     2
#define RASTERIZER_TRUEIMAGE  3
/* Chicago End */

// more download flags from PSCRIPT.H of Microsoft's PS3.5 driver

#define DL_NOTHING  0x0000
#define DL_UNPACK   0x0001
#define DL_FONTS    0x0002
#define DL_CIMAGE   0x0004
#define DL_T3HEADER     0x0008

// Engine Glyph flags

#define FD_QUERY_CHARIMAGE  1
#define FD_QUERY_OUTLINE    2

// smallest ppem size for honoring User request to download Type 1 outline
//     ppem >= MINOUTLINEPPEM -> outline (if not downloaded already)
//     ppem <  MINOUTLINEPPEM -> bitmap
#define MINOUTLINEPPEM    101

// largest ppem size for honoring User request to download Type 3 bitmap
//     ppem <  MAXBITMAPPPEM -> bitmap (if not downloaded already)
//     ppem >= MAXBITMAPPPEM -> outline (Type 1)
#define MAXBITMAPPPEM    500

#define NCHARS 256

#define CWGLYPHFLAGS (NCHARS/(8*sizeof(WORD)))

#define MAKEFIXED(n) ((LONG)(n)<<16)
#define FROMFIXED(n) HIWORD(n)

#define ROT_PORT MAKEFIXED(0)      // rotation for portrait
#define ROT_LAND MAKEFIXED(270)    // rotation for landscape

#define LVHWORD(l) (((WORD FAR *)&l)[1])
#define LVLWORD(l) (((WORD FAR *)&l)[0])

//pertains to loca table
#define MAX_GLYPH_LENGTH 64000 //64k
#define LOCA_TBL_FAULTY -1
#define LOCA_TBL_OK 1

/* Flags for TTFontInfo's dwProperties; --  32 flags for Driver's purpose */
#define TTFI_LOCA_TBL_FAULTY   0x00000001L
#define TTFI_LOCA_TBL_OK       0x00000002L
#define TTFI_IS_REAL_TT        0x00000004L
#define TTFI_IS_TYPE42ABLE     0x00000008L



typedef LONG TTFIXED;
typedef unsigned long ULONG;

//typedef WORD FAR * LPINT;

typedef BYTE huge * LPDIBITS;

typedef unsigned short USHORT;

typedef struct _ttpointfx
{
    TTFIXED x;
    TTFIXED y;
}   TTPOINTFX;

//-------------------------------------
//
//  typedef struct _sizel
//  {
//      LONG cx;
//  LONG cy;
//  }   SIZEL;

typedef struct _bitmapmetrics
{
    SIZEL sizlExtent;
    TTPOINTFX pfxOrigin;
    TTPOINTFX pfxCharInc;
}   BITMAPMETRICS, FAR * LPBITMAPMETRICS;

typedef struct _ttfontinfo
{
    LPWORD prgfGlyphDown;
    WORD  TTRefEM;      // the EM square at which the TT font was rasterized at
    WORD  HighByte ;    // low byte of this word is Zero.
    int sx, sy;
    long lid;
    short lfPoints;
    BYTE  TTFaceName[FONTNAMESIZE];
    LOGFONT lfCopy;
    TEXTXFORM ftCopy;
    HANDLE hFontInfo;  // copy realized at TTRefEM = 2048; for Type 1 only
    WORD    wXFontInfoSize; //size of xFontInfo Structure
    DWORD   dwXFontInfo; //offset to xFontInfo Structure
    char PSName[FONTNAMESIZE];
    DWORD  dwSubFontInfo;  //offset from FontInfo to Substituted font
    LPPSFONTINFO  zeroEscapementFont ;  // used if LogFont has non-zero esc.

    WORD  wTTFlags;    // return value from EngineRealizeFontExt

    LPWORD  Widths;     // Reintroduced for ATM.
    WORD    sizWidths;
    WORD    maxNumGlyph;
    int     iDLFontFormat;   /* Value returned from CheckDLType() */
    DWORD   dwProperties;    /* 32 flags for Driver's purpose */
}   TTFONTINFO, FAR * LPTTFONTINFO;

typedef struct _POLYGONHEADER 
{ 
    ULONG cb;
    ULONG iType;    /*  Must be FD_POLYGON_TYPE */
    TTPOINTFX pteStart;   
}   POLYGONHEADER;

typedef POLYGONHEADER FAR *LPPOLYGONHEADER;

typedef struct _FDPOLYCURVE 
{ /* fdpc */
  USHORT iType;     /* Must be either FD_PRIM_LINE, FD_PRIM_SPLINE,   */
                    /* or FD_PRIM_FLT                  */
  USHORT cptfx;   /* Number of points */
  TTPOINTFX pte[1];
} FDPOLYCURVE;

typedef FDPOLYCURVE FAR *LPFDPOLYCURVE;

#define FD_POLYGON_TYPE 24
#define FD_PRIM_LINE 1
#define FD_PRIM_QSPLINE 2 
#define FD_PRIM_SPLINE 3
#define FD_PRIM_FLT 7

#define ISCHARDOWN(lpttfi,ch) (((lpttfi)->prgfGlyphDown[(ch)/16]) & (1 << ((ch)%16)))
#define SETCHARDOWN(lpttfi,ch) (((lpttfi)->prgfGlyphDown[(ch)/16]) |= (1 << ((ch)%16)))
#define CLRCHARDOWN(lpttfi,ch) (((lpttfi)->prgfGlyphDown[(ch)/16]) &= ~(1 << ((ch)%16)))

// bit flags for the return value of EngineRealizeFont
#define ERF_SUCCESS     0x0001
#define ERF_XY_SCALING  0x0002
#define ERF_SIM_ITALIC  0x0080
#define ERF_SIM_BOLD    0x0040
#define ERF_SIMULATED   (ERF_SIM_ITALIC | ERF_SIM_BOLD | ERF_XY_SCALING)

/*
 *  GDI Engine exports
 */

WORD FAR PASCAL EngineRealizeFont(LPLOGFONT, LPTEXTXFORM, LPPSFONTINFO);
DWORD  FAR PASCAL EngineRealizeFontExt( HDC , LPLOGFONT, LPTEXTXFORM,
                    LPPSFONTINFO, WORD );
WORD FAR PASCAL EngineDeleteFont(LPPSFONTINFO);
WORD FAR PASCAL EngineEnumerateFont(LPSTR, FARPROC, DWORD);
WORD FAR PASCAL EngineGetCharWidth(LPPSFONTINFO, WORD, WORD, LPINT);
WORD FAR PASCAL EngineGetCharWidthEx(LPPSFONTINFO, WORD, WORD, LPINT);
WORD FAR PASCAL EngineSetFontContext(LPPSFONTINFO,WORD);
int  FAR PASCAL EngineGetGlyphBmp(WORD,LPPSFONTINFO,WORD,WORD,LPSTR,DWORD,LPBITMAPMETRICS);
// wrapper function to get around ATM 2.6 zero'ing out high byte of 
// glyph indices
DWORD FAR PASCAL EngineGetGlyphBmpExt(HDC, LPPSFONTINFO,WORD,WORD,LPSTR,
                                   DWORD,LPBITMAPMETRICS);

PSERROR FAR PASCAL TTDownLoadFont(LPPDEVICE lpdv, LPPSFONTINFO lpdf, BOOL bFullFont, LPFONTDATARECORD lpFontDataRecord, BOOL minHeader);
int FAR PASCAL TTUpdateFont(LPPDEVICE lpdv, LPPSFONTINFO lpdf, LPSTR lpStr, int cb, LPFONTDATARECORD lpFontDataRecord, BOOL minHeader); 
LPWORD /* int */ FAR PASCAL TTLockFont(LPPDEVICE lpdv, LPPSFONTINFO lpdf, LPFONTDATARECORD lpFontData);
void FAR PASCAL TTUnlockFont(LPPDEVICE lpdv, LPPSFONTINFO lpdf, LPFONTDATARECORD lpFontData);

/*
void FAR PASCAL TTFlushFonts(LPDV lpdv);
BOOL FAR PASCAL IsTrueTypeEnabled(void);
void FAR PASCAL TTSetBaseFont(LPDV lpdv, LPDF lpdf, LPDF lpdfBase);
*/
LPPSFONTINFO FAR PASCAL TTGetBaseFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPFONTDATARECORD lpFontData);

// Utilities imported from Microsoft's PS3.5 Driver, to support TrueType

int  FAR PASCAL Scale(int, int, int);      /* in SCALE.ASM */
short   FAR PASCAL RCos(short, short);  /* in trig.asm */
short   FAR PASCAL RSin(short, short);

// The following is TYPE 1 specific, from PST1ENC.H (from PS3.5) 

// TYPE 1 commands for use with CharString().  The high word contains the
// number of operands on the stack, and the loword contains the encoding
// of the command.  For two byte commands the LSB of the low word contains
// 12 decimal and the MSB of the low word contains the second byte of the
// code.  See Chapter 6 of the Black Book for further details.

#define STARTCHAR   0xffffffffL // dummy command to signal start of character
                                // definition.

#define PUSHNUMBER  0xfffffffeL // dummy command to place number on stack

#define HSTEM       0x00020001L
#define VSTEM       0x00020003L
#define VMOVETO     0x00010004L
#define RLINETO     0x00020005L
#define HLINETO     0x00010006L
#define VLINETO     0x00010007L
#define RRCURVETO   0x00060008L
#define CLOSEPATH   0x00000009L
#define SBW         0x0004070cL
#define HSBW        0x0002000dL
#define ENDCHAR     0x0000000eL 
#define RMOVETO     0x00020015L
#define HMOVETO     0x00010016L
#define VHCURVETO   0x0004001EL
#define HVCURVETO   0x0004001FL

// external types used
typedef BYTE NEAR *PBYTE;
typedef BYTE FAR *LPBYTE;
typedef DWORD NEAR *PDWORD;
typedef DWORD FAR *LPDWORD;
typedef LONG NEAR *PLONG;
typedef LONG FAR *LPLONG;

// initial r parameter to Encrypt() for the different encryption layers.
// See Chapter 7 of the Black Book for details.

#define RCS         4330u       // CharString encryption
#define REEXEC      55665u      // eexec encryption

/* prototypes */

void FAR PASCAL eexec(LPPDEVICE lppd, LPBYTE lpBuf, WORD len, BOOL  reset);
static DWORD FAR CharString(LPPDEVICE lppd, DWORD dwCmd, ...);
void FAR efprintf(LPPDEVICE lppd, LPSTR lpFmt, ...);
void FAR PASCAL StartEExec(LPPDEVICE lppd);
void FAR PASCAL EndEExec(LPPDEVICE lppd);
