/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: SCANLR.C                                                     */
/*                                                                           */
/* Description: This module contains the functions for ....                  */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_GRAPHSEG)


SHORT FAR PASCAL dmScanLR(LP,SHORT,SHORT,DWORD,SHORT);
/*****************************************************************************/
/*                 DevScanLR                                                 */
/* Purpose:                                                                  */
/*          Invokes dmScanLR                                                 */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/*                                                                           */
/*   LP    lpDevice -- pointer to                                            */
/*   SHORT sX                                                                */
/*   SHORT sY                                                                */
/*   DWORD dpColor                                                                */
/*   SHORT sStyle                                                                */
/*                                                                           */
/* Returns: SHORT                                                            */
/*****************************************************************************/

SHORT _loadds FAR PASCAL DevScanLR(LP lpDevice,SHORT sX,SHORT sY,DWORD dPColor,
                                   SHORT sStyle)
{
      SHORT sRC ;

      sRC = dmScanLR(lpDevice,sX,sY,dPColor,sStyle);

      return(sRC) ;
}
