/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: ENABLE.H                                               */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

BOOL FAR IsFilePort(LPSTR lpszPort);

PSERROR NEAR PASCAL   InitRealizeBuffers(LPPDEVICE  lppd) ;

PSERROR FAR PASCAL InitPDevice(LPPDEVICE lppd);
void  FAR  PASCAL  FreePDeviceBufs(LPPDEVICE lppd);

