/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993, 1994 Microsoft Corporation. All rights reserved.      */
/*                                                                           */
/* Adobe Patent or Adobe Patent Pending Invention Included Within this File  */
/*                                                                           */
/* Module Name: TTEXT.C                                                      */
/*                                                                           */
/* Description: This module contains TRANSLATE layer functions for font      */
/*              download, font instantiations such as basic font, bold font, */
/*              italic font, bolditalic font and a scaled font. Also, all    */
/*              text output functions invoked by the CONTROL layer function  */
/*              DevExtTextOut() are in this module. Almost all functions in  */
/*              this module generate output sent with the job stream.        */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include <string.h>
#include "encode2.h"
#include "ufoenc.h"

#pragma optimize ("", off)

#pragma code_seg(_TTEXTSEG)

// TrueType stuff:  Defines, Macros etc.

#ifndef T3OUTLINE
#define UPDATE_FAILURE  -1
#define UPDATE_LOWVM    0
#define UPDATE_SUCCESS  1
#else
#define bTTtoT3OL       1
#endif

#define DOWNLOADFONT    1
#define TRYDOWNLOADAGAIN   2
#define DOWNLOADDONE    3

#define TERMCHAR 3            // Terminating char for resources
#define CSALLOC 1000          // Initial size of CharString buffer
#define CSGROW  500           // Amount to grow CharString buffer on a ReAlloc

// TrueType related stuff:
#define GLYPHSIZE    50   // YCT

#ifndef T3OUTLINE
#define RemCSBuffer()   (lpTTtoT1stuff->lpCSEnd - lpTTtoT1stuff->lpCSPos)
                // # bytes free left in buffer
#endif

// Macro to compute no. of bytes bi bits takes when aligned on an al-byte boundary
#define BiToByAl(bi,al) (((bi)+(al)*8-1)/((al)*8)*(al))

#ifndef T3OUTLINE
// Macro to truncate the fraction from 16-16 fixed pt numbers
#define TRUNC(fixed)  ((LONG)fixed & 0xffff0000)
#endif

// List of font weight strings that will be plugged into the Type 1 header
// Note: This static is OK since it does not get changed - basically Read-Only.

static char *szWeight[] =  { "Thin", "ExtraLight", "Light", "Normal",
                      "Medium", "SemiBold", "Bold", "ExtraBold",
                      "Heavy"
                     };
static char Hex[]   = "0123456789ABCDEF";

void FAR PASCAL T32ReleaseFontCache(LPPDEVICE lppd, LPFONTDATARECORD lpFontDataRecord);
int NEAR PASCAL TTUpdateT3orT32Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPFONTDATARECORD lpFontData, LPBYTE lpStr, int cb);

#ifdef ADD_EURO
BOOL FAR PASCAL AddEuroToType1Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPFONTDATARECORD FontData);
#endif

// This BoldFakeThickness is no longer used in 4.2 or 4.1CJK.
#define BoldFakeThickness   0.035        // increasing it increases thickness

#define PI        3.1415926535
#define DEG2RAD   (float)(PI/180.0)
#define BOLDPRESENT       0x01
#define ITALICPRESENT     0x02
#define BOLDITALICPRESENT 0x04
#define ANYSTYLEPRESENT   0x08

#define CHARSET_NEED_REENCODE(cs)  \
          ( ( (cs) == 0 )   ||  \
            ( (cs) == 161 ) ||  \
            ( (cs) == 162 ) ||  \
            ( (cs) == 177 ) ||  \
            ( (cs) == 178 ) ||  \
            ( (cs) == 186 ) ||  \
            ( (cs) == 204 ) ||  \
            ( (cs) == 238 ) )

#define SAME_ASCENDER(a, b) (((int)((a+0.0005)*1000)) == ((int)((b+0.0005)*1000)))
#define GET_ASCENDER(a)  ((int)((a+0.0005)*1000))

typedef struct _HDR
{
  unsigned char flag;
  char type         ;
  long length       ;
}
HDR                 ;

typedef struct _PFA_HDR
{
  char ps_id [6];
}
PFA_HDR                 ;

//#ifdef STREAMER

/****************************************************************************
*                            UseType1Incr
*  Function:
*
*  Called:
*       BOOL UseType1Incr(LPPDEVICE lppd)
*
*  Parameters:
*       LPPDEVICE       lppd        pdevice pointer
*
*  Returns:
*    TRUE      use streamer to incrementally download type1 fonts
*    FALSE     bypass the streamer - do not incrementally download
*/
BOOL
UseType1Incr(LPPDEVICE lppd)
{
    int id;
                   /* 0 off, 1 on, 2 ask           */
    if (lppd->job.bfType1Incr == 2) {
//taken out 12/26/97 due to exceed 64k segment ang.
//        id = MessageBox(NULL, "Incrementally download Type1 fonts through the streamer ?",
//                                "Debug AdobePS", MB_ICONQUESTION|MB_YESNO);
        id = MessageBox(NULL, "I",
                                "D", MB_ICONQUESTION|MB_YESNO);
   lppd->job.bfType1Incr = (id == IDYES) ? 1 : 0;
    }
    return(lppd->job.bfType1Incr);
}
//#endif


VOID NEAR PASCAL SendEncodingVector(LPPDEVICE lppd, WORD CharSet)
{
    int procID = -1;

    switch(CharSet) 
    {
        // Encoding_0 is always sent with TEXT - and all Encodings needs TEXT
    case 0:   procID = TEXT;         break;
    case 161: procID = ENCODING_161; break;
    case 162: procID = ENCODING_162; break;
    case 177: procID = ENCODING_177; break;
    case 178: procID = ENCODING_178; break;
    case 186: procID = ENCODING_186; break;
    case 204: procID = ENCODING_204; break;
    case 238: procID = ENCODING_238; break;
    default: break;
    }
    
    if (procID >= 0)
    {
        // Encoding_0 is always sent with TEXT - and all Encodings needs TEXT
        TokenNeedsProcset(lppd, TEXT);
        TokenNeedsProcset(lppd, procID);
    }

}

/****************************************************************************************
*                       Text_CreateFontRecord
*  Function: This function is used by Min-headers to add the FontData to the FontDataList
*            Normal apps call TextBegin_CreatFont() which also creates F0
*  !!!We need the font in FontDataList to support Incremental TT Donwloading for Min-headers!!
****************************************************************************************/
VOID FAR PASCAL Text_CreateFontRecord(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                                 LPFONTDATARECORD FontData)
{
   LPFONTEXTRA FontExtra = (LPFONTEXTRA)BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO)((LPSTR)FontInfo+FontInfo->dfBitsOffset);
   FONTDATARECORD TempFontData                   ;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
#ifdef ADOBE_DRIVER
   // still keep this section so the added FontRecord willbe at the correct
   // savelevel.
   if (!TCleanToVMMark(lppd, 1)) {
   // add this to put %%BeginFont at the beginning of a line. fix a DSC bug.
      (*tempptr->PSSendCRLF)(lppd);
   }
#endif

   TempFontData = *FontData;       // init the local copy
   TempFontData.BoldFake   = FALSE                   ;
   TempFontData.ItalicFake = FALSE                   ;
   TempFontData.DBCSFake   = 0                       ;
   TempFontData.xScale     = 0                       ;
   TempFontData.yScale     = 0                       ;

   // add the new font data record to the list
   TempFontData.FontID = -1;       // have a new font id supplied
   TempFontData.GlyphData = FontData->GlyphData;
   TempFontData.pSubFont = FontData->pSubFont;

   // Fix bug 149729 - should not undefine a RAM font!!! set the flag here correct
   // Remmeber to Add the Downloaded TT font cases check here in 4.2, 5-23-96
   // ANG-6/7/96-Dont set xxx.fontDLType = 0 for T42 resident.
   // This is because we add the MSTT31xxx name to the FontDatalist instead
   // of ArialMT.
   if ( !(FontInfo->dfType & TYPE_TRUETYPE) &&
   (FontExtra->dwSoftFont == 0))
   {
      TempFontData.fontDLType = 0;  // This is Resident/Downloaded Font
   }
   if ( (FontInfo->dfType & TYPE_TRUETYPE) &&
      (lppd->lpPSExtDevmode->dm2.iDLFontFmt == TT_DLFORMAT_NONE ) )
   {
      TempFontData.fontDLType = 0;  // This is Resident/Downloaded Font
   }

   AddFontDataRecord(lppd,&TempFontData);
   // put the font id back into the input fontdata record
   FontData->FontID = TempFontData.FontID;

#ifdef ADOBE_DRIVER
   TSetVMMark(lppd, 1, TRUE);
#endif

}

/****************************************************************************************
*                       CreateReEncodeFont
*  Function:
*    This function is use to ReEncode a T42 Font that had been download.
*    This function is call for min header-character code mode only.
*    Postscript Centric Apps call CreateBasicFont to reEncode font.
*
*  Called:
*    void FAR PASCAL CreateReEncodedFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, BOOL bReEncode)
*  Parameters:
*       LPPDEVICE        lppd        pdevice pointer
*       LPPSFONTINFO       FontInfo    input fontinfo struct
*       LPFONTDATARECORD FontData
*
*  Returns:
*      nothing
****************************************************************************************/
void FAR PASCAL CreateReEncodedFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, BOOL bReEncode)
{
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO)((LPSTR)FontInfo+FontInfo->dfBitsOffset);
   LPFONTEXTRA FontExtra = (LPFONTEXTRA)BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
   char buff[128];
   LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   LPSTR lpszPSFace = NULL;

   PSSendFragment(lppd,PSFRAG_openbracket);
   if (FontInfo->dfType & TYPE_TRUETYPE)
   {
     PSSendString(lppd,lpTTFontInfo->PSName);       // MSTTXXX Name of TT font
   }
   else
   {
     lpszPSFace = (LPSTR) (FontInfo, FontExtra->dwPSFace);
     wsprintf(buff, "%s%04x",lpszPSFace, FontInfo->dfCharSet);     //for PS Font tack on CharSet
     PSSendString(lppd,buff);       // new re-encoded PostScript Name of font
   }
   PSSendFragment(lppd,PSFRAG_closebracket);
   PSSendFragment(lppd,PSFRAG_cvn);
   (*tempptr->PSSendCRLF)(lppd);

   wsprintf((LPSTR)buff,(LPSTR)"/%d ",FontInfo->dfCharSet);
   PSSendString(lppd,buff);                             // send char set number

   (*tempptr->PSSendBoolean)(lppd, bReEncode ? TRUE: FALSE);  //reEncode or not

   PSSendFragment(lppd,PSFRAG_openbracket);
   if (FontInfo->dfType & TYPE_TRUETYPE)
      PSSendString(lppd,lpTTFontInfo->TTFaceName);       // PostScript Name of TT font
   else
   {
      lpszPSFace = (LPSTR) (FontInfo, FontExtra->dwPSFace);
      PSSendString(lppd,lpszPSFace);       // PostScript Name of font
   }
   PSSendFragment(lppd,PSFRAG_closebracket);
   PSSendFragment(lppd,PSFRAG_cvn);

   PSSendFragment(lppd, PSFRAG_min_mF);
   (*tempptr->PSSendCRLF)(lppd);

}


//============================================================================
//
// GetCMapPointer and NeedVerticalRearrangement
//
// For AdobePS 4.1 CJK, the GetCMapPointer and NeedVerticalRearrangement
// functions refer to the same static string array szCMapList.
// When the driver begins to support PPD version 4.3, the GetCMapPointer
// function should be modified to refer to new CMap names taken from *Font
// lines in the PPD, then szCMapList.
// But szCMapList and the NeedVerticalRearrangment function should not be
// modified. No new CMap name should be added to szCMapList. No change should
// be made to the NeedVerticalRearrangement function. By doing nothing to
// them, we can keep notify mF_V_FE procset that a vertical font with one of
// those CMap names in szCMapList need to be rearranged.
// In other words, any vertical font with CMap name not listed in szCMapList
// is supposed to be required no rearrangement.
//
//============================================================================

// Ken Lunde says only these on Windows side. 5-14-96
static LPSTR TTEXTSEG szCMapList[] =
{
   // Do not change the order!
   // CMap names for J
   "-90ms-RKSJ-",
   "-83pv-RKSJ-",
   "-Ext-RKSJ-",
   "-Add-RKSJ-",
   "-78-RKSJ-",
   "-RKSJ-",     /*it's short, must be the last one for J */

   // CMap names for CS
   "-GB-EUC-",
   "-GBT-EUC-",
   "-GBK-EUC-",

   // CMap names for CT
   "-ETen-B5-",
   "-B5-",   // this one is used only if ETen-B5 is not found */

   // CMap names for K
   "-KSC-EUC-",
   "-KSC-Johab-",
   "-KSCms-UHC-",

   // Do not remove the line below!
   (LPSTR)0
};

static LPSTR GetCMapPointer(LPSTR szFontName)
{
   LPSTR s;
   int i;

   for (i = 0; szCMapList[i]; i++)
   {
      if ((s = _fstrstr(szFontName, szCMapList[i])) != NULL)
      {
         if (*(s - 1) == '-') s--;
         return s;
      }
   }

   // s is either a valid pointer or zero.

   return (LPSTR)0;
}

static BOOL NeedVerticalRearrangement(LPSTR lpCMap)
{
   BOOL bResult = FALSE;
   LPSTR s1, s2;
   int i;

   if (lpCMap)
   {
      for (i = 0; s1 = szCMapList[i]; i++)
      {
         s1++; // don't consider the first hypen(-)
         if ((s2 = _fstrstr(lpCMap, s1)) != NULL)
         {
            bResult = TRUE;
         }
      }
   }

   return bResult;
}


/****************************************************************************************
*                       TextBegin_CreateBasicFont
*  Function:
*
*  Called:
*      VOID FAR PASCAL TextBegin_CreateBasicFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
*                                      LPFONTDATARECORD FontData)
*  Parameters:
*       LPPDEVICE        lppd        pdevice pointer
*       LPPSFONTINFO       FontInfo    input fontinfo struct
*       LPFONTDATARECORD FontData
*
*  Returns:
*      nothing
****************************************************************************************/

VOID FAR PASCAL TextBegin_CreateBasicFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                                 LPFONTDATARECORD FontData)
{
   LPFONTEXTRA FontExtra = (LPFONTEXTRA)BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO)((LPSTR)FontInfo+FontInfo->dfBitsOffset);
   FONTDATARECORD TempFontData                   ;
   LPASCIIBINPTRS tempptr;
   char  FontName[128]                           ;
   float Ascender                   ;
   char  buff[5]; //temporary use to store charset
   LPSTR lpszPSFace = NULL;


   // Download proper Non-Ansi Encoding vector if necessary
   // For Downloaded TrueType fonts, DownLoadFont() already sends proper Encoding_x.
   // This is for PostScript fonts only, Fix bug 199143, PPeng, 3-18-97
   // This should be done before CleanToVMMark() !!
   // Be very careful - if we ever changes the Save/Resore again
   if ( !(FontInfo->dfType & TYPE_TRUETYPE) && 
        CHARSET_NEED_REENCODE(FontInfo->dfCharSet) ) 
   {
       SendEncodingVector(lppd, (WORD)FontInfo->dfCharSet) ;
   }

   // Load the font ascender factors if none (Bug#277500)
   if (FontData->ascender == 0) {
      if (!(FontInfo->dfType & TYPE_TRUETYPE))
         FontData->ascender = (float)FontInfo->dfAscent/(float)FontExtra->sPSyScale;
      else
         FontData->ascender= (float)FontInfo->dfAscent/(float)lpTTFontInfo->sy;
   }

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
#ifdef ADOBE_DRIVER
   if (!TCleanToVMMark(lppd, 1)) {
   // add this to put %%BeginFont at the beginning of a line. fix a DSC bug.
      (*tempptr->PSSendCRLF)(lppd);
   }

#endif
   TempFontData = *FontData;       // init the local copy

   TempFontData.BoldFake   = FALSE                   ;
   TempFontData.ItalicFake = FALSE                   ;
   TempFontData.xScale     = 0                       ;
   TempFontData.yScale     = 0                       ;
   TempFontData.addAscExt  = 0                       ;  //Bug #277500

   // add the new font data record to the list
   TempFontData.FontID = -1;       // have a new font id supplied
   TempFontData.GlyphData = FontData->GlyphData;

   // Fix bug 149729 - should not undefine a RAM font!!! set the flag here correct
   // Remmeber to Add the Downloaded TT font cases check here in 4.2, 5-23-96
   if ( !(FontInfo->dfType & TYPE_TRUETYPE) &&
   (FontExtra->dwSoftFont == 0))
   {
      TempFontData.fontDLType = 0;  // This is Resident/Downloaded Font
   }
   if ( (FontInfo->dfType & TYPE_TRUETYPE) &&
      (lppd->lpPSExtDevmode->dm2.iDLFontFmt == TT_DLFORMAT_NONE ) )
   {
      TempFontData.fontDLType = 0;  // This is Resident/Downloaded Font
   }

   AddFontDataRecord(lppd,&TempFontData);

   // put the font id back into the input fontdata record
   FontData->FontID = TempFontData.FontID;
   FontInstName(FontName,&TempFontData)          ;

   Ascender = (float)FontData->ascender          ;
#ifdef ADD_EURO
   if (!(FontInfo->dfType & TYPE_TRUETYPE))
   {
      // Add Euro to the font when it is a PS font in Non-Symbol charset
      AddEuroToType1Font(lppd, FontInfo, FontData);
   }
#endif

   if ( !(FontInfo->dfType & TYPE_TRUETYPE) &&
     (FontExtra->dwSoftFont == 0))
   {
     lpszPSFace = (LPSTR) BUMPFAR (FontInfo, FontExtra->dwPSFace);
     TSendFontDSC(lppd, lpszPSFace); // Send font DSC comments
   }

   if ( (FontInfo->dfType & TYPE_TRUETYPE) &&
      (lppd->lpPSExtDevmode->dm2.iDLFontFmt == TT_DLFORMAT_NONE ) )
   {
     TSendFontDSC(lppd, lpTTFontInfo->PSName); // Send font DSC comments
   }

   // Send TRUE flag if the font's roman needs H-83pv surgery - this is J-only
   if ( !(lppd->fDBCS & (DBCS_83PV_VERT)) )
   {
      if ( !(FontInfo->dfPitchAndFamily & 0x01)
       && lppd->fDBCS & DBCS_DEVICE
       && !(FontInfo->dfType & TYPE_TRUETYPE)   // Fix bug 156229
       && !Is90ms(FontData->FontName) 
       && (FontInfo->dfCharSet == SHIFTJIS_CHARSET)
       )
      {
         (*tempptr->PSSendBoolean)(lppd, TRUE);
      }
      else
      {
         (*tempptr->PSSendBoolean)(lppd, FALSE);
      }
   }
   else
   {
      (*tempptr->PSSendBoolean)(lppd, FALSE);
   }

   PSSendFragment(lppd,PSFRAG_slash);
   PSSendString(lppd,FontName);             // Send font instance name ( /F0 )
   PSSendString(lppd,SPACE);

   (*tempptr->PSSendFloat)(lppd,Ascender);    // flAscender (or sHeight / sSy)

   //  Re-encode font only when it is PostScript and ANSI charset
   wsprintf((LPSTR)buff,(LPSTR)"/%d ",FontInfo->dfCharSet);
   PSSendString(lppd,buff);       // send char set number

    // Send TRUE flag when it is a PS font in Non-Symbol charset OR an FE -CJK vertical PS font.
    // Add Non-Ansi reencoding, Fix bug 199143, PPeng, 3-18-97

    if ( ( !(FontInfo->dfType & TYPE_TRUETYPE) && 
          CHARSET_NEED_REENCODE(FontInfo->dfCharSet) && FontData->ReEncodable ) 
        ||
       ( !(FontInfo->dfType & TYPE_TRUETYPE) && lppd->fDBCS & DBCS_VERT )
      )
    {      //re-encode or do Vertical
        (*tempptr->PSSendBoolean)(lppd, TRUE);
    }
    else
    {  //no need to re-encode
        (*tempptr->PSSendBoolean)(lppd, FALSE);
    }

   PSSendFragment(lppd,PSFRAG_openbracket);
   if  ((FontData->fontDLType == CC_42)&&   //get PS name from TTFace Name if TT(T42)_CC_RESIDENT
    (FontInfo->dfType & TYPE_TTRESIDENT) )
      PSSendString(lppd,lpTTFontInfo->TTFaceName);       // PostScript Name of TT font ie. ArialMT
   else
      PSSendString(lppd,FontData->FontName);       // PostScript Name of font
   PSSendFragment(lppd,PSFRAG_closebracket);
   PSSendFragment(lppd,PSFRAG_cvn);

   if (!(FontInfo->dfType & TYPE_TRUETYPE) &&
      IsDBCSCharSet(FontInfo->dfCharSet))
   {
      static LPSTR GetCMapPointer(LPSTR);

      char szCIDFont[128]; // assume big enough
      LPSTR lpCMap;
      LPSTR szmFName;

      // Split the font name into a CIDFont and CMap.

      lstrcpy(szCIDFont, FontData->FontName);

      lpCMap = GetCMapPointer(szCIDFont);

      if (lpCMap)
      {
         // lpCMap points '-cmap' or '--cmap'.

         *lpCMap++ = '\0';
         if (*lpCMap == '-') *lpCMap++;

         // szCIDFont now consists of a CIDFont name only, and
         // lpCMap points its CMap name.

         PSSendString(lppd, "/");
         PSSendString(lppd, szCIDFont);
         PSSendString(lppd, " /");
         PSSendString(lppd, lpCMap);
      }
      else
      {
         // Failed to identify the CMap name.
#if PSDEBUG
MessageBox(NULL, "Error!!, FontName is NOT in CIDFont-CMAP format", szCIDFont, MB_OK);
#endif
         PSSendString(lppd, "/");
         PSSendString(lppd, szCIDFont);
         PSSendString(lppd, " /UnknownCMap");  // TO be fixed later. ?????
      }

      // Spit a character set value. Use szCIDFont temporarily.

      wsprintf(szCIDFont, " %d ", FontInfo->dfCharSet);
      PSSendString(lppd, szCIDFont);

      (*tempptr->PSSendCRLF)(lppd);

      // spit DBCS specific procset call that can handle
      // both OCF and CID fonts.

      if ((lppd->fDBCS & DBCS_83PV_VERT) &&
         (FontInfo->dfCharSet == SHIFTJIS_CHARSET))
      {
         szmFName = "mF_83V_FE"; // J-specific
      }
      else if (lppd->fDBCS & DBCS_VERT)
      { // common to CJK
         szmFName = NeedVerticalRearrangement(lpCMap) ?
                  "true mF_V_FE" : "false mF_V_FE";
      }
      else
      {
         szmFName = "mF_FE"; // common to CJK
      }

      PSSendString(lppd, szmFName);
   }
   else
      PSSendFragment(lppd,PSFRAG_mF);
   (*tempptr->PSSendCRLF)(lppd);
#ifdef ADOBE_DRIVER
   TSetVMMark(lppd, 1, TRUE);
#endif
}


/****************************************************************************************
*                        TextBegin_CreateBoldItalic
*  Function:
*
*  Called:
*      VOID FAR PASCAL TextBegin_CreateBoldItalic(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
*                                      LPFONTDATARECORD FontData)
*  Parameters:
*       LPPDEVICE        lppd        pdevice pointer
*       LPPSFONTINFO       FontInfo    input fontinfo struct
*       LPFONTDATARECORD FontData
*
*  Returns:
*      nothing
****************************************************************************************/

VOID FAR PASCAL TextBegin_CreateBoldItalic(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                  LPFONTDATARECORD FontData)
{
   LPFONTEXTRA FontExtra = (LPFONTEXTRA)BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO)((LPSTR)FontInfo+FontInfo->dfBitsOffset);
   FONTDATARECORD   TempFontData;
   LPASCIIBINPTRS tempptr;

   char  FontName[128];
   float Ascender;
   float Overhang;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

#ifdef ADOBE_DRIVER
   if (FontData->ItalicFake || FontData->BoldFake)
   {
      TCleanToVMMark(lppd, 1);
   }
#endif
   if (FontData->ItalicFake)
   {
      TempFontData = *FontData;
      TempFontData.GlyphData0 = NULL;  // this one should not inherite this info
      TempFontData.lpW1ByteGI=NULL;

      TempFontData.GlyphData = NULL;
      TempFontData.xScale = 0;
      TempFontData.yScale = 0;
      TempFontData.BoldFake = FALSE;

      // This is a copy only. lpGiTable is not allocated for this instance
      TempFontData.isMylpGITable = 0;
     // store the new font instance in the font instance database

       //we need this for UFL.
       TempFontData.isMypSubFont = 0; //not mine.
       TempFontData.pSubFont = FontData->pSubFont;

      AddFontDataRecord(lppd, &TempFontData);

     // create a name for the fakeitalic form
     FontInstName(FontName,&TempFontData);
     PSSendFragment(lppd,PSFRAG_slash);
     PSSendString(lppd,FontName);     // Send "/Name" for fake italic (/F0I)
     PSSendString(lppd,SPACE);

     // create a name for the base form on which this font is based
     TempFontData.ItalicFake = FALSE;
     FontInstName(FontName,&TempFontData);
     PSSendString(lppd,FontName);     // Send "Name" (/F0)
     PSSendString(lppd,SPACE);

     // The overhang is defined as :
     //
     //      Overhang = Ascender * tan(12 degrees)
     //
     Ascender   = (float)FontInfo->dfAscent;
     if (!(FontInfo->dfType & TYPE_TRUETYPE))
     {
       Ascender   = Ascender/(float)FontExtra->sPSyScale;
     }
     else
     {
       Ascender   = Ascender/(float)lpTTFontInfo->sy;
     }

     Overhang   = Ascender*(float)tan((double)(12.0*DEG2RAD));

     (*tempptr->PSSendFloat)(lppd,Overhang);   // send the "Overhang"

     // send the operator
      if (FontData->fontDLType == CC_CID){
     // Use this one for T0/CIDFont - italizable just as for plain T1 font
       PSSendFragment(lppd,PSFRAG_mIF);
      }
      else {
   if (FontData->DBCSFake & DBCS_DEVICE_FAKE)
      PSSendFragment(lppd,PSFRAG_mIFK);
    else
      PSSendFragment(lppd,PSFRAG_mIF);
      }
     (*tempptr->PSSendCRLF)(lppd);
   }

   if (FontData->BoldFake) // old-boldfake-condition && !(FontData->DBCSFake & DBCS_DEVICE_FAKE))
   {
      TempFontData = *FontData;
      TempFontData.GlyphData0 = NULL;  // this one should not inherite this info
      TempFontData.lpW1ByteGI=NULL;

      TempFontData.GlyphData = NULL;
      TempFontData.xScale = 0;
      TempFontData.yScale = 0;

       //we need this for UFL.
       TempFontData.isMypSubFont = 0; //not mine.
       TempFontData.pSubFont = FontData->pSubFont;

      // This is a copy only. lpGiTable is not allocated for this instance
      TempFontData.isMylpGITable = 0;
     // store the new font instance in the font instance database
     AddFontDataRecord(lppd,&TempFontData);

     // create a name for the fakebold form  (may also be fake italic) (F0B)
     FontInstName(FontName,&TempFontData);
     PSSendFragment(lppd,PSFRAG_slash);
     PSSendString(lppd,FontName);     // Send "/Name" for fake bold
     PSSendString(lppd,SPACE);

     // create a name for the base form on which this font is based
     // base form could be fake italic created a few lines above, So...
     //  TempFontData.ItalicFake = FALSE; will cause a bug!! Comment it out.
     TempFontData.BoldFake = FALSE;
     FontInstName(FontName,&TempFontData);
     (*tempptr->PSSendFloat)(lppd,(float)BoldFakeThickness);

     PSSendString(lppd,FontName);       // Send "Name" for base font
     PSSendString(lppd,SPACE);

     // send the operator
     PSSendFragment(lppd,PSFRAG_mBF);
     (*tempptr->PSSendCRLF)(lppd);

      // Send the step used to Smear a font to fake-embolding
      // Borrow buffer FontName here: - it is not used later on
     (*tempptr->PSSendFloat)(lppd, (float)(lppd->DeviceRes.x_res/300.0));
      wsprintf(FontName, " /sBdx exch def ");
     PSSendString(lppd,FontName);
     (*tempptr->PSSendCRLF)(lppd);

   }
#ifdef ADOBE_DRIVER
   if (FontData->ItalicFake || FontData->BoldFake)
   {
        TSetVMMark(lppd, 1, TRUE);
   }
#endif
}


/****************************************************************************************
*                        TextBegin_CreateNewCharSet
*  Function:
*
*  Called:
*      VOID FAR PASCAL TextBegin_CreateNewCharSet(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
*                                      LPFONTDATARECORD FontData)
*  Parameters:
*       LPPDEVICE        lppd        pdevice pointer
*       LPPSFONTINFO       FontInfo    input fontinfo struct
*       LPFONTDATARECORD FontData
*
*  Returns:
*      nothing
****************************************************************************************/

VOID FAR PASCAL TextBegin_CreateNewCharSet(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                  LPFONTDATARECORD FontData)
{
   // Do nothing. It is a placeholder to extend for multilingual Fonts.
   // Type42 is no longer Multi-lingual anymore. 8-31-95
   return;
}



/****************************************************************************************
*                        TextBegin_CreateScaled
*  Function:
*
*  Called:
*      VOID FAR PASCAL TextBegin_CreateScaled(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
*                                             LPFONTDATARECORD FontData)
*  Parameters:
*       LPPDEVICE        lppd        pdevice pointer
*       LPPSFONTINFO       FontInfo    input fontinfo struct
*       LPFONTDATARECORD FontData
*
*  Returns:
*      nothing
****************************************************************************************/

VOID FAR PASCAL TextBegin_CreateScaled(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
        LPFONTDATARECORD FontData)
{
   LPFONTEXTRA FontExtra = (LPFONTEXTRA) BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO)((LPSTR)FontInfo+FontInfo->dfBitsOffset);
   FONTDATARECORD TempFontData;
   LPASCIIBINPTRS tempptr;
   BOOL  oldVal;

   char  FontName[128];
   int yScale;
   int xScale;
   char *op0[]           = {"xF "  ,"xBF "  }    ;
   char *op1[]           = {"xMF " ,"xMBF " }    ;
   BOOL BoldFake         = FontData->BoldFake     ;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   if (!(FontInfo->dfType & TYPE_TRUETYPE))
   {
     yScale            = FontExtra->sPSyScale  ;
     xScale            = FontExtra->sPSxScale  ;
   }
   else
   {
     yScale = lpTTFontInfo->sy;
     xScale = lpTTFontInfo->sx;
   }

   // This is a copy only. lpGiTable is not allocated for this instance
   oldVal = FontData->isMylpGITable;
   FontData->isMylpGITable = 0;
   // store the new font instance in the font instance database
   AddFontDataRecord(lppd, FontData);
   FontData->isMylpGITable = oldVal;

   // create a name for the new font instance
   FontInstName(FontName, FontData)              ;
   PSSendFragment(lppd,PSFRAG_slash);
   PSSendString(lppd, FontName);       // Send "/Name" (/F0_42)
   PSSendString(lppd, SPACE);

   // create a name for the font instance on which this font is based
   TempFontData = *FontData;
   TempFontData.yScale = 0;
   TempFontData.xScale = 0;
   TempFontData.GlyphData0 = NULL;  // this one should not inherite this info
   TempFontData.lpW1ByteGI=NULL;

   TempFontData.GlyphData = NULL;
   // This is a copy only. lpGiTable is not allocated for this instance
   TempFontData.isMylpGITable = 0;

   TempFontData.isMypSubFont = 0; //not mine.
   TempFontData.pSubFont = FontData->pSubFont;

   FontInstName(FontName,&TempFontData);
   PSSendString(lppd, FontName);       // Send "Name" of base font
   PSSendString(lppd, SPACE);

   if (xScale == yScale)
   {
     (*tempptr->PSSendShort)(lppd,yScale);
     PSSendString(lppd,op0[BoldFake==TRUE]);
     (*tempptr->PSSendCRLF)(lppd);
   }
   else
   {
     (*tempptr->PSSendShort)(lppd,xScale);
     (*tempptr->PSSendShort)(lppd,0);
     (*tempptr->PSSendShort)(lppd,0);
     (*tempptr->PSSendShort)(lppd,yScale);
     (*tempptr->PSSendShort)(lppd,0);
     (*tempptr->PSSendShort)(lppd,0);
     PSSendString(lppd, op1[BoldFake==TRUE]);
     (*tempptr->PSSendCRLF)(lppd);
   }

}


/****************************************************************************************
*                        TextBegin_CreateNewAscender
*  Function:
*
*  Called:
*      VOID FAR PASCAL TextBegin_CreateNewAscender(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
*                                      LPFONTDATARECORD FontData, float ascender)
*  Parameters:
*       LPPDEVICE        lppd        pdevice pointer
*       LPPSFONTINFO       FontInfo    input fontinfo struct
*       LPFONTDATARECORD FontData
        float            oldAscender
*
*  Returns:
*      nothing
****************************************************************************************/

//Added this procedure for Bug#277500

VOID FAR PASCAL TextBegin_CreateNewAscender(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                  LPFONTDATARECORD FontData, float oldAscender)
{
   LPFONTEXTRA FontExtra = (LPFONTEXTRA) BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO)((LPSTR)FontInfo+FontInfo->dfBitsOffset);
   FONTDATARECORD TempFontData;
   LPASCIIBINPTRS tempptr;

   char  FontName[128];
   float Ascender, temp;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

#ifdef ADOBE_DRIVER
   if (FontData->ascender)
   {
      TCleanToVMMark(lppd, 1);
   }
#endif
   if ((FontData->addAscExt == 1) &&
       (!SAME_ASCENDER(FontData->ascender, oldAscender)))
   {
      TempFontData = *FontData;
      TempFontData.addAscExt = 1; 
      TempFontData.GlyphData0 = NULL;  // this one should not inherite this info
      TempFontData.lpW1ByteGI=NULL;

      TempFontData.GlyphData = NULL;
      TempFontData.BoldFake   = FALSE;
      TempFontData.ItalicFake = FALSE;
      TempFontData.xScale = 0;
      TempFontData.yScale = 0;

      // This is a copy only. lpGiTable is not allocated for this instance
      TempFontData.isMylpGITable = 0;
     // store the new font instance in the font instance database

       //we need this for UFL.
       TempFontData.isMypSubFont = 0; //not mine.
       TempFontData.pSubFont = FontData->pSubFont;

      AddFontDataRecord(lppd, &TempFontData);

     //Create a font for the new ascender
     FontInstName(FontName,&TempFontData);
     PSSendFragment(lppd,PSFRAG_slash);
     PSSendString(lppd,FontName);     // Send "/Name" for new ascender (/F0A%d)
     PSSendString(lppd,SPACE);

     // create a name for the base form on which this font is based
     temp = TempFontData.ascender;
     TempFontData.ascender = oldAscender;
     TempFontData.addAscExt = 0;
     FontInstName(FontName,&TempFontData);
     TempFontData.addAscExt = 1;
     TempFontData.ascender = temp;
     PSSendString(lppd,FontName);     // Send "Name" (/F0)
     PSSendString(lppd,SPACE);

     // The overhang is defined as :
     //
     //      Overhang = Ascender * tan(12 degrees)
     //
     Ascender   = (float)FontData->ascender;

     /* wcc -- need to adjust the ascender as well */
     if ( (FontData->fontDLType != CC_CID) && 
          (!(FontData->DBCSFake & DBCS_DEVICE_FAKE)) )
     {
         (*tempptr->PSSendFloat)(lppd, (Ascender - oldAscender));
         PSSendString(lppd, "mAF ");           /* get difference */
     }
     else {
         PSSendString(lppd, " 0 mAF ");  /* Don't change FontMatric's ty */
     }

     (*tempptr->PSSendCRLF)(lppd);
   }

#ifdef ADOBE_DRIVER
   if (FontData->ascender)
   {
        TSetVMMark(lppd, 1, TRUE);
   }
#endif
}

/***************************************************************************
*                         TextBegin_UL_ST
*  Function:
*       sends modifications to the underlining and strikethrough parameters,
*       if necessary
*
*  Called:
*       VOID NEAR PASCAL TextBegin_UL_ST(LPPDEVICE lppd,LPPSFONTINFO FontInfo,
*                                        LPTEXTXFORM TextXForm)
*  Parameters:
*       LPPDEVICE lppd         pdevice pointer
*       LPPSFONTINFO FontInfo    input fontinfo struct
*       LPTEXTXFORM TextXForm  input textxform struct
*
*  Returns:
*       nothing
*
*  NOTE:   does not currently handle the tategaki case
**************************************************************************/

VOID FAR PASCAL TextBegin_UL_ST( LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                         LPTEXTXFORM TextXForm)
{
   LPETM etm ;
   LPASCIIBINPTRS tempptr;

   BOOL UnderLine;
   BOOL StrikeOut;
   int ulwidth;
   int ulpos;
   int stwidth;
   int stpos;
   int yScale;
   int EM;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   if (!(FontInfo->dfType & TYPE_TRUETYPE))
   {
     LPFONTEXTRA FontExtra = (LPFONTEXTRA) BUMPFAR (FontInfo, FontInfo->dfDriverInfo);

     etm = (LPETM)BUMPFAR (FontInfo, FontExtra->dwExtTextMetrics);
     EM = etm->etmMasterUnits;
     yScale = FontExtra->sPSyScale;
   }

   UnderLine = TextXForm->ftUnderline && !FontInfo->dfUnderline;
   if ( UnderLine )
   {
     (*tempptr->PSSendShort)(lppd,0);     // constant X offset of underlining

     if (FontInfo->dfType & TYPE_TRUETYPE)
     {
       PSSCALABLEFONTINFO FAR *lpScaFnt = (PSSCALABLEFONTINFO FAR *)FontInfo;
       ulpos = lpScaFnt->erUnderlinePos;     // already pre-scaled' GDI units!
       ulwidth = lpScaFnt->erUnderlineThick; // already pre-scaled' GDI units!
     }
     else
     {
       ulpos = Scale(etm->etmUnderlineOffset,yScale,EM);
       ulpos = ulpos + FontInfo->dfAscent;
       ulwidth = Scale(etm->etmUnderlineWidth ,yScale,EM);
     }
     (*tempptr->PSSendShort)(lppd,ulpos);        // underlining position
     lppd->lpFontDataList->currentulpos = ulpos;

     (*tempptr->PSSendShort)(lppd,ulwidth);      // underlining width
     lppd->lpFontDataList->currentulwidth = ulwidth;

     PSSendFragment(lppd,PSFRAG_sSU);  // set underlining operators parameter
     (*tempptr->PSSendCRLF)(lppd);
   }  // if (UnderLine)

   StrikeOut = TextXForm->ftStrikeOut && !FontInfo->dfStrikeOut;
   if ( StrikeOut )
   {
     (*tempptr->PSSendShort)(lppd,0);  // constant

     if (FontInfo->dfType & TYPE_TRUETYPE)
     {
       // Some TT fonts (especially converted from other formats)
       //  don't have the correct strike-thru position. We have to adopt this.
       //  By doing this we probably inflict more harm, but we have a bug
       //  against  strikeout and we must address this bug.
       //  Changed 13-Jun-1993  -by-  [olegs]
       stpos =   FontInfo->dfAscent  -
                Scale( FontInfo->dfAscent-FontInfo->dfInternalLeading, 40, 100);
       stwidth = ( FontInfo->dfPixHeight )/20; // Wild guess
     }
     else
     {
       stpos=Scale(etm->etmStrikeOutOffset,yScale,EM);
       stpos=FontInfo->dfAscent - stpos;
       stwidth=Scale(etm->etmStrikeOutWidth ,yScale,EM);
     }
     (*tempptr->PSSendShort)(lppd,stpos);
     lppd->lpFontDataList->currentstpos = stpos;

     (*tempptr->PSSendShort)(lppd,stwidth);
     lppd->lpFontDataList->currentstwidth = stwidth;

     PSSendFragment(lppd,PSFRAG_sST);
     (*tempptr->PSSendCRLF)(lppd);
   }  // if (StrikeOut)
}


/***************************************************************************
*                        TextBegin_CurrentPoint
*  Function:
*       Sends modifications to the underlining and strikethrough parameters,
*       if necessary
*
*  Called:
*       VOID NEAR PASCAL TextBegin_CurrentPoint(LPPDEVICE lppd,LPPOINT CurrentPoint,
*                                        LPTEXTXFORM TextXForm)
*  Parameters:
*       LPPDEVICE  lppd          pdevice pointer
*       LPPOINT    CurrentPoint
*       LPPSFONTINFO FontInfo      input fontinfo struct
*
*  Returns:
*       nothing
**************************************************************************/

VOID FAR PASCAL TextBegin_CurrentPoint(LPPDEVICE lppd, LPPOINT CurrentPoint,
              LPPSFONTINFO FontInfo)
{
   SHORT Escapement;
   float Angle;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

#if 0
   // This is the right way to do it. We'll make this change post Win95
   // See TTextEnd() also.
   Escapement = TextXForm->ftEscapement;
#else
   if (!(FontInfo->dfType & TYPE_TRUETYPE))
   {
     LPFONTEXTRA  FontExtra  = (LPFONTEXTRA) BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
     Escapement = FontExtra->sEscapement;
   }
   else
   {
     LOGFONT        LogFont;
     LPTTFONTINFO   lpTTFontInfo;
     lpTTFontInfo = (LPTTFONTINFO) ((LPSTR) FontInfo +
            FontInfo->dfBitsOffset) ;

     LogFont = lpTTFontInfo->lfCopy;
     Escapement = LogFont.lfEscapement;
   }
#endif

   Escapement = Escapement % 3600;
   Angle = (float)(-Escapement/10.0);

   if (Escapement == 0)
   {
      (*tempptr->PSSendShort)(lppd,CurrentPoint->x);       // ix
      (*tempptr->PSSendShort)(lppd,CurrentPoint->y);       // iy
      (*tempptr->PSSendBasic)(lppd,PSOP_moveto);           // moveto
   }
   else
   {
        if (lppd->DeviceRes.x_res == lppd->DeviceRes.y_res)
       {
         (*tempptr->PSSendFloat)(lppd,Angle);
         (*tempptr->PSSendShort)(lppd,CurrentPoint->x);       // ix
         (*tempptr->PSSendShort)(lppd,CurrentPoint->y);       // iy
         PSSendFragment(lppd,PSFRAG_sR);                      // sR
       }
       else
       {  // non-square resolution setting is in effect
         // output the CTM matrix to give desired rotation and adjust x, y
         // scaling factors in this CTM to account for non-square resolutions.

         float ScaleC = (float) (RCos(1000, Escapement)/1000.0);
         SHORT ScaleS = RSin(1000, Escapement);

         float xRotate = (float) (-Scale( lppd->DeviceRes.y_res,
                  ScaleS, lppd->DeviceRes.x_res)/1000.0);

         float yRotate = (float) (Scale(lppd->DeviceRes.x_res,
                  ScaleS, lppd->DeviceRes.y_res)/1000.0);

         (*tempptr->PSSendFloat)(lppd, ScaleC);
         (*tempptr->PSSendFloat)(lppd, xRotate);
         (*tempptr->PSSendFloat)(lppd, yRotate);
         (*tempptr->PSSendFloat)(lppd, ScaleC);
         (*tempptr->PSSendShort)(lppd,CurrentPoint->x);       // ix
         (*tempptr->PSSendShort)(lppd,CurrentPoint->y);       // iy
         PSSendFragment(lppd,PSFRAG_sRxy);                    // sR
       }  // non-square resolution
   }
   (*tempptr->PSSendCRLF)(lppd);

   // update lpgGState->TextCurrentPoint
   lppd->lpGSStack->lpgGState->TextCurrentPoint.x = CurrentPoint->x;
   lppd->lpGSStack->lpgGState->TextCurrentPoint.y = CurrentPoint->y;
   lppd->lpGSStack->lpgGState->Escapement         = Escapement;
}

/***************************************************************************
*
*                              TTextBegin
*
*    Function:
*
*    Called:  short FAR PASCAL TTextBegin(LPPDEVICE lppd, LPPOINT CurrentPoint, LPPSFONTINFO FontInfo,LPTEXTXFORM TextXForm)
*
*    Parameters:  LPPDEVICE   lppd
*                 LPPOINT     CurrentPoint
*                 LPPSFONTINFO  FontInfo
*                 LPTEXTXFORM TextXForm
*
*    Returns:
*
***************************************************************************/

short FAR PASCAL TTextBegin(  LPPDEVICE lppd, LPPOINT CurrentPoint,
                LPPSFONTINFO FontInfo,LPTEXTXFORM TextXForm)
{
   LPFONTEXTRA FontExtra = (LPFONTEXTRA) BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO)((LPSTR)FontInfo + FontInfo->dfBitsOffset);
   FONTDATARECORD FontData;
   FONTDATARECORD MatchFontData;
   LPASCIIBINPTRS tempptr;
   int   StepNo;
   char  FontName[128];
   short retval;
   TTRAST_OPT TTRasterizer = ((LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo))->devcaps.TTRasterizer;
   int iDLFontFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;
   LPSTR lpszPSFace = NULL;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   //init FontData
   memset((char *)&FontData, 0, sizeof(FONTDATARECORD));

   MatchFontData.GlyphData = FontData.GlyphData = NULL;

   // Load FontData with info for the requested font
   // Do BoldFake and/or ItalicFake, if requested font is bold and/or italic
   //  and font characteristics are not

   FontData.ReEncode = FALSE;  // Default, don't re-encode. 
   FontData.ReEncodable = TRUE; //True for all PS font.
   // The flag is still kept here for future extension of PS Fonts.
   FontData.CharSet = FontInfo->dfCharSet; // added 7-15-95
   FontData.lpGITable = MatchFontData.lpGITable = NULL;
   FontData.DBCSFake = 0;   

   if (FontInfo->dfType & TYPE_TRUETYPE)
   {
      //Most TT fonts are not reEncodable. Exception is TT_T42_CC_RES
      FontData.ReEncodable = FALSE;  
      // If TrueType font is resident then must be T42. -ANG-6/11/96
      iDLFontFormat = lpTTFontInfo->iDLFontFormat;

     switch(iDLFontFormat)
     {
       case TT_DLFORMAT_TYPE42 :
    if ((FontInfo->dfType & TYPE_TTRESIDENT) && 
        !(FontInfo->dfType & PF_GLYPH_INDEX)) //TT_RES_CC
        FontData.ReEncodable = TRUE;  
         FakeBoldItalicType42((LPLOGFONT) &(lpTTFontInfo->lfCopy),TextXForm,
                         (LPFONTDATARECORD)&FontData);
       break;


       case TT_DLFORMAT_NONE : // Do not fake anything !!!
         FontData.BoldFake = FontData.ItalicFake = FALSE;
       break;

    case TT_DLFORMAT_TYPE1:
       if (lpTTFontInfo->wTTFlags & ERF_SIM_BOLD)
              FontData.BoldFake = 1;
       else
              FontData.BoldFake = ((TextXForm->ftWeight>=700) &&
                   (FontInfo->dfWeight < 700));
            FontData.ItalicFake = (TextXForm->ftItalic && !FontInfo->dfItalic);
       break;

       default:                // Type 1 or Type 3
         FontData.BoldFake = ((TextXForm->ftWeight>=700) &&
                         (FontInfo->dfWeight < 700));
         FontData.ItalicFake = (TextXForm->ftItalic && !FontInfo->dfItalic);
       break;
     }
   }
   else        // non-Truetype
   {
     FontData.BoldFake = ((TextXForm->ftWeight>=700) && (FontInfo->dfWeight < 700));
     FontData.ItalicFake = (TextXForm->ftItalic && !FontInfo->dfItalic);

     FontData.DBCSFake
            = ((lppd->fDBCS & DBCS_DEVICE) ? DBCS_DEVICE_FAKE : 0)
               | ((lppd->fDBCS & DBCS_VERT) ? DBCS_VERT_FAKE : 0);

      // for 83pv as vertical (J-specific)
      if ((FontInfo->dfCharSet == SHIFTJIS_CHARSET) && (lppd->fDBCS & DBCS_83PV_VERT))
      {
     FontData.DBCSFake |= (DBCS_VERT_FAKE | DBCS_83PV_VERT_FAKE);
      }

   }

   // Load the font scale factors
   if (!(FontInfo->dfType & TYPE_TRUETYPE))
   {
     FontData.xScale = FontExtra->sPSxScale;
     FontData.yScale = FontExtra->sPSyScale;

     // Load the PostScript face name
     lpszPSFace = (LPSTR) BUMPFAR (FontInfo, FontExtra->dwPSFace);
     lstrcpy(FontData.FontName, lpszPSFace);
     FontData.ascender = (float)FontInfo->dfAscent/(float)FontExtra->sPSyScale;
   }
   else
   {
     FontData.xScale = lpTTFontInfo->sx;
     FontData.yScale = lpTTFontInfo->sy;
     lstrcpy(FontData.FontName, lpTTFontInfo->PSName);
     FontData.ascender= (float)FontInfo->dfAscent/(float)lpTTFontInfo->sy;
   }

   // If we are incrementally downloading header, get the procsets down
   //  now, before we create font instances or change the PostScript
   //  graphics state.  The save/restore associated with downloading
   //  procsets could change some PostScript language state.

   if (FontData.DBCSFake & DBCS_VERT_FAKE)
   {
     retval = TokenNeedsProcset(lppd,VTEXT);
   }
   else if (FontData.DBCSFake & DBCS_DEVICE_FAKE)
   {
     retval = TokenNeedsProcset(lppd,KTEXT);
   }
   else
   if (FontData.BoldFake || FontData.ItalicFake)
   {
     // Normal text procsets are a prerequisite of artificial bolding procset
     retval = TokenNeedsProcset(lppd,ATEXT);
   }
   else
   {
     retval = TokenNeedsProcset(lppd,TEXT);
   }

   if ( (lppd->fDBCS & DBCS_FONT) && FontData.ItalicFake ){
      // Need this because T0/42s and T0/CID share PS stream. ATEXT is not enough
     retval = TokenNeedsProcset(lppd,KTEXT);
     }

   // We can not send color here, "restore" in font section
   // will remove this color.  jjia  5/31/96
   // Set the text color
   // PSSendPenFGColor(lppd);

   // Check the requested font data structure against the current font

   //WCC bug 277500 .. also check for ascender value
   if ((lstrcmpi(lppd->lpGSStack->lpgGState->currentFontData.FontName,FontData.FontName) != 0) ||
      (lppd->lpGSStack->lpgGState->currentFontData.BoldFake != FontData.BoldFake) ||
      (lppd->lpGSStack->lpgGState->currentFontData.ItalicFake != FontData.ItalicFake) ||
      (lppd->lpGSStack->lpgGState->currentFontData.DBCSFake  != FontData.DBCSFake) ||
      (lppd->lpGSStack->lpgGState->currentFontData.xScale != FontData.xScale) ||
      (lppd->lpGSStack->lpgGState->currentFontData.yScale != FontData.yScale) ||
      ( (!IsDBCSCharSet(FontInfo->dfCharSet)) && (lppd->lpGSStack->lpgGState->currentFontData.ascender != FontData.ascender) )
     )
   {
     // Find the closest matching font instance in the font instance list
     StepNo = CheckFontDataRecord(lppd,FontData,(LPFONTDATARECORD)&MatchFontData);
     if ((StepNo == 2) && (!SAME_ASCENDER(FontData.ascender, MatchFontData.ascender)) ||
         ((StepNo > 0) && (MatchFontData.addAscExt == 1)))
          FontData.addAscExt = 1; 

     // Load the FontID from the matching font into the new fontID
     FontData.FontID = MatchFontData.FontID;

     // For TrueType fonts, get & propagate the partial font GlyphData

          //want to set for PS & TT though only apply to TT
          //we needed for delete font
          FontData.isMypSubFont = 0;
          FontData.pSubFont = NULL; //will be set later

     if (FontInfo->dfType & TYPE_TRUETYPE)
     {
       FontData.GlyphData0 = MatchFontData.GlyphData0 ;
       FontData.lpW1ByteGI = MatchFontData.lpW1ByteGI;
       FontData.GlyphData = MatchFontData.GlyphData ;
       // lpGITable is allocated in DownLoadFont() for MatchFontData. It should
       // be copied to FontData - used later in UpdateFont() time. What a mess !!
       FontData.lpGITable = MatchFontData.lpGITable;
       FontData.fontDLType = MatchFontData.fontDLType;  // Fakeitalic need this

            FontData.pSubFont = MatchFontData.pSubFont;
     }
#ifdef ADOBE_DRIVER
     FontData.PSFontRecPtr = NULL;
#endif

     // Create a new font instance based on the closeness of the match

     switch (StepNo)
     {
       case 0:
            // Handle FontName, Ascender & Charset - AND do ReEncoding !
            TextBegin_CreateBasicFont(lppd, FontInfo, (LPFONTDATARECORD)&FontData);

       case 1:
              // Handle re-encoding based on new CharSet
           TextBegin_CreateNewCharSet(lppd, FontInfo, (LPFONTDATARECORD)&FontData);

       case 2:
              // Handle Ascender change
           TextBegin_CreateNewAscender(lppd, FontInfo,
                    (LPFONTDATARECORD)&FontData, (float)MatchFontData.ascender);

              // Handle BoldFake & ItalicFake
           TextBegin_CreateBoldItalic(lppd, FontInfo, (LPFONTDATARECORD)&FontData);

       case 3:
              // Handle ScaleFactors
           TextBegin_CreateScaled(lppd, FontInfo, (LPFONTDATARECORD)&FontData);

       default:
           break;
     }

     // Update current font on host side
     lppd->lpGSStack->lpgGState->currentFontData = FontData;

     // Set current font in printer
     FontInstName(FontName,(LPFONTDATARECORD)&FontData);
     PSSendString(lppd,FontName);                          // Send "FontName"
     PSSendString(lppd, SPACE);

      // Fixed bug 29589 - Type 42 bug
      //  Type 42 handling was implemented incorrectly in
      //  printers with PS version <= 2013. We supply the
      //  PS fix for that, and this fix is activated when
      //  text is sent and TTRasterizer == TTRAST_TYPE42BUGGY
      // Fixed 29-Aug-1994  -by-  [olegsher]
     if (  (FontInfo->dfType & TYPE_TRUETYPE) &&
      (iDLFontFormat == TT_DLFORMAT_TYPE42) &&
      ( TTRasterizer == TTRAST_TYPE42BUGGY )
   )
     {
       (*tempptr->PSSendFloat)(lppd, (float)FontInfo->dfAscent);
       PSSendFragment(lppd, PSFRAG_sF42);
     }
     else
     {
       (*tempptr->PSSendBasic)(lppd,PSOP_setfont);
     }
     (*tempptr->PSSendCRLF)(lppd);

   } // if (lstrcmpi(...)...)

   // Set the text color.  jjia  5/31/96
   PSSendPenFGColor(lppd);

   // Handle UnderLine & StrikeOut
   TextBegin_UL_ST(lppd, FontInfo, TextXForm);

   // Set the CurrentPoint
   TextBegin_CurrentPoint(lppd, CurrentPoint, FontInfo);

   return(retval);
}

/***************************************************************************
*
*                              TTextRun
*    Function:
*
*    Called:  short FAR PASCAL TTextRun(LPPDEVICE lppd, LPSTR String, int count,
*                                       double breakExtra, double charExtra,
*                                       LPPSFONTINFO FontInfo, LPTEXTXFORM TextXForm)
*
*    Parameter:  LPPDEVICE lppd
*                LPSTR     String
*                int       count
*                double    breakExtra
*                double    charExtra
*
*    Returns:
*
***************************************************************************/

short FAR PASCAL TTextRun( LPPDEVICE lppd, LPSTR String,int count, double breakExtra,
            double charExtra, LPPSFONTINFO FontInfo,
            LPTEXTXFORM TextXForm, LPINT lpdx)
{
   LPASCIIBINPTRS tempptr;
   int   i, code, BoldFake;
   short retval;
   WORD  dfBreakChar ;
   TTRAST_OPT TTRasterizer = ((LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo))->devcaps.TTRasterizer;
   int iDLFontFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;
   int idx, length = 0;
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO)((LPSTR)FontInfo + FontInfo->dfBitsOffset);
   LPSTR lpString = String;
   int  StringLen = count;
//   WORD        *lpDLGlyphWord;
   static int strLen =0;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, TEXT);

   if (FontInfo->dfType & TYPE_TRUETYPE)
   {
       // If TrueType font is resident then must be T42. -ANG-6/11/96
      iDLFontFormat = lpTTFontInfo->iDLFontFormat;

       switch (iDLFontFormat)
     {
       case TT_DLFORMAT_TYPE42 :
            {
                FONTDATARECORD   FontData;
                FontData.GlyphData = NULL;

                FakeBoldItalicType42((LPLOGFONT) &(lpTTFontInfo->lfCopy),TextXForm,
                           (LPFONTDATARECORD)&FontData);
                BoldFake = FontData.BoldFake;
            }
       break;

       case TT_DLFORMAT_NONE : // Do not fake anything !!!
         BoldFake =  FALSE;
       break;

    case TT_DLFORMAT_TYPE1 :
      if (lpTTFontInfo->wTTFlags & ERF_SIM_BOLD)
             BoldFake = 1;
      else
          BoldFake = ((TextXForm->ftWeight>=700) && (FontInfo->dfWeight < 700));
      break;

       default:                // Type 1 or Type 3
         BoldFake = ((TextXForm->ftWeight>=700) && (FontInfo->dfWeight < 700));
       break;
     }
   }
   else
   {
     BoldFake = ((TextXForm->ftWeight>=700) && (FontInfo->dfWeight < 700));
   }

   // The PostScript operator used is determined by any differences
   //  in the character spacing or the break spacing between the
   //  PostScript widths and the widths specified by the application:
   //
   //  breakExtra  charExtra      Operator
   //   ---------|--------|--------------
   //     == 0.0 | == 0.0 |  show
   //     == 0.0 | != 0.0 |  ashow
   //     != 0.0 | == 0.0 |  widthshow
   //     != 0.0 | != 0.0 |  awidthshow

   code = ((lpdx != NULL) << 2) +
     ((breakExtra != (float)0.0) << 1) +
     (charExtra != (float)0.0);

   // Fixed bug 29589 - Type 42 bug
   //  Type 42 handling was implemented incorrectly in
   //  printers with PS version <= 2013. We supply the
   //  PS fix for that, and this fix is activated when
   //  text is sent and TTRasterizer == TTRAST_TYPE42BUGGY
   // Fixed 29-Aug-1994  -by-  [olegsher]
   if (  (FontInfo->dfType & TYPE_TRUETYPE) &&
    (iDLFontFormat == TT_DLFORMAT_TYPE42) &&
    ( TTRasterizer == TTRAST_TYPE42BUGGY ) )
   {
     PSSendFragment(lppd,PSFRAG_bS42);
   }

   //  fix for bug 26348: cannot assume break char is 32 !

   if(FontInfo->dfType & PF_GLYPH_INDEX)
   // GDI returns GlyphIndex for dfDefalutChar.
   // There is a possibility that GDI returns value which is bigger
   // than 256.
   {
      if (*(LPWORD)&FontInfo->dfDefaultChar > 256)
     dfBreakChar      = 0xff & *(LPWORD)&FontInfo->dfDefaultChar  ;
      else
     dfBreakChar      = *(LPWORD)&FontInfo->dfDefaultChar  ;
   }
   else
      dfBreakChar     = ((WORD)(FontInfo->dfBreakChar + FontInfo->dfFirstChar)) & 0x00ff;


   switch (code)
   {
     case 0:
                 PSSendTextChar(lppd, lpString, StringLen);

       if (BoldFake)
       {
          PSSendFragment(lppd,PSFRAG_sB);    // Unified Fake-embolding mechansim, 2-28-96, PPeng
       }
       else
       {
         (*tempptr->PSSendBasic)(lppd,PSOP_show);
       }
     break;

     case 1:
       (*tempptr->PSSendFloat)(lppd,(float)charExtra);
       (*tempptr->PSSendFloat)(lppd,0);
                 PSSendTextChar(lppd,lpString, StringLen);

       if (BoldFake)
       {
          PSSendFragment(lppd,PSFRAG_asB);    // Unified Fake-embolding mechansim
       }
       else
       {
         (*tempptr->PSSendBasic)(lppd,PSOP_ashow);
       }
     break;

     case 2:
       (*tempptr->PSSendFloat)(lppd,(float)breakExtra); // PostScript adds ax+cx
       (*tempptr->PSSendFloat)(lppd,0);          // PostScript adds ay+cy
       (*tempptr->PSSendShort)(lppd,dfBreakChar);
                 PSSendTextChar(lppd, lpString, StringLen);

       if (BoldFake)
       {
          PSSendFragment(lppd,PSFRAG_wsB);    // Unified Fake-embolding mechansim
       }
       else
       {
         (*tempptr->PSSendBasic)(lppd,PSOP_widthshow);
       }
     break;

     case 3:
       //    Changed from breakExtra-charExtra to breakExtra
       //    30-Mar-1993 -by-  [olegs]
       (*tempptr->PSSendFloat)(lppd,(float)breakExtra); // PostScript adds ax+cx
       (*tempptr->PSSendFloat)(lppd,0);       // PostScript adds ay+cy
       (*tempptr->PSSendShort)(lppd,dfBreakChar);
       (*tempptr->PSSendFloat)(lppd, (float)charExtra);
       (*tempptr->PSSendFloat)(lppd,0);
                 PSSendTextChar(lppd,lpString, StringLen);

       if (BoldFake)
       {
          PSSendFragment(lppd,PSFRAG_awsB);    // Unified Fake-embolding mechansim
       }
       else
       {
         (*tempptr->PSSendBasic)(lppd,PSOP_awidthshow);
       }
     break;

    /*
     * Add xshow.  jjia  5/9/96
     */
     case 4:
                 length = PSSendTextChar(lppd, lpString, StringLen);
       if (length > 128 )
       {
           (*tempptr->PSSendCRLF)(lppd);
           length = 0;
       }

       length += PSSendFragment(lppd, PSFRAG_leftbracket);
                 for (i = 0; i < StringLen; i++)
       {
          idx = 0;
          if ( !(FontInfo->dfType & PF_GLYPH_INDEX) &&
         (IsDBCSLeadByteEx(FontInfo->dfCharSet,
                        (BYTE)(((int)lpString[i]) & 0x00FF))) )
          {
         idx += lpdx[i];
         i++;
          }
          idx += lpdx[i];
          length += (*tempptr->PSSendFloat)(lppd,(float)(idx));
          if (length > 128)
          {
         (*tempptr->PSSendCRLF)(lppd);
         length = 0;
          }
       }
       PSSendFragment(lppd, PSFRAG_rightbracket);
       if (BoldFake)
       {
          PSSendFragment(lppd,PSFRAG_xsB);    // Unified Fake-embolding mechansim
       }
       else
       {
          //(*tempptr->PSSendBasic)(lppd,PSOP_xshow);
          PSSendString(lppd, "XSE "); // fix bug #199475
       }
//               PSSendString(lppd, "xshow ");
     break;

   } // switch(code)

   (*tempptr->PSSendCRLF)(lppd);

   // Fixed bug 29589 - Type 42 bug
   //  Type 42 handling was implemented incorrectly in
   //  printers with PS version <= 2013. We supply the
   //  PS fix for that, and this fix is activated when
   //  text is sent and TTRasterizer == TTRAST_TYPE42BUGGY
   // Fixed 29-Aug-1994  -by-  [olegsher]
   if (  (FontInfo->dfType & TYPE_TRUETYPE) &&
    (iDLFontFormat == TT_DLFORMAT_TYPE42) &&
    ( TTRasterizer == TTRAST_TYPE42BUGGY ) )
   {
   PSSendFragment(lppd,PSFRAG_eS42);
   }


   return(retval);
}

/***************************************************************************
*
*                               TTextEnd
*
*    Function:
*
*    Called:  short FAR PASCAL TTextEnd( LPPDEVICE lppd, LPPSFONTINFO FontInfo,
*                                        LPTEXTXFORM TextXForm, int extent)
*
*    Parameters:  LPPDEVICE     lppd
*                 LPPSFONTINFO    FontInfo
*                 LPTEXTXFORM   TextXForm
*                 int           extent
*
*    Returns:
*
***************************************************************************/

short FAR PASCAL TTextEnd( LPPDEVICE lppd, LPPSFONTINFO FontInfo,
              LPTEXTXFORM TextXForm, int extent)
{
   LPASCIIBINPTRS tempptr;
   int UnderLine;
   int StrikeOut;
   SHORT Escapement;
   short retval;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, TEXT);

   UnderLine = TextXForm->ftUnderline && !FontInfo->dfUnderline;
   StrikeOut = TextXForm->ftStrikeOut && !FontInfo->dfStrikeOut;

   if (UnderLine)
   {
     (*tempptr->PSSendShort)(lppd,-extent);
     PSSendFragment(lppd,PSFRAG_sU);
     (*tempptr->PSSendCRLF)(lppd);
   }

   if (StrikeOut)
   {
     (*tempptr->PSSendShort)(lppd,-extent);
     PSSendFragment(lppd,PSFRAG_sT);
     (*tempptr->PSSendCRLF)(lppd);
   }

   // Clean up the state
#if 0
   // This is the right way to do it. We'll make this change post Win95
   // See TextBegin_CurrentPoint() also.
   Escapement = TextXForm->ftEscapement;
#else       
   if (!(FontInfo->dfType & TYPE_TRUETYPE))
   {
     LPFONTEXTRA  FontExtra  = (LPFONTEXTRA) BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
     Escapement = FontExtra->sEscapement;
   }
   else
   {
     LOGFONT        LogFont;
     LPTTFONTINFO   lpTTFontInfo;
     lpTTFontInfo = (LPTTFONTINFO) ((LPSTR) FontInfo +
            FontInfo->dfBitsOffset) ;

     LogFont = lpTTFontInfo->lfCopy;
     Escapement = LogFont.lfEscapement;
   }
#endif   
   if ((Escapement % 3600) !=0)
   {
     PSSendFragment(lppd, PSFRAG_eR);
     (*tempptr->PSSendCRLF)(lppd);
   }

   // NOTE: rotated text and vertical writing not supported
   //       update the current point
   if ((Escapement % 3600) == 0)
   {
     lppd->lpGSStack->lpgGState->TextCurrentPoint.x += extent;
   }

   return(retval);
}


/***************************************************************************
*                           TSoftFontLoad
*  Function:
*       Downloads a font to the printer
*
*  Called:
*       short FAR PASCAL TSoftFontLoad(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
*                          LPTEXTXFORM TextXForm,LPSTR String,short sCount )
*
*  Parameters:
*       LPPDEVICE   lppd          pdevice pointer
*       LPPSFONTINFO  FontInfo      input fontinfo struct
*       LPTEXTXFORM TextXForm
*       LPSTR       String
*       short       sCount
*
*  Returns:
*
**************************************************************************/

PSERROR FAR PASCAL TSoftFontLoad(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
             LPTEXTXFORM TextXForm, LPSTR String, short sCount )
{
   LPFONTEXTRA FontExtra = (LPFONTEXTRA) BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO) ((LPSTR)FontInfo + FontInfo->dfBitsOffset);
   FONTDATARECORD FontData, MatchFontData;
   LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   PSERROR rc = PS_SUCCESS;
   BOOL bDownloaded = FALSE;
   BOOL bDownLoadFace = FALSE;
   LPSTR lpszPSFace = NULL;
   LPSTR lpszMSFace = NULL;

   // DownLoad full font only when this specific combination
   //   is present - NULL string and 0 size.
   // Fixed bugs Adobe-50, Microsoft-16078.
   //   15-Mar-94 -by- [olegs]
   BOOL bFullFont = (String == NULL) && (sCount == 0);  // for ESCDownloadFace
   // Download full font if font is Streamer cannot stream it. e.g. PFA, MM Instance
//#ifdef STREAMER
   BOOL bStrmFull=FALSE;
//#else
//   BOOL bStrmFull=TRUE;
//#endif
   BOOL bGlobalFull = FALSE;  // condition set by global UI or WIN.INI.
   BOOL isTT = FontInfo->dfType & TYPE_TRUETYPE;
   BOOL isTTDL = FontInfo->dfType & TYPE_TTRESIDENT;
   OFSTRUCT ofstruct;

   SHORT softFontLoad = DOWNLOADFONT;
   BOOL vmOff = FALSE;
#ifdef MM_INCR
   char  temp2[128];  // a temp string
#endif

#ifdef ADOBE_DRIVER
   LPSTR pstr;
   char  temp[128];  // a temp string
#endif
   char  szSoftFont[MAX_PATH];

   // !!!!!!!!!!!!!!!!!!!!!!!!!
   // Three possible reasons to downlaod a font in full:
   // Global request, StreamerUnable, or Escape(DownloadFace).
   // That is why we have three flags. They can only merge during DownloadFont() call.
   // !!!!!!!!!!!!!!!!!!!!!!!!!

   bDownLoadFace = bFullFont;
   //init FontData
   memset((char *)&FontData, 0, sizeof(FONTDATARECORD));

   if (isTT)
     lstrcpy(FontData.FontName, lpTTFontInfo->PSName);
   else
   { 
     lpszPSFace = (LPSTR) BUMPFAR (FontInfo, FontExtra->dwPSFace);
     lstrcpy(FontData.FontName, lpszPSFace);
   }
   // lppd->lpPSExtDevmode->dm2.bFullDown only controls TrueType. Yak!! PPeng, 9-28-95
   if (isTT && lppd->lpPSExtDevmode->dm2.bFullDown)
   {
      bGlobalFull = TRUE;
   }

   // Return FAIL for Escape (DOWNLOADFACE) if the font is CJK font. bug120335.
   // bFullFont is true only if the call is from Escape (DOWNLOADFACE)
    if ( (IsDBCSCharSet(FontInfo->dfCharSet)) &&
    bFullFont ){
   rc = -1;
   goto EndTSoftFontLoad;
    }

   FontData.CharSet = FontInfo->dfCharSet;  // added 7-12-95, PPeng
   FontData.ReEncodable = TRUE; //True for all PS font.
   FontData.bDownLoadFace = bDownLoadFace;
   MatchFontData = FontData;

   while (softFontLoad != DOWNLOADDONE)
   {
   if (softFontLoad == TRYDOWNLOADAGAIN)
   {
      VMRecoverDisable(lppd);
      vmOff = TRUE;
   }

      // Move the bFullFont check here because UpdateFont() needs this flag.
      // Fix bug 86. 4-19-1995.
#ifdef ADOBE_DRIVER
                /****************************************/
                /* first test if this is any form of    */
                /* a postscript font - either directly  */
                /* specified or as a postscript font    */
                /* that is being substituted for a true */
                /* type font.                   bug 185 */
                /*                                      */
                /* Multimaster instance fonts have      */
                /* neither OUTLINE or TRUETYPE flags set*/
                /****************************************/


   if (FontExtra && ( !(FontInfo->dfType & TYPE_TRUETYPE)  ||
            FontInfo->dfType & TYPE_SUBSTITUTED))
   {

    // For PostScript .PFA files we must set bFullFont to TRUE
    //   since the streamer will not accept it
    // For OBLIQUE fonts we also should set bFullFont to TRUE
    //   Added  6-Oct-1995  -by-  [olesher]
    pstr = (LPSTR) szSoftFont;
    lpszPSFace = (LPSTR)BUMPFAR (FontInfo, FontExtra->dwPSFace);
    (void) GetPFB((LPSTR)lpszPSFace,(LPSTR) pstr);


    // If the font is Multiple Master Instance, must send in full. fix bug 97, 3-9-95
    lpszMSFace = (LPSTR)BUMPFAR (FontInfo, FontExtra->dwMSFace);
    if (IsMMInstanceFont(lppd, lpszMSFace, (LPSTR)temp, 1) ) // byfamilyname=1
     {
        LOGFONT lf;             // Send the base font first: Fix bug 169.
        lf.lfEscapement = 0;
        lf.lfOrientation = 0;
        lf.lfUnderline = 0;
        lf.lfStrikeOut = 0;
      lf.lfCharSet = DEFAULT_CHARSET;
      lf.lfOutPrecision = OUT_DEVICE_PRECIS;
      lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
      lf.lfQuality = DEFAULT_QUALITY;
      lf.lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;
      lstrcpy((LPSTR)lf.lfFaceName, (LPSTR)temp);
        lf.lfItalic = FontInfo->dfItalic;  // Use the style returned by RealizeFont(). !!!!
        lf.lfWeight = FontInfo->dfWeight;
        TRealizeAndSendFont(lppd, (LPLOGFONT)&lf, String, sCount, FALSE);
        // Now send the mm instance font. Send in full and disable VMrecovery--want to keep just sent base font
        bStrmFull=TRUE;
        VMRecoverDisable(lppd);
        vmOff = TRUE;
     }
     else if ((lstrlen(pstr) >= 3) && (0 == lstrcmpi(pstr + lstrlen(pstr) - 3,"PFA")))
     {
       bStrmFull = TRUE;
     }

   }
#endif

//#ifdef STREAMER          
    if (!isTT && !UseType1Incr(lppd))
     bStrmFull = TRUE;     // way to disable the streamer. debugging
//#endif

   if (isTT){
      bStrmFull = FALSE;   // Turn this flag OFF for TrueType Font
      }

   bDownloaded = CheckFontDataRecord(lppd,FontData,(LPFONTDATARECORD)&MatchFontData);


   // Always download full font even it was downloaded
   // before if we came here thru DOWNLOADFONT escape.
   // Aldus' PageMaker uses it's own --save-- and --restore--, so
   //  if we keep track of downloaded fonts this can be incorrect because
   //  one of the --restore-- commands sent down in passthru mode can
   //  blow away all our fonts and  we have no way of knowing that.
   // Fixed bugs Adobe-50, Microsoft-16078.
   //   21-Mar-94  -by-  [olegs]
   if ( bFullFont || !bDownloaded )
   {
     // Font is not already present in printer.  We need to send it.
      if (isTT ||
         OpenFile((LPSTR)szSoftFont, &ofstruct, OF_EXIST) !=
         HFILE_ERROR)
      {

//#ifdef STREAMER
        // For Hybrid fonts we also should set bFullFont to TRUE
        
#ifdef MM_INCR
        memset((char *) &temp2, 0, 128);
        if (!isTT && !bStrmFull && !StreamerAble(pstr, &(LPSTR)FontData.PSFontRecPtr, (LPSTR) temp2))
            bStrmFull = TRUE;

        if (bStrmFull && temp2[0])  //tektonMM-Oblique.  need to undef tekton
        {  
            PSSendString(lppd, "/");
            PSSendString(lppd, (LPSTR) temp2);
            PSSendString(lppd, " undefinefont ");
            (*tempptr->PSSendCRLF)(lppd);
        }
#else
        if (!isTT && !bStrmFull && !StreamerAble(pstr, &(LPSTR)FontData.PSFontRecPtr, (LPSTR) NULL))
            bStrmFull = TRUE;

#endif

//#endif

        // We are permitted to send fonts and...
        // Font file (.PFB etc.) is openable.  Send the font.
        if (bStrmFull || bGlobalFull)
          bFullFont=TRUE;     // Set bFullFont flag with bStrmFull or GlobalFull depends on isTT

        rc = DownLoadFont(lppd, FontInfo, &FontData, bFullFont, FALSE);
        if (rc == PS_LOWVM_VMRECOVER)
        {
            softFontLoad = TRYDOWNLOADAGAIN;
            continue;
        }
        if (PS_ERROR(rc))
            goto EndTSoftFontLoad;

#ifdef MM_INCR
        if (bStrmFull && temp2[0])
        {  
            LPFONTDATARECORD currentptr = lppd->lpFontDataList->FontDataList;
            FONTDATARECORD TempFontData;
            int dex = 0;
            BOOL bFound = FALSE;

            while ( (dex < lppd->lpFontDataList->FontDataNextRecord) )
            {
                if (lstrcmpi(currentptr->FontName, (LPSTR) temp2) == 0)
                {
                    if (currentptr->xScale==0 && currentptr->yScale==0)
                    {
                        if (currentptr->PSFontRecPtr != NULL)
                        {
                            StreamerReleaseFontRec(&currentptr->PSFontRecPtr);
                            currentptr->PSFontRecPtr = NULL;
                        }
                        bFound = TRUE;
                    }
                    *(currentptr->FontName) = *(currentptr->FontName) +1;
                }
                currentptr ++ ;
                dex++;
            }

          //init TempFontData
          memset((char *)&TempFontData, 0, sizeof(FONTDATARECORD));

            // Set correct CharSet and Re-Encode flags: Must be the same as this Oblique one. 3-18-97, PPeng
            TempFontData.CharSet = FontData.CharSet;
            TempFontData.ReEncodable = FontData.ReEncodable;

          // add the new font data record to the list
            TempFontData.FontID = -1;       // have a new font id supplied
            lstrcpy(TempFontData.FontName, temp2);

            TextBegin_CreateBasicFont(lppd, FontInfo, &TempFontData);

        }
#endif

       MatchFontData = FontData;

       }
      else
       {
            // Font file cannot be opened.  Hope some preprocessor inserts the font
            // %%IncludeResource: font Times-Roman
            // For old doc managers this should be %%IncludeFont (See pswriter.rc)
            // %%IncludeResource: font Times-Roman
            // Actually %%IncludeFont (See pswriter.rc)
//         (*tempptr->PSSendDSC)(lppd,DSC_includeresfont,FontData.FontName);
            // new DSC 3.1
            lstrcpy(temp, szFont);
            lstrcat(temp, FontData.FontName);
            (*tempptr->PSSendDSC)(lppd,DSC_includeresource,temp);

            // Add font name to list for DSC %%DocumentNeededFont
            AddFontDSCEntry(lppd,FontData.FontName,FALSE);  //FALSE == Font Needed

      }

   }

        // If app call ESC DOWNLOADFACE then call ExtTextOut for the same font
        // ignore the fact that the font is downloaded, re-download it
        // again to guard the case that the possible passthrough with 
        // save/restore around DOWNLOADFACE call may blow away the font
        // and we don't know about it.  bug # 231753
    // Now download glyphs as appropriate
   if (bFullFont || bStrmFull || bGlobalFull || (bDownloaded && !MatchFontData.GlyphData))
    {
       softFontLoad = DOWNLOADDONE;
    }
   else
        {
           //remember the pSubFont for TTfonts.
           //use by UFL
          softFontLoad = UpdateFont(lppd, FontInfo, String, sCount,
               (LPFONTDATARECORD)&MatchFontData, FALSE);
        }
   if (vmOff)
   {
      VMRecoverEnable(lppd);
      vmOff = FALSE;
   }
   } // while (softFontLoad != DOWNLOADDONE)
EndTSoftFontLoad:
   return(rc);
}

/***************************************************************************
*
*                          TSoftFontLoadMin
*
*    Function:  Soft Font Download function for EPS Printing Escape(Min Header)
*
*    Called:  short FAR PASCAL TSoftFontLoadMin(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
*                          LPTEXTXFORM TextXForm ,LPSTR String,short sCount )
*
*    Parameters: LPPDEVICE    lppd        pdevice pointer
*                LPPSFONTINFO   FontInfo    input fontinfo struct
*                LPTEXTXFORM  TextXForm
*                LPSTR String
*                short sCount
*
*    Returns:
***************************************************************************/


PSERROR FAR PASCAL TSoftFontLoadMin(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
             LPTEXTXFORM TextXForm, LPSTR String, short sCount )
{
   LPFONTEXTRA FontExtra = (LPFONTEXTRA)BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO) ((LPSTR)FontInfo + FontInfo->dfBitsOffset);
   FONTDATARECORD FontData, MatchFontData;
   LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   PSERROR rc = PS_SUCCESS;

   // DownLoad full font only when this specific combination
   //   is present - NULL string and 0 size.
   // Fixed bugs Adobe-50, Microsoft-16078.
   //   15-Mar-94 -by- [olegs]
   BOOL bFullFont = (String == NULL) && (sCount == 0);  // for EscapeDownloadFace
   BOOL isTT = FontInfo->dfType & TYPE_TRUETYPE;
   OFSTRUCT ofstruct;
//#ifdef STREAMER
   BOOL bStrmFull=FALSE;
//#else
//   BOOL bStrmFull=TRUE;
//#endif
   BOOL bGlobalFull = FALSE;  // condition set by global UI or WIN.INI.
   BOOL vmOff = FALSE;
   LPSTR pstr;
   char  temp[128];  // a temp string
   char  szSoftFont[MAX_PATH];
   LPSTR lpszPSFace = NULL;
   LPSTR lpszMSFace = NULL;

#ifdef MM_INCR
   char  temp2[128];  // a temp string
#endif

   // !!!!!!!!!!!!!!!!!!!!!!!!!
   // Three possible reasons to downlaod a font in full:
   // Global request, StreamerUnable, or Escape(DownloadFace).
   // That is why we have three flags. They can only merge during DownloadFont() call.
   // !!!!!!!!!!!!!!!!!!!!!!!!!

   //init FontData
   memset((char *)&FontData, 0, sizeof(FONTDATARECORD));

   if (isTT)
     lstrcpy(FontData.FontName, lpTTFontInfo->PSName);
   else
   {
      lpszPSFace = (LPSTR) BUMPFAR (FontInfo, FontExtra->dwPSFace);
      lstrcpy(FontData.FontName, lpszPSFace);
   }
   // lppd->lpPSExtDevmode->dm2.bFullDown only controls TrueType. Yak!! PPeng, 9-28-95
   if (isTT && lppd->lpPSExtDevmode->dm2.bFullDown){
       bGlobalFull = TRUE;
      }

   // Return FAIL for Escape (DOWNLOADFACE) if the font is CJK font. bug120335.
   // bFullFont is true only if the call is from Escape (DOWNLOADFACE)
    if ( (IsDBCSCharSet(FontInfo->dfCharSet)) &&
    bFullFont ){
   rc = -1;
   goto EndTSoftFontLoadMin;
    }

   FontData.CharSet = FontInfo->dfCharSet;  // added 7-12-95, PPeng
   MatchFontData = FontData;

    // Copy MMInst check from SoftFontLoad(). fix bug 86 for Min-headers.
    // 5-15-1995.
                /****************************************/
                /* first test if this is any form of    */
                /* a postscript font - either directly  */
                /* specified or as a postscript font    */
                /* that is being substituted for a true */
                /* type font.                   bug 185 */
                /*                                      */
                /* Multimaster instance fonts have      */
                /* neither OUTLINE or TRUETYPE flags set*/
                /****************************************/

   if (FontExtra && (    !(FontInfo->dfType & TYPE_TRUETYPE)
            ||   FontInfo->dfType & TYPE_SUBSTITUTED))
   {

    // For PostScript .PFA files we must set bFullFont to TRUE
    //   since the streamer will not accept it
    pstr = szSoftFont;
    lpszPSFace = (LPSTR)BUMPFAR (FontInfo, FontExtra->dwPSFace);
    (void) GetPFB((LPSTR) lpszPSFace,(LPSTR) pstr);

    // If the font is Multiple Master Instance, must send in full. fix bug 97, 3-9-95
    lpszMSFace = (LPSTR)BUMPFAR (FontInfo, FontExtra->dwMSFace);
    if (IsMMInstanceFont(lppd, lpszMSFace, (LPSTR)temp, 1) ) // byfamilyname=1
     {
   LOGFONT lf;             // Send the base font first: Fix bug 169.

        lf.lfEscapement = 0;
   lf.lfOrientation = 0;
     lf.lfUnderline = 0;
        lf.lfStrikeOut = 0;
        lf.lfCharSet = DEFAULT_CHARSET;
        lf.lfOutPrecision = OUT_DEVICE_PRECIS;
        lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
        lf.lfQuality = DEFAULT_QUALITY;
        lf.lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;
   lstrcpy((LPSTR)lf.lfFaceName, (LPSTR)temp);
   lf.lfItalic = FontInfo->dfItalic;  // Use the style returned by RealizeFont(). !!!!
   lf.lfWeight = FontInfo->dfWeight;
   TRealizeAndSendFont(lppd, (LPLOGFONT)&lf, String, sCount, TRUE);
   // Now send the mm instance font. Send in full and disable VMrecovery--want to keep just sent base font
        bStrmFull=TRUE;
   // Is this necessary for Min-header? Doesn't hurt!
   VMRecoverDisable(lppd);
        vmOff = TRUE;
     }
     else if ((lstrlen(pstr) >= 3) && (0 == lstrcmpi(pstr + lstrlen(pstr) - 3,"PFA"))) {
       bStrmFull = TRUE;
     }
  }

//#ifdef STREAMER
    if (!isTT && !UseType1Incr(lppd))
     bStrmFull = TRUE;     // way to disable the streamer. debugging
//#endif

   if (isTT){
      bStrmFull = FALSE;   // Turn this flag OFF for TrueType Font
      }

   // Always download full font even it was downloaded
   // before if we came here thru DOWNLOADFONT escape.
   // Aldus' PageMaker uses it's own --save-- and --restore--, so
   //  if we keep track of downloaded fonts this can be incorrect because
   //  one of the --restore-- commands sent down in passthru mode can
   //  blow away all our fonts and  we have no way of knowing that.
   // Fixed bugs Adobe-50, Microsoft-16078.
   //   21-Mar-94  -by-  [olegs]
   // Add this bFullFont here by PPeng, 9-28-95, for Escape() calls for Oleg's reason above.
   if (bFullFont || !CheckFontDataRecord(lppd,FontData,(LPFONTDATARECORD)&MatchFontData))
   {
     // Font is not already present in printer.  We need to send it.
   if (isTT ||
         OpenFile((LPSTR)szSoftFont, &ofstruct, OF_EXIST) !=
         HFILE_ERROR)
   {

//#ifdef STREAMER
    // For Hybrid fonts we also should set bFullFont to TRUE
#ifdef MM_INCR
    memset((char *) &temp2, 0, 128);
    if (!isTT && !bStrmFull && !StreamerAble(pstr, &(LPSTR)FontData.PSFontRecPtr, (LPSTR)temp2[0]))
      bStrmFull = TRUE;

    if (bStrmFull && temp2[0])  //tektonMM-Oblique.  need to undef tekton
    {  
      PSSendString(lppd, "/");
      PSSendString(lppd, (LPSTR) temp2);
      PSSendString(lppd, " undefinefont ");
      (*tempptr->PSSendCRLF)(lppd);
    }
#else

    if (!isTT && !bStrmFull && !StreamerAble(pstr, &(LPSTR)FontData.PSFontRecPtr, (LPSTR) NULL))
      bStrmFull = TRUE;

#endif

//#endif

       // We are permitted to send fonts and...
       // Font file (.PFB etc.) is openable.  Send the font.
    if (bStrmFull || bGlobalFull)
      bFullFont=TRUE;     // Set bFullFont flag with bStrmFull or GlobalFull depends on isTT

    rc = DownLoadFont(lppd, FontInfo, &FontData, bFullFont, TRUE);
    if (PS_ERROR(rc))
       goto EndTSoftFontLoadMin;

#ifdef MM_INCR
    if (bStrmFull && temp2[0])
    {  
      LPFONTDATARECORD currentptr = lppd->lpFontDataList->FontDataList;
      FONTDATARECORD TempFontData;
      int dex = 0;
      BOOL bFound = FALSE;

      while ( (dex < lppd->lpFontDataList->FontDataNextRecord) )
      {
        if (lstrcmpi(currentptr->FontName, (LPSTR) temp2) == 0)
        {
           if (currentptr->xScale==0 && currentptr->yScale==0)
           {
               if (currentptr->PSFontRecPtr != NULL)
               {
                  StreamerReleaseFontRec(&currentptr->PSFontRecPtr);
                  currentptr->PSFontRecPtr = NULL;
               }
               bFound = TRUE;
           }
           *(currentptr->FontName) = *(currentptr->FontName) +1;
        }
        currentptr ++ ;
        dex++;
      }
      //init TempFontData
      memset((char *)&TempFontData, 0, sizeof(FONTDATARECORD));

        // Set correct CharSet and Re-Encode flags: Must be the same as this Oblique one. 3-18-97, PPeng
        TempFontData.CharSet = FontData.CharSet;
        TempFontData.ReEncodable = FontData.ReEncodable;

        // add the new font data record to the list
        TempFontData.FontID = -1;       // have a new font id supplied
        lstrcpy(TempFontData.FontName, temp2);

       if (lppd->job.bfESCOpenChannel)
            {
                TextBegin_CreateBasicFont(lppd, FontInfo, &TempFontData);
            }
   }
#endif
    
    // lpGITable is allocated in DownLoadFont() for FontData. It should
    // be copied to MatchFontData - used later in UpdateFont() time.
    MatchFontData = FontData;

   }
   else
   {
    // Font file cannot be opened.  Hope some preprocessor inserts the font
    // %%IncludeResource: font Times-Roman
    // For old doc managers this should be %%IncludeFont (See pswriter.rc)
    // %%IncludeResource: font Times-Roman
    // Actually %%IncludeFont (See pswriter.rc)
    // (*tempptr->PSSendDSC)(lppd, DSC_includeresfont, FontData.FontName);
    // new DSC 3.1
       temp[0] = 0;
       lstrcpy(temp, szFont);
       lstrcat(temp, FontData.FontName);
       (*tempptr->PSSendDSC)(lppd,DSC_includeresource,temp);

    // Add font name to list for DSC %%DocumentNeededFont
       AddFontDSCEntry(lppd,FontData.FontName,FALSE);  //FALSE == Font Needed

    }
   }

   if ( !(bFullFont || bStrmFull || bGlobalFull) )
   {
      UpdateFont(lppd, FontInfo, String, sCount,
    (LPFONTDATARECORD)&MatchFontData, TRUE);
   }
#ifdef ADD_EURO
   // Only send Euro for MinHeader apps.
   // Since we do MF for Openchannel apps where the Euro has been sent.
   if ( !(lppd->job.bfESCOpenChannel))  
       AddEuroToType1Font(lppd, FontInfo, &FontData);
#endif

   if (vmOff)
   {  // is this necessary for Min-header? Doesn't hurt!
      VMRecoverEnable(lppd);
      vmOff = FALSE;
   }

EndTSoftFontLoadMin:
   return(rc);
}

#ifdef ADD_EURO
PSERROR FAR PASCAL TDeviceFontLoad(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                            LPTEXTXFORM TextXForm )
{
   LPFONTEXTRA FontExtra = (LPFONTEXTRA)BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
   FONTDATARECORD FontData;
   LPSTR lpszPSFace = NULL;
   PSERROR rc = PS_SUCCESS;

   // Add Euro to device font.

   //init FontData
   memset((char *)&FontData, 0, sizeof(FONTDATARECORD));

   lpszPSFace = (LPSTR) BUMPFAR (FontInfo, FontExtra->dwPSFace);
   lstrcpy(FontData.FontName, lpszPSFace);
   FontData.CharSet = FontInfo->dfCharSet;  // added 7-12-95, PPeng

   AddEuroToType1Font(lppd, FontInfo, &FontData);  // ADD_EURO

   return(rc);
}
#endif

/***************************************************************************
 *
 *                          DownloadFont
 *
 *    Function:  Main routine to download a font.  FontInfo points to
 *               the physical font created by RealizeFont().  bFullFont
 *               takes on the following meaning:
 *
 *               TRUE   download font header and all characters
 *               FALSE  download font header only
 *
 *               This function takes on some of the inline code from the
 *               erstwhile TSoftFontLoad thereby reducing its complexity).
 *               It may be called either by TSoftFontLoad or TSoftFontLoadMin
 *               (as specified by the minHeader flag.) It calls the appropriate
 *               TTDownLoadFont or PSDownLoadFont as required.
 *
 *    Called:    int FAR PASCAL TTDownLoadFont(LPPDEVICE lppd,
 *                                             LPPSFONTINFO FontInfo,
 *                                            LPFONTDATARECORD lpFontDataRecord,
 *                                              BOOL bFullFont, BOOL minHeader)
 *
 *    Parameters:  LPPDEVICE lppd
 *                 LPPSFONTINFO FontInfo
 *                 LPFONTDATARECORD lpFontDataRecord
 *                 BOOL bFullFont
 *                 BOOL minHeader
 *
 *    Returns:     PSERROR
 *
 ***************************************************************************/

PSERROR FAR PASCAL DownLoadFont(
    LPPDEVICE           lppd, 
    LPPSFONTINFO        FontInfo,
    LPFONTDATARECORD    lpFontDataRecord,
    BOOL                bFullFont, 
    BOOL                minHeader
    )
{
    LPASCIIBINPTRS  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    LPTTFONTINFO    lpTTFontInfo = (LPTTFONTINFO) ((LPSTR)FontInfo + FontInfo->dfBitsOffset);
    PSERROR         rc = PS_SUCCESS;
    BOOL            isTT = FontInfo->dfType & TYPE_TRUETYPE;
    int             iDLFontFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;
    BOOL            isTTDL = FALSE;
    char            temp[128];
    BOOL            bUMinBegin = FALSE;  // true after "userdict begin Drv_Dict_Min begin" is sent
    BOOL            bReEncode = TRUE;

    if (!minHeader)
        TokenNeedsProcset(lppd, TEXT);
    if (isTT)
    {
        //Most TT fonts are not reEncodable. Exception is TT_T42_CC_RES
        lpFontDataRecord->ReEncodable = FALSE;

        if (IsDBCSCharSet(FontInfo->dfCharSet))
        {
            char far *lpFaceName = (char far*) lpTTFontInfo->lfCopy.lfFaceName;
            if( *lpFaceName == '@' )
            {
                lppd->fDBCS |= DBCS_VERT;  // we need this flag for WMode in Type42 font.
            }
            lppd->fDBCS |= DBCS_FONT; // need this flag for Escape(DownloadFace).
            TokenNeedsProcset(lppd, TYPE0HDR); // Type 0 Header
        }
        // If TrueType font is resident then must be T42. -ANG-6/11/96
        iDLFontFormat = lpTTFontInfo->iDLFontFormat;

        switch (iDLFontFormat)
        {
        case TT_DLFORMAT_NONE:
            // Fix bug 149729 - should not undefine a RAM font!!! set the flag here correct
            lpFontDataRecord->fontDLType = 0;
            return rc;

        case TT_DLFORMAT_TYPE42:
            // Fix bug 149729 - should not undefine a RAM font!!! set the flag here correct
            if (FontInfo->dfType & PF_GLYPH_INDEX)
                lpFontDataRecord->fontDLType = GI_42;
            else
                lpFontDataRecord->fontDLType = CC_42;

            isTTDL = FontInfo->dfType & TYPE_TTRESIDENT;  //TTDL = TRUE if (T42 & TTresident)

            if (isTTDL && !(FontInfo->dfType & PF_GLYPH_INDEX)) //TT_RES_CC
            { //char code mode Type 42
                int procID = -1;

                lpFontDataRecord->ReEncodable = TRUE;
                if (minHeader)
                    TokenNeedsProcset(lppd, MIN_TEXT);

                switch(FontInfo->dfCharSet) 
                {
                case 0:
                    bReEncode = FALSE;
                    if (minHeader)
                        procID = ENCODING_0;
                    else
                        procID = TEXT;
                    break;

                case 161: procID = ENCODING_161; break;
                case 162: procID = ENCODING_162; break;
                case 177: procID = ENCODING_177; break;
                case 178: procID = ENCODING_178; break;
                case 186: procID = ENCODING_186; break;
                case 204: procID = ENCODING_204; break;
                case 238: procID = ENCODING_238; break;
                }
                if (procID >= 0)
                    TokenNeedsProcset(lppd, procID);

            }
            else  //TT_RES_GI or TT & !resident
            {
                //UFL has it:  TokenNeedsProcset(lppd, TYPE42); //use the T42 font directly
            }

                // CJK CMap is downloaded in TTFonts.c now
            break;

            
        case TT_DLFORMAT_TRUEIMAGE:
            //native TT fonts can be accessed by their original names
            break;

        case TT_DLFORMAT_TYPE1:
        case TT_DLFORMAT_TYPE3:
            if (FontInfo->dfType & TYPE_OUTLINE)
            { // real Type1
#ifdef T3OUTLINE
                if (bTTtoT3OL)            //bugbug!!!  Need UI change
                {
                    TokenNeedsProcset(lppd, TYPE3OLHDR);
                }
                else 
                {
                    TokenNeedsProcset(lppd, TYPE1HDR);
                }
#else
            TokenNeedsProcset(lppd, TYPE1HDR);
#endif

            if (!(FontInfo->dfType & PF_GLYPH_INDEX))
            {
                if (lppd->fDBCS & DBCS_FONT)
                {
                    lpFontDataRecord->fontDLType = CC_T01;
                }
                else
                    lpFontDataRecord->fontDLType = CC_1;
                }
                else // Glyph-index based T1
                    lpFontDataRecord->fontDLType = GI_1;

            }
            else
            {// real Type3
                //UFL has it: TokenNeedsProcset(lppd, TYPE3HDR);
                if (!(FontInfo->dfType & PF_GLYPH_INDEX))
                {
                    if (lppd->fDBCS & DBCS_FONT)
                    {
                        lpFontDataRecord->fontDLType = CC_T03;
                    }
                    else
                        lpFontDataRecord->fontDLType = CC_3;
                }
                else // Glyph-index based T3
                    lpFontDataRecord->fontDLType = GI_3;
            }
            
            break;

        default:  // addd other format here - Type32 ?
            break;
        }
        
        lpFontDataRecord->lpGAS = NULL; // initial to NULL;
        // For GI-T1 and GI-T3, we need to find its GIAssignment if exists.
        // add to the list GI-42  ang 10/31/97

        if ((lpFontDataRecord->fontDLType == GI_1 || lpFontDataRecord->fontDLType == GI_3
             || lpFontDataRecord->fontDLType == GI_42 ) &&
            (!lppd->lpPSExtDevmode->dm2.bFullDown) &&
            (lppd->lpPSExtDevmode->dm2.bTrueTypeFast))
        {
            char FontName[FONTNAMESIZE];  // for TT font, we use "MSTT31abcd00" -maximal length=14
            LPSTR lpFontName = (LPSTR)FontName;
            LPGIASSIGNED  lpMatchGas;
            // Get the  GIAssignment:
            lstrcpy(FontName, lpTTFontInfo->PSName); // make a local copy we can modify
            REMOVE_SHOW_ORDER_SUBSTRING(lpFontName);   // remove the fontid 00.
            if (CheckGIAssignedRecord(lppd, FontName, &lpMatchGas)!=0)
            { // Found
                lpFontDataRecord->lpGAS = lpMatchGas; // save the found Pointer
            }
        }

    }  /* if (isTT) */

    if (!minHeader)
    {
        if (!TCleanToVMMark(lppd, 1)) 
        {
            // add this to put %%BeginFont at the beginning of a line. fix a DSC bug.
            (*tempptr->PSSendCRLF)(lppd);
        }

    }

    // before downloading/updating a TT font, push userdict and our_dict on dictstack
    // to prevent conflicts with apps, and end end after done -part of fix 174233, 9-18-96
    // Need THIS ONLY for MIN-Headers
    // Added THIS for Open Channel also for bug 297833.
    if (isTT)
    {
       if (minHeader && !lppd->job.bfESCOpenChannel)
       {
           PSSendFragment(lppd, PSFRAG_epsprocsetstart); // userdict begin Our_Dict_Min begin
           (*tempptr->PSSendCRLF)(lppd);
           bUMinBegin = TRUE;
       }
       else if (lppd->job.bfESCOpenChannel)
       {
           PSSendFragment(lppd, PSFRAG_OCprocsetstart); // userdict begin Our_Dict_OC begin
           (*tempptr->PSSendCRLF)(lppd);
           bUMinBegin = TRUE;
       }
    }
    
    // There are three cases the %%Begin(End)Resource is required
    // 1. true type full downloaded font with charCode
    // 2. PS full downloaded font not GPLPH_INDEX code
    // 3. PS incremental font. The streamer can't handle it, download full font
    //    anyway. Ex: MultiMaster hybrid font.

    //if this TT font has been downloaded then no need to send BeginFont
    if (!isTTDL)
    {
        if (bFullFont && !(FontInfo->dfType & PF_GLYPH_INDEX) &&
          (lppd->lpPSExtDevmode->dm2.iPS_DLFontFmt != PS_DLFORMAT_DONT_SEND))
        {
            // new DSC 3.1
            lstrcpy(temp, szFont);
            lstrcat(temp, lpFontDataRecord->FontName);
            (*tempptr->PSSendDSC)(lppd,DSC_beginresource,temp);

            // Add Font name to list for DSC %%DocumentSuppliedResource
            // Use PSName instead of TRUETYPE name to be consistent with
            // %%BeginResource: font truetype name
            AddFontDSCEntry(lppd, isTT ? lpTTFontInfo->PSName:
                      lpFontDataRecord->FontName,TRUE);    // TRUE == Font supplied
        }
    }
    // Initial the isMyGITable flag to 0. 7-24-95. Fix bug 118248
    // it'll be set to 1 in TTDownLoad(). So for PSDownLoad, the flag is 0.
    lpFontDataRecord->isMylpGITable = 0;
    lpFontDataRecord->lpGITable = NULL;

    if (isTT)
    {
        rc = TTDownLoadFont(lppd,FontInfo,bFullFont,lpFontDataRecord, minHeader);
        if (PS_ERROR(rc))
            goto EndDownLoadFont;
    }
    else 
    {
        // Fix bug 154622 - if iPS_DLFontFmt is PS_DLFORMAT_DONT_SEND, do not download
        //                  PS font
        if (lppd->lpPSExtDevmode->dm2.iPS_DLFontFmt != PS_DLFORMAT_DONT_SEND)
        {
            // Fix bug 149729 - should not undefine a RAM font!!! set the flag here correct
            lpFontDataRecord->fontDLType = CC_1;  // All PS fonts are Char-Code-Type1

            rc = PSDownLoadFont(lppd,FontInfo,lpFontDataRecord,bFullFont,minHeader);
            if (!bFullFont)
            {
                // fixc bug 189975: to prevent potential FontCache problem
                // fix up the /.notdef for Incrementally downloaded PS fonts
                (*tempptr->PSSendCRLF)(lppd);
                PSSendString(lppd, "/");
                PSSendString(lppd, lpFontDataRecord->FontName);
                PSSendFragment(lppd, PSFRAG_fixnotdef); // "findfont /CharStrings get /.notdef {pop 0 0 setcharwidth } put"
                (*tempptr->PSSendCRLF)(lppd);
            }

            if ( rc )
                lpFontDataRecord->ReEncodable = ( rc == 2 );
        }
        else 
        {
            lstrcpy(temp, szFont);
            lstrcat(temp, lpFontDataRecord->FontName);
            (*tempptr->PSSendDSC)(lppd,DSC_includeresource,temp);

           UpdateFontDSCEntry(lppd,lpFontDataRecord->FontName,FALSE);  //FALSE = font needed
        }
    }

    //if this TT font has been downloaded, then no need to send EndFont


    // There are three cases the %%Begin(End)Resource is required
    // 1. true type full downloaded font with charCode
    // 2. PS full downloaded font not GPLPH_INDEX code
    // 3. PS incremental font. The streamer can't handle it, download full font
    //    anyway. Ex: MultiMaster hybrid font.

    //if this TT font has been downloaded then no need to send BeginFont
    if (!isTTDL)
    {
        if (bFullFont && !(FontInfo->dfType & PF_GLYPH_INDEX) &&
           (lppd->lpPSExtDevmode->dm2.iPS_DLFontFmt != PS_DLFORMAT_DONT_SEND))
        {
            // %% EndResource
            (*tempptr->PSSendDSC)(lppd, DSC_endresource, (LPSTR)NULL);
        }
    }
    else if ( minHeader && !(lppd->job.bfESCOpenChannel) && isTT &&
        (iDLFontFormat == TT_DLFORMAT_TYPE42) &&
        !(FontInfo->dfType & PF_GLYPH_INDEX) )
    {  
        //we re-encode here for min Header - IF Type42 && Downloaded-TT && Char-Code
        //GDI re-encode in CreateBasicFont - do it after %%IncludeResource:font ... ANG, 9-18-96
        CreateReEncodedFont(lppd, FontInfo, bReEncode);
    }

    // add the downloaded font to the list
    lpFontDataRecord->FontID = -1;  // have font id supplied

    if (!minHeader || (lppd->job.bfESCOpenChannel))
     // DO create this Fo instance for OPENChannel-MetaFile GPF bug. 3-1-1996, PPeng
    {
#ifndef ADOBE_DRIVER
        /* This is for Pscript 4.0 */
        TextBegin_CreateBasicFont(lppd, FontInfo, lpFontDataRecord);
        lppd -> lpFontDataList->GlyphData = NULL;

#endif
        TSetVMMark(lppd, 1, TRUE);
#ifdef ADOBE_DRIVER
       /* This is for AdobePS 4.1 */
        TextBegin_CreateBasicFont(lppd, FontInfo, lpFontDataRecord);
        lppd -> lpFontDataList->GlyphData = NULL;

#endif
    }
    else if (!(lppd->job.bfESCOpenChannel))
    {
        // register the font only if NOT-OpenChannel, fix bug 143345, 2-23-1996
        TSetVMMark(lppd, 1, TRUE);
        //need the font in FontDataList to support Incremental TT Donwloading for Min-headers!!
        Text_CreateFontRecord(lppd, FontInfo, lpFontDataRecord);
    }

EndDownLoadFont:
    if (bUMinBegin)
    {
        PSSendFragment(lppd, PSFRAG_end);             // end our dict
        PSSendFragment(lppd, PSFRAG_end);             // end userdict
        (*tempptr->PSSendCRLF)(lppd);
        bUMinBegin = FALSE;
    }
    return(rc);
}


/***************************************************************************
 *
 *                             UpdateFont
 *    Function:
 *
 *    Called:  int FAR PASCAL UpdateFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPSTR lpStr, int cb, LPFONTDATARECORD lpFontDataRecord, BOOL minHeader)
 *
 *    Parameters:  LPPDEVICE        lppd
 *                 LPPSFONTINFO       FontInfo
 *                 LPSTR            lpStr
 *                 int              cb
 *                 LPFONTDATARECORD lpFontDataRecord
 *
 *    Returns:   DOWNLOADDONE or TRYDOWNLOADAGAIN
 *
 ***************************************************************************/

int FAR PASCAL UpdateFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
           LPSTR String, int sCount,
              LPFONTDATARECORD lpFontDataRecord,
              BOOL minHeader)
{
   int retval = DOWNLOADDONE;
   BOOL isTTDL = FontInfo->dfType & TYPE_TTRESIDENT;
   int iDLFontFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO) ((LPSTR)FontInfo + FontInfo->dfBitsOffset);

   if (FontInfo->dfType & TYPE_TRUETYPE)
   {
      // If TrueType font is resident then must be T42. -ANG-6/11/96
      iDLFontFormat = lpTTFontInfo->iDLFontFormat ;

      switch(iDLFontFormat)
      {
     case TT_DLFORMAT_TYPE42:
       if (isTTDL)
        {
          retval = DOWNLOADDONE;
          break;
        }

         case TT_DLFORMAT_TYPE1:
         case TT_DLFORMAT_TYPE3:
                if (TTUpdateFont(lppd,FontInfo,String,sCount,lpFontDataRecord, minHeader)
         == UPDATE_LOWVM)
      {
         retval = TRYDOWNLOADAGAIN;
      }
      break;
         default:
      break;
      }
   }
//#ifdef STREAMER
   else
   {
      if (lpFontDataRecord->PSFontRecPtr == 0)     // We downloaded this entire font before (because streamer couldn't support it)
        retval = DOWNLOADDONE;
       // Fix bug 154622 - if iPS_DLFontFmt is PS_DLFORMAT_DONT_SEND, do not download
       //                  PS font
      else
      if (lppd->lpPSExtDevmode->dm2.iPS_DLFontFmt != PS_DLFORMAT_DONT_SEND)
      {
     
       if (PSUpdateFont(lppd,FontInfo,String,sCount,lpFontDataRecord)
         == UPDATE_LOWVM)
         retval = TRYDOWNLOADAGAIN;
      }
      else {
          UpdateFontDSCEntry(lppd,lpFontDataRecord->FontName,FALSE);  //FALSE = font needed
       retval = DOWNLOADDONE;
      }
   }
//#endif
   if (!minHeader)
      return retval;
   else
      return DOWNLOADDONE;
}
/***************************************************************************
 *
 *                          PSDownloadFont
 *
 *    Function:  Main routine to download a PostScript font.  FontInfo points to
 *               the physical font created by RealizeFont().  bFullFont
 *               takes on the following meaning:
 *
 *               TRUE   download font header and all characters
 *               FALSE  download font header only
 *
 *               Additionally, the bFullFont flag is only meaningful when
 *               the ADOBE_DRIVER preprocessor directive is in effect. If it
 *               is not, we always download the full font.
 *
 *               the minHeader flag tells if the function is invoked in the
 *               context of the min Header. In this case, we do not bother
 *               with the VM tracking stuff.
 *    Called:    int FAR PASCAL PSDownLoadFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
 *                           LPFONTDATARECORD lpFontDataRecord,
 *                           BOOL bFullFont, BOOL minHeader)
 *
 *    Parameters:  LPPDEVICE lppd
 *                 LPPSFONTINFO FontInfo
 *                 LPFONTDATARECORD lpFontDataRecord
 *                 BOOL bFullFont
 *                 BOOL minHeader
 *
 *    Returns:     1 if successful, 0 otherwise
 *
 ***************************************************************************/

int FAR PASCAL PSDownLoadFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
               LPFONTDATARECORD lpFontData,
               BOOL bFullFont, BOOL minHeader)
{
LPFONTEXTRA FontExtra = (LPFONTEXTRA) BUMPFAR (FontInfo,  FontInfo->dfDriverInfo);
LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
int fh, BytesRead;
LONG fileSize;
BOOL NoError, needVMCheck = TRUE;
WORD fontType;
char buf[256];
int bufSize = sizeof(buf);
char ps_id2[5];
union _fonthdr
   {
      HDR hdr;        // for .PFBs
      PFA_HDR pfahdr; // for .PFAs
   } fonthdr;

char szSoftFont[MAX_PATH];
LPSTR lpszPSFace = NULL;
PSERROR rc = PS_SUCCESS;         // return value of function

//#ifdef STREAMER
SHORT flavor;
BOOL binary;
int code;
//#endif

    lpszPSFace = (LPSTR) BUMPFAR (FontInfo, FontExtra->dwPSFace);
    (void) GetPFB((LPSTR)lpszPSFace,(LPSTR) szSoftFont);

//#ifdef STREAMER
   if (!bFullFont)
   {
      VMCheck(lppd, VM_PST1_HEADER, 0);
      DetermineOutputCharacteristics(lppd, &flavor, &binary);

       // Allocate the memory lpFontData->GlyphData to keep track of which char is downloaded here.
           rc = AllocateGlyfData(lppd, lpFontData);       // check return value
           if (PS_ERROR(rc))
               return 0;

      if (code = StreamerDownLoadT1Font(lppd,
            szSoftFont,
            (LPSTR)lpFontData->PSFontRecPtr,
            &(LPSTR)lpFontData->GlyphData, binary, lpFontData->CharSet))
      lppd->lpFontDataList->GlyphData = lpFontData->GlyphData;
      VMUsed(lppd, VM_PST1_HEADER, 0);
      return(code);
   }
//#endif
        // Read a PFB or PFA and download it
   if ((fh = _lopen((LPSTR)szSoftFont, READ)) < 0)
      return 0;
   if (((fileSize = _llseek(fh, 0L, 2)) == HFILE_ERROR) ||
       (_llseek(fh, 0L, 0) == HFILE_ERROR))
   {
      _lclose(fh);
      return 0;
   }
   do
   {
      BytesRead = _lread(fh, (LPSTR)&fonthdr.hdr, sizeof(HDR));
      NoError = (BytesRead == sizeof(HDR));

      if (NoError)
      {
         switch (fonthdr.hdr.type)
         {
       // type=1 --> the data is ASCII
       case 1:
          if ((!minHeader) && (needVMCheck))
          {
             VMCheck(lppd, VM_PFB_FONT, fileSize);
             needVMCheck = FALSE;
             fontType = VM_PFB_FONT;
          }
          NoError = PSSendFontType1(lppd, fh, fonthdr.hdr.length,
                     buf, bufSize);
          break;

       // type=2 --> the data is binary
       case 2:
          if ((!minHeader) && (needVMCheck))
          {
             VMCheck(lppd, VM_PFB_FONT, fileSize);
             needVMCheck = FALSE;
             fontType = VM_PFB_FONT;
          }
          NoError = (*tempptr->PSSendFontType2)(lppd, fh, fonthdr.hdr.length,
                       buf, bufSize);
          break;

       case 3:
          break;

       // Not A PFB - is it a PFA ?
       default:
          fonthdr.pfahdr.ps_id[6] = NULL;
          if (lstrcmp((LPCSTR)&(fonthdr.pfahdr.ps_id), "%!PS-A") == 0)
          {
             if ((!minHeader) && (needVMCheck))
             {
           VMCheck(lppd, VM_PFA_FONT, fileSize);
           needVMCheck = FALSE;
           fontType = VM_PFA_FONT;
             }
             BytesRead = _lread(fh, (LPSTR)&ps_id2, sizeof(ps_id2));
             NoError = (BytesRead == sizeof(ps_id2));
             ps_id2[4] = NULL;
             if (lstrcmp((LPCSTR)&ps_id2, "dobe") == 0)
             PSSendFontPFA(lppd, fh, bufSize, buf);
          }
          break;
         }  // End switch
      } // End if(NoError)
   } while((fonthdr.hdr.type<3) && NoError);      // End do

   _lclose(fh);
   
   if (!minHeader)
      VMUsed(lppd, fontType, fileSize);
   return (NoError ? 1:0);
}

//#ifdef STREAMER
/***************************************************************************
 *
 *                             PSUpdateFont
 *    Function:
 *
 *    Called:  int FAR PASCAL PSUpdateFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPSTR lpStr, int cb, LPFONTDATARECORD lpFontDataRecord)
 *
 *    Parameters:  LPPDEVICE        lppd
 *                 LPPSFONTINFO       FontInfo
 *                 LPSTR            lpStr
 *                 int              cb
 *                 LPFONTDATARECORD lpFontDataRecord
 *
 *    Returns:   UPDATE_FAILURE, UPDATE_LOWVM or UPDATE_SUCCESS
 *
 ***************************************************************************/

int FAR PASCAL PSUpdateFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPSTR lpStr,
            int cb, LPFONTDATARECORD lpFontData)
{
SHORT flavor;
BOOL binary;
int retval;
static int codes[] = {UPDATE_FAILURE, UPDATE_LOWVM, UPDATE_SUCCESS};
        TCleanToVMMark(lppd, 1);
   DetermineOutputCharacteristics(lppd, &flavor, &binary);
   retval = StreamerUpdateT1Font(lppd,
                (LPSTR)lpFontData->PSFontRecPtr,
                (LPSTR)lpFontData->GlyphData,
                 lpStr, cb, binary, lpFontData->CharSet);

        TSetVMMark(lppd, 1, TRUE);
   return (codes[retval]);
}
//#endif
/***************************************************************************
*
*                          PSSendFontPFA
*
*    Function:   Download a PFA font
*
*    Called:     BOOL NEAR PASCAL PSSendFontPFA(LPPDEVICE lppd, int fh,
*                                              long length, LPSTR buf)
*
*    Parameters:  LPPDEVICE   lppd      Pointer to PDEVICE structure
*                 int         fh        File HAndle of font to be downloaded
*                 long        length    Expected size of the font
*                 LPSTR       buf       Buffer into which to read the font
*
*    Returns:  TRUE if things go OK
*              FALSE if the size of the font doesn't match expectations
*
***************************************************************************/

BOOL NEAR PASCAL PSSendFontPFA(LPPDEVICE lppd, int fh, int length, LPSTR buf)
{
  LPASCIIBINPTRS tempptr;
  UINT bytecount;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

  PSSendData(lppd,"%!PS-Adobe",10 ); // I know, these strings are BAD practice!

  do
  {
      bytecount =  _lread(fh, buf, length);
      PSSendData(lppd, (LP)buf, bytecount);
      if (bytecount == HFILE_ERROR)
        return(FALSE);
  }
   while (bytecount > 0);

  (*tempptr->PSSendCRLF)(lppd);

  return(TRUE);

}

/***************************************************************************
*
*                          PSSendFontType1
*
*    Function:   Download a Type 1 font
*
*    Called:     BOOL NEAR PASCAL PSSendFontType1(LPPDEVICE lppd, int fh,
*                                              long length, LPSTR buf, int Size)
*
*    Parameters:  LPPDEVICE   lppd      Pointer to PDEVICE structure
*                 int         fh        File HAndle of font to be downloaded
*                 long        length    Expected size of the font
*                 LPSTR       buf       Buffer into which to read the font
*                 int         Size      Size of the buffer
*
*    Returns:  TRUE if things go OK
*              FALSE if the size of the font doesn't match expectations
*
***************************************************************************/

BOOL NEAR PASCAL PSSendFontType1(LPPDEVICE lppd, int fh,long length,LPSTR buf,int Size)
{
   long   i, nBuffers       ;
   int    nRemaining        ;
   ldiv_t result            ;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   result     = ldiv((long)length,(long)Size);
   nBuffers   = result.quot;
   nRemaining = (int)result.rem;

   for ( i=0; i < nBuffers; i++ )
   {
     if (_lread(fh, buf, Size) != (WORD)Size)
     goto ERR;
     PSSendData(lppd,(LP)buf,(WORD)Size);
   }

   if (nRemaining > 0)
   {
     if (_lread(fh, buf, nRemaining) != (WORD)nRemaining)
     goto ERR;
     PSSendData(lppd, (LP)buf, (WORD)nRemaining);
     (*tempptr->PSSendCRLF)(lppd);
   }

   return(TRUE);

ERR:
   return(FALSE);
}

/***************************************************************************
 *
 *                          PSSendFontType2ASCII
 *
 *    Function:   Download a Type 2 font in ASCII format
 *
 *    Called:     BOOL NEAR PASCAL PSSendFontType2ASCII(LPPDEVICE lppd,
 *                                     int fh, long length,LPSTR buf,int Size)
 *
 *    Parameters:  LPPDEVICE   lppd      Pointer to PDEVICE structure
 *                 int         fh        File HAndle of font to be downloaded
 *                 long        length    Expected size of the font
 *                 LPSTR       buf       Buffer into which to read the font
 *                 int         Size      Size of the buffer
 *
 *    Returns:  TRUE if things go OK
 *              FALSE if the size of the font doesn't match expectations
 *
 ***************************************************************************/

BOOL NEAR PASCAL PSSendFontType2Ascii(LPPDEVICE lppd, int fh,long length,
                        LPSTR buf,int Size)
{
   long   i, nBuffers       ;
   int    nRemaining        ;
   ldiv_t result            ;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   result     = ldiv((long)length,(long)Size);
   nBuffers   = result.quot;
   nRemaining = (int)result.rem;

   for (i=0; i < nBuffers; i++)
   {
     if (_lread(fh, buf, Size) != (WORD) Size)
       goto ERR;
     PSSendBitMapDataLevel1Ascii7(lppd, (BYTE huge *)buf, (DWORD) Size);
   }

   if (nRemaining > 0)
   {
     if(_lread(fh, buf, nRemaining) != (WORD)nRemaining)
       goto ERR;
     PSSendBitMapDataLevel1Ascii7(lppd, (BYTE huge *)buf, (DWORD)nRemaining);
     (*tempptr->PSSendCRLF)(lppd);
   }
   (*tempptr->PSSendCRLF)(lppd);
   return(TRUE);

ERR:
    return(FALSE);
}

/***************************************************************************
 *
 *                        PSSendFontType2Binary
 *
 *    Function:   Download a Type 2 font in Binary format
 *
 *    Called:     BOOL NEAR PASCAL PSSendFontType2Binary(LPPDEVICE lppd, int fh,
 *                                           long length,LPSTR buf,int Size)
 *
 *    Parameters:  LPPDEVICE   lppd      Pointer to PDEVICE structure
 *                 int         fh        File HAndle of font to be downloaded
 *                 long        length    Expected size of the font
 *                 LPSTR       buf       Buffer into which to read the font
 *                 int         Size      Size of the buffer
 *
 *    Returns:  TRUE if things go OK
 *              FALSE if the size of the font doesn't match expectations
 *
 ***************************************************************************/

BOOL NEAR PASCAL PSSendFontType2Binary(LPPDEVICE lppd,int fh,long length,
                       LPSTR buf,int Size)
{
   long   i, nBuffers      ;
   int    nRemaining       ;
   ldiv_t result           ;
   LPASCIIBINPTRS tempptr  ;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   result     = ldiv((long)length,(long)Size);
   nBuffers   = result.quot;
   nRemaining = (int)result.rem;

   for (i=0; i < nBuffers; i++)
   {
     if (_lread(fh, buf, Size) != (WORD) Size)
       goto ERR;
     PSSendBitMapDataLevel1Binary( lppd, (BYTE huge *) buf, (DWORD)Size) ;
   }

   if (nRemaining > 0)
   {
     if (_lread(fh, buf, nRemaining) != (WORD)nRemaining)
       goto ERR;
     PSSendBitMapDataLevel1Binary( lppd, (BYTE huge *) buf, (DWORD)nRemaining) ;
     (*tempptr->PSSendCRLF)(lppd);
   }
   (*tempptr->PSSendCRLF)(lppd);
   return(TRUE);

ERR:
   return(FALSE);
}

/*****************************************************************************
*
*                         CheckFontDataRecord
*  Function:
*       Checks for the closest match the the input FontDataRecord.
*               returns 0 if no match is found, MatchRecord is undefined.
*       else if the fontname matches
*               returns 1 -- MatchRecord contains a copy of the matched record
*       else if BoldFake and ItalicFake match
*               returns 2 , fills in MatchRecord with the data from the
*               closest match.
*       else if a complete match is found
*               returns 3 -- MatchRecord contains a copy of the input record
*  Called:
*       int FAR PASCAL CheckFontDataRecord(LPPDEVICE lppd,
*                                           FONTDATARECORD InFontData,
*                                           LPFONTDATARECORD MatchRecord);
*  Parameters:
*       LPPDEVICE lppd -- pdevice
*       FONTDATARECORD InFontData --  data to compare.
*       LPFONTDATARECORD MatchRecord --  closest match.
*
*  Returns:
*       int -- 0 => no match -- MatchRecord unmodified
*              1 => font name match
*              2 => Charset Match
*              3 => boldfake and italicfake match
*              4 => complete match including scaling
*************************************************************************/

int FAR PASCAL CheckFontDataRecord( LPPDEVICE lppd, FONTDATARECORD InFontData,
                           LPFONTDATARECORD MatchRecord)
{
   LPFONTDATARECORD currentptr;
   int retval, dex;

   retval = 0;
   currentptr = lppd->lpFontDataList->FontDataList;
   dex = 0;

   while ( (retval != 4) && (dex < lppd->lpFontDataList->FontDataNextRecord) )
   {
     switch (retval)
     {
       case 0:   // no match found yet
         if ((lstrcmpi(currentptr->FontName, InFontData.FontName) == 0) &&
            (currentptr->DBCSFake == InFontData.DBCSFake) &&
            !InFontData.bDownLoadFace)
         {
            retval = 1;
            *MatchRecord = *currentptr;            // fill in Matchrecord
         }
         else
         {
            break;
         }

       case 1:  // looking for charset Only if Re-encoding is required
          // This step is not used any more but kept for future extension for PS Fonts.
         if (  (lstrcmpi(currentptr->FontName,InFontData.FontName) == 0) &&
               (currentptr->DBCSFake == InFontData.DBCSFake) &&
               ( (currentptr->CharSet==InFontData.CharSet) || !(InFontData.ReEncode)
                && !InFontData.bDownLoadFace
                )
          )
         {
            retval = 2;
            *MatchRecord = *currentptr; // fill in Matchrecord
         }
         else
         {
            break;
         }

       case 2:  // looking for boldfake and italicfake
         if (  (lstrcmpi(currentptr->FontName,InFontData.FontName) == 0) &&
               (currentptr->DBCSFake == InFontData.DBCSFake) &&
               ( (currentptr->CharSet==InFontData.CharSet) || !(InFontData.ReEncode) ) &&
              (currentptr->BoldFake == InFontData.BoldFake) &&
              (currentptr->ItalicFake == InFontData.ItalicFake) &&
              (SAME_ASCENDER(currentptr->ascender, InFontData.ascender)) && 
               !InFontData.bDownLoadFace
            )
         {
            retval = 3;
            *MatchRecord = *currentptr; // fill in Matchrecord
         }
         else if ((lstrcmpi(currentptr->FontName,InFontData.FontName) == 0) &&
                  (currentptr->DBCSFake == InFontData.DBCSFake) &&
                  ( (currentptr->CharSet==InFontData.CharSet) || !(InFontData.ReEncode) ) &&
                  (SAME_ASCENDER(currentptr->ascender, InFontData.ascender)) && 
                   !InFontData.bDownLoadFace
         )
         {
            *MatchRecord = *currentptr; // fill in Matchrecord
         }
         else
         {
            break;
         }

       case 3:  // looking for xscale and yscale
         if (  (lstrcmpi(currentptr->FontName,InFontData.FontName) == 0) &&
               (currentptr->DBCSFake == InFontData.DBCSFake) &&
               ( (currentptr->CharSet==InFontData.CharSet) || !(InFontData.ReEncode) ) &&
              (currentptr->BoldFake == InFontData.BoldFake) &&
              (currentptr->ItalicFake == InFontData.ItalicFake) &&
              (SAME_ASCENDER(currentptr->ascender, InFontData.ascender)) && 
              (currentptr->xScale == InFontData.xScale) &&
              (currentptr->yScale == InFontData.yScale) &&
              !InFontData.bDownLoadFace
            )
         {
            retval = 4;
            *MatchRecord = *currentptr; // fill in Matchrecord
         }
         else
         {
            break;
         }
 
       default:
       break;
     }  // switch (retval)

     // Go to next record
     currentptr ++ ;
     dex ++;
   } // while (...)

   return(retval);
}

/************************************************************************
*
*                       AddFontDataRecord
*  Function:
*       Adds a record to the font data list --
*
*  Called:
*       BOOL FAR PASCAL AddFontDataRecord(LPPDEVICE lppd,
*                                         LPFONTDATARECORD InFontData);
*  Parameters:
*       LPPDEVICE lppd -- pdevice pointer
*       LPFONTDATARECORD InFontData -- FONTDATARECORD data to be added
*
*  Returns:
*       BOOL -- TRUE => success
*  Note:
*       if InFontData->FontID == -1, the font id will be supplied by this
*       function.
*************************************************************************/

BOOL FAR PASCAL AddFontDataRecord(LPPDEVICE lppd, LPFONTDATARECORD InFontData)
{
   LPFONTDATARECORD currentrec;
   BOOL retval;

   retval = FALSE;

   if (lppd->lpFontDataList->FontDataNextRecord < MAXFONTDATARECORDS)
   {
     currentrec = lppd->lpFontDataList->FontDataList;
     currentrec += lppd->lpFontDataList->FontDataNextRecord;
     if (InFontData->FontID == -1)
     {
       InFontData->FontID = lppd->lpFontDataList->FontDataNextRecord;
     }
     InFontData->StackLevel = lppd->lpProcsetstuff->savelevel;
     *currentrec = *InFontData;
     currentrec->FontCacheUsed = 0; // YCT

     currentrec->IsGlyphDataOurs =
      lppd->lpFontDataList->GlyphData  &&
    currentrec->GlyphData == lppd->lpFontDataList->GlyphData ;

     lppd->lpFontDataList->FontDataNextRecord++;
     retval = TRUE;
   }


   return(retval);
}

/************************************************************************
*                       AddFontDSCEntry
*  Function:
*       Adds a record to the font DSC comment list --
*
*  Called:
*       BOOL FAR PASCAL AddFontDSCEntry(LPPDEVICE lppd,
*                                         LPSTR lpFontName, BOOL bfSupplied);
*  Parameters:
*       LPPDEVICE lppd  -- pdevice pointer
*       LPSTR FontName  -- Name of font to be added
*       BOOL bfSupllied -- Supplied/Needed Flag (pass value along to entry)
*
*  Returns:
*       BOOL -- TRUE => success
*
*************************************************************************/

BOOL FAR PASCAL AddFontDSCEntry(LPPDEVICE lppd, LPSTR lpFontName, BOOL bfSupplied)
{
   LPFONTDSCENTRY currententry;
   BOOL retval;

   retval = FALSE;

   if (retval = CheckFontDSCEntry(lppd, lpFontName) == FALSE)
   {                // Name not is already in list
     if (lppd->lpFontDSCList->FontDSCNextEntry < MAXFONTDATARECORDS)
     {
       currententry = lppd->lpFontDSCList->FontDSCList;
       currententry += lppd->lpFontDSCList->FontDSCNextEntry;
       lstrcpy(currententry->FontName, lpFontName);
       currententry->bfSupplied = bfSupplied;
       lppd->lpFontDSCList->FontDSCNextEntry ++;
     }
   }

   return (retval);
 }
/************************************************************************
*                       UpdateFontDSCEntry
*  Function:
*       Update a record to the font DSC comment list --
*
*  Called:
*       BOOL FAR PASCAL UpdateFontDSCEntry(LPPDEVICE lppd,
*                                         LPSTR lpFontName, BOOL bfSupplied);
*  Parameters:
*       LPPDEVICE lppd  -- pdevice pointer
*       LPSTR FontName  -- Name of font to be added
*       BOOL bfSupplied -- Supplied/Needed Flag (pass value along to entry)
*
*  Returns:
*       BOOL -- TRUE => success
*
*************************************************************************/

BOOL FAR PASCAL UpdateFontDSCEntry(LPPDEVICE lppd, LPSTR lpFontName, BOOL bfSupplied)
{
   LPFONTDSCENTRY currententry;
   BOOL retval;
   int dex;

   currententry = lppd->lpFontDSCList->FontDSCList;
   retval = FALSE;
   dex = 0;
   while (retval == FALSE && (dex < lppd->lpFontDSCList->FontDSCNextEntry))
   {
     if (lstrcmpi(currententry->FontName,lpFontName) == 0)
     
     { // Update the font name that is already in list
       currententry->bfSupplied = bfSupplied;
       retval = TRUE;
     }
     currententry ++ ;
     dex ++;
     
   }
   if ( retval == FALSE)
//              return (AddFontDSCEntry(lppd, lpFontName, TRUE));
      return (AddFontDSCEntry(lppd, lpFontName, bfSupplied));
   return (retval);
 }

/************************************************************************
*
*                       CheckFontDSCEntry
*  Function:
*       Checks to see if a record for a given font has already been
*       added to the font DSC comment list --
*
*  Called:
*       BOOL FAR PASCAL CheckFontDSCEntry(LPPDEVICE lppd, LPSTR lpFontName);
*
*  Parameters:
*       LPPDEVICE lppd  -- pdevice pointer
*       LPSTR lpFontName  -- Name of font to be added
*
*  Returns:
*       BOOL -- TRUE => Name is on list
*               FALSE => Name is not on list
*
*************************************************************************/

BOOL FAR PASCAL CheckFontDSCEntry(LPPDEVICE lppd, LPSTR lpFontName)
{
   LPFONTDSCENTRY currentptr;
   BOOL retval;
   int dex;

   retval = FALSE;
   currentptr = lppd->lpFontDSCList->FontDSCList;
   dex = 0;

   while (retval == FALSE && (dex < lppd->lpFontDSCList->FontDSCNextEntry))
   {
     if (lstrcmpi(currentptr->FontName,lpFontName) == 0)
     {
       retval = TRUE;
     }
     currentptr ++ ;
     dex ++;
   }

   return (retval);
}

/***************************************************************************
 *
 *                          TSendFontDSC
 *
 *    Function:  Sends the %%IncludeFont DSC comment, and adds the font
 *               name to the list of fonts for the %%DocumentNeededFont DSC
 *               comment. We use %%IncludeFont instead of %%IncludeResource: font
 *               for compatibility with old document managers.
 *
 *    Called:    VOID FAR PASCAL TSendFontDSC(LPPDEVICE lppd, LPSTR FontName)
 *
 *    Parameters:  LPPDEVICE lppd
 *                 LPSTR FontName
 *
 *    Returns:  Nothing
 *
 ***************************************************************************/

VOID FAR PASCAL TSendFontDSC(LPPDEVICE lppd, LPSTR FontName)
{
   LPASCIIBINPTRS tempptr;
   BOOL retval;
   char buf[FONTNAMESIZE+1];

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   // For old doc managers we send %%IncludeFont: Times-Roman,
   // instead of newer %%IncludeResource: font Times-Roman

   //lstrcpy(buf, FontName);
   //(*tempptr->PSSendDSC)(lppd, DSC_includeresfont, buf); //Really %%IncludeFont:
   // new DSC 3.1
   
   lstrcpy(buf, szFont);
   lstrcat(buf, FontName);
   (*tempptr->PSSendDSC)(lppd, DSC_includeresource, buf); //%%includeresource

   // Add font name to list for DSC %%DocumentNeededFont
   retval = AddFontDSCEntry(lppd,FontName,FALSE);  //FALSE == Font Needed
}

WORD NEAR PASCAL GetFontAttribute(LPLOGFONT lpLogFont, int *RealAttributes)
{
   TYPE42HEADER *lpHeadTable = NULL;
   LPTABLEENTRY lpTblEntry = NULL;
   HDC hDC = NULL;
   HFONT hFont = NULL;
   HFONT hPrevFont = NULL;
   DWORD nTableSize;
   BYTE huge * lpData = NULL;
   int macStyle = 0;

    //if not a real tt font, meaning no ttfont data, we return 0

   if ((hDC = GetDC(NULL)) == NULL)
     return 0;

   if ((hFont = CreateFontIndirect(lpLogFont) ) == NULL)
     return 0;

   if ((hPrevFont = SelectObject(hDC,hFont)) == NULL)
     return 0;

   //get the size of the TrueType font file "head" table
   nTableSize = GetTableHDC(hDC, (DWORD)HEAD_TABLE, (BYTE)NULL);

   //allocate buffer for head table
   if (nTableSize != 0 )
      lpData = (BYTE huge *) GlobalAllocPtr(GHND, nTableSize);

   if (lpData == NULL)
      return 0;

   if (GetTableHDC(hDC, (DWORD) HEAD_TABLE, (BYTE huge *) lpData) == -1)
       return 0;

  lpHeadTable = (TYPE42HEADER *) lpData;

  macStyle = (int) (MOTOROLAINT(lpHeadTable->macStyle));

  if ((macStyle & MACSTYLE_BOLD_PRESENT) && (macStyle & MACSTYLE_ITALIC_PRESENT))
  {
     *RealAttributes |= BOLDITALICPRESENT;
  }
  else if ((macStyle & MACSTYLE_BOLD_PRESENT) && !(macStyle & MACSTYLE_ITALIC_PRESENT))
      {
         *RealAttributes |= BOLDPRESENT;
      }
      else if (!(macStyle & MACSTYLE_BOLD_PRESENT) && (macStyle & MACSTYLE_ITALIC_PRESENT))
          {
             *RealAttributes |= ITALICPRESENT;
          }

    if (hPrevFont != NULL)
        SelectObject (hDC, hPrevFont) ;
    if (hFont != NULL)
        DeleteObject (hFont) ;
    if (lpData != NULL)
        GlobalFreePtr(lpData) ;
    if (hDC != NULL)
        ReleaseDC (NULL, hDC) ;
   return (1);
  
}

/***************************************************************************
*
*                          FakeBoldItalicCallback
*
*    Function:
*
*    Called:  int CALLBACK FakeBoldItalicCallback(LPLOGFONT lpLogFont,
*                             NEWTEXTMETRIC FAR *tm, int FontType, DWORD lpData)
*
*    Parameters:  LPLOGFONT          lpLogFont
*                 NEWTEXTMETRIC FAR  *tm
*                 int                FontType
*                 DWORD              lpData
*
*    Returns:
*
***************************************************************************/
int CALLBACK FakeBoldItalicCallback(LPLOGFONT lpLogFont, NEWTEXTMETRIC FAR *tm, int FontType, DWORD lpData)
{
   LPINT attribute = (LPINT) lpData;

   *attribute |=   ANYSTYLEPRESENT;   // this means this function is called at least once. not "Glerbish" font!!

  return 1;
}


/***************************************************************************
*
*                          FakeBoldItalicType42
*    Function:
*
*    Called:  VOID FAR PASCAL FakeBoldItalicType42(LPSTR faceName, LPTEXTXFORM TextXForm,
*                                       LPFONTDATARECORD lpFontData)
*
*    Parameters:  LPSTR            faceName
*                 LPTEXTXFORM      TextXForm
*                 LPFONTDATARECORD lpFontData
*
*    Returns:
*
***************************************************************************/

VOID FAR PASCAL FakeBoldItalicType42(LPLOGFONT lpLogFont, LPTEXTXFORM TextXForm,
                     LPFONTDATARECORD lpFontData)
{
   int RealAttributes = 0;
   FARPROC lpCallbackProc;

   lpCallbackProc= MakeProcInstance((FARPROC)FakeBoldItalicCallback, ghDriverMod);
   EngineEnumerateFont(lpLogFont->lfFaceName, lpCallbackProc, (DWORD)(LPINT)&RealAttributes);

   // if the base font "Glerbish" doesn't exist at all (RealAttributes=0)
   // don't fake anything - Fix bug 122818.
   if (RealAttributes == 0 )
   {
       lpFontData->BoldFake = lpFontData->ItalicFake = FALSE;
   }
   else
   {   //Fix bug 292825:  Use TTFont's Head table to determine if
       //we should fake BOLD and facke Italic.
       if (GetFontAttribute(lpLogFont, (int *) &RealAttributes) != 0)
       {
          if ((TextXForm->ftWeight>=700) &&
              (TextXForm->ftItalic) && 
              (RealAttributes & BOLDITALICPRESENT) )
          {
           // If we have bold-italic font - don't bother to fake it
               lpFontData->BoldFake = lpFontData->ItalicFake = FALSE;
          }
          else
          {
               lpFontData->BoldFake = ((TextXForm->ftWeight>=700) && !(RealAttributes & BOLDPRESENT));
               lpFontData->ItalicFake = ((TextXForm->ftItalic) && !(RealAttributes & ITALICPRESENT));
          }
       }
   }

   FreeProcInstance(lpCallbackProc);
}

/***************************************************************************
*
*                          CheckDLType
*    Function:
*    int FAR PASCAL CheckDLType(LPPDEVICE lppd, LPLOGFONT lpLogFont, LPFONTDATARECORD lpTmpFontData)
*
*
*    Parameters:  LPSTR            faceName
*                 LPTEXTXFORM      TextXForm
*                 LPFONTDATARECORD lpFontData
*
User-Set    Font-Type42Able  PrnType42Able   TT_Resident  Outline  Return
T42           Yes             must be Yes       Y/N          Y       T42
T42           No              must be Yes       Y/N          Y       T1
--
T1            Yes             YES               Yes          Y       T42 **
T1            Yes             No                Yes          Y       T1  ***
T1            Yes             Y/N               No           Y       T1
T1            NO              Y/N               Y/N          Y       T1
T1            NO              Y/N               Y/N          N       T3
--
T3            Yes             YES               Yes          Y       T42 **
T3            Yes             No                Yes          Y       T1  ***
T3            NO              Y/N               Y/N          Y       T1
T3            NO              Y/N               Y/N          N       T3
--
** and *** We assume a printer with TT_Resident must be Type42Capable
*    Returns:
*
***************************************************************************/
int FAR PASCAL CheckDLType(LPPDEVICE lppd, LPLOGFONT lpLogFont, LPPSFONTINFO lpFontInfo, LPFONTDATARECORD lpTmpFontData)
{
   TEXTXFORM      tmpTextXForm;
   int Type42Able = 0;  // default to 0 so we can use it to check for real Type42
   int iDLFontFormat;

   iDLFontFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;

   tmpTextXForm.ftWeight = lpLogFont->lfWeight;
   tmpTextXForm.ftItalic = lpLogFont->lfItalic;

   //fakeitalic used for T42, and FakeBold is for T1-GDI bug fix
   if (lpTmpFontData)
   {
     lpTmpFontData->ItalicFake = 0;  
     lpTmpFontData->BoldFake = 0;
     FakeBoldItalicType42(lpLogFont, (LPTEXTXFORM)&tmpTextXForm,
            (LPFONTDATARECORD)lpTmpFontData);
   }

   Type42Able = IsType42Able(lppd, lpFontInfo); // Real TT Font-not ATMfont
   if (lpTmpFontData && !Type42Able){
      lpTmpFontData->ItalicFake = 0; // undo side effect for T1/3 -GDI does italic
   }

   // Step 1 ***
   // If User asks for T42 and this is NOT t42 font, return T1
   if ( (iDLFontFormat == TT_DLFORMAT_TYPE42) &&
    !Type42Able )
   {
       return TT_DLFORMAT_TYPE1;
   }
   // If TrueType font is resident then must be T42.   -ANG-6/11/96
   // Override user selection's DLformat and change it to T42 naming
   // ttext.DownloadFont does the same.
   // Step 2 ***
   if ( Type42Able &&
   (lpFontInfo->dfType & TYPE_TTRESIDENT))
   {
       iDLFontFormat = TT_DLFORMAT_TYPE42; // to check FakeItalic later
   }
   // Step 3 ***
   //It's actually type 3
   if ((iDLFontFormat == TT_DLFORMAT_TYPE1) && !(lpFontInfo->dfType & TYPE_OUTLINE))
   {
       return TT_DLFORMAT_TYPE3;
   }
   // Step 4 ***
   if ((iDLFontFormat == TT_DLFORMAT_TYPE3) && (lpFontInfo->dfType & TYPE_OUTLINE))
   {
       return TT_DLFORMAT_TYPE1;
   }

   return (iDLFontFormat);
}

/***************************************************************************
*
*                            FontInstName
*
*    Function:
*
*    Called:  VOID FAR PASCAL FontInstName(LPSTR Name,LPFONTDATARECORD FontData)
*
*    Parameters:  LPSTR            Name
*                 LPFONTDATARECORD FontData
*
*    Returns:
*
****************************************************************************/

VOID FAR PASCAL FontInstName(LPSTR Name, LPFONTDATARECORD FontData)
{
   char Buff[20];
   int temp;

   temp = GET_ASCENDER(FontData->ascender);

   lstrcpy(Name, (LPSTR)"F");

   wsprintf((LPSTR)Buff,(LPSTR)"%d",FontData->FontID);
   lstrcat(Name,(LPSTR)Buff);

   //WCC Bug#277500
   if (FontData->addAscExt) {
      wsprintf((LPSTR)Buff, (LPSTR)"A%d", temp);  // A for ascender
      lstrcat(Name, (LPSTR)Buff);
   }

   if (FontData->BoldFake) //old-boldfake-condition && !(FontData->DBCSFake & DBCS_DEVICE_FAKE))
     lstrcat(Name,(LPSTR)"B");
   if (FontData->ItalicFake)
     lstrcat(Name,(LPSTR)"I");

   // Add Charset value
   if (FontData->ReEncode){
      // Only if re-encoded. Not used anymore, but kept for future PS Fonts extension
      wsprintf((LPSTR)Buff,(LPSTR)"C%d", (int)FontData->CharSet);  // C for CharSet
      lstrcat(Name,(LPSTR)Buff);
     }

   if ((FontData->xScale != 0) || (FontData->yScale != 0))
   {
     // Tack on xScale
     wsprintf((LPSTR)Buff,(LPSTR)"S%d",FontData->xScale);    // S for scale
     lstrcat(Name,(LPSTR)Buff);

     if (FontData->yScale != FontData->xScale)
     {
       // Tack on yscale if it doesn't = xscale
       wsprintf((LPSTR)Buff, (LPSTR)"Y%d", FontData->yScale);  // Y for y scale
       lstrcat(Name, (LPSTR)Buff);
     }
   }
}


/***************************************************************************
 *
 *                          TTDownLoadT3orT32Font
 *
 *    Function:  Generates the necessary font definition code to create a
 *               new Type 32 font.  The parameters are the same as TTDownloadFont.
 *
 *    Called:    int NEAR PASCAL TTDownLoadT32Font(LPPDEVICE lppd,
 *                                        LPPSFONTINFO FontInfo,
 *                               LPFONTDATARECORD lpFontData, BOOL bFullFont)
 *    Parameters: LPPDEVICE   lppd               Pointer to PDEVICE structure
 *                LPPSFONTINFO  FontInfo
 *                BOOL        bFullFont
 *                LPFONTDATARECORD  lpFontDataRecord
 *
 *    Returns:    PSERROR
 *
 ***************************************************************************/

PSERROR NEAR PASCAL TTDownLoadT3orT32Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
        LPFONTDATARECORD lpFontData, BOOL bFullFont, unsigned long maxNumGlyphs)

{
    LPSUBFONT43  pSubFont = (LPSUBFONT43) GlobalAllocPtr(GHND, sizeof(SUBFONT43));
    LPTTFONTINFO lpttfi = (LPTTFONTINFO) ((LPSTR)FontInfo + FontInfo->dfBitsOffset);
    WORD         iCount = 1;
    BYTE         *pByte;
    int          doVMRecovery = lppd->doVMRecovery;

    if (!pSubFont)
       return PS_ALLOC_FAILED;

    lstrcpy(pSubFont->strPSName, (LPSTR)lpttfi->PSName);

    pSubFont->lppd = (LPVOID)lppd;
    pSubFont->FontInfo = (LPVOID) FontInfo;
    pSubFont->bFullFont = bFullFont;
    pSubFont->pufo = (LPVOID) NULL;
    BNewType3Font(lppd, pSubFont, maxNumGlyphs, DLFONT_TYPE332); /* Type3/32 combo */
    lpFontData->pSubFont = pSubFont;
    lpFontData->isMypSubFont = 1;

    /* Since no two TextOut() or Download() calls overlap, we can use hte global buffer gWordArray0 */
    pByte = (BYTE *) gWordArray0;

    /* Force UFL (Fake) a FullFont downloading - download all chars from 0 to 255 */
    if (bFullFont)
    {
        if(FontInfo->dfType & PF_GLYPH_INDEX)
        {
            for (iCount = 0; iCount < WARRAY0SIZE; iCount++)
            {
                gWordArray0[iCount] = iCount;
            }
        }
        else
        {
            for (iCount = 0; iCount < WARRAY0SIZE; iCount++)
            {
                pByte[iCount] = (BYTE)iCount;
            }
        }
        iCount = WARRAY0SIZE;
    }
    else
    {
        /* force the header to be sent - as win old Win95 driver*/
        if(FontInfo->dfType & PF_GLYPH_INDEX)
            gWordArray0[0] = 0;
        else
            pByte[0]=' ';   /* space */

        iCount = 1;
    }

    /* disable VM Recovery for font Header or FullFontDown*/
    lppd->doVMRecovery = 0;
    TTUpdateT3orT32Font(lppd, FontInfo, lpFontData, pByte, iCount);
    lppd->doVMRecovery = doVMRecovery ;

    return (PS_SUCCESS);

}


/***************************************************************************
 *
 *                          TTDownloadFont
 *
 *    Function:  Main routine to download a TrueType font.  FontInfo points to
 *               the physical font created by TTRealizeFont().  bFullFont
 *               takes on the following meaning:
 *
 *               TRUE   download font header and all characters
 *               FALSE  download font header only
 *
 *               After doing some common housekeeping the code calls the Type 1
 *               or Type 3 font generator as appropriate.  The decision is
 *               determined in TTRealizeFont() and reflected in the TYPE_OUTLINE
 *               bit of FontInfo->dfType.
 *
 *    Called:    int FAR PASCAL TTDownLoadFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
 *                           BOOL bFullFont, LPFONTDATARECORD lpFontDataRecord, BOOL minHeader)
 *
 *    Parameters:  LPPDEVICE lppd
 *                 LPPSFONTINFO FontInfo
 *                 BOOL bFullFont
 *                 LPFONTDATARECORD lpFontDataRecord
 *
 *    Returns:    PSERROR
 *
 ***************************************************************************/

PSERROR FAR PASCAL TTDownLoadFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                                         BOOL bFullFont, LPFONTDATARECORD lpFontDataRecord, BOOL minHeader)
{
   LPTTFONTINFO   lpttfi;     // TrueType info structure
   LPASCIIBINPTRS tempptr;
   PSERROR rc = PS_SUCCESS;                // return value of function
   int iDLFontFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;
   BOOL isTTDL = FontInfo->dfType & TYPE_TTRESIDENT;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   lpttfi = (LPTTFONTINFO)((LPSTR) FontInfo + FontInfo->dfBitsOffset);
                       // get TrueType font information

   // Validate pointers in FontInfo and get the download flags
   // Try to get a font match with maximum matching attributes

   lpFontDataRecord->BoldFake = FALSE;
   lpFontDataRecord->ItalicFake = FALSE;
   lpFontDataRecord->xScale = lpttfi->sx; // 0;
   lpFontDataRecord->yScale = lpttfi->sy; // 0;

   //Get additional space for post table. ang 9/18/97  ufl stuff.


   // for Portability (nodribble), the FONTDATALIST gets flushed every page.
   // So, even if the same font is realized in subsequent pages, it is treated
   // as a new font, i.e., font header + any glyphs get downloaded again
   // TSoftFontLoad() has the necessary logic to decide this - [ShyamV] - 8/30/93

   // call the appropriate font generation routine

   //Calculate XUID record for output
   MakeXUIDVector(lppd, &(lpttfi->lfCopy), lpFontDataRecord, FontInfo);

   // If TrueType font is resident then must be T42. -ANG-6/11/96
   iDLFontFormat = lpttfi->iDLFontFormat;

   switch (iDLFontFormat)
   {
     case TT_DLFORMAT_TYPE3:
     case TT_DLFORMAT_TYPE1:
       rc = AllocateGlyfData(lppd, lpFontDataRecord);
       if (PS_ERROR(rc))
           break;

       TTLockFont(lppd, FontInfo, lpFontDataRecord);

      if( lpFontDataRecord->fontDLType == CC_T01 ||
     lpFontDataRecord->fontDLType == CC_T03)
     { // This TypeType font is downlaoded as Type0 Font (T0/1 or T0/3):
          rc = TTDownLoadT0Font(lppd, FontInfo, bFullFont, lpFontDataRecord);
     }
     else // old way: T1 or T3
    {
        if (FontInfo->dfType & TYPE_OUTLINE)
      {
#ifdef T3OUTLINE
            if (bTTtoT3OL)        //bugbug!!!    Need UI change
         {
                rc = TTDownLoadT3OutlineFont(lppd, FontInfo, lpFontDataRecord, bFullFont, MAX_NUM_CHARS_US);
         }
         else
         {
                rc = TTDownLoadT1OutlineFont(lppd, FontInfo, lpFontDataRecord, bFullFont, MAX_NUM_CHARS_US);
         }
#else
                rc = TTDownLoadT1Font(lppd, FontInfo, lpFontDataRecord, bFullFont, MAX_NUM_CHARS_US);
#endif
      }
        else
            {      //YCT
                rc = TTDownLoadT3orT32Font(lppd, FontInfo, lpFontDataRecord, bFullFont, MAX_NUM_CHARS_US);
            }
    }

        break;

     case TT_DLFORMAT_TYPE42:
        if (!isTTDL)
            rc = AllocateGlyfData(lppd, lpFontDataRecord);
        if (PS_ERROR(rc))
            break;

        TTLockFont(lppd, FontInfo, lpFontDataRecord);
         //we'll use TTDownLoadT42 to do both.
        rc = TTDownLoadT42(lppd, FontInfo, lpFontDataRecord, bFullFont);

        break;

     case TT_DLFORMAT_TRUEIMAGE:
       TTDownLoadTTFont(lppd, FontInfo, bFullFont);
     break;

     case TT_DLFORMAT_NONE:
     break;
   }

   TTUnlockFont(lppd, FontInfo, lpFontDataRecord);
   if (PS_ERROR(rc))
   {
       // Free Glyph data
       if (lpFontDataRecord->GlyphData)
       {
      GlobalFreePtr(lpFontDataRecord->GlyphData);
      lpFontDataRecord->GlyphData = NULL;
      lppd->lpFontDataList->GlyphData = NULL; // Was pointing to what we just freed
       }
   }
   
   return rc;
}

/***************************************************************************
 *
 *                          TTDownloadT1Font
 *
 *    Function:   Generates the necessary font definition code to create a new
 *                Type 1 font. The parameters are the same as TTDownloadFont.
 *
 *    Called:     int NEAR PASCAL TTDownLoadT1Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
 *                               LPFONTDATARECORD lpFontData, BOOL bFullFont)
 *
 *    Parameters:    LPPDEVICE   lppd
 *                   LPPSFONTINFO  FontInfo
 *                   BOOL        bFullFont
 *                   LPFONTDATARECORD  lpFontDataRecord
 *
 *    Returns:      PSERROR
 *
 ***************************************************************************/
#define  SHIFTBITS  0

#ifdef T3OUTLINE
PSERROR NEAR PASCAL TTDownLoadT1OutlineFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
             LPFONTDATARECORD lpFontData, BOOL bFullFont, unsigned long maxNumGlyphs)
#else
PSERROR NEAR PASCAL TTDownLoadT1Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
             LPFONTDATARECORD lpFontData, BOOL bFullFont, unsigned long maxNumGlyphs)
#endif

{
    LPSUBFONT43  pSubFont = (LPSUBFONT43) GlobalAllocPtr(GHND, sizeof(SUBFONT43));
    LPTTFONTINFO lpttfi = (LPTTFONTINFO) ((LPSTR)FontInfo + FontInfo->dfBitsOffset);
    WORD         iCount = 1;
    BYTE         *pByte;
    int          doVMRecovery = lppd->doVMRecovery;

    if (!pSubFont)
        return PS_ALLOC_FAILED;

    lstrcpy(pSubFont->strPSName, (LPSTR)lpttfi->PSName);
    pSubFont->lppd = (LPVOID)lppd;
    pSubFont->FontInfo = (LPVOID) FontInfo;
    pSubFont->bFullFont = bFullFont;
    pSubFont->pufo = (LPVOID) NULL;

    BNewType1Font(lppd, pSubFont, maxNumGlyphs);
    lpFontData->pSubFont = pSubFont;
    lpFontData->isMypSubFont = 1;

    /* Since no two TextOut() or Download() calls overlap, we can use hte global buffer gWordArray0 */
    pByte = (BYTE *) gWordArray0;

    /* Force UFL (Fake) a FullFont downloading - download all chars from 0 to 255 */
    if (bFullFont)
    {
        if(FontInfo->dfType & PF_GLYPH_INDEX)
        {
            for (iCount = 0; iCount < WARRAY0SIZE; iCount++)
            {
                gWordArray0[iCount] = iCount;
            }
        }
        else
        {
            for (iCount = 0; iCount < WARRAY0SIZE; iCount++)
            {
                pByte[iCount] = (BYTE)iCount;
            }
        }
        iCount = WARRAY0SIZE;
    }
    else
    {
        /* force the header to be sent - as win old Win95 driver*/
        if(FontInfo->dfType & PF_GLYPH_INDEX)
            gWordArray0[0] = 0;
        else
            pByte[0]=' ';   /* space */

        iCount = 1;
    }

    /* disable VM Recovery for font Header or FullFontDown*/
    lppd->doVMRecovery = 0;
    TTUpdateT1Font(lppd, FontInfo, lpFontData, pByte, iCount);
    lppd->doVMRecovery = doVMRecovery ;

    return (PS_SUCCESS);
}


/***************************************************************************
 *
 *                          TTDownLoadT3Font
 *
 *    Function:  Generates the necessary font definition code to create a
 *               new Type 3 font.  The parameters are the same as TTDownloadFont.
 *
 *    Called:    int NEAR PASCAL TTDownLoadT3Font(LPPDEVICE lppd,
 *                                        LPPSFONTINFO FontInfo,
 *                               LPFONTDATARECORD lpFontData, BOOL bFullFont)
 *    Parameters: LPPDEVICE   lppd               Pointer to PDEVICE structure
 *                LPPSFONTINFO  FontInfo
 *                BOOL        bFullFont
 *                LPFONTDATARECORD  lpFontDataRecord
 *
 *    Returns:    PSERROR
 *
 ***************************************************************************/

PSERROR NEAR PASCAL TTDownLoadT3Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
        LPFONTDATARECORD lpFontData, BOOL bFullFont, unsigned long maxNumGlyphs)
{
    LPSUBFONT43  pSubFont = (LPSUBFONT43) GlobalAllocPtr(GHND, sizeof(SUBFONT43));
    LPTTFONTINFO lpttfi = (LPTTFONTINFO) ((LPSTR)FontInfo + FontInfo->dfBitsOffset);
    WORD         iCount = 1;
    BYTE         *pByte;
    int          doVMRecovery = lppd->doVMRecovery;

    if (!pSubFont)
       return PS_ALLOC_FAILED;

    lstrcpy(pSubFont->strPSName, (LPSTR)lpttfi->PSName);

    pSubFont->lppd = (LPVOID)lppd;
    pSubFont->FontInfo = (LPVOID) FontInfo;
    pSubFont->bFullFont = bFullFont;
    pSubFont->pufo = (LPVOID) NULL;
    BNewType3Font(lppd, pSubFont, maxNumGlyphs, DLFONT_TYPE3);  /* Type3-Only */
    lpFontData->pSubFont = pSubFont;
    lpFontData->isMypSubFont = 1;

    /* Since no two TextOut() or Download() calls overlap, we can use hte global buffer gWordArray0 */
    pByte = (BYTE *) gWordArray0;

    /* Force UFL (Fake) a FullFont downloading - download all chars from 0 to 255 */
    if (bFullFont)
    {
        if(FontInfo->dfType & PF_GLYPH_INDEX)
        {
            for (iCount = 0; iCount < WARRAY0SIZE; iCount++)
            {
                gWordArray0[iCount] = iCount;
            }
        }
        else
        {
            for (iCount = 0; iCount < WARRAY0SIZE; iCount++)
            {
                pByte[iCount] = (BYTE)iCount;
            }
        }
        iCount = WARRAY0SIZE;
    }
    else
    {
        /* force the header to be sent - as win old Win95 driver*/
        if(FontInfo->dfType & PF_GLYPH_INDEX)
            gWordArray0[0] = 0;
        else
            pByte[0]=' ';   /* space */

        iCount = 1;
    }

    /* disable VM Recovery for font Header or FullFontDown*/
    lppd->doVMRecovery = 0;
    TTUpdateT3orT32Font(lppd, FontInfo, lpFontData, pByte, iCount);
    lppd->doVMRecovery = doVMRecovery ;

    return (PS_SUCCESS);

}



/***************************************************************************
 *
 *                          T32ReleaseFontCache
 *
 *    Function:  Remove the all the glyphs defined for current font ID
 *               The TFontCacheAvailable is updated
 *
 *    Called:    void NEAR PASCAL T32ReleaseFontCache(LPPDEVICE lppd, int CurFontId)
 *
 *    Parameters:  LPPDEVICE lppd
 *                 int CurFontId
 *
 *    Returns:   void
 *
 ***************************************************************************/

void FAR PASCAL T32ReleaseFontCache(LPPDEVICE lppd, LPFONTDATARECORD lpFontDataRecord)
{
   if (lpFontDataRecord->FontCacheUsed > 0)
   {
       lppd->lpFontDataList->TFontCacheAvail += (long)lpFontDataRecord->FontCacheUsed;
       lpFontDataRecord->FontCacheUsed = (DWORD)0;
   }
}


/***************************************************************************
 *
 *                          TTUpdateT3orT32Font
 *
 *    Function:  Adds all of the characters from lpStr that aren't already
 *               downloaded for the TrueType font in FontInfo.
 *
 *    Called:    int NEAR PASCAL TTUpdateT3orT32Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPBYTE lpStr, int cb)
 *
 *    Parameters:  LPPDEVICE lppd
 *                 LPPSFONTINFO FontInfo
 *                 LPBYTE lpStr
 *                 int cb
 *
 *    Returns:   UPDATE_FAILURE, UPDATE_LOWVM or UPDATE_SUCCESS
 *
 ***************************************************************************/

int NEAR PASCAL TTUpdateT3orT32Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPFONTDATARECORD lpFontData, LPBYTE lpStr, int cb)
{
    static int  strLen = 0;
    ULONG       VMUsage, FCUsage;
    int         PSVersion = GetPSVersion(lppd);
    LPDWORD     lpDLGlyph = NULL;
    LPWORD      lpCharIndex= NULL;
    LPWORD      lpUnicode = NULL;
    BOOL        rc=TRUE;

    strLen = cb;
            
    FillUFLGIArray(
        lppd, 
        FontInfo,
        cb,     /* number of glyphs/CharIndex/Unicode - a guess */
        &lpDLGlyph,         /* pointer to glyphID array */
        &lpCharIndex,   /* pointer to CharIndex array */
        &lpUnicode,     /* pointer to Unicode array */
        lpFontData,
        lpStr,          /* Original Char String from TextOut() */
        &strLen);

    /* Need to update pointers in lpFontData->pSubFont for UFL call back */
    UpdateUFLSubFont(lpFontData->pSubFont, lppd, FontInfo, lpFontData );

    if (DoVMTracking(lppd))
    {
        BUFOVMNeeded((ULONG) DLFONT_TYPE3, (LPSUBFONT43) lpFontData->pSubFont,
                (short)strLen, lpDLGlyph, (unsigned char **)&apszEncode, 
                lpCharIndex, lpUnicode, (ULONG *) &VMUsage, (ULONG *) &FCUsage);

        /* Don't bother with small bytes of VM */
        if (VMUsage > 100) 
        {
            if ( TRUE == VMCheck(lppd, VM_GOODESTIMATE, VMUsage) )
                return UPDATE_LOWVM;
        }
    }

    rc = BUFODownload((ULONG) DLFONT_TYPE3, (LPSUBFONT43) lpFontData->pSubFont,
                (short)strLen, lpDLGlyph, (unsigned char **)&apszEncode, 
                lpCharIndex, lpUnicode, (ULONG *) &VMUsage, (ULONG *) &FCUsage);


    if (PSVersion < 2016)
        VMUsed(lppd, VM_GOODESTIMATE, VMUsage);

    if (rc)
      return (UPDATE_SUCCESS);
    else
      return (UPDATE_FAILURE);
}


/***************************************************************************
 *
 *                          TTUpdateT1Font
 *
 *    Function: Adds all of the characters from lpStr that aren't already
 *              downloaded for the TrueType font in FontInfo.
 *
 *    Called:   int NEAR PASCAL TTUpdateT1Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPFONTDATARECORD lpFontData, LPBYTE lpStr, int cb)
 *
 *    Parameters:  LPPDEVICE        lppd
 *                 LPPSFONTINFO       FontInfo
 *                 LPFONTDATARECORD lpFontData
 *                 LPBYTE           lpStr
 *                 int              cb
 *
 *    Returns:   UPDATE_FAILURE, UPDATE_LOWVM or UPDATE_SUCCESS
 *
 ***************************************************************************/
#ifdef T3OUTLINE
int NEAR PASCAL TTUpdateT1OutlineFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPFONTDATARECORD lpFontData, LPBYTE lpStr, int cb)
#else
int NEAR PASCAL TTUpdateT1Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPFONTDATARECORD lpFontData, LPBYTE lpStr, int cb)
#endif
{
    static int strLen = 0;
    ULONG       VMUsage, FCUsage;
    LPDWORD     lpDLGlyph = NULL;
    LPWORD      lpCharIndex= NULL;
    LPWORD      lpUnicode = NULL;
    BOOL        rc=TRUE;

    strLen = cb;
            
    FillUFLGIArray(
        lppd, 
        FontInfo,
        cb,     /* number of glyphs/CharIndex/Unicode - a guess */
        &lpDLGlyph,         /* pointer to glyphID array */
        &lpCharIndex,   /* pointer to CharIndex array */
        &lpUnicode,     /* pointer to Unicode array */
        lpFontData,
        lpStr,          /* Original Char String from TextOut() */
        &strLen);

    /* Need to update pointers in lpFontData->pSubFont for UFL call back */
    UpdateUFLSubFont(lpFontData->pSubFont, lppd, FontInfo, lpFontData );
    
    if (DoVMTracking(lppd))
    {
        BUFOVMNeeded((ULONG) DLFONT_TYPE1, (LPSUBFONT43) lpFontData->pSubFont, 
                (short)strLen, lpDLGlyph, (unsigned char **)&apszEncode, 
                lpCharIndex, lpUnicode, (ULONG *) &VMUsage, (ULONG *) &FCUsage);

        /* Don't bother with small bytes of VM */
        if (VMUsage > 100) 
        {
            if ( TRUE == VMCheck(lppd, VM_GOODESTIMATE, VMUsage) )
                return UPDATE_LOWVM;
        }
    }

    rc = BUFODownload((ULONG) DLFONT_TYPE1, (LPSUBFONT43) lpFontData->pSubFont, 
                (short)strLen, lpDLGlyph, (unsigned char **)&apszEncode, 
                lpCharIndex, lpUnicode, (ULONG *) &VMUsage, (ULONG *) &FCUsage);


    VMUsed(lppd, VM_GOODESTIMATE, VMUsage);

    if (rc)
      return(UPDATE_SUCCESS);
    else
      return(UPDATE_FAILURE);
   
}


/***************************************************************************
 *
 *                             TTUpdateFont
 *    Function:
 *
 *    Called:  int FAR PASCAL TTUpdateFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPSTR lpStr, int cb, LPFONTDATARECORD lpFontDataRecord, BOOL minHeader)
 *
 *    Parameters:  LPPDEVICE        lppd
 *                 LPPSFONTINFO       FontInfo
 *                 LPSTR            lpStr
 *                 int              cb
 *                 LPFONTDATARECORD lpFontDataRecord
 *
 *    Returns:   UPDATE_FAILURE, UPDATE_LOWVM or UPDATE_SUCCESS
 *
 ***************************************************************************/

int FAR PASCAL TTUpdateFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPSTR lpStr,
                                                   int cb, LPFONTDATARECORD lpFontDataRecord, BOOL minHeader)
{
   int rc = UPDATE_SUCCESS;
   LPTTFONTINFO  lpttfi = (LPTTFONTINFO)((LPSTR)FontInfo + FontInfo->dfBitsOffset);
   int iDLFontFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;
   LPBYTE   lpFontName = lpttfi->PSName;


   // If TrueType font is resident then must be T42. -ANG-6/11/96
   iDLFontFormat = lpttfi->iDLFontFormat;
   // Get GlyphData for current font, for record of chars already downloaded

   TTLockFont(lppd, FontInfo, lpFontDataRecord);

   if( lpFontDataRecord->fontDLType == CC_T01 ||
       lpFontDataRecord->fontDLType == CC_T03)
      { // This TypeType font is downlaoded as Type0 Font (T0/1 or T0/3):
      rc = TTUpdateT0Font(lppd, FontInfo, lpStr, cb, lpFontDataRecord);
      }
   else // old way: T1 or T3 or T42
   if (FontInfo->dfType & TYPE_OUTLINE)
   {
#ifdef ADOBE_DRIVER
      if (iDLFontFormat == TT_DLFORMAT_TYPE42)
      {
//old way
//       if (FontInfo->dfType & PF_GLYPH_INDEX)
//       {
//          rc = TTUpdateCompositeFont(lppd, FontInfo, lpFontDataRecord, (LPWORD)lpStr, cb);
//       }
//       else
//       {
//       UFL combined 42gi and 42cc so we just use TTUpdateT42
          rc = TTUpdateT42(lppd, FontInfo, lpFontDataRecord, lpStr, cb );
//       }
      }
      else
      {
      
#endif
#ifdef T3OUTLINE
      if (bTTtoT3OL)     // bugbug!!!    Need UI change
      {
          rc = TTUpdateT3OutlineFont(lppd, FontInfo, lpFontDataRecord, lpStr, cb);
      }
      else
      {
        rc = TTUpdateT1OutlineFont(lppd, FontInfo, lpFontDataRecord, lpStr, cb);
      }
#else
        rc = TTUpdateT1Font(lppd, FontInfo, lpFontDataRecord, lpStr, cb);
#endif
     }
   }
   else
   {  //!outline

         rc = TTUpdateT3orT32Font(lppd, FontInfo, lpFontDataRecord, lpStr, cb);
   }

   TTUnlockFont(lppd, FontInfo, lpFontDataRecord);
   return rc;
}
/***************************************************************************
 *
 *                             TTUpdateFontExt
 *    Function: For Type0 Font update, Use TTUpdateT3orT32Font to update T3-only font
 *
 *    Called:  int FAR PASCAL TTUpdateFontExt(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPSTR lpStr, int cb, LPFONTDATARECORD lpFontDataRecord)
 *
 *    Parameters:  LPPDEVICE        lppd
 *                 LPPSFONTINFO       FontInfo
 *                 LPSTR            lpStr
 *                 int              cb
 *                 LPFONTDATARECORD lpFontDataRecord
 *
 *    Returns:   UPDATE_FAILURE, UPDATE_LOWVM or UPDATE_SUCCESS
 *
 ***************************************************************************/

int FAR PASCAL TTUpdateFontExt(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPSTR lpStr,
                     int cb, LPFONTDATARECORD lpFontDataRecord)
{
int             rc = UPDATE_SUCCESS;
LPTTFONTINFO    lpttfi = (LPTTFONTINFO)((LPSTR)FontInfo + FontInfo->dfBitsOffset);
int             iDLFontFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;

    // If TrueType font is resident then must be T42. -ANG-6/11/96
    iDLFontFormat = lpttfi->iDLFontFormat;
    // Get GlyphData for current font, for record of chars already downloaded

    TTLockFont(lppd, FontInfo, lpFontDataRecord);

    if (FontInfo->dfType & TYPE_OUTLINE)
    {
#ifdef ADOBE_DRIVER
        if (iDLFontFormat == TT_DLFORMAT_TYPE42)
        {
            rc = TTUpdateT42(lppd, FontInfo, lpFontDataRecord, lpStr, cb );
        }
        else
#endif
#ifdef T3OUTLINE
        if (bTTtoT3OL)     // bugbug !!!   Need UI change
        {
           rc = TTUpdateT3OutlineFont(lppd, FontInfo, lpFontDataRecord, lpStr, cb);
        }
       else
        {
           rc = TTUpdateT1OutlineFont(lppd, FontInfo, lpFontDataRecord, lpStr, cb);
        }
#else
       rc = TTUpdateT1Font(lppd, FontInfo, lpFontDataRecord, lpStr, cb);
#endif
    }
    else
    {
       rc = TTUpdateT3orT32Font(lppd, FontInfo, lpFontDataRecord, lpStr, cb);
    }
    
    TTUnlockFont(lppd, FontInfo, lpFontDataRecord);
    return rc;
}

/***************************************************************************
 *
 *                          AllocateGlyfData
 *    Function:
 *
 *    Called:  BOOL AllocateGlyfData(LPPDEVICE lppd, LPFONTDATARECORD lpFontDataRecord)
 *
 *
 *    Parameters:  LPPDEVICE lppd
 *                 LPFONTDATARECORD lpFontDataRecord
 *
 *    Returns:
 *
 ***************************************************************************/

PSERROR AllocateGlyfData(LPPDEVICE lppd, LPFONTDATARECORD lpFontDataRecord)
{
   PSERROR rc = PS_SUCCESS;
   DWORD   dwSize;

   // 256 is Not enough for CJK fonts
   // MAX_NUM_CHARS = 24200 for CJK fonts, updated 7-25-95
   if (IsDBCSCharSet(lpFontDataRecord->CharSet))
      dwSize = SIZE_GLYPHDATA_CJK;
   else
      dwSize = SIZE_GLYPHDATA_US;

   lpFontDataRecord->GlyphData = (LPWORD)GlobalAllocPtr(GHND, dwSize);

   if (!lpFontDataRecord->GlyphData)
       rc = PS_ALLOC_FAILED;

   lppd->DLState = DL_NOTHING;
   //  tell the world you just created a new buffer!
   lppd->lpFontDataList->GlyphData = lpFontDataRecord->GlyphData ;

   // Allocate GlyphIndex Table
   lpFontDataRecord->lpGITable = (LPGITABLE)GlobalAllocPtr(GHND, sizeof(GITABLE) );
   if (!lpFontDataRecord->lpGITable)
       rc = PS_ALLOC_FAILED;
   else {
      lpFontDataRecord->isMylpGITable = 1;  // remember it is allocated by me.
      lpFontDataRecord->lpGITable->n = 0;
      // 32K is Not enough to hold MAX_NUM_CHARS Word. All CJK fonts have <MAX_NUM_CHARS chars.
      // MAX_NUM_CHARS = 24200 for CJK fonts, updated 7-25-95
      // lpwGI is no longer used for DBCS CID fonts, so only allocate 256 WORD, 4-11-1996,
      lpFontDataRecord->lpGITable->lpwGI = (LPWORD)GlobalAllocPtr(GHND, (DWORD)(256*2));
      if (!lpFontDataRecord->lpGITable->lpwGI)    // check return value.
          rc = PS_ALLOC_FAILED;
     }

   return rc;
}

/***************************************************************************
 *
 *                          TTLockFont
 *    Function:
 *
 *
 *    Called:  LPWORD FAR PASCAL TTLockFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
 *                                        LPFONTDATARECORD lpFontData)
 *
 *    Parameters:  LPPDEVICE        lppd
 *                 LPPSFONTINFO       FontInfo
 *                 LPFONTDATARECORD lpFontData
 *
 *    Returns:
 *
 ***************************************************************************/

LPWORD FAR PASCAL TTLockFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                     LPFONTDATARECORD lpFontData)
{
   LPTTFONTINFO lpttfi;

   int iDLFontFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;
   // For all iDLFontFormat, we lock the same data, so we (ADOBE_DRIVER)
   // don't have to do IsType42Able() check here !! - save time.

   lpttfi = (LPTTFONTINFO) ((LPSTR)FontInfo + FontInfo->dfBitsOffset);
   lpttfi->prgfGlyphDown = lpFontData->GlyphData;

   return lpFontData->GlyphData;             // 0 if Type42
}

/***************************************************************************
 *
 *                          TTUnlockFont
 *    Function:
 *
 *    Called:  void FAR PASCAL TTUnlockFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPFONTDATARECORD lpFontData)
 *
 *    Parameters:   LPPDEVICE        lppd
 *                  LPPSFONTINFO       FontInfo
 *                  LPFONTDATARECORD lpFontData
 *
 *    Returns:
 *
 ***************************************************************************/

void FAR PASCAL TTUnlockFont( LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                LPFONTDATARECORD lpFontData)
{
   ;  // nothing!
}

/***************************************************************************
 *
 *                          TTGetBaseFont
 *    Function:
 *
 *
 *    Called:  void FAR PASCAL TTGetBaseFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPFONTDATARECORD lpFontData)
 *
 *
 *    Parameters:   LPPDEVICE        lppd
 *                  LPPSFONTINFO       FontInfo
 *                  LPFONTDATARECORD lpFontData
 *
 *    Returns:
 *
 ***************************************************************************/
LPPSFONTINFO FAR PASCAL TTGetBaseFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                  LPFONTDATARECORD lpFontData)
{
   LPTTFONTINFO lpttfi;
   LPPSFONTINFO lpXFontInfo  = NULL;  // points to initRef

   lpttfi = (LPTTFONTINFO)((LPSTR)FontInfo + FontInfo->dfBitsOffset);
   if (!lpttfi->dwXFontInfo && lpttfi->wXFontInfoSize)
   {
      initRefEMfont(lppd, FontInfo) ;
   }
   if (lpttfi->dwXFontInfo)
      lpXFontInfo = (LPPSFONTINFO)BUMPFAR (FontInfo, lpttfi->dwXFontInfo) ;

   return lpXFontInfo;
}
 /***************************************************************************
 *
 *                          GetResourceData
 *
 *    Function:  Find and load a resource identified by sProcID.
 *               returns a LOCKED pointer to data
 *               stuffs the handle of the resource in *lphData (for future referance)
 *
 *    Called:  LPSTR FAR PASCAL GetResourceData(LPPDEVICE lppd, LPHANDLE lphData, short sProcID)
 *
 *    Parameters:  LPPDEVICE lppd
 *                 LPHANDLE  lphData
 *                 short     sProcID
 *
 *    Returns:  NULL if resource not found or some other error has occurred
 *
 ***************************************************************************/

LPSTR FAR PASCAL GetResourceData(LPPDEVICE lppd, LPHANDLE lphData, short sProcID)
{
   HANDLE hInfo;
   LPSTR lpData = NULL;

   if (hInfo = FindResource(  ghDriverMod, (LPSTR)((LONG)sProcID),
                (LPSTR)((LONG)PS_proc)))
   {
     if (*lphData = LoadResource(ghDriverMod, hInfo) )
     {
       if (!(lpData = LockResource(*lphData)))
       {
         FreeResource(*lphData);
       }
     }
   }
   return lpData;
}

/***************************************************************************
 *
 *                          UnGetResourceData
 *
 *    Function:   Unlocks and frees resource referanced by hData
 *
 *    Called:  BOOL FAR PASCAL UnGetResourceData(hData)
 *
 *    Parameters:  HANDLE hData   Handle to data to be unlocked
 *
 *    Returns: BOOL, True - if successful, False - otherwise
 *
 ***************************************************************************/
#undef GlobalUnlock
BOOL FAR PASCAL UnGetResourceData( HANDLE hData)
{
   UnlockResource(hData);   // This is actually a GlobalUnlock()

   // remember backwards logic on FreeResource()
   return(!FreeResource(hData));
}
#define GlobalUnlock(h)

#pragma optimize("e", on) // Turn the optimization back on


/***************************************************************************
*
*                          PSSendFixedAscii7
*    Function:
*
*    Called:  short FAR PASCAL PSSendFixedAscii7(LPPDEVICE lppd, long FixedNum)
*
*    Parameters:  LPPDEVICE     lppd
*                 long          FixedNum)
*
*    Returns:
*
***************************************************************************/

short FAR PASCAL PSSendFixedAscii7(LPPDEVICE lppd, long FixedNum)
{
   char zTemp[12];
   short sLen;
   short far *NumPtr;

   NumPtr = (short far *)&FixedNum;

   if (FixedNum < 0)
   {
     PortWrite(lppd,(LP)"-",1);
     FixedNum = -FixedNum;
   }

   sLen = wsprintf((LPSTR)zTemp,(LPSTR)"%d", *(NumPtr+1) );
   PortWrite(lppd, (LPSTR)zTemp, sLen);
   PortWrite(lppd,(LP)".",1);
   sLen = wsprintf((LPSTR)zTemp,(LPSTR)"0 ");
   PortWrite(lppd,(LPSTR)zTemp,sLen);

   return(RC_ok);
}


/* Remove FontSubstitutes trailing stuff:
*  Win.INI's  [FontSubstitutes] has
*  Arial Cyr,204=Arial,204
*  Then remove Cyr from the FontName
*
*  This function will change the passed-in buffer lpFontName:
*/
VOID FAR PASCAL FixWinSubsFontName(LPSTR lpFontName, int lfCharSet)
{
char section[] ="FontSubstitutes";
char entry[128];
char def[2], tmp[128], *p;

  wsprintf((LPSTR)entry, "%s,%d", lpFontName, lfCharSet);
  def[0]='\0'; tmp[0]='\0';
  if (GetProfileString((LPSTR)section, entry, (LPSTR)def, (LPSTR)tmp, sizeof(tmp)))
    {
     p = lstrrchr(tmp, ',');
     if (p) *p = '\0';
     lstrcpy(lpFontName, tmp);
    }

}


/***************************************************************************
*
*                          PSSendOrigFont
*    Function:
*
*    Called:  VOID FAR PASCAL PSSendOrigFont(LPPDEVICElppd,
*                               LPPSFONTINFO,
*                               LPFONTDATARECORD);
*
*    Parameters:  LPPDEVICE         lppd
*                 LPPSFONTINFO      FontInfo
*                 LPFONTDATARECORD  FontData
*    Returns:
*
***************************************************************************/

VOID FAR PASCAL PSSendOrigFont(LPPDEVICE lppd , LPPSFONTINFO FontInfo,
            LPFONTDATARECORD FontData)
{
   LPFONTEXTRA FontExtra = (LPFONTEXTRA)BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO)((LPSTR)FontInfo+FontInfo->dfBitsOffset);
   LPASCIIBINPTRS tempptr;
   char  FontName[128];
   int ulpos;
   int ulwidth;
   int yScale;
   int EM;
   FONTDATARECORD tmpFontData;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;


/* Add two values UnderlinePosition and UnderlineThickness to fix mad
 * PageMaker 5 bugs: It tries to get these values if FontInfo dict is present
 * 10-26-1995, PPeng.
 * These two numbers are not sent anymore because PM 5/6 nad QuarkExpress have trouble
 * with the numbers. These numbers look like in GDI's unit, but not sure. One example is
 *  ULPos=202 and Thickness=11 (in 800dpi) but a PS font has -100 and 56 resp. 12-4-95
**/


   if (FontInfo->dfType & TYPE_TRUETYPE)
     {
      PSSCALABLEFONTINFO FAR *lpScaFnt = (PSSCALABLEFONTINFO FAR *)FontInfo;
     ulpos = lpScaFnt->erUnderlinePos;     // already pre-scaled' GDI units!
     ulwidth = lpScaFnt->erUnderlineThick; // already pre-scaled' GDI units!
    }
   else
    {
   LPETM etm = (LPETM) BUMPFAR (FontInfo, FontExtra->dwExtTextMetrics);
     EM = etm->etmMasterUnits;
     yScale = FontExtra->sPSyScale;
      ulpos = Scale(etm->etmUnderlineOffset,yScale,EM);
     ulpos = ulpos + FontInfo->dfAscent;
     ulwidth = Scale(etm->etmUnderlineWidth ,yScale,EM);
    }

   // Send these underline values for PageMaker's enjoyment:
/*
removed from the PS Stream: 12-4-95, PPeng.
    (*tempptr->PSSendShort)(lppd, (int)ulpos);
     (*tempptr->PSSendShort)(lppd, (int)ulwidth);
*/


/*  10-19-1995
5) The hints are:
   a) /OrigFontName (lfFaceName string; spaces OK;
   FontSubstitutes trailing stuff removed; use es
cape for problematic characters don't hex the string)
   b) /OrigFontStyle () (Bold) (Italic) (BoldItalic) based on lfWeight and lfItalic.
   c) /OrigFontType /TrueType -- this allows future reconsideration of /Type1.
   d) /WinCharSet lfCharSet.
   e) /WinPitchAndFamily lfPitchAndFamily
*/

   lstrcpy((LPSTR) FontName, FontData->FontName  );
   if (FontInfo->dfType & TYPE_TRUETYPE)
   {
      lstrcpy((LPSTR) FontName, lpTTFontInfo->lfCopy.lfFaceName);
   }

   // Remove FontSubstitutes trailing stuff
   FixWinSubsFontName(FontName, (int)FontInfo->dfCharSet);

   PSSendString(lppd,SPACE);
   PSSendFragment(lppd,PSFRAG_openbracket);
   PSSendString(lppd, FontName);
   PSSendFragment(lppd,PSFRAG_closebracket);

  // Borrow FontName to send FontStyle - "", "Bold", "Italic" or "BoldItalic"
   FontName[0] = '\0';  // initialize to ""
   if (FontInfo->dfType & TYPE_TRUETYPE)
   {
      CheckDLType(lppd,&(lpTTFontInfo->lfCopy), FontInfo, &tmpFontData);
      switch (FontData->fontDLType)
      {
       case CC_42:
       case GI_42:
       case CC_CID:
       case GI_CID:
       case CC_T042:
       case GI_T042:
       case CC_1:
       case CC_T01:
       case GI_1:
       case GI_T01:
          if( ((lpTTFontInfo->lfCopy.lfWeight>=700)||(FontInfo->dfWeight>=700))
              && !tmpFontData.BoldFake )
          {
              lstrcat((LPSTR) FontName,"Bold");
          }
          if( (lpTTFontInfo->lfCopy.lfItalic || FontInfo->dfItalic)
               && !tmpFontData.ItalicFake  )
          {
             lstrcat((LPSTR) FontName,"Italic");
          }
          break;

       case CC_3:
       case CC_32:
       case CC_T03:
       case CC_T032:
       case GI_3:
       case GI_32:
       case GI_T03:
       case GI_T032:
          if( ( lpTTFontInfo->lfCopy.lfWeight>=700 ) ||
              ( FontInfo->dfWeight>=700 ) ||
              FontData->BoldFake )
          {
              lstrcat((LPSTR) FontName,"Bold");
          }
          if( lpTTFontInfo->lfCopy.lfItalic ||
              FontInfo->dfItalic ||
              FontData->ItalicFake  )
          {
             lstrcat((LPSTR) FontName,"Italic");
          }


      }//end switch

   }else
   {
   if( FontData->BoldFake )
   {
       lstrcat((LPSTR) FontName,"Bold");
   }
   if( FontData->ItalicFake  )
   {
       lstrcat((LPSTR) FontName,"Italic");
   }
   }

   PSSendString(lppd,SPACE);
   PSSendFragment(lppd,PSFRAG_openbracket);
   PSSendString(lppd, FontName);   // Actually it is Style
   PSSendFragment(lppd,PSFRAG_closebracket);

   PSSendString(lppd,SPACE);
   if (FontInfo->dfType & TYPE_TRUETYPE)
   {
       PSSendString(lppd,"/TrueType ");
   }else
   {
       PSSendString(lppd,"/Type1 ");
   }

   // Send the lfCharSet value:
   (*tempptr->PSSendShort)(lppd, (int)FontInfo->dfCharSet);    // lfCharSet

   // Send the lfPitchAndFamily value:
   if (FontInfo->dfType & TYPE_TRUETYPE){
      (*tempptr->PSSendShort)(lppd, (int)lpTTFontInfo->lfCopy.lfPitchAndFamily);
      }
   else{
      // This is probably NOT right - because Microsoft messed up dfPitchAndFamily
      // and lfPitchAndFamily's defs in Win3 SDK. But currently we don't send this for PS Fonts.
      (*tempptr->PSSendShort)(lppd, (int)FontInfo->dfPitchAndFamily);
      }

   // Send flag wheter to add these entries or not. DON"T add them if Glyph-index
   if (FontInfo->dfType & PF_GLYPH_INDEX)
      (*tempptr->PSSendBoolean)(lppd, FALSE);
   else
      (*tempptr->PSSendBoolean)(lppd, TRUE);

}


///////////////////////////////////////////////////////////////////////////
///// Functions to Improve PS side performance for GlyphIndex downloading.
///// A font MSTT31abcd corresponds an array of WORD GIAssigned
///// Which is used to minmize the number of fonts used for Speed mode.
///// Currently, this is for Speed Mode Only..Unless we change the MSTT31abcd
///// based on VM recovery - otherwise service bearua will be upset.!!!!!!! 9-22-1995
///////////////////////////////////////////////////////////////////////////

PSERROR FAR PASCAL AllocGIAssigned(LPPDEVICE lppd, LPSTR lpFontName, LPGIASSIGNED lpGAS)
{
   PSERROR rc = PS_SUCCESS;
   LPGIASSIGNED lpTmpGas;

   if (CheckGIAssignedRecord(lppd, lpFontName, &lpTmpGas))
      return rc; // already there, don't allocate again.

   lstrcpy(lpGAS->FontName, lpFontName);
   lpGAS->NextFID= 0;
   lpGAS->NextCH = 1;    // Char ID starts from 1 for 1st font - so lpGI2F[gi]!=0 for all gi!

   lpGAS->dwSize1 = 16;  // start frm 16 for 32K+ glyph-index, must be non-zero for later reallocation
   lpGAS->lpGI2F1 = (LPWORD)GlobalAllocPtr(GHND, 2+(LONG)(lpGAS->dwSize1)*sizeof(WORD));
   if (lppd->fDBCS & DBCS_FONT) lpGAS->dwSize = 12000;  // Satrt 12K GIs for CJK- may re-allocate;
   else
      lpGAS->dwSize = 512;  // start with 512 GIs - my reallocate

   lpGAS->lpGI2F = (LPWORD)GlobalAllocPtr(GHND, 2+(LONG)(lpGAS->dwSize)*sizeof(WORD));
   lpGAS->lpF2GI = (LPWORD)GlobalAllocPtr(GHND, 2+(LONG)(lpGAS->dwSize)*sizeof(WORD));
   if (!lpGAS->lpGI2F || !lpGAS->lpF2GI || !lpGAS->lpGI2F1)   // check return value.
       rc = PS_ALLOC_FAILED;

   return rc;
}

VOID FAR PASCAL FreeGIAssigned(LPPDEVICE lppd, LPGIASSIGNED lpGAS)
{
   if (lpGAS->lpGI2F)    // 293130
       GlobalFreePtr(lpGAS->lpGI2F);
   if (lpGAS->lpF2GI)    // 293130
       GlobalFreePtr(lpGAS->lpF2GI);
   lpGAS->lpGI2F = NULL;
   lpGAS->lpF2GI = NULL;
   if (lpGAS->lpGI2F1)    // 293130
       GlobalFreePtr(lpGAS->lpGI2F1);
   lpGAS->lpGI2F1 = NULL;
   lpGAS->FontName[0]='\0';  // won't find this one again.
}


BOOL FAR PASCAL AddGIAssignedRecord(LPPDEVICE lppd, LPGIASSIGNED lpGAS)
{
   LPGIASSIGNED currentrec;
   BOOL retval;
   retval = FALSE;
   if (!lppd->lpGASList) return retval; // called too early- before AllocTransLayerData().
   if (lppd->lpGASList->GASNextRecord >= MAXFONTDATARECORDS){
      // The reserved space is used up. It's time to recycle:
      // Reset the GAS List
      LPGIASSIGNED  gas;
      int dex;
      dex = (lppd->lpGASList->GASNextRecord - 1);
      gas = lppd->lpGASList->GASList;
      gas += dex;
      while (dex >= 0)
   {  // we may choose to free upto a number other than 0. PPeng, 9-27-95
    FreeGIAssigned(lppd, gas);
    gas --;
    dex --;
   }
      lppd->lpGASList->GASNextRecord = dex + 1;
   }

   if (lppd->lpGASList->GASNextRecord < MAXFONTDATARECORDS)
   {  // this must be true after above recycle.
     currentrec = lppd->lpGASList->GASList;
     currentrec += lppd->lpGASList->GASNextRecord;
     lpGAS->StackLevel = lppd->lpProcsetstuff->savelevel;
     *currentrec = *lpGAS;
     lppd->lpGASList->GASNextRecord++;
     retval = TRUE;
   }
   return(retval);
}


int FAR PASCAL CheckGIAssignedRecord(LPPDEVICE lppd, LPSTR lpFontName, LPGIASSIGNED *lpMatchGA)
{
   LPGIASSIGNED currentptr;
   int retval, dex;

   retval = 0;
   if (!lppd->lpGASList) return retval; // called too early- before AllocTransLayerData().
   currentptr = lppd->lpGASList->GASList;
   dex = 0;
   while ( (dex < lppd->lpGASList->GASNextRecord) )
   {
   if (lstrcmpi(currentptr->FontName, lpFontName) == 0)
       {
      retval = 1;
      *lpMatchGA = currentptr;            // Pass the pointer back as Matched record
      break; // not necessary to search any more
       }
    // Go to next record
    currentptr ++ ;
    dex ++;
  } // while (...)
   return(retval);
}


// From Assignement ID to GI - when we need the real Glyph-index
// For a show-order x, the gi is always lpF2GI[x]
WORD FAR PASCAL GetGIFromAssignmentID(LPGIASSIGNED lpGAS, WORD asi)
{
    return (lpGAS->lpF2GI[asi]);
}


// From GI to Show-order-index- when we need the new show-order-index
// GI gi's show-order is in lpGI2F[gi] or lpGI2F1[gi-32K]
WORD FAR PASCAL GetAssignmentIDFromGI(LPGIASSIGNED lpGAS, WORD gi)
{
     if (gi > LIMIT_32K){
   return (lpGAS->lpGI2F1[gi-LIMIT_32K]);
     }
     else
   return (lpGAS->lpGI2F[gi]);
}


VOID FAR PASCAL AssignGIStr(LPGIASSIGNED lpGAS, LPWORD lpgi, int count)
{
int i;
WORD gi;
DWORD dwTmp;
WORD  newgi;

  for (i=0; i<count; i++){
     gi = *(lpgi+i);

     if (gi > LIMIT_32K){
 #ifdef PS_DEBUG
   MessageBox(NULL, "Glyph index over 32K", "I gottya!", MB_OK);
 #endif
   newgi = (WORD)((LONG)gi - LIMIT_32K);
   if (newgi >= lpGAS->dwSize1){
      dwTmp = lpGAS->dwSize1 + (lpGAS->dwSize1)/2;
      dwTmp = max(dwTmp, newgi+10);  // New size is 1.5 of old or 10 bigger than gi
      if (dwTmp > LIMIT_32K) dwTmp = LIMIT_32K;  //not to over-increase here.
      lpGAS->dwSize1 = dwTmp;
      GlobalReAllocPtr(lpGAS->lpGI2F1, 2+(LONG)(lpGAS->dwSize1)*sizeof(WORD), GMEM_ZEROINIT);
      }
    if (lpGAS->lpGI2F1[newgi]) continue;   // already assigned a FID and a ch id
    dwTmp = MAKEWORD(lpGAS->NextCH, lpGAS->NextFID);  // fid is HiByte
    lpGAS->lpGI2F1[newgi] = (WORD)dwTmp;  // this cust is safe - we will never have more than 255 fonts based on show-order!!.
    lpGAS->lpF2GI[dwTmp] = gi;  // this is GI, not newGI !!!
   }
     else
   {   // gi is less than 32K
   if (gi >= lpGAS->dwSize){
      dwTmp = lpGAS->dwSize + (lpGAS->dwSize)/2;
      dwTmp = max(dwTmp, gi+10);  // New size is 1.5 of old or 10 bigger than gi
      if (dwTmp > LIMIT_32K) dwTmp = LIMIT_32K;  //not to over-increase here.
      lpGAS->dwSize = dwTmp;
      GlobalReAllocPtr(lpGAS->lpGI2F, 2+(LONG)(lpGAS->dwSize)*sizeof(WORD), GMEM_ZEROINIT);
      GlobalReAllocPtr(lpGAS->lpF2GI, 2+(LONG)(lpGAS->dwSize)*sizeof(WORD), GMEM_ZEROINIT);
      }
   if (lpGAS->lpGI2F[gi]) continue;   // already assigned a FID and a ch id
   dwTmp = MAKEWORD(lpGAS->NextCH, lpGAS->NextFID);  // fid is HiByte
   lpGAS->lpGI2F[gi] = (WORD)dwTmp; // this cust is safe - we will never have more than 255 fonts based on show-order!!.
   lpGAS->lpF2GI[dwTmp] = gi;
   }

     lpGAS->NextCH++;  // prepare for next char
     if (lpGAS->NextCH>255){
   // advance to the next font
   lpGAS->NextFID++;
   lpGAS->NextCH=1;   // ch id starts from 1 for all fonts - so lstrlen() still works.
       }
    }
}

// From GI str to Assignment id Str -Show-Order-Index str. First Add/Create GIASSignment record
BOOL FAR PASCAL GetGIAssignmentStr(LPPDEVICE lppd, LPSTR lpFontName, LPWORD lpgi, LPWORD lpwNew, int count)
{
  GIASSIGNED  Gas;
  LPGIASSIGNED lpGas;
  int i;

    if (CheckGIAssignedRecord(lppd, lpFontName, &lpGas)==0){  // not found
        // alloc a new one
        if (AllocGIAssigned(lppd, lpFontName, (LPGIASSIGNED) &Gas) == PS_ALLOC_FAILED)
        {
            FreeGIAssigned(lppd, (LPGIASSIGNED) &Gas);
            return FALSE;    // 293130  jjia
        }
   AddGIAssignedRecord(lppd, (LPGIASSIGNED) &Gas);  // Copy GAs to the GASList
   if (CheckGIAssignedRecord(lppd, lpFontName, &lpGas)==0){
       FreeGIAssigned(lppd, (LPGIASSIGNED) &Gas);
       return FALSE; // failed for adding GAS
       }
   }
    AssignGIStr(lpGas, (LPWORD)lpgi, count);   // assign Show-Order-index for lpgi
    for (i=0;i<count; i++){
       //wcc If > 32K, use lpGI2F1
       if (*lpgi > LIMIT_32K)
         *lpwNew = (lpGas->lpGI2F1[*lpgi - LIMIT_32K]);
       else
         *lpwNew = (lpGas->lpGI2F[*lpgi]);
       lpgi++; lpwNew++;
      }
    return TRUE;  // success
}
///////// End of Speed Glyph-index - ShowOrder Index Code
///////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
////// Functions to support Downloading TT as Composite Fonts -
////// T0/T1, T0/T3, T0/T42, T0/CID is in TTfonts.c - share PS stream with T0/42.
/////////////////////////////////////////////////////////////////////////////////
#ifdef T3OUTLINE
PSERROR NEAR PASCAL TTDownLoadT1OutlineFontExt(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                     LPFONTDATARECORD lpFontData, BOOL bFullFont, LPSTR lpCopyFrom,
                     BOOL bCopy)
#else
PSERROR NEAR PASCAL TTDownLoadT1FontExt(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                     LPFONTDATARECORD lpFontData, BOOL bFullFont, LPSTR lpCopyFrom,
                     BOOL bCopy)
#endif
{
LPTTFONTINFO    lpttfi;
PSERROR         rc = PS_SUCCESS;

    // If this is Not Copy. Call TTDownloadT1Font() Function as before
    // We can only copy Hdr. So if full downloading still use old function
    if (!bCopy || bFullFont)
    {
#ifdef T3OUTLINE
        if (bTTtoT3OL)        // bugbug!!!     Need UI change
        {
            rc= TTDownLoadT3OutlineFont(lppd, FontInfo, lpFontData, bFullFont, MAX_NUM_CHARS_US);
        }
        else
        {
            rc= TTDownLoadT1OutlineFont(lppd, FontInfo, lpFontData, bFullFont, MAX_NUM_CHARS_US);
        }
#else
        rc= TTDownLoadT1Font(lppd, FontInfo, lpFontData, bFullFont, MAX_NUM_CHARS_US);
        /* Force the font be created */
        TTUpdateT1Font(lppd, FontInfo, lpFontData, " ", 1);

#endif
        return rc;
    }
    else
    {
        // Copy the font header ....
        LPSUBFONT43 pSubFontFrom = lpFontData->pSubFont;
        LPSUBFONT43 pSubFontTo = (LPSUBFONT43) GlobalAllocPtr(GHND, sizeof(SUBFONT43));
        
        if (!pSubFontTo)
            return PS_ALLOC_FAILED;

        lpttfi = (LPTTFONTINFO) ((LPSTR)FontInfo + FontInfo->dfBitsOffset);
        lstrcpy(pSubFontTo->strPSName, (LPSTR)lpttfi->PSName);

        pSubFontTo->lppd = (LPVOID)lppd;
        pSubFontTo->FontInfo = (LPVOID) FontInfo;
        pSubFontTo->bFullFont = bFullFont;
        pSubFontTo->pufo = (LPVOID) NULL;
        pSubFontTo->iUFLDLFormat = DLFONT_TYPE1;

        if (BCopyFont(lppd, pSubFontFrom, pSubFontTo, DLFONT_TYPE1) )
        {
            while(pSubFontFrom->pNext) 
                pSubFontFrom = pSubFontFrom->pNext;
            pSubFontFrom->pNext = pSubFontTo;
        }
        else
        {
            // Failed, free the pointer:
            GlobalFreePtr(pSubFontTo);
        }

        VMUsed(lppd, VM_TTT1_HEADER, 0);
        return rc;
    }
}


PSERROR NEAR PASCAL TTDownLoadT3FontExt(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                     LPFONTDATARECORD lpFontData, BOOL bFullFont, LPSTR lpCopyFrom,
                     BOOL bCopy)

{
LPTTFONTINFO     lpttfi;
PSERROR rc = PS_SUCCESS;

    // If this is Not Copy. Call TTDownloadT3Font() Function as before
    // We can only copy Hdr. So if full downloading still use old function
    if (!bCopy || bFullFont)
    {
        rc= TTDownLoadT3Font(lppd, FontInfo, lpFontData, bFullFont, MAX_NUM_CHARS_US);
        return rc;
    }
    else
    {
        // Copy the font header ....
        LPSUBFONT43 pSubFontFrom = lpFontData->pSubFont;
        LPSUBFONT43 pSubFontTo = (LPSUBFONT43) GlobalAllocPtr(GHND, sizeof(SUBFONT43));

        if (!pSubFontTo)
            return PS_ALLOC_FAILED;

        lpttfi = (LPTTFONTINFO) ((LPSTR)FontInfo + FontInfo->dfBitsOffset);;
        lstrcpy(pSubFontTo->strPSName, (LPSTR)lpttfi->PSName);

        pSubFontTo->lppd = (LPVOID)lppd;
        pSubFontTo->FontInfo = (LPVOID) FontInfo;
        pSubFontTo->bFullFont = bFullFont;
        pSubFontTo->pufo = (LPVOID) NULL;
        pSubFontTo->iUFLDLFormat = DLFONT_TYPE3;

        if (BCopyFont(lppd, pSubFontFrom, pSubFontTo, DLFONT_TYPE3) )
        {
            while(pSubFontFrom->pNext) 
                pSubFontFrom = pSubFontFrom->pNext;
            pSubFontFrom->pNext = pSubFontTo;
        }
        else
        {
            // Failed, free the pointer:
            GlobalFreePtr(pSubFontTo);
        }

        VMUsed(lppd, VM_TTT3_HEADER, 0);
        return rc;
   }  // else bCopy
}


// A short hand to download T1 or T3 font. This one differs from
// TTDownloadFont() in that AllocGlyphData() is not called - because it is
// Allocated for the parent and all children shares it. This is also the reason
// We cannot call TTDownloadFont() within TTDownloadT0Font() . 8-22-95, PPeng
PSERROR FAR PASCAL TTDownLoadChildFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                     BOOL bFullFont, LPFONTDATARECORD lpFontDataRecord, LPSTR lpBaseName,
                     BOOL bCopy)
{
PSERROR rc = PS_SUCCESS;                // return value of function
int iDLFontFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;
LPTTFONTINFO     lpttfi = (LPTTFONTINFO) ((LPSTR)FontInfo + FontInfo->dfBitsOffset);

    // If not type42 able, then switch to Type 1,
    // We need re-check here after FontDown is able to Download FE fonts *****
//    if ((iDLFontFormat == TT_DLFORMAT_TYPE42 ) && 
//        !(lpttfi->dwProperties & TTFI_IS_TYPE42ABLE)
//       )
//        iDLFontFormat = TT_DLFORMAT_TYPE1;
    iDLFontFormat = lpttfi->iDLFontFormat;

    TTLockFont(lppd, FontInfo, lpFontDataRecord);

    //Currentlly only T0-1/3 are used. For Type 42, Type 32, ... Please add here !!
    switch (iDLFontFormat)
    {
    case TT_DLFORMAT_TYPE1:
    case TT_DLFORMAT_TYPE3:
        if (FontInfo->dfType & TYPE_OUTLINE)
        { // real Type1
#ifdef T3OUTLINE
            if (bTTtoT3OL)    // bugbug !!! need UI change
            {
                rc = TTDownLoadT3OutlineFontExt(lppd, FontInfo, lpFontDataRecord, bFullFont,lpBaseName,bCopy);
            }
            else
            {
                rc = TTDownLoadT1OutlineFontExt(lppd, FontInfo, lpFontDataRecord, bFullFont,lpBaseName,bCopy);
            }
#else
            rc = TTDownLoadT1FontExt(lppd, FontInfo, lpFontDataRecord, bFullFont,lpBaseName,bCopy);
#endif
        }
        else
        {
            rc = TTDownLoadT3FontExt(lppd, FontInfo, lpFontDataRecord, bFullFont,lpBaseName,bCopy);
        }
        break;

        case TT_DLFORMAT_TYPE42:
            // We should not see this case now.
#if PSDEBUG
MessageBox(NULL, "Error!!", "How can you get to this point - OCF/T42 child", MB_OK);
#endif
//                 rc = TTDownLoadT42FontExt(lppd, FontInfo, lpFontDataRecord, bFullFont,lpBaseName,bCopy);
        break;

      case TT_DLFORMAT_TRUEIMAGE:
      break;

      case TT_DLFORMAT_NONE:
      break;
   }

   TTUnlockFont(lppd, FontInfo, lpFontDataRecord);

   return rc;
}


/***************************************************************************
 *
 *                          TTDownloadT0Font
 *
 *    Function:  Routine to download a TrueType font as Type 0 Font.
 *               FontInfo points to
 *               the physical font created by TTRealizeFont().  bFullFont
 *               takes on the following meaning:
 *
 *               TRUE   download font header and all characters
 *               FALSE  download font header only
 *
 *               After doing some common housekeeping the code calls the Type 1
 *               or Type 3 font generator as appropriate.  The decision is
 *               determined in TTRealizeFont() and reflected in the TYPE_OUTLINE
 *               bit of FontInfo->dfType.
 *
 *    Called:    int FAR PASCAL TTDownLoadT0Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
 *                           BOOL bFullFont, LPFONTDATARECORD lpFontDataRecord)
 *
 *    Parameters:  LPPDEVICE lppd
 *                 LPPSFONTINFO FontInfo
 *                 BOOL bFullFont
 *                 LPFONTDATARECORD lpFontDataRecord
 *
 *    Returns:    PSERROR
 *NOTE!!!!!!!! This is for Downloading T0/1, T0/3 and Build T0/42 struct only.
 *    !!!!!!!! T0/42 shares code with T0/CID in ttfonts.c
 ***************************************************************************/

PSERROR FAR PASCAL TTDownLoadT0Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                     BOOL bFullFont, LPFONTDATARECORD lpFontDataRecord)
{
LPBYTE  lpFontName;
int     i, j, k, fontDLType, childType, fontNameLen;
char    tmpbuf[256], smlbuf[10], FirstFontName[50];
BOOL    bCopy = FALSE;
int     Subs[258], Enc0[258];
PSERROR rc = PS_SUCCESS;                // return value of function
LPDBCSENCODE   lpEncoding;
LPTTFONTINFO   lpTTFontInfo = (LPTTFONTINFO)((LPSTR)FontInfo+FontInfo->dfBitsOffset);
LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
DWORD   vmSize;
int     iDescendant=0;
int     vmR = FALSE;
BOOL    vmOff = FALSE;
BOOL    bEUDC =lppd->lpPSExtDevmode->dm2.bEUDCAble;
WORD    parentXUIDx = 0;

    lpEncoding = GetEncoding((int)FontInfo->dfCharSet, bEUDC);

    // Count number of Descendant fonts:
    // Single Byte fonts:
    iDescendant = 0;
    for (i=0; i<MAX_1STBRANGES; i++)
    {
        if (lpEncoding->Single[i].min==0 && lpEncoding->Single[i].max==0) 
            break;
        iDescendant++;
    }
    // Double Byte Fonts: 8/8 mapping
    for (i=0; i<MAX_1STBRANGES; i++)
    {
        if (lpEncoding->Double[i].min==0 && lpEncoding->Double[i].max==0) 
            break;
        iDescendant += 1+lpEncoding->Double[i].max - lpEncoding->Double[i].min;
    }

    // Update Number of Descendant fonts:
    lppd->lpFontDataList->iDefinedFonts[lppd->lpProcsetstuff->savelevel] += iDescendant;

    vmSize = (DWORD)iDescendant;
    // The VM? values are inflated somehow. One test case shows that
    // VM? 3456000 actually only uses 1420K - (128 T3 Headers).1420/3456 =0.4108.. USE 0.45
    // VM? 2304000 only uses 733800 (128 T1 font headers). 734/2304=0.3185..       USE 0.35
    // VM? 2304000 only uses 730000 (128 T42 font headers). 730/2304=0.3165..      USE 0.35
    // The inflation is about 200%. So we need this wired deflation factor
    // After this deflation, I can print a Chinese Docment on a LJ4 with 2 MB memory

    if (!bFullFont) 
    { // Incremental Downloading
        if (lpFontDataRecord->fontDLType == CC_T01)
        {
            /* T0/T1 header defines 120+ descendant fonts, but
               they shared the same CharStrings dict, only thing not shared is
               the encoding - 255*4 bytes */
                vmSize = (DWORD) iDescendant;
            vmR = VMCheck(lppd, VM_TTT01_HEADER, vmSize);
            VMUsed(lppd, VM_TTT01_HEADER, vmSize);
        }
        else if (lpFontDataRecord->fontDLType == CC_T03)
        {       
            vmSize = (DWORD) ((float)vmSize*0.45 + 0.5);
            vmR = VMCheck(lppd, VM_TTT03_HEADER, vmSize);
            VMUsed(lppd, VM_TTT03_HEADER, vmSize);
        }
        else
        {
           // Not T1 or T3. Must be T42. Add other cases here - T0/32...
           vmSize = (DWORD) ((float)vmSize*0.35 + 0.5);
           vmR = VMCheck(lppd, VM_TTT0CID_FONT, vmSize);
           VMUsed(lppd, VM_TTT0CID_FONT, vmSize);
        }
    }
    else 
    {   // Full Downloading.
        // Deflation:
        vmSize = (DWORD) ((float)vmSize*0.5);  // Good enough ??
        if (lpFontDataRecord->fontDLType == CC_T01)
        {
            vmSize = (DWORD)(FontInfo->dfLastChar - FontInfo->dfFirstChar + 1)*vmSize;
            vmR = VMCheck(lppd, VM_TTT1_FONT, vmSize);
            VMUsed(lppd, VM_TTT1_FONT, vmSize);
        }
        else if (lpFontDataRecord->fontDLType == CC_T03)
        {
            //Estimate size for T3.
            vmSize = BiToByAl(FontInfo->dfMaxWidth, 4) *vmSize;  // number of fonts.
            vmSize *= FontInfo->dfPixHeight;
            vmSize = (WORD)(FontInfo->dfLastChar - FontInfo->dfFirstChar + 1) * vmSize;
            if (FontInfo->dfPoints <= 10)
            {
                vmSize *= 2;
            }
            else if (FontInfo->dfPoints > 20)
            {
                vmSize /= 2;
            }
            vmR = VMCheck(lppd, VM_TTT3_FONT, vmSize);
            VMUsed(lppd, VM_TTT3_FONT, vmSize);
        }                              
        else
        {
            // Not T1 or T3. Must be T42. Add other cases here - T0/32...
            vmSize = (DWORD) ((float)vmSize*0.35 + 0.5);
            vmR = VMCheck(lppd, VM_TTT0CID_FONT, vmSize);
            VMUsed(lppd, VM_TTT0CID_FONT, vmSize);
        }
    }

    if (vmR)
    {
        // VMRecover was executed above, the iDefinedFonts[] is changed
        // so need to re-Update Number of Descendant fonts:
        lppd->lpFontDataList->iDefinedFonts[lppd->lpProcsetstuff->savelevel] += iDescendant;
    }

    // necessary VM recovery is done in above VMCheck().
    // VMUsed() is also called above. So, EstimateUsed will be up todate.
    // About 100 Small fonts are to be send, we cannot recover VM in the
    // middle of this task - because Parent's pointers are shared by children.
    // Disable VMRecovery first
    // The VmCheck is done for the Parent font, so we don't do it for
    // the Descendant fonts:
    if (lppd->doVMRecovery)
    {
        VMRecoverDisable(lppd);
        vmOff = TRUE;
    }

    VMDisable(lppd);

    // Change the DL Type first: need to call TTDownload() with correct DLType.
    fontDLType = lpFontDataRecord->fontDLType;
    if (lpFontDataRecord->fontDLType == CC_T01)
        childType = CC_1;
    else if (lpFontDataRecord->fontDLType == CC_T03)
        childType = CC_3;
    else  
        childType = CC_42;   // else Type 42. add elseif here for Type32...

    //save the xuid.x field.  See bug 174120 for xuid vector specification.
    parentXUIDx = lpFontDataRecord->xuidRec.x; 
    lpFontName = lpTTFontInfo->PSName; fontNameLen = 0;
    while(lpFontName && *lpFontName)
    {
        lpFontName++; 
        fontNameLen++ ;  // save old fontname
    }
    for (i=0; i<258; i++)
    { 
        Subs[i]=0; 
        Enc0[i]=0;
    }

    if (lpFontDataRecord->fontDLType == CC_T042)
    {
        lpFontName = &(lpTTFontInfo->PSName[fontNameLen]);
        AppNumToName3(lpFontName, 0);   //MSTT31abcd000 !!! "000" is hard coded here
        lstrcpy((LPSTR)FirstFontName, lpTTFontInfo->PSName);
        bCopy = TRUE;  // for T0/42, just copy ...
    }

    // First download all descendant fonts.
    // Single Byte fonts:
    for (i=0; i<MAX_1STBRANGES; i++)
    {
        if (lpEncoding->Single[i].min==0 && lpEncoding->Single[i].max==0) 
            break;
        Enc0[lpEncoding->Single[i].min] = 1;
        //  tack on HighByte as part of FontName.
        lpFontName = &(lpTTFontInfo->PSName[fontNameLen]);
        AppNumToName3(lpFontName, lpEncoding->Single[i].min);
        // download a  descendant font
        lpTTFontInfo->HighByte = (lpEncoding->Single[i].min)<<8 ;
        lpFontDataRecord->fontDLType = childType;
        // modified XUID accorind to index
        lpFontDataRecord->xuidRec.x = parentXUIDx + lpEncoding->Single[i].min;

        rc = TTDownLoadChildFont(lppd, FontInfo, bFullFont, lpFontDataRecord, FirstFontName, bCopy);

        if (!bCopy)
        {
            lstrcpy(FirstFontName, lpTTFontInfo->PSName);
            bCopy = TRUE;
        }

        if (rc!=PS_SUCCESS) goto DLT0_END;
    }

    // Double Byte Fonts: 8/8 mapping
    for (i=0; i<MAX_1STBRANGES; i++)
    {
        if (lpEncoding->Double[i].min==0 && lpEncoding->Double[i].max==0) 
            break;
        Enc0[lpEncoding->Double[i].min] = 2;
        Enc0[lpEncoding->Double[i].max] = 3;
        for (j=lpEncoding->Double[i].min; j<=lpEncoding->Double[i].max+1; j++)
        { 
            // one extra font
            //  tack on HighByte as part of FontName.
               lpFontName = &(lpTTFontInfo->PSName[fontNameLen]);
            AppNumToName2(lpFontName, j);   // add 2 chars
            // download a softfont, if necessary
            lpTTFontInfo->HighByte = j<<8 ;
            lpFontDataRecord->fontDLType = childType;
            lpFontDataRecord->xuidRec.x = parentXUIDx + j;

            rc = TTDownLoadChildFont(lppd, FontInfo, bFullFont, lpFontDataRecord, FirstFontName, bCopy);
           
            if (!bCopy)
            {
                lstrcpy(FirstFontName, lpTTFontInfo->PSName);
                bCopy = TRUE;
            }

            if (rc!=PS_SUCCESS) goto DLT0_END;
        }

        // Construct the decsendant T0 font: 8/8 mapping:
        lpFontName = &(lpTTFontInfo->PSName[fontNameLen]);
        AppNumToName5(lpFontName, (int)lpEncoding->Double[i].min, (int)lpEncoding->Double[i].max);   // add 5 chars

        wsprintf((LPSTR)tmpbuf, "%d /%s %d",
               0,  // PaintType
               lpTTFontInfo->PSName,
               ((lppd->fDBCS & DBCS_VERT)>0)?1:0  // Vertical=1 or not(0)
               );
        PSSendString(lppd, tmpbuf);
        (*tempptr->PSSendCRLF)( lppd );

        // FDepVector
        PSSendFragment(lppd, PSFRAG_leftbracket);
        for (j=lpEncoding->Double[i].min; j<=lpEncoding->Double[i].max+1; j++)
        { 
            // one extra font
            //  tack on HighByte as part of FontName.
            lpFontName = &(lpTTFontInfo->PSName[fontNameLen]);
            AppNumToName2(lpFontName, j);   // add 2 chars
            wsprintf((LPSTR)tmpbuf, "/%s findfont ", lpTTFontInfo->PSName );
            PSSendString(lppd, tmpbuf);
            if ((j-lpEncoding->Double[i].min+1)%3==0) (*tempptr->PSSendCRLF)( lppd );
        }
        PSSendFragment(lppd, PSFRAG_rightbracket);
        (*tempptr->PSSendCRLF)( lppd );

        // Encoding
        PSSendFragment(lppd, PSFRAG_leftbracket);
        for (j=lpEncoding->Double[i].min; j<=lpEncoding->Double[i].max; j++)
        { 
            // one extra font is implicit
            wsprintf((LPSTR)tmpbuf, "%d ", j-lpEncoding->Double[i].min);
            PSSendString(lppd, tmpbuf);
            if ((j-lpEncoding->Double[i].min+1)%16==0) (*tempptr->PSSendCRLF)( lppd );
        }
        PSSendFragment(lppd, PSFRAG_rightbracket);
        (*tempptr->PSSendCRLF)( lppd );

        // now send the origFontName/Style/Type/CharSet to make Distiller/Acrobat happy.
        PSSendOrigFont(lppd, FontInfo , lpFontDataRecord );
        wsprintf((LPSTR)tmpbuf, "Type02Hdr");
        PSSendString(lppd, tmpbuf);
        (*tempptr->PSSendCRLF)( lppd );
    }

    ///////////////////////// Finally...
    // Construct the required T0 Font: SubsVector mapping:
    lpFontName = lpTTFontInfo->PSName;
    lpFontName[fontNameLen]='\0';   // restore old fontname
    wsprintf((LPSTR)tmpbuf, "%d /%s %d",
               0,  // PaintType
               lpFontName,
               ((lppd->fDBCS & DBCS_VERT)>0)?1:0  // Vertical=1 or not(0)
               );
    PSSendString(lppd, tmpbuf);
    (*tempptr->PSSendCRLF)( lppd );

    // FDepVector
    k = 0; // count num of descendant font: used to construct Encoding vector
    PSSendFragment(lppd, PSFRAG_leftbracket);
    for (i=0; i<257; i++)
    { // one extra font
        if (Enc0[i] == 0) continue;
        
        if (Enc0[i] == 1)
        {
            Subs[k] = i;
            k++;
            lpFontName = &(lpTTFontInfo->PSName[fontNameLen]);
            AppNumToName3(lpFontName, i);
            wsprintf((LPSTR)tmpbuf, "/%s findfont ", lpTTFontInfo->PSName);
            PSSendString(lppd, tmpbuf);
            if (k%3==0) (*tempptr->PSSendCRLF)( lppd );
        }

        if(Enc0[i] == 2) 
        {
            Subs[k] = i;
            k++;
            j = i+1;  // dOUBLE BYTE RANGE  has at least two leading bytes !!.
            while (Enc0[j]==0) j++;  // actually till find 3.
            //  tack on i - j as part of FontName.
            lpFontName = &(lpTTFontInfo->PSName[fontNameLen]);
            AppNumToName5(lpFontName, i, j);   // add 5 chars
            wsprintf((LPSTR)tmpbuf, "/%s findfont ", lpTTFontInfo->PSName);
            PSSendString(lppd, tmpbuf);
            if (k%3==0) (*tempptr->PSSendCRLF)( lppd );
        }
    }
    PSSendFragment(lppd, PSFRAG_rightbracket);
    (*tempptr->PSSendCRLF)( lppd );

    // Encoding
    PSSendFragment(lppd, PSFRAG_leftbracket);
    for (j=0; j<k; j++)
    { 
        // one extra font is implicit
        wsprintf((LPSTR)tmpbuf, "%d ", j);
        PSSendString(lppd, tmpbuf);
        if ((j+1)%16==0) (*tempptr->PSSendCRLF)( lppd );
    }
    PSSendFragment(lppd, PSFRAG_rightbracket);
    (*tempptr->PSSendCRLF)( lppd );

    // SubsVector - IT is a String !! send in HEX format <...>
    PSSendFragment(lppd, PSFRAG_leftcaret);
    wsprintf((LPSTR)tmpbuf, "00");  // Number of bytes used to map =1
    for (j=1; j<k; j++)
    { 
        // one extra font is implicit
        wsprintf((LPSTR)smlbuf, "%2.2X", (int) Subs[j]-Subs[j-1]);
        lstrcat(tmpbuf, smlbuf);
    }
    PSSendString(lppd, tmpbuf);
    PSSendFragment(lppd, PSFRAG_rightcaret);
    (*tempptr->PSSendCRLF)( lppd );

    // now send the origFontName/Style/Type/CharSet to make Distiller/Acrobat happy.
    PSSendOrigFont(lppd, FontInfo , lpFontDataRecord );
    wsprintf((LPSTR)tmpbuf, "Type06Hdr");
    PSSendString(lppd, tmpbuf);
    (*tempptr->PSSendCRLF)( lppd );

DLT0_END:
    // Restore the saved fontDLType and Font name:
    lpFontDataRecord->fontDLType = fontDLType;
    lpFontDataRecord->xuidRec.x = parentXUIDx;
    lpTTFontInfo->PSName[fontNameLen]='\0';
    // Enable VMRecovery again
    VMEnable(lppd);
    if (vmOff) VMRecoverEnable(lppd);

    return (rc);
}


/***************************************************************************
 *
 *                             TTUpdateT0Font
 *    Function:
 *
 *    Called:  int FAR PASCAL TTUpdateT0Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPSTR lpStr, int cb, LPFONTDATARECORD lpFontDataRecord)
 *
 *    Parameters:  LPPDEVICE        lppd
 *                 LPPSFONTINFO       FontInfo
 *                 LPSTR            lpStr
 *                 int              cb
 *                 LPFONTDATARECORD lpFontDataRecord
 *
 *    Returns:   UPDATE_FAILURE, UPDATE_LOWVM or UPDATE_SUCCESS
 *NOTE!!!!!!!! This is for T0/1 and T0/3 only.
 *    !!!!!!!! T0/42 shares code with T0/CID in ttfonts.c
 ***************************************************************************/

int FAR PASCAL TTUpdateT0Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPSTR lpStr,
                           int cb, LPFONTDATARECORD lpFontDataRecord)
{
WORD        HighByte ;
LPBYTE      lpSubStr, lpTmpStr;
int         cbSub;
LPBYTE      lpFontName;
int         i, fontDLType, childType, fontNameLen;
PSERROR     rc = UPDATE_SUCCESS;                // return value of function
LPDBCSENCODE   lpEncoding;
LPTTFONTINFO   lpTTFontInfo = (LPTTFONTINFO)((LPSTR)FontInfo+FontInfo->dfBitsOffset);
BOOL        bEUDC =lppd->lpPSExtDevmode->dm2.bEUDCAble;
LPSUBFONT43 pSubFontSaved, pSubFont;


    /* Save the old pointer */
    pSubFontSaved = lpFontDataRecord->pSubFont;

    lpEncoding = GetEncoding((int)FontInfo->dfCharSet, bEUDC);

    // Change the DL Type first: need to call TTUpdate() with correct DLType.
    fontDLType = lpFontDataRecord->fontDLType;
    if (lpFontDataRecord->fontDLType == CC_T01)
        childType = CC_1;
    else
        childType = CC_3;
    lpFontName = lpTTFontInfo->PSName; fontNameLen = 0;
    
    while(lpFontName && *lpFontName)
    {
        lpFontName++; 
        fontNameLen++ ;  // save old fontname
    }

    lpSubStr = (LPBYTE)lpStr ;

    while (cb>0)
    {
        HighByte = *lpSubStr;
        lpTmpStr = lpSubStr;
        cbSub = 0;             
        // Search Single Byte fonts:
        for (i=0; i<MAX_1STBRANGES; i++)
        {
            if (lpEncoding->Single[i].min==0 && lpEncoding->Single[i].max==0) 
                break;
            if (HighByte<lpEncoding->Single[i].min ||
                HighByte>lpEncoding->Single[i].max ) continue;
            
            // HighByte is indeed In this range: find its comrades:
            while ( *lpTmpStr >= lpEncoding->Single[i].min &&
                    *lpTmpStr <= lpEncoding->Single[i].max &&
                    cbSub<=cb )
            {
                lpTmpStr++;
                cbSub++;
            }
            //  tack on HighByte as part of FontName.
            lpFontName = &(lpTTFontInfo->PSName[fontNameLen]);
            AppNumToName3(lpFontName, lpEncoding->Single[i].min);
            // Update the descendant font
            // HighByte should be 0 for single byte range chars:
            lpTTFontInfo->HighByte = 0 ;
            lpFontDataRecord->fontDLType = childType;

            pSubFont = pSubFontSaved;
            while( pSubFont && 
                   lstrcmp(pSubFont->strPSName, lpTTFontInfo->PSName) )
            {
                pSubFont = pSubFont->pNext;
            }

            /* can update if we find it in the list */
            if (pSubFont)
            {
                /* Temporarily mess up with the pointers, PPeng, 1-7-1997 */
                lpFontDataRecord->pSubFont = pSubFont;
                rc = TTUpdateFontExt(lppd, FontInfo, (LPSTR)lpSubStr, cbSub, lpFontDataRecord);
            }
            if (rc!=UPDATE_SUCCESS) goto UDT0_END;
            lpSubStr += cbSub;
            cb -= cbSub;
            goto WHILE_END;  // Not necessary to search Double Byte ranges.
        }

        // Search Double Byte Fonts:
        for (i=0; i<MAX_1STBRANGES; i++)
        {
            if (lpEncoding->Double[i].min==0 && lpEncoding->Double[i].max==0) 
                break;
            if (HighByte<lpEncoding->Double[i].min ||
                HighByte>lpEncoding->Double[i].max ) continue;
            
            // HighByte is indeed In this range: find its comrades - different from 1 Byte:
            while ( *lpTmpStr == HighByte&&
                    cbSub<=cb )
            {
                lpTmpStr++;
                lpTmpStr++;  // Skip trailing byte for a double byte char
                cbSub++;
                cbSub++;
            }
            //  tack on HighByte as part of FontName.
            lpFontName = &(lpTTFontInfo->PSName[fontNameLen]);
            AppNumToName2(lpFontName, HighByte);   // add 2 chars
            // Update the descendant font
            lpTTFontInfo->HighByte = HighByte <<8;
            lpFontDataRecord->fontDLType = childType;
            pSubFont = pSubFontSaved;
            while( pSubFont && 
                   lstrcmp(pSubFont->strPSName, lpTTFontInfo->PSName) )
            {
                pSubFont = pSubFont->pNext;
            }

            /* can update if we find it in the list */
            if (pSubFont)
            {
                /* Temporarily mess up with the pointers, PPeng, 1-7-1997 */
                lpFontDataRecord->pSubFont = pSubFont;
                rc = TTUpdateFontExt(lppd, FontInfo, (LPSTR)lpSubStr, cbSub, lpFontDataRecord);
            }

            if (rc!=UPDATE_SUCCESS) goto UDT0_END;
            lpSubStr += cbSub;
            cb -= cbSub;
            goto WHILE_END;  // It's really in Double Byte ranges.
        }
        // Searched all Single and Double byte ranges, if still not found, skip this Highbyte
        cb -=1;
        WHILE_END: ;  // do nothing.
    }

UDT0_END:

    // Restore the saved fontDLType and Font name:
    lpFontDataRecord->fontDLType = fontDLType;
    lpTTFontInfo->PSName[fontNameLen]='\0';
    
    /* Restore the old pointer */
    lpFontDataRecord->pSubFont = pSubFontSaved ;

    return (rc);

}


void FAR PASCAL DeleteSubFont(LPPDEVICE lppd, LPFONTDATARECORD lpFontDataRecord)
{
LPSUBFONT43 pSubFont, pTmp ;
   if (!lpFontDataRecord->isMypSubFont)
      return;

   if (!lpFontDataRecord->pSubFont)
     return;

   pSubFont = lpFontDataRecord->pSubFont; /* This must be the head */

   switch (lpFontDataRecord->fontDLType)
   {

    case CC_1:
    case GI_1:
    case CC_T01:
    case GI_T01:
        while(pSubFont)
        {   
            pTmp = pSubFont->pNext;
            DeleteType1Font(pSubFont);
            GlobalFreePtr(pSubFont);
            pSubFont = pTmp;
        }
        break;

    case CC_3:
    case CC_32:
    case GI_3:
    case GI_32:
    case CC_T03:
    case CC_T032:
    case GI_T03:
    case GI_T032:
        while(pSubFont)
        {   
            pTmp = pSubFont->pNext;
            DeleteType3Font(pSubFont);
            GlobalFreePtr(pSubFont);
            pSubFont = pTmp;
        }
        break;

    case CC_42:
    case GI_42:
    case CC_CID:
    case GI_CID:
    case CC_T042:
    case GI_T042:
        while(pSubFont)
        {   
            pTmp = pSubFont->pNext;
            DeleteType42Font(pSubFont);
            GlobalFreePtr(pSubFont);
            pSubFont = pTmp;
        }
        break;

    default:
#ifdef PSDEBUG
         MessageBox(NULL, "Unknown Type in DeleteSubFont", "Debug error", MB_OK);
#endif
         break;
   }

   lpFontDataRecord->isMypSubFont = 0;
   lpFontDataRecord->pSubFont = NULL;

}


void FAR PASCAL UpdateUFLSubFont(
    LPSUBFONT43         pSubFont,
    LPPDEVICE           lppd,
    LPPSFONTINFO        lpFontInfo,
    LPFONTDATARECORD    lpFontDataRecord
    )
{
    /* Need to update these pointers in pSubFOnt for every UpdateFont() calls 
     becasue for the same font, two different ExtTextOut() calls may have two 
     different lpFontInfo pointers.
    */
    pSubFont->lppd = (LPVOID)lppd;
    pSubFont->FontInfo = (LPVOID) lpFontInfo;
    pSubFont->lpFontData = lpFontDataRecord;
}

// Adobe Patent application tracking 
// # P294CIP, entitled GENERATING A GLYPH, inventors: Jia,Rublee,Jacobs,Phinney,Hall
#ifdef ADD_EURO

BOOL AddEuroToThisFont(
    LPPDEVICE         lppd,
    LPPSFONTINFO      FontInfo)
{
    LPSTR    lpszMSFace = NULL;
    char     temp[128];
    LPFONTEXTRA FontExtra = (LPFONTEXTRA)BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
    DWORD    dwSCDParamsSize;
    HANDLE   hSCDParams;
    LPSHORT  lpTemp;
    int      NumEuroFonts;

    // User disable Euro.
    if ((lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED) &&
        (!lppd->lpPSExtDevmode->dm2.bAddEuro))
        return (FALSE);

    if ((FontInfo->dfType & TYPE_TRUETYPE) ||
       !(CHARSET_NEED_REENCODE(FontInfo->dfCharSet) ))
        return (FALSE);   // TT fonts and Symbol fonts

    // we do not handle MM base font and instance font.
    lpszMSFace = (LPSTR)BUMPFAR (FontInfo, FontExtra->dwPSFace);
    if (!lstrcmpi(lpszMSFace, "Carta") ||
        !lstrcmpi(lpszMSFace, "Sonata") ||
        !lstrcmpi(lpszMSFace, "ZapfDingbats"))
        return (FALSE);    // More symbol fonts

    lpszMSFace = (LPSTR)BUMPFAR (FontInfo, FontExtra->dwPSFace);
    if (IsMMBaseFont(lppd, lpszMSFace, 1))
        return (FALSE);
    lpszMSFace = (LPSTR)BUMPFAR (FontInfo, FontExtra->dwMSFace);
    if ((IsMMInstanceFont(lppd, lpszMSFace, (LPSTR)temp, 1)) ||   // by facename.
        (IsMMBaseFont(lppd, lpszMSFace, 1)))
        return (FALSE);


    if (lppd->lpEuroFontList == NULL)
    {
        LoadEuroFontList(ID_EUROFONT_NAMES, &lppd->lpEuroFontList);
        if (lppd->lpEuroFontList)
        {
            for (NumEuroFonts = 0; lppd->lpEuroFontList[NumEuroFonts] != NULL; NumEuroFonts++);
            lppd->NumEuroFonts = NumEuroFonts;
        }
    }
    if (lppd->lpEuroFontList == NULL)
        return (FALSE);

    if (lppd->lpSCDParams == NULL)
    {
        lpTemp = (LPSHORT)LoadFontResource(ID_SETCACHEDEVICE_PARAMS, &hSCDParams);
        if (lpTemp)
        {
            dwSCDParamsSize = (NumEuroFonts + 1) * 6 * sizeof(int);
            lppd->lpSCDParams =  GlobalAllocPtr(GHND | GMEM_DDESHARE, dwSCDParamsSize);
            if (lppd->lpSCDParams)
                MemCopy(lppd->lpSCDParams, lpTemp, dwSCDParamsSize);
            UnloadFontResource(hSCDParams);
        }
    }
    if (lppd->lpSCDParams == NULL)
        return (FALSE);

    return (TRUE);
}

int GetEuroFontIndex(
    LPPDEVICE         lppd,
    LPPSFONTINFO      FontInfo,
    LPSTR             FontName,
    LPBOOL            lpSubstitution)
{
    int  i;
    char temp[128];

    *lpSubstitution = FALSE;
    for (i = 0; lppd->lpEuroFontList[i] != NULL; i++)
    {
        if (!lstrcmpi(lppd->lpEuroFontList[i], FontName))
        break;
    }
    if (lppd->lpEuroFontList[i] == NULL)
    {
        *lpSubstitution = TRUE;
        if (FontInfo->dfPitchAndFamily & 0x01)  // Variable Pitch font
        {
            if ((FontInfo->dfPitchAndFamily) & FF_ROMAN)
            {
                if (FontInfo->dfWeight < 700)
                {
                    if (!(FontInfo->dfItalic))
                        lstrcpy(temp, "Times-Roman");
                    else
                        lstrcpy(temp, "Times-Italic");
                }
                else
                {
                    if (!(FontInfo->dfItalic))
                        lstrcpy(temp, "Times-Bold");
                    else
                        lstrcpy(temp, "Times-BoldItalic");
                }
            }
            else if ((FontInfo->dfPitchAndFamily) & FF_SWISS)
            {
                if (FontInfo->dfWeight < 700)
                {
                    if (!(FontInfo->dfItalic))
                        lstrcpy(temp, "Helvetica");
                    else
                        lstrcpy(temp, "Helvetica-Oblique");
                }
                else
                {
                    if (!(FontInfo->dfItalic))
                        lstrcpy(temp, "Helvetica-Bold");
                    else
                        lstrcpy(temp, "Helvetica-BoldOblique");
                }
            }
            else
                return FALSE;
        }
        else                                    // Fixed Pitch Font
        {
            if (FontInfo->dfWeight < 700)
            {
                if (!(FontInfo->dfItalic))
                    lstrcpy(temp, "Courier");
                else
                    lstrcpy(temp, "Courier-Oblique");
            }
            else
            {
                if (!(FontInfo->dfItalic))
                    lstrcpy(temp, "Courier-Bold");
                else
                    lstrcpy(temp, "Courier-BoldOblique");
            }
        }

        for (i = 0; lppd->lpEuroFontList[i] != NULL; i++)
        {
            if (!lstrcmpi(lppd->lpEuroFontList[i], temp))
                break;
        }
    }
    return i;
}

BOOL FAR PASCAL AddEuroToType1Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
               LPFONTDATARECORD FontData)
{
    int      i, j, k;
    LPSHORT  lpSCDParams1;
    HANDLE   hT1CSIdx;
    LPSHORT  lpT1CSIdx;
    HANDLE   hT1CS;
    LPBYTE   lpT1CS;
    WORD     wT1CSOffset;
    WORD     wT1CSLength;

    LPASCIIBINPTRS tempptr;
    BOOL     bError = FALSE;
    BOOL     bFinish = FALSE;
    int      iLeng = 0;
    BOOL     bNeedVMCheck;
    char     temp[128];
    LPSTR    *lpObliqueTb = NULL;
    int      ObliqueTbSize;
    BOOL     bFirstPass = TRUE;
    BOOL     bSubstitution;
    LPFONTEXTRA FontExtra = (LPFONTEXTRA)BUMPFAR (FontInfo, FontInfo->dfDriverInfo);
    BOOL     bUMinBegin = FALSE;  // true after "userdict begin Drv_Dict_Min begin" is sent

    if (!AddEuroToThisFont(lppd, FontInfo))
        return (FALSE);

    i = GetEuroFontIndex(lppd, FontInfo, FontData->FontName, &bSubstitution);
                               
    if (lppd->lpEuroFontList[i] == NULL)
        return (FALSE);

    if (!LoadEuroFontList(ID_OBLIQUE_UNDERLYING, &lpObliqueTb))
        return (FALSE);

    lpT1CSIdx = (LPSHORT)LoadFontResource(ID_EURO_T1CSIDX, &hT1CSIdx);
    lpT1CS = (LPBYTE)LoadFontResource(ID_EURO_T1CS, &hT1CS);
    if ((lpT1CSIdx == NULL)  || (lpT1CS == NULL) )
    {
        FreeEuroFontList(&lpObliqueTb);
        if (lpT1CSIdx != NULL) UnloadFontResource(hT1CSIdx);
        if (lpT1CS != NULL) UnloadFontResource(hT1CS);
        return (FALSE);
    }

    for (ObliqueTbSize = 0; lpObliqueTb[ObliqueTbSize] != NULL; ObliqueTbSize++);
    for (j = 0; j < ObliqueTbSize / 2; j++)
    {
        if (!lstrcmpi(lpObliqueTb[j], FontData->FontName))
        break;
    }
    if (j < (ObliqueTbSize / 2))
    {
        lstrcpy(temp, lpObliqueTb[ j + (ObliqueTbSize / 2)]);
        for (j = 0; lppd->lpEuroFontList[j] != NULL; j++)
        {
            if (!lstrcmpi(lppd->lpEuroFontList[j], temp))
                break;
        }
        if (lppd->lpEuroFontList[j] == NULL)
            j = -1;
    }
    else
        j = -1;


    TokenNeedsProcset(lppd, EUROHDR);

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    if (fIsMinHeaderLppd(lppd) && !lppd->job.bfESCOpenChannel)
    {
        PSSendFragment(lppd, PSFRAG_epsprocsetstart); // userdict begin Our_Dict_Min begin
        (*tempptr->PSSendCRLF)(lppd);
        bUMinBegin = TRUE;
    }
    else if (lppd->job.bfESCOpenChannel)
    {
        PSSendFragment(lppd, PSFRAG_OCprocsetstart); // userdict begin Our_Dict_OC begin
        (*tempptr->PSSendCRLF)(lppd);
        bUMinBegin = TRUE;
    }

    PSSendFragment(lppd, PSFRAG_slash);
    PSSendString(lppd, FontData->FontName);
    PSSendString(lppd, " FontHasEuro not");
    PSSendFragment(lppd, PSFRAG_crlf);
    PSSendString(lppd, "{");
    PSSendFragment(lppd, PSFRAG_crlf);

    // Do VM Check only for device font.
    // For Type1 Softfonts, we will do VM Check when downloading;
    bNeedVMCheck = !(lppd->job.bfJobMinHeader || lppd->job.bfESCOpenChannel) &&
                   (FontExtra->dwSoftFont == 0) &&
                   (lppd->lpPSExtDevmode->dm.enumDialect != DIA_PORTABLE) &&
                   (lppd->lpPSExtDevmode->dm.enumDialect != DIA_ARCHIVE) &&
                   (lppd->lpPSExtDevmode->dm.enumDialect != DIA_PJL_ARCHIVE);
    if (bNeedVMCheck)
        VMCheck(lppd, VM_GOODESTIMATE, 5000);
    PSSendFragment(lppd, PSFRAG_slash);
    PSSendString(lppd, "Euro.");
    PSSendString(lppd, FontData->FontName);
    PSSendFragment(lppd, PSFRAG_crlf);
    while (1)
    {
        lpSCDParams1 = lppd->lpSCDParams + 6*i;
        wT1CSOffset = lpT1CSIdx[i];
        wT1CSLength = wT1CSOffset;
        while (1)
        {
            if ((lpT1CS[wT1CSOffset++] == 0x09) &&
               (lpT1CS[wT1CSOffset++] == 0x0E))
               break;      // finish if we see 0x090e
        }
        wT1CSLength = wT1CSOffset - wT1CSLength;
        wT1CSOffset = lpT1CSIdx[i];

        if ((j >= 0) && bFirstPass)
        {
            PSSendFragment(lppd, PSFRAG_slash);
            PSSendString(lppd, FontData->FontName);
            PSSendString(lppd, " UseObliqueEuro {");
            PSSendFragment(lppd, PSFRAG_crlf);
        }
        PSSendString(lppd, "[");
        for (k = 0; k < 6; k++)
            (*tempptr->PSSendShort)(lppd, *lpSCDParams1++);
        PSSendString(lppd, "]");
        PSSendFragment(lppd, PSFRAG_crlf);
        PSSendFragment(lppd, PSFRAG_leftcaret);
        PSSendBitMapDataLevel1Ascii7(lppd, lpT1CS + wT1CSOffset, (DWORD)wT1CSLength);
        PSSendFragment(lppd, PSFRAG_rightcaret);
        PSSendFragment(lppd, PSFRAG_crlf);
        if (j >= 0)
        {
            if (bFirstPass)
            {
                PSSendString(lppd, "} {");
                PSSendFragment(lppd, PSFRAG_crlf);
                i = j;
                bFirstPass = FALSE;
            }
            else
            {
                PSSendString(lppd, "} ifelse");
                PSSendFragment(lppd, PSFRAG_crlf);
                break;
            }
        }
        else
            break;
    }

    PSSendString(lppd, "AddEuroGlyph ");
    PSSendFragment(lppd, PSFRAG_slash);
    PSSendString(lppd, "Euro ");
    PSSendFragment(lppd, PSFRAG_slash);
    PSSendString(lppd, FontData->FontName);
    PSSendFragment(lppd, PSFRAG_crlf);
    PSSendString(lppd, "UseT3EuroFont");
    PSSendFragment(lppd, PSFRAG_crlf);
    PSSendString(lppd, "{");
    PSSendFragment(lppd, PSFRAG_slash);
    PSSendString(lppd, FontData->FontName);
    PSSendString(lppd, "-Copy BuildT3EuroFont}");
    PSSendFragment(lppd, PSFRAG_crlf);
    PSSendString(lppd, "{AddEuroToT1Font} ifelse");
    PSSendFragment(lppd, PSFRAG_crlf);
    PSSendString(lppd, "} if");
    PSSendFragment(lppd, PSFRAG_crlf);
    if (bNeedVMCheck)
        VMUsed(lppd, VM_GOODESTIMATE, 5000);

    UnloadFontResource(hT1CSIdx);
    UnloadFontResource(hT1CS);
    FreeEuroFontList(&lpObliqueTb);

    if (bUMinBegin)
    {
        PSSendFragment(lppd, PSFRAG_end);             // end our dict
        PSSendFragment(lppd, PSFRAG_end);             // end userdict
        (*tempptr->PSSendCRLF)(lppd);
        bUMinBegin = FALSE;
    }

    return (TRUE);
}
#endif

