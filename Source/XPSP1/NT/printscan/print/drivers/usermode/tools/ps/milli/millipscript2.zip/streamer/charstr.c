/* charstr.c -- interprets a Type1 charstring.

              Copyright 1994 -- Adobe Systems, Inc.
            PostScript is a trademark of Adobe Systems, Inc.
NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

Original version: Ron Fischer, Fri Mar 4nd, 1994
*/

/* -------------------------------------------------------------------------
     Header Includes
  --------------------------------------------------------------------------- */

#include <stdio.h>

#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES
#include FP

#include BLEND

#include STREAMER
#include PARSEGLU

#include "buffglue.h"
#include "charstr.h"

#define FAUXCODE 1


#define MAX_TYPE1_ARGS	24

#define CS_HSTEM_CODE           1        /* Char string op codes */
#define CS_COMPOSE_CODE         2	 /* ONLY USED BY CUBE! */
#define CS_VSTEM_CODE           3
#define CS_VMOVETO_CODE         4
#define CS_RLINETO_CODE         5
#define CS_HLINETO_CODE         6
#define CS_VLINETO_CODE         7
#define CS_RRCURVETO_CODE       8
#define CS_CLOSEPATH_CODE       9
#define CS_CALLSUBR_CODE       10
#define CS_RETURN_CODE         11
#define CS_EXT_CODE            12
#define CS_HSBW_CODE           13
#define CS_ENDCHAR_CODE        14
#define CS_RMOVETO_CODE        21
#define CS_HMOVETO_CODE        22
#define CS_VHCURVETO_CODE      30
#define CS_HVCURVETO_CODE      31
/* 32 is the offset for extended codes--if it is used must change code! */

#define CS_DOTSECTION_EXT       0        /* Extended op codes */
#define CS_VSTEM3_EXT           1
#define CS_HSTEM3_EXT           2
#define CS_SEAC_EXT             6
#define CS_SBW_EXT              7
#define CS_ADD_EXT	       10
#define CS_SUB_EXT	       11
#define CS_DIV_EXT             12
#define CS_CALLOTHER_EXT       16
#define CS_POP_EXT             17
#define CS_SETWV_EXT	       19
#define CS_MUL_EXT 	       24
#define CS_DIV2_EXT            25
#define CS_DUP_EXT             26
#define CS_EXCH_EXT            27
#define CS_PUT_EXT             28
#define CS_GET_EXT             29
#define CS_IFELSE_EXT          30
#define CS_SETCURP_EXT         33

/* Other subrs */
#define CS_FLEX_CODE		0
#define CS_PREFLEX1_CODE	1
#define CS_PREFLEX2_CODE	2
#define CS_HINTSUB_CODE		3
#define CS_UNIQUEID_CODE	4
#define CS_GCOLORME_CODE	6
#define CS_SPECL1_CODE		7 /* All CUBE commands currently unsupported */
#define CS_SPECL2_CODE		8
#define CS_SPECL3_CODE		9
#define CS_SPECL4_CODE	       10
#define CS_SPECL6_CODE	       11
#define CS_GLBCLR1_CODE        12 
#define CS_GLBCLR2_CODE        13
#define CS_BLEND1_CODE         14        
#define CS_BLEND2_CODE         15
#define CS_BLEND3_CODE         16
#define CS_BLEND4_CODE         17
#define CS_BLEND6_CODE         18
#define CS_STOREWV_CODE        19
#define CS_OTHERADD_CODE       20
#define CS_OTHERSUB_CODE       21
#define CS_OTHERMUL_CODE       22
#define CS_OTHERDIV_CODE       23
#define CS_OTHERPUT_CODE       24
#define CS_OTHERGET_CODE       25
#define CS_PSPUT_CODE          26
#define CS_IFELSE_CODE         27
#define CS_RANDOM_CODE         28
#define CS_OTHERDUP_CODE       29
#define CS_OTHEREXCH_CODE      30

PRIVATE boolean fauxAccentMoveTo;
PRIVATE boolean integerdividend;
#if FAUXCODE
PRIVATE boolean FauxSkipEndChar;
PRIVATE boolean FauxSkipHSBW;
PRIVATE Card16 FauxLastCode;
#endif /* FAUXCODE */

PUBLIC Card16 charStringKey;
PRIVATE Int32 argStack[MAX_TYPE1_ARGS];
PRIVATE Int32 curH;
PRIVATE Int32 curV;
PRIVATE Int32 intCurH;
PRIVATE Int32 intCurV;
PRIVATE Int32 curHSB;
PRIVATE Int32 curVSB;
PRIVATE Int32 intHSB;
PRIVATE Int32 intVSB;
PRIVATE Int32 stackTop;
PRIVATE Int32 accentDY, accentDX;

#if FAUXCODE
#define  SCALE(V)       (V = fixmul(V, fi->LowercaseScale))
#define  CONDENSE(V)    (V = fixmul(V, fi->condense))
#endif /* FAUXCODE */
#define  POP            argStack[--stackTop]




/*************************************************************************

Function name:  BufferCharData()

**************************************************************************

Date:           
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        
Description:    
                
Parameters:     
                
Return Values:  
Notes:          
See also:       

**************************************************************************/


/* Process the CharString OpCode with a variable number of argments (up to */
/* 6).  First arg is streamed first, then the OpCode.  2 Byte OpCodes are */
/* given as 32 + OpCode.  N is treated as a 16.16 format number, but only */
/* the top 16 bits are taken as an integer.  If you need rounding, add */
/* 0x00008000 to it before calling this function!  There can be 6 arguments, */
/* each being 5 bytes long followed by an op code that is 2 bytes long for */
/* a max of 32 bytes!  NOTE '...' for args IS ANSI standard. */

#if (DEBUG_IN_ENGLISH == false)
PRIVATE void BufferCharData ARGDEF4(Card8, OpCode, Int16, ArgCount, 
                               Int32 *, Args, CharStrOpts *, opts)
{
static Card8 S[32];                       /* Maximum length! */
register Card8 *P = S;
register Int16 n;
Int16 Len;
Int32 dummyLen;
IntX i;

/* If just processing charstrings but not using flattened output (which is
   all this code produces) just return here. */
if (!opts->flattenCharStrs)
   return;

for (i = 0; i < ArgCount; i++)
 { n = (Int16)FTrunc(Args[i]);

   if (-107 <= n && n <= 107)
      *P++ = (Card8)(n + 139);
   else if (108 <= n && n <= 1131)
    { n -= 108;
      *P++ = (Card8)((n >> 8) + 247);
      *P++ = (Card8)(n);                       /* Just the low byte */
    } /* end else */
   else if (-1131 <= n && n <= -108)
    { n += 108;
      *P++ = (Card8)((-n >> 8) + 251);
      *P++ = (Card8)(-n);                       /* Just the low byte */
    } /* end else if */
   else
    { *P++ = 255;
      *P++ = (Card8)(n >> 24);
      *P++ = (Card8)(n >> 16);
      *P++ = (Card8)(n >> 8);
      *P++ = (Card8)(n);
    } /* end else */
 } /* end while */

if (OpCode >= 32)
 { *P++ = CS_EXT_CODE;
   *P++ = (Card8)(OpCode - 32);
 } /* end if */
else
   *P++ = OpCode;

// Instead of doing "Len = P - S;", 
// we do the following to avoid a compiler warning message
//Len =  P - S;  // prior solution failed, back to orignal.. pdb
Len = P -S;

if (opts->lenIV > -1) 		   /* Encrypt the sequence */
   BufferEncrypt(S, S, Len, &dummyLen, &opts->charStringKey, ST_ENCRYPT);   
BufferChars(S, Len);               /* Buffer it and we are done */
return;
} /* end BufferCharData() */


#else /* DEBUG_IN_ENGLISH */


/* Write the CharString out in English */

PRIVATE void BufferCharData ARGDEF4(Card8, OpCode, Int16, ArgCount, 
                               Int32 *, Args, CharStrOpts *, opts)
{
Card8 *Code;
Card8 SpaceString[] = " ";
IntX i;

for (i = 0; i < ArgCount; i++)
 { BufferInt(FTrunc(Args[i]));
   BufferChars(SpaceString, 1);
 } /* end while */

switch (OpCode)
 { case CS_HSTEM_CODE:
      Code = "hstem";
      break;

   case CS_COMPOSE_CODE:
      Code = "compose";
      break;

   case CS_VSTEM_CODE:
      Code = "vstem";
      break;

   case CS_VMOVETO_CODE:
      Code = "vmoveto";
      break;

   case CS_RLINETO_CODE:
      Code = "rlineto";
      break;

   case CS_HLINETO_CODE:
      Code = "hlineto";
      break;

   case CS_VLINETO_CODE:
      Code = "vlineto";
      break;

   case CS_RRCURVETO_CODE:
      Code = "rrcurveto";
      break;

   case CS_CLOSEPATH_CODE:
      Code = "closepath";
      break;

   case CS_CALLSUBR_CODE:
      Code = "callsubr";
      break;

   case CS_RETURN_CODE:
      Code = "return";
      break;

   case CS_HSBW_CODE:
      Code = "hsbw";
      break;

   case CS_ENDCHAR_CODE:
      Code = "endchar";
      break;

   case CS_RMOVETO_CODE:
      Code = "rmoveto";
      break;

   case CS_HMOVETO_CODE:
      Code = "hmoveto";
      break;

   case CS_VHCURVETO_CODE:
      Code = "vhcurveto";
      break;

   case CS_HVCURVETO_CODE:
      Code = "hvcurveto";
      break;

   case 32 + CS_DOTSECTION_EXT:
      Code = "dotsection";
      break;

   case 32 + CS_VSTEM3_EXT:
      Code = "vstem3";
      break;

   case 32 + CS_HSTEM3_EXT:
      Code = "hstem3";
      break;

   case 32 + CS_SEAC_EXT:
      Code = "seac";
      break;

   case 32 + CS_SBW_EXT:
      Code = "sbw";
      break;

   case 32 + CS_ADD_EXT:
      Code = "add";
      break;

   case 32 + CS_SUB_EXT:
      Code = "sub";
      break;

   case 32 + CS_SETWV_EXT:
      Code = "setwv";
      break;

   case 32 + CS_MUL_EXT:
      Code = "mul";
      break;

   case 32 + CS_DIV2_EXT:
      Code = "div2";
      break;

   case 32 + CS_DUP_EXT:
      Code = "dup";
      break;
 
   case 32 + CS_EXCH_EXT:
      Code = "exch";
      break;

   case 32 + CS_PUT_EXT:
      Code = "put";
      break;

   case 32 + CS_GET_EXT:
      Code = "get";
      break;

   case 32 + CS_IFELSE_EXT:
      Code = "ifelse";
      break;

   case 32 + CS_CALLOTHER_EXT:
      Code = "callother";
      break;

   case 32 + CS_POP_EXT:
      Code = "pop";
      break;

   case 32 + CS_SETCURP_EXT:
      Code = "setcurrentpoint";
      break;

   default:
      Code = "UNKNOWN";
      break;
 }

BufferChars((Card8 *) Code, os_strlen(Code));
BufferChars(SpaceString, 1);

return;
} /* end BufferCharData() */

#endif /* DEBUG_IN_ENGLISH */


/*************************************************************************

Function name:  BlendVal()

**************************************************************************

Date:           
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        
Description:    
                
Parameters:     
                
Return Values:  
Notes:          
See also:       

**************************************************************************/



/* Blend the numbers starting in ValP (16.16 format) using the Weight */
/* Vector with Count elements.  Write the output back out starting at ValP.  */
/* ValCount == 1 means 1 value will be generated, ValCount == 2 means 2 */
/* values ... up to 6.  */

/* Given ValCount of 2 and Count of 4 the arguments are stored as  */
/* a1 b1 a2-a1 a3-a1 a4-a1 b2-b1 b3-b1 b4-b1 where (a2-a1) can be written as */
/* d1 etc.. */

/* When blending (a d1 d2 d3) by (w1 w2 w3 w4) we get (w1a + w2(d1+a) + */
/* w3(d2+a) + w4(d3+a) which gives us a(w1 + w2 + w3 + w4) + d1w2 + d2w3 + */
/* d3w4 but (w1 + w2 + w3 +w4) == 1 so we can essentially skip the first */
/* element of the weight vector and we do not have to unravel the deltas! */

PRIVATE void BlendVal ARGDEF4(Int32 *, ValP, Int16, ValCount, T1FontPointer, fp,
                              CharStrOpts *, opts)
{
register Int32 *BaseP;
register Int32 *DeltaP;
register Int32 *WeightP;
Card16 I,
      J;
Int32  Acc;

BaseP = ValP;
DeltaP = BaseP + ValCount;

I = 0;
while (I++ < (Card16)ValCount)
 { Acc = *ValP++;
   J = 1;
   WeightP = (Int32 *)fp->weightVector + 1;
   while (J++ < fp->pFontDict[0]->numMasters)
      Acc += fixmul(*WeightP++, *DeltaP++);

   argStack[stackTop++] = Acc;/* Push the result */
 } /* end while */

} /* end BlendVal() */



/*************************************************************************

Function name:  ProcessCharString()

**************************************************************************

Date:           04/9/94
Author:         Ron Fischer (rff)
Prototype in:   charstr.h
Summary:        Interpret a Type1 charstring.
Description:    
                
Parameters:     DataP - 
                Length - 
                Depth - 
                DoingFaux -
Return Values:  
Notes:          
See also:       

**************************************************************************/


PRIVATE IntX ProcessCharString ARGDEF6(Card8 *, DataP, Int32, Length, 
  Int16, Depth, T1FontPointer, fp, CharStrOpts *, opts,  FauxInfoPointer, fi)
{
Card8 C = 0;
Int32  EndPos;
register Int32 Val;
Int32 Args[MAX_TYPE1_ARGS];/* Max args that will fit on buildchar stack */

if (Depth > 10)
   return ST_BAD_CHARSTRING;

EndPos = (Length > 0) ? (Int32) DataP + Length : 0x7FFFFFFF;

do
 { if (stackTop >= MAX_TYPE1_ARGS)
    { /*printf("\nStack overflow: C = '%c'\n", C);*/
      return ST_BAD_CHARSTRING;
    } /* end if */
   else if (stackTop < 0)
    { /*printf("\nStack underflow: C = '%c'\n", C);*/
      return ST_BAD_CHARSTRING;
    } /* end if */

   C = *DataP++;

   switch (C) 				/* These are instructions */
    { case CS_HSTEM_CODE: 		/* Y and DY for a horizontal stem */
       { Int32  DVal,
               Y1,
               Y2;

         if (stackTop != 2)	/* According to Black Book */
            return ST_BAD_CHARSTRING;

         DVal = POP;               /* Pop values off the stack */
         Val = POP;

         Y1 = curVSB + Val;      /* These are based on Vertical SB */
         Y2 = Y1 + DVal;

#if  FAUXCODE
         if (opts->doingFaux)
          { FauxLastCode = CS_HSTEM_CODE;
            if (fi->LowercaseScale)
             { SCALE(Y1);
               SCALE(Y2);
             } /* end if */

            Y1 += accentDY;  /* Add these after Y has been scaled */
            Y2 += accentDY;
          } /* end if */
#endif /* FAUXCODE */

         Args[0] = FRoundF(Y1) - intVSB;
         Args[1] = FRoundF(Y2) - intVSB - Args[0];
        
         BufferCharData(C, 2, Args, opts);
         break;
       } /* end CS_HSTEM_CODE */

      case CS_VSTEM_CODE:
       { Int32  DVal,
               X1,
               X2;

         if (stackTop != 2)	/* According to Black Book */
            return ST_BAD_CHARSTRING;

         DVal = POP;               /* Pop values off the stack */
         Val = POP;

         X1 = curHSB + Val;
         X2 = X1 + DVal;

#if FAUXCODE
         if (opts->doingFaux)
          { FauxLastCode = CS_VSTEM_CODE;
            if (fi->LowercaseScale)
             { SCALE(X1);
               SCALE(X2);
             } /* end if */

            if (fi->condense)
             { CONDENSE(X1);
               CONDENSE(X2);
             } /* end if */

            X1 += accentDX;  /* Add these after X has been scaled */
            X2 += accentDX;
          } /* end if */
#endif  /* FAUXCODE */

         Args[0] = FRoundF(X1) - intHSB;
         Args[1] = FRoundF(X2) - intHSB - Args[0];

         BufferCharData(C, 2, Args, opts);
         break;
       } /* end case CS_VSTEM_CODE */

      case CS_COMPOSE_CODE:			/* For now, can't handle CUBE */
         opts->canSparseSubrs = false;
         return ST_BAD_CHARSTRING;
#if !HC386 /* High C complains "Unreachable statement" */
         break; 
#endif /* !HC386 */

      case CS_VMOVETO_CODE:
         if (stackTop != 1)	/* According to Black Book */
            return ST_BAD_CHARSTRING;

#if FAUXCODE
         if (opts->doingFaux && fauxAccentMoveTo)
          { Int32  OldV,
                  OldH;

            FauxLastCode = CS_VMOVETO_CODE;

            Val = POP;
            OldH = intCurH;
            OldV = intCurV;

            if (fi->LowercaseScale)
               SCALE(Val);

            curH = accentDX + curHSB;
            curV = accentDY + curVSB + Val;
            intCurH = FRoundF(curH);
            intCurV = FRoundF(curV);
            Args[0] = intCurH - OldH;
            Args[1] = intCurV - OldV;
            BufferCharData(CS_RMOVETO_CODE, 2, Args, opts);
            fauxAccentMoveTo = false;

            break;
         } /* end if */  /* NOTE: Drop through if not a faux seac accent */
#endif /* FAUXCODE */

      case CS_VLINETO_CODE:
       { Int32  OldV;

         if (stackTop != 1)	/* According to Black Book */
            return ST_BAD_CHARSTRING;

         Val = POP;

#if FAUXCODE
         if (opts->doingFaux)
          { FauxLastCode = C;
            if (fi->LowercaseScale)
               SCALE(Val);
          } /* end if */
#endif /* FAUXCODE */

         OldV = intCurV;
         curV += Val;
         intCurV = FRoundF(curV);
         Args[0] = intCurV - OldV;

         BufferCharData(C, 1, Args, opts);
         break;
       } /* end case CS_VLINETO_CODE */

      case CS_HMOVETO_CODE:
         if (stackTop != 1)	/* According to Black Book */
            return ST_BAD_CHARSTRING;
#if FAUXCODE
         if (opts->doingFaux && fauxAccentMoveTo)
          { Int32  OldV,
                  OldH;

            FauxLastCode = CS_HMOVETO_CODE;

            Val = POP;
            OldH = intCurH;
            OldV = intCurV;

            if (fi->LowercaseScale)
               SCALE(Val);
            if (fi->condense)
               CONDENSE(Val);

            curH = accentDX + curHSB + Val;
            curV = accentDY + curVSB;
            intCurH = FRoundF(curH);
            intCurV = FRoundF(curV);
            Args[0] = intCurH - OldH;
            Args[1] = intCurV - OldV;
            BufferCharData(CS_RMOVETO_CODE, 2, Args, opts);
            fauxAccentMoveTo = false;

            break;
         } /* end if */     /* NOTE: Drop through if not a faux seac accent */
#endif /* FAUXCODE */

      case CS_HLINETO_CODE:
       { Int32  OldH;

         if (stackTop != 1)	/* According to Black Book */
            return ST_BAD_CHARSTRING;

         Val = POP;

#if FAUXCODE
         if (opts->doingFaux)
          { FauxLastCode = C;
            if (fi->LowercaseScale)
               SCALE(Val);
            if (fi->condense)
               CONDENSE(Val);
          } /* end if */
#endif /* FAUXCODE */

         OldH = intCurH;
         curH += Val;
         intCurH = FRoundF(curH);
         Args[0] = intCurH - OldH;
         BufferCharData(C, 1, Args, opts);
         break;
       } /* end case CS_HLINETO_CODE */

      case CS_RMOVETO_CODE:
         if (stackTop != 2)	/* According to Black Book */
            return ST_BAD_CHARSTRING;

#if FAUXCODE
         if (opts->doingFaux && fauxAccentMoveTo)
          { Int32  DX,
                  DY,
                  OldV,
                  OldH;

            FauxLastCode = CS_RMOVETO_CODE;

            DY = POP;
            DX = POP;

            OldH = intCurH;
            OldV = intCurV;

            if (fi->LowercaseScale)
             { SCALE(DX);
               SCALE(DY);
             } /* end if */
            if (fi->condense)
               CONDENSE(DX);

            curH = accentDX + curHSB + DX;
            curV = accentDY + curVSB + DY;
            intCurH = FRoundF(curH);
            intCurV = FRoundF(curV);
            Args[0] = intCurH - OldH;
            Args[1] = intCurV - OldV;
            BufferCharData(CS_RMOVETO_CODE, 2, Args, opts);
            fauxAccentMoveTo = false;

            break;
          } /* end if */  /* NOTE: Drop through if not a faux seac accent */
#endif /* FAUXCODE */

      case CS_RLINETO_CODE:
       { Int32  DX,
               DY,
               OldH,
               OldV;

         if (stackTop != 2)	/* According to Black Book */
            return ST_BAD_CHARSTRING;

         DY = POP;
         DX = POP;               /* Pop the values */

#if FAUXCODE
         if (opts->doingFaux)
          { FauxLastCode = C;
            if (fi->LowercaseScale)
             { SCALE(DX);
               SCALE(DY);
             } /* end if */
            if (fi->condense)
               CONDENSE(DX);
          } /* end if */
#endif /* FAUXCODE */

         OldH = intCurH;
         OldV = intCurV;
         curV += DY;
         curH += DX;
         intCurH = FRoundF(curH);
         intCurV = FRoundF(curV);

         Args[0] = intCurH - OldH;
         Args[1] = intCurV - OldV;
         BufferCharData(C, 2, Args, opts);
         break;
       } /* end case CS_RLINETO_CODE */

      case CS_RRCURVETO_CODE:
       { Int32  OldH,
               OldV;
         register Int32 *StackP;

         if (stackTop != 6)	/* According to Black Book */
            return ST_BAD_CHARSTRING;

         stackTop -= 6;
         StackP = &argStack[stackTop];
         Args[0] = *StackP++;               /* dx1 */
         Args[1] = *StackP++;               /* dy1 */
         Args[2] = *StackP++;               /* dx2 */
         Args[3] = *StackP++;               /* dy2 */
         Args[4] = *StackP++;               /* dx3 */
         Args[5] = *StackP;               /* dy3 */

#if FAUXCODE
         if (opts->doingFaux)
          { FauxLastCode = CS_RRCURVETO_CODE;

            if (fi->LowercaseScale)
             { SCALE(Args[0]);
               SCALE(Args[1]);
               SCALE(Args[2]);
               SCALE(Args[3]);
               SCALE(Args[4]);
               SCALE(Args[5]);
             } /* end if */

            if (fi->condense)
             { CONDENSE(Args[0]);
               CONDENSE(Args[2]);
               CONDENSE(Args[4]);
             } /* end if */
          } /* end if */
#endif /* FAUXCODE */

         OldH = intCurH;
         OldV = intCurV;
         curH += Args[0];
         curV += Args[1];
         intCurH = FRoundF(curH);
         intCurV = FRoundF(curV);
         Args[0] = intCurH - OldH;
         Args[1] = intCurV - OldV;

         OldH = intCurH;
         OldV = intCurV;
         curH += Args[2];
         curV += Args[3];
         intCurH = FRoundF(curH);
         intCurV = FRoundF(curV);
         Args[2] = intCurH - OldH;
         Args[3] = intCurV - OldV;

         OldH = intCurH;
         OldV = intCurV;
         curH += Args[4];
         curV += Args[5];
         intCurH = FRoundF(curH);
         intCurV = FRoundF(curV);
         Args[4] = intCurH - OldH;
         Args[5] = intCurV - OldV;

         
         BufferCharData(C, 6, Args, opts);
         break;
       } /* end case CS_RRCURVETO_CODE */

      case CS_RETURN_CODE:
       { return ST_NOERR;		/* Pop out of this level of recursion */
#if !HC386 /* High C complains "Unreachable statement" */
         break;
#endif /* !HC386 */
       } /* end case CS_RETURN_CODE */

      case CS_ENDCHAR_CODE: 		/* We are done! */
       { /* Do the code only if we are not doing a seac base char */
#if FAUXCODE
         if (opts->doingFaux) 
          { if (FauxSkipEndChar == false)
             { BufferCharData(C, 0, Args, opts);
               FauxLastCode = CS_ENDCHAR_CODE;
             } /* end if */
          } /* end if */
         else
#endif /* FAUXCODE */
            BufferCharData(C, 0, Args, opts);

         break;
       } /* end case CS_ENDCHAR_CODE */

      case CS_CLOSEPATH_CODE:
       { BufferCharData(C, 0, Args, opts);
#if FAUXCODE
         if (opts->doingFaux)
            FauxLastCode = CS_CLOSEPATH_CODE;
#endif /* FAUXCODE */
         break;
       } /* end case CS_CLOSEPATH_CODE */

      case CS_CALLSUBR_CODE: 			/* Recurse! */
       { IntX  Index;
         Card8 *SubrOffset;
         Card16 SubrLen;

         if (stackTop < 1)	/* According to Black Book */
             return ST_BAD_CHARSTRING;

         Index = (IntX)FTrunc(POP);

         if (fp->standardSubrs)	/* Special handling when they are standard! */
            do
             { if (Index < 4)	/* We *DO* have these subrs! */
                { /* No need to recurse and unwind! */
                  if (Index == 0)	/* Flex pulls off 3 items */
                   { Int32  H, V, D; /* Simulate the setcurrentpoint */
   
                     V = POP;
                     H = POP;
                     D = POP;
   
#if FAUXCODE
                     if (opts->doingFaux)
                      { FauxLastCode = CS_SETCURP_EXT + 32;
                        if (fi->LowercaseScale)
                         { SCALE(H);
                           SCALE(V);
                         } /* end if */
      
                        if (fi->condense)
                           CONDENSE(H);
                        else if ((Val = fi->expand) != 0)
                           H += (Val >> 1);
                      } /* end if */
#endif /* FAUXCODE */
   
#if 0
                     /* According to Terry calculated point & point on stack */
                     /* should be identical at this point in time. */
                     if ((curV != V) || (curH != H))
                        return ST_BAD_CHARSTRING;
#endif
   
                     curV = V; 
                     curH = H;
      
                     intCurV = FRoundF(curV);
                     intCurH = FRoundF(curH);
      
                     Args[0] = D;
                     Args[1] = intCurH;
                     Args[2] = intCurV;
                     Args[3] = (Card32)Index << 16;
                     BufferCharData(C, 4, Args, opts);
                   } /* end if (FLEX)*/
                  else
                   { Args[0] = (Card32)Index << 16;
                     BufferCharData(C, 1, Args, opts);        
                   } /* end else */
                  break;
                } /* end if */
               else if (Index == 4)	/* Subr 4 is special */
                { if (fp->subr4 == STANDARDV1)	/* Handle the 1st variant */
                   { Args[0] = 0x00030000;
                     Args[1] = 0x00040000;
                     /* Always turn this into a call to subr3 (return) */
                     BufferCharData(C, 2, Args, opts);/*Generate the Subr Call*/
                     Index = (IntX)FTrunc(POP);   /* Unwind the Subr # on the stack */
                   } /* end if */
                  /* 2nd variant does not need unwinding... */
                  else if (fp->subr4 == STANDARDV2) 
                   { Args[0] = 0x00040000; 
                     BufferCharData(C, 1, Args, opts);/*Generate the Subr Call*/
                     break;
                   } /* end if */
                  else
                     break;
                } /* end else */
             } while (Index <= 4);         /* Just to be safe */

         /* Don't try to walk through 1st 5 if they are the standard ones */
         if (!fp->standardSubrs || (Index > 4) || ((Index == 4) && (fp->subr4 == NOTSTANDARDV))	)
          { IntX code/*, flattenStatus*/;
            if (!opts->GetSubr(Index, &SubrOffset, &SubrLen) || 
                             SubrOffset == NULL)
               return ST_CALLBACKFAILED;

            code = ProcessCharString((Card8 *) SubrOffset, SubrLen, 
                                        Depth + 1, fp, opts, fi);
            if (code != ST_NOERR)
              return code;
          } /* end if */
         break;
       } /* end case CS_CALLSUBR_CODE */

      case CS_HSBW_CODE:
       { Int32  SBX,
               WX;

         if (stackTop != 2)	/* According to Black Book */
            return ST_BAD_CHARSTRING;

         WX = POP;
         SBX = POP;

#if FAUXCODE
         if (opts->doingFaux)
          { FauxLastCode = CS_HSBW_CODE;

            if (FauxSkipHSBW)    /* Do nothing! */
               break;

            if (fi->LowercaseScale)
             { SCALE(WX);
               SCALE(SBX);
             } /* end if */

            if (fi->condense)
             { CONDENSE(WX);
               CONDENSE(SBX);
             } /* end if */
            else if ((Val = fi->expand) != 0) /* Assignment */
             { WX += Val;               /* Add full expand to width */
               SBX += (Val >> 1);       /* Half goes to side bearing */
             } /* end else if */
          } /* end if */
#endif /* FAUXCODE */

         WX = FRoundF(WX);
         curHSB = SBX;               /* Used for hints */
         intHSB = FRoundF(SBX);
         curVSB = 0L;
         intVSB = 0L;
                                        /* Not doing a faux font accent */
         if (false == (opts->doingFaux && fauxAccentMoveTo))
          { curH = SBX;          /* Seac Accents are handled differently */
            intCurH = FRoundF(SBX);
            curV = 0L;
            intCurV = 0L;

            Args[0] = intCurH;
            Args[1] = WX;
            BufferCharData(C, 2, Args, opts);
          } /* end if */

         break;
       } /* end case CS_HSBW_CODE */

      case CS_VHCURVETO_CODE:
       { Int32  OldHVal,
               OldVVal;
         register Int32 *StackP;

         if (stackTop != 4)	/* According to Black Book */
            return ST_BAD_CHARSTRING;

         stackTop -= 4;
         StackP = &argStack[stackTop];
         Args[0] = *StackP++;               /* dy1 */
         Args[1] = *StackP++;               /* dx2 */
         Args[2] = *StackP++;               /* dy2 */
         Args[3] = *StackP;               /* dx3 */

#if FAUXCODE
         if (opts->doingFaux)
          { FauxLastCode = CS_VHCURVETO_CODE;
            if (fi->LowercaseScale)
             { SCALE(Args[0]);
               SCALE(Args[1]);
               SCALE(Args[2]);
               SCALE(Args[3]);
             } /* end if */

            if (fi->condense)
             { CONDENSE(Args[1]);
               CONDENSE(Args[3]);
             } /* end if */
          } /* end if */
#endif /* FAUXCODE */

         OldVVal = intCurV;
         curV += Args[0];
         intCurV = FRoundF(curV);
         Args[0] = intCurV - OldVVal;

         OldHVal = intCurH;
         OldVVal = intCurV;
         curH += Args[1];
         curV += Args[2];
         intCurH = FRoundF(curH);
         intCurV = FRoundF(curV);
         Args[1] = intCurH - OldHVal;
         Args[2] = intCurV - OldVVal;

         OldHVal = intCurH;
         curH += Args[3];
         intCurH = FRoundF(curH);
         Args[3] = intCurH - OldHVal;

         BufferCharData(C, 4, Args, opts);
         break;
       } /* end case CS_VHCURVETO_CODE */

      case CS_HVCURVETO_CODE:
       { Int32  OldHVal,
               OldVVal;
         Int32 *StackP;

         if (stackTop != 4)	/* According to Black Book */
            return ST_BAD_CHARSTRING;

         stackTop -= 4;
         StackP = &argStack[stackTop];
         Args[0] = *StackP++;               /* dx1 */
         Args[1] = *StackP++;               /* dx2 */
         Args[2] = *StackP++;               /* dy2 */
         Args[3] = *StackP;                 /* dy3 */

#if FAUXCODE
         if (opts->doingFaux)
          { FauxLastCode = CS_HVCURVETO_CODE;
            if (fi->LowercaseScale)
             { SCALE(Args[0]);
               SCALE(Args[1]);
               SCALE(Args[2]);
               SCALE(Args[3]);
             } /* end if */

            if (fi->condense)
             { CONDENSE(Args[0]);
               CONDENSE(Args[1]);
             } /* end if */
          } /* end if */
#endif /* FAUXCODE */

         OldHVal = intCurH;
         curH += Args[0];
         intCurH = FRoundF(curH);
         Args[0] = intCurH - OldHVal;

         OldHVal = intCurH;
         OldVVal = intCurV;
         curH += Args[1];
         curV += Args[2];
         intCurH = FRoundF(curH);
         intCurV = FRoundF(curV);
         Args[1] = intCurH - OldHVal;
         Args[2] = intCurV - OldVVal;

         OldVVal = intCurV;
         curV += Args[3];
         intCurV = FRoundF(curV);
         Args[3] = intCurV - OldVVal;

         BufferCharData(C, 4, Args, opts);
         break;
       } /* end case CS_HVCURVETO_CODE */

      case CS_EXT_CODE: 		/* Get the extended command */
         { C = *DataP++;

           switch (C)
            { case CS_DOTSECTION_EXT:
               { 
#if FAUXCODE
                 if (opts->doingFaux)
                     FauxLastCode = CS_DOTSECTION_EXT + 32;
#endif /* FAUXCODE */

                  BufferCharData((Card8)(C + 32), 0, Args, opts);
                  break;
               } /* end case CS_DOTSECTION_EXT */

              case CS_VSTEM3_EXT:
              case CS_HSTEM3_EXT:
               { Int32  Val0,
                        Val1,
                        Val2,
                        Val3,
                        Val4,
                        Val5;
                  Int32  CurSB,
                        IntSB;
                  register Int32 *StackP;

                  if (stackTop != 6)	/* According to Black Book */
                     return ST_BAD_CHARSTRING;

                  stackTop -= 6;
                  StackP = &argStack[stackTop];
                  Val0 = *StackP++;    /* X0 or Y0... */
                  Val1 = *StackP++;    /* DX0 */
                  Val2 = *StackP++;    /* X1 */
                  Val3 = *StackP++;    /* DX1 */
                  Val4 = *StackP++;    /* X2 */
                  Val5 = *StackP;      /* DX2 */

                  if (C == CS_VSTEM3_EXT)
                   { CurSB = curHSB;
                     IntSB = intHSB;
                   } /* end if */
                  else
                   { CurSB = curVSB;
                     IntSB = intVSB;
                   } /* end else */

                  Val0 += CurSB;
                  Val1 += Val0;
                  Val2 += CurSB;
                  Val3 += Val2;
                  Val4 += CurSB;
                  Val5 += Val4;

#if FAUXCODE
                  if (opts->doingFaux)
                   { Int32  FauxSeacHintOffset;

                     FauxSeacHintOffset = (C == CS_VSTEM3_EXT) ?
                                           accentDX : accentDY;
                     Val0 += FauxSeacHintOffset;
                     Val2 += FauxSeacHintOffset;
                     Val4 += FauxSeacHintOffset;

                     FauxLastCode = C + 32;

                     if (fi->LowercaseScale)
                      { SCALE(Val0);
                        SCALE(Val1);
                        SCALE(Val2);
                        SCALE(Val3);
                        SCALE(Val4);
                        SCALE(Val5);
                      } /* end if */

                     if (C == CS_VSTEM3_EXT && fi->condense)
                       /* condense horizontally only */
                      { CONDENSE(Val0);
                        CONDENSE(Val1);
                        CONDENSE(Val2);
                        CONDENSE(Val3);
                        CONDENSE(Val4);
                        CONDENSE(Val5);
                      } /* end if */
                   } /* end if */
#endif /* FAUXCODE */

                  /* Process this hint only if it is monotonic!  The Black
                     book specifies some rules for us.  We will */
                  /* force things by setting Val4 and Val5 ourselves, this
                     way guaranteeing that things match up. */

                  if ((Val0 <= Val1 && Val1 <= Val2 && Val2 <= Val3 && Val3 <= 
                       Val4 && Val4 <= Val5)
                     || (Val0 >= Val1 && Val1 >= Val2 && Val2 >= Val3 && Val3 
                         >= Val4 && Val4 >= Val5))
                   { Val0 = FRoundF(Val0) - IntSB;        /* Round everything */
                     Val1 = FRoundF(Val1) - IntSB;
                     Val2 = FRoundF(Val2) - IntSB;
                     Val3 = FRoundF(Val3) - IntSB;
                     Val4 = Val2 + Val3 - Val1;
                     Val5 = Val2 + Val3 - Val0;

                     Args[0] = Val0;
                     Args[1] = Val1 - Val0; 
                     Args[2] = Val2;
                     Args[3] = Val3 - Val2;
                     Args[4] = Val4;
                     Args[5] = Val5 - Val4;
                     BufferCharData((Card8)(C + 32), 6, Args, opts);
                   } /* end if */
                  break;
                } /* end case CS_HSTEM3_EXT */

              case CS_SEAC_EXT:
               { Int32  ASB,
                        ADX,
                        ADY;
                  Card16 BChar,
                        AChar;
                  register Int32 *StackP;

                  if (stackTop != 5)	/* According to Black Book */
                     return ST_BAD_CHARSTRING;

                  stackTop -= 5;
                  StackP = &argStack[stackTop];
                  ASB = *StackP++;
                  ADX = *StackP++;
                  ADY = *StackP++;
                  BChar = (Card16)FTrunc(*StackP++);
                  AChar = (Card16)FTrunc(*StackP);

                  opts->baseChar = BChar;
                  opts->accentChar = AChar;
#if FAUXCODE
                  if (opts->doingFaux) /* Unwind the SEAC and recurse !!! */
                   { Card16 BaseLength,
                           AccentLength;
                     CharDataPtr BaseP;
                     CharDataPtr AccentP;
                     Card8 *charName;
                     IntX code;

                     if (fi->LowercaseScale)
                      { SCALE(ADX);
                        SCALE(ADY);
                      } /* end if */

                     if (fi->condense)
                        CONDENSE(ADX);

                     code = opts->GetCharString(BChar, INDEX_IS_ENCODING, &BaseP, 
                                         &BaseLength, &charName);
                     if (!code || (BaseP == NULL))
                        return ST_BAD_CHARSTRING;
                     code = opts->GetCharString(AChar, INDEX_IS_ENCODING, &AccentP, 
                                         &AccentLength, &charName);
                     if (!code || (AccentP == NULL))
                        return ST_BAD_CHARSTRING;

                     /* Process the base (do not do an EndChar) and be
                        sure that it ends in a ClosePath.  Do not add 1 to */
                     /* Depth since we do not want to overflow it becase
                        of SEAC if it normally reaches the limit. */

                     FauxSkipHSBW = true;

                     FauxSkipEndChar = true;
                     FauxLastCode = 0;
                     code = ProcessCharString((Card8 *) BaseP, 
                                    BaseLength, Depth, fp, opts, fi);
                     FauxSkipEndChar = false;

                     /* Close the path ourselves */
                     if (FauxLastCode != CS_CLOSEPATH_CODE) 
                        BufferCharData(C, 0, Args, opts);

                     if (code != ST_NOERR)
                        return ST_BAD_CHARSTRING;

                     /* Each path can have only 1 MoveTo... so we need to */
                     /* keep track of the fact that this is a Seac accent... */
                     /* we will do special things when we hit HSB and MoveTo */
                     /* in the accent.  Process the accent... its EndChar */
                     /* will end the whole thing. */

                     accentDX = ADX;
                     accentDY = ADY;
                     fauxAccentMoveTo = true;
                     code = ProcessCharString((Card8 *) AccentP, 
                              AccentLength, Depth, fp, opts, fi);
                     fauxAccentMoveTo = false;
                     accentDX = 0L;
                     accentDY = 0L;

                     FauxSkipHSBW = false;

                     if (code != ST_NOERR)
                        return ST_BAD_CHARSTRING;
                   } /* end if */
                  else /* Generate SEAC op codes only if not faux */
#endif /* FAUXCODE */
                   { ASB = FRoundF(ASB);
                     ADX = FRoundF(ADX);
                     ADY = FRoundF(ADY);

                     Args[0] = ASB;
                     Args[1] = ADX;
                     Args[2] = ADY;
                     Args[3] = FixInt(BChar);
                     Args[4] = FixInt(AChar);
                     BufferCharData((Card8)(C + 32), 5, Args, opts);
                   } /* end else */

                  break;
                } /* end case CS_SEAC_EXT */

              case CS_SBW_EXT:
               { Int32  SBX,
                        SBY,
                        WX,
                        WY;
                  register Int32 *StackP;

                  if (stackTop != 4)	/* According to Black Book */
                     return ST_BAD_CHARSTRING;

                  stackTop -= 4;
                  StackP = &argStack[stackTop];
                  SBX = *StackP++;
                  SBY = *StackP++;
                  WX = *StackP++;
                  WY = *StackP;

#if FAUXCODE
                  if (opts->doingFaux)
                   { FauxLastCode = CS_SBW_EXT + 32;

                     if (FauxSkipHSBW)        /* Do nothing! */
                        break;

                     if (fi->LowercaseScale)
                      { SCALE(SBX);
                        SCALE(SBY);
                        SCALE(WX);
                        SCALE(WY);
                      } /* end if */

                     if (fi->condense)
                      { CONDENSE(SBX);
                        CONDENSE(WX);
                      } /* end if */
                     else if ((Val = fi->expand) != 0)
                      { WX += Val;
                        SBX += (Val >> 1);
                      } /* end else if */
                   } /* end if */ 
#endif /* FAUXCODE */

                  WX = FRoundF(WX);
                  WY = FRoundF(WY);
                  curHSB = SBX;
                  curVSB = SBY;
                  intHSB = FRoundF(SBX);
                  intVSB = FRoundF(SBY);

                  if (false == (opts->doingFaux && fauxAccentMoveTo))
                   { curH = SBX;
                     curV = SBY;
                     intCurH = FRoundF(SBX);
                     intCurV = FRoundF(SBY);

                     Args[0] = intCurH;
                     Args[1] = intCurV;
                     Args[2] = WX;
                     Args[3] = WY;
                     BufferCharData((Card8)(C + 32), 4, Args, opts);
                   } /* end if */

                  break;
                } /* end case CS_SBW_EXT */
						/* DO THE ARITHMETIC FUNCS */
               case CS_ADD_EXT: 
                { Int32  Num1,
                        Num2;

                  Num2 = POP;
                  Num1 = POP;

#if FAUXCODE
                  if (opts->doingFaux)
                     FauxLastCode = CS_ADD_EXT + 32;
#endif /* FAUXCODE */

                  argStack[stackTop++] = Num1+Num2;
                  break;
                } /* end case CS_ADD_EXT */

               case CS_SUB_EXT: 
                { Int32  Num1,
                        Num2;

                  Num2 = POP;
                  Num1 = POP;

#if FAUXCODE
                  if (opts->doingFaux)
                     FauxLastCode = CS_SUB_EXT + 32;
#endif /* FAUXCODE */

                  argStack[stackTop++] = Num1-Num2;
                  break;
                } /* end case CS_SUB_EXT */

               case CS_DIV_EXT: 
                { Int32  Num1,
                        Num2;

                  if (stackTop < 2)	/* According to Black Book */
                     return ST_BAD_CHARSTRING;

                  Num2 = POP;
                  Num1 = POP;

#if FAUXCODE
                  if (opts->doingFaux)
                     FauxLastCode = CS_DIV_EXT + 32;
#endif /* FAUXCODE */

                  if (integerdividend)
                   { Num2 = FTrunc(Num2);
                     integerdividend = false;
                   } /* end if */
                  argStack[stackTop++] = fixdiv(Num1, Num2);
                  break;
                } /* end case CS_DIV_EXT */

               case CS_SETWV_EXT: 	/* NO CUBE SUPPORT YET! */
                  return ST_BAD_CHARSTRING;
#if !HC386 /* High C complains "Unreachable statement" */
                  break;
#endif /* !HC386 */

               case CS_MUL_EXT: 
                { Int32  Num1,
                        Num2;

                  Num2 = POP;
                  Num1 = POP;

#if FAUXCODE
                  if (opts->doingFaux)
                     FauxLastCode = CS_MUL_EXT + 32;
#endif /* FAUXCODE */

                  argStack[stackTop++] = fixmul(Num1, Num2);
                  break;
                } /* end case CS_MUL_EXT */

               case CS_DIV2_EXT: 
                { Int32  Num1,
                        Num2;

                  if (stackTop < 2)	/* According to Black Book */
                     return ST_BAD_CHARSTRING;

                  Num2 = POP;
                  Num1 = POP;

                  if (integerdividend)
                     integerdividend = false;

#if FAUXCODE
                  if (opts->doingFaux)
                     FauxLastCode = CS_DIV2_EXT + 32;
#endif /* FAUXCODE */

                  argStack[stackTop++] = fixdiv(Num1, Num2);
                  break;
                } /* end case CS_DIV2_EXT */
       
               case CS_DUP_EXT: 
                { argStack[stackTop] = argStack[stackTop-1];
                  stackTop++;

#if FAUXCODE
                  if (opts->doingFaux)
                     FauxLastCode = CS_DUP_EXT + 32;
#endif /* FAUXCODE */

                  break;
                } /* end case CS_DUP_EXT */

               case CS_EXCH_EXT: 
                { Int32 Num1;
                  
                  Num1 = POP;
                  argStack[stackTop] = argStack[stackTop-1];
                  argStack[stackTop-1] = Num1;
                  stackTop++;

#if FAUXCODE
                  if (opts->doingFaux)
                     FauxLastCode = CS_EXCH_EXT + 32;
#endif /* FAUXCODE */

                  break;
                } /* end case CS_EXCH_EXT */

               case CS_PUT_EXT: 
                { Int32 Num1, index;
                  
                  if (stackTop < 2)	/* According to Black Book */
                      return ST_BAD_CHARSTRING;

                  index = POP;
                  Num1 = POP;
                  if ((index >= (Int32)fp->pFontDict[0]->lenBuildCharArray) || 
                      (index < 0))
                     return ST_BAD_CHARSTRING;
                  fp->buildCharArray[index] = Num1;

#if FAUXCODE
                  if (opts->doingFaux)
                     FauxLastCode = CS_PUT_EXT + 32;
#endif /* FAUXCODE */

                  break;
                } /* end case CS_PUT_EXT */

               case CS_GET_EXT: 
                { Int32 index;
                  
                  opts->canSparseSubrs = false;
                  if (stackTop < 2)	/* According to Black Book */
                      return ST_BAD_CHARSTRING;

                  index = POP;
                  if ((index >= (Int32)fp->pFontDict[0]->lenBuildCharArray) || 
                      (index < 0))
                     return ST_BAD_CHARSTRING;
                  argStack[stackTop++] = fp->buildCharArray[index];

#if FAUXCODE
                  if (opts->doingFaux)
                     FauxLastCode = CS_GET_EXT + 32;
#endif /* FAUXCODE */

                  break;
                } /* end case CS_GET_EXT */

               case CS_IFELSE_EXT: 
                { Int32 v1, v2, s1, s2;
                  
                  opts->canSparseSubrs = false;
                  if (stackTop < 4)	/* According to Black Book */
                      return ST_BAD_CHARSTRING;

                  v2 = POP;
                  v1 = POP;
                  s2 = POP;
                  s1 = POP;
                  if (v1 <= v2)
                     argStack[stackTop++] = s1;
                  else
                     argStack[stackTop++] = s2;

#if FAUXCODE
                  if (opts->doingFaux)
                     FauxLastCode = CS_IFELSE_EXT + 32;
#endif /* FAUXCODE */

                  break;
                } /* end case CS_IFELSE_EXT */

               case CS_CALLOTHER_EXT:
                { Int32  Index;

                  if (stackTop < 2)	/* According to Black Book */
                     return ST_BAD_CHARSTRING;

                  Index = FTrunc(POP);

#if FAUXCODE
                  /* FauxLastCode doesn't seem to need the exact othersubr */
                  if (opts->doingFaux)
                     FauxLastCode = CS_CALLOTHER_EXT + 32;
#endif /* FAUXCODE */

                  switch (Index)
                   { case CS_FLEX_CODE:
                     case CS_PREFLEX1_CODE:
                     case CS_PREFLEX2_CODE:
                      { IntX n, i;
                        n = (IntX)FTrunc(POP);
                        /* Save which command and num args */
                        Args[n+1] = FixInt(Index);
                        Args[n] = FixInt(n);
                        for (i = n-1; i >= 0; i--)
                           Args[i] = POP;
                        BufferCharData(CS_CALLOTHER_EXT, n+2, Args, opts);
                        break;
                      } /* end first 3 othersubrs */

                     case CS_HINTSUB_CODE:
                      { IntX n;
                        n = (IntX)FTrunc(POP);
                        if (n != 1)
                           return ST_BAD_CHARSTRING;
                        /* If just checking out the charstrings (perhaps
                           flattening) don't need to generate these args
                           and code */
                        if (opts->flattenCharStrs)
                         { /* Assumes a subr 3 (return) will exist */
                           Args[0] = FixInt(3);
                           Args[1] = FixInt(1);
                           Args[2] = FixInt(3);
                           BufferCharData(CS_CALLOTHER_EXT+32, 3, Args, opts);
                           /* And there should be a POP after the callother */
                           BufferCharData(CS_POP_EXT+32, 0, Args, opts);
                           BufferCharData(CS_CALLSUBR_CODE, 0, Args, opts);
                         } /* end if */
                        break;
                      } /* end CS_HINTSUB_CODE */

                     case CS_UNIQUEID_CODE:	/* Obsolete function */
                      { IntX n;
                        n = (IntX)FTrunc(POP);
                        if (n != 1)
                           return ST_BAD_CHARSTRING;
                        if (integerdividend)
                           integerdividend = false;
                        n = (IntX)POP;
                      } /* end CS_UNIQUEID_CODE */

                     case CS_GCOLORME_CODE:
                      { IntX n;
                        n = (IntX)POP;
                        if (n != 0)
                           return ST_BAD_CHARSTRING;
                        Args[0] = 0;
                        Args[1] = FixInt(Index);
                        BufferCharData(CS_CALLOTHER_EXT, 2, Args, opts);
                        break;
                      } /* end CS_GCOLORME */

                     /* All CUBE commands currently unsupported */
                     case CS_SPECL1_CODE:
                     case CS_SPECL2_CODE:
                     case CS_SPECL3_CODE:
                     case CS_SPECL4_CODE:
                     case CS_SPECL6_CODE:
                        return ST_BAD_CHARSTRING;
#if !HC386 /* High C complains "Unreachable statement" */
                        break;
#endif /* !HC386 */

                     case CS_GLBCLR1_CODE:
                     case CS_GLBCLR2_CODE:
                      { IntX n, i;

                        if (stackTop < 1)	/* According to Black Book */
                            return ST_BAD_CHARSTRING;

                        n = (IntX)FTrunc(POP);
                        /* Save which command and num args */
                        Args[n+1] = FixInt(Index);
                        Args[n] = FixInt(n);
                        /* Make sure GC data is in correct order */
                        for (i = n-1; i >= 0; i--)
                           Args[i] = POP;
                        BufferCharData(CS_CALLOTHER_EXT, n+2, Args, opts);
                        break;
                      } /* end GLBCLR cases */

                     case CS_BLEND1_CODE:
                     case CS_BLEND2_CODE:
                     case CS_BLEND3_CODE:
                     case CS_BLEND4_CODE:
                     case CS_BLEND6_CODE:
                      { Int32  Count;
                        Int32 *ValP;
                        Int16 ValueCount;
      
                        /* Number of values */
                        Count = FTrunc(argStack[--stackTop]);        
                        stackTop -= Count;        /* Pop everything off */
                        /* Points to values in order! */
                        ValP = &argStack[stackTop];        
      
                        ValueCount = ((Int16)Index == CS_BLEND6_CODE) ? 6 : 
                                            (Int16)(Index + 1) - CS_BLEND1_CODE;
                        /* Push blended val(s) on the PS stack */
                        BlendVal(ValP, ValueCount, fp, opts);        
                        break;
                      } /* end BLEND cases */

                     case CS_STOREWV_CODE:
                      { Int32 offset, i;
                        
                        if (stackTop < 2)	/* According to Black Book */
                            return ST_BAD_CHARSTRING;

                        offset = POP;	/* Get rid of count */
                        offset = FTrunc(POP);
                        if ((offset >= (Int32)fp->pFontDict[0]->lenBuildCharArray) || 
                            (offset < 0))
                           return ST_BAD_CHARSTRING;
                        if (offset + fp->pFontDict[0]->numMasters >= (Int32)fp->pFontDict[0]->lenBuildCharArray)
                           return ST_BAD_CHARSTRING;

                        for (i = offset; i < offset + fp->pFontDict[0]->numMasters; i++)
                           fp->buildCharArray[i] = fp->weightVector[i-offset];
                      
                        break;
                      } /* end CS_STOREWV_CODE */
						/* DO THE ARITHMETIC FUNCS */
                     case CS_OTHERADD_CODE: 
                      { Int32  Num1,
                              Num2;

                       if (stackTop < 3)	/* According to Black Book */
                           return ST_BAD_CHARSTRING;

                        Num1 = POP;	/* Discard count */
                        Num2 = POP;
                        Num1 = POP;

                        argStack[stackTop++] = Num1+Num2;
                        break;
                      } /* end case CS_OTHERADD_CODE */
      
                     case CS_OTHERSUB_CODE: 
                      { Int32  Num1,
                              Num2;
      
                       if (stackTop < 3)	/* According to Black Book */
                           return ST_BAD_CHARSTRING;

                        Num1 = POP;	/* Discard count */
                        Num2 = POP;
                        Num1 = POP;
      
                        argStack[stackTop++] = Num1-Num2;
                        break;
                      } /* end case CS_OTHERSUB_CODE */
      
                     case CS_OTHERMUL_CODE: 
                      { Int32  Num1,
                              Num2;
      
                       if (stackTop < 3)	/* According to Black Book */
                           return ST_BAD_CHARSTRING;

                        Num1 = POP;	/* Discard count */
                        Num2 = POP;
                        Num1 = POP;
      
                        argStack[stackTop++] = fixmul(Num1, Num2);
                        break;
                      } /* end case CS_OTHERMUL_CODE */
      
                     case CS_OTHERDIV_CODE: 
                      { Int32  Num1,
                              Num2;
      
                       if (stackTop < 3)	/* According to Black Book */
                           return ST_BAD_CHARSTRING;

                        if (integerdividend)
                           integerdividend = false;
                        Num1 = POP;	/* Discard count */
                        Num2 = POP;
                        Num1 = POP;
      
                        argStack[stackTop++] = fixdiv(Num1, Num2);
                        break;
                      } /* end case CS_OTHERDIV_CODE */

                     case CS_PSPUT_CODE: 
                     case CS_OTHERPUT_CODE: 
                      { Int32 Num1, index;
                        
                        if (stackTop < 3)	/* According to Black Book */
                            return ST_BAD_CHARSTRING;

                        Num1 = POP;	/* Discard count */
                        index = FTrunc(POP);
                        Num1 = POP;
                        if ((index >= (Int32)fp->pFontDict[0]->lenBuildCharArray) || 
                            (index < 0))
                           return ST_BAD_CHARSTRING;
                        fp->buildCharArray[index] = Num1;
      
                        break;
                      } /* end case CS_OTHERPUT_CODE */
      
                     case CS_OTHERGET_CODE: 
                      { Int32 index;
                        
                        opts->canSparseSubrs = false;
                        if (stackTop < 2)	/* According to Black Book */
                            return ST_BAD_CHARSTRING;

                        index = POP;	/* Discard count */
                        index = FTrunc(POP);
                        if ((index >= (Int32)fp->pFontDict[0]->lenBuildCharArray) || 
                            (index < 0))
                           return ST_BAD_CHARSTRING;
                        argStack[stackTop++] = fp->buildCharArray[index];
      
                        break;
                      } /* end case CS_OTHERGET_CODE */
      
                     case CS_IFELSE_CODE: 
                      { Int32 v1, v2, s1, s2;
                        
                        opts->canSparseSubrs = false;
                        if (stackTop < 5)	/* According to Black Book */
                            return ST_BAD_CHARSTRING;

                        v1 = POP;		/* Discard count */
                        v2 = POP;
                        v1 = POP;
                        s2 = POP;
                        s1 = POP;
                        if (v1 <= v2)
                           argStack[stackTop++] = s1;
                        else
                           argStack[stackTop++] = s2;
      
                        break;
                      } /* end case CS_IFELSE_CODE */

                   case CS_RANDOM_CODE:
                    { Fixed a;

                       opts->canSparseSubrs = false;
                       if (stackTop < 1)	/* According to Black Book */
                           return ST_BAD_CHARSTRING;

                      a = POP;			/* Discard count */

                      a = fp->initialRandomSeed = fp->initialRandomSeed * 
                             1103515245L + 12345L;
                      a = ((a>>16)&65535L) + 1L;
                      if (a == 0) 
                         a = 1;
                      argStack[stackTop++] = a;
                      break;
                    } /* end case CS_RANDOM_CODE */
      
                  case CS_OTHERDUP_CODE: 
                   { Fixed dummy = POP;		/* Discard count */
                     dummy = dummy;		/* Shut compiler up */

                     if (stackTop < 1)	/* According to Black Book */
                         return ST_BAD_CHARSTRING;

                     argStack[stackTop] = argStack[stackTop-1];
                     stackTop++;
   
                     break;
                   } /* end case CS_OTHERDUP_CODE */
   
                  case CS_OTHEREXCH_CODE: 
                   { Int32 Num1;

                     if (stackTop < 2)	/* According to Black Book */
                         return ST_BAD_CHARSTRING;

                     Num1 = POP;		/* Discard count */

                     Num1 = POP;
                     argStack[stackTop] = argStack[stackTop-1];
                     argStack[stackTop-1] = Num1;
                     stackTop++;
   
                     break;
                   } /* end case CS_OTHEREXCH_CODE */

                  default:		/* UNKNOWN OTHERSUBR! */
                      return ST_BAD_CHARSTRING;
#if !HC386 /* High C complains "Unreachable statement" */
                      break;
#endif /* !HC386 */
                 } /* end othersubr switch */

                break; 
              } /* end case CS_CALLOTHER_EXT */
      
            case CS_POP_EXT:  
               break;

            case CS_SETCURP_EXT:	/* This should ONLY occur in flex! */
               return ST_BAD_CHARSTRING;/* It is handled in the CALLSUBR code.*/
#if !HC386 /* High C complains "Unreachable statement" */
               break;
#endif /* !HC386 */

            default:
               return ST_BAD_CHARSTRING;
          } /* end switch */

         break;                       /* break from the outside switch */
       } /* end case CS_EXT_CODE */

      default: 				/* its a number!!! */
       { if (C <= 246)
            argStack[stackTop++] = (Int32) (C - 139) << 16;
         else if (C <= 250)
            argStack[stackTop++] = ((((Int32) (C - 247) << 8) + *DataP++)
                                           + 108) << 16;
         else if (C <= 254)
            argStack[stackTop++] = -(((((Int32) (C - 251) << 8) + *DataP++)
                                           + 108) << 16);
         else
          { Int32 n;                  /* changed: dowling 5/26/95 via pdb */ 
            n = *DataP++;
            n = (n << 8) | *DataP++;
            n = (n << 8) | *DataP++;
            n = (n << 8) | *DataP++;
            if (n >= -32000 && n <= 32000)
               argStack[stackTop++] = FixInt(n);
            else
             { argStack[stackTop++] = n;
               integerdividend = true;
             } /* end else */
          } /* end else */
         break;
       } /* end default */

    } /* end Switch */

 } while ((Int32) DataP < EndPos);    /* Do */

return ST_NOERR;
} /* end ProcessCharString() */


/*************************************************************************

Function name:  SEACLoop

**************************************************************************

Date:           
Author:         Ron Fischer (rff)
Prototype in:   none
Summary:        
Description:    
                
Parameters:     
                
Return Values:  
Notes:          
See also:       

**************************************************************************/

PRIVATE IntX SEACLoop ARGDEF6(Card8 *, DataP, Int32, Length,
  Int16, Depth, T1FontPointer, fp, CharStrOpts *, opts, Card8 *, done)
{
Card8 C = 0;
Int32  EndPos;

if (Depth > 10)
   return ST_BAD_CHARSTRING;

EndPos = (Length > 0) ? (Int32) DataP + Length : 0x7FFFFFFF;

do
 { if (stackTop >= MAX_TYPE1_ARGS)
    { /*printf("\nStack overflow: C = '%c'\n", C);*/
      return ST_BAD_CHARSTRING;
    } /* end if */
   else if (stackTop < 0)
    { /*printf("\nStack underflow: C = '%c'\n", C);*/
      return ST_BAD_CHARSTRING;
    } /* end if */

   C = *DataP++;

   switch (C)
    { case CS_HSTEM_CODE:
      case CS_COMPOSE_CODE:
      case CS_VSTEM_CODE:
      case CS_VMOVETO_CODE:
      case CS_RLINETO_CODE:
      case CS_HLINETO_CODE:
      case CS_VLINETO_CODE:
      case CS_RRCURVETO_CODE:
      case CS_CLOSEPATH_CODE:
      case CS_ENDCHAR_CODE:
      case CS_RMOVETO_CODE:
      case CS_HMOVETO_CODE:
      case CS_VHCURVETO_CODE:
      case CS_HVCURVETO_CODE:
         *done = true;
         break;

      case CS_HSBW_CODE:
      case CS_RETURN_CODE:
         break;

      case CS_EXT_CODE:                 /* Get the extended command */
       { C = *DataP++;

         switch (C)
          { case CS_SEAC_EXT:
               opts->baseChar = (Card16)FTrunc(argStack[--stackTop]);
               opts->accentChar = (Card16)FTrunc(argStack[--stackTop]);
               *done = true;
               return ST_NOERR;
               break;
            case CS_POP_EXT:
               break;					/* Do nothing. BlendVal puts values on stack */
	 	    case CS_CALLOTHER_EXT:
	 	       { Int32  Index;
	 	 
	 	         if (stackTop < 2)     /* According to Black Book */
	 	            return ST_BAD_CHARSTRING;
	 	 
	 	         Index = FTrunc(POP);

	 	         switch (Index)
	 	          { case CS_BLEND1_CODE:
	 	            case CS_BLEND2_CODE:
	 	            case CS_BLEND3_CODE:
	 	            case CS_BLEND4_CODE:
	 	            case CS_BLEND6_CODE:
	 	             { Int32  Count;
	 	               Int32 *ValP;
	 	               Int16 ValueCount;
	 	 
	 	               /* Number of values */
	 	               Count = FTrunc(argStack[--stackTop]);
	 	               stackTop -= Count;        /* Pop everything off */
	 	               /* Points to values in order! */
	 	               ValP = &argStack[stackTop];
	 	 
	 	               ValueCount = ((Int16)Index == CS_BLEND6_CODE) ? 6 :
	 	                           (Int16)(Index + 1) - CS_BLEND1_CODE;
	 	               /* Push blended val(s) on the PS stack */
	 	               BlendVal(ValP, ValueCount, fp, opts);
	 	               break;
	 	             } /* end BLEND cases */
	 	 
	 	            default:
	 	               *done = true;
	 	               return ST_NOERR;
	 	               break;
	 	          } /* end switch */
	 	 		break;
	 	        } /* end case CS_CALLOTHER_EXT: */

            default:
               *done = true;
               return ST_NOERR;
               break;
          } /* end switch */
		break;
       } /* end case CS_EXT_CODE */

      case CS_CALLSUBR_CODE:                    /* Recurse! */
       { IntX  Index, code;
         Card8 *SubrOffset;
         Card16 SubrLen;

         if (stackTop < 1)      /* According to Black Book */
             return ST_BAD_CHARSTRING;

         Index = (IntX)FTrunc(POP);

         if ((fp->standardSubrs) && (Index < 4)) 
            return ST_NOERR;
         if ((Index == 4) && (fp->subr4 != NOTSTANDARDV))
            return ST_NOERR;

         if (!opts->GetSubr(Index, &SubrOffset, &SubrLen) ||
                             SubrOffset == NULL)
            return ST_CALLBACKFAILED;

         code = SEACLoop((Card8 *) SubrOffset, SubrLen,
                                        Depth + 1, fp, opts, done);
         if (code != ST_NOERR)
           return code;
         break;
       } /* end case CS_CALLSUBR_CODE */

 
       default:                          /* its a number!!! */
        { if (C <= 246)
             argStack[stackTop++] = (Int32) (C - 139) << 16;
          else if (C <= 250)
             argStack[stackTop++] = ((((Int32) (C - 247) << 8) + *DataP++)
                                            + 108) << 16;
          else if (C <= 254)
             argStack[stackTop++] = -(((((Int32) (C - 251) << 8) + *DataP++)
                                            + 108) << 16);
          else
          { Card32 n;
            n = *DataP++;
            n = (n << 8) | *DataP++;
            n = (n << 8) | *DataP++;
            n = (n << 8) | *DataP++;
            if (n >= -32000 && n <= 32000)
               argStack[stackTop++] = FixInt(n);
            else
             { argStack[stackTop++] = n;
               integerdividend = true;
             } /* end else */
          } /* end else */

          break;
        } /* end default */
 
    } /* end switch */

 } while (((Int32) DataP < EndPos) && !(*done));    /* end do-while */

return ST_NOERR;
} /* end SEACLoop() */


/*************************************************************************

Function name:  CheckForSeac()

**************************************************************************

Date:           06/14/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Check charstrings to find SEAC base and accent characters.
Description:    Performs a fast check of charstrings to determine if they
		are SEAC charstrings, and if they are, what the base
 		and accent characters are (in the CharStrOpts struct).
                As soon as the loop determines that the charstring cannot
		be for a SEAC character it returns.
                
Parameters:     DataP - the charstring to examine
                Length - the length of the charstring.
		fp - the pointer to the Font Information record
		opts - the charstring options
Return Values:  standard ST values
Notes:          
See also:       

**************************************************************************/

PUBLIC IntX CheckForSEAC ARGDEF4(Card8 *, DataP, Int32, Length,
  T1FontPointer, fp, CharStrOpts *, opts)
{
Card8 done = false;
stackTop = 0;
integerdividend = false;

opts->baseChar = 0;             /* Since they are both zero this isn't seac */
opts->accentChar = 0;

if (DataP == NULL)
   return ST_NOERR;                  /* Just sending an endchar out. */

return SEACLoop(DataP, Length, 0, fp, opts, &done);
} /* end CheckForSEAC() */


/*************************************************************************

Function name:  StreamCharString()

**************************************************************************

Date:           03/20/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream a charstring
Description:    Current implementation wants to snapshot&flatten!
                In general this should stream a charstring.  If snapshotting
                is not selected that will only consist of (possibly)
                changing the encryption of the charstring.  For snapshotting
                that will include snapshot and flattening.
Parameters:     dataP -- the pointer to the initial charstring
                length -- the length of the charstring
                charName -- the name of the charstring
                opts -- the charstring options
Return Values:  see ST_ values in streamer.h
Notes:          
See also:       

**************************************************************************/

PUBLIC IntX StreamCharString ARGDEF7(Card8 *, dataP, Int32, length, 
   Card8 *, charName, T1FontPointer, fp, CharStrOpts *, opts,  
   FauxInfoPointer, fi, PBufferStatus, b)
{
IntX code = ST_NOERR;
#if !DEBUG_IN_ENGLISH
Card8 charHeader[64];
Card32 s;
Card16 saveKey;
char endchar[1] = "\x0E";	/* used for null charstrings */
#endif

curH = 0;
curV = 0;
intCurH = 0;
intCurV = 0;
curHSB = 0;
curVSB = 0;
intHSB = 0;
intVSB = 0;
fauxAccentMoveTo = false;
integerdividend = false;

stackTop = 0;

opts->baseChar = 0;		/* Since they are both zero this isn't seac */
opts->accentChar = 0;

if (charName == NULL)
   charName = (Card8 *)".notdef";
if (dataP == NULL)
   length = 1;			/* Just sending an endchar out. */

#if DEBUG_IN_ENGLISH

BufferRestore(b);

BufferChar('/');
BufferString(charName);
BufferString(" ## RD { ");
if (dataP == NULL)
   code = ProcessCharString (dataP, length, 0, fp, opts, fi);
else
   BufferString("endchar");

if (code != ST_NOERR) 
   return code;
BufferStringEOL(" } ND");

#else /* DEBUG_IN_ENGLISH */

/* Don't know the size of the charstring until after it's processed.
   It must be inserted before the data */
BufferFlush();
/* Don't allow BufferFlush()es while building up a charString */
BufferLock(true);

saveKey = opts->charStringKey;
if (opts->lenIV > -1)
   BufferChars(opts->lenIVBytes, opts->lenIV);
if (dataP != NULL)
   code = ProcessCharString(dataP, length, 0, fp, opts, fi); 
else if (opts->flattenCharStrs) /* non-flattened handled below */
 { if (opts->lenIV == -1)
      BufferChar((Card8 )endchar[0]);
   else
      BufferAndEncrypt((Card8 *)endchar, 1, &opts->charStringKey);
 } /* end else */

if (code != ST_NOERR) 
   return code;

if (opts->flattenCharStrs)
 { s = BufferSize();
   os_sprintf((char *)charHeader, "/%s %ld RD ", charName, s);
   BufferInsert(charHeader, os_strlen((char *)charHeader));
 } /* end if */
else	/* Charstring data has not been output yet! */
 { if (opts->lenIV > -1)
    { os_sprintf((char *)charHeader, "/%s %ld RD ",charName, length+opts->lenIV);
      BufferInsert(charHeader, os_strlen((char *)charHeader));
      if (dataP != NULL)
         BufferAndEncrypt(dataP, length, &opts->charStringKey);
      else
         BufferAndEncrypt((Card8 *)endchar, 1, &opts->charStringKey);
    } /* end if */
   else
    { os_sprintf((char *)charHeader, "/%s %ld RD ", charName, length);
      BufferInsert(charHeader, os_strlen((char *)charHeader));
      if (dataP != NULL)
         BufferChars(dataP, length);
      else
         BufferChar((Card8)endchar[0]);
    } /* end else */
 } /* end else */

#if 0 /* Ajit says he does not need this on a per charstring basis */
if (opts->accessCharStrings)
   BufferStringEOL((Card8 *)" executeonly def");
else
#endif
   BufferStringEOL((Card8 *)" ND");

opts->charStringKey = saveKey;

#endif /* DEBUG_IN_ENGLISH */

BufferLock(false);		/* No need to prevent flushes anymore */
BufferFlush();			/* Clean out buffer */
BufferSave(b);
return BufferError();
} /* end StreamCharString() */




