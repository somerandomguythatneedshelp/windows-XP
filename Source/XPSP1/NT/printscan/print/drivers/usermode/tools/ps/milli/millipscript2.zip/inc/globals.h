/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: GLOBALS.H                                              */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

//Setjmp.h provides declartions for the setjmp() and longjmp() routines.
#include "setjmp.h"

#define STRINGBUFSIZE 1024
#ifdef DEFINEGLOBALS
HANDLE ghDriverMod=NULL;                //the PSWriter instance handle
SYSRESOURCESREC gSysResources ;
BOOL gSysResourcesLockFlag ;
jmp_buf ErrJmpVector ;
char szUnknownError[60];
char szNone[5];
char szFalse[6];
char szTrue[5];
char szDefaultPrinter[16];
char szHelpFile[13];            // "ADOBEPS4.HLP"             from registry
char szIniCreator[64];          // "ADOBEPS4.DRV Version 4.1" from registry 
char szOne[2];
char szTwo[2];
char szQuestion[8];
int iHelpTopic;
HWND hWndDevMode;
LPSTR** AliasTable;
LPSTR* IncorrectFixedFontList;
LPSTR* PrefCJKFontList;
LPSTR* MacGlyphNameList;
LPSTR* EncodeNameList;  //use in UFL no longer in Streamer
#else
extern HANDLE ghDriverMod;
extern SYSRESOURCESREC gSysResources ;
extern BOOL gSysResourcesLockFlag ;
extern jmp_buf ErrJmpVector ;
extern char szUnknownError[60];
extern char szNone[5];                  /* duplicate copy in glstatic.h */
extern char szFalse[6];                 /* sizes must match             */
extern char szTrue[5];
extern char szDefaultPrinter[16];
extern char szHelpFile[13];
extern char szIniCreator[64];
extern char szOne[2];
extern char szTwo[2];
extern char szQuestion[8];
extern int iHelpTopic;
extern HWND hWndDevMode;
extern LPSTR** AliasTable;
extern LPSTR* IncorrectFixedFontList;

extern LPSTR* PrefCJKFontList;
extern LPSTR* EncodeNameList;  //use in UFL no longer in Streamer
extern LPSTR* MacGlyphNameList;
#endif

