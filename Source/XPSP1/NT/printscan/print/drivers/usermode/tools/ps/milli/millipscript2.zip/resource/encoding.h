/*
 * encoding.h
 * 
 * Copyright (c) 1989-1991 Adobe Systems Incorporated.
 * All rights reserved.
 *
 * This file may be freely copied and redistributed as long as:
 *   1) This entire notice continues to be included in the file, 
 *   2) If the file has been modified in any way, a notice of such
 *      modification is conspicuously indicated.
 *
 * PostScript, Display PostScript, and Adobe are registered trademarks of
 * Adobe Systems Incorporated.
 * 
 * ************************************************************************
 * THE INFORMATION BELOW IS FURNISHED AS IS, IS SUBJECT TO CHANGE WITHOUT
 * NOTICE, AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY ADOBE SYSTEMS
 * INCORPORATED. ADOBE SYSTEMS INCORPORATED ASSUMES NO RESPONSIBILITY OR 
 * LIABILITY FOR ANY ERRORS OR INACCURACIES, MAKES NO WARRANTY OF ANY 
 * KIND (EXPRESS, IMPLIED OR STATUTORY) WITH RESPECT TO THIS INFORMATION, 
 * AND EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR PARTICULAR PURPOSES AND NONINFINGEMENT OF THIRD PARTY RIGHTS.
 * ************************************************************************
 */

#define true    -1
#define false    0

/* encoding.c: exported functions */

extern void EncodeInteger (long integer);
extern void EncodeReal (float real);
extern void EncodeName (int type, char *name);
extern void EncodeDSC (char *text);
extern void SendEOL (void);


#define AppendString(text)              \
{                                       \
  long length = strlen (text);          \
  if ((stringLength + length) > MAXSTRING) \
    FatalError ("String too long.");    \
  strncpy (stringPointer, text, (size_t)length); \
                /* WARNING: in MS C 6.0, size_t is unsigned int, i.e.   \
                 * shorter than a long.  Should be OK as long as        \
                 * MAXSTRING <= 64K.    \
                 */                     \
  stringPointer += length;              \
  stringLength += length;               \
}

#define AppendByte(byte)                \
{                                       \
  if ((stringLength + 1) > MAXSTRING)   \
    FatalError ("String too long.");    \
  *stringPointer++ = (byte);            \
  stringLength++;                       \
}

/* operations: possible modes of operation for this program */
enum OP {
    OP_STATISTICS,      /* Gathering statistics on potential shrinkage */
    OP_TOKENSEQ,        /* Emitting sequences of consecutive tokens */
    OP_EMIT             /* Emit a shrunken version of input */
};

/* controls: each of these flags controls some aspect of emitted code */
extern enum OP  iOperation;     /* Set to mode of operation; see list */
extern int highByteFirst;       /* TRUE if numbers stored high byte first */
extern int ieeeFormat;          /* TRUE if reals to be emitted in IEEE. */
extern int fLevel2;             /* TRUE if PostScript Level 2 may be emitted. */
extern int fBinary;             /* TRUE if binary data may be emitted. */
extern int cTokenSeq;           /* length of token sequence to emit. 
                                   (if iOperation == OP_TOKENSEQ)       */
extern int fSubstGeneric;       /* TRUE if generic numbers and string 
                                   tokens should be emitted.
                                   (if iOperation == OP_TOKENSEQ)       */
extern int fKeepDSC;            /* TRUE if we should keep DSC comments  */

extern char *stringPointer;
extern long stringLength;
extern int  fDelimPrevToken;    /* TRUE if previous token is self-delimiting */
extern unsigned long cbLine;    /* Byte count of current line */

extern void BeginStringEncoding(void);
extern void EndStringEncoding(void);
extern void InitEncoding(void);


#ifdef MSC
#define MAXSTRING 32768
        /* In MS C 6.0 small model programs, malloc allocates off of
         * the local heap, which shares the local segment with global
         * variables and the stack.  InitParser() in encoding.c allocates
         * a buffer of MAXSTRING, and it must be small enough to fit in
         * local heap space.  So, define MAXSTRING to be much less than 
         * 64K.
         */
#else
#define MAXSTRING 65535         /* in Unix systems, can allocate 64k */
#endif



/* mapname.c: exported functions and data structures */
extern int MapName( char *name );


/* parser.l: exported functions and data structures */
extern void InitParser(void);
#if DEBUG

extern void Trace(char *message, ...);
#define TRACE(x)        Trace x

#else  /*DEBUG*/
#define TRACE(x)
#endif /*DEBUG*/


/* pshrink.c: exported functions and data structures */
extern void FatalError( char *message, ... );

/* Statistics gathering data structures
 *
 * This program counts every byte as it is read, and classifies it into
 * a StatisticsCategory.  It keeps track of the sums of bytes read in 
 * rgcbIn[].  As it writes data, it keeps track of sums of bytes written
 * in rgcbOut[], using the same StatisticsCategories.
 */

enum StatisticsCategory {
  SC_NUMBERS,   // Numbers in all forms and encodings
  SC_NAMES,     // Names in all forms and encodings, and {}[] etc.
  SC_STRINGS,   // PostScript language strings in all encodings
  SC_DSC,       // Document Structuring Conventions comments
                // (including newlines that terminate DSC comments).
  SC_FILLER,    // Whitespace, newlines, non-DSC comments.
  SC_DATA       // Literal data denoted with %%Binary.
};
#define SC_FIRST (SC_NUMBERS)
#define SC_MAX   (SC_DATA+1)

extern unsigned long rgcbIn[SC_MAX];   // Amount of data read.
extern unsigned long rgcbOut[SC_MAX];  // Amount of data written.

/* cbEOL contains the number of bytes a '\n' consumes in the file. */
/* N.B. this is a constant, while the input file could contain various
 * combinations of CR and LF as end-of-line sequences.  If the file
 * has non-standard end-of-line sequences, this program will probably 
 * miscount the bytes in end-of-line sequences.
 */
#ifdef MSC
#define cbEOL 2
#else
#define cbEOL 1
#endif
