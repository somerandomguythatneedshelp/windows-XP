/*
 * Include file for cont\ps_debug.c
 */
#ifndef PS_DEBUG_H
#define PS_DEBUG_H

#define PRFDEVMODE          0
#define PRFEXTDEVMODE       1
#define PRFDEVINSTALL       2
#define PRFDEVCAPS          3
#define PRFPROPSHEET        4

#define PRFBITBLT          10
#define PRFCOLORINFO       11
#define PRFCONTROL         12
#define PRFDISABLE         13
#define PRFENABLE          14
#define PRFENUMDFONTS      15
#define PRFENUMOBJ         16
#define PRFOUTPUT          17
#define PRFPIXEL           18
#define PRFREALIZEPEN      19
#define PRFREALIZEBRUSH    20
#define PRFREALIZEFONT     21
#define PRFSTRBLT          22
#define PRFSCANLR          23
#define PRFEXTTEXTOUT      24
#define PRFCHARWIDTH       25
#define PRFDEVBITMAP       26
#define PRFFASTBORDER      27
#define PRFSETATTR         28
#define PRFDIBTODEVICE     29
#define PRFSTRETCHBLT      30
#define PRFSTRETCHDIB      31

#if 1
#define PRFNEWFRAME           32    
#define PRFABORTDOC           33    
#define PRFNEXTBAND           34    
#define PRFSETCOLORTABLE      35    
#define PRFGETCOLORTABLE      36    
#define PRFFLUSHOUTPUT        37    
#define PRFDRAFTMODE          38    
#define PRFQUERYESCSUPPORT    39    
#define PRFSETABORTPROC       40    
#define PRFSTARTDOC           41    
#define PRFENDDOC             42    
#define PRFGETPHYSPAGESIZE    43    
#define PRFGETPRINTINGOFFSET  44    
#define PRFGETSCALINGFACTOR   45    
#define PRFSETCOPYCOUNT       46    
#define PRFSELECTPAPERSOURCE  47    
#define PRFPASSTHROUGH        48    
#define PRFGETTECHNOLOGY      49    
#define PRFSETLINECAP         50    
#define PRFSETLINEJOIN        51    
#define PRFSETMITERLIMIT      52    
#define PRFBANDINFO           53    
#define PRFDRAWPATTERNRECT    54    
#define PRFGETVECTORPENSIZE   55    
#define PRFGETVECTORBRUSHSIZE 56    
#define PRFENABLEDUPLEX       57    
#define PRFGETSETPAPERBINS    58    
#define PRFGETSETPAPERORIENTATION  59
#define PRFENUMPAPERBINS      60      
#define PRFSETDIBSCALING      61    
#define PRFEPSPRINTING        62    
#define PRFENUMPAPERMETRICS   63    
#define PRFGETSETPAPERMETRICS 64    
#define PRFGETVERSION         65    
#define PRFPOSTSCRIPTDATA     66    
#define PRFPOSTSCRIPTIGNORE   67    
#define PRFRESETDC            68    
#define PRFGETEXTENDEDTEXTMETRICS 69
#define PRFGETEXTENTTABLE     70    
#define PRFGETPAIRKERNTABLE   71    
#define PRFGETTRACKKERNTABLE  72    
#define PRFEXTEXTOUT          73    
#define PRFGETFACENAME        74    
#define PRFDOWNLOADFACE       75    
#define PRFATMINFO            76    
#define PRFENABLERELATIVEWIDTHS 77  
#define PRFENABLEPAIRKERNING  78    
#define PRFSETKERNTRACK       79    
#define PRFSETALLJUSTVALUES   80    
#define PRFSETCHARSET         81    
#define PRFBEGINPATH          82    
#define PRFCLIPTOPATH         83    
#define PRFENDPATH            84    
#define PRFEXTDEVICECAPS      85    
#define PRFRESTORECTM         86    
#define PRFSAVECTM            87    
#define PRFSETARCDIRECTION    88    
#define PRFSETBACKGROUNDCOLOR 89    
#define PRFSETPOLYMODE        90    
#define PRFSETSCREENANGLE     91    
#define PRFSETSPREAD          92    
#define PRFTRANSFORMCTM       93    
#define PRFSETCLIPBOX         94    
#define PRFSETBOUNDS          95 
// Micro grafix escapes
#define PRFSETMIRRORMODE         96    
#define PRFSETSCREENFREQUENCY    97  
#define PRFGETSCANORIENTATION    98  
#define PRFSCANFILL              99  
#define PRFPOLYSET               100  
#define PRFDRAWBITMAP            101  
// New Aldus escapes            
#define PRFOPENCHANNEL           102  
#define PRFDOWNLOADHEADER        103  
#define PRFCLOSECHANNEL          104  
#define PRFSETGDIXFORM           105  
#define PRFRESETPAGE             106  
#define PRFPOSTSCRIPT_PASSTHROUGH  107
#define PRFENCAPSULATED_POSTSCRIPT 108
#endif
#define DOCPRINT           109
#define REALIZE_PASS1      110
#define REALIZE_PASS2      111
#define PRFCTEXTBEGIN      112



#define PRFCTEXTRUN        113
#define PRFCTEXTEND        114
#define PRFCSOFTFONTLOAD   115



#if (defined(PS_PROFILE) || defined(STATPROF))
extern BOOL _loadds FAR PASCAL DevBitBlt(LP,short,short,LPBITMAP,
                                         short,short,short,short,
                                         DWORD, LPPBRUSH,LPDRAWMODE);

extern DWORD _loadds FAR PASCAL ColorInfo(LP,DWORD,LPPCOLOR);

extern WORD _loadds FAR PASCAL Control(LP,WORD,LP,LP);

extern VOID _loadds FAR PASCAL DevDisable(LP);

extern short _loadds FAR PASCAL DevEnable(LP,WORD,LPSTR,LPSTR,LPDEVMODE);

extern WORD _loadds FAR PASCAL EnumDFonts(LP, LPSTR, FARPROC, LP);

extern short _loadds FAR PASCAL EnumObj(LP,short,FARPROC,LP);

extern short _loadds FAR PASCAL Output(LP,short,short,LPPOINT,LPPPEN,LPPBRUSH,
                                       LPDRAWMODE,LPRECT);

extern DWORD _loadds FAR PASCAL Pixel(LP,short,short,DWORD,LPDRAWMODE);

extern WORD _loadds FAR PASCAL RealizeObject(LP,short,LP,LP,LP);

#if 0
extern DWORD _loadds FAR PASCAL StrBlt(LP,SHORT,SHORT,LPRECT,LPSTR,
                                       SHORT,LPPSFONTINFO,
                                       LPDRAWMODE, LPTEXTXFORM);
#endif
extern SHORT _loadds FAR PASCAL DevScanLR(LP,SHORT,SHORT,DWORD,SHORT);

extern short _loadds FAR PASCAL DeviceMode(HWND,HANDLE,LPSTR, LPSTR);

extern DWORD _loadds FAR PASCAL DevExtTextOut(LPPDEVICE, int, int, 
                                              LPRECT, LPSTR, int,
                                              LPPSFONTINFO, LPDRAWMODE,
                                              LPTEXTXFORM, LPSHORT,
                                              LPRECT, WORD);

extern short _loadds FAR PASCAL DevGetCharWidth(LP,LPSHORT,WORD, WORD,
                                                LPPSFONTINFO,LPDRAWMODE,
                                                LPTEXTXFORM);

extern SHORT _loadds FAR PASCAL DeviceBitmap(LP,SHORT,LPBITMAP,LP);

extern SHORT _loadds FAR PASCAL FastBorder(LPRECT,WORD,WORD,
                                           DWORD,LP,LPPBRUSH,LPDRAWMODE,LPRECT);

extern SHORT _loadds FAR PASCAL SetAttribute(LP,SHORT,SHORT,SHORT);

extern short _loadds FAR PASCAL DIBToDevice(LP,WORD,WORD,WORD,
                                            WORD,LPRECT,
                                            LPDRAWMODE,LP, 
                                            LPBITMAPINFO,LPSTR);

extern short _loadds FAR PASCAL DevStretchBlt(LP,short,short,         
                                              short,short,LPBITMAP,
                                              short,short, short,short,
                                              DWORD,LPPBRUSH,
                                              LPDRAWMODE,LPRECT);

extern short _loadds FAR PASCAL StretchDIB(LP,WORD,
                                           WORD,WORD,WORD,WORD,
                                           WORD ,WORD ,WORD ,WORD ,
                                           LP,LPBITMAPINFO,
                                           LPSTR,DWORD,LPPBRUSH,
                                           LPDRAWMODE,LPRECT);

extern short _loadds FAR PASCAL ExtDeviceMode(HWND, HANDLE, LPDEVMODE,
                                              LPSTR, LPSTR, 
                                              LPDEVMODE, LPSTR,
                                              WORD);

extern DWORD _loadds FAR PASCAL DeviceCapabilities(LPSTR,LPSTR,WORD,
                                                   LP,LPDEVMODE);
#if 0
extern WORD _loadds FAR PASCAL DevInstall(HWND, LPSTR, LPSTR,
                                          LPSTR);

extern short _loadds WINAPI ExtDeviceModePropSheet(HINSTANCE,
                                                   LPDEVMODE,
                                                   LPSTR,
                                                   LPSTR,
                                                   LPDEVMODE,
                                                   LPSTR,
                                                   WORD,
                                                   LPFNADDPROPSHEETPAGE,
                                                   LPARAM);
#endif
#endif
#endif

