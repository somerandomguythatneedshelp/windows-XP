/*
 * This file contains the structures and sizes for the devmode of the original
 * Win95 PostScript driver. We need this to upgrade the devmode without losing
 * user settings.
 */

#define PS1_DRIVER_VERSION  0x403

#define  PS1_NUM_CUST_SIZES   3
#define  PS1_MAXPAPERMARGINS  20
#define  PS1_MAXOPTIONSTATES  100


typedef struct
{
   DEVMODE dm;

   WORD   check1;       // Checksum of PSDEVMODE
   WORD   check2;       // Checksum of PSEXTDEVMODE
   DWORD  dwTimeStamp,  // obtained from WPX  PRINTINFO structure.
          dwRandom;     // verifies we are dealing with the same printer
                        //  instance.

   // ------------  PAPER  PROPERTY  SHEET  -----------------------

   // Note: Custom paper has been moved below option state array, as it is
   // considered printer sticky for EXCEL.
   DSPUNITS  DspUnits;    // units in which to display papersizes in Dialog box.

   short Copies;
   LAYOUT  layout ;
   PAP_ORIENT    PaperOrient;  // one to one correspondence to UI control
   MARGINS marginState;        // margin state: default, zero

   //  to determine papersize, source, type, see optionState index.

   // ------------  GRAPHICS  PROPERTY  SHEET  -----------------------
   //
   //  to determine resolution, , see optionState index.

   COLOR  iColorOption;        /* type of color conversion used, DIC, etc. */

   BOOL   bUseImageColorMatching; /* TRUE to use, FALSE to not use */
   COLOR_METHOD iColorMatchingMethod; /* Type of color matching to use */
   RENDERING_INTENT iRenderingIntent; /* Rendering Intent */

   BOOL   useDefaultHalftoneParams ;  // if true driver doesn't attempt to send
                                    // commands to alter halftone parameters
   //  These devmode halftone parameters hold only the user's settings
   //  not the defaults which are kept in the WPX structs on a per
   //  resolution basis.  (stored as tenths of units. ie
   //  an actual ScreenFreq of 60.0  is stored in the DWORD as 600.)

   DWORD   ScreenFrequency;  /* halftone screen frequency */
   DWORD   ScreenAngle;      /* halftone screen angle */

   BOOL  bNegImage;        /* TRUE if negative images requested */
   BOOL  bMirror;          /* TRUE if output should be mirrored */
   BOOL  bColorToBlack;    /* realize only black brushes and pens */
   short Scale;

   // ------------  POSTSCRIPT  PROPERTY  SHEET  -----------------------
   //

   //output flavor stuff
   DIALECT     enumDialect ;    //Indicates type of output from Driver,
                                // eg. PostScript or AI3 generate EPS
                                // output is one of several possible modes

   // ------------  DEVICE OPTIONS  PROPERTY  SHEET  -----------------------

   WORD  privateFlags ;  // was currentICM[2]

   /*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/
   /****!!!! NOTE: DO NOT ADD ANY DOC STICKY FIELDS BELOW THIS. !!!!****/
   /*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/

   // Everything below except the first IND_NUMPREDEFINEDHDRS elements of
   //  the optionstate array are considered printer sticky for EXCEL.

   OPTIONSTATE  optionState[PS1_MAXOPTIONSTATES] ;

   //  you can determine if custom paper size is currently selected
   //  by comparing the current PAPERSIZE option using KeywordGetCurrentOption()
   //  to the value of CustomPageSize  in WPXinfo->PRINTERINFO.DEVCAPS
   //  If this is TRUE, then the value of currentCustPaper indicates
   //  which of the NUM_CUST_SIZES custPapers in the array should be selected.

   WORD       currentCustPaper ;  // which of the three sizes is selected?
   CUSTPAPER  custPaper[PS1_NUM_CUST_SIZES] ;
   // App defined custom sizes not equal to any of the sizes in  the array
   // above are stored here, and currentCustPaper is set to APP_DEFINED.
   float      appCustWidth ;
   float      appCustHeight ;

   // what options are in effect for each MainKeyword
   // the first n elements in this array always refer to the option
   // associated with mainkeyword n.
   // a subset of these n keywords is the InstallableOptions keywords
   // these will occupy indicies from
   //  PrinterInfo.InstallableOptions to n-1.
   // UI and devmode merging code should be aware of this division
   // so they may avoid changing these options.

} PS1_PSDEVMODE, *PPS1_PSDEVMODE, FAR *LPPS1_PSDEVMODE;



// These items should only be modified via ExtDeviceModePropSheet call
// Not advanced dialog setup or extDevMode!  Not via any app !
// these are not job specific settings - should be initialized only
// from win.ini (or driver should supply reasonable defaults).

typedef struct tagPS1_PSDEVMODE2
{
  RECT  revisedPaperMargins[PS1_MAXPAPERMARGINS] ;
  // holds imageable areas for the first 20 papersizes.

  BOOL  fHeader;          /* TRUE=download header per Job */
  BOOL  bErrHandler;      /* TRUE if we should use error handler */
  float fUserVMSelection; /* User selected amount of VM for VM Option */

  BYTE  password[MAXKEYLEN];   //  PPD supplied password for exitserver
  BYTE  defaultICM[2] ;  // placeholder

/* ------------  TT FONT DOWNLOADING  PROPERTY  SHEET  ----------------- */

   TT_DLFMT iDLFontFmt;       // font DL format (Type 3, Type 1, TrueType)
   PS_DLFMT iPS_DLFontFmt;    // font DL format for PS fonts
   FONTSUB  iTTSubsFmtSource; // Source of TT Subs (DL TT, use printer, etc.)
   WORD iMinOutlinePPEM;      // crossover point for Type 1 outlines

/* ------------ printer sticky fields in Postscript dialog ------------- */

  WORD iJobTimeout;            // The job timeout in seconds
  WORD iWaitTimeout;           // The wait timeout in seconds

/* ------------  ADVANCED  POSTSCRIPT  PROPERTY  SHEET  ----------------- */

   BYTEFLAG bfUseLevel2 ;     // Flags that level 2 PostScript should be used

   //  ---- one of these doesn't have a dedicated UI control ---- !
   BOOL  bCompress;                // TRUE if we should ALWAYS compress bitmaps
   PROTOCOLS  iDataOutputFormat;   // Output format (CRTL D or not, BCP, etc.)
   BOOL bSendCtrlDBefore;
   BOOL bSendCtrlDAfter;
   BOOL bIsRotated; // Flag to remember rotated state

/* ------------ this space reserved for driver variables --------------- */

  /* Output dialect variable array */
  BYTE bOutputDialect ;  /* Indicates type of output from Driver,
                          * eg. PostScript or AI3 */
  BOOL bDSC;             /* TRUE if output should conform to DSC */
  BOOL bPJL_Protocol;
  BOOL bVM_Tracking;


  float fMinVM;              // VMOption Lower bound
  float fMaxVM;              // VMOption Upper bound

  WORD  numSlots;         //  number of input slots enum'ed in slotAssign
  BOOL bAllowExitServer;                 //Allow exit server or not.
  BOOL bClearVMPerPage;  // TRUE if clear VM each page

  BOOL  bFavorTT ;   // breaks name ties in favor of TT.


}PS1_PSDEVMODE2, *PPS1_PSDEVMODE2, FAR *LPPS1_PSDEVMODE2;


typedef struct tagPSEXTDEVMODE
{
  PS1_PSDEVMODE  dm;
  PS1_PSDEVMODE2 dm2;
}PS1_PSEXTDEVMODE, *PPS1_PSEXTDEVMODE, FAR *LPPS1_PSEXTDEVMODE;

