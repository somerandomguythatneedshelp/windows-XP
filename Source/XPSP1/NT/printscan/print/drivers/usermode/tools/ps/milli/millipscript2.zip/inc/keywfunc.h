
/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: KEYWFUNC.H                                                   */
/*                                                                           */
/* Description: Contains prototypes for new API to access Keyword from WPX   */
/*              and PSEXTDEVMODE structures.                                 */
/*                                                                           */
/*****************************************************************************/
//  Resource ID where synthetic (driver generated) keywords (strings) begin
#define  MAX_RESOURCE_ID   3000

//  Indicates the first or last keyword in function KeywordNextOrderedKeyword
#define FIRST_LAST_KEYWORD       0xFFFF

// Standard keyword (1 to IND_NUMPREDEFINEDHDRS) indicees for WPX access
//  as defined in  PRINTCAPS.H

#define ID_KEY_PAGESIZE          0
#define ID_KEY_DUPLEXINGINFO     2
#define ID_KEY_DUPLEX            2
#define ID_KEY_INPUTSLOT         3
#define ID_KEY_RESOLUTION        4
#define ID_KEY_OUTPUTBIN         5  
#define ID_KEY_MEDIATYPE         6

// Driver defined Keywords that have no WPX entry
// These strings are accessed directly from driver resources

#define ID_KEY_BASE_INPUTSLOT    3016
#define ID_KEY_PAGEREGION        3085
#define ID_KEY_PAPERDIM          3087
#define ID_KEY_MANUALFEED        3088
#define ID_KEY_BASE_ORIENT       3092
#define ID_KEY_BASE_DUPLEX       3097
#define ID_KEY_PROTOCOL          3106
#define ID_KEY_COPIES            3116
#define ID_KEY_SCALING           3117
#define ID_KEY_CUSTOMPAGE        3121
#define ID_KEY_CUSTOMPAGEPARAMS  3122
#define ID_KEY_MIXEDBINS         3139
#define ID_KEY_LANDSCAPEORIENT   3141
#define ID_BASE_LANDSCAPEORIENT  3142
#define ID_KEY_JCL_STARTJOB      3152
#define ID_KEY_JCL_ENDJOB        3153
#define ID_KEY_JCL_JCLTOPS       3154
 //Leave room for 3 landscape orientation angle options.
#define ID_KEY_SCREENFREQUENCY   3169
#define ID_KEY_JOBPATCHFILE      3175
#define ID_KEY_PATCHFILE         3176

#define ID_KEY_COLOR             11010

#define ID_KEY_CUSTOMWIDTH       11020
#define ID_KEY_CUSTOMHEIGHT      11021
#define ID_KEY_CUSTOMNAME        11022

#define ID_KEY_LAYOUT            11040

#define ID_KEY_INSTALLEDMEMORY      11060
#define ID_KEY_VMOPTION             11061

#define ID_KEY_USER_SCREENFREQUENCY 11067
#define ID_KEY_USER_SCREENANGLE     11068
#define ID_KEY_SCREENFREQUENCY_RES  11069
#define ID_KEY_SCREENANGLE_RES      11070

#define ID_KEY_TTRASTERIZER         3168
#define ID_KEY_PASSWORD             3136
#define ID_KEY_EXITSERVER           3137
#define ID_KEY_PCFILENAME           3166


//  new structs for UI constraint evaluation functions.

typedef struct _tagUICARRAY
{
      WORD wOldOption;
      WORD wNewOption;
} UICARRAY, FAR * LPUICARRAY;

typedef struct _tagUICONFLICT
{
      WORD wMainConstrainer;
      WORD wOptionConstrainer;
      WORD wMainConstrained;
      WORD wOptionConstrained;
} UICONFLICT, FAR * LPUICONFLICT;



// TEMPORARY until Peter's include files are integrated!!

LPPSEXTDEVMODE FAR PASCAL PsExtDevmodeCreateCopy(LPPSEXTDEVMODE);
BOOL FAR PASCAL PsExtDevmodeCopy(LPPSEXTDEVMODE lpDestination, LPPSEXTDEVMODE lpSource);
BOOL FAR PASCAL PsExtDevmodeRead(LPPSEXTDEVMODE lpPSExtDevmode, LPSTR lpszModelName, 
                                 LPSTR lpszPort);
BOOL FAR PASCAL PsExtDevmodeDestroy(LPPSEXTDEVMODE);
WORD FAR PASCAL DrvStateRead(LPPDEVICE, LPPSEXTDEVMODE);

BOOL FAR PASCAL FreePrinter(LPWPXBLOCKS);
BOOL FAR PASCAL TerminateWPXcache();

// Deferences a STRINGREF.dword to obtain a normal far pointer.
// Note however the string may contain NULLs or not be NULL
//  terminated. So you must rely on  stringRef.w.length to determine the
//  actual length of the string.

LPBYTE   FAR  PASCAL  StringRefToLPBYTE(  LPPDEVICE  lppd,
                                          DWORD    dwstringref);
WORD   FAR  PASCAL  CopyStringRefToLPBYTE(LPWPXBLOCKS lpWPXblock, 
                                          LPBYTE lpDest, 
                                          DWORD dwstringref) ;

#ifdef Adobe_Driver
BOOL    NEAR  PASCAL  modifyOptionState(  LPOPTIONSTATE  lpOptionState,
                                          WORD  MainKeywordIndex, 
                                          LPBOOL  lpOptionArray,
                                          WORD    numMainKeyHdrs,
                                          WORD    numOptions,
                                          WORD    maxOption );
#else                                          
BOOL    NEAR  PASCAL  modifyOptionState(  LPOPTIONSTATE  lpOptionState,
                                          WORD  MainKeywordIndex, 
                                          LPBOOL  lpOptionArray,
                                          WORD    numMainKeyHdrs,
                                          WORD    numOptions );
#endif

WORD FAR PASCAL KeywordGetKeywordTranslation(LPPDEVICE lppd, 
                                             WORD KeywordIndex, 
                                             LPSTR translation, WORD Len);
WORD FAR PASCAL KeywordGetMainKeyword(LPPDEVICE lppd, 
                                             WORD KeywordIndex, 
                                             LPSTR MainKeyString, WORD Len);
WORD FAR PASCAL KeywordGetOptionKeyword(LPPDEVICE lppd, WORD KeywordIndex,
                                            WORD OptionIndex, LPSTR keywordString, 
                                            WORD Len);
WORD FAR PASCAL KeywordGetOptionTranslation(LPPDEVICE lppd, WORD KeywordIndex,
                                            WORD OptionIndex, LPSTR translation, 
                                            WORD Len);
BOOL FAR PASCAL KeywordGetNumOfOptions(LPPDEVICE lppd, WORD KeywordIndex, 
                                       LPWORD lpNumOptions);

WORD FAR PASCAL KeywordGetOptionPS(LPPDEVICE lppd, WORD KeywordIndex,
                                   WORD OptionIndex, LPSTR InvocationPS, 
                                   LPWORD lpLen);

BOOL FAR PASCAL KeywordSetOptionPS(LPPDEVICE lppd, WORD KeywordIndex,
                                   WORD OptionIndex, LPSTR InvocationPS);

BOOL    FAR  PASCAL  KeywordOptionConstraintArray( LPPDEVICE  lppd ,
                                                   WORD  MainKeywordIndex, 
                                                   LPBOOL  lpOptionArray);  
BOOL    FAR  PASCAL  IsKeywordOptConstrained(LPPDEVICE  lppd,
                                             WORD  MainKeywordIndex, 
                                             WORD  OptionKeywordIndex);
BOOL    FAR  PASCAL  KeywordGetFirstOptionNotConstrained(LPPDEVICE  lppd,
                                                WORD  MainKeywordIndex, 
                                                LPWORD  lpOptionKeywordIndex);

// The following 2 functions accesses its info from PSEXTDEVMODE
// for PICKONE keyword options
BOOL    FAR  PASCAL  KeywordSetCurrentOption(LPPDEVICE   lppd,
                                             WORD  MainKeywordIndex, 
                                             WORD  OptionIndex);
BOOL    FAR  PASCAL  KeywordGetCurrentOption(LPPDEVICE  lppd,
                                             WORD  MainKeywordIndex, 
                                             LPWORD  lpOptionIndex);

BOOL    FAR  PASCAL  rawKeywordGetCurrentOption(
LPWPXBLOCKS  lpWPXblock ,
LPOPTIONSTATE  lpOptionState ,
WORD  MainKeywordIndex, 
LPWORD  lpOptionIndex) ;

BOOL    FAR  PASCAL  KeywordGetDefaultOption(LPPDEVICE  lppd,
                                             WORD  MainKeywordIndex, 
                                             LPWORD  lpOptionIndex);


// The following 2 functions accesses its info from PSEXTDEVMODE
// for PICKMANY keyword options
BOOL    FAR  PASCAL  KeywordSetCurrentOptionArray( LPPDEVICE  lppd,
                                                   WORD  MainKeywordIndex, 
                                                   LPBOOL  lpOptionArray);
BOOL    FAR  PASCAL  KeywordGetCurrentOptionArray( LPPDEVICE  lppd,
                                                   WORD  MainKeywordIndex, 
                                                   LPBOOL  lpOptionArray);
BOOL  FAR  PASCAL  KeywordSetOptionsToPPDdefault(LPPDEVICE  lppd);

BOOL    FAR  PASCAL   intValidateOptionArray(
LPWPXBLOCKS   lpWPXblock, 
LPPSEXTDEVMODE  lpExtDevMode,
LPUICARRAY lpArray, 
LPUICONFLICT  lpUIConflict); 



BOOL    FAR  PASCAL   validateOptionArray(LPWPXBLOCKS   lpWPXblock, 
                                          LPPSEXTDEVMODE  lpPSExtDevMode) ;

// This function takes the CurrentKeywordIndex (0xFFFF to start process)
// and returns lpKeywordIndex, the next ordered keyword index.
// The process ends if the next ordered keyword in lpKeywordIndex is 0xFFFF

BOOL    FAR  PASCAL  KeywordNextOrderedKeyword( LPPDEVICE  lppd,
                                                LPWORD  lpKeywordIndex, 
                                                WORD  CurrentKeywordIndex);

BOOL    FAR  PASCAL  KeywordGetPPDOrderValue( LPPDEVICE lppd,
                                              WORD   KeywordIndex,
                                              double far *lpcurrPPDOrderValue,
                                              double far *lpnextPPDOrderValue);
#if 0
                     // Parametric keyword stuff 

BOOL FAR PASCAL KeywordGetParamVal(LPPDEVICE lppd, WORD KeywordIndex,
                                   WORD OptionIndex, int ParamType,
                                   VOID FAR *lpVal, WORD MaxParamLen);
BOOL FAR PASCAL KeywordSetParamVal(LPPDEVICE lppd, WORD KeywordIndex,
                                   WORD OptionIndex, int ParamType,
                                   VOID FAR *lpVal);
BOOL FAR PASCAL KeywordGetParamBnds(LPPDEVICE lppd, WORD KeywordIndex,
                                    WORD OptionIndex, int ParamType,
                                    VOID FAR *lpLowLimit, 
                                    VOID FAR *lpHighLimit); 

                  //    Cannot set bounds in WPX
BOOL FAR PASCAL KeywordSetParamBnds(LPPDEVICE lppd, WORD KeywordIndex,
                                    WORD OptionIndex, int ParamType,
                                    VOID FAR *lpLowLimit, 
                                    VOID FAR *lpHighLimit);

BOOL FAR PASCAL SetKeywordParamInt(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode,
                                   WORD KeywordIndex, int ParamID, int Value);
int  FAR PASCAL GetKeywordParamInt(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode,
                                   WORD KeywordIndex, int ParamID); 

#endif //0

/* The routine below is currently a noop. It was previously used to advance
   the current keyword pointer to the selected position and skip a certain
   number of 'Special' keywords in the count. Since all the present 'Special'
   keywords are now in the predefined headers section this routine now
   does nothing unless we give it a purpose again. */

BOOL FAR PASCAL DoesKeywordExistByIndex(LPPDEVICE lppd, WORD KeywordIndex);

BOOL    NEAR  PASCAL   PriorityConstraintArray(
LPWPXBLOCKS   lpWPXblock, 
LPOPTIONSTATE  lpOptionState ,
LPWORD   lpPriorityArray,   //  New!
WORD  MainKeywordIndex, 
LPBOOL  lpOptionArray,
LPUICONFLICT  lpUIConflict,  // New! may be NULL.
LPOPTIONSTATE  lpOldOptionState ) ;

WORD FAR PASCAL GetInputSlotOptionIndex(LPPDEVICE lppd, WORD InputSlotID);
WORD FAR PASCAL GetOpenUIKeywordIndex(LPPDEVICE  lppd ,
                                      LPSTR      lpOpenUIKeyword);

