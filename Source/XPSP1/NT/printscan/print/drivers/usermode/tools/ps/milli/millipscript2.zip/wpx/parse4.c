/*  parse4.c  - functions to set paper and slot IDs  *
 *       also support for LanguageEncoding keyword   */


#include <string.h>
#include  "generic.h"

#pragma code_seg(_PARSE1SEG)

struct
{
   WORD  width ;
   WORD  length ;
   WORD  paperID ;
   BOOL  transverse;   
   BOOL  assigned ;
}  paperIDtable[] = 
{
   { 850,1100,DMPAPER_LETTER       ,FALSE, FALSE},   // Letter
   { 850,1100,DMPAPER_LETTERSMALL  ,FALSE, FALSE},   // LetterSmall
   {1100,1700,DMPAPER_TABLOID      ,FALSE, FALSE},   // Tabloid
   {1700,1100,DMPAPER_LEDGER       ,FALSE, FALSE},   // Ledger
   { 850,1400,DMPAPER_LEGAL        ,FALSE, FALSE},   // Legal
   { 550, 850,DMPAPER_STATEMENT    ,FALSE, FALSE},   // Statement
   { 725,1050,DMPAPER_EXECUTIVE    ,FALSE, FALSE},   // Executive
   {1169,1654,DMPAPER_A3           ,FALSE, FALSE},   // A3
   { 827,1169,DMPAPER_A4           ,FALSE, FALSE},   // A4
   { 827,1169,DMPAPER_A4SMALL      ,FALSE, FALSE},   // A4 Small
   { 583, 827,DMPAPER_A5           ,FALSE, FALSE},   // A5
   {1012,1433,DMPAPER_B4           ,FALSE, FALSE},   // B4 JIS
   { 717,1012,DMPAPER_B5           ,FALSE, FALSE},   // B5 JIS
   { 850,1300,DMPAPER_FOLIO        ,FALSE, FALSE},   // Folio
   { 846,1083,DMPAPER_QUARTO       ,FALSE, FALSE},   // Quarto
   {1000,1400,DMPAPER_10X14        ,FALSE, FALSE},   // 10x14
   {1100,1700,DMPAPER_11X17        ,FALSE, FALSE},   // 11x17
   { 850,1100,DMPAPER_NOTE         ,FALSE, FALSE},   // Note 8.5 x 11
   { 388, 888,DMPAPER_ENV_9        ,FALSE, FALSE},   // Envelope #9
   { 413, 950,DMPAPER_ENV_10       ,FALSE, FALSE},   // Envelope #10
   { 450,1038,DMPAPER_ENV_11       ,FALSE, FALSE},   // Envelope #11
   { 475,1100,DMPAPER_ENV_12       ,FALSE, FALSE},   // Envelope #12
   { 500,1150,DMPAPER_ENV_14       ,FALSE, FALSE},   // Envelope #14
   {1700,2200,DMPAPER_CSHEET       ,FALSE, FALSE},   // C size sheet
   {2200,3400,DMPAPER_DSHEET       ,FALSE, FALSE},   // D size sheet
   {3400,4400,DMPAPER_ESHEET       ,FALSE, FALSE},   // E size sheet
   { 433, 866,DMPAPER_ENV_DL       ,FALSE, FALSE},   // Envelope DL
   { 638, 902,DMPAPER_ENV_C5       ,FALSE, FALSE},   // Envelope C5
   {1276,1803,DMPAPER_ENV_C3       ,FALSE, FALSE},   // Envelope C3
   { 902,1276,DMPAPER_ENV_C4       ,FALSE, FALSE},   // Envelope C4
   { 449, 638,DMPAPER_ENV_C6       ,FALSE, FALSE},   // Envelope C6
   { 449, 902,DMPAPER_ENV_C65      ,FALSE, FALSE},   // Envelope C65
   { 984,1390,DMPAPER_ENV_B4       ,FALSE, FALSE},   // Envelope B4
   { 693, 984,DMPAPER_ENV_B5       ,FALSE, FALSE},   // Envelope B5
   { 693, 492,DMPAPER_ENV_B6       ,FALSE, FALSE},   // Envelope B6
   { 433, 906,DMPAPER_ENV_ITALY    ,FALSE, FALSE},   // Envelope 110x230
   { 388, 750,DMPAPER_ENV_MONARCH  ,FALSE, FALSE},   // Envelope Monarch
   { 363, 650,DMPAPER_ENV_PERSONAL ,FALSE, FALSE},   // Envelope 6 3/4
   {1488,1100,DMPAPER_FANFOLD_US   ,FALSE, FALSE},   // US Standard Fanfold
   { 850,1200,DMPAPER_FANFOLD_STD_GERMAN, FALSE, FALSE},   // German Standard Fanfold
   { 850,1300,DMPAPER_FANFOLD_LGL_GERMAN, FALSE, FALSE},   // German Legal Fanfold
   { 984,1390,DMPAPER_ISO_B4       ,FALSE, FALSE},   // B4 ISO 
   { 394, 583,DMPAPER_JAPANESE_POSTCARD, FALSE, FALSE},    // Japanese postcard
   { 900,1100,DMPAPER_9X11         ,FALSE,FALSE},   // 9 x 11 in
   {1000,1100,DMPAPER_10X11        ,FALSE,FALSE},   // 10 x 11 in
   {1500,1100,DMPAPER_15X11        ,FALSE,FALSE},   // 15 x 11 in
   { 866, 866,DMPAPER_ENV_INVITE   ,FALSE,FALSE},   // Envelope Invite   
   { 950,1200,DMPAPER_LETTER_EXTRA ,FALSE,FALSE},   // Letter Extra
   { 950,1500,DMPAPER_LEGAL_EXTRA  ,FALSE,FALSE},   // Legal Extra
   {1169,1800,DMPAPER_TABLOID_EXTRA,FALSE,FALSE},   // Tabloid Extra
   { 927,1269,DMPAPER_A4_EXTRA     ,FALSE,FALSE},   // A4 Extra
   { 850,1100,DMPAPER_LETTER_TRANSVERSE, TRUE, FALSE},   // Letter Transverse
   { 827,1169,DMPAPER_A4_TRANSVERSE, TRUE, FALSE},   // A4 Transverse
   { 950,1200,DMPAPER_LETTER_EXTRA_TRANSVERSE, TRUE, FALSE},   // Letter Extra Transverse
   { 894,1402,DMPAPER_A_PLUS       ,FALSE,FALSE},   // SuperA/SuperA/A4
   {1201,1917,DMPAPER_B_PLUS       ,FALSE,FALSE},   // SuperB/SuperB/A3
   { 850,1269,DMPAPER_LETTER_PLUS  ,FALSE,FALSE},   // Letter Plus
   { 827,1299,DMPAPER_A4_PLUS      ,FALSE,FALSE},   // A4 Plus
   { 583, 827,DMPAPER_A5_TRANSVERSE, TRUE,FALSE},   // A5 Transverse
   { 717,1012,DMPAPER_B5_TRANSVERSE, TRUE,FALSE},   // B5 Transverse
   {1268,1752,DMPAPER_A3_EXTRA     ,FALSE,FALSE},   // A3 Extra
   { 685, 925,DMPAPER_A5_EXTRA     ,FALSE,FALSE},   // A5 Extra
   { 791,1087,DMPAPER_B5_EXTRA     ,FALSE,FALSE},   // B5 Extra
   {1654,2339,DMPAPER_A2           ,FALSE,FALSE},   // A2
   {1169,1654,DMPAPER_A3_TRANSVERSE, TRUE,FALSE},   // A3 Transverse
   {1268,1752,DMPAPER_A3_EXTRA_TRANSVERSE, TRUE, FALSE},   // A3 Extra Transverse
   // Far East Paper sizes:
   {787,  583,DMPAPER_DBL_JAPANESE_POSTCARD,FALSE,FALSE}, // Double Japanese Postcard
   {413,  583,DMPAPER_A6           ,FALSE,FALSE},   // A6
   {945, 1307,DMPAPER_JENV_KAKU2   ,FALSE,FALSE},   // Japanese Envelope Kaku #2
   {850, 1090,DMPAPER_JENV_KAKU3   ,FALSE,FALSE},   // Japanese Envelope Kaku #3
   {472,  925,DMPAPER_JENV_CHOU3   ,FALSE,FALSE},   // Japanese Envelope Chou #3  
   {354,  807,DMPAPER_JENV_CHOU4   ,FALSE,FALSE},   // Japanese Envelope Chou #4  
   {1100, 850,DMPAPER_LETTER_ROTATED,FALSE,FALSE},   // Letter Rotate 11 x 8 1/2 11 in
   {1654,1169,DMPAPER_A3_ROTATED   ,FALSE,FALSE},   // A3 Rotate 420 x 297 mm
   {1169, 827,DMPAPER_A4_ROTATED   ,FALSE,FALSE},   // A4 Rotate 297 x 210 mm
   {827,  583,DMPAPER_A5_ROTATED   ,FALSE,FALSE},   // A5 Rotate 210 x 148 mm
   {1433,1012,DMPAPER_B4_JIS_ROTATED,FALSE,FALSE},   // B4 (JIS) Rotate 364 x 257 mm
   {1012, 717,DMPAPER_B5_JIS_ROTATED,FALSE,FALSE},   // B5 (JIS) Rotate 257 x 182 mm
   {583,  394,DMPAPER_JAPANESE_POSTCARD_ROTATED,FALSE,FALSE},// Japanese Postcard Rotate 148 x 100 mm
   {583,  787,DMPAPER_DBL_JAPANESE_POSTCARD_ROTATED,FALSE,FALSE},// Double Japanese Postcard Rotate 148 x 200 mm
   {583,  413,DMPAPER_A6_ROTATED   ,FALSE,FALSE},// A6 Rotate 148 x 105 mm
   {1307, 945,DMPAPER_JENV_KAKU2_ROTATED,FALSE,FALSE},// Japanese Envelope Kaku #2 Rotate
   {1090, 850,DMPAPER_JENV_KAKU3_ROTATED,FALSE,FALSE},// Japanese Envelope Kaku #3 Rotate
   {925,  472,DMPAPER_JENV_CHOU3_ROTATED,FALSE,FALSE},// Japanese Envelope Chou #3 Rotate
   {925,  472,DMPAPER_JENV_CHOU4_ROTATED,FALSE,FALSE},// Japanese En1velope Chou #4 Rotate
   // more Far East paper sizes  
   {504,  717,DMPAPER_B6_JIS			,FALSE,FALSE},    /* B6 (JIS) 128 x 182 mm           */
   {717,  504,DMPAPER_B6_JIS_ROTATED	,FALSE,FALSE}, /* B6 (JIS) Rotated 182 x 128 mm   */
   {1200,1100,DMPAPER_12X11			,FALSE,FALSE},    /* 12 x 11 in                      */
   {413,  925,DMPAPER_JENV_YOU4		,FALSE,FALSE},    /* Japanese Envelope You #4        */
   {925,  413,DMPAPER_JENV_YOU4_ROTATED	,FALSE,FALSE},/* Japanese Envelope You #4 Rotated*/
   {575,  850,DMPAPER_P16K				,FALSE,FALSE},    /* PRC 16K 146 x 215 mm            */
   {382,  595,DMPAPER_P32K				,FALSE,FALSE},    /* PRC 32K 97 x 151 mm             */
   {382,  595,DMPAPER_P32KBIG			,FALSE,FALSE},    /* PRC 32K(Big) 97 x 151 mm        */
   {400,  650,DMPAPER_PENV_1			,FALSE,FALSE},    /* PRC Envelope #1 102 x 165 mm    */
   {400,  690,DMPAPER_PENV_2			,FALSE,FALSE},    /* PRC Envelope #2 102 x 176 mm    */
   {490,  690,DMPAPER_PENV_3			,FALSE,FALSE},    /* PRC Envelope #3 125 x 176 mm    */
   {433,  820,DMPAPER_PENV_4			,FALSE,FALSE},    /* PRC Envelope #4 110 x 208 mm    */
   {433,  866,DMPAPER_PENV_5			,FALSE,FALSE},    /* PRC Envelope #5 110 x 220 mm    */
   {470,  900,DMPAPER_PENV_6			,FALSE,FALSE},    /* PRC Envelope #6 120 x 230 mm    */
   {630,  900,DMPAPER_PENV_7			,FALSE,FALSE},    /* PRC Envelope #7 160 x 230 mm    */
   {470, 1220,DMPAPER_PENV_8			,FALSE,FALSE},    /* PRC Envelope #8 120 x 309 mm    */
   {900, 1275,DMPAPER_PENV_9			,FALSE,FALSE},    /* PRC Envelope #9 229 x 324 mm    */
   {1275,1800,DMPAPER_PENV_10			,FALSE,FALSE},    /* PRC Envelope #10 324 x 458 mm   */
   {850,  575,DMPAPER_P16K_ROTATED	,FALSE,FALSE},    /* PRC 16K Rotated                 */
   {595,  382,DMPAPER_P32K_ROTATED	,FALSE,FALSE},    /* PRC 32K Rotated                 */
   {595,  382,DMPAPER_P32KBIG_ROTATED	,FALSE,FALSE}, /* PRC 32K(Big) Rotated            */
   {650,  400,DMPAPER_PENV_1_ROTATED	,FALSE,FALSE}, /* PRC Envelope #1 Rotated 165 x 102 mm*/
   {690,  400,DMPAPER_PENV_2_ROTATED	,FALSE,FALSE}, /* PRC Envelope #2 Rotated 176 x 102 mm*/
   {690,  490,DMPAPER_PENV_3_ROTATED	,FALSE,FALSE}, /* PRC Envelope #3 Rotated 176 x 125 mm*/
   {820,  433,DMPAPER_PENV_4_ROTATED	,FALSE,FALSE}, /* PRC Envelope #4 Rotated 208 x 110 mm*/
   {866,  433,DMPAPER_PENV_5_ROTATED	,FALSE,FALSE}, /* PRC Envelope #5 Rotated 220 x 110 mm*/
   {900,  470,DMPAPER_PENV_6_ROTATED	,FALSE,FALSE}, /* PRC Envelope #6 Rotated 230 x 120 mm*/
   {900,  630,DMPAPER_PENV_7_ROTATED	,FALSE,FALSE}, /* PRC Envelope #7 Rotated 230 x 160 mm*/
   {1220, 470,DMPAPER_PENV_8_ROTATED	,FALSE,FALSE}, /* PRC Envelope #8 Rotated 309 x 120 mm*/
   {1275, 900,DMPAPER_PENV_9_ROTATED	,FALSE,FALSE}, /* PRC Envelope #9 Rotated 324 x 229 mm*/
   {1800,1275,DMPAPER_PENV_10_ROTATED	,FALSE,FALSE}, /* PRC Envelope #10 Rotated 458 x 324 mm */ 
   {   0,   0, 0, FALSE, FALSE}   // end of List
} ;

BOOL   scaled = FALSE ;

struct
{
   LPBYTE  slotname;
   WORD    slotID ;
}
slotIDtable[] =
{
   { "Upper",       DMBIN_UPPER } ,
   { "Lower",       DMBIN_LOWER } ,
   { "Middle",      DMBIN_MIDDLE } ,
   { "Cassette",     DMBIN_CASSETTE },
   { "LargeCapacity",DMBIN_LARGECAPACITY },
   { "LargeFormat",  DMBIN_LARGEFMT },
   { "AnySmallFormat",  DMBIN_SMALLFMT },
   { "Envelope",  DMBIN_ENVELOPE },
   { "", 0}
} ;

BYTE  ISOLatin1Table[256];              /* used as extern in parse2.c   */

void  FAR   PASCAL   InitISOLatin1Table(void)
{
   WORD  i;

   for( i = 0 ; i < 256 ; i++)
      ISOLatin1Table[i] = (BYTE)i ;

   ISOLatin1Table[39] = 146 ;
   ISOLatin1Table[96] = 145 ;
   ISOLatin1Table[145] = 96 ;
   ISOLatin1Table[146] = 180 ;
   ISOLatin1Table[148] = 152 ;
   ISOLatin1Table[149] = 175 ;
   ISOLatin1Table[152] = 168 ;
}


BOOL  FAR   PASCAL   EncodeString(LPBYTE  table, STRINGREF   string)
{
   LPBYTE  lpString ;
   WORD    j ;

   lpString = StringRefToLP(string) ;

   for(j = 0 ; j < string.w.length ; j++)
   {
      lpString[j] = table[lpString[j]] ;
   }

   return(TRUE);
}


BOOL  NEAR   PASCAL   setSlotID(
STRINGREF   optionName ,
LPINPUTSLOTINFO   lpExtraInputSlotInfo, 
LPWORD   lpUndefinedID  )
{
   extern  LPBYTE   lpStringPtr ; 
   LPBYTE  lpStringTable ;
   WORD    j ;

   lpStringTable = (LPBYTE)MAKELONG(0, HIWORD(lpStringPtr));

   for(j = 0 ; slotIDtable[j].slotID ; j++)
   {
      if(!strtblcmp(optionName.dword, lpStringTable, slotIDtable[j].slotname))
      {
         lpExtraInputSlotInfo->slotID = slotIDtable[j].slotID ;
         return(TRUE);
      }
   }
   lpExtraInputSlotInfo->slotID = (*lpUndefinedID)++ ;
   return(TRUE);
}


//  first pass: match papers only by paper dimension.
//  using name match to break ties.

BOOL  NEAR   PASCAL   setPaperID(  
HPBYTE   paperName ,
LPPAPERINFO   lpExtraPaperInfo, 
LPWORD   lpUndefinedID  )
{
   WORD  j;

   for(j = 0 ; paperIDtable[j].paperID  ; j++)
   {  // tolerance of 5 points (refer to the Red book, p.233)
      if(lpExtraPaperInfo->width  >= paperIDtable[j].width  - 5 &&
         lpExtraPaperInfo->width  <= paperIDtable[j].width  + 5 &&
         lpExtraPaperInfo->length >= paperIDtable[j].length - 5 &&
         lpExtraPaperInfo->length <= paperIDtable[j].length + 5 &&
         ((_fstrstr(paperName, "Transverse") && paperIDtable[j].transverse) || 
          (!_fstrstr(paperName, "Transverse") && !paperIDtable[j].transverse)))
      {
         if(!paperIDtable[j].assigned)
         {
            lpExtraPaperInfo->paperID = paperIDtable[j].paperID ;
            paperIDtable[j].assigned = TRUE ;
            return(TRUE);
         }
      }
   }
   lpExtraPaperInfo->paperID = (*lpUndefinedID)++ ;
   return(TRUE);
}



//  ensure papersize table is in points!


void  NEAR   PASCAL   scalePaperIDtable( void ) 
{
   WORD  j;

   for(j = 0 ; paperIDtable[j].paperID  ; j++)
      paperIDtable[j].assigned = FALSE ;

   if(scaled)  // hasn't this been done already ?
      return;

   for(j = 0 ; paperIDtable[j].paperID  ; j++)
   {
      paperIDtable[j].width = MulDiv(paperIDtable[j].width, 72, 100) ;
      paperIDtable[j].length = MulDiv(paperIDtable[j].length, 72, 100) ;
   }
   scaled = TRUE ;
}
