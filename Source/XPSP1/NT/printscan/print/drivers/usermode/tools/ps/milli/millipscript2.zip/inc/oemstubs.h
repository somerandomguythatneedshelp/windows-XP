#ifdef Adobe_Driver                               

typedef struct _OEMFILTER_HEADER
{   
    STRINGREF       refModuleName;
    STRINGREF       refUserString;
    ARRAYREF        refOEMData;
} OEMFILTERHEADER, FAR *LPOEMFILTERHEADER; 

#endif

#define DRV_VERSION 0x0410                  // define driver version number
                                                    // to be used in OEMInitDLL()  
typedef struct
{
  HINSTANCE               hOEMCustDll;
  HINSTANCE               hOEMFilterDll;
  LPOEMINITDLL            lpOEMInitDll;
  LPOEMBEGINSESSION       lpOEMBeginSession;
  LPOEMDEVINSTALL         lpOEMDevInstall;
  LPOEMGETPROPERTYPAGES   lpOEMGetPropertyPages;
  LPOEMDEVICECAPABILITIES lpOEMDeviceCapabilities;
  LPOEMSTARTDOC           lpOEMStartDoc;
  LPOEMENDDOC             lpOEMEndDoc;
  LPOEMABORTDOC           lpOEMAbortDoc;
  LPOEMINSERTPSBEFORE     lpOEMInsertPSBefore;
  LPOEMCHANGEDRIVERPS     lpOEMChangeDriverPS;
  LPOEMINSERTPSAFTER      lpOEMInsertPSAfter;
  LPOEMVALIDATEDEVMODE    lpOEMValidateDevmode;

#ifdef Adobe_Driver  
  // Filter functions
  LPOEMOPENJOB        lpOEMOpenJob; 
  LPOEMSTARTSPOOLPAGE lpOEMStartSpoolPage;
  LPOEMWRITESPOOL     lpOEMWriteSpool;
  LPOEMENDSPOOLPAGE   lpOEMEndSpoolPage;
  LPOEMDELETEJOB      lpOEMDeleteJob;
  LPOEMCLOSEJOB       lpOEMCloseJob;
#endif

  LPOEMENDSESSION     lpOEMEndSession;
  LPOEMTERMDLL        lpOEMTermDll;

  /* Important data */
  WORD                wEntry;

#ifdef Adobe_Driver
  // Filter information
  BOOL                bOEMFilter;
#endif
  
  WORD                flDllType;           
  /* Important pointers */
  LPPSEXTDEVMODE      lpPSExtDevmode;
  LPPDEVICE           lppd;
  LPDRIVERINFO        lpDrvInfo;
  HANDLE              hOEM;
} OEMINFO, FAR *LPOEMINFO;


BOOL FAR PASCAL GetPCFileNameFromWPX(LPSTR WPXfileName, LPSTR lpPCFileName);

HANDLE FAR PASCAL OEMInitDllStub(DRIVERINFOT FAR *lpDrvInfo,LPSTR lpFileName,
                             int iOEMDllType, WORD flEntry);

int FAR PASCAL OEMDevInstallStub(HANDLE hOemCust,
                             HWND hWnd,
                             LPSTR lpszModelName,
                             LPSTR lpszOldPort,
                             LPSTR lpszNewPort);

BOOL FAR PASCAL OEMGetPropertyPagesStub(HANDLE hOemCust,
                             LPPROPSHEETPAGE lpPropSheetArray,
                             int FAR *lpNumOEMPropPages,
                             DWORD FAR *lpdwDriverPropPagesToDisplay);

BOOL FAR PASCAL OEMDeviceCapabilitiesStub(HANDLE hOemCust, 
                             LPSTR lpszDevice, 
                             LPSTR lpszPort, 
                             WORD  fwCapability, 
                             LPSTR lpszOutput,
                             DWORD *lpdwRetVal);

SHORT FAR PASCAL OEMStartDocStub(HANDLE hOemCust,
                             LPSTR  lpJobName,
                             WORD   wPrintJobType);
WORD FAR PASCAL OEMEndDocStub(HANDLE hOemCust);

WORD FAR PASCAL OEMEndSessionStub(HANDLE hOemCust);
                             
                             
void FAR PASCAL OEMAbortDocStub(HANDLE hOemCust);

void FAR PASCAL OEMInsertPSBeforeStub(HANDLE hContext,
                                      LPPDEVICE lppd,
                                      DWORD dwPSIndex);
void FAR PASCAL OEMChangeDriverPSStub(HANDLE hContext,
                                      LPPDEVICE lppd,
                                      DWORD dwPSIndex,
                                      LPSTR FAR *lplpDriverPS,
                                      unsigned FAR *lpDriverPSLen);
void FAR PASCAL OEMInsertPSAfterStub(HANDLE hContext,
                                     LPPDEVICE lppd,
                                     DWORD dwPSIndex);
void FAR PASCAL CallOEMSendPSStub(LPPDEVICE lppd, DWORD dwPSIndex,
                                  LPSTR lpDriverPS,
                                  LONG lLength);
void FAR PASCAL OEMSetDllExist(LPSTR lpszFriendly,
                               int iOEMDllType, BOOL bExist);
BOOL FAR PASCAL OEMGetDllExist(LPPDEVICE lppd, int iOEMDllType);
void FAR PASCAL OEMTermDllStub(HANDLE hOemCust);

void FAR PASCAL OEMValidateDevmodeStub(HANDLE hContext);

#ifdef Adobe_Driver
// Filter support functions

#define FILTEROUTPUT(lpOEMInfo) ((lpOEMInfo) && (lpOEMInfo)->bOEMFilter)
                                
HANDLE FAR PASCAL CallOEMOpenJobStub(LPPDEVICE lppd,
                                     LPSTR  lpOutput,
                                     LPSTR  lpTitle,
                                     HDC    hdc
                                    );

int FAR PASCAL CallOEMStartSpoolPageStub(LPPDEVICE lppd);

int FAR PASCAL CallOEMWriteSpoolStub(LPPDEVICE lppd, 
                                     LPSTR  lpData,
                                     WORD   cch
                                    );
int FAR PASCAL CallOEMEndSpoolPageStub(LPPDEVICE lppd);

int FAR PASCAL CallOEMDeleteJobStub(LPPDEVICE lppd,
                                    WORD    wDummy
                                   );
int FAR PASCAL CallOEMCloseJobStub(LPPDEVICE lppd);

HANDLE FAR PASCAL OEMOpenJobStub(HANDLE hContext,
                                 LPSTR  lpOutput,
                                 LPSTR  lpTitle,
                                 HDC    hdc,
                                 WORD   wFilters,
                                 LPOEMFILTERINFO lpFilterInfo
                                ); 

int FAR PASCAL OEMStartSpoolPageStub(HANDLE hContext, HANDLE hJob);

int FAR PASCAL OEMWriteSpoolStub(HANDLE hContext,
                                 HANDLE hJob, 
                                 LPSTR  lpData,
                                 WORD   cch
                                );
                                
int FAR PASCAL OEMEndSpoolPageStub(HANDLE hContext, HANDLE hJob);

int FAR PASCAL OEMDeleteJobStub(HANDLE  hContext,
                                HANDLE  hJob,
                                WORD    wDummy
                               );

int FAR PASCAL OEMCloseJobStub(HANDLE hContext, HANDLE hJob);

#endif
                  
/* Macros to eliminate code in the Microsoft version of the driver */
#define AdobeOEMInitDllStub(a,b,c,d)        OEMInitDllStub(a,b,c,d)
#define AdobeOEMDevInstallStub(a,b,c,d,e)   OEMDevInstallStub(a,b,c,d,e)
#define AdobeOEMGetPropertyPagesStub(a,b,c,d) OEMGetPropertyPagesStub(a,b,c,d) 
#define AdobeOEMDeviceCapabilitiesStub(a,b,c,d,e,f) OEMDeviceCapabilitiesStub(a,b,c,d,e,f) 
#define AdobeOEMStartDocStub(a,b,c)         OEMStartDocStub(a,b,c)
#define AdobeOEMEndDocStub(a)               OEMEndDocStub(a)
#define AdobeOEMAbortDocStub(a)             OEMAbortDocStub(a)
#define AdobeOEMTermDllStub(a)              OEMTermDllStub(a)
#define AdobeOEMSendPSStub(a,b,c,d)         CallOEMSendPSStub(a,b,c,d)
#define AdobeOEMEndSessionStub(a)           OEMEndSessionStub(a) // new
#define AdobeOEMValidateDevmode(a)          OEMValidateDevmodeStub((a))

// Filter Functions
#ifdef Adobe_Driver 
#define AdobeOEMOpenJobStub(a,b,c,d)        CallOEMOpenJobStub((a),(b),(c),(d))
#define AdobeOEMCloseJobStub(a)             CallOEMCloseJobStub((a))
#define AdobeOEMDeleteJobStub(a,b)          CallOEMDeleteJobStub((a),(b))
#define AdobeOEMStartSpoolPageStub(a)       CallOEMStartSpoolPageStub((a)) 
#define AdobeOEMWriteSpoolStub(a,b,c)       CallOEMWriteSpoolStub((a),(b),(c))
#define AdobeOEMEndSpoolPageStub(a)         CallOEMEndSpoolPageStub((a))
#else
//#define AdobeOEMSendPSStub(a,b,c,d)         PortWrite((a),(c),(d))
#define AdobeOEMOpenJobStub(a,b,c,d)        OpenJob((LPSTR)(b),(LPSTR)(c),(HDC)(d))
#define AdobeOEMCloseJobStub(a)             CloseJob((HANDLE)((LPPDEVICE)(a))->hPortHandle)
#define AdobeOEMDeleteJobStub(a,b)          DeleteJob((HANDLE)((LPPDEVICE)(a))->hPortHandle,(b))

#define AdobeOEMStartSpoolPageStub(a)       StartSpoolPage((HANDLE)((LPPDEVICE)(a))->hPortHandle)
#define AdobeOEMWriteSpoolStub(a,b,c)       WriteSpool((HANDLE)((LPPDEVICE)(a))->hPortHandle,(LPSTR)(b),(WORD)(c))
#define AdobeOEMEndSpoolPageStub(a)         EndSpoolPage((HANDLE)((LPPDEVICE)(a))->hPortHandle)

#endif

