/* CM_VerSion charmap.c atm05 1.2 09045.eco sum= 34668 */
/* CM_VerSion charmap.c atm04 1.2 07592.eco sum= 60396 */
/*
  charmap.c

Copyright (c) 1988-1990 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks
of Adobe Systems Incorporated.

Original version:
Edit History:
Scott Byer: Thu Jul 12 17:40:11 1990
Ivor Durham: Wed Sep 28 08:27:19 1988
Joe Pasqua: Tue Jan 10 15:03:35 1989
Jim Sandman: Thu Aug 31 09:50:41 1989
End Edit History.
*/

#include "parseglu.h"         

char *standardCharacters[ATM_NUM_STANDARD_CHARACTERS] =  /* 229, parseglu.h */
	{
	".notdef",	/* 0 */
	"A",		/* 1 */
	"AE",		/* 2 */
	"Aacute",	/* 3 */
	"Acircumflex",	/* 4 */
	"Adieresis",	/* 5 */
	"Agrave",	/* 6 */
	"Aring",	/* 7 */
	"Atilde",	/* 8 */
	"B",		/* 9 */
	"C",		/* 10 */
	"Ccedilla",	/* 11 */
	"D",		/* 12 */
	"E",		/* 13 */
	"Eacute",	/* 14 */
	"Ecircumflex",	/* 15 */
	"Edieresis",	/* 16 */
	"Egrave",	/* 17 */
	"Eth",		/* 18 */
	"F",		/* 19 */
	"G",		/* 20 */
	"H",		/* 21 */
	"I",		/* 22 */
	"Iacute",	/* 23 */
	"Icircumflex",	/* 24 */
	"Idieresis",	/* 25 */
	"Igrave",	/* 26 */
	"J",		/* 27 */
	"K",		/* 28 */
	"L",		/* 29 */
	"Lslash",	/* 30 */
	"M",		/* 31 */
	"N",		/* 32 */
	"Ntilde",	/* 33 */
	"O",		/* 34 */
	"OE",		/* 35 */
	"Oacute",	/* 36 */
	"Ocircumflex",	/* 37 */
	"Odieresis",	/* 38 */
	"Ograve",	/* 39 */
	"Oslash",	/* 40 */
	"Otilde",	/* 41 */
	"P",		/* 42 */
	"Q",		/* 43 */
	"R",		/* 44 */
	"S",		/* 45 */
	"Scaron",	/* 46 */
	"T",		/* 47 */
	"Thorn",	/* 48 */
	"U",		/* 49 */
	"Uacute",	/* 50 */
	"Ucircumflex",	/* 51 */
	"Udieresis",	/* 52 */
	"Ugrave",	/* 53 */
	"V",		/* 54 */
	"W",		/* 55 */
	"X",		/* 56 */
	"Y",		/* 57 */
	"Yacute",	/* 58 */
	"Ydieresis",	/* 59 */
	"Z",		/* 60 */
	"Zcaron",	/* 61 */
	"a",		/* 62 */
	"aacute",	/* 63 */
	"acircumflex",	/* 64 */
	"acute",	/* 65 */
	"adieresis",	/* 66 */
	"ae",		/* 67 */
	"agrave",	/* 68 */
	"ampersand",	/* 69 */
	"aring",	/* 70 */
	"asciicircum",	/* 71 */
	"asciitilde",	/* 72 */
	"asterisk",	/* 73 */
	"at",		/* 74 */
	"atilde",	/* 75 */
	"b",		/* 76 */
	"backslash",	/* 77 */
	"bar",		/* 78 */
	"braceleft",	/* 79 */
	"braceright",	/* 80 */
	"bracketleft",	/* 81 */
	"bracketright",	/* 82 */
	"breve",	/* 83 */
	"brokenbar",	/* 84 */
	"bullet",	/* 85 */
	"c",		/* 86 */
	"caron",	/* 87 */
	"ccedilla",	/* 88 */
	"cedilla",	/* 89 */
	"cent",		/* 90 */
	"circumflex",	/* 91 */
	"colon",	/* 92 */
	"comma",	/* 93 */
	"copyright",	/* 94 */
	"currency",	/* 95 */
	"d",		/* 96 */
	"dagger",	/* 97 */
	"daggerdbl",	/* 98 */
	"degree",	/* 99 */
	"dieresis",	/* 100 */
	"divide",	/* 101 */
	"dollar",	/* 102 */
	"dotaccent",	/* 103 */
	"dotlessi",	/* 104 */
	"e",		/* 105 */
	"eacute",	/* 106 */
	"ecircumflex",	/* 107 */
	"edieresis",	/* 108 */
	"egrave",	/* 109 */
	"eight",	/* 110 */
	"ellipsis",	/* 111 */
	"emdash",	/* 112 */
	"endash",	/* 113 */
	"equal",	/* 114 */
	"eth",		/* 115 */
	"exclam",	/* 116 */
	"exclamdown",	/* 117 */
	"f",		/* 118 */
	"fi",		/* 119 */
	"five",		/* 120 */
	"fl",		/* 121 */
	"florin",	/* 122 */
	"four",		/* 123 */
	"fraction",	/* 124 */
	"g",		/* 125 */
	"germandbls",	/* 126 */
	"grave",	/* 127 */
	"greater",	/* 128 */
	"guillemotleft",/* 129 */
	"guillemotright",/* 130 */
	"guilsinglleft",/* 131 */
	"guilsinglright",/* 132 */
	"h",		/* 133 */
	"hungarumlaut",	/* 134 */
	"hyphen",	/* 135 */
	"i",		/* 136 */
	"iacute",	/* 137 */
	"icircumflex",	/* 138 */
	"idieresis",	/* 139 */
	"igrave",	/* 140 */
	"j",		/* 141 */
	"k",		/* 142 */
	"l",		/* 143 */
	"less",		/* 144 */
	"logicalnot",	/* 145 */
	"lslash",	/* 146 */
	"m",		/* 147 */
	"macron",	/* 148 */
	"minus",	/* 149 */
	"mu",		/* 150 */
	"multiply",	/* 151 */
	"n",		/* 152 */
	"nine",		/* 153 */
	"ntilde",	/* 154 */
	"numbersign",	/* 155 */
	"o",		/* 156 */
	"oacute",	/* 157 */
	"ocircumflex",	/* 158 */
	"odieresis",	/* 159 */
	"oe",		/* 160 */
	"ogonek",	/* 161 */
	"ograve",	/* 162 */
	"one",		/* 163 */
	"onehalf",	/* 164 */
	"onequarter",	/* 165 */
	"onesuperior",	/* 166 */
	"ordfeminine",	/* 167 */
	"ordmasculine",	/* 168 */
	"oslash",	/* 169 */
	"otilde",	/* 170 */
	"p",		/* 171 */
	"paragraph",	/* 172 */
	"parenleft",	/* 173 */
	"parenright",	/* 174 */
	"percent",	/* 175 */
	"period",	/* 176 */
	"periodcentered",/* 177 */
	"perthousand",	/* 178 */
	"plus",		/* 179 */
	"plusminus",	/* 180 */
	"q",		/* 181 */
	"question",	/* 182 */
	"questiondown",	/* 183 */
	"quotedbl",	/* 184 */
	"quotedblbase",	/* 185 */
	"quotedblleft",	/* 186 */
	"quotedblright",/* 187 */
	"quoteleft",	/* 188 */
	"quoteright",	/* 189 */
	"quotesinglbase",/* 190 */
	"quotesingle",	/* 191 */
	"r",		/* 192 */
	"registered",	/* 193 */
	"ring",		/* 194 */
	"s",		/* 195 */
	"scaron",	/* 196 */
	"section",	/* 197 */
	"semicolon",	/* 198 */
	"seven",	/* 199 */
	"six",		/* 200 */
	"slash",	/* 201 */
	"space",	/* 202 */
	"sterling",	/* 203 */
	"t",		/* 204 */
	"thorn",	/* 205 */
	"three",	/* 206 */
	"threequarters",/* 207 */
	"threesuperior",/* 208 */
	"tilde",	/* 209 */
	"trademark",	/* 210 */
	"two",		/* 211 */
	"twosuperior",	/* 212 */
	"u",		/* 213 */
	"uacute",	/* 214 */
	"ucircumflex",	/* 215 */
	"udieresis",	/* 216 */
	"ugrave",	/* 217 */
	"underscore",	/* 218 */
	"v",		/* 219 */
	"w",		/* 220 */
	"x",		/* 221 */
	"y",		/* 222 */
	"yacute",	/* 223 */
	"ydieresis",	/* 224 */
	"yen",		/* 225 */
	"z",		/* 226 */
	"zcaron",	/* 227 */
	"zero"		/* 228 */
	};

