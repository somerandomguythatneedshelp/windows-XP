/*
    charstr.h

    This module parses the charstrings and creates the appropriate output.

           Copyright 1992-1994 -- Adobe Systems Incorporated
    PostScript is a registered trademark of Adobe Systems Incorporated.

    NOTICE:  All information contained herein or attendant hereto is, and
    remains, the property of Adobe Systems, Inc.  Many of the intellectual
    and technical concepts contained herein are proprietary to Adobe Systems,
    Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
    are protected as trade secrets.  Any dissemination of this information or
    reproduction of this material are strictly forbidden unless prior written
    permission is obtained from Adobe Systems, Inc.

*/

#ifndef CHARSTR_H
#define CHARSTR_H

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif
#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES


#define DEBUG_IN_ENGLISH false

#endif /* CHARSTR_H */
