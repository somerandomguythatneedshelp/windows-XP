/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PSWTRANS.H                                                   */
/*                                                                           */
/* Description: This module contains ...                                     */
/*                                                                           */
/*****************************************************************************/

/* Defines for PSSendMySetup for the type of setup to send */
typedef enum _SETUP {
        SETUP_GDI_COORDS,       /* Set up GDI coordinate system */
        SETUP_PS_COORDS,         /* Set up PostScript default coordinate sys */
        SETUP_EPS_COORDS,         /* Set up EPS default coordinate sys */
        SETUP_XGDI_COORDS         /* Set up Aldus default coordinate sys */
} SETUP_TYPE;


#define  LPARAN  (LPSTR)"("
#define  RPARAN  (LPSTR)")"
#define  BLANK   (LPSTR)" "
#define  SPACE   (LPSTR)" "
#define  PERIOD  (LPSTR)"."

// the procset groups -- set document toknpset.doc
#define TEXT 1
#define ATEXT 2
#define VTEXT 3
#define GDIOBJ 4
#define BITBLT 5
#define DIB 6
#define PASST 7
#define TYPE3HDR 8
#define TYPE1HDR 9
#define TYPE42   10
#define RLE_DECODE 11
#define KTEXT 12

// Encoding arrays for known lfCharSet:
#define ENCODING_0    13
#define ENCODING_1    14
#define ENCODING_2    15
#define ENCODING_77   16
#define ENCODING_161  17
#define ENCODING_162  18
#define ENCODING_177  19
#define ENCODING_178  20
#define ENCODING_204  21
#define ENCODING_222  22
#define ENCODING_238  23
#define ENCODING_255  24
// CMAPs for CJK fonts (TrueType to CIDFonts only)
#define CMAP_128      25
#define CMAP_129      26
#define CMAP_130      27
#define CMAP_134      28
#define CMAP_136      29
#define TYPE0HDR      30
#define CMAP_FFFF     31
#define ENCODING_186  32   //add missing encoding numbers
#define MIN_TEXT      33
#define UFLT3HEADER   34
#define UFLT42HEADER  35
#define UFLCFFHEADER  36
#define UFLCMAPFE     37

#ifdef  ADD_EURO
#define EUROHDR       38
#ifdef  T3OUTLINE
#define TYPE3OLHDR    39
// If add more entries her, increase #define MAXPROCSETRECORDS 40  in PS.H
#else
// If add more entries her, increase #define MAXPROCSETRECORDS 39  in PS.H
#endif
#else   // ADD_EURO
#ifdef  T3OUTLINE
#define TYPE3OLHDR    38
// If add more entries her, increase #define MAXPROCSETRECORDS 39  in PS.H
#else
// If add more entries her, increase #define MAXPROCSETRECORDS 38  in PS.H
#endif
#endif  // ADD_EURO

#define L1L2COMPAT 1
#define L2ONLY 2

enum{
     PSOP_arc          ,
     PSOP_circulararc  ,
     PSOP_ellipticalarc,
     PSOP_arcn         ,
     PSOP_circpiestroke,
     PSOP_ashow        ,
     PSOP_awidthshow   ,
     PSOP_closepath    ,
     PSOP_def          ,
     PSOP_div          ,
     PSOP_eofill       ,
     PSOP_circpiefill  ,
     PSOP_fill         ,
     PSOP_grestore     ,
     PSOP_gsave        ,
     PSOP_lineto       ,
     PSOP_moveto       ,
     PSOP_newpath      ,
     PSOP_rcurveto     ,
     PSOP_rlineto      ,
     PSOP_rmoveto      ,
     PSOP_scale        ,
     PSOP_setfont      ,
     PSOP_setlinecap   ,
     PSOP_setlinejoin  ,
     PSOP_setlinewidth ,
     PSOP_show         ,
     PSOP_xshow        ,
     PSOP_showpage     ,
     PSOP_stroke       ,
     PSOP_translate    ,
     PSOP_widthshow,
     PSOP_rotate
};
#define MIN_PSOP       PSOP_arc
#define MAX_PSOP       PSOP_rotate


typedef struct _PSOP
{
        LPSTR lpzName;
        WORD  BinCode;
}
PSOP,FAR *LPPSOP;

extern PSOP gPSop[MAX_PSOP-MIN_PSOP + 1];

/*----------------
 * PSOP Abbreviations
 *
 * Almost all the PostScript language operator names are abbreviated.
 * The abbreviations are defined in PSABBR.H, incorporated into UTILS0.PS.
 * 'arct is not abbreviated, because it alone among the names is a Level 2
 * operator, with an emulation in GRAPH1.PS.  This makes it awkward to 
 * define an abbreviation for it.
 */


// stuff to do with the function pointers
VOID FAR PASCAL AsciiOrBinary(short,BOOL,LPPDEVICE);
VOID FAR PASCAL FlavorOfPostScript(LPPDEVICE lppd, short Flavor);
short FAR PASCAL AssignDLLTokens(LPPDEVICE lppd, HANDLE hTokenDLL );
#ifdef ADOBE_DRIVER
VOID FAR PASCAL DetermineOutputCharacteristics(LPPDEVICE lppd, LPSHORT Flavor,
                                                  LPBOOL Binary);
#else
VOID NEAR PASCAL DetermineOutputCharacteristics(LPPDEVICE lppd, LPSHORT Flavor,
                                                  LPBOOL Binary);
#endif

// procset management prototypes
VOID FAR PASCAL InitProcsetList( LPPDEVICE lppd);
short FAR PASCAL AddProcsetRecord(LPPDEVICE lppd, short Psetnumber);
short FAR PASCAL TokenNeedsProcset(LPPDEVICE lppd, short Procset);
short NEAR PASCAL downloadprocset(LPPDEVICE lppd, short psetnum);
short NEAR PASCAL downloadprocsetstartup(LPPDEVICE lppd);
short FAR PASCAL procsetsendprocs(LPPDEVICE lppd, short procsettype);
short FAR PASCAL endprocsetdownload(LPPDEVICE lppd);

// font list prototypes
VOID FAR PASCAL InitFontDataList( LPPDEVICE );
VOID FAR PASCAL ResetFontDataList( LPPDEVICE );
int FAR PASCAL CheckFontDataRecord(LPPDEVICE, FONTDATARECORD, LPFONTDATARECORD);
BOOL FAR PASCAL AddFontDataRecord(LPPDEVICE, LPFONTDATARECORD);
BOOL FAR PASCAL CheckFontDSCEntry(LPPDEVICE,LPSTR );
BOOL FAR PASCAL AddFontDSCEntry(LPPDEVICE, LPSTR, BOOL);
BOOL FAR PASCAL UpdateFontDSCEntry(LPPDEVICE, LPSTR, BOOL);
BOOL FAR PASCAL AddFileDSCEntry(LPPDEVICE, LPSTR, BOOL);
BOOL FAR PASCAL AddFeatureDSCEntry(LPPDEVICE, LPSTR, BOOL, BOOL);

//module specific prototypes
//
short FAR PASCAL PSSendColor         (LPPDEVICE, DWORD);
short FAR PASCAL PSSendRGBColor      (LPPDEVICE, DWORD);
VOID  FAR PASCAL PSSendPenWidth      (LPPDEVICE, POINT);
VOID  FAR PASCAL PSSendPenCap        (LPPDEVICE, BYTE);
VOID  FAR PASCAL PSSendPenJoin       (LPPDEVICE, BYTE);
VOID  FAR PASCAL PSSendPenMiter      (LPPDEVICE, short);
VOID  FAR PASCAL PSSendPenStyle      (LPPDEVICE, BYTE , int);
VOID  FAR PASCAL PSSendPenBGColor    (LPPDEVICE);
VOID  FAR PASCAL PSSendPenFGColor    (LPPDEVICE);
short FAR PASCAL PSSendBrush         (LPPDEVICE,short,LPSTR,LPSTR);
short FAR PASCAL PSSendGSave         (LPPDEVICE);
short FAR PASCAL PSSendGRestore      (LPPDEVICE);
VOID  FAR PASCAL PSSendColorOP       (LPPDEVICE, FLAG);
VOID  FAR PASCAL PSSendRGBColorOP    (LPPDEVICE, FLAG);
FLAG FAR PASCAL PSSendBGHatch(LPPDEVICE, DWORD, short);
FLAG FAR PASCAL PSSendFGHatch(LPPDEVICE lppd, DWORD dColor, int iPat);
int FAR PASCAL PSSendPatBrush(LPPDEVICE lppd);
short FAR PASCAL PSSendProc(LPPDEVICE,short);
short FAR PASCAL PSSendMySetup(LPPDEVICE,LPRECT,SHORT );
short FAR PASCAL PSSendOrientationMatrix(LPPDEVICE, float, float);
short FAR PASCAL PSSendBeginProtocol(LPPDEVICE);
short FAR PASCAL PSSendEndProtocol(LPPDEVICE);
VOID  FAR PASCAL TInitGraphicState(LPPDEVICE);
VOID  FAR PASCAL TSetPen(LPPDEVICE);
VOID  FAR PASCAL TSetBrush(LPPDEVICE);
short FAR PASCAL TSendDeviceFeatures(LPPDEVICE);
short NEAR PASCAL TSendSetup(LPPDEVICE);
short NEAR PASCAL TSendPageSetup(LPPDEVICE);
short NEAR PASCAL TSendPageTrailer(LPPDEVICE, BOOL);
short FAR  PASCAL TSendTrailer(LPPDEVICE, BOOL);
void  FAR  PASCAL TSendPrologInit(LPPDEVICE,BOOL);
short FAR PASCAL TSendPPD(LPPDEVICE, WORD, WORD,LPSTR, WORD, BOOL, BOOL);
short FAR PASCAL TSendPPDJCL(LPPDEVICE, WORD, WORD, LPSTR);
void NEAR PASCAL TSendCustomPaper(LPPDEVICE, LPSTR, int);
void FAR  PASCAL TSendHeader(LPPDEVICE, BOOL);
void NEAR PASCAL TSendHeaderVMError(LPPDEVICE);
void FAR  PASCAL TSendHeaderPrtVMMsg(LPPDEVICE);
void NEAR PASCAL TSendHeaderInitAlreadyDown(LPPDEVICE);
void NEAR PASCAL TSendHeaderL2OnlyDribble(LPPDEVICE);
void NEAR PASCAL TSendHeaderL2OnlyALL(LPPDEVICE);
void NEAR PASCAL TSendHeaderL1L2CompatDribble(LPPDEVICE);
void NEAR PASCAL TSendHeaderL1L2CompatALL(LPPDEVICE);
void FAR PASCAL TSendHeaderL2ImageError(LPPDEVICE);
void NEAR PASCAL TSendHeaderOnlyL2Error(LPPDEVICE);
void NEAR PASCAL TSendHeaderOpenChannel(LPPDEVICE);
void NEAR PASCAL TSendProtocolError(LPPDEVICE);
void NEAR PASCAL TSendHeaderBinNoProtError(LPPDEVICE);
void NEAR PASCAL TSendHeaderBinBCP_A_Error(LPPDEVICE);
void NEAR PASCAL TSendHeaderBinBCP_B_Error(LPPDEVICE);
void NEAR PASCAL TSendHeaderProNotPresentError(LPPDEVICE);
short FAR PASCAL TMSRectHack(LPPDEVICE, BOOL, LPRECT, LPRECT );

float FAR ArcTanDegrees  (float  ,float                );
float FAR Quadrant       (float  ,float                );

// Support level2 "rectfill" and "rectstroke" operator.  jjia  7/8/96
short FAR PASCAL RectFill(LPPDEVICE, LPRECT, short, LPSTR, LPSTR);
short FAR PASCAL RectStroke(LPPDEVICE, LPRECT);
// End "rectfill" and "rectstroke"
short FAR PASCAL FillAndOrStroke(LPPDEVICE, FLAG,FLAG ,short,LPSTR,LPSTR );
VOID  FAR PASCAL PSSendRect     (LPPDEVICE, int,int,int,int);
VOID  FAR PASCAL PSSendBezier   (LPPDEVICE, LPPOINT, short);
VOID  FAR PASCAL PSSendLineSeg  (LPPDEVICE, LPPOINT, short);
VOID  FAR PASCAL PSSendPolyLine (LPPDEVICE, LPPOINT, short);

VOID  FAR PASCAL GSStackCreate(LPPDEVICE lppd);
VOID  FAR PASCAL GSStackPush(LPPDEVICE lppd);
VOID  FAR PASCAL GSStackPop(LPPDEVICE lppd);
short FAR PASCAL GSStackNumPushed(LPPDEVICE lppd);
VOID FAR PASCAL FreeTranslateLayerData( LPPDEVICE lppd   );
PSERROR FAR PASCAL AllocTranslateLayerData( LPPDEVICE lppd);
VOID FAR PASCAL LockTranslateLayerData( LPPDEVICE lppd);
VOID FAR PASCAL UnLockTranslateLayerData(LPPDEVICE lppd);

// ttext Prototypes

VOID FAR PASCAL FontInstName(LPSTR, LPFONTDATARECORD);
VOID FAR PASCAL TextBegin_CreateBasicFont(LPPDEVICE,LPPSFONTINFO, LPFONTDATARECORD);
VOID FAR PASCAL TextBegin_CreateBasicFont_MkFnt(LPPDEVICE,LPPSFONTINFO, LPFONTDATARECORD);
VOID FAR PASCAL TextBegin_CreateBoldItalic(LPPDEVICE,LPPSFONTINFO, LPFONTDATARECORD);
VOID FAR PASCAL TextBegin_CreateScaled(LPPDEVICE, LPPSFONTINFO, LPFONTDATARECORD);
VOID FAR PASCAL PSSendOrigFont(LPPDEVICE, LPPSFONTINFO, LPFONTDATARECORD);
VOID FAR PASCAL FakeBoldItalicType42( LPLOGFONT, LPTEXTXFORM, LPFONTDATARECORD);
int FAR PASCAL CheckDLType(LPPDEVICE, LPLOGFONT, LPPSFONTINFO, LPFONTDATARECORD);

VOID FAR PASCAL TextBegin_UL_ST(LPPDEVICE, LPPSFONTINFO, LPTEXTXFORM);
VOID FAR PASCAL TextBegin_CurrentPoint(LPPDEVICE, LPPOINT, LPPSFONTINFO);

VOID  NEAR PASCAL Bin2Ascii(LPSTR,int               );
BOOL  NEAR PASCAL PSSendFontType1(LPPDEVICE, int,long,LPSTR,int);


void FAR PASCAL PSSendSave(LPPDEVICE lppd, BOOL pageSetup);
short FAR PASCAL PSSendRestore(LPPDEVICE lppd);

void FAR PASCAL PSSetNoCurrentPoint(LPPDEVICE lppd);

short FAR PASCAL PSSendClipRect(LPPDEVICE, short, short, short, short);
void  FAR PASCAL PSStringOutput(LPPDEVICE, BYTE huge *, DWORD );
void FAR PASCAL PSSendNup(LPPDEVICE lppd);
void FAR PASCAL PSSendNupMatrix(LPPDEVICE lppd);

short FAR PASCAL PSSendTextAscii7    (LPPDEVICE, LPSTR);
short FAR PASCAL PSSendTextCharAscii7(LPPDEVICE, LPSTR, int);
short FAR PASCAL PSSendBBoxAscii7    (LPPDEVICE, LPRECT, LPSTR);
short FAR PASCAL PSSendCTM           (LPPDEVICE, LPPSMATRIX);
short FAR PASCAL PSSendStringAscii7  (LPPDEVICE, LPSTR, int);
short FAR PASCAL PSSendCharAscii7    (LPPDEVICE, LPSTR);
short FAR PASCAL PSSendDataAscii7    (LPPDEVICE, LP, WORD);
short FAR PASCAL PSSendHexByteAscii7 (LPPDEVICE, BYTE);
short FAR PASCAL PSSendHexColorAscii7(LPPDEVICE, DWORD);
short FAR PASCAL PSSendFragmentAscii7(LPPDEVICE, WORD);

void FAR PASCAL TSendSpecialPSData(LPPDEVICE lppd);


// Fix bug (143352) - copied from 4.1CJK, 3-21-1996, PPeng.
short FAR PASCAL PSSendTextAscii7OrHex(LPPDEVICE lppd, LPSTR lpz, int count);
// not used : #define PSSendText(x,y)     PSSendTextAscii7OrHex(x, y, lstrlen(y))
#define PSSendTextChar(x,y,c) PSSendTextAscii7OrHex(x, y, c)

#define PSSendString(x,y)   PSSendStringAscii7(x,y, lstrlen(y))
#define PSSendChar(x,y)     PSSendCharAscii7(x,y)
#define PSSendData(w,x,y)   PSSendDataAscii7(w,x,y)

#define PSSendBBox(x,y,z)     PSSendBBoxAscii7(x,y,z)
#define PSSendHexByte(x,y)  PSSendHexByteAscii7(x,y)
#define PSSendHexColor(x,y) PSSendHexColorAscii7(x,y)
#define PSSendFragment(x,y) PSSendFragmentAscii7(x,y)

void FAR PASCAL TSendViewingOrientation(LPPDEVICE lppd, BOOL bSendDefault);

BOOL  FAR PASCAL             TSetVMMark(LPPDEVICE, WORD, BOOL);
short FAR PASCAL             TCleanToVMMark(LPPDEVICE, WORD);

