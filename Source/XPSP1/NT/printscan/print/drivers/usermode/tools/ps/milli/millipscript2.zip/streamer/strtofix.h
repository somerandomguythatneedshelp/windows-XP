/* CM_VerSion strtofix.h atm04 1.3 04307.eco sum= 46221 */
/*
  strtofix.h -- convert strings to 16.16 and 2.30 format fixed point numbers

Copyright (c) 1991 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of
Adobe Systems Incorporated.  Many of the intellectual and
technical concepts contained herein are proprietary to Adobe,
are protected as trade secrets, and are made available only to
Adobe licensees for their internal use.  Any reproduction or
dissemination of this software is strictly forbidden unless
prior written permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks of
Adobe Systems Incorporated.

Original version: Craig Rublee 28-May-91
Edit History:
Paul Haahr: Mon Apr 6 11:39:10 1992
Craig Rublee: Mon Jun 24 18:13:39 1991
End Edit History.

Revision History
  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/STRTOFIX.H_V  $
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:07:08   unknown
 *- |Initial revision.
  Revision 6.1  91/10/07  18:22:46  rublee



End Revision History.
*/

#ifndef	STRTOFIX_H
#define STRTOFIX_H

extern Frac ConvertFrac ARGDECL1(char *, s);
extern Fixed ConvertFixed ARGDECL1(char *, s);

#endif
