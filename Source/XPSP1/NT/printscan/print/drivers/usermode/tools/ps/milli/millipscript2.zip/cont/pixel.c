/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PIXEL.C                                                      */
/*                                                                           */
/* Description: This module contains the functions for pixel operations.     */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_GRAPHSEG)


//The following error code is inconsistent with the DDK and it is probably
// wrong, however it is what the Microsoft Driver returns...
#define PIXEL_ERROR RGB_WHITE

short _loadds FAR PASCAL Output(LP,short,short,LPPOINT,LPPPEN,LPPBRUSH,LPDRAWMODE,LPRECT);
DWORD FAR PASCAL dmPixel(LP,short,short,DWORD,LPDRAWMODE);


/*****************************************************************************
*
* FUNCTION: Pixel
*
* DESCRIPTION: This functions sets or retrieves the color to the specified
*    pixel.  If lpDrawMode is not NULL then this functions sets the given pixel
*    to the color given by dwPhysColor, using binary raster operation given
*    by lpDrawMode.  if lpDrawMode is NULL the function returns the physical
*    color of the pixel.
*
* PSUEDO CODE
* -----------
*
* PARAMETERS        TYPE          PURPOSE
* ----------        ----          -------
* lpDevice          LPPDEVICE     The device to put the pixel to.
* sX                short         The X coordinate for the pixel.
* sY                short         The Y coordinate for the pixel.
* dPhysColor        DWORD         The color of the pixel.
* lpDrawMode        LPDRAWMODE    Pointer to the drawing mode for this pixel.
*
* RETURNS           MEANING
* -------           -------
* DWORD             lpDraw == NULL    Color of the pixel.
*                   lpDrawMode != NULL all ok 0000:0001
*                                      error  8000:0000
*
*****************************************************************************/
DWORD _loadds FAR PASCAL Pixel(LP lpDevice,short sX,short sY,DWORD dPhysColor,
                               LPDRAWMODE lpDrawMode)
{
    LPPDEVICE lppd;
    DWORD     dwRC;
    RECT      LclRect;
    PBRUSH    LclBrush;

    lppd=(LPPDEVICE)lpDevice;
    dwRC = PIXEL_ERROR ;

    //if this call to a memory bitmap?
    if(lppd->sMagic == 0)
        dwRC = dmPixel(lpDevice,sX,sY,dPhysColor,lpDrawMode);

    else if (lppd->sMagic == LUCAS)
        {
        // valid pdevice

            if (lpDrawMode == NULL)
                {
                //GetPixel mode...
                //LATER: remove this!
                dwRC = RGB_WHITE ;
                }
            else
                {
                dwRC = (DWORD)1;
                //SetPixel mode...
                // Since there are no raster ops in postscript
                //   none are past to CPixel.
                LclBrush.bStyle = BS_SOLID;
                LclBrush.dFGColor = dPhysColor;

                LclRect.left = sX;
                LclRect.top = sY;
                LclRect.right = sX;
                LclRect.bottom = sY;

                Output((LP)lppd,OS_RECTANGLE,2,(LPPOINT)&LclRect,
                         NULL,&LclBrush,lpDrawMode,NULL)  ;       // Draw a rect with a brush
                }
        }

        return(dwRC) ;
}
