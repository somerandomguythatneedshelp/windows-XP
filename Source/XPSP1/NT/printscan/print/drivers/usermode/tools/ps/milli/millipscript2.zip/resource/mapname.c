/*
 * mapname.c
 * 
 * $Header:   L:/PVCS/PS40/PSCRIPT/RESOURCE/MAPNAME.C_V   1.7   27 Mar 1995 11:23:18   olegsher  $
 * 
 * Copyright (c) 1989-1991 Adobe Systems Incorporated.
 * All rights reserved.
 *
 * This file may be freely copied and redistributed as long as:
 *   1) This entire notice continues to be included in the file, 
 *   2) If the file has been modified in any way, a notice of such
 *      modification is conspicuously indicated.
 *
 * PostScript, Display PostScript, and Adobe are registered trademarks of
 * Adobe Systems Incorporated.
 * 
 * ************************************************************************
 * THE INFORMATION BELOW IS FURNISHED AS IS, IS SUBJECT TO CHANGE WITHOUT
 * NOTICE, AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY ADOBE SYSTEMS
 * INCORPORATED. ADOBE SYSTEMS INCORPORATED ASSUMES NO RESPONSIBILITY OR 
 * LIABILITY FOR ANY ERRORS OR INACCURACIES, MAKES NO WARRANTY OF ANY 
 * KIND (EXPRESS, IMPLIED OR STATUTORY) WITH RESPECT TO THIS INFORMATION, 
 * AND EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR PARTICULAR PURPOSES AND NONINFINGEMENT OF THIRD PARTY RIGHTS.
 * ************************************************************************
 * 
 * $Log:   L:/PVCS/PS40/PSCRIPT/RESOURCE/MAPNAME.C_V  $
 *- |
 *- |   Rev 1.7   27 Mar 1995 11:23:18   olegsher
 *- |Merged with Microsoft codedrop 03/20/95.
 *- |
 *- |   Rev 1.0   28 Jul 1993 15:08:08   JKEEFE
 *- |Initial revision.
 *- |
 *- |   Rev 3.0   05 Aug 1992 15:38:42   JKEEFE
 *- |Initial revision.
 *- |
 *- |   Rev 1.0   23 Oct 1991 14:45:20   jdlh
 *- |Initial revision.
 *
 */

#include <assert.h>
#include <stdio.h>
#include <string.h>

#ifndef DEBUG
#define DEBUG 0
#endif  /*DEBUG*/

typedef struct _t_SystemName {
  char   *name;
  int     index;
} SystemName;

static SystemName systemNames[] = {
#include "sysnames.h"
};

int SearchTable(int first, int last, char *name);

int SearchTable (first, last, name)
  int first, last;
  char *name;
 /*
   Recursive binary table search.
  */
{
  int     rangeSize = last - first + 1;
  int     halfRangeSize = rangeSize / 2;
  int     probeIndex = first + (rangeSize / 2);
  int     comparison;
  SystemName *probe = &systemNames[probeIndex];

  assert (rangeSize > 0);

  if (probe->name == NULL)
    comparison = -1;
  else
    comparison = strcmp (name, probe->name);

  if (comparison == 0)
    return (probe->index);
  else if (rangeSize == 1)
    return (-1);
  else if (comparison < 0) {
    /* Earlier in table */
    return (SearchTable (first, first + halfRangeSize - 1, name));
  } else {
    /* Later in table */
    return (SearchTable (first + halfRangeSize, last, name));
  }
}

int MapName (char *name)
{
  return (SearchTable (0, 255, name));
}
