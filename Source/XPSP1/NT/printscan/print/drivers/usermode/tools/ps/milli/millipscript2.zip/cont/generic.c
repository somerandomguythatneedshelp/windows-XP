// generic.c -- used to create generic.pch file from generic.h
#include "generic.h"

// every other C file must have ``#include "generic.h"'' as the
// first non-comment line in the file.  If it does not, then you
// must add a rule for the .obj file in unidrv.mk.
