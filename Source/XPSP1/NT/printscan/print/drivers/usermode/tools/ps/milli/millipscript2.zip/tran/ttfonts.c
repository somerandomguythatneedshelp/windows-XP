/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TTFONTS.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for                       */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "ufoenc.h"
#include "encode2.h"

#pragma code_seg(_TTFONTSSEG)

DWORD NEAR PASCAL sizesfnt(HDC hDC) ;
#define GDLLHND  (GHND | GMEM_SHARE)

#define UPDATE_FAILURE  -1
#define UPDATE_LOWVM    0
#define UPDATE_SUCCESS  1

/*****************************************************************************/
/*                 GetTableHDC                                               */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HDC hdc - where the current font is selected                            */
/*   DWORD tableName --                                                      */
/*   BYTE huge *lpTable -- The table returns                                 */
/*                                                                           */
/* Returns: size of the table                                                */
/*****************************************************************************/

DWORD FAR PASCAL GetTableHDC(HDC hdc, DWORD tableName, BYTE huge *lpTable)
{
    DWORD retVal;
    retVal = GetFontData(hdc, tableName, 0, NULL, 0L);  // size of the table
    if (lpTable != NULL)
        retVal = GetFontData(hdc, tableName, 0, lpTable, retVal); // get whole table
    return retVal;
}


DWORD FAR PASCAL GetTableDirectory(HDC hDC, LPTABLEDIRECTORY lpTableDir)
{
    DWORD ret = sizeof(TABLEDIRECTORY);
    if (lpTableDir == NULL) 
        return ret;   // find out the size only
    // TableDirectory starts from 0 byte of the font file:
    ret = GetFontData(hDC, 0, 0L, (void FAR*) lpTableDir, sizeof(TABLEDIRECTORY));
    return ret;
}


DWORD FAR PASCAL GetTableCheckSum(LPTABLEDIRECTORY lpTableDir, LPTABLEENTRY lpTableEntry, DWORD tableName)
{
    WORD i;
    DWORD checkSumNotFound = 0;

    for (i = 0; i < MOTOROLAINT(lpTableDir->numTables) ; ++i)
    {
        if (lpTableEntry->tag == tableName)
        {
            return  lpTableEntry->checkSum;
        }
        lpTableEntry = (LPTABLEENTRY)((LPSTR)lpTableEntry + sizeof(TABLEENTRY));
    }
    return checkSumNotFound;
}

DWORD FAR PASCAL GetTableEntry(HDC hDC, LPTABLEENTRY lpTableEntry, LPTABLEDIRECTORY lpTableDir)
{
    DWORD ret ;
    if (lpTableDir ==NULL ) return 0;  // we need the TableDirectory to get the entry.

    ret = MOTOROLAINT(lpTableDir->numTables) * sizeof(TABLEENTRY);

    if (lpTableEntry == NULL ) return ret;  // find out the size

    // TableDirectory starts from sizeof(TABLEDIRECTORY) byte of the font file:
    ret = GetFontData(hDC, 0, sizeof(TABLEDIRECTORY), (void FAR*) lpTableEntry, ret);
    return ret;
}


void FAR PASCAL TTComposeCIDFont(
    LPPDEVICE           lppd, 
    LPPSFONTINFO        lpFontInfo,
    LPFONTDATARECORD    lpFontData, 
    LPCMAPINFO          lpCMAPInfo
    )
    //
    // compose a Type 0 font based on CMAP and CIDFont
    //
{
    LPASCIIBINPTRS  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    char tmpbuf[256], cidFontName[50];

    /* The CIDFopnt resource name is in pSubFont */
    lstrcpy(cidFontName, lpFontData->pSubFont->strPSName);

    // If Vertical
    if (lppd->fDBCS & DBCS_VERT)
    {
        // Name of the result font - for the very last definefont:
        wsprintf((LPSTR)tmpbuf, "/%s", lpFontData->FontName);
        PSSendString(lppd, tmpbuf);
        (*tempptr->PSSendCRLF)( lppd );
        
        // now send the origFontName/Type/CharSet
        PSSendOrigFont(lppd, lpFontInfo , lpFontData );  // origFontname, origFontType, lfCharSet, AddFlag
        (*tempptr->PSSendCRLF)( lppd );

        /* Make a copy of the CIDFont to create a rotated version 
        * E.g. /TT3782053888t0R /TT3782053888t0cid T42CIDCPR */

        wsprintf((LPSTR)tmpbuf, "/%sR /%s T42CIDCPR",
            cidFontName, cidFontName);
        PSSendString(lppd, tmpbuf);
        (*tempptr->PSSendCRLF)( lppd );

        /* Compose a font called /MSTT31abcdV - and then copy it for adding OrigFOntInfo */
        wsprintf((LPSTR)tmpbuf, "/%sV /%s [/%s /%sR] composefont",
            lpFontData->FontName, lpCMAPInfo->CMapName, cidFontName, cidFontName );
        PSSendString(lppd, tmpbuf);
        (*tempptr->PSSendCRLF)( lppd );

        /* now copy it and definefont the copy as lpFontData->FontName */
        wsprintf((LPSTR)tmpbuf,
            "dup length 2 add dict begin {1 index /FID ne {def} {pop pop} ifelse} forall");
        PSSendString(lppd, tmpbuf);
        (*tempptr->PSSendCRLF)( lppd );
        wsprintf((LPSTR)tmpbuf,
            "AddOrigFP currentdict end definefont pop");
        PSSendString(lppd, tmpbuf);
        (*tempptr->PSSendCRLF)( lppd );
    }
    else
    {
        // Horizontal - use T09Hdr 
        wsprintf((LPSTR)tmpbuf, "%d /%s %d /%s /CMap findresource",
            0 , // paintType 0 = fill
            lpFontData->FontName,
            ((lppd->fDBCS & DBCS_VERT)>0)?1:0,  // Vertical=1 or not(0)
            lpCMAPInfo->CMapName);
        PSSendString(lppd, tmpbuf);
        (*tempptr->PSSendCRLF)( lppd );

        wsprintf((LPSTR)tmpbuf, "[/%s /CIDFont findresource] [0]", cidFontName);
        PSSendString(lppd, tmpbuf);
        (*tempptr->PSSendCRLF)( lppd );

        // now send the origFontName/Type/CharSet to make Distiller/Acrobat happy.
        PSSendOrigFont(lppd, lpFontInfo , lpFontData );  // origFontname, origFontType, lfCharSet, AddFlag
        wsprintf((LPSTR)tmpbuf, "Type09Hdr");
        PSSendString(lppd, tmpbuf);
        (*tempptr->PSSendCRLF)( lppd );
    }

}


PSERROR TTDownloadCMap(
    LPPDEVICE           lppd, 
    LPPSFONTINFO        lpFontInfo ,
    LPCMAPINFO          lpCMAPInfo
    )
{
    LPASCIIBINPTRS  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    PSERROR         rc = PS_SUCCESS;
    int             procID = 0 ;

    if (lppd->fDBCS & DBCS_FONT)
    {
        // Download proper CMAP -if not Down yet:
        // First Set as if in CharCode mode based on charset val.
        switch(lpFontInfo->dfCharSet)
        {
        case 128: 
            procID = CMAP_128; 
            break;
        case 129: 
            procID = CMAP_129; 
            break;
        case 130: 
            procID = CMAP_130; 
            break;
        case 134: 
            procID = CMAP_134; 
            break;
        case 136: 
            procID = CMAP_136; 
            break;
        }
        
        // Overwrite by identity CMAP if in Glyph-index mode.
        if (lpFontInfo->dfType & PF_GLYPH_INDEX)
        {
            // UFL has it: procID = CMAP_FFFF; // if Glyph-index mode this one is enough
            procID = 0;
        }

        lppd->iResIdCMap = procID;      // remember this resource ID. used in VMRecovery
    }

    if (procID)
    {
        char tmpbuf[256];

        TokenNeedsProcset(lppd, procID); //cmap
        // initialize the CMAP resource 
        wsprintf((LPSTR)tmpbuf, "CMAP-%s", lpCMAPInfo->CMapName);
        PSSendString(lppd, tmpbuf);
        (*tempptr->PSSendCRLF)( lppd );
    }

    return rc;
}




FONTTYPE DecideType42DownloadFormat(
    LPPDEVICE           lppd, 
    LPPSFONTINFO        lpFontInfo
    )
{
    FONTTYPE fontType = BASE_FONT;
    
    if (lppd->fDBCS & DBCS_FONT)
    {
        if (lpFontInfo->dfType & PF_GLYPH_INDEX)
        {
            fontType = CID_H;
        }
        else
        {
            /* Download the CIDFont Resource only
            * driver will do composefont */
            fontType = CID_RESOURCE_H;
        }
    }

    if (lppd->fDBCS & DBCS_VERT)
    {
        if (lpFontInfo->dfType & PF_GLYPH_INDEX)
        {
            fontType = CID_V;
        }
        else
        {
            /* Download the CIDFont Resource only
            * driver will do composefont */
            fontType = CID_RESOURCE_V;
        }
    }

    return fontType;
}



/*****************************************************************************/
/*                 TTDownLoadT42                                             */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   LPDEVICE lppd --                                                        */
/*   LPPSFONTINFO lpFontInfo --                                              */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

PSERROR FAR PASCAL TTDownLoadT42(
    LPPDEVICE           lppd, 
    LPPSFONTINFO        lpFontInfo,
    LPFONTDATARECORD    lpFontDataRecord, 
    BOOL                bFullFont
    )
{
    PSERROR      rc = PS_SUCCESS;  
    FONTTYPE     fontType ;
    LPSUBFONT43  pSubFont ;
    LPTTFONTINFO lpttfi ;
    WORD         iCount = 1;
    BYTE         *pByte;
    int          doVMRecovery = lppd->doVMRecovery;
    int          PSVersion    = GetPSVersion(lppd);

    pSubFont = (LPSUBFONT43) GlobalAllocPtr(GHND, sizeof(SUBFONT43));

    if (!pSubFont)
        return PS_ALLOC_FAILED;

    fontType = DecideType42DownloadFormat(lppd, lpFontInfo);
    lpttfi = (LPTTFONTINFO)((LPSTR) lpFontInfo + lpFontInfo->dfBitsOffset);

    pSubFont->lppd = (LPVOID)lppd;
    pSubFont->FontInfo = (LPVOID) lpFontInfo;
    pSubFont->bFullFont = bFullFont;
    pSubFont->pufo = (LPVOID) NULL;

    /* assume the correct FontName */
    lstrcpy(pSubFont->strPSName, (LPSTR)lpttfi->PSName);

    if (fontType == CID_RESOURCE_H || 
        fontType == CID_RESOURCE_V )
    {
        /* Give the CIDFont resource a different name */
        lstrcat(pSubFont->strPSName, "cid");
    }

    /* Set our own dlType - either GI_42, CC_42, CC_CID, GI_CID */
    if (lppd->fDBCS & DBCS_FONT)
    {
        if (lpFontInfo->dfType & PF_GLYPH_INDEX)
            lpFontDataRecord->fontDLType = GI_CID ;
        else
            lpFontDataRecord->fontDLType = CC_CID ;
    }
    else
    {
        if (lpFontInfo->dfType & PF_GLYPH_INDEX)
            lpFontDataRecord->fontDLType = GI_42 ;
        else
            lpFontDataRecord->fontDLType = CC_42 ;
    }

    BNewType42Font(lppd, pSubFont, MAX_NUM_CHARS_US, (FONTTYPE) fontType);
    lpFontDataRecord->pSubFont = pSubFont;
    lpFontDataRecord->isMypSubFont = 1;

    /* as in old Win95 driver, we need to force the font header be sent now */
    /* Since no two TextOut() or Download() calls overlap, we can use hte global buffer gWordArray0 */
    pByte = (BYTE *) gWordArray0;

    /* Force UFL (Fake) a FullFont downloading - download all chars from 0 to 255 */
    if (bFullFont)
    {
        if(lpFontInfo->dfType & PF_GLYPH_INDEX)
        {
            for (iCount = 0; iCount < WARRAY0SIZE; iCount++)
            {
                gWordArray0[iCount] = iCount;
            }
        }
        else
        {
            for (iCount = 0; iCount < WARRAY0SIZE; iCount++)
            {
                pByte[iCount] = (BYTE)iCount;
            }
        }
        iCount = WARRAY0SIZE;
    }
    else
    {
        /* force the header to be sent - as win old Win95 driver*/
        if(lpFontInfo->dfType & PF_GLYPH_INDEX)
            gWordArray0[0] = 0;
        else
            pByte[0]=' ';   /* space */

        iCount = 1;
    }

    /* disable VM Recovery for font Header or FullFontDown*/
    if (PSVersion >= 2015)
        lppd->doVMRecovery = 0;

    rc = TTUpdateT42(lppd, lpFontInfo, lpFontDataRecord, pByte, iCount);
    if (rc == UPDATE_LOWVM)
        rc = PS_LOWVM_VMRECOVER;
    else if (rc != UPDATE_SUCCESS)
        rc = PS_GENERIC_FAIL;

    lppd->doVMRecovery = doVMRecovery;

    if ( CID_RESOURCE_H == fontType ||
        CID_RESOURCE_V == fontType )
    {
        LPCMAPINFO  lpCMapInfo;

        lpCMapInfo = GetCMAPInfo((int)lpFontInfo->dfCharSet,
                        ((lppd->fDBCS & DBCS_VERT)>0)?1:0 ); 

        /* now download the proper CMap and Instiatiate it */
        TTDownloadCMap(lppd, lpFontInfo, lpCMapInfo);

        TTComposeCIDFont(lppd, lpFontInfo, lpFontDataRecord, lpCMapInfo);
    }
    return rc;
}



/****************************************************************
*
*                       TTDownloadTTFont
*
* Action: FOR DEVICES THAT ACCEPT RAW TRUETYPE FONTS, e.g., TrueImage
*         printers, dump down the entire TrueType font using the
*         readhexsfnt operator.
*
*         Font size calculation code compliments of ccteng.
*
* Parameters:  
*   LPDEVICE lppd -- 
*   LPPSFONTINFO lpdf --
*   BOOL bFullFont --
*
* Returns: 1 if successful, 0 otherwise.
*
* transfer all this code straight out of pscript.drv
*
**************************************************************/

int FAR PASCAL TTDownLoadTTFont(LPPDEVICE lppd, LPPSFONTINFO lpdf, 
	 BOOL bFullFont)
{

#define MAX_TTCOL_WIDTH 80 /* must be an even number */
#define MAX_TTBUF_SIZE  (MAX_TTCOL_WIDTH * 200) /* 16Kb xfer buffer */

   int rc = 0;
																DWORD dwTTSize;
   DWORD dwBufSize;
   DWORD dwNumBytes;
   DWORD dwOffset;
   HDC hDC;
   HFONT hTTFont;
   HFONT hPrevFont;
   LPTTFONTINFO lpttfi;
   LPSTR lpBuf;
   LOGFONT logfont;
   BOOL  okSoFar = TRUE ;
   LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   DWORD resrcSize;


   lpttfi = (LPTTFONTINFO) ((LPSTR) lpdf + lpdf->dfBitsOffset);

   /* Get the screen DC.
   */
   if (!(hDC=GetDC(NULL)))
	goto backout0;

   /* Create the TrueType engine font using the stored copy
    ** of the logical font structure.  If we do not actually
    ** get the TrueType font then we're hosed.
    */
    logfont = lpttfi->lfCopy;
     /*
     * Mark this LOGFONT copy as TT_only realizable to prevent
     * ATM from realizing this font when we call CreateFontIndirect
     * and ATM has the PS font with the same name.
     * Fixed 27-May-1993  -by-  [olegs]
     * ANG 4/22/97 moved from realize.c (TTRealizeFont)
     */
     logfont.lfOutPrecision = OUT_TT_ONLY_PRECIS;
   
   if ( !(hTTFont=CreateFontIndirect(&logfont)))
   {
      goto backout1;
   }
   if (!(hPrevFont=SelectObject(hDC,hTTFont)))
   {
      goto backout2;
   }

#if 0
   char facenm[LF_FACESIZE];

   if (!GetTextFace(hDC,sizeof(facenm),facenm))
      goto backout3;  // useless code

   facenm[lstrlen(logfont.lfFaceName)] = '\0';
   if (lstrcmpi(facenm,lpttfi->lfCopy.lfFaceName))
   {
      goto backout3;
   }
#endif

   // Compute the size of the font by adding up the sizes in
   // the font's header.  This is more robust than assuming that
   // the font file itself is the correct length.  If we download
   // more or less bytes than indicated in the font header then
   // the printer will fall out of sync and most likely will not
   // recover.
   //
   if (!(dwTTSize=sizesfnt(hDC)))
   {
      goto backout3;
   }

   resrcSize = dwTTSize;
   VMCheck(lppd, VM_TT_FONT, resrcSize);

   // Allocate a buffer used for copying the font.  We will be
   // using the PSSendBitMapDataLevel1Ascii7 proc which converts
   // binary data into CRLF separated HEX strings of max length 40h
   //

   if (dwTTSize > MAX_TTBUF_SIZE )
   {
      dwBufSize = MAX_TTBUF_SIZE;
   }
   else
   {
      dwBufSize = dwTTSize ;
   }

   dwNumBytes = dwBufSize ;  // useless initialization 

   if (!(lpBuf = GlobalAllocPtr(GDLLHND, dwBufSize)))
   {
      goto backout3;
   }

   // Prepend the data with the command to build a sfnt.
   
   PSSendString(lppd, "mark { currentfile readhexsfnt } stopped");
   (*tempptr->PSSendCRLF)( lppd );

   // Dump the sfnt (TrueType font) in hex format.

   okSoFar = TRUE ;

   for (dwOffset = 0L; dwOffset < dwTTSize; dwOffset += dwNumBytes) 
   {
      DWORD  nRead;

      // how many bytes shall we read ?
      if (dwNumBytes  > (dwTTSize - dwOffset))
      {
	 dwNumBytes = dwTTSize - dwOffset;
      }

      if (okSoFar  &&  dwNumBytes > (nRead = GetFontData(hDC, 0L, dwOffset, lpBuf,
		dwNumBytes)))
      {
	 // We encountered an error attempting to read the font,
	 // so pad out the rest of the length of the font with
	 // zeroes        

	 MemSet(lpBuf+nRead, 0, dwNumBytes - nRead);
	 // assumes buffer fits within a segment
	 PSSendBitMapDataLevel1Ascii7(lppd, (BYTE huge *)lpBuf, dwNumBytes );
	 MemSet(lpBuf, 0, (DWORD)nRead);  // clear the rest of the buffer.
	 okSoFar = FALSE ;
      } 
      else
      {
	 PSSendBitMapDataLevel1Ascii7(lppd, (BYTE huge *)lpBuf, dwNumBytes );
      }
   }

   // Conclude the data by assigning a font name to the new sfnt.
   // If the printer encountered an error during the download, then
   // we just pop everything without assigning a name to the font.
   //
   {
      char  tempbuf[80];

      wsprintf(tempbuf, "not { /%s exch definefont } if cleartomark",
	       (LPSTR)lpttfi->PSName);
      PSSendString(lppd, tempbuf);
      (*tempptr->PSSendCRLF)( lppd );
   }

   // Update current VM value, accomodate what has already
   // been added for this font.
   //

   rc = 1;

   GlobalFreePtr(lpBuf);
   VMUsed(lppd, VM_TT_FONT, resrcSize);

backout3:
   SelectObject(hDC,hPrevFont);
backout2:
   DeleteObject(hTTFont);
backout1:
   ReleaseDC(NULL,hDC);
backout0:
   return rc;
}


/****************************************************************
* Name: sizesfnt()
*
* Action: Reads a TrueType font and computes its exact size based
*         upon the numbers in the font's tables.
*
* Returns: The size of the font in bytes.
*
**************************************************************/

DWORD NEAR PASCAL sizesfnt(HDC hDC)
{
   int i;
   int nTables;
   DWORD dwTblSize;
   DWORD dwMaxOffset;
   DWORD dwMaxLength = 0;
   DWORD dwOffset;
   DWORD dwPad;
   LPTABLEENTRY lpTbl;
   TABLEDIRECTORY dir;

   // Get the file header.
    
   if (GetFontData(hDC, 0L, 0L, (LPSTR)&dir,
	    sizeof(TABLEDIRECTORY)) != sizeof(TABLEDIRECTORY)) 
   {
      goto backout0;
   }
   nTables = MOTOROLAINT(dir.numTables);

   // Allocate an array of directory structures (one for each table).
   
   dwTblSize = (DWORD)nTables * sizeof(TABLEENTRY);
   if(!(lpTbl = (LPTABLEENTRY)GlobalAllocPtr(GDLLHND,dwTblSize)))
   {
      goto backout0;
   }

   // Read the array of tables.
   
   if (GetFontData(hDC, 0L, sizeof(TABLEDIRECTORY), (LPSTR)lpTbl,
	    dwTblSize) != dwTblSize)
   {
      goto backout1;
   }

   // Walk the array of tables finding the last one in the
   // file.  Its location and length rounded out to the nearest
   // 4 byte boundary constitutes the number of bytes the printer
   // will expect.
   //
   for (i = 0, dwMaxOffset = 0; i < nTables; i++, lpTbl++) 
   {
      dwOffset = MOTOROLALONG(lpTbl->offset);
      if (dwMaxOffset < dwOffset)
      {
	 dwMaxOffset = dwOffset;
	 dwMaxLength = MOTOROLALONG(lpTbl->length);
      }
   }
   if (dwPad = dwMaxLength % 4)
      dwPad = 4 - dwPad;
   dwMaxLength += dwMaxOffset + dwPad;

backout1:
   GlobalFreePtr(lpTbl);
backout0:
   return(dwMaxLength);
}


// New version of GetOIDGlyphIndex(), doesn't require lpGITable present - Speeeed up
/****************************************************************************
*                                                                           *
*                          GetOIDGlyphIndexDirect                           *
*                                                                           *
* This local routine is used to  to find the   
* PrimaryIndex of a given character in unicode or prefixed by 0xF0.         *
* The return code is a WORD value. If NULL, it means we have not succeeded. *
*                                                                           *
* The function is called by the interface function: TTUpdateT42             *
*                                                                           *
****************************************************************************/

WORD FAR PASCAL GetOIDGlyphIndexDirect(LPPDEVICE lppd, LPFONTDATARECORD lpFontDataRecord,
    int oid, LPLOGFONT lplf, BOOL bEUDC)
{
    WORD wGlyfIndex=0;
    LPGITABLE lpGITable = lpFontDataRecord->lpGITable;

    if (!IsDBCSCharSet(lplf->lfCharSet) && lpGITable->n==0)
    {
        // Fill the table for speed - only for non-DBCS fonts
        lpGITable->lf = *lplf;
        FillGlyphIndexTable(NULL, lpGITable);
    }

    if (IsDBCSCharSet(lplf->lfCharSet) || 
        lpGITable->n==0 ||
        (WORD)oid > lpGITable->n )
    {
        //Use GetCharPlacement() to find out GI from oid:
        wGlyfIndex = GetGlyphIndexFromOID(lplf, (WORD)oid, bEUDC);
    }
    else
        wGlyfIndex = *(lpGITable->lpwGI+oid); 

    return wGlyfIndex;
}


/**************************************************************************
*                                                                         *
*                           TTUpdateT42                                   * 
*                                                                         *
* This function is called by TTUpdateFont which resides in the module     *
* ttext.obj. when the user or the application requests incremental down   *
* load support. The return code is an integer value identified by irc.    *
* If the result of the operation is a success irc=1 or 0 otherwise.       *
* function calls the following subroutines:                               *
*                                                                         *
* It also make uses of the following macros:                              *
*     ISCHARDOWN and SETCHARDOWN.                                         *
*                                                                         *
*                                                                         *
**************************************************************************/

int FAR PASCAL TTUpdateT42(
    LPPDEVICE           lppd,
    LPPSFONTINFO        lpFontInfo,
    LPFONTDATARECORD    lpFontDataRecord,
    LPSTR               lpStr,
    int                 cb
    )
{
    ULONG           UFLDLType =  DLFONT_TYPE42;
    unsigned short  strLen = 0;
    ULONG           VMUsage, FCUsage;
    LPDWORD         lpDLGlyph = NULL;
    LPWORD          lpCharIndex= NULL;
    LPWORD          lpUnicode = NULL;
    BOOL            rc=TRUE;

    if (lppd->fDBCS & DBCS_FONT)
        UFLDLType = DLFONT_TYPE42_CID;

    strLen = cb;
            
    FillUFLGIArray(
        lppd, 
        lpFontInfo,
        cb,     /* number of glyphs/CharIndex/Unicode - a guess */
        &lpDLGlyph,         /* pointer to glyphID array */
        &lpCharIndex,   /* pointer to CharIndex array */
        &lpUnicode,     /* pointer to Unicode array */
        lpFontDataRecord,
        lpStr,          /* Original Char String from TextOut() */
        &strLen);

    /* Need to update pointers in lpFontData->pSubFont for UFL call back */
    UpdateUFLSubFont(lpFontDataRecord->pSubFont, lppd, lpFontInfo, lpFontDataRecord );

    if (DoVMTracking(lppd))
    {
        BUFOVMNeeded( UFLDLType, lpFontDataRecord->pSubFont, 
                (short) strLen, lpDLGlyph, (unsigned char **)apszEncode, 
                lpCharIndex, lpUnicode, (ULONG *) &VMUsage, (ULONG *) &FCUsage);

        /* Don't bother with small bytes of VM */
        if (VMUsage > 100) 
        {
            if ( TRUE == VMCheck(lppd, VM_GOODESTIMATE, VMUsage) )
                return UPDATE_LOWVM;
        }
    }

    rc = BUFODownload( UFLDLType, lpFontDataRecord->pSubFont, 
                (short) strLen, lpDLGlyph, (unsigned char **)apszEncode, 
                lpCharIndex, lpUnicode, (ULONG *) &VMUsage, (ULONG *) &FCUsage);

    VMUsed(lppd, VM_GOODESTIMATE, VMUsage);

    if (rc)
      return(UPDATE_SUCCESS);
    else
      return(UPDATE_FAILURE);
}


/*****************************************************************************
*
*                          PSSendTextWordAscii7
*
* Function: Sends text strings as words, with low byte and high byte properly
*           swapped and positioned as a double-byte character. Function is 
*           used in Composite fonts with 8/8 mapping.
*
* Called:  short FAR PASCAL PSSendTextWordAscii7(LPPDEVICE lppd, LPSTR lpz,
*                                                int count)
*
* Parameters: LPPDEVICE lppd     PDEVICE pointer
*             LPWORD    String   pointer to string of double-bytes to send
*             int       count    Number of double-bytes to send
*               
* Returns:  Length
*
*****************************************************************************/
short FAR PASCAL PSSendTextWordAscii7(LPPDEVICE lppd, LPWORD String, int count)
{
  LPWORD lpWString = String;
  short  i, sLength = 0;
  char   buf[6];     // to hold one word in hex
  WORD   len;

  // Insert a left angular bracket to indicate ASCIIHEX string
  sLength += PSSendFragment(lppd, PSFRAG_leftcaret);

  lpWString = String;
  for (i=0; i<count; i++)
  {
     len = wsprintf(buf, "%04x", *lpWString);
     sLength += PSSendString(lppd, buf);
     lpWString++;
  }
   
  sLength += PSSendFragment(lppd, PSFRAG_rightcaret);

  return(sLength);                                 
}


/*****************************************************************************
*
*                          PSSendTextWordBinary
*
* Function: Sends text strings as binary encoded words, with low byte and high 
*           byte properly swapped and positioned as a double-byte character. 
*           Function is used in Composite fonts with 8/8 mapping.
*
* Called:  short FAR PASCAL PSSendTextWordBinary(LPPDEVICE lppd, LPSTR lpz,
*                                                int count)
*
* Parameters: LPPDEVICE lppd     PDEVICE pointer
*             LPWORD    String   pointer to string of double-bytes to send
*             int       count    Number of double-bytes to send
*               
* Returns:  Length
*
*****************************************************************************/
short FAR PASCAL PSSendTextWordBinary(LPPDEVICE lppd, LPWORD String, int count)
{


#if 1

   return PSSendTextWordAscii7(lppd, String, count);

#else

BUGBUG - bug #200133

This Function Swaps bytes in a Passed-in Pointer,
Need to allocate, copy and then swap.

For now, use the Ascii version - Binary is disabled for T42
show-string -NOT Much Penalty

   int SwappedCount = count;
   LPWORD SwappedString = String;
   WORD DoubleByte;
   short  sLength = 0;
   LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
 
   while (SwappedCount > 0)
   {
      DoubleByte = *String;

      *String++ = MOTOROLAINT(DoubleByte);
      SwappedCount--;  
   }

   (*tempptr->PSSendShort)(lppd, (short)count*2);
   PSSendString(lppd, "RD ");
   sLength += 3;
   PSSendBitMapDataLevel1Binary(lppd, (BYTE huge *)SwappedString, count*2);
   sLength += count * 2;

   return(sLength);

#endif

}



/***************************************************************************
*
*                              TTextRunWide
*    Function:  
*                
*    Called:  short FAR PASCAL TTextRunWide(LPPDEVICE lppd, LPWORD String, int count, 
*                                       double breakExtra, double charExtra,
*                                       LPPSFONTINFO FontInfo, LPTEXTXFORM TextXForm)
*                                    
*    Parameter:  LPPDEVICE lppd
*                LPWORD    String
*                int       count
*                double    breakExtra
*                double    charExtra
*
*    Returns:
*
***************************************************************************/

short FAR PASCAL TTextRunWide( LPPDEVICE lppd, LPWORD String,int count, double breakExtra, 
			       double charExtra, LPPSFONTINFO FontInfo,
			       LPTEXTXFORM TextXForm, LPINT lpdx )
{
   LPASCIIBINPTRS tempptr;
   int   code, BoldFake;
   short retval;
   WORD  dfBreakChar ;
   int   i, idx, length = 0;

   short Flavor;
   BOOL  bfBinaryOutput;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, TEXT);

   if (FontInfo->dfType & TYPE_TRUETYPE) 
   { 
	  FONTDATARECORD   FontData;


	  LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO)((LPSTR)FontInfo + 
								FontInfo->dfBitsOffset);

     FontData.GlyphData = NULL;

	  switch (lppd->lpPSExtDevmode->dm2.iDLFontFmt)
	  {
		 case TT_DLFORMAT_TYPE42 :
			FakeBoldItalicType42((LPLOGFONT) &(lpTTFontInfo->lfCopy),TextXForm,
								 (LPFONTDATARECORD)&FontData);
			BoldFake = FontData.BoldFake;
		 break;

		 case TT_DLFORMAT_NONE : // Do not fake anything !!!
			BoldFake =  FALSE;
		 break;

		 default:                // Type 1 or Type 3
			BoldFake = ((TextXForm->ftWeight>=700) && (FontInfo->dfWeight < 700));
		 break;
	  }
   } 
   else
   {
	  BoldFake = ((TextXForm->ftWeight>=700) && (FontInfo->dfWeight < 700));
   }

   // The PostScript operator used is determined by any differences
   //  in the character spacing or the break spacing between the
   //  PostScript widths and the widths specified by the application:
   //
   //  breakExtra  charExtra      Operator
   //   ---------|--------|--------------
   //     == 0.0 | == 0.0 |  show
   //     == 0.0 | != 0.0 |  ashow
   //     != 0.0 | == 0.0 |  widthshow
   //     != 0.0 | != 0.0 |  awidthshow

   code = ((lpdx != NULL) << 2) +
	  ((breakExtra != (float)0.0) << 1) +
	  (charExtra != (float)0.0);

   if ( (FontInfo->dfType & TYPE_TRUETYPE) &&
		(lppd->lpPSExtDevmode->dm2.iDLFontFmt == TT_DLFORMAT_TYPE42) 
		//  &&
		// (GetCurrBinPPDVal(lppd, &(lppd->drvState.PPDList), ID_PPDSTR_KEY_TYPE42BUGGY)) 
	  )
   {
	  PSSendFragment(lppd,PSFRAG_bS42);
   }

   //  fix for bug 26348: cannot assume break char is 32 !

   if(FontInfo->dfType & PF_GLYPH_INDEX)
      dfBreakChar      = *(LPWORD)&FontInfo->dfDefaultChar  ;
   else
      dfBreakChar     = ((WORD)(FontInfo->dfBreakChar + FontInfo->dfFirstChar)) & 0x00ff;


   DetermineOutputCharacteristics(lppd, &Flavor, &bfBinaryOutput);
   switch (code)
   {
      case 0:
//         PSSendTextChar(lppd, String, count);

      if (bfBinaryOutput)
      {
	 PSSendTextWordBinary(lppd, (LPWORD)String, count);
      }
      else
      {
	 PSSendTextWordAscii7(lppd, (LPWORD)String, count);
      }

      if (BoldFake)
      {
		    PSSendFragment(lppd,PSFRAG_sB);    // Unified Fake-embolding mechansim, 2-28-96
		 }
		 else
		 {
			(*tempptr->PSSendBasic)(lppd,PSOP_show);
		 }
	  break;

	  case 1:
		 (*tempptr->PSSendFloat)(lppd,(float)charExtra);
		 (*tempptr->PSSendFloat)(lppd,0);
//               PSSendTextChar(lppd,String, count);
      if (bfBinaryOutput)
      {
	 PSSendTextWordBinary(lppd, (LPWORD)String, count);
      }
      else
      {
	 PSSendTextWordAscii7(lppd, (LPWORD)String, count);
      }

		 if (BoldFake)
		 {
		    PSSendFragment(lppd,PSFRAG_asB);    // Unified Fake-embolding mechansim
		 }
		 else
		 {
			(*tempptr->PSSendBasic)(lppd,PSOP_ashow);
		 }
	  break;

	  case 2:
		 (*tempptr->PSSendFloat)(lppd,(float)breakExtra); // PostScript adds ax+cx
		 (*tempptr->PSSendFloat)(lppd,0);          // PostScript adds ay+cy
		 (*tempptr->PSSendShort)(lppd,dfBreakChar);
//               PSSendTextChar(lppd, String, count);

      if (bfBinaryOutput)
      {
	 PSSendTextWordBinary(lppd, (LPWORD)String, count);
      }
      else
      {
	 PSSendTextWordAscii7(lppd, (LPWORD)String, count);
      }

		 if (BoldFake)
		 {
		    PSSendFragment(lppd,PSFRAG_wsB);    // Unified Fake-embolding mechansim
		 }
		 else
		 {
			(*tempptr->PSSendBasic)(lppd,PSOP_widthshow);
		 }
		 break;

	  case 3:
		 //    Changed from breakExtra-charExtra to breakExtra
		 //    30-Mar-1993 -by-  [olegs]
		 (*tempptr->PSSendFloat)(lppd,(float)breakExtra); // PostScript adds ax+cx
		 (*tempptr->PSSendFloat)(lppd,0);       // PostScript adds ay+cy
		 (*tempptr->PSSendShort)(lppd,dfBreakChar);
		 (*tempptr->PSSendFloat)(lppd, (float)charExtra);
		 (*tempptr->PSSendFloat)(lppd,0);
//               PSSendTextChar(lppd,String, count);
      if (bfBinaryOutput)
      {
	 PSSendTextWordBinary(lppd, (LPWORD)String, count);
      }
      else
      {
	 PSSendTextWordAscii7(lppd, (LPWORD)String, count);
      }

		 if (BoldFake)
		 {
		    PSSendFragment(lppd,PSFRAG_awsB);    // Unified Fake-embolding mechansim
		 }
		 else
		 {
			(*tempptr->PSSendBasic)(lppd,PSOP_awidthshow);
		 }
	  break;

	 /*
	  * Add xshow. jjia  5/13/96
	  */
	  case 4:
		if (bfBinaryOutput)
		{
		    length += PSSendTextWordBinary(lppd, (LPWORD)String, count);
		}
		else
		{
		    length += PSSendTextWordAscii7(lppd, (LPWORD)String, count);
		}
		if (length > 128)
		{
		    (*tempptr->PSSendCRLF)(lppd);
		    length = 0;
		}
		length += PSSendFragment(lppd, PSFRAG_leftbracket);
		for (i = 0; i < count; i++)
		{
		    idx = 0;         

		    if ( !(FontInfo->dfType & PF_GLYPH_INDEX) &&
			(IsDBCSLeadByteEx(FontInfo->dfCharSet,
			(BYTE)(((int)String[i]) & 0x00FF))) )
		    {
			idx += lpdx[i];
			i++;
		    }

		    idx += lpdx[i];
		    length += (*tempptr->PSSendFloat)(lppd,(float)(idx));
		    if (length > 128)
		    {
			(*tempptr->PSSendCRLF)(lppd);
			length = 0;
		    }
		}
		PSSendFragment(lppd, PSFRAG_rightbracket);
		if (BoldFake)
		{
		    PSSendFragment(lppd,PSFRAG_xsB);    // Unified Fake-embolding mechansim
		}
		else
		{
		    //(*tempptr->PSSendBasic)(lppd,PSOP_xshow);
		    PSSendString(lppd, "XSE "); // fix bug #199475
		}
	  break;
   } // switch(code)

   (*tempptr->PSSendCRLF)(lppd);

   if ( (FontInfo->dfType & TYPE_TRUETYPE) &&
		(lppd->lpPSExtDevmode->dm2.iDLFontFmt == TT_DLFORMAT_TYPE42) 
		// &&
		// (GetCurrBinPPDVal(lppd, &(lppd->drvState.PPDList), ID_PPDSTR_KEY_TYPE42BUGGY))
	  )         
   {
	  PSSendFragment(lppd,PSFRAG_eS42);
   }

   return(retval);
}


/***************************************************************************
*
*                              GetPSVersion
*                
*    Parameter:  LPPDEVICE lppd
*
*    Returns:  int PSVersion (in the form 20xx)
*    Note:     Highly PPD format dependent. Parses option value for the
*              PPD keyword PSVersion: "(2010.101) 1"
*
***************************************************************************/
int FAR PASCAL GetPSVersion(LPPDEVICE lppd)
{

   LPBYTE   lpPSVersionStr;
   int      PSVersion=0, i=0;

   // Get PSVersion fro WPX struct. It is in PPD format, ie: "(20xx.xxx) 1"
   lpPSVersionStr = StringRefToLPBYTE(lppd, ((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->PSVersion.dword);  

   // Unpack the PSVersion and get the relevant part, ie: "20xx"   
   while (*lpPSVersionStr != '(')
      lpPSVersionStr++;
      lpPSVersionStr++;
   while (*lpPSVersionStr == ' ')
      lpPSVersionStr++;

   // We now have PSVersion as a string of format "20xx". 
   // Convert this to an int.

   while(i<4 && *lpPSVersionStr >= '0'  &&  *lpPSVersionStr <= '9')
   {
      PSVersion *= 10;
      PSVersion += *lpPSVersionStr - '0' ;
      lpPSVersionStr++ ;
   }

   return PSVersion;
}

/*This procedure further distinquish GI vs CC, Vert vs Horiz and the 
**style (BI, B, I, R) in the XUID.y field.
** Input 
**    isCC  = 1 if CharCode, =0 if Glyph Index.
**    isVert = 0 if Horizontal, =1 if vertical.
**
**  We us the sum of the following 3 parameter to distinquish the font type
**
**  isCC  = 1 if CharCode, = 0 if Glyph Index.
**  orientation:  horizontal =1, vertical =3
**  style: Regular =0, Bold = 4, italic = 8, BoldItalic = 12
**
**             Reg(0)   B(4)  I(8) BI(12)
**  GI+H =1        1    5     9     13
**  CC+H =2        2    6     10    14
**  GI+V =3        3    7     11    15
**  CC+V =4        4    8     12    16
**  
**  notice: GI are odd, CC are even
**  as the style changes from Regular the value increases.
**  
*/ 
WORD NEAR PASCAL XUIDdotYExt(LPFONTDATARECORD lpFontData, WORD isCC, WORD isVert, 
                               LPPSFONTINFO FontInfo, LPTTFONTINFO lpTTFontInfo)
{
   WORD orientation = isVert? 3: 1; //vertical =3, horiz=1
   WORD base;
   WORD fontBold=0, fontItalic =0;

   if( ( lpTTFontInfo->lfCopy.lfWeight>=700 ) ||
	    ( FontInfo->dfWeight>=700 ) ||
	    lpFontData->BoldFake )
	{
	    fontBold = 1;
	}
	if( lpTTFontInfo->lfCopy.lfItalic ||
	    FontInfo->dfItalic ||
	    lpFontData->ItalicFake  )
	{
	    fontItalic = 1;
	}

    if (fontBold && fontItalic)
       base = 12;
    else if (fontItalic)
       base = 8;
    else if (fontBold)
       base = 4;
    else //regular;
       base = 0;

   return (isCC+base+orientation); 
}


BOOL FAR PASCAL MakeXUIDVector (LPPDEVICE lppd, LPLOGFONT lpLogFont, 
				LPFONTDATARECORD lpFontData, 
				LPPSFONTINFO FontInfo)
{
    LPTABLEENTRY lpTblEntry = NULL;
    HDC hDC = NULL ;
    HFONT hFont = NULL ;
    HFONT hPrevFont = NULL ;
    BOOL bDataFound = FALSE ;
    TABLEDIRECTORY  tableDir;
    DWORD size = 0;
    LPTTFONTINFO lpttfi = (LPTTFONTINFO) ((LPSTR)FontInfo  + FontInfo->dfBitsOffset);
    BOOL isVert;
    WORD  ithTableEntry = 0;
       DWORD checkSum = 0;
    
    isVert = ((lppd->fDBCS & DBCS_VERT)>0) ? 1 : 0;  // Vertical=1 or not(0)

    if (hDC = GetDC(NULL))
      	goto exit ;

    if ((hFont = CreateFontIndirect (lpLogFont) )== NULL)
	      goto exit ;

    if ((hPrevFont = SelectObject (hDC, hFont))== NULL)
	      goto exit ;

    //get the number of tables
    memset((char *)&tableDir, 0, sizeof(TABLEDIRECTORY));
    size = GetTableDirectory(hDC, (LPTABLEDIRECTORY)&tableDir);
    
    if (!tableDir.numTables)
      goto exit;

    //get the size of the Table Entry
    if ((size = GetTableEntry(hDC, NULL, (LPTABLEDIRECTORY)&tableDir)) <= 0)
       goto exit; // get size only

    if ((lpTblEntry = (LPTABLEENTRY) GlobalAllocPtr(GHND, size)) == NULL)
       goto exit;

    //get the content of the Table Directory Entry
    if (!GetTableEntry(hDC, lpTblEntry, (LPTABLEDIRECTORY)&tableDir)) // get data
       goto exit;

    if (!lpFontData)
       goto exit;


//due to bug 287085 where some font vendors give bogus checksum values
//we ara changing the algo for calculating checksums.

   for (ithTableEntry; ithTableEntry < MOTOROLAINT(tableDir.numTables) ; ++ithTableEntry)
   {
      checkSum += (DWORD) lpTblEntry->tag;
      checkSum += (DWORD) lpTblEntry->checkSum;
      checkSum += (DWORD) lpTblEntry->offset;
      checkSum += (DWORD) lpTblEntry->length;
   }
   lpFontData->xuidRec.locaCkSum = (DWORD) checkSum;
   lpFontData->xuidRec.glyfCkSum = 0;
   lpFontData->xuidRec.os2CkSum = 0;

#if 0
    if (!(lpFontData->xuidRec.locaCkSum = (DWORD) GetTableCheckSum(&tableDir, lpTblEntry, LOCA_TABLE)))
       goto exit;

    if (!(lpFontData->xuidRec.glyfCkSum = (DWORD) GetTableCheckSum(&tableDir, lpTblEntry, GLYF_TABLE)))
       goto exit;

    if (!(lpFontData->xuidRec.os2CkSum = (DWORD) GetTableCheckSum(&tableDir, lpTblEntry, OS2_TABLE)))
       goto exit;
#endif
    //get additional info of XUID stuff
    lpFontData->xuidRec.dlType = 2; //most type use 2 except t42/CID
    switch (lpFontData->fontDLType)
    {
       case CC_42:
       case GI_42:
       case CC_CID:
       case GI_CID:
       case CC_T042:
       case GI_T042:
	    lpFontData->xuidRec.dlType = 42;
	    lpFontData->xuidRec.x = isVert ? 2 : 1; //Horz =1, Vert = 2
	 break;

       case CC_1:
       case CC_T01:
	    lpFontData->xuidRec.x = (WORD) FontInfo->dfCharSet;
            lpFontData->xuidRec.y = XUIDdotYExt(lpFontData, 1, isVert, FontInfo, lpttfi);
            
       break;

       case GI_1:
       case GI_T01:
	    lpFontData->xuidRec.x = (WORD) FontInfo->dfPixHeight;
            lpFontData->xuidRec.y = XUIDdotYExt(lpFontData, 0, isVert, FontInfo, lpttfi);

	 break;

       case CC_3:
       case CC_32:
       case CC_T03:
       case CC_T032:
	    lpFontData->xuidRec.x = (WORD) FontInfo->dfCharSet;
            lpFontData->xuidRec.y = XUIDdotYExt(lpFontData, 1, isVert, FontInfo, lpttfi);
	    lpFontData->xuidRec.pixelSize = (DWORD)FontInfo->dfPixHeight; //need to know if this is ok???
	 break;

       case GI_3:
       case GI_32:
       case GI_T03:
       case GI_T032:
	    lpFontData->xuidRec.x = lpttfi->HighByte;
	    lpFontData->xuidRec.pixelSize = (DWORD) FontInfo->dfPixHeight; //need to know if this is ok???
            lpFontData->xuidRec.y = XUIDdotYExt(lpFontData, 0, isVert, FontInfo, lpttfi);
   	 break;
    }

    bDataFound = TRUE;

exit:
    if (!bDataFound)
    {
      lpFontData->xuidRec.locaCkSum = 0;
      lpFontData->xuidRec.glyfCkSum = 0;
      lpFontData->xuidRec.os2CkSum = 0;
      lpFontData->xuidRec.x = 0;
      lpFontData->xuidRec.y = 0;
      lpFontData->xuidRec.pixelSize = 0;
    }

    if (hPrevFont != NULL)
	SelectObject (hDC, hPrevFont) ;

    if (hFont != NULL)
	DeleteObject (hFont) ;

    if (hDC != NULL)
       ReleaseDC(NULL, hDC); 
 
    if (lpTblEntry != NULL)
      GlobalFreePtr(lpTblEntry);

    return bDataFound;
}
