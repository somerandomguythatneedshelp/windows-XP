/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DRIVINIT.H                                                   */
/*                                                                           */
/* Description: Header file for printer driver initialization using          */
/*              ExtDeviceMode() and DeviceCapabilities().                    */
/*                                                                           */
/*****************************************************************************/



/* size of a device name string */
#define CCHDEVICENAME 32

/* current version of specification */
#define DM_SPECVERSION 0x30A        // for Windows 3.1

/* field selection bits */
#define DM_ORIENTATION      0x00000001L
#define DM_PAPERSIZE        0x00000002L
#define DM_PAPERLENGTH      0x00000004L
#define DM_PAPERWIDTH       0x00000008L
#define DM_SCALE            0x00000010L
#define DM_COPIES           0x00000100L
#define DM_DEFAULTSOURCE    0x00000200L
#define DM_PRINTQUALITY     0x00000400L
#define DM_COLOR            0x00000800L
#define DM_DUPLEX           0x00001000L
#define DM_YRESOLUTION      0x00002000L
#define DM_TTOPTION         0x00004000L

#define DM_COLLATE          0x00008000L   
#define DM_FORMNAME         0x00010000L
#define DM_LOGPIXELS        0x00020000L
#define DM_BITSPERPEL       0x00040000L
#define DM_PELSWIDTH        0x00080000L
#define DM_PELSHEIGHT       0x00100000L
#define DM_DISPLAYFLAGS     0x00200000L
#define DM_DISPLAYFREQUENCY 0x00400000L
#define DM_ICMMETHOD        0x00800000L
#define DM_ICMINTENT        0x01000000L
#define DM_MEDIATYPE        0x02000000L
#define DM_DITHERTYPE       0x04000000L

/* Collation selections */
#define DMCOLLATE_TRUE      1   /* Collate multiple output pages */
#define DMCOLLATE_FALSE     0   /* Do not collate multiple output pages  */

/* orientation selections  - Add Rotated Landscape */
#define DMORIENT_PORTRAIT               1
#define DMORIENT_LANDSCAPE              2
#define DMORIENT_ROT_LANDSCAPE          3

#define DMORIENT_FIRST                  DMORIENT_PORTRAIT
#define DMORIENT_LAST                   DMORIENT_ROT_LANDSCAPE

/* paper selections */
#define DMPAPER_FIRST        DMPAPER_LETTER
#define DMPAPER_LETTER       1           // Letter 8 1/2 x 11 in
#define DMPAPER_LETTERSMALL  2           // Letter Small 8 1/2 x 11 in
#define DMPAPER_TABLOID      3           // Tabloid 11 x 17 in
#define DMPAPER_LEDGER       4           // Ledger 17 x 11 in
#define DMPAPER_LEGAL        5           // Legal 8 1/2 x 14 in
#define DMPAPER_STATEMENT    6           // Statement 5 1/2 x 8 1/2 in
#define DMPAPER_EXECUTIVE    7           // Executive"7 1/2 x 10 in
#define DMPAPER_A3           8           // A3 297 x 420 mm
#define DMPAPER_A4           9           // A4 210 x 297 mm
#define DMPAPER_A4SMALL      10          // A4 Small 210 x 297 mm
#define DMPAPER_A5           11          // A5 148 x 210 mm
#define DMPAPER_B4           12          // B4 250 x 354
#define DMPAPER_B5           13          // B5 182 x 257 mm
#define DMPAPER_FOLIO        14          // Folio 8 1/2 x 13 in
#define DMPAPER_QUARTO       15          // Quarto 215 x 275 mm
#define DMPAPER_10X14        16          // 10x14 in
#define DMPAPER_11X17        17          // 11x17 in
#define DMPAPER_NOTE         18          // Note 8 1/2 x 11 in
#define DMPAPER_ENV_9        19          // Envelope #9 3 7/8 x 8 7/8
#define DMPAPER_ENV_10       20          // Envelope #10 4 1/8 x 9 1/2
#define DMPAPER_ENV_11       21          // Envelope #11 4 1/2 x 10 3/8
#define DMPAPER_ENV_12       22          // Envelope #12 4 \276 x 11
#define DMPAPER_ENV_14       23          // Envelope #14 5 x 11 1/2
#define DMPAPER_CSHEET       24          // C size sheet
#define DMPAPER_DSHEET       25          // D size sheet
#define DMPAPER_ESHEET       26          // E size sheet
#define DMPAPER_ENV_DL       27          // Envelope DL
#define DMPAPER_ENV_C5       28          // Envelope C5
#define DMPAPER_ENV_C3       29          // Envelope C3  324 x 458 mm          */
#define DMPAPER_ENV_C4       30          // Envelope C4  229 x 324 mm          */
#define DMPAPER_ENV_C6       31          // Envelope C6  114 x 162 mm          */
#define DMPAPER_ENV_C65      32          // Envelope C65 114 x 229 mm          */
#define DMPAPER_ENV_B4       33          // Envelope B4  250 x 353 mm          */
#define DMPAPER_ENV_B5       34          // Envelope B5  176 x 250 mm          */
#define DMPAPER_ENV_B6       35          // Envelope B6  176 x 125 mm          */
#define DMPAPER_ENV_ITALY    36          // Envelope 110 x 230 mm              */
#define DMPAPER_ENV_MONARCH  37          // Envelope Monarch
#define DMPAPER_ENV_PERSONAL 38          // 6 3/4 Envelope 3 5/8 x 6 1/2 in    */
#define DMPAPER_FANFOLD_US   39          // US Std Fanfold 14 7/8 x 11 in      */
#define DMPAPER_FANFOLD_STD_GERMAN  40   // German Std Fanfold 8 1/2 x 12 in   */
#define DMPAPER_FANFOLD_LGL_GERMAN  41   // German Legal Fanfold 8 1/2 x 13 in */

/* These are #defined in 3.5 in printers.h   */
/* NOTE:DDK says these #defines exist;Vol 3 of SDK says it doesn't */
/* eg DMPAPER_LETTER_EXTRA */

#define DMPAPER_LETTER_EXTRA             50  // Letter Extra 9 \275 x 12 in
#define DMPAPER_LEGAL_EXTRA              51  // Legal Extra 9 \275 x 15 in
#define DMPAPER_TABLOID_EXTRA            52  // Tabloid Extra 11.69 x 18 in
#define DMPAPER_A4_EXTRA                 53  // A4 Extra 9.27 x 12.69 in
#define DMPAPER_LETTER_TRANSVERSE        54  // Letter Transverse 11 x 8 \275 in
#define DMPAPER_A4_TRANSVERSE            55  // Transverse 297 x 210 mm
#define DMPAPER_LETTER_EXTRA_TRANSVERSE  56  // Letter Extra Transverse 12 x 9\275 in

#define DMPAPER_LAST        DMPAPER_LETTER_EXTRA_TRANSVERSE
#define DMPAPER_USER        256

/* bin selections */
#define DMBIN_FIRST         DMBIN_UPPER
#define DMBIN_UPPER         1
#define DMBIN_ONLYONE       1
#define DMBIN_LOWER         2
#define DMBIN_MIDDLE        3
#define DMBIN_MANUAL        4
#define DMBIN_ENVELOPE      5
#define DMBIN_ENVMANUAL     6
#define DMBIN_AUTO          7
#define DMBIN_TRACTOR       8
#define DMBIN_SMALLFMT      9
#define DMBIN_LARGEFMT      10
#define DMBIN_LARGECAPACITY 11
#define DMBIN_CASSETTE      14
#define SINGLE_SLOT         15
#define DMBIN_LAST          SINGLE_SLOT

#define DMBIN_USER          256     /* device specific bins start here */

/* user defined options typically begin at the following number */
#define DMOPT_USER          256

/* print qualities */
#define DMRES_DRAFT         (-1)
#define DMRES_LOW           (-2)
#define DMRES_MEDIUM        (-3)
#define DMRES_HIGH          (-4)

/* color enable/disable for color printers */
#define DMCOLOR_MONOCHROME  1
#define DMCOLOR_COLOR       2

/* duplex enable */
#define DMDUP_SIMPLEX    1
#define DMDUP_VERTICAL   2
#define DMDUP_HORIZONTAL 3
#define DMDUP_FIRST      DMDUP_SIMPLEX
#define DMDUP_LAST       DMDUP_HORIZONTAL

/* landscape orientation angle selections */
#define DMORIENT_PLUS90          1
#define DMORIENT_MINUS90         2
#define DMORIENT_ANY             3
#define DMORIENT_ANGLE_FIRST     DMORIENT_PLUS90
#define DMORIENT_ANGLE_LAST      DMORIENT_ANY

/* truetype capabilities */
#define DCTT_BITMAP      0x0000001L
#define DCTT_DOWNLOAD    0x0000002L
#define DCTT_SUBDEV      0x0000004L

#define MAX_PORT_NAME    32

typedef struct _devicemode 
{
   char  dmDeviceName[CCHDEVICENAME];
   WORD  dmSpecVersion;
   WORD  dmDriverVersion;
   WORD  dmSize;
   WORD  dmDriverExtra;
   DWORD dmFields;
   short dmOrientation;
   short dmPaperSize;
   short dmPaperLength;
   short dmPaperWidth;
   short dmScale;
   short dmCopies;
   short dmDefaultSource;
   short dmPrintQuality;
   short dmColor;
   short dmDuplex;
   short dmYResolution;
   short dmTTOption;

   int   dmCollate;
   char  dmFormName[CCHFORMNAME];
   WORD  dmLogPixels;
   DWORD dmBitsPerPel;
   DWORD dmPelsWidth;
   DWORD dmPelsHeight;
   DWORD dmDisplayFlags;
   DWORD dmDisplayFrequency;
   DWORD dmICMMethod;
   DWORD dmICMIntent;
   DWORD dmMediaType;
   DWORD dmDitherType;
   DWORD dmICCManufacturer;
   DWORD dmICCModel;

   /* char dmPort[MAX_PORT_NAME]; */
   /* char  dummy[2];  MS assumes this structure is at least this size */
   // DRVSTATE drvState;

} DEVMODE;

typedef DEVMODE * PDEVMODE, NEAR * NPDEVMODE, FAR * LPDEVMODE;

/* mode selections for the device mode function */
#define DM_UPDATE           1
#define DM_COPY             2
#define DM_PROMPT           4
#define DM_MODIFY           8

#define DM_IN_BUFFER        DM_MODIFY
#define DM_IN_PROMPT        DM_PROMPT
#define DM_OUT_BUFFER       DM_COPY
#define DM_OUT_DEFAULT      DM_UPDATE

/* device capabilities indices */
#define DC_FIELDS           1
#define DC_PAPERS           2
#define DC_PAPERSIZE        3
#define DC_MINEXTENT        4
#define DC_MAXEXTENT        5
#define DC_BINS             6
#define DC_DUPLEX           7
#define DC_SIZE             8
#define DC_EXTRA            9
#define DC_VERSION          10
#define DC_DRIVER           11
#define DC_BINNAMES          12      // support code added. Shyam Vijay, 1/20/93
#define DC_ENUMRESOLUTIONS  13
#define DC_FILEDEPENDENCIES 14
#define DC_TRUETYPE         15
#define DC_PAPERNAMES       16
#define DC_ORIENTATION      17
#define DC_COPIES           18

/* export ordinal definitions */
#define PROC_EXTDEVICEMODE      MAKEINTRESOURCE(90)
#define PROC_DEVICECAPABILITIES MAKEINTRESOURCE(91)
#define PROC_OLDDEVICEMODE      MAKEINTRESOURCE(13)

/* define types of pointers to ExtDeviceMode() and DeviceCapabilities()
 * functions
 */
typedef WORD FAR PASCAL FNDEVMODE(HWND, HANDLE, LPDEVMODE, LPSTR, LPSTR,
                                  LPDEVMODE, LPSTR, WORD);

typedef FNDEVMODE FAR * LPFNDEVMODE;

typedef DWORD FAR PASCAL FNDEVCAPS(LPSTR, LPSTR, WORD, LPSTR, LPDEVMODE);

typedef FNDEVCAPS FAR * LPFNDEVCAPS;


