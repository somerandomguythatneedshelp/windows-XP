/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DIBTODEV.C                                                   */
/*                                                                           */
/* Description: This module contains the function which copies               */
/* device-independent bitmap data directly to the given device.              */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_DIBSEG)


short _loadds FAR PASCAL StretchDIB(LP,WORD,WORD,WORD,WORD,WORD,WORD,WORD,WORD,
                                    WORD,LP,LPBITMAPINFO,LPSTR,DWORD,LPPBRUSH,
                                    LPDRAWMODE,LPRECT);

/****************************************************************************
*                               DIBToDevice
*  function:
*       The function converts the bitmap data to the appropriate 
*       device-specific format and copies the resulting bits to  the device.
*  prototype:
*       short FAR PASCAL DIBToDevice(LP lpDevice, WORD DestX, WORD DestY,
*                                    WORD Start, WORD RstrLines, LPRECT lpClip,
*                                    LPDRAWMODE lpDrawMode, LP lpBits, 
*                                    LPBITMAPINFO lpBitmapInfo,
*                                    LPSTR lpConversion);
*  parameters:
*       LP           lpDevice -- Points to a PDEVICE structure specifying the 
*                                device to receive the device-independent bitmap.
*       WORD         DestX -- x-coordinate to receive the top left corner of 
*                             the device-independent bitmap.
*       WORD         DestY -- y-coordinate to receive the top left corner of 
*                             the device-independent bitmap.       
*       WORD         Start -- Starting scan line.      
*       WORD         RstrLines -- Number of scan lines to copy.
*       LPRECT       lpClip -- Points to a RECT structure specifying the 
*                              clip rectangle.
*       LPDRAWMODE   lpDrawMode -- Points to a DRAWMODE structure.
*       LP           lpBits -- Points to a buffer containing the device-independent
*                              bitmap bits.
*       LPBITMAPINFO lpBitmapInfo -- Points to a BITMAPINFO structure.
*       LPSTR        lpConversion -- Points to an array of color-translation 
*                                    values for converting palette colors to
*                                    actual device colors.
*       
*  returns:
*       short == number of scan lines actually copied : if successful
*                0 : if error or no scan lines are copied 
*       
*****************************************************************************/

short _loadds FAR PASCAL DIBToDevice(LP lpDevice,WORD DestX,WORD DestY,
                                     WORD Start,WORD RstrLines,LPRECT lpClip,
                                     LPDRAWMODE lpDrawMode,LP lpBits, 
                                     LPBITMAPINFO lpBitmapInfo,
                                     LPSTR lpConversion)
{
//   RECT      Clip;
   DWORD     DIBHeight,rop,xScale,yScale,Accum;
   WORD      GetSet;
   WORD      DstX,DstY,DstXE,DstYE;
   WORD      SrcX,SrcY,SrcXE,SrcYE;
   short     sRC;
   LPPBRUSH  lpBrush;
   LPPDEVICE lppd;
   DWORD     NumScans = RstrLines;
   
   sRC  = 0;       // Indicate failure.
   lppd = (LPPDEVICE)lpDevice;
   
   if (lppd->sMagic == LUCAS)
   {
         if (lppd->graphics.ScaleMode == 2)
         {
            xScale = (DWORD)lppd->graphics.xScale; // Scale factors from
            yScale = (DWORD)lppd->graphics.yScale; // ESCSetDIBScaling()
         }
         else                                // ScaleMode 0 or 1
         {
            xScale = (DWORD)lpBitmapInfo->bmiHeader.biWidth;
            yScale = (DWORD)lpBitmapInfo->bmiHeader.biHeight;
         }                                   
   
   // The diagram below illustrates the geometry of the DIB. The figure
   // on the left is the source. The one on the right is the destination.
   // Some important features of DIBs are:
   //
   //      o - The width of a DIB sent to the driver is always
   //          a multiple of DWORDS( i.e. Width = n*sizeof(DWORD) )
   //
   //      o - The DIB bits are pointed to by lpBits and points to
   //          the bottom of the DIB( i.e. the DIB origin is the
   //          lower left hand corner).
   //
   //      o - The DIB bits are output as they occur in the lpBits buffer
   //          and therefore appear to be inverted( see the diagram ).
   //          PostScript will perform the inversion.
   //
   //                                                   (DestX,DestY)
   //                                     Start             { [-----------] -----
   //                                     -----  * yScale...{ [           ]   |
   //                                    DIBHeight          { [           ]   |
   //                                                         [-----------]   |
   //            DIB                                        { [ abc////// ]   |
   //            [--------]   ---                           { [ ///////// ]   |
   //            [--------]    |           Scans            { [ ///////// ]   |
   //         {  [ ///xyz ]    |           ----- * yScale...{ [ ///////// ]   |
   // Scans...{  [ ////// ]    |         DIBHeight          { [ ///////// ] yScale
   //         {  [ ////// ]    |                            { [ ///////// ]   |
   //      ----->[ abc/// ] DIBHeight                       { [ //////xyz ]   |
   //      |     [--------]    |                              [-----------]   |
   //  lpBits    [        ]    |                              [           ]   |
   //  -and-     [        ]    |                              [           ]   |
   //  Start    -|--------]   ---                             [           ]   |
   //          (0,0)                                          [           ]   |
   //                                                         [           ]   |
   //            |-Width--|                                   [-----------] -----
   //
   //                                                         |--xScale---|
   
   
   
         DIBHeight   = lpBitmapInfo->bmiHeader.biHeight;
         
         GetSet      = 0;                           // 0 - Set  1 - Get
         rop         = SRCCOPY;
         lpBrush     = (LPPBRUSH)NULL;
         
         SrcX        = 0;
         SrcY        = 0;
         SrcXE       = (WORD)lpBitmapInfo->bmiHeader.biWidth;
         SrcYE       = (WORD)NumScans;
         
         DstX        = DestX;
         Accum       = (Start*yScale)/DIBHeight;    // Avoid product overflows
         DstY        = DestY + (WORD)Accum;
         DstXE       = (WORD)xScale;
         Accum       = (NumScans*yScale)/DIBHeight; // Avoid product overflows
         DstYE       = (WORD)Accum;
         
//         Clip.top    = DstY;
//         Clip.left   = DstX;
//         Clip.right  = DstX + DstXE;
//         Clip.bottom = DstY + DstYE;
         
         
         // StretchDIB() is also a public entry point and may be called by GDI
         // directly.
         
         sRC = StretchDIB((LP)lppd,GetSet,DstX,DstY,DstXE,DstYE,SrcX,SrcY,
                    SrcXE,SrcYE, lpBits,lpBitmapInfo,lpConversion,rop,
                    lpBrush,lpDrawMode,(LPRECT) lpClip);
         
   } 
   
   return(sRC);

} // END DIBToDevice
