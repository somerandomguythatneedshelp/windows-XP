//  fproto.h - function declarations for getwpx.dll


//  -------------  functions defined in parse1.c -----------------------


BOOL  FAR   PASCAL  initWPXinfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable,
LPBYTE   lpPPDName ) ; 


BOOL  NEAR  PARSE1SEG  PASCAL  initPaperInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable ) ;


BOOL  NEAR   PARSE1SEG PASCAL  initInputSlotInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable ) ;


BOOL  NEAR   PARSE1SEG PASCAL  initInstalledMemoryInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable ) ;


BOOL  NEAR   PARSE1SEG PASCAL  initDuplexingInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock  ) ;


BOOL  NEAR   PARSE1SEG PASCAL  initCollationInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock  ) ;
                              
                              
BOOL  NEAR   PARSE1SEG PASCAL  initOutputOrderInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock,
LPBYTE lpStringTable   ) ;


BOOL  NEAR    PARSE1SEG PASCAL  initResolutionInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock) ;


BOOL  NEAR    PARSE1SEG PASCAL  initOutputBinInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable ) ;


BOOL  NEAR    PARSE1SEG PASCAL  initMediaTypeInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable ) ;



short  FAR  PASCAL  scale(
short  mul1,
short  mul2,
short  divisor) ;


BOOL NEAR PARSE1SEG PASCAL  initPrinterCaps(LPPRINTERINFO lpPrinterInfo, 
                                            LPBYTE lpStringTable ) ;



BOOL  NEAR    PARSE1SEG PASCAL  initPrinterInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable,
LPBYTE   lpPPDName ) ;



BOOL  NEAR    PARSE1SEG PASCAL  initCustPageInfo(
LPPRINTERINFO  lpPrinterInfo) ;


BOOL  NEAR    PARSE1SEG PASCAL  extractParams(
LPPARAM  lpParam,     // the structure
LPBYTE   lpOption) ; // "Width" for example


BOOL  FAR  PASCAL  convStrToInt(
LPLONG  lpValue ,  // return converted number here.
HPBYTE   hpStr ,    // string to be converted
short     power ) ;   // include power digits to right of decimal pt. if


DWORD  NEAR   PARSE1SEG PASCAL  extractResolution(
HPBYTE   hpStr ) ;   // option keyword to be parsed


WORD    FAR  PASCAL  strtblcmp(
long    lengthOffset ,   //  two words - self explainatory
LPBYTE  lpStringTable ,  //  points to byte 0 of stringTable
HPBYTE  hpBuf  ) ;        //  points to normal NULL terminated string.


// ------------ functions defined in parse2.c ----------


BOOL    FAR  PASCAL  createWPXfileFromPPDnow(
LPBYTE  PPDfilename,  // full pathname of root PPD file, including extension
LPBYTE  WPXfilename) ;  // full pathname of target WPD file



long  NEAR  PARSE2SEG PASCAL InsertFileContents(
LPBYTE  filename,  // file containing contents to be read
long    insertionPt ,  // offset at which to insert contents from filename.
long    bytesToShift ) ; // number of bytes residing in hpBuf beyond the


void   NEAR PARSE2SEG  PASCAL  shiftNBytes( 
HPBYTE   hpDest,
HPBYTE   hpSrc ,
long     numBytes) ;


long  NEAR  PARSE2SEG PASCAL  ScanForInclude(
long  StartScan ,
long  scanCount ,
LPBYTE    incFilename ,
WORD   bufSiz );  //  max num bytes to write into  buffer incFilename.


WORD   NEAR  PARSE2SEG PASCAL  IndexKeywords(
LPKEYENTRY  lpKeyEntry,
HPBYTE   hpBuf,
long     bufCount );    // number bytes to read in hpBuf.


WORD   NEAR  PASCAL  determineKeywordValue(HPBYTE   hpBuf, WORD  keyLen) ;


WORD   FAR  PASCAL  searchKeywordValue(HPBYTE   hpBuf) ;


LPBYTE  FAR  PASCAL  StringRefToLP(STRINGREF  stringRef) ;


WORD  NEAR  PASCAL  loadSymbolTable(
   LPKEYENTRY  lpKeyEntry,
   WORD        numKeywords ) ;


HPBYTE  NEAR  PASCAL  extractOption(
LPHPBYTE  lphpNext ,  //  initially points to token, later points
BOOL    bSymbol ,     //  TRUE if parsing for symbolName
LPHPBYTE  lphpTranslation) ;  // places pointer to option translation string here.


void  NEAR  PASCAL  SetKeyEntryFlags(
   LPKEYENTRY  lpKeyEntry,
   WORD        numKeywords ) ;

void  NEAR  PASCAL  SetKeyEntryJCLFlag(
   LPKEYENTRY  lpKeyEntry,
   WORD        numKeywords ) ;

HPBYTE  FAR  PASCAL  extractQuotedLiteral(
LPHPBYTE  lphpNext,  //  initially points at or before quote
BOOL    symbolOK ) ;  //  set true if a symbol may be used instead of literal.


WORD  FAR  PASCAL  hstrcmp(HPBYTE  str1, HPBYTE  str2) ;


void  FAR  PASCAL  hstrcpyn(
HPBYTE  hpDest,
HPBYTE  hpSrc,
long    count ) ;


void  NEAR  PASCAL  fillKeyEntries(
LPKEYENTRY  lpKeyEntry,
WORD        numKeywords ) ;  // hpBuf is unnecessary! the entry table has all pointers!


HPBYTE  NEAR  PASCAL  extractValue(
LPHPBYTE    lphpToken ,  // returns pointer to end of string.
LPBOOL    lpbQuoted ) ;  //  function sets to TRUE if value was quoted or Symbol


HPBYTE   NEAR  PASCAL  extractStringValue(
LPHPBYTE    lphpNext) ;  //  initially points to string value, later points


LPBYTE  FAR  PASCAL  extractStringToken(
LPLPBYTE    lplpNext ) ;  //  initially points to token, later points

long  FAR  PASCAL  addTransStringToTable(
HPBYTE   hpStr) ;  //  translation source string


long  FAR  PASCAL  addQuotedStringToTable(
HPBYTE   hpStr,   //  source string
LPBYTE   lpBuf,   //  possible destination
WORD     bufSiz) ;  //  size of lpBuf if any.

long  FAR  PASCAL  addParenStringToTable(
HPBYTE   hpStr,   //  source string
LPBYTE   lpBuf,   //  possible destination
WORD     bufSiz) ;  //  size of lpBuf if any.


long  FAR  PASCAL  addStringToTable(
HPBYTE   hpStr) ;

long  FAR  PASCAL  addBracedStringToTable(
HPBYTE   hpStr) ;


BYTE     NEAR  PASCAL  ReadHexDigit(
BYTE     hexDigit);  //  should be a value from '0' - '9' , 'a' - 'f'


DWORD  NEAR  PASCAL  CountNewUIKeywords(LPKEYENTRY  lpKeyEntry, 
         LPNEWUIKEYWORDS  lpNewUIKeywords) ;

void  NEAR  PASCAL  initMainKeyWordsTable(void) ;

DWORD  FAR  PASCAL  crc32(HPBYTE buff, DWORD  length) ;

//  ---------------  functions defined in parse3.c ------------------------


BOOL  FAR   PASCAL  initOpenUIstructs(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable ) ;


BOOL  FAR   PASCAL  initOrderDependency(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable ) ;


void  FAR   PASCAL     removeZeroOptions(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock,
LPWORD     lpSection) ;


BOOL  FAR   PASCAL  initUIConstraints(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable ) ;


BOOL  FAR   PASCAL     initJCLinfo(LPJCLINFO  lpJCLinfo) ;


BOOL  FAR   PASCAL     initFontList(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable ) ;


WORD  FAR   PASCAL  findQueryAndDefaultKeyword(
WORD   baseKeyword,   // index of base Keyword
LPWORD  lpDefaultKeyword, 
LPBYTE  lpStringTable) ;


WORD  NEAR   PASCAL  addConstraint(
WORD  UIconstraintIndex,     //  index to first UI_constraints element in link
WORD  constrainedMainIndex,
WORD  constrainedOptionIndex) ;


BOOL  FAR   PASCAL     initNoneOptionIndex(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable ) ;


//  ---------------  functions defined in parse4.c ------------------------

void  FAR   PASCAL   InitISOLatin1Table(void) ;
BOOL  FAR   PASCAL   EncodeString(LPBYTE  table, STRINGREF   string) ;


BOOL  NEAR   PARSE1SEG PASCAL   setSlotID(
STRINGREF   optionName ,
LPINPUTSLOTINFO   lpExtraInputSlotInfo, 
LPWORD   lpUndefinedID  ) ;


BOOL  NEAR   PARSE1SEG PASCAL   setPaperID(  
HPBYTE   optionName ,
LPPAPERINFO   lpExtraPaperInfo, 
LPWORD   lpUndefinedID  ) ;


void  NEAR   PARSE1SEG PASCAL   scalePaperIDtable( void )  ;






//  ---------------  functions defined in fileman1.c ------------------------



BOOL   NEAR  PASCAL  verifyTree(
LPBYTE   lpdsWritableSubdir) ;


void   NEAR  PASCAL  appendPath(
LPBYTE  lpRootPath ,
LPBYTE  lpSubPath  ) ;


BOOL  NEAR  PASCAL  extractFileNameFromIndex(
LPBYTE  lpModelName,
LPBYTE  lpFileName ,
WORD    Bufsize    ,  // size of lpFileName  (dest buffer)
LPBYTE  lpIndex )  ;


HPBYTE   NEAR  PASCAL  ReadFileIntoHBuf(
LPBYTE  lpFileName ,  // file to read
LPDWORD  lpnbytes  )  ;


BOOL   NEAR  PASCAL  indexWPXs(
LPBYTE   lpIndexPath )  ;


LPBYTE NEAR PASCAL EnumFilesInDirectory(LPSTR lpDirectory,
                                        LPSTR fileSpec) ;



WORD  NEAR  PASCAL  pwstrncmp(
LPBYTE    lpStr1 ,
LPBYTE    lpStr2 ,
WORD   count ) ;



LPBYTE    NEAR  PASCAL  pwstrcpy(
LPBYTE    destBuf,
LPBYTE    srcString ) ;


BOOL   NEAR  PASCAL  extractWPXmodelName(
LPBYTE   lpModelName ,  //  fills in this string.  Caller must supply
LPBYTE   lpFileName  ,  //  briefly opens this for reading.
WORD     Bufsize ) ;


BOOL   NEAR  PASCAL  appendEntryToIndex(
LPBYTE  lpModelName,
LPBYTE  lpFileName,
LPBYTE  lpIndex ) ;


BOOL  NEAR  PASCAL  createWPXfile(
LPBYTE   lpModelName ,
LPBYTE   lpFileName  ,
LPBYTE   lpIndexSubDir ,  // the subdir where indicies are to be found.
WORD     wBufSize ) ;


BOOL   NEAR  PASCAL  createWPXfileFromPPDs(
LPBYTE   lpModelName,
LPBYTE   lpFileName ,
LPBYTE   lpIndexSubDir) ;


BOOL   NEAR  PASCAL  indexPPDs(
LPBYTE   lpIndexPath )  ;


BOOL   NEAR  PASCAL  extractPPDmodelName(
LPBYTE   lpModelName ,  //  fills in this string.  Caller must supply
LPBYTE   lpFileName  ,  //  briefly opens this for reading.
WORD     Bufsize  )  ;


LPBYTE  NEAR  PASCAL  filenameonly(
LPBYTE  fullPathName ) ;



VOID  FAR   PASCAL  errorMsg(
WORD     function,
WORD     error) ;


VOID  FAR   PASCAL  errorString(
HPBYTE     string);


WORD  FAR  PASCAL  obtainWPXfile(
LPBYTE  lpModelName,
LPBYTE  lpFileName ,
WORD    Bufsize    ,  // size of lpFileName  (dest buffer)
BOOL    bNukeIndex ) ;

BOOL FAR PASCAL GetPPDFileName(
LPBYTE  lpModelName,
LPBYTE  lpPPDFileName,
WORD    wSize,
LPBYTE  lpIndexSubDir);

BOOL FAR PASCAL CreateNewWPXFile(LPSTR lpszModelName, BOOL bCreate);

//  srini's font module.

BOOL  FAR   PASCAL InstallPrinterFonts(
LPPRINTERINFO lpPrinterInfo, 
LPBYTE  lpStringHeap,
LPBYTE  lpArrayHeap) ;

BOOL FAR PASCAL GetPFMFileName(LPBYTE  lpFaceName,
LPBYTE  lpFileName ,
WORD    Bufsize    ,    // size of lpFileName  (dest buffer)
LPBYTE  lpIndex ) ;     // full path where indexfile is expected.

BOOL  FAR  PASCAL  indexPFMs(
LPBYTE   lpIndexPath ) ;  // caller supplies full path and name of index.
                          // and of course verifies subdir is writable.

LONG FAR PASCAL 
GetPPDNameFromModelName(LPBYTE lpModelName, LPBYTE lpPPDName, WORD wBufSize);

LONG FAR PASCAL 
GetDriverNameFromModelName(LPBYTE lpModelName, LPBYTE lpDriverName, WORD wBufSize);

LONG FAR PASCAL 
GetHelpNameFromModelName(LPBYTE lpModelName, LPBYTE lpHelpName, WORD wBufSize);

LONG FAR PASCAL 
GetIniCreatorFromModelName(LPBYTE lpModelName, LPBYTE lpHelpName, WORD wBufSize);

BOOL  FAR  PASCAL     SupportedEncoding( LPBYTE lpEncoding );
BOOL  FAR  PASCAL     IsMinchoOrGothic( LPBYTE   lpFontname );
BOOL  FAR  PASCAL     IsDBCSPFont( LPBYTE lpFontname);
BOOL  FAR  PASCAL     Is90ms( LPBYTE lpFontname);
BOOL  FAR  PASCAL     IsRKSJ( LPBYTE lpFontname);

//-------------------  entry point in oldwpd.c ----------------------

BOOL FAR PASCAL ConvertOldWPD(LPSTR lpModelName,
                               LPSTR lpPath,
                               WORD  wBufSize) ;

