/* CM_VerSion fxl.c atm05 1.2 10076.eco sum= 34142 */
/* CM_VerSion fxl.c atm04 1.5 07436.eco sum= 31095 */
/*
  fxl.h

Copyright (c) 1992 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of
Adobe Systems Incorporated.  Many of the intellectual and
technical concepts contained herein are proprietary to Adobe,
are protected as trade secrets, and are made available only to
Adobe licensees for their internal use.  Any reproduction or
dissemination of this software is strictly forbidden unless
prior written permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks of
Adobe Systems Incorporated.

Original version: Tom Malloy: Feb 5, 1992
Revision History
Paul Sholtz: Feb 12, 1992
End Revision History.
*/

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif

#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES
#include BUILDCH
#include FP
#include "fxl.h"

/*
 * DEBUG_FXL
 *	turning this on makes all Fxl computations check their results
 *	against doubles.  makes use of stdio for reporting errors.
 */

#ifndef DEBUG_FXL
#define DEBUG_FXL	0
#endif

/* macros */

#define mostSigBit	0x40000000
#define Odd(x)		((x) & 1)
#define expFixed	14	/* difference in exponent from Fixed to Frac */
#define expInteger	30	/* difference in exponent from integer to Frac */
#define fracScale	1073741824.0	/* i=1, f=30 , range [-2, 2) */


#if BCMAIN || DEBUG_FXL
PUBLIC double FxlToDouble ARGDEF1(Fxl, fxl) {
  double dbl = fxl.mantissa;
  IntX shift = fxl.exp - expInteger;

  if (shift < 0)
    while (shift++ < 0)
      dbl *= 0.5;
  else
    while (shift-- > 0)
      dbl *= 2.0;
  return dbl;
}
#endif

#if DEBUG_FXL
PRIVATE procedure check ARGDEF3(boolean, cond, IntX, op, char *, str) {
  if (!cond) {
    fprintf(stderr, "FxlCheck failed on %c: %s\n", op, str);
    abort();
  }
}

PRIVATE procedure FxlCheck ARGDEF4(IntX, op, Fxl, af, Fxl, bf, Fxl, rf) {
  double a, b, r, r2, threshold;
  IntX shift;

  a = FxlToDouble(af); 
  b = FxlToDouble(bf); 
  r = FxlToDouble(rf);
  switch (op) {
  case '+':	r2 = a + b;	break;
  case '-':	r2 = a - b;	break;
  case '*':	r2 = a * b;	break;
  case '/':	r2 = a / b;	break;
  case '$':	r2 = os_sqrt(a); break;
  default:
    fprintf(stderr, "FxlCheck called with unknown op: %c\n", op);
    return;
  }

  check((r < 0) == (r2 < 0), op, "sign mismatch");
  /* Just a swag - there ought to be about 24 bits of accuracy */
  threshold = 200.0;
  shift = rf.exp - expInteger;
  if (shift < 0)
    while (shift++ < 0)
      threshold *= 0.5;
  else
    while (shift-- > 0)
      threshold *= 2.0;
  check((-threshold <= r - r2) && (r - r2 < threshold), op, "threshold error");
}

PUBLIC Fxl Xfxladd ARGDECL2(Fxl, a, Fxl, b);
PUBLIC Fxl fxladd ARGDEF2(Fxl, a, Fxl, b) {
  Fxl r = Xfxladd(a, b);
  FxlCheck('+', a, b, r);
  return r;
}
#define	fxladd	Xfxladd

PUBLIC Fxl Xfxlsub ARGDECL2(Fxl, a, Fxl, b);
PUBLIC Fxl fxlsub ARGDEF2(Fxl, a, Fxl, b) {
  Fxl r = Xfxlsub(a, b);
  FxlCheck('-', a, b, r);
  return r;
}
#define	fxlsub	Xfxlsub

PUBLIC Fxl Xfxlmul ARGDECL2(Fxl, a, Fxl, b);
PUBLIC Fxl fxlmul ARGDEF2(Fxl, a, Fxl, b) {
  Fxl r = Xfxlmul(a, b);
  FxlCheck('*', a, b, r);
  return r;
}
#define	fxlmul	Xfxlmul

PUBLIC Fxl Xfxldiv ARGDECL2(Fxl, a, Fxl, b);
PUBLIC Fxl fxldiv ARGDEF2(Fxl, a, Fxl, b) {
  Fxl r = Xfxldiv(a, b);
  FxlCheck('/', a, b, r);
  return r;
}
#define	fxldiv	Xfxldiv

PUBLIC Fxl Xfxlsqrt ARGDECL1(Fxl, fxl);
PUBLIC Fxl fxlsqrt ARGDEF1(Fxl, fxl) {
  Fxl r = Xfxlsqrt(fxl);
  FxlCheck('$', fxl, fxl, r);
  return r;
}
#define	fxlsqrt	Xfxlsqrt

#endif /* DEBUG_FXL */


PUBLIC Fixed FxlToFixed ARGDEF1(Fxl, fxl) {
  Fixed f = fxl.mantissa;
  IntX shift = fxl.exp - expFixed;
  boolean neg = false;

  if (f == 0 || shift == 0)
    return f;
  else if (shift < 0) {
    Fixed tempF = f >> (-shift - 1);
    if (tempF < 0) {
      neg = true;
      tempF = -tempF;
    }
    f = (tempF >> 1) + (tempF & 1);
    return neg ? -f : f;
  } else
    return (fxl.mantissa < 0) ? FixedNegInf : FixedPosInf;
}

PUBLIC Frac FxlToFrac ARGDEF1(Fxl, fxl) {
  Fixed f = fxl.mantissa;
  IntX shift = fxl.exp;
  boolean neg = false;

  if (f == 0 || shift == 0)
    return f;
  else if (shift < 0) {
    Fixed tempF = f >> (-shift - 1);
    if (tempF < 0) {
      neg = true;
      tempF = -tempF;
    }
    f = (tempF >> 1) + (tempF & 1);
    return neg ? -f : f;
  } else
    return (fxl.mantissa < 0) ? FixedNegInf : FixedPosInf;
}

/* mkfxl -- create a normalized Fxl from mantissa and exponent */
PRIVATE Fxl mkfxl ARGDEF2(Frac, mantissa, IntX, exp) {
  Fxl fxl;
  if (mantissa == 0)
    exp = 0;
  else {
    boolean neg;
    if (mantissa >= 0)
      neg = false;
    else {
      mantissa = -mantissa;
      neg = true;
    }
    for (; (mantissa & mostSigBit) == 0; exp--)
      mantissa <<= 1;
    if (neg)
      mantissa = -mantissa;
  }
  fxl.mantissa = mantissa;
  fxl.exp = exp;
  return fxl;
}

PUBLIC Fxl FixedToFxl ARGDEF1(Fixed, f) {
  return mkfxl(f, expFixed);
}

PUBLIC Fxl Int32ToFxl ARGDEF1(Int32, i) {
  return mkfxl(i, expInteger);
}

/* fxlnormalize -- Guarantee that Fxl mantissa (as a frac) is in [1 .. 2) */
PUBLIC Fxl fxlnormalize ARGDEF1(Fxl, fxl) {
  return mkfxl(fxl.mantissa, fxl.exp);
}

PUBLIC Fxl fxladd ARGDEF2(Fxl, a, Fxl, b) {
  Frac mantissa, fa, fb;
  IntX shift, exp;

  if (FxlIsZero(a))
    return b;
  if (FxlIsZero(b))
    return a;

  shift = a.exp - b.exp;
  if (shift < 0) {
    Fxl t;
    t = a;
    a = b;
    b = t;
    shift = -shift;
  }

  exp = a.exp;
  fa = a.mantissa;
  fb = b.mantissa;
  if (shift > 0)
    if (fb >= 0) {
      fb >>= (shift - 1);
      fb = (fb >> 1) + Odd(fb);
    } else {
      fb = (-fb) >> (shift - 1);
      fb = -((fb >> 1) + Odd(fb));
    }

  if ((fa < 0) == (fb < 0)) {		/* signs alike */
    boolean neg = (fa < 0);
    unsigned long f;
    if (neg) {
      fa = -fa;
      fb = -fb;
    }
    f = fa + fb;
    if (f >= (Card32) 0x80000000l) {		/* overflow */
      mantissa = (f >> 1) + Odd(f);
      exp++;
    } else
      mantissa = f;
    if (neg)
      mantissa = -mantissa;
  } else
    mantissa = fa + fb;

  return mkfxl(mantissa, exp);
}

PUBLIC Fxl fxlsub ARGDEF2(Fxl, a, Fxl, b) {
  b.mantissa = -b.mantissa;
  return fxladd(a, b);
}

PUBLIC Fxl fxlmul ARGDEF2(Fxl, a, Fxl, b) {
  Frac f;

  /* Force a to be in [.5 .. 1) (as Frac!) to keep in range */
  if (a.mantissa >= 0)
    f = (a.mantissa >> 1) + Odd(a.mantissa);
  else
    f = -(((-a.mantissa) >> 1) + Odd(a.mantissa));

  return mkfxl(fracmul(f, b.mantissa), a.exp + b.exp + 1);
}

PUBLIC Fxl fxldiv ARGDEF2(Fxl, a, Fxl, b) {
  Frac mantissa;
  IntX exp;

  mantissa = fracdiv(a.mantissa, b.mantissa);
  exp = a.exp - b.exp;
  return mkfxl(mantissa, exp);
}

PUBLIC Fxl fxlsqrt ARGDEF1(Fxl, fxl) {
  Frac mantissa;
  IntX exp;

  /* assert(fxl.mantissa >= 0); */

  if (Odd(fxl.exp)) {			/* make sure exponent is even */
    mantissa = (fxl.mantissa >> 1) + Odd(fxl.mantissa);
    exp = fxl.exp + 1;
  } else {
    mantissa = fxl.mantissa;
    exp = fxl.exp;
  }

  return mkfxl(fracsqrt(mantissa), (exp >= 0) ? (exp >> 1) : -((-exp) >> 1));
}

#if 0
#include <math.h>
PUBLIC Fxl DoubleToFxl ARGDEF1(double, d) {
  Frac f;
  IntX exp;
  d = frexp(d, &exp);
  f = (Frac) ldexp(d, expInteger);
  return mkfxl(f, exp);
}
#endif
