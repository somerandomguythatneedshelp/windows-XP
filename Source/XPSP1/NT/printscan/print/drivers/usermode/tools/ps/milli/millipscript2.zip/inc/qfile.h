/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: QFILE.H                                                */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

#define Q_VERSION 0x01000000    /* 1.0.0.0 */
#define Q_STRING "%!PS-Adobe PC QFile 1.0"
#define Q_STRINGLEN 24          /* the len of the above string incl. null */
#define Q_MAGICNUMBER 28        /* the mode of the Quasifile token */

#define Q_sender 0
#define Q_receiver 1

#define QTYPE_normal 0
#define QTYPE_immediate 1

#define QEXECPOS_start 30
#define QEXECPOS_optimize (QEXECPOS_start+2)
#define QEXECPOS_extra (QEXECPOS_start+5)
#define QEXECPOS_jobat (QEXECPOS_start+8)
#define QEXECPOS_jobid (QEXECPOS_start+16)
#define QEXECPOS_jobprintertype (QEXECPOS_start+20)
#define QEXECPOS_jobpriority (QEXECPOS_start+23)
#define QEXECPOS_jobspooler (QEXECPOS_start+26)
#define QEXECPOS_jobport (QEXECPOS_start+29)

VOID FAR PASCAL QInit(BYTE bType,BYTE bMode);

