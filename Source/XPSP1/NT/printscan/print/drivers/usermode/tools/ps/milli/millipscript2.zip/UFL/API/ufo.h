/*
 *    Adobe Universal Font Library
 *
 *    Copyright (c) 1996 Adobe Systems Inc.
 *    All Rights Reserved
 *
 *    UFO -- Universal Font Object
 *
 *
 * $Header:
 */

#ifndef _H_UFO
#define _H_UFO

/*===============================================================================*
 * Include files used by this interface                                                                                                               *
 *===============================================================================*/
#include "UFL.h"
#include "UFLPriv.h"

#ifdef __cplusplus
extern "C" {
#endif

/*===============================================================================*
 * Theory of Operation                                                                                                                                  *
 *===============================================================================*/
/* 
   This file defines the Universal Font Object
*/

/*===============================================================================*
 * Constants                                                                                                                                              *
 *===============================================================================*/

/*===============================================================================*
 * Macros                                                                                                                                                  *
 *===============================================================================*/

#define IS_GLYPH_SENT(arr, i)         ((arr)[((i)>>3)] & (1 << ((i)&7)))
#define SET_GLYPH_SENT_STATUS(arr, i) (arr)[((i)>>3)] |= (1 << ((i)&7))
#define GLYPH_SENT_BUFSIZE(n)         ( ((n) + 7) / 8 )


/*===============================================================================*
 * Scalar Types                                                                                                                                             *
 *===============================================================================*/

/* Font state */
typedef enum {
    kFontCreated,          /* The font object is created, but has not initialized */
    kFontInit,             /* The font object is initialized and is valid to be used */
    kFontHeaderDownloaded, /* The font object downloaded an empty font header */
    kFontHasChars,         /* Font has chars in it */
    kFontFullDownloaded    /* The font object downloaded a full font */
} UFLFontState;

/* Misc Flags for UFO */
#define     UFO_HasFontInfo     0x00000001L
#define     UFO_HasG2UDict      0x00000002L
#define     UFO_HasXUID         0x00000004L


/*===============================================================================*
 * Classes defined in this interface                                                                                                               *
 *===============================================================================*/
typedef struct t_UFOStruct UFOStruct;

typedef UFLErrCode (UFLCALLBACK *pfnUFODownloadIncr)( 
    const UFOStruct     *aFont, 
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMUsage,
    unsigned long       *pFCUsage  /* T32 FontCache tracking */
    );

typedef UFLErrCode (UFLCALLBACK *pfnUFOVMNeeded)( 
    const UFOStruct     *aFont, 
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMNeeded,
    unsigned long       *pFCNeeded   /* T32 FontCache tracking */
    );


typedef UFLErrCode (UFLCALLBACK *pfnUFOUndefineFont)( 
    const UFOStruct *pFont
);

typedef void (UFLCALLBACK *pfnUFOCleanUp)( 
    UFOStruct *pFont 
);

typedef UFOStruct * (UFLCALLBACK *pfnUFOCopy)( 
    const UFOStruct *pFont,
    const UFLRequest* pRequest
);



/* This is the base font class.  Subclasses for each type of font is derived from this.
*/

/* A common struct to be used with TT-as-T1/T3/T42 - notice it saves a bunch of
  pointers - just a comvenient way to access data and a common struct for functions like
  GetGlyphName(), GETFONTDATA() and so on
 */
typedef UFLHANDLE  UFOHandle;  /* a void Pointer */


#define AFONT_AddRef(pDLGlyphs)    ((pDLGlyphs)->refCount++) 
#define AFONT_Release(pDLGlyphs)   ((pDLGlyphs)->refCount--) 
#define AFONT_RefCount(pDLGlyphs)  ((pDLGlyphs)->refCount)


typedef struct t_AFontStruct {
    UFOHandle       hFont;                  /* A pointer to a font struct -T1/T3/T42 or CFF */

    unsigned char   *pDownloadedGlyphs;         /* List of downloaded glyphs for hFont */

    unsigned char   *pVMGlyphs;                         /* List of downloaded glyphs, used to calculate VM usage */

    unsigned char   *pCodeGlyphs;           /* List of glyphs used to update Code Points in FontInfo */

    unsigned long   dwTTPostSize;
    void            *pTTpost;
    unsigned long    refCount;
}AFontStruct;


typedef struct t_UFOStruct {

    /* protected Data */
    UFLDownloadType     lDownloadFormat;

    UFLFontState        flState;                        /* Flag used to keep track the state of the font. */

    unsigned long       dwFlags;                        /* Misc flags: has FontInfo, AddGlyphName2Unicode... */

    UFLHANDLE           hClientData;                    /* UFL Client private data */

    long                lProcsetResID;                  /* Resource ID of the required procset  */

    int                 ufoType;

    const UFLMemObj     *pMem;

    const UFLStruct     *pUFL;
    
    const UFLFontDataInfo *pFData;                      /* a pointer for access convenience */

    long                useMyGlyphName;                 /* if 1, use the glyph names passed in by client */

    /* Data unique to the current font  - a copy of a UFObj has a different name/encoding */
    char                *pszFontName;                   /* font name */

    char                *pszEncodeName;                 /* Font encoding.  If this field is NULL, then creat a font with names UFL likes */

    unsigned char       *pUpdatedEncoding;              /* bits in Encoding Vector with correct name set*/

    UFLXUID             Xuid;                           /* XUID array  info - copied from client or created from TTF file */

    // Fix bug 274008
    unsigned char       *pEncodeNameList;
    unsigned short      *pwCommonEncode;
    unsigned short      *pwExtendEncode;
    UFLBool             bNT4SymbolFont;

    /* Data that is sharable among several instances */
    AFontStruct         *pAFont;                                            /* A font with a list of downloaded glyphs */
   
    /* Method */

    pfnUFODownloadIncr  pfnDownloadIncr;
    pfnUFOVMNeeded      pfnVMNeeded;
    pfnUFOUndefineFont  pfnUndefineFont;
    pfnUFOCleanUp       pfnCleanUp;
    pfnUFOCopy          pfnCopy;

    //Fix bug 287084
    //For now NT will set this flag true, w 95 will set this false.
    UFLBool             bUseHheaForVhea;         //True if use hhea table for vhea.  False if try vhea then os/2 then hhea
    unsigned char       *pMacGlyphNameList;
} UFOStruct;


/* Number of glyphs in this TT font file - check against it for bounds */
#define UFO_NUM_GLYPHS(pUFObj)  ((pUFObj)->pFData->cNumGlyphs)

//
// Constant values for UFOStruct.ufoType
//

#define UFO_CFF     0
#define UFO_TYPE1   1
#define UFO_TYPE42  2
#define UFO_TYPE3   3


UFLBool
bUFOTestRestricted(
    const UFLMemObj *pMem,
    const UFLStruct *pSession,
    const UFLRequest *pRequest
    );

UFOStruct * UFOInit( 
    const UFLMemObj *pMem, 
    const UFLStruct *pSession, 
    const UFLRequest *pRequest 
    );

UFLErrCode UFODownloadIncr( 
    const UFOStruct     *aFont, 
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMUsage,
    unsigned long       *pFCUsage   /* T32 FontCache tracking */
    );

UFLErrCode UFOVMNeeded( 
    const UFOStruct     *aFont, 
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMNeeded,
    unsigned long       *pFCUsage   /* T32 FontCache tracking */
    );


UFLErrCode UFOUndefineFont( 
    const UFOStruct *pFont
);


void UFOInitData( 
    UFOStruct           *pUFO, 
    int                 ufoType,
    const UFLMemObj     *pMem, 
    const UFLStruct     *pSession, 
    const UFLRequest    *pRequest, 
    pfnUFODownloadIncr  pfnDownloadIncr,
    pfnUFOVMNeeded      pfnVMNeeded,
    pfnUFOUndefineFont  pfnUndefineFont,
    pfnUFOCleanUp       pfnCleanUp,
    pfnUFOCopy          pfnCopy
    );

void UFOCleanUpData( 
    UFOStruct *pUFO 
    );

void UFOCleanUp( 
    UFOStruct *aFont 
    );

UFOStruct *
UFOCopyFont( 
	const UFOStruct *aFont,
    const UFLRequest* pRequest
);


UFLErrCode
UFOGIDsToCIDs(
	const UFOStruct  *aFont,
    const short      cGlyphs,
    const UFLGlyphID *pGIDs,
    unsigned short   *pCIDs
);

// fix bug 274008
UFLErrCode
FindGlyphName(
    UFOStruct           *pUFObj,
    const UFLGlyphsInfo *pGlyphs,
    short               i, 
    unsigned short      wIndex,
    char                **pGoodName);
UFLBool
ValidGlyphName(
    const UFLGlyphsInfo *pGlyphs,
    short               i,
    unsigned short      wIndex,
    char                *pGoodName);

UFLErrCode
UpdateEncodingVector(
    UFOStruct           *pUFO,
    const UFLGlyphsInfo *pGlyphs,
    short int           sStart,
    short int           sEnd
);


UFLErrCode
UpdateCodeInfo(
    UFOStruct           *pUFObj,
    const UFLGlyphsInfo *pGlyphs
);


UFLErrCode
ReEncodePSFont(
    const UFOStruct *pUFO,
    const char      *pszNewFontName,
    const char      *pszNewEncodingName
);


UFLErrCode
NewFont(
    UFOStruct           *pUFO,
    unsigned long       dwSize,
    const long          cGlyphs
);


void
vDeleteFont(
    UFOStruct           *pUFO
);


UFOStruct *
CopyFont(
    const UFOStruct *pUFO,
    const UFLRequest* pRequest
    );


void 
VSetNumGlyphs( 
    UFOStruct     *pUFO,
    unsigned long cNumGlyphs
);

#ifdef __cplusplus
}
#endif

#endif   /* ifndef _H_UFO */
