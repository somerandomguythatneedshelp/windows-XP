/* CM_VerSion bitarray.c atm05 1.2 10076.eco sum= 22128 */
/* CM_VerSion bitarray.c atm04 1.2 04235.eco sum= 62100 */

/*
  bitarray.c

Copyright (c) 1991 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of
Adobe Systems Incorporated.  Many of the intellectual and
technical concepts contained herein are proprietary to Adobe,
are protected as trade secrets, and are made available only to
Adobe licensees for their internal use.  Any reproduction or
dissemination of this software is strictly forbidden unless
prior written permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks of
Adobe Systems Incorporated.

Original version: Craig Rublee September 3, 1991
Edit History:
End Edit History.

Revision History
  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/BITARRAY.C_V  $
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:08:08   unknown
 *- |Initial revision.
  Revision 6.3  91/11/13  11:43:28  rublee
  Removed include of atm.h and swapunit.h to remove dependency on the
  buildch package.
  
  Revision 6.2  91/10/07  18:21:55  rublee
   
  
  Revision 6.1  91/09/24  16:35:00  rublee
  Added include of swapunit.h
  
End Revision History.
*/

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif

#include PACKAGE_SPECS
#include ENVIRONMENT
#include FRAMEPIXEL


/* NOTE: In the PostScript Environment the following leftBitArray and 
   rigthBitArrays are defined in the patternimpl.c module in the
   devpattern package. 
*/
 

#if  SWAPBITS == DEVICE_CONSISTENT

#if SWAPUNIT==8
PUBLIC readonly SWAPTYPE leftBitArray[SWAPUNIT] =
  {0xff, 0xfe, 0xfc, 0xf8, 0xf0, 0xe0, 0xc0, 0x80};

PUBLIC readonly SWAPTYPE rightBitArray[SWAPUNIT] =
  {0x0, 0x1, 0x3, 0x7, 0xf, 0x1f, 0x3f, 0x7f};

#endif /* SWAPUNIT==8 */

#if SWAPUNIT==16
PUBLIC readonly SWAPTYPE leftBitArray[SWAPUNIT] =
  {0xffff, 0xfffe, 0xfffc, 0xfff8, 0xfff0, 0xffe0, 0xffc0, 0xff80,
   0xff00, 0xfe00, 0xfc00, 0xf800, 0xf000, 0xe000, 0xc000, 0x8000};

PUBLIC readonly SWAPTYPE rightBitArray[SWAPUNIT] =
  {0x0, 0x1, 0x3, 0x7, 0xf, 0x1f, 0x3f, 0x7f,
   0xff, 0x1ff, 0x3ff, 0x7ff, 0xfff, 0x1fff, 0x3fff, 0x7fff};

#endif /* SWAPUNIT==16 */

#if  SWAPUNIT==32  
PUBLIC readonly SWAPTYPE leftBitArray[SWAPUNIT] =
  {0xffffffffL, 0xfffffffeL, 0xfffffffcL, 0xfffffff8L,
    0xfffffff0L, 0xffffffe0L, 0xffffffc0L, 0xffffff80L,
   0xffffff00L, 0xfffffe00L, 0xfffffc00L, 0xfffff800L,
     0xfffff000L, 0xffffe000L, 0xffffc000L, 0xffff8000L,
   0xffff0000L, 0xfffe0000L, 0xfffc0000L, 0xfff80000L,
     0xfff00000L, 0xffe00000L, 0xffc00000L, 0xff800000L,
   0xff000000L, 0xfe000000L, 0xfc000000L, 0xf8000000L,
     0xf0000000L, 0xe0000000L, 0xc0000000L, 0x80000000L};

PUBLIC readonly SWAPTYPE rightBitArray[SWAPUNIT] =
  {0x00000000L, 0x00000001L, 0x00000003L, 0x00000007L,
   0x0000000fL, 0x0000001fL, 0x0000003fL, 0x0000007fL,
   0x000000ffL, 0x000001ffL, 0x000003ffL, 0x000007ffL,
   0x00000fffL, 0x00001fffL, 0x00003fffL, 0x00007fffL,
   0x0000ffffL, 0x0001ffffL, 0x0003ffffL, 0x0007ffffL,
   0x000fffffL, 0x001fffffL, 0x003fffffL, 0x007fffffL,
   0x00ffffffL, 0x01ffffffL, 0x03ffffffL, 0x07ffffffL,
   0x0fffffffL, 0x1fffffffL, 0x3fffffffL, 0x7fffffffL};

#endif /* SWAPUNIT==32 */

#else /* SWAPBITS != DEVICE_CONSISTENT */

#if SWAPUNIT==8
PUBLIC readonly SWAPTYPE leftBitArray[SWAPUNIT] =
  {0xff, 0x7f, 0x3f, 0x1f, 0xf, 0x7, 0x3, 0x1};

PUBLIC readonly SWAPTYPE rightBitArray[SWAPUNIT] =
  {0x00, 0x80, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc, 0xfe};

#endif /* SWAPUNIT==8 */

#if SWAPUNIT==16
PUBLIC readonly SWAPTYPE leftBitArray[SWAPUNIT] =
  {0xffff, 0x7fff, 0x3fff, 0x1fff, 0xfff, 0x7ff, 0x3ff, 0x1ff,
     0xff,   0x7f,   0x3f,   0x1f,   0xf,   0x7,   0x3,   0x1};

PUBLIC readonly SWAPTYPE rightBitArray[SWAPUNIT] =
  {0x0000, 0x8000, 0xc000, 0xe000, 0xf000, 0xf800, 0xfc00, 0xfe00,
   0xff00, 0xff80, 0xffc0, 0xffe0, 0xfff0, 0xfff8, 0xfffc, 0xfffe};

#endif /* SWAPUNIT==16 */

#if SWAPUNIT==32
PUBLIC readonly SWAPTYPE leftBitArray[SWAPUNIT] =
  {0xffffffffL, 0x7fffffffL, 0x3fffffffL, 0x1fffffffL, 0xfffffffL, 0x7ffffffL,
   0x3ffffffL, 0x1ffffffL, 0xffffffL, 0x7fffffL, 0x3fffffL, 0x1fffffL,
   0xfffffL, 0x7ffffL, 0x3ffffL, 0x1ffffL,
   0xffffL, 0x7fffL, 0x3fffL, 0x1fffL, 0xfffL, 0x7ffL, 0x3ffL, 0x1ffL,
   0xffL, 0x7fL, 0x3fL, 0x1fL, 0xfL, 0x7L, 0x3L, 0x1L};

PUBLIC readonly SWAPTYPE rightBitArray[SWAPUNIT] =
  {0x00000000L, 0x80000000L, 0xc0000000L, 0xe0000000L, 0xf0000000L,
   0xf8000000L, 0xfc000000L, 0xfe000000L, 0xff000000L, 0xff800000L,
   0xffc00000L, 0xffe00000L, 0xfff00000L, 0xfff80000L, 0xfffc0000L,
   0xfffe0000L, 0xffff0000L, 0xffff8000L, 0xffffc000L, 0xffffe000L,
   0xfffff000L, 0xfffff800L, 0xfffffc00L, 0xfffffe00L, 0xffffff00L,
   0xffffff80L, 0xffffffc0L, 0xffffffe0L, 0xfffffff0L, 0xfffffff8L,
   0xfffffffcL, 0xfffffffeL};

#endif /* SWAPUNIT==32 */

#endif /* SWAPBITS != DEVICE_CONSISTENT */


