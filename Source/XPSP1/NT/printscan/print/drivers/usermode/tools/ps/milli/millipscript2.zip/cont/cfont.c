/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Adobe Patent or Adobe Patent Pending Invention Included Within this File  */
/*                                                                           */
/* Module Name: CFONT.C                                                      */
/*                                                                           */
/* Description: This module contains the functions for ...                   */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_REALIZESEG)

#define NEGATIVE      1
#define ZERO          2
#define POSITIVE      3
#define POLARITY(n)   ((n<0)? NEGATIVE:((n==0)?ZERO:POSITIVE))

#define f10pts          10.0                    // 10 points - default
#define f72pt_in        72.0                    // 72 points/inch
#define f1000em_pt    1000.0                    // 1000 ems/point

// #define EMsToPixels   .004160  // Varies with resolution. See note below.

// Rather than the define below:
//
//      #define f300pix_in  300.0
//
// the variable f300pix_in is set to lppd->drvState.sDeviceRes


// The following define converts EMs to Pixels. As a floating point number it
// is computed as follows:
//
// #define EMsToPixels   (float)(f300pix_in)/(f1000em_pt * f72pt_in)
//
// This computation produces a result of .00416 EMs/Pixel. A 10 point
// font would therefore be computed as
//
// Height(in pixels) = (int)(10pts. * 1000 ems/pt * EMsToPixels)
//                   = (int)(10pts  * 1000 ems/pt * .00416 pixels/em)
//                   = (int)41.6 pixels
//                   = 41 pixels
//
// Previous drivers report this 10pt height as 42 pixels. Therefore,
// close attention to roundup erros is neccessary.

typedef int FAR* LPINT;

extern int GetEuroFontIndex(LPPDEVICE, LPPSFONTINFO, LPSTR, LPBOOL);
extern BOOL AddEuroToThisFont(LPPDEVICE, LPPSFONTINFO);

void FAR PASCAL SetLeading(BYTE PitchAndFamily,SHORT Points, int Height,
                       int Res,LPINT IntLead,LPINT ExtLead,int EM, BYTE CharSet)
{
  int    ptLeadSuggest            ;       // suggest leading in points


  // compute the suggested leading based on the type of font
  // first look at the family

  switch (PitchAndFamily & 0x0f0)
  {

  case FF_ROMAN:                                        // Tms Rmn  type fonts
	    ptLeadSuggest = 2                     ;
	    break                                 ;

  case FF_SWISS:                                        // Helv type fonts
	    if (Points <= 12)
		      ptLeadSuggest = 2             ;
	    else if (Points < 14)
		      ptLeadSuggest = 3             ;
	    else
		      ptLeadSuggest = 4             ;
	    break                                 ;

  default:
	    // default to 19.6%
	    ptLeadSuggest = Scale(Points,196,EM);
	    break                                 ;
  }

  // for all fixed pitched fonts (Courier) use no leading

  if (PitchAndFamily & 0x01 || IsDBCSCharSet(CharSet))
  {
      *IntLead      = Scale((*IntLead),Height,EM);
  }
  else
  {
     *IntLead       = 0                          ;
      ptLeadSuggest = 0                          ;
  }

// here we make sure the IntLeading and ExtLeading add up
// to the recomended leading but don't allow external leading
// to become negative.

  *ExtLead  = (int) Scale( ptLeadSuggest, Res, 72 ) - *IntLead;
  *ExtLead  = max(0,(*ExtLead))                 ;
}

VOID NEAR PASCAL MPFontScale(LPPDEVICE lppd,LPPFMHEADER lpPFMHdr,LPINT Width,
		             LPINT Height,LPINT xScale,LPINT yScale,int EM)
{

  switch(POLARITY(*Height))
  {
     case NEGATIVE:
	*Height = -(*Height)                               ;
	  break                                             ;

     case ZERO    :  // Use 10 point size font as a default
	*Height = (int)Scale(10, lppd->DeviceRes.y_res, 72);
	  break                                             ;

     case POSITIVE:
	*Height = Scale( (*Height), EM, EM+lpPFMHdr->dfInternalLeading );
	  break                                             ;
  }
  *yScale = *Height                                  ;

  switch(POLARITY(*Width))
  {
     case NEGATIVE:
	  *Width = -(*Width);      // Fall thru .....
     case POSITIVE:
	  *xScale= Scale( (*Width), EM, lpPFMHdr->dfAvgWidth) ;
	  break;

     case ZERO    :
	  *Width = Scale(lpPFMHdr->dfAvgWidth,(*Height),EM);
	  *Width = Scale( (*Width) , lppd->DeviceRes.x_res,
			      lppd->DeviceRes.y_res ) ;
	  *xScale= Scale( (*Height), lppd->DeviceRes.x_res,
			      lppd->DeviceRes.y_res ) ;

	  break;
  }

}


void FAR PASCAL PatchPFMOffsets(LPPFMHEADER lpPFMHdr)
{
    LPPFMEXTENSION lpPFMExt;
    DWORD          dwOffset = sizeof(PFMPROLOG);


    if (lpPFMHdr) 
    {
        lpPFMHdr->dfDevice -= dwOffset;
        lpPFMHdr->dfFace   -= dwOffset;
        if (lpPFMHdr->dfBitsOffset)
          lpPFMHdr->dfBitsOffset -= dwOffset;

        lpPFMExt = (LPPFMEXTENSION) ((LPBYTE) lpPFMHdr + sizeof(PFMHEADER));

        lpPFMExt->dfExtMetricsOffset -= dwOffset;
        if (lpPFMExt->dfExtentTable)
          lpPFMExt->dfExtentTable -= dwOffset;
        if (lpPFMExt->dfPairKernTable)
          lpPFMExt->dfPairKernTable -= dwOffset;
        if (lpPFMExt->dfTrackKernTable)
          lpPFMExt->dfTrackKernTable -= dwOffset;
        lpPFMExt->dfDriverInfo -= dwOffset;
    }
}


// The picture below is the *.pfm file structure. In addition, the driver's
// internal structures PSFONTINFO & FONTEXTRA are shown as they relate to
// to the file.

//    ---------------------
//    |  dfVersion        |
//    |  dfSize           |  .. PROLOG
//    |  dfCopyRight      |
//    ---------------------
//    |  dfType           | <=== lpFontInfo
//    |  dfPoints         |
//    |  dfVertRes        |  .. HEADER
//    |     :             |
//    |  dfDevice         |
//    |  dfFace           |
//    ---------------------
//    | dfExtMetricsOff   |
//    | dfExtentTable     |
//    | dfOriginTable     |  .. EXTENSION
//    | dfPairKernTable   |
//    | dfTrackKernTable  |
//    | dfDriverInfo      |  = lpFontExtra
//    ---------------------         |
//    |  --------------   |         |
//    |  |  Extent    |   |         |
//    |  |   Table    |   |         |
//    |  --------------   |         |
//    |  --------------   |         |
//    |  |  PairKern  |   |         |
//    |  |   Table    |   |         |
//    |  --------------   |         |
//    |  --------------   |         |
//    |  |  TrackKern |   |         |
//    |  |   Table    |   |         |
//    |  --------------   |         |
//    |        :          |         |
//    |  --------------   |         |
//    |  |ExtTextMetric   |         |
//    |  |   Table    |   |         |
//    |  --------------   |         |
//    ---------------------         |
//    | sPSxScale         |  <=======
//    | sPSyScale         |
//    | sOrientation      |
//    | sEscapement       |
//    | sFontid           |
//    | lpzMSFace         | = lpFontInfo + dfFace        - size(PROLOG)
//    | lpzPSFace         | = lpFontInfo + dfDriverInfo  - size(PROLOG)
//    | lpzDevice         | = lpFontInfo + dfDevice      - size(PROLOG)
//    | lpsWidths         | = lpFontInfo + dfExtentTable - size(PROLOG)
//    | lpTrackKern       | = lpFontInfo + dfTrackKern   - size(PROLOG)
//    | lpPairKern        | = lpFontInfo + dfPairKern    - size(PROLOG)
//    | lpExtTextMetrics  | = lpFontInfo + dfExtMetricOff- size(PROLOG)
//    ---------------------

FLAG FAR PASCAL RealizeFontProperties(LPPDEVICE lppd,LPLOGFONT LogFont,
LPPSFONTINFO FontInfo,LPTEXTXFORM TextXForm, HPFONTDIRECTORY hpFontDir,
BOOL bFontDownL, BYTE bIndexMFD, HPPFMPROLOG hpPFMProlog)
{
  int         Height,Width,xScale,yScale               ;
  int         sFontid,IntLead,ExtLead                  ;
  DWORD       FileSize   = hpFontDir->dwMetricSize;
  HPPFMHEADER hpPFMHdr  = NULL;
  LPFONTEXTRA FontExtra  = (LPFONTEXTRA)BUMPFAR(FontInfo,FileSize);
  float       f300pix_in_x = (float)lppd->DeviceRes.x_res;
  float       f300pix_in_y = (float)lppd->DeviceRes.y_res;

  FontExtra->dwPairKern  = 0L                 ;
  FontExtra->dwWidths   = 0L                 ;
  FontExtra->dwTrackKern = 0L                 ;


  if(hpFontDir && FontInfo && LogFont && TextXForm)
  {
     LPPFMEXTENSION lpPFMExt;
     LPETM lpETM;
     int   EM;


	  //Get Metric from the cache. If not in cache, this procedure
	  //will load it to the cache, also
	  if ((hpPFMHdr = GetMetricCache(hpFontDir, bIndexMFD, hpPFMProlog)) == NULL)
          return FALSE;

		//leave PFM untouch in the cache.
		//Copy Metric to FontInfo which will be modified
      if (FileSize - sizeof(PFMPROLOG) <= 0)
        return FALSE; //something went wrong.
      MemCopy((LP)FontInfo, (HPVOID)hpPFMHdr,(DWORD) (FileSize - sizeof(PFMPROLOG)));

	   PatchPFMOffsets((LPPFMHEADER)FontInfo);
		lpPFMExt = (LPPFMEXTENSION) ((LPBYTE) FontInfo + sizeof(PFMHEADER));     
      lpETM = (LPETM) ((LPBYTE) hpPFMHdr + lpPFMExt->dfExtMetricsOffset);
      EM = lpETM->etmMasterUnits;

     Height = LogFont->lfHeight                          ;
     Width  = LogFont->lfWidth                           ;
     MPFontScale(lppd,hpPFMHdr,&Width,&Height,&xScale,&yScale,EM);

     FontInfo->dfPoints    = Scale(Height, 72, (int)f300pix_in_y );
     FontInfo->dfAscent    = Scale(Height,hpPFMHdr->dfAscent,EM);
     FontInfo->dfPixWidth  = Width                       ;
     FontInfo->dfAvgWidth  = Scale(xScale,hpPFMHdr->dfAvgWidth,EM);
     FontInfo->dfMaxWidth  = Scale(xScale,hpPFMHdr->dfMaxWidth,EM);
     FontInfo->dfCharSet   = hpPFMHdr->dfCharSet                   ;

     IntLead               = hpPFMHdr->dfInternalLeading;
     ExtLead               = hpPFMHdr->dfExternalLeading;

     SetLeading(FontInfo->dfPitchAndFamily,FontInfo->dfPoints,Height,
		(int)f300pix_in_y,&IntLead,&ExtLead, EM, FontInfo->dfCharSet);

     FontInfo->dfInternalLeading = IntLead               ;
     FontInfo->dfExternalLeading = ExtLead               ;
     FontInfo->dfPixHeight       = Height + IntLead      ;

// Construct the FontExtra structure

     FontExtra->psAvgWidth   = hpPFMHdr->dfAvgWidth      ;
     FontExtra->sPSxScale    = xScale                    ;
     FontExtra->sPSyScale    = yScale                    ;
     FontExtra->sOrientation = LogFont->lfOrientation    ;
     FontExtra->sEscapement  = LogFont->lfEscapement     ;
     FontExtra->sFontid      = sFontid                   ;
     FontExtra->fTategaki = (hpPFMHdr->dfCharSet==EXT_RKSJ_CHARSET);

     //change these from pointers to offset.
     //ang 09/07/96 BUG 148279
     FontExtra->dwMSFace = (DWORD)FontInfo->dfFace                           ;
     FontExtra->dwPSFace = (DWORD)FontInfo->dfDriverInfo                     ;
     FontExtra->dwDevice = (DWORD)FontInfo->dfDevice                         ;
     FontExtra->dwExtTextMetrics = (DWORD)FontInfo->dfExtMetricsOffset               ;

     // There are segment offsets
     // bugfix  pdb 5/8/95 - after above BUMPFAR's to avoid double offset
     FontInfo->dfFace += OFFSETOF(FontInfo); 

     FontInfo->dfDevice += OFFSETOF(FontInfo); 

     FontInfo->dfBitsOffset += OFFSETOF(FontInfo);


#if 0
   delay this until needed.

   ScaleDevCharWidths(FontInfo) ;

#endif

     //change these from pointers to offset.
     //ang 09/07/96 BUG 148279

     if(FontInfo->dfTrackKernTable)
     {
       FontExtra->dwTrackKern = (DWORD) FontInfo->dfTrackKernTable               ;
     }

     if(FontInfo->dfPairKernTable)
     {
       FontExtra->dwPairKern = (DWORD) FontInfo->dfPairKernTable                ;
     }

     FontExtra->dwSoftFont = bFontDownL ? 0: (DWORD) hpFontDir->dwOutlineSize;
     FontInfo->dfDriverInfo = (DWORD)FileSize;



// Construct the TextXForm structure

     TextXForm->ftHeight       = Height + IntLead        ;
     TextXForm->ftWidth        = Width                   ;
     TextXForm->ftWeight       = FontInfo->dfWeight      ; // Actual weight of realized font
     TextXForm->ftItalic       = LogFont->lfItalic       ;
     TextXForm->ftUnderline    = LogFont->lfUnderline    ;
     TextXForm->ftStrikeOut    = LogFont->lfStrikeOut    ;

     TextXForm->ftEscapement   = LogFont->lfEscapement   ;
     TextXForm->ftOrientation  = LogFont->lfOrientation  ;
     TextXForm->ftAccelerator  = 0                       ;

     TextXForm->ftOverhang     = OVERHANG                ;
     TextXForm->ftClipPrecision= CLIP_CHARACTER_PRECIS   ;
     TextXForm->ftOutPrecision = OUT_CHARACTER_PRECIS    ;

  }
  return(TRUE)                                          ;
}



VOID  FAR PASCAL ScaleDevCharWidths(LPPDEVICE lppd, LPPSFONTINFO FontInfo)
{
   LPFONTEXTRA FontExtra  = (LPFONTEXTRA) BUMPFAR( FontInfo, FontInfo->dfDriverInfo);
   LPPFMEXTENSION lpPFMExt;
   LPETM lpETM;
   WORD  i, MaxI ;
   int   EM;
   LPSHORT lpsWidths;
   SHORT   sZeroWidth;

   lpPFMExt = (LPPFMEXTENSION) ((LPBYTE) FontInfo + sizeof(PFMHEADER));
   lpETM = (LPETM) ((LPBYTE) FontInfo + lpPFMExt->dfExtMetricsOffset);
   EM = lpETM->etmMasterUnits;

   if(FontInfo->dfExtentTable && !FontExtra->dwWidths)
   {
#ifdef ADD_EURO
       int  Index;
       LPSTR FontName;
       SHORT sEuroWidth;
       BOOL  bChangeWidth;
       BOOL  bAddEuroToThisFont = FALSE;
       BOOL  bSubstitution = FALSE;

       if (AddEuroToThisFont(lppd, FontInfo))
       {
           FontName = (LPSTR) BUMPFAR (FontInfo, FontExtra->dwPSFace);
           Index = GetEuroFontIndex(lppd, FontInfo, FontName, &bSubstitution);
           bAddEuroToThisFont = TRUE;
       }

#endif

       MaxI = FontInfo->dfLastChar - FontInfo->dfFirstChar ;
       FontExtra->dwWidths =  FontInfo->dfExtentTable;

       lpsWidths =  (LPSHORT)BUMPFAR(FontInfo, FontExtra->dwWidths);

       for (i = 0 ; i <= MaxI ; i++)
       {
           FontExtra->lpdWidths[i] = lpsWidths[i];
           lpsWidths[i] = Scale(lpsWidths[i], FontExtra->sPSxScale, EM);
#ifdef ADD_EURO

// Adobe Patent application tracking 
// # P294CIP, entitled GENERATING A GLYPH, inventors: Jia,Rublee,Jacobs,Phinney,Hall
           if (bAddEuroToThisFont  &&
               (((i + FontInfo->dfFirstChar) == 128) ||
                ((i + FontInfo->dfFirstChar) == 136)))
           {
               bChangeWidth = FALSE;
               if (lppd->lpEuroFontList[Index] != NULL)
                   sEuroWidth = *(lppd->lpSCDParams + 6*Index);
               else
                   sEuroWidth = 0;

               switch (FontInfo->dfCharSet)
               {
                   case RUSSIAN_CHARSET:      //CodePage = 1251;
                       if ((i + FontInfo->dfFirstChar) == 136)
                       {
                           bChangeWidth = TRUE;
                       }
                       break;

                   case EASTEUROPE_CHARSET:   //CodePage = 1250; 
                   case ANSI_CHARSET:         //CodePage = 1252;
                   case GREEK_CHARSET:        //CodePage = 1253;
                   case TURKISH_CHARSET:      //CodePage = 1254;
                   case HEBREW_CHARSET:       //CodePage = 1255;
                   case ARABIC_CHARSET:       //CodePage = 1256;
                   case BALTIC_CHARSET:       //CodePage = 1257;
                       if ((i + FontInfo->dfFirstChar) == 128)
                       {
                           bChangeWidth = TRUE;
                       }
                       break;
                   default:
                       break;
               }
               if (bChangeWidth)
               {
                   sZeroWidth = lpsWidths[48 - FontInfo->dfFirstChar];
                   if ((sZeroWidth != lpsWidths[i]) || !bSubstitution)
                   {
                       if (sEuroWidth)
                       {
                           FontExtra->lpdWidths[i] = sEuroWidth;
                           lpsWidths[i] = Scale(sEuroWidth, FontExtra->sPSxScale, EM);
                       }
                       else
                       {
                           lpsWidths[i] = sZeroWidth;
                           FontExtra->lpdWidths[i] =
                           FontExtra->lpdWidths[48 - FontInfo->dfFirstChar];
                       }
                   }
               }
           }
#endif
       }
   }
}

