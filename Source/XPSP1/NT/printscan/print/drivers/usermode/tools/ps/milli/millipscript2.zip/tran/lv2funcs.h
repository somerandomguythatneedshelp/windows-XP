/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: LV2FUNCS.H                                                   */
/*                                                                           */
/* Description: This module contains PostScript Level 2 defines and          */
/*              prototype support                                            */
/*                                                                           */
/*****************************************************************************/
//              -----   Bitmaps   -----

short FAR PASCAL TBitmapHeader2  (LPPDEVICE,LPRECT ,LPRECT,DWORD        );
short FAR PASCAL TBitmapData2    (LPPDEVICE,LPBITMAP,LPRECT,SHORT       );
short FAR PASCAL TBitmapOperator2(LPPDEVICE,BOOL,DWORD,DWORD,DWORD      );

//              -----   DIBs   -----
// L3_MASK FAST_IMAGE
short FAR PASCAL TDIBHeader2(LPPDEVICE lppd, LPDRAWMODE lpdm,
                            LPRECT SrcRect,LPRECT DstRect,
                            BOOL bCMYK, LPBITMAPINFO lpBitmapInfo,
                            SHORT FastImgType,
                            float far * ResampleRatio);
short FAR PASCAL TDIBOperator2(LPPDEVICE lppd, short BitsPerSample,
                            SHORT FastImgType);
short FAR PASCAL TDIBDataBits2(LPPDEVICE lppd, LPDRAWMODE lpdm,
                            LPRECT SrcRect, LPRECT DstRect, LPSTR lpBits,
                            LPBITMAPINFO lpBitmapInfo,
                            LPSTR GrayTable, SHORT FastImgTable,
                            float far * ResampleRatio);
