/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: REALIZE.C                                                    */
/*                                                                           */
/* Description: This module contains functions for GDI object realization    */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "regsetup.h"

#pragma code_seg(_REALIZESEG)

extern BOOL bATMLoaded;

#define NUM_BASE_FONTS  11    // Including different styles total is 35


char REALIZESEG BaseFontTable[NUM_BASE_FONTS][32] =
{
   "AvantGarde",
   "Bookman",
   "Courier",
   "Helvetica",
   "Helvetica-Narrow",
   "NewCenturySchlbk",
   "Palatino",
   "Symbol",
   "Times",
   "ZapfChancery",
   "ZapfDingbats"
};

short FAR PASCAL  EngineGetCharWidthStr(LPPSFONTINFO, LPBYTE, WORD, LPSHORT);
short FAR PASCAL dmRealizeObject(LP,short,LP,LP,LP);
WORD NEAR PASCAL GetRefFontSize(LPPDEVICE lppd, LPLOGFONT lpLogFont, 
                                BOOL bOutline, BOOL bTTResident)
{
   WORD wSize = 0;
   WORD glyphSize = 0;
   LOGFONT lfCopy;
   BOOL isRealTT;

   //check if real TT font
   lfCopy = *lpLogFont;
   lfCopy.lfEscapement = lfCopy.lfOrientation = 0;
   lfCopy.lfWidth = 0;
   // Do this for all cases and set a default 10pt if the heightis 0
   if (!lfCopy.lfHeight)
      lfCopy.lfHeight = - MulDiv(10, lppd->DeviceRes.y_res, 72);

   isRealTT = IsRealTTFont(&lfCopy);

   //it is possible at some pt when this procedure is called
   //DLFontFormat is T42 but bOutline =false.  So check both.
   //(isRealTT && bTTResident) mean it can be a T42 font.
   if (bOutline || (isRealTT && bTTResident) )
   {
      if (isRealTT || !bATMLoaded)
      {
          glyphSize = (WORD)EngineRealizeFontExt(lppd->hdc, &lfCopy,
                              (LPTEXTXFORM) NULL,
                              (LPPSFONTINFO) NULL, 0); //glyphIndex

          wSize = (WORD)EngineRealizeFontExt(lppd->hdc, &lfCopy,
                              (LPTEXTXFORM) NULL,
                              (LPPSFONTINFO) NULL, 0x0001); //char Code

          //Take the larger of the two
          if (glyphSize > wSize)
             wSize = glyphSize;

      } else
      {
           wSize = EngineRealizeFont(&lfCopy,
                              (LPTEXTXFORM) NULL,
                              (LPPSFONTINFO) NULL);
      }
      

   }

   return (wSize);
}

BOOL NEAR PASCAL IsTTFontResident(LPLOGFONT lpLogFont, LPREALIZEBUFS lpCache, 
                 BOOL bUseGlyphIndex, BYTE bCharSet)
{
  BOOL bTTResident = FALSE;
  int index = -1;
  FONTFILE TTFont;

   //Test if it has been downloaded.
   //1) if logFont.lfFacename is garbage index = -1;
   //2) We call SearchFontIndexDir by FaceName, rather than FontName.
   //This is because the index table is sorted by FaceName.
   //The search is faster.


   //If not real TrueType font, cannot be downloaded as T42 which is the only
   //type of TT download able.
   if (! IsRealTTFont(lpLogFont))
     return (bTTResident);

   //Try to find the PS Font Name for this TT font
      lstrcpy((LPSTR)TTFont.szName2, (LPSTR)lpLogFont->lfFaceName);
      GetTTInfo(&TTFont, TTPSName, lpLogFont);

      if (*(TTFont.szName1))
      { 
         //found exact PS name
         HPDIRINDEX hpDirIndex = lpCache->lpFontCache->hpDirIndex;
         HPDIRINDEX hpTempDirIndex;
         HPFONTDIRECTORY hpFontDir;
         index = 0;

         //while inspecting this font family
         while ( !bTTResident && ((WORD)index < lpCache->wNumFonts)  &&
            (hpTempDirIndex = hpDirIndex+ index) &&
            (hpFontDir = INDEX_TO_DIR(hpTempDirIndex, lpCache->lpFontCache->hpFontDirs)))
         {
            if (lstrcmpi((LPSTR)TTFont.szName2, (LPSTR)hpFontDir->szFaceName) == 0 )
            { 
            if (lstrcmpi((LPSTR)TTFont.szName1, (LPSTR)hpFontDir->szFontName) == 0 &&
               (hpTempDirIndex->statusFlag & MASK_FONT_DL) == FONT_ON_DEVICE)
            { //the font wanted is in the list && DownLoaded.
               if (bUseGlyphIndex)
               {
                  if ((hpTempDirIndex->statusFlag & MASK_FONT_MODE) == GI_CC)
                     bTTResident = TRUE;
               }
               else
               {
                  bTTResident = TRUE;
               }
            }
            }
            index++;
         }//while
      } //found exact PSName

  return (bTTResident);
}

/***************************************************************************
*                               ConstructTTName
*  Function:
*       ...
*  Prototype:
*     VOID NEAR PASCAL ConstructTTName(LPPDEVICE lppd, LPLOGFONT lpLogFont, LPPSFONTINFO lpFontInfo, BOOL bUseGlyphIndex, WORD cyFont)
*  Parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE 
*  Returns:
*       VOID
*
***************************************************************************/
VOID NEAR PASCAL ConstructTTName(LPPDEVICE lppd, LPLOGFONT lpLogFont, LPPSFONTINFO lpFontInfo, BOOL bUseGlyphIndex, WORD cyFont)
{
   char buf[128];
   char szXUID[12];
   char szFontDLType[20];
   FONTDATARECORD tmpFontData;
   int iDLFontFormat;
   char cDLFontFormat = 'X';
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO) ((LPSTR)lpFontInfo  + lpFontInfo->dfBitsOffset);
   LPREALIZEBUFS lpCache = &lppd->GlobalBuffer.RealizeBufs ;
   LPPSFONTINFO  lpTTFI  = lpCache->lpTTFI;         /*  .. and the pointer to it */
   LPSTR    lpFaceName = NULL;
   BOOL isVertFont = FALSE;

   *szFontDLType = '\0';

   iDLFontFormat = CheckDLType(lppd, lpLogFont, lpFontInfo, &tmpFontData);

   if (tmpFontData.BoldFake && lpFontInfo->dfType & TYPE_OUTLINE)
   {
      if (lpFontInfo->dfWeight > FW_NORMAL) 
         lpFontInfo->dfWeight -= (FW_BOLD-FW_NORMAL); // fix a GDI-CJK bug.
   }

   if (lpLogFont->lfFaceName[0] =='@')
     isVertFont = TRUE;

   //create MSTT31xxxx Name
   //Include dfPixHeight and dfAvgWidth for T1 and T3. bug 163331
   if (ExtractXUID(lpLogFont, (LPSTR) szXUID, FALSE))
   {
      switch (iDLFontFormat)
      {
        case TT_DLFORMAT_TYPE1:
          cDLFontFormat = bUseGlyphIndex? 'o': 'O';
          wsprintf(szFontDLType, "%c%03d%03d", 
                  cDLFontFormat,
                  lpTTFI->dfPixHeight,
                  lpTTFI->dfAvgWidth
                  );
          if (isVertFont)
            lstrcat(szFontDLType, "V");
             
          if (lpFontInfo->dfItalic)
            lstrcat(szFontDLType, "I");
          break;
        case TT_DLFORMAT_TYPE3:
          cDLFontFormat = bUseGlyphIndex? 'b': 'B';
          wsprintf(szFontDLType, "%c%03d%03d%03d%03d", 
                  cDLFontFormat, 
                  cyFont, 
                  lpFontInfo->dfWeight,
                  lpTTFI->dfPixHeight,
                  lpTTFI->dfAvgWidth);

          if (isVertFont)
            lstrcat(szFontDLType, "V");

          if (lpFontInfo->dfItalic)
            lstrcat(szFontDLType, "I");
          break;

        case TT_DLFORMAT_TYPE42:
          cDLFontFormat = bUseGlyphIndex? 't': 'T';
          wsprintf(szFontDLType, "%c", cDLFontFormat);
          if (isVertFont)
            lstrcat(szFontDLType, "V");

          if (!tmpFontData.ItalicFake && lpFontInfo->dfItalic)
            lstrcat (szFontDLType, "I");
          break;
      }

     if (lpFontInfo->dfType & PF_GLYPH_INDEX)
     {
         wsprintf(buf, "MSTT31%s%s", 
                        szXUID, 
                        szFontDLType);
     }
     else
     {
         wsprintf(buf, "MSTT31%s%s%02x", 
                        szXUID, 
                        szFontDLType,
                        lpFontInfo->dfCharSet);
     }


     lstrcpy(lpTTFontInfo->TTFaceName, buf);
   }
   else  //use old way if GetFontData failed
   {
      if(tmpFontData.ItalicFake)
         {
         // if download as type42 and need to do fake-italic, use the
         // same name as the regular style font
         wsprintf(buf, "%04xD%sF%04x%04x%04x%04x%04x%4x%02x%02x",
               HIWORD((DWORD)lppd),
               lpLogFont->lfFaceName,
               lpLogFont->lfWidth,
               (lpFontInfo->dfType & TYPE_OUTLINE) ? 0 : cyFont,
               (lpFontInfo->dfType & TYPE_OUTLINE) ? 0 : lpLogFont->lfEscapement,
               lpFontInfo->dfWeight,
               !lpFontInfo->dfItalic,
               lpFontInfo->dfCharSet,  // Add charset to support Multi-lingual Win95. 8-31-95, PPeng
               (int)lpFontInfo->dfPitchAndFamily,  // Add this value in to distinguish between two diff fonts.
               (iDLFontFormat == TT_DLFORMAT_TYPE42)?1:0 );   // add this to not confuse Type1 and Type42 fonts. 11-6-95, PPeng
      }
      else
      {
         wsprintf(buf, "%04xD%sF%04x%04x%04x%04x%04x%4x%02x%02x",
                  HIWORD((DWORD)lppd),
                  lpLogFont->lfFaceName,
                  lpLogFont->lfWidth,
                  (lpFontInfo->dfType & TYPE_OUTLINE) ? 0 : cyFont,
                  (lpFontInfo->dfType & TYPE_OUTLINE) ? 0 : lpLogFont->lfEscapement,
                  lpFontInfo->dfWeight,
                  lpFontInfo->dfItalic,
                  lpFontInfo->dfCharSet,  // Add charset to support Multi-lingual Win95. 8-31-95, PPeng
                  (int)lpFontInfo->dfPitchAndFamily,  // Add this value in to distinguish between two diff fonts.
                  (iDLFontFormat == TT_DLFORMAT_TYPE42)?1:0 );   // add this to not confuse Type1 and Type42 fonts. 11-6-95, PPeng
      }
       if (isVertFont)
            lstrcat(buf, "V");

      //Save the TrueType and PostScript font Name
      wsprintf(lpTTFontInfo->TTFaceName, "MSTT31%04x",
               GetTTFontID(lppd, buf));
   }
   //save the name in PSName also.
   lstrcpy(lpTTFontInfo->PSName, lpTTFontInfo->TTFaceName ) ;

}

// change:  just return the charset of named font.

int FAR PASCAL  AreCharSetsSame(lplf, lpntm, FontType, lpData)
LOGFONT FAR* lplf;   /* address of logical-font data structure */
NEWTEXTMETRIC FAR* lpntm;  /* address of physical-font data structure   */
int FontType;  /* type of font, */
LPARAM lpData; /* address of application-defined data */
{
   int  rc = 1 ;

   if(FontType == 2)  // device font
      rc = 0 ;    // stop enumeration immediately.

   *(LPBYTE)lpData = lplf->lfCharSet ;

   return (rc) ;
}

BOOL NEAR PASCAL IsPreferredCJKFont(LPSTR lpdfFaceName, LPSTR lplfFaceName)
{
    int i;

    if (PrefCJKFontList == NULL
        || lplfFaceName == NULL || *lplfFaceName == '\0' )
    {
        return FALSE;
    }

    for (i = 0; PrefCJKFontList[i] != NULL; i++)
    {
        // Take care of default Vertical fonts:
        // if requested is Vertical - "@junk" then skip all non-vertical ones
        if ((lplfFaceName[0]=='@') && (PrefCJKFontList[i][0]!='@')) continue;
        // if requested is Horizontal - "Ajunk" then skip all vertical ones
        if ((lplfFaceName[0]!='@') && (PrefCJKFontList[i][0]=='@')) continue;

        if (!lstrcmpi(PrefCJKFontList[i], lpdfFaceName) &&
            lstrcmpi(PrefCJKFontList[i], lplfFaceName))
        {
            return TRUE;
        }
    }

    return FALSE;
}


// This function returns TRUE if the font is a real TrueType Font.
BOOL FAR PASCAL IsRealTTFont(LPLOGFONT lplf){
   DWORD ttDataSize;
   HDC hDC;
   HFONT hPrevFont;
   HFONT hFont;
   BOOL  rc=FALSE;

   if (lplf==NULL || lplf->lfFaceName[0]=='\0')
         return rc;       // This case is safe guard the driver from crash.

   // GetFontData requires a screen DC to operate
   hDC = GetDC(NULL);
   hFont = CreateFontIndirect(lplf);
   hPrevFont = SelectObject(hDC, hFont);

   // Get the size of the entire TrueType font file
   ttDataSize = GetFontData(hDC, 0, 0L, NULL, 0L);
   // Check if ttDataSize is reasonable. 1 to 1Giga-Bytes (very reasonable for next 20 years!)
   if (ttDataSize>0 && ttDataSize<0x3FFFFFFF) rc=TRUE;

   SelectObject(hDC, hPrevFont);
   DeleteObject(hFont);
   if (hDC != NULL)
   ReleaseDC(NULL, hDC);
   return rc;
}
     

// This function returns TRUE if the font is a real TrueType Font.
BOOL FAR PASCAL IsType42Able(LPPDEVICE lppd, LPPSFONTINFO lpFontInfo)
{
   LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO) ((LPSTR)lpFontInfo  + lpFontInfo->dfBitsOffset);
   BOOL isTT = lpFontInfo->dfType & TYPE_TRUETYPE;
   BOOL isRealTT = FALSE;
   int  psVer;

   if (!isTT) return FALSE; // no one should call this function for PS fonts!!.
   
   if (lpTTFontInfo->dwProperties & TTFI_IS_REAL_TT)
       isRealTT = TRUE;
   
   //isLocaFault: 0=not init
   if (lpTTFontInfo->dwProperties & TTFI_LOCA_TBL_FAULTY == 0 &&
       lpTTFontInfo->dwProperties & TTFI_LOCA_TBL_OK == 0 )
   {
      if ( LOCA_TBL_OK == IsLocaTblFaulty(&lpTTFontInfo->lfCopy) )
          lpTTFontInfo->dwProperties |= TTFI_LOCA_TBL_OK ;
      else
          lpTTFontInfo->dwProperties |= TTFI_LOCA_TBL_FAULTY ;
   }

   psVer = GetPSVersion(lppd);
   if ((lpTTFontInfo->dwProperties & TTFI_LOCA_TBL_FAULTY) && (psVer < 2015))
   {
     return FALSE;  //Loca table is faulty or unreachable, can't do type 42
   }

   if (!isRealTT) return FALSE;  // cannot do Type42 if the font is not Real TT.
   if ( IsDBCSCharSet(lpFontInfo->dfCharSet) &&
        lppd->lpPSExtDevmode->dm2.bEUDCAble )
        return FALSE;  // cannot do EUDC for Type42 (FE fonts only)

   if (IsDBCSCharSet(lpFontInfo->dfCharSet) && psVer < 2015)
        return FALSE;  // cannot do Type42 on pre2015 printers for FarEast Fonts.
   // add other strange cases here (before return TRUE:)

   return TRUE;
}


DWORD  FAR PASCAL EngineRealizeFontWrapper(HDC hdc, LPLOGFONT lpLogFont,
    LPTEXTXFORM lpXform, LPPSFONTINFO lpFI, WORD flags)
{
    DWORD rc;

    if (bATMLoaded)
    {
        rc = (DWORD)EngineRealizeFont(lpLogFont, lpXform, lpFI);
        if (lpFI)
        {
            if (lpFI->dfType & PF_GLYPH_INDEX)
            {
                if (flags)
                {   // flags == 1 => we do not want wide fonts.
                    EngineDeleteFont(lpFI);
                    rc = EngineRealizeFontExt(hdc, lpLogFont, lpXform, lpFI, flags);
                }
            }
            else
            {
                lpFI->dfType |= TYPE_ATMFONT;
            }
        }
    }
    else
    {
        rc = EngineRealizeFontExt(hdc, lpLogFont, lpXform, lpFI, flags);
    }

// Do this here because we want this flag set for all cases (not just ATMloaded and flags=0)
    rc |= ERF_SUCCESS;

    return rc;
}

BOOL NEAR PASCAL Is35BaseFont(LPSTR lpFaceName)
{
   BOOL  retVal = FALSE;  // assume the font is NOT one of the 35 base fonts
   int   i;

   for(i=0; i<NUM_BASE_FONTS; i++)
   {
      if (lstrcmpi(lpFaceName, BaseFontTable[i]) == 0)
      {
         retVal = TRUE;
         break;
      }
   }

   return(retVal);
}



/***************************************************************************
 * AliasFace
 *
 * this routine looks through an Alias table that associates
 * groups of font names with each other.  That is any name in the
 * group is an alias for any other name in the group.
 * If the two names passed are aliases of each other
 * (are found in the same group)  then   return(TRUE);
 * else  return(FALSE);
 *
 **************************************************************************/

BOOL NEAR PASCAL AliasFace(WORD wGroup, LPSTR lpFontName )
{
     WORD     j;

     if( AliasTable[wGroup] == NULL )    // No such group
         return(FALSE);

     for(j = 0 ; AliasTable[wGroup][j] ; j++)
     {
         if (lstrcmpi(AliasTable[wGroup][j], lpFontName) == 0)
             return(TRUE);
     }

     return(FALSE);
}


WORD NEAR PASCAL  ScoreFontNames(WORD wGroup, LPLOGFONT lplf,
                                 LPTEXTMETRIC lptm, LPSTR lpszFaceName,
                                 LPSTR lpszFakeName)
{
    WORD    score;
    LPSTR  lplfFaceName, lpdfFaceName;

    lplfFaceName = lplf->lfFaceName;
    lpdfFaceName = lpszFaceName;

    if (!lstrcmpi(lplfFaceName, lpdfFaceName))
        score = NAME_EXACT_MATCH;
    else if (lpszFakeName  &&  !lstrcmpi(lplfFaceName, lpszFakeName))
        score = NAME_ALIAS_MATCH;
    else if (AliasFace(wGroup, lpdfFaceName))
        score = NAME_ALIAS_MATCH;
    else
        score = NAME_NO_MATCH;

    return(score);
}


WORD NEAR PASCAL  ScorePitchAndFamily(WORD wG, LPLOGFONT lplf,
                                      LPTEXTMETRIC lptm, LPSTR lpszFaceName,
                                      LPSTR lpszFakeName)
{
   LPSTR lplfFaceName;
   LPSTR lpdfFaceName;
   char  PitchFamily;
   WORD  i;
   WORD  score = 1;

   lplfFaceName = lplf->lfFaceName;
   lpdfFaceName = lpszFaceName;

    // Favor Courier... if no other font fits
    // NOTE: I assume we resort to this "favoritism" for Courier only if there
    //       is neither an EXACT nor ALIAS name match. So, adding COURIER_MATCH
    //      to the score makes sense ONLY if requested FaceName is NOT "Courier"
    //       AND devicefont FaceName is "Courier". If requested FaceName and
    //       devicefont FaceName both happen to be "Courier", adding
    //       COURIER_MATCH unconditionally leads to a TotalScore > PERFECT_MATCH
    //       regardless of boldness and italic score, which together is less
    //       than the score of COURIER_MATCH. Case in point: ccMail Print
    //       specifically asks for "Courier" and we realize
    //       "Courier Bold Oblique". After the
    //       FaceName match and addition of COURIER_MATCH, boldness and italics
    //       not matching did not matter at all. We reported PERFECT_MATCH and
    //       returned from RealizeFont().
    //       - bug403 - FIXED - ShyamV - 8/3/93.

    if (!lstrcmpi("Courier", lpdfFaceName) &&
            lstrcmpi("Courier", lplfFaceName))
   {
      // Favor Courier if no other font fits.
        score += COURIER_MATCH;
    }

    if ( IsDBCSCharSet(lptm->tmCharSet) &&
         (lptm->tmCharSet == DefaultCJKCharSet ) &&
         IsPreferredCJKFont(lpdfFaceName, lplfFaceName))
   {
      // Favor a CJK font if no other font fints.
      // PREFCJKFNT_MATCH value is slightly greater
      // than COURIER_MATCH.
        score += PREFCJKFNT_MATCH;
    }

    PitchFamily = lptm->tmPitchAndFamily;

    // Some fonts have incorrect PFMs, they advertize themselves as
   // Variable Pitch, so whenever we encounter such font - cast it
   // into fixed pitch.

   if (IncorrectFixedFontList != NULL)
   {
      for(i = 0; IncorrectFixedFontList[i]; i++)
      {
         if (!lstrcmpi(lpdfFaceName, IncorrectFixedFontList[i]))
         {
               PitchFamily = FIXED_PITCH + FF_MODERN;
               break;
         }
      }
    }

   if (lplf->lfCharSet == lptm->tmCharSet)
   {
      // prevent Symbol from being used for Roman fonts
      score += CHARSET_EXACT_MATCH;
   }

   // To score PITCH_EXACT_MATCH correctly, be awere of the differece
   // of the lower two bits of lfPitchAndFamily and PitchFamily.
   //
   // lfPitchAndFamily
   // 0x00: Don't care (either 'fixed' or 'variable')
   // 0x01: fixed
   // 0x02: variable
   // PitchFamily (tmPitchAndFamily)
   // 0x00: fixed
   // 0x01: variable

   if (((PitchFamily & 0x01) ? (lplf->lfPitchAndFamily & 0x02)
                       : (lplf->lfPitchAndFamily & 0x01))
      || ((lplf->lfPitchAndFamily & 0x03) == DEFAULT_PITCH ))
    {
        score += PITCH_EXACT_MATCH;
    }

   if (((lplf->lfPitchAndFamily & 0x0f0) == (PitchFamily & 0x0f0))
      || ((lplf->lfPitchAndFamily & 0x0f0) == FF_DONTCARE))
    {
        score += FAMILY_EXACT_MATCH;
    }

    return(score);
}



WORD NEAR PASCAL  ScoreItalicsAndBold(WORD wG, LPLOGFONT lplf,
                                      LPTEXTMETRIC lptm, LPSTR lpszFaceName,
                                      LPSTR lpszFakeName)
{
    WORD    score = 1 ;
    WORD    logItalics, candidateItalics;
    WORD    logWeight, candidateWeight, weightDiff;

    //  hirearchy that I wanted to impose through scoring system:
    //  penalize an overItalicized font severely.
    //  Since GDI cannot simulate a non-italics font
    //  from an italicized one.
    //  The penalty of 45 pts is set larger than the
    //  bonus of 30 + 10 = 40 pts for having perfect weight.
    //  Penalize an overweight font severely,
    //  Though not as badly as an overItalicized font.
    //  Again GDI cannot lighten the font's weight.
    //  There is a 30 point penalty for being overweight.
    //  I would rather force GDI to simulate both
    //  italics and boldness on a very light font
    //  than to use an italicized font that was too heavy.
    //  Therefore 10 + 12 < 30 ; the penalty for being overweight.
    //  Finally, its easier to simulate boldness than italics
    //  so that is why the bonus for matching italics (12) is greater
    //  than the bonus for matching weights (10).

    //  in other words, this is delicately balanced and
    //  interlinked scoring system.  Don't change any values
    //  without knowing exactly what the consequences are.

    //  some apps violate specification by using values
    //  other than 0 or 1 for the flags.  See DDK 12-36

    //  logItalics = lplf->lfItalic & 1;       //  possible values are 0 or 1
    //  but for backward compatibility we must revert to incorrect behavior.

    logItalics = (lplf->lfItalic) ? 1 : 0 ;

    candidateItalics = lptm->tmItalic & 0x0001;

    if(logItalics >= candidateItalics)
        score += 45;  // bonus for not being overItalicized.
                      //  GDI can't unItalicize a font

    if(logItalics == candidateItalics)
        score += 12;  // bonus for matching Italics;


    logWeight = lplf->lfWeight;
    candidateWeight = lptm->tmWeight;

    if(logWeight >= candidateWeight)
        score += 30;  // bonus for not being overweight.
                      //  GDI can't unBolden a font

    if(logWeight >= candidateWeight)
        weightDiff = (logWeight - candidateWeight) / 100;
    else
        weightDiff = (candidateWeight - logWeight) / 100;

    score += 10 - weightDiff;   //  the closer the weights match, the better

    return(score);
}


// @ Vertical Font scoring.
WORD NEAR PASCAL  ScoreVertical(WORD wGroup, LPLOGFONT lplf,
                                 LPTEXTMETRIC lptm, LPSTR lpszFaceName,
                                 LPSTR lpszFakeName)
{
    LPSTR  lplfFaceName, lpdfFaceName;
    WORD    score;

    lplfFaceName = lplf->lfFaceName;
    lpdfFaceName = lpszFaceName;

    // This Vertical matching  is used to break ties if there are two good matches
    // and one of them doesn't match vertical ("@MenuName")
    // So, the base score should assume everything else matches except Name.

    //  In other words, this is delicately balanced and
    //  interlinked scoring system.  Don't change any values
    //  without knowing exactly what the consequences are.

    score = NAME_EXACT_MATCH    +
            PITCH_EXACT_MATCH   +
            FAMILY_EXACT_MATCH  +
            45 + 30;  // assume Italic and Weight already matches !!

    // CharSet Match has to be added here - to prevent using a K font on J-system
    if ( lplf->lfCharSet == lptm->tmCharSet )
   {
      // Get higher score Only if asking CJK and the CharSet matches.
        score += CHARSET_EXACT_MATCH;
    }
    else if ( (lplf->lfCharSet == DEFAULT_CHARSET) &&
              (lptm->tmCharSet == DefaultCJKCharSet) )
   {
      // Get higher score if asking default CharSet and matches current defautlCJKCharSet
        score += 1 ;  // this is needed to fix bug 198911 - K fonts used on J system , PPeng, 3-20-1997
    }

    if ( IsDBCSCharSet(lptm->tmCharSet) &&
         (lptm->tmCharSet == DefaultCJKCharSet ) &&
         IsPreferredCJKFont(lpdfFaceName, lplfFaceName))
   {
      // Favor a CJK font if no other font fints.
      // PREFCJKFNT_MATCH value is slightly greater
      // than COURIER_MATCH.
        score += PREFCJKFNT_MATCH;
    }
    else
        score += COURIER_MATCH;




    // Finally Vertical checking.
    if ( !('@' == *lplfFaceName) ^ ('@' == *lpdfFaceName) )
        score += 10;

    return score;
}


#ifdef ENUMERATOR
WORD FAR PASCAL CallbackScoreProc(LPFONTDIRECTORY lpFontDir,
                                  LPFONTDATA lpFontData,
                                  LP lpData)
{

}
#endif

BYTE NEAR PASCAL ScoreFonts(
LPPDEVICE lppd, LPLOGFONT lpLogFont,
LPLOGFONT lpTTLogFont, WORD wGroup,
LPBYTE lpScoreArray, NEARPROC ScoreProc,
BYTE HighScore, WORD wNumFonts, WORD wNumDeviceFonts)
{
    HPFONTDIRECTORY  hpFontDir;  // use huge pointer to cross Seg boundry
    HPDIRINDEX       hpTempIndex;
    LPFONTCACHE      lpCache;
    BYTE             newHighScore = 0, newScore;
    WORD             i;


    newHighScore = HighScore;

    /* Score Engine Font */
    if (lpScoreArray[0] >= HighScore)
    {
        TEXTMETRIC    tm;
        LPPSFONTINFO  lpTTFI;
        LPSTR         lpRealName, lpFakeName;

        tm.tmHeight = lpTTLogFont->lfHeight;
        tm.tmAveCharWidth = lpTTLogFont->lfWidth;
        tm.tmWeight = lpTTLogFont->lfWeight;
        tm.tmItalic = lpTTLogFont->lfItalic;
        tm.tmCharSet = lpTTLogFont->lfCharSet;
        tm.tmPitchAndFamily = lpTTLogFont->lfPitchAndFamily;

        // GDI is appending the real font name after dfFace (which could
        // be a substituted name) in the FontInfo structure.
        // We should have realized a font by now, so it
        // should be in the lppd realizebuf cache.
        lpTTFI = lppd->GlobalBuffer.RealizeBufs.lpTTFI;
        lpFakeName = MAKELP(SELECTOROF(lpTTFI), lpTTFI->dfFace);
        lpRealName = lpFakeName + lstrlen(lpFakeName) + 1;
        lpScoreArray[0] = (*ScoreProc)(wGroup, lpLogFont,
                                               (LPTEXTMETRIC) &tm,
                                               lpRealName, lpFakeName);

        if (lpScoreArray[0] > newHighScore)
            newHighScore = lpScoreArray[0];

    }
    else
        lpScoreArray[0] = 0;      /* Out of the competition */

#ifdef ENUMERATOR
    /* Call enumerator if present */
    if (IsEnumeratorPresent())
    {
        SCOREBLOCK ScoreBlock;

        ScoreBlock.lpScoreArray = lpScoreArray;
        ScoreBlock.i = 0;
        ScoreBlock.newHighScore = newHighScore;

        Enum_EnumerateFonts(lppd, PS_ALL, NULL, (FARPROC) CallbackScoreProc,
                            (LP) &ScoreBlock);
        newHighScore = ScoreBlock.newHighScore;
        goto scorefonts_exit;
    }
#endif

    /* Score all other fonts */
    lpCache = lppd->GlobalBuffer.RealizeBufs.lpFontCache;
    if (! lpCache)
        goto scorefonts_exit;

    for (i=1; i<=wNumFonts; i++)
    {

        if (lpScoreArray[i] >= HighScore)
        {
            //off by one becuase 1st lpScoreArray is taken by TT fonts
            hpTempIndex = lpCache->hpDirIndex+i-1;

            hpFontDir = INDEX_TO_DIR(hpTempIndex, lpCache->hpFontDirs);

            /* Couldn't get font data. So can't compete */
            /*or TrueType font, don't score*/
            /*or Not-Realize Flag is set */
            if (!hpFontDir || 
               (hpTempIndex->statusFlag & MASK_PS_TT) == TT_FONT ||
               (hpTempIndex->statusFlag & MASK_FONT_VISIBILTY) == ENUM_RLZE_NOT_VISIBLE)
            {   
                lpScoreArray[i] = 0;
                continue;
            }

            if(lppd->lpPSExtDevmode->dm2.bFax35FontsOnly)
            {
               // Check if font  downloadable (ie has outline) 
               // or is one of the 35 base fonts. If it is,
               // do the regular score procedure. If it is not, lower
               // the score for this font.

               if(hpFontDir->dwOutlineSize || 
                  Is35BaseFont((LPSTR)hpFontDir->szFaceName))
               {
                  // has outline or 35 base font
                  lpScoreArray[i] = newScore = (*ScoreProc)(wGroup, lpLogFont,
                                   (LPTEXTMETRIC) &hpFontDir->defTextMetric,
                                   (LPSTR) hpFontDir->szFaceName, (LPSTR) NULL);
               }
               else
               {
                  lpScoreArray[i] = newScore = 0; // out of the competition
               }
            }
            else
            {
               lpScoreArray[i] = newScore = (*ScoreProc)(wGroup, lpLogFont,
                                   (LPTEXTMETRIC) &hpFontDir->defTextMetric,
                                   (LPSTR) hpFontDir->szFaceName, (LPSTR) NULL);
            }

            if (newScore > newHighScore)
                newHighScore = newScore;
        }
        else
            lpScoreArray[i] = 0;  /* Out of the competition */
    }

scorefonts_exit:
    return newHighScore;
}

/************************************************************************/

BYTE NEAR PASCAL QuickScoreFonts(
LPPDEVICE lppd, LPLOGFONT lpLogFont,
LPLOGFONT lpTTLogFont, WORD wGroup,
LPBYTE lpScoreArray, NEARPROC ScoreProc,
BYTE HighScore, WORD wNumFonts, WORD wNumDeviceFonts)
{
    HPFONTDIRECTORY  hpFontDir;  // use huge pointer to cross Seg boundry
    HPFONTDIRECTORY  hpFontDirHDR;
    HPDIRINDEX       hpDirIndex;
    LPFONTCACHE      lpCache;
    BYTE             newHighScore = 0;
    WORD             i, j;


    newHighScore = HighScore;

    lpCache = lppd->GlobalBuffer.RealizeBufs.lpFontCache;
    if (! lpCache)
        goto scorefonts_exit;
    hpFontDirHDR = lpCache->hpFontDirs[0];
    hpDirIndex = lpCache->hpDirIndex;

    /* Score Engine Font */
    if (lpScoreArray[0] >= HighScore)
    {
        TEXTMETRIC    tm;
        LPPSFONTINFO  lpTTFI;
        LPSTR         lpRealName, lpFakeName;

        tm.tmHeight = lpTTLogFont->lfHeight;
        tm.tmAveCharWidth = lpTTLogFont->lfWidth;
        tm.tmWeight = lpTTLogFont->lfWeight;
        tm.tmItalic = lpTTLogFont->lfItalic;
        tm.tmCharSet = lpTTLogFont->lfCharSet;
        tm.tmPitchAndFamily = lpTTLogFont->lfPitchAndFamily;

        // GDI is appending the real font name after dfFace (which could
        // be a substituted name) in the FontInfo structure.
        // We should have realized a font by now, so it
        // should be in the lppd realizebuf cache.
        lpTTFI = lppd->GlobalBuffer.RealizeBufs.lpTTFI;
        lpFakeName = MAKELP(SELECTOROF(lpTTFI), lpTTFI->dfFace);
        lpRealName = lpFakeName + lstrlen(lpFakeName) + 1;
        lpScoreArray[0] = (*ScoreProc)(wGroup, lpLogFont,
                                               (LPTEXTMETRIC) &tm,
                                               lpRealName, lpFakeName);
        if (lpScoreArray[0] > newHighScore)
            newHighScore = lpScoreArray[0];

    }
    else
        lpScoreArray[0] = 0;      /* Out of the competition */


    /* Score all other fonts */
    if (lpLogFont->lfFaceName[0])
    {

      //score log Font - exact match;
      i = SearchFontIndexDir(lpCache, lpLogFont->lfFaceName, 
                              lpCache->wNumFonts, FALSE, FONT_NOHINT);

      while ( (WORD)i < (lpCache->wNumFonts) 
            && (((hpDirIndex + i)->statusFlag & MASK_PS_TT) == PS_FONT)
            && (hpFontDir = ((HPFONTDIRECTORY) hpFontDirHDR) + (hpDirIndex+i)->wDirRecIndex)
            && lstrcmpi((LPSTR) hpFontDir->szFaceName, lpLogFont->lfFaceName) == 0) 
      {
         i++;
         lpScoreArray[i] = NAME_EXACT_MATCH;
         if ((lpScoreArray[i]) > newHighScore)
               newHighScore = lpScoreArray[i];
      } //while

      if( AliasTable[wGroup] != NULL )    // has an Alias group
      {
         for(j = 0 ; AliasTable[wGroup][j] ; j++)
         {
               i = SearchFontIndexDir(lpCache, (LPSTR) AliasTable[wGroup][j], 
                           lpCache->wNumFonts, FALSE, FONT_NOHINT);

               while ( (WORD)i < (lpCache->wNumFonts) 
                  && (((hpDirIndex + i)->statusFlag & MASK_PS_TT) == PS_FONT)
                  && (hpFontDir = ((HPFONTDIRECTORY) hpFontDirHDR) + (hpDirIndex+i)->wDirRecIndex)
                  && lstrcmpi((LPSTR) hpFontDir->szFaceName, (LPSTR) AliasTable[wGroup][j]) == 0) 
               {
                  i++;
                  if (lpScoreArray[i] < NAME_ALIAS_MATCH)
                     lpScoreArray[i] = NAME_ALIAS_MATCH;
                  if ((lpScoreArray[i]) > newHighScore)
                     newHighScore = lpScoreArray[i];
               }   //while     
         } //for
      } //if Alias Group exit.
    }

scorefonts_exit:

    return newHighScore;
}

/************************************************************************
*                       RealizeFont
*  function:
*       returns the size of the structure returned in lpFontInfo or
*       converts a logical font and returns a FontInfo struct in
*       lpFontInfo and a TextXForm struct in lpTextXForm.
*  prototype:
*       WORD NEAR PASCAL RealizeFont(lppd,lpLogFont,lpFontInfo,lpTextXForm);
*  parameters:
*       LPPDEVICE   lppd        -- pdevice pointer
*       LPLOGFONT   lpLogFont   -- pointer to logical font struct passed in
*       LPPSFONTINFO  lpFontInfo  -- pointer to the FontInfo struct returned.
*       LPTEXTXFORM lpTextXForm -- pointer to the TextXForm struct returned
*  returns:
*       size of the font info struct returned
**************************************************************************/
WORD NEAR PASCAL RealizeFont(LPPDEVICE lppd,LPLOGFONT lpLogFont,
                             LPPSFONTINFO lpFontInfo, LPTEXTXFORM lpTextXForm)
{
   LPREALIZEBUFS  lpCache ;
   LPBYTE      lpStrHeap;
   WORD        EngineSize;           /* How many bytes for Engine realization */
   WORD        UseDLableFont, UseDevFont;           /* Which approximation is better */
   BOOL        bTTReplaced = FALSE;  /* Replace TT font with device font */
   WORD        sFontInfoSize  = 0;   /* FAIL */
   WORD        wNumFonts, wNumDeviceFonts;
   BOOL        bSuccess  = FALSE, bUseWideFont = FALSE;
   BOOL        bDevice = FALSE;

   if (!lppd->bPass1Done && lpFontInfo)
   {
       if (RealizeFont(lppd, lpLogFont, NULL, lpTextXForm) == 0)
           return 0;
   }

#if (defined(PS_PROFILE) || defined(STATPROF))
    if (lpFontInfo)
    {
        START_PROFILE("Font Realization 2", REALIZE_PASS2);
    }
    else
    {
        START_PROFILE("Font Realization 1", REALIZE_PASS1);
    }
#endif



   lpStrHeap = lppd->lpWPXblock->WPXstrings;

   lpCache = &lppd->GlobalBuffer.RealizeBufs ;


if (!lpFontInfo) // first pass
{
   LOGFONT     TTLogFont;            /* LOGFONT structure for TT fonts */
   LPBYTE      lpScoreArray = NULL;  /* Keeps score for all the fonts */
   HPFONTDIRECTORY hpFontDir;
   LPFONTCACHE lpFontCache;
   HPDIRINDEX  hpDirIndex, hpTempDirIndex;
   WORD        i, wGroup;
   BYTE        tempScore;
   BYTE        HighScore = 0;        /* Best score so far */
   BOOL        bPerformSub;          /* If TT is to be substituted */
   LPPSEXTDEVMODE lpPSExtDevmode = lppd->lpPSExtDevmode;
   LPSTR lpszFriendlyName = (lpPSExtDevmode->dm).dm.dmDeviceName;


   lppd->bPass1Done = TRUE;
   /* Get pointer to font directories*/
   if (!(lpFontCache = lpCache->lpFontCache = GetFontCache(lpszFriendlyName)))
      goto endRealizeFont;

   wNumFonts = lpCache->wNumFonts = lpFontCache->wNumFonts;
   
   lpCache->nTTrealized  = 0 ;  //  how many TT fonts have been realized
               // in this pair of realize calls ?

   /*
   * Create an array long enough to hold scores for all device fonts.
   * Entry 0 is for Engine Score.
   */

   lpScoreArray = lpCache->lpScoreArray  ;

   if (wNumFonts + 1 > lpCache->cScoreArray)
   {
      lpScoreArray =  ReallocBuffer(wNumFonts +1 , GHND|GMEM_DDESHARE,
            &lpCache->cScoreArray,
            (LPBYTE  FAR  *)&lpCache->lpScoreArray  ) ;

      if (!lpScoreArray)
         goto  endRealizeFont ;
   }

   /* Initialize the score array to 1  for PS fonts*/
   MemSet((LPVOID) lpScoreArray, 1, (DWORD) wNumFonts+1);

   /* First try to find the font group requested */
   for(wGroup = 0 ; AliasTable[wGroup] ; wGroup++)
   {
      for(i = 0 ; AliasTable[wGroup][i] ; i++)
      {
         if (lstrcmpi(AliasTable[wGroup][i], lpLogFont->lfFaceName) == 0)
            goto GroupFound;
      }
   }

GroupFound:


   if (GetAppCompatFlags(0) & GACF_DISABLEWIDEFONT)
      lpCache->bUseWideFont = FALSE ;
   else
      lpCache->bUseWideFont = lppd->lpPSExtDevmode->dm2.bTrueTypeWide;

   // fix bug 191. Min-header expects Char code based font.
   lpCache->bUseWideFont = lpCache->bUseWideFont && !lppd->job.bfESCOpenChannel && !(fIsMinHeaderLppd(lppd));

   /*--------------------------------------------------------------------
   * Score TT font
   */
   lpCache->nTTrealized +=
         TTRealizeFont(lppd, lpLogFont, (LPTEXTXFORM) NULL,
                     (LPLOGFONT) &TTLogFont, (LPPSFONTINFO) NULL,
                     (LPWORD) &EngineSize, lpCache->bUseWideFont);


   if ( EngineSize == 0 )
      lpScoreArray[0] = 0;              /* Disqualify TT font */

   // ATM can fake tt font but cannot fake TT FontData. For Type 42
   // Downloading we now switch to Type1 at Download time, so no Fix at RealizeTime,
   // Fix bug 119279 - 9-8-1995, Comment them out re-fix bug 120333. 10-16-95
   //   if ((lppd->lpPSExtDevmode->dm2.iDLFontFmt == TT_DLFORMAT_TYPE42) &&
   //       !IsRealTTFont((LPLOGFONT)&TTLogFont))
   //      lpScoreArray[0] = 0;              /* Disqualify this Fake TT font for Type 42 */


   /*--------------------------------------------------------------------
   * Realize the PS font and get the score
   */
#if 0
   HighScore = ScoreFonts(lppd, lpLogFont, (LPLOGFONT) &TTLogFont, wGroup,
                        lpScoreArray, (NEARPROC) ScoreFontNames,
                        HighScore=1, wNumFonts, wNumDeviceFonts);
#else
   HighScore = QuickScoreFonts(lppd, lpLogFont, (LPLOGFONT) &TTLogFont, wGroup,
                        lpScoreArray, (NEARPROC) ScoreFontNames,
                        HighScore=1, wNumFonts, wNumDeviceFonts);
#endif
   bPerformSub = (lppd->lpPSExtDevmode->dm2.iTTSubsFmtSource
                  != TTSUBSFORMAT_DOWNLOADTT);

#if 0

   //If TT font is downloaded do not perform substitution, use DL'ed font
   // bug #205316
   bTTResident = IsTTFontResident( lpLogFont, lpCache, lpCache->bUseWideFont, lpLogFont->lfCharSet );

   if (bTTResident && bPerformSub)
   {
      BOOL changeFlag = TRUE;

      if (lppd->lpPSExtDevmode->dm2.iTTSubsFmtSource == TTSUBSFORMAT_TABLE)
      {
         BYTE       SubFont[MAX_NAME_LEN];  // holds name of font in SubTable.
         SubFont[0] = '\0' ;
         GetSubstitute(ghDriverMod, lppd, lppd->lpPSExtDevmode,
                        (LPSTR) &TTLogFont.lfFaceName, (LPSTR) SubFont);
         if (SubFont[0])    // There is a substitution font 
         {
            if (AliasFace(wGroup, SubFont) == FALSE)
             // use real substitution from Subsitution Table in win.ini 
             // Option 1: Sub according to Sub Table, Table select PS that
             //   is different from requested font
              changeFlag = FALSE;
         }
      }

      // we change the TT sub PS flag for the following cases:
      // Option 1: Sub according to Sub Table, Table select DL as TT. 
      // Option 1: Sub according to Sub Table, Table select PS but 
      //           alias of requested font
      // Option 2: Always use device font. 

      if (changeFlag)  
        bPerformSub = FALSE;
   }
#endif


   /*--------------------------------------------------------------------
   * If we are asked to realize font with TT_ONLY precision  -
   * disqualify any PS font
   */
   if( ! bPerformSub && lpScoreArray[0] &&
      (lpLogFont->lfOutPrecision == OUT_TT_ONLY_PRECIS)
      )
   {
      HighScore += 2;
      lpScoreArray[0] = HighScore;
   }
   else if (HighScore > 1 && (lpScoreArray[0] == HighScore))
   {
      /* Resolve Ties */
      BOOL bFavorTT;

      if(lpLogFont->lfOutPrecision == OUT_DEVICE_PRECIS)
         bFavorTT = FALSE;
      else if(lpLogFont->lfOutPrecision == OUT_TT_PRECIS)
         bFavorTT = TRUE;
      else
         bFavorTT = lppd->lpPSExtDevmode->dm2.bFavorTT;

      if(bFavorTT)
      {
         /* Explicitely favor TT fonts */
         HighScore++;
         lpScoreArray[0] = HighScore;
      }
      else
      {
         /* Increment all high scoring Device font scores */
         BYTE newScore = HighScore;

         for (i=1; i<=wNumFonts; i++)
         {
            if (lpScoreArray[i] == HighScore)
            lpScoreArray[i] = newScore = HighScore + 1;
         }
         HighScore = newScore;
      }
   }

  if (IsDBCSCharSet(DefaultCJKCharSet)){
      // FE chicago wants TrueType to be a default font.
      bDevice = (HighScore == 1);
    }
  else{
    if (HighScore == 1)       /* No names matched */
    {
      lpScoreArray[0] = 0;    /* Disqualify engine fonts */
    }
  }
  
  if (lpScoreArray[0] == HighScore || bDevice)
   {
      if(bPerformSub)
      {
         //There might be a better substitution than the table, Try this first.
         for (i=1; i<=wNumFonts; i++)
         {
            if (lpScoreArray[i] == NAME_EXACT_MATCH)
            {
               if (
                  ((((lpFontCache->hpDirIndex)+i-1)->statusFlag & MASK_FONT_DL) 
                        == FONT_ON_DEVICE)  &&
                  ((((lpFontCache->hpDirIndex)+i-1)->statusFlag & MASK_PS_TT) 
                        == PS_FONT)
                  )
               {
                  HPFONTDIRECTORY hpFontDir;  // use huge pointer to cross segment boundry
                  hpTempDirIndex = lpFontCache->hpDirIndex +i -1;
                  hpFontDir = INDEX_TO_DIR(hpTempDirIndex, lpFontCache->hpFontDirs);
                  if (hpFontDir->defTextMetric.tmCharSet == TTLogFont.lfCharSet)
                  {
                     lpScoreArray[i] = HighScore + 2;
                     bTTReplaced = TRUE;
                  } //charset match
               } //the font is resident
            }//if there is  an exact match
         } //for
       }//do this if use sub or send Device

      //perform substitution from Win.ini Table if no replacement is found yet
      if (!bTTReplaced && bPerformSub)
      {
         BYTE       SubFont[MAX_NAME_LEN];  // holds name of font in SubTable.

         SubFont[0] = '\0' ;
         GetSubstitute(ghDriverMod, lppd, lppd->lpPSExtDevmode,
                        (LPSTR) &TTLogFont.lfFaceName, (LPSTR) SubFont);
         if (SubFont[0])    /* There is a substitution font */
         {
            LPSTR lpName;
            BYTE  devCharset ;

            if (bDevice)
               goto  noSubstitution ;

            GetDevCharset((LPBYTE)lppd, SubFont, (FARPROC)AreCharSetsSame, (LPBYTE)&devCharset);
            if(devCharset != TTLogFont.lfCharSet)
               goto  noSubstitution ;

            /*
            * Find font with the replacement name and give it a score
            * of HighScore+2.
            */

            /* look at all fonts */
            hpDirIndex = lpFontCache->hpDirIndex;
            for (i=1; i<=wNumFonts; i++)
            {
               hpTempDirIndex = hpDirIndex +i -1;
               hpFontDir = INDEX_TO_DIR(hpTempDirIndex, lpFontCache->hpFontDirs);
               lpName = hpFontDir->szFaceName;

               if(lppd->lpPSExtDevmode->dm2.bFax35FontsOnly)
               {
                  // Check if font is one of the 35 base fonts. If it is,
                  // do the regular score procedure. If it is not, lower
                  // the score for this font.

                  if(hpFontDir->dwOutlineSize || Is35BaseFont(lpName))
                  {
                     // 35 base font or downloadable.
                     if (lpName[0] && ! lstrcmpi(lpName, (LPSTR) SubFont))
                     {
                        lpScoreArray[i] = HighScore + 2;
                        bTTReplaced = TRUE;
                     }
                  }
                  else
                  {
                     // not 35 base font, do nothing
                  }
               }
               else
               {
                  if (lpName[0] && ! lstrcmpi(lpName, (LPSTR) SubFont))
                  {
                     lpScoreArray[i] = HighScore + 2;
                     bTTReplaced = TRUE;
                  }
               }
            }//for

noSubstitution:
            ;
            if (lppd->lpPSExtDevmode->dm2.iTTSubsFmtSource ==
               TTSUBSFORMAT_USEPRINTER)
            {
               lpScoreArray[0] = 0;
               bTTReplaced = TRUE;
            }
         }// SubFont[0]
      }  // end bPerformSub

      //we have just check the table and tried to use Ares.
      // if Substituting, reRealize TT font without GLYPH_INDEX.
      if(bTTReplaced  &&  lpCache->lpTTFI->dfType & PF_GLYPH_INDEX)
      {
         EngineDeleteFont(lpCache->lpTTFI);
         lpCache->nTTrealized = 0 ;
         lpCache->nTTrealized +=
            TTRealizeFont(lppd, lpLogFont, (LPTEXTXFORM) NULL,
                     (LPLOGFONT) &TTLogFont, (LPPSFONTINFO) NULL,
                     (LPWORD) &EngineSize, FALSE);

      }  //reRealize as Glyph Index

      /* Find current HighScore */
      tempScore = 0;
      for (i=0; i<=wNumFonts; i++)
      {
         if (lpScoreArray[i] > tempScore)
         tempScore = lpScoreArray[i];
      }
      HighScore = tempScore;

   } // end TT font has HighScore.

//#ifndef FE_DEVICE // US Version
//   if (HighScore == 1)
//#else
   if (HighScore == 1 || bDevice)
//#endif
   {
      HighScore = ScoreFonts(lppd, lpLogFont, (LPLOGFONT) &TTLogFont, wGroup,
                              lpScoreArray, (NEARPROC) ScorePitchAndFamily,
                              HighScore, wNumFonts, wNumDeviceFonts);
   }

    HighScore = ScoreFonts(lppd, lpLogFont, (LPLOGFONT) &TTLogFont, wGroup,
                        lpScoreArray, (NEARPROC) ScoreItalicsAndBold,
                        HighScore, wNumFonts, wNumDeviceFonts);

  if ( IsDBCSCharSet(DefaultCJKCharSet) )
    {
     // For FE- vertical support - this is only on CJK Win95
     HighScore = ScoreFonts(lppd, lpLogFont, (LPLOGFONT) &TTLogFont, wGroup,
                        lpScoreArray, (NEARPROC) ScoreVertical,
                        HighScore, wNumFonts, wNumDeviceFonts);
    }

   /* Determine best font to use*/
   UseDevFont =  UseDLableFont = 0;
   for (i=1; i<=wNumFonts; i++)
   {
      if (lpScoreArray[i] == HighScore)
      {
         if ((((lpFontCache->hpDirIndex)+i-1)->statusFlag & MASK_FONT_DL) 
                     == FONT_ON_DEVICE)
         {
            UseDevFont = i;
            break;
         }
         else
         {
            if (!UseDLableFont)  //use the first DL font, just like 4.1
               UseDLableFont = i;
         }
      }
   }

   /* For TT realization we also keep the info provided by EngineRealizeFont */
   if (bTTReplaced || (!UseDevFont || !UseDLableFont)) //this might need change to bTTReplaced
   {
      sFontInfoSize = EngineSize;

//     lpCache->bTTResident = IsTTFontResident(lpLogFont, lpCache, lpCache->bUseWideFont, lpLogFont->lfCharSet );
//     ang 5/29/97 bug 20...
//     Don't check TTResident here any more because we want to use lfCopy.logFont in
//     TTRealizeFont 2nd pass.  GetRefFontSize() will create more space
//     for T42 potential.

      /* add-in size for xFontInfo*/
      sFontInfoSize += GetRefFontSize(lppd, lpLogFont, lpCache->bOutline, TRUE); //assume T42able to create larger buffer
   }

   if (UseDevFont || UseDLableFont)
   {
      HPFONTDIRECTORY hpFontDir;  // use huge pointer to cross segment boundry
      WORD i = UseDevFont ? UseDevFont: UseDLableFont;

      hpTempDirIndex = lpFontCache->hpDirIndex +i -1;
      hpFontDir = INDEX_TO_DIR(hpTempDirIndex, lpFontCache->hpFontDirs);

      if (hpFontDir)
      {
          sFontInfoSize += (WORD)hpFontDir->dwMetricSize - sizeof(PFMPROLOG) + sizeof(FONTEXTRA)
                            + 256 * sizeof(WORD);
      }


      // if we really don't want to realize a TT font...
      // delete the cached font created by first call to TTRealizeFont
      // which created one secretly.

      if(!bTTReplaced  &&  lpCache->nTTrealized) //might need to change to bTTReplaced
      {
         EngineDeleteFont(lpCache->lpTTFI);
         lpCache->nTTrealized-- ;  // should be zero at this time.
      }
   }

   lpCache->sFontInfoSize  = sFontInfoSize ;
   lpCache->UsePSFont = UseDevFont ? UseDevFont: UseDLableFont;
   lpCache->hpDirIndex = hpTempDirIndex;
   lpCache->bTTReplaced = bTTReplaced;


}  // end first pass

else   //  second pass
{
   HPFONTDIRECTORY hpFontDir = NULL;
   HPPFMPROLOG hpPFMProlog = NULL;
   LPFONTCACHE lpFontCache = lpCache->lpFontCache;
   HPDIRINDEX hpDirIndex = lpCache->hpDirIndex;
   BOOL bFontDownL = FALSE;
   BOOL endRealize = FALSE;

   lppd->bPass1Done = FALSE;
   UseDevFont = lpCache->UsePSFont;
   bTTReplaced = lpCache->bTTReplaced;
   sFontInfoSize  = lpCache->sFontInfoSize ;
   if (UseDevFont)
   {
      hpFontDir = INDEX_TO_DIR(hpDirIndex, lpFontCache->hpFontDirs);
      bFontDownL = (hpDirIndex->statusFlag & MASK_FONT_DL) == FONT_ON_DEVICE;
      hpPFMProlog = INDEX_TO_METRIC(hpDirIndex, lpFontCache->hpPFMPrologs);
   }

   lpCache->bUseWideFont = lpCache->bUseWideFont && !bTTReplaced ;

   if (UseDevFont && !(bTTReplaced && UseDevFont))
   {
      if (!RealizeFontProperties(lppd, lpLogFont, lpFontInfo,
               lpTextXForm, hpFontDir,
               bFontDownL, //indicate downloaded or not
               hpDirIndex->wDirIndex,
               hpPFMProlog))
          {
            endRealize = TRUE;
            goto cleanCache;
          }

   }
   else   // originally wanted to use TT font
   {
      lpCache->nTTrealized +=
                  TTRealizeFont(lppd, lpLogFont, lpTextXForm,
                  (LPLOGFONT) NULL, lpFontInfo, (LPWORD) &EngineSize,
                  lpCache->bUseWideFont);

      if(!EngineSize)  // failed
         goto  endRealizeFont ;


      if (UseDevFont && hpFontDir)  // substitution has occured !
      {
         TEXTXFORM cTXF; /* Dummy structure for RealizeFontProperties */
         LPPSFONTINFO lpSubFontInfo ;  // points to substituted device font.
         LPTTFONTINFO lpTTFontInfo = (LPTTFONTINFO)((LPSTR)lpFontInfo +
                                      lpFontInfo->dfBitsOffset ) ;

         //changed SubFontInfo from long pointer to offset from FontInfo
         //ang 9/7/96 bug 148279
         //ang 11/25/96 -memory leak bug
         //wXFontInfoSize is set in TTRealizeFont(2ndpass)
         lpTTFontInfo->dwSubFontInfo = EngineSize + lpTTFontInfo->wXFontInfoSize;
         lpSubFontInfo = (LPPSFONTINFO)BUMPFAR (lpFontInfo, lpTTFontInfo->dwSubFontInfo) ;

         /*
         * Realize a fontinfo struct in the space beyond the TTFONTINFO
         * portion of the TT font
         */

//                WorkLogFont =  *lpLogFont;  no longer needed since
//    the name of the substituted font is never used.

         if (!RealizeFontProperties(lppd, lpLogFont,
                              lpSubFontInfo, (LPTEXTXFORM) &cTXF,
                              hpFontDir, 
                              bFontDownL,
                              hpDirIndex->wDirIndex,
                              hpPFMProlog))
          {
            endRealize = TRUE;
             goto cleanCache;
          }

         lpFontInfo->dfType |= TYPE_SUBSTITUTED;
         lpSubFontInfo->dfAscent = lpFontInfo->dfAscent;
      }
   }

   /*
   *  The reason for the following code is:
   *   The data in PSFONTINFO are related to the physical realization
   *   of the font, and if the font per se is not underlined -
   *   we should underline it. That's why we put all the difference
   *   between currently realized font and desired one into TEXTXFORM.
   */
   if (lpFontInfo->dfUnderline != lpLogFont->lfUnderline)
      lpTextXForm->ftUnderline = lpLogFont->lfUnderline;
   if( lpFontInfo->dfStrikeOut != lpLogFont->lfStrikeOut)
      lpTextXForm->ftStrikeOut = lpLogFont->lfStrikeOut;

cleanCache:

   if (lpCache->lpFontCache)
     FreeCache(lpCache->lpFontCache);
   if (lpCache->hpDirIndex)
     lpCache->hpDirIndex = NULL;


   if (endRealize)
      goto endRealizeFont;
}  // end of 2nd pass


   bSuccess = TRUE ;  // Finally got all the way through

   /* Cleanup */
endRealizeFont:



#if (defined(PS_PROFILE) || defined(STATPROF))
   if (lpFontInfo)
   {
      STOP_PROFILE(REALIZE_PASS2);
   }
   else
   {
      STOP_PROFILE(REALIZE_PASS1);
   }
#endif

   if(bSuccess)
      return(sFontInfoSize);
   else   //  failure
   {
      if(lpCache->nTTrealized)
      {
         EngineDeleteFont(lpFontInfo);

         if (lpCache->nTTrealized > 1) // may not even be initialized otherwise
         {
            LPTTFONTINFO lpTTFontInfo ;
            LPPSFONTINFO lpXFontInfo  = NULL;  // points to initRef

            lpTTFontInfo = (LPTTFONTINFO)((LPSTR)lpFontInfo + lpFontInfo->dfBitsOffset);
            if (lpTTFontInfo->dwXFontInfo)
            {
               lpXFontInfo = (LPPSFONTINFO)BUMPFAR (lpFontInfo, lpTTFontInfo->dwXFontInfo);
               EngineDeleteFont(lpXFontInfo);
               lpTTFontInfo->dwXFontInfo = 0 ;  // no RefFont realized.
            }
         }
      }
      return(0) ;
   }
}


/**************************************************************************
*
*       TTRealizeFont
*   Input:  lpLogFont, lpTextXform
*
*   Output: lpEngineLogFont - basic information about font, used for
*                               font scoring
*           lpFontInfo      - more detailed info
*
*  return value: specifies whether or not a TTfont was realized.
*  independently of function's success.  This is required so
*  caller can delete this font when need arises.
*
**************************************************************************/

WORD  NEAR PASCAL TTRealizeFont(LPPDEVICE lppd, LPLOGFONT lpLogFont, \
                               LPTEXTXFORM lpTextXForm,
                               LPLOGFONT lpEngineLogFont,
                               LPPSFONTINFO lpFontInfo,
                               LPWORD  lpSize ,
                               BOOL    bUseGlyphIndex)
{
   WORD          wSize;          /* Size of memory required to store PSFONTINFO */
   WORD          cyFont;         /* The y-scaling factor for the font */
   LPPSFONTINFO  lpTTFI;         /*  .. and the pointer to it */
   TEXTXFORM     cEngineTXF;     /* Dummy structure for EngineRealizeFont */
   BOOL          bSuccess  = FALSE;
   BOOL          bOutline  = FALSE;
   WORD          nTTrealized  = 0;  //  have we realized a TT font?
   LPREALIZEBUFS  lpCache ;
   WORD    flags ;
   int     lfHeight = lpLogFont->lfHeight;
   PSERROR rc;
   FONTFILE ttFont;
   int index = -1;

   if(bUseGlyphIndex)
      flags = 0 ;
   else
      flags = 0x0001 ;

   lpCache = &lppd->GlobalBuffer.RealizeBufs ;

   if (lppd->job.bfTTEnabled == FALSE)
      goto  endTTRealizeFont ;

   lpTTFI = lpCache->lpTTFI  ;

   // Do this for all cases and set a default 10pt if the heightis 0
   // --11-2-1995, PPeng -- Fix a GPF bug psdt EXT002\etext057.psd.
   if (!lfHeight)
   {
       lpLogFont->lfHeight = - MulDiv(10, lppd->DeviceRes.y_res, 72);
   }


   if(!lpFontInfo)  //  first pass
   {
      //  identifiers unique to first pass.
      WORD          cxFont;         /* The x-scaling factor for the font */

      /* Get the size of the PSFONTINFO necessary for realization */
      wSize = (WORD)EngineRealizeFontWrapper(lppd->hdc, lpLogFont,
            (LPTEXTXFORM) NULL, (LPPSFONTINFO)NULL, flags);

      if( wSize == 0 )        //  GDI failed.
         goto  endTTRealizeFont ;  // don't need to touch lpEngineLogFont

      /* Allocate the memory and get the information */


      if (wSize > lpCache->cTTFI)
      {
         lpTTFI = (LPPSFONTINFO) ReallocBuffer(wSize, GHND|GMEM_DDESHARE,
               &lpCache->cTTFI,
               (LPBYTE  FAR  *)&lpCache->lpTTFI  ) ;

         if (!lpTTFI)
            goto  endTTRealizeFont ;
      }

      MemSet ((LPBYTE)lpTTFI, 0, (DWORD) wSize ) ;

          // fix 291523 - jpatters
      MemSet ((LPBYTE)&cEngineTXF, 0, sizeof( cEngineTXF )) ;

      if ( !( ERF_SUCCESS & (lpCache->wTTFlags = (WORD)EngineRealizeFontWrapper(
                                                   lppd->hdc,
                                                   lpLogFont,
                                                   (LPTEXTXFORM) &cEngineTXF,
                                                   lpTTFI,
                                                   flags))) )
                 //  GDI failed.
         goto  endTTRealizeFont ;  // don't need to touch lpEngineLogFont

      nTTrealized++ ;   //  must unrealize font eventually.

      cyFont = lpTTFI->dfPixHeight - lpTTFI->dfInternalLeading;
      if (cyFont == 0)            /* Use default font */
         cyFont = Scale(10, lppd->DeviceRes.y_res, 72);

      cxFont = lpTTFI->dfPixWidth;
      if (cxFont == 0 )
         cxFont = lpTTFI->dfAvgWidth;


      /*
      * In case of Type42 font we must reserve additional space
      * for unscaled character widths table which goes after PSFONTINFO
      * structure returned from EngineRealizeFont call.
      * The same is true for Type1 too.
      * Fixed  23-Jun-1993  -by-   [olegs]
      */
      if (
            // Always use outline for openchannel & minheader apps
            (lppd->job.bfESCOpenChannel) ||
            (lppd->job.bfJobMinHeader)   ||
            !(
              (lppd->lpPSExtDevmode->dm2.iDLFontFmt == TT_DLFORMAT_TYPE1 &&
               cyFont < lppd->lpPSExtDevmode->dm2.iMinOutlinePPEM)
             ||
              (lppd->lpPSExtDevmode->dm2.iDLFontFmt == TT_DLFORMAT_TYPE3 &&
               cyFont < MAXBITMAPPPEM)
             ||
              (lppd->lpPSExtDevmode->dm2.iDLFontFmt == TT_DLFORMAT_NONE)
            )   // make sure it is really a WIFE font by checking the existence of required TTF tables
            && !((lpTTFI->dfType & PF_WIFE_TYPE) && !HasRequiredTables(lpLogFont))
         )
      {
         bOutline  = TRUE   ;  //  outline font used.
      }

#if 0

      // don't allocate space for any width caches

   WORD          numGlyphs ;     // number of Glyphs in this font.
   WORD   wExtraWidthTable, wWidthTable, ;

      if(lpTTFI->dfType & PF_GLYPH_INDEX)
         numGlyphs = *(LPWORD)&lpTTFI->dfFirstChar ;
      else
         numGlyphs = lpTTFI->dfLastChar - lpTTFI->dfFirstChar + 1 ;

      wWidthTable = numGlyphs * sizeof( WORD )   ;
      wExtraWidthTable = (bOutline) ? wWidthTable : 0    ;
       lpCache->numGlyphs = numGlyphs ;

#endif

       lpCache->wSize = wSize ;
       lpCache->cyFont = cyFont ;
       lpCache->bOutline = bOutline ;
       lpCache->cEngineTXF = cEngineTXF ;
   }
   else   // this is the 2nd pass.
   {
      //  define  identifiers unique to 2nd pass.
      LPTTFONTINFO  lpTTFontInfo;   /* Pointer to the TT-specific info */
      LPPSFONTINFO  lpTTFI0  =NULL;
      WORD  h0, w0; 
      
       wSize = lpCache->wSize  ;
       cyFont = lpCache->cyFont  ;
       bOutline = lpCache->bOutline  ;
       cEngineTXF = lpCache->cEngineTXF  ;

#if 0

       numGlyphs = lpCache->numGlyphs  ;
      // following 2 lines duplicated in both passes, so what?
      wWidthTable = numGlyphs * sizeof( WORD )   ;
      wExtraWidthTable = (bOutline) ? wWidthTable : 0    ;

#endif


   /**************************************************************
         *  Fill out PSFONTINFO structure
         */
      MemCopy(lpFontInfo, lpTTFI, wSize);

   
      lpFontInfo->dfType |= TYPE_TRUETYPE;
      lpFontInfo->dfType |= TYPE_HAVEWIDTHS;

      /* set the outline bit if appropriate */
      if (bOutline)
         lpFontInfo->dfType |= TYPE_OUTLINE;


      lpFontInfo->dfBitsOffset = (DWORD) ( wSize /* + wExtraWidthTable */ ) ;
      //  location of  lpTTFontInfo

      /******** Now fill out TTFONTINFO structure  ***********/

      lpTTFontInfo = (LPTTFONTINFO)((LPSTR)lpFontInfo +
                                    wSize /* + wExtraWidthTable */ );

      lpTTFontInfo->TTRefEM = ((PSSCALABLEFONTINFO FAR *)(lpFontInfo))->erEM;


      /* TrueType fonts are already scaled by the engine 
       * Except for Type42, we ahve to scale it properly ourself (change sx).
       * Do it only after initRefEMfont() is called - we need xFont.
       */
      lpTTFontInfo->sx = lpTTFontInfo->sy = cyFont;
      lpTTFontInfo->lfPoints = Scale(cyFont, 72,
                                       lppd->DeviceRes.y_res);
      /* Make a copy of LogFont and TextXForm */
      lpTTFontInfo->lfCopy =  *lpLogFont;
      lpTTFontInfo->ftCopy =  cEngineTXF;

      // WIFE font can be rotated only by a multiple of 90.
      if (lpFontInfo->dfType & PF_WIFE_TYPE)
      {
          lpTTFontInfo->lfCopy.lfEscapement = lpTTFontInfo->ftCopy.ftEscapement;
          lpTTFontInfo->lfCopy.lfOrientation = lpTTFontInfo->ftCopy.ftOrientation;
      }
      // Adjust the lfCharSet in lfCopy so that we can correctly decide this is
      // a FarEast font or not based on lfCopy:
      if (lpLogFont->lfCharSet != (BYTE)lpFontInfo->dfCharSet)
          {
          lpTTFontInfo->lfCopy.lfCharSet = (BYTE)lpFontInfo->dfCharSet;
          }

      /*
         * Mark this LOGFONT copy as TT_only realizable to prevent
         * ATM from realizing this font when we call CreateFontIndirect
         * and ATM has the PS font with the same name.
         * Fixed 27-May-1993  -by-  [olegs]
         */
      //lpTTFontInfo->lfCopy.lfOutPrecision = OUT_TT_ONLY_PRECIS;
      //moved to ttfonts.c

      lpCache->bTTResident = IsTTFontResident( &(lpTTFontInfo->lfCopy), lpCache, lpCache->bUseWideFont, (lpTTFontInfo->lfCopy).lfCharSet );

      if (lpCache->bTTResident)
         lpFontInfo->dfType |= TYPE_TTRESIDENT;

      /* add-in size for xFontInfo*/
      lpTTFontInfo->wXFontInfoSize = GetRefFontSize(lppd, lpLogFont, lpCache->bOutline , lpCache->bTTResident);
      lpTTFontInfo->dwXFontInfo = 0; // until Ref font is realized.
      /*------------------------------------------------------------*/

      lpTTFontInfo->dwSubFontInfo = 0L ;  // none right now.
      // new field, points to lpFontInfo of device font, if any.

      // new field, points to tmp width arrays.
      //  make these  communal buffers in lppd

      // lpTTFontInfo->lpdWidths = NULL ;
      // lpTTFontInfo->sizlpdWidths = 0 ;

      // lpTTFontInfo->rgwWidths = NULL ;
      // lpTTFontInfo->sizrgwWidths = 0 ;

      lpTTFontInfo->zeroEscapementFont = NULL ;

      lpTTFontInfo->wTTFlags = lpCache->wTTFlags ;

      lpTTFontInfo->Widths = NULL;   // For ATM
      lpTTFontInfo->sizWidths = 0;

      //this will help determine if T42able
      if (IsRealTTFont(&lpTTFontInfo->lfCopy) )
          lpTTFontInfo->dwProperties |= TTFI_IS_REAL_TT ;

      if (IsType42Able(lppd, lpFontInfo) )
          lpTTFontInfo->dwProperties |= TTFI_IS_TYPE42ABLE ;

      if ( LOCA_TBL_OK == IsLocaTblFaulty(&lpTTFontInfo->lfCopy) )
          lpTTFontInfo->dwProperties |= TTFI_LOCA_TBL_OK ;
      else
          lpTTFontInfo->dwProperties |= TTFI_LOCA_TBL_FAULTY ;

      lpTTFontInfo->iDLFontFormat = CheckDLType(lppd,&(lpTTFontInfo->lfCopy) , lpFontInfo, NULL);

      /* NOTICE: Only after this point, dwProperties & TTFI_xxx and
       * lpTTFontInfo->iDLFontFormat can be used - e.g., TextOut() and TTDownload()
       */

      if (lpTTFontInfo->iDLFontFormat == TT_DLFORMAT_TYPE42)
         lpFontInfo->dfType |= TYPE_OUTLINE;
        
      //this will be need in initlpdWidths and initrgwWidths
      lpTTFontInfo->maxNumGlyph = CGetMaxNumberOfGlyphs(&(lpTTFontInfo->lfCopy));


      /* TrueType fonts are already scaled by the engine 
       * Except for Type42, we ahve to scale it properly ourself.
       * Do it only after initRefEMfont() is called - we need xFont.
       */
      rc = initrgwWidths(lppd, lpFontInfo, NULL, 256) ;
      if (PS_ERROR(rc))
           goto endTTRealizeFont;
      rc = initRefEMfont(lppd, lpFontInfo);
      if (PS_ERROR(rc))
           goto endTTRealizeFont;


      // Fix Bug 155189, 7-17-96, PPeng
      if (lpTTFontInfo->dwXFontInfo)
         lpTTFI0 = (LPPSFONTINFO)BUMPFAR (lpFontInfo, lpTTFontInfo->dwXFontInfo) ;

      if (lpTTFontInfo->iDLFontFormat == TT_DLFORMAT_TYPE42 &&
          lpTTFontInfo->lfCopy.lfWidth &&
          lpFontInfo->dfType & TYPE_OUTLINE){
          // See initRefEMfont() in realize.c -xFont is in Natural Width:
          h0 = (lpTTFI0->dfPixHeight - lpTTFI0->dfInternalLeading);
          w0 = lpTTFI0->dfPixWidth;
          if (w0 == 0 ) w0 = lpTTFI0->dfAvgWidth;
          lpTTFontInfo->sx = MulDiv(h0, lpTTFontInfo->lfCopy.lfWidth, w0);
         }

     // For all cases, use MSTT31xxxx name. 8-31-95 Fix bug 119001
     ConstructTTName(lppd, &(lpTTFontInfo->lfCopy), lpFontInfo, bUseGlyphIndex, cyFont);
      // if the font is resident, we would like the true PS name for TT font
      // lpFontInfo->lfCopy.lfFaceName = Arial
      // lpTTFontInfo->TTFaceName = ArialMT
      // lpTTFontInfo->PSName = MSTT31%04x
      //  We make th asumption thisis a type 42 font.
      if (lpFontInfo->dfType & TYPE_TTRESIDENT)
      {
         //query engine w/ Family Name to find PSName
         lstrcpy(ttFont.szName2, lpTTFontInfo->lfCopy.lfFaceName);
         GetTTInfo(&ttFont, TTPSName, &(lpTTFontInfo->lfCopy));
         
         lstrcpy(lpTTFontInfo->TTFaceName, ttFont.szName1 ) ;
      }
   } //end of 2nd pass

  /******** common to 1st and 2nd pass  ***********/

   if(lpTextXForm)
      *lpTextXForm = cEngineTXF ;

   /*
   * Copy all necessary information into EngineLogFont structure
   *  We will later use this info for font scoring
   */
   if(lpEngineLogFont  &&  lpLogFont)
   {
      LPSTR    lpFaceName= MAKELP( SELECTOROF(lpTTFI), lpTTFI->dfFace  ) ;

      *lpEngineLogFont = *lpLogFont ;
      lpEngineLogFont->lfWeight = lpTTFI->dfWeight;
      lpEngineLogFont->lfItalic = lpTTFI->dfItalic;
      lpEngineLogFont->lfUnderline = lpTTFI->dfUnderline;
      lpEngineLogFont->lfCharSet = lpTTFI->dfCharSet;
      lpEngineLogFont->lfPitchAndFamily = lpTTFI->dfPitchAndFamily;
      lstrcpy(lpEngineLogFont->lfFaceName, lpFaceName );
   }

   bSuccess  = TRUE ;  // Wow, we made it to the end without error!

endTTRealizeFont:

   // restore the old Height -- For all cases -- 11-2-95. PPeng
   lpLogFont->lfHeight = lfHeight;

   if(lpSize)
   {
      if(bSuccess)
      {
         *lpSize =  wSize + sizeof(TTFONTINFO) ;
                    //   + wExtraWidthTable + wWidthTable;
      }
      else
      {
         *lpSize = 0 ;
      }
   }
   return(nTTrealized);
}


/************************************************************************
*
*       Set of functions to deal with allocation of strings for
*                           font tables
*
*
**************************************************************************/


WORD NEAR PASCAL GetTTFontID(LPPDEVICE lpdv, LPSTR lpszCacheKey)
{
   HANDLE hList;
   ATOM aFace;

   /* see if the atom already exists and if so we're done! */
   aFace = GlobalFindAtom(lpszCacheKey);
   if (aFace)
       return aFace;

   /* nope, need to add to list... */
   if (!lpdv->sTTFontList) {
       hList = GlobalAlloc(GDLLHND, 128 * sizeof(WORD));
       if (!hList)
           return 0;
       lpdv->lpTTFontList = (WORD FAR *)GlobalLock(hList);
       lpdv->sTTFontList = 128;
   } else if (lpdv->cTTFontList == lpdv->sTTFontList) {
       HANDLE hNewList;

       /* grow buffer */
       hList = (HANDLE)GlobalHandle(HIWORD((DWORD)lpdv->lpTTFontList));
       GlobalUnlock(hList);
       hNewList = GlobalReAlloc(hList, (lpdv->sTTFontList + 128) * sizeof(WORD),
                                      GMEM_MOVEABLE);
       if (!hNewList)
           return 0;
       lpdv->lpTTFontList = (WORD FAR *)GlobalLock(hNewList);
       lpdv->sTTFontList += 128;
   }

   /* get an atom for the string */
   aFace = GlobalAddAtom(lpszCacheKey);
   if (!aFace)
       return 0;

   /* add atom to end of list */
   lpdv->lpTTFontList[lpdv->cTTFontList++] = aFace;

   /* return atom # as id */
   return aFace;
}

void FAR PASCAL FreeTTFontTable(LPPDEVICE lpdv)
{
          int i;
          HANDLE h;

          for (i = 0; i < lpdv->cTTFontList; ++i)
                    GlobalDeleteAtom(lpdv->lpTTFontList[i]);
          h = HIWORD((DWORD)lpdv->lpTTFontList);
          if (h) {
               h = (HANDLE)GlobalHandle(h);
               GlobalUnlock(h);
               GlobalFree(h);
          }
          lpdv->cTTFontList = lpdv->sTTFontList = 0;
          lpdv->lpTTFontList = 0;
}



/************************************************************************
*                       RealizePen
*  function:
*       returns the size of a PPEN structure or converts a logical pen
*       structure into a physical pen structure.
*  prototype:
*       WORD FAR PASCAL RealizePen(lppd,lpLogPen,lpPPen);
*  parameters:
*       LPPDEVICE  lppd     -- pdevice pointer
*       LPLOGPEN lpLogPen -- pointer to logical pen struct passed in
*       LPPPEN     lpPPen   -- pointer to the physical pen struct returned.
*  returns:
*       sizeof (PPEN)
**************************************************************************/

WORD FAR PASCAL RealizePen(LPPDEVICE lppd,LPLOGPEN lpLogPen,LPPPEN lpPPen)
{
  if(lpPPen)                                            // If the ptr is null
  {                                                     // return the size
      lpPPen->bStyle  = (BYTE)lpLogPen->lopnStyle;
      lpPPen->ptWidth = lpLogPen->lopnWidth      ;
      lpPPen->dFGColor= lpLogPen->lopnColor      ;
      lpPPen->bSpare  = 0                        ;

      //the value of these have either previously been set by escapes,
      //or, they have been set to their defaults during Enable()

      lpPPen->bCap   = lppd->pen.bCap            ;
      lpPPen->bJoin  = lppd->pen.bJoin           ;
      lpPPen->sMiterLimit=lppd->pen.sMiterLimit  ;
  }
  return(sizeof(PPEN))                          ;
}

/************************************************************************
*                       RealizeBrush
*  function:
*       returns the size of a PBRUSH structure or converts a logical brush
*       structure into a physical brush structure.
*  prototype:
*       WORD FAR PASCAL RealizeBrush(lppd,lpLogBrush,lpPBrush,lpPt)
*  parameters:
*       LPPDEVICE  lppd       -- pdevice pointer
*       LPLOGBRUSH lplogbrush -- pointer to logical brush struct passed in
*       LPPBRUSH   lpPBrush   -- pointer to the physical brush struct returned.
*       LPPOINT    lpPt       -- pointer to a point struct (coordinates used to "align" patterns)
*                                (currently ignored)
*  returns:
*       sizeof (PBRUSH) if lpPBrush is NULL,
*       else following bits are set as appropriate:
*              BRUSH_SUCCESS if no error.
*              BRUSH_SOLID_MONOCHROME if brush is solid for a monochrome DC.
*              BRUSH_SOLID_COLOR if brush is solid for a color DC.
**************************************************************************/

WORD FAR PASCAL RealizeBrush(LPPDEVICE lppd,LPLOGBRUSH lpLogBrush,
                             LPPBRUSH lpPBrush, LPPOINT lpPt)
{
    LPBITMAP lpbm;
    LP lpbmBits;
    short i;
    WORD rc = 0;

    //if the pointer to the Physical Brush is null, return the size,
    //otherwise...
    if(lpPBrush != NULL) {
        lpPBrush->bStyle  = (BYTE)lpLogBrush->lbStyle;
        lpPBrush->bHatch  = (BYTE)lpLogBrush->lbHatch;
        lpPBrush->dFGColor= lpLogBrush->lbColor;

        //we extract the pattern from the color field for pattern brushes
        if(lpPBrush->bStyle==BRUSHSTYLE_pattern) {
            lpbm=(LPBITMAP)lpLogBrush->lbColor;
            lpbmBits=(LP)lpbm->bmBits;

            //we assume here that this is a monochrome pattern
            for(i=0;i<8;i++) {
                lpPBrush->pattern[7 - i]=lpbmBits[0];
                lpbmBits+=lpbm->bmWidthBytes;
            }
        }

        //hatched brushes are the only ones allowed to have a background color
        if(lpPBrush->bStyle==BRUSHSTYLE_hatched)
          lpPBrush->dBGColor=lpLogBrush->lbBkColor;
        else
          lpPBrush->dBGColor=RGB_WHITE;

        if (lpPBrush->bStyle == BRUSHSTYLE_solid) {
            if (lppd->sMagic == LUCAS) {
                /* !!! Note: When we support color and modify InitGDIInfo()
                 * in cont\enable.c, we have to add logic here to decide
                 * if the current DC is color or monochrome.
                 */
                  rc |= BRUSH_SOLID_MONOCHROME;
            }
            else {              /* Bitmap pdevice */
                BITMAP FAR* lpBM = (BITMAP FAR*) lppd;

                if (lpBM->bmPlanes == 1 && lpBM->bmBitsPixel == 1)
                  rc |= BRUSH_SOLID_MONOCHROME;
                else
                  rc |= BRUSH_SOLID_COLOR;
            }
        }
        rc |= BRUSH_SUCCESS;
    }
    else
      rc = sizeof(PBRUSH);

    return rc;
}


/**************************************************************************
*                       RealizeObject
*  function:
*       realize object entry point.
*  prototype:
*       WORD FAR PASCAL RealizeObject(LP lpDevice,short sStyle,LP lpInObj,
*                                      LP lpOutObj,LP lpData)
*  parameters:
*       LP lpDevice -- PDEVICE pointer
*       short sStyle -- one of OBJ_PEN, OBJ_BRUSH, OBJ_FONT
*       LP lpInObj -- ptr to a logical pen, brush, or font struct
*       LP lpOutObj -- ptr to a PPEN, PBRUSH, or a truncated PSFONTINFO struct
*       LP lpData -- TEXTXFORM struct if sStyle is OBJ_FONT, NULL otherwize
*  returns:
*       0 for error, else size of OutObj structure if lpOutObj == NULL
**************************************************************************/

WORD _loadds FAR PASCAL RealizeObject(LP lpDevice,short sStyle,LP lpInObj,
                                      LP lpOutObj,LP lpData)
{
     LPPDEVICE lppd;
     WORD retval;

     lppd=(LPPDEVICE)lpDevice;
     retval = 0;

     //if this call to a memory bitmap?
     if(lppd->sMagic == 0)
     {
          if (sStyle != OBJ_FONT)
               retval = dmRealizeObject(lpDevice,sStyle, lpInObj,lpOutObj,lpData);
     }
     else if(lppd->sMagic == LUCAS)
     {

               switch(sStyle)
                    {
                    case OBJ_PEN:
                         retval = RealizePen(lppd,(LPLOGPEN)lpInObj,(LPPPEN)lpOutObj);
                    break;

                    case -OBJ_PEN:
                         retval = 1;
                    break;

                    case OBJ_BRUSH:
                         retval = RealizeBrush(lppd,(LPLOGBRUSH)lpInObj,
                                                   (LPPBRUSH)lpOutObj,(LPPOINT)lpData);
                    break;

                    case -OBJ_BRUSH:
                         retval = 1;
                    break;

                    case OBJ_FONT:
                         retval = RealizeFont(lppd, (LPLOGFONT)lpInObj,
                                               (LPPSFONTINFO)lpOutObj,(LPTEXTXFORM)lpData);
                    break;

                    case -OBJ_FONT:
                      if (((LPPSFONTINFO) lpInObj)->dfType & TYPE_TRUETYPE)
                      {
                         LPPSFONTINFO FontInfo = (LPPSFONTINFO)lpInObj;
                         LPTTFONTINFO lpTTFontInfo ;

                         lpTTFontInfo = (LPTTFONTINFO)
                               ((LPSTR)FontInfo + FontInfo->dfBitsOffset);

                         if(lpTTFontInfo->zeroEscapementFont)
                         {
                           EngineDeleteFont(lpTTFontInfo->zeroEscapementFont);
                           GlobalFreePtr(lpTTFontInfo->zeroEscapementFont);
                           lpTTFontInfo->zeroEscapementFont = NULL ;
                         }
                         if (FontInfo->dfType & TYPE_OUTLINE  &&
                                    lpTTFontInfo->dwXFontInfo)
                         {
                           // The reason for this part is that we keep an extra
                           // copy of PSFONTINFO and extra realized font in natural
                           // height (2048 pixels grid) for T1 convertion
                           LPPSFONTINFO lpXFontInfo =  NULL;

                           if (lpTTFontInfo->dwXFontInfo)
                           {
                              lpXFontInfo = (LPPSFONTINFO)BUMPFAR (FontInfo, lpTTFontInfo->dwXFontInfo) ;
                              EngineDeleteFont(lpXFontInfo);
                              lpTTFontInfo->dwXFontInfo = 0;  // no RefFont realized.
                           }
                         }
                         if (FontInfo->dfType & TYPE_ATMFONT)
                         {
                             if (lpTTFontInfo->Widths)
                             {
                                 GlobalFreePtr(lpTTFontInfo->Widths);
                                 lpTTFontInfo->Widths = NULL;
                                 lpTTFontInfo->sizWidths = 0;
                             }
                         }
                         EngineDeleteFont(FontInfo);
                      }
                      retval = 1;
                    break;

                    default:
                         retval = 0 ;
                    } //switch
     }

     return(retval);
}


int FAR PASCAL CompareFonts(LPVOID elem1, LPVOID elem2)
{
    return lstrcmp((LPSTR) ((LPFONTSUBSTABLE) elem1)->TTFontName, (LPSTR) elem2);
}


/*****************************************************************************/
/*                 GetSubstitute                                             */
/* Purpose:                                                                  */
/*   Given buffers already allocated, given a TT Font we pass back           */
/*   the substitute if it exist or a 0 length string if it doesn't           */
/*                                                                           */
/* Parameters:                                                               */
/*   HANDLE ghDriverMod -- Driver module handle                              */
/*   LPPDEVICE lppd -- pdevice                                               */
/*   LPSTR lpTTFont -- TrueType font family (input)                          */
/*   LPSTR lpPSFont -- Mapped to this PostScript Font family (output)        */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void FAR PASCAL GetSubstitute(HANDLE ghDriverMod, LPPDEVICE lppd,
                               LPPSEXTDEVMODE lpPSExtDevmode,
                               LPSTR lpTTFont, LPSTR lpPSFont)
{
    int  i;

    *lpPSFont = '\0';

    if (! lppd->lpFontSubsTable)
      CreateFontSubsTable(lppd);

    if (lppd->lpFontSubsTable) {
        i = BSearch((LPVOID) lppd->lpFontSubsTable, 0, lppd->wFontSubsEntries,
                    sizeof(FONTSUBSTABLE), CompareFonts, (LPVOID) lpTTFont);
        if (i != -1)
          lstrcpy(lpPSFont, lppd->lpFontSubsTable[i].PSFontName);
    }

    return;
}



LPBYTE   FAR PASCAL   ReallocBuffer(
WORD   wSize,
WORD    mode,
LPWORD  lpRecordedSize,
LPBYTE  FAR  *  lplpBuf )
{
   LPBYTE  lpTmp;

   lpTmp = GlobalReAllocPtr((LPBYTE)*lplpBuf,
                                    wSize, mode);

   if (lpTmp)
   {
      *lpRecordedSize = wSize;
      *lplpBuf = lpTmp;
   }
   else
   {
#ifdef PSDEBUG
      MessageBox(NULL, (LPSTR) "Out of Memory", (LPSTR) "PSCRIPT DRIVER",
                  MB_OK | MB_ICONEXCLAMATION);
#endif
   }

   return(lpTmp) ;
}


//
// This function fills up the CharWidth array similar to the way
// EngineGetCharWidthStr would do, except that it is used whenever ATM has
// realized a font.
// It gets the width table from ATM using EngineGetCharWidth, and then
// pulls off the appropriate widths and populates the CharWidth array.
//
BOOL NEAR PASCAL ATMGetCharWidthStr(LPPSFONTINFO lpFontInfo, LPTTFONTINFO lpTTFontInfo,
    LPPSFONTINFO lpActualFI, LPBYTE textstr, WORD count, LPWORD lpWidthTable)
{
    WORD i, j;
    BOOL rc = TRUE;

     if (lpTTFontInfo->sizWidths == 0)
     {
         if (lpTTFontInfo->Widths = GlobalAllocPtr(GHND|GMEM_DDESHARE,
             256 * sizeof(WORD)))
             lpTTFontInfo->sizWidths = 256 * sizeof(WORD);
     }

     if (lpTTFontInfo->Widths &&
         lpTTFontInfo->sizWidths <
         (lpFontInfo->dfLastChar - lpFontInfo->dfFirstChar + 1)*sizeof(WORD))
     {
         LPWORD lpTemp;

         lpTemp = GlobalReAllocPtr(lpTTFontInfo->Widths,
             (lpFontInfo->dfLastChar - lpFontInfo->dfFirstChar + 1)*sizeof(WORD),
             GMEM_ZEROINIT);
         if (!lpTemp)
         {
             GlobalFreePtr(lpTTFontInfo->Widths);
             lpTTFontInfo->Widths = NULL;
             lpTTFontInfo->sizWidths = 0;
         }
         else
         {
             lpTTFontInfo->Widths = lpTemp;
             lpTTFontInfo->sizWidths = (lpFontInfo->dfLastChar - lpFontInfo->dfFirstChar + 1)*sizeof(WORD);
         }
     }

     if (lpTTFontInfo->Widths)
     {
         EngineGetCharWidth((LPPSFONTINFO)lpActualFI, lpFontInfo->dfFirstChar,
                   lpFontInfo->dfLastChar, lpTTFontInfo->Widths);
         for (i=0; i<count; i++)
         {
             if (textstr[i] < lpFontInfo->dfFirstChar ||
                 textstr[i] > lpFontInfo->dfLastChar)
                 j = lpFontInfo->dfDefaultChar;
             else
                 j = textstr[i];

             // FIx a bug where dfDefaultChar < lpFontInfo->dfFirstChar -in CJK
             if (j < lpFontInfo->dfFirstChar) j = lpFontInfo->dfFirstChar;

             lpWidthTable[i] = lpTTFontInfo->Widths[j-lpFontInfo->dfFirstChar];
         }
     }
     else
         rc = FALSE;

     return rc;
}

// CCGetCharWidthStr() - should be called SlowGetCharWidthStr().
// This function fills up the lpCharWidthTable array similar to the way
// EngineGetCharWidthStr() would do, except that it uses
// EngineGetCharWidth() for one char at a time. This function is created
// to work-around a GPF in GDI - see bug 123330.
//
BOOL NEAR PASCAL CCGetCharWidthStr(LPPSFONTINFO lpActualFI, LPBYTE textstr, WORD count, LPWORD lpWidthTable)
{
    WORD i;
    BOOL rc = TRUE;

    i = 0;
    while (i < count )
    {
      EngineGetCharWidth((LPPSFONTINFO)lpActualFI, textstr[i],
                   textstr[i], &(lpWidthTable[i]));
      i++;
    }//while

     return rc;
}


PSERROR FAR PASCAL   initrgwWidths(LPPDEVICE lppd, LPPSFONTINFO lpFontInfo,
LPBYTE  textstr, WORD  count)
{
   LOGFONT LogFont ;
   LPTTFONTINFO  lpTTFontInfo;   /* Pointer to the TT-specific info */
   LPREALIZEBUFS  lpCache ;
   WORD   flags ;
   LPPSFONTINFO  lpFI,  // may use this if escapement non-zero
            lpActualFI;    // points to FontInfo actually used.
   PSERROR  rc = PS_SUCCESS;
   LPWORD lpGID = NULL;
   WORD   wCount;

  if (textstr == NULL || count == 0)
  {
        return rc;
  }

    wCount = count * 2; // want one more count*Word buffer for lpGID

   lpCache = &lppd->GlobalBuffer.RealizeBufs ;

   lpTTFontInfo = (LPTTFONTINFO)((LPSTR)lpFontInfo +
                                 lpFontInfo->dfBitsOffset ) ;
   LogFont = lpTTFontInfo->lfCopy ;

   if(!lpCache->rgwWidths && wCount >0)
   {
      // allocate a buffer of size 2*wCount !
      if (lpCache->rgwWidths =
            GlobalAllocPtr(GHND|GMEM_DDESHARE, (wCount + 10) * sizeof(WORD)))
          lpCache->sizrgwWidths = (wCount + 10) * sizeof(WORD);
      else
      {
          rc = PS_ALLOC_FAILED;
          goto screwedUpWidths;
      }
   }

   if(lpCache->sizrgwWidths < wCount * sizeof(WORD))
   {
      //  realloc with room to grow.
      LPBYTE  lpBuf ;  // status.

      lpBuf =  ReallocBuffer((wCount+10) * sizeof(WORD),
            GHND|GMEM_DDESHARE,  &lpCache->sizrgwWidths,
            (LPBYTE  FAR  *)&lpCache->rgwWidths  ) ;

      if (!lpBuf)
      {
         GlobalFreePtr(lpCache->rgwWidths) ;
         lpCache->rgwWidths = NULL ;
         lpCache->sizrgwWidths = 0 ;
         rc = PS_ALLOC_FAILED;

         goto  screwedUpWidths ;
      }
   }

   // initialize CharWidths Table
   {

      lpActualFI = lpFontInfo ;
      lpFI = NULL ;

      if(lpFontInfo->dfType & PF_GLYPH_INDEX)
         flags = 0 ;
      else
         flags = 0x0001 ;


      /*
         * Fix for non-square resolution printers:
         * When asked to realize the font with non-zero escapement for
         * non-square resolution the width is scaled proportionally.
         * We need normal width, so we can position characters properly
         *  Added  23-Apr-1993  -by-  [olegs]
         */
      if(LogFont.lfEscapement || LogFont.lfOrientation)
      {
         if(lpTTFontInfo->zeroEscapementFont)
            lpFI = lpTTFontInfo->zeroEscapementFont ;
         else
         {
            //  we need to create the zeroEscapementFont

            TEXTXFORM   txfCopy ;
            WORD        cb, wSize;


            /* make font as unhinted with 0 escapment with rest of
               LOGFONT same  */
            LogFont.lfEscapement = LogFont.lfOrientation = 0;

            /* allocate space for new font */

            if (lpFontInfo->dfType & TYPE_ATMFONT)
            {
                wSize = EngineRealizeFont((LPLOGFONT) &LogFont,
                                    (LPTEXTXFORM) NULL ,
                                    (LPPSFONTINFO) NULL);
            }
            else
            {
                wSize = (WORD)EngineRealizeFontExt(lppd->hdc, (LPLOGFONT) &LogFont,
                                    (LPTEXTXFORM) NULL ,
                                    (LPPSFONTINFO) NULL, flags );
            }

            lpFI = lpTTFontInfo->zeroEscapementFont =
                  GlobalAllocPtr(GHND|GMEM_DDESHARE, wSize) ;
            if (!lpFI)
            {
                rc = PS_ALLOC_FAILED;
                goto screwedUpWidths;
            }

            if (lpFontInfo->dfType & TYPE_ATMFONT)
            {
                cb = EngineRealizeFont((LPLOGFONT) &LogFont,
                                    (LPTEXTXFORM) &txfCopy,
                                    (LPPSFONTINFO)lpFI);
            }
            else
            {
                cb = (WORD)EngineRealizeFontExt(lppd->hdc, (LPLOGFONT) &LogFont,
                                    (LPTEXTXFORM) &txfCopy,
                                    (LPPSFONTINFO)lpFI, flags);
            }

            if(!cb)
            {
               GlobalFreePtr(lpFI) ;
               lpFI = lpTTFontInfo->zeroEscapementFont = NULL ;
               rc = PS_ENGINEREALIZEFONT_FAILED;
               goto  screwedUpWidths ;
            }
         }
         lpActualFI = lpFI ;
      }

#if  0
      /* Get the widths of all defined chars in a font.
       * For glyph index TrueType fonts, we must use the
       * new engine callback so ATM doesn't stomp the high bytes.
       *
       * 21-February-1994  -by-  Raymond E. Endres [rayen]
       */

      if(lpFontInfo->dfType & PF_GLYPH_INDEX)
      {
         WORD   numGlyphs ;     // number of Glyphs in this font.

         numGlyphs = *(LPWORD)&lpFontInfo->dfFirstChar ;

         EngineGetCharWidthEx((LPPSFONTINFO)lpActualFI, 0, numGlyphs-1,
                        lpTTFontInfo->rgwWidths);
      }
      else
      {
         EngineGetCharWidth((LPPSFONTINFO)lpActualFI, lpFontInfo->dfFirstChar,
                        lpFontInfo->dfLastChar, lpTTFontInfo->rgwWidths);
      }

      if(lpFI)
         EngineDeleteFont((LPPSFONTINFO)lpFI ) ;

#endif

     if ( lpFontInfo->dfType & PF_GLYPH_INDEX )
     {
        WORD  i;

        lpGID = (LPWORD) ( ((LPBYTE)lpCache->rgwWidths) + count * sizeof(WORD) );
        MemCopy(lpGID, textstr, count*sizeof(WORD));

        for (i=0; i<count; i++)
        {
            // remove junky gid;
            if (lpGID[i] > lpTTFontInfo->maxNumGlyph )
                lpGID[i] = 0;
        }
     }
     else
     {
         lpGID = (WORD *) textstr;
     }


      if (lpFontInfo->dfType & TYPE_ATMFONT)
      {
          if (!ATMGetCharWidthStr(lpFontInfo, lpTTFontInfo,
              lpActualFI, (LPBYTE)lpGID, count, lpCache->rgwWidths))
          {
              rc = PS_ALLOC_FAILED; // Should be return by ATMGet...() in future.
              goto screwedUpWidths;
          }
      }
      else
      {

        // IF Char-code mode ...  fix a GPF in GDI.exe, 123330
        // also fixed for 195627 and 207471
        // See bug 207471 for logic of if stmt.
        // See bug 209372 for new logic of if stmt.
        // IMPORTANT!!! make sure code change here is in both initrgwWidths() and initlpdWidths()
        if ( (lpFontInfo->dfType & PF_GLYPH_INDEX) ||  //GI || (DBCS & !Fixed) || CS==128
             (IsDBCSCharSet(lpActualFI->dfCharSet) && (lpActualFI->dfPitchAndFamily & 0x01))||
             (lpActualFI->dfCharSet == 128)
           )
        {
            EngineGetCharWidthStr((LPPSFONTINFO)lpActualFI, (LPBYTE)lpGID, count,
                        lpCache->rgwWidths);
        }
        else
        {
            CCGetCharWidthStr((LPPSFONTINFO)lpActualFI, (LPBYTE)lpGID, count,
                        lpCache->rgwWidths);
        }
     }
   }

screwedUpWidths:
   if (PS_ERROR(rc))
   {
       if (lpCache->rgwWidths)
       {
            GlobalFreePtr(lpCache->rgwWidths) ;
            lpCache->rgwWidths = NULL ;
            lpCache->sizrgwWidths = 0 ;
       }

       if (lpTTFontInfo->zeroEscapementFont)
       {
           GlobalFreePtr(lpTTFontInfo->zeroEscapementFont) ;
           lpTTFontInfo->zeroEscapementFont = NULL ;
       }
   }
   return rc;
}


/*-----------------------------------------------------------
   * In order to get the best outlines for T1 fonts we need to
   * realize the font non-hinted with natural width and height
   * in the original digitized grid.
------------------------------------------------------------ */

PSERROR FAR PASCAL initRefEMfont(LPPDEVICE lppd, LPPSFONTINFO lpFontInfo)
{
   int           cyFont , cxFont;
   LPTTFONTINFO  lpTTFontInfo;   /* Pointer to the TT-specific info */
   PSERROR       rc = PS_SUCCESS;
   LPPSFONTINFO xFontInfo =NULL;

   lpTTFontInfo = (LPTTFONTINFO)((LPSTR)lpFontInfo +
                                 lpFontInfo->dfBitsOffset ) ;

   cyFont = lpTTFontInfo->sy;

   cxFont = lpFontInfo->dfPixWidth;
   if (cxFont == 0 )
      cxFont = lpFontInfo->dfAvgWidth;


   if ((lpFontInfo->dfType & TYPE_OUTLINE) && !lpTTFontInfo->dwXFontInfo)
   {
//      LPFONTEXTRA lpFontExtra  = (LPFONTEXTRA)lpFontInfo->dfDriverInfo;
//    doesn't exist for TT fonts.
      LOGFONT lfCopy;
      WORD wSize;
      WORD   flags ;
      int iDLFontFmt;
      LPPSFONTINFO lpXFontInfo =NULL;
      WORD rtn = 0;

      if(lpFontInfo->dfType & PF_GLYPH_INDEX)
         flags = 0 ;
      else
         flags = 0x0001 ;


// #if 0  // -by- ShyamV - Is this a bug or a fix? - 10/6/93
//      No!!! This is a specific fix for Bug 425.
      /* make font as unhinted with 0 escapment with rest
      * of LOGFONT same  */

      lfCopy = lpTTFontInfo->lfCopy ;
      lfCopy.lfEscapement = lfCopy.lfOrientation = 0;
      lfCopy.lfHeight = -(int)lpTTFontInfo->TTRefEM ;

   // Do this for all cases and set a default 10pt if the heightis 0
   if (!lfCopy.lfHeight)
      lfCopy.lfHeight = - MulDiv(10, lppd->DeviceRes.y_res, 72);


      /* For type42 fonts request the realization with
      * natural width.  Fixed bug 425. 25-Aug-1993  -by-  [olegs] */

      lfCopy.lfWidth = 0 ;
      iDLFontFmt = lpTTFontInfo->iDLFontFormat;

      if (iDLFontFmt != TT_DLFORMAT_TYPE42)
      {
         lfCopy.lfWidth = Scale(cxFont, lpTTFontInfo->TTRefEM, cyFont);
      }
//#endif


      if (lpFontInfo->dfType & TYPE_ATMFONT)
      {
           wSize = EngineRealizeFont(&lfCopy,
                              (LPTEXTXFORM) NULL,
                              (LPPSFONTINFO) NULL);
      }
      else
      {
          wSize = (WORD)EngineRealizeFontExt(lppd->hdc, &lfCopy,
                              (LPTEXTXFORM) NULL,
                              (LPPSFONTINFO) NULL, flags);
      }

      if(!wSize)
      {

         lpTTFontInfo->dwXFontInfo = 0 ;  // no RefFont realized.
         rc = PS_ENGINEREALIZEFONT_FAILED;
         goto  screwUP2;
      }

      xFontInfo = GlobalAllocPtr(GHND|GMEM_DDESHARE, wSize) ;
      if(!xFontInfo || (lpTTFontInfo->wXFontInfoSize < wSize))
      {
         rc = PS_ALLOC_FAILED;
         goto  screwUP2;
      }

      lpTTFontInfo->dwXFontInfo = lpFontInfo->dfBitsOffset + sizeof(TTFONTINFO);
      lpXFontInfo = (LPPSFONTINFO)BUMPFAR (lpFontInfo, lpTTFontInfo->dwXFontInfo) ;

      if (lpFontInfo->dfType & TYPE_ATMFONT)
      {
          rtn = EngineRealizeFont(&lfCopy,
                              (LPTEXTXFORM) &lpTTFontInfo->ftCopy,
                              (LPPSFONTINFO)xFontInfo);

      }
      else
      {
          rtn = (WORD)EngineRealizeFontExt(lppd->hdc, &lfCopy,
                              (LPTEXTXFORM) &lpTTFontInfo->ftCopy,
                              (LPPSFONTINFO)xFontInfo, flags);
      }

      if(!rtn)
      {
         lpTTFontInfo->dwXFontInfo = 0 ;  // no RefFont realized.
         rc = PS_ENGINEREALIZEFONT_FAILED;
         goto  screwUP2;
      }

      MemCopy((LP)lpXFontInfo, (LP) xFontInfo, wSize);


#if  0
      /* Get the widths of all defined chars in a font.
       * For glyph index TrueType fonts, we must use the
       * new engine callback so ATM doesn't stomp the high bytes.
       *
       * 21-February-1994  -by-  Raymond E. Endres [rayen]
       */

      lpWidths = lpTTFontInfo->lpdWidths ;  ///  !!! is this correct ?

      if(lpFontInfo->dfType & PF_GLYPH_INDEX)
      {
         WORD   numGlyphs ;     // number of Glyphs in this font.
         LPPSFONTINFO lpXFontInfo =  NULL;
         
         if (lpTTFontinfo->dwXFontInfo)
            lpXFontInfo = (LPPSFONTINFO)BUMPFAR (lpFontInfo, lpTTFontInfo->dwXFontInfo) ;

         numGlyphs = *(LPWORD)&lpFontInfo->dfFirstChar ;

//         EngineGetCharWidth((LPPSFONTINFO)lpTTFontInfo->xFontInfo,

         EngineGetCharWidthEx(xFontInfo, 0, numGlyphs-1, lpWidths);
      }
      else
      {
         EngineGetCharWidth((xFontInfo,
            lpFontInfo->dfFirstChar, lpFontInfo->dfLastChar, lpWidths);
      }

// !!!  Warning  all accesses to lpFontInfo + wSize must be modified
// to expect first element contains width of dfFirstChar !!!!

#endif

   }

screwUP2:
   if (xFontInfo)
     GlobalFreePtr(xFontInfo);
     
   if (PS_ERROR(rc))
   {
       lpFontInfo->dfType &= ~TYPE_OUTLINE;
   }
   return rc;
}


PSERROR  FAR PASCAL   initlpdWidths(LPPDEVICE lppd, LPPSFONTINFO lpFontInfo,
LPBYTE  textstr, WORD  count)
{
   LPTTFONTINFO  lpTTFontInfo;   /* Pointer to the TT-specific info */
   LPREALIZEBUFS  lpCache ;
   PSERROR        rc = PS_SUCCESS;
   LPPSFONTINFO xFontInfo =  NULL;
   LPWORD lpGID = NULL;
   WORD   wCount;


  if (textstr == NULL || count == 0)
  {
        return rc;
  }

   wCount = count * 2; // want one more count*Word buffer for lpGID
   lpCache = &lppd->GlobalBuffer.RealizeBufs ;

   lpTTFontInfo = (LPTTFONTINFO)((LPSTR)lpFontInfo +
                                 lpFontInfo->dfBitsOffset ) ;
   if (!(lpFontInfo->dfType & TYPE_OUTLINE) )
      return rc;  // this font has no lpdWidths ! there is nothing to do.

   if ((rc=initRefEMfont(lppd, lpFontInfo)) != PS_SUCCESS)
      return rc; // failed to create reference font.

   if(!lpCache->lpdWidths)
   {
      // allocate a buffer of size 2*count !
      if (lpCache->lpdWidths =
            GlobalAllocPtr(GHND|GMEM_DDESHARE, (wCount + 10) * sizeof(WORD)))
          lpCache->sizlpdWidths = (wCount + 10) * sizeof(WORD) ;
      else
      {
          rc = PS_ALLOC_FAILED;
          goto EndinitlpdWidths;
      }
   }
   if(lpCache->sizlpdWidths < wCount * sizeof(WORD))
   {
      //  realloc with room to grow.
      LPBYTE  lpBuf ;  // status.

      lpBuf =  ReallocBuffer((wCount+10) * sizeof(WORD),
            GHND|GMEM_DDESHARE,  &lpCache->sizlpdWidths,
            (LPBYTE  FAR  *)&lpCache->lpdWidths  ) ;

      if (!lpBuf)
      {
         GlobalFreePtr(lpCache->lpdWidths) ;
         lpCache->lpdWidths = NULL ;
         lpCache->sizlpdWidths = 0 ;
         rc = PS_ALLOC_FAILED;

         goto EndinitlpdWidths;
      }
   }

   if (lpTTFontInfo->dwXFontInfo)
   {
      xFontInfo = (LPPSFONTINFO)BUMPFAR (lpFontInfo, lpTTFontInfo->dwXFontInfo) ;
   }


    if ( lpFontInfo->dfType & PF_GLYPH_INDEX )
     {
        WORD  i;

        lpGID = (LPWORD) ( ((LPBYTE)lpCache->lpdWidths) + count * sizeof(WORD) );
        MemCopy(lpGID, textstr, count*sizeof(WORD));

        for (i=0; i<count; i++)
        {
            // remove junky gid;
            if (lpGID[i] > lpTTFontInfo->maxNumGlyph )
                lpGID[i] = 0;
        }
     }
     else
     {
         lpGID = (WORD *) textstr;
     }

   if (lpFontInfo->dfType & TYPE_ATMFONT)
   {
       if (!ATMGetCharWidthStr(lpFontInfo, lpTTFontInfo,
           xFontInfo, (LPBYTE)lpGID, count, lpCache->lpdWidths))
       {
           rc = PS_ALLOC_FAILED; // In a perfect world, the function should have returned this.
           goto EndinitlpdWidths;
       }
   }
   else
   {
        // IF Char-code mode ...  fix a GPF in GDI.exe, 123330
        // also fixed for 195627 and 207471
        // See bug 207471 for logic of if stmt.
        // IMPORTANT!!! make sure code change here is in both initrgwWidths() and initlpdWidths()
        if ( (lpFontInfo->dfType & PF_GLYPH_INDEX) //GI or (DBCS & !Fixed) || CS==128
              || (IsDBCSCharSet(xFontInfo->dfCharSet) && (xFontInfo->dfPitchAndFamily & 0x01))
              || (xFontInfo->dfCharSet == 128)
           )
        {
            EngineGetCharWidthStr((LPPSFONTINFO)xFontInfo,
                (LPBYTE) lpGID, count, lpCache->lpdWidths);
        }
        else
        {
            CCGetCharWidthStr((LPPSFONTINFO)xFontInfo,
                (LPBYTE)lpGID, count, lpCache->lpdWidths);
        }
   }

EndinitlpdWidths:
   if (PS_ERROR(rc))
   {
       if (lpCache->lpdWidths)
       {
           GlobalFreePtr(lpCache->lpdWidths) ;
           lpCache->lpdWidths = NULL ;
           lpCache->sizlpdWidths = 0 ;
       }
   }
   return rc;
}



PSERROR FAR PASCAL   initDeviceWidths(LPPDEVICE lppd, LPPSFONTINFO lpFontInfo,
LPBYTE  textstr, WORD  count)
{
   WORD         dfFirstChar ;
   WORD         dfLastChar ;
   WORD         dfDefaultChar;
   WORD        i ;
   BOOL        fVariablePitch;
   LPREALIZEBUFS  lpCache ;
   LPFONTEXTRA      FontExtra ;
   PSERROR     rc = PS_SUCCESS;
   LPSHORT     lpsWidths;
   LPWORD      devlpdWidths;
   LPWORD      devlpsWidths;
   LPSHORT     lpdWidthsFontExtra;
   short       iCh ;


   lpCache = &lppd->GlobalBuffer.RealizeBufs ;

   if(!lpCache->devlpdWidths)
   {
      // allocate a buffer of size 2*count !
      if (lpCache->devlpdWidths =
            GlobalAllocPtr(GHND|GMEM_DDESHARE, (count + 10) * sizeof(WORD)))
          lpCache->sizdevlpdWidths = (count + 10) * sizeof(WORD) ;
      else
      {
          rc = PS_ALLOC_FAILED;
          goto EndinitDeviceWidths;
      }
   }
   if(lpCache->sizdevlpdWidths < count * sizeof(WORD))
   {
      //  realloc with room to grow.
      LPBYTE  lpBuf ;  // status.

      lpBuf =  ReallocBuffer((count+10) * sizeof(WORD),
            GHND|GMEM_DDESHARE,  &lpCache->sizdevlpdWidths,
            (LPBYTE  FAR  *)&lpCache->devlpdWidths  ) ;

      if (!lpBuf)
      {
         GlobalFreePtr(lpCache->devlpdWidths) ;
         lpCache->devlpdWidths = NULL ;
         lpCache->sizdevlpdWidths = 0 ;
         rc = PS_ALLOC_FAILED;

         goto EndinitDeviceWidths;
      }
   }

   if(!lpCache->devlpsWidths)
   {
      // allocate a buffer of size 2*count !
      if (lpCache->devlpsWidths =
            GlobalAllocPtr(GHND|GMEM_DDESHARE, (count + 10) * sizeof(WORD)))
          lpCache->sizdevlpsWidths = (count + 10) * sizeof(WORD);
      else
      {
          rc = PS_ALLOC_FAILED;
          goto EndinitDeviceWidths;
      }
   }
   if(lpCache->sizdevlpsWidths < count * sizeof(WORD))
   {
      //  realloc with room to grow.
      LPBYTE  lpBuf ;  // status.

      lpBuf =  ReallocBuffer((count+10) * sizeof(WORD),
            GHND|GMEM_DDESHARE,  &lpCache->sizdevlpsWidths,
            (LPBYTE  FAR  *)&lpCache->devlpsWidths  ) ;

      if (!lpBuf)
      {
         GlobalFreePtr(lpCache->devlpsWidths) ;
         lpCache->devlpsWidths = NULL ;
         lpCache->sizdevlpsWidths = 0 ;
         rc = PS_ALLOC_FAILED;

         goto EndinitDeviceWidths;
      }
   }

   FontExtra=(LPFONTEXTRA) BUMPFAR(lpFontInfo,lpFontInfo->dfDriverInfo);

   fVariablePitch = lpFontInfo->dfPitchAndFamily & 1 ;

   devlpdWidths = lpCache->devlpdWidths;
   devlpsWidths = lpCache->devlpsWidths;
   lpdWidthsFontExtra = FontExtra->lpdWidths;

   if(!fVariablePitch)
   {
      for( i = 0 ; i  < count ; i++ )
      {
         devlpdWidths[i] = FontExtra->psAvgWidth ;
         devlpsWidths[i] = lpFontInfo->dfAvgWidth ;
      }
      return rc;
   }

   dfFirstChar     = ((WORD)lpFontInfo->dfFirstChar) & 0x00ff;
   dfLastChar      = ((WORD)lpFontInfo->dfLastChar ) & 0x00ff;
   dfDefaultChar   = ((WORD)(lpFontInfo->dfDefaultChar + dfFirstChar)) & 0x00ff;


   if(!FontExtra->dwWidths)
      ScaleDevCharWidths(lppd, lpFontInfo) ;

   lpsWidths = (LPSHORT) BUMPFAR(lpFontInfo, FontExtra->dwWidths);

   //   FontExtra->lpdWidths[0]  starts with dfFirstChar !



   if ( IsDBCSCharSet(lpFontInfo->dfCharSet) )
   {
      LPSTR lpLeadByte = GetLeadByteVector(lpFontInfo->dfCharSet);

      for (i = 0 ; i < count ; i++ )
      {
         iCh = textstr[i] ;  // assume is NON glyph index.

         if (!(*(lpLeadByte+iCh)))
         {
             if ( ((WORD)iCh   < dfFirstChar   ) ||
                  ((WORD)iCh   > dfLastChar    )  )
             {
                // If char is out of range, use default, fix BUG 190724, 1-20-1997, PPeng
                lpCache->devlpdWidths[i] = lpdWidthsFontExtra[0] ; // USE THE first entry - usually "space"
                lpCache->devlpsWidths[i] = lpsWidths[0] ;
             }
             else
             {
                lpCache->devlpdWidths[i] = lpdWidthsFontExtra[iCh - dfFirstChar] ;
                lpCache->devlpsWidths[i] = lpsWidths[iCh - dfFirstChar] ; //ANG
             }
         }
         else
         {
            devlpdWidths[i] = devlpdWidths[i+1] = FontExtra->psAvgWidth;
            devlpsWidths[i] = devlpsWidths[i+1] = lpFontInfo->dfAvgWidth ;
            i++;

         }
      }
   }
   else
   for( i = 0 ; i  < count ; i++ )
   {
      iCh = textstr[i] ;  // assume is NON glyph index.

      if ( ((WORD)iCh   < dfFirstChar   ) ||
            ((WORD)iCh   > dfLastChar    )   )
      {
         devlpdWidths[i] = lpdWidthsFontExtra[0] ;  // USE THE first entry - usually "space"
         devlpsWidths[i] = lpsWidths[0] ;
      }
      else
      {
         devlpdWidths[i] = lpdWidthsFontExtra[iCh - dfFirstChar] ;
         devlpsWidths[i] = lpsWidths[iCh - dfFirstChar] ;
      }
   }
EndinitDeviceWidths:
    if (PS_ERROR(rc))
    {
        if (lpCache->devlpdWidths)
        {
            GlobalFreePtr(lpCache->devlpdWidths);
            lpCache->devlpdWidths = NULL;
        }
        if (lpCache->devlpsWidths)
        {
            GlobalFreePtr(lpCache->devlpsWidths);
            lpCache->devlpsWidths = NULL;
        }
    }
    return rc;
}


