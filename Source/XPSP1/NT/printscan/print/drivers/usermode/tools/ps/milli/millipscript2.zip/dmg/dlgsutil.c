/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DLGSUTIL.C                                                   */
/*                                                                           */
/* Description: This module contains the dialog box helper functions         */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

// added 9/27 due to internal MS compiler error in retail build. b.d.
#pragma optimize("",off)

#pragma code_seg(_DIALOGSSEG)

//  We repeat some definitions from windows.h here as they are
//  not visible to our code due to mysteries of nested include files

/* Pen Styles */
#define PS_SOLID        0
#define PS_DASH         1
#define PS_DOT          2
#define PS_DASHDOT      3
#define PS_DASHDOTDOT   4
#define PS_NULL         5
#define PS_INSIDEFRAME  6

#define WHITE_PEN       6
#define BLACK_PEN       7
#define NULL_PEN        8

HPEN     WINAPI CreatePen(int, int, COLORREF);
HBRUSH   WINAPI CreateSolidBrush(COLORREF);
HGDIOBJ  WINAPI GetStockObject(int);
COLORREF WINAPI SetPixel(HDC, int, int, COLORREF);

#define LABEL_LENGTH     9

//---------------------------------------------------------------------------
// Constants & typedefs:
//---------------------------------------------------------------------------
#define  EOS     (0x00)
#define  BUF_SZ  1024

#define NUM_ERROR_CONTROLS  21

typedef struct 
{
   WORD   ctrlID;
   WORD   textID;
} ERROR_CTRL_MAP;

ERROR_CTRL_MAP DIALOGSSEG ErrorCtrlMap[NUM_ERROR_CONTROLS] = {
    ID_COPIES,          ID_TEXT_COPIES,       /* Paper Dialog box */       
    ID_LEFT_MARGIN,     ID_TEXT_LEFTMARGINE,  /* Unprintable Area dialog box */    
    ID_RIGHT_MARGIN,    ID_TEXT_RIGHTMARGINE,             
    ID_TOP_MARGIN,      ID_TEXT_TOPMARGINE,             
    ID_BOTTOM_MARGIN,   ID_TEXT_BOTTOMMARGINE,             
    ID_SCALE,           ID_SCALING_TEXT,             
    ID_FONTS_THRESHOLD, ID_TEXT_THRESHOLD,     /* SendFontAs dialog */       
    ID_PRINTER_VM,      ID_TEXT_PRINTER_VM,    /* Device features dialog box */
    ID_JOB_TIMEOUT,     ID_TEXT_JOBTIMEOUT,    /* Postscript dialog box */
    ID_WAIT_TIMEOUT,    ID_TEXT_WAITTIMEOUT,             
    ID_ADV_LEVEL,       ID_ADV_TEXT_LEVEL,     /* Advanced dialog */
    ID_WATERMARK_SIZE,  ID_TEXT_WM_SIZE,       /* Watermark edit/new dialog */
    ID_WATERMARK_ANGLE, ID_TEXT_WM_ANGLE,
    ID_WATERMARK_XPOS,  ID_TEXT_WM_XPOS,
    ID_WATERMARK_YPOS,  ID_TEXT_WM_YPOS,
    ID_WATERMARK_RED,   ID_TEXT_WM_RED,
    ID_WATERMARK_GREEN, ID_TEXT_WM_GREEN,
    ID_WATERMARK_BLUE,  ID_TEXT_WM_BLUE,
    ID_PRINTER_FONTCACHE, ID_TEXT_PRINTER_FONTCACHE,    /* Device option FontCache */
};

VOID NEAR PASCAL RemoveUnwantedChars(LPSTR lpStr);

typedef BOOL (WINAPI *LPGETOPENFILENAME)(OPENFILENAME FAR*);

extern HBITMAP WINAPI LoadBitmap(HINSTANCE, LPCSTR);
extern BOOL    WINAPI StretchBlt(HDC, int, int, int, int, HDC, int, int, int,
                                 int, DWORD);
extern BOOL    WINAPI BitBlt(HDC, int, int, int, int, HDC, int, int, DWORD);
extern int     WINAPI GetObject(HBITMAP, int, LPSTR);
extern HBITMAP WINAPI CreateCompatibleBitmap(HDC, int, int);

/***************************************************************************/
/*                   ExtractFileName                                       */
/*                                                                         */
/*  extract the filename from path                                         */
/*                                                                         */
/***************************************************************************/

LPSTR FAR PASCAL ExtractFileName( LPSTR lpszFileNameWithPath )
{  LPSTR lpszName = NULL;
   WORD len;
   
   if( lpszFileNameWithPath && *lpszFileNameWithPath )
   {  
      len = lstrlen( lpszFileNameWithPath );
      lpszName = lpszFileNameWithPath + len - 1;
      while( lpszName >= lpszFileNameWithPath && *lpszName != '\\' )
         lpszName--;
      lpszName++;
   }
   return( lpszName );
}

/*****************************************************************************/
/*                 RemoveUnwantedChars                                       */
/* Purpose: Remove '&' and ':' from a string.                                */
/*                                                                           */
/* Returns: none                                                             */
/*****************************************************************************/
VOID NEAR PASCAL RemoveUnwantedChars(LPSTR lpStr)
{
   char  szTmp[256];
   LPSTR lpTmpPt = lpStr;
   int   i = 0;

   while(*lpTmpPt != '\0')
   {
      if(*lpTmpPt != '&' && *lpTmpPt != ':')
      {
         szTmp[i++] = *lpTmpPt;
      }
      lpTmpPt++;
   }
   szTmp[i] = '\0';
   lstrcpy(lpStr, szTmp);
}


/*****************************************************************************/
/*                 ShowErrorValueMessage                                     */
/* Purpose: Display an message box telling user that one of the values       */
/*          entered is incorrect. The message including the error field,     */
/*          minimum and maximum numbers.                                     */
/*                                                                           */
/* Returns: none                                                             */
/*****************************************************************************/
VOID FAR PASCAL ShowErrorValueMessage(HWND hDlg,   WORD ctrlID, 
                                      long minVal, long maxVal)
{
   WORD   textID;
   BOOL   bFound = FALSE;
   int    i;
   char   szText[256], szBuffer[256];

   // find the text of the error field
   for(i=0; i<NUM_ERROR_CONTROLS && !bFound; i++)
   {
      if(ErrorCtrlMap[i].ctrlID == ctrlID)
      {
         bFound = TRUE;
         textID = ErrorCtrlMap[i].textID;
      }
   }

   // Assemble the output string including text of the error field, 
   // max, and min values.
   LoadString(ghDriverMod, DLGS_VALUE_ERROR, szText, sizeof(szText));

   GetDlgItemText(hDlg, textID, szBuffer, sizeof(szBuffer));
   RemoveUnwantedChars(szBuffer);
   lstrcat(szText, szBuffer);
   lstrcat(szText, " \n");

   LoadString(ghDriverMod, DLGS_MINIMUM, szBuffer, sizeof(szBuffer));
   lstrcat(szText, szBuffer);
   _ltoa(minVal, szBuffer, 10);
   lstrcat(szText, szBuffer);
   lstrcat(szText, " \n");

   LoadString(ghDriverMod, DLGS_MAXIMUM, szBuffer, sizeof(szBuffer));
   lstrcat(szText, szBuffer);
   _ltoa(maxVal, szBuffer, 10);
   lstrcat(szText, szBuffer);
   MessageBox(GetParent(hDlg), szText, NULL, MB_ICONSTOP | MB_OK);

   /* Highlight bad control & beep. */
   SetFocus(GetDlgItem(hDlg, ctrlID));
   SendDlgItemMessage(hDlg, ctrlID, EM_SETSEL, 0, MAKELONG(0,-1));
   MessageBeep(0);
}


/***************************************************************************/
/* BOOL __export CALLBACK LoseSoftFontsProc
**
** Description:     Processes messages for the LoseSoftFontsProc.
**
**                  At WM_INITDIALOG, <lParam> contains the string that is
**                  to be used for the ID_LOSESOFTFONTS_TEXT string.
*/
BOOL __export CALLBACK
LoseSoftFontsProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    RECT            rc0, rc1;
    POINT           pt;

    switch (message)
    {
        case WM_INITDIALOG:
            SetDlgItemText(hDlg, ID_LOSESOFTFONTS_TEXT, (LPSTR)lParam);
            GetWindowRect(GetDesktopWindow(), &rc0);
            GetWindowRect(hDlg, &rc1);
            pt.x = rc0.left + (rc0.right - rc0.left)/2 - (rc1.right - rc1.left)/2;
            pt.y = rc0.top  + (rc0.bottom - rc0.top)/2 - (rc1.bottom - rc1.top)/2;

                                        /* center on screen and force to    */
                                        /* the top of the z-order           */
            SetWindowPos(hDlg, HWND_TOPMOST, pt.x, pt.y, 0, 0, SWP_NOSIZE);

            return (TRUE);

        case WM_COMMAND:
            switch(wParam) {
                case IDOK:
                    EndDialog(hDlg, TRUE);  /* Exits the dialog box        */
                    return (TRUE);
                default:
                    break;
            }
            break;
    }
    return (FALSE);                         /* Didn't process a message    */
}
/******************************************************************************/
/* void WarningLoseSoftfonts
**
** Description:     Brings up a modal dialog box to indicate that softfonts
**                  may be lost by changing the printer port.
**
**                  The reason that this is not a simple message box is that
**                  this function explicidly forces itself into the foreground.
**                  For some reason (a background thread?) a standard
**                  message box goes to the bottom of the z-order when
**                  called by DevInstall.
**
*/
void
WarningLoseSoftfonts(HWND hWndOwner, LPSTR lpszOldPort, LPSTR lpszNewPort)
{
    char    szFmt[256], szBuf[256];

                        /* "Fonts downloaded to this printer while          */
                        /* connected to %s may be lost. You may need to     */
                        /* resend them again on %s"                         */

    LoadString(ghDriverMod, IDS_SOFTFONTWARNING, szFmt, sizeof(szFmt));
    wsprintf(szBuf, szFmt, lpszOldPort, lpszNewPort);

    DialogBoxParam(ghDriverMod, MAKEINTRESOURCE(CH_LOSESOFTFONTS_DLG),
                                hWndOwner,
                                LoseSoftFontsProc,
                                (LPARAM)(LPSTR)szBuf);
}

/****************************************************************************
*
*                             PositionControls
*  function:
*       This function moves/removes the controls from wFirstID to wLastID
*       inclusive. If wFlags is NULL, the controls are removed and the x and y
*       offsets are updated. if wFlags is non-NULL, the controls are
*       moved up and to the left by the x and y offsets, respectively.
*
*  arguments:
*       hDlg - handle to dialog box window
*       lpxOffset - pointer to x offset
*       lpyOffset - pointer to y offset
*       dwFlags - if FALSE delete controls, else compact them.
*       wFirstID, wLastID - range of control IDs
*       wRefID - Last ID that was rearranged.
*
*  returns: None
****************************************************************************/

VOID NEAR PASCAL PositionControls(HWND  hDlg,
                                  LPINT lpxOffset,
                                  LPINT lpyOffset,
                                  DWORD dwFlags,
                                  WORD  wFirstID,
                                  WORD  wLastID,
                                  WORD  wRefID)
{
    int    yOffset=lpyOffset?*lpyOffset:0;
    int    xOffset=lpxOffset?*lpxOffset:0;
    WORD   wLoop;
    POINT  pt;
    RECT   rc, rcRef;

    if(dwFlags)
    {
        if(yOffset || xOffset)
        {
            for(wLoop=wFirstID;wLoop<=wLastID;wLoop++)
            {
                GetWindowRect(GetDlgItem(hDlg,wLoop),&rc);
                pt.x = rc.left;
                pt.y = rc.top;
                ScreenToClient(hDlg, (POINT FAR*)&pt);

                MoveWindow(GetDlgItem(hDlg,wLoop),
                           pt.x-xOffset,
                           pt.y-yOffset,
                           rc.right-rc.left,
                           rc.bottom-rc.top,
                           FALSE);
            }
        }
    }
    else
    {
        // Update the offset for the next pass
        if(wRefID)
        {
            GetWindowRect(GetDlgItem(hDlg,wRefID),&rcRef);
            GetWindowRect(GetDlgItem(hDlg,wFirstID),&rc);
            if(lpxOffset)
                *lpxOffset += (rcRef.left - rc.left);

            if(lpyOffset)
                *lpyOffset += (rcRef.top - rc.top);
        }

        // Now delete all of the windows in the list
        for(wLoop=wFirstID;wLoop<=wLastID;wLoop++)
        {   // do not destroy color UI in Win98. disable and hide it.
            if( !IsWin40() && wLoop >= ID_COLOR_GROUP && wLoop <= ID_COLOR_CHOOSE_METHOD )
            {
                HWND hwnd = GetDlgItem(hDlg,wLoop);
                EnableWindow(hwnd, FALSE);
                GetWindowRect(hwnd,&rc);
                pt.x = rc.left;
                pt.y = rc.top;
                ScreenToClient(hDlg, (POINT FAR*)&pt);
                MoveWindow(hwnd,
                           pt.x-xOffset,
                           pt.y-yOffset,
                           rc.right-rc.left,
                           rc.bottom-rc.top,
                           FALSE);
                ShowWindow(hwnd, SW_HIDE);           
            }
            else DestroyWindow(GetDlgItem(hDlg,wLoop));    
        }
    }
}


/*****************************************************************************/
/*                 FixedMulDiv                                               */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

#ifdef ADOBE_DRIVER
void FAR PASCAL FixedMulDiv(DWORD number, int mult, int div, int nDecimals,
                             LPINT quotient, LPINT remainder)
#else
void NEAR PASCAL FixedMulDiv(DWORD number, int mult, int div, int nDecimals,
                             LPINT quotient, LPINT remainder)
#endif
{
    unsigned long temp, factor = 10L;
    int  i;

    for (i=0; i<nDecimals; i++)
    {
        factor *= 10L;
    }

    temp = ((unsigned long)number * (unsigned long)mult * factor) / (unsigned long)div;
    temp += 5L;                 /* Add 5 to round off to nearest digit */

    *quotient = (int)(temp/factor);
    temp = temp - ((long)(*quotient) * factor);

    *remainder = (int)(temp / 10);
}


/*****************************************************************************/
/*                 DisplayFixedPointNumber                                   */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to a dialog box                                     */
/*   int iCtrlID -- Control ID for the edit text or static text              */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL DisplayFixedPointNumber(HWND hDlg, int iCtrlID, int whole,
                                         int part, LPSTR  lpDecimal,
                                         int iNumDecimals)
{
    char format[20], buffer[64];

    wsprintf((LPSTR)format, "%%d%%s%%0%d.%dd", iNumDecimals, iNumDecimals);
    wsprintf(buffer, format, whole, lpDecimal, part);
    SetDlgItemText(hDlg, iCtrlID, (LPSTR)buffer);
}

/*****************************************************************************/
/*                 SetDlgItemLong                                            */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to a dialog box                                     */
/*   int iCtrlID -- Control ID for the edit text or static text              */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/
void FAR PASCAL SetDlgItemLong(HWND hDlg, int iCtrlID, DWORD number, BOOL bBeep)
{
    char buffer[64];

    wsprintf(buffer, "%ld", number);
    SetDlgItemText(hDlg, iCtrlID, (LPSTR)buffer);
}

/*****************************************************************************/
/*                 GetDlgItemReal                                            */
/* Purpose:                                                                  */
/*   Retrieves the real value stored in the edit control "ictrl" as a DWORD. */
/*   Example, if 3.42 is stored, it returns 342 if nDecimals is 2, and 34 if */
/*   nDecimals is 1.                                                         */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   lpDrvInfo -- Pointer to DRIVERINFO structure                            */
/*   nDecimals -- Number of digits to consider after the decimalSeparator.   */
/*   decimalSeparator -- Usually "."                                         */
/*   lpbSucess -- Pointer to bool to return status.                          */
/*   bBeep     -- If TRUE, highlight control and beep on failure.            */
/*                                                                           */
/* Returns:                                                                  */
/*   The value in ictrl                                                      */
/*****************************************************************************/

#ifdef ADOBE_DRIVER
DWORD FAR PASCAL GetDlgItemReal(HWND hDlg, int ictrl, int nDecimals,
                                LPSTR decimalSeparator, LPBOOL lpbSuccess,
                                BOOL bBeep)
#else
DWORD NEAR PASCAL GetDlgItemReal(HWND hDlg, int ictrl, int nDecimals,
                                LPSTR decimalSeparator, LPBOOL lpbSuccess,
                                BOOL bBeep)
#endif
{
    LPSTR  ptr;
    DWORD  num = 1;
    WORD   imult = 1;
    int    i;
    char   buf[32], ch;

    *lpbSuccess = FALSE;

    for (i=0; i<nDecimals; i++)
    {
        imult *= 10;
    }

    if (!GetDlgItemText(hDlg, ictrl, ptr=buf, sizeof(buf)))
        goto EndGetDlgItemReal;

    for (num=0; ch=*ptr; ptr++)
    {
        if (ch >= '0' && ch <= '9')
        {
            num = (num * 10) + (WORD)(ch - '0');
        }
        else
            break;
    }

    num *= imult;

    if (ch == *decimalSeparator)
    {
        while ((imult = imult / 10) && (ch = *++ptr))
        {
            if (ch >= '0' && ch <= '9')
                num += (imult * (WORD)(ch - '0'));
            else
                break;
        }
    }

    while (ch >= '0' && ch <= '9')
        ch = *++ptr;

    if (!ch)
        *lpbSuccess=TRUE;

EndGetDlgItemReal:
    if (!*lpbSuccess && bBeep)
    {
        SetFocus(GetDlgItem(hDlg, ictrl));
        SendDlgItemMessage(hDlg, ictrl, EM_SETSEL,0,MAKELPARAM(0,-1));
        MessageBeep(0);
    }

    return num;
}


/*****************************************************************************/
/*                 RetrieveDialogValues                                      */
/* Purpose:                                                                  */
/*   Retrieves the real values from the edit boxes from ictrl to             */
/*   ictrl+nitems-1, converts them into points and puts them in the lpValue  */
/*   array.                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   lpValue   -- pointer to array of words to receive values.               */
/*   nitems    -- Number of elements in lpValue array.                       */
/*   ictrl     -- ID of the first control (edit box).                        */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE f successful, else FALSE.                                          */
/*****************************************************************************/

BOOL NEAR PASCAL RetrieveDialogValues(HWND hDlg, LPWORD lpValue, int nitems,
                                      int ictrl, BOOL bInches)
{
    long temp, factor = 10L;
    int  nDecimals, i;
    BOOL bOK;

    nDecimals = bInches ? 2 : 1;

    for (i=0; i<nDecimals; i++)
    {
        factor *= 10L;
    }

    if (! bInches)
    { // millimeters
        factor /= 10L;
        factor *= 254L;
    }

    for (i=0; i<nitems; i++)
    {
        temp = (long)GetDlgItemReal(hDlg, ictrl+i, nDecimals,
                                    decimalSeparator, &bOK, TRUE);
        if (!bOK)
            return FALSE;

        /* Round off factor is .007 inches or .18 mm */
        temp = temp*10L + (nDecimals == 2 ? 7 : 18);

        /* convert to points */
        lpValue[i] = (WORD) (temp * 72L / factor);
    }

    return TRUE;
}


/*****************************************************************************/
/*                 DoDisplayDialogValues                                     */
/* Purpose:                                                                  */
/*   Displays the real values in the edit controls from ictrl to             */
/*   ictrl+nitems-1. The values are given in lpValue.                        */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   lpValue   -- pointer to array of values.                                */
/*   nitems    -- Number of elements in lpValue array.                       */
/*   ictrl     -- ID of the first control (edit box).                        */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing                                                                 */
/*****************************************************************************/
void NEAR PASCAL DoDisplayDialogValues(HWND hDlg, LPWORD lpValue, int nitems,
                                       int ictrl, BOOL bInches)
{
    WORD x, y, whole, part;
    int  i, nDecimals;

    if (bInches)
    {
        x = 72;
        y = 1;
        nDecimals = 2;
    }
    else
    {
        x = 720;
        y = 254;
        nDecimals = 1;
    }

    for (i=0; i<nitems; i++)
    {
        FixedMulDiv(lpValue[i], y, x, nDecimals, &whole, &part);
        DisplayFixedPointNumber(hDlg, ictrl+i, whole, part,
                                decimalSeparator, nDecimals);
    }
}


/*****************************************************************************/
/*                 SetCurrentSpinPos                                         */
/* Purpose:                                                                  */
/*   Sets the current spin positions by reading the value from the edit      */
/*   control and setting the spin control.                                   */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   spinCtrl  -- ID of the first spin control.                              */
/*   editCtrl  -- ID of the first edit control.                              */
/*   nitems    -- Number of elements in lpValue array.                       */
/*   nDecimals -- Number of decimal places to retrieve the number from the   */
/*                edit box.                                                  */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing                                                                 */
/*****************************************************************************/

#ifdef ADOBE_DRIVER
void FAR PASCAL SetCurrentSpinPos(HWND hDlg, int spinCtrl, int editCtrl,
                                   int nitems, int nDecimals)
#else
void NEAR PASCAL SetCurrentSpinPos(HWND hDlg, int spinCtrl, int editCtrl,
                                   int nitems, int nDecimals)
#endif
{
    DWORD temp;
    int  i;
    BOOL bOK;

    for (i=0; i<nitems; i++)
    {
        temp = GetDlgItemReal(hDlg, editCtrl+i, nDecimals, decimalSeparator,
                              &bOK, FALSE);
        SendDlgItemMessage(hDlg, spinCtrl+i, UDM_SETPOS, NULL,
                           MAKELPARAM(temp, NULL));
    }

}


/*****************************************************************************/
/*                 HandleMetricChange                                        */
/* Purpose:                                                                  */
/*   Changes displayed values from mm to inches and vice-versa.              */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   lpValue   -- Array of words to hold values.                             */
/*   nitems    -- Number of elements in lpValue array.                       */
/*   spinCtrl  -- ID of the first spin control.                              */
/*   editCtrl  -- ID of the first edit control.                              */
/*   wParam    -- Whatever comes to the dialog handling function.            */
/*   fnSetRange - Pointer to a function that sets the spin range.            */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing                                                                 */
/*****************************************************************************/

void NEAR PASCAL HandleMetricChange(HWND hDlg, LPWORD lpValue, int nitems,
                                    int spinCtrl, int editCtrl, WORD wParam,
                                    SPINRANGEPROC fnSetRange,
                                    LPDRIVERINFO lpDrvInfo)
{
    if (RetrieveDialogValues(hDlg, lpValue, nitems, editCtrl,
                             wParam != ID_CP_INCHES))
    {
        CheckRadioButton(hDlg, ID_CP_INCHES, ID_CP_MILLIMETERS, wParam);
        (*fnSetRange)(hDlg, lpDrvInfo, wParam == ID_CP_INCHES);
        DoDisplayDialogValues(hDlg, lpValue, nitems, editCtrl,
                              wParam == ID_CP_INCHES);
        SetCurrentSpinPos(hDlg, spinCtrl, editCtrl, nitems,
                          wParam == ID_CP_INCHES ? 2 : 1);
    }
}


/*****************************************************************************/
/*                 HandleEditControlChange                                   */
/* Purpose:                                                                  */
/*   Call this function when the edit control of a spin's buddy is changed.  */
/*   This function retrieves the value, and sets the spin's range.           */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   spinCtrl  -- ID of the first spin control.                              */
/*   editCtrl  -- ID of the first edit control.                              */
/*   wParam    -- Whatever comes to the dialog handling function.            */
/*   bInches   -- TRUE if currently displaying in Inches                     */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing                                                                 */
/*****************************************************************************/

void NEAR PASCAL HandleEditControlChange(HWND hDlg, int spinCtrl, int editCtrl,
                                         WORD wParam, BOOL bInches)
{
    DWORD temp;
    BOOL bOK;

    temp = GetDlgItemReal(hDlg, wParam, bInches ? 2 : 1,
                          decimalSeparator, &bOK, FALSE);
    if (bOK)
    {
        SendDlgItemMessage(hDlg, wParam - editCtrl + spinCtrl, UDM_SETPOS, NULL,
                           MAKELPARAM(temp, NULL));
    }
}


/*****************************************************************************/
/*                 HandleSpinControlChange                                   */
/* Purpose:                                                                  */
/*  Call this function when the spin controls are hit. It displays the next  */
//* number in the associated edit control box.                               */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   spinCtrl  -- ID of the first spin control.                              */
/*   editCtrl  -- ID of the first edit control.                              */
/*   wID       -- ID of spin control that changed.                           */
/*   value     -- New value of spin control.                                 */
/*   bInches   -- TRUE if currently displaying in Inches                     */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing                                                                 */
/*****************************************************************************/

void NEAR PASCAL HandleSpinControlChange(HWND hDlg, int spinCtrl, int editCtrl,
                                         WORD wID, DWORD value, BOOL bInches)
{
    WORD x, dx, factor = 1;
    int  nDecimals, i;

    nDecimals = bInches ? 2 : 1;
    for (i=0; i<nDecimals; i++)
    {
        factor *= 10;
    }

    FixedMulDiv(value, 1, factor, nDecimals, &x, &dx);
    DisplayFixedPointNumber(hDlg, wID - spinCtrl + editCtrl, x, dx,
                            decimalSeparator, nDecimals);
}

#if 0

void NEAR PASCAL HandleMixedBinsUIC(LPDRIVERINFO lpDrvInfo)
{
    UICONFLICT    uiconflict;
    LPUICARRAY    lpArray;
    LPPRINTERINFO lpPrinterInfo;

    lpPrinterInfo =
        (LPPRINTERINFO)lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;

    lpArray = (LPUICARRAY)GlobalAllocPtr(GMEM_SHARE|GHND,
                              lpPrinterInfo->numMainKeyHdrs * sizeof(UICARRAY));
    if (!lpArray)
        goto EndMixedBins;

    uiconflict = lpDrvInfo->uiConflict;
    KeywordSetCurrentOption(&lpDrvInfo->pDev, IND_INPUTSLOTINFO,
                            GetInputSlotOptionIndex(&lpDrvInfo->pDev,
                                                    DMBIN_UPPER));
    if (intValidateOptionArray(lpDrvInfo->pDev.lpWPXblock,
                               lpDrvInfo->lpDM, lpArray,
                               &lpDrvInfo->uiConflict))
    {
        KeywordSetCurrentOption(&lpDrvInfo->pDev, IND_INPUTSLOTINFO,
                                GetInputSlotOptionIndex(&lpDrvInfo->pDev,
                                                        DMBIN_LOWER));

        if (intValidateOptionArray(lpDrvInfo->pDev.lpWPXblock,
                                   lpDrvInfo->lpDM, lpArray,
                                   &lpDrvInfo->uiConflict))
        {
            /* Restore original uiconflict */
            lpDrvInfo->uiConflict = uiconflict;
        }
    }

    /*
     * If one of the reasons for the conflict is the inputslot, make sure
     * current option is reported as MixedBins and not Upper or Lower.
     */
    if (lpDrvInfo->uiConflict.wMainConstrainer == IND_INPUTSLOTINFO)
        lpDrvInfo->uiConflict.wOptionConstrainer =
            lpPrinterInfo->devcaps.MixedBins;
    if (lpDrvInfo->uiConflict.wMainConstrained == IND_INPUTSLOTINFO)
        lpDrvInfo->uiConflict.wOptionConstrained =
            lpPrinterInfo->devcaps.MixedBins;

EndMixedBins:
    if (lpArray)
    {
        GlobalFreePtr(lpArray);
        KeywordSetCurrentOption(&lpDrvInfo->pDev, IND_INPUTSLOTINFO,
                                lpPrinterInfo->devcaps.MixedBins);
    }
}


#endif


/*****************************************************************************/
/*                 UICSetCurrentOption                                       */
/* Purpose:                                                                  */
/*    This function is called when the user changes the value of a keyword   */
/*    with UI constraints through the UI. It saves the previous value, sets  */
/*    the new value, and checks if the current set of values is constrained. */
/*    If not, it returns SCREENUPDATE_NONE and we are done. If a UIC         */
/*    is detected, it puts up the UIC dialog. If the user chooses OK, it sets*/
/*    all keywords to the values in the UIC table it showed, and returns     */
/*    SCREENUPDATE_ALL which means the entire dialog now has to be rebuilt & */
/*    redisplayed. If the user chose CANCEL, it sets the keyword to its old  */
/*    value and returns SCREENUPDATE_CURRENT, which means that the currently */
/*    displayed value for that keyword is not what it should be and needs to */
/*    be updated. If the user chose IGNORE, it returns                       */
/*    SCREENUPDATE_UICONSTRAINTS, which means that all keywords which can be */
/*    affected by UICs have to be rebuilt and redisplayed.                   */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/

WORD NEAR PASCAL UICSetCurrentOption(LPDRIVERINFO lpDrvInfo, WORD keyword,
                                     WORD option, HWND hDlg)
{
    LPPRINTERINFO lpPrinterInfo;
    WORD oldcustpaper, newcustpaper, oldoption, result = SCREENUPDATE_NONE;
    BOOL bConstrained, bBadOption = FALSE, bChange, bCustomPaper = FALSE;

    KeywordGetCurrentOption(&lpDrvInfo->pDev, keyword, &oldoption);

    if ((keyword == IND_PAPERINFO) && ((int)option < 0))
    {
        bCustomPaper = TRUE;
        lpPrinterInfo =
            (LPPRINTERINFO)lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;

        oldcustpaper = lpDrvInfo->pDev.lpPSExtDevmode->dm.currentCustPaper;
        newcustpaper = -(int)option - 1;
        option = lpPrinterInfo->devcaps.CustomPageSize;

        bChange = (oldoption != option) || (oldcustpaper != newcustpaper);
    }
    else
    {
        bChange = (oldoption != option);
    }

    if (bChange)
    {
        KeywordSetCurrentOption(&lpDrvInfo->pDev, keyword, option);

        if (keyword == IND_PAPERINFO)
        {
            if (bCustomPaper)
            {
                lpDrvInfo->pDev.lpPSExtDevmode->dm.currentCustPaper =
                    newcustpaper;
            }
            else
            {
                KeywordSetCurrentOption(&lpDrvInfo->pDev, IND_PAGEREGIONINFO,
                                        option);
            }
        }

        /* Check if current selection causes a UI constraint */
        bConstrained = ! intValidateOptionArray(lpDrvInfo->pDev.lpWPXblock,
                                                lpDrvInfo->lpDM,
                                                lpDrvInfo->lpUICArray,
                                                &lpDrvInfo->uiConflict);

        /*
         * No UI constraint, do not allow invalid states in future, ie. warn
         * user the next time UIC occurs.
         */
        if (!bConstrained)
        {
            if (lpDrvInfo->bAllowConstraint)
            {
//                lpDrvInfo->bAllowConstraint = FALSE;
                result = SCREENUPDATE_UICONSTRAINTS;
            }
            return result;
        }

        /*
         * Inform user about UIC if invalid states are not allowed. Invalid
         * states will be allowed if the user is already in an invalid state
         * because (s)he elected to not have the driver fix the UIC's.
         */
        if (!lpDrvInfo->bAllowConstraint)
        {
            LPPRINTERINFO lpPrinterInfo;
            int           rc;

            lpPrinterInfo =
                (LPPRINTERINFO)lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;

#if 0

support for MixedBins has been removed.

            /*
             * Check if current option is Mixed bins or if the constraints is
             * due to Mixed bins. This case is signalled by all fields of
             * uiConflict being set to -1. Has to be treated differently.
             */
            if (lpDrvInfo->uiConflict.wMainConstrainer == 0xffff)
            {
                HandleMixedBinsUIC(lpDrvInfo);
            }
#endif

            /*
             * Check to see if the currently chosen option is constrained
             * due to a keyword with a higher precedence, causing the fix to
             * change the current option. The best fix in this case is to
             * not accept the latest change.
             */
            if (lpDrvInfo->lpUICArray[keyword].wOldOption !=
                lpDrvInfo->lpUICArray[keyword].wNewOption)
            {
                int i;

                /*
                 * Force all other keywords to retain their options, so that
                 * ComplainAboutUIConstraints does not show them to the user.
                 */
                for (i=0; (WORD)i<lpPrinterInfo->numMainKeyHdrs; i++)
                {
                    if ((WORD)i != keyword)
                    {
                        lpDrvInfo->lpUICArray[i].wOldOption =
                            lpDrvInfo->lpUICArray[i].wNewOption;
                    }
                    else
                    {
                        lpDrvInfo->lpUICArray[i].wNewOption = oldoption;
                    }
                }
                bBadOption = TRUE;
            }

            lpDrvInfo->bShowIgnore = TRUE;
            lpDrvInfo->bShowCancel = TRUE;
            rc = DialogBoxParam(ghDriverMod, MAKEINTRESOURCE(CH_UICDIALOG),
                                hDlg, CHUICDlg, (LPARAM)lpDrvInfo);

            if (rc == IDOK && !bBadOption)
            {
                validateOptionArray(lpDrvInfo->pDev.lpWPXblock,
                                    lpDrvInfo->lpDM);
                result = SCREENUPDATE_ALL;
            }
            else if (rc == IDCANCEL || (rc == IDOK && bBadOption))
            {
                KeywordSetCurrentOption(&lpDrvInfo->pDev, keyword, oldoption);
                if (keyword == IND_PAPERINFO)
                {
                    if (bCustomPaper)
                    {
                        lpDrvInfo->pDev.lpPSExtDevmode->dm.currentCustPaper =
                            oldcustpaper;
                    }
                    else
                    {
                        KeywordSetCurrentOption(&lpDrvInfo->pDev,
                                                IND_PAGEREGIONINFO, oldoption);
                    }
                }

                result = SCREENUPDATE_CURRENT;
            }
            else
            {
                /*
                 * Allow UI-constraint to remain, and do not complain to
                 * the user in future till a non constrained state is reached.
                 */
                lpDrvInfo->bAllowConstraint = TRUE;
                result = SCREENUPDATE_UICONSTRAINTS;
            }
        }
        else
        {
            result = SCREENUPDATE_UICONSTRAINTS;
        }
    }
    return result;
}

#ifdef ADOBE_DRIVER
BOOL FAR PASCAL UICCheckAllOptions(LPDRIVERINFO lpDrvInfo,
                                    HWND hDlg,
                                    BOOL bRestoreDefaults,
                                    WORD wFlags)
#else
BOOL NEAR PASCAL UICCheckAllOptions(LPDRIVERINFO lpDrvInfo,
                                    HWND hDlg,
                                    BOOL bRestoreDefaults,
                                    WORD wFlags)
#endif
{

    LPPRINTERINFO lpPrinterInfo;
    BOOL          rc = TRUE;

    if (!intValidateOptionArray(lpDrvInfo->pDev.lpWPXblock, lpDrvInfo->lpDM,
                                lpDrvInfo->lpUICArray, &lpDrvInfo->uiConflict))
    {
        if (bRestoreDefaults && lpDrvInfo->bAllowConstraint)
            return rc;

        lpPrinterInfo =
            (LPPRINTERINFO)lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;

#if 0

support for MixedBins has been removed.

        /* Check if mixedbins is responsible for constraint */
        if (lpDrvInfo->uiConflict.wMainConstrainer == 0xffff)
        {
            HandleMixedBinsUIC(lpDrvInfo);
        }

#endif

        lpDrvInfo->bShowIgnore = bRestoreDefaults;
        lpDrvInfo->bShowCancel = ! bRestoreDefaults;
        rc = DialogBoxParam(ghDriverMod, MAKEINTRESOURCE(CH_UICDIALOG),
                            hDlg, CHUICDlg, (LPARAM)lpDrvInfo);

        if (rc == IDOK)
        {
            validateOptionArray(lpDrvInfo->pDev.lpWPXblock, lpDrvInfo->lpDM);
            if (bRestoreDefaults)
            {
                SendMessage(hDlg, WM_BUILD_DLG, wFlags, 0L);
                SendMessage(hDlg, WM_SHOW_DLG, wFlags, 0L);
                rc = TRUE;
            }
            lpDrvInfo->bAllowConstraint = FALSE; /* Unnecesary, but no harm */
        }
        else if (rc == IDIGNORE)
        {
            lpDrvInfo->bAllowConstraint = TRUE;
            rc = FALSE;
        }
        else
        {
            rc = FALSE;
        }
    }
    return rc;
}





void NEAR PASCAL TruncateToTabStop(HWND hDlg, LPSTR buffer, int iTabStop)
{
    TEXTMETRIC tm;
    HDC        hdc;
    int        width, nChars;

    hdc = GetWindowDC(hDlg);
    if ((width = LOWORD(GetTextExtent(hdc, buffer, lstrlen(buffer)))) >=
        2*iTabStop)
    {
        /* Truncate to fit and add trailing "..." */
        GetTextMetrics(hdc, &tm);
        nChars = (2*iTabStop - 4*tm.tmAveCharWidth) / tm.tmAveCharWidth;

        // fix "garbage"-on screen bug, 145843, 4-22-96. PPeng
        if ( nChars>=1){
            int   nCurr=0;
            // We HAVE to start from beginning!  Second Byte char may Also IsDBCSLeadByte!
            while(nCurr<nChars){
               if ( IsDBCSLeadByte(buffer[nCurr]) ) nCurr +=2;
               else nCurr +=1;
               }
            if (nCurr>nChars &&
                IsDBCSLeadByte(buffer[nChars-1])
               ){
               nChars--;   
               }
           }
        
        buffer[nChars] = '.';
        buffer[nChars + 1] = '.';
        buffer[nChars + 2] = '.';
        buffer[nChars + 3] = '\0';
    }
    ReleaseDC(hDlg, hdc);
}

void NEAR PASCAL ShowUIConstraint(HDC hDC, int x, int y, int id)
{
    BITMAP   bm;
    HBITMAP  hBitmap, hMask;
    POINT    ptOrg;
    HDC      hdcMem, hdcMask;

    /* Get the ui constraint bitmap */
    hBitmap = LoadBitmap(ghDriverMod, MAKEINTRESOURCE(id));
    hdcMem = CreateCompatibleDC(hDC);
    SelectObject(hdcMem, hBitmap);
    GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);

    /* Get the mask bitmap */
    hMask  = LoadBitmap(ghDriverMod, MAKEINTRESOURCE(id+1));
    hdcMask = CreateCompatibleDC(hDC);
    SelectObject(hdcMask, hMask);

    /* Calculate bitmap size and origin */
    ptOrg.x = ptOrg.y = 0;
    DPtoLP(hDC, &ptOrg, 1);

    /* Apply transparent blt */
    BitBlt(hDC, x, y, bm.bmWidth, bm.bmHeight,
           hdcMask, ptOrg.x, ptOrg.y, SRCAND);
    BitBlt(hDC, x, y, bm.bmWidth, bm.bmHeight,
           hdcMem, ptOrg.x, ptOrg.y, SRCPAINT);

    /* Cleanup */
    DeleteDC(hdcMem);
    DeleteObject(hBitmap);
    DeleteDC(hdcMask);
    DeleteObject(hMask);
}


/*****************************************************************************/
/*                 DrawPaperSize                                             */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void FAR PASCAL DrawPaperSize(LPDRIVERINFO lpDrvInfo,
                              LPSTR buffer,
                              LPDRAWITEMSTRUCT lpdi,
                              RECT FAR* lprcIcon,
                              WORD paperID,
                              int  iFontHt,
                              BOOL bCustomPaper)
{
    RECT       rc;
    HANDLE     hIcon;

    /* Set the background color */
    ExtTextOut(lpdi->hDC, lpdi->rcItem.left,
               lpdi->rcItem.bottom,
               ETO_OPAQUE | ETO_CLIPPED, &lpdi->rcItem, NULL, 0, NULL);

    /* Calculate rectangle in which text is to be written */
    rc.left = lpdi->rcItem.left;
    rc.right = lpdi->rcItem.right;
    rc.top = lpdi->rcItem.top + 5 + lprcIcon->bottom - lprcIcon->top;
    rc.bottom = rc.top + iFontHt*3/2;

    if (LOWORD(GetTextExtent(lpdi->hDC, buffer, lstrlen(buffer))) >=
        (WORD)(rc.right - rc.left))
    {
        short nTermIdx = LABEL_LENGTH;
        buffer[nTermIdx] = '\0'; /* Truncate to LABEL_LENGTH characters */

        if (LOWORD(GetTextExtent(lpdi->hDC, buffer, nTermIdx)) >=
            (WORD)(rc.right - rc.left))
        {
            nTermIdx--;
            buffer[nTermIdx] = '\0';
        }

        /*
         * Indicate string has more chars than it shown by adding '+' at the
         * end of the string. Check whether the last char is the 2nd byte of
         * a DBCS char. If so, set '+' at the one more char before the last
         * char.
         */
        if (IsDBCSLeadByte((BYTE)buffer[nTermIdx - 2]))
        {
            buffer[nTermIdx - 2] = '+';
            buffer[nTermIdx - 1] = '\0';
        }
        else
        {
            buffer[nTermIdx - 1] = '+';
        }
    }

    DrawText(lpdi->hDC, buffer, lstrlen(buffer), (RECT FAR*)&rc,
             DT_CENTER | DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER);

     if (paperID < DMPAPER_USER)
     {
        hIcon = lpDrvInfo->lpGetIconResource(PAPER_BASE + paperID);
     }
     else if (bCustomPaper)
     {
       // use one of the 15 custom paper sizes Adobe defined
       hIcon = LoadIcon(ghDriverMod, MAKEINTRESOURCE(PAPER_BASE + paperID));
    }
     else
     {
       // use Other paper icon (Microsoft defined) for all the undefined paper sizes
       hIcon = lpDrvInfo->lpGetIconResource(PAPER_OTHER);
    }

    DrawIcon(lpdi->hDC, lpdi->rcItem.left +
             (lprcIcon->right - lprcIcon->left)/2,
             lpdi->rcItem.top+5, hIcon);

    if((GetFocus() == lpdi->hwndItem) && (lpdi->itemState & ODS_SELECTED))
    {
       // draw a doted rectangle edge around the selected item indicating
       // the list box has the input focus.

       HPEN  hpen, hpenOld;

       hpen = CreatePen(PS_DOT, 1, RGB(0, 0, 0));
       hpenOld = SelectObject(lpdi->hDC,  hpen);

       MoveTo(lpdi->hDC, lpdi->rcItem.left,   lpdi->rcItem.top);
       LineTo(lpdi->hDC, lpdi->rcItem.right-1,lpdi->rcItem.top);
       LineTo(lpdi->hDC, lpdi->rcItem.right-1,lpdi->rcItem.bottom);
       LineTo(lpdi->hDC, lpdi->rcItem.left,   lpdi->rcItem.bottom);
       LineTo(lpdi->hDC, lpdi->rcItem.left,   lpdi->rcItem.top);

       SelectObject(lpdi->hDC, hpenOld);
       DeleteObject(hpen);
    }
}


void NEAR PASCAL HandleMCListBoxDrawItem(HWND hDlg,
                                         LPDRIVERINFO lpDrvInfo,
                                         int iCtrl,
                                         LPDRAWITEMSTRUCT lpdi,
                                         LPSTR buffer,
                                         int iFontHt)
{
    COLORREF      cfg, cbg;
    RECT          rcIcon;
    LPMAINKEYHDR  lpCurMainKeyHdr;
    LPPRINTERINFO lpPrinterInfo;
    LPPAPERINFO   lpPaperInfo;
    WORD          option = lpdi->itemID, paperID = 0;
    int           i;
    BOOL          bConstraint;
    BOOL          bCustomPaper;

    lpPrinterInfo = (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;
    lpPaperInfo = (LPPAPERINFO) MAKELONG(lpCurMainKeyHdr->extraOptionArray,
                                HIWORD(lpDrvInfo->pDev.lpWPXblock->WPXarrays));

    /*
     * If we are painting any of the custom papers, option should be set to
     * the custompaper option.
     */
    i = LOWORD(SendDlgItemMessage(hDlg, ID_SIZELIST, LB_GETITEMDATA,
                                  lpdi->itemID, 0));
    /* i< 0 => custom paper index + 1 in negative */
    if (i < 0)
    {
       paperID = GetCustomPaperID(lpDrvInfo, -(i + 1));
        option  = lpPrinterInfo->devcaps.CustomPageSize;
       bCustomPaper = TRUE;
    }
    else
     {
         paperID = lpPaperInfo[lpdi->itemID].paperID;
       bCustomPaper = FALSE;
     }

    GetWindowRect(GetDlgItem(hDlg, ID_ICON), (RECT FAR*)&rcIcon);

    /* Reverse colors if current item is selected */
    if (lpdi->itemState & ODS_SELECTED)
    {
        cfg = SetTextColor(lpdi->hDC, GetSysColor(COLOR_HIGHLIGHTTEXT));
        cbg = SetBkColor(lpdi->hDC, GetSysColor(COLOR_HIGHLIGHT));
    }

    /* Do the actual work */
    DrawPaperSize(lpDrvInfo, buffer, lpdi, &rcIcon, paperID, iFontHt, bCustomPaper);

    bConstraint = IsKeywordOptConstrained(&lpDrvInfo->pDev, IND_PAPERINFO,
                                          option);
    if (bConstraint)
    {
        ShowUIConstraint(lpdi->hDC, lpdi->rcItem.left +
                         (lpdi->rcItem.right - lpdi->rcItem.left -
                          (rcIcon.right - rcIcon.left))/2,
                         lpdi->rcItem.top + 5, LARGE_UIC_BMP);
    }

    /* Set colors back if we reversed them */
    if (lpdi->itemState & ODS_SELECTED)
    {
        SetTextColor(lpdi->hDC, cfg);
        SetBkColor(lpdi->hDC, cbg);
    }

    /* Set item data */
    SendDlgItemMessage(hDlg, ID_SIZELIST, LB_SETITEMDATA, lpdi->itemID,
                       (long)((DWORD)bConstraint<<16|(DWORD)((WORD)i)));
}


/*****************************************************************************/
/*                 GetCustomPaperID                                          */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: WORD                                                             */
/*****************************************************************************/

WORD NEAR PASCAL GetCustomPaperID(LPDRIVERINFO lpDrvInfo, int nIndex)
{
    // Choose one of the five different sized custom paper icons.

    WORD            paperID;
    WORD            wPaperSizeRange;
    LPPSEXTDEVMODE  lpPSExtDevmode;
    float           fWidth;
    float           fHeight;
    int             nIconKind;

    lpPSExtDevmode = lpDrvInfo->lpDM;

    fWidth  = lpPSExtDevmode->dm.custPaper[nIndex].customWidth;
    fHeight = lpPSExtDevmode->dm.custPaper[nIndex].customHeight;

    // We have five different sized paper icons for rectangles longer
    // in virtical and horizontal, and squares each.

    if (fHeight == fWidth)
    {
        nIconKind = 0;
    }
    else if (fHeight > fWidth)
    {
        nIconKind = 1;
    }
    else
    {
        nIconKind = 2;
        fHeight = fWidth;
    }

    wPaperSizeRange = (WORD)((int)(fHeight / 72.0));

    wPaperSizeRange = wPaperSizeRange / NUM_CUSTOM_PAPER_ICON + 1;

    if (wPaperSizeRange > NUM_CUSTOM_PAPER_ICON)
    {
        wPaperSizeRange = NUM_CUSTOM_PAPER_ICON;
    }

    paperID = DMPAPER_USER +
                nIconKind * NUM_CUSTOM_PAPER_ICON + wPaperSizeRange;

    return paperID;
}


/*****************************************************************************/
/*                 GetControlKeyword                                         */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

WORD NEAR PASCAL GetControlKeyword(LPDRIVERINFO lpDrvInfo, int iCtrl)
{
    LPPRINTERINFO lpPrinterInfo;
    WORD          keyword;

    lpPrinterInfo = (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);

    if (iCtrl == ID_SIZELIST)
        keyword = IND_PAPERINFO;
    else if (iCtrl == ID_SOURCELIST)
        keyword = IND_INPUTSLOTINFO;
    else if (iCtrl == ID_TYPELIST)
        keyword = IND_MEDIATYPEINFO;
    else if (iCtrl == ID_BINLIST)
        keyword = IND_OUTPUTBININFO;
    else if (iCtrl == ID_RESOLUTION_CB)
        keyword = IND_RESOLUTIONINFO;
    else if (iCtrl == ID_DUPLEXLIST)
        keyword = IND_DUPLEXINGINFO;
    else if (iCtrl == ID_COLLATE)
        keyword = IND_COLLATIONINFO;
    else if (iCtrl == ID_REVERSE_ORDER)
        keyword = IND_OUTPUTORDERINFO; 
#ifdef PROOFING        
    else if (iCtrl == ID_CM_PROFILE_CB )
        keyword = ID_CM_PROFILE_CB;    
#endif        
    else if (iCtrl == ID_ACTIVE_ITEM_VALUE)
    {
        keyword = lpPrinterInfo->DocSticky.w.offset +
            lpDrvInfo->iDocStickyIndex;
    }
    else if (iCtrl == ID_DEV_I_OPT_ACTIVE_ITEM_VALUE)
    {
        keyword = ((int)lpPrinterInfo->PrinterSticky.w.length ==
                   lpDrvInfo->iPrinterStickyIndex) ? IND_MEMORYINFO :
                   lpPrinterInfo->PrinterSticky.w.offset +
                   lpDrvInfo->iPrinterStickyIndex;
    }
    return keyword;
}


/*****************************************************************************/
/*                 HandleMeasureItem                                         */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL HandleMeasureItem(HWND hDlg,
                                   LPDRIVERINFO lpDrvInfo,
                                   int iCtrl,
                                   LPMEASUREITEMSTRUCT lpmi)
{
    NONCLIENTMETRICS ncm;
    TEXTMETRIC       tm;
    LOGFONT          lf;
    HFONT            hfont, hOldfont;
    HDC              hdc;


    if (lpmi->CtlType == ODT_COMBOBOX)
    {
        /*
         * The default font used for the combo boxes is the MessageFont of
         * the Nonclient area. Find the font name and size, create a logical
         * font, select it into the DC, and get its metrics.
         */
        ncm.cbSize = sizeof(NONCLIENTMETRICS);
        SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS),
                             (void FAR*)&ncm, 0);
        hdc = GetDC(hDlg);
        _fmemset(&lf, 0, sizeof(LOGFONT));
        lstrcpy(lf.lfFaceName, ncm.lfMessageFont.lfCommon.lfFaceName);
        lf.lfHeight = (short)ncm.lfMessageFont.lfHeight;
        hfont = CreateFontIndirect(&lf);
        hOldfont = SelectObject(hdc, hfont);
        GetTextMetrics(hdc, &tm);
        DeleteObject(SelectObject(hdc, hOldfont));
        ReleaseDC(hDlg, hdc);
        lpmi->itemHeight = tm.tmHeight + tm.tmExternalLeading;
    }
    else if (lpmi->CtlType == ODT_LISTBOX)
    {    /* Multi column list box */
        RECT rc;

        GetWindowRect(GetDlgItem(hDlg, ID_SIZELIST), &rc);
        lpmi->itemHeight = rc.bottom - rc.top;
    }
}


/*****************************************************************************/
/*                 HandleDrawItem                                            */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL HandleDrawItem(HWND hDlg,
                                LPDRIVERINFO lpDrvInfo,
                                int iCtrl,
                                LPDRAWITEMSTRUCT lpdi)
{
    TEXTMETRIC    tm;
    COLORREF      cfg, cbg;
    WORD          keyword;
    int           ht;
    char          buffer[256]; 
    LPSTR         lpszText = (LPSTR)buffer;

    if (!(lpdi->itemAction & (ODA_FOCUS | ODA_DRAWENTIRE | ODA_SELECT)) || (iCtrl < 0))
        return;

    GetTextMetrics(lpdi->hDC, &tm);
    ht = tm.tmHeight+tm.tmExternalLeading;

    /* Get associated keyword */
    keyword = GetControlKeyword(lpDrvInfo, iCtrl);

    /* Get string associated with item */
    SendDlgItemMessage(hDlg, iCtrl,
                       (iCtrl == ID_SIZELIST) ? LB_GETTEXT : CB_GETLBTEXT,
                       lpdi->itemID, (long)((LPSTR)buffer));

    if (keyword == IND_PAPERINFO)
    {
        HandleMCListBoxDrawItem(hDlg, lpDrvInfo, iCtrl, lpdi, buffer, ht);
        return;
    }

#ifdef PROOFING
    if( keyword == ID_CM_PROFILE_CB )
    {   LPSTR tmpStr = ExtractFileName( (LPSTR)buffer );
        if( tmpStr ) lpszText = tmpStr; 
    }
#endif

    /* Reverse colors if current item is selected */
    if (lpdi->itemState & ODS_SELECTED)
    {
        cfg = SetTextColor(lpdi->hDC, GetSysColor(COLOR_HIGHLIGHTTEXT));
        cbg = SetBkColor(lpdi->hDC, GetSysColor(COLOR_HIGHLIGHT));
    }

    ExtTextOut(lpdi->hDC, lpdi->rcItem.left + ht + 2, lpdi->rcItem.top,
               ETO_OPAQUE | ETO_CLIPPED, &lpdi->rcItem, lpszText,
               lstrlen(lpszText), NULL);

#ifdef PROOFING
    if (keyword != ID_CM_PROFILE_CB &&
           (IsKeywordOptConstrained(&lpDrvInfo->pDev, keyword, lpdi->itemID))
#else
    if (IsKeywordOptConstrained(&lpDrvInfo->pDev, keyword, lpdi->itemID))
#endif
    {
        ShowUIConstraint(lpdi->hDC, lpdi->rcItem.left, lpdi->rcItem.top,
                         SMALL_UIC_BMP);
    }


    /* Set colors back if we reversed them */
    if (lpdi->itemState & ODS_SELECTED)
    {
        SetTextColor(lpdi->hDC, cfg);
        SetBkColor(lpdi->hDC, cbg);
    }
}


/*****************************************************************************/
/*                 GetDecimalSeparator                                       */
/* Purpose:                                                                  */
/*   Gets the character selected by the control panel as the decimal point.  */
/*   Defaults to the normal decimal point "." if we can't find an entry.     */
/*                                                                           */
/* Parameters:                                                               */
/*   LPSTR lpDecimalSeparator -- Pointer to buffer to receive decimal        */
/*   int iMaxBuffLen -- Maximum size of buffer receiving decimal characters  */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

#ifdef ADOBE_DRIVER
void FAR PASCAL GetDecimalSeparator(LPSTR lpDecimalSeparator, int iMaxBuffLen)
#else
void NEAR PASCAL GetDecimalSeparator(LPSTR lpDecimalSeparator, int iMaxBuffLen)
#endif
{
    char section[16], entry[16];

    LoadString(ghDriverMod, IDS_INI_INTL, section, sizeof(section)) ;
    LoadString(ghDriverMod, IDS_INI_DECIMAL, entry, sizeof(entry)) ;
    GetProfileString(section, entry, ".", lpDecimalSeparator, iMaxBuffLen);
}


/*****************************************************************************/
/*                 GetMeasurementUnit                                        */
/* Purpose:                                                                  */
/*   Gets the unit system to be used from the control panel Win.ini entry    */
/*                                                                           */
/* Parameters:                                                               */
/*   BOOL bFlipped -- TRUE if we want the reverse, FALSE if we want normal   */
/*                                                                           */
/* Returns: int                                                              */
/*   ID_CP_INCHES, ID_CP_MILLIMETERS if units are Imperial units or SI units */
/*****************************************************************************/

int NEAR PASCAL GetMeasurementUnit(BOOL bFlipped)
{
    char section[16], entry[16];
    int iMeas;

    LoadString(ghDriverMod, IDS_INI_INTL, section, sizeof(section)) ;
    LoadString(ghDriverMod, IDS_INI_INT_MEASURE, entry, sizeof(entry)) ;
    iMeas = GetProfileInt(section, entry, 0);

    return ((bFlipped && (iMeas == 1)) || (! bFlipped && (iMeas != 1))) ?
            ID_CP_MILLIMETERS : ID_CP_INCHES;
}


/****************************************************************************
*
*                             BuildCBOptList
*  function:
*       This routine builds a combo box option list with PPD options for a
*       specified keyword.
*
*  arguments:
*       lpDrvInfo -- ptr to DRIVERINFO structure
*       hDlg - handle to dialog box window
*       keyword_index - index of keyword whose CB option list is to be built
*       ctrl_id - resource id for combo box
*
*  returns: None
*
****************************************************************************/
VOID NEAR DIALOGSSEG PASCAL BuildCBOptList(LPDRIVERINFO lpDrvInfo, HANDLE hDlg,
                                 WORD keyword_index, int ctrl_id)
{
    WORD  i, num_opts, curr_ctrl_opt_id ;
    int   imsg, imsg2;
    char trans[MAX_TR_STRING_LEN] ;

    SendDlgItemMessage(hDlg, ctrl_id, WM_SETREDRAW, FALSE, 0L) ;

    /* Special case: Paper Size is a list box */
    imsg = (ctrl_id == ID_SIZELIST) ? LB_RESETCONTENT : CB_RESETCONTENT;

    SendDlgItemMessage(hDlg, ctrl_id, imsg, 0, 0L) ;

    KeywordGetNumOfOptions(&lpDrvInfo->pDev, keyword_index, (LPWORD)&num_opts);

    imsg  = (ctrl_id == ID_SIZELIST) ? LB_ADDSTRING : CB_ADDSTRING;
    imsg2 = (ctrl_id == ID_SIZELIST) ? LB_SETITEMDATA : CB_SETITEMDATA;

    for (i = 0; i < num_opts; i++)
    {
        KeywordGetOptionTranslation(&lpDrvInfo->pDev, keyword_index, i,
                                    trans, sizeof(trans));
        curr_ctrl_opt_id = LOWORD(SendDlgItemMessage(hDlg, ctrl_id, imsg, 0,
                                                (DWORD) ((LPSTR) trans)));
        // Store PPD option index with combo list item.
        SendDlgItemMessage(hDlg, ctrl_id, imsg2, curr_ctrl_opt_id, i);
    }  // for (...)

    SendDlgItemMessage(hDlg, ctrl_id, WM_SETREDRAW, TRUE, 0L) ;
}  // BuildCBOptList


// Done - ShyamV
/****************************************************************************
*
*                            TruncateToFitControl
*  Purpose:
*
*  Parameters:
*       HWND  hDlg --
*       int   iCtrlID --
*       LPSTR lpSrc --
*       LPSTR lpDest --
*
*  Returns: none
*
****************************************************************************/
void FAR PASCAL TruncateToFitControl(HWND hDlg, int iCtrlID, LPSTR lpSrc, LPSTR lpDest)
{
   int   iLenStr, xext, xRunLen;
   HWND  hCtrl;
   RECT  ctrlRect;
   HDC   hDC;
   HFONT hFont;
   BOOL  done = FALSE;

   /* Start by copying stuff over */
   lstrcpy(lpDest, lpSrc);
   iLenStr = lstrlen(lpDest);

   /* Get the control xext */
   hCtrl = GetDlgItem(hDlg, iCtrlID);
   GetWindowRect(hCtrl, &ctrlRect);
   xext = ctrlRect.right - ctrlRect.left;

   /* Check the length in pixels */
   hFont = (HFONT)SendMessage(hCtrl, WM_GETFONT, 0, 0L);

   hDC = GetDC(hDlg);
   SelectObject(hDC, hFont);

   while (!done)
   {
      /* Add 4 since there's 2 for border and 2 for space to border */
      xRunLen = LOWORD(GetTextExtent(hDC, lpDest, iLenStr)) + 4;

      if (xRunLen >= xext)
      {  /* Trim one letter off */
         iLenStr--;
         if (*(lpDest + iLenStr) == '.')
         {  /* We are trimming off and elipse */
            *(lpDest + iLenStr) = '\0';
            if (iLenStr - 3 >= 0)
            {  /* Set another elipse */
               *(lpDest + iLenStr - 3) = '.';
            }
         }
         else
         {  /* We need to add an elpise */
            lstrcat(lpDest, "...");
            iLenStr = lstrlen(lpDest);
         }
      }
      else
      {
         done = TRUE;
      }
   }

   ReleaseDC(hDlg, hDC);

}  // END TruncateToFitControl


/*****************************************************************************
*
*                               DevInstall
*  Purpose:
*       THIS IS A NEW ENTRY POINT FOR WINDOWS 3.1
*       THAT IS CALLED BY THE WIN 3.1 CONTROL PANEL
*
*       The Win 3.1 Control Panel calls DevInstall()
*       whenever the user switches the port for a printer model
*       or installs a new printer
*
*  Parameters:
*       HANDLE hwnd -- parent windows handle
*       LPSTR  lszModelName -- Points to a zero terminated string
*                              specifying the name of the current
*                              printer model.
*       LPSTR  lszOldPort   -- Points to a zero terminated string
*                              specifying the name of the port being
*                              changed.  If lszOldPort is NULL,  a
*                              new printer is being installed.
*       LPSTR  lszNewPort   -- Points to a zero terminated string
*                              specifying the name of the port to be
*                              changed to.  If lszNewPort is NULL,  the
*                              printer is being removed.
*
*
*  Returns: WORD
*       1     => function succeeded
*       0     => Doesn't support this function
*      -1     => Failed
*
*****************************************************************************/
WORD _loadds FAR PASCAL DevInstall(HWND hWnd, LPSTR lpszModelName,
                                   LPSTR lpszOldPort, LPSTR   lpszNewPort )
{
   int  retVal = -1;
   BOOL bAddATM = FALSE;
#ifdef Adobe_Driver
   HANDLE hOemCust = NULL;
   LPWPXBLOCKS   lpWPXblock;
   LPPRINTERINFO lpPrinterInfo;
   LPSTR lpFileName;
   PDEVICE pDev;
#endif
   char   szWebPrinter[12]; 
   int   count;
    char   lptmpModelName[128];

   LoadString(ghDriverMod, IDS_WEBPRINTER, szWebPrinter, sizeof(szWebPrinter));

   count = lstrlen(szWebPrinter);

   lstrcpy(lptmpModelName, lpszModelName);

   if (lpszOldPort == NULL)
   {
      //--------------------------------------------------
      // New Printer being installed
      //--------------------------------------------------

      // This step must be done before CreateWPXFile  
      // need to move fonts in Win.ini  and
      // copy fonts in ATM.ini not already in registry.
      // ang 3/11/96
      SynIniFilesToRegistry(lpszNewPort, FALSE);

      // Create WPX MFD files
      if (CreateNewWPXFile(lpszModelName, TRUE))
      {
         // if WPX and/or Custom font cache exist in memory, set delete flag
         SetWPXDeleteFlag(lpszModelName);

         // Write out TT Substitutions if not already there
         InitializeTTSubsTable(ghDriverMod);

         bAddATM = TRUE;
         retVal = 1;

#ifdef Adobe_Driver
         /* Call for OEM Cust */
         lpWPXblock = GetPrinter(lpszModelName);
         pDev.lpWPXblock = lpWPXblock;
         lpPrinterInfo = (LPPRINTERINFO)(lpWPXblock->WPXprinterInfo);
         lpFileName = StringRefToLPBYTE(&pDev, lpPrinterInfo->PCFileName.dword);

         hOemCust = AdobeOEMInitDllStub(NULL,lpFileName,
                                        DLL_TYPE_OEM_CUST,DEVINSTALL);
         retVal = AdobeOEMDevInstallStub(hOemCust,hWnd,lpszModelName,
                       lpszOldPort,lpszNewPort);
         AdobeOEMTermDllStub(hOemCust);

         if (retVal == 1)
           { /* Call for PS FAX */
           hOemCust = AdobeOEMInitDllStub(NULL,NULL,
                                          DLL_TYPE_PS_FAX,DEVINSTALL);
           retVal = AdobeOEMDevInstallStub(hOemCust,hWnd,lpszModelName,
                         lpszOldPort,lpszNewPort);
           AdobeOEMTermDllStub(hOemCust);
           }
//#ifdef ADOBE_WEB
           // if lpszModelName match with "WEBPrinter".
           // make sure the size of lpszModeName is bigger than count
             if (lstrlen(lptmpModelName) >= count)
           {

              lptmpModelName[count] = '\0';
              if(lstrcmp(lptmpModelName, szWebPrinter) == 0)
              {
                 
                  hOemCust = AdobeOEMInitDllStub(NULL,NULL,
                                          DLL_TYPE_WEB_PRINTER,DEVINSTALL);
                 retVal = AdobeOEMDevInstallStub(hOemCust,hWnd,lpszModelName,
                         lpszOldPort,lpszNewPort);
                 AdobeOEMTermDllStub(hOemCust);
              }
              }
//#endif
#endif

      }
   }
   else
   {
      if (lpszNewPort == NULL)
      {
         //--------------------------------------------------
         // Existing printer is being deleted
         //--------------------------------------------------
         // Delete WPX and custom font MFD files
         CreateNewWPXFile(lpszModelName, FALSE);

         // if WPX and/or Custom font cache exist in memory, set delete flag
         SetWPXDeleteFlag(lpszModelName);

         retVal = 1;

#ifdef Adobe_Driver
         // YCT bug 9106
         if (retVal == 1)
         { /* Call for OEM Cust */
           lpWPXblock = GetPrinter(lpszModelName);
           pDev.lpWPXblock = lpWPXblock;
           lpPrinterInfo = (LPPRINTERINFO)(lpWPXblock->WPXprinterInfo);
           lpFileName = StringRefToLPBYTE(&pDev, lpPrinterInfo->PCFileName.dword);

           hOemCust = AdobeOEMInitDllStub(NULL, lpFileName, DLL_TYPE_OEM_CUST, DEVINSTALL);
           retVal = AdobeOEMDevInstallStub(hOemCust,hWnd,lpszModelName,
                         lpszOldPort,lpszNewPort);
           AdobeOEMTermDllStub(hOemCust);
         }
         /* Call for PS FAX */
         hOemCust = AdobeOEMInitDllStub(NULL, NULL, DLL_TYPE_PS_FAX, DEVINSTALL);
         retVal = AdobeOEMDevInstallStub(hOemCust,hWnd,lpszModelName,
                       lpszOldPort,lpszNewPort);
         AdobeOEMTermDllStub(hOemCust);

//#ifdef ADOBE_WEB
         // if lpszModelName match with "WEBPrinter".
         // make sure the size of lpszModeName is bigger than count
         if (lstrlen(lptmpModelName) >= count)
         {
             lptmpModelName[count] = '\0';
            if(lstrcmp(lptmpModelName, szWebPrinter) == 0)
            {
                    /* Call for Web Printer */
               hOemCust = AdobeOEMInitDllStub(NULL, NULL, DLL_TYPE_WEB_PRINTER, DEVINSTALL);
               retVal = AdobeOEMDevInstallStub(hOemCust,hWnd,lpszModelName,
                       lpszOldPort,lpszNewPort);
               AdobeOEMTermDllStub(hOemCust);
            }
         }
//#endif

#endif
      }
      else
      {
   
         //--------------------------------------------------
         // Existing printer is being Re-Assigned to different port
         //--------------------------------------------------

       WarningLoseSoftfonts(hWnd, lpszOldPort, lpszNewPort);

      // Need to move fonts in Win.ini and
      // ATM.ini not already in registry.
      // ang 3/11/96
      // No need to flush the Font Cache here as before.  
      // If new fonts are found the registry would of been updated.
      SynIniFilesToRegistry(lpszNewPort, FALSE);

         bAddATM = TRUE;
         retVal = 1;

#ifdef Adobe_Driver
         /* Call for OEM Cust */
         lpWPXblock = GetPrinter(lpszModelName);
         pDev.lpWPXblock = lpWPXblock;
         lpPrinterInfo = (LPPRINTERINFO)(lpWPXblock->WPXprinterInfo);
         lpFileName = StringRefToLPBYTE(&pDev, lpPrinterInfo->PCFileName.dword);

         hOemCust = AdobeOEMInitDllStub(NULL, lpFileName, DLL_TYPE_OEM_CUST, DEVINSTALL);
         retVal = AdobeOEMDevInstallStub(hOemCust,hWnd,lpszModelName,
                       lpszOldPort,lpszNewPort);
         AdobeOEMTermDllStub(hOemCust);

         if (retVal == 1)
           { /* Call for PS FAX */
           hOemCust = AdobeOEMInitDllStub(NULL, NULL, DLL_TYPE_PS_FAX, DEVINSTALL);
           retVal = AdobeOEMDevInstallStub(hOemCust,hWnd,lpszModelName,
                         lpszOldPort,lpszNewPort);
           AdobeOEMTermDllStub(hOemCust);
           }

//#ifdef ADOBE_WEB
           // if lpszModelName match with "WEBPrinter", init WEB plugi
           // make sure the size of lpszModeName is bigger than count
             if (lstrlen(lptmpModelName) >= count)
           {
               lptmpModelName[count] = '\0';
              if(lstrcmp(lptmpModelName, szWebPrinter) == 0)
              {
                 hOemCust = AdobeOEMInitDllStub(NULL, NULL, DLL_TYPE_WEB_PRINTER, DEVINSTALL);
                 retVal = AdobeOEMDevInstallStub(hOemCust,hWnd,lpszModelName,
                         lpszOldPort,lpszNewPort);
                 AdobeOEMTermDllStub(hOemCust);
              }
           }
//#endif
#endif
      }
  }

   // Add ATM place holder if not already present
   if (bAddATM)
   {
       char szSection[BUF_SIZE];
       char szBuffer[BUF_SIZE];

       LoadString(ghDriverMod, IDS_POSTSCRIPT, szSection, BUF_SIZE);
       lstrcat((LPSTR) szSection, lpszNewPort);
       if (lpszNewPort[lstrlen(lpszNewPort) - 1] == ':')
           szSection[lstrlen(szSection) - 1] = '\0';

       if (GetProfileString((LPSTR) szSection, (LPSTR) "ATM", (LPSTR) "",
                            (LPSTR) szBuffer, BUF_SIZE) == 0)
       {
           WriteProfileString((LPSTR) szSection, (LPSTR) "ATM",
                              (LPSTR) "placeholder");
       }
   }


#ifdef ENUMERATOR
   if (IsEnumeratorPresent()) {
      Enum_InstallPrinter(lpszModelName, lpszOldPort, lpszNewPort);
      if (lpszOldPort == NULL) {
         LPWPXBLOCKS   lpWPXblock;
         LPPRINTERINFO lpPInfo;
         LPFONTLIST    lpFontList;

         lpWPXblock = GetPrinter(lpszModelName);
         lpPInfo = (LPPRINTERINFO) lpWPXblock->WPXprinterInfo;
         lpFontList = (LPFONTLIST) ARRREF_TO_PTR(lpWPXblock->WPXarrays,
                                                 lpPInfo->FontList);
         Enum_AddFonts(lpszModelName, lpszNewPort, lpFontList,
                       lpPInfo->FontList.w.length,
                       lpWPXblock->WPXstrings);
         FreePrinter(lpWPXblock);
      }
  }
#endif

   return(retVal);
}  // DevInstall

/*****************************************************************************/
/*                 ValidatePicture                                           */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/
void FAR PASCAL ValidatePicture(HWND hDlg, WORD idcPicture, BOOL validate)
{
   RECT rectp;
   
   GetWindowRect( GetDlgItem(hDlg, idcPicture), (LPRECT)&rectp);
   MapWindowPoints(NULL, hDlg, (POINT FAR*)&rectp, 2); 
   if( validate ) ValidateRect(hDlg,&rectp);
   else InvalidateRect(hDlg, &rectp, TRUE);
}

/*****************************************************************************/
/*                 DrawPicture                                               */
/* Purpose: Load and draw bitmaps                                            */
/*                                                                           */
/* Parameters:                                                               */
/*   hDlg - handle to dialog box window                                      */
/*   id - dialog item id                                                     */
/*   nBmp - bitmap resource id                                               */
/*   nMaskBmp - mask bitmap resource id                                      */
/*   mode - 0:normal; 1:center bitmap; 2:center bitmap horizontally          */
/*   xoffset - units to offset bitmap horizontally                           */
/*   yoffset - units to offset bitmap horizontally                           */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/
void FAR PASCAL DrawPicture( HWND hDlg, int id, int nBmp, int nMaskBmp, 
                             int mode, int xoffset, int yoffset )
{
    HDC     hdc, hdcBmpMemory, hdcMskMemory;
    HBITMAP hBmp, hBmpOld;
    HBITMAP hMsk, hMskOld;
    BITMAP  bm;
    RECT    rcChild, rcParent;
    int     x, y, destX, destY;

    hdc = GetDC(hDlg);
   
    hBmp = LoadBitmap(ghDriverMod, MAKEINTRESOURCE(nBmp));
    hdcBmpMemory = CreateCompatibleDC(hdc);
    hBmpOld = SelectObject(hdcBmpMemory, hBmp);

    if( nMaskBmp )
    {
        hMsk = LoadBitmap(ghDriverMod, MAKEINTRESOURCE(nMaskBmp));
        hdcMskMemory = CreateCompatibleDC(hdc);
        hMskOld = SelectObject(hdcMskMemory, hMsk);
    }
    GetObject(hBmp, sizeof(BITMAP), (LPSTR)&bm);
            
    GetWindowRect(hDlg, &rcParent);
    GetWindowRect(GetDlgItem(hDlg, id), &rcChild);

    x = rcChild.left-rcParent.left;
    y = rcChild.top-rcParent.top;
   
    if( (int)bm.bmWidth > rcChild.right - rcChild.left )
        destX = rcChild.right - rcChild.left;
    else
    {
        destX = bm.bmWidth;
        x += xoffset;
        if( mode == 1 || mode == 2 )
            x += ( rcChild.right - rcChild.left - bm.bmWidth ) >> 1;
    }    
    
    if( (int)bm.bmHeight > rcChild.bottom - rcChild.top )
        destY = rcChild.bottom - rcChild.top;
    else
    {
        destY = bm.bmHeight;
        y += yoffset;
        if( mode == 1 )
            y += ( rcChild.bottom - rcChild.top - bm.bmHeight ) >> 1;
    }    

    if( nMaskBmp) 
    {
        BitBlt(hdc, x, y, destX, destY, hdcMskMemory, 0, 0, SRCAND); 
        BitBlt(hdc, x, y, destX, destY, hdcBmpMemory, 0, 0, SRCPAINT);
    }
    else
        BitBlt(hdc, x, y, destX, destY, hdcBmpMemory, 0, 0, SRCCOPY);
                        
    SelectObject(hdcBmpMemory, hBmpOld);
    DeleteObject(hBmp);
    DeleteDC(hdcBmpMemory);
    if( nMaskBmp) 
    {
        SelectObject(hdcMskMemory, hMskOld);
        DeleteObject(hMsk);
        DeleteDC(hdcMskMemory);
    }
    ReleaseDC(hDlg, hdc);
}
 
/*****************************************************************************/
/*                 DrawPicture                                               */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/
/*
void FAR PASCAL DrawPicture( HWND hDlg, int id, int nBmp, int nMaskBmp )
{
   HDC     hdc, hdcBmpMemory, hdcMskMemory;
   HBITMAP hBmp, hBmpOld;
   HBITMAP hMsk, hMskOld;
   BITMAP  bm;
   RECT    rcChild, rcParent;
   int     x, y, destX, destY;
   int     divX = 20, divY = 4;

   hdc = GetDC(hDlg);
           
   hBmp = LoadBitmap(ghDriverMod, MAKEINTRESOURCE(nBmp));
   hdcBmpMemory = CreateCompatibleDC(hdc);
   hBmpOld = SelectObject(hdcBmpMemory, hBmp);

   hMsk = LoadBitmap(ghDriverMod, MAKEINTRESOURCE(nMaskBmp));
   hdcMskMemory = CreateCompatibleDC(hdc);
   hMskOld = SelectObject(hdcMskMemory, hMsk);

   GetObject(hBmp, sizeof(BITMAP), (LPSTR)&bm);
            
   GetWindowRect(hDlg, &rcParent);
   GetWindowRect(GetDlgItem(hDlg, id), &rcChild);

   if( nBmp == LOGO_BMP )
   {
       int dx = (rcChild.right - rcChild.left) / divX;
       int dy = (rcChild.bottom- rcChild.top)  / divY;
       x = rcChild.right-rcParent.left+dx;
       y = rcChild.top-rcParent.top+dy;
       destX = bm.bmWidth;
       destY = bm.bmHeight;
   }
   else
   {
       x = rcChild.left-rcParent.left;
       y = rcChild.top-rcParent.top;
       destX = (int)bm.bmWidth > rcChild.right - rcChild.left ?
               rcChild.right - rcChild.left : bm.bmWidth;
       destY = (int)bm.bmHeight > rcChild.bottom - rcChild.top ?
               rcChild.bottom - rcChild.top : bm.bmHeight;
   }
                     
   BitBlt(hdc, x, y, destX, destY, hdcMskMemory, 0, 0, SRCAND); 
   BitBlt(hdc, x, y, destX, destY, hdcBmpMemory, 0, 0, SRCPAINT);
                        
   SelectObject(hdcBmpMemory, hBmpOld);
   SelectObject(hdcMskMemory, hMskOld);
   DeleteObject(hBmp);
   DeleteObject(hMsk);
   DeleteDC(hdcBmpMemory);
   DeleteDC(hdcMskMemory);
   ReleaseDC(hDlg, hdc);
}
*/
/*****************************************************************************/
/*                 HandleDrawButton                                          */
/* Purpose:                                                                  */
/*   Handle drawing of owner draw buttons                                    */
/*                                                                           */
/* Parameters:                                                               */
/*   hDlg - handle to dialog box window                                      */
/*   lpdis -- Pointer to the draw item structure                             */
/*   state -- state of button to draw                                        */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void FAR PASCAL HandleDrawButton( HWND hDlg, LPDRAWITEMSTRUCT lpdis, BNSTATE state,
                                  int xoffset, int yoffset )
{
    HPEN hPen, hPenOld, hBrush, hBrushOld;
    RECT rc = lpdis->rcItem;
    int i;
                
    switch (state) 
    {
        case NOFOCUS:
            hBrush = CreateSolidBrush( GetSysColor( COLOR_BTNFACE ) );
            hBrushOld = SelectObject( lpdis->hDC, hBrush );
            hPenOld = SelectObject( lpdis->hDC, GetStockObject(NULL_PEN) );
            Rectangle( lpdis->hDC, rc.left, rc.top, rc.right, rc.bottom );

            SelectObject( lpdis->hDC, GetStockObject(WHITE_PEN) );
            MoveTo( lpdis->hDC, rc.left, rc.bottom );
            LineTo( lpdis->hDC, rc.left, rc.top );
            LineTo( lpdis->hDC, rc.right, rc.top );
            MoveTo( lpdis->hDC, rc.left+1, rc.bottom-1 );
            LineTo( lpdis->hDC, rc.left+1, rc.top+1 );
            LineTo( lpdis->hDC, rc.right-1, rc.top+1 );

            SelectObject( lpdis->hDC, GetStockObject(BLACK_PEN) );
            MoveTo( lpdis->hDC, rc.right-1, rc.top );
            LineTo( lpdis->hDC, rc.right-1, rc.bottom-1 );
            LineTo( lpdis->hDC, rc.left, rc.bottom-1 );

            hPen = CreatePen( PS_SOLID, 1, RGB(128,128,128) );
            SelectObject( lpdis->hDC, hPen );
            MoveTo( lpdis->hDC, rc.right-2, rc.top+1 );
            LineTo( lpdis->hDC, rc.right-2, rc.bottom-2 );
            LineTo( lpdis->hDC, rc.left+1, rc.bottom-2 );
            DeleteObject( hPen );
            SelectObject( lpdis->hDC, hPenOld );
                    
            DeleteObject( hBrush );
            SelectObject( lpdis->hDC, hBrushOld );

            DrawPicture( hDlg, ID_LOGO, LOGO_BMP, LOGO_MASK_BMP, 1, xoffset, yoffset );
            break;

        case FOCUS:
            hBrush = CreateSolidBrush( GetSysColor( COLOR_BTNFACE ) );
            hBrushOld = SelectObject( lpdis->hDC, hBrush );
            Rectangle( lpdis->hDC, rc.left, rc.top, rc.right, rc.bottom );
            MoveTo( lpdis->hDC, rc.right-1, rc.top+1 );
            LineTo( lpdis->hDC, rc.right-1, rc.bottom-1 );
            LineTo( lpdis->hDC, rc.left+1, rc.bottom-1 );

            hPenOld = SelectObject( lpdis->hDC, GetStockObject(WHITE_PEN) );
            MoveTo( lpdis->hDC, rc.left+1, rc.bottom-2 );
            LineTo( lpdis->hDC, rc.left+1, rc.top+1 );
            LineTo( lpdis->hDC, rc.right-1, rc.top+1 );
            MoveTo( lpdis->hDC, rc.left+2, rc.bottom-3 );
            LineTo( lpdis->hDC, rc.left+2, rc.top+2 );
            LineTo( lpdis->hDC, rc.right-2, rc.top+2 );
            DeleteObject( hPen );
                    
            hPen = CreatePen( PS_SOLID, 1, RGB(128,128,128) );
            SelectObject( lpdis->hDC, hPen );
            MoveTo( lpdis->hDC, rc.right-2, rc.top+2 );
            LineTo( lpdis->hDC, rc.right-2, rc.bottom-2 );
            LineTo( lpdis->hDC, rc.left+2, rc.bottom-2 );
            DeleteObject( hPen );
            SelectObject( lpdis->hDC, hPenOld );                     
                                         
            for( i=rc.left+6; i<=rc.right-6; i+=2 )
            {
                SetPixel( lpdis->hDC, i, rc.top+5, RGB(0,0,0) );
                SetPixel( lpdis->hDC, i, rc.bottom-5, RGB(0,0,0) );
            }                        
            for( i=rc.top+6; i<=rc.bottom-6; i+=2 )
            {
                SetPixel( lpdis->hDC, rc.left+5, i, RGB(0,0,0) );
                SetPixel( lpdis->hDC, rc.right-5, i, RGB(0,0,0) );
            }
                    
            DeleteObject( hBrush );
            SelectObject( lpdis->hDC, hBrushOld );
                        
            DrawPicture( hDlg, ID_LOGO, LOGO_BMP, LOGO_MASK_BMP, 1, xoffset, yoffset );
            break;

        case PUSHED: 
            hBrush = CreateSolidBrush( GetSysColor( COLOR_BTNFACE ) );
            hBrushOld = SelectObject( lpdis->hDC, hBrush );
            Rectangle( lpdis->hDC, rc.left, rc.top, rc.right, rc.bottom );

            hPen = CreatePen( PS_SOLID, 1, RGB(128,128,128) );
            hPenOld = SelectObject( lpdis->hDC, hPen );
            Rectangle( lpdis->hDC, rc.left+1, rc.top+1, rc.right-1, rc.bottom-1 );
            DeleteObject( hPen );
            SelectObject( lpdis->hDC, hPenOld );                     
            DeleteObject( hBrush );
            SelectObject( lpdis->hDC, hBrushOld );
                                         
            for( i=rc.left+6; i<=rc.right-6; i+=2 )
            {
                SetPixel( lpdis->hDC, i, rc.top+5, RGB(0,0,0) );
                SetPixel( lpdis->hDC, i, rc.bottom-5, RGB(0,0,0) );
            }                        
            for( i=rc.top+6; i<=rc.bottom-6; i+=2 )
            {
                SetPixel( lpdis->hDC, rc.left+5, i, RGB(0,0,0) );
                SetPixel( lpdis->hDC, rc.right-5, i, RGB(0,0,0) );
            }
                        
            DrawPicture( hDlg, ID_LOGO, LOGO_BMP, LOGO_MASK_BMP, 1, xoffset, yoffset );
            break;
    }
}

/****************************************************************************
 * EVERYTHING BELOW THIS IS DEAD CODE, COMMENTED OUT WITH THE FOLLOWING #if *
 ****************************************************************************/


#if 0 // Dead code

/*****************************************************************************
*
*                           CenterPopup
*  Purpose:
*       This routine centers the popup window in the screen or display
*       using the window handles provided.  The window is centered over
*       the parent if the parent window is valid.  Special provision
*       is made for the case when the popup would be centered outside
*       the screen - in this case it is positioned at the appropriate
*       border.
*
*  Parameters:
*    HWND hWnd -- window handle
*    HWND hParentWnd -- parent window handle
*
*  Returns: BOOL
*
*****************************************************************************/
BOOL FAR PASCAL CenterPopup( HWND hWnd, HWND hParentWnd )
{
   int   xPopup;
   int   yPopup;
   int   cxPopup;
   int   cyPopup;
   int   cxScreen;
   int   cyScreen;
   int   cxParent;
   int   cyParent;
   RECT  rcWindow;


   /* retrieve main display dimensions */
   cxScreen = GetSystemMetrics( SM_CXSCREEN );
   cyScreen = GetSystemMetrics( SM_CYSCREEN );

   /* retrieve popup rectangle  */
   GetWindowRect( hWnd, (LPRECT)&rcWindow );

   /* calculate popup extents */
   cxPopup = rcWindow.right - rcWindow.left;
   cyPopup = rcWindow.bottom - rcWindow.top;

   /* calculate bounding rectangle */
   if ( hParentWnd )
   {
      /* retrieve parent rectangle */
      GetWindowRect( hParentWnd, (LPRECT)&rcWindow );

      /* calculate parent extents */
      cxParent = rcWindow.right - rcWindow.left;
      cyParent = rcWindow.bottom - rcWindow.top;

      /* center within parent window */
      xPopup = rcWindow.left + ((cxParent - cxPopup)/2);
      yPopup = rcWindow.top + ((cyParent - cyPopup)/2);

      /* adjust popup x-location for screen size */
      if ( xPopup+cxPopup > cxScreen )
      {
         xPopup = cxScreen - cxPopup;
      }

      /* adjust popup y-location for screen size */
      if ( yPopup+cyPopup > cyScreen )
      {
         yPopup = cyScreen - cyPopup;
      }
   } /* End IF (hParentWnd) */
   else
   {
      /* center within entire screen */
      xPopup = (cxScreen - cxPopup) / 2;
      yPopup = (cyScreen - cyPopup) / 2;
   }                       /* End ELSE */

   /* move window to new location & display */

   MoveWindow( hWnd,
               ( xPopup > 0 ) ? xPopup : 0,
               ( yPopup > 0 ) ? yPopup : 0,
               cxPopup, cyPopup,
               TRUE );

   /* normal return */

   return( TRUE );

} // END CenterPopup


// Done - ShyamV
/****************************************************************************
*
*                            ReSizeComboBox
*  Purpose:
*
*  Parameters:
*       HWND hDlg --
*       int iCtrlID --
*
*  Returns: none
*
****************************************************************************/
void NEAR PASCAL ReSizeComboBox(HWND hDlg, int iCtrlID)
{
   int        iCharHeight;
   HDC        hDC;
   TEXTMETRIC tm;
   int        xext, yext, iNumItems;
   RECT       ctrlRect;
   POINT      ctrlPt;
   HWND       hCtrl;
   HFONT      hFont;

   hCtrl = GetDlgItem(hDlg, iCtrlID);

   ShowWindow(hCtrl, SW_HIDE);
   hFont = (HFONT)SendMessage(hCtrl, WM_GETFONT, 0, 0L);

   hDC = GetDC(hDlg);
   SelectObject(hDC, hFont);
   GetTextMetrics(hDC, &tm);
   ReleaseDC(hDlg, hDC);

   iCharHeight = tm.tmHeight;
   iNumItems = (int)SendDlgItemMessage(hDlg, iCtrlID, CB_GETCOUNT, 0, 0L);

   if (iNumItems > 6)
   {
      iNumItems = 6;
   }
   if (iNumItems < 1)
   {
      iNumItems = 1;
   }

   GetWindowRect(hCtrl, &ctrlRect);
   xext = ctrlRect.right - ctrlRect.left;
   yext = (int)(iCharHeight * (iNumItems + 1.75));
   ctrlPt.x = ctrlRect.left;
   ctrlPt.y = ctrlRect.top;
   ScreenToClient(hDlg, &ctrlPt);
   MoveWindow(hCtrl, ctrlPt.x, ctrlPt.y, xext, yext, TRUE);
   ShowWindow(hCtrl, SW_SHOWNA);

} // END ReSizeComboBox


// Done - ShyamV
/****************************************************************************
*
*                            IsDialectDLLPresent
*  Purpose:
*       This function retreives the name of the .DLL used to process tokens
*       for the output format indicated by the index.  If no .DLL is required
*       or if the .DLL is present, the function returns TRUE.  If the .DLL
*       is required but is not present, the function returns FALSE.
*
*  Parameters:
*       int dialect -- some int between DIALECT_FIRST and DIALECT_LAST
*
*  Returns: BOOL
*       TRUE => no .DLL is required or .DLL is required and present
*       FALSE => .DLL is required but is not present
*
****************************************************************************/
BOOL FAR PASCAL IsDialectDLLPresent(int dialect)
{
   BOOL   retval;
   char   dialectfname[PATHSIZE];
   HANDLE temphand;
   int    NumBytes;

   retval = TRUE;
   // see if the .DLL for the mystery format is present
   NumBytes = LoadString(ghDriverMod, (INI_DIALECTFILENAME_BASE + dialect),
                         dialectfname,PATHSIZE);

   if (NumBytes > 0)
   {
      // got a .DLL file name -- .DLL is required
      retval = FALSE;
      // try to load the DLL for the particular DIALECT
      if (LoadDrvrLibrary(dialectfname, &temphand) == RC_ok )
      {
         // free the DLL again
         if (temphand != NULL )
         {
            FreeDrvrLibrary(&temphand);
         }
         // required and found -- return TRUE
         retval = TRUE;
      }
   }
   return(retval);

} // END IsDialectDLLPresent


// not used for Chicago

// Done - ShyamV
/****************************************************************************
*
*                         KeyboardHookProc
*  Purpose:
*       Hook proceedure for catching the F1 help key (Windows 3.1)
*
*  Parameters:
*       int    code --
*       WPARAM wParam --
*       LPARAM lParam --
*
*  Returns: LRESULT
*
****************************************************************************/
LRESULT _loadds CALLBACK KeyboardHookProc(int code, WPARAM wParam, LPARAM lParam)
{
   LRESULT lResult;

   switch (wParam)
   {
      case VK_F1:
         if (lParam & 0x80000000L)
         {  /* Key Up */
/*            PostMessage(hWndDevMode, WM_ADOBE_HELP, 0, 0L); */
            PostMessage(GetActiveWindow(), WM_ADOBE_HELP, 0, 0L);
         }
      break;
   }

   lResult = CallNextHookEx(hSystemHook, code, wParam, lParam);

   return (lResult);

} // END KeyboardHookProc

// Done - ShyamV
/****************************************************************************
*
*                       Keyboard30HookProc
*  Purpose:
*       Hook proceedure for catching the F1 help key (Windows 3.0)
*
*  Parameters:
*       int    code --
*       WPARAM wParam --
*       LPARAM lParam --
*
*  Returns: int
*
****************************************************************************/
int _loadds FAR PASCAL Keyboard30HookProc(int code, WPARAM wParam, LPARAM lParam)
{
   LRESULT lResult;

   switch (wParam)
   {
      case VK_F1:
         if (lParam & 0x80000000L)
         { /* Key Up */
/*            PostMessage(hWndDevMode, WM_ADOBE_HELP, 0, 0L); */
            PostMessage(GetActiveWindow(), WM_ADOBE_HELP, 0, 0L);
         }
         break;
   }

   lResult = (LRESULT)DefHookProc(code, wParam, lParam, (FARPROC FAR *)&hSystemHook);

   return (LOWORD(lResult));

} // END Keyboard30HookProc


// Done - ShyamV
/****************************************************************************
*
*                            WriteProfileInt
*  Purpose:
*
*  Parameters:
*       LPSTR section --
*       LPSTR entry --
*       int   i --
*
*  Returns: none
*
****************************************************************************/
void WriteProfileInt(LPSTR section, LPSTR entry, int i)
{
   char strBuff[7];

   wsprintf(strBuff, "%d", i);
   WriteProfileString(section, entry, strBuff);

} // END WriteProfileInt


// No lpDrvState->zNickName in new Chicago driver - ShyamV
/****************************************************************************
*
*                            GetNextNickName
*  Purpose:
*
*  Parameters:
*       LPDRVSTATE lpTempDrvState --
*
*  Returns: none
*
****************************************************************************/
void GetNextNickName(LPDRVSTATE lpTempDrvState)
{
   int  i;
   char section[32], entry[16], strBuff[16];

   LoadString(ghDriverMod, IDS_NEXTNICK_SECTION, section,32);
   LoadString(ghDriverMod, IDS_NEXTNICK_ENTRY  , entry  ,16);
   LoadString(ghDriverMod, IDS_NEXTNICK_BASE   , strBuff,16);

   i = GetProfileInt(section, entry, 0);
   i++; /* increment to the next printer number */
   WriteProfileInt(section, entry, i);

   lstrcpy(lpTempDrvState->zNickName, strBuff);
   wsprintf(strBuff, "%d", i);
   lstrcat(lpTempDrvState->zNickName, strBuff);

} // END GetNextNickName


// Done - OEM DLL info. stored in WIN.INI since keywords cannot be synthesized
/****************************************************************************
*
*                               OemDllExists
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*
*  Returns: BOOL
*
****************************************************************************/
BOOL OemDllExists(LPPDEVICE lppd)
{
   BOOL retVal;

#if 0
   if (lppd == NULL)
   {
      return(FALSE);
   }
   retVal = GetCurrBinPPDVal(lppd, &(lppd->drvState.PPDList),ID_PPDSTR_KEY_OEMCUSTDLL);
#endif

   retVal = GetProfileInt("AdobeOEMCustomization", "OemDllExists", 0);

   return(retVal);
} // END OemDllExists


// Done - OEM DLL info. stored in WIN.INI since keywords cannot be synthesized
/****************************************************************************
*
*                            SetOemDllExists
*  Purpose:
*
*  Parameters:
*       HANDLE    hPrinter --
*       LPPDEVICE lppd --
*       BOOL      bExists --
*
*  Returns: none
*
****************************************************************************/
void SetOemDllExists(HANDLE hPrinter, LPPDEVICE lppd, BOOL bExists)
{
#if 0
   char KeyWord[32], Condition[16];
   if (hPrinter == NULL || lppd == NULL)
   {
      return;
   }

   LoadString(ghDriverMod, ID_PPDSTR_KEY_OEMCUSTDLL, KeyWord, 32);

   if (bExists)
   {
      LoadString(ghDriverMod, GLBL_szTrue, Condition, 16);
   }
   else
   {
      LoadString(ghDriverMod, GLBL_szFalse, Condition, 16);
   }
   Ps_PPDSetKeywordOption(hPrinter, KeyWord, Condition);
#endif //0

   WriteProfileInt("AdobeOEMCustomization", "OemDllExists", 1);

}  // END SetOemDllExists


// Done - OEM DLL info. stored in WIN.INI since keywords cannot be synthesized
/****************************************************************************
*
*                               OemHelpExists
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*
*  Returns: BOOL
*
****************************************************************************/
BOOL OemHelpExists(LPPDEVICE lppd)
{
   BOOL retVal;

#if 0
   if (lppd == NULL)
   {
      return(FALSE);
   }

   retVal = GetCurrBinPPDVal(lppd, &(lppd->drvState.PPDList),
                                       ID_PPDSTR_KEY_OEMHELPFILE);
#endif

   retVal = GetProfileInt("AdobeOEMCustomization", "OemHelpExists", 0);

   return(retVal);

} // END OemHelpExists


// Done - OEM DLL info. stored in WIN.INI since keywords cannot be synthesized
/****************************************************************************
*
*                         SetOemHelpExists
*  Purpose:
*
*  Parameters:
*       HANDLE    hPrinter --
*       LPPDEVICE lppd --
*       BOOL      bExists --
*
*  Returns: none
*
****************************************************************************/
void SetOemHelpExists(HANDLE hPrinter, LPPDEVICE lppd, BOOL bExists)
{
#if 0
   char KeyWord[32], Condition[16];

   if (hPrinter == NULL || lppd == NULL)
   {
      return;
   }

   LoadString(ghDriverMod, ID_PPDSTR_KEY_OEMHELPFILE, KeyWord, 32);

   if (bExists)
   {
      LoadString(ghDriverMod, GLBL_szTrue, Condition, 16);
   }
   else
   {
      LoadString(ghDriverMod, GLBL_szFalse, Condition, 16);
   }
   Ps_PPDSetKeywordOption(hPrinter, KeyWord, Condition);
#endif

   WriteProfileInt("AdobeOEMCustomization", "OemHelpExists", bExists);

} // END SetOemHelpExists


// Done - ShyamV
/****************************************************************************
*
*                         SetOEMHelpFileName
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*
*  Returns: none
*
****************************************************************************/
void SetOEMHelpFileName(LPPDEVICE lppd)
{
   if (OemHelpExists(lppd))
   {
      char fileBuff[MAX_FILE_NAME_SIZE];

      GetOemBaseName(lppd, fileBuff, MAX_FILE_NAME_SIZE);

      if (lstrlen(fileBuff) != 0)
      {  /* There is an OEM help file */
         lstrcpy(szHelpFile, fileBuff);
         LoadString(ghDriverMod, IDS_HLP_EXT, fileBuff, MAX_FILE_NAME_SIZE);
         lstrcat(szHelpFile, fileBuff);
      }
   }
} // END SetOEMHelpFileName


// Done - ShyamV
/****************************************************************************
*
*                            GetOemBaseName
*  Purpose:
*       Gets OEM base name with .PPD stripped off.
*
*  Parameters:
*       LPPDEVICE lppd --
*       LPSTR     lpBaseName --
*       int       BaseNameBufSize --
*
*  Returns: none
*
****************************************************************************/
void GetOemBaseName(LPPDEVICE lppd, LPSTR lpBaseName, int BaseNameBufSize)
{
   char   option[MAX_OPTION_LEN] ;

#if 0
   short  rc = RC_ok ;
   short  enum_rc ;
   HANDLE pihdl;
   char   keyword[MAX_KEYWORD_LEN] ;

   if (lppd == NULL)
   {
      *lpBaseName = '\0';
   }

   pihdl = Ps_EnumOpen((LPSTR)&(lppd->drvState.zNickName), 0);
   if (pihdl)
   {
      LoadString(ghDriverMod, ID_PPDSTR_KEY_PCFILENAME,keyword,sizeof(keyword));
      enum_rc = Ps_PPDGetKeywordOptionPS(pihdl, keyword, NULL,
                                         option, MAX_OPTION_LEN ) ;
      if (enum_rc == PS_RC_DATA_NOT_FOUND)
      {
         *lpBaseName = '\0';
      }
      else
      {
         int len;

         len = lstrlen(option);
         option[len-4] = '\0';
         lstrcpy(lpBaseName, option);
      }
      Ps_EnumClose(pihdl);
   }
   else
   {
      *lpBaseName = '\0';
   }
#endif   // 0
   // Need to get *PCFileName into WPX to use this function - ShyamV - 9/23/93

   LPPRINTERINFO lpPrinterInfo ;
   LPBYTE Translation;
   int len;

   lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo ;

   Translation = StringRefToLPBYTE(lppd, lpPrinterInfo->PCFileName.dword);
   lstrcpyn(option, Translation, (lpPrinterInfo->PCFileName.w.length+1));

   len = lstrlen(option);
   option[len-4] = '\0';
   lstrcpy(lpBaseName, option);

} // END GetOemBaseName

// Done - ShyamV
/****************************************************************************
*
*                       InitOEMExistanceFlags
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*
*  Returns: none
*
****************************************************************************/
void InitOEMExistanceFlags(LPPDEVICE lppd)
{
   BOOL       bExists;
   char       BaseName[MAX_FILE_NAME_SIZE], TestName[PATHSIZE], strBuff[MAX_FILE_NAME_SIZE];
   OFSTRUCT   ofs;
   HFILE      hFile;
   HANDLE     hPrinter;

#if 0
   LPDRVSTATE lpDrvState;

   lpDrvState = &lppd->drvState;
   hPrinter   = Ps_EnumOpen( lpDrvState->zNickName, 0 );
#endif

   GetOemBaseName(lppd, BaseName, MAX_FILE_NAME_SIZE);

   if (lstrlen(BaseName) != 0)
   {
      /* Test if DLL exists */
      GetDriverDirectory(TestName, PATHSIZE);
      lstrcat(TestName, "\\");
      lstrcat(TestName, BaseName);
      LoadString(ghDriverMod, IDS_DLL_EXT, strBuff, MAX_FILE_NAME_SIZE);
      lstrcat(TestName, strBuff);
      hFile = OpenFile(TestName, &ofs, OF_EXIST);

      if (hFile !=HFILE_ERROR)
      {
         bExists = TRUE;
         _lclose(hFile);
      }
      else
      {
         bExists = FALSE;
      }
      SetOemDllExists(hPrinter, lppd, bExists);

      /* Test if HLP exists */
      GetDriverDirectory(TestName, PATHSIZE);
      lstrcat(TestName, "\\");
      lstrcat(TestName, BaseName);
      LoadString(ghDriverMod, IDS_HLP_EXT, strBuff, MAX_FILE_NAME_SIZE);
      lstrcat(TestName, strBuff);
      hFile = OpenFile(TestName, &ofs, OF_EXIST);

      if (hFile !=HFILE_ERROR)
      {
         bExists = TRUE;
         _lclose(hFile);
      }
      else
      {
         bExists = FALSE;
      }
      SetOemHelpExists(hPrinter, lppd, bExists);
   }
   else
   {  /* PPD file didn't have PCFileName */
      SetOemDllExists (hPrinter, lppd, FALSE);
      SetOemHelpExists(hPrinter, lppd, FALSE);
   }

#if 0
   if (hPrinter!=0)
   {
      Ps_EnumClose( hPrinter );
   }
#endif

} // END InitOEMExistanceFlags


// Done - ShyamV
/****************************************************************************
*
*                            IsOemDLLKeyInPPB
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*
*  Returns: BOOL
*
****************************************************************************/
BOOL IsOemDLLKeyInPPB(LPPDEVICE lppd)
{
   BOOL          bExists = FALSE;
#if 0
   LPDRVSTATE    lpDrvState;
   HANDLE        hPrinter;
   unsigned char Keyword[MAX_KEYWORD_LEN];
   unsigned char Option[MAX_OPTION_LEN];
   unsigned char Condition[16];

   lpDrvState = &lppd->drvState;
   hPrinter   = Ps_EnumOpen( lpDrvState->zNickName, 0 );

   if (hPrinter == NULL || lppd == NULL)
   {
      return bExists;
   }

   LoadString(ghDriverMod, ID_PPDSTR_KEY_OEMCUSTDLL, Keyword, 32);
   Ps_PPDGetKeywordOption(hPrinter, Keyword, Option,MAX_OPTION_LEN,NULL,NULL);
   LoadString(ghDriverMod, GLBL_szTrue, Condition, 16);

   if (!lstrcmp (Option, Condition))
   {
      bExists = TRUE;
   }

   if (hPrinter!=0)
   {
      Ps_EnumClose( hPrinter );
   }
#endif   //0

   bExists = (BOOL)GetProfileInt("AdobeOEMCustomization", "OemDllExists", 0);
   return (bExists);

}  // END IsOemDLLKeyInPPB

// Done - ShyamV
/****************************************************************************
*
*                            CallOEMInstall
*  Purpose:
*
*  Parameters:
*       HWND      hWnd --
*       LPSTR     lpDevType --
*       LPSTR     lpOldPort --
*       LPSTR     lpNewPort --
*       LPPDEVICE lppd --
*
*  Returns: int
*
****************************************************************************/
int CallOEMInstall(  HWND hWnd, LPSTR lpDevType, LPSTR lpOldPort,
                     LPSTR lpNewPort, LPPDEVICE lppd)
{
   int retVal;

   if (IsOemDLLKeyInPPB(lppd))
   {                     // There is an OEM Dll
      HINSTANCE    hOemDll = NULL;
      LPOEMINSTALL lpOemFn = NULL;
      char    OemDllName[MAX_FILE_NAME_SIZE], fileBuff[MAX_FILE_NAME_SIZE];

      GetOemBaseName(lppd, OemDllName, MAX_FILE_NAME_SIZE);
      LoadString(ghDriverMod, IDS_DLL_EXT, fileBuff, MAX_FILE_NAME_SIZE);
      lstrcat(OemDllName, fileBuff);
      hOemDll = LoadLibrary(OemDllName);

      if ((UINT) hOemDll > 32)
      {
         /* Grab the Install proc if one exists */
         lpOemFn = (LPOEMINSTALL)GetProcAddress(hOemDll, "OEMInstall");
      }

      /* If didn't get the proc set to original proc */
      if (lpOemFn != NULL)
      {  /* Have an OEMInstall function */
         retVal = (*lpOemFn)(hWnd, lpDevType, lpOldPort, lpNewPort, lppd,
                             OEM_DLL_VERSION);
      }
      else
      {
         retVal = 1;
      }

      /* Free whatever was loaded */
      if ((UINT) hOemDll > 32)
      {
         FreeLibrary(hOemDll);
      }
   }
   else
   {
      retVal = 1;
   }

   return (retVal);

} // END CallOEMInstall

// Done - ShyamV
/****************************************************************************
*
*                            DrvModalDialogBox
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       LPPSEXTDEVMODE lpPSExtDevmode -- Driver State
*       HANDLE ghDriverMod -- Driver module instance handle
*       HWND      hDlg --
*       DLGPROC   fnDlg --
*       LPSTR     lpDlgName --
*       LPSTR     lpOemDlgName --
*       LPSTR     lpOemFnName --
*
*  Returns: int
*
****************************************************************************/
int DrvModalDialogBox(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode,
                     HANDLE ghDriverMod, HWND hDlg, DLGPROC fnDlg,
                     LPSTR lpDlgName, LPSTR lpOemDlgName, LPSTR lpOemFnName)
{
   int retVal;
   DRIVERINFOT drvInfo;

   drvInfo.pDev = *lppd;
   drvInfo.lpDM = lpPSExtDevmode;
   drvInfo.ghDriverMod = ghDriverMod;

   if (!OemDllExists(lppd))
   {
      retVal = DialogBoxParam(ghDriverMod, lpDlgName, hDlg, fnDlg, (DWORD)(LPDRIVERINFO)&drvInfo);
   }
   else
   {  // There is an OEM Dll
      HINSTANCE hOemDll = NULL;
      HRSRC     hResource = NULL;
      HGLOBAL   hResMem = NULL;
      DLGPROC   lpOemFn = NULL;
      char      OemDllName[MAX_FILE_NAME_SIZE], fileBuff[MAX_FILE_NAME_SIZE];

      GetOemBaseName(lppd, OemDllName, MAX_FILE_NAME_SIZE);
      LoadString(ghDriverMod, IDS_DLL_EXT, fileBuff, MAX_FILE_NAME_SIZE);
      lstrcat(OemDllName, fileBuff);
      hOemDll = LoadLibrary(OemDllName);

      if ((UINT) hOemDll > 32)
      {
         // Grab the template if one exists
         hResource = FindResource(hOemDll, lpOemDlgName, RT_DIALOG);
         if (hResource != NULL)
         {
            hResMem = LoadResource(hOemDll, hResource);
         }

         // Grab the dialog replacement proc if one exists
         lpOemFn = GetProcAddress(hOemDll, lpOemFnName);
      }

      // If didn't get the proc set to original proc
      if (lpOemFn == NULL)
      {
         lpOemFn = fnDlg;
      }

      if (hResMem != NULL)
      {  // Found the OEM template
         retVal = DialogBoxIndirectParam(ghDriverMod, hResMem, hDlg, lpOemFn,
                                          (DWORD)(LPDRIVERINFO)&drvInfo);
      }
      else
      {  // Failed to load template from OEM Dll
         retVal = DialogBoxParam(ghDriverMod, lpDlgName, hDlg, lpOemFn,
                                 (DWORD)(LPDRIVERINFO)&drvInfo);
      }

      // Free whatever was loaded
      if (hResMem != NULL)
      {
         FreeResource(hResMem);
      }

      if ((UINT) hOemDll > 32)
      {
         FreeLibrary(hOemDll);
      }
   }

   return (retVal);

} // DrvModalDialogBox

// Done - ShyamV
/****************************************************************************
*
*                            DrvProcessHookProc
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       HWND      hDlg --
*       unsigned  uMsg --
*       WORD      wParam --
*       LONG      lParam --
*       LPSTR     lpOemHookFnName --
*
*  Returns: BOOL
*       Return FALSE if message is untouched else return TRUE in which
*       case processing is complete and caller need not process
*
****************************************************************************/
BOOL DrvProcessHookProc(LPPDEVICE lppd, HWND hDlg, unsigned uMsg,
                        WORD wParam, LONG lParam, LPSTR lpOemHookFnName)
{
   BOOL retVal;

   if (!OemDllExists(lppd))
   {
      retVal = FALSE;
   }
   else
   {                    // There is an OEM Dll
      HINSTANCE hOemDll = NULL;
      LPOEMPROC lpOemHookFn = NULL;
      char      OemDllName[MAX_FILE_NAME_SIZE], fileBuff[MAX_FILE_NAME_SIZE];

      GetOemBaseName(lppd, OemDllName, MAX_FILE_NAME_SIZE);
      LoadString(ghDriverMod, IDS_DLL_EXT, fileBuff, MAX_FILE_NAME_SIZE);
      lstrcat(OemDllName, fileBuff);
      hOemDll = LoadLibrary(OemDllName);

      if ((UINT) hOemDll > 32)
      {
         // Grab the dialog hook proc if one exists
         lpOemHookFn = (LPOEMPROC)GetProcAddress(hOemDll, lpOemHookFnName);
      }

      if (lpOemHookFn == NULL)
      {  // No hook proc so nothing to process
         retVal = FALSE;
      }
      else
      {  // Execute the hook proc
         retVal = (*lpOemHookFn)(hDlg, uMsg, wParam, lParam);
      }

      if ((UINT) hOemDll > 32)
      {
         FreeLibrary(hOemDll);
      }
   }

   return (retVal);

} // DrvProcessHookProc

// Done - ShyamV
/****************************************************************************
*
*                           AbortDevmodeDlg
*  function:
*       This routine is called when we wish to abort the DevmodeDlg function.
*
*  arguments:
*       lppd - pdevice pointer
*       hDlg - handle to dialog box window
*       status - error code sent to EndDialog()
*
*  returns: None
*
****************************************************************************/
VOID FAR PASCAL AbortDevmodeDlg(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode,
                                LPPSEXTDEVMODE lpArgPSExtDevmode, HWND hDlg,
                                int status)
{

#if 0    // Chicago driver has no .zNickName concept.
   if (lstrcmpi((*lpDrvState).zNickName, (*lpArgDrvState).zNickName))
   {
      //Reassign original printer instance to port.
      Ps_AssignPrinterToPort(NULL, (*lpArgDrvState).zNickName,
                             (*lpArgDrvState).port.zName) ;
   }
   DrvStateDestroy(lppd, lpDrvState) ;
#endif

   EndDialog(hDlg, status) ;

}  // AbortDevmodeDlg


// Done - ShyamV
/*****************************************************************************
*
*                               IsWin31
*  function:
*
*       This function detects whether the driver is
*       is being run under Window v 3.1 or not
*
*  prototype:
*       BOOL  FAR IsWin31( void );
*
*  parameters:
*             none
*
*  returns:
*       TRUE  => If running under Win 3.1
*       FALSE => If running under Win 3.0
*
*****************************************************************************/
BOOL  FAR   IsWin31()
{
   DWORD        wVers;
   BOOL        bRc;

   /* Get the Windows version */
   wVers = GetVersion();

   /* Is it Win 30 or Win 31 */
   if (LOBYTE(wVers) > 0x03 || (LOBYTE(wVers) == 0x03 && HIBYTE(wVers) > 0x00))
   {
      /* Win 3.1 and above */
      bRc = TRUE;
   }
   else
   {
      /* Win 3.0 */
      bRc = FALSE;
   }

   return( bRc );

} // IsWin31

// Done - ShyamV
/*****************************************************************************
*
*                               IsWin40
*  function:
*
*       This function detects whether the driver is
*       is being run under Window v 4.0 or not
*
*  prototype:
*       BOOL  FAR IsWin40( void );
*
*  parameters:
*             none
*
*  returns:
*       TRUE  => If running under Win 4.0
*       FALSE => If running under Win 3.1 or Win 3.0
*
*****************************************************************************/
BOOL  FAR   IsWin40()
{
   DWORD        wVers;
   BOOL        bRc;

   /* Get the Windows version */
   wVers = GetVersion();

   if (LOBYTE(LOWORD(wVers)) >= 4)
   {
      bRc = TRUE;
   }
   else
   {
      bRc = FALSE;
   }

   return( bRc );

} // IsWin40


//-------------------------------DLGS2.C-----------------------

// Done - ShyamV
/*****************************************************************************
*
*                          SuppressOptionalFeature
*  function:
*     This function determines if the given keyword should be suppressed in
*     the Chicago Device features dialog box
*
*  parameters:
*
*  returns:
*       TRUE  => If successful
*       FALSE => If not
*
*****************************************************************************/
BOOL SuppressOptionalFeature(LPSTR lpTestKeyword)
{
  char keyword[MAX_KEYWORD_LEN];

  LoadString(ghDriverMod, ID_PPDSTR_KEY_DUPLEX, keyword, MAX_KEYWORD_LEN);
  if (lstrcmp(lpTestKeyword, keyword) == 0)
    return (TRUE);

  LoadString(ghDriverMod, ID_PPDSTR_KEY_MEDIATYPE, keyword, MAX_KEYWORD_LEN);
  if (lstrcmp(lpTestKeyword, keyword) == 0)
    return (TRUE);

  LoadString(ghDriverMod, ID_PPDSTR_KEY_OUTPUTBIN, keyword, MAX_KEYWORD_LEN);
  if (lstrcmp(lpTestKeyword, keyword) == 0)
    return (TRUE);

  LoadString(ghDriverMod, ID_PPDSTR_KEY_RESOLUTION, keyword, MAX_KEYWORD_LEN);
  if (lstrcmp(lpTestKeyword, keyword) == 0)
    return (TRUE);

  return (FALSE);
}

#endif // 0

