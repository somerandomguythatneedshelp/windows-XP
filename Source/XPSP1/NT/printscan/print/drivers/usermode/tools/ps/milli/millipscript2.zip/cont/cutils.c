/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: CUTILS.C                                                     */
/*                                                                           */
/* Description: This module contains the function for ...                    */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_UTILSSEG)

// Global variables used in recusive function- ONLY locally.,
typedef int  (FAR PASCAL *LPCOMPARE_FUNC)(LPVOID, LPVOID);
typedef int  (FAR PASCAL *LPCOMPARE_BY_INDEX_FUNC)(LPVOID, LPVOID, HPVOID);
HPVOID  NHQS_lpData;
WORD    NHQS_wSize;
LPCOMPARE_FUNC NHQS_Compare;
HPVOID  NHQS_hpFDirs;
LPCOMPARE_BY_INDEX_FUNC NHQS_CompareByIndex;
// Function used locally. It should never be called by anyone else.
void NEAR PASCAL NearHugeQsort(int start, int end);
void NEAR PASCAL NearHugeQsortByIndex(int start, int end);

#define FONTDIR_FACENAME(pFontDir)     ((LPSTR)(pFontDir)->szFontName)
#define FONTDIR_FAMILYNAME(pFontDir)   ((LPSTR)(pFontDir)->szFaceName)

/***************************************************************************
*                               CInitPen
*  Function:
*       ...
*  Prototype:
*       VOID FAR PASCAL CInitPen(LPPDEVICE lppd)
*  Parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*  Returns:
*       VOID
*
***************************************************************************/
VOID FAR PASCAL CInitPen(LPPDEVICE lppd)
{
   lppd->pen.bStyle= (BYTE) -1 ;
   lppd->pen.ptWidth.x=lppd->pen.ptWidth.y= -1;
   lppd->pen.bCap= (BYTE) -1;
   lppd->pen.bJoin= (BYTE)  -1;
   // Now we initialize the pen style to "default for GDI".
   // Later, on TRAN side, this stile will be changed to 1.
   // Changed  17-May-1993  -by-  [olegs]

   lppd->pen.sMiterLimit=PENMITER_default;
   lppd->pen.dFGColor=RGB_BLACK;

} // END CInitPen


/***************************************************************************
*                               CInitBrush
*  Function:
*       ...
*  Prototype:
*       VOID FAR PASCAL CInitBrush(LPPDEVICE lppd)
*  Parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*  Returns:
*       VOID
*
***************************************************************************/
VOID FAR PASCAL CInitBrush(LPPDEVICE lppd)
{
   //LATER: more complete initialization?

   lppd->brush.bStyle=BRUSHSTYLE_solid;
   lppd->brush.bHatch=(BYTE)BRUSHHATCH_none;
   lppd->brush.dFGColor=RGB_BLACK;
   lppd->brush.dBGColor=RGB_WHITE;

} // END CInitBrush



VOID FAR PASCAL FlopRect(LPPDEVICE lppd, LPRECT lpOldRect, LPRECT lpFloppedRect)
/**********************************************************************
*
*  function:
*       Effectively rotate a rectangle 90 degrees by swapping the
*       (top, bottom) coordinates with the (left, right) coordinates
*       taking X, Y resolution into account, if necessary.
*
*  parameters:
*       lppd       - ptr to the PDEVICE
*       lpOldRect - ptr to the rectangle before flopping
*       lpFloppedRect - ptr to the rectangle created by 'flopping' OldRect
*
*  returns: None
************************************************************************/
{
   RECT wrk_rect ;

   //Use wrk_rect in case lpOldRect == lpFloppedRect.

   if (lppd->DeviceRes.x_res == lppd->DeviceRes.y_res)
   {
     wrk_rect.top = (*lpOldRect).left ;
     wrk_rect.bottom = (*lpOldRect).right ;
     wrk_rect.left = (*lpOldRect).top ;
     wrk_rect.right = (*lpOldRect).bottom ;
   }
   else     // case of non-square resolution (e.g 800x400 in Compaq Pagemark
   {
     wrk_rect.top = MulDiv( (*lpOldRect).left, lppd->DeviceRes.y_res,
                                    lppd->DeviceRes.x_res) ;
     wrk_rect.bottom = MulDiv( (*lpOldRect).right, lppd->DeviceRes.y_res,
                                    lppd->DeviceRes.x_res) ;
     wrk_rect.left = MulDiv( (*lpOldRect).top, lppd->DeviceRes.x_res,
                                    lppd->DeviceRes.y_res);
     wrk_rect.right = MulDiv( (*lpOldRect).bottom, lppd->DeviceRes.x_res,
                                    lppd->DeviceRes.y_res);
   }

   (*lpFloppedRect) = wrk_rect ;
}

/*****************************************************************************
*                        NormalizeRect
*  function:
*       Normalizes the rectangle if it has inverted corners.
*       The algorithm is the following:
*           IF (top, left) < (right, bottom)
*               copy rect and return.
*           ELSE
*               IF ( top > bottom )
*                       top <=> bottom
*               IF ( left > right )
*                        left <=> right
*
*  prototype:
*       VOID FAR PASCAL NormalizeRect(LPRECT Dest,LPRECT Src)
*  paremeters:
*       LPRECT Dest -- the Destination rectangle
*       LPRECT Src  -- the Source rectangle
*  returns:
*       NONE
*****************************************************************************/
VOID FAR PASCAL NormalizeRect(LPRECT Dest,LPRECT Src)
{
   int    i;       // Use temp variable to avoid problems when Src == Dest

   i = Src->left ;
   if( i <= Src->right )
   {
      Dest->left      = i;
      Dest->right     = Src->right;
   }else
   {
      Dest->left      = Src->right;
      Dest->right     = i ;
   }

   i = Src->top ;
   if ( i <= Src->bottom )
   {
      Dest->top       = i;
      Dest->bottom    = Src->bottom;
   }else
   {
      Dest->top       = Src->bottom;
      Dest->bottom    = i ;
   }
}


/*****************************************************************************
*                        TransformCoord
*
*  function  : Determines the dimensions in Destination space of the
*              minimum rectangle discovered in ShapeSource() given
*              the original sizes of the source and destination rectangle.
*               In general: If original Src changed to Bit, then
*                               we change original Dst to New with
*                               all proportions intact.
*
*  prototype : void FAR PASCAL TransformCoord(New, Dst, Bit, Src)
*
*  paremeters: LPRECT New -- Pointer to the new destination rectangle
*              LPRECT Dst -- Pointer to the original destination rectangle
*              LPRECT Bit -- Pointer to the minimized source rectangle
*              LPRECT Src -- Pointer to the original source rectangle
*
*  returns:    none
*****************************************************************************/
void FAR PASCAL TransformCoord(LPRECT New,LPRECT Dst,LPRECT Bit,LPRECT Src)
{
// This routine performs the following coordinate transformations.
//
//
//     [ X ]     [ DestXE-SrcX/SrcXE    0       ] [ pixel ]   [ DestX ]
//     [   ]  =  [                              ] [       ] + [       ]
//     [ Y ]     [      0     DestYE-SrcY/SrcYE ] [  row  ]   [ DestY ]
//
  int DestX = Dst->left;
  int DestY = Dst->top;
  int  SrcX     = Src->left ;
  int  SrcY     = Src->top ;

   float   XRatio = ( Dst->right - Dst->left) /
            ((float) ( Src->right - Src->left )) ;  //  X Stretch   Ratio
   float   YRatio = ( Dst->bottom - Dst->top)/
            ((float) ( Src->bottom - Src->top )) ;   //  Y Stretch   Ratio

  New->left    = (int) ( ( Bit->left   -SrcX) * XRatio + DestX);
  New->top     = (int) ( ( Bit->top    -SrcY) * YRatio + DestY);
  New->right   = (int) ( ( Bit->right  -SrcX) * XRatio + DestX);
  New->bottom  = (int) ( ( Bit->bottom -SrcY) * YRatio + DestY);
}


/**********************************************************************
*                           DeviceToDefaultPS
*
*  function:
*   this function transforms one point in the device (apps)
*   coordinate system to the default Postscript coordinate system
*   (origin at lower left hand corner of page, units are 1/72 ").
*
*  parameters:
*   POINT in device coordinate system (GDI)
*  return:
*   POINT converted to PostScript coordinates
*
************************************************************************/
void FAR PASCAL DeviceToDefaultPS(LPPDEVICE lppd, LPPOINT lpPoint)
{
   int   dx, dy;
   LPPSMATRIX lpCTM;

   lpCTM = lppd->psmatrix;
   dx = lpPoint->x;
   dy = lpPoint->y;


   lpPoint->x = (int) (dx*lpCTM[0] +  dy*lpCTM[2] + lpCTM[4] );
   lpPoint->y = (int) (dx*lpCTM[1] +  dy*lpCTM[3] + lpCTM[5] );
}


int FAR PASCAL lstrcmpn(LPSTR lpStr1, LPSTR lpStr2, WORD cnt)
{
    /* Assume no NULL strings */
    while (*lpStr1 && *lpStr2 && --cnt) {
        if (*lpStr1 != *lpStr2)
          break;
        lpStr1++;
        lpStr2++;
    }

    return (int) (*lpStr1 - *lpStr2);
}



LPSTR FAR PASCAL lstrchr(LPSTR lpStr, int c)
{
    LPSTR lpPtr = lpStr + lstrlen(lpStr);

    while (lpStr <= lpPtr) {
        if (*lpStr == (char) c)
          break;
        lpStr++;
    }

    return (lpStr <= lpPtr) ? lpStr : NULL;
}


LPSTR FAR PASCAL lstrrchr(LPSTR lpStr, int c)
{

    LPSTR lpPtr = lpStr + lstrlen(lpStr);

    while (lpPtr >= lpStr) {
        if (*lpPtr == (char) c)
          break;
        lpPtr--;
    }

    return (lpPtr >= lpStr) ? lpPtr : NULL;
}


void NEAR PASCAL Exchange(LPVOID lpData, int i, int j, WORD wSize)
{
    if ( i != j) {
	MemCopy((LPSTR) buffer, ELEMENT(lpData, i, wSize), wSize);
	MemCopy(ELEMENT(lpData, i, wSize), ELEMENT(lpData, j, wSize), wSize);
	MemCopy(ELEMENT(lpData, j, wSize), (LPSTR) buffer, wSize);
    }
}


void FAR PASCAL Qsort(LPVOID lpData, int start, int end, WORD wSize,
		      int (FAR PASCAL *Compare)(LPVOID, LPVOID))
{
    int i, j;

    if (start < end) {
	i = start;
	j = end + 1;

	while (1) {
	    while (i < j) {
		i++;
		if (Compare(ELEMENT(lpData, i, wSize), ELEMENT(lpData, start, wSize)) >= 0)
		  break;
	    }

	    while(1) {
		j--;
		if (Compare(ELEMENT(lpData, j, wSize), ELEMENT(lpData, start, wSize)) <= 0)
		  break;
	    }

	    if (i < j)
	      Exchange(lpData, i, j, wSize);
	    else
	      break;
	}

	Exchange(lpData, start, j, wSize);
	Qsort(lpData, start, j-1, wSize, Compare);
	Qsort(lpData, j+1, end, wSize, Compare);
    }
}


int FAR PASCAL BSearch(LPVOID lpData, int start, int end, WORD wSize,
	     int (FAR PASCAL *Compare) (LPVOID, LPVOID), LPVOID compData)
{
    int   l, u, m;
    int   i = -1;
    int   value;
    BOOL  done;

    l = start;
    u = end;
    done = FALSE;

    while ((l <= u) && ! done) {
	m = (l + u) / 2;        /* Get index of middle record */
	value = Compare(compData, ELEMENT(lpData, m, wSize));
	if (value > 0)
	  l = m + 1;            /* Look in upper half */
	else if (value == 0) {
	    i = m;
	    done = TRUE;
	}
	else
	  u = m - 1;            /* Look in lower half */
    }

    return i;
}


int FAR PASCAL SubsCompare(LPVOID elem1, LPVOID elem2)
{
    return lstrcmp((LPSTR) ((LPFONTSUBSTABLE) elem1)->TTFontName,
		   (LPSTR) ((LPFONTSUBSTABLE) elem2)->TTFontName);
}



WORD NEAR PASCAL GetTTFontIndex(LPPDEVICE lppd, WORD indexLast,
                                LPSTR lpszBuffer)
{
    WORD i, index = indexLast;

    for (i=0; i<indexLast; i++)
    {
        if (lstrcmp(lpszBuffer,
                    (LPSTR) lppd->lpFontSubsTable[i].TTFontName) == 0)
        {
            index = i;
            break;
        }
    }
    return index;
}


PSERROR FAR PASCAL CreateFontSubsTable(LPPDEVICE lppd)
{
	int		nNumDefSubsFont;
   int		nNumSubsFont;
   LPSTR	   lpszBuf;
   char	   szSection[SHORT_BUFF_LEN];
	char	   szSubsFont[FONTNAMESIZE];
	DWORD	   dwAllocSize;
	LPVOID	lpvGlobalMemory;
	PSERROR	psError;
	WORD	   wIndex;
	WORD	   wIndexLast;
   int		i;

	// Get the number of the default substitution fonts in resource.
	nNumDefSubsFont = GetNumDefSubsFont();
	if (nNumDefSubsFont <= 0)
	{
		// There must be al least one TT/PS font pair.
		return PS_GENERIC_FAIL;
	}
	nNumDefSubsFont /= 2;

   // Get the number of the substituion fonts in win.ini.
   nNumSubsFont = 0;
	lpszBuf = buffer;

   LoadString(ghDriverMod, IDS_INI_SUBS_TITLE, szSection, sizeof szSection);
   i = GetProfileString(szSection, NULL, "", lpszBuf, BUF_SIZE);

   if (i > 0)
	{
		while (*lpszBuf != 0)
		{
	    	nNumSubsFont++;
	    	lpszBuf += lstrlen(lpszBuf) + 1;
		}
   }


   // Allocate memory for the substitution table.
	dwAllocSize = (nNumDefSubsFont + nNumSubsFont) * sizeof (FONTSUBSTABLE);

	lpvGlobalMemory = GlobalAllocPtr(GHND | GMEM_SHARE, dwAllocSize);

   if (lpvGlobalMemory == NULL)
   {
        return PS_ALLOC_FAILED;
   }

   // Fill in the default substitution font names
   psError = LoadDefSubsFont(lpvGlobalMemory, FONTNAMESIZE);

	if (psError != PS_SUCCESS)
	{
		GlobalFreePtr(lpvGlobalMemory);
		return psError;
	}

   //Overwrite with Win.ini entries
	lppd->lpFontSubsTable = (LPFONTSUBSTABLE)lpvGlobalMemory;

   lpszBuf = buffer; //pointer to font sub pairs in Win.ini
   wIndexLast = 0;

   for (i = 0; i < nNumSubsFont; i++)
	{
		GetProfileString(szSection,
							lpszBuf,
							"",
							szSubsFont,
							sizeof szSubsFont);

       wIndex = GetTTFontIndex(lppd, wIndexLast, lpszBuf);

       if (wIndex == wIndexLast) //found TT font in current default sub list
		 {
          //add new found to end of current default sub list.
          lstrcpy(lppd->lpFontSubsTable[wIndex].TTFontName, lpszBuf);
          wIndexLast++;
       }

       if (lstrcmp(szSubsFont, "0") == 0) 
		 {
           //this mean an entry like "Arial=0" in Win.ini
           // so we modify current sub list to no substitution for Arial
            szSubsFont[0] = '\0';
		 }

       //update the new PS name for current TTFont.
       lstrcpy(lppd->lpFontSubsTable[wIndex].PSFontName, szSubsFont);

       lpszBuf += lstrlen(lpszBuf) + 1;
    }//for

    
    Qsort((LPVOID)lppd->lpFontSubsTable,
			0,
			wIndexLast - 1,
			sizeof (FONTSUBSTABLE),
			SubsCompare);


    // Resize buffer - shouldn't fail as we are decreasing size
    GlobalReAllocPtr(lppd->lpFontSubsTable,
						wIndexLast * sizeof (FONTSUBSTABLE),
                     	GHND);

    lppd->wFontSubsEntries = wIndexLast;

    return PS_SUCCESS;
}

/****************************************************************************
*                       SearchFontDir
*  function:
*       Peforms binary search on given font directory for a font with the
*       specified face name. If multiple fonts are found with the same name
*       it returns the one at the minimum index.
*  WARING:  INCORRECT RESULT IF SEARCH BY FAMILY NAME. 
*  FONTDIRECTORY IS SORTED BY POSTSCRIPT FONT NAME. IN CASES WHERE FAMILY 
*  NAME DIFFER FROM POSTSCRIPT NAME, THIS FUNCTION WILL NOT FIND THE FAMILY
*  NAME IN QUESTION EVENTHOUGH IT IS IN THE FONTDIRECTORY LIST.  ANG--2/12/96
*  prototype:
*       LPFONTDIRECTORY SearchFontDir(LPFONTDIRECTORY, LPSTR, WORD)
*  parameters:
*       lpFontDir:    Pointer to the font directory.
*       lpszFaceName: Pointer to name string (should be non null)
*       wNumFonts:    Number of fonts in FontDir.
*       bFontName:    If TRUE, lpszFaceName is the font name, else it is
*                     the font family name.
*       hint:         If not FONT_NOHINT, it is the index of the font in
*                     lpFontDir. Of course it is only a hint, & could be wrong.
*  returns:
*       Pointer to FontDir if font found, else NULL
****************************************************************************/
LPFONTDIRECTORY FAR PASCAL SearchFontDir(LPFONTDIRECTORY lpFontDir,
                                         LPSTR lpszFaceName, WORD wNumFonts,
                                         BOOL bFontName, WORD hint,
                                         BOOL bCharSet, BYTE wCharSet)
{
    LPFONTDIRECTORY rc = NULL;
    HPFONTDIRECTORY hpHugeFontDir; // a HUGE pointer to do huge pointer +. 6-12-95
    HPFONTDIRECTORY hpTempFontDir; // a Tmp HUGE pointer to do huge pointer +.
    LPSTR lpszName, lpszName2 = NULL;
    int             l, u, m;
    int             i = -1;
    int             value;
    BOOL            done;


    //make sure this is not an empty list
    if ((hpHugeFontDir = (HPFONTDIRECTORY)lpFontDir) == NULL ||
        !wNumFonts)
      return rc;

    if (hint != FONT_NOHINT && hint < wNumFonts)
    {
        hpTempFontDir = hpHugeFontDir+hint;
        lpszName = bFontName ? FONTDIR_FACENAME(hpTempFontDir) :
          FONTDIR_FAMILYNAME(hpTempFontDir);
        if (lstrcmpi(lpszFaceName, lpszName) == 0 )
            return (hpTempFontDir);
    }

    l = 0;
    u = wNumFonts - 1;
    done = FALSE;

    while ((l <= u) && ! done)
    {
        m = (l + u) / 2;        /* Get index of middle record */
        hpTempFontDir = hpHugeFontDir+m;
        lpszName = bFontName ? FONTDIR_FACENAME(hpTempFontDir) :
          FONTDIR_FAMILYNAME(hpTempFontDir);
        value = lstrcmpi(lpszFaceName, lpszName);
        if (value > 0)
            l = m + 1;            /* Look in upper half */
        else if (value == 0)
        {  /* Found it!! */
           if (!bCharSet || (wCharSet == (hpTempFontDir->defTextMetric).tmCharSet))
           {
              i = m;
              done = TRUE;
              rc = hpTempFontDir;
           } 
           else if (wCharSet > (hpTempFontDir->defTextMetric).tmCharSet)
             l = m+1;
           else
             u = m - 1; //look in the lower half
        }
        else
            u = m - 1; /* Look in lower half */
    }

    /* Search backward for first font with this facename */
    /* if not searching for exact charset*/
    if (!bCharSet && i >= 0)
    {
        hpTempFontDir = hpHugeFontDir+i;
        lpszName2 = bFontName ? FONTDIR_FACENAME(hpTempFontDir) :
          FONTDIR_FAMILYNAME(hpTempFontDir);
        while (i > 0)
        {

            lpszName = lpszName2;
            hpTempFontDir = hpHugeFontDir+i-1;
            lpszName2 = bFontName ? FONTDIR_FACENAME(hpTempFontDir) :
                FONTDIR_FAMILYNAME(hpTempFontDir);
            if (lstrcmpi(lpszName, lpszName2) == 0)
                i--;
            else
                break;
        }

        /* Get record associated with index */
        hpTempFontDir = hpHugeFontDir + i;
        rc = hpTempFontDir;
    }

    return rc;
}


// Huge version of QSort() and Exchange()

void FAR PASCAL HugeExchange(HPVOID lpData, int i, int j, WORD wSize)
{
    if ( i != j) {
	MemCopy((LPSTR) buffer, HUGEELEMENT(lpData, i, wSize), wSize);
	MemCopy(HUGEELEMENT(lpData, i, wSize), HUGEELEMENT(lpData, j, wSize), wSize);
	MemCopy(HUGEELEMENT(lpData, j, wSize), (LPSTR) buffer, wSize);
    }
}


#if 0
This function overflows the stack if the driver is first initialized
from simple stupid apps - such as Win3.1's notepad. -- 6-13-95
void FAR PASCAL HugeQsort(HPVOID lpData, int start, int end, WORD wSize,
		      int (FAR PASCAL *Compare)(LPVOID, LPVOID))
{
    int i, j;

    if (start < end) {
	i = start;
	j = end + 1;

	while (1) {
	    while (i < j) {
		i++;
		if (Compare(HUGEELEMENT(lpData, i, wSize), HUGEELEMENT(lpData, start, wSize)) >= 0)
		  break;
	    }

	    while(1) {
		j--;
		if (Compare(HUGEELEMENT(lpData, j, wSize), HUGEELEMENT(lpData, start, wSize)) <= 0)
		  break;
	    }

	    if (i < j)
	      HugeExchange(lpData, i, j, wSize);
	    else
	      break;
	}

	HugeExchange(lpData, start, j, wSize);
	HugeQsort(lpData, start, j-1, wSize, Compare);
	HugeQsort(lpData, j+1, end, wSize, Compare);
    }
}
#endif


void FAR PASCAL HugeQsort(HPVOID lpData, int start, int end, WORD wSize,
		      int (FAR PASCAL *Compare)(LPVOID, LPVOID))
{
    // QSort() calls itself recursively. It creates stack overflow for some apps
    // such as Win3.1's notepad.exe. To overcome this problem, use global variables
    // to remember the passed-in parms and then call a Near function -NearHugeQsort().

    // Setup gloabl vars used by NearHugeQsort().
    NHQS_lpData = lpData;
    NHQS_wSize  = wSize;
    NHQS_Compare= Compare;
    NearHugeQsort(start, end);
}

/*
remove by ang 08.30.96 see comment below.
void NEAR PASCAL NearHugeQsort(int start, int end)
{
    int i, j;

    if (start < end) {
	i = start;
	j = end + 1;

	while (1) {
	    while (i < j) {
		i++;
		if (NHQS_Compare(HUGEELEMENT(NHQS_lpData, i, NHQS_wSize),
                         HUGEELEMENT(NHQS_lpData, start, NHQS_wSize)) >= 0)
		  break;
	    }

	    while(1) {
		j--;
		if (NHQS_Compare(HUGEELEMENT(NHQS_lpData, j, NHQS_wSize),
                         HUGEELEMENT(NHQS_lpData, start, NHQS_wSize)) <= 0)
		  break;
	    }

	    if (i < j)
	      HugeExchange(NHQS_lpData, i, j, NHQS_wSize);
	    else
	      break;
	}

	HugeExchange(NHQS_lpData, start, j, NHQS_wSize);
	NearHugeQsort(start, j-1);
	NearHugeQsort(j+1, end);
    }
}
*/

/* This algorithm was taken from "Practical Algorithms for Programmers"
written by Andrew Binstock and John Rex.  1995
Basic Quick sort pages 194 to 196
*/
/* don't want to use this recursive sort if the list is too long
we can run out of stack space. ang 5/9/97*/
void NEAR PASCAL NearHugeQsort(int start, int end)
{
   int i, j;

   if (end > start) {
   	i = start-1;
	   j = end;

    	while (1) {

	      while ((i < end) && 
                (NHQS_Compare(HUGEELEMENT(NHQS_lpData, ++i, NHQS_wSize),
                   HUGEELEMENT(NHQS_lpData, end, NHQS_wSize))) < 0) {

	      }

	      while(j > 0) {
		      if (NHQS_Compare(HUGEELEMENT(NHQS_lpData, --j, NHQS_wSize),
                           HUGEELEMENT(NHQS_lpData, end, NHQS_wSize)) <= 0)
		      break;
	      }

	      if (i >= j )
         break;

	      HugeExchange(NHQS_lpData, i, j, NHQS_wSize);
	   } //outer while

	HugeExchange(NHQS_lpData, i, end, NHQS_wSize);
	NearHugeQsort(start, i-1);
	NearHugeQsort(i+1, end);
  }//if 

}
/* Insertion sort from "Algorithms in C" by Robert Sedgewick, pg 100 */
/*

  insertion(int a[], int N)
  {
     int i, j, v;
     for (i=2; i<=N; i++) //index from 1
     {
       v = a[i]; j =i;
       while ( a[j-1] > v)
           { a[j] = a[j-1]; j--; }
       a[j] =v;
     }
  }
*/

/*  
   N - Nth element of the list. we are assuming a 0 index list.
   wSize - size of each item that needs to be swapped.
*/
#if 0
If the record we have two swap is big, it take too much time for the memcopy.
This insertion can be up to 20 time slower than the recursive quicksort.
below is another version of insertion sort that can deal with large record better.
ang 5/16/97
BOOL FAR PASCAL HugeIsort(HPVOID lpData, int N, WORD wSize, 
            		      int (FAR PASCAL *Compare)(LPVOID, LPVOID))
{                                       
   int i, j;
   LPVOID lpTempBuf = NULL;


   if ( N <= 1) return (TRUE);

	if( (lpTempBuf = (LPSTR) GlobalAllocPtr(GHND, (DWORD) wSize)) == NULL)
   {
      return (FALSE);
   }

   // we have all we need to start sorting

   for (i = 1; i <= N; i++) //index from 0
   {
      MemCopy((LPSTR)lpTempBuf, HUGEELEMENT(lpData, i, wSize), wSize); 
      j = i;

      while((j > 0 )&& 
            (Compare(HUGEELEMENT(lpData, j-1 , wSize), lpTempBuf ) > 0 ))
      {
         MemCopy(HUGEELEMENT(lpData, j, wSize), HUGEELEMENT(lpData, j-1, wSize), wSize ); 
         j--;
      }

      //don't copy unless we need to
      if (i != j)
         MemCopy(HUGEELEMENT(lpData, j, wSize), (LPSTR)lpTempBuf, wSize); 
   }

   if (lpTempBuf)
      GlobalFreePtr(lpTempBuf);

   return (TRUE);
}
#endif

VOID NEAR PASCAL UncrambleSortList(HPVOID lpData, int N, WORD wSize, int *lpword)
{
   int i =0, j = 0, k = 0;
   LPVOID lpTempBuf = NULL;

	if( (lpTempBuf = (LPSTR) GlobalAllocPtr(GHND, (DWORD) wSize) ) == NULL)
   {
      return;
   }    

   for (i = 0; i <=N; i++)   {
      if (*(lpword+i) != i)
      {
         MemCopy((LPSTR)lpTempBuf, HUGEELEMENT(lpData, i, wSize), wSize); 
         k = i;

         do {

            j=k;
            MemCopy(HUGEELEMENT(lpData, j, wSize), HUGEELEMENT(lpData, *(lpword+j), wSize),wSize); 
            k = *(lpword+j);
            *(lpword+j) = j;

         } while(k !=i);
           
         MemCopy(HUGEELEMENT(lpData, j, wSize), (LPSTR)lpTempBuf, wSize); 
      }
   }

   if (lpTempBuf)
      GlobalFreePtr(lpTempBuf);

}

/* Insertion sort from "Algorithms in C" by Robert Sedgewick, pg 105-106 */
/* Sort using and index then unscrable it later.  This  algorithm minimize
** unecessary moving of large records.
*/
BOOL FAR PASCAL HugeIsort(HPVOID lpData, int N, WORD wSize, 
            		      int (FAR PASCAL *Compare)(LPVOID, LPVOID))
{                                       
   int i, j, v;
   int  *lpword;


   if ( N <= 1) return (TRUE);

  	if( (lpword = (int *) GlobalAllocPtr(GHND, (DWORD) (sizeof(int)*N+1))) == NULL)
   {
      return (FALSE);
   }

   for (i = 0; i <= N; i++) 
   {
      *(lpword+i) = i;
   }

   // we have all we need to start sorting

   for (i = 1; i <= N; i++) //index from 0
   {
      v = *(lpword+i);
      j = i;

      while((j > 0 )&& 
            (Compare(HUGEELEMENT(lpData, *(lpword+j-1) , wSize), HUGEELEMENT(lpData, v, wSize)) > 0 ))
      {
         *(lpword+j) = *(lpword+j-1);
         j--;
      }

      *(lpword+j) =v;

   }

   UncrambleSortList(lpData, N, wSize, lpword);

   if (lpword)
      GlobalFreePtr(lpword);

   return (TRUE);
}

/****************************************************************************
*                       SearchFontIndexDir
*  function:
*       Peforms binary search on given font index directory for a font with the 
*       specified face name. If multiple fonts are found with the same name
*       it returns the one at the minimum index.
*  prototype:
*      short int SearchFontIndexDir(LPDIRINDEXTABLE, LPSTR, WORD)
*  parameters:
*       lpFontDir:    Pointer to the font directory.
*       lpszFaceName: Pointer to name string (should be non null)
*       wNumFonts:    Number of fonts in FontDir.
*       bFontName:    If TRUE, lpszFaceName is the font name, else it is
*                     the font family name.
*       hint:         If not FONT_NOHINT, it is the index of the font in 
*                     lpFontDir. Of course it is only a hint, & could be wrong.
*  returns:
*		  returns an index to the index table if no value found return -1
****************************************************************************/
short int FAR PASCAL SearchFontIndexDir(LPFONTCACHE lpCache,
                                         LPSTR lpszFaceName, WORD wNumFonts, 
                                         BOOL bFontName, WORD hint)
{
    short int rc = -1;
    HPDIRINDEX hpTempDirIndex; // a HUGE pointer to do huge pointer.
    HPDIRINDEX hpDirIndex = (HPDIRINDEX) lpCache->hpDirIndex; 
										// a HUGE pointer to do huge pointer.
    HPFONTDIRECTORY *hpFontDirs = (HPFONTDIRECTORY FAR *) lpCache->hpFontDirs;
                     //pointer to an array of font dir pointers

    HPFONTDIRECTORY hpTempFontDir; // a Tmp HUGE pointer to do huge pointer +.
    LPSTR lpszName, lpszName2 = NULL;
    int             l, u, m;
    int             i = -1;
    int             value;
    BOOL            done;


    if (!lpCache || !wNumFonts)
      return rc;

    hpDirIndex = (HPDIRINDEX)lpCache->hpDirIndex;

    if ((hint != FONT_NOHINT) && (hint < wNumFonts))
    {
        hpTempDirIndex = hpDirIndex+hint;
        hpTempFontDir= INDEX_TO_DIR(hpTempDirIndex, hpFontDirs);
        if (hpTempFontDir != NULL)
        {
            lpszName = bFontName ? FONTDIR_FACENAME(hpTempFontDir) : 
               FONTDIR_FAMILYNAME(hpTempFontDir);
            if (lstrcmpi(lpszFaceName, lpszName) == 0)
               return (hint);
         }
    }
   /* We can only do a top down seach of PS font names. */
   /* The Index list is now sorted by family name */

   /* Find the first PS font name*/
   if (bFontName)
   {
      l = 0;
      for ( l = 0; (WORD)l < wNumFonts ; l++)
      {
         hpTempDirIndex = hpDirIndex+l;
         hpTempFontDir= INDEX_TO_DIR(hpTempDirIndex, hpFontDirs);
         lpszName = FONTDIR_FACENAME(hpTempFontDir) ;
         if (lstrcmpi(lpszFaceName, lpszName) == 0)
         {
            return ((short int)l);
         }
      }
      return (rc);
   }
 
/* search by Family Name*/    
    l = 0;
    u = wNumFonts - 1;
    done = FALSE;

    while ((l <= u) && ! done) 
    {
        m = (l + u) / 2;        /* Get index of middle record */
        hpTempDirIndex = hpDirIndex+m;
        hpTempFontDir= INDEX_TO_DIR(hpTempDirIndex, hpFontDirs);
        if (hpTempFontDir == NULL) 
           return(rc);
        lpszName = bFontName ? FONTDIR_FACENAME(hpTempFontDir) : 
          FONTDIR_FAMILYNAME(hpTempFontDir);
        value = lstrcmpi(lpszFaceName, lpszName);
        if (value > 0) 
            l = m + 1;            /* Look in upper half */
        else if (value == 0) 
        {  /* Found it!! */
            i = m;
            done = TRUE;
        }
        else
            u = m - 1;            /* Look in lower half */
    }

    /* Search backward for first font with this facename */
    if (i >= 0) 
    {
        hpTempDirIndex = hpDirIndex+i;
        hpTempFontDir=(HPFONTDIRECTORY) INDEX_TO_DIR(hpTempDirIndex, hpFontDirs);
        if (hpTempFontDir == NULL) 
           return(-1);
        lpszName2 = bFontName ? FONTDIR_FACENAME(hpTempFontDir) : 
          FONTDIR_FAMILYNAME(hpTempFontDir);
        while (i > 0) 
        {
            lpszName = lpszName2;
            hpTempDirIndex = hpDirIndex+i-1;
   	      hpTempFontDir=INDEX_TO_DIR(hpTempDirIndex, hpFontDirs);
        		lpszName2 = bFontName ? FONTDIR_FACENAME(hpTempFontDir) : 
          		FONTDIR_FAMILYNAME(hpTempFontDir);
            if (lstrcmpi(lpszName, lpszName2) == 0)
                i--;
            else
                break;
        }
        
        /* Get record associated with index */
       rc = i;
    }
    
    return rc;
}
void FAR PASCAL HugeQsortByIndex(HPVOID lpData, int start, int end, WORD wSize,
		      int (FAR PASCAL *Compare)(LPVOID, LPVOID, HPVOID), HPVOID hpFontDirs)
{
    // QSort() calls itself recursively. It creates stack overflow for some apps
    // such as Win3.1's notepad.exe. To overcome this problem, use global variables
    // to remember the passed-in parms and then call a Near function -NearHugeQsort().

    // Setup gloabl vars used by NearHugeQsortByIndex().
    NHQS_lpData = lpData;
    NHQS_wSize  = wSize;
    NHQS_CompareByIndex= Compare;
	 NHQS_hpFDirs = hpFontDirs;
    NearHugeQsortByIndex(start, end);
}
void NEAR PASCAL NearHugeQsortByIndex(int start, int end)
{
    int i, j;

    if (start < end) {
	i = start;
	j = end + 1;

	while (1) {
	    while (i < j) {
		i++;
		if (NHQS_CompareByIndex(HUGEELEMENT(NHQS_lpData, i, NHQS_wSize), 
                         HUGEELEMENT(NHQS_lpData, start, NHQS_wSize),
								 NHQS_hpFDirs) >= 0)
		  break;
	    }
	    
	    while(1) {
		j--;
		if (NHQS_CompareByIndex(HUGEELEMENT(NHQS_lpData, j, NHQS_wSize), 
                         HUGEELEMENT(NHQS_lpData, start, NHQS_wSize),
								 NHQS_hpFDirs) <= 0)
		  break;
	    }

	    if (i < j) 
	      HugeExchange(NHQS_lpData, i, j, NHQS_wSize);
	    else
	      break;
	}

	HugeExchange(NHQS_lpData, start, j, NHQS_wSize);
	NearHugeQsortByIndex(start, j-1);
	NearHugeQsortByIndex(j+1, end);
    }
}

BOOL FAR PASCAL HugeIsortByIndex(HPVOID lpData, int N, WORD wSize, 
		      int (FAR PASCAL *Compare)(LPVOID, LPVOID, HPVOID), HPVOID hpFontDirs)
{                                       
   int i, j;
   LPVOID lpTempBuf = NULL;


   if ( N <= 1) return (TRUE);

	if( (lpTempBuf = (LPSTR) GlobalAllocPtr(GHND, (DWORD) wSize)) == NULL)
   {
      return (FALSE);
   }


   // we have all we need to start sorting

   for (i = 1; i <= N; i++) //index from 0
   {
      MemCopy((LPSTR)lpTempBuf, HUGEELEMENT(lpData, i, wSize), wSize); 
      j = i;

      while((j > 0 )&& 
            (Compare(HUGEELEMENT(lpData, j-1 , wSize), lpTempBuf , hpFontDirs) > 0 ))
      {
         MemCopy(HUGEELEMENT(lpData, j, wSize), HUGEELEMENT(lpData, j-1, wSize), wSize ); 
         j--;
      }

      //don't copy unless we need to
      if (i != j)
         MemCopy(HUGEELEMENT(lpData, j, wSize), (LPSTR)lpTempBuf, wSize); 
   }


   if (lpTempBuf)
      GlobalFreePtr(lpTempBuf);

   return (TRUE);
}

WORD FAR PASCAL CompositeString(HINSTANCE hInst, UINT uiRsc1, UINT uiRsc2, UINT uiRsc3, LPSTR lpszBuff, int iBufSize)
{
   WORD rc = RC_OK;
   LPSTR bufString1 = NULL;
   LPSTR bufString2 =NULL;
   LPSTR bufString3 = NULL;

   *lpszBuff = '\0';
   if ((bufString1 = (LPSTR) GlobalAllocPtr(GDLLHND, 3*SM_BUF)) == NULL)
     return (RC_ERROR);
   bufString2 = bufString1 + SM_BUF;
   bufString3 = bufString1 + (2*SM_BUF);

   if (uiRsc1)
   {
      LoadString(hInst, uiRsc1, bufString1, SM_BUF);
      if (uiRsc2)
      {
         LoadString(hInst, uiRsc2, bufString2, SM_BUF);
         if (uiRsc3)
         {
            LoadString(hInst, uiRsc3, bufString3, SM_BUF);
            if ((lstrlen(bufString1) + lstrlen(bufString2) +lstrlen(bufString3)) < iBufSize)
              wsprintf(lpszBuff, bufString1, bufString2, bufString3);
         }
         else if ((lstrlen(bufString1) + lstrlen(bufString2)) < iBufSize)
            wsprintf(lpszBuff, bufString1, bufString2);
      } else if (lstrlen(bufString1) < iBufSize)
         lstrcpy(lpszBuff,bufString1);
   }
   else 
      rc = RC_ERROR;

   GlobalFreePtr(bufString1);
   return rc;

}
BOOL FAR PASCAL IsCharSetSupported(BYTE dfCharSet)
{
   BOOL bSupported = FALSE;

   switch (dfCharSet)
   {
      case ANSI_CHARSET: 
      case GREEK_CHARSET:
      case TURKISH_CHARSET:
      case HEBREW_CHARSET:
      case ARABIC_CHARSET:
      case BALTIC_CHARSET:
      case RUSSIAN_CHARSET:
      case EASTEUROPE_CHARSET:
         bSupported = TRUE;
   }
   return bSupported;
}

// ALWAYS_ICM
/*****************************************************************************
*
*                               IsWin40
*  function:
*
*       This function detects whether the driver is
*       is being run under Window v 4.0 or not
*
*  prototype:
*       BOOL  FAR IsWin40( void );
*
*  parameters:
*             none
*
*  returns:
*       TRUE  => If running under Win 4.0
*       FALSE => If running under Win 4.1
*
*****************************************************************************/
BOOL  FAR   IsWin40()
{
   BOOL           bRc = TRUE;
   OSVERSIONINFO  osInfo;

   /* Get the Windows version */
#if 0
   // This function does not work.
   DWORD       wVers;
   BYTE        ll, hl;

   wVers = GetVersion();
   ll = LOBYTE(LOWORD(wVers));
   hl = HIBYTE(LOWORD(wVers));
   if ((ll >= 4) && (hl > 0))
   {
      bRc = TRUE;
   }
#endif
   osInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
   bRc = GetVersionEx(&osInfo);
   if (bRc && (osInfo.dwMajorVersion == 4) && (osInfo.dwMinorVersion > 0))
       return (FALSE);
   else
       return (TRUE);

} // IsWin40

