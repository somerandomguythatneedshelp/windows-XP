/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: TRANS.H                                                */
/*                                                                           */
/* Description: This include contains the prototype for TRANS.C              */
/*                                                                           */
/*****************************************************************************/

SHORT FAR PASCAL StartTranslation(LPPDEVICE lppd, LPDOCINFO lpDocInfo) ;
VOID FAR PASCAL EndTranslation(LPPDEVICE lppd)    ;
VOID FAR PASCAL InitFontDataList( LPPDEVICE );
VOID FAR PASCAL ResetFontDataList( LPPDEVICE );
VOID FAR PASCAL AsciiOrBinary(short Flavor, BOOL Binary, LPPDEVICE lppd);
