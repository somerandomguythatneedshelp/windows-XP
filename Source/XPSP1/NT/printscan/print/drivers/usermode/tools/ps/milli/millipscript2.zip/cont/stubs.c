/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: STUBS.C                                                      */
/*                                                                           */
/* Description: This module contains ...                                     */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_STUBSSEG)


SHORT _loadds FAR PASCAL DeviceBitmap(LP lpDevice,SHORT sCommand,
                                      LPBITMAP lpBitmap, LP lpBits)
{
        SHORT sRC = 0 ;
       // EntryMonitor(ID_DEVICEBITMAP, NULL) ; //Register entry into the Driver.
       // ExitMonitor(ID_DEVICEBITMAP, NULL ) ; //Register exit from the Driver.
        return(sRC);
}


SHORT _loadds FAR PASCAL FastBorder(LPRECT lpRect,WORD wBorderWidth,
                                    WORD wBorderDepth, DWORD dROP,LP lpDevice,
                                    LPPBRUSH lpPBrush,LPDRAWMODE lpDrawMode,
                                    LPRECT lpClipRect)
{
        SHORT sRC = 0 ;
       // EntryMonitor(ID_FASTBORDER, NULL) ; //Register entry into the Driver.
       // ExitMonitor(ID_FASTBORDER, NULL) ; //Register exit from the Driver.
        return(sRC);
}


SHORT _loadds FAR PASCAL SetAttribute(LP lpDevice,SHORT sStateNum,SHORT sIndex,
                                      SHORT sAttribute)
{
        SHORT sRC = 0 ;
      //  EntryMonitor(ID_SETATTRIBUTE, NULL) ; //Register entry into the Driver.
      //  ExitMonitor(ID_SETATTRIBUTE, NULL) ; //Register exit from the Driver.
        return(sRC);
}

