/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: KEYWFUNC.C                                                   */
/*                                                                           */
/* Description: Contains functions for new API to access info. from WPX and  */
/*              PSEXTDEVMODE structures.                                     */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_UTILSSEG)


/****************************************************************************/
/*                                                                          */
/*                      KeywordGetKeywordTranslation                        */
/*                                                                          */
/*  Function:                                                               */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
WORD  FAR  PASCAL  KeywordGetKeywordTranslation(LPPDEVICE  lppd ,
                                                WORD  MainKeywordIndex,
                                                LPSTR lpTranslation,
                                                WORD  Len)
{
   LPPRINTERINFO lpPrinterInfo ;
   LPMAINKEYHDR lpCurMainKeyHdr ;
   STRINGREF MainTranslation;
   LPBYTE Translation;

   lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo ;

   // Do a LoadString() if it is a driver synthetic UI type keyword
   if (MainKeywordIndex >= MAX_RESOURCE_ID)
   {
      LoadString(ghDriverMod, MainKeywordIndex, lpTranslation, Len);
      return(TRUE);
   }
   
   if(MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
      return(FALSE) ;  // specified index exceeds range!

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;
   MainTranslation = lpCurMainKeyHdr->MainTranslation ;

   if(!MainTranslation.w.length)  // none found
      MainTranslation = lpCurMainKeyHdr->MainKey ;

   Translation = StringRefToLPBYTE(lppd, MainTranslation.dword);  
//   *lpLen = MainTranslation.w.length ;

   // Copy the string into supplied buffer, with an EOS.
   if ( Len >= (MainTranslation.w.length+1) )
   {
      lstrcpyn( lpTranslation, Translation, (MainTranslation.w.length+1) ) ;
   }
   else
   {
      lstrcpyn( lpTranslation, Translation, Len ) ;
   }

   return(MainTranslation.w.length);
}
/****************************************************************************/
/*                                                                          */
/*                      KeywordGetMainKeyword                               */
/*                                                                          */
/*  Function:           Get MainKeyword string only                         */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
WORD  FAR  PASCAL  KeywordGetMainKeyword(LPPDEVICE  lppd ,
                                                WORD  MainKeywordIndex,
                                                LPSTR lpMainKeyword,
                                                WORD  Len)
{
   LPPRINTERINFO lpPrinterInfo ;
   LPMAINKEYHDR lpCurMainKeyHdr ;
   STRINGREF MainKeyword;
   LPBYTE MainKeyString;

   lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo ;

   // Do a LoadString() if it is a driver synthetic UI type keyword
   if (MainKeywordIndex >= MAX_RESOURCE_ID)
   {
      LoadString(ghDriverMod, MainKeywordIndex, lpMainKeyword, Len);
      return(TRUE);
   }
   
   if(MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
      return(FALSE) ;  // specified index exceeds range!

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;
   MainKeyword = lpCurMainKeyHdr->MainKey ;

   MainKeyString = StringRefToLPBYTE(lppd, MainKeyword.dword);  

   // Copy the string into supplied buffer, with an EOS.
   if ( Len >= (MainKeyword.w.length+1) )
   {
      lstrcpyn( lpMainKeyword, MainKeyString, (MainKeyword.w.length+1) ) ;
   }
   else
   {
      lstrcpyn( lpMainKeyword, MainKeyString, Len ) ;
   }

   return(MainKeyword.w.length);
}

/****************************************************************************/
/*                                                                          */
/*                      KeywordGetOptionKeyword                             */
/*                                                                          */
/*  Function:                                                               */
/*   Given a Main and Option keyword index returns a STRINGREF.dword which  */
/*   can be used to access the OptionKeyword string associated              */ 
/*   with that option. With trivial modification this function can return   */
/*   the option keyword or invocation string                                */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
WORD  FAR  PASCAL  KeywordGetOptionKeyword( LPPDEVICE  lppd,
                                            WORD  MainKeywordIndex,
                                            WORD  OptionKeywordIndex,
                                            LPSTR lpOptionKeyword,
                                            WORD  Len)
{
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR   lpCurMainKeyHdr ;
   WORD           numOptions  ;
   STRINGREF      keywordString;
   LPBYTE         lpOptionsBlock;
   LPGENERIC_OPTION   lpOptionInfo ;
   LPBYTE         lpKeywordStr;

   lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo ;
   lpOptionsBlock = lppd->lpWPXblock->WPXarrays ;

   if(MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
      return(FALSE) ;  // specified index exceeds range!

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;
   numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

   if(OptionKeywordIndex >= numOptions)
      return(FALSE) ;  // specified option index exceeds range!

   lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
      lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

   keywordString = lpOptionInfo[OptionKeywordIndex].OptionKey ;

   lpKeywordStr = StringRefToLPBYTE(lppd, keywordString.dword);  

   // Copy the string into supplied buffer, with an EOS.
   if(!keywordString.w.length)
      lpOptionKeyword[0] = '\0' ;
   else if ( Len >= (keywordString.w.length+1) )
   {
        lstrcpyn( lpOptionKeyword, lpKeywordStr, (keywordString.w.length+1) ) ;
   }
   else
   {
        lstrcpyn( lpOptionKeyword, lpKeywordStr, Len ) ;
   }

   return(keywordString.w.length);
}

/****************************************************************************/
/*                                                                          */
/*                      KeywordGetOptionTranslation                         */
/*                                                                          */
/*  Function:                                                               */
/*   Given a Main and Option keyword index returns a STRINGREF.dword which  */
/*   can be used to access the OptionKeyword Translation string associated  */ 
/*   with that option. With trivial modification this function can return   */
/*   the option keyword or invocation string                                */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
WORD  FAR  PASCAL  KeywordGetOptionTranslation( LPPDEVICE  lppd,
                                                WORD  MainKeywordIndex,
                                                WORD  OptionKeywordIndex,
                                                LPSTR lpTranslation,
                                                WORD Len)
{
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   WORD           numOptions  ;
   STRINGREF    OptionTranslation;
   LPBYTE      lpOptionsBlock;
   LPGENERIC_OPTION   lpOptionInfo ;
   LPBYTE Translation;

   lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo ;
   lpOptionsBlock = lppd->lpWPXblock->WPXarrays ;

   // Do a LoadString() if it is a driver synthetic UI type keyword
   if (OptionKeywordIndex >= MAX_RESOURCE_ID)
   {
      LoadString(ghDriverMod, OptionKeywordIndex, lpTranslation, Len);
      return(TRUE);
   }
   
   if(MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
      return(FALSE) ;  // specified index exceeds range!

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;
   numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

   if(OptionKeywordIndex >= numOptions)
      return(FALSE) ;  // specified option index exceeds range!

   lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
      lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

   OptionTranslation = 
      lpOptionInfo[OptionKeywordIndex].OptionTranslation ;

   if(!OptionTranslation.w.length)  // none found
      OptionTranslation = 
         lpOptionInfo[OptionKeywordIndex].OptionKey ;

   Translation = StringRefToLPBYTE(lppd, OptionTranslation.dword);  
//   *lpLen = OptionTranslation.w.length ;

   // Copy the string into supplied buffer, with an EOS.
   if(!OptionTranslation.w.length)
      lpTranslation[0] = '\0' ;
   else if ( Len >= (OptionTranslation.w.length+1) )
   {
        lstrcpyn( lpTranslation, Translation, (OptionTranslation.w.length+1) ) ;
   }
   else
   {
        lstrcpyn( lpTranslation, Translation, Len ) ;
   }

   return(OptionTranslation.w.length);
}

/****************************************************************************/
/*                                                                          */
/*                      KeywordGetNumOfOptions                              */
/*                                                                          */
/*  Function:                                                               */
/*   Given a MainKeyword index returns the number of Options availible      */ 
/*   for that MainKeyword                                                   */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
BOOL  FAR  PASCAL  KeywordGetNumOfOptions(LPPDEVICE  lppd ,
                                          WORD  MainKeywordIndex,
                                          LPWORD  lpNumOptions)
{
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;

   lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo ;

   if(MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
   {
      *lpNumOptions = 0 ;
      return(FALSE) ;  // specified index exceeds range!
   }

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;
   *lpNumOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;
   return(TRUE);
}

/****************************************************************************/
/*                                                                          */
/*                          KeywordGetOptionPS                              */
/*                                                                          */
/*  Function:                                                               */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/

WORD  FAR  PASCAL  KeywordGetOptionPS( LPPDEVICE  lppd ,
                                       WORD  MainKeywordIndex,
                                       WORD  OptionKeywordIndex,
                                       LPSTR lpInvocation,
                                       LPWORD lpLen)
{
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   WORD          numOptions  ;
   STRINGREF    OptionInvocation;
   LPBYTE      lpOptionsBlock;
   LPGENERIC_OPTION   lpOptionInfo ;
   LPBYTE   Invocation;

   lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo ;
   lpOptionsBlock = lppd->lpWPXblock->WPXarrays ;

   // Check if MainKeywordIndex passed in is one of those that only
   // a STRINGREF in PrinterInfo (for example, JCL, JobPatchFile etc).
   // These features have no MainKeyHdr struct and no options. They
   // are of type    *Keyword:  Invocation

   switch (MainKeywordIndex)
   {
      case ID_KEY_PASSWORD:
         OptionInvocation = lpPrinterInfo->password; 
      break;

      case ID_KEY_EXITSERVER:
         OptionInvocation = lpPrinterInfo->exitServer; 
      break;

      case ID_KEY_PATCHFILE:
         OptionInvocation = lpPrinterInfo->PatchFile; 
      break;

//      case ID_KEY_JOBPATCHFILE:      
//         OptionInvocation = lpPrinterInfo->JobPatchFile; 
//      break;

      case ID_KEY_PCFILENAME:
         OptionInvocation = lpPrinterInfo->PCFileName; 
      break;

#if 0    // To be done later - ShyamV 
      case ID_KEY_CUSTOMPAGE:
      break;

      case ID_KEY_JCLINFO:
      break;
#endif

      default:
      {
         if (MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
            return(FALSE) ;  // specified index exceeds range!

         lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;
         numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

         if(OptionKeywordIndex >= numOptions)
            return(FALSE) ;  // specified option index exceeds range!

         lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
            lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

         OptionInvocation = 
            lpOptionInfo[OptionKeywordIndex].Invocation ;
      }
      break;

   }  // switch(MainKeywordIndex)

   Invocation = StringRefToLPBYTE(lppd, OptionInvocation.dword);  

   if (!Invocation)
      return(FALSE) ;  // no Invocation string

   // Copy the invocation string into supplied buffer, with an EOS.

   if ( *lpLen >= (OptionInvocation.w.length+1) )
   {
      lstrcpyn( lpInvocation, Invocation, (OptionInvocation.w.length+1) ) ;
   }
   else
   {
      lstrcpyn( lpInvocation, Invocation, *lpLen ) ;
   }

   return(OptionInvocation.w.length);
}


/****************************************************************************/
/*                                                                          */
/*                    KeywordOptionContraintArray                           */
/*                                                                          */
/*  Function:                                                               */
/*   Given a MainKeyword index, returns an array of BOOLEANS indicating     */
/*   the current status of option constraints.  A TRUE indicates this       */
/*   option is currently Enabled.  FALSE means option should be grayed out  */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
BOOL    FAR  PASCAL  KeywordOptionConstraintArray( LPPDEVICE  lppd ,
                                                   WORD  MainKeywordIndex, 
                                                   LPBOOL  lpOptionArray)  
{
   LPWPXBLOCKS  lpWPXblock ;
   LPOPTIONSTATE  lpOptionState ;
   LPPRINTERINFO  lpPrinterInfo ;
   LPBYTE      lpOptionsBlock;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   WORD           numOptions,  i ;
   LPUI_CONSTRAINTS  lpUIconstraints ;
   LPGENERIC_OPTION   lpOptionInfo ;

   lpWPXblock = lppd->lpWPXblock ;
   lpOptionState = lppd->lpPSExtDevmode->dm.optionState ;
   lpOptionsBlock = lpWPXblock->WPXarrays ;
   lpUIconstraints = lpWPXblock->WPXconstraints ;

   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;

   if(MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
      return(FALSE) ;  // specified main index exceeds range!

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;
   numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

   if(!numOptions)
      return(FALSE);  // No options exist!

   for(i = 0 ; i < numOptions ; i++)
      lpOptionArray[i] = TRUE ;  // until explicitly constrained.

   for(i = 0 ; i < lpPrinterInfo->numMainKeyHdrs ; i++)
   {
      WORD    curState,  optionIndex,  constrntIndex, j ;

      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + i ;
      lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
         lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

      if(!lpCurMainKeyHdr->OptionKeyWords.w.length)
         continue ;   //  there's nothing here!
                     //  optionIndex and lpOptionInfo[optionIndex] 
                     //  is undefined.

      for(curState = i ; 1 ; )
      {
         optionIndex = lpOptionState[curState].optionKeyIndex ;
         constrntIndex = lpOptionInfo[optionIndex].UIconstraintIndex ;

         while(constrntIndex != 0xFFFF)  
         {                // evaluate each element in constraint list
            if(lpUIconstraints[constrntIndex].MainKeyIndex == MainKeywordIndex)
            {
               if(constrntIndex == 0xFFFE) // disable all but none or false
               {
                  for(j = 1 ; j < numOptions ; j++)
                     lpOptionArray[j] = FALSE ;
                  return(TRUE);  // according to law, at least one option
                                 // must be selected !
               }
               else
                  lpOptionArray[lpUIconstraints[constrntIndex].OptionKeyIndex] = FALSE ;
            }
            constrntIndex = lpUIconstraints[constrntIndex].nextIndex ;
         }
         if((curState = lpOptionState[curState].nextState) == 0xFFFF)
            break;
      }
   }   

//  note  must also update code in PriorityConstraintArray

   if(MainKeywordIndex == IND_INPUTSLOTINFO  &&  
         lpPrinterInfo->devcaps.MixedBins != 0xFFFF)
   {
      BOOL  bUpper = FALSE, bLower = FALSE ;
      WORD  j, iMixedBins = lpPrinterInfo->devcaps.MixedBins ;
      LPINPUTSLOTINFO    lpInputSlotInfo ;

      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;

      lpInputSlotInfo = (LPINPUTSLOTINFO)MAKELONG(
         lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );


      for(j = 0 ; j < numOptions ; j++)
      {
         if(lpInputSlotInfo[j].slotID == DMBIN_UPPER  &&  lpOptionArray[j] )
            bUpper = TRUE ;
         else if(lpInputSlotInfo[j].slotID == DMBIN_LOWER  &&  lpOptionArray[j] )
            bLower = TRUE ;
      }
      if(!(bUpper && bLower))  //  if either is FALSE.
         lpOptionArray[iMixedBins] = FALSE ;
   }
   return(TRUE);  
}

/****************************************************************************/
/*                                                                          */
/*                      IsKeywordOptConstrained                             */
/*                                                                          */
/*  Function:                                                               */
/*   Given a MainKeyword index and OptionKeyword index, returns a BOOLean   */
/*   that indicates if the option is currently contrained or not.           */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
BOOL    FAR  PASCAL  IsKeywordOptConstrained(LPPDEVICE  lppd,
                                             WORD  MainKeywordIndex, 
                                             WORD  OptionKeywordIndex)
{
   BOOL  OptionArray[100] ;  // can be overflowed !
   WORD   numOpts;

   KeywordGetNumOfOptions(lppd , MainKeywordIndex, &numOpts) ;
   if (numOpts > 100  ||  OptionKeywordIndex >= numOpts)  
      return(FALSE);       // too many options to fit in local array.


   if(! KeywordOptionConstraintArray(lppd , MainKeywordIndex, OptionArray)) 
      return(FALSE);

   return(!OptionArray[OptionKeywordIndex]) ;
}

/****************************************************************************/
/*                                                                          */
/*                   KeywordGetFirstOptionNotContrained                     */
/*                                                                          */
/*  Function:                                                               */
/*   Given a MainKeyword index, returns the first OptionKeyword index       */
/*   that is currently unconstrained.                                       */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
BOOL    FAR  PASCAL  KeywordGetFirstOptionNotConstrained(LPPDEVICE  lppd,
                                                WORD  MainKeywordIndex, 
                                                LPWORD  lpOptionKeywordIndex)
{
   BOOL  OptionArray[100] ;  // can be overflowed !
   WORD  i , numOpts;

   KeywordGetNumOfOptions(lppd , MainKeywordIndex, &numOpts) ;
   if (numOpts > 100)  // too many options to fit in local array.
      return(FALSE);

   if(! KeywordOptionConstraintArray(lppd , MainKeywordIndex, OptionArray)) 
      return(FALSE);

   for(i = 0 ; i < numOpts ; i++)
   {
      if(OptionArray[i])
      {
         *lpOptionKeywordIndex = i ;
         return(TRUE) ;
      }
   }
   return(FALSE);
}

/****************************************************************************/
/*                                                                          */
/*                    KeywordSetCurrentOption                               */
/*                                                                          */
/*  Function:                                                               */
/*   WARNING:  special function for PICKONE UItype only!                    */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
BOOL    FAR  PASCAL  KeywordSetCurrentOption(LPPDEVICE   lppd,
                                             WORD  MainKeywordIndex, 
                                             WORD  OptionIndex)
{
   LPWPXBLOCKS  lpWPXblock ;
   LPOPTIONSTATE  lpOptionState ;
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   WORD           numOptions ;

   lpWPXblock = lppd->lpWPXblock ;
   lpOptionState = lppd->lpPSExtDevmode->dm.optionState ;

   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;

   if(MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
      return(FALSE) ;  // specified main index exceeds range!

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;
   numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

   if(OptionIndex >= numOptions)
      return(FALSE) ;  // specified option index exceeds range!

   lpOptionState[MainKeywordIndex].optionKeyIndex = OptionIndex ;
   lpOptionState[MainKeywordIndex].nextState = 0xFFFF ;
   return(TRUE) ;
}

/****************************************************************************/
/*                                                                          */
/*                    KeywordGetCurrentOption                               */
/*                                                                          */
/*  Function:                                                               */
/*   WARNING:  special function for PICKONE UItype only!                    */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
BOOL    FAR  PASCAL  KeywordGetCurrentOption(LPPDEVICE  lppd,
                                             WORD  MainKeywordIndex, 
                                             LPWORD  lpOptionIndex)
{
   LPWPXBLOCKS  lpWPXblock ;
   LPOPTIONSTATE  lpOptionState ;

   lpWPXblock = lppd->lpWPXblock ;
   lpOptionState = lppd->lpPSExtDevmode->dm.optionState ;


   return(rawKeywordGetCurrentOption(lpWPXblock, lpOptionState,
            MainKeywordIndex, lpOptionIndex)) ;
}


BOOL    FAR  PASCAL  rawKeywordGetCurrentOption(
LPWPXBLOCKS  lpWPXblock ,
LPOPTIONSTATE  lpOptionState ,
WORD  MainKeywordIndex, 
LPWORD  lpOptionIndex)
{
   LPPRINTERINFO  lpPrinterInfo ;

   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;

   if(MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
      return(FALSE) ;  // specified main index exceeds range!

   *lpOptionIndex = lpOptionState[MainKeywordIndex].optionKeyIndex ;
   return(TRUE) ;
}

/****************************************************************************/
/*                                                                          */
/*                    KeywordGetDefaultOption                               */
/*                                                                          */
/*  Function: Get current mainkeyword default option index                  */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
BOOL  FAR  PASCAL  KeywordGetDefaultOption(LPPDEVICE  lppd,
                                             WORD  MainKeywordIndex, 
                                             LPWORD  lpOptionIndex)
{
   LPWPXBLOCKS  lpWPXblock ;
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;

   lpWPXblock = lppd->lpWPXblock ;			
   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;

   *lpOptionIndex = lpCurMainKeyHdr->DefaultOptionIndex ;
   return(TRUE) ;

}


/****************************************************************************/
/*                                                                          */
/*                    KeywordSetCurrentOptionArray                          */
/*                                                                          */
/*  Function:                                                               */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
BOOL    FAR  PASCAL  KeywordSetCurrentOptionArray( LPPDEVICE  lppd,
                                                   WORD  MainKeywordIndex, 
                                                   LPBOOL  lpOptionArray)
{
   LPWPXBLOCKS  lpWPXblock ;
   LPOPTIONSTATE  lpOptionState ;
   LPPRINTERINFO  lpPrinterInfo ;
   LPBYTE      lpOptionsBlock;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   WORD           numOptions  ;

   lpWPXblock = lppd->lpWPXblock ;
   lpOptionState = lppd->lpPSExtDevmode->dm.optionState ;

   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;
   lpOptionsBlock = lpWPXblock->WPXarrays ;

   if(MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
      return(FALSE) ;  // specified main index exceeds range!

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;
   numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

   if(!numOptions)
      return(FALSE);  // Nothing to set!

#if 0
   //  UI code should only permit selection of unconstrained options
   //  this check is redundant.
   //  verify all new options are allowed by UI constraints.

   if(!AreOptionsAllowed())
      return(FALSE);
#endif
   if(lpCurMainKeyHdr->UItype != PICKMANY)
   {
      WORD   selectedOpt ;

      //  determine selectedOpt
      for(selectedOpt = 0 ; selectedOpt < numOptions ; selectedOpt++)
      {
         if(lpOptionArray[selectedOpt]) 
            break;
      }
      if(selectedOpt >= numOptions)
         return(FALSE) ;  // No option was selected.

      lpOptionState[MainKeywordIndex].optionKeyIndex = selectedOpt ;
         return(TRUE);
   }
   else
   {
// OEMPLUGI begin
      return(modifyOptionState(lpOptionState, MainKeywordIndex, 
               lpOptionArray, lpPrinterInfo->numMainKeyHdrs, numOptions, 
               MAXOPTIONSTATES - lppd->lpPSExtDevmode->dm.numOEMDocSticky));
// OEMPLUGI end
   }
}

/****************************************************************************/
/*                                                                          */
/*                    KeywordGetCurrentOptionArray                          */
/*                                                                          */
/*  Function:  inits an array of BOOLs to true for each selected option     */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
BOOL    FAR  PASCAL  KeywordGetCurrentOptionArray( LPPDEVICE  lppd,
                                                   WORD  MainKeywordIndex, 
                                                   LPBOOL  lpOptionArray)
{
   LPWPXBLOCKS  lpWPXblock ;
   LPOPTIONSTATE  lpOptionState ;
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   WORD           numOptions,  index , i ;

   lpWPXblock = lppd->lpWPXblock ;
   lpOptionState = lppd->lpPSExtDevmode->dm.optionState ;

   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;

   if(MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
      return(FALSE) ;  // specified main index exceeds range!

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;
   numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

   if(!numOptions)
      return(FALSE) ;

   for(i = 0 ; i < numOptions ; i++)
      lpOptionArray[i] = FALSE ;

   for(index = MainKeywordIndex ; 1 ; )
   {
      lpOptionArray[lpOptionState[index].optionKeyIndex] = TRUE ;
      if((index = lpOptionState[index].nextState) == 0xFFFF)
         break;
   }

   return(TRUE) ;
}

/****************************************************************************/
/*                                                                          */
/*                      KeywordNextOrderedKeyword                           */
/*                                                                          */
/*  Function:                                                               */
/*    To obtain the first index for a particular section,                   */
/*    set  CurrentKeywordIndex = 0xFFFF - section ;                         */
/*    where section is one of                                               */
/*       ANYWHERE, ATEXITSERVER, PROLOG, DOCSETUP, PAGESETUP, JCLSETUP      */
/*                                                                          */
/*    After obtaining the first ordered KeywordIndex 'k'; to get the next   */
/*    keyword in that section, pass 'k' as the CurrentKeywordIndex. The     */
/*    process continues until the next ordered keyword becomes 0xFFFF which */
/*    signals that there are no more keywords in that section.              */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
BOOL    FAR  PASCAL  KeywordNextOrderedKeyword( LPPDEVICE  lppd,
                                                LPWORD  lpKeywordIndex, 
                                                WORD  CurrentKeywordIndex)
{
   LPWPXBLOCKS  lpWPXblock ;
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;

   lpWPXblock = lppd->lpWPXblock ;

   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;

   if(CurrentKeywordIndex < 0xFFF0)
   {
      if(CurrentKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
         return(FALSE) ;  // specified main index exceeds range!

      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + CurrentKeywordIndex ;
      *lpKeywordIndex = lpCurMainKeyHdr->order.ArrayIndex ;
      return(TRUE) ;
   }

   CurrentKeywordIndex = 0xFFFF - CurrentKeywordIndex ;

   switch(CurrentKeywordIndex)   // Maybe the root is requested!
   {
      case  ATEXITSERVER:
         *lpKeywordIndex = lpPrinterInfo->OrderListRoot.ExitServer;
         break;
      case  PROLOG:
         *lpKeywordIndex = lpPrinterInfo->OrderListRoot.Prolog;
         break;
      case  DOCSETUP:
         *lpKeywordIndex = lpPrinterInfo->OrderListRoot.DocumentSetup;
         break;
      case  PAGESETUP:
         *lpKeywordIndex = lpPrinterInfo->OrderListRoot.PageSetup;
         break;
      case  JCLSETUP:
         *lpKeywordIndex = lpPrinterInfo->OrderListRoot.JCLSetup;
         break;
      case  ANYWHERE:
         *lpKeywordIndex = lpPrinterInfo->OrderListRoot.Unassigned;
         break;
      default:
         return(FALSE) ;   // Illegal root.
   }

   return(TRUE) ;
}

/****************************************************************************/
/*                                                                          */
/*                      KeywordGetPPDOrderValue                             */
/*                                                                          */
/*  Function:                                                               */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
BOOL    FAR  PASCAL  KeywordGetPPDOrderValue( LPPDEVICE  lppd,
                                              WORD       KeywordIndex,
                                              double far *lpcurrPPDOrderValue,
                                              double far *lpnextPPDOrderValue)
{
   LPWPXBLOCKS    lpWPXblock ;
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR   lpCurMainKeyHdr ;
   WORD           nextKeywordIndex;

   lpWPXblock = lppd->lpWPXblock ;
   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;

   if(KeywordIndex < 0xFFF0)
   {
      if(KeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
         return(FALSE) ;  // specified main index exceeds range!
      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + KeywordIndex ;
      *lpcurrPPDOrderValue = lpCurMainKeyHdr->order.PPDorderValue;

      nextKeywordIndex = lpCurMainKeyHdr->order.ArrayIndex ;
      if(nextKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
         return(FALSE) ;  // specified main index exceeds range!
      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + nextKeywordIndex ;
      *lpnextPPDOrderValue = lpCurMainKeyHdr->order.PPDorderValue;
      return(TRUE) ;
   }
   return (FALSE);
}

/****************************************************************************/
/*                                                                          */
/*                    KeywordSetOptionsToPPDdefault                         */
/*                                                                          */
/*  Function:                                                               */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
BOOL  FAR  PASCAL  KeywordSetOptionsToPPDdefault(LPPDEVICE  lppd)
{
   LPWPXBLOCKS  lpWPXblock ;
   LPOPTIONSTATE  lpOptionState ;
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   WORD          mainIndex;

   lpWPXblock = lppd->lpWPXblock ;
   lpOptionState = lppd->lpPSExtDevmode->dm.optionState ;

   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;

   for(mainIndex = 0 ; mainIndex < lpPrinterInfo->numMainKeyHdrs ; mainIndex++)
   {
      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + mainIndex ;

      lpOptionState[mainIndex].optionKeyIndex = lpCurMainKeyHdr->DefaultOptionIndex ;
      lpOptionState[mainIndex].nextState = 0xFFFF ;
   }

   return(TRUE) ;
}


WORD FAR PASCAL GetInputSlotOptionIndex(LPPDEVICE lppd, WORD InputSlotID)
{
   LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
   LPBYTE lpOptionsBlock = lppd->lpWPXblock->WPXarrays;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   LPINPUTSLOTINFO  lpSlotInfo ;
   WORD i, nOptions;

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;

   lpSlotInfo = (LPINPUTSLOTINFO)MAKELONG(
          lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );
   KeywordGetNumOfOptions(lppd, IND_INPUTSLOTINFO, (LPWORD)&nOptions);

   for (i=0; i<nOptions; i++)
   {
       if (lpSlotInfo[i].slotID == InputSlotID)
           break;
   }

   if (i >= nOptions)
      i = 0xFFFF;

   return i;
}


/****************************************************************************/
/*                                                                          */
/*                         modifyOptionState                                */
/*                                                                          */
/*  Function:                                                               */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE otherwise                          */
/*                                                                          */
/****************************************************************************/
// OEMPLUGI begin
BOOL    NEAR  PASCAL  modifyOptionState(  LPOPTIONSTATE  lpOptionState,
                                          WORD  MainKeywordIndex, 
                                          LPBOOL  lpOptionArray,
                                          WORD    numMainKeyHdrs,
                                          WORD    numOptions,
                                          WORD    maxOption )
{
   OPTIONSTATE  newOptionState[MAXOPTIONSTATES] ;  // reconstruct state here
   WORD   i, newExtendedState ;


   newExtendedState = numMainKeyHdrs ;

   for(i = 0 ; i < numMainKeyHdrs ; i++)
   {
      if(MainKeywordIndex == i)
      {
         WORD  newState,  j ;
         //  set options from lpOptionArray

         newState =  i ;

         for(j = 0 ; j < numOptions ; j++)
         {
            if(lpOptionArray[j])
               break;
         }
         if(j >= numOptions)
            return(FALSE);  // no option was selected!

         while(1)
         {
            newOptionState[newState].optionKeyIndex = j ;

            for(j++ ; j < numOptions ; j++)
            {
               if(lpOptionArray[j])
                  break;
            }
            if(j >= numOptions)
            {
               newOptionState[newState].nextState = 0xFFFF ;
               break;
            }

            newOptionState[newState].nextState = newExtendedState ;
            newState = newExtendedState ;
            if(++newExtendedState > maxOption)
               return(FALSE);  // Ran out of optionstates!
         }
      }
      else
      {
         WORD  newState, oldState ;
         //  set options from  lpOptionState[i] chain.

         newState = oldState = i ;

         while(1)
         {
            newOptionState[newState].optionKeyIndex = 
                        lpOptionState[oldState].optionKeyIndex ;
            newOptionState[newState].nextState = 
                        lpOptionState[oldState].nextState ;
            if((oldState = lpOptionState[oldState].nextState) == 0xFFFF)
            {
               break ;  //  no further traversal needed.
            }

            newOptionState[newState].nextState = newExtendedState ;
            newState = newExtendedState ;
            if(++newExtendedState > maxOption)
               return(FALSE);  // Ran out of optionstates!
         }
      }
   }
   //  copy   newOptionState  back to   lpOptionState

   for(i = 0 ; i < newExtendedState ; i++)
   {
      lpOptionState[i].optionKeyIndex = 
                  newOptionState[i].optionKeyIndex ;
      lpOptionState[i].nextState = 
                  newOptionState[i].nextState ;
   }
}
// OEMPLUGI end

/****************************************************************************/
/*                                                                          */
/*                         StringRefToLPBYTE                                */
/*                                                                          */
/*  Function:                                                               */
/*   Dereferences a STRINGREF.dword to obtain a normal far pointer. Note    */
/*   however the string may contain NULLs or not be NULL terminated. So     */
/*   you must rely on stringRef.w.length to determine the actual length     */
/*   of the string.                                                         */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   Long Pointer to a String                                     */
/*                                                                          */
/****************************************************************************/
LPBYTE   FAR  PASCAL  StringRefToLPBYTE(  LPPDEVICE  lppd,
                                          DWORD    dwstringref)
{
   LPBYTE  lpString;
   STRINGREF  stringRef ;

   stringRef.dword = dwstringref ;

   if(!stringRef.w.length)
      return(NULL);  // no string exists!

   lpString = (LPBYTE)MAKELONG(stringRef.w.offset, 
                               HIWORD(lppd->lpWPXblock->WPXstrings) );
   return(lpString);
}

/****************************************************************************/
/*                                                                          */
/*                         CopyStringRefToLPBYTE                            */
/*                                                                          */
/*  Function:                                                               */
/*    returns number of bytes copied not including null termination         */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:                                                                */
/*                                                                          */
/****************************************************************************/
WORD   FAR  PASCAL  CopyStringRefToLPBYTE(
LPWPXBLOCKS  lpWPXblock , 
LPBYTE  lpDest, 
DWORD    dwstringref)
{
   LPBYTE     lpSrc ;
   STRINGREF  stringRef ;
   WORD     i ;

   stringRef.dword = dwstringref ;

   if(!stringRef.w.length)
      return(0);  // no string exists!

   lpSrc = (LPBYTE)MAKELONG(stringRef.w.offset, 
                               HIWORD(lpWPXblock->WPXstrings) );

   for(i = 0 ; i < stringRef.w.length ; i++)
      *lpDest++ = *lpSrc++ ;

   *lpDest = '\0' ;  // NULL terminate
   return(i);
}

/****************************************************************************/
/*                                                                          */
/*                         DoesKeywordExistByIndex                          */
/*                                                                          */
/*  Function:                                                               */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:                                                                */
/*                                                                          */
/****************************************************************************/
BOOL FAR PASCAL DoesKeywordExistByIndex(LPPDEVICE lppd, WORD KeywordIndex)
{
   WORD NumOptions;

   KeywordGetNumOfOptions(lppd, KeywordIndex, (LPWORD)&NumOptions);

   if (NumOptions)
      return (TRUE);
   else
      return (FALSE);
}




/****************************************************************************/
/*                                                                          */
/*                         validateOptionArray                              */
/*                                                                          */
/*  Function:                                                               */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns: FALSE to indicate user supplied optionState array              */
/*    conflicts with UI constraints or capacity of OptionArray was exceeded */
/*                                                                          */
/****************************************************************************/
BOOL    FAR  PASCAL   validateOptionArray(
LPWPXBLOCKS   lpWPXblock, 
LPPSEXTDEVMODE  lpExtDevMode) 
{
   BOOL  status ;

   status = intValidateOptionArray(lpWPXblock, lpExtDevMode, NULL, 
            NULL) ; 

   return(status);
}



/****************************************************************************/
/*                                                                          */
/*                         intValidateOptionArray                           */
/*                                                                          */
/*  Function: this internal function supports validateOptionArray()  and    */
/*             IsUIConstrained().                                           */
/*                                                                          */
/*  Arguments:  if lpArray is NULL lpExtDevMode will be Update with a valid */
/*             optionArray, otherwise lpArray is updated instead            */
/*             if lpUIConflict exists, it is initialized if the return value*/
/*             is FALSE.                                                    */
/*                                                                          */
/*  Returns: FALSE to indicate user supplied optionState array              */
/*    conflicts with UI constraints or capacity of OptionArray was exceeded */
/*                                                                          */
/****************************************************************************/
BOOL    FAR  PASCAL   intValidateOptionArray(
LPWPXBLOCKS   lpWPXblock, 
LPPSEXTDEVMODE  lpExtDevMode,

LPUICARRAY lpArray,    // New! if not NULL lpExtDevMode will NOT be updated!
LPUICONFLICT  lpUIConflict)  // New! may be NULL.
{
   OPTIONSTATE  newOptionState[MAXOPTIONSTATES] ;  // reconstruct state here
   WORD   i, j, newExtendedState, numMainKeyHdrs, priority, 
               start, count, PriorityArray[MAXOPTIONSTATES] ;
   LPOPTIONSTATE  lpOptionState ;
   LPPRINTERINFO  lpPrinterInfo ;
   BOOL  status = TRUE, OptionArray[100] ;  // can be overflowed !
   BOOL   bInitUIConflict = FALSE ;     

   lpOptionState = lpExtDevMode->dm.optionState ;
   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;
   numMainKeyHdrs = lpPrinterInfo->numMainKeyHdrs ;

   lpOptionState[IND_PAGEREGIONINFO].optionKeyIndex = lpOptionState[IND_PAPERINFO].optionKeyIndex ;

   newExtendedState = numMainKeyHdrs ;

   //  initialize PriorityArray[]

   start = lpPrinterInfo->PrinterSticky.w.offset ;
   count = lpPrinterInfo->PrinterSticky.w.length ;

   for(priority = i = 0 ; i < count ; i++)
      PriorityArray[start+i] = priority++ ;

   for(i = 0 ; i < numMainKeyHdrs ; i++)
   {
      if(i < start  ||  i >= start + count)
         PriorityArray[i] = priority++ ;
   }

   for(j = 0 ; j < numMainKeyHdrs ; j++)
   {
      WORD  newState, oldState, tenativeOption , NumOptions , 
            validOption, oldExtendedState;
      LPMAINKEYHDR  lpCurMainKeyHdr ;
      //  set options from  lpOptionState[i] chain.


      for(i = 0 ; PriorityArray[i] != j ; i++)
         ;  // this determines i from j !

      oldExtendedState = newExtendedState ;  
         //  use to truncate list if invalid option is encountered.

      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + i ;
      NumOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

      if(!NumOptions)  //  don't worry about this case.
      {
         newOptionState[i].optionKeyIndex =
            lpOptionState[i].optionKeyIndex ;
         newOptionState[i].nextState =
            lpOptionState[i].nextState ;
         continue ;
      }


      if(lpUIConflict)
      {
         lpUIConflict->wMainConstrainer = 0xFFFF ;
         lpUIConflict->wOptionConstrainer = 0xFFFF ;
         //  lpUIConflict->wOptionConstrained =  see lpOptionState;
      }
      
      PriorityConstraintArray(lpWPXblock, newOptionState, 
            PriorityArray, i, OptionArray, lpUIConflict, lpOptionState);

      if(lpUIConflict  &&  lpUIConflict->wMainConstrainer != 0xFFFF)
      {
         lpUIConflict = NULL ;  // prevent all future access !
      }

      validOption = lpCurMainKeyHdr->DefaultOptionIndex ;

      if(!OptionArray[validOption])  //  if default option itself is invalid...
      {
         for(validOption = 0 ; validOption < NumOptions && !OptionArray[validOption] ; validOption++)
            ;  // grab the first valid option.
         if(validOption >= NumOptions)        // if no options are valid - screw the constraints
            validOption = lpCurMainKeyHdr->DefaultOptionIndex ;
      }

      newState = oldState = i ;

      while(1)
      {
         tenativeOption =
                     newOptionState[newState].optionKeyIndex = 
                     lpOptionState[oldState].optionKeyIndex ;
         newOptionState[newState].nextState = 
                     lpOptionState[oldState].nextState ;
         if(!OptionArray[tenativeOption])
         {
            //  invalid option found, this causes all
            //  selected options for this MainKeyword to be
            //  deselected and replaced by validOption !

            newOptionState[i].optionKeyIndex = validOption ;
            newOptionState[i].nextState = 0xFFFF ;
            newExtendedState = oldExtendedState ;  
            status = FALSE ;  //  user supplied option array not acceptable.
            if(i == IND_INPUTSLOTINFO  &&  
               lpPrinterInfo->devcaps.MixedBins != 0xFFFF  &&
               tenativeOption == lpPrinterInfo->devcaps.MixedBins)
            {
               if(lpUIConflict)
               {
                  lpUIConflict->wMainConstrainer = 0xFFFF ;
                  lpUIConflict->wOptionConstrainer = 0xFFFF ;
                  lpUIConflict = NULL ;  // prevent all future access !
               }
            }
            break;
         }
         if(lpCurMainKeyHdr->UItype != PICKMANY)
         {
            newOptionState[i].nextState = 0xFFFF ;
            break;
         }
         if((oldState = lpOptionState[oldState].nextState) == 0xFFFF)
         {
            break ;  //  no further traversal needed.
         }

         newOptionState[newState].nextState = newExtendedState ;
         newState = newExtendedState ;
         
         if(++newExtendedState > MAXOPTIONSTATES - lpExtDevMode->dm.numOEMDocSticky)
            return(FALSE);  // Ran out of optionstates!
#ifdef OLD
         if(++newExtendedState > MAXOPTIONSTATES)
            return(FALSE);  // Ran out of optionstates!
#endif
      
      }
   }

   newOptionState[IND_PAGEREGIONINFO].optionKeyIndex = 
      newOptionState[IND_PAPERINFO].optionKeyIndex ;

   if(lpArray)  // just report results to caller, don't do.
   {
      for(i = 0 ; i < numMainKeyHdrs ; i++)
      {
         lpArray[i].wOldOption = lpOptionState[i].optionKeyIndex ;
         lpArray[i].wNewOption = newOptionState[i].optionKeyIndex ;
      }
   }
   else     //  copy   newOptionState  back to   lpOptionState
   {
      for(i = 0 ; i < newExtendedState ; i++)
      {
         lpOptionState[i].optionKeyIndex = 
                     newOptionState[i].optionKeyIndex ;
         lpOptionState[i].nextState = 
                     newOptionState[i].nextState ;
      }
   }
   return(status);
}


//  internal function used by intValidateOptionArray().
//  enhancement: we will explicity assign priorities
//  to each of the elements in MainKeyHdr.  This function
//  will consult with all options belonging to elements
//  with higher priority before generating the OptionArray
//  for the specified MainKeyword.
//  Assume lpOptionState for all higher priority elements
//  has been initialized and are valid. 

BOOL    NEAR  PASCAL   PriorityConstraintArray(
LPWPXBLOCKS   lpWPXblock, 
LPOPTIONSTATE  lpOptionState ,
LPWORD   lpPriorityArray,   //  New!
WORD  MainKeywordIndex, 
LPBOOL  lpOptionArray,
LPUICONFLICT  lpUIConflict,  // New! may be NULL.
   //  if not NULL, the fields wMainConstrainer and wOptionConstrainer
   //  must be initialized to 0xFFFF.
LPOPTIONSTATE  lpOldOptionState )  // contains current options, initialize
   // lpUIConflict only if one of these is obstructed!
{
   LPPRINTERINFO  lpPrinterInfo ;
   LPBYTE      lpOptionsBlock;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   WORD           numOptions,  i ;
   LPUI_CONSTRAINTS  lpUIconstraints ;
   LPGENERIC_OPTION   lpOptionInfo ;

   lpOptionsBlock = lpWPXblock->WPXarrays ;
   lpUIconstraints = lpWPXblock->WPXconstraints ;

   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;

   if(MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
      return(FALSE) ;  // specified main index exceeds range!

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;
   numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

   for(i = 0 ; i < numOptions ; i++)
      lpOptionArray[i] = TRUE ;  // until explicitly constrained.

   for(i = 0 ; i < lpPrinterInfo->numMainKeyHdrs ; i++)
   {
      WORD    curState,  optionIndex,  constrntIndex, j ;

      if(lpPriorityArray[MainKeywordIndex] <= lpPriorityArray[i])
         continue;  // lower priority KeyWord.

      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + i ;
      lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
         lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

      if(!lpCurMainKeyHdr->OptionKeyWords.w.length)
         continue ;   //  there's nothing here!
                     //  optionIndex and lpOptionInfo[optionIndex] 
                     //  is undefined.

      for(curState = i ; 1 ; )
      {
         optionIndex = lpOptionState[curState].optionKeyIndex ;
         constrntIndex = lpOptionInfo[optionIndex].UIconstraintIndex ;

         while(constrntIndex != 0xFFFF)  
         {                // evaluate each element in constraint list
            if(lpUIconstraints[constrntIndex].MainKeyIndex == MainKeywordIndex)
            {

               if(lpUIconstraints[constrntIndex].OptionKeyIndex == 0xFFFE) 
               {                // disable all but none or false
                  for(j = 0 ; j < numOptions ; j++)
                     lpOptionArray[j] = FALSE ;  // don't assume first option is None

                  lpOptionArray[lpPrinterInfo->mainKeyHdrs[MainKeywordIndex].NoneOptionIndex] = TRUE ;
                     // Only the None option is spared.

                  if(lpUIConflict  &&  
                     !lpOptionArray[lpOldOptionState[MainKeywordIndex].optionKeyIndex] )
                  {
                     // note we check only the first option when there
                     // could be multiple options selected.
                     // Well if the first option is unconstrained, this implies
                     // it is the 'None' option and by definition
                     // 'None'  mutually excludes any other option
                     // from being selected.
                     // Thus further evaluation is unecessary.
                     // and if the first option is constrained, then
                     // we must fill out the lpUIConflict structure.


                     lpUIConflict->wMainConstrainer = i ;
                     lpUIConflict->wOptionConstrainer = optionIndex ;
                     lpUIConflict->wMainConstrained = MainKeywordIndex ;
                     lpUIConflict->wOptionConstrained = 
                        lpOldOptionState[MainKeywordIndex].optionKeyIndex ;

                     lpUIConflict = NULL ;
                  }
                  return(TRUE);  // Evaluation of remaining constraints
                                 // is either redundant or would lead
                                 // to disablement of the last surviving
                                 // option, which is illegal.
               }
               else
               {
                  lpOptionArray[lpUIconstraints[constrntIndex].OptionKeyIndex] = FALSE ;
                  if(lpUIConflict)  
                  {
                     BOOL  doit = FALSE;
                     WORD    oldState ;

                     //  evaluate chain of old options:
                     for(oldState = MainKeywordIndex ; 1 ; )
                     {
                        if(lpOldOptionState[oldState].optionKeyIndex == 
                           lpUIconstraints[constrntIndex].OptionKeyIndex)
                        {
                           doit = TRUE ;
                           break ;  // we found what we came for.
                        }
                        if((oldState = lpOldOptionState[oldState].nextState) == 0xFFFF)
                           break;
                     }

                     if(doit)
                     {
                        lpUIConflict->wMainConstrainer = i ;
                        lpUIConflict->wOptionConstrainer = optionIndex ;
                        lpUIConflict->wMainConstrained = MainKeywordIndex ;
                        lpUIConflict->wOptionConstrained =  
                                 lpUIconstraints[constrntIndex].OptionKeyIndex ;

                        lpUIConflict = NULL ;
                     }
                  }
               }
            }
            constrntIndex = lpUIconstraints[constrntIndex].nextIndex ;
         }
         if((curState = lpOptionState[curState].nextState) == 0xFFFF)
            break;
      }
   }   

   if(MainKeywordIndex == IND_INPUTSLOTINFO  &&  
         lpPrinterInfo->devcaps.MixedBins != 0xFFFF)
   {
      BOOL  bUpper = FALSE, bLower = FALSE ;
      WORD  j, iMixedBins = lpPrinterInfo->devcaps.MixedBins ;
      LPINPUTSLOTINFO    lpInputSlotInfo ;

      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;

      lpInputSlotInfo = (LPINPUTSLOTINFO)MAKELONG(
         lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );


      for(j = 0 ; j < numOptions ; j++)
      {
         if(lpInputSlotInfo[j].slotID == DMBIN_UPPER  &&  lpOptionArray[j] )
            bUpper = TRUE ;
         else if(lpInputSlotInfo[j].slotID == DMBIN_LOWER  &&  lpOptionArray[j] )
            bLower = TRUE ;
      }
      if(!(bUpper && bLower))  //  if either is FALSE.
         lpOptionArray[iMixedBins] = FALSE ;
   }
   return(TRUE);  
}




LPPSEXTDEVMODE FAR PASCAL PsExtDevmodeCreateCopy(LPPSEXTDEVMODE lpSrcDM)
{
   LPPSEXTDEVMODE   lpNewDM ;

   lpNewDM = (LPPSEXTDEVMODE)GlobalAllocPtr(GDLLHND, sizeof(PSEXTDEVMODE));
   if(lpNewDM)
      *lpNewDM = *lpSrcDM ;
   return(lpNewDM) ;
}

BOOL FAR PASCAL PsExtDevmodeCopy(LPPSEXTDEVMODE lpDestination, LPPSEXTDEVMODE lpSource)
{
   if(lpDestination && lpSource)
   {
      *lpDestination = *lpSource ;
      return(TRUE);
   }
   
   return(FALSE);
}

BOOL FAR PASCAL PsExtDevmodeRead(LPPSEXTDEVMODE lpPSExtDevmode, 
LPSTR lpszModelName, 
LPSTR lpszPort)  // serves no purpose.
{
   LPWPXBLOCKS   lpWPXblock ;
   BOOL   status ;

   lpWPXblock = GetPrinter(lpszModelName) ;
   if(!lpWPXblock)
      return(FALSE);

   status = InitDefaultDevmode(lpWPXblock, lpPSExtDevmode, lpszModelName) ;
   FreePrinter(lpWPXblock) ;

   return(status);
}



BOOL FAR PASCAL PsExtDevmodeDestroy(LPPSEXTDEVMODE  lpDM)
{
   GlobalFreePtr(lpDM);
   return TRUE;
}

WORD FAR PASCAL GetOpenUIKeywordIndex(LPPDEVICE  lppd ,
                                      LPSTR      lpOpenUIKeyword)
{
    LPMAINKEYHDR  lpCurMainKeyHdr;
    WORD          numOpenUIs;
    LPPRINTERINFO lpPrinterInfo;
    WORD          i;
    LPBYTE        lpString;
    STRINGREF     stringRef;

    lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo ;
    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_NUMPREDEFINEDHDRS;
    numOpenUIs = lpPrinterInfo->numMainKeyHdrs - IND_NUMPREDEFINEDHDRS;
 
    i = 0;
    while(i < numOpenUIs)
    {
        stringRef.dword = lpCurMainKeyHdr->MainKey.dword;
        lpString = StringRefToLPBYTE(lppd, stringRef.dword );
        if(lstrcmp(lpOpenUIKeyword, lpString) == 0)
        {
            return i + IND_NUMPREDEFINEDHDRS;
        }
        else
        {
            i++;
            lpCurMainKeyHdr++;
        }
    }
    return 0xFFFF;
}

