/*  note:  Gray Levels and Color Separations are not yet supportted
       in this wpx file.
*/


#ifndef PRINTCAP_DEFINED

#define PRINTCAP_DEFINED

// increment this define, 4.2.1 add web printer support
#define  WPXVERSION   22  // increment this every time these structures change!

#define  MAX_JOBPATCHES  20
#define  MAXKEYLEN  40
#define _MAX_PATH   260
#define GDLLHND   (GHND | GMEM_SHARE)

#define ICM_MANUFACTURER_LEN   4
#define ICM_MODEL_NAME_LEN     4

// note! this list also determines the order in which these
// invocations are sent, (in the absence of explicit OrderDependency
// statements).  The invocation with the largest index is sent first!

#define  IND_PAPERINFO      0
#define  IND_PAGEREGIONINFO 1   // use generic option struct
#define  IND_DUPLEXINGINFO  2   // use generic option struct
#define  IND_INPUTSLOTINFO  3
#define  IND_RESOLUTIONINFO 4  
#define  IND_OUTPUTBININFO  5   // use generic option struct
#define  IND_MEDIATYPEINFO  6   // use generic option struct
#define  IND_MEMORYINFO     7
// RS #define  IND_NUMPREDEFINEDHDRS  8   // one more than last value.
#define  IND_COLLATIONINFO   8
#define  IND_OUTPUTORDERINFO 9
#define  IND_NUMPREDEFINEDHDRS  10   // one more than last value.
// RS


typedef  BYTE  _huge  *HPBYTE;
typedef  HPBYTE  far  *LPHPBYTE;
typedef  LPBYTE  far  *LPLPBYTE;
typedef  short  int  far  *LPSHORT;
typedef  BOOL  far  *  LPBOOL ;

typedef  enum  {TTRAST_NONE, TTRAST_68K, TTRAST_TYPE42, TTRAST_TRUEIMAGE, TTRAST_TYPE42BUGGY} TTRAST_OPT ;
typedef  enum  {ANYWHERE, ATEXITSERVER, PROLOG, DOCSETUP, PAGESETUP, JCLSETUP, ANYSETUP}  SECTION;
typedef  enum  {TYPOINTS, INTS, REALS} UNITS ;
typedef  enum  {NATURAL_UNITS, INCHES_100, MILLIMETERS_10}  DSPUNITS ;
typedef  enum  {UI_NONE, PICKONE, PICKMANY, BOOLEAN } UITYPE ;
typedef  enum  {DUPLEX_NONE, DUPLEXNOTUMBLE, DUPLEXTUMBLE, SIMPLEXTUMBLE, 
                            NUM_DUPLEX_MODES} DUPLEX_MODES ;
typedef  enum  {COLLATE_FALSE, COLLATE_TRUE, NUM_COLLATE_MODES} COLLATE_MODES ;
typedef  enum  {OUTPUTORDER_NORMAL, OUTPUTORDER_REVERSE, NUM_OUTPUTORDER_MODES} OUTPUTORDER_MODES ;
typedef  enum  {NOENCODING, ISOLATIN1} ENCODING ;

typedef  enum  {ASCII= 1, BCP, TBCP, BINARY} DEFAULTPROTOCOL;

typedef  union  tagSTRINGREF
{
    DWORD    dword ;
    struct  
    {
        WORD  offset;  // loword
        WORD  length;  // hiword
    } w ;
}  STRINGREF , *PSTRINGREF, FAR *LPSTRINGREF,
    ARRAYREF  , *PARRAYREF,  FAR *LPARRAYREF;


typedef struct tagORDER
{
 //   SECTION  section;      what section may command appear in ?
    WORD   ArrayIndex;  //  init to 0xFFFF to indicate end of list.
                              //  init to 0xFFFE to indicate not linked.
                              //  points to next MainKeyHdr or option
    double  PPDorderValue ;  // this is useless after mainKeyIndex
}  ORDER ;                 //  is initialized, linking all main keys together.



typedef  struct  tagDEVCAPS
{
   BOOL  color;
   BYTE  languageLevel;
   ENCODING  LanguageEncoding ;
   BOOL  PJLsupport ;         //  if FALSE, there's nothing in JCLINFO
   BOOL  BCPsupport ;
   BOOL  TBCPsupport ;
   BOOL  SupportsDuplexing ; 
   BOOL  bOutputOrderSupport;
   BOOL  bCollateSupport;    
   
#ifdef Adobe_Driver
   BOOL  bFaxSupport;          // True if support fax
#endif
    
    //  these indicies are set to 0xFFFF if input slot (or paper) option 
    //  not availible.  Else contains array index of option.

   WORD  AutoSense ;
   WORD  MixedBins ;       
   WORD  ManualFeed ;      //  index to Manual Feed if availible.
   WORD  CustomPageSize ;  //  index to CustomPage size option 

   BOOL  landscapeOrientPlus90 ;  //  True if 90 , else is 270
   BOOL  TrueImageSupport ;
   TTRAST_OPT  TTRasterizer ;   //   TT font rasterizer type.

#if 0   // not part of PPD file.
   BOOL  LeadingControlD ;     //  true if control D is to be added
   BOOL  TrailingControlD ;    //  to print stream.
#endif

   DWORD iFreeVM;              // Printer Memory (in KB)
   WORD  iFontCacheSize;       // 1st entry as default
   BOOL  bFontCacheSize;       // Printer Font Cache size
   BOOL  DefaultToPortability; // this is a hack for QMS.
   DEFAULTPROTOCOL  iDefaultProtocol;     // *ADDefaultProtocol if it is not specified = 0
                               // 1 - ASCII 2 - BCP 3 - TBCP 4- PJL
   WORD  JobTimeout;           // PPD suggested job timeout
   WORD  WaitTimeout;          // PPD suggested wait timeout
   BOOL  bPrintPSErrors;       // printer error to display in device
   WORD  PrintPSErrorExist;    // mark *PrinterPSErrors exist
            
   WORD  iAdHasEuro;           // PPD setting for *AdHasEuro: 0=FALSE, 1=TRUE, 0xFFFF=does not exist in PPD

}  DEVCAPS, *PDEVCAPS, FAR *LPDEVCAPS;


typedef struct tagJCLINFO  // init only if JCLcapable == TRUE !
{
    STRINGREF   JCLBegin ;  // init to default for HP printers
    STRINGREF   JCLToPSInterpreter ;  // init with null string
    STRINGREF   JCLEnd   ;  // init to default for HP printers

} JCLINFO, FAR *LPJCLINFO ;


typedef  struct  tagPARAM
{
    BYTE       order ;  //  order of params on stack
    UNITS      units ;  
    int        min   ;  //  minimum allowed value
    int        max   ;  //  max allowed value.
} PARAM, *PPARAM, FAR *LPPARAM;


typedef  struct  tagFPARAM
{
   BYTE       order ;  //  order of params on stack
   UNITS      units ;  
   float      min   ;  //  minimum allowed value
   float      max   ;  //  max allowed value.
} FPARAM, *PFPARAM, FAR *LPFPARAM;

typedef  struct  tagCUSTPAGEINFO
{
   //  bSupported   Check    if(CustomPageSize != 0xFFFF) in DEVCAPS
    STRINGREF Invocation ;    // Enable custom page  (equv to PageRegion)
    WORD    MaxMediaWidth ; // sum of width and widthOffset must not exceed
    RECT    HWmargins;      // width of margins
   BOOL    isCutSheet ;    // true if this is a CutSheet instead of roll fed.
    PARAM   width ;         // fast scan dimension
    PARAM   height ;        // slow scan (feed) dimension
    PARAM   widthOffset ;   // allows paper to be surrounded with
    PARAM   heightOffset ;  // margins (Extra size) 
    PARAM   Orientation ;   // normal or transverse (is x-axis along fast scan?)
} CUSTPAGEINFO, *PCUSTPAGEINFO, FAR *LPCUSTPAGEINFO;



typedef struct tagMAINKEYHDR
{
    WORD         MainKeyID;            // keyword index for OpenUI entries
    STRINGREF    MainKey;        //   null terminated mainKeyword
    STRINGREF    MainTranslation;   // translation string for mainKeyword
    STRINGREF    OptionQuery;   // future expansion - reqs BiDi.
    ORDER     order;  //  order relative to other commands ?
    WORD      OrderListRoot;   //  init to 0xFFFF - nothing in list
    UITYPE   UItype ;  //  enumeration of {UI_NONE, PICKONE, PICKMANY, BOOLEAN }
        // NONE might mean there are no options availible for this keyword.
    ARRAYREF    OptionKeyWords ;  // num of elements in the option array.
                                            // and offset to start of array!
    WORD        extraOptionArray ;  // offset to array of additional info
    WORD        DefaultOptionIndex ; // set to -1 to indicate printer has no default.
                    // used only to initialize current selection in devmode.
   WORD        NoneOptionIndex ;  // which option is "None" or "False" ?
               // set to 0xFFFF  if no such option exists.
   WORD        flags ;  //  wpxParser use only.  see KEYENTRY struct.
}  MAINKEYHDR, FAR *  LPMAINKEYHDR; 



typedef struct tagGENERIC_OPTION
{
    STRINGREF    OptionKey;        //  null terminated OptionKeyword
    STRINGREF    OptionTranslation;   // translation string for OptionKeyword
    STRINGREF    Invocation;   // translation string for mainKeyword
    WORD        UIconstraintIndex ;  //  if not 0xFFFF, points to linked list of incompatible options.
    ORDER       order  ;     //  used if PICKMANY, init to 0xFFFE for unused
}  GENERIC_OPTION, FAR *  LPGENERIC_OPTION  ;



typedef  struct  tagRESOLUTIONINFO
{
    union
    {
        DWORD    dword ;
        struct  
        {
            WORD  x;  // loword
            WORD  y;  // hiword
        } word ;
    }  res ;

    DWORD  ScreenFreq;          //  Tenths of an inch
    DWORD  ScreenAngle;         //  Tenths of a degree
                                      
} RESOLUTIONINFO, *PRESOLUTIONINFO, FAR *LPRESOLUTIONINFO;


typedef  struct  tagMEMORYINFO
{
    DWORD      AvailibleVM ;  // VM associated with this InstalledMemory option
   WORD       AvailibleFC ; // Font Cache size available for this memory module
} MEMORYINFO, *PMEMORYINFO, FAR *LPMEMORYINFO;


typedef  struct  tagSLOTINFO
{
    WORD       slotID ;      // assign a predefined ID or a value above 256
    BOOL       ReqsPageRegion; //  must PageRegion follow InputSlot command ?
} INPUTSLOTINFO, *PINPUTSLOTINFO, FAR *LPINPUTSLOTINFO;
                                        //  manual feed is treated as another slot.

typedef  struct  tagPAPERINFO
{
    WORD       paperID ;      // assign a predefined ID or a value above 256
    WORD       width, length; // store as 1/72's of an inch.
//   DSPUNITS   NaturalUnit;   // Unit of display for this paper
    RECT       imageableArea; // location in 1/72 of an inch - Pscript coorids
} PAPERINFO, *PPAPERINFO, FAR  *LPPAPERINFO;



typedef struct tagFONTLIST 
{
    STRINGREF      fontname;
    STRINGREF      familyname;
    BOOL           custom;        //  TRUE if custom font.
   WORD           index;            //  Index of font in
   STRINGREF      version;
                                            // fontcache (Used as a hint for fast access).
} FONTLIST, FAR *LPFONTLIST;



typedef struct tagORDERROOT 
{
    WORD     ExitServer,
                Prolog,
                Unassigned,  // sent just before any in DocumentSetup.
                DocumentSetup,
                PageSetup,
                JCLSetup,
                AnySetup;   // only used by parser, not by driver.
} ORDERROOT, FAR *LPORDERROOT;
     

typedef struct tagPRINTERINFO
{
    STRINGREF    fileID;            // verbatim copy of first line in PPD file
   STRINGREF    PCFileName ;       // string value of *PCFileName
   STRINGREF    Product    ;       // string value of *Product
   STRINGREF    PSVersion  ;       // string value of *PSVersion
   STRINGREF    PPDVersion ;       // string value of *PPD-Adobe 

    WORD         versionNum;        // Set to WPDVERSION
    STRINGREF    modelname;         // Name of printer model - 
        // by whichever exists in this priority: shortnickname, modelname, nickname
   STRINGREF    RealModelName;     // string value of *ModelName.  (118385) jjia. 10/18/95
   STRINGREF    Manufacturer;      // string value of *Manufacture.(118385) jjia. 10/18/95

   BYTE   ICMManufacturer[ICM_MANUFACTURER_LEN+1]; // icm manufacturer name in registry
   BYTE   ICMModelName   [ICM_MODEL_NAME_LEN+1];   // icm model name in registry

    DWORD  dwPPDchecksum,  // initialized during WPX creation.
           dwRandom;      // verifies we are dealing with the same printer
                            //  instance.
   DWORD  dwDrvrLMT,    // Last Modified Time of pscript.drv
          dwPPDLMT;     // Same for PPD file - WPX file will be 
                             // recreated if driver or PPD file changes.
    DEVCAPS      devcaps ;          // describes printer features
    STRINGREF    disableManFeed;    // issued before any slot selection
    CUSTPAGEINFO custpageinfo;      // info for specifying custom pages
    STRINGREF    password;          // Password from PPD file
    STRINGREF    exitServer;        // ExitServer from PPD file
    STRINGREF    PatchFile    ;     // PatchFile
   WORD        nJobPatchFiles ;    // how many entries in array are valid?

   struct
   {
      WORD        order ;  //  the 'option' value
      STRINGREF   invoc ;  //  the patch to be downloaded
   } JobPatchFile[MAX_JOBPATCHES] ;     // JobPatchFile Array

    JCLINFO      JCLinfo;           // contains hexstrings for various JCL
                                              // commands if any.

    WORD         InstallableOptions; //  mainkeyhdrs with indicies equal to
                                              //  or larger than this value are 
                                              //  installable options.
                                              //  init to 0xFFFF if none.
    ARRAYREF     FontList  ;        //  List of device fonts
   STRINGREF    CustomFontFile ;
    ORDERROOT    OrderListRoot  ;   //  index of MainKeyHdr which is start of linked order list
    WORD         numMainKeyHdrs ;   //  num elements in array.
    
// OEMPLUGI begin
   BOOL         bOEMExist;         // TRUE => Found OEM Dll.
   WORD         numOEMDocSticky;   //  number of bytes reserved for OEM DocSticky 
// OEMPLUGI end

//#ifdef ADOBE_WEB
   char szWebURL[128]     ;       // string value of *WEBURL
   char szWebServer[128]  ;       // string value of *WEBServer
   char szWebPort[32]     ;       // string value of *WEBPort
   char szWebPrinter[128] ;       // string value of *WEBPrinter
   char szWebPrinterName[64];     // string value of *WEBPrinterName
   char szWebCommProtocol[10];    // string value of *WEBCommProtocol
   char szWebPPD[32]      ;       // string value of *WEBPPD
   char szWebNotice[256]  ;       // string value of *WEBNotice
//#endif

    ARRAYREF     PrinterSticky  ;    //  Index range occupied by printerSticky mainKeyHdrs
    ARRAYREF     DocSticky  ;        //  Index range occupied by DocSticky mainKeyHdrs
    MAINKEYHDR   mainKeyHdrs[0] ;        // start of array of mainKeyHeaders

} PRINTERINFO, *PPRINTERINFO, FAR *LPPRINTERINFO;



typedef struct tagUI_CONSTRAINTS
{
    WORD        MainKeyIndex  ;      //   specifies particular MainKey
    WORD        OptionKeyIndex ;       //   specifies particular option
                                                //  may be set to 0xFFFF if it was omitted
    WORD        nextIndex ;  //  if not 0xFFFF, points to next incompatible option.
}  UI_CONSTRAINTS, FAR *  LPUI_CONSTRAINTS ;





typedef struct tagWPX_HEADER
{ 
    DWORD PrinterInfo_loc;  // offset from start of file.
    WORD  PrinterInfo_len;  // always expressed in bytes.
    DWORD OptionArray_loc;  // arrays of structure for each option keyword
    WORD  OptionArray_len;
    DWORD stringtab_loc;    // heap for string storage
    WORD  stringtab_len;
    DWORD UI_constraint_loc;  // list of UI constraints
    WORD  UI_constraint_len;
} WPX_HEADER, FAR *LPWPX_HEADER;   


#if 0
-----
/* alternative to generic handling, don't want to support
it since generic approach works and don't want to special
case OrderDependency info for this one case. */



typedef  struct  tagPRINTMODE
{
    COMMAND    MirrorPrintOn ;     //  if these exist should they
    COMMAND    MirrorPrintOff ;    //  be used instead of our informal
    COMMAND    NegativePrintOn ;   //  methods?  yes, especially for 
    COMMAND    NegativePrintOff ;  //  color and grayscale printers.
} PRINTMODE, *PPRINTMODE, FAR *LPPRINTMODE;

#endif


typedef struct   //  points to 3 global blocks
{
     LPBYTE  WPXprinterInfo;  // printInfo struct and mainkeyword arrays
     LPBYTE  WPXarrays;  // other variable len arrays
     LPBYTE  WPXstrings  ;  // string table (begins at offset zero)
     LPUI_CONSTRAINTS  WPXconstraints ;  // Pointer to array of UI constraints.


}  WPXBLOCKS, far  *  LPWPXBLOCKS;




#endif    // PRINTCAP_DEFINED

