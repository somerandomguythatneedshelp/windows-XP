/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1994 Adobe Systems, Inc. All rights reserved.               */
/*                                                                           */
/* Module Name: OEMSTUBS.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for OEM Customization     */
/*                                                                           */
/*****************************************************************************/
#include "generic.h"

extern LPBYTE   lpStringPtr ;  //  points to uninitialized portion of string table.
extern HBITMAP WINAPI LoadBitmap(HINSTANCE, LPCSTR);
extern BOOL FAR PASCAL IsWebPrinter (LPSTR);
void FAR PASCAL initMainKeyWordsTableStub(void);
int FAR PASCAL GetShowAlert(void);
int FAR PASCAL SetShowAlert(int);
PSInjectionPoint FAR PASCAL GetAPPInjectID(DWORD PSIndex, int *lpInjectType);
void FAR PASCAL SendPSInjectionData(LPPDEVICE lppd, PSInjectionPoint PSInjectID,
                                                    LPSTR FAR *lplpDriverPS,
                                            unsigned FAR *lpDriverPSLen);
BOOL FAR PASCAL ICMProfileInstalled(LPPRINTERINFO lpPrinterInfo, LPSTR lpFriendlyName);

WORD NEAR lstrncpy( LPSTR lpDest, LPSTR lpSrc, WORD size )
{  WORD nbyte = 0;

   if( lpSrc && lpDest && size > 0 )
   {
      WORD i, len = lstrlen( lpSrc ) + 1;
      nbyte = size > len ? len : size;

      for( i=0; i<nbyte; i++ )
         lpDest[i] = lpSrc[i];
   }
   return( nbyte );
}

#ifdef Adobe_Driver
/************************************************************************/
/*  BEGIN FILTER FUNCTIONS                                              */
/************************************************************************/

/************************************************************************/


void NEAR PASCAL SetOEMFilterInfo(LPOEMFILTERINFO    lpFilterInfo,
                                  LPOEMFILTERHEADER  lpOEMFilterHeader,
                                  LPBYTE             lpOEMData
                                 )
{
    if (lpFilterInfo && lpOEMFilterHeader && lpOEMData)
    {
        lpFilterInfo->wDataSize = lpOEMFilterHeader->refOEMData.w.length;
        if (lpOEMFilterHeader->refOEMData.w.length)
            lpFilterInfo->lpOEMData = lpOEMData + lpOEMFilterHeader->refOEMData.w.offset;
        else
            lpFilterInfo->lpOEMData = NULL;

        // Module name is always required.
        lpFilterInfo->lpModuleName = lpOEMData + lpOEMFilterHeader->refModuleName.w.offset;

        if (lpOEMFilterHeader->refOEMData.w.length)
            lpFilterInfo->lpUserString = lpOEMData + lpOEMFilterHeader->refUserString.w.offset;
        else
            lpFilterInfo->lpUserString = NULL;
    }
}

/************************************************************************/

LPOEMFILTERINFO NEAR PASCAL BuildOEMFilterInfoArray(LPPDEVICE lppd)
{
    LPOEMFILTERINFO     lpFilterInfo, lpCurrentFilterInfo;
    LPOEMFILTERHEADER   lpOEMFilterHeader;

    if (lppd->wcOEMFilter)
    {   // if there is a registered filter
        lpOEMFilterHeader = (LPOEMFILTERHEADER)GlobalLock(lppd->hOEMFilterData);
        if (lpOEMFilterHeader)
        {
            lpFilterInfo = (LPOEMFILTERINFO)GlobalAllocPtr(GMEM_DDESHARE|GHND,
                                    (sizeof(OEMFILTERINFO) * lppd->wcOEMFilter) + lppd->cbOEMDataSize);
            if (lpFilterInfo)
            {
                LPBYTE  lpOEMDataSrc, lpOEMDataDest;
                int     i;

                lpOEMDataDest = (LPBYTE)lpFilterInfo + (lppd->wcOEMFilter * sizeof(OEMFILTERINFO));
                lpOEMDataSrc = (LPBYTE)lpOEMFilterHeader + (sizeof(OEMFILTERHEADER) * MAX_OEMFILTER);
                _fmemcpy(lpOEMDataDest, lpOEMDataSrc, (size_t)lppd->cbOEMDataSize);
                for (i = 0, lpCurrentFilterInfo = lpFilterInfo;
                     i < MAX_OEMFILTER;
                     i++, lpOEMFilterHeader++)
                {
                    if (lpOEMFilterHeader->refModuleName.w.length)
                    {
                        SetOEMFilterInfo(lpCurrentFilterInfo, lpOEMFilterHeader, lpOEMDataDest);
                        lpCurrentFilterInfo++;
                    }
                }
            }
        }
        GlobalUnlock(lppd->hOEMFilterData);
    }
    return lpFilterInfo;
}

/************************************************************************/

HANDLE FAR PASCAL OEMOpenJobStub(HANDLE    hContext,
                                 LPSTR     lpOutput,
                                 LPSTR     lpTitle,
                                 HDC       hDC,
                                 WORD      wFilters,
                                 LPOEMFILTERINFO lpFilterInfo
                                )
{
    LPOEMINFO   lpOEMInfo;
    HANDLE      hJob;

    hJob = (HANDLE)SP_ERROR;
    if (hContext)
    {
        if( lpOEMInfo = (LPOEMINFO)GlobalLock(hContext) )
        {
           if (FILTEROUTPUT(lpOEMInfo))
           {
              hJob = lpOEMInfo->lpOEMOpenJob(lpOutput, lpTitle, hDC, wFilters, lpFilterInfo);
              if( !hJob ) hJob = (HANDLE)SP_ERROR;
           }
           GlobalUnlock(hContext);
        }
        else hJob = (HANDLE)SP_OUTOFMEMORY;
    }
    return hJob;
}

/************************************************************************/

HANDLE FAR PASCAL CallOEMOpenJobStub(LPPDEVICE lppd,
                                     LPSTR  lpOutput,
                                     LPSTR  lpTitle,
                                     HDC    hDC
                                    )
{
    LPOEMFILTERINFO  lpFilterInfo;
    HANDLE           hJob;

    hJob = (HANDLE)NULL;

    if (lppd->wcOEMFilter)
    {
        lpFilterInfo = BuildOEMFilterInfoArray(lppd);

        if (lpFilterInfo)
        {
            if (!hJob && lppd->hAppIsv )
               hJob = OEMOpenJobStub(lppd->hAppIsv, lpOutput, lpTitle, hDC, lppd->wcOEMFilter, lpFilterInfo);
            if (!hJob && lppd->hWebPrinter )
                hJob = OEMOpenJobStub(lppd->hWebPrinter, lpOutput, lpTitle, hDC, lppd->wcOEMFilter, lpFilterInfo);
            if (!hJob && lppd->hPSFax )
                hJob = OEMOpenJobStub(lppd->hPSFax, lpOutput, lpTitle, hDC, lppd->wcOEMFilter, lpFilterInfo);
            if (!hJob && lppd->hOemCust )
                hJob = OEMOpenJobStub(lppd->hOemCust, lpOutput, lpTitle, hDC, lppd->wcOEMFilter, lpFilterInfo);
            GlobalFreePtr(lpFilterInfo);
        }
    }
    if( !hJob )
    {
        hJob = OpenJob(lpOutput, lpTitle, hDC);
    }
    return hJob;
}

/************************************************************************/
int FAR PASCAL OEMStartSpoolPageStub(HANDLE hContext, HANDLE hJob)
{
    LPOEMINFO lpOEMInfo;
    int       retVal = 0;

    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        if (FILTEROUTPUT(lpOEMInfo))
        {
            retVal = lpOEMInfo->lpOEMStartSpoolPage(hJob);
        }
        if (lpOEMInfo)
            GlobalUnlock(hContext);
    }
    return retVal;
}

/************************************************************************/

int FAR PASCAL CallOEMStartSpoolPageStub(LPPDEVICE lppd)
{

    int       retVal;

    retVal = OEMStartSpoolPageStub(lppd->hAppIsv, lppd->hPortHandle);
    if (!retVal)
        retVal = OEMStartSpoolPageStub(lppd->hWebPrinter, lppd->hPortHandle);
    if (!retVal)
        retVal = OEMStartSpoolPageStub(lppd->hPSFax, lppd->hPortHandle);
    if (!retVal)
        retVal = OEMStartSpoolPageStub(lppd->hOemCust, lppd->hPortHandle);
    if (!retVal)
        retVal = StartSpoolPage(lppd->hPortHandle);
    return retVal;
}

/************************************************************************/

int FAR PASCAL OEMWriteSpoolStub(HANDLE hContext,
                                 HANDLE hJob,
                                 LPSTR  lpData,
                                 WORD   cch
                                )
{
    LPOEMINFO lpOEMInfo;
    int       retVal;

    retVal = 0;
    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        if (FILTEROUTPUT(lpOEMInfo))
        {
            retVal = lpOEMInfo->lpOEMWriteSpool(hJob, lpData, cch);
        }
        GlobalUnlock(hContext);
    }
    return retVal;
}

/************************************************************************/

int FAR PASCAL CallOEMWriteSpoolStub(LPPDEVICE lppd,
                                     LPSTR  lpData,
                                     WORD   cch
                                    )
{
    int     retVal;

    lppd->job.bfInWriteSpool = TRUE;

    retVal = OEMWriteSpoolStub(lppd->hAppIsv, lppd->hPortHandle, lpData, cch);
    if (!retVal)
        retVal = OEMWriteSpoolStub(lppd->hWebPrinter, lppd->hPortHandle, lpData, cch);
    if (!retVal)
        retVal = OEMWriteSpoolStub(lppd->hPSFax, lppd->hPortHandle, lpData, cch);
    if (!retVal)
        retVal = OEMWriteSpoolStub(lppd->hOemCust, lppd->hPortHandle, lpData, cch);
    if (!retVal)
        retVal = WriteSpool(lppd->hPortHandle, lpData, cch);

    lppd->job.bfInWriteSpool = FALSE;

    return retVal;
}

/************************************************************************/
int FAR PASCAL OEMEndSpoolPageStub(HANDLE hContext, HANDLE hJob)
{
    LPOEMINFO       lpOEMInfo;
    int             retVal;

    retVal = 0;
    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        if (FILTEROUTPUT(lpOEMInfo))
        {
            retVal = lpOEMInfo->lpOEMEndSpoolPage(hJob);
        }
        GlobalUnlock(hContext);
    }
    return retVal;
}

/************************************************************************/

int FAR PASCAL CallOEMEndSpoolPageStub(LPPDEVICE lppd)
{
    int       retVal = 0;

    retVal = OEMEndSpoolPageStub(lppd->hAppIsv, lppd->hPortHandle);
    if (!retVal)
        retVal = OEMEndSpoolPageStub(lppd->hWebPrinter, lppd->hPortHandle);
    if (!retVal)
        retVal = OEMEndSpoolPageStub(lppd->hPSFax, lppd->hPortHandle);
    if (!retVal)
        retVal = OEMEndSpoolPageStub(lppd->hOemCust, lppd->hPortHandle);
    if (!retVal)
        retVal = EndSpoolPage(lppd->hPortHandle);
    return retVal;
}

/************************************************************************/

int FAR PASCAL OEMDeleteJobStub(HANDLE  hContext,
                                HANDLE  hJob,
                                WORD    wDummy
                               )
{
    LPOEMINFO lpOEMInfo;
    int       retVal;

    retVal = 0;
    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        if (FILTEROUTPUT(lpOEMInfo))
        {
            retVal = lpOEMInfo->lpOEMDeleteJob(hJob, wDummy);
        }
        GlobalUnlock(hContext);
    }
    return retVal;
}

/************************************************************************/

int FAR PASCAL CallOEMDeleteJobStub(LPPDEVICE lppd,
                                    WORD    wDummy
                                   )
{
    int       retVal;

    retVal = OEMDeleteJobStub(lppd->hAppIsv, lppd->hPortHandle, wDummy);
    if (!retVal)
        retVal = OEMDeleteJobStub(lppd->hWebPrinter, lppd->hPortHandle, wDummy);
    if (!retVal)
        retVal = OEMDeleteJobStub(lppd->hPSFax, lppd->hPortHandle, wDummy);
    if (!retVal)
        retVal = OEMDeleteJobStub(lppd->hOemCust, lppd->hPortHandle, wDummy);
    if (!retVal)
        retVal = DeleteJob(lppd->hPortHandle, wDummy);

    return retVal;

}

/************************************************************************/
int FAR PASCAL OEMCloseJobStub(HANDLE hContext, HANDLE hJob)
{
    LPOEMINFO lpOEMInfo;
    int       retVal;

    retVal = 0;
    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        if (FILTEROUTPUT(lpOEMInfo))
        {
            retVal = lpOEMInfo->lpOEMCloseJob(hJob);
        }
        GlobalUnlock(hContext);
    }
    return retVal;
}


int FAR PASCAL CallOEMCloseJobStub(LPPDEVICE lppd)
{
    int       retVal;

    retVal = OEMCloseJobStub(lppd->hAppIsv, lppd->hPortHandle);
    if (!retVal)
        retVal = OEMCloseJobStub(lppd->hWebPrinter, lppd->hPortHandle);
    if (!retVal)
        retVal = OEMCloseJobStub(lppd->hPSFax, lppd->hPortHandle);
    if (!retVal)
        retVal = OEMCloseJobStub(lppd->hOemCust, lppd->hPortHandle);
    if (!retVal)
        retVal = CloseJob(lppd->hPortHandle);

    return retVal;

}

/************************************************************************/

BOOL NEAR PASCAL OEMAddFilter(LPPDEVICE lppd,
                              LPSTR     lpModuleName,
                              LPSTR     lpUserString,
                              WORD      cbDataSize,
                              LPBYTE    lpData,
                              OEMFILTER_TYPE flType
                             )
{
    BOOL    retVal;
    unsigned int cbSize;
    DWORD   cbCurrentOffset;
    LPBYTE  lpOEMData;
    WORD    wLen;

    retVal = FALSE;

    if ((lppd == (LPPDEVICE)NULL) ||
        (flType > MAX_OEMFILTER) ||
        (lpModuleName == (LPSTR)NULL) ||
        (lstrlen(lpModuleName) == 0)
       )
        return retVal;

    if (lpModuleName)
        cbSize = lstrlen(lpModuleName) + 1;
    if (lpUserString)
        cbSize += lstrlen(lpUserString) + 1;
    if (lpData)
        cbSize += cbDataSize;

    if (lppd->hOEMFilterData == (HANDLE)NULL)
    {
        lppd->hOEMFilterData = GlobalAlloc(GHND, cbSize + (sizeof(OEMFILTERHEADER) * MAX_OEMFILTER));
        cbCurrentOffset = 0;
    }
    else {
        lppd->hOEMFilterData = GlobalReAlloc(lppd->hOEMFilterData,
                                             lppd->cbOEMDataSize + cbSize + (sizeof(OEMFILTERHEADER) * MAX_OEMFILTER),
                                             GMEM_MOVEABLE);
        cbCurrentOffset = lppd->cbOEMDataSize;
    }
    if (lppd->hOEMFilterData)
    {
        LPOEMFILTERHEADER   lpOEMFilterHeader;

        lpOEMData = GlobalLock(lppd->hOEMFilterData);
        if (lpOEMData)
        {
            lpOEMFilterHeader = (LPOEMFILTERHEADER)lpOEMData + flType;

            if (lpData && cbDataSize)
            {
                lpOEMFilterHeader->refOEMData.w.offset = (WORD)cbCurrentOffset;
                lpOEMFilterHeader->refOEMData.w.length = (WORD)cbDataSize;
                cbCurrentOffset += cbDataSize;
            }

            if (lpModuleName)
            {
                wLen = (WORD)lstrlen(lpModuleName);
                if (wLen)
                {
                    lpOEMFilterHeader->refModuleName.w.offset = (WORD)cbCurrentOffset;
                    wLen++;     // Count Null terminated character
                    lpOEMFilterHeader->refModuleName.w.length = wLen;
                    cbCurrentOffset += wLen;
                }
            }

            if (lpUserString)
            {
                wLen = (WORD)lstrlen(lpUserString);
                if (wLen)
                {
                    lpOEMFilterHeader->refUserString.w.offset = (WORD)cbCurrentOffset;
                    wLen++;     // Count Null terminated character
                    lpOEMFilterHeader->refUserString.w.length = wLen;
                    cbCurrentOffset += wLen;
                }
            }

            // Point to where data space begin
            lpOEMData += sizeof(OEMFILTERHEADER) * MAX_OEMFILTER;

            if (lpOEMFilterHeader->refOEMData.w.length)
                _fmemcpy(lpOEMData + lpOEMFilterHeader->refOEMData.w.offset,
                     lpData, lpOEMFilterHeader->refOEMData.w.length);

            if (lpOEMFilterHeader->refModuleName.w.length)
                _fmemcpy(lpOEMData + lpOEMFilterHeader->refModuleName.w.offset,
                         (LPBYTE)lpModuleName, lpOEMFilterHeader->refModuleName.w.length);

            if (lpOEMFilterHeader->refUserString.w.length)
                _fmemcpy(lpOEMData + lpOEMFilterHeader->refUserString.w.offset,
                         (LPBYTE)lpUserString, lpOEMFilterHeader->refUserString.w.length);

            lppd->cbOEMDataSize = cbCurrentOffset;

            lppd->wcOEMFilter += 1; // increment number of registered filter
            retVal = TRUE;
        }
        GlobalUnlock(lppd->hOEMFilterData);
    }
    return retVal;
}

/************************************************************************/

BOOL _loadds FAR PASCAL DRVSetFilter(HANDLE hContext,
                                     LPSTR  lpModuleName,
                                     LPSTR  lpUserString,
                                     WORD   wDataSize,
                                     LPBYTE lpData
                                    )
{
    BOOL retVal = FALSE;
    LPOEMINFO lpOEMInfo;
    LPPDEVICE    lppd;

    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        lppd = lpOEMInfo->lppd;
        GlobalUnlock(hContext);
    }
    else
        return FALSE;

    if (lpOEMInfo)
    {
        lpOEMInfo->hOEMFilterDll = LoadLibrary(lpModuleName);
        if (lpOEMInfo->hOEMFilterDll > HINSTANCE_ERROR)
        {
            lpOEMInfo->lpOEMOpenJob        = (LPOEMOPENJOB )GetProcAddress(lpOEMInfo->hOEMFilterDll, "OEMOpenJob");
            lpOEMInfo->lpOEMCloseJob       = (LPOEMCLOSEJOB )GetProcAddress(lpOEMInfo->hOEMFilterDll, "OEMCloseJob");
            lpOEMInfo->lpOEMDeleteJob      = (LPOEMDELETEJOB )GetProcAddress(lpOEMInfo->hOEMFilterDll, "OEMDeleteJob");
            lpOEMInfo->lpOEMStartSpoolPage = (LPOEMSTARTSPOOLPAGE )GetProcAddress(lpOEMInfo->hOEMFilterDll, "OEMStartSpoolPage");
            lpOEMInfo->lpOEMWriteSpool     = (LPOEMWRITESPOOL )GetProcAddress(lpOEMInfo->hOEMFilterDll, "OEMWriteSpool");
            lpOEMInfo->lpOEMEndSpoolPage   = (LPOEMENDSPOOLPAGE )GetProcAddress(lpOEMInfo->hOEMFilterDll, "OEMEndSpoolPage");


            if (lpOEMInfo->lpOEMOpenJob &&
                lpOEMInfo->lpOEMCloseJob &&
                lpOEMInfo->lpOEMDeleteJob &&
                lpOEMInfo->lpOEMStartSpoolPage &&
                lpOEMInfo->lpOEMWriteSpool &&
                lpOEMInfo->lpOEMEndSpoolPage &&
                lpOEMInfo->wEntry == PRINTING
                )
            {
                OEMFILTER_TYPE  flFilterType;

                // can only be ISV, OEM or fax filter.
        if (lpOEMInfo->flDllType == DLL_TYPE_OEM_CUST)
            flFilterType = OEM_FILTER;
        else
        {
            if (lpOEMInfo->flDllType == DLL_TYPE_PS_FAX)
                flFilterType = FAX_FILTER;
            else
                flFilterType = APP_FILTER;
        }
                retVal = OEMAddFilter(lppd, lpModuleName, lpUserString, wDataSize, lpData, flFilterType);
                lpOEMInfo->bOEMFilter = retVal;
/*
                if (lpOEMInfo->hOEMFilterDll)
                {
                    FreeLibrary(lpOEMInfo->hOEMFilterDll);
                }
*/
            }
            else
            {
                if (lpOEMInfo->hOEMFilterDll)
                {
                FreeLibrary(lpOEMInfo->hOEMFilterDll);
                lpOEMInfo->hOEMFilterDll = 0;
      }
            }
        }
    }
    return (retVal);
}


/************************************************************************/
/*  END FILTER                                                          */
/************************************************************************/
#endif

/************************************************************************/

void FAR PASCAL CallOEMSendPSStub(LPPDEVICE lppd,
                                  DWORD dwPSIndex,
                                  LPSTR lpDriverPS,
                                  LONG lLength)
{
    LPSTR lpTempPS;
    unsigned int iTempLen;
    int InjectType;
    PSInjectionPoint PSInjectID;

#ifdef Adobe_Driver
    if (lppd->hOemCust || lppd->hPSFax || lppd->hWebPrinter || lppd->hAppIsv || lppd->lpPSInjectRoot)
//    if (lppd->hOemCust || lppd->hPSFax || lppd->hAppIsv || lppd->lpPSInjectRoot)
//#endif
#else
    if (lppd->hOemCust || lppd->hAppIsv)
#endif
    {
        lpTempPS = lpDriverPS;
        iTempLen = (int)lLength;

        /* The first passes */
        if (lppd->hAppIsv && !lppd->job.bfESCOpenChannel)
            OEMInsertPSBeforeStub(lppd->hAppIsv, lppd, dwPSIndex);

#ifdef Adobe_Driver
        if (lppd->hWebPrinter && !lppd->job.bfESCOpenChannel)
            OEMInsertPSBeforeStub(lppd->hWebPrinter, lppd, dwPSIndex);
        if (lppd->hPSFax && !lppd->job.bfESCOpenChannel)
            OEMInsertPSBeforeStub(lppd->hPSFax, lppd, dwPSIndex);
#endif
    if (lppd->hOemCust && !lppd->job.bfESCOpenChannel)
            OEMInsertPSBeforeStub(lppd->hOemCust, lppd, dwPSIndex);

    // if APP PSInject & attribute is before

    PSInjectID = GetAPPInjectID (dwPSIndex, &InjectType );
    if (lppd->lpPSInjectRoot && PSInjectID != 0 && InjectType == 1)
        {
        SendPSInjectionData(lppd, PSInjectID, &lpTempPS, &iTempLen);
        }

        /* Let the OEM's try to modify the driver string */
        OEMChangeDriverPSStub(lppd->hAppIsv,  lppd, dwPSIndex, &lpTempPS, &iTempLen);

#ifdef Adobe_Driver
        OEMChangeDriverPSStub(lppd->hWebPrinter, lppd, dwPSIndex, &lpTempPS, &iTempLen);
        OEMChangeDriverPSStub(lppd->hPSFax,   lppd, dwPSIndex, &lpTempPS, &iTempLen);
#endif
        if (lppd->lpPSInjectRoot && PSInjectID != 0 && InjectType == 2)
        {
        SendPSInjectionData(lppd, PSInjectID, &lpTempPS, &iTempLen);
        }
        OEMChangeDriverPSStub(lppd->hOemCust, lppd, dwPSIndex, &lpTempPS, &iTempLen);

        /* Send the possible modified driver string */
        if (lpTempPS != NULL && iTempLen > 0L)
        {
            if (lppd->job.bfESCOpenChannel)
            {
                CRawPrinterData(lppd,lpTempPS, iTempLen);
            }
            else
            {
                PortWrite(lppd, (LP)lpTempPS, iTempLen);
            }
        }

        /* The last passes */
        if (lppd->hAppIsv && !lppd->job.bfESCOpenChannel)
            OEMInsertPSAfterStub(lppd->hAppIsv, lppd, dwPSIndex);
    if (lppd->lpPSInjectRoot && PSInjectID != 0 && InjectType == 3)
        {
        SendPSInjectionData(lppd, PSInjectID, &lpTempPS, &iTempLen);
        }
        if (lppd->hOemCust && !lppd->job.bfESCOpenChannel)
            OEMInsertPSAfterStub(lppd->hOemCust, lppd, dwPSIndex);

#ifdef Adobe_Driver
        if (lppd->hPSFax && !lppd->job.bfESCOpenChannel)
            OEMInsertPSAfterStub(lppd->hPSFax, lppd, dwPSIndex);
        if (lppd->hWebPrinter && !lppd->job.bfESCOpenChannel)
            OEMInsertPSAfterStub(lppd->hWebPrinter, lppd, dwPSIndex);
#endif
    }
    else
        PortWrite(lppd,(LP)lpDriverPS,LOWORD(lLength));
}

/************************************************************************/

HANDLE FAR PASCAL OEMInitDllStub(DRIVERINFOT FAR *lpDrvInfo,
                                 LPSTR lpFileName, int iOEMDllType, WORD wEntry)
{
    LPOEMINFO lpOEMInfo;
    HANDLE hContext = NULL;
    BOOL bResult,bSession = TRUE;
    BOOL bSuccess = FALSE;
    char PCFileName[14];
    char Path[128];
    DWORD dwDrvVersion, dwOEMVersion;

    hContext = GlobalAlloc(GMEM_DDESHARE|GHND, sizeof(OEMINFO));
    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        bSuccess = (lpOEMInfo != NULL);
    }

    if (bSuccess == FALSE)
        return (NULL);

    bSuccess = FALSE;
    /* Store important data */
    if (lpDrvInfo != NULL)
    {
        lpOEMInfo->lpPSExtDevmode = lpDrvInfo->lpDM;
        lpOEMInfo->lppd = &(lpDrvInfo->pDev);
        lpOEMInfo->lpDrvInfo = lpDrvInfo;
        lpOEMInfo->flDllType = iOEMDllType;
    }
    else
    {
        lpOEMInfo->lpPSExtDevmode = NULL;
        lpOEMInfo->lppd = NULL;
        lpOEMInfo->lpDrvInfo = NULL;
    }

    lpOEMInfo->hOEMCustDll = (HINSTANCE)NULL;
#ifdef Adobe_Driver
    lpOEMInfo->hOEMFilterDll = (HINSTANCE)NULL;
    if (iOEMDllType == DLL_TYPE_PS_FAX && lpOEMInfo->lppd)
    {
        // check to see if this printer support fax
        LPPRINTERINFO   lpPrinterInfo;

        lpPrinterInfo = (LPPRINTERINFO)lpOEMInfo->lppd->lpWPXblock->WPXprinterInfo ;
        bSuccess = (lpPrinterInfo->devcaps.bFaxSupport);
        if (bSuccess)
            lstrcpy(PCFileName,"\\psfax.dll");
    }
    else if ((iOEMDllType == DLL_TYPE_WEB_PRINTER && lpOEMInfo->lppd) ||
        (iOEMDllType == DLL_TYPE_WEB_PRINTER && wEntry == DEVINSTALL))
    {
        bSuccess = TRUE;
        lstrcpy(PCFileName,"\\WebPrPlg.dll");
    }
    else
#endif
    {
        int iLen;

        bSuccess = (lpFileName != NULL);
        if (bSuccess)
        {
            // Do not process the PCFileName length > 8.3 format
            // bug # 175731 yct
            if (lstrlen(lpFileName) > 12)
            {
                bSuccess = FALSE;
                GlobalFree(hContext);
                return NULL;
            }
            lstrcpy(PCFileName,"\\");
            lstrcat(PCFileName, lpFileName);
            iLen = lstrlen(PCFileName);
            PCFileName[iLen-3] = '\0';
            lstrcat(PCFileName, "dll");
        }
    }

    if (bSuccess)
    {
        lpOEMInfo->wEntry = wEntry;
#ifdef Adobe_Driver
        lpOEMInfo->bOEMFilter = FALSE;
#endif
        GetDriverDirectory(Path, sizeof(Path));
        lstrcat(Path,PCFileName);
        lpOEMInfo->hOEMCustDll = LoadLibrary(Path);
        if (lpOEMInfo->hOEMCustDll <= HINSTANCE_ERROR)
        {
            GetWindowsDirectory(Path, sizeof(Path));
            lstrcat(Path,PCFileName);
            lpOEMInfo->hOEMCustDll = LoadLibrary(Path);

        }
        bSuccess = (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR);
    }

    if (bSuccess)
    { /* Things are fine */
        lpOEMInfo->lpOEMInitDll  = (LPOEMINITDLL )GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMInitDll");
        lpOEMInfo->lpOEMBeginSession  = (LPOEMBEGINSESSION )GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMBeginSession");
        lpOEMInfo->lpOEMDevInstall = (LPOEMDEVINSTALL)GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMDevInstall");
        lpOEMInfo->lpOEMGetPropertyPages = (LPOEMGETPROPERTYPAGES)GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMGetPropertyPages");
        lpOEMInfo->lpOEMDeviceCapabilities = (LPOEMDEVICECAPABILITIES)GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMDeviceCapabilities");
        lpOEMInfo->lpOEMStartDoc = (LPOEMSTARTDOC)GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMStartDoc");
        lpOEMInfo->lpOEMEndDoc   = (LPOEMENDDOC  )GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMEndDoc");
        lpOEMInfo->lpOEMAbortDoc = (LPOEMABORTDOC)GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMAbortDoc");
        lpOEMInfo->lpOEMInsertPSBefore = (LPOEMINSERTPSBEFORE)GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMInsertPSBefore");
        lpOEMInfo->lpOEMInsertPSAfter  = (LPOEMINSERTPSAFTER )GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMInsertPSAfter");
        lpOEMInfo->lpOEMChangeDriverPS = (LPOEMCHANGEDRIVERPS)GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMChangeDriverPS");
        lpOEMInfo->lpOEMEndSession  = (LPOEMENDSESSION )GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMEndSession");
        lpOEMInfo->lpOEMTermDll  = (LPOEMTERMDLL )GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMTermDll");
        lpOEMInfo->lpOEMValidateDevmode  = (LPOEMVALIDATEDEVMODE)GetProcAddress(lpOEMInfo->hOEMCustDll, "OEMValidateDevmode");

        if (lpOEMInfo->lpOEMInitDll          &&
            lpOEMInfo->lpOEMBeginSession     &&
            lpOEMInfo->lpOEMDevInstall       &&
            lpOEMInfo->lpOEMGetPropertyPages &&
//(optional)lpOEMInfo->lpOEMDeviceCapabilities &&
//(optional lpOEMInfo->lpOEMValidateDevmode  &&
            lpOEMInfo->lpOEMStartDoc         &&
            lpOEMInfo->lpOEMEndDoc           &&
            lpOEMInfo->lpOEMAbortDoc         &&
            lpOEMInfo->lpOEMInsertPSBefore   &&
            lpOEMInfo->lpOEMInsertPSAfter    &&
            lpOEMInfo->lpOEMChangeDriverPS   &&
            lpOEMInfo->lpOEMEndSession       &&
            lpOEMInfo->lpOEMTermDll)
            bSuccess = TRUE; /* Success ! */
        else
            bSuccess = FALSE; /* Failure */

        if (bSuccess && wEntry==VALIDATEDM)
            bSuccess = lpOEMInfo->lpOEMValidateDevmode ? TRUE : FALSE;

        if (bSuccess && wEntry==DEVICECAP)
            bSuccess = lpOEMInfo->lpOEMDeviceCapabilities ? TRUE : FALSE;
#if 0
        {
            char *msg;
            switch (wEntry)
            {
            case ADVSETUPDLG: msg = "ADVSETUPDLG"; break;
            case EXTDEVMODE: msg = "EXTDEVMODE"; break;
            case PROPSHEET: msg = "PROPSHEET"; break;
            case DEVINSTALL: msg = "DEVINSTALL"; break;
            case PRINTING: msg ="PRINTING"; break;
            }

            MessageBox(NULL, msg, "OEMInitDll", MB_OK|MB_ICONHAND);
        }
#endif
        if (bSuccess)
        {
            if (lpDrvInfo != NULL)
            {
                 dwDrvVersion = DRV_VERSION;
                 dwOEMVersion = 0;

                bResult = (*(lpOEMInfo->lpOEMInitDll))(
                               lpDrvInfo->lpDM->dm.dm.dmDeviceName,
                               lpDrvInfo->pDev.szPortName,
                               &dwDrvVersion,
                               &dwOEMVersion);

             // now driver has the chance to decide whether to talk to
             // the OEM or not
            }
            else
            {

            dwDrvVersion = DRV_VERSION;
            dwOEMVersion = 0;
                bResult = (*(lpOEMInfo->lpOEMInitDll))(
                               NULL,
                               NULL,
                               &dwDrvVersion,
                               &dwOEMVersion);
                }
        }

        // if OEMInitDLL return FLASE, don't start the session

        if (bSuccess && bResult)
        {
            if (lpDrvInfo != NULL)
            {
                lpOEMInfo->hOEM = (*(lpOEMInfo->lpOEMBeginSession))(hContext,
                               ghDriverMod,
                               lpDrvInfo->lpDM->dm.dm.dmDeviceName,
                               lpDrvInfo->pDev.szPortName,
                               lpOEMInfo->lpPSExtDevmode->dm.dwTimeStamp,
                               lpOEMInfo->lpPSExtDevmode->dm.dwRandom,
                               wEntry);
            }
            else

            {
                lpOEMInfo->hOEM = (*(lpOEMInfo->lpOEMBeginSession))(hContext,
                               ghDriverMod,
                               NULL, NULL,
                               (DWORD)0,
                               (DWORD)0,
                               wEntry);
            }

            if (lpOEMInfo->hOEM == (HANDLE)NULL)
                bSession = FALSE;
        }
        else
            lpOEMInfo->hOEM = NULL;
    }

    GlobalUnlock(hContext);

    // The OEMInitDLL and OEMBeginSession are called only when OEMDLL is setting
    // up the calling routine correctly

    if (bSuccess && (!bSession || !bResult))
    { /* Failure */
        if (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR)
        {
              if (bSession)
             (*(lpOEMInfo->lpOEMEndSession))(lpOEMInfo->hOEM);

           if (bResult)
             (*(lpOEMInfo->lpOEMTermDll))();

           FreeLibrary(lpOEMInfo->hOEMCustDll);
             lpOEMInfo->hOEMCustDll = 0;
        }
        GlobalFree(hContext);
        hContext = NULL;
    }
    if (!bSuccess)
    {

        if (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR)
        {
              FreeLibrary(lpOEMInfo->hOEMCustDll);
              lpOEMInfo->hOEMCustDll = 0;
        }

        GlobalFree(hContext);
        hContext = NULL;
    }
    return (hContext);
}

/************************************************************************/

int FAR PASCAL OEMDevInstallStub(HANDLE hContext,
                                 HWND hWnd,
                                 LPSTR lpszModelName,
                                 LPSTR lpszOldPort,
                                 LPSTR lpszNewPort)
{ /* done */
  LPOEMINFO lpOEMInfo;
  int retVal = -1;

  if (hContext)
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
  else
    return (FALSE);

  if (lpOEMInfo &&
      (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR) &&
      (lpOEMInfo->hOEM != NULL))
    { /* Things are fine */
    retVal = (*(lpOEMInfo->lpOEMDevInstall))(lpOEMInfo->hOEM,
                           hWnd,
                           lpszModelName, lpszOldPort, lpszNewPort);
    }

  GlobalUnlock(hContext);
  return (retVal);
}

/************************************************************************/

BOOL FAR PASCAL OEMGetPropertyPagesStub(HANDLE hContext,
                             LPPROPSHEETPAGE lpPropSheetArray,
                             int FAR *lpNumOEMPropPages,
                             DWORD FAR *lpdwDriverPropPagesToDisplay)
{
  LPOEMINFO lpOEMInfo;
  BOOL retVal = FALSE;

  if (hContext)
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
  else
    return (FALSE);

  if (lpOEMInfo &&
      (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR) &&
      (lpOEMInfo->hOEM != NULL))
    { /* Things are fine */
    retVal = (*(lpOEMInfo->lpOEMGetPropertyPages))(lpOEMInfo->hOEM,
                             lpPropSheetArray,
                             lpNumOEMPropPages,
                             lpdwDriverPropPagesToDisplay);

    }

  GlobalUnlock(hContext);
  return (retVal);
}

/************************************************************************/

BOOL FAR PASCAL OEMDeviceCapabilitiesStub(HANDLE hContext,
                             LPSTR lpszDevice,
                             LPSTR lpszPort,
                             WORD  fwCapability,
                             LPSTR lpszOutput,
                             DWORD *lpdwRetVal)
{
  LPOEMINFO lpOEMInfo;
  BOOL OEMDoneIt = FALSE;

  if (hContext)
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
  else
    return (FALSE);

  if (lpOEMInfo &&
      lpOEMInfo->lpOEMDeviceCapabilities &&
      (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR) &&
      (lpOEMInfo->hOEM != NULL))
    { /* Things are fine */
    OEMDoneIt = (*(lpOEMInfo->lpOEMDeviceCapabilities))(lpOEMInfo->hOEM,
                             lpszDevice,
                             lpszPort,
                             fwCapability,
                             lpszOutput,
                             lpdwRetVal);
    }

  GlobalUnlock(hContext);
  return (OEMDoneIt);
}

/************************************************************************/

SHORT FAR PASCAL OEMStartDocStub(HANDLE hContext,
                                 LPSTR  lpJobName,
                                 WORD   wPrintJobType)
{ /* done */
  LPOEMINFO lpOEMInfo;
  SHORT retVal = SP_ERROR;

  if (hContext)
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
  else
    return (SP_ERROR);


  if (lpOEMInfo &&
      (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR) &&
      (lpOEMInfo->hOEM != NULL))
    { /* Things are fine */
    retVal = (*(lpOEMInfo->lpOEMStartDoc))(lpOEMInfo->hOEM, lpJobName, wPrintJobType);
    }

  GlobalUnlock(hContext);
  return (retVal);
}

/************************************************************************/

WORD FAR PASCAL OEMEndDocStub(HANDLE hContext)
{ /* done */
  LPOEMINFO lpOEMInfo;
  BOOL retVal = FALSE;

  if (hContext)
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
  else
    return (FALSE);

  if (lpOEMInfo &&
      (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR) &&
      (lpOEMInfo->hOEM != NULL))
    { /* Things are fine */

    retVal = (*(lpOEMInfo->lpOEMEndDoc))(lpOEMInfo->hOEM);
    }

  GlobalUnlock(hContext);
  return (retVal);
}
/************************************************************************/

WORD FAR PASCAL OEMEndSessionStub(HANDLE hContext)
{ /* done */
  LPOEMINFO lpOEMInfo;
  BOOL retVal = FALSE;

  if (hContext)
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
  else
    return (FALSE);

  if (lpOEMInfo &&
      (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR) &&
      (lpOEMInfo->hOEM != NULL))
    { /* Things are fine */

     (*(lpOEMInfo->lpOEMEndSession))(lpOEMInfo->hOEM);
    }

  GlobalUnlock(hContext);
  return (retVal);
}


/************************************************************************/

void FAR PASCAL OEMAbortDocStub(HANDLE hContext)
{ /* done */
  LPOEMINFO lpOEMInfo;

  if (hContext)
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
  else
    return;

  if (lpOEMInfo &&
      (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR) &&
      (lpOEMInfo->hOEM != NULL))
    { /* Things are fine */
    (*(lpOEMInfo->lpOEMAbortDoc))(lpOEMInfo->hOEM);
    }

  GlobalUnlock(hContext);
}

/************************************************************************/

void FAR PASCAL OEMInsertPSBeforeStub(HANDLE hContext,
                                      LPPDEVICE lppd,
                                      DWORD dwPSIndex)
{
  LPOEMINFO lpOEMInfo;
  BOOL bContinue;
  LPSTR lpOEMPS;
  unsigned int OEMPSLen;

  if (hContext)
    {
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
    bContinue = FALSE;
    lpOEMPS = NULL;
    OEMPSLen = 0;
    }
  else
    return;

  if (lpOEMInfo &&
      (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR) &&
      (lpOEMInfo->hOEM != NULL))
    { /* Things are fine */
    do
      {
      bContinue = (*(lpOEMInfo->lpOEMInsertPSBefore))(lpOEMInfo->hOEM,
                                                      dwPSIndex,
                                                      &lpOEMPS,
                                                      &OEMPSLen);

      if (OEMPSLen > 0 && lpOEMPS != NULL)
        PortWrite(lppd, (LP)lpOEMPS, OEMPSLen);
      } while (bContinue);
    }

  GlobalUnlock(hContext);
}

/************************************************************************/

void FAR PASCAL OEMChangeDriverPSStub(HANDLE hContext,
                                      LPPDEVICE lppd,
                                      DWORD dwPSIndex,
                                      LPSTR FAR *lplpDriverPS,
                                      unsigned FAR *lpDriverPSLen)
{
  LPOEMINFO lpOEMInfo;

  if (hContext)
    {
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
    }
  else
    return;

  if (lpOEMInfo &&
      (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR) &&
      (lpOEMInfo->hOEM != NULL))
    { /* Things are fine */
    (*(lpOEMInfo->lpOEMChangeDriverPS))(lpOEMInfo->hOEM,
                                        dwPSIndex,
                                        lplpDriverPS,
                                        lpDriverPSLen);
    }

  GlobalUnlock(hContext);
}

/************************************************************************/

void FAR PASCAL OEMInsertPSAfterStub(HANDLE hContext,
                                     LPPDEVICE lppd,
                                     DWORD dwPSIndex)
{
  LPOEMINFO lpOEMInfo;
  BOOL bContinue;
  LPSTR lpOEMPS;
  unsigned int OEMPSLen;

  if (hContext)
    {
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
    bContinue = FALSE;
    lpOEMPS = NULL;
    OEMPSLen = 0;
    }
  else
    return;

  if (lpOEMInfo &&
      (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR) &&
      (lpOEMInfo->hOEM != NULL))
    { /* Things are fine */
    do
      {
      bContinue = (*(lpOEMInfo->lpOEMInsertPSAfter))(lpOEMInfo->hOEM,
                                                     dwPSIndex,
                                                     &lpOEMPS,
                                                     &OEMPSLen);

      if (OEMPSLen > 0 && lpOEMPS != NULL)
        PortWrite(lppd, (LP)lpOEMPS, LOWORD(OEMPSLen));
      } while (bContinue);
    }

  GlobalUnlock(hContext);
}

/************************************************************************/

void FAR PASCAL OEMTermDllStub(HANDLE hContext)
{ /* done */
  LPOEMINFO lpOEMInfo;

  if (hContext)
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
  else
    return;

  if (lpOEMInfo &&
      (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR) &&
      (lpOEMInfo->hOEM != NULL))
    { /* Things are fine */

        (*(lpOEMInfo->lpOEMEndSession))(lpOEMInfo->hOEM);

#ifdef Adobe_Driver
        if (lpOEMInfo->bOEMFilter)      // Free global data if necessary.
        {
            LPPDEVICE   lppd;

            lppd = lpOEMInfo->lppd;
            lppd->wcOEMFilter -= 1;
            if (lppd->wcOEMFilter == 0 && lppd->hOEMFilterData)
            {
                GlobalFree(lppd->hOEMFilterData);
                lppd->hOEMFilterData = (HANDLE)NULL;
            }
        }
#endif

        /* Free the library */
        (*(lpOEMInfo->lpOEMTermDll))();
        FreeLibrary(lpOEMInfo->hOEMCustDll);

#ifdef Adobe_Driver
        if (lpOEMInfo->hOEMFilterDll > HINSTANCE_ERROR)
            FreeLibrary(lpOEMInfo->hOEMFilterDll);
#endif

    }

  /* Free the Memory */
  GlobalUnlock(hContext);
  GlobalFree(hContext);
}

/************************************************************************/

void FAR PASCAL OEMValidateDevmodeStub(HANDLE hContext)
{ /* done */
  LPOEMINFO lpOEMInfo;

  if (hContext)
  {
     lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
     if (lpOEMInfo &&
         (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR) &&
         (lpOEMInfo->hOEM != NULL) &&
         (lpOEMInfo->lpOEMValidateDevmode))
     { /* Things are fine */
        (*(lpOEMInfo->lpOEMValidateDevmode))(lpOEMInfo->hOEM);
     }

     GlobalUnlock(hContext);
  }
}

/************************************************************************/

BOOL FAR PASCAL GetPCFileNameFromWPX(LPSTR WPXfileName, LPSTR lpPCFileName)
{
  HFILE hfile = HFILE_ERROR;
  LPWPXBLOCKS lpWPXblocks;
  WPX_HEADER  wpxHeader;   // table of contents for wpx file.
  PDEVICE pDev;
  LPSTR lpFileName;
  unsigned int count;
  LPPRINTERINFO lpPrinterInfo = NULL;

  lpWPXblocks = GlobalAllocPtr(GDLLHND, sizeof(WPXBLOCKS));
  lpWPXblocks->WPXprinterInfo = NULL;

  hfile = _lopen(WPXfileName, READ) ;
  if (hfile == HFILE_ERROR )
    goto  FailedGetPCFileNameFromWPX;

  count = sizeof(WPX_HEADER);

  if (count != _lread(hfile, &wpxHeader,  count))
    goto  FailedGetPCFileNameFromWPX;

  count = wpxHeader.PrinterInfo_len;
  lpWPXblocks->WPXprinterInfo = GlobalAllocPtr(GDLLHND, (long)count);
  count = wpxHeader.stringtab_len;
  lpWPXblocks->WPXstrings = GlobalAllocPtr(GDLLHND, (long)count);

  _llseek(hfile, wpxHeader.PrinterInfo_loc, SEEK_SET);   //  seek to pos byte
  count = wpxHeader.PrinterInfo_len;
  if (count != _lread(hfile,  lpWPXblocks->WPXprinterInfo, count))
    goto  FailedGetPCFileNameFromWPX;

  _llseek(hfile, wpxHeader.stringtab_loc, SEEK_SET);   //  seek to pos byte
  count = wpxHeader.stringtab_len;
  if (count != _lread(hfile,  lpWPXblocks->WPXstrings, count))
    goto  FailedGetPCFileNameFromWPX;

  _lclose(hfile);

  lpPrinterInfo = (LPPRINTERINFO)(lpWPXblocks->WPXprinterInfo);
  pDev.lpWPXblock = lpWPXblocks;
  lpFileName = StringRefToLPBYTE(&pDev, lpPrinterInfo->PCFileName.dword);

  // bug 175731 yct do not process PCFileName length > 8.3
  if (lstrlen(lpFileName) > 12)
    goto  FailedGetPCFileNameFromWPX;

  lstrcpy(lpPCFileName, lpFileName);

  /* Clean up */
  GlobalFreePtr(lpWPXblocks->WPXprinterInfo);
  GlobalFreePtr(lpWPXblocks->WPXstrings);
  GlobalFreePtr(lpWPXblocks);
  return (TRUE);

FailedGetPCFileNameFromWPX:
  if (hfile != HFILE_ERROR)
    _lclose(hfile);

  GlobalFreePtr(lpWPXblocks->WPXprinterInfo);
  GlobalFreePtr(lpWPXblocks->WPXstrings);
  GlobalFreePtr(lpWPXblocks);
  return (FALSE);
}

/************************************************************************/
/*                                                                      */
/* AdobePS exports these for the oem dlls                               */
/*                                                                      */
/************************************************************************/

int _loadds FAR PASCAL DRVGetKeywordID(HANDLE hContext, LPSTR lpKeyword)
//                                       BOOL bIsReadOnly)
{
  int retVal = -1;
  int iMainKeywordIndex = -1;
  char strBuff[64];
  int iBase;
  KEYWORD iKeyword;
  STRINGREF MainKeyword;
  LPBYTE lpMainKeyword;
  unsigned int i, iNumOptions, iOffset;
  LPPDEVICE lppd = NULL;
  LPPRINTERINFO lpPrinterInfo = NULL;
  LPMAINKEYHDR  lpCurMainKeyHdr = NULL;
  LPOEMINFO lpOEMInfo;

  if (hContext)
    {
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);

    lppd = lpOEMInfo->lppd;
    if (lppd)
      {
      lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);
      if (!lpPrinterInfo)
        {
        return (retVal);
        }
      }
    GlobalUnlock(hContext);
    }
  else
    return (retVal);

  /* Take care of general keywords that are being parsed for */
  /* Doc Sticky first */
  iNumOptions = lpPrinterInfo->DocSticky.w.length;
  iOffset = lpPrinterInfo->DocSticky.w.offset;
  for (i = 0; i < iNumOptions && retVal == -1; i++)
    {
    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + i + iOffset;
    MainKeyword = lpCurMainKeyHdr->MainKey;

    lpMainKeyword = StringRefToLPBYTE(lppd, MainKeyword.dword);
    lstrcpyn(strBuff, lpMainKeyword, (MainKeyword.w.length+1));
    if (lstrcmp(lpKeyword, strBuff) == 0)
        retVal = ID_DM_DOCUMENT_STICKY_OPTIONS_BASE + i;
    }

  /* Printer Sticky */
  iNumOptions = lpPrinterInfo->PrinterSticky.w.length;
  iOffset = lpPrinterInfo->PrinterSticky.w.offset;
  for (i = 0; i < iNumOptions && retVal == -1; i++)
    {
    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + i + iOffset;
    MainKeyword = lpCurMainKeyHdr->MainKey;

    lpMainKeyword = StringRefToLPBYTE(lppd, MainKeyword.dword);
    lstrcpyn(strBuff, lpMainKeyword, (MainKeyword.w.length+1));
    if (lstrcmp(lpKeyword, strBuff) == 0)
        retVal = ID_DM_PRINTER_STICKY_OPTIONS_BASE + i;
    }
  /* Return for UI keywords */
  if (retVal != -1)
    return(retVal);

  /* Take care of the main keywords we parse for */
  lpMainKeyWordsTable = (LPSTRINGREF)GlobalAllocPtr(GHND, MAXMAINKEYWORDSTABLESIZ * sizeof(STRINGREF));
  if (!lpMainKeyWordsTable)
    return (retVal);
  lpStringPtr = (LPBYTE)GlobalAllocPtr(GHND, 0x10000L);
  if (!lpStringPtr)
    return (retVal);
  initMainKeyWordsTableStub();
  for (iKeyword = PPDVERSION; iKeyword < ENDOFLIST && iMainKeywordIndex == -1; iKeyword++) /* 68 */
    {
    lpMainKeyword = StringRefToLPBYTE(lppd, lpMainKeyWordsTable[iKeyword].dword);
    lstrcpyn(strBuff, lpMainKeyword, (lpMainKeyWordsTable[iKeyword].w.length+1));
    if (lstrcmp(lpKeyword, strBuff) == 0)
      iMainKeywordIndex = iKeyword;
    }
  GlobalFreePtr(lpStringPtr);
  GlobalFreePtr(lpMainKeyWordsTable);

  if (iMainKeywordIndex != -1)
    { /* We have found it somewhere */

    switch (iMainKeywordIndex)
      {
      case PPDVERSION:
        retVal = -1;
        break;
      case MODELNAME:
          retVal = ID_DEFAULT_MODELNAME;
        break;
      case NICKNAME:
      case SHORTNICKNAME:
          retVal = ID_DM_DM_DEVICENAME;
        break;
      case COLORDEVICE:
          retVal = ID_DEFAULT_COLORDEVICE;
        break;
      case LANGUAGELEVEL:
        retVal = ID_DEFAULT_LANGUAGE_LEVEL;
        break;
      case PROTOCOLSS:
        retVal = -1;
        break;
      case FREEVM:
          retVal = ID_DEFAULT_FREE_VM;
        break;
      case ORDERDEPENDENCY:
        retVal = -1;
        break;
      case PAGESIZE:
          retVal = ID_DM_PAPERSIZE;
        break;
      case DEFAULTPAGESIZE:
        retVal = -1;
        break;
      case Q_PAGESIZE:
        retVal = -1;
        break;
      case PAGEREGION:
        retVal = -1;
        break;
      case IMAGEABLEAREA:
        retVal = -1;
        break;
      case PAPERDIMENSION:
        retVal = -1;
        break;
      case LANDSCAPEORIENTATION:
          retVal = ID_DM_PAPER_ORIENTATION;
        break;
      case CUSTOMPAGESIZE:
          retVal = ID_DEFAULT_CUSTOM_PAGE_SIZE;
        break;
      case PARAMCUSTOMPAGESIZE:     // YCT check what's different
        retVal = ID_DEFAULT_CUSTOM_PAGE_SIZE;
        break;
      case MAXMEDIAWIDTH:
        retVal = -1;
        break;
      case HWMARGINS:
        retVal = -1;
        break;
      case MEDIATYPE:
        retVal = ID_DM_MEDIATYPE;
        break;
      case DEFAULTMEDIATYPE:
        retVal = -1;
        break;
      case Q_MEDIATYPE:
        retVal = -1;
        break;
      case INPUTSLOT:
        retVal = -1;
        break;
      case DEFAULTINPUTSLOT:
        retVal = -1;
        break;
      case Q_INPUTSLOT:
        retVal = -1;
        break;
      case REQUIRESPAGEREGION:
        retVal = -1;
        break;
      case OUTPUTBIN:
        retVal = -1;
        break;
      case DEFAULTOUTPUTBIN:
        retVal = -1;
        break;
      case Q_OUTPUTBIN:
        retVal = -1;
        break;
      case MANUALFEED:
        retVal = -1;
        break;
      case DUPLEX:
        retVal = -1;
        break;
      case Q_DUPLEX:
        retVal = -1;
        break;
      case DEFAULTDUPLEX:
        retVal = -1;
        break;
      case MIRRORPRINT:
        retVal = -1;                    // driver feature only
        break;
      case DEFAULTRESOLUTION:
        retVal = -1;
        break;
      case RESOLUTION:
        retVal = -1;
        break;
      case Q_RESOLUTION:
        retVal = -1;
        break;
      case SETRESOLUTION:
        retVal = -1;
        break;
      case SCREENFREQ:
        retVal = -1;      // driver feature only
        break;
      case SCREENANGLE:
        retVal = -1;      // driver feature only
        break;
      case SCREENFREQRES:
        retVal = ID_DEFAULT_RES_SCREEN_FREQ;
        break;
      case SCREENANGLERES:
        retVal = ID_DEFAULT_RES_SCREEN_ANGLE;
        break;
      case FONT:
        retVal = -1;
        break;
      case DEFAULTFONT:
        retVal = -1;
        break;
      case PASSWORD:
        retVal = -1;
        break;
      case EXITSERVER:
        retVal = -1;
        break;
      case SYMBOLVALUE:
        retVal = -1;
        break;
      case OPENUI:
        retVal = -1;
        break;
      case OPENGROUP:
        retVal = -1;
        break;
      case CLOSEGROUP:
        retVal = -1;
        break;
      case UICONSTRAINT:
        retVal = -1;
        break;
      case TTRASTERIZER:
        retVal = ID_DM_TT_RASTERIZER_TYPE;
        break;
      case TRUEIMAGEDEVICE:
        retVal = -1;
        break;
      case JCLBEGIN:
        retVal = -1;
        break;
      case JCLTOPS:
        retVal = -1;
        break;
      case JCLEND:
        retVal = -1;
        break;
      case JCLOPENUI:
        retVal = -1;
        break;
      case JCLCLOSEUI:
        retVal = -1;
        break;
      case DEFAULTJCLRESOLUTION:
        retVal = -1;
        break;
      case JCLRESOLUTION:
        retVal = -1;
        break;
      case Q_JCLRESOLUTION:
        retVal = -1;
        break;
      case DEFAULTINSTALLEDMEMORY:
        retVal = -1;
        break;
      case INSTALLEDMEMORY:
        retVal = -1;
        break;
      case LANGUAGEENCODING:
        retVal = -1;
        break;
      case PCFILENAME:
        retVal = -1;
        break;
      case PRODUCT:
        retVal = -1;
        break;
      case PSVERSION:
        retVal = -1;
        break;
      case COLLATE:
        retVal = -1;
        break;
      case Q_COLLATE:
        retVal = -1;
        break;
      case DEFAULTCOLLATE:
        retVal = -1;
        break;
      case OUTPUTORDER:
        retVal = -1;
        break;
      case DEFAULTOUTPUTORDER:
        retVal = -1;
        break;
      case Q_OUTPUTORDER:
        retVal = -1;
        break;
      default:
        retVal = -1;
        break;
      }
    }
  /* Return for Main keywords */
  if (retVal != -1)
    return(retVal);

  /* Take care of the predefined headers */
    iBase = ID_DM_PREDEFINED_OPTIONS_BASE;

  if (retVal < 0)
    {
    LoadString(ghDriverMod, ID_PPDSTR_KEY_PAGESIZE,
               (LPSTR)strBuff, (int)sizeof(strBuff));
    if (lstrcmp(lpKeyword, strBuff) == 0)
      retVal = iBase + IND_PAPERINFO;
    }

  if (retVal < 0)
    {
    LoadString(ghDriverMod, ID_PPDSTR_KEY_PAGEREGION,
               (LPSTR)strBuff, (int)sizeof(strBuff));
    if (lstrcmp(lpKeyword, strBuff) == 0)
      retVal = iBase + IND_PAGEREGIONINFO;
    }

  if (retVal < 0)
    {
    LoadString(ghDriverMod, ID_PPDSTR_KEY_DUPLEX,
               (LPSTR)strBuff, (int)sizeof(strBuff));
    if (lstrcmp(lpKeyword, strBuff) == 0)
      retVal = iBase + IND_DUPLEXINGINFO;
    }

  if (retVal < 0)
    {
    LoadString(ghDriverMod, ID_PPDSTR_KEY_INPUTSLOT,
               (LPSTR)strBuff, (int)sizeof(strBuff));
    if (lstrcmp(lpKeyword, strBuff) == 0)
      retVal = iBase + IND_INPUTSLOTINFO;
    }

  if (retVal < 0)
    {
    LoadString(ghDriverMod, ID_PPDSTR_KEY_RESOLUTION,
               (LPSTR)strBuff, (int)sizeof(strBuff));
    if (lstrcmp(lpKeyword, strBuff) == 0)
      retVal = iBase + IND_RESOLUTIONINFO;
    }

  if (retVal < 0)
    {
    LoadString(ghDriverMod, ID_PPDSTR_KEY_OUTPUTBIN,
               (LPSTR)strBuff, (int)sizeof(strBuff));
    if (lstrcmp(lpKeyword, strBuff) == 0)
      retVal = iBase + IND_OUTPUTBININFO;
    }

  if (retVal < 0)
    {
    LoadString(ghDriverMod, ID_PPDSTR_KEY_MEDIATYPE,
               (LPSTR)strBuff, (int)sizeof(strBuff));
    if (lstrcmp(lpKeyword, strBuff) == 0)
      retVal = iBase + IND_MEDIATYPEINFO;
    }

  if (retVal < 0)
    {
    LoadString(ghDriverMod, ID_PPDSTR_KEY_INSTALLEDMEMORY,
               (LPSTR)strBuff, (int)sizeof(strBuff));
    if (lstrcmp(lpKeyword, strBuff) == 0)
      retVal = iBase + IND_MEMORYINFO;
    }

  if (retVal < 0)
    {
    LoadString(ghDriverMod, ID_PPDSTR_KEY_COLLATE,
               (LPSTR)strBuff, (int)sizeof(strBuff));
    if (lstrcmp(lpKeyword, strBuff) == 0)
      retVal = iBase + IND_COLLATIONINFO;
    }

  if (retVal < 0)
    {
    LoadString(ghDriverMod, ID_PPDSTR_KEY_OUTPUTORDER,
               (LPSTR)strBuff, (int)sizeof(strBuff));
    if (lstrcmp(lpKeyword, strBuff) == 0)
      retVal = iBase + IND_OUTPUTORDERINFO;
    }

  return (retVal);
}

/************************************************************************/

BOOL _loadds FAR PASCAL DRVSetDWord(HANDLE hContext, int iDataItemID, DWORD dwData)
{
  BOOL bSuccess = FALSE;
  LPOEMINFO lpOEMInfo = NULL;
  LPPSEXTDEVMODE lpPSExtDevmode = NULL;
  LPPDEVICE lppd = NULL;
  LPPRINTERINFO lpPrinterInfo = NULL;
  int iKeywordIndex;
  int iVal;
  LPBYTE        lpOptionsBlock = NULL;
  LPMAINKEYHDR  lpCurMainKeyHdr = NULL;
  LPPAPERINFO   lpPaperInfo = NULL;
  volatile int x;


  if (hContext)
    {
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
    lpPSExtDevmode = lpOEMInfo->lpPSExtDevmode;

    lppd = lpOEMInfo->lppd;
    if (lppd)
      {
      lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);

      lpOptionsBlock = lppd->lpWPXblock->WPXarrays;
      if (lpPrinterInfo)
        {
        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;
        if (lpCurMainKeyHdr)
          lpPaperInfo = (LPPAPERINFO)MAKELONG(
            lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );
        }
      }
    GlobalUnlock(hContext);
    }
  else
    return (FALSE);

  // for backward compatibility
  if (iDataItemID == ID_DM_COLLATE)
    iDataItemID = ID_DM_COLLATION;

  if ((ID_DM_DOCUMENT_STICKY_OPTIONS_BASE <= iDataItemID) &&
      (iDataItemID < ID_DM_DOCUMENT_STICKY_OPTIONS_BASE + 100))
    {
    iKeywordIndex = lpPrinterInfo->DocSticky.w.offset + (iDataItemID -
                    ID_DM_DOCUMENT_STICKY_OPTIONS_BASE);
    bSuccess = TRUE;
    }

  if ((ID_DM_PRINTER_STICKY_OPTIONS_BASE <= iDataItemID) &&
      (iDataItemID < ID_DM_PRINTER_STICKY_OPTIONS_BASE + 100))
    {
    iKeywordIndex = lpPrinterInfo->PrinterSticky.w.offset + (iDataItemID -
                    ID_DM_PRINTER_STICKY_OPTIONS_BASE);
    bSuccess = TRUE;
    }

  if (bSuccess == TRUE)
    {
    WORD curr_PPD_opt_id;

    curr_PPD_opt_id = LOWORD(dwData);
    KeywordSetCurrentOption(lppd, iKeywordIndex, curr_PPD_opt_id);
    }

  /* Check the predefined options first */
  if (!bSuccess)
    {
    switch (iDataItemID)
      {
      case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAPERINFO:
      case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAGEREGIONINFO:
      case ID_DM_PREDEFINED_OPTIONS_BASE + IND_DUPLEXINGINFO:
      case ID_DM_PREDEFINED_OPTIONS_BASE + IND_INPUTSLOTINFO:
      case ID_DM_PREDEFINED_OPTIONS_BASE + IND_RESOLUTIONINFO:
      case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTBININFO:
      case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEDIATYPEINFO:
      case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEMORYINFO:
      case ID_DM_PREDEFINED_OPTIONS_BASE + IND_COLLATIONINFO:
      case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTORDERINFO:
        iKeywordIndex = iDataItemID - ID_DM_PREDEFINED_OPTIONS_BASE;
        iVal = LOWORD(dwData);
        KeywordSetCurrentOption(lppd,iKeywordIndex,iVal);
        if( iDataItemID == ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTORDERINFO )
           lpPSExtDevmode->dm.bOutputOrder = iVal;
        bSuccess = TRUE;
        break;
      }
    }

  if (!bSuccess)
  {
    if ((iDataItemID >= ID_DM_CUSTOM_WIDTH_BASE) &&
        (iDataItemID <  ID_DM_CUSTOM_WIDTH_BASE + MAX_NUM_CUSTOM_PAPERS))
      {

      bSuccess = TRUE;
      x = iDataItemID - ID_DM_CUSTOM_WIDTH_BASE;
      lpPSExtDevmode->dm.custPaper[x].customWidth = (float)(DWORD)dwData;
      }

    if ((iDataItemID >= ID_DM_CUSTOM_HEIGHT_BASE) &&
        (iDataItemID <  ID_DM_CUSTOM_HEIGHT_BASE + MAX_NUM_CUSTOM_PAPERS))
      {
      bSuccess = TRUE;
        x = iDataItemID - ID_DM_CUSTOM_HEIGHT_BASE;
      lpPSExtDevmode->dm.custPaper[x].customHeight = (float)dwData;
      }

    if ((iDataItemID >= ID_DM_CUSTOM_TRANSVERSE_BASE) &&
        (iDataItemID <  ID_DM_CUSTOM_TRANSVERSE_BASE + MAX_NUM_CUSTOM_PAPERS))
      {
      bSuccess = TRUE;
        x = iDataItemID - ID_DM_CUSTOM_TRANSVERSE_BASE;
      lpPSExtDevmode->dm.custPaper[x].Transverse = (BOOL)(LOWORD(dwData));
      }

    if ((iDataItemID >= ID_DM_CUSTOM_WIDTH_OFFSET_BASE) &&
        (iDataItemID <  ID_DM_CUSTOM_WIDTH_OFFSET_BASE + MAX_NUM_CUSTOM_PAPERS))
      {
      bSuccess = TRUE;
        x = iDataItemID - ID_DM_CUSTOM_WIDTH_OFFSET_BASE;
      lpPSExtDevmode->dm.custPaper[x].widthOffset = (int)(LOWORD(dwData));
      }

    if ((iDataItemID >= ID_DM_CUSTOM_HEIGHT_OFFSET_BASE) &&
        (iDataItemID <  ID_DM_CUSTOM_HEIGHT_OFFSET_BASE + MAX_NUM_CUSTOM_PAPERS))
      {
      bSuccess = TRUE;
        x = iDataItemID - ID_DM_CUSTOM_HEIGHT_OFFSET_BASE;
      lpPSExtDevmode->dm.custPaper[x].heightOffset = (int)(LOWORD(dwData));
      }
    if ((iDataItemID >= ID_DM_CUSTOM_MARGIN_TOP_BASE) &&
        (iDataItemID <  ID_DM_CUSTOM_MARGIN_TOP_BASE + MAX_NUM_CUSTOM_PAPERS))
      {
      bSuccess = TRUE;
        x = iDataItemID - ID_DM_CUSTOM_MARGIN_TOP_BASE;
      lpPSExtDevmode->dm.custPaper[x].HWmargins.top = (int)(LOWORD(dwData));
      }

    if ((iDataItemID >= ID_DM_CUSTOM_MARGIN_BOTTOM_BASE) &&
        (iDataItemID <  ID_DM_CUSTOM_MARGIN_BOTTOM_BASE + MAX_NUM_CUSTOM_PAPERS))
      {
      bSuccess = TRUE;
        x = iDataItemID - ID_DM_CUSTOM_MARGIN_BOTTOM_BASE;

      lpPSExtDevmode->dm.custPaper[x].HWmargins.bottom = (int)(LOWORD(dwData));
      }

    if ((iDataItemID >= ID_DM_CUSTOM_MARGIN_LEFT_BASE) &&
        (iDataItemID <  ID_DM_CUSTOM_MARGIN_LEFT_BASE + MAX_NUM_CUSTOM_PAPERS))
      {
      bSuccess = TRUE;
        x = iDataItemID - ID_DM_CUSTOM_MARGIN_LEFT_BASE;

      lpPSExtDevmode->dm.custPaper[x].HWmargins.left =  (int)(LOWORD(dwData));
      }

    if ((iDataItemID >= ID_DM_CUSTOM_MARGIN_RIGHT_BASE) &&
        (iDataItemID <  ID_DM_CUSTOM_MARGIN_RIGHT_BASE + MAX_NUM_CUSTOM_PAPERS))
      {
      bSuccess = TRUE;
        x = iDataItemID - ID_DM_CUSTOM_MARGIN_RIGHT_BASE;
      lpPSExtDevmode->dm.custPaper[x].HWmargins.right = (int)(LOWORD(dwData));
      }

    }

  if (!bSuccess)
    { /* Handle Margins and Paper Sizes */
    if ((iDataItemID >= ID_DM_MARGIN_BASE_LEFT) &&
        (iDataItemID < ID_DM_MARGIN_BASE_LEFT + MAX_NUM_PAPER_MARGINS))
      {
      bSuccess = TRUE;
      lpPSExtDevmode->dm2.revisedPaperMargins[iDataItemID-ID_DM_MARGIN_BASE_LEFT].left =
        (int)(LOWORD(dwData));
      }

    if ((iDataItemID >= ID_DM_MARGIN_BASE_RIGHT) &&
        (iDataItemID < ID_DM_MARGIN_BASE_RIGHT + MAX_NUM_PAPER_MARGINS))
      {
      bSuccess = TRUE;
      lpPSExtDevmode->dm2.revisedPaperMargins[iDataItemID-ID_DM_MARGIN_BASE_RIGHT].right =
        (int)(LOWORD(dwData));
      }

    if ((iDataItemID >= ID_DM_MARGIN_BASE_TOP) &&
        (iDataItemID < ID_DM_MARGIN_BASE_TOP + MAX_NUM_PAPER_MARGINS))
      {
      bSuccess = TRUE;
      lpPSExtDevmode->dm2.revisedPaperMargins[iDataItemID-ID_DM_MARGIN_BASE_TOP].top =
        (int)(LOWORD(dwData));
      }

    if ((iDataItemID >= ID_DM_MARGIN_BASE_BOTTOM) &&
        (iDataItemID < ID_DM_MARGIN_BASE_BOTTOM + MAX_NUM_PAPER_MARGINS))
      {
      bSuccess = TRUE;
      lpPSExtDevmode->dm2.revisedPaperMargins[iDataItemID-ID_DM_MARGIN_BASE_BOTTOM].bottom =
        (int)(LOWORD(dwData));
      }
    }

  if (!bSuccess)
    { /* Handle OEM Data */
    if ((iDataItemID >= ID_DM_OEM_DATA_BASE) &&
        (iDataItemID < ID_DM_OEM_DATA_BASE + (int)lpPSExtDevmode->dm.numOEMDocSticky))
      {
      DWORD FAR *lpData;
      WORD      index;

      bSuccess = TRUE;
      index = (MAXOPTIONSTATES - 1) - (iDataItemID - ID_DM_OEM_DATA_BASE);
      lpData = (DWORD FAR *) &(lpPSExtDevmode->dm.optionState[index]);
      *(lpData) = dwData;
      }
    }

  if (!bSuccess)
    {
    switch (iDataItemID)
      {
      case ID_DM_DM_DEVICENAME:
        break;
      case ID_DM_DM_SPECVERSION:
        break;
      case ID_DM_DM_ORIENTATION:
        break;
      case ID_DM_DM_PAPERSIZE:
        break;
      case ID_DM_DM_PAPERLENGTH:
        break;
      case ID_DM_DM_PAPERWIDTH:
        break;
      case ID_DM_DM_SCALE:
        lpPSExtDevmode->dm.Scale = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_DM_COPIES:
        break;
      case ID_DM_DM_DEFAULTSOURCE:
        break;
      case ID_DM_DM_PRINTQUALITY:
        break;
      case ID_DM_DM_COLOR:
        break;
      case ID_DM_DM_DUPLEX:
        break;
      case ID_DM_DM_COLLATE:
        break;
      case ID_DM_DM_YRESOLUTION:
        break;
      case ID_DM_DM_TTOPTION:
        break;
      case ID_DM_COPIES:
        if ((LOWORD(dwData)) > MAX_COPIES)
            bSuccess= FALSE;
        else
        {
        lpPSExtDevmode->dm.Copies = (int)(LOWORD(dwData));
            bSuccess = TRUE;
        }
        break;
      case ID_DM_LAYOUT:
        lpPSExtDevmode->dm.layout = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
     case ID_DM_PRINT_PAGE_BORDER:
        lpPSExtDevmode->dm2.bPrintPageBorder = (BOOL)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_PAPER_ORIENTATION:
        lpPSExtDevmode->dm.PaperOrient = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DEFAULT_COLORDEVICE:
        break;
      case ID_DM_USE_IMAGE_COLOR_MATCHING:
        lpPSExtDevmode->dm.useImageColorMatching = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_COLOR_METHOD:
        lpPSExtDevmode->dm.iColorMatchingMethod = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_RENDERING_INTENT:
        lpPSExtDevmode->dm.iRenderingIntent = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_ABSOLUTECOLORMETRIC:
        lpPSExtDevmode->dm.iAbsoluteColorimetric = (short)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_USE_HALFTONE_PARAMS:
        lpPSExtDevmode->dm.useDefaultHalftoneParams = (BOOL)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_SCREEN_FREQ:
        lpPSExtDevmode->dm.ScreenFrequency = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_SCREEN_ANGLE:
        lpPSExtDevmode->dm.ScreenAngle = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_HALFTONE_MODIFIED:
        lpPSExtDevmode->dm2.bHalftoneModified = (BYTE)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_NEGATIVE_IMAGE:
        lpPSExtDevmode->dm.bNegImage = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_MIRROR:
        lpPSExtDevmode->dm.bMirror = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_DIALECT:
        bSuccess = TRUE;
        lpPSExtDevmode->dm.enumDialect = (int)(LOWORD(dwData));
        break;
      case ID_DM_CURRENT_CUST_PAPER:
        bSuccess = TRUE;
        lpPSExtDevmode->dm.currentCustPaper = (int)(LOWORD(dwData));
        break;
      case ID_DM_DOWNLOAD_HEADER:
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.fHeader = (BOOL)(LOWORD(dwData));
        break;
      case ID_DM_USE_ERROR_HANDLER:
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.bErrHandler = (BOOL)(LOWORD(dwData));
        break;
      case ID_DM_USER_VM_SELECTION:
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.fUserVMSelection = (float)dwData;
        break;
      case ID_DM_USER_FONTCACHE_SELECTION:
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.fUserFCSelection = (float)dwData;
        break;
      case ID_DM_PPD_PASSWORD:
        break;
      case ID_DM_TT_DL_FORMAT:
        lpPSExtDevmode->dm2.iDLFontFmt = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_PS_DL_FORMAT:
        lpPSExtDevmode->dm2.iPS_DLFontFmt = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
#ifdef Adobe_Driver
      case ID_DM_FAX_35FONTS_ONLY:
        lpPSExtDevmode->dm2.bFax35FontsOnly = (BOOL)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
#endif
      case ID_DM_TT_SUBS_SOURCE:
        lpPSExtDevmode->dm2.iTTSubsFmtSource = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_MIN_OUTLINE_PPEM:
        lpPSExtDevmode->dm2.iMinOutlinePPEM = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_JOB_TIMEOUT:
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.iJobTimeout = (int)(LOWORD(dwData));
        break;
      case ID_DM_WAIT_TIMEOUT:
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.iWaitTimeout = (int)(LOWORD(dwData));
        break;
      case ID_DM_USE_LEVEL2:
        bSuccess = TRUE;
//        lpPSExtDevmode->dm2.useLanguageLevel = (BOOL)(LOWORD(dwData));
        break;
#ifdef ADOBE_DRIVER_42
      case ID_DM_USE_LANGUAGE_LEVEL:
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.useLanguageLevel = (WORD)(LOWORD(dwData));
        break;
#endif
      case ID_DM_BITMAP_COMPRESSION:
#ifndef ADOBE_DRIVER_42
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.bCompress = (BOOL)(LOWORD(dwData));
#endif
        break;
      case ID_DM_PROTOCOL:
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.iDataOutputFormat = (int)(LOWORD(dwData));
        break;
      case ID_DM_SEND_CTRL_D_BEFORE:
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.bSendCtrlDBefore = (BOOL)(LOWORD(dwData));
        break;
      case ID_DM_SEND_CTRL_D_AFTER:
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.bSendCtrlDAfter = (BOOL)(LOWORD(dwData));
        break;
      case ID_DM_IS_ROTATED:
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.bIsRotated = (BOOL)(LOWORD(dwData));
        break;
//      case ID_DM_PJL_PROTOCOL:
//        break;
      case ID_DM_MIN_VM_BOUND:
        lpPSExtDevmode->dm2.fMinVM = (float)dwData;
        bSuccess = TRUE;
        break;
      case ID_DM_MAX_VM_BOUND:
        lpPSExtDevmode->dm2.fMaxVM = (float)dwData;
        bSuccess = TRUE;
        break;
      case ID_DM_MIN_FONTCACHE_BOUND:
        lpPSExtDevmode->dm2.fMinFontCache = (float)dwData;
        bSuccess = TRUE;
        break;
      case ID_DM_MAX_FONTCACHE_BOUND:
        lpPSExtDevmode->dm2.fMaxFontCache = (float)dwData;
        bSuccess = TRUE;
        break;
      case ID_DM_ALLOW_EXIT_SERVER:
        break;
      case ID_DM_FAVOR_TRUETYPE:
        lpPSExtDevmode->dm2.bFavorTT = (BOOL)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_MARGIN_BASE_LEFT:
        break;
      case ID_DM_MARGIN_BASE_RIGHT:
        break;
      case ID_DM_MARGIN_BASE_TOP:
        break;
      case ID_DM_MARGIN_BASE_BOTTOM:
        break;
#ifdef Adobe_Driver
      case ID_DM_FAXING_P:
#ifndef MICROSOFT_DRIVER_VERSION
        bSuccess = TRUE;
        lpPSExtDevmode->dm2.bFAXingP = (int)(LOWORD(dwData));
#else
        // don't change anything, return success or failure as requested
        bSuccess = !(LOWORD(dwData));
#endif
        break;
      case ID_DM_FAXING_D:
#ifndef MICROSOFT_DRIVER_VERSION
        bSuccess = TRUE;
        lpPSExtDevmode->dm.bFAXingD = (int)(LOWORD(dwData));
#else
        // don't change anything, return success or failure as requested
        bSuccess = !(LOWORD(dwData));
#endif
        break;
#endif
      case ID_DM_TT_RASTERIZER_TYPE:    // THuynh 11/30/94
        lppd->lpPSExtDevmode->dm2.TTRasterizer = (TTRAST_OPT)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_WATERMARK:
        lppd->lpPSExtDevmode->dm.dwWatermarkID = dwData;
        bSuccess = TRUE;
        break;
      case ID_DM_WATERMARK_FIRSTPAGEONLY:
        lppd->lpPSExtDevmode->dm.WMFirstPageOnly = (int)(LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_WATERMARK_FOREGROUND:
        lppd->lpPSExtDevmode->dm.WMForeGround = (int) (LOWORD(dwData));
        bSuccess = TRUE;
        break;
      case ID_DM_WATERMARK_OUTLINE:
        lppd->lpPSExtDevmode->dm.WMOutline = (int) (LOWORD(dwData));
        bSuccess = TRUE;
        break;

      case ID_DM_TRUETYPE_WIDE:
        lpPSExtDevmode->dm2.bTrueTypeWide = (BOOL)(LOWORD(dwData));
        bSuccess = TRUE;
        break;

      case ID_DM_FULL_DOWNLOAD:
        lpPSExtDevmode->dm2.bFullDown = (BOOL)(LOWORD(dwData));
        bSuccess = TRUE;
        break;

      case ID_DM_TRUETYPE_FAST:
        lpPSExtDevmode->dm2.bTrueTypeFast = (BOOL)(LOWORD(dwData));
        bSuccess = TRUE;
        break;

      case ID_DM_EUDC_ABLE:
        lpPSExtDevmode->dm2.bEUDCAble = (BOOL)(LOWORD(dwData));
        bSuccess = TRUE;
        break;

      case ID_DM_DITHERTYPE:
        if (dwData == DMDITHER_NONE || dwData == DMDITHER_COARSE ||
            dwData == DMDITHER_FINE || dwData == DMDITHER_LINEART ||
               dwData == DMDITHER_ERRORDIFFUSION || dwData == DMDITHER_GRAYSCALE)
        {
           lpPSExtDevmode->dm.dm.dmDitherType = dwData;
           bSuccess = TRUE;
        }
          else
           bSuccess = FALSE;

        break;

      case ID_DM_DMMEDIATYPE:
        if (dwData == DMMEDIA_TRANSPARENCY || dwData == DMMEDIA_STANDARD ||
            dwData == DMMEDIA_GLOSSY || dwData >= 256)
        {
           lpPSExtDevmode->dm.dm.dmMediaType = dwData;
              bSuccess = TRUE;
        } else
              bSuccess = FALSE;

        break;

      case ID_ALERT_INCOMPATIBLE:
        {
        char alertVal;

        bSuccess = TRUE;
        alertVal = (char)(LOWORD(dwData));
        SetShowAlert(alertVal);

        break;
        }

      case ID_DM_ADD_EURO:
        lpPSExtDevmode->dm2.bAddEuro = (BOOL)(LOWORD(dwData));
        bSuccess = TRUE;
        break;

      }
    }

  return (bSuccess);
}

/************************************************************************/

DWORD _loadds FAR PASCAL DRVGetDWord(HANDLE hContext, int iDataItemID, BOOL bDefault)
{
  DWORD retVal = 0L;
  LPOEMINFO lpOEMInfo = NULL;
  LPPSEXTDEVMODE lpPSExtDevmode = NULL;
  LPPRINTERINFO lpPrinterInfo = NULL;
  LPPDEVICE lppd = NULL;
  int iKeywordIndex;
  int iVal;
  BOOL bSuccess = FALSE;
  LPBYTE        lpOptionsBlock = NULL;
  LPMAINKEYHDR  lpCurMainKeyHdr = NULL;
  LPPAPERINFO   lpPaperInfo = NULL;
  volatile int x;


    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        lpPSExtDevmode = lpOEMInfo->lpPSExtDevmode;

        lppd = lpOEMInfo->lppd;
        if (lppd)
        {
            lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);
            lpOptionsBlock = lppd->lpWPXblock->WPXarrays;
            if (lpPrinterInfo)
            {
                lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;
                if (lpCurMainKeyHdr)
                    lpPaperInfo = (LPPAPERINFO)MAKELONG(
                            lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );
            }
        }
        GlobalUnlock(hContext);
    }
    else return (0xFFFF);

    // for backward compatibility
    if (iDataItemID == ID_DM_COLLATE)
       iDataItemID = ID_DM_COLLATION;

    if ((ID_DM_DOCUMENT_STICKY_OPTIONS_BASE <= iDataItemID) &&
       (iDataItemID < ID_DM_DOCUMENT_STICKY_OPTIONS_BASE + 100))
    {
       if (lpPrinterInfo)
       {
            iKeywordIndex = lpPrinterInfo->DocSticky.w.offset + (iDataItemID -
                                  ID_DM_DOCUMENT_STICKY_OPTIONS_BASE);
            bSuccess = TRUE;
       }
    }
       if ((ID_DM_PRINTER_STICKY_OPTIONS_BASE <= iDataItemID) &&
       (iDataItemID < ID_DM_PRINTER_STICKY_OPTIONS_BASE + 100))
       {
          if (lpPrinterInfo)
          {
             iKeywordIndex = lpPrinterInfo->PrinterSticky.w.offset + (iDataItemID -
                                  ID_DM_PRINTER_STICKY_OPTIONS_BASE);
            bSuccess = TRUE;
          }
       }

    if (bSuccess == TRUE)
    {
       WORD curr_PPD_opt_id;

       if (bDefault)   // WPX IDs
       {
           if (bSuccess == TRUE)
           {
              LPMAINKEYHDR  lpCurMainKeyHdr;

              lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + iKeywordIndex;
              retVal = (DWORD)(lpCurMainKeyHdr->DefaultOptionIndex);
           }
       }
       else
       {
          if (lppd)
          {
             if (KeywordGetCurrentOption(lppd, iKeywordIndex, (LPWORD)&curr_PPD_opt_id))
                retVal = (DWORD)curr_PPD_opt_id;
             else
                retVal = (DWORD)-1;
          }
          else
            bSuccess = FALSE;
      }
    }
    /* Check the predefined options first */
    if (!bSuccess)
    {
        switch (iDataItemID)
        {
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAPERINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAGEREGIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_DUPLEXINGINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_INPUTSLOTINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_RESOLUTIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTBININFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEDIATYPEINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEMORYINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_COLLATIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTORDERINFO:
                if (bDefault)
                {

                   if (lpPrinterInfo)
                   {
                      LPMAINKEYHDR  lpCurMainKeyHdr;
                      volatile  int x;

                      x = iDataItemID - ID_DM_PREDEFINED_OPTIONS_BASE;
                      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + x;
                      retVal = (DWORD)(lpCurMainKeyHdr->DefaultOptionIndex);
                      bSuccess = TRUE;
                    }
                }
                else
                {
                   if (lppd)
                   {
                      iKeywordIndex = iDataItemID - ID_DM_PREDEFINED_OPTIONS_BASE;
                      KeywordGetCurrentOption(lppd,iKeywordIndex,(LPWORD)(&iVal));
                      retVal = (LONG)iVal;
                      bSuccess = TRUE;
                    }
                }
                break;
            case ID_DEFAULT_NUM_DOCUMENT_STICKY_OPTIONS:
                if (lpPrinterInfo)
                {
                    retVal = (DWORD)(lpPrinterInfo->DocSticky.w.length);
                    bSuccess = TRUE;
                }
                break;
            case ID_DEFAULT_NUM_PRINTER_STICKY_OPTIONS:
                if (lpPrinterInfo)
                {
                    retVal = (DWORD)(lpPrinterInfo->PrinterSticky.w.length);
                    bSuccess = TRUE;
                }
                break;
        }
    }

    if (!bSuccess && lpPSExtDevmode)
    {
        if ((iDataItemID >= ID_DM_CUSTOM_NAME_BASE) &&
            (iDataItemID <  ID_DM_CUSTOM_NAME_BASE + MAX_NUM_CUSTOM_PAPERS))
        {
            bSuccess = TRUE;
            x = iDataItemID - ID_DM_CUSTOM_NAME_BASE;
            retVal = (DWORD)(lpPSExtDevmode->dm.custPaper[x].CustomName);
        }

        if ((iDataItemID >= ID_DM_CUSTOM_WIDTH_BASE) &&
            (iDataItemID <  ID_DM_CUSTOM_WIDTH_BASE + MAX_NUM_CUSTOM_PAPERS))
        {
            bSuccess = TRUE;
            x = iDataItemID - ID_DM_CUSTOM_WIDTH_BASE;
            if (bDefault)
               retVal = (DWORD)(lpPrinterInfo->custpageinfo.width.min);
            else
               retVal = (DWORD)(lpPSExtDevmode->dm.custPaper[x].customWidth);
        }
        if ((iDataItemID >= ID_DM_CUSTOM_HEIGHT_BASE) &&
            (iDataItemID <  ID_DM_CUSTOM_HEIGHT_BASE + MAX_NUM_CUSTOM_PAPERS))

        {
            bSuccess = TRUE;
            x = iDataItemID - ID_DM_CUSTOM_HEIGHT_BASE;
            if (bDefault)
               retVal = (DWORD)(lpPrinterInfo->custpageinfo.height.min);
            else
               retVal = (DWORD)(lpPSExtDevmode->dm.custPaper[x].customHeight);
        }
        if ((iDataItemID >= ID_DM_CUSTOM_TRANSVERSE_BASE) &&
            (iDataItemID <  ID_DM_CUSTOM_TRANSVERSE_BASE + MAX_NUM_CUSTOM_PAPERS))
        {
            bSuccess = TRUE;
            x = iDataItemID - ID_DM_CUSTOM_TRANSVERSE_BASE;
            if (bDefault)
               retVal = (DWORD)(lpPrinterInfo->custpageinfo.Orientation.min);
            else
               retVal = (DWORD)(lpPSExtDevmode->dm.custPaper[x].Transverse);
        }
        if ((iDataItemID >= ID_DM_CUSTOM_WIDTH_OFFSET_BASE) &&
            (iDataItemID <  ID_DM_CUSTOM_WIDTH_OFFSET_BASE + MAX_NUM_CUSTOM_PAPERS))
        {
            bSuccess = TRUE;
            x = iDataItemID - ID_DM_CUSTOM_WIDTH_OFFSET_BASE;
            if (bDefault)
               retVal = (DWORD)(lpPrinterInfo->custpageinfo.widthOffset.min);
            else
               retVal = (DWORD)(lpPSExtDevmode->dm.custPaper[x].widthOffset);
        }
        if ((iDataItemID >= ID_DM_CUSTOM_HEIGHT_OFFSET_BASE) &&
            (iDataItemID <  ID_DM_CUSTOM_HEIGHT_OFFSET_BASE + MAX_NUM_CUSTOM_PAPERS))
        {
            bSuccess = TRUE;
            x = iDataItemID - ID_DM_CUSTOM_HEIGHT_OFFSET_BASE;
            if (bDefault)
               retVal = (DWORD)(lpPrinterInfo->custpageinfo.heightOffset.min);
            else
               retVal = (DWORD)(lpPSExtDevmode->dm.custPaper[x].heightOffset);
        }
    }

    if (!bSuccess)
    { /* Handle Margins and Paper Sizes */

        if ((iDataItemID >= ID_DEFAULT_PAPER_HEIGHT_BASE) &&
            (iDataItemID < ID_DEFAULT_PAPER_HEIGHT_BASE + MAX_NUM_PAPER_SIZES) &&
            lpPaperInfo)
        {
            bSuccess = TRUE;
            retVal = MAKELONG(lpPaperInfo[iDataItemID-ID_DEFAULT_PAPER_HEIGHT_BASE].length, 0);
        }

        if ((iDataItemID >= ID_DEFAULT_PAPER_WIDTH_BASE) &&
            (iDataItemID < ID_DEFAULT_PAPER_WIDTH_BASE + MAX_NUM_PAPER_SIZES) &&
            lpPaperInfo)
        {
            bSuccess = TRUE;
            retVal = MAKELONG(lpPaperInfo[iDataItemID-ID_DEFAULT_PAPER_WIDTH_BASE].width, 0);
        }

        if ((iDataItemID >= ID_DM_MARGIN_BASE_LEFT) &&
            (iDataItemID < ID_DM_MARGIN_BASE_LEFT + MAX_NUM_PAPER_MARGINS) &&
            lpPSExtDevmode)
        {
            bSuccess = TRUE;

            if (bDefault)
               retVal = MAKELONG(lpPaperInfo[iDataItemID-ID_DM_MARGIN_BASE_LEFT].imageableArea.left, 0);
            else
               retVal = MAKELONG(lpPSExtDevmode->dm2.revisedPaperMargins[iDataItemID-ID_DM_MARGIN_BASE_LEFT].left, 0);
        }
        if ((iDataItemID >= ID_DM_MARGIN_BASE_RIGHT) &&
            (iDataItemID < ID_DM_MARGIN_BASE_RIGHT + MAX_NUM_PAPER_MARGINS) &&
            lpPSExtDevmode)
        {
            bSuccess = TRUE;
            if (bDefault)
               retVal = MAKELONG(lpPaperInfo[iDataItemID-ID_DM_MARGIN_BASE_RIGHT].imageableArea.right, 0);
            else
               retVal = MAKELONG(lpPSExtDevmode->dm2.revisedPaperMargins[iDataItemID-ID_DM_MARGIN_BASE_RIGHT].right, 0);
        }
        if ((iDataItemID >= ID_DM_MARGIN_BASE_TOP) &&
            (iDataItemID < ID_DM_MARGIN_BASE_TOP + MAX_NUM_PAPER_MARGINS) &&
            lpPSExtDevmode)
        {
            bSuccess = TRUE;
            if (bDefault)
               retVal = MAKELONG(lpPaperInfo[iDataItemID-ID_DM_MARGIN_BASE_TOP].imageableArea.top, 0);
        else
               retVal = MAKELONG(lpPSExtDevmode->dm2.revisedPaperMargins[iDataItemID-ID_DM_MARGIN_BASE_TOP].top, 0);
        }
        if ((iDataItemID >= ID_DM_MARGIN_BASE_BOTTOM) &&
            (iDataItemID < ID_DM_MARGIN_BASE_BOTTOM + MAX_NUM_PAPER_MARGINS) &&
            lpPSExtDevmode)
        {
            bSuccess = TRUE;
            if (bDefault)
               retVal = MAKELONG(lpPaperInfo[iDataItemID-ID_DM_MARGIN_BASE_BOTTOM].imageableArea.bottom, 0);
        else
               retVal = MAKELONG(lpPSExtDevmode->dm2.revisedPaperMargins[iDataItemID-ID_DM_MARGIN_BASE_BOTTOM].bottom, 0);
        }
         // add custom paper HWmargins
        if ((iDataItemID >= ID_DM_CUSTOM_MARGIN_BOTTOM_BASE) &&
            (iDataItemID < ID_DM_CUSTOM_MARGIN_BOTTOM_BASE + MAX_NUM_CUSTOM_PAPERS) &&
            lpPSExtDevmode)
        {
            bSuccess = TRUE;
            x = iDataItemID - ID_DM_CUSTOM_MARGIN_BOTTOM_BASE;
            retVal = MAKELONG(lpPSExtDevmode->dm.custPaper[x].HWmargins.bottom, 0);
        }
        if ((iDataItemID >= ID_DM_CUSTOM_MARGIN_TOP_BASE) &&
            (iDataItemID < ID_DM_CUSTOM_MARGIN_TOP_BASE + MAX_NUM_CUSTOM_PAPERS) &&
            lpPSExtDevmode)
        {
            bSuccess = TRUE;
            x = iDataItemID - ID_DM_CUSTOM_MARGIN_TOP_BASE;
            retVal = MAKELONG(lpPSExtDevmode->dm.custPaper[x].HWmargins.top, 0);
        }
        if ((iDataItemID >= ID_DM_CUSTOM_MARGIN_RIGHT_BASE) &&
            (iDataItemID < ID_DM_CUSTOM_MARGIN_RIGHT_BASE + MAX_NUM_CUSTOM_PAPERS) &&
            lpPSExtDevmode)
        {
            bSuccess = TRUE;
            x = iDataItemID - ID_DM_CUSTOM_MARGIN_RIGHT_BASE;
            retVal = MAKELONG(lpPSExtDevmode->dm.custPaper[x].HWmargins.right, 0);
        }

        if ((iDataItemID >= ID_DM_CUSTOM_MARGIN_LEFT_BASE) &&
            (iDataItemID < ID_DM_CUSTOM_MARGIN_LEFT_BASE + MAX_NUM_CUSTOM_PAPERS) &&
            lpPSExtDevmode)
        {
            bSuccess = TRUE;
            x = iDataItemID - ID_DM_CUSTOM_MARGIN_LEFT_BASE;
            retVal = MAKELONG(lpPSExtDevmode->dm.custPaper[x].HWmargins.left, 0);
        }

    }

    if (!bSuccess)
    {   /* Handle OEM Data */
        if ((iDataItemID >= ID_DM_OEM_DATA_BASE) &&
            (iDataItemID < ID_DM_OEM_DATA_BASE + (int)lpPSExtDevmode->dm.numOEMDocSticky) &&
            lpPSExtDevmode)
        {
            DWORD FAR *lpData;
            WORD  index;

            bSuccess = TRUE;
            //      retVal = lpPSExtDevmode->dm.OEMData[iDataItemID-ID_DM_OEM_DATA_BASE];
            index = (MAXOPTIONSTATES - 1) - (iDataItemID - ID_DM_OEM_DATA_BASE);
            lpData = (DWORD FAR *) &(lpPSExtDevmode->dm.optionState[index]);
            return *(lpData);
        }
    }

    if (!bSuccess)
    {
        switch (iDataItemID)
        {
            case ID_DM_DM_DEVICENAME:
                break;
            case ID_DM_DM_SPECVERSION:
                break;
            case ID_DM_DM_ORIENTATION:
                break;
            case ID_DM_DM_PAPERSIZE:
                break;
            case ID_DM_DM_PAPERLENGTH:
                break;
            case ID_DM_DM_PAPERWIDTH:
                break;
            case ID_DM_DM_SCALE:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (LONG)100;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.Scale, 0);
                }
                break;
            case ID_DM_DM_DEFAULTSOURCE:
                break;
            case ID_DM_DM_PRINTQUALITY:
                break;
            case ID_DM_DM_COLOR:
                break;
            case ID_DM_DM_DUPLEX:
                break;
            case ID_DM_DM_COLLATE:
                break;
            case ID_DM_DM_YRESOLUTION:
                break;
            case ID_DM_DM_TTOPTION:
                break;
            case ID_DM_COPIES:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = 1L;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.Copies, 0);
                }
                break;
            case ID_DM_LAYOUT:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (LONG)ONE_UP;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.layout, 0);
                }
                break;
            case ID_DM_PRINT_PAGE_BORDER:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (LONG)TRUE;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm2.bPrintPageBorder, 0);
                }
                break;
            case ID_DM_PAPER_ORIENTATION:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (LONG)OR_PORTRAIT;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.PaperOrient, 0);
                }
                break;

            case ID_DEFAULT_DUPLEX:
                if (bDefault)
                {
                   if (lpPrinterInfo)
                   {
                      bSuccess = TRUE;
                      retVal = (DWORD)lpPrinterInfo->devcaps.SupportsDuplexing;
                   }
                }
                break;
            case ID_DEFAULT_COLLATE:
                if (bDefault)
                {
                   if (lpPrinterInfo)
                   {
                      bSuccess = TRUE;
                      retVal = (DWORD)lpPrinterInfo->devcaps.bCollateSupport;
                   }
                }
                break;
            case ID_DEFAULT_OUTPUTORDER:
                if (bDefault)
                {
                   if (lpPrinterInfo)
                   {
                      bSuccess = TRUE;
                      retVal = (DWORD)lpPrinterInfo->devcaps.bOutputOrderSupport;
                   }
                }
                break;
            case ID_DEFAULT_COLORDEVICE:
                if (bDefault)
                {
                   if (lpPrinterInfo)
                   {
                      bSuccess = TRUE;
                      retVal = (DWORD)lpPrinterInfo->devcaps.color;
                   }
                }
                break;
            case ID_DM_USE_IMAGE_COLOR_MATCHING:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (LONG)ICM_ALLOW;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.useImageColorMatching, 0);
                }
                break;
            case ID_DM_COLOR_METHOD:
                if (bDefault)
                {
                     bSuccess = TRUE;
                     retVal = (LONG)DMICMMETHOD_SYSTEM;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.iColorMatchingMethod, 0);
                }
                break;
            case ID_DM_RENDERING_INTENT:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (LONG)INTENT_SATURATION;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.iRenderingIntent, 0);
                }
                break;
            case ID_DM_ABSOLUTECOLORMETRIC:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (LONG)0;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.iAbsoluteColorimetric, 0);
                }
                break;
            case ID_DM_USE_HALFTONE_PARAMS:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (LONG)TRUE;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.useDefaultHalftoneParams, 0);
                }
                break;
            case ID_DM_SCREEN_FREQ:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (LONG)600;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.ScreenFrequency, 0);
                }
                break;
            case ID_DM_SCREEN_ANGLE:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (LONG)450;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.ScreenAngle, 0);
                }
                break;
            case ID_DM_HALFTONE_MODIFIED:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm2.bHalftoneModified, 0);
                }
                break;
            case ID_DM_NEGATIVE_IMAGE:
                if (bDefault)
                {
                   bSuccess = TRUE;
                   retVal = (LONG)FALSE;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.bNegImage, 0);
                }
                break;
            case ID_DM_MIRROR:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (LONG)FALSE;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.bMirror, 0);
                }
                break;
            case ID_DM_DIALECT:
                if (bDefault)
                {
                    bSuccess = TRUE;
#ifndef ADOBE_DRIVER_42
                    if (lpPrinterInfo->devcaps.DefaultToPortability)
                        retVal = MAKELONG(DIA_PORTABLE, 0);
                    else
#endif
                        retVal = MAKELONG(DIA_SPEED, 0);
                }
                else
                {
                    if (lpPSExtDevmode)
                    {
                       bSuccess = TRUE;
                       retVal = MAKELONG(lpPSExtDevmode->dm.enumDialect, 0);
                    }
                }
                break;
            case ID_DM_CURRENT_CUST_PAPER:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm.currentCustPaper, 0);
                }
                break;
            case ID_DM_APP_CUST_WIDTH:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm.appCustWidth);
                }
                break;
            case ID_DM_APP_CUST_HEIGHT:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm.appCustHeight);
                }
                break;
            case ID_DM_DOWNLOAD_HEADER:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)TRUE;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.fHeader);
                }
                break;
            case ID_DM_USE_ERROR_HANDLER:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)TRUE;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.bErrHandler);
                }
                break;
            case ID_DM_USER_VM_SELECTION:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.fUserVMSelection);
                }
                break;
            case ID_DM_USER_FONTCACHE_SELECTION:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.fUserFCSelection);
                }
                break;
            case ID_DM_MIN_FONTCACHE_BOUND:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.fMinFontCache);
                }
                break;
            case ID_DM_MAX_FONTCACHE_BOUND:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.fMaxFontCache);
                }
                break;

          case ID_DM_PPD_PASSWORD:
                break;
          case ID_DM_TT_DL_FORMAT:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)TT_DLFORMAT_TYPE1;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.iDLFontFmt);
                }
                break;
            case ID_DM_PS_DL_FORMAT:
                if (bDefault)
                {
                   bSuccess = TRUE;
                   retVal = (DWORD)PS_DLFORMAT_NATIVE;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.iPS_DLFontFmt);
                }
                break;
#ifdef Adobe_Driver
            case ID_DM_FAX_35FONTS_ONLY:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.bFax35FontsOnly);
                }
                break;
#endif
            case ID_DM_TT_SUBS_SOURCE:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)TTSUBSFORMAT_TABLE;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.iTTSubsFmtSource);
                }
                break;
            case ID_DM_MIN_OUTLINE_PPEM:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)100;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.iMinOutlinePPEM);
                }
                break;
            case ID_DM_JOB_TIMEOUT:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)DEF_JOBTIMEOUT;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.iJobTimeout);
                }
                break;
            case ID_DM_WAIT_TIMEOUT:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = DEF_WAITTIMEOUT;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.iWaitTimeout);
                }
                break;
            case ID_DM_USE_LEVEL2:
                if (bDefault)
                {
                   bSuccess = TRUE;
                   if (lpPrinterInfo)
                      retVal = (DWORD)(lpPrinterInfo->devcaps.languageLevel >= 2);
                   else
                      retVal = (DWORD)FALSE;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.useLanguageLevel >= 2);
                }
                break;
#ifdef ADOBE_DRIVER_42
            case ID_DM_USE_LANGUAGE_LEVEL:
                if (bDefault)
                {
                   bSuccess = TRUE;
                   if (lpPrinterInfo)
                      retVal = (DWORD)(lpPrinterInfo->devcaps.languageLevel);
                   else
                      retVal = (DWORD)FALSE;
                }
                else if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.useLanguageLevel);
                }
                break;
#endif

            case ID_DM_BITMAP_COMPRESSION:
                break;

            case ID_DM_PROTOCOL:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)PROTOCOL_ASCII;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.iDataOutputFormat);
                }
                break;
            case ID_DM_SEND_CTRL_D_BEFORE:
                if (bDefault)
                {
                   bSuccess = TRUE;
                   retVal = (DWORD)FALSE;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.bSendCtrlDBefore);
                }
                break;
            case ID_DM_SEND_CTRL_D_AFTER:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)TRUE;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.bSendCtrlDAfter);
                }
                break;
            case ID_DM_IS_ROTATED:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.bIsRotated);
                }
                break;
//            case ID_DM_PJL_PROTOCOL:
//                break;
            case ID_DM_MIN_VM_BOUND:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.fMinVM);
                }
                break;
            case ID_DM_MAX_VM_BOUND:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.fMaxVM);
                }
                break;
            case ID_DM_ALLOW_EXIT_SERVER:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.bAllowExitServer);
                }
                break;
            case ID_DM_FAVOR_TRUETYPE:
                if (bDefault)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)FALSE;
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.bFavorTT);
                }
                break;

#ifdef Adobe_Driver
            case ID_DM_FAXING_D:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm.bFAXingD);
                }
                break;
            case ID_DM_FAXING_P:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.bFAXingP);
                }
                break;
#endif
             case ID_DM_TRUETYPE_WIDE:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm2.bTrueTypeWide, 0);
                }
                break;

             case ID_DM_FULL_DOWNLOAD:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm2.bFullDown, 0);
                }
                break;

             case ID_DM_TRUETYPE_FAST:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm2.bTrueTypeFast, 0);
                }
                break;

            case ID_DM_EUDC_ABLE:
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = MAKELONG(lpPSExtDevmode->dm2.bEUDCAble, 0);
                }
                break;


            case ID_DM_WATERMARK:
                if (lpPSExtDevmode)
                {
                    retVal = lppd->lpPSExtDevmode->dm.dwWatermarkID;
                    bSuccess = TRUE;
                }
                break;
            case ID_DM_WATERMARK_FIRSTPAGEONLY:
                if (lpPSExtDevmode)
                {
                    retVal = (DWORD)(lppd->lpPSExtDevmode->dm.WMFirstPageOnly);
                    bSuccess = TRUE;
                }
                break;
            case ID_DM_WATERMARK_FOREGROUND:
                if (lpPSExtDevmode)
                {
                    retVal = (DWORD)lppd->lpPSExtDevmode->dm.WMForeGround;
                    bSuccess = TRUE;
                }
                break;
            case ID_DM_WATERMARK_OUTLINE:
                if (lpPSExtDevmode)
                {
                    retVal = (DWORD)lppd->lpPSExtDevmode->dm.WMOutline;
                    bSuccess = TRUE;
                }
                break;
            case ID_DM_ADD_EURO:
                if (bDefault)
                {
                   if (lpPrinterInfo)
                   {
                      bSuccess = TRUE;
                      if (lpPrinterInfo->devcaps.iAdHasEuro != 0xFFFF)  // PPD has *ADHasEuro
                          retVal = (DWORD)(lpPrinterInfo->devcaps.iAdHasEuro != 1);
                      else
                          retVal = (DWORD)(GetPSVersion(lppd) < 3011);
                   }
                }
                else
                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm2.bAddEuro);
                }
                break;
            case ID_DEFAULT_LANDSCAPE_ORIENTATION_PLUS90:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->devcaps.landscapeOrientPlus90;
                }
                break;

            case ID_DEFAULT_CUSTOM_PAGE_SIZE:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->devcaps.CustomPageSize;
                }
                break;

            case ID_DM_TT_RASTERIZER_TYPE:
                if (bDefault)
                {
                   if (lpPrinterInfo)
                   {
                      bSuccess = TRUE;
                      retVal = (DWORD)lpPrinterInfo->devcaps.TTRasterizer;
                   }
                }
                break;


                // Add ID_DM_DITHERTYPE and ID_DM_DMMEDIATYPE
            case ID_DM_DITHERTYPE:

                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm.dm.dmDitherType);
                }
                break;
            case ID_DM_DMMEDIATYPE:

                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPSExtDevmode->dm.dm.dmMediaType);
                }
                break;


            case ID_DEFAULT_CUSTOM_MIN_WIDTH:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->custpageinfo.width.min;
                }
                break;
            case ID_DEFAULT_CUSTOM_MAX_WIDTH:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->custpageinfo.width.max;
                }
                break;
            case ID_DEFAULT_CUSTOM_MIN_HEIGHT:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->custpageinfo.height.min;
                }
                break;
            case ID_DEFAULT_CUSTOM_MAX_HEIGHT:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->custpageinfo.height.max;
                }
                break;
            case ID_DEFAULT_CUSTOM_MIN_WIDTHOFFSET:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->custpageinfo.widthOffset.min;
                }
                break;

            case ID_DEFAULT_CUSTOM_MAX_WIDTHOFFSET:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->custpageinfo.widthOffset.max;
                }
                break;

            case ID_DEFAULT_CUSTOM_MIN_HEIGHTOFFSET:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->custpageinfo.heightOffset.min;
                }
                break;

            case ID_DEFAULT_CUSTOM_MAX_HEIGHTOFFSET:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->custpageinfo.widthOffset.max;
                }
                break;

            case ID_DEFAULT_CUSTOM_IS_CUTSHEET:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPrinterInfo->custpageinfo.isCutSheet);
                }
                break;

            case ID_DEFAULT_CUSTOM_MARGIN_TOP:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPrinterInfo->custpageinfo.HWmargins.top);
                }
                break;
            case ID_DEFAULT_CUSTOM_MARGIN_BOTTOM:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPrinterInfo->custpageinfo.HWmargins.bottom);
                }
                break;
            case ID_DEFAULT_CUSTOM_MARGIN_LEFT:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPrinterInfo->custpageinfo.HWmargins.left);
                }
                break;
            case ID_DEFAULT_CUSTOM_MARGIN_RIGHT:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPrinterInfo->custpageinfo.HWmargins.right);
                }
                break;
            case ID_DEFAULT_PJL_SUPPORT:

                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPrinterInfo->devcaps.PJLsupport);
                }
                break;

            case ID_DEFAULT_LANGUAGE_LEVEL:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPrinterInfo->devcaps.languageLevel);
                }
                break;

            case ID_DEFAULT_BCP_SUPPORT:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPrinterInfo->devcaps.BCPsupport);
                }
                break;
            case ID_DEFAULT_TBCP_SUPPORT:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPrinterInfo->devcaps.TBCPsupport);
                }
                break;
            case ID_DEFAULT_FAX_SUPPORT:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPrinterInfo->devcaps.bFaxSupport);
                }
                break;
            case ID_DEFAULT_TRUEIMAGE:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)(lpPrinterInfo->devcaps.TrueImageSupport);
                }
                break;
            case ID_DEFAULT_FREE_VM:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->devcaps.iFreeVM;
                }
                break;
            case ID_DEFAULT_PRINTER_FONTCACHE:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->devcaps.iFontCacheSize;
                }
                break;
            case ID_DEFAULT_USER_DEFINED_PROTOCOL:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->devcaps.iDefaultProtocol;
                }
                break;
            case ID_DEFAULT_ERROR_HANDLER_EXIST:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->devcaps.PrintPSErrorExist;
                }
                break;
            case ID_DEFAULT_JOB_TIMEOUT:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->devcaps.JobTimeout;
                }
                break;
            case ID_DEFAULT_WAIT_TIMEOUT:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->devcaps.WaitTimeout;
                }
                break;

            case ID_DEFAULT_USE_ERROR_HANDLER:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->devcaps.bPrintPSErrors;
                }
                break;

            case ID_ALERT_INCOMPATIBLE:
            {
                char alertval;

                bSuccess = TRUE;
                alertval = GetShowAlert(); //change the alert implementation
                retVal = (DWORD)alertval;
                break;
            }
            case ID_CHECK_ICMPROFILE:
            {
// WIN95-98
                BOOL bIsICMExist = FALSE;

                if (lpPSExtDevmode)
                {
                    bSuccess = TRUE;
                    bIsICMExist = ICMProfileInstalled(lpPrinterInfo,
                                                      lpPSExtDevmode->dm.dm.dmDeviceName);
                }
                retVal = (DWORD)bIsICMExist;
                break;
            }
            case ID_DEFAULT_MANUALFEED:
                if (lpPrinterInfo)
                {
                    bSuccess = TRUE;
                    retVal = (DWORD)lpPrinterInfo->devcaps.ManualFeed;
                }
                break;
        }
    }

    return (retVal);
}

/************************************************************************/
int _loadds FAR PASCAL  DRVGetKeywordNumOptions(HANDLE hContext, int iDataItemID)
{
  int retVal = -1;
  LPOEMINFO lpOEMInfo;
  LPPSEXTDEVMODE lpPSExtDevmode;
  LPPDEVICE lppd;
  LPPRINTERINFO lpPrinterInfo;
  int iKeywordIndex;

  if (hContext)
  {
     lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
     lpPSExtDevmode = lpOEMInfo->lpPSExtDevmode;
     lppd = lpOEMInfo->lppd;
     lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);
     GlobalUnlock(hContext);
  }
  else
     return (-1);

  if ((ID_DM_DOCUMENT_STICKY_OPTIONS_BASE <= iDataItemID) &&
      (iDataItemID < ID_DM_DOCUMENT_STICKY_OPTIONS_BASE + 100))
  {
     iKeywordIndex = lpPrinterInfo->DocSticky.w.offset + (iDataItemID -
                     ID_DM_DOCUMENT_STICKY_OPTIONS_BASE);
     KeywordGetNumOfOptions(lppd, iKeywordIndex, (LPWORD)&retVal);
  }

  if ((ID_DM_PRINTER_STICKY_OPTIONS_BASE <= iDataItemID) &&
      (iDataItemID < ID_DM_PRINTER_STICKY_OPTIONS_BASE + 100))
  {
     iKeywordIndex = lpPrinterInfo->PrinterSticky.w.offset + (iDataItemID -
                     ID_DM_PRINTER_STICKY_OPTIONS_BASE);
     KeywordGetNumOfOptions(lppd, iKeywordIndex, (LPWORD)&retVal);
  }

  /* Check the predefined options first */
  if (retVal == -1)
  {
     if (iDataItemID==ID_DM_COLLATE)
        iDataItemID = ID_DM_COLLATION;

     switch (iDataItemID)
     {
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAPERINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAGEREGIONINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_DUPLEXINGINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_INPUTSLOTINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_RESOLUTIONINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTBININFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEDIATYPEINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEMORYINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_COLLATIONINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTORDERINFO:
           iKeywordIndex = iDataItemID - ID_DM_PREDEFINED_OPTIONS_BASE;
           KeywordGetNumOfOptions(lppd, iKeywordIndex, (LPWORD)&retVal);
           break;
     }
  }
  return (retVal);          // the error return is -1
}

/************************************************************************/

BOOL _loadds FAR PASCAL DRVGetKeywordOptionTranslation(HANDLE hContext,
                                               int iDataItemID,
                                               int iIDOption,
                                               LPSTR lpOptionBuffer,
                                               unsigned int FAR *lpSize)
{
    LPOEMINFO lpOEMInfo;
    BOOL retVal = FALSE;
    LPPDEVICE lppd;
    LPPRINTERINFO lpPrinterInfo;
    int iKeywordIndex;

    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        lppd = lpOEMInfo->lppd;
        if (lppd)
        {
            lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);
            if (lpPrinterInfo)
                retVal = (lpOptionBuffer && lpSize && *lpSize > 0);
        }
        GlobalUnlock(hContext);
    }

    if (!retVal)
    {
        if (lpOptionBuffer && lpSize && *lpSize > 0)
            *lpOptionBuffer = '\0';
        if (lpSize)
            *lpSize = 0;
        return FALSE;
    }

    retVal = FALSE;
    *lpOptionBuffer = '\0';

    if ((ID_DM_DOCUMENT_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DM_DOCUMENT_STICKY_OPTIONS_BASE + 100))
    {
        iKeywordIndex = lpPrinterInfo->DocSticky.w.offset + (iDataItemID -
                        ID_DM_DOCUMENT_STICKY_OPTIONS_BASE);
        retVal = TRUE;
    }
    if (!retVal &&
        (ID_DM_PRINTER_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DM_PRINTER_STICKY_OPTIONS_BASE + 100))
    {
        iKeywordIndex = lpPrinterInfo->PrinterSticky.w.offset + (iDataItemID -
                        ID_DM_PRINTER_STICKY_OPTIONS_BASE);
        retVal = TRUE;
    }
    /* Check the predefined options first */
    if (retVal == FALSE)
    {
        if (iDataItemID==ID_DM_COLLATE)
           iDataItemID = ID_DM_COLLATION;

        switch (iDataItemID)
        {
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAPERINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAGEREGIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_DUPLEXINGINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_INPUTSLOTINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_RESOLUTIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTBININFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEDIATYPEINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEMORYINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_COLLATIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTORDERINFO:
            iKeywordIndex = iDataItemID - ID_DM_PREDEFINED_OPTIONS_BASE;
            retVal = TRUE;
            break;
        }
    }

    if (retVal)
    {
        retVal = KeywordGetOptionTranslation(lppd,iKeywordIndex,iIDOption,
                                             lpOptionBuffer,*lpSize);
    }
    *lpSize = (retVal) ? lstrlen(lpOptionBuffer) + 1 : 0;
    return (retVal);
}

/************************************************************************/

DWORD _loadds FAR PASCAL DRVGetKeywordOptionDWord(HANDLE hContext,
                                                 int iDataItemID,
                                                 int iIDOption,
                                                                BOOL bDefault)
{
  DWORD retVal = 0;
  LPOEMINFO lpOEMInfo;
  LPPDEVICE lppd;
  LPPRINTERINFO lpPrinterInfo ;
  LPMAINKEYHDR lpCurMainKeyHdr ;
  LPRESOLUTIONINFO lpResInfo;
  int option;

  if (hContext)
    {
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
    lppd = lpOEMInfo->lppd;
    lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);
    GlobalUnlock(hContext);
    }
  else
    return (0xFFFF);


  switch (iDataItemID)
    {
    case ID_DEFAULT_RES_SCREEN_FREQ:
      {
      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_RESOLUTIONINFO;
      lpResInfo = (LPRESOLUTIONINFO)MAKELONG(
                        lpCurMainKeyHdr->extraOptionArray,
                        HIWORD(lppd->lpWPXblock->WPXarrays));
      KeywordGetNumOfOptions(lppd, IND_RESOLUTIONINFO, (LPWORD)&option);

      if ( iIDOption >= option)
         retVal = 0;
      else
         retVal = (LONG)(lpResInfo[iIDOption].ScreenFreq);
      }
      break;

    case ID_DEFAULT_RES_SCREEN_ANGLE:
      {
      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_RESOLUTIONINFO;
      lpResInfo = (LPRESOLUTIONINFO)MAKELONG(
                        lpCurMainKeyHdr->extraOptionArray,
                        HIWORD(lppd->lpWPXblock->WPXarrays));
      KeywordGetNumOfOptions(lppd, IND_RESOLUTIONINFO, (LPWORD)&option);

      if ( iIDOption >= option)
         retVal = 0;
      else
         retVal = (LONG)(lpResInfo[iIDOption].ScreenAngle);
      }
      break;

    case ID_DM_AVAILABLE_VM:
      {
      LPMAINKEYHDR   lpCurMainKeyHdr;
      LPMEMORYINFO   lpMemoryInfo;

      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_MEMORYINFO;
      lpMemoryInfo = (LPMEMORYINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray,
                                            HIWORD(lppd->lpWPXblock->WPXarrays));
      retVal = (LONG)(lpMemoryInfo[iIDOption].AvailibleVM);
      }
      break;
    case ID_DM_AVAILABLE_FONTCACHE:
      {
      LPMAINKEYHDR   lpCurMainKeyHdr;
      LPMEMORYINFO   lpMemoryInfo;

      lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_MEMORYINFO;
      lpMemoryInfo = (LPMEMORYINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray,
                                            HIWORD(lppd->lpWPXblock->WPXarrays));
      retVal = (LONG)(lpMemoryInfo[iIDOption].AvailibleFC);
      }
      break;
    default:
      retVal = 0xFFFF;
      break;
    }


  return (retVal);
}

/************************************************************************/

BOOL _loadds FAR PASCAL DRVGetKeywordString(HANDLE hContext,
                                            int iDataItemID,
                                            LPSTR lpBuffer,
                                            unsigned int FAR *lpSize)
{ /* Gets the string name of the keyword */
    BOOL bSuccess = FALSE;
    int iKeywordIndex;
    int iMainKeywordIndex = -1;
    KEYWORD iKeyword = ENDOFLIST;
    STRINGREF MainKeyword;
    LPBYTE lpMainKeyword;
    unsigned int iNumOptions;
    LPPDEVICE lppd = NULL;
    LPPRINTERINFO lpPrinterInfo = NULL;
    LPMAINKEYHDR  lpCurMainKeyHdr = NULL;
    LPOEMINFO lpOEMInfo;
    unsigned int len;


    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        lppd = lpOEMInfo->lppd;
        if (lppd)
        {
            lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);
            if (lpPrinterInfo)
                bSuccess = (lpBuffer && lpSize && *lpSize > 0);
        }
        GlobalUnlock(hContext);
    }

    if (bSuccess == FALSE)
    {
        if (lpBuffer && lpSize && *lpSize > 0)
            *lpBuffer = '\0';
        if (lpSize)
            *lpSize = 0;
        return FALSE;
    }

    bSuccess = FALSE;
    *lpBuffer = '\0';
    len = 0;

    /* Take care of general keywords that are being parsed for */
    /* Doc Sticky first */
    iNumOptions = lpPrinterInfo->DocSticky.w.length;
    if ((ID_DM_DOCUMENT_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DM_DOCUMENT_STICKY_OPTIONS_BASE + (int)iNumOptions))
    {
        iKeywordIndex = lpPrinterInfo->DocSticky.w.offset + (iDataItemID -
                        ID_DM_DOCUMENT_STICKY_OPTIONS_BASE);
        bSuccess = TRUE;
    }
    if (!bSuccess)
    {
        /* Printer Sticky */
        iNumOptions = lpPrinterInfo->PrinterSticky.w.length;
        if ((ID_DM_PRINTER_STICKY_OPTIONS_BASE <= iDataItemID) &&
            (iDataItemID < ID_DM_PRINTER_STICKY_OPTIONS_BASE + (int)iNumOptions))
        {
            iKeywordIndex = lpPrinterInfo->PrinterSticky.w.offset + (iDataItemID -
                            ID_DM_PRINTER_STICKY_OPTIONS_BASE);
            bSuccess = TRUE;
        }
    }

    if (bSuccess)
    {
        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + iKeywordIndex;
        MainKeyword = lpCurMainKeyHdr->MainKey;
        lpMainKeyword = StringRefToLPBYTE(lppd, MainKeyword.dword);
        if (lstrlen((LPSTR)lpMainKeyword) + 1 > (int)*lpSize)
            lstrcpyn(lpBuffer, lpMainKeyword, *lpSize);
        else
            lstrcpy(lpBuffer, lpMainKeyword);
    }

    if (!bSuccess)
    {
        /* Take care of the main keywords we parse for */
        lpMainKeyWordsTable = (LPSTRINGREF)GlobalAllocPtr(GHND, MAXMAINKEYWORDSTABLESIZ * sizeof(STRINGREF));
        if (lpMainKeyWordsTable)
        {
            lpStringPtr = (LPBYTE)GlobalAllocPtr(GHND, 0x10000L);
            if (lpStringPtr)
            {
                initMainKeyWordsTableStub();

                /* Figure out which keyword the OEM wants -John Kwan */
                switch (iDataItemID)
                {
                    case ID_DM_DM_DEVICENAME:
                      iKeyword = MODELNAME;
                      bSuccess = TRUE;
                      break;
                    case ID_DEFAULT_COLORDEVICE:
                      iKeyword = COLORDEVICE;
                      bSuccess = TRUE;
                      break;
                    case ID_DEFAULT_LANGUAGE_LEVEL:
                      iKeyword = LANGUAGELEVEL;
                      bSuccess = TRUE;
                      break;
                    case ID_DEFAULT_FREE_VM:
                      iKeyword = FREEVM;
                      bSuccess = TRUE;
                      break;
                    case ID_DM_DM_PAPERSIZE:
                      iKeyword = PAGESIZE;
                      bSuccess = TRUE;
                      break;
                    case ID_DM_PAPER_ORIENTATION:
                      iKeyword = LANDSCAPEORIENTATION;
                      bSuccess = TRUE;
                      break;
                    case ID_DEFAULT_CUSTOM_PAGE_SIZE:
                      iKeyword = CUSTOMPAGESIZE;
                      bSuccess = TRUE;
                      break;
                    case ID_DM_MEDIATYPE:
                      iKeyword = MEDIATYPE;
                      bSuccess = TRUE;
                      break;
                    case ID_DM_MIRROR:
                      iKeyword = MIRRORPRINT;
                      bSuccess = TRUE;
                      break;
                    case ID_DM_SCREEN_FREQ:
                      iKeyword = SCREENFREQ;
                      bSuccess = TRUE;
                      break;
                    case ID_DM_SCREEN_ANGLE:
                      iKeyword = SCREENANGLE;
                      bSuccess = TRUE;
                      break;
                    case ID_DEFAULT_RES_SCREEN_FREQ:
                      iKeyword = SCREENFREQRES;
                      bSuccess = TRUE;
                      break;
                    case ID_DEFAULT_RES_SCREEN_ANGLE:
                      iKeyword = SCREENANGLERES;
                      bSuccess = TRUE;
                      break;
                    default:
                      iKeyword = ENDOFLIST;
                      bSuccess = FALSE;
                      break;
                }
            }
        }
        if (bSuccess)
        {
            lpMainKeyword = StringRefToLPBYTE(lppd, lpMainKeyWordsTable[iKeyword].dword);
            if (lstrlen((LPSTR)lpMainKeyword) + 1 > (int)*lpSize)
                lstrcpyn(lpBuffer, lpMainKeyword, *lpSize);
            else
                lstrcpy(lpBuffer, lpMainKeyword);
        }
        if (lpStringPtr)
            GlobalFreePtr(lpStringPtr);
        if (lpMainKeyWordsTable)
            GlobalFreePtr(lpMainKeyWordsTable);
    }

    /* Take care of the predefined headers */
    if (!bSuccess &&
        (iDataItemID == ID_DM_PAPERSIZE))
    {
        len = LoadString(ghDriverMod, ID_PPDSTR_KEY_PAGESIZE, lpBuffer, *lpSize);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (iDataItemID == ID_DM_PAGEREGION))
    {
        len = LoadString(ghDriverMod, ID_PPDSTR_KEY_PAGEREGION, lpBuffer, *lpSize);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (iDataItemID == ID_DM_DUPLEX))
    {
        len = LoadString(ghDriverMod, ID_PPDSTR_KEY_DUPLEX, lpBuffer, *lpSize);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (iDataItemID == ID_DM_INPUTSLOT))
    {
        len = LoadString(ghDriverMod, ID_PPDSTR_KEY_INPUTSLOT, lpBuffer, *lpSize);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (iDataItemID == ID_DM_RESOLUTION))
    {
        len = LoadString(ghDriverMod, ID_PPDSTR_KEY_RESOLUTION, lpBuffer, *lpSize);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (iDataItemID == ID_DM_OUTPUTBIN))
    {
        len = LoadString(ghDriverMod, ID_PPDSTR_KEY_OUTPUTBIN, lpBuffer, *lpSize);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (iDataItemID == ID_DM_MEDIATYPE))
    {
        len = LoadString(ghDriverMod, ID_PPDSTR_KEY_MEDIATYPE, lpBuffer, *lpSize);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (iDataItemID == ID_DM_INSTALLED_MEMORY))
    {
        len = LoadString(ghDriverMod, ID_PPDSTR_KEY_INSTALLEDMEMORY, lpBuffer, *lpSize);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (iDataItemID == ID_DM_COLLATE || iDataItemID == ID_DM_COLLATION))
    {
        len = LoadString(ghDriverMod, ID_PPDSTR_KEY_COLLATE, lpBuffer, *lpSize);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (iDataItemID == ID_DM_OUTPUTORDER))
    {
        len = LoadString(ghDriverMod, ID_PPDSTR_KEY_OUTPUTORDER, lpBuffer, *lpSize);
        bSuccess = TRUE;
    }

    if (bSuccess)
        len = lstrlen(lpBuffer) + 1;


    *lpSize = len;
    return (bSuccess);
}

/************************************************************************/

BOOL _loadds FAR PASCAL DRVSetString(HANDLE hContext,
                                     int iDataItemID,
                                     LPSTR lpszData,
                                     unsigned int uiLength)
{
    BOOL bSuccess = FALSE;
    LPPDEVICE lppd = NULL;
    LPPRINTERINFO lpPrinterInfo = NULL;
    LPMAINKEYHDR  lpCurMainKeyHdr = NULL;
    LPPSEXTDEVMODE lpPSExtDevmode = NULL;
    LPOEMINFO lpOEMInfo;
    volatile int x;

    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        bSuccess = lpOEMInfo ? TRUE : FALSE;
        lppd = lpOEMInfo->lppd;
        lpPSExtDevmode = lpOEMInfo->lpPSExtDevmode;
        GlobalUnlock(hContext);
    }
    if (bSuccess == FALSE)
        return FALSE;

    bSuccess = FALSE;
    if ((iDataItemID >= ID_DM_CUSTOM_NAME_BASE) &&
        (iDataItemID <  ID_DM_CUSTOM_NAME_BASE + MAX_NUM_CUSTOM_PAPERS) &&
        lpPSExtDevmode)
    {
        bSuccess = (uiLength <= CUSTOMNAMELEN && lpszData);
        x = iDataItemID - ID_DM_CUSTOM_NAME_BASE;
        if (bSuccess)
            bSuccess = (BOOL)((lstrcpy(lpPSExtDevmode->dm.custPaper[x].CustomName,
                                  lpszData)) ? 1 : 0);
    }
#ifdef PROOFING
    else if( iDataItemID == ID_DM_PROOFING_PROFILE && lpPSExtDevmode )
    {
       if( uiLength && *lpszData )
          lpPSExtDevmode->dm2.dwProfile = HashString( lpszData, uiLength );
       else
          lpPSExtDevmode->dm2.dwProfile = 0;
    }
#endif
    return (bSuccess);
}

/************************************************************************/
BOOL NEAR PASCAL CopyRefString(LPPDEVICE lppd,
                               STRINGREF PSString,
                               LPSTR lpBuffer,
                               unsigned int FAR *lpSize)
{
    BOOL    bRetVal;
    LPBYTE lpPSString;
    unsigned int iPSStringLen;

    bRetVal = FALSE;
    lpPSString = StringRefToLPBYTE(lppd, PSString.dword);
    if (lpPSString && PSString.w.length > 0)
    {
        iPSStringLen = PSString.w.length + 1;
        if (iPSStringLen > *lpSize)
        {
            iPSStringLen = *lpSize;
            lstrcpyn(lpBuffer, (LPSTR)lpPSString, iPSStringLen);
        }
        else
        {
            lstrcpy(lpBuffer, (LPSTR)lpPSString);
        }
        *lpSize = lstrlen(lpBuffer) + 1;
        bRetVal = TRUE;
    }
    return bRetVal;
}

/************************************************************************/
BOOL _loadds FAR PASCAL DRVGetString(HANDLE hContext, int iDataItemID,
                                     LPSTR lpBuffer, unsigned int FAR *lpSize, BOOL bDefault)
{
    BOOL bSuccess = FALSE;
#if 0
    int iKeywordIndex;
#endif
    LPPDEVICE lppd = NULL;
    LPPRINTERINFO lpPrinterInfo = NULL;
    LPMAINKEYHDR  lpCurMainKeyHdr = NULL;
    LPPSEXTDEVMODE lpPSExtDevmode = NULL;
    LPOEMINFO lpOEMInfo;
    volatile int x;
    unsigned char tmpstring[CUSTOMNAMELEN];
    LPSTR lpFileName = NULL;

    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        if (lpOEMInfo)
        {
            lppd = lpOEMInfo->lppd;
            if (lppd)
            {
                lpPSExtDevmode = lpOEMInfo->lpPSExtDevmode;
                lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);
                if (lpPrinterInfo)
                    bSuccess = (lpBuffer && lpSize && *lpSize > 0);

            }
        }
        GlobalUnlock(hContext);
    }

    if (bSuccess == FALSE)
    {
        if (lpBuffer && lpSize && *lpSize > 0)
            *lpBuffer = '\0';
        if (lpSize)
            *lpSize = 0;
        return FALSE;
    }

    bSuccess = FALSE;
    *lpBuffer = '\0';

#if 0
    /* Take care of general keywords that are being parsed for */
    /* Doc Sticky first */
    if ((ID_DM_DOCUMENT_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DM_DOCUMENT_STICKY_OPTIONS_BASE + 100))
    {
        iKeywordIndex = lpPrinterInfo->DocSticky.w.offset + (iDataItemID -
                                              ID_DM_DOCUMENT_STICKY_OPTIONS_BASE);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (ID_DEFAULT_DOCUMENT_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DEFAULT_DOCUMENT_STICKY_OPTIONS_BASE + 100))
    {
        iKeywordIndex = lpPrinterInfo->DocSticky.w.offset + (iDataItemID -
                                          ID_DEFAULT_DOCUMENT_STICKY_OPTIONS_BASE);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (ID_DM_PRINTER_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DM_PRINTER_STICKY_OPTIONS_BASE + 100))
    {
        iKeywordIndex = lpPrinterInfo->PrinterSticky.w.offset + (iDataItemID -
                                          ID_DM_PRINTER_STICKY_OPTIONS_BASE);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (ID_DEFAULT_PRINTER_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DEFAULT_PRINTER_STICKY_OPTIONS_BASE + 100))
    {
        iKeywordIndex = lpPrinterInfo->PrinterSticky.w.offset + (iDataItemID -
                                      ID_DEFAULT_PRINTER_STICKY_OPTIONS_BASE);
        bSuccess = TRUE;
    }

    if (bSuccess == TRUE)
    {
        if (iKeywordIndex >= (int)lpPrinterInfo->numMainKeyHdrs)
            bSuccess = FALSE;
    }

    if (bSuccess)
    {
        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + iKeywordIndex;
        bSuccess = CopyRefString(lppd, lpCurMainKeyHdr->OptionQuery, lpBuffer, lpSize);
    }
#endif

    if (!bSuccess && lpPSExtDevmode && (iDataItemID >= ID_DM_CUSTOM_NAME_BASE) &&
        (iDataItemID <  ID_DM_CUSTOM_NAME_BASE + MAX_NUM_CUSTOM_PAPERS))
    {
        x = iDataItemID - ID_DM_CUSTOM_NAME_BASE;

        if (!bDefault)
        {
            bSuccess = (BOOL)((lstrcpy(lpBuffer, (LPSTR)lpPSExtDevmode->dm.custPaper[x].CustomName))
                      ? 1 : 0);
            *lpSize = lstrlen(lpBuffer) + 1;
        }
        else
        {   // return default string and convert custom page number
           if (LoadString(ghDriverMod,IDS_BASE_CUSTOM_NAME, (LPSTR)tmpstring,
                                    sizeof(tmpstring)) != 0)
           {
              wsprintf(lpBuffer, tmpstring, x+1);

              bSuccess = TRUE;
              *lpSize = lstrlen(lpBuffer) + 1;
           }
           else
              bSuccess = FALSE;
        }

    }


    if (!bSuccess && bDefault &&
        iDataItemID >= ID_DEFAULT_JOBPATCHFILE_BASE &&
        iDataItemID <  ID_DEFAULT_JOBPATCHFILE_BASE + (int)lpPrinterInfo->nJobPatchFiles)
    {
       lpFileName = StringRefToLPBYTE(lppd,
           lpPrinterInfo->JobPatchFile[iDataItemID - ID_DEFAULT_JOBPATCHFILE_BASE].invoc.dword);
       if (lpFileName)
          bSuccess = TRUE;
       lstrcpy(lpBuffer, lpFileName);
       *lpSize = lstrlen(lpBuffer) + 1;
    }

    if (!bSuccess)
    {
       if (bDefault)
       {
          switch(iDataItemID)
          {
             case ID_DEFAULT_PPDFILENAME: {
                char         szPPDFileName[64];
                char         szDevName[64];
                DWORD        dwType, dwNeeded;

                szDevName[0] = '\0';                /* Null intialize it */
                if (DrvGetPrinterData(lpPSExtDevmode->dm.dm.dmDeviceName, (LPSTR)INT_PD_PRINTER_MODEL, &dwType, szDevName,
                                      CCHDEVICENAME, &dwNeeded) != ERROR_SUCCESS)
                {
                     /* Unknown model - use default printer. */
                     LoadString(ghDriverMod, IDS_DEFAULTPRINTER, szDevName, CCHDEVICENAME);
                }
                GetPPDNameFromModelName(szDevName, szPPDFileName, sizeof(szPPDFileName));
                lstrcpy(lpBuffer, szPPDFileName);

                if (lpBuffer)
                {
                    *lpSize = lstrlen(lpBuffer) + 1;
                    bSuccess = TRUE;
                }

                break;
               }

             case ID_DEFAULT_PCFILENAME:
                lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->PCFileName.dword);
                if (lpFileName)
                   bSuccess = TRUE;
                lstrcpy(lpBuffer, lpFileName);
                *lpSize = lstrlen(lpBuffer) + 1;
                break;

             case  ID_DEFAULT_PRODUCT:
                lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->Product.dword);
                if (lpFileName)
                   bSuccess = TRUE;
                lstrcpy(lpBuffer, lpFileName);
                *lpSize = lstrlen(lpBuffer) + 1;
                 break;

             case  ID_DEFAULT_PSVERSION:
                lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->PSVersion.dword);
                if (lpFileName)
                   bSuccess = TRUE;
                lstrcpy(lpBuffer, lpFileName);
                *lpSize = lstrlen(lpBuffer) + 1;
                break;

             case  ID_DEFAULT_MODELNAME:
                lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->modelname.dword);
                if (lpFileName)
                   bSuccess = TRUE;
                lstrcpy(lpBuffer, lpFileName);
                *lpSize = lstrlen(lpBuffer) + 1;
                break;

             case  ID_DEFAULT_MANUFACTURER:
                lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->Manufacturer.dword);
                if (lpFileName)
                   bSuccess = TRUE;
                lstrcpy(lpBuffer, lpFileName);
                *lpSize = lstrlen(lpBuffer) + 1;
                break;

             case  ID_DEFAULT_PASSWORD:
                lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->password.dword);
                if (lpFileName)
                   bSuccess = TRUE;
                lstrcpy(lpBuffer, lpFileName);
                *lpSize = lstrlen(lpBuffer) + 1;
                break;

             case  ID_DEFAULT_PATCHFILE:
                lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->PatchFile.dword);
                if (lpFileName)
                   bSuccess = TRUE;
                lstrcpy(lpBuffer, lpFileName);
                *lpSize = lstrlen(lpBuffer) + 1;
                break;

             case ID_DM_LPSZOUTPUT:
                lstrcpy( lpBuffer, lppd->szSDOutput );
                *lpSize = lstrlen(lpBuffer) + 1;
                bSuccess = TRUE;
                break;

#ifdef PROOFING
             case ID_DM_PROOFING_PROFILE:
                *lpBuffer = 0;
                *lpSize = lstrlen(lpBuffer) + 1;
                bSuccess = TRUE;
                break;
#endif

          }
       }
       else
       {
          switch(iDataItemID)
          {
             case ID_DM_LPSZOUTPUT:
                lstrcpy( lpBuffer, lppd->szSDOutput );
                *lpSize = lstrlen(lpBuffer) + 1;
                bSuccess = TRUE;
                break;

#ifdef PROOFING
             case ID_DM_PROOFING_PROFILE:
                *lpBuffer = 0;
                if( lpPSExtDevmode->dm2.dwProfile &&
                    EnumICMProfile( ENUMICMP_MATCH, 0,
                       lpPSExtDevmode->dm2.dwProfile, lpBuffer, *lpSize ) )
                {
                   bSuccess = TRUE;
                   *lpSize = lstrlen(lpBuffer) + 1;
                }
                break;
#endif
          }
       }
    }

    if (!bSuccess)
        *lpSize = 0;

    return (bSuccess);
}

/************************************************************************/

BOOL _loadds FAR PASCAL DRVGetKeywordTranslation(HANDLE hContext,
                                                 int iDataItemID,
                                                 LPSTR lpBuffer,
                                                 unsigned int FAR *lpSize)
{
    BOOL bSuccess = FALSE;
    int iKeyword;
    LPPRINTERINFO lpPrinterInfo;
    LPPDEVICE lppd;
    LPOEMINFO lpOEMInfo;

    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        lppd = lpOEMInfo->lppd;
        if (lppd)
        {
            lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);
            if (lpPrinterInfo)
                bSuccess = (lpBuffer && lpSize && *lpSize > 0);
        }
        GlobalUnlock(hContext);
    }

    if (bSuccess == FALSE)
    {
        if (lpBuffer && lpSize && *lpSize > 0)
            *lpBuffer = '\0';
        if (lpSize)
            *lpSize = 0;
        return FALSE;
    }

    bSuccess = FALSE;

    if ((ID_DM_DOCUMENT_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DM_DOCUMENT_STICKY_OPTIONS_BASE + 100))
    {
        iKeyword = lpPrinterInfo->DocSticky.w.offset + (iDataItemID -
                   ID_DM_DOCUMENT_STICKY_OPTIONS_BASE);
        bSuccess = TRUE;
    }

    if (!bSuccess &&
        (ID_DM_PRINTER_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DM_PRINTER_STICKY_OPTIONS_BASE + 100))
    {
        iKeyword = lpPrinterInfo->PrinterSticky.w.offset + (iDataItemID -
                   ID_DM_PRINTER_STICKY_OPTIONS_BASE);
        bSuccess = TRUE;
    }

    if (!bSuccess)
    {
        if (iDataItemID==ID_DM_COLLATE)
           iDataItemID = ID_DM_COLLATION;

        /* Check the predefined options first */
        switch (iDataItemID)
        {
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAPERINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAGEREGIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_DUPLEXINGINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_INPUTSLOTINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_RESOLUTIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTBININFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEDIATYPEINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEMORYINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_COLLATIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTORDERINFO:
              iKeyword = iDataItemID - ID_DM_PREDEFINED_OPTIONS_BASE;
              bSuccess = TRUE;
              break;
        }
    }

    *lpBuffer = '\0';
    if (bSuccess)
    {
        bSuccess = KeywordGetKeywordTranslation(lppd, iKeyword, lpBuffer, *lpSize);
        *lpSize = lstrlen(lpBuffer) + 1;
    }
    else
    {
        *lpSize = 0;
    }
    return bSuccess;
}

/****************************************************************************/
/*                                                                          */
/*                      KeywordGetOption                                    */
/*                                                                          */
/*  Function:                                                               */
/*   Given a Main and Option keyword index returns a STRINGREF.dword which  */
/*   can be used to access the OptionKeyword string associated              */
/*   with that option. With trivial modification this function can return   */
/*   the option keyword or invocation string                                */
/*                                                                          */
/*  Arguments:                                                              */
/*                                                                          */
/*  Returns:   TRUE if successful, FALSE if failed                          */
/*                                                                          */
/****************************************************************************/

WORD  FAR  PASCAL  KeywordGetOption( LPPDEVICE  lppd,
                                    WORD  MainKeywordIndex,
                                    WORD  OptionKeywordIndex,
                                    LPSTR lpOption,
                                    WORD Len)
{
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   WORD           numOptions  ;
   STRINGREF    OptionString;
   LPBYTE      lpOptionsBlock;
   LPGENERIC_OPTION   lpOptionInfo ;
   LPBYTE Option;

   lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo ;
   lpOptionsBlock = lppd->lpWPXblock->WPXarrays ;

   // Do a LoadString() if it is a driver synthetic UI type keyword
   if (OptionKeywordIndex >= MAX_RESOURCE_ID)
   {
      return LoadString(ghDriverMod, OptionKeywordIndex, lpOption, Len);
   }

   if(MainKeywordIndex >= lpPrinterInfo->numMainKeyHdrs)
      return(FALSE) ;  // specified index exceeds range!

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + MainKeywordIndex ;
   numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

   if(OptionKeywordIndex >= numOptions)
      return(FALSE) ;  // specified option index exceeds range!

   lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
      lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

   OptionString =
      lpOptionInfo[OptionKeywordIndex].OptionKey ;

   Option = StringRefToLPBYTE(lppd, OptionString.dword);

   // Copy the string into supplied buffer, with an EOS.
   if(!OptionString.w.length)
      lpOption[0] = '\0' ;
   else if ( Len >= (OptionString.w.length+1) )
   {
        lstrcpyn( lpOption, Option, (OptionString.w.length+1) ) ;
   }
   else
   {
        lstrcpyn( lpOption, Option, Len ) ;
   }

   return(OptionString.w.length);
}

/************************************************************************/

BOOL _loadds FAR PASCAL DRVGetKeywordOptionString(HANDLE hContext,
                                          int iDataItemID,
                                          int iIDOption,
                                          LPSTR lpOptionBuffer,
                                          unsigned int FAR *lpSize)
{
    LPOEMINFO lpOEMInfo;
    BOOL retVal = FALSE;
    LPPDEVICE lppd;
    LPPRINTERINFO lpPrinterInfo;
    int iKeywordIndex;

    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        lppd = lpOEMInfo->lppd;
        if (lppd)
        {
            lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);
            if (lpPrinterInfo)
                retVal = (lpOptionBuffer && lpSize && *lpSize > 0);
        }
        GlobalUnlock(hContext);
    }

    if (retVal == FALSE)
    {
        if (lpOptionBuffer && lpSize && *lpSize > 0)
            *lpOptionBuffer = '\0';
        if (lpSize)
            *lpSize = 0;
        return FALSE;
    }

    retVal = FALSE;
    *lpOptionBuffer = '\0';

    if ((ID_DM_DOCUMENT_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DM_DOCUMENT_STICKY_OPTIONS_BASE + 100))
    {
        iKeywordIndex = lpPrinterInfo->DocSticky.w.offset + (iDataItemID -
                        ID_DM_DOCUMENT_STICKY_OPTIONS_BASE);
        retVal = TRUE;
    }
    if ((ID_DM_PRINTER_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DM_PRINTER_STICKY_OPTIONS_BASE + 100))
    {
        iKeywordIndex = lpPrinterInfo->PrinterSticky.w.offset + (iDataItemID -
                        ID_DM_PRINTER_STICKY_OPTIONS_BASE);
        retVal = TRUE;
    }
    if (!retVal)
    {   /* Check the predefined options first */
        if (iDataItemID==ID_DM_COLLATE)
           iDataItemID = ID_DM_COLLATION;

        switch (iDataItemID)
        {
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAPERINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAGEREGIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_DUPLEXINGINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_INPUTSLOTINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_RESOLUTIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTBININFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEDIATYPEINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEMORYINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_COLLATIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTORDERINFO:
                iKeywordIndex = iDataItemID - ID_DM_PREDEFINED_OPTIONS_BASE;
                retVal = TRUE;
                break;
        }
    }
    if (retVal == TRUE)
    {
        KeywordGetOption(lppd,iKeywordIndex,iIDOption,lpOptionBuffer,*lpSize);
        *lpSize = lstrlen(lpOptionBuffer) + 1;
    }
    else *lpSize = 0;
    return (retVal);
}

/************************************************************************/

BOOL _loadds FAR PASCAL DRVGetKeywordOptionPS(HANDLE hContext,
                                      int iDataItemID,
                                      int iIDOption,
                                      LPSTR lpPSStringBuffer,
                                      unsigned int FAR *lpSize)
{
    LPOEMINFO lpOEMInfo = NULL;
    LPPRINTERINFO lpPrinterInfo = NULL;
    LPPDEVICE lppd = NULL;
    int iKeywordIndex;
    BOOL bSuccess = FALSE;

    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        lppd = lpOEMInfo->lppd;
        if (lppd)
        {
            lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);
            if (lpPrinterInfo)
                bSuccess = (lpPSStringBuffer && lpSize && *lpSize > 0);
        }
        GlobalUnlock(hContext);
    }

    if (bSuccess == FALSE)
    {
        if (lpPSStringBuffer && lpSize && *lpSize > 0)
            *lpPSStringBuffer = '\0';
        if (lpSize)
            *lpSize = 0;
        return FALSE;
    }

    bSuccess = FALSE;
    *lpPSStringBuffer = '\0';

    if ((ID_DM_DOCUMENT_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DM_DOCUMENT_STICKY_OPTIONS_BASE + 100))
    {
        iKeywordIndex = lpPrinterInfo->DocSticky.w.offset + (iDataItemID -
                              ID_DM_DOCUMENT_STICKY_OPTIONS_BASE);
        bSuccess = TRUE;
    }

    if ((ID_DM_PRINTER_STICKY_OPTIONS_BASE <= iDataItemID) &&
        (iDataItemID < ID_DM_PRINTER_STICKY_OPTIONS_BASE + 100))
    {
        iKeywordIndex = lpPrinterInfo->PrinterSticky.w.offset + (iDataItemID -
                              ID_DM_PRINTER_STICKY_OPTIONS_BASE);
        bSuccess = TRUE;
    }
    if (!bSuccess)
    {
        if (iDataItemID==ID_DM_COLLATE)
           iDataItemID = ID_DM_COLLATION;

        switch (iDataItemID)
        {
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAPERINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAGEREGIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_DUPLEXINGINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_INPUTSLOTINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_RESOLUTIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTBININFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEDIATYPEINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEMORYINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_COLLATIONINFO:
            case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTORDERINFO:
                iKeywordIndex = iDataItemID - ID_DM_PREDEFINED_OPTIONS_BASE;
                bSuccess = TRUE;
                break;
            case ID_DM_PPD_PASSWORD:
                iKeywordIndex = ID_KEY_PASSWORD;
                bSuccess = TRUE;
                break;
            case ID_DM_ALLOW_EXIT_SERVER:
                iKeywordIndex = ID_KEY_EXITSERVER;
                bSuccess = TRUE;
                break;

        }
    }
    if (bSuccess)
    {
        *lpSize = KeywordGetOptionPS(lppd, iKeywordIndex, iIDOption,
                                     lpPSStringBuffer, lpSize);
    }
    if (*lpSize > 0)
    {
        *lpSize = lstrlen(lpPSStringBuffer) + 1;
    }
    return (bSuccess);
}

/************************************************************************/

BOOL _loadds FAR PASCAL  DRVIsKeywordOptionConstrained(HANDLE hContext,
                                                       int iDataItemID,
                                                       int iIDOption)
{
  BOOL retVal = FALSE;
  LPOEMINFO lpOEMInfo;
  LPPSEXTDEVMODE lpPSExtDevmode;
  LPPDEVICE lppd;
  LPPRINTERINFO lpPrinterInfo;
  int iKeywordIndex = -1;

  if (hContext)
    {
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
    lpPSExtDevmode = lpOEMInfo->lpPSExtDevmode;
    lppd = lpOEMInfo->lppd;
    lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);
    GlobalUnlock(hContext);
    }
  else
    return (retVal);

  if ((ID_DM_DOCUMENT_STICKY_OPTIONS_BASE <= iDataItemID) &&
      (iDataItemID < ID_DM_DOCUMENT_STICKY_OPTIONS_BASE + 100))
    {
    iKeywordIndex = lpPrinterInfo->DocSticky.w.offset + (iDataItemID -
                    ID_DM_DOCUMENT_STICKY_OPTIONS_BASE);
    }

  if ((ID_DM_PRINTER_STICKY_OPTIONS_BASE <= iDataItemID) &&
      (iDataItemID < ID_DM_PRINTER_STICKY_OPTIONS_BASE + 100))
    {
    iKeywordIndex = lpPrinterInfo->PrinterSticky.w.offset + (iDataItemID -
                    ID_DM_PRINTER_STICKY_OPTIONS_BASE);
    }

  /* Check the predefined options first */
  if (iKeywordIndex == -1)
  {
     if (iDataItemID==ID_DM_COLLATE)
        iDataItemID = ID_DM_COLLATION;

     switch (iDataItemID)
     {
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAPERINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_PAGEREGIONINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_DUPLEXINGINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_INPUTSLOTINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_RESOLUTIONINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTBININFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEDIATYPEINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_MEMORYINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_COLLATIONINFO:
        case ID_DM_PREDEFINED_OPTIONS_BASE + IND_OUTPUTORDERINFO:
           iKeywordIndex = iDataItemID - ID_DM_PREDEFINED_OPTIONS_BASE;
           break;
     }
  }

  retVal = IsKeywordOptConstrained(lppd, iKeywordIndex, iIDOption);

  return (retVal);
}

/************************************************************************/

BOOL _loadds FAR PASCAL  DRVDoCommand(HANDLE hContext,
                                      int iIDCommand,
                                      FARPROC lpfn,
                                      DWORD dwData)
{
  BOOL bSuccess = FALSE;
  LPOEMINFO lpOEMInfo = NULL;
  LPPSEXTDEVMODE lpPSExtDevmode = NULL;
  LPPDEVICE lppd = NULL;
  DRIVERINFOT FAR *lpDrvInfo = NULL;

  if (hContext)
    {
    lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
    lpPSExtDevmode = lpOEMInfo->lpPSExtDevmode;

    lpDrvInfo = lpOEMInfo->lpDrvInfo;
    if (lpDrvInfo == NULL)
      return (FALSE);

    lppd = lpOEMInfo->lppd;
    GlobalUnlock(hContext);
    }
  else
    return (FALSE);

  switch (iIDCommand)
    {
    case ID_COMMAND_ENUMDFONTS:
      bSuccess = TRUE;
      EnumDFonts((LP)lppd,NULL,(FONTENUMPROC)lpfn,(LP)dwData);
      break;
    case ID_COMMAND_CANCEL:
      bSuccess = TRUE;
      lpDrvInfo->lpDM = &(lpDrvInfo->DMSave);
      break;
    case ID_COMMAND_UPDATE_GLOBAL:
      bSuccess = TRUE;
      UpdateGlobal(lpDrvInfo,(BOOL)(LOWORD(dwData)));
      break;
    case ID_COMMAND_SEND_MODE:
      if (RC_fail == DoSwitchBetweenAsciiAndBinaryStub(lpDrvInfo, LOWORD(dwData)))
        bSuccess = FALSE;
      else
        bSuccess = TRUE;
      break;
    case ID_COMMAND_DOWNLOAD_HEADER:
      if (RC_fail == DoHeaderDownloading(lpDrvInfo))
        bSuccess = FALSE;
      else
        bSuccess = TRUE;
      break;
    default:
      bSuccess = FALSE;
      break;
    }

  return (bSuccess);
}



/************************************************************************/

HANDLE _loadds FAR PASCAL DRVLoadIcon(HANDLE hContext,
                                      int    iId
                                     )
{
    BOOL    flOk;
    HANDLE  hdl;
    LPOEMINFO lpOEMInfo;
    LPDRIVERINFO lpDrvInfo;

    hdl = (HANDLE)NULL;
    flOk = FALSE;
    lpDrvInfo = (LPDRIVERINFO)NULL;

    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        lpDrvInfo = lpOEMInfo->lpDrvInfo;
        GlobalUnlock(hContext);
    }

    if (lpDrvInfo) {
        switch(iId)
        {
            case PORTRAIT_ICON:
            case LANDSCAPE_ICON:
            case ROTATED_LAND_ICON:
            case DUPLEX_P_NONE_ICON:
            case DUPLEX_L_NONE_ICON:
            case DUPLEX_R_NONE_ICON:
            case DUPLEX_P_LONG_ICON:
            case DUPLEX_L_LONG_ICON:
            case DUPLEX_R_LONG_ICON:
            case DUPLEX_P_SHORT_ICON:
            case DUPLEX_L_SHORT_ICON:
            case DUPLEX_R_SHORT_ICON:
            case NM_BASE_ICON:
            case NEGATIVE_ICON:
            case MIRROR_ICON:
            case NEGATIVE_MIRROR_ICON:

            case PAPER_BASE_ICON:
            case PAPER_LETTER_ICON:
            case PAPER_LETTERSMALL_ICON:
            case PAPER_TABLOID_ICON:
            case PAPER_LEDGER_ICON:
            case PAPER_LEGAL_ICON:
            case PAPER_STATEMENT_ICON:
            case PAPER_EXECUTIVE_ICON:
            case PAPER_A3_ICON:
            case PAPER_A4_ICON:
            case PAPER_A4SMALL_ICON:
            case PAPER_A5_ICON:
            case PAPER_B4_ICON:
            case PAPER_B5_ICON:
            case PAPER_FOLIO_ICON:
            case PAPER_QUARTO_ICON:
            case PAPER_10X14_ICON:
            case PAPER_11X17_ICON:
            case PAPER_NOTE_ICON:
            case PAPER_ENV9_ICON:
            case PAPER_ENV10_ICON:
            case PAPER_ENV11_ICON:
            case PAPER_ENV12_ICON:
            case PAPER_ENV14_ICON:
            case PAPER_C_ICON:
            case PAPER_D_ICON:
            case PAPER_E_ICON:
            case PAPER_ENVDL_ICON:
            case PAPER_ENVC5_ICON:
            case PAPER_ENVC3_ICON:
            case PAPER_ENVC4_ICON:
            case PAPER_ENVC6_ICON:
            case PAPER_ENVC65_ICON:
            case PAPER_ENVB4_ICON:
            case PAPER_ENVB5_ICON:
            case PAPER_ENVB6_ICON:
            case PAPER_ITALY_ICON:
            case PAPER_MONARCH_ICON:
            case PAPER_PERSONAL_ICON:
            case PAPER_FAN_US_ICON:
            case PAPER_FAN_GM_STD_ICON:
            case PAPER_FAN_GM_LGL_ICON:

            case PAPER_JIS_B4_ICON:
            case PAPER_JPN_POSTCARD_ICON:
            case PAPER_9X11_ICON:
            case PAPER_10X11_ICON:
            case PAPER_15X11_ICON:

            case PAPER_LETEXTRA_ICON:
            case PAPER_LEGEXTRA_ICON:
            case PAPER_TABEXTRA_ICON:
            case PAPER_A4EXTRA_ICON:
            case PAPER_LETTERTRANS_ICON:
            case PAPER_A4TRANS_ICON:
            case PAPER_LETTEREXTRANS_ICON:
            case PAPER_SUPERA_ICON:
            case PAPER_SUPERB_ICON:
            case PAPER_LETTERPLUS_ICON:
            case PAPER_A4PLUS_ICON:
            case PAPER_A5TRANS_ICON:
            case PAPER_B5TRANS_ICON:
            case PAPER_A3EXTRA_ICON:
            case PAPER_A5EXTRA_ICON:
            case PAPER_B5EXTRA_ICON:
            case PAPER_A2_ICON:
            case PAPER_A3TRANS_ICON:
            case PAPER_A3EXTRANS_ICON:

            case PAPER_USER_ICON:
            case PAPER_OTHER_ICON:

            // Layout icons
            case ONEUP_ICON:
            case TWOUP_ICON:
            case FOURUP_ICON:
                flOk = TRUE;
                break;
        }
        if (flOk)
            hdl = lpDrvInfo->lpGetIconResource(iId);
        else switch(iId)
        {
            case SIXUP_ICON:
            case NINEUP_ICON:
            case SIXTEENUP_ICON:

            case TWOUPBD_ICON:
        case FOURUPBD_ICON:
            case SIXUPBD_ICON:
            case NINEUPBD_ICON:
        case SXTNUPBD_ICON:

                hdl = LoadIcon(ghDriverMod, MAKEINTRESOURCE(iId));
                break;
        }
    }
    return hdl;
}

HANDLE _loadds FAR PASCAL DRVLoadBitmap(HANDLE hContext, int iId)
{
    HANDLE  hdl;
    LPOEMINFO lpOEMInfo;
    LPDRIVERINFO lpDrvInfo;

    hdl = (HANDLE)NULL;
    lpDrvInfo = (LPDRIVERINFO)NULL;

    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        lpDrvInfo = lpOEMInfo->lpDrvInfo;
        GlobalUnlock(hContext);
    }

    if (lpDrvInfo)
    {
        if( iId >= PAPER_PDNCNRN_BMP && iId <= PAPER_HANDLING_LANDSCAPE_MASK_BMP )
           hdl = LoadBitmap(ghDriverMod, MAKEINTRESOURCE(iId));
        else
        {
           switch(iId)
           {
              case LARGE_UIC_BMP:
              case LARGE_UIC_MASK:
              case SMALL_UIC_BMP:
              case SMALL_UIC_MASK:
                 hdl = LoadBitmap(ghDriverMod, MAKEINTRESOURCE(iId));
                 break;
           }
        }
    }
    return hdl;
}

/************************************************************************/
WORD NEAR PASCAL ConvertOEMID( LPPRINTERINFO lpPrinterInfo, WORD idDriver )
{
    WORD    idOEM = (WORD)-1;

    if ( idDriver < IND_NUMPREDEFINEDHDRS )                     // Predefined
        idOEM = idDriver + ID_DM_PREDEFINED_OPTIONS_BASE;
    else {
        if ( idDriver <  lpPrinterInfo->DocSticky.w.offset )    // Printer Sticky
            idOEM = ID_DM_PRINTER_STICKY_OPTIONS_BASE + idDriver -
                    lpPrinterInfo->PrinterSticky.w.offset;
        else                                                    // Document Sticky
            idOEM = ID_DM_DOCUMENT_STICKY_OPTIONS_BASE + idDriver -
                    lpPrinterInfo->DocSticky.w.offset;
    }
    return idOEM;
}

WORD _loadds FAR PASCAL DRVValidateOptionArray( HANDLE hContext,
                                          LPUICARRAY   lpArray,
                                     unsigned int FAR* lpcElements,
                                          LPUICONFLICT lpConflict )

{
    WORD            retVal = VAL_NO_CONSTRAINT;
    LPOEMINFO       lpOEMInfo;
    LPPSEXTDEVMODE  lpPSExtDevmode;
    LPPDEVICE       lppd;
    LPPRINTERINFO   lpPrinterInfo;
    LPDRIVERINFO    lpDrvInfo;
    int             iKeywordIndex = -1;

    if (hContext)
    {
        lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
        lpPSExtDevmode = lpOEMInfo->lpPSExtDevmode;
        lppd = lpOEMInfo->lppd;
        lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);
        lpDrvInfo = lpOEMInfo->lpDrvInfo;
        GlobalUnlock(hContext);


        if ( lpArray != NULL ) { // OEM wants to update the array
            // Validate the buffer size
            if ( lpcElements ) {
                if ( *lpcElements < lpPrinterInfo->numMainKeyHdrs ) {
                    *lpcElements = lpPrinterInfo->numMainKeyHdrs;
                    retVal = VAL_BUFFER_TOO_SMALL;
                }
            }
            else retVal = VAL_INVALID_PARAM;
        }

        if ( retVal == VAL_NO_CONSTRAINT ) {
            if ( !intValidateOptionArray( lppd->lpWPXblock, lpPSExtDevmode, lpArray, lpConflict ) )
                retVal = VAL_CONSTRAINT;

            // Convert IDs to OEM definitions.
            if ( lpConflict ) {
                if ( lpConflict->wMainConstrainer != 0xFFFF )
                    lpConflict->wMainConstrainer = ConvertOEMID( lpPrinterInfo, lpConflict->wMainConstrainer );
                if ( lpConflict->wMainConstrained != 0xFFFF )
                    lpConflict->wMainConstrained = ConvertOEMID( lpPrinterInfo, lpConflict->wMainConstrained );
            }
        }

    }
    return (retVal);
}



