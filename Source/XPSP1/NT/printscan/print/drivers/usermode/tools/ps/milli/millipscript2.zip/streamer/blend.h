/* CM_VerSion blend.h atm05 1.2 10076.eco sum= 31408 */
/* CM_VerSion blend.h atm04 1.4 06339.eco sum= 46474 */
/*
  blend.h -- interface to weight vector computations

Copyright (c) 1984-1992 Adobe Systems Incorporated.
All rights reserved.

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript is a registered trademark of Adobe Systems Incorporated.
Display PostScript is a trademark of Adobe Systems Incorporated.

Original version: Paul Haahr: November 8, 1990
Edit History:
Paul Haahr: Fri Oct 23 12:40:27 1992
Craig Rublee: Thu Feb 27 10:44:26 PST 1992
End Edit History.
*/

#ifndef	BLEND_H
#define	BLEND_H

#define	MAXAXES		4	/* maximum number of dimensions of the design space */
#define	MAXWEIGHT	16	/* maximum number of elements in the weight vector */
#define MAXFONTFIT	2	/* maximum number of axes that FontFit() can handle */

/* DS_allocfunc -- type of a DesignSpace allocation function, ARGDECL workaround */
typedef void *(*DS_allocfunc) ARGDECL2(IntX, nbytes, void *, tag);

/* DesignSpace -- the normalized design space for a particular font */
typedef struct DesignSpace DesignSpace;

extern DesignSpace *MakeDesignSpace ARGDECL4(
  IntX, ndimen,			/* the number of axes */
  IntX, nmasters,		/* the number of designs in the master */
  DS_allocfunc, alloc,      	/* a memory allocation function */
  void *, tag			/* a tag to be passed to the allocator */
);

extern boolean SetMasterDesignPosition ARGDECL3(DesignSpace *, ds, CardX, n, Fixed *, dv);
extern boolean GetWeightVector ARGDECL3(DesignSpace *, ds, Fixed *, wv, Fixed *, dv);

/*
 * FontFit -- multiple master contraint matching
 */

typedef struct {
  Fixed lo, hi;		/* in normalized design vector space */
} FontFitBounds;

extern boolean FontFit ARGDECL8(
  DesignSpace *,	ds,
  Fixed *,		dv,
  Fixed *,		wv,
  IntX,			nvary,
  Int16 *,		vary,
  FontFitBounds *,	clamp,
  Fixed *,		target,
  Fixed **,		metric
);

typedef struct {
  Fixed			origdv[MAXAXES];
  Int16			nvary;
  Int16			vary[MAXFONTFIT];
  FontFitBounds		clamp[MAXFONTFIT];
  Int16			npreset;
  Fixed			target[MAXFONTFIT-1];
  Fixed			collapsed[MAXFONTFIT-1][1 << MAXFONTFIT];
  Int16			nextrema[MAXFONTFIT-1];
  FCd			extrema[MAXFONTFIT-1][1 << MAXFONTFIT];
} FontFitDomain;

extern boolean SetupFontFit ARGDECL9(
  FontFitDomain *,	domain,
  DesignSpace *,	ds,
  Fixed *,		origdv,
  IntX,			nvary,
  Int16 *,		vary,
  FontFitBounds *,	clamp,
  IntX,			npreset,
  Fixed *,		target,
  Fixed **,		metric
);

extern boolean SolveFontFit ARGDECL6(
  FontFitDomain *,	domain,
  DesignSpace *,	ds,
  Fixed *,		dv,
  Fixed *,		wv,
  Fixed *,		target,
  Fixed **,		metric
);

typedef struct {
  Fixed			lo0, lo1, hi0, hi1;	/* clamp.lo @ 0, clamp.lo @ 1, ... */
} FontFitExtra;

extern boolean ExtrapolateFontFit ARGDECL7(
  FontFitDomain *,	domain,
  DesignSpace *,	ds,
  Fixed *,		dv,
  Fixed *,		wv,
  Fixed *,		target,
  Fixed **,		metric,
  FontFitExtra *,	extra
);

#endif	/* BLEND_H */
