
//--------------------------------------------------------------------------//
// Filename:    dbcs.h
//
// This file contains information of DBCS handling functions and definitions.
//
//--------------------------------------------------------------------------//
// DBCS related funtions prototypes
//----------------------------------------------------------------------------
BOOL    FAR PASCAL IsDBCSCharSet(BYTE);
BOOL    FAR PASCAL IsDBCSLeadByteEx(BYTE, BYTE);
LPSTR   FAR PASCAL GetLeadByteVector(BYTE);
