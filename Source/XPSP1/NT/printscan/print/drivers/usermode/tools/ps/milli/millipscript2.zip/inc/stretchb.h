/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: STRETCHB.H                                                   */
/*                                                                           */
/* Description: Contains prototypes for the stretch blt function.            */
/*                                                                           */
/*****************************************************************************/

SHORT _loadds FAR PASCAL DevStretchBlt(LP,SHORT,SHORT,SHORT,SHORT,LPBITMAP,SHORT,
                                       SHORT, SHORT,SHORT,DWORD,LPPBRUSH,
                                       LPDRAWMODE,LPRECT);

SHORT FAR PASCAL DoDevStretchBlt(LP lpDest, SHORT DestX, SHORT DestY,
				SHORT DestXE, SHORT DestYE, LPBITMAP Bitmap,
				SHORT SrcX, SHORT SrcY, SHORT SrcXE, SHORT SrcYE,
				DWORD rop, LPPBRUSH lpPBrush,
				LPDRAWMODE lpDrawMode, LPRECT lpClip);
