/*
 *    Adobe Universal Font Library
 *
 *    Copyright (c) 1996 Adobe Systems Inc.
 *    All Rights Reserved
 *
 *    UFLMath.c
 *
 *        These are the Fixed math routines used by UFL.
 *
 * $Header:
 */

#include "UFLMath.h"

UFLFixed 
UFLFixedDiv( 
    UFLFixed a, 
    UFLFixed b 
    )
{
    /* #define UFLFixedDiv( a, b )            ( (UFLFixed)( (float)((UFLFixed)(a)) / (float) (UFLFixed)(b) * (float) 65536.0) ) */

    UFLFLOATOBJ    fo, fo1;

    UFLFLOATOBJ_SetLong(&fo, a);
    UFLFLOATOBJ_SetLong(&fo1, b);
#ifdef WINNT_40
    UFLFLOATOBJ_MulFloat(&fo1, (float)65536.0);
#else
    UFLFLOATOBJ_MulLong(&fo1, 65536);
#endif
    UFLFLOATOBJ_Div(&fo, &fo1);
    return (UFLFixed)UFLFLOATOBJ_GetLong(&fo);
}

UFLFixed 
UFLFixedMul( 
    UFLFixed a, 
    UFLFixed b 
    )
{
    /* #define UFLFixedMul( a, b )           ( (UFLFixed)( (float)((UFLFixed)(a)) * (float) (UFLFixed)(b) / (float) 65536.0) ) */
    UFLFLOATOBJ    fo, fo1;

    UFLFLOATOBJ_SetLong(&fo, a);
    UFLFLOATOBJ_SetLong(&fo1, b);
#ifdef WINNT_40
    UFLFLOATOBJ_DivFloat(&fo1, (float)65536.0);
#else
    UFLFLOATOBJ_DivLong(&fo1, 65536);
#endif
    UFLFLOATOBJ_Mul(&fo, &fo1);
    return (UFLFixed)UFLFLOATOBJ_GetLong(&fo);
}

#if 0
UFLFixed 
UFLFloatToFixed( 
    FLOATL f 
    )
{
    UFLFLOATOBJ    fo;
    
    /* ((long)( (x) * (float)65536.0 )) */

    UFLFLOATOBJ_SetFloat(&fo, f);
#ifdef WINNT_40
    UFLFLOATOBJ_MulFloat(&fo1, (float)65536.0);
#else
    UFLFLOATOBJ_MulLong(&fo, 65536);
#endif
    return UFLFLOATOBJ_GetLong(&fo);
}
#endif
