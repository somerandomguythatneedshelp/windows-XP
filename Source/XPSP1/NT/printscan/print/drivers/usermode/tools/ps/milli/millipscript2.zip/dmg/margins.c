 /*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: Margins.c                                                    */
/*                                                                           */
/* Description: This module contains the functions for the Margins Dialog    */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "apd42map.hh"

#pragma code_seg(_DIALOGSSEG)


/*****************************************************************************/
/*                 SetMarginsSpinRange                                       */
/* Purpose:                                                                  */
/*   Sets the range of the spin controls in the margins dialog               */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   lpDrvInfo -- Pointer to DRIVERINFO structure                            */
/*   bInches   -- TRUE if currently displaying in inches.                    */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing.                                                                */
/*****************************************************************************/

void NEAR PASCAL SetMarginsSpinRange(HWND hDlg, LPDRIVERINFO lpDrvInfo,
                                     BOOL bInches)
{
    LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    WORD minval[4], maxval[2], x, y, minpart, maxpart, factor = 1;
    WORD minvalshow[4], maxvalshow[2], minpartshow[4], maxpartshow[2];
    int  i, nDecimals;
    WORD paperIndex;
    char format[60], buffer[128];

    KeywordGetCurrentOption(&lpDrvInfo->pDev, IND_PAPERINFO, &paperIndex) ;

    if ((paperIndex == lpPrinterInfo->devcaps.CustomPageSize)
           && (lpPrinterInfo->custpageinfo.isCutSheet))
    {
       WORD qdimx;
       int  index = lpDrvInfo->lpDM->dm.currentCustPaper;
       BOOL bTransverse = lpDrvInfo->lpDM->dm.custPaper[index].Transverse;
       RECT *lpHWMargins = &(lpPrinterInfo->custpageinfo.HWmargins);

       // if custom paper size and cut-sheet paper
        GetCustomPageDimensions(lpDrvInfo, &maxval[0], &maxval[1],
                                &qdimx, &qdimx);
        minval[0] = bTransverse ? lpHWMargins->bottom : lpHWMargins->left;
        minval[1] = bTransverse ? lpHWMargins->top    : lpHWMargins->right;
        minval[2] = bTransverse ? lpHWMargins->right  : lpHWMargins->bottom;
        minval[3] = bTransverse ? lpHWMargins->left   : lpHWMargins->top;
    }
    else
    {
       // get the default margins
       GetPaperDimensionAndArea(&lpDrvInfo->pDev, &maxval[0], &maxval[1],
                                &minval[0], &minval[2], &minval[1], &minval[3]);

       minval[1] = maxval[0] - minval[1];
       minval[3] = maxval[1] - minval[3];
    }

    OrientationConversion(lpPSExtDevmode, &maxval[0], &maxval[1],
                       &minval[0], &minval[2], &minval[1], &minval[3]);

    maxval[0] >>= 1;                 /* Max margin is half paper width */
    maxval[1] >>= 1;

    /* Convert from points to display units */
    if (bInches)
    {
        x = 72;
        y = 1;
        nDecimals = 2;
    }
    else
    {
        x = 720;
        y = 254;
        nDecimals = 1;
    }

    for (i=0; i<nDecimals; i++)
    {
        factor *= 10;
    }

    wsprintf((LPSTR)format, "[%%d%%s%%0%d.%dd ... %%d%%s%%0%d.%dd]",
             nDecimals, nDecimals, nDecimals, nDecimals);
    for (i=0; i<4; i++)
    {
        wsprintf(buffer, format, minval[i], (LPSTR) decimalSeparator,
                 minpart, maxval[i/2], (LPSTR) decimalSeparator, maxpart);
        SetDlgItemText(hDlg, ID_LEFTMARGINE_RANGE+i, (LPSTR)buffer);
    }

    for (i=0; i<4; i++)
    {
        FixedMulDiv(minval[i], y, x, nDecimals, &minval[i], &minpart);

        minvalshow[i]  = minval[i]; // keep the x.y value for range display
        minpartshow[i] = minpart;
        /* Convert max value from the real "x.y" form to the integer "xy" */
        minval[i] *= factor;
        minval[i] += minpart;
    }

    for (i=0; i<2; i++)
    {
        FixedMulDiv(maxval[i], y, x, nDecimals, &maxval[i], &maxpart);

        maxvalshow[i] = maxval[i]; // keep the x.y value for range display
        maxpartshow[i] = maxpart;
        /* Convert max value from the real "x.y" form to the integer "xy" */
        maxval[i] *= factor;
        maxval[i] += maxpart;
    }

    wsprintf((LPSTR)format, "[%%d%%s%%0%d.%dd ... %%d%%s%%0%d.%dd]",
             nDecimals, nDecimals, nDecimals, nDecimals);
    for (i=0; i<4; i++)
    {
        // display the range
        wsprintf(buffer, format, minvalshow[i], (LPSTR) decimalSeparator,
                 minpartshow[i], maxvalshow[i/2], (LPSTR) decimalSeparator,
                 maxpartshow[i/2]);
        SetDlgItemText(hDlg, ID_LEFTMARGINE_RANGE+i, (LPSTR)buffer);

        // set the spin range
        SendDlgItemMessage(hDlg, ID_LEFT_MARGIN_SPN+i, UDM_SETRANGE, NULL,
                           MAKELPARAM(maxval[i/2], minval[i]));
    }
}


/*****************************************************************************/
/*                 InitMarginsDlg                                            */
/* Purpose:                                                                  */
/*   Initialize the Margins dialog                                           */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   lpDrvInfo -- Pointer to DRIVERINFO structure                            */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing.                                                                */
/*****************************************************************************/

void NEAR PASCAL InitMarginsDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    int            iUnits;

    /* Now initialize the dialog's widgets */
    iUnits = GetMeasurementUnit(FALSE);
    CheckRadioButton( hDlg, ID_CP_INCHES, ID_CP_MILLIMETERS, iUnits);

    /* Set scroll range */
    SetMarginsSpinRange(hDlg, lpDrvInfo, iUnits == ID_CP_INCHES);
}


/*****************************************************************************/
/*                 DisplayMargins                                            */
/*  Purpose:                                                                 */
/*    Displays the current values for the margins in the margins dialog box  */
/*                                                                           */
/*  parameters:                                                              */
/*    HWND hDlg -- dialog box handle                                         */
/*    lpDrvInfo -- Pointer to DRIVERINFO structure                           */
/*    BOOL bInches -- TRUE if display is in inches, else in mm.              */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/

void NEAR PASCAL DisplayMargins(HWND hDlg, LPDRIVERINFO lpDrvInfo, BOOL bInches)
{
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;
    WORD  dimX, dimY, margins[4];
    int   index;
    WORD paperIndex, qdimx;

    KeywordGetCurrentOption(&lpDrvInfo->pDev, IND_PAPERINFO, &paperIndex) ;

    if ((paperIndex == lpPrinterInfo->devcaps.CustomPageSize)
         && (lpPrinterInfo->custpageinfo.isCutSheet))
    {
       GetCustomPageDimensions(lpDrvInfo, &dimX, &dimY, &qdimx, &qdimx);

       index = lpPSExtDevmode->dm.currentCustPaper;
       margins[0] = lpPSExtDevmode->dm.custPaper[index].HWmargins.left;
       margins[1] = lpPSExtDevmode->dm.custPaper[index].HWmargins.right;
       margins[2] = lpPSExtDevmode->dm.custPaper[index].HWmargins.bottom;
       margins[3] = lpPSExtDevmode->dm.custPaper[index].HWmargins.top;
    }
    else
    {
       GetPaperDimensionAndArea(&lpDrvInfo->pDev, &dimX, &dimY, &margins[0],
                                &margins[0], &margins[0], &margins[0]);

       index = lpDrvInfo->Paper_opt_index;
       margins[0] = lpPSExtDevmode->dm2.revisedPaperMargins[index].left;
       margins[1] = dimX - lpPSExtDevmode->dm2.revisedPaperMargins[index].right;
       margins[2] = lpPSExtDevmode->dm2.revisedPaperMargins[index].bottom;
       margins[3] = dimY - lpPSExtDevmode->dm2.revisedPaperMargins[index].top;

    }

    OrientationConversion(lpPSExtDevmode, &dimX, &dimY, &margins[0],
                          &margins[2], &margins[1], &margins[3]);

    DoDisplayDialogValues(hDlg, margins, 4, ID_LEFT_MARGIN, bInches);
    SetCurrentSpinPos(hDlg, ID_LEFT_MARGIN_SPN, ID_LEFT_MARGIN, 4,
                      bInches ? 2 : 1);
}


/*****************************************************************************/
/*                 SaveMarginsDlg                                            */
/* Purpose:                                                                  */
/*   Saves the margins' values or warn user if values are out of bounds      */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   LPDRIVERINFO lpDrvinfo -- Pointer to driver info structure              */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/

BOOL NEAR PASCAL SaveMarginsDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    WORD           dimX, dimY, dXMax, dYMax, margins[4], qdimx;
    WORD           minval[4];
    int            index;
    WORD           paperIndex ;

    KeywordGetCurrentOption(&lpDrvInfo->pDev, IND_PAPERINFO, &paperIndex) ;

    if ((paperIndex == lpPrinterInfo->devcaps.CustomPageSize)
           && (lpPrinterInfo->custpageinfo.isCutSheet))
    {
       // if custom paper size and cut-sheet paper
       GetCustomPageDimensions(lpDrvInfo, &dimX, &dimY, &qdimx, &qdimx);
    }
    else
    {
       GetPaperDimensionAndArea(&lpDrvInfo->pDev, &dimX, &dimY,
                        &margins[0], &margins[0], &margins[0], &margins[0]);
    }

    /* Change dimensions to current orientation */
    OrientationConversion(lpPSExtDevmode, &dimX, &dimY, &margins[0],
                          &margins[0], &margins[0], &margins[0]);

    if (!RetrieveDialogValues(hDlg, margins, 4, ID_LEFT_MARGIN,
                              IsDlgButtonChecked(hDlg, ID_CP_INCHES)))
    {
        return FALSE;
    }

    /* Change everything to default orientation */
    OrientationConversion(lpPSExtDevmode, &dimX, &dimY, &margins[0],
                          &margins[2], &margins[1], &margins[3]);

    /* Upper limits for margins */
    dXMax = dimX/2;
    dYMax = dimY/2;

    // Lower limits for margins
    if ((paperIndex == lpPrinterInfo->devcaps.CustomPageSize)
           && (lpPrinterInfo->custpageinfo.isCutSheet))
    {
       // if custom paper size and cut-sheet paper
       int  index = lpPSExtDevmode->dm.currentCustPaper;
       BOOL bTransverse = lpPSExtDevmode->dm.custPaper[index].Transverse;
       RECT *lpHWMargins = &(lpPrinterInfo->custpageinfo.HWmargins);

       minval[0] = bTransverse ? lpHWMargins->bottom : lpHWMargins->left;
       minval[1] = bTransverse ? lpHWMargins->top    : lpHWMargins->right;
       minval[2] = bTransverse ? lpHWMargins->right  : lpHWMargins->bottom;
       minval[3] = bTransverse ? lpHWMargins->left   : lpHWMargins->top;
    }
    else
    {
       GetPaperDimensionAndArea(&lpDrvInfo->pDev, &dimX, &dimY,
                              &minval[0], &minval[2], &minval[1], &minval[3]);

       minval[1] = dimX - minval[1];
       minval[3] = dimY - minval[3];
    }

    if (margins[0] > dXMax || margins[0] < minval[0] ||
        margins[1] > dXMax || margins[1] < minval[1] ||
        margins[2] > dYMax || margins[2] < minval[2] ||
        margins[3] > dYMax || margins[3] < minval[3])
    {
        /* Bad Margin size entry */
        int iIDBadCtrl;

        // put up message box
        DrvrStringMessageBox(hDlg, DLGS_MARGINS_ERROR, NULL,
                             MB_ICONSTOP | MB_OK);

        /* Check top margin */
        if (margins[3] > dYMax || margins[3] < minval[3])
        {
            switch (lpPSExtDevmode->dm.PaperOrient)
            {
                case OR_PORTRAIT:
                    iIDBadCtrl = ID_TOP_MARGIN;
                    break;

                case OR_LANDSCAPE:
                    iIDBadCtrl = ID_LEFT_MARGIN;
                    break;

                case OR_ROTLANDSCAPE:
                    iIDBadCtrl = ID_RIGHT_MARGIN;
                    break;
            }
        }
        /* Check bottom margin */
        else if (margins[2] > dYMax || margins[2] < minval[2])
        {
            switch (lpPSExtDevmode->dm.PaperOrient)
            {
                case OR_PORTRAIT:
                    iIDBadCtrl = ID_BOTTOM_MARGIN;
                    break;

                case OR_LANDSCAPE:
                    iIDBadCtrl = ID_RIGHT_MARGIN;
                    break;

                case OR_ROTLANDSCAPE:
                    iIDBadCtrl = ID_LEFT_MARGIN;
                    break;
            }
        }
        /* Check left margin */
        else if (margins[0] > dXMax || margins[0] < minval[0])
        {
            switch (lpPSExtDevmode->dm.PaperOrient)
            {
                case OR_PORTRAIT:
                    iIDBadCtrl = ID_LEFT_MARGIN;
                    break;

                case OR_LANDSCAPE:
                    iIDBadCtrl = ID_BOTTOM_MARGIN;
                    break;

                case OR_ROTLANDSCAPE:
                    iIDBadCtrl = ID_TOP_MARGIN;
                    break;
            }
        }
        /* Otherwise right margin is incorrect */
        else
        {
            switch (lpPSExtDevmode->dm.PaperOrient)
            {
                case OR_PORTRAIT:
                    iIDBadCtrl = ID_RIGHT_MARGIN;
                    break;

                case OR_LANDSCAPE:
                    iIDBadCtrl = ID_TOP_MARGIN;
                    break;

                case OR_ROTLANDSCAPE:
                    iIDBadCtrl = ID_BOTTOM_MARGIN;
                    break;
            }
        }

        SetFocus(GetDlgItem(hDlg, iIDBadCtrl));
        SendDlgItemMessage(hDlg, iIDBadCtrl, EM_SETSEL,0,MAKELPARAM(0,-1));

        return (FALSE);
    }
    else
    {
        /* Values are OK */
        if ((paperIndex == lpPrinterInfo->devcaps.CustomPageSize)
             && (lpPrinterInfo->custpageinfo.isCutSheet))
        {
           index = lpPSExtDevmode->dm.currentCustPaper;
           lpPSExtDevmode->dm.custPaper[index].HWmargins.left   = margins[0];
           lpPSExtDevmode->dm.custPaper[index].HWmargins.right  = margins[1];
           lpPSExtDevmode->dm.custPaper[index].HWmargins.bottom = margins[2];
           lpPSExtDevmode->dm.custPaper[index].HWmargins.top    = margins[3];
        }
        else
        {
           index = lpDrvInfo->Paper_opt_index;
           lpPSExtDevmode->dm2.revisedPaperMargins[index].left   = margins[0];
           lpPSExtDevmode->dm2.revisedPaperMargins[index].right  = dimX-margins[1];
           lpPSExtDevmode->dm2.revisedPaperMargins[index].bottom = margins[2];
           lpPSExtDevmode->dm2.revisedPaperMargins[index].top    = dimY-margins[3];

        }
        return (TRUE);
    }
}


/*****************************************************************************/
/*                 RestoreAndDisplayMarginsDefaults                          */
/* Purpose:                                                                  */
/*   Figures out margins' defaults and display them                          */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   LPDRIVERINFO lpDrvInfo -- Pointer to the driver info structure          */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/

void NEAR PASCAL RestoreAndDisplayMarginsDefaults(HWND hDlg,
                                                  LPDRIVERINFO lpDrvInfo)
{
    LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    WORD           dimX, dimY, margins[4];
    BOOL           bInches = IsDlgButtonChecked(hDlg, ID_CP_INCHES);
    WORD           paperIndex, qdimx;

    KeywordGetCurrentOption(&lpDrvInfo->pDev, IND_PAPERINFO, &paperIndex) ;

    if ((paperIndex == lpPrinterInfo->devcaps.CustomPageSize)
           && (lpPrinterInfo->custpageinfo.isCutSheet))
    {
       // if custom paper size and cut-sheet paper
       int  index = lpPSExtDevmode->dm.currentCustPaper;
       BOOL bTransverse = lpPSExtDevmode->dm.custPaper[index].Transverse;
       RECT *lpHWMargins = &(lpPrinterInfo->custpageinfo.HWmargins);

       GetCustomPageDimensions(lpDrvInfo, &dimX, &dimY, &qdimx, &qdimx);

       margins[0] = bTransverse ? lpHWMargins->bottom : lpHWMargins->left;
       margins[1] = bTransverse ? lpHWMargins->top    : lpHWMargins->right;
       margins[2] = bTransverse ? lpHWMargins->right  : lpHWMargins->bottom;
       margins[3] = bTransverse ? lpHWMargins->left   : lpHWMargins->top;
    }
    else
    {
       GetPaperDimensionAndArea(&lpDrvInfo->pDev, &dimX, &dimY, &margins[0],
                                &margins[2], &margins[1], &margins[3]);

       margins[1] = dimX - margins[1];
       margins[3] = dimY - margins[3];
    }

    OrientationConversion(lpPSExtDevmode, &dimX, &dimY, &margins[0],
                          &margins[2], &margins[1], &margins[3]);

    DoDisplayDialogValues(hDlg, margins, 4, ID_LEFT_MARGIN, bInches);
    SetCurrentSpinPos(hDlg, ID_LEFT_MARGIN_SPN, ID_LEFT_MARGIN, 4,
                      bInches ? 2 : 1);
}



/*****************************************************************************/
/*                 CHMarginsDlg                                              */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the Margins dialog box                            */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHMarginsDlg(HWND hDlg, unsigned imsg,
                                     WORD wParam, LONG lParam)
{
    LPDRIVERINFO   lpDrvInfo;
    LPPSEXTDEVMODE lpPSExtDevmode;

    if (lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
    {
        lpPSExtDevmode = lpDrvInfo->lpDM;
    }

    switch (imsg)
    {
        case WM_INITDIALOG:
            SetWindowLong(hDlg,DWL_USER,lParam);
            lpDrvInfo = (LPDRIVERINFO)lParam;
            InitMarginsDlg(hDlg, lpDrvInfo);
            DisplayMargins(hDlg, lpDrvInfo,
                           IsDlgButtonChecked(hDlg, ID_CP_INCHES));
            break;

        case WM_CONTEXTMENU:
            if (wParam != -1)
            {
                WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                        (DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_HELP:
            if (((LPHELPINFO) lParam)->hItemHandle != -1)
            {
                WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                        HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                    if (!SaveMarginsDlg(hDlg,lpDrvInfo))
                        break;

                    // Fall through if successful

                case IDCANCEL:
                    EndDialog(hDlg, wParam) ;
                    break ;

                case ID_RESTORE_DEFAULTS:
                    RestoreAndDisplayMarginsDefaults(hDlg, lpDrvInfo);
                    break;

#ifndef USE_WHATSTHIS_HELP
                case ID_HELP:
                    WinHelp(hDlg, szHelpFile, HELP_CONTEXT,
                            IDH_PSCRIPT_SET_MARGINS);
                    break;
#endif

                case ID_CP_INCHES:
                case ID_CP_MILLIMETERS:
                    /*
                     * These two controls don't use the AUTORADIOBUTTON
                     * style. This lets us retrieve the current size
                     * in the old units, then change the units and
                     * display the units in the new size. It also means
                     * that we need to explicitly set the new state.
                     * Don't do anything if the button for the current
                     * state is being pressed.
                     */
                    if(!IsDlgButtonChecked(hDlg,wParam))
                    {
                        WORD margins[4];

                        HandleMetricChange(hDlg,margins,4,ID_LEFT_MARGIN_SPN,
                                           ID_LEFT_MARGIN, wParam,
                                           SetMarginsSpinRange, lpDrvInfo);
                    }
                    break;

                case ID_LEFT_MARGIN:
                case ID_RIGHT_MARGIN:
                case ID_TOP_MARGIN:
                case ID_BOTTOM_MARGIN:
                    if (HIWORD(lParam) == EN_CHANGE)
                    {
                        HandleEditControlChange(hDlg, ID_LEFT_MARGIN_SPN,
                                        ID_LEFT_MARGIN, wParam,
                                        IsDlgButtonChecked(hDlg, ID_CP_INCHES));

                    }
                    break;

                default:
                    return FALSE;
            } /* switch(wParam) */
            break ;

        case WM_VSCROLL:
            {
                WORD wID;

                switch (wID = GetDlgCtrlID(HIWORD(lParam)))
                {
                    case ID_LEFT_MARGIN_SPN:
                    case ID_RIGHT_MARGIN_SPN:
                    case ID_TOP_MARGIN_SPN:
                    case ID_BOTTOM_MARGIN_SPN:
                        HandleSpinControlChange(hDlg, ID_LEFT_MARGIN_SPN,
                                         ID_LEFT_MARGIN, wID, LOWORD(lParam),
                                         IsDlgButtonChecked(hDlg,ID_CP_INCHES));
                        break;
                }
            }
            break;

        default:
            return FALSE;
    } /* switch(imsg) */

    return TRUE;
}
