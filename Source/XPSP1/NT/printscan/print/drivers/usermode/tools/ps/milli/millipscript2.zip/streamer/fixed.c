/* CM_VerSion fixed.c atm05 1.2 10076.eco sum= 07373 */
/* CM_VerSion fixed.c atm04 1.5 07518.eco sum= 55024 */
/* fixed.c

              Copyright 1984, '87 -- Adobe Systems, Inc.
            PostScript is a trademark of Adobe Systems, Inc.
NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

Original version: Ed Taft, 1984
Edit History:
John Nogrady: Tue Apr 28 10:56:04 1992
Craig Rublee: Thu Jul 18 13:19:33 1991
Scott Byer: Sun Jul  1 12:13:38 1990
Ed Taft: Tue Nov 10 10:43:32 1987
Bill Paxton: Thu Mar 15 09:49:25 1990
End Edit History.

Revision History
  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/FIXED.C_V  $
 *- |
 *- |   Rev 1.1   28 Jun 1995 16:43:58   peterb
 *- |fixed compiler warning - different floating point types
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:08:08   unknown
 *- |Initial revision.
  Revision 6.2  91/11/13  11:44:18  rublee
  Removed include of atm.h to remove dependency on the buildch package.

  Revision 6.1  91/10/07  18:22:04  rublee



End Revision History.

Fixed point multiply, divide, and conversions -- machine independent.
See fp.h for the specification of what these procedures do.

The double-to-int conversion is assumed to truncate rather than round;
this is specified by the C language manual. The direction of truncation
is machine-dependent, but is toward zero rather than toward minus
infinity on the Vax and Sun. This explains the peculiar way in which
fixmul and fixdiv do rounding.
*/

#include PACKAGE_SPECS
#include PUBLICTYPES
#include FP

/* These switches define what code will come from this "C" module,
   and what code is in an assembler module */

/* Arithmetic routines are in assembler */
#ifndef ASMARITH
#define ASMARITH        0
#endif  /* ASMARITH */

/* Conversion routines are in assembler */
#ifndef ASMCONV
#define ASMCONV         0
#endif  /* ASMCONV */

#define fixedScale 65536.0      /* i=15, f=16, range [-32768, 32768) */
#define fracScale 1073741824.0  /* i=1, f=30 , range [-2, 2) */

/* Macros for software conversion between unsigned long and double
   (some compilers don't implement these conversions correctly) */

#ifndef SOFTUDCONV
#define SOFTUDCONV (ISP==isp_vax && OS==os_bsd)
#endif

#if SOFTUDCONV
#define UnsignedToDouble(u) \
  ((u > (Card32) MAXinteger)? \
    (double) (u - (Card32) MAXinteger - 1) + (double) MAXinteger + 1.0 : \
    (double) u)

#define DoubleToUnsigned(d) \
  ((d >= (double) MAXinteger + 1.0)? \
    (Card32) (d - (double) MAXinteger - 1.0) + (Card32) MAXinteger + 1 : \
    (Card32) d)

#else /* SOFTUDCONV */
#define UnsignedToDouble(u) ((double) u)
#define DoubleToUnsigned(d) ((Card32) d)
#endif /* SOFTUDCONV */

#if !ASMARITH
PUBLIC Fixed fixmul(Fixed x, Fixed y)       /* returns x*y */
  {
  double d = (double) x * (double) y / fixedScale;
  d += (d < 0)? -0.5 : 0.5;
  if (d >= FixedPosInf) return FixedPosInf;
  if (d <= FixedNegInf) return FixedNegInf;
  return (Fixed) d;
  }
#endif

#if !ASMARITH
PUBLIC Frac fracmul(Frac x, Frac y)       /* returns x*y */
  {
  double d = (double) x * (double) y / fracScale;
  d += (d < 0)? -0.5 : 0.5;
  if (d >= FixedPosInf) return FixedPosInf;
  if (d <= FixedNegInf) return FixedNegInf;
  return (Frac) d;
  }
#endif

#if !ASMARITH
PUBLIC Fixed fxfrmul(Fixed x, Fixed y)      /* returns x*y */
  {return fracmul(x, y);}
#endif

#if !ASMARITH
PUBLIC Fixed fixdiv(Fixed x, Fixed y)       /* returns x/y */
  {
  double d;
  if (y == 0) return (x < 0)? FixedNegInf : FixedPosInf;
  d = (double) x / (double) y * fixedScale;
  d += (d < 0)? -0.5 : 0.5;
  if (d >= FixedPosInf) return FixedPosInf;
  if (d <= FixedNegInf) return FixedNegInf;
  return (Fixed) d;
  }
#endif

#if !ASMARITH
PUBLIC Fixed fracratio(Frac x, Frac y)    /* returns x/y */
  {return fixdiv(x, y);}
#endif

#if ((ASMARITH==0)||(ISP==isp_rs6000))
PUBLIC Frac fixratio(Fixed x, Fixed y)      /* returns x/y */
  {
  double d;
  if (y == 0) return (x < 0)? FixedNegInf : FixedPosInf;
  d = (double) x / (double) y * fracScale;
  d += (d < 0)? -0.5 : 0.5;
  if (d >= FixedPosInf) return FixedPosInf;
  if (d <= FixedNegInf) return FixedNegInf;
  return (Frac) d;
  }
#endif


#if !ASMCONV
PUBLIC procedure fixtopflt(Fixed x, float* pf) /* converts x to float and stores at *pf */
  {*pf = (float) ((float) x / fixedScale);}
#endif

#if !ASMCONV
PUBLIC Fixed pflttofix(float* pf)      /* converts float *pf to fixed */
  {
  float f = *pf;
  if (f >= (float)(FixedPosInf / fixedScale)) return FixedPosInf;
  if (f <= (float)(FixedNegInf / fixedScale)) return FixedNegInf;
  return (Fixed) (f * fixedScale);
  }
#endif

#if ((ASMARITH==0)||(ISP==isp_rs6000))
PUBLIC UFrac fracsqrt(UFrac x)        /* returns square root of x */
  {
  double d = UnsignedToDouble(x);
  d = sqrt(d / fracScale) * fracScale + 0.5;
  return DoubleToUnsigned(d);
  }
#endif

#if ((ASMARITH==0)||(ISP==isp_rs6000))
PUBLIC Frac fracdiv ARGDEF2(Frac, x, Frac, y) {
  double d;
  if (y == 0)
    return (x < 0)? FixedNegInf : FixedPosInf;
  d = ((double) x) / ((double) y);
  d += (d < 0) ? (-0.5 / fracScale) : (0.5 / fracScale);
  if (d < -2.0)
    return FixedNegInf;
  if (d >= 2.0)
    return FixedPosInf;
  return (Frac) (d * fracScale);
}
#endif

