/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: RESOURCE.H                                                   */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/


#ifndef RELEASE
int    FAR PASCAL LoadDrvrString( HANDLE hInstance, WORD wId, LPSTR lpBuffer, int nBufferMax );
#else
#define LoadDrvrString(h, id, buf, sz)  LoadString(h, id, buf, sz)
#endif

HANDLE FAR PASCAL LoadDrvrLibrary( LPSTR lpLibraryName, LPHANDLE lphLibrary );
VOID   FAR PASCAL FreeDrvrLibrary( LPHANDLE lphLibrary );
int    FAR PASCAL DrvrStringMessageBox( HWND parent, int TextID, int CaptionID, WORD Type);
LPSTR  FAR PASCAL ReturnDrvrString( HANDLE hInstance, WORD wId, LPSTR lpBuffer, int nBufferMax );

LPBYTE	FAR PASCAL LoadFontResource(int nFontID, HGLOBAL* phgblRcData);
VOID	FAR PASCAL UnloadFontResource(HGLOBAL hgblRcData);
BOOL	FAR PASCAL LoadFontList(int nIdFontRcData, LPSTR** pplpStrPtr);
BOOL	FAR PASCAL LoadAliasTable(VOID);
VOID	FAR PASCAL FreeAliasTable(VOID);
int		FAR PASCAL GetNumDefSubsFont(VOID);
PSERROR FAR PASCAL LoadDefSubsFont(LPSTR lpSubsFontTable, int nFontNameSize);
BOOL	FAR PASCAL LoadIncorrectFixedFontList(VOID);
VOID	FAR PASCAL FreeIncorrectFixedFontList(VOID);
BOOL	FAR PASCAL LoadPreferredCJKFontList(VOID);
VOID	FAR PASCAL FreePreferredCJKFontList(VOID);

//#ifdef STREAMER
BOOL	FAR PASCAL LoadEncodeNameList(VOID);
VOID	FAR PASCAL FreeEncodeNameList(VOID);
//#endif
#ifdef ADD_EURO
BOOL    FAR PASCAL LoadEuroFontList(int EuroResID, LPSTR **);
VOID    FAR PASCAL FreeEuroFontList(LPSTR **);
#endif
BOOL    FAR PASCAL LoadMacGlyphNameList(VOID);
VOID    FAR PASCAL FreeMacGlyphNameList(VOID);

/*
** RESOURCE STRING ROUTINE
*/

#define MAX_RESOURCE_STRING_LENGTH  120
#ifndef DRIVER
#if 0
#define LOAD_STRING_BUFFER(STRING_ID,BUFFER)  ReturnDrvrString((HANDLE)ghDriverMod,(WORD)STRING_ID,(LPSTR)BUFFER,(int)sizeof(BUFFER))
#define LOAD_STRING(STRING_ID)  LOAD_STRING_BUFFER(STRING_ID,szTempBuffer2)
#endif
#endif

#ifdef GLOBAL
char szTempBuffer2[MAX_RESOURCE_STRING_LENGTH];
#else
extern char szTempBuffer2[MAX_RESOURCE_STRING_LENGTH];
#endif
