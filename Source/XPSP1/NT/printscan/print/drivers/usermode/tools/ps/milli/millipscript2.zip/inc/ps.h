/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PS.H                                                         */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/* Change History:                                                           */
/* L3_CLIP -- Level3 clipsave/cliprestore support.  9/16/96  jjia            */
/*                                                                           */
/*****************************************************************************/
                                        // added -by-  [ShyamV]  -09/06/93

#ifndef NOWININCS       // at places, we desire only the plain vanilla PS.H
                        // NOWININCS lets us control what's included from PS.H
#define PRINTDRIVER

#ifndef DBCS
#define DBCS    // this will allow us to have Far-east paper sizes, e.g JAPANESE_POSTCARD
#endif

#include "print.h"      // from SDK. includes <windows.h> if PRINTDRIVER defined
#include "gdidefs.inc"  // from DDK. we were using driver's private GDI.H before.
                        //  moved stuff we need not avail.in GDIDEFS.INC to PS.H
#endif

#include "printcap.h"
#include "devmode.h"
#include "icm.h"
#include "ttfonts2.h"  // This is included here because some defs are used here


#define GDI_VERSION     0x400   //windows version this driver was built for
// Fix bug 164376
// We have to increase this number whenever the EXTDEVMODE data structure is changed.
#define DRIVER_VERSION  0x409   //driver's version number, used by ExtDevMode()
#define RES             300
#define LUCAS           21690   //Lucas' birthday...driver's unique, magic, number
#define INTERNAL_SPOOL_MAX  (4096)  // This is the most efficient buffer size
#define MAX_FILE_NAME_SIZE  13  /* buffer size for any dos file name */
#define MAX_PORT_NAME    MAX_PATH
#define MAX_SAVELEVEL   12   // Maximum allowable savelevel depth

#define SIZE_GLYPHDATA_US   ((DWORD) sizeof(DWORD)+2*((LONG)MAX_NUM_CHARS_US/8))
#define SIZE_GLYPHDATA_CJK  ((DWORD) sizeof(DWORD)+2*((LONG)MAX_NUM_CHARS_CJK/8))

#define RGB_WHITE 0x00FFFFFFL
#define RGB_BLACK 0x00000000L

#define NORMAL 1          // possible value for the "type" arg of rTJobType
#define EPS    2          // possible value for the "type" arg of rTJobType

#define MMPERINCHX10 254

#define MAXPROCS  256
#define PATHSIZE  128
#define DWNULL    (0L)
#define INTENSITY(r,g,b)  (BYTE)(((WORD)((r)*30) + (WORD)((g)*59) + (WORD)((b)*11))/100)
#define wsizeof(x)        ((WORD)sizeof(x))
#define lsizeof(x)        ((LONG)sizeof(x))
#define dsizeof(x)        ((DWORD)sizeof(x))

#define ABS(x) (((x)<0)?(-(x)):(x))

// FAST_IMAGE
#define COLORTOGRAY        1
#define INDEXCOLORTOGRAY   2
#define RESAMPLE           4
#define RESAMPLE_RATIO     4

typedef char CHAR, FAR * LPCHAR;
typedef short SHORT,FAR * LPSHORT;
typedef short FLAG, FAR * LPFLAG;
typedef char BYTEFLAG;
typedef unsigned long DWORD;
typedef CHAR FAR * LP;
typedef HDC FAR * LPHDC;
typedef DWORD (FAR PASCAL *DFARPROC)();
typedef LONG (FAR PASCAL *LFARPROC)();
typedef WORD (FAR PASCAL *WFARPROC)();
typedef SHORT (FAR PASCAL *SFARPROC)();
typedef FLAG (FAR PASCAL *FFARPROC)();
typedef BYTE (FAR PASCAL *BFARPROC)();
typedef CHAR (FAR PASCAL *CFARPROC)();
typedef VOID (FAR PASCAL *VFARPROC)();
typedef HANDLE (FAR PASCAL *HFARPROC)();
// typedef LP (FAR PASCAL *LPFARPROC)(); -by- [ShyamV] - 09/06/93 - Redefinition problem
typedef BOOL  FAR *LPBOOL ;
typedef float FAR *LPFLOAT;

typedef SHORT ANGLE;

#include "fonthdr.h"


typedef float PSMATRIX[6],FAR * LPPSMATRIX;
typedef BYTE PAT[8],FAR * LPPAT; // Brush pattern

//-------------------------------------------------------------------------
//      translation structures
//-------------------------------------------------------------------------

// add CMAP_FFFF for GI-CID/42
#ifdef ADD_EURO
#ifdef T3OUTLINE
// add TYPE3OLHDR
#define MAXPROCSETRECORDS 40
#else
#define MAXPROCSETRECORDS 39
#endif
#else    // ADD_EURO
#ifdef T3OUTLINE
#define MAXPROCSETRECORDS 39
#else
#define MAXPROCSETRECORDS 38
#endif
#endif   // ADD_EURO

// a procset download state record is used to keep track of the status
// of fonts which are downloaded
typedef struct _PROCSETDOWNLOAD
{
     BOOL  allthere;       // TRUE => all procsets are already in the printer
     BOOL  anyprocsetsent; // used during procset downloading -- FALSE
                                         // implies that no procset has been sent during
                                         // this downloading session.
     short procsettype;    // L1L2COMPAT or L2ONLY
     short procsetnextrecord;   // next available slot in list
     short savelevel;           // the current save and restore level
     short currpagenumber;
     short nuppagenumber;
     short  procsetlist[MAXPROCSETRECORDS]; // -1 means not downloaded
                                           // otherwise the save level
     SHORT pagesaveLevel;

} PROCSETDOWNLOAD, FAR * LPPROCSETDOWNLOAD;

// stuff for the font data record
#define FONTNAMESIZE 50         // maximum length of a font name

// stuff for the DSC data record
#define DSCNAMESIZE 255         // maximum length of a DSC name

#define MAXFONTDATARECORDS 200  // maximum number of font records

#define ONEBUF 0x1000           // 4K for one chunk of PassThrough entries
#define HEADERSIZE 0x8

#define MAKEWORD(low, high) ((WORD)(((BYTE)(low)) | (((WORD)((BYTE)(high))) << 8)))

typedef enum _FONTDLTYPE
{
 CC_1=1,   // start from 1, 0 is used for Resident/Downloaded Fonts. !!!!
 CC_3,
 CC_32,
 CC_42,
 CC_CID,
 CC_T01,   // Composite font based on T1
 CC_T03,
 CC_T032,
 CC_T042,
 GI_1,
 GI_3,
 GI_32,
 GI_42,
 GI_CID,
 GI_T01,
 GI_T03,
 GI_T032,
 GI_T042
 } FONTDLTYPE;   // CC=CharCode, GI=Glyph-Index

// defs for tracking Glyph Indexes based on Show Order -GI assignement - GAS
// It is called GAS because gas is connected to SPEED
typedef struct _GIASSIGNED
{
     char   FontName[FONTNAMESIZE];       // font name
     int    StackLevel;                  // level of stack for this font
     LPWORD lpGI2F;          // glyph Index as (Font ID/Char) WORD
     LPWORD lpF2GI;          // Font ID/Char to Glyph-index
     int    NextFID;         // Next font ID - starts from 0
     int    NextCH;          // Next char  - starts from 1
     DWORD  dwSize;          // Size of lpFIDCH and     

     // more WORD to handle 32K+ glyph indices in Korean Fonts (FontName 177188184178)
     LPWORD lpGI2F1;          // glyph Index as (Font ID/Char) WORD
     // we don't need lpF2GI1 because lpF2GI is able to handle 32K chars (FID/CID)(count from 0!)
     // and we will either run-out of VM or do VM recovery before 32K chars are seen.
     DWORD  dwSize1;          // Size of lpFIDCH and     

} GIASSIGNED, FAR * LPGIASSIGNED;

typedef struct _GASDATALIST
{
     GIASSIGNED  GASList[MAXFONTDATARECORDS];
     int         GASNextRecord;   // index to the next available record
} GASLIST, FAR * LPGASLIST;

typedef struct _XUIDREC
{
   WORD     dlType;
   DWORD     locaCkSum;
   DWORD     glyfCkSum;
   DWORD     os2CkSum;
   WORD     x;
   WORD     y;
   DWORD    pixelSize;
} XUIDREC;

typedef struct _SUBFONT43 
{
  LPVOID    lppd;
  LPVOID    FontInfo;
  LPVOID    lpFontData;
  BOOL      bFullFont;
  int       iUFLDLFormat;   /* DLFONT_FORMAT in UFL's view. CC_3 and GI_3 are both DLFONT_TYPE3 */
  LPVOID    pufo;
  char      strPSName[FONTNAMESIZE]; 
  struct _SUBFONT43 *pNext;
}SUBFONT43, FAR *LPSUBFONT43;

// record structure for font data list
typedef struct _FONTDATARECORD
{
     char   FontName[FONTNAMESIZE];       // font name
     BOOL   BoldFake     ;
     BOOL   ItalicFake   ;

     WORD   DBCSFake     ;
     LPWORD GlyphData0;                  // partial font glyph info -- for Pre-StartDoc status
     LPWORD        lpW1ByteGI;     // A 256 entry table to remember one-Byte-char's Glyph-indices.

     int    xScale       ;
     int    yScale       ;
     int    FontID       ;
     float  ascender     ;    //ascending/height ratio.  Added to keep track of same font with different ascender value
     BOOL   addAscExt    ;    //whether to add AXXX to font name. Bug#277500
     LPWORD GlyphData;                  // partial font glyph info & status flag
     SHORT  StackLevel;                  // level of stack for this font
     BOOL   IsGlyphDataOurs ;           // is this buffer ours or owned by 
                                       //  some other FontDataRecord?
#ifdef ADOBE_DRIVER
     LPVOID PSFontRecPtr;
#endif

     // Buffer for Glyph-index table - see ttfonts2.h for its def.
     BYTE  CharSet;  // charset is added to distinguish different charset for a WideFont
     BOOL  ReEncode;  // flag = TRUE if it is re-encoded from primary encoding
     BOOL  ReEncodable; // flag = TRUE if Streamer detects that a font can be reencoded. 
     BOOL  isMylpGITable;
     LPGITABLE   lpGITable;  /*Its members are Allocated in TRAN\ttext.c and freed in trans.c*/
     FONTDLTYPE  fontDLType; // CC/GI-1,3,42,CID,32
     LPGIASSIGNED lpGAS;     // pass GI assignment from cont to tran.
     // Type32 Font Cache tracking
     DWORD FontCacheUsed;    // YCT
     BOOL bDownLoadFace;
     XUIDREC xuidRec;

     BOOL isMypSubFont;
     LPSUBFONT43 pSubFont;
} FONTDATARECORD, FAR * LPFONTDATARECORD;

#define DBCS_DEVICE_FAKE  1
#define DBCS_VERT_FAKE    2
#define DBCS_83PV_VERT_FAKE 4

typedef struct _FONTDATALIST
{
     FONTDATARECORD  FontDataList[MAXFONTDATARECORDS];
     int             currentulpos;         // current underlining position
     int             currentulwidth;       // current underlining width
     int             currentstpos;         // current strikethrough position
     int             currentstwidth;       // current strikethrough width
     int             FontDataNextRecord;   // index to the next available record
                                           // in the font data list
     LPWORD          GlyphData;            // holds most recently allocated buffer
     long            TFontCacheAvail;     // YCT Type32 Font Cache tracking

     // For FE.
     // # of defined fonts in PS interpreter including all OCF Decsendant fonts:
     int    iDefinedFonts[MAX_SAVELEVEL+1];  // # of defined fonts in all savelevels

} FONTDATALIST, FAR * LPFONTDATALIST;

// The following structure stores a list of pass through id and data count
// and pointer to the next passthrough entry
typedef struct tagPASSTHROUGHENTRY
{
     DWORD TickCount;              // Pass through ID
     DWORD dataLen;                // pass through data length
     unsigned short AsciiBinHandle;          // 
     unsigned short passthroughIndex;        // number of entry
} PASSTHROUGHENTRY, FAR * LPPASSTHROUGHENTRY;

typedef struct _PASSTHROUGHHEADER
{
     LPSTR lpNextBufferEntry;
     int   nIndex;
} PASSTHROUGHEADER, FAR * LPPASSTHROUGHHEADER;

// The following structure stores a list of font names for DSC comments
// %%DocumentSuppliedFonts & %%DocumentNeededFonts

typedef struct _FONTDSCENTRY
{
     char FontName[FONTNAMESIZE];       // font name
     BOOL bfSupplied;                   // Supplied (TRUE) or Needed (FALSE)

} FONTDSCENTRY, FAR * LPFONTDSCENTRY;

typedef struct _FONTDSCLIST
{
     short FontDSCNextEntry;
     FONTDSCENTRY FontDSCList[MAXFONTDATARECORDS];

} FONTDSCLIST, FAR * LPFONTDSCLIST;

// The following structure stores a list of file resource names for DSC comments
// %%DocumentSuppliedResource ( Begin/EndResource)
// & %%DocumentNeededResource ( IncludeResource)

typedef struct _FILEDSCENTRY
{
     char FileName[DSCNAMESIZE];       // file name
     BOOL bfileSupplied;                   // Supplied (TRUE) or Needed (FALSE)

} FILEDSCENTRY, FAR * LPFILEDSCENTRY;

typedef struct _FILEDSCLIST
{
     short FileDSCNextEntry;
     FILEDSCENTRY FileDSCList[MAXFONTDATARECORDS];

} FILEDSCLIST, FAR * LPFILEDSCLIST;


// The following structure stores a list of printer feature names for DSC comments
// %%DocumentSuppliedFeatures ( Begin/EndFeature)

typedef struct _FEATUREDSCENTRY
{
     char FeatureName[DSCNAMESIZE];       // feature name
     BOOL bfeatureSupplied;                   // Supplied (TRUE)
     BOOL bNonPPDFeature;                   //NonPPDFeature (TRUE)

} FEATUREDSCENTRY, FAR * LPFEATUREDSCENTRY;

typedef struct _FEATUREDSCLIST
{
     short FeatureDSCNextEntry;
     FEATUREDSCENTRY FeatureDSCList[MAXFONTDATARECORDS];

} FEATUREDSCLIST, FAR * LPFEATUREDSCLIST;

typedef struct _GSTATE          // PostScript graphics state
{
     DWORD    dColor;
     POINT    ptPen;
     short    sPenMiter;
     BYTE     bPenStyle;
     int      nPenStyleWidth;
     BYTE     bPenCap;
     BYTE     bPenJoin;
     BYTE     bBrushStyle;
     BYTE     bBrushHatch;
     PSMATRIX jobCTM;
     POINT    TextCurrentPoint;          // current point for text.
     int      Escapement;
     FONTDATARECORD currentFontData; // font data record for the "current"
                                                         // font instance
     short cliprect[4];       // current cliprect associated with this
                                              // gstate context.
     BYTE   fClipIsMax;       // TRUE if cliprect is as big as it can be
     short  savelevel;        // the save level at which this gsave occurred
     BOOL   bColorSpaceChanged; // TRUE after issue ColspRefresh or setcolorspace jjia 5/30/96
     CSPACESET  ColorSpace;   // Currently active ColorSpace
     DWORD      CRDActive;    // Currently selected CRD
     WORD       bColorMode;   //  if CM_USE_ICM   -   change RGBs
                              //  if CM_USE_CS    -   use ColorSpace
                              //  if CM_USE_CRD   -   use CRD
                              //  if CM_SEND_CRD  -   send CRD
                              //      if CM_CMYK_OUT - send CMYK 
                              //      if CM_USE_ICM   - apply ICM
                              //      if CM_CMYK_IN   - expect CMYK
} GSTATE, FAR * LPGSTATE;

#define MAX_GSSTACK_ELEMS 15
typedef struct tagGSSTACKREC  //This structure is used to make a GSTATE stack.
{
     int      num_pushed ;
     LPGSTATE lpgGState;
     GSTATE   elems[MAX_GSSTACK_ELEMS] ;

} GSSTACKREC, FAR * LPGSSTACKREC ;

//-------------------------------------------------------------------------
//included headers
//      this is done here to let the headers below use the definitions above
//-------------------------------------------------------------------------
//
#include "escmg.h"
//-------------------------------------------------------------------------


typedef struct _PBRUSH
{
     BYTE  bStyle      ;
     BYTE  bHatch      ;
     PAT   pattern     ;
     DWORD dFGColor    ;
     DWORD dBGColor    ;
     FLAG  fPaintBack  ;
} PBRUSH, FAR * LPPBRUSH;

typedef struct _PPEN
{
     BYTE   bStyle     ;
     BYTE   bCap       ;
     BYTE   bJoin      ;
     BYTE   bSpare     ;
     POINT  ptWidth    ;
     SHORT  sMiterLimit;
     DWORD  dFGColor   ;
     DWORD  dBGColor   ;
     FLAG   fPaintBack ;
} PPEN, FAR * LPPPEN;



typedef struct _tagRESOLUTION
{
     short  x_res;
     short  y_res;
} SRESOLUTION;


//state data generated by the driver's dialogs
//
#define MAX_NICKNAME_LEN        32
#define MAX_DEVICE_NAME_LEN     16

/* Item below has to be the sum of the two above plus room for a comma at least */
#define MAX_DEVICE_NICKNAME_LEN MAX_NICKNAME_LEN + MAX_DEVICE_NAME_LEN
#define MAX_DEVTYPE_LEN         32


typedef struct _FONTMETRICS
{
     short int dfType;
     short int dfPoints;
     short int dfVertRes;
     short int dfHorizRes;
     short int dfAscent;
     short int dfInternalLeading;
     short int dfExternalLeading;
     BYTE      dfItalic;
     BYTE      dfUnderline;
     BYTE      dfStrikeOut;
     short int dfWeight;
     BYTE      dfCharSet;
     short int dfPixWidth;
     short int dfPixHeight;
     BYTE      dfPitchAndFamily;
     short int dfAvgWidth;
     short int dfMaxWidth;
     BYTE      dfFirstChar;
     BYTE      dfLastChar;
     BYTE      dfDefaultChar;
     BYTE      dfBreakChar;
     short int dfWidthBytes;

} FONTMETRICS, FAR * LPFONTMETRICS;

//font instance style masks
//
#define FI_none      0x00
#define FI_italic    0x01
#define FI_bold      0x02
#define FI_underline 0x04
#define FI_strikeout 0x08
#define FI_vertical  0x80


typedef enum _JUSTTYPE
{
     JUST_standard,  //use standard Windows justification--data in DRAWMODE struct
     JUST_word,      //use SETALLJUSTVALUES with word breaks
     JUST_char       //use SETALLJUSTVALUES with char breaks
} JUSTTYPE, FAR * LPJUSTTYPE;

typedef struct 
{
     short extra;
     short rem;
     short err;
     WORD count;
     WORD ccount;
} JUSTBREAKREC, FAR *LPJUSTBREAKREC;


typedef struct _TEXTSTATE
{
     JUSTTYPE     justType  ;    // current justification mode
     JUSTBREAKREC jWord     ;    // state data for word justification
     JUSTBREAKREC jChar     ;    // state data for char justification
     SHORT        sTrack    ;    // current track kerning track number
     BYTEFLAG     bfPairKern;    // TRUE=pair kerning enabled
     BYTE         bSpare    ;    // unused
     DWORD        dColor    ;    // current color of text, an RGB value
} TEXTSTATE, FAR * LPTEXTSTATE;


// typedef ST: Driver (control-side) states
// See ..\dmg\statmach.h for more information on these states.  They are
// declared here because they must be used everywhere.

typedef enum _ST 
{
     ST_NULL = 0,        // For error checking
     ST_INITIAL,
     ST_ENABLED,
     ST_JOB_STARTED,
     ST_EMPTY_PAGE,
     ST_MARKED_PAGE,
     ST_RAW_DATA,
     ST_JOB_DONE,
     ST_ENDED,
     ST_TERMINAL
} ST, far *LPST;

#define ST_MAX  (ST_TERMINAL+1)         // ST_MAX: number of items in _ST


typedef struct _JOB
{
     BYTEFLAG bfDoMSRectHack;    // TRUE => Last call was PASSTHROUGH which
                                                   // activates "MSRectHack"; if next call is 
                                                   // Output(OS_RECTANGLE) do "MSRectHack".
                                                   // FALSE => standard behaviour.
     BYTEFLAG bfDisableGDI;      // TRUE => Calls which put marks on page or
                                                   // change GDI state are to be NOPs but return
                                                   // success.  FALSE => Such calls proceed normally.
     BYTEFLAG bfCopyCountSent;   //TRUE => Copy count sent through Escape
     BYTEFLAG bfIsCurrentPoint;  //TRUE=>Don't do moveto when creating MGX paths
     
     BYTEFLAG bfTTEnabled;    // TRUE => TrueType fonts are enabled
     BYTEFLAG bfReset;        // set if RESETDC called
     BYTEFLAG bfESCSetBounds; // set if escape SET_BOUNDS called
     BYTEFLAG bfESCPassThrough; // set if escape PASSTHROUGH called
     BYTEFLAG bfESCOpenChannel; // set if escape OPENCHANNEL called
     BYTEFLAG bfJobMinHeader ;  // set if only MinHeader is used.

#ifdef ADOBE_DRIVER
     BYTEFLAG bfType1Incr;   // set if incremental type 1 downloading desired.
                             // 0 off, 1 on, 2 ask each job
#endif
     BYTEFLAG bfIsFirstNextBand; // to detect the first NEXTBAND call
     BYTEFLAG bfESCResetPage;    // set if escape RESETPAGE called
     BYTEFLAG bfInStretchDib;    // to block nested stretchdib calls.
                                 // work around to fix bug 192129. jjia  12/2/97
     BYTEFLAG bfInWriteSpool;

} JOB, FAR * LPJOB;

typedef struct _GRAPHICS
{
     BYTE     bArcDirection  ;  // Set by Escape. Used by TArc().
     BYTE     bBackgroundMode;  // Same as DrawMode.bkMode=OPAQUE or TRANSPARENT
     DWORD    dBGColor       ;
     DWORD    dFGColor       ;
     DWORD    hCMTransform   ;  // Currently active transform
     DWORD    CRDClear       ;  // CRD that should be undefined
     DWORD    CSAClear       ;  // CSA that should be undefined
     BYTE     bCRDSent[MAX_SAVELEVEL]   ;  // What CRDs had been sent for each savelevel
     BYTE     bCSASent[MAX_SAVELEVEL]   ;  // What CSAs had been sent for each savelevel
     LOGCOLORSPACE CS        ;  // CSA built from this Logical color space.
     BYTE     bPolyMode      ;  // PolyMode BEZIER,POLYLINE, or POLYSEGMENT
     SHORT    ScaleMode      ;  // Set in ESCSetDIBScaling.Used in DIBToDevice()
     SHORT    xScale         ;  //  "            "            "         "
     SHORT    yScale         ;  //  "            "            "         "
     int      PathLevel;
     short    XformLevel ;      // number of pending CTM saves performed
     // L3_CLIP
     GSTATE   GState;           // current gstate.
     BOOL     bClipSave;        // TRUE if clipsave is send.
     // ALWAYS_ICM
     DWORD    hDefCMTransform;  // Default ICM transform. The driver use this information
                                // to turn on ICM.
} GRAPHICS, FAR * LPGRAPHICS;

typedef DWORD PCOLOR, FAR * LPPCOLOR;


// Driver has private (extended) versions of FONTINFO and SCALABLEFONTINFO structures.
// So this is used in the driver, rather than the one from GDIDEFS.INC

//if the size of FONTINFO is desired consider...
//1. if only the std stuff is needed do "sizeof(FONTINFO)"
//2. if the complete size is desired, you must get the size of the
//              related PFM minus sizeof(PFMPROLOG) plus sizeof(FONTEXTRA)
//
typedef struct tagPSFONTINFO
{
            //this stuff makes up the "std" struct...if there
            //is such a thing
            //
            short int dfType;
            short int dfPoints;
            short int dfVertRes;
            short int dfHorizRes;
            short int dfAscent;
            short int dfInternalLeading;
            short int dfExternalLeading;
            BYTE dfItalic;
            BYTE dfUnderline;
            BYTE dfStrikeOut;
            short int       dfWeight;
            BYTE dfCharSet;
            short int dfPixWidth;
            short int dfPixHeight;
            BYTE dfPitchAndFamily;
            short int dfAvgWidth;
            short int dfMaxWidth;
            BYTE dfFirstChar;
            BYTE dfLastChar;
            BYTE dfDefaultChar;
            BYTE dfBreakChar;
            short int       dfWidthBytes;
            unsigned long int       dfDevice;
            unsigned long int       dfFace;
            unsigned long int       dfBitsPointer;
            unsigned long int       dfBitsOffset;
            WORD dfSizeFields;
            DWORD dfExtMetricsOffset;
            DWORD dfExtentTable;
            DWORD dfOriginTable;
            DWORD dfPairKernTable;
            DWORD dfTrackKernTable;
            DWORD dfDriverInfo;             //will hold the ptr to the "below the 2nd line" data
            DWORD dfReserved;
            //
            //-----------------THE FIRST LINE-------------------
            //The rest of the FONTINFO contents are positioned
            //at varying positions using offsets from the main
            //structure above. All of this information is gotten
            //from the PFM file that was used to create it. This
            //data includes...
            //
            //      device name...char[]
            //      MS face name...char[]
            //      EXTTEXTMETRIC structure
            //      extent table (character widths)
            //      PS face name
            //      pair kern table
            //      track kern table
            //
            //----------------THE SECOND LINE-------------------
            //Data related to the particular instance of a font
            //is stored after everything else.  In addition it
            //contains the relavant pointers to the stuff above
            //and below the first line.
            //
            //      FONTEXTRA fontExtra
} PSFONTINFO, FAR *LPPSFONTINFO;



typedef struct _tagREALIZEBUFS    // frequently used buffers for realization
{

// --------------------- for RealizeFont --------------
//   pass1 to pass2  cache

     BOOL      bTTReplaced;
     WORD        sFontInfoSize ;   /* FAIL */

//   -------------------  for TTRealizeFont -------------
//       avoid redundancy, cache results between passes
     WORD      wSize ;
     WORD      numGlyphs ;  
     WORD      cyFont ;
     BOOL      bOutline ;
     BOOL      bTTResident;
     TEXTXFORM     cEngineTXF;

     WORD      wTTFlags;

//   ----------------------------------------------------

   LPBYTE   lpScoreArray ;
   WORD     cScoreArray  ;
   LPPSFONTINFO   lpTTFI ;
   WORD     cTTFI  ;
   LPPSFONTINFO   lpFI ;
   WORD     cFI  ;
   BOOL bUseWideFont;

// ------ realize to Disable cache. -------

   LPFONTLIST  lpFontList;
   WORD        wNumFonts  ;
   WORD        nTTrealized ;

   LPFONTCACHE    lpFontCache;
   HPFONTDIRECTORY      hpFontDir;
    HPDIRINDEX      hpDirIndex;
   WORD             UsePSFont;

// ------- font width cache -------

    WORD  offsetWidths ;
    LPWORD  lpdWidths ;  //  widths of TTRefEMfont
    WORD  sizlpdWidths ;
    LPWORD rgwWidths;   //  for TT width in pixels
    WORD sizrgwWidths;
    LPWORD devlpsWidths;   //  for device font width in pixels
    WORD sizdevlpsWidths;
    LPWORD devlpdWidths;   //  for device font width in EMs
    WORD sizdevlpdWidths;

}  REALIZEBUFS, FAR * LPREALIZEBUFS ;


// Used in TTEXT.C for TT to Type1 conversion (statics before, moved here)

typedef struct _tagTTTOTYPE1STUFF
{
     LPBYTE   lpOutlineBuf ;
     WORD     wOutlineBufSize ;
     LPBYTE   lpCSBuffer;
     LPBYTE   lpCSPos;       //  points to current position within buffer.
     LPBYTE   lpCSEnd ;
     WORD    wCSSize;
     WORD    rEExec;        // Current seed for eexec functions 
} TTTOTYPE1STUFF, FAR * LPTTTOTYPE1STUFF;



// These are for buffering bitmaps - moved from stretchd.h
typedef struct _BITMAPBUFFER
{
    BOOL        dib;
    LONG        destX;
    LONG        destY;
    LONG        destXE;
    LONG        destYE;
    LONG        srcX;
    LONG        srcY;
    LONG        srcXE;
    LONG        srcYE;
    DWORD       rop;
    PBRUSH      pBrush;
    DRAWMODE    dm;
    RECT        clip;
    BOOL        nullPBrush;
    BOOL        nullDM;
    BOOL        nullClip;
    BITMAP   devBitmap;
    HANDLE      hBits;
    BITMAPINFOHEADER bitmapInfo; // this field must be at the end
} BITMAPBUFFER, FAR * LPBITMAPBUFFER;

typedef HANDLE HBITMAPBUFFER;

typedef struct _tagUFLBUFFER
{
    LPDWORD lpDLGlyph;          /* HiWord is ToEngine, LoWord is Gid */
    WORD    wDLGlyphSize;
    
    USHORT  *lpCharIndex;
    WORD    wCharIndexSize;

    LPWORD  lpUnicode;
    WORD    wUnicodeSize;

} UFLBUFFER, FAR * LPUFLBUFFER;

//The following structure contains pre-allocated buffers used by the Send functions,
// Binary conversion functions and PortWrite functions. It is extensible.

typedef struct _tagGLOBALMEMBUFFER
{
     // data space for use by PSSendStringAscii7():  Initial size 0x7000 bytes    
     HANDLE    hStringAscii7;   
     BYTE huge * lpStringAscii7;  
     DWORD     dStringAscii7;

     // data space for use by PSSendDirect(): Fixed size 0x1000 bytes    
     HANDLE    hDirect;   
     LPBYTE    lpDirect; 
     DWORD     dDirect;
     // data space for use by PSSendBitMapDataLevel1Binary(): Fixed size 0x4000 bytes    
     HANDLE    hBitMapDataLevel1Binary;   
     LPBYTE    lpBitMapDataLevel1Binary; 
     DWORD     dBitMapDataLevel1Binary;

     // data space for use by PSSendStringOutput(): Initial size 0x800 bytes    
     HANDLE    hStringOutput;   
     BYTE huge * lpStringOutput;  
     DWORD     dStringOutput;

     LPBYTE   lpSubStringBuf ;
     WORD     cSubStringBuf  ;

     TTTOTYPE1STUFF TTtoT1stuff; // all TT to Type1 statics moved here
     REALIZEBUFS  RealizeBufs;  // frequently used buffers for realization

     // Information about bitmap being buffered.
     HBITMAPBUFFER    hBitmapBf;
     LPBITMAPBUFFER   lpBitmapBf;
     BOOL             handleBitmapNow;
     BOOL             bFlushInProgress;

     UFLBUFFER         UFLBuffers;
} GLOBALMEMBUFFER ; 


// Font Substitution table
typedef struct _FONTSUBSTABLE 
{
     char      TTFontName[FONTNAMESIZE];
     char      PSFontName[FONTNAMESIZE];
} FONTSUBSTABLE, FAR* LPFONTSUBSTABLE;


// Stuff to save Special PassThrough Data and Font Data send before StartDoc():
typedef struct tagSPCLPSDATA
{
  DWORD    dwSize;      // size of the buffer - lpPSData
  DWORD    dwPSCount;   // length of PS data (in bytes) or current position in lpPSData
  LPBYTE   lpPSData;    // Pointer PS data
  struct   tagSPCLPSDATA FAR * lpNextPSData; /* To have a list of data records */
} SPCLPSDATA, FAR* LPSPCLPSDATA;

// this def is used as a convinent way to convert data, first two bytes as a WORD from a string
typedef struct _WLPBYTE
    {
      WORD     wLen;
      LPBYTE   lpData;
}
WLPBYTE, FAR *LPWLPBYTE;

//
// Constants for PSINJECTBYTE.PSInjectID field
//
typedef enum  _PSInjectionPoint{

  IPS_BEGINSTREAM = 1,               // before the first byte of job stream
  IPS_PSADOBE,                        // 2    before %!PS-Adobe-x.y
  IPS_PAGESATEND,                     // 3  replaces driver's %%Pages: (atend)
  IPS_PAGES,                          // 4    replaces driver's %%Pages: nnn

  IPS_DOCUMENTNEEDEDRESOURCES,                   // 5    resources needed by the application
  IPS_DOCUMENTSUPPLIEDRESOURCES,                 // 6    resources supplied by the application
  IPS_PAGEORDER,                      // 7    replaces driver's %%PageOrder:
  IPS_ORIENTATION,                    // 8    replaces driver's %%Orientation:
  IPS_BOUNDINGBOX,                    // 9    replaces driver's %%BoundingBox:
  IPS_DOCUMENTPROCESSCOLORS,          // 10   replaces driver's %%DocumentProcessColors: <color>

  IPS_ENDCOMMENTS,                       // 11   before %%EndComments
  IPS_BEGINDEFAULTS,                  // 12   after %%BeginDefaults
  IPS_ENDDEFAULTS,                    // 13   before %%EndDefaults
  IPS_BEGINPROLOG,                    // 14   after %%BeginProlog
  IPS_ENDPROLOG,                      // 15   before %%EndProlog
  IPS_BEGINSETUP,                     // 16   after %%BeginSetup
  IPS_ENDSETUP,                       // 17   before %%EndSetup
  IPS_TRAILER,                        // 18   after %%Trailer
  IPS_EOF,                            // 19   after %%EOF
  IPS_ENDSTREAM,                      // 20   after the last byte of job stream
  IPS_DOCUMENTPROCESSCOLORSATEND,     // 21   replaces driver's %%DocumentProcessColors: (atend)

  IPS_PAGE_PAGENUMBER    = 100,            //       replaces driver's %%Page:
  IPS_PAGE_BEGINSETUP,                 // 101  after %%BeginPageSetup
  IPS_PAGE_ENDSETUP,                   // 102  before %%EndPageSetup
  IPS_PAGE_TRAILER,                    // 103  after %%PageTrailer
  IPS_PLATECOLOR,                     // 104  replace driver's %%PlateColor: <color>

  IPS_PAGE_SHOWPAGE,                       // 105  before showpage operator
  IPS_PAGEBOUNDINGBOX,                       // 106  replaces driver's %%PageBoundingBox:
  IPS_ENDPAGECOMMENTS                 // 107  before %%EndPageComments
} PSInjectionPoint, FAR * LPPSInjectionPoint;


// Stuff to save PostScript Injection Data 
typedef struct tagPSINJECTDATA
{
  DWORD    dwbufSize;   // size of the availabel buffer - lpPSData
  DWORD    dwPSCount;   // length of PS data (in bytes) 
  LPBYTE   lpPSData;    // Pointer PS data
  BOOL     bStartBuffer;   // indicate whether this is starting of the buffer
  WORD     iPSInjectID; // PostScript injection id
  WORD     iPageNumber;  // Injection point id
  struct   tagPSINJECTDATA FAR * lpNextPSInjectData; /* To have a list of data records */
} PSINJECTDATA, FAR* LPPSINJECTDATA;

// this def is used as a convinent way to convert data. 
typedef struct _PSINJECTBYTE
{
    DWORD    dwLen;      // length of PostScript data
    WORD     PSInjectID;
    WORD     PageNumber;

    //
    // Followed by raw data to be injected
    //

}
PSINJECTBYTE, FAR *LPPSINJECTBYTE;

// this def is used as a convinent way to convert data,
// first six bytes as THREE WORDs from a string
typedef struct _W3LPBYTE
    {
      WORD     wFirst;
      WORD     wSecond;
      WORD     wThird;
      LPBYTE   lpData;
}
W3LPBYTE, FAR *LPW3LPBYTE;

typedef enum _SMSSTARTDOC  /* Simple-Minded-State for startdoc() call*/
{
NORMAL_SD=0,
FIRST_SD,
SECOND_SD
 } SMSSTARTDOC;   // Normal =0 as before.


typedef enum _WATERTYPE
{
        WATER_null=0,   // WATERMARK structure is null/no memory allocated for FONTINFO..
        WATER_filled=1,   // WaterMark FontInfo/TextXForm are filled/valid
        WATER_form_sent=2,  // Watermark Formdict is sent
        WATER_exec_sent=3       // Watermark formdict execform command is sent
}
WATERTYPE, FAR * LPWATERTYPE;
    /* I intentionally put numbers 0,1,2,3 there because the ORDER is important.
       If new state is added, these numbers should be un-changed.

    A Simple Water State Transition:
       Start_doc  => set it to WATER_null if lpWMark!=NULL
       Init lpWMark => set it to WATER_null
       WATER_null    => call InitFontInfo, change state to WATER_filled;
       >= WATER_filled  => Can use the FontInfo, send form/exec change to form/exec_sent
       WATER_filled => can send form, change to WATER_form_sent
       WATER_form_sent => can send exec, change to WATER_exec_sent
       WATER_exec_sent => done with watermark
       At end of every page, reset to WATER_filled if not NULL.
    */


typedef struct _WMARK_FONT
{
        HANDLE      fontHandle;     // Handle for lpFOntInfo
        LPPSFONTINFO    lpPsFontInfo;       // FontInfo for the Watermark font
        HANDLE      txfHandle;      // handle for lpTextXForm
        LPTEXTXFORM lpTextXForm;    // for watermark font
        //SHORT     onlyFirstPage;  //  Watermark on First Page only flag
        WATERTYPE   WaterState;     // Water state/quality. 
        //SHORT     WaterBackground;   // use Underground water flag.
}
WATERMARK_FONT, FAR * LPWATERMARK_FONT;


typedef struct _WMARK_INFO
{
        WATERMARK_FONT  wmFont;
        WATERMARK_FONT  wmBaseFont;  // This addtion is used to handle Multiple Master Fonts. fix bug 385
}
WATERMARK_INFO, FAR * LPWATERMARK_INFO;
// This WATERMARK_INFO is the info PDEVICE wants to keep. Different from WM in watermrk.h
// WM is used to access watermar.ini .

#define MAXPATTERN 10 // max number of pattern brushes saved

// structures for saved hatched and bitmap pattern brushes
typedef struct _PATBRUSH
{
     BYTE  bStyle;   // style of brushes saved
     PAT   pattern;  // pattern of bitmap brush or if brush is hatched, pattern[0] is the hatch style
     short savelevel;// savelevel in which this brush is created
} PATBRUSH, FAR *LPPATBRUSH;     

typedef struct _PATBRUSHINFO
{
   BYTE       bBrushIndex;  // index into bStyle where new pattern is inserted
   PATBRUSH   brush[MAXPATTERN]; // pattern brushes saved
} PATBRUSHINFO, FAR * LPPATBRUSHINFO;

typedef struct _PDEVICE
{
     short     sMagic  ;        //absolutely has to be here!
     HDC       hdc     ;        //DC for Abort procedure 
     PBRUSH    brush   ;        //Current physical brush
     PPEN      pen     ;        //Current physical pen
     TEXTSTATE text    ;        //text output stuff
     GRAPHICS  graphics;
     JOB       job     ;

     CHAR      szPortName[MAX_PORT_NAME];   // Port name
     CHAR      szSDOutput[MAX_PORT_NAME];   // output name of DOCINFO in StartDoc time
     HANDLE    hPortHandle  ;    // Job handle which comes from OpenJob()
     short      wSpoolError  ;   //  result of WriteSpool.
     CHAR      szTitle[128];    //Passed in with STARTDOC escape, move to JOB struct??
     SRESOLUTION DeviceRes;     //resolution structure takes non-square resolutions into account
     RECT     bbox;              
     ST       stCurrent;         // Current state of state machine (statmach.c).
                                 //since last start doc (for MSWord fix)

// The following, if used, must be initialized from DEVMODE structs
// and may be changed during the course of a job via escapes
     SHORT    sScreenAngle;                 //for MicroGrafix escapes
     FREQUENCY ScreenFrequency;             //for MicroGrafix escapes
     SHORT    sSetSpread;                   //for MicroGrafix escapes

//paper stuff
     POINT    ptPaperDim;                   //height and width of paper in pixels, from PPD keyword PAPERDIM
     RECT     imageRect;                    //imageable area on paper, in pixel units, from PPD keyword IMGAREA
     PSMATRIX psmatrix;                      // Converts GDI to User coords.

     
     WORD FAR *lpTTFontList;    // handle to array of atoms for fonts used 
     int       sTTFontList;     // number of entries in list 
     int       cTTFontList;     // count of fonts in list 

     HANDLE    TFuncHandle;     // handle to token processing functions
     LPVOID    lpTFuncPtr;      // ptr to token processing functions
     HANDLE    AsciiBinHandle;  // handle to ascii or binary output functions
     LPVOID    lpAsciiBinPtr;   // ptr to ascii or binary output functions
     
     HANDLE    FontDataHandle;  // handle to the font data list structure
     LPFONTDATALIST lpFontDataList;    // ptr to the font data list structure
     HANDLE    FontDSCHandle;          // handle to the font DSC list structure
     LPFONTDSCLIST lpFontDSCList;      // ptr to the font DSC list structure
     HANDLE    FileDSCHandle;          // handle to the file DSC list structure
     LPFILEDSCLIST lpFileDSCList;      // ptr to the file DSC list structure
     HANDLE    FeatureDSCHandle;          // handle to the feature DSC list structure
     LPFEATUREDSCLIST lpFeatureDSCList;   // ptr to the feature DSC list structure
//     HANDLE    PassThroughHandle;         // handle to the PassThrough list structure
//     LPPASSTHROUGHENTRY lpPassThroughCurrentEntry;   // ptr to the current passthrough entry
   
     LPSTR lpPassThroughRootEntry;   // ptr to the begin of the passthrough entry
     LPSTR lpPassThroughCurrentEntry;// ptr to the begin of the passthrough entry
     int       iCurrIndex;

     HANDLE    ProcsetstuffHandle;     // handle to the procset data
     LPPROCSETDOWNLOAD lpProcsetstuff; // ptr to the procset data
     
     HANDLE    hdlGSStack;      // handle to the Gstate Stack
     LPGSSTACKREC lpGSStack;    // ptr to the Gstate stack

     HANDLE    hDriverTokenDLL; // DLL handle for external translator DLL.
     HANDLE    hAltTrans;       // handle for data space for use by
                                // alternate translators
     LPVOID    lpAltTrans;      // pointer to the data space for alternate
                                // translators

     WORD      iSpoolBufferCount;                 // Internal PDEVICE spooling
     BYTE      SpoolBuffer[ INTERNAL_SPOOL_MAX ]; // Internal PDEVICE spooling
     
     // The following are entries for TrueType support only!!
     WORD      DLState;         // "converted font" header download status
     GLOBALMEMBUFFER GlobalBuffer;

     // For EnumDFonts when printer has different x & y resolutions
     LPTEXTMETRIC lptm;

     // TT Font Substitution table
     LPFONTSUBSTABLE lpFontSubsTable;
     WORD      wFontSubsEntries;

     int       iHelpContext;    /* Help Context */

     LPWPXBLOCKS lpWPXblock;       // pointer to wpx (PPD data)
     LPPSEXTDEVMODE lpPSExtDevmode;   // pointer to Extended Devmode structure

     // VM tracking stuff
     // should only be changed by the VM code
     // use VMEnable, VMDisable, VMRecoverEnable, VMRecoverDisable
     SHORT doVMTracking;   // keep track if VM tracking is enable
     SHORT doVMRecovery;   // keep track if VM recovery is enable
                           // this only matters if VM tracking is enable
     float vmEstimateUsed; // keep track of used vm
     BOOL  VMDisabledOnPassThru;

     short pagebackground; // last page for which background white was sent
     LAYOUT     startingLayout;
     PAP_ORIENT startingOrient;
     BOOL       startingMirror;
          
     // For FE.
     WORD fDBCS;
     int  iResIdCMap;
     DWORD dwDownloadFaceStr;  // length of buffer lpDownloadFaceStr
     LPW3LPBYTE lpDownloadFaceStr ; // String used for next Escape(DownloadFace) call. 
     int  nPreStartDocFonts;    // keep track of Fonts downloaded before startDOC

    // OEMPLUGI begin
#ifdef Adobe_Driver    
    WORD   wcOEMFilter;           // Number of registered filters
    DWORD  cbOEMDataSize;         // size of current OEMFilterData
    HANDLE hOEMFilterData;        // Handle of the OEMFilterData.
    HANDLE hPSFax;

    HANDLE hWebPrinter;
#endif
    
    
    HANDLE hAppIsv;
    HANDLE hDrvInfo; /* OEMCUST -John KWan */
    HANDLE hOemCust; /* OEMCUST -John Kwan */
    // OEMPLUGI end

#ifdef ADOBE_DRIVER
  BOOL WMFirstPageFlag;
  BOOL disableNUP;     /* 0 - default/allow features; otherwise disabled */
  BOOL disableWMark;   /* 0 - default/allow features; otherwise disabled  */
  SMSSTARTDOC  SmsStartDoc;  // a simple minded state to remember how the EscStartDoc() is called to support DownlaodFace before startDoc.
  BOOL bCopyToSpecial;            // after this flag is set, all data goes to lpSpecialPSData.
  LPSPCLPSDATA lpSpecialPSData;   // Special passthrough PS data and DownloadFace's fontdata go here

  BOOL bCopyToInjectBuff;         // after this flag is set, all data goes to lpPSInjectionData.
  LPPSINJECTDATA lpPSInjectData;    // PS Injection data record
  LPPSINJECTDATA lpPSInjectRoot;    // PS Inject record anchor 
  LPBYTE lpCurrentBuffer;          // PS Injection buffer ptr base

  float vmUsedPreStartDoc;    // keep track of used vm before startDOC - such as SpecialPassThrough2
  HANDLE    WMarkHandle;          // Handle to the Watermark cached FontInfo stuff,
  LPWATERMARK_INFO lpWMark;   // Pointer to Watermark cached FontInfo,
#endif
   HANDLE    GASHandle;  // handle to the GIAssigned list structure
   LPGASLIST lpGASList;    // ptr to the font data list structure

// added data for UFL
   LPVOID   pufl;
   LPVOID   pout;
   
   int iCurrentCopies;   // current number of copies
   HANDLE   hPatBrushInfo;    // handle to array of pattern brushes saved
   LPPATBRUSHINFO lpPatBrushInfo;   // ptr to pattern brushes saved

   LPWORD   pwCommonEncode;
   HANDLE   hCommonEncode;

   int   iDefaultCopies;          // the initial # of copies from Application

   BOOL     bPass1Done;
#ifdef ADD_EURO
   LPSTR    *lpEuroFontList;
   LPSHORT  lpSCDParams;
   int      NumEuroFonts;
#endif

} PDEVICE, FAR *LPPDEVICE;

typedef struct _OUTSTREAM
{
   LPVOID   put;
   LPVOID   downloadProcset;
   LPPDEVICE    pdev;
}
OUTSTREAM, FAR * LPOUTSTREAM;

// Flags for fDBCS in PDEVICE.
#define DBCS_FONT      0x0001
#define DBCS_DEVICE    0x0002
#define DBCS_VERT      0x0004
#define DBCS_83PV_VERT 0x0008


//this is done for the sake of completeness
//...now, all driver type definitions are in this file
//
// #include "drivinit.h". Replaced by PRINT.H -by-  [ShyamV] - 9/7/93
//  stuff in drivinit.h, not available in PRINT.H has been moved to PS.H.

//-------------------------------------------------------------------------
// constants and enumerations
//-------------------------------------------------------------------------
//

enum
{   //those that apply map directly to GDI
     BRUSHSTYLE_solid,
     BRUSHSTYLE_null,        //same as hollow type in GDI
     BRUSHSTYLE_hatched,
     BRUSHSTYLE_pattern,
     BRUSHSTYLE_indexed,
     BRUSHSTYLE_dibpattern,
     BRUSHSTYLE_customglyph,
     BRUSHSTYLE_custompattern,
     BRUSHSTYLE_end
};

enum
{   //those that apply map directly to GDI
     BRUSHHATCH_none=-1,
     BRUSHHATCH_horiz,
     BRUSHHATCH_vert,
     BRUSHHATCH_fdiag,
     BRUSHHATCH_bdiag,
     BRUSHHATCH_cross,
     BRUSHHATCH_xxx,
     BRUSHHATCH_end
};

enum
{
     PENCAP_butt,
     PENCAP_round,
     PENCAP_square,
     PENCAP_end
};

enum
{
     PENJOIN_miter,
     PENJOIN_round,
     PENJOIN_bevel,
     PENJOIN_end
};

#define PENMITER_default 10

enum
{   //those that apply map directly to GDI
     PENSTYLE_solid,
     PENSTYLE_dash,
     PENSTYLE_dot,
     PENSTYLE_dashdot,
     PENSTYLE_dashdotdot,
     PENSTYLE_null,
     PENSTYLE_inside,
     PENSTYLE_custom,
     PENSTYLE_end
};

enum
{
     ARC_cw,
     ARC_ccw,
     ARC_end
};

// EM describes the basic character cell dimension (in Adobe units)
// #define EM 1000 Do not hardcode - Get from pfm file

//Dialects that the Driver can produce as output:
#define DIALECT_PS    0
#define DIALECT_EPS   1
#define DIALECT_AI3   2
#define DIALECT_FIRST DIALECT_PS
#define DIALECT_LAST  DIALECT_AI3

//Data protocols supported:
#define PROTOCOL_ASCII      0
#define PROTOCOL_BCP        1
#define PROTOCOL_TBCP       2
#define PROTOCOL_BINARY     3

// #define PROTOCOL_PJL        2
// #define PROTOCOL_PJL_TBCP   4
// #define PROTOCOL_TBCP_PJL   5
// #define PROTOCOL_FIRST      PROTOCOL_ASCII
// #define PROTOCOL_LAST       PROTOCOL_TBCP_PJL



///////////////////////////////////////////////////////////////////////////
// Stuff from old DRIVINIT.H  (PRINT.H replaces it)
///////////////////////////////////////////////////////////////////////////

// Added -by- [ShyamV] - 09/06/93
// The following are some things private to the driver from the old DRIVINIT.H
// Since we have started using SDK'S  PRINT.H, these were moved here.

#define DMORIENT_ROT_LANDSCAPE          3
#define DMORIENT_FIRST                  DMORIENT_PORTRAIT
#define DMORIENT_LAST                   DMORIENT_ROT_LANDSCAPE

// bin numbers
#define SINGLE_SLOT         15          // Chicago PRINT.H has  DMBIN_ROLL

#undef DMBIN_LAST
#define DMBIN_LAST          SINGLE_SLOT

// user defined options typically begin at the following number 
#define DMOPT_USER          256

#define DMDUP_FIRST      DMDUP_SIMPLEX
#define DMDUP_LAST       DMDUP_HORIZONTAL

// landscape orientation angle selections 
#define DMORIENT_PLUS90         1
#define DMORIENT_MINUS90        2
#define DMORIENT_ANY            3
#define DMORIENT_ANGLE_FIRST    DMORIENT_PLUS90
#define DMORIENT_ANGLE_LAST     DMORIENT_ANY


///////////////////////////////////////////////////////////////////////////
// Stuff from old GDI.H (GDIDEFS.INC replaces it)
///////////////////////////////////////////////////////////////////////////

// Added -by- [ShyamV] - 09/06/93
// Contains remnants from driver's private GDI.H which are not available in  
//  the DDK supplied  GDIDEFS.INC.   
// Also has stuff that should be in PRINT.H (or GDIDEFS.INC) but was omitted.  

#define OVERHANG 0      // used only in  CFONT.C
#define EXT_RKSJ_CHARSET 128     // used only in CFONT.C. Japanese char set.

/* The output styles not defined in  GDIDEFS.INC */
#define     OS_ROUNDRECT        72

// should be in PRINT.H!
typedef RGBTRIPLE FAR* LPRGBTRIPLE;
typedef RGBQUAD FAR* LPRGBQUAD;

// The pair kerning structure
// Note: the kern amount is given in hundreths of a point per character
typedef struct _KP
{
     int cPairs;                   // The number of kerning pairs
     struct
     {
          int iKey;               // The kerning pair concatenated into a key
                                                  // NOTE: this is syntactically different from
                                                  // the way this is defined in the DDK, but
                                                  // represents the equivalent...union(byte[2],word)
          int iKernAmount;
     } rgPairs[1];
}
KP, FAR *LPKP;

/* The info for a single kern track */
typedef struct _TRACK
{
            short iDegree ;      // The degree of kerning
            short iPtMin  ;      // The minimum point size
            short iKernMin;      // The minimum kern amount
            short iPtMax  ;      // The maximum point size
            short iKernMax;      // The maximum kern amount
}TRACK, FAR *LPTRACK  ;

// The track kerning table for a font
typedef struct _KT
{
            short cTracks    ;   // The number of kern tracks
            TRACK rgTracks[1];   // The kern track information
}
KT, FAR *LPKT;

typedef struct _ETM
{
            short etmSize;
            short etmPointSize;
            short etmOrientation;
            short etmMasterHeight;
            short etmMinScale;
            short etmMaxScale;
            short etmMasterUnits;
            short etmCapHeight;
            short etmXHeight;
            short etmLowerCaseAscent;
            short etmLowerCaseDescent;
            short etmSlant;
            short etmSuperScript;
            short etmSubScript;
            short etmSuperScriptSize;
            short etmSubScriptSize;
            short etmUnderlineOffset;
            short etmUnderlineWidth;
            short etmDoubleUpperUnderlineOffset;
            short etmDoubleLowerUnderlineOffset;
            short etmDoubleUpperUnderlineWidth;
            short etmDoubleLowerUnderlineWidth;
            short etmStrikeOutOffset;
            short etmStrikeOutWidth;
            WORD etmNKernPairs;
            WORD etmNKernTracks;
}
ETM, FAR *LPETM;

//This structure is an enigma.  Nobody seems to use it
//so why is it here...My hypothesis is that is is a remnant
//from a much more complicated time in a galaxy far, far away...
//...no seriously it probably has ties to the old EXTTEXTOUT
//escape that has been superseded by the ExtTextOut() OEM function
//
// The DDK uses this structure in defining EXTTEXTDATA but does not describe
//  it anywhere - [ShyamV] - 9/6/93

typedef struct _APPEXTTEXTDATA
{
            short   x;
            short   y;
            int     count;
            RECT    ClipRect;
            LPSTR   lpStr;
            short   far *lpWidths;
}
APPEXTTEXTDATA, FAR *LPAPPEXTTEXTDATA;

//the EXTTEXTDATA structure is goofy, the second entry (lpInData) takes
//on a variety of meanings depending on the escape.  I believe
//that GDI takes the data from the application and generates
//this bastard structure so that text escapes can be insured
//that whatever data they might need, they'll be able to get
//...sometimes the APPEXTTEXTDATA is referenced by the lpInData
//entry.
//
typedef struct _EXTTEXTDATA
{
            short sSize;
            LPAPPEXTTEXTDATA lpInData;    // see 3.1 DDK, page 471
            LPFONTINFO lpFontInfo;
            LPTEXTXFORM lpXForm;
            LPDRAWMODE lpDrawMode;
}
EXTTEXTDATA, FAR *LPEXTTEXTDATA;

//  ORIENT structure.
//     This structure specifies a paper orientation.
//
//     member Orientation is either DMORIENT_PORTRAIT or DMORIENT_LANDSCAPE.
//
typedef struct
{
      SHORT     Orientation;
      SHORT     Reserved1;
      SHORT     Reserved2;
      SHORT     Reserved3;
      SHORT     Reserved4;
} ORIENT, FAR *LPORIENT;

//the extra font stuff that is needed by the driver that
//will be in the FONTINFO structure below the 2nd line
//
typedef struct _FONTEXTRA
{
            SHORT   sPSxScale       ;  // The PS x scale factor for this font instance
            SHORT   sPSyScale       ;  // The PS y scale factor for this font instance
            SHORT   sOrientation    ;  // The character orientation
            SHORT   sEscapement     ;  // The angle a line of text makes wrt. horizontal
            SHORT   sFontid         ;  // The PI dependent font id
            DWORD   dwMSFace       ;  // Windows FaceName
            DWORD   dwPSFace       ;  // PostScript FaceName
            DWORD   dwDevice       ;  // "PostScript"
            DWORD  dwWidths       ;  // A pointer to the character widths table
                                                         //  was LPSHORT from PS.H. Changed to WINDOWS.H def.
            DWORD    dwTrackKern     ;  // A pointer to the track kern table
            DWORD    dwPairKern      ;  // A pointer to the pair kern table
            DWORD    dwExtTextMetrics;  // A pointer to the ExtTextMetrics table
            DWORD   dwSoftFont      ;  //The size of the softfont
                                       //if no outline or has been d/led dwSoftfont =0
            BOOL    fTategaki       ;  // true => vertical writing
            short   psAvgWidth      ;  // unscaled average width
            short   lpdWidths[0]  ;  // unscaled widths
}
FONTEXTRA, FAR *LPFONTEXTRA; 


/* PSSCALABLEFONTINFO    struc                ;*/ typedef     struct  {        /*
  erType     dw       0 ; Type field for the font.        ;*/ short int   erType;          /*
  erPoints      dw       0 ; Point size of font.             ;*/ short int   erPoints;        /*
  erVertRes     dw       0 ; Vertical digitization.          ;*/ short int   erVertRes;          /*
  erHorizRes       dw       0 ; Horizontal digitization.        ;*/ short int   erHorizRes;        /*
  erAscent      dw       0 ; Baseline offset from char cell top.      ;*/ short int   erAscent;        /*
  erInternalLeading dw      0 ; Internal leading included in font     ;*/ short int   erInternalLeading; /*
  erExternalLeading dw      0 ; Prefered extra space between lines       ;*/ short int   erExternalLeading; /*
  erItalic      db       0 ; Flag specifying if italic.         ;*/ BYTE       erItalic;         /*
  erUnderline      db       0 ; Flag specifying if underlined.     ;*/ BYTE       erUnderline;       /*
  erStrikeOut      db       0 ; Flag specifying if struck out.     ;*/ BYTE       erStrikeOut;       /*
  erWeight      dw       0 ; Weight of font.           ;*/ short int   erWeight;        /*
  erCharSet     db       0 ; Character set of font.          ;*/ BYTE       erCharSet;        /*
  erPixWidth       dw       0 ; Width field for the font.          ;*/ short int   erPixWidth;        /*
  erPixHeight      dw       0 ; Height field for the font.         ;*/ short int   erPixHeight;       /*
  erPitchAndFamily  db      0 ; Flag specifying pitch and family.     ;*/ BYTE       erPitchAndFamily;  /*
  erAvgWidth       dw       0 ; Average character width.        ;*/ short int   erAvgWidth;        /*
  erMaxWidth       dw       0 ; Maximum character width.        ;*/ short int   erMaxWidth;        /*
  erFirstChar      db       0 ; First character in the font.          ;*/ BYTE       erFirstChar;       /*
  erLastChar       db       0 ; Last character in the font.        ;*/ BYTE       erLastChar;        /*
  erDefaultChar     db      0 ; Default character for out of range.      ;*/ BYTE       erDefaultChar;     /*
  erBreakChar      db       0 ; Character to define wordbreaks.       ;*/ BYTE       erBreakChar;       /*
  erWidthBytes     dw       0 ; Number of bytes in each row.          ;*/ short int   erWidthBytes;      /*
  erDevice      dd       0 ; Offset to device name.          ;*/ unsigned long int   erDevice;  /*
  erFace     dd       0 ; Offset to face name.            ;*/ unsigned long int   erFace;    /*
  erBitsPointer     dd      0 ; Bits pointer.             ;*/ unsigned long int   erBitsPointer;/*
  erBitsOffset     dd       0 ; Offset to the begining of the bitmap.     ;*/ unsigned long int   erBitsOffset;/*
  erFlags       db       0 ; flags, and word align the stuff to come   ;*/ BYTE erReservedByte;    /*
  erUnderlinePos    dw      0 ; underline position relative to cell origin ;*/ short int   erUnderlinePos;  /*
  erUnderlineThick  dw      0 ; underline thickness              ;*/ short int   erUnderlineThick;/*
  erStrikeoutPos    dw      0 ; Strikeout position relative to cell origin ;*/ short int   erStrikeoutPos;  /*
  erStrikeoutThick  dw      0 ; strikeout thickness              ;*/ short int   erStrikeoutThick;/*
  erEFontIndex      dw      0   ; Index into FE data base to entry for thefnt;*/   short      erEFontIndex;     /*
  erEM              dw      0   ; Notional size of EM.                       ;*/   short      erEM;             /*
  erSpotSizeX       dd      0   ; 16.16 number defining spot size of device  ;*/   long       erSpotSizeX;      /*
  erSpotSizeY       dd      0   ;  WRT unity pel                             ;*/   long       erSpotSizeY;      /*
  erEscapement     dw       0 ; Escapement of font.              ;*/   short      erEscapement; /*
  erScaleX      dw       0 ; Scale factor along escapement vector      ;*/   short      erScaleX;  /*
  erHeightEM        dw      0   ; Height of the EM in device units.          ;*/   short      erHeightEM;       /*
  erCharBias        dw      0   ; Amount to add to any char when rasterizing.;*/   short      erCharBias;       /*
  erhFontFile       dd      0   ; Handle to engine font file.                ;*/   long       erhFontFile;      /*
  erhPFont          dw      0   ; Handle to actual physical font.            ;*/   short      erhPFont;         /*
  erTempOffset      dw      0   ; Offset to scratch area where bmp is loaded.;*/   short      erTempOffset;     /*
  erTempBufferSize  dw      0   ; Size of that buffer.                       ;*/   short      erTempBufferSize; /*
  erWidthTable      dw      0   ; Table of character increments (widths).    ;*/   short      erWidthTable;     /*
  erACTable         dw      0   ; Offset to table of A and C spaces of glyphs;*/   short      erACTable;        /*
  erSizePFont       dd      0   ; Size of physical font object.              ;*/   long       erSizePFont;      /*
  erBlockSizeInc    dd      0   ; Amount by which to increment glyph cache me;*/   long       erBlockSizeInc;   /*
  erCurrOffset      dd      0   ; Offset to next character's bitmap.         ;*/   long       erCurrOffset;     /*
  erFreeSize        dd      0   ; Size of available space for glyphs in cache;*/   long       erFreeSize;       /*
PSSCALABLEFONTINFO    ends                    ;*/ } PSSCALABLEFONTINFO;        
PSSCALABLEFONTINFO   FAR *LPPSSCALABLEFONTINFO;


///////////////////////////////////////////////////////////////////////////
//      ------------------ Pulled out of WINDOWS.H ----------------------
//
// These should possibly be in GDIDEFS.INC since it contains other GDI Logical
//  Object structure definitions such as LOGBRUSH, LOGFONT etc. PRINT.H forces
//  NOGDIOBJ when #including WINDOWS.H. GDIDEFS.INC, WINDOWS.H and PRINT.H have
//  to be made more robust at which time we can remove these things from here.

/* Structure passed to FONTENUMPROC */
/* NOTE: NEWTEXTMETRIC is the same as TEXTMETRIC plus 4 new fields */
typedef struct tagNEWTEXTMETRIC
{
      int     tmHeight;
      int     tmAscent;
      int     tmDescent;
      int     tmInternalLeading;
      int     tmExternalLeading;
      int     tmAveCharWidth;
      int     tmMaxCharWidth;
      int     tmWeight;
      BYTE    tmItalic;
      BYTE    tmUnderlined;
      BYTE    tmStruckOut;
      BYTE    tmFirstChar;
      BYTE    tmLastChar;
      BYTE    tmDefaultChar;
      BYTE    tmBreakChar;
      BYTE    tmPitchAndFamily;
      BYTE    tmCharSet;
      int     tmOverhang;
      int     tmDigitizedAspectX;
      int     tmDigitizedAspectY;
      DWORD   ntmFlags;
      UINT    ntmSizeEM;
      UINT    ntmCellHeight;
      UINT    ntmAvgWidth;
} NEWTEXTMETRIC;
typedef NEWTEXTMETRIC*       PNEWTEXTMETRIC;
typedef NEWTEXTMETRIC NEAR* NPNEWTEXTMETRIC;
typedef NEWTEXTMETRIC FAR*  LPNEWTEXTMETRIC;

#define LF_FULLFACESIZE     64
#define LF_FACESIZE     32
#define TRUETYPE_FONTTYPE   0x0004

/* Structure passed to FONTENUMPROC */
typedef struct tagENUMLOGFONT
{
      LOGFONT elfLogFont;
      char    elfFullName[LF_FULLFACESIZE];
      char    elfStyle[LF_FACESIZE];
} ENUMLOGFONT, FAR* LPENUMLOGFONT;


typedef struct 
    {
    DWORD   lStructSize;
    LPSTR   lpOutString;
    UINT FAR *lpOrder;
    int FAR  *lpDx;
    int FAR  *lpCaretPos; 
    LPSTR     lpClass;
    UINT FAR *lpGlyphs;
    UINT    nGlyphs;    
    int     nMaxFit;
    } GCP_RESULTS, FAR* LPGCP_RESULTS;

DWORD WINAPI GetFontLanguageInfo( HDC );
DWORD WINAPI GetCharacterPlacement(HDC, LPCSTR, int, int, LPGCP_RESULTS, DWORD);


//      ------------------ Pulled out of WINDOWS.H ----------------------
///////////////////////////////////////////////////////////////////////////

//ANG 6/6/96 Foregign language charset defs were
//omitted by Microsoft from GDIDEFS.INC .  It is however in windows.h
//
#define GREEK_CHARSET        161
#define TURKISH_CHARSET      162
#define HEBREW_CHARSET       177
#define ARABIC_CHARSET       178
#define BALTIC_CHARSET      186
#define RUSSIAN_CHARSET      204
#define THAI_CHARSET             222
#define EASTEUROPE_CHARSET   238
#define OEM_CHARSET         255


/* Support for tracing Alloc & Free */
#ifdef PS_MEMTRACE 
extern void    FAR PASCAL MemCheckStart(void);
extern void    FAR PASCAL MemCheckEnable(void);
extern void    FAR PASCAL MemCheckDisable(void);
extern void    FAR PASCAL MemCheckEnd(void);
extern HGLOBAL FAR PASCAL MemCheckGlobalAlloc(UINT, DWORD, LPSTR, int);
extern HGLOBAL FAR PASCAL MemCheckGlobalFree(HGLOBAL, LPSTR, int);

#define GlobalAlloc(a, b)  MemCheckGlobalAlloc((a), (b), (LPSTR) __FILE__, \
                                               __LINE__)
#define GlobalFree(a)      MemCheckGlobalFree((a), (LPSTR) __FILE__, __LINE__)

#define INIT_MEMTRACE()    MemCheckStart()
#define END_MEMTRACE()     MemCheckEnd()

#else
#define INIT_MEMTRACE()
#define END_MEMTRACE()
#endif


/* Support for Profiling */
#if (defined(PS_PROFILE) || defined(STATPROF))
#include "ps_debug.h"

typedef struct tagPROFREC {
    char  szStr[32];
    DWORD time;
    DWORD start;
    DWORD nCalls;
} PROFREC, FAR* LPPROFREC;

#define MAXPROFRECORDS 150

#define INIT_PROFILE()         InitProfile()
#define END_PROFILE()          EndProfile()

extern LPPROFREC PsProfile;
extern BOOL    bInitStat;
extern BOOL    bStatRunning;

extern void FAR PASCAL InitProfile();
extern void FAR PASCAL EndProfile();

#ifdef STATPROF
extern void  StartElapsed(void);
extern DWORD ReadElapsed(void);

#define START_PROFILE(str, i)   { if (PsProfile) { \
                                    LPPROFREC lpProf = &PsProfile[(int)(i)]; \
                                    if (! lpProf->nCalls) \
                                      lstrcpy(lpProf->szStr, (str)); \
                                    if (! bStatRunning) { \
                                        bStatRunning = TRUE; \
                                        StartElapsed(); \
                                    } \
                                    lpProf->start = ReadElapsed(); \
                                    lpProf->nCalls++; \
                                 } \
                                }

#define STOP_PROFILE(i)         { if (PsProfile) { \
                                    LPPROFREC lpProf = &PsProfile[(int)(i)]; \
                                    if (lpProf->szStr[0]) \
                                      lpProf->time += ReadElapsed() - \
                                        lpProf->start; \
                                  } \
                                }
#else
#define START_PROFILE(str, i)   { if (PsProfile) { \
                                    LPPROFREC lpProf = &PsProfile[(int)(i)]; \
                                    if (! lpProf->nCalls) \
                                      lstrcpy(lpProf->szStr, (str)); \
                                    lpProf->start = GetTickCount(); \
                                    lpProf->nCalls++; \
                                  } \
                                }

#define STOP_PROFILE(i)         { if (PsProfile) { \
                                    PsProfile[(int)(i)].time += \
                                      GetTickCount() - \
                                      PsProfile[(int)(i)].start; \
                                  } \
                                }
#endif
#else
#define INIT_PROFILE()
#define END_PROFILE()
#define START_PROFILE(str, i)
#define STOP_PROFILE(i)
#endif

/*--------------------------------------------------------------------*
 *  Macros to remove GlobalLock() and GlobalUnlock() calls
 *--------------------------------------------------------------------*/
#define GlobalLock(h)              (MAKELP((h), 0))
#define GlobalUnlock(h)

#ifdef GlobalAllocPtr
#undef GlobalAllocPtr
#endif
#define GlobalAllocPtr(flags, cb)  (MAKELP(GlobalAlloc((flags), (cb)), 0))

#ifdef GlobalFreePtr
#undef GlobalFreePtr
#endif
#define GlobalFreePtr(ptr)         (GlobalFree(SELECTOROF((ptr))))

#ifdef GlobalReAllocPtr
#undef GlobalReAllocPtr
#endif
#define GlobalReAllocPtr(ptr, cb, flags) \
                     (GlobalLock(GlobalReAlloc(SELECTOROF(ptr), (cb), (flags))))


/*--------------------------------------------------------------------*
 *  Macros to replace the MGxxxx() memory allocation/freeing wrappers *
 *--------------------------------------------------------------------*/
#define MGAlloc(lppd, cb, wF, jF)            ((HANDLE) GlobalAlloc((wF), (cb)))
#define MGLock(lppd, hdl, jF)                ((LPSTR) GlobalLock((hdl)))
#define MGAllocLock(lppd, lpHdl, cb, wF, jF)  \
                 ((LPSTR) GlobalLock(*(lpHdl) = GlobalAlloc((wF), (cb))))
#define MGReAlloc(lppd, hdl, cb, wF, jF)     ((HANDLE) (hdl) == NULL ? \
                                              GlobalAlloc((wF), (cb)) : \
                                              GlobalReAlloc((hdl), (cb), (wF)))
#define MGFree(lppd, hdl, jF)                ((HANDLE) GlobalFree((hdl)))
#define MGUnlock(hdl)                        
#define MGUnlockFree(lppd, hdl, jF)          ((HANDLE) GlobalFree((hdl)))


/*--------------------------------------------------------------------*
 *               Some common external declarations                    *
 *--------------------------------------------------------------------*/
extern void FAR PASCAL MemCopy(LPVOID, LPVOID, DWORD);      /* _fmemcpy */
extern void FAR PASCAL MemSet(LPVOID, int, DWORD);          /* _fmemset */
extern BOOL FAR PASCAL MemComp(LPVOID, LPVOID, DWORD);      /* _fmemcmp */

extern int FAR PASCAL lstrcmpn(LPSTR, LPSTR, WORD);
extern LPSTR FAR PASCAL lstrchr(LPSTR, int);
extern LPSTR FAR PASCAL lstrrchr(LPSTR , int);


//              ----------- Pulled out of WINDOWS.H ----------  
//
// PRINT.H defines NOGDIOBJ before including WINDOWS.H, thereby disabling these
// protos. We can remove these when PRINT.H and GDIDEFS.INC are made more robust.

BOOL    WINAPI GetTextMetrics(HDC, TEXTMETRIC FAR*);

BOOL    WINAPI DeleteObject(HGDIOBJ);
HGDIOBJ WINAPI SelectObject(HDC, HGDIOBJ);
HFONT   WINAPI CreateFontIndirect(const LOGFONT FAR*);
int     WINAPI GetTextFace(HDC, int, LPSTR);

DWORD FAR PASCAL GetFontData(HDC, DWORD, DWORD, void FAR *, DWORD);

typedef int (CALLBACK* FONTENUMPROC)(const ENUMLOGFONT FAR*, const NEWTEXTMETRIC FAR*, int, LPARAM);
int     WINAPI EnumFontFamilies(HDC, LPCSTR, FONTENUMPROC, LPARAM);

///////////////////////////////////////////////////////////////////////////

