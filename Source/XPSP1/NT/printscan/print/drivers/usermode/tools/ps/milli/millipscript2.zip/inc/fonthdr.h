#ifndef _FONTHDR_H
#define _FONTHDR_H

#define LIMIT_64K           0x10000
#define PS_FILE_PATH_LENGTH MAX_PATH
#define MFD_VERSION         0x040A  /* Dec = 0410 */

#define MAX_DEVICE_NAME     128
#define MAX_NAME_LEN        32
#define MAX_PS_NAME_LEN     127
#define MAX_MFD            3
#define CACHE_LIMIT         3

#define POINTS10            10
#define POINTS_PER_INCH     72

#define DEF_RESOLUTION      300   /* Resolution at which FontInfo is 
                                     cached in MFD files */

#define RC_OK               1
#define RC_ERROR            0

#define FONT_NOHINT         0xffff


//bit 0 to 3 determines outline availblity
//0  no outline
#define  SINGLE_MASTER        0x0001   //bit 0 = 1 single master
#define  MM_INSTANCE          0x0002   //bit 1 = 1 MM Instance, master not resident on printer
#define  FAUX                 0x0004   //bit 2 = 1 Faux, master not resident on printer
#define  MASK_FONT_TYPE       0x0007

#define  FONT_ON_DEVICE       0x0008   //bit 3 = 1 if master on device.
#define  MASK_FONT_DL         0x0008

//bit 4 determines enumeration status
//bit 5 determines realize status
#define ENUM_RLZE_NOT_VISIBLE 0x0000 //bit 4&5 = 0 if invisible
#define ENUM_RLZE_VISIBLE     0x0030 //bit 4&5 = 1 if visible
#define RLZE_VISIBLE          0x0020 //bit 5 = 0 if realize not visible
#define MASK_FONT_VISIBILTY   0x0030 //bit 4 and 5

//bit 6 determines font type  0=PS, 1=TT
//bit 7 determines resident/downloaded type 1=GI and 0=CC capable, 
#define PS_FONT               0x0000 //bit 6 = 0 PS font
#define TT_FONT               0x0040 //bit 6 = 1 TT font
#define MASK_PS_TT            0x0040 //bit 6

#define GI_CC                 0x0080 //7=1  -> GI & CC capable
#define CC_ONLY               0x0000 //7=0  -> CC capable only
#define MASK_FONT_MODE        0x0080 //bit 7

#define DIR_TO_DATA(lpFDir, hpFData)   ((LPFONTDATA) ((BYTE _huge*) hpFData + \
                                                     lpFDir->dwOffset))
#define STRREF_TO_PTR(strheap, strref) ((LPSTR) (strref.w.length == 0 ? "" : \
                                           (LPBYTE) strheap + strref.w.offset))
#define ARRREF_TO_PTR(arrheap, arrref) \
                                 ((LPVOID) ((LPBYTE) arrheap + arrref.w.offset))
#define INDEX_TO_DIR(hpDIndex, hpFDirs) ((HPFONTDIRECTORY) ((HPFONTDIRECTORY) hpFDirs[hpDIndex->wDirIndex]) + hpDIndex->wDirRecIndex)
#define INDEX_TO_METRIC(hpDIndex, hpFPrologs) ((HPPFMPROLOG) ((HPPFMPROLOG) hpFPrologs[hpDIndex->wDirIndex]))
#define DIR_TO_METRIC(hpFDir, hpFPrologHead)   ((HPPFMPROLOG) ((BYTE _huge*) hpFPrologHead + \
                                                     hpFDir->dwMetricOffset))

#define INDEX_TO_DATA(lpITable, hpFDir) ((LPFONTMETRIC) (lpITable->lpIHdr->lpFontData[lpITable->lpIDir->wDirIndex] + \
                              (lpITable->lpIDir->wDirRecIndex + hpFDir->dwOffset))

#define BUMPFAR(x,y)  (((LP)(x))+(y))

typedef void _huge* HPVOID;

/* PFM file structure */

typedef struct tagPFMPROLOG {
    WORD  dfVersion;
    DWORD dfSize;
    char  dfCopyRight[60];
} PFMPROLOG, FAR* LPPFMPROLOG, _huge* HPPFMPROLOG;

typedef struct tagPFMHEADER {
    WORD  dfType;
    WORD  dfPoints;
    WORD  dfVertRes;
    WORD  dfHorizRes;
    WORD  dfAscent;
    WORD  dfInternalLeading;
    WORD  dfExternalLeading;
    BYTE  dfItalic;
    BYTE  dfUnderline;
    BYTE  dfStrikeOut;
    WORD  dfWeight;
    BYTE  dfCharSet;
    WORD  dfPixWidth;
    WORD  dfPixHeight;
    BYTE  dfPitchAndFamily;
    WORD  dfAvgWidth;
    WORD  dfMaxWidth;
    BYTE  dfFirstChar;
    BYTE  dfLastChar;
    BYTE  dfDefaultChar;
    BYTE  dfBreakChar;
    WORD  dfWIdthBytes;
    DWORD dfDevice;
    DWORD dfFace;
    DWORD dfBitsPointer;
    DWORD dfBitsOffset;
} PFMHEADER, FAR* LPPFMHEADER, _huge* HPPFMHEADER;

typedef struct tagPFMEXTENSION {
    WORD  dfSizeFields;
    DWORD dfExtMetricsOffset;
    DWORD dfExtentTable;
    DWORD dfOriginTable;
    DWORD dfPairKernTable;
    DWORD dfTrackKernTable;
    DWORD dfDriverInfo;
    DWORD dfReserved;
} PFMEXTENSION, FAR* LPPFMEXTENSION;

typedef struct tagPFM {
    PFMPROLOG     prolog;
    PFMHEADER     hdr;
    PFMEXTENSION  ext;
} PFM, FAR* LPPFM;


/* 
 * Structure of the mfd files:
 *  |-----------------|
 *  |     FILEHDR     |
 *  |-----------------|
 *  |  FONTDIR table  |
 *  |-----------------|
 *  | list of FONTDATA|
 *  |     records     |
 *  |-----------------|
 *
 * The number of elements in the FONTDIR table is equal to the number of fonts 
 * in the file. Each FONTDATA record specifies one font. 
 */

typedef struct tagFILEHDR {
    WORD    wCrcVal;          /* CRC to check if file is valid */
    DWORD   dwPSFRSerialNo; /*Serial number of Postscript Registry*/
    DWORD   dwTTFRSerialNo; /*Serial number from TrueType Registry*/
    DWORD   dwMFMTimeStamp; /*MFM Time Stamp at Drv load time*/
    WORD    wVersionNumber;   /* Version number of driver that created file */
    WORD    wNumFonts;        /* Number of fonts in this file */
    DWORD   dwTotalFontSize;  /* Total bytes of all font metric in this file*/
} FILEHDR, FAR* LPFILEHDR;

/* 
 * This is the font directory that gives the offset into the fontdata block for 
 * the beginning of the i'th fontdata record. 
 */
typedef struct tagDIR {
   char  szFontName[MAX_PS_NAME_LEN];  /* e.g. "Courier-Bold" */
      /* szFontName is retrieve from PFMHEADER.dfFace */
      /* use by findfont */
   char  szFaceName[MAX_NAME_LEN];  /* e.g. "Courier Bold"*/
      /* szFaceName is retrieve from PFMEXTENSION.dfDriverInfo */
      /* use to display in Windows's menu */
   WORD  index;                  /*i'th font in directory*/
   TEXTMETRIC  defTextMetric;    /* Text metrics cached for performance */
   WORD     xRes;                /* Resolution at which TextMetric ... */
   WORD     yRes;                /* ... is cached */
   BYTE     underline;           /* can be different from TextMetric */
   BYTE     strikeout;           /* can be different from TextMetric */
   DWORD    dwMetricVersion;     /* versions # from PFM or TTF */
   DWORD    dwMetricOffset;      /* offset to Metric Data, 0 = TTFont*/
   DWORD    dwMetricSize;        /* size of Metric portion */
   DWORD    dwFauxMetricSize;    /* offset to Faux metric data */
   DWORD    dwOutlineSize;       /* size of Single Master outline to down load */
   WORD     wMMBIndex;           /* index to Directory for a MMBase font*/
   BYTE     bCIDFont;            /* 1 to indicat it's a cid font*/      
   BYTE     pfmSource;           /* PFM_FROM_REGISTRY = 0, PFM_FROM_ADFONTS_MFM = 1, PFM_FROM_OEM_MFM = 2*/
   BYTE     bOutlnAvail;          /* types of outline available for down load*/
   char     reserved[256-MAX_NAME_LEN-MAX_PS_NAME_LEN-31-33]; 
   // make sizeof(FONTDIR)=256
   // 31 bytes in Text Metrics,  
   // 33 bytes inside FONTDIRECTORY not including psname and family name
} FONTDIRECTORY, FAR* LPFONTDIRECTORY,  _huge* HPFONTDIRECTORY;


typedef struct tagDIRINDEXHDR {
   DWORD   dwResFontsSerialNo;        /* Serial number from Resident font*/
   DWORD   dwMFD0TimeStamp;
   DWORD   dwPSFRSerialNo; /*Serial number of Postscript Registry*/
   DWORD   dwTTFRSerialNo; /*Serial number from TrueType Registry*/
   DWORD   dwSecondPSFRSerialNo; /*Second Serial number of Postscript Registry*/
   DWORD   dwSecondTTFRSerialNo; /*Second Serial number from TrueType Registry*/
   WORD    wVersionNumber; /* Version number of driver that created file */
   WORD    wTotalFonts;      /* Number of fonts in this file */
   WORD    wFriendlyNameLen;     /* Length of Friendly name (includes '\0') */
} DIRINDEXHDR, FAR* LPDIRINDEXHDR, _huge* HPDIRINDEXHDR;

typedef struct tagDIRINDEX {
   BYTE  wDirIndex;        /* Index to lpFontDir in DIRINDEXHDR */
   WORD  wDirRecIndex;     /* Index into the appropriate FontDirectory */
   BYTE  statusFlag;       /* Status of D/L'ed, D/L'able & Enum*/
} DIRINDEX, FAR* LPDIRINDEX, _huge* HPDIRINDEX;

typedef struct tagFONTCACHE {
   char    szFriendlyName[MAX_DEVICE_NAME];
   WORD    wNumFonts;  /* Number of fonts in FontData */
   DWORD   dwResFontsSerialNo;        /* Serial number from Resident font*/
   DWORD   dwMFD0TimeStamp;          /* we assume there is one FONTSDir.MFD*/
                                      /* change this to a vector, if more*/ 
   DWORD   dwPSFRSerialNo; /*Serial number of Postscript Registry*/
   DWORD   dwTTFRSerialNo; /*Serial number from TrueType Registry*/
   DWORD   dwSecondPSFRSerialNo; /*Second Serial number of Postscript Registry*/
   DWORD   dwSecondTTFRSerialNo; /*Second Serial number from TrueType Registry*/

    /* These are internal to font caching scheme */
    HPDIRINDEX  hpDirIndex;
    HPFONTDIRECTORY  FAR *hpFontDirs;
    HPPFMPROLOG   FAR *hpPFMPrologs;//Pointer to Metric Data

    WORD            wUseCount;  /* To decide whether to delete entry */
    BOOL            bDelete;    /* If true, delete entry when wUseCount
                                  goes to 0. */
    struct tagFONTCACHE FAR* lpNextCache; /* To have a list of cache records */

} FONTCACHE, FAR* LPFONTCACHE, _huge* HPFONTCACHE;

typedef struct tagFONTDIRCACHE{

   //Font Directory structures FontRecord of FontsFDB.MFD or FontsDir.MFD
   DWORD   dwPSFRSerialNo; /*Serial number of Postscript Registry*/
   DWORD   dwTTFRSerialNo; /*Serial number from TrueType Registry*/
   DWORD   dwMFMTimeStamp; /*MFM Time Stamp at Drv load time*/
   
   WORD     wTotalNumFonts;
   HPFONTDIRECTORY  hpFontDirTab[MAX_MFD];
   HPPFMPROLOG      hpPFMProlog[MAX_MFD];//Pointer to Metric Data
   WORD             wNumFonts[MAX_MFD];
   DWORD            dwTimeStamp[MAX_MFD];

   struct tagFONTDIRCACHE FAR* lpNextCache; /* To have a list of cache records */

} FONTDIRCACHE, FAR* LPFONTDIRCACHE, _huge* HPFONTDIRCACHE;
typedef struct tagCACHEHDR {
   //List of Fonts/IndexTables structures
   LPFONTCACHE       lpCacheStart;  
   LPFONTCACHE       lpCacheEnd;
   WORD              wNumFontCached;

   LPFONTDIRCACHE    lpFontDirCurrent; //current is beginning of list.
   LPFONTDIRCACHE    lpFontDirEnd;
   WORD              wNumFontDir;
   
} CACHEHDR, FAR* LPCACHEHDR;

/* Structure to pass to function to create MFD file */
#define PFMPFB    0
#define SFNT      1
#define TrueType  2

typedef struct tagRESIDENTFONT
{
   LPSTR  lpFontName;
   LPSTR  lpValue;   
   BYTE   propertyFlag;
} RESIDENTFONT, FAR* LPRESIDENTFONT, _huge* HPRESIDENTFONT;

/* Structure to pass to function to create MFD file */
typedef struct tagPFMFILE {
    char szPFMName[PS_FILE_PATH_LENGTH]; /* Full path name */
    char szPFBName[PS_FILE_PATH_LENGTH]; /* Full path name */
    WORD wAddedByOther;   /* 1: if this PFB is added by MergeOtherSoftFonts() */
} PFMFILE, FAR* LPPFMFILE, _huge* HPPFMFILE;

/* Structure of mfm file header */
typedef struct tagMFMHDR {
    char szMagic[80];
    WORD wVersion;
    WORD wNumPFMBlocks;
} MFMHDR, FAR* LPMFMHDR;

/* Structure for CRC calculation */
typedef struct tagCRCINFO {
    LPVOID lpBuffer;
    WORD   wNumber;
} CRCINFO, FAR* LPCRCINFO;

typedef enum {
    PS_FONTNAME,
    PS_FACENAME,
    PS_ALL,
} ENUMTYPE;

typedef struct serialNum {
   DWORD dwResFontsSerialNo;
   DWORD dwScndTTFRSerialNo;
   DWORD dwScndPSFRSerialNo;
} SERIALNUMS, FAR * LPSERIALNUMS;

#endif /* ifndef _FONTHDR_H */
