/*  GetPrinter() - loads WPX for specified printer model
   into 3 Global memory blocks, one for each section of the WPX
   data.  Writes address of each block into appropriate fields
   in WPXBLOCKS.  If successful return value is the ->WPXprintInfo  
   casted to  LPPRINTERINFO, else returns NULL and sets all 
   three pointers in lpdv to NULL.

   dmDeviceName points to a Caller-supplied buffer. GetPrinter
   will fill this in with the appropriate Alias/ModelName if
   successful.  Caller may pass NULL if this name is not needed.
   This is the name that should be stored in the devmode structure.
   And is also the section name used when saving to win.ini .
   This also becomes the name to be used when passing a ModelName 
   down to any subsequent function requiring a devmode ModelName.
   (as opposed to a PPD ModelName which is stored in WPXPrintInfo)

   Note: this function also handles the case "Postscript Printer"
   automatically without special casing!.
*/

#include "generic.h"

#pragma code_seg(_UTILSSEG)


typedef WORD (FAR PASCAL* OBTAINWPXPROC)(LPBYTE,LPBYTE,WORD,BOOL);

WORD  FAR  PASCAL  obtainWPXfile(
LPBYTE  lpModelName,
LPBYTE  lpFileName ,
WORD    Bufsize    ,  // size of lpFileName  (dest buffer)
BOOL    bNukeIndex );  // If true, force rebuild (delete WPX index)



static  LPWPXNODE  WPXcache = NULL;


BOOL FAR PASCAL FreeWPXblocks(LPWPXBLOCKS lpWpx)
{
   if(!lpWpx)
      return FALSE;

   if(lpWpx->WPXprinterInfo)
      GlobalFreePtr(lpWpx->WPXprinterInfo);
   if(lpWpx->WPXarrays)
      GlobalFreePtr(lpWpx->WPXarrays);
   if(lpWpx->WPXstrings)
      GlobalFreePtr(lpWpx->WPXstrings);
   if(lpWpx->WPXconstraints)
      GlobalFreePtr(lpWpx->WPXconstraints);

   lpWpx->WPXprinterInfo =
   lpWpx->WPXarrays   = 
   lpWpx->WPXstrings       = NULL ;
   lpWpx->WPXconstraints   = NULL ;

   return TRUE;
}



BOOL FAR PASCAL GetFileModTimes(
LPBYTE lpPPDFile,
LPDWORD lpdwTime)
{
   OFSTRUCT  ofFileStruct;
   HFILE     hFile;
   int       i;
#ifdef ADOBE_DRIVER   
   char      szDriverMod[MAX_PATH];
#endif
   
   i = 0;
   do 
   {
       if ((hFile = OpenFile((LPSTR) lpPPDFile, (LPOFSTRUCT) &ofFileStruct,
                             OF_READ)) == HFILE_ERROR)
       {
           /* No PPD file */
           return(FALSE);
       }
       else
       {
#ifdef _M_I86MM                                             /* medium model */
           _dos_getftime(hFile, 
                         (unsigned *) OFFSETOF((unsigned FAR*) &DateTime.date),
                         (unsigned *) OFFSETOF((unsigned FAR*) &DateTime.time));
#else
           _dos_getftime(hFile, &DateTime.date, &DateTime.time);
#endif
           _lclose(hFile);
           lpdwTime[i] = (DWORD)(*((LPDWORD)&DateTime));
       }
#ifdef ADOBE_DRIVER
       if (GetModuleFileName(ghDriverMod, szDriverMod, sizeof(szDriverMod)))
           lpPPDFile = szDriverMod;
       else return FALSE;
#else
       lpPPDFile = (LPBYTE)"pscript.drv";
#endif
   } while (++i < 2);
   return(TRUE);
}


BOOL NEAR PASCAL NeedNewWPXFile(
LPWPXBLOCKS lpWPXblocks, 
LPBYTE lpModelName)
{
   DWORD dwTemp[2];
   BYTE  IndexDir[_MAX_PATH], FileName[_MAX_PATH];

   GetWindowsDirectory(IndexDir, _MAX_PATH);
   if (!GetPPDFileName(lpModelName, FileName, _MAX_PATH, IndexDir))
   {
       /* No PPD file, can't recreate new WPX file anyway */
       return(FALSE);
   }
   if (!GetFileModTimes(FileName, (LPDWORD)&dwTemp))
       return(FALSE);

   if(((LPPRINTERINFO)lpWPXblocks->WPXprinterInfo)->dwPPDLMT != dwTemp[0] ||
      ((LPPRINTERINFO)lpWPXblocks->WPXprinterInfo)->dwDrvrLMT != dwTemp[1])
       return(TRUE);
   else
       return(FALSE);
}

/*  this function either finds the requested printer or fails  */

BOOL NEAR PASCAL GetThisPrinter(
LPWPXBLOCKS  lpWPXblocks ,   // caller supplies 
LPBYTE  lpModelName)  // caller supplies 
{
   BYTE  WPXfileName[_MAX_PATH];
   WPX_HEADER  wpxHeader;   // table of contents for wpx file.
   HFILE   hfile = HFILE_ERROR ;
   WORD    wDLLVersion;
   WORD    count;
   BOOL    bNukeIndex=FALSE;


   lpWPXblocks->WPXprinterInfo =
   lpWPXblocks->WPXarrays   = 
   lpWPXblocks->WPXstrings       =  NULL ;
   lpWPXblocks->WPXconstraints   = NULL ;


   if(!*lpModelName)
      goto GetPrinterFailed;

CallDLL:

#if 1
   {
      UINT          uOldErrorMode;

      // Fail silently if we can't load the DLL
      uOldErrorMode=SetErrorMode(SEM_NOOPENFILEERRORBOX);

      wDLLVersion=obtainWPXfile(lpModelName, WPXfileName, _MAX_PATH,
                                bNukeIndex);

      // Restore previous error mode
      SetErrorMode(uOldErrorMode);

   }
#else

   wDLLVersion = obtainWPXfile(lpModelName, WPXfileName, _MAX_PATH,
                                bNukeIndex);

#endif

   if(WPXVERSION != wDLLVersion)  // GETWPX.DLL is the wrong version--ouch!
      goto GetPrinterFailed;
   
   hfile = _lopen(WPXfileName, READ) ;
   if(hfile == HFILE_ERROR )
      goto  GetPrinterFailed ;

   count = sizeof(WPX_HEADER);

   if(count != _lread(hfile, &wpxHeader,  count))
      goto  GetPrinterFailed ;

   count = wpxHeader.PrinterInfo_len;
   lpWPXblocks->WPXprinterInfo = GlobalAllocPtr(GDLLHND, (long)count);
   count = wpxHeader.OptionArray_len;
   lpWPXblocks->WPXarrays = GlobalAllocPtr(GDLLHND, (long)count);
   count = wpxHeader.stringtab_len;
   lpWPXblocks->WPXstrings = GlobalAllocPtr(GDLLHND, (long)count);
   count = wpxHeader.UI_constraint_len;
   if(count)
      lpWPXblocks->WPXconstraints = 
               (LPUI_CONSTRAINTS)GlobalAllocPtr(GDLLHND, (long)count);
   else
      lpWPXblocks->WPXconstraints = NULL ;
      


   if(!(lpWPXblocks->WPXprinterInfo  &&  lpWPXblocks->WPXarrays
      &&  lpWPXblocks->WPXstrings  &&  
      (!wpxHeader.UI_constraint_len  || lpWPXblocks->WPXconstraints)  ))
      goto  GetPrinterFailed ;

   _llseek(hfile, wpxHeader.PrinterInfo_loc, SEEK_SET);   //  seek to pos byte

   count = wpxHeader.PrinterInfo_len;
   if(count != _lread(hfile,  lpWPXblocks->WPXprinterInfo, count))
      goto  GetPrinterFailed ;

   _llseek(hfile, wpxHeader.OptionArray_loc, SEEK_SET);   //  seek to pos byte

   count = wpxHeader.OptionArray_len;
   if(count != _lread(hfile,  lpWPXblocks->WPXarrays, count))
      goto  GetPrinterFailed ;

   _llseek(hfile, wpxHeader.stringtab_loc, SEEK_SET);   //  seek to pos byte

   count = wpxHeader.stringtab_len;
   if(count != _lread(hfile,  lpWPXblocks->WPXstrings, count))
      goto  GetPrinterFailed ;

   if(count = wpxHeader.UI_constraint_len)  // assignment intended
   {
      _llseek(hfile, wpxHeader.UI_constraint_loc, SEEK_SET);   //  seek to pos byte
      if(count != _lread(hfile,  (LPBYTE)lpWPXblocks->WPXconstraints, count))
         goto  GetPrinterFailed ;
   }
   // else nothing to read, no buffer to write to anyway.


   //  perform fontSummary elsewhere since its per printer instance

   _lclose(hfile);

   // Check if a new WPX file is needed based on last modified times on
   // pscript.drv and PPD file.
   if (NeedNewWPXFile(lpWPXblocks, lpModelName))
   {
      FreeWPXblocks(lpWPXblocks);
      CreateNewWPXFile(lpModelName, TRUE);
      goto CallDLL;
   }

   //  Check the version of this file--it it's an old version, tell
   //  obtainWPXfile to delete its index and re-parse this baby. Don't
   //  forget to free up the memory that we've allocated. There should
   //  never be a case where we get here and bIndex is TRUE, but adding
   //  the extra guard keeps us from going to never never land.
   if(WPXVERSION != ((LPPRINTERINFO)lpWPXblocks->WPXprinterInfo)->versionNum)
   {
      if(bNukeIndex)
         goto GetPrinterFailed;
      else
      {
         FreeWPXblocks(lpWPXblocks);
         bNukeIndex=TRUE;
         goto CallDLL;
      }
   }

   return(TRUE);

GetPrinterFailed:

   if(hfile != HFILE_ERROR)
      _lclose(hfile);

   FreeWPXblocks(lpWPXblocks) ;

   return(FALSE);
}



//---------------------------------*FreePrinter*----------------------------
// Action: Free the blocks associated with the passed in WPX pointer.
//
// Note:   Eventually, this will just decrement a lock count in the cache,
//         instead of actually freeing the memory.
//
// Return: TRUE if successful, FALSE if not
//--------------------------------------------------------------------------


BOOL FAR PASCAL FreePrinter(LPWPXBLOCKS lpWpx)
{
   //  decrement the RefCount!
   LPWPXNODE       curNode ;

   //  Search through cache 
   
   for(curNode = WPXcache  ; curNode ; curNode = curNode->NextNode)
   {
      //  attempt to match pointer
      if(&(curNode->WPXblock) == lpWpx)
      {
         if(curNode->RefCount)
         {
            curNode->RefCount-- ;
            return(TRUE);
         }
         return(FALSE);   //  Refcount already zero!!!
      }
   }
   return(FALSE);  //  never located specified printer!!!
}

//  special note: a cache is kept for each ModelName
//  Also note: Must assume ModelName is limited to a buffer of
//  size CCHDEVICENAME.

LPWPXBLOCKS  FAR PASCAL GetPrinter(
LPBYTE  lpModelName )
{
   LPWPXNODE       curNode , unusedNode;
   WORD            cunused ;

   //  Search through cache for matching node:
   
   unusedNode = NULL ;

   for(curNode = WPXcache , cunused = 0 ; curNode ; 
                           curNode = curNode->NextNode)
   {
      //  attempt to match modelname
      if(!lstrcmp(curNode->modelname , lpModelName))
      {
         if(!curNode->WPXblock.WPXprinterInfo)
            return(NULL);
         if(curNode->deleteWhenRefCountZero  &&  !curNode->RefCount)
         {
            unusedNode = curNode;   
            break;
         }
         curNode->RefCount++ ;
         return(&(curNode->WPXblock));
      }
      if(!curNode->RefCount)
      {
         if(++cunused >= 3)  //  use the 3rd unused node regardless!!!
            unusedNode = curNode;   
      }
   }

   if(unusedNode)
   {
      curNode =  unusedNode ;
      FreeWPXblocks(&(curNode->WPXblock)) ;
   }
   else     //  just tack on a new node.
   {
      curNode = (LPWPXNODE)GlobalAllocPtr(GDLLHND , sizeof(WPXNODE));
      if(!curNode)
         return(NULL);  // utter failure.
      curNode->NextNode = WPXcache ;
      WPXcache = curNode ;   //  insert new nodes at start of list.
   }

   lstrcpy(curNode->modelname , lpModelName);
   curNode->deleteWhenRefCountZero = FALSE ;
   curNode->RefCount = 0 ;

   if(GetThisPrinter(&(curNode->WPXblock), lpModelName))
   {
      curNode->RefCount = 1 ;  // activates WPX info cache.
      return(&(curNode->WPXblock));
   }

   return(NULL) ;
}


BOOL FAR PASCAL TerminateWPXcache()
{
   LPWPXNODE       curNode, nextNode ;

   for(curNode = WPXcache  ; curNode ; curNode = nextNode)
   {
      nextNode = curNode->NextNode ;
      FreeWPXblocks(&(curNode->WPXblock)) ;
      GlobalFreePtr(curNode);  // once this has occured, curNode
         //  is undefined.
   }

   WPXcache = NULL ;

   return (TRUE);
}


void FAR PASCAL SetWPXDeleteFlag(
LPSTR lpModelName )
{
   LPWPXNODE       curNode ;

   //  Search through cache for matching node:
   
   for(curNode = WPXcache ; curNode ; 
                           curNode = curNode->NextNode)
   {
      //  attempt to match modelname
      if(!lstrcmp(curNode->modelname , lpModelName))
      {
     curNode->deleteWhenRefCountZero = TRUE;
         break;
      }
   }
}




