/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: GRAPHICS.H                                             */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHGraphicsDlg(HWND hdlg, unsigned msg, 
                                      WORD wParam, LONG lParam);
void NEAR DIALOGSSEG PASCAL FillParametricComboBox(HWND hDlg, int idCombo, LONG lLowBound,
                            LONG lHighBound, LONG lIncrement,
                            LONG lInitialValue);
void FAR PASCAL RestoreGraphicsDefaults(LPPSEXTDEVMODE lpPSExtDevmode,
                                        LPWPXBLOCKS lpWPXBlock,
                                        DWORD dwUIFlags);
