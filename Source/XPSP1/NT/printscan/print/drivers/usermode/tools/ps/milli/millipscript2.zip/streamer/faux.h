/*
  faux.h

  Header file for the faux font code.

             Copyright (c) 1994 -- Adobe Systems Incorporated
    PostScript is a registered trademark of Adobe Systems Incorporated.

NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

*/

#ifndef _FAUX_H_
#define _FAUX_H_

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif
#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES

#define ADOBESANS       1
#define ADOBESERIF      2

#define MAX_GLYPHS	259

/**********************************************************************/
/* FauxVals */

typedef struct FauxValsRecord 
 { Card16 code;          /* Code for this 'thing' */
   Card16 argCount;      /* Number of elements in thing */
   Int16 data[1];       /* Data values */
 } FauxValsRecord, *FauxValsPointer;

/*
   The FauxVals table provides information necessary for 
   making a single master snap shot of a faux font using the MM chameleon 
   font.  It gives information which is only available to the font designer; 
   saying how each hint should be blended.
  
   There are two Op codes for every hint 'things' such as 'BLUE VALUES'.   
   One Op code tells us to use the values directly while the other means that 
   we should blend the values.  For example if we are blending BLUE VALUES 
   with an ArgCount of 6, then the data will be of the form:
  
      GI1 Val1-1 Val1-2 ... Val1-N, GI2 Val2-1 Val2-2 ... Val2-N, ...  
      GI6 Val6-1, Val6-2 ... Val6-N
  
   where GI1 means the GlyphIndex of the character whose DVT weight vector 
   should be used to blend Val1-1 through Val1-N where the font has N masters.
   (Obviously Data has (NumMasters + 1) * ArgCount values in the blended case.
  
   NOTE: FAUX_FORCE_BOLD_THRESHOLD is given an arg count of 2, because its 
   value is listed as 16.16 Fixed point number.  This is also true of 
   FAUX_BLUE_SHIFT... no blended version is currently provided.
  
   FAUX_BLUE_SCALE and FAUX_BLUE_SCALE_BLEND are given arguments that 
   correspond to the OverShoot Point size.  The value placed in the T1 data 
   is obtained by:

     (PtSize - .49) / 240
 */

#define  FAUX_BLUE_VALUES           0x00
#define  FAUX_BLUE_VALUES_BLEND     0x80
#define  FAUX_OTHER_BLUES           0x01
#define  FAUX_OTHER_BLUES_BLEND     0x81
#define  FAUX_STHW                  0x02
#define  FAUX_STHW_BLEND            0x82
#define  FAUX_STDVW                 0x03
#define  FAUX_STVW_BLEND            0x83
#define  FAUX_STEM_SNAP_H           0x04
#define  FAUX_STEM_SNAP_H_BLEND     0x84
#define  FAUX_STEM_SNAP_V           0x05
#define  FAUX_STEM_SNAP_V_BLEND     0x85
#define  FAUX_BLUE_SCALE            0x06
#define  FAUX_BLUE_SCALE_BLEND      0x86
#define  FAUX_BLUE_SHIFT            0x07
#define  FAUX_BLUE_FUZZ             0x08
#define  FAUX_BLUE_FUZZ_BLEND       0x88
#define  FAUX_FAMILY_BLUES          0x09
#define  FAUX_FAMILY_BLUES_BLEND    0x89
#define  FAUX_FAMILY_OTHER          0x0A
#define  FAUX_FAMILY_OTHER_BLEND    0x8A

/* Must be provided before FAUX_FORCE_BOLD_BLEND */
#define  FAUX_FORCE_BOLD_THRESHOLD  0x0B        

#define  FAUX_FORCE_BOLD            0x0C
#define  FAUX_FORCE_BOLD_BLEND      0x8C



/*************************************************************************/
/* FauxInfo */

typedef struct _FauxInfoRecord 
 { boolean  IsFixedPitch;            /* Is the font fixed pitch? */
   char     *FontName;               /* The PostScript font name */
   char     *FullName;	             /* The full PostScript name */
   char     *FamilyName;             /* The PostScript family name */
   Fixed    LowercaseScale;          /* XHeight matching scale */
   Int16    glyphCount;               /* Number of glyphs in faux font */
   Fixed    ItalicAngle;             /* Italic angle of target font */
   Fixed    UnderlinePos;            /* Underline position of target font */
   Fixed    UnderlineThickness;      /* Underline thickness of target font */
   Fixed    expand;                  /* Expansion factor */
   Fixed    condense;                /* Condense factor */
   Card8    MMToUse;                 /* Which MM font should be used to faux */
   Card16   fauxValsCount;           /* number of fauxVals entries */
 } FauxInfoRecord, *FauxInfoPointer;


/* Type for the GetFauxInfo callback.  This callback gets info about a
   specific glyph in the faux font.  The information is used to produce 
   the font dictionary information for the snapshotted faux font.  This
   callback returns true on success, false if the information could not
   be found.  Note that the index should be the standard encoding position
   for a character, or the character index (INDEX_IS_ENCODING or, 
   INDEX_IS_CHARINDEX). */

typedef IntX (*GetFauxInfoFunc) ARGDECL5(IntX, index, IntX, indexType, 
  char *, name, Fixed *, designVector, Card8 *, isLower);

/*************************************************************************

Function name:  SetFauxFont()

**************************************************************************

Date:           05/02/94
Author:         Ron Fischer (rff)
Prototype in:   faux.h
Summary:        Set faux font data in the FontRecord
Description:    Uses the fauxInfo structure and the fauxVals data to modify
                the FontRecord information.  On entry the FontRecord should
                contain the information for the MM chameleon font being
                used.  Upon successful completion the FontRecord will contain
                fields that pertain to the faux font to be substituted
                (the defaultVals field in particular is affected).  The
                fields set will allow the Streamer functions to produce a
                valid Type 1 font.

Parameters:     fp - the pointer to the FontRecord structure to modify
                fauxVals - the pointer to the faux font values data
                fauxInfo - the pointer to the faux font information struct

Return Values:  ST_NOERR if all is OK, one of the ST_ errors if a problem
                is encountered.
Notes:          Modifies data in the T1FontPointer it is given.
                It's the user's responsibility to get the fauxInfo and
                fauxVals information.  The faux info comes mostly from the
                faux database (although note that most of the values should
                be converted to fixed point).  The design vector information
                comes from the FontFit code.  The fauxVals info comes from
                small, special data files which contain information about
                the creation of font level hints.  See GetFauxData() in
                getfaux.c in the stream product to learn how to read in these
                files.
                Also note that you may want to change additional fields by
                hand.  For instance, if the faux font should have a special
                encoding you would want to change the standard encoding
                flag and the special encoding array.
See also:

**************************************************************************/


IntX SetFauxFont ARGDECL4(T1FontPointer, fp, FauxValsPointer, fauxVals,
              FauxInfoPointer, fauxInfo, GetFauxInfoFunc, GetFauxInfo);


#endif /* _FAUX_H_ */
