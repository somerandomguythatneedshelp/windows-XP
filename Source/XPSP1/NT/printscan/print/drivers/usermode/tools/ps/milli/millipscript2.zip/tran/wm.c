/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1994 Adobe Systems, Inc. All rights reserved.               */
/*                                                                           */
/* Module Name: WM.C                                                    */
/*                                                                           */
/* Description:This module contains functions for implementing watermark     */
/*		functionality in the 4.1 version.
/*****************************************************************************/

#include "generic.h"
#include <string.h>

// #pragma code_seg(_TSTARTSEG)
#pragma code_seg(_WATERMARKSEG)

#pragma check_stack (on)

#ifdef ADOBE_DRIVER
#define MAXWMTEXTLEN 256
#define MAX_RGB_COLOR  ((float)255.0)

#define DEFAULT_FONT  "Courier"

// locally used function.
int TSendWMFont(LPPDEVICE lppd, LPWM lpWaterMark);

int StringFontDownLoad(LPPDEVICE   lpdv, LPSTR   lpbSrc,   
	int cbSrc, LPPSFONTINFO  lpPsFontInfo, LPTEXTXFORM lpTextXForm);

int SendWaterMarkPSData(LPPDEVICE lppd, LPWM lpWaterMark, LPWATERMARK_FONT lpWMFont, int sendFontOnly);

int CALLBACK WaterMarkEnumAFont(LPENUMLOGFONT lpLogFont, LPNEWTEXTMETRIC lpTextMetric,
  int iFontType, LPARAM lParam);

short FAR PASCAL FillWater(LPPDEVICE lppd, LPWATERMARK_FONT lpWMFont, LPWM lpWaterMark);
short FAR PASCAL InitWaterMark(LPPDEVICE lppd);
short FAR PASCAL PSSendMySetup_Name(LPPDEVICE lppd, LPRECT lpRect, SHORT sSendType, BYTE bOrientation, 
     int mysetup_name);
short FAR PASCAL GetMySetupMatrix(LPPDEVICE lppd, LPRECT lpRect, SHORT sSendType,
BYTE bOrient, int LandscapeOrientation, LPPSMATRIX lpMatrix);
int FAR PASCAL ConvertToGI(LPLOGFONT lplf, LPSTR lpStr, LPWORD lpwGI, int count);

// Add a data structure so that we can pass Watermark infor to EnumWmAFont()
typedef struct _WMARK_LPPD
{
   LPPDEVICE         lppd;
   LPWATERMARK_FONT  lpWMFont;      // from lppd->lpWMark.wmFont/wmBaseFont
   LPWM              lpWaterMark;  // read from watermar.ini
}
WATERMARK_LPPD, FAR * LPWATERMARK_LPPD;


void TSendWMPdefn(LPPDEVICE lppd)
{
LPASCIIBINPTRS tempptr;
char szTmp[64];   // wsprintf uses

	if (lppd==NULL) return;
	tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
	// ???? Change to our dictionary ???....
	PSSendFragment(lppd,PSFRAG_watermark_0_L2); //"userdict /WaterMark_Adobe_Drv 7 dict dup begin put "
	PSSendFragment(lppd,PSFRAG_crlf);
	PSSendFragment(lppd,PSFRAG_watermark_1_L2); //"/FormType 1 def /Matrix [1 0 0 1 0 0] def /BBox "
	PSSendFragment(lppd,PSFRAG_crlf);

    // Fix bug 143370, 3-21-96, copied from 4.1CJK
        wsprintf(szTmp, "[%d %d %d %d] def\n",
		  0,
		  lppd->imageRect.bottom-lppd->imageRect.top,
		  lppd->imageRect.right-lppd->imageRect.left,
		  0);
	PSSendData(lppd, (LPSTR)szTmp, lstrlen(szTmp));
	(*tempptr->PSSendCRLF)(lppd);
	PSSendFragment(lppd,PSFRAG_watermark_2_L2); //"/PaintProc { WaterMarkTextShow pop } def end"
	PSSendFragment(lppd,PSFRAG_crlf);
	(*tempptr->PSSendCRLF)(lppd);
}

void TSendWaterMark(LPPDEVICE lppd)
{
LPTEXTXFORM lpTextXForm;
LPPSFONTINFO lpFontInfo;
LPASCIIBINPTRS tempptr;
POINT cp;
long wx, wy;
WORD old_TTFormat, old_MinOutLine, old_fDBCS;
BYTE old_Wide, old_Full, old_Fast;
int  old_FontDataNextRecord;
RECT  rect;
HANDLE hlpwm;       // Mem handle to LpWaterMark
LPWM lpWaterMark;
LPPSDEVMODE psdm=(LPPSDEVMODE) &(lppd->lpPSExtDevmode->dm);
int rc=FALSE;
LPPSFONTINFO  TranFontInfo;  // for TextBegin(), fix bug 159992, 8-6-96

	if (lppd==NULL) return;

	hlpwm = NULL;
	if (psdm->dwWatermarkID)
       {  // Non-null watermark
	    lpWaterMark = (LPWM) MGAllocLock(lppd, (LPHANDLE) &hlpwm,
		    	(DWORD) sizeof(WM), GHND, TRUE);
       }
    else return; // no watermark;

	rc=ReadWatermark(psdm->dwWatermarkID, lpWaterMark);
    if (rc==FALSE) return; // no watermark

   if (psdm->WMFirstPageOnly)
   {
	if (lppd->WMFirstPageFlag)
	    return;
	lppd->WMFirstPageFlag = TRUE;
   }
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

/*	*	*   !!!!! HACK !!!!!	*	*	*/
    old_Full = lppd->lpPSExtDevmode->dm2.bFullDown;
    old_Wide = lppd->lpPSExtDevmode->dm2.bTrueTypeWide;
    old_Fast = lppd->lpPSExtDevmode->dm2.bTrueTypeFast;
    lppd->lpPSExtDevmode->dm2.bFullDown = 0;
    lppd->lpPSExtDevmode->dm2.bTrueTypeWide = 1;
    lppd->lpPSExtDevmode->dm2.bTrueTypeFast = 1;

	/* Bugs 78, 79 - If TT fonts are to be downloaded as bitmaps, */
	/* temporarily override that to outline so that the charpath */
	/* operator (essential to proper functioning of "outline only" */
	/* attribute as well as positioning on the page) works correctly */
   // Also, have to change the MinOutLinePPEM threshold. PPeng, 5-8-1995

    old_TTFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;
    old_MinOutLine = lppd->lpPSExtDevmode->dm2.iMinOutlinePPEM;
    lppd->lpPSExtDevmode->dm2.iMinOutlinePPEM=1;
	lppd->lpPSExtDevmode->dm2.iDLFontFmt=TT_DLFORMAT_TYPE1;

    old_FontDataNextRecord = lppd->lpFontDataList->FontDataNextRecord;
    old_fDBCS = lppd->fDBCS;

	// Now download Font: 

     // In side the next function, we check for Multiple Master Instance fonts 
      TSendWMFont(lppd, lpWaterMark);
      // if lpWMark is still NULL, there is no watermark, nothing to do:
      if ((lppd->WMarkHandle == NULL) || (lppd->lpWMark==NULL)) goto DONE_WM;

      lpFontInfo=(lppd->lpWMark->wmFont).lpPsFontInfo;
      lpTextXForm=(lppd->lpWMark->wmFont).lpTextXForm;

     // This must be done here: it's a problem to do it in SendHeader when the header is DOWN.
     // This call is removed from theader.c and epsfuncs.c.
     TSendWMPdefn(lppd);
     cp.x = 0;
     cp.y = 0;
	/* Create scaled instance with fake bolding/italicizing if necessary */
	 // fix bug 159992
     if(lpFontInfo->dfType & TYPE_SUBSTITUTED)
        TranFontInfo = (LPPSFONTINFO)((char far *)lpFontInfo +
          lpFontInfo->dfBitsOffset + sizeof(TTFONTINFO));
     else
        TranFontInfo = lpFontInfo;
     TTextBegin(lppd, &cp, TranFontInfo, lpTextXForm);
     TTextEnd(lppd, TranFontInfo, lpTextXForm, 0);

	/* Now define the Form proc */
	      PSSendString(lppd, "/WaterMarkTextShow {");
	      (*tempptr->PSSendCRLF)(lppd);
    // Fix bug 143370, 3-21-96, copied from 4.1CJK
    // We should use Paper to place Watermark
          wx = (((long)lpWaterMark->xpos)*((long)lppd->DeviceRes.x_res)/100L) +
			(lppd->ptPaperDim.x)/2 - lppd->imageRect.left;  // mysetup already moves ->left..
          // Notice y- is in GDI direction in Watermar.ini
          wy = (((long)(-lpWaterMark->ypos))*((long)lppd->DeviceRes.y_res)/100L) +
			(lppd->ptPaperDim.y)/2 - lppd->imageRect.top;
	      cp.x = (int)wx;
	      cp.y = (int)wy;
	/* Create scaled instance with fake bolding/italicizing if necessary */
	      TTextBegin(lppd, &cp, TranFontInfo, lpTextXForm);
	/* set color , divide by MAX_RGB_COLOR first. fix bug 97, 3-8-1995 */
	      (*tempptr->PSSendFloat)(lppd, (float)lpWaterMark->R/MAX_RGB_COLOR);
	      PSSendFragment(lppd, PSFRAG_space);
	      (*tempptr->PSSendFloat)(lppd, (float)lpWaterMark->G/MAX_RGB_COLOR);
	      PSSendFragment(lppd, PSFRAG_space);
	      (*tempptr->PSSendFloat)(lppd, (float)lpWaterMark->B/MAX_RGB_COLOR);
	      PSSendString(lppd, " setrgbcolor ");
	      (*tempptr->PSSendCRLF)(lppd);
	      
	      PSSendString(lppd,"gsave");
	      (*tempptr->PSSendCRLF)(lppd);
	      PSSendString(lppd,"currentpoint translate ");
	      PSSendTextChar(lppd, lpWaterMark->text, lstrlen(lpWaterMark->text));

	      PSSendFragment(lppd, PSFRAG_space);
	      PSSendString(lppd,"false charpath pathbbox ");
	      (*tempptr->PSSendCRLF)(lppd);
	      PSSendString(lppd,"grestore");
	      (*tempptr->PSSendCRLF)(lppd);
	      PSSendString(lppd,"exch 4 -1 roll add 2 div neg 3 1 roll add 2 div neg -M");
	      (*tempptr->PSSendCRLF)(lppd);
	      if (psdm->WMOutline)
	      {
  			PSSendFragment(lppd,PSFRAG_watermark_3_L2); //" 1.0 lw [] 0 setdash "
			PSSendFragment(lppd,PSFRAG_crlf);
	        PSSendTextChar(lppd, lpWaterMark->text, lstrlen(lpWaterMark->text));
			PSSendString(lppd," false charpath K ");
			(*tempptr->PSSendCRLF)(lppd);
	      }
	      else{
                TTextRun(lppd, lpWaterMark->text, lstrlen(lpWaterMark->text), 0.0, 0.0, lpFontInfo, lpTextXForm, NULL);
	      }

	      TTextEnd(lppd, lpFontInfo, lpTextXForm, 0);
	      (*tempptr->PSSendCRLF)(lppd);
	      PSSendString(lppd," } def ");
	      (*tempptr->PSSendCRLF)(lppd);

//	ExecWMForm
         if( fIsMinHeaderLppd(lppd) )
		  {
          //Construct the coordinate transformation matrix(CTM) for Watermark.
          // Does this fix bug 428. This may fix other min-header watermark bugs.
           if (lppd->lpPSExtDevmode->dm.marginState == NO_MARGINS){
	          //Full page is imageable.
	          SetRect(&rect, 0, 0, lppd->ptPaperDim.x, lppd->ptPaperDim.y) ;
	          }
            else{
	          rect = lppd->imageRect ;
	          }
		    PSSendFragment(lppd,PSFRAG_ctm_wm_save); // "/ctm_wm_save matrix currentmatrix def"
		    PSSendFragment(lppd,PSFRAG_crlf);
	        //Send mysetup_wm use current page's orientation. 
            PSSendMySetup_Name(lppd, &rect, (short)SETUP_GDI_COORDS, 
                  (BYTE)lppd->lpPSExtDevmode->dm.PaperOrient, PSFRAG_mysetup_wm);
		    PSSendFragment(lppd,PSFRAG_ctm_wm_cont); 
             //above="matrix defaultmatrix setmatrix mysetup concat mysetup_wm concat"
		    PSSendFragment(lppd,PSFRAG_crlf);
		  }

		PSSendFragment(lppd,PSFRAG_watermark_exec); // " Watermark_Adobe_drv ExecWMForm "
		PSSendFragment(lppd,PSFRAG_crlf);

        if( fIsMinHeaderLppd(lppd) )
	        {
		    PSSendFragment(lppd,PSFRAG_ctm_wm_set); // "ctm_wm_save setmatrix"
		    PSSendFragment(lppd,PSFRAG_crlf);
		    }

DONE_WM:	
	if (hlpwm!=NULL)  { MGUnlockFree(lppd, hlpwm, TRUE);}     
    lppd->lpPSExtDevmode->dm2.bFullDown = old_Full;
    lppd->lpPSExtDevmode->dm2.bTrueTypeWide = old_Wide;
    lppd->lpPSExtDevmode->dm2.bTrueTypeFast = old_Fast;
    lppd->lpPSExtDevmode->dm2.iDLFontFmt = old_TTFormat;
    lppd->lpPSExtDevmode->dm2.iMinOutlinePPEM = old_MinOutLine;

    // trick for QuarkXpress 3.31: remove the scaled font data record
    if (lppd->lpFontDataList->FontDataNextRecord > old_FontDataNextRecord)
        lppd->lpFontDataList->FontDataNextRecord --;
    // Reset the Far East fDBCS font flag - so WM font won't mess up text font
    // lppd->fDBCS = 0;
    lppd->fDBCS = old_fDBCS;
}



/* This function will send the Font, but first it checks for if the 
 * WM font is already cached or not. If not, realize and cache it.
 * MM Fonts are also handled here.
 * If the font is Multiple Master Instance, it will send the MM Base font
 * first.
 */
int TSendWMFont(LPPDEVICE lppd, LPWM lpWaterMark)
{
	int    rc;
    LPPSDEVMODE psdm = (LPPSDEVMODE) &lppd->lpPSExtDevmode->dm;
	
	if (lppd==NULL) return RC_fail;
    
	if (lppd->disableWMark) return RC_ok; // two flags now to control wm and n-up 

	rc=RC_fail;
	if (psdm->dwWatermarkID)
   {  // Non-null watermark
		rc=ReadWatermark(psdm->dwWatermarkID, lpWaterMark);

		if ((rc==TRUE) && (lpWaterMark->text[0])){
		 // get font info
		 // First check if the FontInfo is already initialized.

		 if (lppd->WMarkHandle == NULL){
			// First Time Allocate mem for the WaterMark structure
			// it is supposedly done in AllocateTransLayerData(). 
			InitWaterMark(lppd);
			}
		 if ( (lppd->WMarkHandle != NULL) &&
			  (lppd->lpWMark->wmFont.WaterState == WATER_null) ){

			  // We fill the wmFont first because the lpWatermark->lf.lfFacenaem may be changed
			  // to "Courier" if the instance is not available. In that case, we don't have to
			  // do wmBaseFont. Save time and money. 5-4-1995, PPeng
			  FillWater(lppd, (LPWATERMARK_FONT)&(lppd->lpWMark->wmFont), lpWaterMark);
			} // Water should be filled now.

/*
 Note: 
 Direct call to RealizeObject() is NOT able to realize any TrueType fonts.
 Reason is The GDI fills in some structure in the background.
 if use CreateFontIndirect() and then selectObject
 to select the font to  a printer dc, the font is relaized - by
 the following sequence:
   GDI(3),
   RealizeObject(,,NULL,NULL), 
   RealizeObject(,, , ,),
The sequence in our code is the same execpt that we are not GDI(3)

Finally, comes this solution: Use EnumFontFamilies to give GDI a chance to fill in the
hidden structure.
*/

		 if ( (lppd->WMarkHandle != NULL) &&
			  (lppd->lpWMark->wmFont.WaterState >= WATER_filled) ){
			  // send the Watermark stuff, depends on the Driver to check fonts record.
			  SendWaterMarkPSData(lppd, lpWaterMark, (LPWATERMARK_FONT)&(lppd->lpWMark->wmFont), 0); // 0 =send the wm form also
			  } // WaterState should be form_sent now.
		  rc=RC_ok;
		  }
		}

   return rc;
}




/**********************************************************************
*                       SendWaterMarkPSData()
*  function:
*       Actuall work to send the watermarks form filled with data
*       Use the FontInfo passed in to do the actual PS code work
*  prototype:
*  int SendWaterMarkPSData(LPPDEVICE lppd, LPWM lpWaterMark, LPPSFONTINFO lpPsFontInfo,
*                       LPTEXTXFORM lpTextXForm)
*  int iFontType, LPARAM lParam)
*  parameters:
*       valid fontinf and watermark.
*  returns:
*       RC_ok: success.
**********************************************************************/

int SendWaterMarkPSData(LPPDEVICE lppd, LPWM lpWaterMark, LPWATERMARK_FONT lpWMFont, int sendFontOnly)
{
    LPPSFONTINFO lpPsFontInfo;
	LPTEXTXFORM lpTextXForm;
	int    rc;
	LPASCIIBINPTRS tempptr;
	WORD  old_TT_DLFormat;
	POINT currentPoint;
    LPPSDEVMODE psdm;
    LPPSFONTINFO  TranFontInfo;  // for TextBegin(), fix bug 159992, 8-6-96

	if (lppd==NULL) return RC_fail;

    psdm = (LPPSDEVMODE) &lppd->lpPSExtDevmode->dm;

	tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    lpPsFontInfo = lpWMFont->lpPsFontInfo;
	lpTextXForm= lpWMFont->lpTextXForm;

	   // We need send font manipulate procsets for Min-Header Apps:
       // Do this before downloading because a MM base font may be sent and 
       // used Inside DownloadFont().
	   if( fIsMinHeaderLppd(lppd) )
		  {
		  // Do a Minheader dict invocation
		  PSSendFragment(lppd, PSFRAG_epsprocsetstart);
		  (*tempptr->PSSendCRLF)(lppd);
		  PSSendProc(lppd, PSPROC_watermark_ps2); // ps1 is the same
		  (*tempptr->PSSendCRLF)(lppd);
		  PSSendFragment(lppd, PSFRAG_end);
        PSSendFragment(lppd, PSFRAG_end); // Take userdict from the stack
                                          // Changed 20-Oct-1995 -by- [olegsher]
		  (*tempptr->PSSendCRLF)(lppd);
		  }


		if ( psdm->WMOutline &&
		   (lpPsFontInfo->dfType & TYPE_TRUETYPE) ){
			 // force to Type1 download in order to do Outline Watermark
			old_TT_DLFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;
    		lppd->lpPSExtDevmode->dm2.iDLFontFmt=TT_DLFORMAT_TYPE1;
			}

         {  // hack to do Fast for WM
          LPTTFONTINFO  lpTTFontInfo ;
          LPBYTE   lpFontName;
          WORD     wGI[256], wShowOrder[256]; // maximal length of Watermark is 256
          int      i, count;
          if(lpPsFontInfo->dfType & TYPE_SUBSTITUTED)
		      TranFontInfo = (LPPSFONTINFO)((char far *)lpPsFontInfo +
					 lpPsFontInfo->dfBitsOffset + sizeof(TTFONTINFO));
          else
		      TranFontInfo = lpPsFontInfo;
          //If the font is TrueType, we do it in Fast Way:
 	      if ((TranFontInfo->dfType & TYPE_TRUETYPE) &&
 	          (TranFontInfo->dfType & PF_GLYPH_INDEX) &&
 	          (!lppd->lpPSExtDevmode->dm2.bFullDown) && 
              (lppd->lpPSExtDevmode->dm2.bTrueTypeFast) )
             {
              lpTTFontInfo = (LPTTFONTINFO)((LPSTR)TranFontInfo + 
                                       TranFontInfo->dfBitsOffset);

              // Convert lpWaterMark->text to Glyph-index: Use the lfCopy saved in lpTTInfo
              count = ConvertToGI((LPLOGFONT)&(lpTTFontInfo->lfCopy), (LPSTR)lpWaterMark->text, (LPWORD)&wGI, (int)lstrlen(lpWaterMark->text));

              lpFontName = lpTTFontInfo->PSName;
              // Modify the name so it won't interfer with Document Font:
              if (_fstrstr(lpFontName, "wm")==NULL)
                {
                 while(*lpFontName) lpFontName++ ;
                 wsprintf(lpFontName, "%s", "wm");  // Add two chars "wm" 
                }
              else
                {
                // already has "wm", must also has the HighByte appended, remove it
                REMOVE_SHOW_ORDER_SUBSTRING(lpFontName);
                }

              // Now point to the name - should be "MSTT31...wm"
              lpFontName = lpTTFontInfo->PSName;
              // Get the  GIAssignment:
              if (GetGIAssignmentStr(lppd, (LPSTR)lpFontName,
                   (LPWORD)&wGI, (LPWORD)wShowOrder, count) )
                   {
                    //Copy wShowOrder to lpWaterMark->text:
                    for (i=0; i<count; i++) lpWaterMark->text[i] = (BYTE) (wShowOrder[i]&0x00FF);
                    lpWaterMark->text[i] = '\0';  // null temrinate it
                   }

              lpTTFontInfo->HighByte = wShowOrder[0] & 0xFF00  ;
              APPEND_SHOW_ORDER_SUBSTRING(lpFontName, lpTTFontInfo->HighByte);
		      }
          } // End hack to do Fast for WM

		StringFontDownLoad(lppd, (LPSTR)(lpWaterMark->text), (int)lstrlen(lpWaterMark->text),
			lpPsFontInfo, lpTextXForm);

   // For Far East. DBCS font flag initialize.
  {
   if(lpPsFontInfo->dfType & TYPE_SUBSTITUTED)
      TranFontInfo = (LPPSFONTINFO)((char far *)lpPsFontInfo +
    	 lpPsFontInfo->dfBitsOffset + sizeof(TTFONTINFO));
   else
      TranFontInfo = lpPsFontInfo;
   lppd->fDBCS = 0;
   if( IsDBCSCharSet(TranFontInfo->dfCharSet))
   {

      lppd->fDBCS |= DBCS_FONT;
      if(!(TranFontInfo->dfType & TYPE_TRUETYPE) )
         {
         char far *lpFaceName;

         lppd->fDBCS |= DBCS_DEVICE;
         lpFaceName = (char far*)lpPsFontInfo+TranFontInfo->dfFace;
         if( *lpFaceName == '@' )
            {
            if( (lpPsFontInfo->dfPitchAndFamily & 0x01) &&
                TranFontInfo->dfCharSet == SHIFTJIS_CHARSET)
                lppd->fDBCS |= DBCS_83PV_VERT;   // this is for J only.
            else
                lppd->fDBCS |= DBCS_VERT;        // This is for CJK vertical printing.
            }
         }

     }
  }
   
		currentPoint.x=0; currentPoint.y=0;
		// extra 0 0 moveto/M is send in TTextBegin().
        TTextBegin(lppd, &currentPoint, TranFontInfo, lpTextXForm);
		// Setup font record and son on:
		TTextEnd(lppd, TranFontInfo, lpTextXForm, 0);

 		lpWMFont->WaterState = WATER_form_sent;
		
		rc=RC_ok;
		
   return(rc);  // don't continue for other fonts with the same name.
}



/**********************************************************************
*                       WaterMarkEnumAFont
*  function:
*       Actuall work to send the watermarks form filled with data
*       The reason we use this call back function is that the RealizeObject()
*       calls must be issued from a function has a HDC seleceted.
*       We cannot call realizeObject() in PSSendWaterMark() directly.
*  prototype:
*  int CALLBACK WaterMarkEnumAFont(LPENUMLOGFONT lpLogFont, LPNEWTEXTMETRIC lpTextMetric,
*  int iFontType, LPARAM lParam)
*  parameters:
*       .... lParam is the current lppd.
*  returns:
*       0. Means only enumerate once.
**********************************************************************/

int CALLBACK WaterMarkEnumAFont(LPENUMLOGFONT lpLogFont, LPNEWTEXTMETRIC lpTextMetric,
  int iFontType, LPARAM lParam)
{
	HANDLE hlpwm;       // Mem handle to LpWaterMark, a local copy, maybe modified.
	LPWM lpWaterMark;
    LPWATERMARK_FONT  lpWMFont;      // a copy of lppd->lpWMark
	int    rc;
	float Size;     // Watermark Font size
	LPPDEVICE lppd;
	WORD  old_TT_DLFormat, old_MinOutLine;
    LPPSDEVMODE psdm;


		lppd = ((LPWATERMARK_LPPD)lParam)->lppd;
  		if (lppd==NULL) return (0); // don't continue - bad time

        psdm = (LPPSDEVMODE) &lppd->lpPSExtDevmode->dm;
		lpWMFont = ((LPWATERMARK_LPPD)lParam)->lpWMFont;
        hlpwm = NULL;
  	    lpWaterMark = (LPWM) MGAllocLock(lppd, (LPHANDLE) &hlpwm,
					(DWORD) sizeof(WM), GHND, TRUE);
		MemCopy((LP)lpWaterMark, (LP)((LPWATERMARK_LPPD)lParam)->lpWaterMark, sizeof(WM));
        lpWaterMark->lf.lfCharSet = lpLogFont->elfLogFont.lfCharSet; // so the copy in lpTTFont is correct- at least

       // force to Type1 download in order to do Watermark correctly. Fix bug 78, PPeng, 5-8-95
       old_MinOutLine = lppd->lpPSExtDevmode->dm2.iMinOutlinePPEM;
       lppd->lpPSExtDevmode->dm2.iMinOutlinePPEM=1;
       old_TT_DLFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;
       lppd->lpPSExtDevmode->dm2.iDLFontFmt=TT_DLFORMAT_TYPE1;
       //

        Size = (float)MulDiv(lpWaterMark->lf.lfHeight, lppd->DeviceRes.x_res, 72);
		// Adjust it to logical unit for our dirver
		lpWaterMark->lf.lfHeight = (int)-Size;  // Value of Size is not used again.
	
		if (lpWMFont->txfHandle==NULL){
		   // never allocated before
		    lpWMFont->lpTextXForm = (LPTEXTXFORM) MGAllocLock(lppd,
				(LPHANDLE) &(lpWMFont->txfHandle),(DWORD) sizeof(TEXTXFORM), GHND, TRUE);
		   }
		if (lpWMFont->fontHandle!=NULL){
		   // FontInfo may change, so free it now, allocate again after get the size
		   MGUnlockFree(lppd, lpWMFont->fontHandle, TRUE);
		   lpWMFont->fontHandle = NULL ;
		   }

		rc=RealizeObject((LP)lppd, (short)OBJ_FONT, (LP)&(lpWaterMark->lf), 
				(LP)NULL, (LP)(lpWMFont->lpTextXForm) );
		if (rc>0) {
		   lpWMFont->lpPsFontInfo = (LPPSFONTINFO) MGAllocLock(lppd,
			   (LPHANDLE) &(lpWMFont->fontHandle), (DWORD) rc, GHND, TRUE);
		   rc=RealizeObject((LP)lppd, (short)OBJ_FONT, (LP)&(lpWaterMark->lf),
			   (LP)lpWMFont->lpPsFontInfo, (LP)lpWMFont->lpTextXForm);
		   // if the font is TT and substituted by PS font, re-realize it.
		   // fix a bug for replacing TT by Resident PS. Are there other ways ? -- PPeng
		   if ((lpWMFont->lpPsFontInfo->dfType & TYPE_SUBSTITUTED) &&
			   (lpWMFont->lpPsFontInfo->dfType & TYPE_TRUETYPE)) {
				char SubFont[MAX_PS_NAME];
				SubFont[0] = '\0' ;
                GetSubstitute(ghDriverMod, lppd, lppd->lpPSExtDevmode, 
                        (LPSTR)(lpWaterMark->lf.lfFaceName), (LPSTR) SubFont);
				if (SubFont[0]){
				   lstrcpy((LPSTR)(lpWaterMark->lf.lfFaceName), (LPSTR) SubFont);
				   // FontInfo may change, so free it now, allocate again after get the size
				   MGUnlockFree(lppd, lpWMFont->fontHandle, TRUE);
				   lpWMFont->fontHandle = NULL ;
				   rc=RealizeObject((LP)lppd, (short)OBJ_FONT, (LP)&(lpWaterMark->lf), 
						(LP)NULL, (LP)(lpWMFont->lpTextXForm) );
				   if (rc>0) {
					  lpWMFont->lpPsFontInfo = (LPPSFONTINFO) MGAllocLock(lppd,
						  (LPHANDLE) &(lpWMFont->fontHandle), (DWORD) rc, GHND, TRUE);
					  rc=RealizeObject((LP)lppd, (short)OBJ_FONT, (LP)&(lpWaterMark->lf),
						  (LP)lpWMFont->lpPsFontInfo, (LP)lpWMFont->lpTextXForm);
						  }
				   }
			   }

		   // Change the Water state to filled:
		   lpWMFont->WaterState = WATER_filled;
		   }

	 // reverse to original download format
 	lppd->lpPSExtDevmode->dm2.iDLFontFmt = old_TT_DLFormat;
    lppd->lpPSExtDevmode->dm2.iMinOutlinePPEM = old_MinOutLine;
	if (hlpwm!=NULL)  { MGUnlockFree(lppd, hlpwm, TRUE);}     

    return(0);  // don't continue for other fonts with the same name.
 }



short FAR PASCAL FillWater(LPPDEVICE lppd, LPWATERMARK_FONT lpWMFont, LPWM lpWaterMark)
 {

	HDC hPrinterDC;
    WATERMARK_LPPD   lpWMPD;    // watermark and lppd info
    char szTmp[254];   // used for driver file name,

    	if (lppd==NULL) return 0;  // called at bad time

			// use this expensive EnumFontFamilies() call to fill FontInfo structure
			// The lpPsFontInfo and so on will be filled in the callback function
			/* Get the device and then realize the font using EnumFontFamilies */
      		GetModuleFileName(ghDriverMod, szTmp, sizeof(szTmp));
            // szTmp contains Path. It seems it's OK to use it directly in Windows 95-96.

            // Fixed bug 120534. Use GetDC instead of CreateDC
            hPrinterDC = GetDC( NULL );
			//hPrinterDC = CreateDC(szTmp, (LPSTR)lppd->lpPSExtDevmode->dm.dm.dmDeviceName,
			//		 lppd->szPortName, NULL);

			if (hPrinterDC != NULL){
			   lpWMPD.lppd = lppd;
			   lpWMPD.lpWMFont = lpWMFont;
			   lpWMPD.lpWaterMark = lpWaterMark;
			   EnumFontFamilies(hPrinterDC, (LPCSTR)(lpWaterMark->lf.lfFaceName),
					 (FONTENUMPROC)WaterMarkEnumAFont, (LPARAM)(&lpWMPD) );

               // Fix bug 120534. Try to enum PostScript Font.
               if (lpWMFont->WaterState == WATER_null)
               {
                    ENUMLOGFONT   LogFont;
                    NEWTEXTMETRIC TextMetric;
                    
                    MemSet((LPSTR)(&LogFont), 0, (DWORD)sizeof(ENUMLOGFONT));
                    MemSet((LPSTR)(&TextMetric), 0, (DWORD)sizeof(NEWTEXTMETRIC));
                    LogFont.elfLogFont.lfCharSet = DEFAULT_CHARSET;
                    WaterMarkEnumAFont(&LogFont, &TextMetric, 0, (LPARAM)(&lpWMPD));
               }

			   // If font lpWaterMark->lf.lfFaceName is not available, the call back function
			   // WaterMarkEnumAFont() won't be called, so, let's try Courier
			   // Because we still want our watermark as Courier
			   if (lpWMFont->WaterState == WATER_null){
				  lstrcpy((LPSTR)(lpWaterMark->lf.lfFaceName), DEFAULT_FONT);
				  EnumFontFamilies(hPrinterDC, (LPCSTR)(lpWaterMark->lf.lfFaceName),
					 (FONTENUMPROC)WaterMarkEnumAFont, (LPARAM)(&lpWMPD) );
				  }

               // Fix bug 120534. 
               ReleaseDC (NULL, hPrinterDC);
               // DeleteDC(hPrinterDC);
	   }

return 1;  // Success.
}


/***************************************************************
* Name: StringFontDownLoad()
*
* Action: This routine is used to down load softfont for a given string
*         Without actually draw/show the string. 
*
******************************************************************/

int StringFontDownLoad(lpdv, lpbSrc, cbSrc, lpPsFontInfo, lpTextXForm)
LPPDEVICE   lpdv;       /* Far ptr the device descriptor */
LPSTR   lpbSrc;     /* Far ptr to the source string */
int cbSrc;      /* Size of the source string */
LPPSFONTINFO  lpPsFontInfo;     /* Far ptr to the FONTINFO structure */
LPTEXTXFORM lpTextXForm;    /* Font transformation structure */
{
	 LPFONTEXTRA FontExtra;  /* Far ptr to the extended device font structure */
	 LPPSFONTINFO  TranFontInfo;/* The FONTINFO structure for the
									 * TRAN side font  - it can be different
									 * from the lpPsFontInfo if we substitute font
									 */
	 LONG     lCharExtra=0;
	 LONG     lBreakExtra=0;
	 LPTFUNCTIONPTRS tempptr;

	 tempptr = (LPTFUNCTIONPTRS)lpdv->lpTFuncPtr;

	 if(lpPsFontInfo->dfType & TYPE_SUBSTITUTED)
		  TranFontInfo = (LPPSFONTINFO)((char far *)lpPsFontInfo +
					 lpPsFontInfo->dfBitsOffset + sizeof(TTFONTINFO));
	 else
		  TranFontInfo = lpPsFontInfo;

	 FontExtra=(LPFONTEXTRA)BUMPFAR (TranFontInfo, TranFontInfo->dfDriverInfo);

	 // download a softfont, if necessary
	  if( (TranFontInfo->dfType & TYPE_TRUETYPE) ||
				  (FontExtra->dwSoftFont) ) {
           //if mmInstance, we need to use TSoftFontLoad for download base as well as instance. ANG 1/17
           TSOFTFONTLOAD oldTSoftFontLoad = tempptr->rTSoftFontLoad;
           tempptr->rTSoftFontLoad      = TSoftFontLoad      ;
           TSoftFontLoad(lpdv,TranFontInfo,lpTextXForm,lpbSrc,cbSrc);
              //Use TSoftFontLoad() directly here becasue we register F0 for minheader but not create scaled instance. Ppeng
           tempptr->rTSoftFontLoad      = oldTSoftFontLoad      ;
		  }
			
  return (1);
}


/* Function to set Watermark data. It must be called 
 * Before use the watermark data.
*/
short FAR PASCAL GetWaterMarkData(LPPDEVICE lppd)
{
   	if (lppd==NULL) return RC_ok;  // called at bad time
	if (lppd->disableWMark) return RC_ok; // Watermark is disabled
	
	if (lppd->WMarkHandle == NULL){
		// First Time Allocate mem for the WaterMark structure
		InitWaterMark(lppd);
	   }

	if (lppd->WMarkHandle == NULL){
		// Still Unable to allocate memory ?
		return (RC_fail);
		}

   return (RC_ok);
}



// Function to initializethe memory for Matermark settings
short FAR PASCAL InitWaterMark(LPPDEVICE lppd)
{
   	if (lppd==NULL) return RC_ok;  // called at bad time
	if (lppd->WMarkHandle == NULL){
		 // First Time Allocate for Whole structure
		 lppd->lpWMark = (LPWATERMARK_INFO) MGAllocLock(lppd,
			(LPHANDLE) &(lppd->WMarkHandle), (DWORD) sizeof(WATERMARK_INFO), GHND, TRUE);
		 lppd->lpWMark->wmFont.txfHandle  = NULL;
		 lppd->lpWMark->wmFont.fontHandle = NULL;
		 lppd->lpWMark->wmFont.WaterState = WATER_null;
		 lppd->lpWMark->wmBaseFont.txfHandle  = NULL;
		 lppd->lpWMark->wmBaseFont.fontHandle = NULL;
		 lppd->lpWMark->wmBaseFont.WaterState = WATER_null;
	}
return (RC_ok);
}


// Function to free the memory for Watermark stuff
short FAR PASCAL FreeWaterMark(LPPDEVICE lppd)
{
   if (lppd==NULL) return RC_ok;  // called at bad time
   if (lppd->WMarkHandle != NULL){
	  // Free the internal Pointers first:
	 if (lppd->lpWMark->wmFont.txfHandle!=NULL)   {
		 MGUnlockFree(lppd, lppd->lpWMark->wmFont.txfHandle, TRUE);
		 }
	 if (lppd->lpWMark->wmFont.fontHandle!=NULL)  {
		 MGUnlockFree(lppd, lppd->lpWMark->wmFont.fontHandle, TRUE);
		 }
	 if (lppd->lpWMark->wmBaseFont.txfHandle!=NULL)   {
		 MGUnlockFree(lppd, lppd->lpWMark->wmBaseFont.txfHandle, TRUE);
		 }
	 if (lppd->lpWMark->wmBaseFont.fontHandle!=NULL)  {
		 MGUnlockFree(lppd, lppd->lpWMark->wmBaseFont.fontHandle, TRUE);
		 }
	  // Free the pointer itself
	 MGUnlockFree(lppd, lppd->WMarkHandle, TRUE);
	 lppd->WMarkHandle = NULL;
	 lppd->lpWMark = (LPWATERMARK_INFO) NULL;
	 }
   return (RC_ok);  
}




short FAR PASCAL PSSendMySetup_Name(LPPDEVICE lppd, LPRECT lpRect, SHORT sSendType, BYTE bOrientation, int mysetup_name)
{
   PSMATRIX  Matrix;
   LPASCIIBINPTRS tempptr;
   int  i;
   int  LandscapeOrientation; //default is Minus90 Orientation
   LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   LandscapeOrientation =lpPrinterInfo->devcaps.landscapeOrientPlus90;
//   LandscapeOrientation = DMORIENT_PORTRAIT;

   // For Nup's orientation, use given bOrientation:
   GetMySetupMatrix(lppd, lpRect, sSendType,
      bOrientation, LandscapeOrientation, (LPPSMATRIX)&Matrix);

   PSSendFragment(lppd,PSFRAG_slash);
   PSSendFragment(lppd,mysetup_name);  // must be a PSFRAG_...
   PSSendFragment(lppd,PSFRAG_leftbracket);
   for(i=0;i<6;i++)
   {
	 (*tempptr->PSSendFloat)(lppd,Matrix[i]);
//	 lppd->lpGSStack->lpgGState->jobCTM[ i ] = Matrix[ i ];
   }

   PSSendFragment( lppd,PSFRAG_rightbracket );
   (*tempptr->PSSendBasic)( lppd,PSOP_def );
   (*tempptr->PSSendCRLF)( lppd );

   return( RC_ok );
} /* PSSendMySetup_Name */



/* GetMySetupMatrix(), Separated from PSSendMySetup(), so we can
   Send a matrix based on a specified orientation. to do Nup right. fix bug 304
*/
short FAR PASCAL GetMySetupMatrix(LPPDEVICE lppd, LPRECT lpRect, SHORT sSendType,
BYTE bOrient, int LandscapeOrientation, LPPSMATRIX lpMatrix)
{
//   MemCopy(lpMatrix, lppd->psmatrix, sizeof(PSMATRIX));

   LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
   PAP_ORIENT  bOrientation;   //  Orientation of image on paper, eg. landscape, from from PPD keyword ORIENT
   double   a, b, c, d, tx, ty ;
   BOOL     bMinHeader = FALSE;  // !!!! Should get this from data structure !!!!
   BOOL     bLandscapePlus90;

   bMinHeader = fIsMinHeaderLppd(lppd);

   bOrientation = bOrient;  // current orientation, passed in 

   if (bOrientation == OR_PORTRAIT){ 
      // This is the same as lppd->psmatrix
      MemCopy(lpMatrix, lppd->psmatrix, sizeof(PSMATRIX));
      return 1;
      }

   bLandscapePlus90 = LandscapeOrientation; // passed-in
   if (bLandscapePlus90) 
   {
	if (bOrientation == OR_LANDSCAPE)
	    bOrientation = OR_ROTLANDSCAPE;
	else if (bOrientation == OR_ROTLANDSCAPE)
	    bOrientation = OR_LANDSCAPE;
   }

   // For min-header, don't rotate again: fix bug 261, 6-8-95
    a = 1.0 ;
    b = 0.0 ;
    c = 0.0 ;
    d = -1.0 ;

   {
      switch (bOrientation)
      {
	 case  OR_LANDSCAPE:     //  rotate minus 90 degs
	    tx = lpRect->left ;
	    ty = lpRect->bottom ;

	    break;
	 case  OR_ROTLANDSCAPE:  // rotate plus 90 degs
	    tx = lpRect->left ;
	    ty = lpRect->bottom ;

	    break;
	 case  OR_PORTRAIT:    // This is the same as lppd->psmatrix
	 default:
	    tx = lppd->psmatrix[5] ;
	    ty = lppd->psmatrix[6] ;
	    break;
      }
   }

   {   //  convert  CTM from  points to log resolution
      a *= 72.0 / lppd->DeviceRes.x_res ;
      c *= 72.0 / lppd->DeviceRes.x_res ;
      b *= 72.0 / lppd->DeviceRes.y_res ;
      d *= 72.0 / lppd->DeviceRes.y_res ;
      tx *= 72.0 / lppd->DeviceRes.x_res ;
      ty *= 72.0 / lppd->DeviceRes.y_res ;
   }


   lpMatrix[0] = (float)a ;
   lpMatrix[1] = (float)b ;
   lpMatrix[2] = (float)c ;
   lpMatrix[3] = (float)d ;
   lpMatrix[4] = (float)tx ;
   lpMatrix[5] = (float)ty ;

   return 1;
}


int FAR PASCAL ConvertToGI(LPLOGFONT lplf, LPSTR lpStr, LPWORD lpwGI, int count)
{
HDC hDC;
HFONT hFont1, hOldFont1;
GCP_RESULTS results;

    results.lStructSize = sizeof(GCP_RESULTS);
    results.lpOutString = NULL;
    results.lpOrder = NULL;
    results.lpDx = NULL;
    results.lpCaretPos = NULL;
    results.lpClass = NULL;

   // Use Screen DC.
   hDC=GetDC(NULL);
   hFont1 = CreateFontIndirect(lplf);
   hOldFont1 = SelectObject(hDC, hFont1);

   results.lpGlyphs = lpwGI;
   results.nGlyphs = results.nMaxFit = count;
   GetCharacterPlacement(hDC, (LPSTR)lpStr, count, count, &results, 0); //dwLangInfo&FLI_MASK);

   SelectObject(hDC, hOldFont1);
   DeleteObject(hFont1);
   ReleaseDC(NULL, hDC);

   return results.nGlyphs;
   
}


#endif  /* ifdef ADOBE_DRIVER */

