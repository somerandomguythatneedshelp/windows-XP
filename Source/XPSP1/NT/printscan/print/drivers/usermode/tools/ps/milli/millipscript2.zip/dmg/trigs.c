/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1995 Adobe Systems Inc. All rights reserved.                */
/*                                                                           */
/* Module Name: TRIGS.C                                                      */
/*                                                                           */
/* Description: Transform functions for watermark code.                      */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_WATERMARKSEG)

/*****************************************************************************/

typedef struct {
  int num;
  int denom;
} FRACT;

/*****************************************************************************/

/*	sin(a) == SineTbl[a*10]/255;
	Turns out that this simpler form is close enough for us
 */
BYTE WATERMARKSEG SineTbl[] = {
	  0,  0,  1,  1,  2,  2,  3,  3,  4,  4,	/*	0 */
	  4,  5,  5,  6,  6,  7,  7,  8,  8,  8,	/*	1 */
	  9,  9, 10, 10, 11, 11, 12, 12, 12, 13,	/*	2 */
	 13, 14, 14, 15, 15, 16, 16, 16, 17, 17,	/*	3 */
	 18, 18, 19, 19, 20, 20, 20, 21, 21, 22,	/*	4 */
	 22, 23, 23, 24, 24, 24, 25, 25, 26, 26,	/*	5 */
	 27, 27, 28, 28, 28, 29, 29, 30, 30, 31,	/*	6 */
	 31, 32, 32, 32, 33, 33, 34, 34, 35, 35,	/*	7 */
	 35, 36, 36, 37, 37, 38, 38, 39, 39, 39,	/*	8 */
	 40, 40, 41, 41, 42, 42, 43, 43, 43, 44,	/*	9 */
	 44, 45, 45, 46, 46, 46, 47, 47, 48, 48,	/* 10 */
	 49, 49, 50, 50, 50, 51, 51, 52, 52, 53,	/* 11 */
	 53, 53, 54, 54, 55, 55, 56, 56, 56, 57,	/* 12 */
	 57, 58, 58, 59, 59, 60, 60, 60, 61, 61,	/* 13 */
	 62, 62, 63, 63, 63, 64, 64, 65, 65, 66,	/* 14 */
	 66, 66, 67, 67, 68, 68, 69, 69, 69, 70,	/* 15 */
	 70, 71, 71, 72, 72, 72, 73, 73, 74, 74,	/* 16 */
	 75, 75, 75, 76, 76, 77, 77, 78, 78, 78,	/* 17 */
	 79, 79, 80, 80, 80, 81, 81, 82, 82, 83,	/* 18 */
	 83, 83, 84, 84, 85, 85, 86, 86, 86, 87,	/* 19 */
	 87, 88, 88, 88, 89, 89, 90, 90, 91, 91,	/* 20 */
	 91, 92, 92, 93, 93, 93, 94, 94, 95, 95,	/* 21 */
	 96, 96, 96, 97, 97, 98, 98, 98, 99, 99,	/* 22 */
	100,100,100,101,101,102,102,102,103,103,	/* 23 */
	104,104,105,105,105,106,106,107,107,107,	/* 24 */
	108,108,109,109,109,110,110,111,111,111,	/* 25 */
	112,112,113,113,113,114,114,115,115,115,	/* 26 */
	116,116,117,117,117,118,118,119,119,119,	/* 27 */
	120,120,121,121,121,122,122,122,123,123,	/* 28 */
	124,124,124,125,125,126,126,126,127,127,	/* 29 */
	128,128,128,129,129,129,130,130,131,131,	/* 30 */
	131,132,132,132,133,133,134,134,134,135,	/* 31 */
	135,136,136,136,137,137,137,138,138,139,	/* 32 */
	139,139,140,140,140,141,141,141,142,142,	/* 33 */
	143,143,143,144,144,144,145,145,146,146,	/* 34 */
	146,147,147,147,148,148,148,149,149,150,	/* 35 */
	150,150,151,151,151,152,152,152,153,153,	/* 36 */
	153,154,154,155,155,155,156,156,156,157,	/* 37 */
	157,157,158,158,158,159,159,159,160,160,	/* 38 */
	160,161,161,162,162,162,163,163,163,164,	/* 39 */
	164,164,165,165,165,166,166,166,167,167,	/* 40 */
	167,168,168,168,169,169,169,170,170,170,	/* 41 */
	171,171,171,172,172,172,173,173,173,174,	/* 42 */
	174,174,175,175,175,176,176,176,176,177,	/* 43 */
	177,177,178,178,178,179,179,179,180,180,	/* 44 */
	180,181,181,181,182,182,182,183,183,183,	/* 45 */
	183,184,184,184,185,185,185,186,186,186,	/* 46 */
	186,187,187,187,188,188,188,189,189,189,	/* 47 */
	190,190,190,190,191,191,191,192,192,192,	/* 48 */
	192,193,193,193,194,194,194,194,195,195,	/* 49 */
	195,196,196,196,196,197,197,197,198,198,	/* 50 */
	198,198,199,199,199,200,200,200,200,201,	/* 51 */
	201,201,201,202,202,202,203,203,203,203,	/* 52 */
	204,204,204,204,205,205,205,206,206,206,	/* 53 */
	206,207,207,207,207,208,208,208,208,209,	/* 54 */
	209,209,209,210,210,210,210,211,211,211,	/* 55 */
	211,212,212,212,212,213,213,213,213,214,	/* 56 */
	214,214,214,215,215,215,215,216,216,216,	/* 57 */
	216,216,217,217,217,217,218,218,218,218,	/* 58 */
	219,219,219,219,219,220,220,220,220,221,	/* 59 */
	221,221,221,222,222,222,222,222,223,223,	/* 60 */
	223,223,223,224,224,224,224,225,225,225,	/* 61 */
	225,225,226,226,226,226,226,227,227,227,	/* 62 */
	227,227,228,228,228,228,228,229,229,229,	/* 63 */
	229,229,230,230,230,230,230,231,231,231,	/* 64 */
	231,231,231,232,232,232,232,232,233,233,	/* 65 */
	233,233,233,233,234,234,234,234,234,235,	/* 66 */
	235,235,235,235,235,236,236,236,236,236,	/* 67 */
	236,237,237,237,237,237,237,238,238,238,	/* 68 */
	238,238,238,239,239,239,239,239,239,239,	/* 69 */
	240,240,240,240,240,240,241,241,241,241,	/* 70 */
	241,241,241,242,242,242,242,242,242,242,	/* 71 */
	243,243,243,243,243,243,243,243,244,244,	/* 72 */
	244,244,244,244,244,244,245,245,245,245,	/* 73 */
	245,245,245,245,246,246,246,246,246,246,	/* 74 */
	246,246,247,247,247,247,247,247,247,247,	/* 75 */
	247,248,248,248,248,248,248,248,248,248,	/* 76 */
	248,249,249,249,249,249,249,249,249,249,	/* 77 */
	249,250,250,250,250,250,250,250,250,250,	/* 78 */
	250,250,250,251,251,251,251,251,251,251,	/* 79 */
	251,251,251,251,251,252,252,252,252,252,	/* 80 */
	252,252,252,252,252,252,252,252,252,252,	/* 81 */
	253,253,253,253,253,253,253,253,253,253,	/* 82 */
	253,253,253,253,253,253,253,253,254,254,	/* 83 */
	254,254,254,254,254,254,254,254,254,254,	/* 84 */
	254,254,254,254,254,254,254,254,254,254,	/* 85 */
	254,254,254,254,254,255,255,255,255,255,	/* 86 */
	255,255,255,255,255,255,255,255,255,255,	/* 87 */
	255,255,255,255,255,255,255,255,255,255,	/* 88 */
	255,255,255,255,255,255,255,255,255,255,	/* 89 */
	255 										/* 90 */
};

/*	get sine of angle
	in: x = angle in degrees*10
		returns FRACT struct

 */
FRACT sine(int x) {

	int 	ix;
	int 	q;
	FRACT	f;

	ix = x % 900;			/* distance into table */
	q  = (x / 900) % 4; 	/* quadrant:  1 | 0 */
							/*			  --+-- */
	if (q&1)				/*			  2 | 3 */
		ix=900-ix;
	f.num = (int)SineTbl[ix];
	f.denom = 255;
	if (q>1)
		f.num = -f.num;

	return f;
}


/*  get cosine of angle
	in: x = angle in degrees*10
		-> FRACT struct to fill in
 */
FRACT cosine(int x) {
	return sine(x+900);
}

/*
transforming an arbitrary point (x,y) by angle p works like this: (for
rotation about point 0,0).

	matrix: +-	 -+    +-			  -+
			| a b |  = | cos(A) sin(A) |
			| c d |    |-sin(A) cos(A) |
			+-	 -+    +-			  -+

	x' = ax + cy    == cos(A)x - sin(A)y
	y' = bx + dy    == sin(A)x + cos(A)y

We can simplify by translating the lower-left corner of our rectangle to
zero, points to be transformed look like so.

		Q  0,y	   x,y	R
			+-------+
			|		|
			+-------+
		S  0,0	   x,0	T


	Qx = -sin(a)y
	Qy = cos(a)y
	Rx = cos(a)x -sin(a)y
	Ry = sin(a)x +cos(a)y
	Sx = 0
	Sy = 0
	Tx = cos(a)x
	Ty = sin(a)x

	or even simpler:

	Qx = -sin(a)y
	Qy = cos(a)y
	Sx = 0
	Sy = 0
	Tx = cos(a)x
	Ty = sin(a)x
	Rx = Tx + Qx
	Ry = Ty + Qy

	To improve accuracy, we should use pixels *4 or *8 in the calcs

	the min&max x/y coordinates become the new bounding rectangle

	r.left	 = MIN(MIN(qx,rx),MIN(sx,tx));
	r.top	 = MIN(MIN(qy,ry),MIN(sy,ty));
	r.right  = MAX(MAX(qx,rx),MAX(sx,tx));
	r.bottom = MAX(MAX(qy,ry),MAX(sy,ty));

 */

#if 0	/* need a more general-purpose function */

/*	Return bounding rectangle enclosing the rotated version of the input
	rectangle.

	Rotation is always about the lower-left corner of the rectangle.

	'a' is the rotation angle, counterclockwise from 'East' in
	degrees*10.
    
 */
void PASCAL TransformRect(int a, RECT* r)
{
	POINT	trans;
	POINT	ur;
	POINT	ul;
	POINT	lr;
	FRACT	fsin;
	FRACT	fcos;
	RECT	wr;

	trans.x = r->left;			/* vector to rotation point */
	trans.y = r->bottom;

	ur.x = r->right-r->left;	/* starting coordinates of upper-right corner */
	ur.y = r->bottom-r->top;	/* (ll translated to zero, w/+y moving up) */

#if 0
	ur.x <<2;					/* enlarge for precision */
	ur.y <<2;
#endif

	fsin = sine(a); 			/* get sine & cosine of our angle */
	fcos = cosine(a);
								/* rotate points */
	ul.x = -MulDiv(ur.y,fsin.num,fsin.denom);
	ul.y = MulDiv(ur.y,fcos.num,fcos.denom);
	lr.x = MulDiv(ur.x,fcos.num,fcos.denom);
	lr.y = MulDiv(ur.x,fsin.num,fsin.denom);
	ur.x = lr.x + ul.x;
	ur.y = lr.y + ul.y;

#if 0
	ul.x = (ul.x+2)>>2; 		/* reduce again */
	ul.y = (ul.y+2)>>2;
	lr.x = (lr.x+2)>>2;
	lr.y = (lr.y+2)>>2;
	ur.x = (ur.x+2)>>2;
	ur.y = (ur.y+2)>>2;
#endif

	/* find bounding rectangle (relative to rotation point)
	 */
	wr.left   = min(min(0,ul.x),min(lr.x,ur.x));
	wr.right  = max(max(0,ul.x),max(lr.x,ur.x));
	wr.top	  = max(max(0,ul.y),max(lr.y,ur.y));
	wr.bottom = min(min(0,ul.y),min(lr.y,ur.y));

	/* translate to rotation point & restore Y direction
	 */
	wr.left   = trans.x + wr.left;
	wr.right  = trans.x + wr.right;
	wr.top	  = trans.y - wr.top;
	wr.bottom = trans.y - wr.bottom;

	/*	give rect back to caller
	 */
	*r = wr;
}
#endif


/*	In this slower but more versatile version we can specify an
    arbitrary rotation point.
 */

/*	rotate point about origin by angle
 */
POINT TransPt(POINT p,FRACT fsin,FRACT fcos) {
	POINT pp;
	pp.x = MulDiv(p.x,fcos.num,fcos.denom) - MulDiv(p.y,fsin.num,fsin.denom);
	pp.y = MulDiv(p.x,fsin.num,fsin.denom) + MulDiv(p.y,fcos.num,fcos.denom);
	return pp;
}

/*	this version accepts an angle in 10ths of a degree
 */
POINT PASCAL TransformPtbyAngle(POINT p,int a) {
	FRACT	fsin;
	FRACT	fcos;

	fsin = sine(a); 					/* get sine & cosine of our angle */
	fcos = cosine(a);
	return TransPt(p,fsin,fcos);		/* rotate the point & return */
}


/*  Return bounding rectangle enclosing the rotated version of the input
	rectangle.
	'a' is the rotation angle, counterclockwise from 'East' in
	degrees*10.
 */
void PASCAL TransformRect(int a, LPRECT r, POINT o) {
	POINT	ur; 				/* the rectangle corner points */
	POINT	ul;
	POINT	lr;
	POINT	ll;
	FRACT	fsin;
	FRACT	fcos;
	RECT	wr;

	/* translate the rotation origin to zero
	   & y so postitve moves go up
	 */
	ul.x = ll.x = r->left	- o.x;
	ur.x = lr.x = r->right	- o.x;
	ul.y = ur.y = o.y - r->top;
	ll.y = lr.y = o.y - r->bottom;

	fsin = sine(a); 					/* get sine & cosine of our angle */
	fcos = cosine(a);
	ur = TransPt(ur,fsin,fcos); 		/* rotate the points */
	ul = TransPt(ul,fsin,fcos);
	lr = TransPt(lr,fsin,fcos);
	ll = TransPt(ll,fsin,fcos);

	/* find bounding rectangle (relative to rotation point)
	 */
	wr.left   = min(min(ll.x,ul.x),min(lr.x,ur.x));
	wr.right  = max(max(ll.x,ul.x),max(lr.x,ur.x));
	wr.top	  = max(max(ll.y,ul.y),max(lr.y,ur.y));
	wr.bottom = min(min(ll.y,ul.y),min(lr.y,ur.y));

	/* translate wr back to rotation point */

	wr.left   = wr.left  + o.x;
	wr.right  = wr.right + o.x;
	wr.top	  = o.y - wr.top;
	wr.bottom = o.y - wr.bottom;

	/*	& pass back to caller;
	 */
	*r = wr;
}
