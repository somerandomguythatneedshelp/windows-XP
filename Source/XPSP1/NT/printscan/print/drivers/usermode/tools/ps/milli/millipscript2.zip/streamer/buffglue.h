/*
    buffglue.h

    This header file declares the external functions for buffglue.c. 

           Copyright 1992-1994 -- Adobe Systems Incorporated
    PostScript is a registered trademark of Adobe Systems Incorporated.

    NOTICE:  All information contained herein or attendant hereto is, and
    remains, the property of Adobe Systems, Inc.  Many of the intellectual
    and technical concepts contained herein are proprietary to Adobe Systems,
    Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
    are protected as trade secrets.  Any dissemination of this information or
    reproduction of this material are strictly forbidden unless prior written
    permission is obtained from Adobe Systems, Inc.

*/
#ifndef BUFFGLUE_H
#define BUFFGLUE_H

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif
#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES
#include STREAMER

extern ReallocFunc MemoryRealloc;      /* Realloc routine provided by application */

PUBLIC void BufferFlush ARGDECL0();
PUBLIC IntX BufferChars ARGDECL2(Card8 *,s, Card32, len);
PUBLIC IntX BufferChar ARGDECL1(Card8, c);
PUBLIC IntX BufferString ARGDECL1(Card8 *,s);
PUBLIC IntX BufferStringEOL ARGDECL1(Card8 *,s);
PUBLIC IntX BufferInt ARGDECL1(Card32, i);
PUBLIC IntX BufferFixed ARGDECL1(Fixed, f);
PUBLIC IntX BufferTime ARGDECL0();
PUBLIC void FracToString ARGDECL3(Fixed, n, Card16, places, Card8 *, s);
PUBLIC IntX BufferInitialize ARGDECL2(Card32, len, PStreamerOpts, so);
PUBLIC void BufferDeinit ARGDECL1(PStreamerOpts, so);
PUBLIC IntX BufferError ARGDECL0();
PUBLIC Card32 BufferSize ARGDECL0();
PUBLIC IntX BufferInsert ARGDECL2(Card8 *, buf, Card32, len);
PUBLIC IntX BufferSetEEKey ARGDECL2(Card16, initialKey, Card8, eexec);
PUBLIC void BufferGetEEKey ARGDECL2(Card16 *, currentKey, Card8 *, eexecOpt);
PUBLIC IntX BufferAndEncrypt ARGDECL3(Card8 *, s, Card32, len, Card16 *, eeKey);
PUBLIC void BufferLock ARGDECL1(Card8, lockStatus);

/*************************************************************************

Function name:  BufferSave()

**************************************************************************

Date:           03/29/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Save the state of streamer's internal buffers
Description:    Save the buffer's state.  This state should be restored
                before reusing attempting to reuse the buffer.
                Use of this function and BufferRestore() allow multiple
                fonts to run through streamer approximately concurrently.

Parameters:     b -- points to the storage location

Return Values:  none
Notes:          Streamer functions Flush the data from the buffer when
                they exit.
See also:       BufferRestore(), StreamerStart()

**************************************************************************/

PUBLIC void BufferSave ARGDECL1(BufferStatus *, b);


/*************************************************************************

Function name:  BufferRestore()

**************************************************************************

Date:           03/29/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Restore a buffer state.
Description:    Restore a particular buffer's state.

Parameters:     b -- Points to the storage location

Return Values:  none
Notes:
See also:       BufferSave()

**************************************************************************/

PUBLIC void BufferRestore ARGDECL1(BufferStatus *, b);


#endif /* BUFFGLUE_H */


