/* CM_VerSion publictypes.h atm05 1.2 10076.eco sum= 39973 */
/* CM_VerSion publictypes.h atm04 1.8 07620.eco sum= 25666 */
/*
  publictypes.h

Copyright (c) 1984, '85, '86, '87, '88, '91 Adobe Systems Incorporated.
All rights reserved.

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript is a registered trademark of Adobe Systems Incorporated.
Display PostScript is a trademark of Adobe Systems Incorporated.

Original version: 
Edit History:
Craig Rublee: Thu Aug  8 15:55:35 1991
Scott Byer: Mon Jul 16 08:14:39 1990
Ivor Durham: Thu Aug 11 08:45:50 1988
Bill Paxton: Tue Apr 18 14:24:24 1989
Ramin Behtash: Wed Apr  1 18:37:36 1992
End Edit History.
*/

#ifndef	PUBLICTYPES_H
#define	PUBLICTYPES_H

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif

#ifndef PACKAGE_SPECS_H
#include PACKAGE_SPECS
#endif


#include <stdio.h>			/* Usually define NULL here */
#include ENVIRONMENT
/* include procs.h in middle of file */

#define	_inline
#define	_priv	extern

/* Control Constructs */

#define until(x) while (!(x))

#define endswitch default:;

/* Switch in and out assembly portions */

#ifndef	USE68KMATRIX
#define USE68KMATRIX		0
#endif	/* USE68KMATRIX */

#ifndef	USE68KCSCANASM
#define USE68KCSCANASM		0
#endif	/* USE68KCSCANASM */

#ifndef USE68KFONTBUILD
#define USE68KFONTBUILD		0
#endif	/* USE68KFONTBUILD */

/* Type boolean based derived from unsigned int */

typedef unsigned int boolean;

#define true 1
#define false 0

/* Various size integers and pointers to them */

typedef short int Int16, *PInt16;
typedef long int Int32, *PInt32;
typedef long int integer;


typedef integer (*PIntProc)();	/* pointer to procedure returning integer */

#define MAXInt32 ((Int32)0x7FFFFFFF)
#define MAXinteger ((integer)0x7FFFFFFF)
#define MINInt32 ((Int32)0x80000000)
#define MINinteger ((integer)0x80000000)
#define MAXInt16 ((Int16)0x7FFF)
#define MINInt16 ((Int16)0x8000)

/* Various size cardinals and pointers to them */

typedef unsigned char Card8, *PCard8;
typedef unsigned short int Card16, *PCard16;
typedef unsigned long int Card32, *PCard32;
typedef unsigned short int cardinal;
typedef unsigned long int longcardinal;


#define MAXCard32 ((unsigned long)0xFFFFFFFF)
#define MAXlongcardinal MAXCard32
#define MAXunsignedinteger MAXCard32
#define MAXCard16 0xFFFF
#define MAXcardinal MAXCard16
#define MAXCard8 0xFF

/* The following definitions of CardX and IntX differ from "int" and 
 * "unsigned int" in that they mean  "use whatever width you like".  
 * It is assumed to be at least 16 bits. If FORCE16BITS is true 
 * these types will be forced to 16 bits (short int). If FORCE32BITS
 * is true these types will be forced to 32 bits.
 */
#ifndef	FORCE16BITS
#define	FORCE16BITS	0
#endif	/* FORCE16BITS */

#ifndef FORCE32BITS
#define FORCE32BITS     0
#endif  /* FORCE32BITS */

#if FORCE16BITS
typedef unsigned short int CardX;
typedef short int IntX;
#elif FORCE32BITS
typedef unsigned long CardX;
typedef long IntX;
#else
typedef unsigned int CardX;
typedef int IntX;
#endif

/* Bit fields */

typedef unsigned BitField;

/* Reals and Fixed point */

typedef float real, *Preal;
typedef double longreal;

#if !MACROM || __GNUC__
typedef long int Fixed;		/* 16 bits of integer, 16 bits of fraction */
#elif OS==os_mpw
typedef long Fixed;			/* NZL - avoid including <Types.h> for the Mac */
#endif
typedef Fixed *PFixed;

/* Co-ordinates */

typedef real Component;

typedef struct _t_RCd {
  Component x,
            y;
} RCd, *PRCd;

typedef struct _t_FCd {
  Fixed x,
        y;
} FCd, *PFCd;


/* Characters and strings */

typedef unsigned char character, *string, *charptr;

/* Inline string function from C library */

#define	NUL	'\0'

/* Generic Pointers */

#ifndef NULL
#define	NULL	0
#endif

#define	NIL	NULL

typedef	void (*PVoidProc)();	/* Pointer to procedure returning no result */

/* Codes for exit system calls */

#if VAXC
#define exitNormal 1
#define exitError 2
#else
#define exitNormal 0
#define exitError 1
#endif

#if 0			/* Don't think we need this... MWB */
/* Generic ID for contexts, spaces, name cache, etc. */

#define	BitsInGenericIndex	10
#define	BitsInGenericGeneration	(32 - BitsInGenericIndex)

#define	MAXGenericIDIndex	((Card32)((1 << BitsInGenericIndex) - 1))
#define	MAXGenericIDGeneration	((Card32)((1 << BitsInGenericGeneration) - 1))

typedef union {
  struct {
    BitField index:BitsInGenericIndex;		/* Reusable component */
    BitField generation:BitsInGenericGeneration;/* Non-reusable component */
  } id;
  Card32  stamp;		/* Unique combined id (index, generation) */
} GenericID;			/* For contexts, spaces, streams, names, etc */
#endif


/* PROCS.H */
/*#include "procs.h"*/


/* Inline Functions */
#ifndef ABS
#define ABS(x) ((x)<0?-(x):(x))
#endif
#ifndef MIN
#define MIN(a,b) ((a)<(b)?(a):(b))
#endif
#ifndef MAX
#define MAX(a,b) ((a)>(b)?(a):(b))
#endif

/* Declarative Sugar */

#define forward extern
#if defined(WINATM) && defined(MAKEPUB)
#define PRIVATE
#else
#define PRIVATE static
#endif
#define PUBLIC
#define global extern
#define procedure void

#ifdef __STDC__
#define	readonly const
#else
#ifndef VAXC
#define readonly
#endif
#endif

#endif	/* PUBLICTYPES_H */
