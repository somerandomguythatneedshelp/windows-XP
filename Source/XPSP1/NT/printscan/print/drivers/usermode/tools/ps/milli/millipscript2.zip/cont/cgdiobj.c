/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: CGDIOBJ.C                                                     */
/*                                                                           */
/* Description: This module contains ...                                     */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_GRAPHSEG)


// These routines handle Brushes.

short FAR PASCAL CBrush(LPPDEVICE lppd)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTBrushStyle  )(lppd,lppd->brush.bStyle);
   (*tempptr->rTBrushHatch  )(lppd,lppd->brush.bHatch);
   (*tempptr->rTBrushBGColor)(lppd,lppd->brush.dBGColor);
   (*tempptr->rTBrushFGColor)(lppd,lppd->brush.dFGColor);
   return(TRUE);

}
short FAR PASCAL CBrushBGColor(LPPDEVICE lppd,DWORD Color)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTBrushBGColor)(lppd,Color);
   return(TRUE);
}
short FAR PASCAL CBrushFGColor(LPPDEVICE lppd,DWORD Color)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTBrushFGColor)(lppd,Color);
   return(TRUE);
}
short FAR PASCAL CBrushHatch(LPPDEVICE lppd,BYTE Hatch)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTBrushHatch)(lppd, Hatch);
   return(TRUE);
}
short FAR PASCAL CBrushPattern(LPPDEVICE lppd,LPPAT Pattern)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTBrushPattern)(lppd,Pattern);
   return(TRUE);
}
short FAR PASCAL CBrushStyle(LPPDEVICE lppd,BYTE Style)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTBrushStyle)(lppd,Style);
   return(TRUE);
}


// These routines handle Pens.

short FAR PASCAL CPen(LPPDEVICE lppd,LPPPEN Pen)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTPen)(lppd,Pen);
   return(TRUE);
}
short FAR PASCAL CPenCap(LPPDEVICE lppd,BYTE Cap)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTPenCap)(lppd,Cap);
   return(TRUE);
}
short FAR PASCAL CPenFGColor(LPPDEVICE lppd,DWORD Color)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTPenFGColor)(lppd,Color);
   return(TRUE);
}
short FAR PASCAL CPenBGColor(LPPDEVICE lppd,DWORD Color)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTPenBGColor)(lppd,Color);
   return(TRUE);
}
short FAR PASCAL CPenJoin(LPPDEVICE lppd,BYTE Join)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTPenJoin)(lppd,Join);
   return(TRUE);
}
short FAR PASCAL CPenMiterLimit(LPPDEVICE lppd,short MiterLimit)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTPenMiterLimit)(lppd,MiterLimit);
   return(TRUE);
}
short FAR PASCAL CPenStyle(LPPDEVICE lppd,BYTE Style)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTPenStyle)(lppd,Style);
   return(TRUE);
}
short FAR PASCAL CPenWidth(LPPDEVICE lppd,POINT Width)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTPenWidth)(lppd,Width);
   return(TRUE);
}



short FAR PASCAL CArc(LPPDEVICE lppd,LPRECT lpRect,LPPOINT lpStartPt,
                      LPPOINT lpStopPt)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTArc)(lppd,lpRect,lpStartPt,lpStopPt);
   return(TRUE);
}
short FAR PASCAL CChord(LPPDEVICE lppd,LPRECT lpRect,FLAG fFill,FLAG fStroke,
                        LPPOINT Start,LPPOINT Stop)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTChord)(lppd,lpRect,fFill,fStroke,Start,Stop);
   return(TRUE);
}
short FAR PASCAL CEllipse(LPPDEVICE lppd,LPRECT lpRect,FLAG fFill,FLAG fStroke)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTEllipse)(lppd,lpRect,fFill,fStroke);       // Execute proper T function
   return(TRUE);
}
short FAR PASCAL CCircle(LPPDEVICE lppd,LPRECT lpRect,FLAG fFill,FLAG fStroke)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTCircle)(lppd,lpRect,fFill,fStroke);       // Execute proper T function
   return(TRUE);
}
short FAR PASCAL CLine(LPPDEVICE lppd,LPPOINT lppt)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTLine)(lppd,lppt);
   return(TRUE);
}


short FAR PASCAL CPie(LPPDEVICE lppd,LPRECT lpRect,FLAG fFill,FLAG fStroke,
                      LPPOINT Start,LPPOINT Stop)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTPie)(lppd,lpRect,fFill,fStroke,Start,Stop);
   return(TRUE);
}
short FAR PASCAL CPolygon(LPPDEVICE lppd,LPPOINT lppt,FLAG fFill,FLAG fStroke,
                          FLAG eofill,short sNumPts)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTPolygon)(lppd,lppt,fFill,fStroke,eofill,sNumPts);
   return(TRUE);
}

short FAR PASCAL CPolyBezier(LPPDEVICE lppd,LPPOINT lppt,short sNumPts)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTPolyBezier)(lppd,lppt,sNumPts);
   return(TRUE);
}


short FAR PASCAL CPolyLine(LPPDEVICE lppd,LPPOINT lppt,short sNumPts)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTPolyLine)(lppd,lppt,sNumPts);
   return(TRUE);
}


short FAR PASCAL CRectangle(LPPDEVICE lppd,LPRECT lpRect,FLAG fFill,
                            FLAG fStroke)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTRectangle)(lppd,lpRect,fFill,fStroke);       // Execute proper T function
   return(TRUE);
}
short FAR PASCAL CRoundRectangle(LPPDEVICE lppd,LPRECT lpRect,FLAG fFill,
                                 FLAG fStroke,LPPOINT lppt)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTRoundRectangle)(lppd,lpRect,fFill,fStroke,lppt);       // Execute proper T function
   return(TRUE);
}
short FAR PASCAL CScanLine(LPPDEVICE lppd,LPPOINT Points,FLAG fFill,
                           FLAG fStroke,short sCount)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTScanLine)(lppd,Points,fFill,fStroke,sCount);
   return(TRUE);
}
short FAR PASCAL CScanLineBegin(LPPDEVICE lppd)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTScanLineBegin)(lppd);
   return(TRUE);
}
short FAR PASCAL CScanLineEnd(LPPDEVICE lppd)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTScanLineEnd)(lppd);
   return(TRUE);
}

short FAR PASCAL COpaqueBox(LPPDEVICE lppd,LPRECT DstRect,DWORD rgb, WORD Angle)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTOpaqueBox)(lppd,DstRect,rgb, Angle);
   return(TRUE);
}

short FAR PASCAL CBMOpaqueBox(LPPDEVICE lppd,LPRECT DstRect,DWORD rgb)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   (*tempptr->rTBMOpaqueBox)(lppd,DstRect,rgb);
   return(TRUE);
}
