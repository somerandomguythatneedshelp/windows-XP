/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: PAPER.H                                                */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

extern char decimalSeparator[4];

BOOL _loadds FAR PASCAL CHPaperDlg(HWND hdlg, unsigned msg, WORD wParam, 
                                   LONG lParam);

void FAR PASCAL ResetKeywordOption(LPPSEXTDEVMODE lpPSExtDevmode,
                                    LPPRINTERINFO lpPrinterInfo, 
                                    int iKeywordIndex);
void NEAR DIALOGSSEG PASCAL OrientationConversion(LPPSEXTDEVMODE lpPSExtDevmode,
                                                  LPWORD lpDimX, LPWORD lpDimY,
                                                  LPWORD lpDx1, LPWORD lpDy1,
                                                  LPWORD lpDx2, LPWORD lpDy2);
void NEAR DIALOGSSEG PASCAL GetPaperDimension(LPPDEVICE lppd,
                                   float FAR *lpDimX, float FAR *lpDimY);
void NEAR DIALOGSSEG PASCAL GetPaperDimensionAndArea(LPPDEVICE lppd, 
                                                     LPWORD lpDimX, 
                                                     LPWORD lpDimY, 
                                                     LPWORD lpX1, 
                                                     LPWORD lpY1, 
                                                     LPWORD lpX2, 
                                                     LPWORD lpY2);
void FAR PASCAL RestorePaperDefaults(LPPSEXTDEVMODE lpPSExtDevmode,
                                     LPWPXBLOCKS lpWPXBlock,
                                     DWORD dwUIFlags);


BOOL _loadds FAR PASCAL CHAdvancedPaperDlg(HWND hDlg, unsigned imsg,
                                           WORD wParam, LONG lParam);

