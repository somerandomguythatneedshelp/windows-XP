#ifndef _ENUMFONT_H
#define _ENUMFONT_H 1

#define FACENAME(lpFontDir, i)    ((LPSTR) (lpFontDir + i)->szFontName)
#define FAMILYNAME(lpFontDir, i)  ((LPSTR) (lpFontDir + i)->szFaceName)

#define MAGIC_FONTTYPE          2 // this is a magic number returned
                                  // to the client callback by EnumDFonts

typedef struct tagCALLBACKSTRUCT {
    FARPROC   lpCallbackProc;
    LP        lpClientData;
    LPPDEVICE lppd;
} CALLBACKSTRUCT, FAR* LPCALLBACKSTRUCT;

typedef short FAR PASCAL ENUMDFONTSCALLBACK(LPLOGFONT, LPTEXTMETRIC, WORD, LP);

/* NEAR functions - segment "_ENUM" */
BOOL NEAR ENUMSEG PASCAL SearchFontList(LPPDEVICE, LPSTR, LPFONTLIST, WORD, 
                                        LPWORD, BOOL);

/* FAR functions */
//move prototype of SearchFontDir to utils.h since code is in cutils.c
WORD FAR PASCAL EnumFontsCallback(LPFONTDIRECTORY, LP);
WORD FAR PASCAL DoEnumFonts(LPPDEVICE, ENUMTYPE, LPSTR, FARPROC, LP);
WORD NEAR PASCAL CreateTMandLogFont (LPPDEVICE, LPFONTDIRECTORY,
                                    LOGFONT *, LPTEXTMETRIC *);

/* Exported FAR functions */
WORD _loadds FAR PASCAL EnumDFonts(LP, LPSTR, FARPROC, LP);
WORD _loadds FAR PASCAL GetDevCharset(LP lpDevice, LPSTR lpszFaceName, 
                               FARPROC lpCallbackProc, LP lpClientData);

#endif /* ifndef _ENUMFONT_H */
