/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TUTILS.H                                                     */
/*                                                                           */
/* Description: This module contains the prototypes for TUTILS.C             */
/*                                                                           */
/*****************************************************************************/

typedef  DWORD  LANGID;
// 0804
#define  LANGUAGE_CS  0x30383034
// 0404
#define  LANGUAGE_CT  0x30343034
// 0411
#define  LANGUAGE_J   0x30343131
// 040C
#define  LANGUAGE_K   0x30343043
// 0409
#define  LANGUAGE_Eng 0x30343039

LANGID GetSystemDefaultLangID(VOID);

 
VOID FAR PASCAL TInitGraphicState(LPPDEVICE lppd);
VOID FAR PASCAL TSetPen(LPPDEVICE lppd);
VOID FAR PASCAL TSetBrush(LPPDEVICE lppd);
VOID FAR PASCAL InitProcsetList( LPPDEVICE lppd );
short FAR PASCAL AddProcsetRecord(LPPDEVICE lppd, short Psetnumber);
short FAR PASCAL TokenNeedsProcset(LPPDEVICE lppd, short Procset);
short FAR PASCAL procsetsendprocs(LPPDEVICE lppd, short procsettype);
short FAR PASCAL endprocsetdownload(LPPDEVICE lppd);
void FAR PASCAL PSSetNoCurrentPoint(LPPDEVICE lppd);
BOOL FAR PASCAL RLEDecodeNeeded(LPPDEVICE lppd);
DWORD FAR PASCAL RLEncode(BYTE huge *lpHugeBuf, long inlen, 
                          BYTE huge *lpoutbytes);
void FAR PASCAL PSSendNegativeImage(LPPDEVICE lppd, BOOL);
VOID FAR PASCAL ResetPatternCache(LPPDEVICE lppd);
int  FAR PASCAL SavePassthroughInfo(LPPDEVICE lppd);
int  FAR PASCAL PrintPassthroughInfo(LPPDEVICE lppd, int iCount);
VOID FAR PASCAL PrintPassthroughEndDSC(LPPDEVICE lppd);

