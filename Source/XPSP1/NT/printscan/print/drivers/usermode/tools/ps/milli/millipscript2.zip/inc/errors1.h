/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ERRORS1.H                                                    */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/

enum
{
   C_begin,
   C_create=0,C_open,C_read,C_write,C_close,C_seek,
   C_memory,C_quasifile,C_file,C_immediate,
   C_translate,
   C_end
};

enum
{
   E_begin,
   E_OK=0,
   E_fatal,E_fail,E_warning,E_alert,
   E_end
};

enum
{
   RC_begin,
   RC_ok=0,
   RC_status,
   RC_file,
   RC_end
};


