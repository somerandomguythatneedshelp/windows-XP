/*
  mon.h

Copyright (c) 1991-1992 Adobe Systems Incorporated.
All rights reserved.

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript is a registered trademark of Adobe Systems Incorporated.
Display PostScript is a trademark of Adobe Systems Incorporated.

Original version: John Nogrady
Edit History:
John Nogrady: Fri Jan 10 15:26:48 1992
End Edit History.
Revision History
  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/MON.H_V  $
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:07:24   unknown
 *- |Initial revision.
End Revision History.
*/

#ifndef	MON_H
#define	MON_H

/* Dummy header file to make ps_manager happy */
/* in buildch package, PSsupp_h.h includes MON */

#endif	/* MON_H */
