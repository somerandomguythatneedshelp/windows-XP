/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1999 Adobe Systems Inc. All rights reserved.                */
/*                                                                           */
/* Module Name: LZWEBUF.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for the LZW encoding      */
/*                                                                           */
/* Original version: Ed McCreight: 17 Feb 90                                 */
/* Edit History:                                                             */
/* Ross Thompson: Sun Mar 16 12:24:22 1997                                   */
/* Alex Freed: Wed May 27 11:50:51 1992                                      */
/* Ed McCreight: 19 Feb 1999                                                 */
/* End Edit History.                                                         */
/*                                                                           */
/*                                                                           */
/*  The LZW compression method is said to be the subject of patents          */
/*  owned by the Unisys Corporation.  For further information, consult       */
/*  the PostScript Language Reference Manual, second edition                 */
/*  (Addison Wesley, 1990, ISBN 0-201-18127-4).                              */
/*                                                                           */
/*  This source code is provided to you by Adobe on a non-exclusive,         */
/*  royalty-free basis to facilitate your development of PostScript          */
/*  language programs.  You may incorporate it into your software as is      */
/*  or modified, provided that you include the following copyright           */
/*  notice with every copy of your software containing any portion of        */
/*  this source code.                                                        */
/*                                                                           */
/* Copyright 1990-1993 Adobe Systems Incorporated.  All Rights Reserved.     */
/*                                                                           */
/* Adobe does not warrant or guarantee that this source code will            */
/* perform in any manner.  You alone assume any risks and                    */
/* responsibilities associated with implementing, using or                   */
/* incorporating this source code into your software.                        */
/*                                                                           */
/*****************************************************************************/

#include <stdlib.h> /* Using: NULL */
#include <memory.h> /* Using: memset */
#include "lzwbuf.h"

#define HASHSIZE 8191   /* prime, approx == 2*LZWMAXCODE */

#define CTOFFSET  NLITCODES(8 /* unitLen */ )

typedef unsigned short HashEntry, ASFAR * HashEntryPtr;

typedef struct _t_LZWE_PDataRec
{
   BitBufRec bb[1];
   int curCodeLen; /* 9-12 bits */
   int prevCodeWord;
   int nextAvailCodeWord;
   long int limCodeWordThisLen;
   HashEntryPtr hashTab; /* [HASHSIZE] */
   LZWCode zc; /* [LZWMAXCODE] */
}
PDataRec, *PData;

typedef struct _t_LZWCWS {
   HashEntry hashTab[HASHSIZE];
   LZWCodeRec zc[LZWMAXCODE];
} LZWCWSRec, ASFAR * LZWCWS;


/*****************************************************************************/
/*                 LZWCompressWorkSpaceSize                                  */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/
size_t LZWCompressWorkSpaceSize()
{
   return sizeof(LZWCWSRec);
}

#define Synch()

/*****************************************************************************/
/*                 lZWEAdjustCodeLen                                         */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*                                                                           */
/* Remarks:                                                                  */
/* The odd capitalization of the function name is a memorial                 */
/*    to a post-compilation assembler for the Intel 960 that thought         */
/*    the original name was a local jump target.                             */
/*                                                                           */
/*****************************************************************************/
static void lZWEAdjustCodeLen( PData pd, long nextAvailCodeWord )
{
   while ((pd->limCodeWordThisLen <= nextAvailCodeWord) &&
          (pd->curCodeLen < LZWMAXCODELEN ))
   {
      pd->curCodeLen++;
      pd->limCodeWordThisLen =
      (pd->limCodeWordThisLen << 1);
   }
}

/*****************************************************************************/
/*                 LZWESetLimits                                             */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/
static void LZWESetLimits(PData pd)
{
   pd->curCodeLen = LZWMINCODELEN(8);
   pd->limCodeWordThisLen = (1 << LZWMINCODELEN(8));
   lZWEAdjustCodeLen(pd, pd->nextAvailCodeWord - 1);
}

/*****************************************************************************/
/*                 LZWEClearInit                                             */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/
static void LZWEClearInit(PData pd)
{
   pd->curCodeLen = LZWMINCODELEN(8);
   pd->limCodeWordThisLen = (1 << LZWMINCODELEN(8));
   pd->nextAvailCodeWord = NLITCODES(8);
   pd->prevCodeWord = -1;
   pd->zc[0].prevCodeWord = LZWMAXCODE + 1; /* sentinel */
   memset((void *)pd->hashTab, (ASUns8) 0,
          (size_t) (HASHSIZE*sizeof(pd->hashTab[0])));
}

#define NoteCollision(n)

#define FIRSTHASHFN(pcw , ch)               \
  ((pcw) + 8 * (ch)) /* 0 <= x < (HASHSIZE - 1000) */
#define SECONDHASHFN(pcw , ch, fhf)              \
  ((HASHSIZE - 100) - ((ch) + (fhf)))
      /* 0 < x < HASHSIZE, x is relatively prime to HASHSIZE
        (since HASHSIZE itself is prime) and not 0, so it
        generates the ring of integers modulo HASHSIZE.
      */
       
/*****************************************************************************/
/*                 HashEntryPtr                                              */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/
static HashEntryPtr LZWEHash( PData pd, int ch )
{
   int hti = FIRSTHASHFN(pd->prevCodeWord, ch);
   HashEntry * htp = pd->hashTab + hti;
   LZWCode zcCur = pd->zc + *htp;
   if (
       !(
         (zcCur->prevCodeWord == (ASUns16)pd->prevCodeWord) &&
         /* pd->zc[0].prevCodeWord == LZWMAXCODE + 1, as sentinel */
         (zcCur->finalChar == ch)
        ) /* it doesn't match */ &&
        (*htp != 0) /* there was a collision */
      )
   {
      int delta = SECONDHASHFN(pd->prevCodeWord, ch, hti);
      LZWCode zcCur;
#if STAGE == DEVELOP
      int hti0 = hti;
#endif /* STAGE == DEVELOP */
      NoteCollision(0);
      do
      {
         NoteCollision(1);
         if ( HASHSIZE <= (hti += delta) )
            hti -= HASHSIZE;
         ASDebugAssert( (0 <= hti) && (hti < HASHSIZE) && (hti != hti0) );
         /* hash failed -- should be impossible */
         zcCur = pd->zc + pd->hashTab[hti];
      } while (
               (zcCur != pd->zc) &&
               (
                (zcCur->prevCodeWord != (ASUns16)pd->prevCodeWord) ||
                (zcCur->finalChar != ch)
               )
              );
      htp = &pd->hashTab[hti];
   }
   return htp;
}

/*****************************************************************************/
/*                 FPutBB                                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/
static void FPutBB(unsigned code, int codeLen, BitBuf bb)
{
   bb->residue = (bb->residue << codeLen) | code;
   bb->residueLen += codeLen;
   while ( 8 <= bb->residueLen )
   {
      bb->residueLen -= 8;
      if ( bb->ix < bb->size )
      bb->buf[bb->ix] = (bb->residue >> bb->residueLen) & 0xFF;
      bb->ix++;
   }
}

#define PutBB FPutBB

/*****************************************************************************/
/*                 LZWCompressBufInner                                       */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*      returns number of chars of output, or LZW_RESULT_x.                  */
/*      If result > outCnt, chars beyond outCnt are not written to outBuf    */
/*      ws is a work space of size at least LZWEncodeWorkSpaceSize() bytes.  */
/*****************************************************************************/
long LZWCompressBufInner(ASUns8FP inBuf, long inCnt, ASUns8FP outBuf, long outCnt,
                         ASUns8FP ws)
{
   PDataRec pd[1];
   ASUns8P buf, bufLim;
   
   memset((ASUns8P) pd, (ASUns8) 0, sizeof(PDataRec));
   
   if ( ws == (ASUns8FP) NULL )
      return LZW_RESULT_ALLOC_ERR;
   pd->hashTab = ((LZWCWS)ws)->hashTab;
   pd->zc = ((LZWCWS)ws)->zc;
   
   pd->bb->buf = outBuf;
   pd->bb->size = outCnt;
   
   LZWEClearInit(pd);
   FPutBB(LZW_CLEAR(8), pd->curCodeLen, pd->bb);
   Synch();

   for ( buf = inBuf, bufLim = inBuf + inCnt; buf < bufLim; buf++ )
   {
      int ch = *buf & 0xFF /* inMask */;

      if (pd->prevCodeWord < 0)
         pd->prevCodeWord = ch;
      else
      {
         /* This is a slightly modified inline expansion of LZWEHash
            for speed.
         */
         int hti = FIRSTHASHFN(pd->prevCodeWord, ch);
         HashEntry * htp = pd->hashTab + hti;
         LZWCode zcCur = pd->zc + *htp;
         if (
             /* it matches */
             (zcCur->prevCodeWord == (ASUns16)pd->prevCodeWord) &&
             /* pd->zc[0].prevCodeWord == LZWMAXCODE + 1, as sentinel */
             (zcCur->finalChar == ch)
            )
            pd->prevCodeWord = *htp;
            /* this extension is already in the table, continue... */
         else
         {
            if ( *htp != 0 )
            {
               /* There was a collision.  Try to resolve it. */
               int delta = SECONDHASHFN(pd->prevCodeWord, ch, hti);
               LZWCode zcCur;
#if STAGE == DEVELOP
               int hti0 = hti;
#endif /* STAGE == DEVELOP */
               NoteCollision(0);
               do
               {
                  NoteCollision(1);
                  if ( HASHSIZE <= (hti += delta) )
                     hti -= HASHSIZE;
                  ASDebugAssert( (0 <= hti) && (hti < HASHSIZE) && (hti != hti0) );
                  /* hash failed -- should be impossible */
                  zcCur = pd->zc + pd->hashTab[hti];
               } while (
                        (zcCur != pd->zc) &&
                        (
                         (zcCur->prevCodeWord != (ASUns16)pd->prevCodeWord) ||
                         (zcCur->finalChar != ch)
                        )
                       );
               htp = &pd->hashTab[hti];
            }

            if ( *htp != 0 )
                pd->prevCodeWord = *htp;
            /* collision resolved to desired extension, which
              is already in the table, continue...
            */
            else
            {
               /* Desired extension is not yet in the
               table.  The range of possible emitted codewords
               is [0..pd->nextAvailCodeWord).  pd->curCodeLen bits must be
               sufficient to express pd->nextAvailCodeWord-1.
               */
               PutBB(pd->prevCodeWord, pd->curCodeLen, pd->bb);
               Synch();

               if ( pd->limCodeWordThisLen <= pd->nextAvailCodeWord )
               {
                  if ( LZWMAXCODE <= pd->nextAvailCodeWord )
                  {
                     /* The table is full.  Don't extend it. */
                     goto EExtensionDone;
                  }
                  else
                  {
                     /* pd->curCodeLen bits no longer suffice to hold
                        pd->nextAvailCodeWord.  Increase pd->curCodeLen.
                     */
                     lZWEAdjustCodeLen(pd, pd->nextAvailCodeWord);
                  }
               }

               /* Extend the table */
               zcCur = pd->zc + pd->nextAvailCodeWord;
               zcCur->prevCodeWord = pd->prevCodeWord;
               zcCur->finalChar = ch;
               *htp = pd->nextAvailCodeWord++;

EExtensionDone:
               pd->prevCodeWord = ch;
            }
         }
      }
   }

   if (0 <= pd->prevCodeWord)
   {
      FPutBB(pd->prevCodeWord, pd->curCodeLen, pd->bb);
      Synch();
      lZWEAdjustCodeLen(pd, pd->nextAvailCodeWord);
      pd->prevCodeWord = -1;
   }
   FPutBB(LZW_EOD(8), pd->curCodeLen, pd->bb);
   Synch();
   if ( 0 < pd->bb->residueLen )
      FPutBB(0, (- pd->bb->residueLen) & 0x07, pd->bb);
      /* finish out the last byte with 0's */

   return pd->bb->ix;
}

/*****************************************************************************/
/*                 LZWCompressBuf                                            */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/
long LZWCompressBuf(ASUns8FP inBuf, long inCnt, ASUns8FP outBuf, long outCnt)
{
   LZWCWSRec *pCws;
   long result;
  
   pCws = (LZWCWSRec *)malloc( sizeof(LZWCWSRec) );
   if( pCws )
   {
      result = LZWCompressBufInner(inBuf, inCnt, outBuf, outCnt, (ASUns8FP) pCws);
      free( pCws );
   }
   else
      result = LZW_RESULT_ALLOC_ERR;
          
   return result;
}
