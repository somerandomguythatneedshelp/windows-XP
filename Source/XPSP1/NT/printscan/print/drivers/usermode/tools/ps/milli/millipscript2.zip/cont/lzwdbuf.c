/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1999 Adobe Systems Inc. All rights reserved.                */
/*                                                                           */
/* Module Name: LZWDBUF.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for the LZW decoding      */
/*                                                                           */
/* Original version: Ed McCreight: 17 Feb 90                                 */
/* Edit History:                                                             */
/* Ross Thompson: Sun Mar 16 12:23:54 1997                                   */
/* Edward Fiala: Thu Mar 28 14:17:00 PST 1996                                */
/* Alex Freed:   Wed May 27 11:49:22 1992                                    */
/* Ed McCreight: 19 Feb 99                                                   */
/* End Edit History.                                                         */
/*                                                                           */
/*                                                                           */
/*  The LZW compression method is said to be the subject of patents          */
/*  owned by the Unisys Corporation.  For further information, consult       */
/*  the PostScript Language Reference Manual, second edition                 */
/*  (Addison Wesley, 1990, ISBN 0-201-18127-4).                              */
/*                                                                           */
/*  This source code is provided to you by Adobe on a non-exclusive,         */
/*  royalty-free basis to facilitate your development of PostScript          */
/*  language programs.  You may incorporate it into your software as is      */
/*  or modified, provided that you include the following copyright           */
/*  notice with every copy of your software containing any portion of        */
/*  this source code.                                                        */
/*                                                                           */
/* Copyright 1990-1993 Adobe Systems Incorporated.  All Rights Reserved.     */
/*                                                                           */
/* Adobe does not warrant or guarantee that this source code will            */
/* perform in any manner.  You alone assume any risks and                    */
/* responsibilities associated with implementing, using or                   */
/* incorporating this source code into your software.                        */
/*                                                                           */
/*****************************************************************************/

#include <stdlib.h> /* Using: NULL */
#include <memory.h> /* Using: memset */
#include "lzwbuf.h"

typedef struct _t_LZWD_PDataRec
{
   long int curCodeLen; /* (unitLen+1)..12 bits */
   unsigned int curCodeMask;
   long int limCodeWordThisLen;
   ASUns16 prevCodeWord;
      /*
        limCodeWordThisLen <= NLITCODES means that there
        is no previous code word
      */
   long int nextAvailCodeWord;
   LZWCode zc;
      /* [LZWMAXCODE+1] .. allows for
         .seqlen = LZW_SEQLEN_UNDEF beyond end
      */
} PDataRec, *PData;

typedef struct _t_LZWDWS {
   LZWCodeRec zc[LZWMAXCODE + 1];
} LZWDWSRec, ASFAR * LZWDWS;



/*****************************************************************************/
/*                 LZWDecompressWorkSpaceSize                                */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/
size_t LZWDecompressWorkSpaceSize()
{
   return sizeof(LZWDWSRec);
}

/*****************************************************************************/
/*                 lZWDSetCodeMask                                           */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*                                                                           */
/* Remarks:                                                                  */
/*    The odd capitalization of the function name is a memorial              */
/*    to a post-compilation assembler for the Intel 960 that thought         */
/*    the original name was a local jump target.                             */
/*                                                                           */
/*****************************************************************************/
static void lZWDSetCodeMask( PData pd )
{
   pd->curCodeMask = (1 << pd->curCodeLen) - 1;
   pd->limCodeWordThisLen = pd->curCodeMask;
}


/*****************************************************************************/
/*                 LZWDIncreaseCodeLen                                       */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/
static void LZWDIncreaseCodeLen( PData pd )
{
   ++pd->curCodeLen;
   lZWDSetCodeMask(pd);
}

/*****************************************************************************/
/*                 LZWDClearCode                                             */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/
static void LZWDClearCode( PData pd )
{
   pd->curCodeLen = LZWMINCODELEN(8);
   lZWDSetCodeMask(pd);
   pd->limCodeWordThisLen = NLITCODES(8);
   pd->nextAvailCodeWord = NLITCODES(8);
   pd->zc[pd->nextAvailCodeWord].seqLen = LZW_SEQLEN_UNDEF;
   /* mark as undefined */
}

/*****************************************************************************/
/*                 LZWDExtendTable                                           */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/
static void LZWDExtendTable( PData pd, ASUns8 lastCh )
{
   if (pd->nextAvailCodeWord < LZWMAXCODE)
   {
      /* Table isn't full. */
      if (NLITCODES(8) < pd->limCodeWordThisLen)
      {
         /* Previous code word exists. */
         LZWCode zc = &pd->zc[pd->nextAvailCodeWord];
         int pcwl = pd->zc[pd->prevCodeWord].seqLen;
         
         /* Extend the table */
         zc->finalChar = lastCh;
         ASDebugAssert(pd->prevCodeWord != LZW_CLEAR(8));
         zc->prevCodeWord = pd->prevCodeWord;
         zc->seqLen = LZW_INCREMENT_SEQLEN(pcwl);
         zc[1].seqLen = LZW_SEQLEN_UNDEF;
         
         /* Extend the codeword length if necessary and possible */
         if ( (pd->limCodeWordThisLen <= pd->nextAvailCodeWord) &&
              (pd->curCodeLen < LZWMAXCODELEN) )
         {
            ASDebugAssert(pd->curCodeMask == (pd->nextAvailCodeWord));
            LZWDIncreaseCodeLen(pd);
         }
         pd->nextAvailCodeWord++;
      }
      else
         lZWDSetCodeMask(pd);
         /* if this was the first code after start-up or a clear */
   }
}

/*****************************************************************************/
/*                 LZWDecompressBufInner                                     */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*      returns number of chars of output, or LZW_RESULT_x.                  */
/*      If result > outCnt, chars beyond outCnt are not written to outBuf    */
/*      ws is a work space of size at least LZWDecodeWorkSpaceSize() bytes.  */
/*****************************************************************************/
long LZWDecompressBufInner(ASUns8FP inBuf, long inCnt, ASUns8FP outBuf, long outCnt,
                           ASUns8FP ws)
{
   PDataRec pd[1];
   long int residueLen = 0;
   unsigned int residue = 0;
   long inIdx = 0;
   long outIdx = 0;
   unsigned int i;
       
   memset((ASUns8P) pd, (ASUns8) 0, (size_t) sizeof(pd[0]));
   
   if ( ws == (ASUns8FP) NULL )
      return LZW_RESULT_ALLOC_ERR;
   pd->zc = ((LZWDWS)ws)->zc;

   /* Initialize the first part of the code table */
   for (i = 0; i < (unsigned int)LZW_CLEAR(8); i++)
   {                          
      ASUns8 x = (ASUns8)i;
         
      LZWCode zce = &pd->zc[i];
      zce->finalChar = x & ((1 << 8) - 1);
      zce->seqLen = 0;
      zce->prevCodeWord = i; /* loop to same code */
   }
   for ( ; i < (unsigned int)NLITCODES(8); i++)
   {
      LZWCode zce = &pd->zc[i];
      zce->finalChar = 0;
      zce->seqLen = LZW_SEQLEN_SPECIAL;
      zce->prevCodeWord = 0;
   }

   LZWDClearCode(pd);

   for ( ;; )
   {
      int curCode;
      LZWCode zc;

      /* Read a codeword from the input stream.  The codeword
         lies in the interval [0..nextAvailCodeWord].
      */

      /* Make sure we have enough bit residue left */

      while (residueLen < pd->curCodeLen)
      {
         if ( inCnt <= inIdx )
            goto ByteStmEnd;
         residue = (residue << 8) | inBuf[inIdx++];
         residueLen += 8;
      }
      residueLen -= pd->curCodeLen;
      curCode = (residue >> residueLen) & pd->curCodeMask;

      if ( pd->nextAvailCodeWord < curCode )
         goto BadInputCode;

      zc = &pd->zc[curCode];

      for ( ;; )
      {
         int seqLen = zc->seqLen;
         if ( seqLen <= LZW_SEQLEN_LONG )
         {
            int ofst;
            if (seqLen == LZW_SEQLEN_LONG)
            {
               /* long sequence of unknown length >= (LZW_SEQLEN_LONG + 1) */
               LZWCode zcp;
               for
               (
                 zcp = &pd->zc[zc->prevCodeWord];
                 (zcp->seqLen == LZW_SEQLEN_LONG);
                 zcp = &pd->zc[zcp->prevCodeWord]
               )
                  seqLen++;
            }

            /* sequence of length exactly (seqLen + 1) */
            for ( ofst = seqLen; 0 <= ofst; ofst-- )
            {
               if ( (outIdx + ofst) < outCnt )
                  outBuf[outIdx + ofst] = zc->finalChar;
               zc = &pd->zc[zc->prevCodeWord];
            }
            outIdx += (seqLen + 1);
            LZWDExtendTable(pd, zc->finalChar);
            goto NextCodeword;
         }
         else if ( seqLen == LZW_SEQLEN_SPECIAL )
         {
            /* Encoder sent either LZW_CLEAR or LZW_EOD */
            if (curCode == LZW_EOD(8))
               return outIdx;
            else
            {
               LZWDClearCode(pd);
               goto NextCodeword;
            }
         }
         else /* seqLen == LZW_SEQLEN_UNDEF */
         {
            /* This is the one confusing case of LZW decoding.
            The encoder has asked us to decode a code that is not
            yet in our table.  It must be the next code that we're going
            to put into our table; otherwise neither would it yet be in the
            encoder's table.
                     
            Let lower-case letters represent single characters and upper-case
            letters represent (possibly empty) strings.
                     
            Suppose, without
            loss of generality, that the encoder was encoding the string
            ABcDE, and that the beginning of B corresponded to a codeword
            boundary, and that the string B was then in the encoder's table,
            but the string Bc was not.  The encoder would then send the
            codeword representing B, and add Bc to the table.
                     
            Then suppose that the codeword that the encoder found for
            cD was the same as that for the new entry Bc.  Then c must
            be identical to the first character of B.
            */
            LZWCode zcp;
            if(pd->limCodeWordThisLen <= NLITCODES(8)) /* prefix doesn't exist */
               goto BadInputCode;

            /* Patch the table and try this code word again */
            zcp = &pd->zc[(zc->prevCodeWord = pd->prevCodeWord)];
            zc->seqLen = LZW_INCREMENT_SEQLEN(zcp->seqLen);
            while (0 < zcp->seqLen)
               zcp = &pd->zc[zcp->prevCodeWord];
            ASDebugAssert(zcp->seqLen == 0);
            zc->finalChar = zcp->finalChar;
         }
      }

      NextCodeword:
      pd->prevCodeWord = curCode;
   }

   ByteStmEnd: ;
    /* We ran off the end of the input buffer before we saw
      an LZW_EOD code.
    */
   BadInputCode:
   return LZW_RESULT_FORMAT_ERR;
}

/*****************************************************************************/
/*                 LZWDecompressBuf                                          */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*      returns number of chars of output, or LZW_RESULT_x.                  */
/*      If result > outCnt, chars beyond outCnt are not written to outBuf    */
/*****************************************************************************/
long LZWDecompressBuf(ASUns8FP inBuf, long inCnt, ASUns8FP outBuf, long outCnt)
{
   LZWDWSRec *pDws;
   long result = 0;
  
   pDws = (LZWDWSRec *)malloc( sizeof(LZWDWSRec) );
   if( pDws )
   {
      result = LZWDecompressBufInner(inBuf, inCnt, outBuf, outCnt, (ASUns8FP) pDws);
      free( pDws );
   }
   else
      result = LZW_RESULT_ALLOC_ERR;
  
   return result;
}

