/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DRVSTATE.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for the DRIVE STATE       */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_UTILSSEG)


//default DrvState values

#define DSbfusecolor FALSE
#define DSbfcolordevice FALSE
#define DSborientation DMORIENT_PORTRAIT
#define DSsmathres RES
#define DSDeviceResolution {RES, RES}     // {300, 300} usually
#define DSbjobEPS FALSE            // normal job -- not eps
#define DSbimagecompression 0
#define DSbimagedatatype 0
#define DSsscreenangle 45
#define DSsscreenfrequency {SF_INCHES,60}
#define DSptpaperdim {((RES*8)+((RES+1)/2)),RES*11}
#define DSimagerect {(RES+2)/4,(RES+2)/4,((RES*8)+((RES+1)/2))-(RES+2)/4,RES*11-(RES+2)/4}
#define DSbfpsfilesystem FALSE
#define DSbfpsprolog 1
#define DSbfadjustmatriz FALSE
#define DSmatrixadjust {1,0,0,0,1,0,0,0,1}

#define POINTS_PER_INCH    72
#define rndp(x)            ((int) (x+0.5))  // Rounds positive float to nearest integer

// char szDefaultPrinter[16];
// LONG OldTime = 0L; /* OK for multitasking since this is only used to avoid   */
		   /* bringing the use default printer message repeatedly.   */
		   /* If value gets screwed up by preemptive, not a problem. */

#if 0    // Do we need this? - ShyamV
/*****************************************************************************/
/*                                                                           */
/*                        LocateMissingPrinter                               */
/* Function:                                                                 */
/*    Execute this routine if app gave us a bad port and we are trying       */
/*    to recover some appropriate settings.                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   LPSTR lpDevType                                                         */
/*   LPSTR lpNickName                                                        */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE  => if success,                                                    */
/*   FALSE => if failure,                                                    */
/*****************************************************************************/
BOOL LocateMissingPrinter(LPSTR lpDevType, LPSTR lpNickName)
{
   char strBuff[MAX_PORT_NAME];
   char portsArray[MAX_PORT_NAME * 16]; /* Limitation on 16 ports */
   LPSTR lpTestPort;
   int TestPortLen;

   /* Grab the list of ports in win.ini */
   LoadString(ghDriverMod, GLBL_szPortsSection, strBuff, sizeof(strBuff));
   GetProfileString(strBuff, NULL, "", portsArray, sizeof(portsArray));
   lpTestPort = portsArray;

   while (lstrlen(lpTestPort) > 0)
   {
      Ps_ExtQueryPrinterAtPort(lpTestPort, lpDevType,
			      lpNickName,
			      MAX_NICKNAME_LEN) ;

      if (*lpNickName != '\0')
      {
	 return(TRUE);
      }

      TestPortLen = lstrlen(lpTestPort);
      lpTestPort = lpTestPort + TestPortLen + 1; /* Take care of the NULL terminator */
   }
   return (FALSE);
}
#endif   // 0


/***************************************************************************/
/*                                                                         */
/*                          DrvStateRead                                   */
/*  function:                                                              */
/*       This routine reads in a DRVSTATE structure describing the current */
/*      parameters for the printer at the specified port from the printer  */
/*      database. If the database does not have a record for the specified */
/*       printer, then 'sensible' defaults are returned.                   */
/*  arguments:                                                             */
/*       lppd -- ptr to PDEVICE which needs to be updated                  */
/*       lpPSExtDevmode -- ptr to PSEXTDEVMODE which is to be used for     */
/*                                                                         */
/*                                                                         */
/*  returns: RC_ok if no fatal error occurs, else RC_fail.                 */
/*           Note that most errors encountered by this routine shall be    */
/*           regarded as not fatal, and will therefore be ignored.         */
/*                                                                         */
/***************************************************************************/
WORD FAR PASCAL DrvStateRead(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode)
{
    POINT    ptCorner;
    PSMATRIX tempMatrix;
    WORD     rc = RC_ok;
	 RECT     paperRect ;

   // When do I plug in Default printer info. anyway? - ShyamV

   // Determine paper infoin points. 
   // DO NOT account for orientation before returning paper metrics.
   GetPPDPaperMetrics(lppd, lpPSExtDevmode);

   SetCTMatrix(lppd, lpPSExtDevmode, (LPPOINT) &ptCorner); // Sets lppd->psmatrix

   if ( (lpPSExtDevmode->dm.PaperOrient == OR_ROTLANDSCAPE) ||
	(lpPSExtDevmode->dm.PaperOrient == OR_LANDSCAPE) )
   {
       /* swap resolutions */
       short tmp;

       tmp = lppd->DeviceRes.x_res;
       lppd->DeviceRes.x_res = lppd->DeviceRes.y_res;
       lppd->DeviceRes.y_res = tmp;
   }

   // Transform Paper dimensions and Imageable area to GDI coordinates/units.
   tempMatrix[0] = lppd->psmatrix[0];
   tempMatrix[1] = lppd->psmatrix[1];
   tempMatrix[2] = lppd->psmatrix[2];
   tempMatrix[3] = lppd->psmatrix[3];
   tempMatrix[4] = (float) ptCorner.x;
   tempMatrix[5] = (float) ptCorner.y;

	paperRect.bottom = paperRect.left = 0;
	paperRect.right =  lppd->ptPaperDim.x ;
	paperRect.top =  lppd->ptPaperDim.y ;

   DefaultPStoGDI((LPPSMATRIX) tempMatrix, (LPSHORT) &paperRect.left, 
		  (LPSHORT) &paperRect.top);
   DefaultPStoGDI((LPPSMATRIX) tempMatrix, (LPSHORT) &paperRect.right, 
		  (LPSHORT) &paperRect.bottom);

   GDIorderRect((LPRECT) &paperRect);
	lppd->ptPaperDim.x = paperRect.right ;
	lppd->ptPaperDim.y = paperRect.bottom ;


   DefaultPStoGDI((LPPSMATRIX) tempMatrix, (LPSHORT) &lppd->imageRect.left, 
		  (LPSHORT) &lppd->imageRect.top);
   DefaultPStoGDI((LPPSMATRIX) tempMatrix, (LPSHORT) &lppd->imageRect.right, 
		  (LPSHORT) &lppd->imageRect.bottom);

   GDIorderRect((LPRECT) &lppd->imageRect);

   return rc ;
}

//
/****************************************************************************/
/*                                                                          */
/*                         GetPPDPaperMetrics                               */
/*  function:                                                               */
/*    This routine gets data describing the size of a sheet of the currently*/
/*    selected type of paper from the appropriate keyword strings in the    */
/*    PPDList in the DrvState passed in.                                    */
/*    sets paper Dimensions, Imageable area and bounding box in PS coords   */
/*                                                                          */
/*  arguments:                                                              */
/*     lppd - pdevice ptr                                                   */
/*     lpDrvState - ptr to a valid DrvState structure                       */
/*     PaperDim - ptr to POINT in which paper dimensions(in pixels) are     */
/*                placed.                                                   */
/*     imageableArea - ptr to RECT identifying region of page that can be   */
/*        written to                                                        */
/*     res_x - ptr to loc where x resolution in pixels per inch is placed.  */
/*        This defines the x units used for PaperDim & imageableArea.     */
/*     res_y - ptr to loc where y resolution in pixels per inch is placed.  */
/*        This defines the y units used for PaperDim & imageableArea.     */
/*                                                                          */
/*  returns: RC_ok if no error occurs, else RC_fail or RC_not_found.        */
/*                                                                          */
/****************************************************************************/
short FAR PASCAL GetPPDPaperMetrics(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode)
{
   LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
   LPBYTE lpOptionsBlock = lppd->lpWPXblock->WPXarrays;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   LPPAPERINFO  lpPaperInfo ;
   BOOL     bMinHeader = FALSE;  // !!!! Should get this from data structure !!!!
   WORD     paperIndex ;
   int        res_x, res_y;
   int        RetValue = RC_ok;

   // Get the Resolution in pixels per inch.

   bMinHeader = (lppd)->job.bfJobMinHeader ;

   RetValue = GetCurrentResolution(lppd, lpPSExtDevmode, (LPINT) &res_x, 
				   (LPINT) &res_y);
   if (RetValue != RC_ok)
   {
      res_x = RES;                   // plug in default (300x300) resolution
      res_y = RES;
      RetValue = RC_ok;
   }

   KeywordGetCurrentOption(lppd , IND_PAPERINFO, &paperIndex) ;

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;

   lpPaperInfo = (LPPAPERINFO)MAKELONG(
		  lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );

   if (paperIndex == lpPrinterInfo->devcaps.CustomPageSize)
   {
      // Check if it is not app defined custom paper
      if (lpPSExtDevmode->dm.currentCustPaper != APP_DEFINED)
      {
          LPSTR  lpPPDVersion;

          lpPPDVersion = StringRefToLPBYTE(lppd, lpPrinterInfo->PPDVersion.dword);
          if((lpPSExtDevmode->dm.custPaper[lpPSExtDevmode->dm.currentCustPaper].Transverse)
              && (lstrcmp(lpPPDVersion, "4.3") < 0)          
              && (lpPrinterInfo->custpageinfo.isCutSheet))
          { 
             // do this only in (PPD-42 && cut-sheet) case
             lppd->ptPaperDim.x =
	             (int) (lpPSExtDevmode->dm.custPaper[lpPSExtDevmode->dm.currentCustPaper]).customHeight;
             lppd->ptPaperDim.y =
       	       (int) (lpPSExtDevmode->dm.custPaper[lpPSExtDevmode->dm.currentCustPaper]).customWidth;
          }
          else
          {
             lppd->ptPaperDim.x =
                (int) (lpPSExtDevmode->dm.custPaper[lpPSExtDevmode->dm.currentCustPaper]).customWidth;
             lppd->ptPaperDim.y =
                (int) (lpPSExtDevmode->dm.custPaper[lpPSExtDevmode->dm.currentCustPaper]).customHeight;
          }
      }
      else
      {
          // App defined.
          lppd->ptPaperDim.x = (int)lpPSExtDevmode->dm.appCustWidth;
          lppd->ptPaperDim.y = (int)lpPSExtDevmode->dm.appCustHeight;
      }
   }
   else
   {
      lppd->ptPaperDim.y = lpPaperInfo[paperIndex].length; 
      lppd->ptPaperDim.x = lpPaperInfo[paperIndex].width; 
   }

   AdjustResolution(lpPSExtDevmode, (LPINT) &res_x, (LPINT) &res_y, 
		    (LPPOINT) &lppd->ptPaperDim);

   // NOTE: there is no PPD mechanism (currently) for the user to
   // specify imageable area for a custom page size.  The custom
   // page code example for level 2 (page 45 of the PPD spec version 4.0B3)
   // specifically indicates that the imageable area of the custom
   // page will be the full dimensions of the specified custom paper.
   // (look up "ImageBBox = NULL" in the Red Book if you don't believe me).
   // Therefore, we will set the imageable area to be the same
   // as the paper dimensions until some new spec comes along.


   if (lpPSExtDevmode->dm.marginState == NO_MARGINS   ||  bMinHeader)
   {  // Custom paper selected  or  NO_MARGINS specified.
      //  in  default PS coords  (left, top, right, bottom)
      lppd->imageRect.left = 0;
      lppd->imageRect.top = lppd->ptPaperDim.y;
      lppd->imageRect.right = lppd->ptPaperDim.x;
      lppd->imageRect.bottom = 0;
      //  note minimal header flag also activates No Margins 
   }
   else if (paperIndex == lpPrinterInfo->devcaps.CustomPageSize)
   {
      // Custom paper  
      RECT  hwMargins;

      if(lpPSExtDevmode->dm.currentCustPaper == APP_DEFINED)
      {
         hwMargins = lpPrinterInfo->custpageinfo.HWmargins;
      }
      else
      {
         hwMargins = 
         lpPSExtDevmode->dm.custPaper[lpPSExtDevmode->dm.currentCustPaper].HWmargins;
      }
         
      lppd->imageRect.left   = hwMargins.left;
      lppd->imageRect.bottom = hwMargins.bottom;
      lppd->imageRect.top    = lppd->ptPaperDim.y - hwMargins.top ;
      lppd->imageRect.right  = lppd->ptPaperDim.x - hwMargins.right ;
   }
   else
   {
      // Standard paper
      if(paperIndex < MAXPAPERMARGINS)
         lppd->imageRect = lpPSExtDevmode->dm2.revisedPaperMargins[paperIndex];
      else
         lppd->imageRect = lpPaperInfo[paperIndex].imageableArea ;
   }


   lppd->bbox = lppd->imageRect;

   // Update PDEVICE with the current resolution
   lppd->DeviceRes.x_res = res_x;
   lppd->DeviceRes.y_res = res_y;

   return( RetValue );
}


/***************************************************************************/
/*                                                                         */
/*                          AdjustResolution                               */
/*  function:                                                              */
/*  arguments:                                                             */
/*  returns: no return value                                               */
/*                                                                         */
/***************************************************************************/
void FAR PASCAL AdjustResolution(LPPSEXTDEVMODE lpPSExtDevmode, 
				  LPINT res_x, LPINT res_y,
				  LPPOINT lpPoint)
{
    int max_res_x, max_res_y;

   // Calculate the maximum resolution possible which will compute to a
   // paper size (in pixels) that will not overflow a signed integer.

   max_res_x = MulDiv(32000, POINTS_PER_INCH, (int)lpPoint->x)-1; 
   max_res_y = MulDiv(32000, POINTS_PER_INCH, (int)lpPoint->y)-1; 

#if 1
// Re-enable this portion of code to fix Non-Square Resolution Bug 120114, 11-27-1995, PPeng
// See bug 120114 for a possible real fix - which requires 4 steps/things:
// 1. Re-do truetype font downlaoding - change /fontmatrix to [1 0 0 resx/resy 0 0];
// 2. Mkae sure we don't re-scale font using non-square scaling;
// 3. ETO-rect returned back to app should be adjusted;   
// 4. Rotate CTM in a correct way - 45degree should be 28 degree.
   // temporarily force square resolutions until we fix all
   // non-square resolution bugs - Shyam Vijay - 5/14/93
   // When we do fix them all, this section goes away and 
   // the following one, now #if 0 is activated.

   if (*res_x != *res_y)
   {
      if (*res_x > *res_y)          // Pick larger one. Then make them equal.
      {
	 *res_y = *res_x;
      }
      else
      {
	 *res_x = *res_y;
      }
   }
   while (*res_x > min(max_res_x, max_res_y))
   {
      *res_x >>= 1;            // Halve it
   }
   *res_y = *res_x;            // Update res_y now. Remember they were equal
#else
      // temporarily disable non-square resolutions until we fix all 
      // non-square resolution bugs - Shyam Vijay - 5/14/93

      while (*res_x > max_res_x)
      {
	 *res_x >>= 1;        // Halve it
      }
      while (*res_y > max_res_y)
      {
	 *res_y >>= 1;        // Halve it
      }
#endif
}


/***************************************************************************/
/*                       GetCurrentResolution                              */
/*                                                                         */
/*       This function returns the current X, Y resolution                 */
/*                                                                         */
/*  parameters:                                                            */
/*       int * X_Res    -- pointer to X resolution                         */
/*       int * Y_Res    -- pointer to Y resolution                         */
/*                                                                         */
/*  returns:                                                               */
/*       RC_ok => we got the resolution                                    */
/*       RC_fail => we could not get the resolution                        */
/*                                                                         */
/***************************************************************************/
short FAR PASCAL GetCurrentResolution(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode,
				      int FAR * X_Res, int FAR * Y_Res)
{
   LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
   LPBYTE lpOptionsBlock = lppd->lpWPXblock->WPXarrays;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   LPRESOLUTIONINFO lpResolutionInfo ;
   WORD ResolutionIndex ;

   short  rc = RC_ok;

   KeywordGetCurrentOption(lppd , IND_RESOLUTIONINFO, &ResolutionIndex) ;

   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_RESOLUTIONINFO ;

   lpResolutionInfo = (LPRESOLUTIONINFO)MAKELONG(
		  lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );

   *X_Res = lpResolutionInfo[ResolutionIndex].res.word.x;
   *Y_Res = lpResolutionInfo[ResolutionIndex].res.word.y;

   // How do I handle JCLResolution? - ShyamV - 9/29/93
   if (! (*X_Res && *Y_Res))
       rc = RC_fail;

   return rc;
}

#if 0       // not used anymore - ShyamV
/*************************************************************************/
/*                       Ps_GetPPDIntValue                               */
/*                                                                       */
/*       This function retrieves integer value from the PPD              */
/*                                                                       */
/*                                                                       */
/*  prototype:                                                           */
/*       BOOL FAR PASCAL Ps_GetPPDIntValue(LPPDEVICE lppd,               */
/*                             LPSTR szKey,int FAR * value);             */
/*  parameters:                                                          */
/*       LPPDEVICE lppd -- pointer to pdevice structure                  */
/*       LPSTR     szKey - string holding key eg "screenfrequency"          */
/*       int FAR  * value -- pointer to integer                          */
/*           LPSTR     nickname - pointer to printer nickname            */
/*                                                                       */
/*  returns:                                                             */
/*       BOOL -- TRUE => we got the resolution                           */
/*************************************************************************/
BOOL FAR PASCAL Ps_GetPPDIntValue(LPPDEVICE lppd,LPSTR szKey,int FAR * value,
							 LPSTR nickname)
{
    short  rc = RC_ok;
    HANDLE pihdl = NULL;
    double    RX = 0L;
    short  enum_rc = RC_ok;
//    char   option[MAX_OPTION_LEN] ;

    // Get Handle to printer instance
    pihdl = Ps_EnumOpen(nickname,0);
    if(!pihdl)
    {
       rc = RC_fail;
    }

    // Query Enumerator for default keyword value
    if(rc == RC_ok)
    {
       enum_rc = Ps_PPDGetKeywordOptionPS(pihdl, szKey, NULL,
					  LocalStringBuffer, MAX_OPTION_LEN );
       if (enum_rc == PS_RC_OK)
       {
	  *value = (int)latof(&LocalStringBuffer[0]);
       }
       else 
       {
	  rc = RC_fail;
       }
    }
    if (pihdl)
    {
       if(Ps_EnumClose(pihdl) != PS_RC_OK)      // Close the binary PPD file
       {
	rc = RC_fail;
       }
    }
    return rc;
}


/****************************************************************************/
/*                                                                          */
/*                            DriverAToF                                    */
/*  function:                                                               */
/*     Converts a string of floats to floats and returns the count.         */
/*                                                                          */
/*  arguments:                                                              */
/*     LPSTR       pString   The string to retrieve the floats from.        */
/*     short       nMaxCount The number of pointers to floats that was      */
/*                           passed.                                        */
/*     float FAR * ...       Variable number of pointers to floats.         */
/*                                                                          */
/*  returns: short Number of converted floats.                              */
/*                                                                          */
/****************************************************************************/
LPSTR FAR PASCAL DriverAToF(LPSTR pString, LPFLOAT pValue)
{
   BOOL       fDone;
   short      nCount;

   fDone = FALSE;
   nCount = 0;
   /* Burn off leading blanks */
   while( *pString == ' ' )
   {
      ++pString;
   }
   /* If the string is not null */
   if( *pString != '\0' )
   {    //Bad craziness here because atof() only accepts near pointers.
/*     *pValue = (float)atof( (PSTR) LOWORD((DWORD) pString) ); */
     *pValue = (float)latof( pString );
     ++nCount;

     /* Burn off extra characters */
     while( *pString != ' ' && *pString != '\0' )
     {
	++pString;
     }
   }
   else
   {
      fDone = TRUE;
   }

   return( pString );
} /* End of DriverAToF */
#endif


short FAR PASCAL SetCTMatrix(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode,
			     LPPOINT lpCorner)
/****************************************************************************

  function:  
   this function will grab all relavent parameters from
   the separately supplied lpDrvState.  Which may be a clone
   of the one in lppd but modified via an app through ExtDevMode
   or through the dialog box in AdvDialogSetup or whatever.

   Heed this warning:  call SetCTMatrix only after value of all
   determining fields have been set to their final state.

  (partial replacement for GetPPDPaperMetrics)
   This routine determines the CurrentTransformation Matrix
   used to transform from the GDI coordinates to the
   Postscript Default User Space coordinates.

       This function uses the following determining fields:
       (they must be set to the intended values or a garbage
       CTM will be written).

       EPS mode     (ignore orientation, use Portrait only?)
	  bOutputDialect == DIALECT_EPS ?

       lppd->drvState.bfNoMargins (TRUE means imageable area is full page)
	  note: noMargins affects the bounding box - as well it should
	  since an EPS bounding box must enclose all ink on the page
	  regardless of printer limitations like unprintable regions.

       minimal header flag  (units are logRes or points)
       FLAG     bMinHeader;    // true means use points 

       lppd->drvState.bOrientation
	    DMORIENT_ROT_LANDSCAPE   or
	    DMORIENT_LANDSCAPE       or
	    DMORIENT_PORTRAIT


       lppd->drvState.bMirroring

      lpDrvState->ptAbsPaperDim;                //height and width of paper in pts, from PPD keyword PAPERDIM
      lpDrvState->AbsImageRect;                 //imageable area on paper, in pts, from PPD keyword IMGAREA


      (note logRes values are computed by SetResolution()
      after all other above fields and printer resolution have
      been determined.)

      lpDrvState->DeviceRes.x_res   // units for GDI coordinate system
      lpDrvState->DeviceRes.y_res   

      have all been previously defined.

       This function writes into the fields:

      lpDrvState->Matrix ;        // Converts GDI to Default User coords.



  arguments:
       lppd - pdevice ptr
       lpDrvState - ptr to a valid DrvState structure

  returns: RC_ok if no error occurs, else RC_fail or RC_not_found.

****************************************************************************/
{
   LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
   int      RetValue;
   PAP_ORIENT  bOrientation;   //  Orientation of image on paper, eg. landscape, from from PPD keyword ORIENT
   RECT     logImageRect ;  //  what the driver thinks is the imageable area
   double   a, b, c, d, tx, ty ;
   BOOL     bMinHeader = FALSE;  // !!!! Should get this from data structure !!!!
   BOOL     bLandscapePlus90;
   BOOL     bCustTransverse;
   WORD     paperIndex, curCustPaper;
   LPSTR    lpPPDVersion;

   RetValue = RC_ok ;

   bMinHeader = (lppd)->job.bfJobMinHeader ;

   bOrientation = lpPSExtDevmode->dm.PaperOrient;

//   if(lpPSExtDevmode->dm2.bOutputDialect == DIALECT_EPS)
//      bOrientation = OR_PORTRAIT ;


   bLandscapePlus90 = lpPrinterInfo->devcaps.landscapeOrientPlus90;
   if (bLandscapePlus90) 
   {
	if (bOrientation == OR_LANDSCAPE)
	    bOrientation = OR_ROTLANDSCAPE;
	else if (bOrientation == OR_ROTLANDSCAPE)
	    bOrientation = OR_LANDSCAPE;
   }

   logImageRect = lppd->imageRect ;

   KeywordGetCurrentOption(lppd , IND_PAPERINFO, &paperIndex) ;
   curCustPaper = lpPSExtDevmode->dm.currentCustPaper;

   lpPPDVersion = StringRefToLPBYTE(lppd, lpPrinterInfo->PPDVersion.dword);
   if ((paperIndex == lpPrinterInfo->devcaps.CustomPageSize) 
       && (curCustPaper != APP_DEFINED)
       && (lpPSExtDevmode->dm.custPaper[curCustPaper].Transverse)
       && (lstrcmp(lpPPDVersion, "4.3") < 0)          
       && (lpPrinterInfo->custpageinfo.isCutSheet))
   {
      // do this only in (PPD-42 && cut-sheet)
      bCustTransverse = TRUE;
   }
   else
   {
      bCustTransverse = FALSE;
   }

   if(lpPSExtDevmode->dm.bMirror)
   {

      switch (bOrientation)
      {
	 case  OR_LANDSCAPE:     //  rotate minus 90 degs
       if(bCustTransverse)
       {
	       a = -1.0 ;
	       b = 0.0 ;
	       c = 0.0 ;
	       d = -1.0 ;
	       tx = logImageRect.right;
	       ty = logImageRect.top;
          
	       lpCorner->x = lppd->ptPaperDim.x;
	       lpCorner->y = lppd->ptPaperDim.y;
       }
       else
       {
	       a = 0.0 ;
	       b = -1.0 ;
	       c = 1.0 ;
	       d = 0.0 ;
	       tx = logImageRect.left ;
	       ty = logImageRect.top ;
          
	       lpCorner->x = 0 ;
	       lpCorner->y = lppd->ptPaperDim.y;
       }
	    break;

	 case  OR_ROTLANDSCAPE:  // rotate plus 90 degs
       if(bCustTransverse)
       {
	       a = 1.0 ;
	       b = 0.0 ;
	       c = 0.0 ;
	       d = 1.0 ;
	       tx = logImageRect.left;
	       ty = logImageRect.bottom;
          
	       lpCorner->x = 0;
	       lpCorner->y = 0;
       }
       else
       {
	       a = 0.0 ;
	       b = 1.0 ;
	       c = -1.0 ;
	       d = 0.0 ;
	       tx = logImageRect.right ;
	       ty = logImageRect.bottom ;
          
	       lpCorner->x = lppd->ptPaperDim.x;
	       lpCorner->y = 0 ;
       }
	    break;
	 case  OR_PORTRAIT:
	 default:
       if(bCustTransverse)
       {
	       a = 0.0 ;
	       b = 1.0 ;
	       c = -1.0 ;
	       d = 0.0 ;
	       tx = logImageRect.right ;
	       ty = logImageRect.bottom ;
          
	       lpCorner->x = lppd->ptPaperDim.x;
	       lpCorner->y = 0 ;
       }
       else
       {
	       a = -1.0 ;
	       b = 0.0 ;
	       c = 0.0 ;
	       d = -1.0 ;
	       tx = logImageRect.right ;
	       ty = logImageRect.top ;
          
	       lpCorner->x = lppd->ptPaperDim.x;
	       lpCorner->y = lppd->ptPaperDim.y;
       }
	    break;
      }
   }
   else
   {
      switch (bOrientation)
      {
	 case  OR_LANDSCAPE:     //  rotate minus 90 degs
       if(bCustTransverse)
       {
	       a = -1.0 ;
	       b = 0.0 ;
	       c = 0.0 ;
	       d = 1.0 ;
	       tx = logImageRect.right;
	       ty = logImageRect.bottom;
          
	       lpCorner->x = lppd->ptPaperDim.x;
	       lpCorner->y = 0;
       }
       else
       {
	       a = 0.0 ;
	       b = -1.0 ;
	       c = -1.0 ;
	       d = 0.0 ;
	       tx = logImageRect.right ;
	       ty = logImageRect.top ;
          
	       lpCorner->x = lppd->ptPaperDim.x;
	       lpCorner->y = lppd->ptPaperDim.y;
       }
	    break;
	 case  OR_ROTLANDSCAPE:  // rotate plus 90 degs
       if(bCustTransverse)
       {
	       a = 1.0 ;
	       b = 0.0 ;
	       c = 0.0 ;
	       d = -1.0 ;
	       tx = logImageRect.left;
	       ty = logImageRect.top;
          
	       lpCorner->x = 0;
	       lpCorner->y = lppd->ptPaperDim.y;
       }
       else
       {
	       a = 0.0 ;
	       b = 1.0 ;
	       c = 1.0 ;
	       d = 0.0 ;
	       tx = logImageRect.left ;
	       ty = logImageRect.bottom ;
          
	       lpCorner->x = 0 ;
	       lpCorner->y = 0 ;
       }
	    break;
	 case  OR_PORTRAIT:
	 default:
       if(bCustTransverse)
       {
	       a = 0.0 ;
	       b = -1.0 ;
	       c = -1.0 ;
	       d = 0.0 ;
	       tx = logImageRect.right ;
	       ty = logImageRect.top ;
          
	       lpCorner->x = lppd->ptPaperDim.x;
	       lpCorner->y = lppd->ptPaperDim.y;
       }
       else
       {
	       a = 1.0 ;
	       b = 0.0 ;
	       c = 0.0 ;
	       d = -1.0 ;
	       tx = logImageRect.left ;
	       ty = logImageRect.top ;
          
	       lpCorner->x = 0 ;
	       lpCorner->y = lppd->ptPaperDim.y;
       }
	    break;
      }
   }


   if(bMinHeader == FALSE)
   {
      //  convert  CTM from  points to log resolution
      a *= 72.0 / lppd->DeviceRes.x_res ;
      c *= 72.0 / lppd->DeviceRes.x_res ;
      b *= 72.0 / lppd->DeviceRes.y_res ;
      d *= 72.0 / lppd->DeviceRes.y_res ;
   }

   lppd->psmatrix[0] = (float)a ;
   lppd->psmatrix[1] = (float)b ;
   lppd->psmatrix[2] = (float)c ;
   lppd->psmatrix[3] = (float)d ;
   lppd->psmatrix[4] = (float)tx ;
   lppd->psmatrix[5] = (float)ty ;

   return(RetValue);
}

#pragma  optimize ("se", off)
#pragma  optimize ("d", on)

void  DefaultPStoGDI(LPPSMATRIX  matrix, LPSHORT  x, LPSHORT  y)
{
   float  fx, fy;

   //  we assume either  (a and d)  OR  (b and c)  are zero.

   if(matrix[0])
   {
      fx = (*x - matrix[4]) / matrix[0] ;
      fy = (*y - matrix[5]) / matrix[3] ;
   }
   else
   {
      fx = (*y - matrix[5]) / matrix[1] ;
      fy = (*x - matrix[4]) / matrix[2] ;
   }
   *x = (SHORT)fx ;
   *y = (SHORT)fy ;
}

#pragma  optimize ("d", off)
#pragma  optimize ("se", on)

void  GDItoDefaultPS(LPPSMATRIX  matrix, LPSHORT  x, LPSHORT  y)
{
   float  fx, fy;

   fx = matrix[0] * *x + matrix[2] * *y + matrix[4] ;
   fy = matrix[1] * *x + matrix[3] * *y + matrix[5] ;

   *x = (SHORT)fx ;
   *y = (SHORT)fy ;
}

void FAR PASCAL  GDIorderRect(LPRECT  lpImageRect)
/*  this function swaps (top with bottom)
 *   and  (left with right)  
 *   as needed so that top is smaller than bottom
 *   and left is smaller than right.
 */
{
   SHORT  temp;

   if(lpImageRect->top > lpImageRect->bottom)
   {
      temp = lpImageRect->top;
      lpImageRect->top = lpImageRect->bottom ;
      lpImageRect->bottom = temp ;
   }
   if(lpImageRect->left > lpImageRect->right)
   {
      temp = lpImageRect->left;
      lpImageRect->left = lpImageRect->right ;
      lpImageRect->right = temp ;
   }
}
