/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: UPGRADE.C                                                    */
/*                                                                           */
/* Description: This module contains the functions that read in devmode      */
/*              settings from win.ini, so that Win31 settings will be        */
/*              retained.                                                    */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_UPGRADESEG)

#define DMBIN_AUTOSLOT  255

// The win31 driver had some internal printers as resources. We need to
// be able to get the default slot data for these old beasts, or else
// we lose our paper size on upgrade.
typedef struct _OLDINTERNALWPDINFO
{
    LPSTR lpszOldModel;
    short sDefaultInputSlot;
} OLDINTERNALWPDINFO, FAR * LPOLDINTERNALWPDINFO;

// We go through this separate array, just to force the strings to be
// stored on the code segment (since we use them so rarely).
static char UPGRADESEG szApp1[] = "Apple LaserWriter";
static char UPGRADESEG szApp2[] = "Apple LaserWriter Plus";
static char UPGRADESEG szApp3[] = "Apple LaserWriter II NTX";
static char UPGRADESEG szApp4[] = "Apple LaserWriter II NT";
static char UPGRADESEG szAst[]  = "AST TurboLaser/PS-R4081";
static char UPGRADESEG szData[] = "Dataproducts LZR-2665";
static char UPGRADESEG szDig1[] = "Digital LN03R ScriptPrinter";
static char UPGRADESEG szDig2[] = "Digital PrintServer 40";
static char UPGRADESEG szIBM1[] = "IBM Personal Pageprinter";
static char UPGRADESEG szIBM2[] = "IBM Personal Page Printer II-30";
static char UPGRADESEG szIBM3[] = "IBM Personal Page Printer II-31";
static char UPGRADESEG szOli1[] = "Olivetti PG 303";
static char UPGRADESEG szOli2[] = "Olivetti PG 308 HS PostScript";
static char UPGRADESEG szQMS1[] = "QMS-PS 810";
static char UPGRADESEG szQMS2[] = "QMS-PS 800 Plus";
static char UPGRADESEG szQMS3[] = "QMS-PS 800";
static char UPGRADESEG szQMS4[] = "QMS ColorScript 100";
static char UPGRADESEG szVari[] = "Varityper VT-600";
static char UPGRADESEG szWan1[] = "Wang LCS15";
static char UPGRADESEG szWan2[] = "Wang LCS15 FontPlus";

static OLDINTERNALWPDINFO UPGRADESEG OldInternalWPDInfo[]={
    {szApp1, DMBIN_UPPER},
    {szApp2, DMBIN_UPPER},
    {szApp3, DMBIN_UPPER},
    {szApp4, DMBIN_UPPER},
    {szAst,  DMBIN_UPPER},
    {szData, DMBIN_LOWER},
    {szDig1, DMBIN_UPPER},
    {szDig2, DMBIN_LARGECAPACITY},
    {szIBM1, DMBIN_UPPER},
    {szIBM2, DMBIN_UPPER},
    {szIBM3, DMBIN_UPPER},
    {szOli1, DMBIN_UPPER},
    {szOli2, DMBIN_UPPER},
    {szQMS1, DMBIN_UPPER},
    {szQMS2, DMBIN_UPPER},
    {szQMS3, DMBIN_UPPER},
    {szQMS4, DMBIN_UPPER},
    {szVari, DMBIN_UPPER},
    {szWan1, DMBIN_AUTO},
    {szWan2, DMBIN_AUTO},
    {NULL,   0}};


int FAR PASCAL ExtractDefInputSlotFromWPD(LPSTR lpModelName) ;


//--------------------------------------------------------------------
// Function: ExtractDefInputSlotFromInternalWPD(lpModelName)
//
// Action: Extract the default input slot from an internal WPD, if
//         we find a match.
//
// Return: The default input slot if successul, -1 if not.
//--------------------------------------------------------------------
short NEAR PASCAL ExtractDefInputSlotFromInternalWPD(LPSTR lpModelName)
{
    LPOLDINTERNALWPDINFO lpowi;

    for(lpowi=OldInternalWPDInfo;lpowi->lpszOldModel;lpowi++)
    {
        if(!lstrcmpi(lpowi->lpszOldModel,lpModelName))
            return lpowi->sDefaultInputSlot;
    }

    return -1;
}

int NEAR PASCAL GetString(LPSTR section, LPSTR key, LPSTR defaultval, 
                          LPSTR buf, int size, LPSTR profile)
{
    if (profile)
        return GetPrivateProfileString(section, key, defaultval, buf, size, 
                                       profile);
    else
        return GetProfileString(section, key, defaultval, buf, size);
}

int NEAR PASCAL GetInt(LPSTR section, LPSTR key, int defaultval, LPSTR profile)
{
    if (profile)
        return GetPrivateProfileInt(section, key, defaultval, profile);
    else
        return GetProfileInt(section, key, defaultval);
}


void NEAR PASCAL MergeValue(WORD ValueType, WORD SuspectValue, 
                            LPWPXBLOCKS lpWPXblock, LPPSEXTDEVMODE lpDevmode,
                            LPPDEVICE lppd)
{
    LPMAINKEYHDR  lpCurMainKeyHdr;
    LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO) lpWPXblock->WPXprinterInfo;
    WORD          i;
    
    lppd->lpWPXblock = lpWPXblock;
    lppd->lpPSExtDevmode = lpDevmode;

    switch (ValueType)
    {
        case  IDS_FAVORTT:
            lpDevmode->dm2.bFavorTT = (SuspectValue != 0);
            break;
        case  IDS_HEADER:
            lpDevmode->dm2.fHeader =  (SuspectValue != 0);
            break;
        case  IDS_DOEPS:
            if (SuspectValue != 0)
                lpDevmode->dm.enumDialect = DIA_EPS;
            break;

        case  IDS_COPIES:
            if ((SuspectValue > 0) && (SuspectValue <= MAX_COPIES))
                lpDevmode->dm.Copies = SuspectValue;
            break;
        
        case  IDS_DSPUNITS:
            switch (SuspectValue)
            {
                case  INCHES_100:
                case  MILLIMETERS_10:
                case  NATURAL_UNITS:
                    lpDevmode->dm.DspUnits = SuspectValue;
                    break;
            }
            break;
        
        case  IDS_CUSTOMWIDTH:
            if (lpPrinterInfo->devcaps.CustomPageSize != 0xffff)
            {
                WORD min, max;

                min = (WORD) (lpPrinterInfo->custpageinfo.HWmargins.left +
                              lpPrinterInfo->custpageinfo.HWmargins.right);
                if (min < (WORD) lpPrinterInfo->custpageinfo.width.min)
                    min = (WORD) lpPrinterInfo->custpageinfo.width.min;
                max = (WORD) lpPrinterInfo->custpageinfo.width.max;
        
                if (SuspectValue > max)
                    SuspectValue = max;
                if (SuspectValue < min)
                    SuspectValue = min;

                lpDevmode->dm.custPaper[0].customWidth = (float) SuspectValue;
            }
            break;
        
        case  IDS_CUSTOMHEIGHT: 
            if (lpPrinterInfo->devcaps.CustomPageSize != 0xffff)
            {
                WORD min, max;
       
                min = (WORD) (lpPrinterInfo->custpageinfo.HWmargins.top +
                              lpPrinterInfo->custpageinfo.HWmargins.bottom);
                if (min < (WORD) lpPrinterInfo->custpageinfo.height.min)
                    min = (WORD) lpPrinterInfo->custpageinfo.height.min;
                max = (WORD) lpPrinterInfo->custpageinfo.height.max;
        
                if (SuspectValue > max)
                    SuspectValue = max;
                if (SuspectValue < min)
                    SuspectValue = min;

                lpDevmode->dm.custPaper[0].customHeight = (float) SuspectValue;
            }
            break;
        
        case  IDS_CUSTOMTRANSVERSE:
            if (lpPrinterInfo->devcaps.CustomPageSize != 0xffff)
            {
                WORD min, max;

                min = (WORD) lpPrinterInfo->custpageinfo.Orientation.min;
                max = (WORD) lpPrinterInfo->custpageinfo.Orientation.max;
        
                if (SuspectValue > max)
                    SuspectValue = max;
                if (SuspectValue < min)
                    SuspectValue = min;

                lpDevmode->dm.custPaper[0].Transverse = (SuspectValue != 0);
            }
            break;
        
        case  IDS_CUSTOMWIDTHOFFSET:
            if (lpPrinterInfo->devcaps.CustomPageSize != 0xffff)
            {
                WORD min, max;
        
                min = (WORD) lpPrinterInfo->custpageinfo.widthOffset.min;
                max = (WORD) lpPrinterInfo->custpageinfo.widthOffset.max;
        
                if (SuspectValue > max)
                    SuspectValue = max;
                if (SuspectValue < min)
                    SuspectValue = min;

                lpDevmode->dm.custPaper[0].widthOffset = SuspectValue;
            }
            break;
        
        case  IDS_CUSTOMHEIGHTOFFSET:
            if (lpPrinterInfo->devcaps.CustomPageSize != 0xffff)
            {
                WORD min, max;
        
                min = (WORD) lpPrinterInfo->custpageinfo.heightOffset.min;
                max = (WORD) lpPrinterInfo->custpageinfo.heightOffset.max;
        
                if (SuspectValue > max)
                    SuspectValue = max;
                if (SuspectValue < min)
                    SuspectValue = min;

                lpDevmode->dm.custPaper[0].heightOffset = SuspectValue;
            }
            break;
        
        case  IDS_MARGINS:
            switch(SuspectValue)
            {
                case  902:      /* DEFAULT_MARGINS */
                    lpDevmode->dm.marginState = DEFAULT_MARGINS;
                    break;
                case  903:      /* ZERO_MARGINS */
                    lpDevmode->dm.marginState = NO_MARGINS;
                    break;
            }
            break;

        case  IDS_DUPLEX:
            if (lpPrinterInfo->devcaps.SupportsDuplexing)
            {
                LPGENERIC_OPTION lpDuplexInfo;
                WORD  index = 0xffff;
                
                lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + 
                    IND_DUPLEXINGINFO ;

                lpDuplexInfo = (LPGENERIC_OPTION)
                    MAKELONG(lpCurMainKeyHdr->OptionKeyWords.w.offset, 
                             HIWORD(lpWPXblock->WPXarrays));

                switch (SuspectValue)
                {
                    case  DMDUP_VERTICAL:
                        if(lpDuplexInfo[DUPLEXNOTUMBLE].Invocation.w.length)
                            index = DUPLEXNOTUMBLE;
                        break;
                    case  DMDUP_HORIZONTAL:
                        if(lpDuplexInfo[DUPLEXTUMBLE].Invocation.w.length)
                            index = DUPLEXTUMBLE;
                        break;
                    case  DMDUP_SIMPLEX:
                        index = DUPLEX_NONE;
                        break;
                }

                if (index != 0xffff)
                    KeywordSetCurrentOption(lppd , IND_DUPLEXINGINFO, index);
            }
            break;
        
        case   IDS_ORIENTATION:
            switch (SuspectValue)
            {
                case  DMORIENT_PORTRAIT:
                    lpDevmode->dm.PaperOrient = OR_PORTRAIT;
                    break;
                case  DMORIENT_LANDSCAPE:
                    if (lpDevmode->dm.PaperOrient == OR_PORTRAIT)
                        lpDevmode->dm.PaperOrient = OR_LANDSCAPE;
                    break;
            }
            break;

        case   IDS_COLOR:
            if (lpPrinterInfo->devcaps.color)
            {
                switch(SuspectValue) {
                    // Fix bug 164376.  iColorOption is a printer sticky feature.
                    case  DMCOLOR_COLOR:
                        if (lpDevmode->dm2.iColorOption == COLOR_8BIT)
                            lpDevmode->dm2.iColorOption = COLOR_FULL_COLOR;
                        break;
                    case  DMCOLOR_MONOCHROME:
                        lpDevmode->dm2.iColorOption = COLOR_8BIT;
                        break;
                }
            }
            break;

        case  IDS_PAPERSOURCE:
            {
                WORD slotID = 0xffff;
                
                if(SuspectValue == DMBIN_AUTOSLOT)
                {
                    slotID = lpPrinterInfo->devcaps.AutoSense;
                }
                else
                {
                    LPINPUTSLOTINFO  lpInputSlotInfo;
                    WORD numSlots;
                    
                    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + 
                        IND_INPUTSLOTINFO ;

                    lpInputSlotInfo = (LPINPUTSLOTINFO)
                        MAKELONG(lpCurMainKeyHdr->extraOptionArray, 
                                 HIWORD(lpWPXblock->WPXarrays));
        
                    numSlots = lpCurMainKeyHdr->OptionKeyWords.w.length;
                    
                    for (i=0 ; i<numSlots; i++)
                    {
                        if (lpInputSlotInfo[i].slotID == SuspectValue)
                        {
                            slotID = i;
                            break;
                        }
                    }
                }

                if (slotID != 0xffff)
                {
                    KeywordSetCurrentOption(lppd , IND_INPUTSLOTINFO, slotID);

                    // We need to update dmDefaultSource right away, or
                    // else we don't update paper sizes correctly.
                    lpDevmode->dm.dm.dmDefaultSource=slotID;
                }
            }
            break;
        
        case  IDS_RES:
            {
                LPRESOLUTIONINFO  lpResInfo;
                WORD   numRes;
                
                lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + 
                    IND_RESOLUTIONINFO;
        
                lpResInfo = (LPRESOLUTIONINFO)
                    MAKELONG(lpCurMainKeyHdr->extraOptionArray, 
                             HIWORD(lpWPXblock->WPXarrays));

                numRes = lpCurMainKeyHdr->OptionKeyWords.w.length;

                for (i=0 ; i<numRes; i++)
                {
                    if (SuspectValue == lpResInfo[i].res.word.x)
                    {
                        KeywordSetCurrentOption(lppd , IND_RESOLUTIONINFO, i);
                        break;
                    }
                }
            }
            break;
        
        case  IDS_YRES:
            /* Assumes that X resolution is merged before Y resolution */
            {
                LPRESOLUTIONINFO  lpResInfo;
                WORD   resIndex, numRes;
                WORD   xResln;

                lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + 
                    IND_RESOLUTIONINFO;
        
                lpResInfo = (LPRESOLUTIONINFO)
                    MAKELONG(lpCurMainKeyHdr->extraOptionArray, 
                             HIWORD(lpWPXblock->WPXarrays));

                KeywordGetCurrentOption(lppd , IND_RESOLUTIONINFO, &resIndex) ;

                xResln = lpResInfo[resIndex].res.word.x;

                numRes = lpCurMainKeyHdr->OptionKeyWords.w.length;

                for (i=0 ; i<numRes; i++)
                {
                    if ((SuspectValue == lpResInfo[i].res.word.y) &&
                        (xResln == lpResInfo[i].res.word.x))
                    {
                        KeywordSetCurrentOption(lppd , IND_RESOLUTIONINFO, i);
                        break;
                    }
                }
            }
            break;
        
        case  IDS_SCALE:
            if (SuspectValue >= 10 & SuspectValue <= 400)
                lpDevmode->dm.Scale = SuspectValue;
            break;

        case  IDS_PAPERX:
            {
                LPPAPERINFO  lpPaperInfo;
                WORD numPapers;

                lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs +
                    IND_PAPERINFO;
        
                lpPaperInfo = (LPPAPERINFO)
                    MAKELONG(lpCurMainKeyHdr->extraOptionArray, 
                             HIWORD(lpWPXblock->WPXarrays));

                numPapers = lpCurMainKeyHdr->OptionKeyWords.w.length ;

                for (i=0; i<numPapers; i++)
                {
                    if (SuspectValue == lpPaperInfo[i].paperID)
                    {
                        KeywordSetCurrentOption(lppd , IND_PAPERINFO, i);
                        break;
                    }
                }
            }
            break;

        case  IDS_PRINTERVM:
            // Old value is in KB, new value is in bytes
            if (SuspectValue >= 100)
            {
                float fValue=((float)SuspectValue) * 1024;

                if(fValue > lpDevmode->dm2.fMaxVM)
                    fValue=lpDevmode->dm2.fMaxVM;
                else if(fValue < lpDevmode->dm2.fMinVM)
                    fValue=lpDevmode->dm2.fMinVM;

                lpDevmode->dm2.fUserVMSelection = fValue;
            }
            break;
        
        case  IDS_JOBTIMEOUT:
            lpDevmode->dm2.iJobTimeout = SuspectValue;
            break;
        case  IDS_WAITTIMEOUT:
            lpDevmode->dm2.iWaitTimeout = SuspectValue;
            break;
        case  IDS_SCREENFREQUENCY:
            lpDevmode->dm.ScreenFrequency = (DWORD) SuspectValue;
            lpDevmode->dm.useDefaultHalftoneParams = FALSE;
            break;
        case  IDS_SCREENANGLE:
            lpDevmode->dm.ScreenAngle = (DWORD) SuspectValue;
            lpDevmode->dm.useDefaultHalftoneParams = FALSE;
            break;
        case  IDS_MINOUTLINEPPEM:
            lpDevmode->dm2.iMinOutlinePPEM = SuspectValue;
            break;

        case  IDS_ADVFLAGS:
            lpDevmode->dm.bNegImage = ((SuspectValue & ADVF_NEGIMAGE) != 0);
            lpDevmode->dm.bMirror = ((SuspectValue & ADVF_MIRROR) != 0);
            if ((SuspectValue & ADVF_DSC) || (SuspectValue & ADVF_PERPAGE))
                lpDevmode->dm.enumDialect = DIA_PORTABLE;
            lpDevmode->dm.bColorToBlack = 
                ((SuspectValue & ADVF_COLORTOBLACK) != 0);
#ifndef ADOBE_DRIVER_42                
            lpDevmode->dm2.bCompress = ((SuspectValue & ADVF_COMPRESS) != 0);
#endif            
            lpDevmode->dm2.bErrHandler = 
                ((SuspectValue & ADVF_ERRHANDLER) != 0);
            if (SuspectValue & ADVF_NODOWNLOAD)
                lpDevmode->dm2.iTTSubsFmtSource = TTSUBSFORMAT_USEPRINTER;
            else if (SuspectValue & ADVF_SUBFONTS)
                lpDevmode->dm2.iTTSubsFmtSource = TTSUBSFORMAT_TABLE;
            else
                lpDevmode->dm2.iTTSubsFmtSource = TTSUBSFORMAT_DOWNLOADTT;
            if (SuspectValue & ADVF_TYPE3)
                lpDevmode->dm2.iDLFontFmt = TT_DLFORMAT_TYPE3;
            else if (SuspectValue & ADVF_TRUETYPE)
                lpDevmode->dm2.iDLFontFmt = TT_DLFORMAT_TRUEIMAGE;
            else if (SuspectValue & ADVF_TYPE3)
                lpDevmode->dm2.iDLFontFmt = TT_DLFORMAT_TYPE1;
            break;

        case IDS_CONTROLD_LEADING:
            lpDevmode->dm2.bSendCtrlDBefore = (SuspectValue != 0);
            break;

        case IDS_CONTROLD_TRAILING:
            lpDevmode->dm2.bSendCtrlDAfter = (SuspectValue != 0);
            break;

        default:
            break;
    }
}


void MergeFromProfile(LPBYTE section, WORD key, LPWPXBLOCKS lpWPXblocks,
                      LPPSEXTDEVMODE lpDevmode, LPBYTE lpProfile, 
                      LPPDEVICE lppd)
{
   char idsBuf[40];
   int  value;   
    
   LoadString(ghDriverMod, key, idsBuf, sizeof(idsBuf));  // into idsBuf

   value = GetInt(section, idsBuf, -1, lpProfile) ;

   if(key == IDS_PAPERSOURCE)
   {
      if (value == -1)
      {
         value = ExtractDefInputSlotFromWPD(STRREF_TO_PTR(lpWPXblocks->WPXstrings, 
                    ((LPPRINTERINFO)lpWPXblocks->WPXprinterInfo)->modelname)) ;
      }

      // If we fail, check to see if it's an internal resource.
      if (value == -1)
      {
         value = ExtractDefInputSlotFromInternalWPD(
            STRREF_TO_PTR(lpWPXblocks->WPXstrings, 
            ((LPPRINTERINFO)lpWPXblocks->WPXprinterInfo)->modelname)) ;
      }
   }
   if (value != -1)
   {
      MergeValue(key, value, lpWPXblocks, lpDevmode, lppd);

      if((key==IDS_PAPERSOURCE) && (lpDevmode->dm.dm.dmDefaultSource != value))
      {
          char szFormat[20];

          // If a printer was using a paper source that existed under win31
          // but no longer exists in the win95 PPD, we need to do some
          // extra massaging to win.ini in order to ensure that we end up
          // with the correct paper size. If X is the old default paper size
          // and Y is the new default size, move the value associated
          // with feedX to feedY.

          LoadString(ghDriverMod,IDS_PAPERX,szFormat,sizeof(szFormat));
          wsprintf(idsBuf,szFormat,value);

          value=GetInt(section,idsBuf,-1,lpProfile);
          if(-1 != value)
          {
             char szValue[10];

             wsprintf(idsBuf,szFormat,lpDevmode->dm.dm.dmDefaultSource);
             wsprintf(szValue,"%d",value);

             if(lpProfile)
                WritePrivateProfileString(section,idsBuf,szValue,lpProfile);
             else
                WriteProfileString(section,idsBuf,szValue);
          }
      }
   }
}


void MergePaperSizeFromProfile(LPBYTE section, LPWPXBLOCKS lpWPXblocks,
                               LPPSEXTDEVMODE lpDevmode, LPBYTE lpProfile, 
                               LPPDEVICE lppd)
{
    LPMAINKEYHDR    lpCurMainKeyHdr ;
    LPINPUTSLOTINFO lpInputSlotInfo ;
    LPPRINTERINFO   lpPrinterInfo = (LPPRINTERINFO)lpWPXblocks->WPXprinterInfo;
    int             value;   
    WORD            slotIndex;
    char            tmpBuf[40], idsBuf[40];
        
    LoadString(ghDriverMod, IDS_PAPERX, tmpBuf, sizeof(tmpBuf));

    KeywordGetCurrentOption(lppd , IND_INPUTSLOTINFO, &slotIndex);
    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO;
    lpInputSlotInfo = 
        (LPINPUTSLOTINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray, 
                                  HIWORD(lpWPXblocks->WPXarrays));
    wsprintf(idsBuf, tmpBuf, lpInputSlotInfo[slotIndex].slotID);

    if ((value = GetInt(section, idsBuf, -1, lpProfile)) != -1)
        MergeValue(IDS_PAPERX, value, lpWPXblocks, lpDevmode, lppd);
}


void FAR PASCAL MergeProfileWithDevmode(LPWPXBLOCKS lpWPXblock, 
                                        LPPSEXTDEVMODE lpDevmode, 
                                        LPSTR lpProfile,
                                        LPSTR lpszDevName,
                                        LPSTR lpszPort)
{
    char          idsBuf[40];
    char          Section[MAX_PATH];
    LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo;
    LPPDEVICE     lppd;
    LPSTR         lpSection;
    int           len;

    if (! lpszPort)
        return;

    if (!(lppd = (LPPDEVICE) GlobalAllocPtr(GMEM_SHARE|GHND, sizeof(PDEVICE))))
        return;
    
    /* Get section name */
    lpSection = Section;

    if (lstrlen(lpszDevName) + lstrlen(lpszPort) + 2 > sizeof(Section))
        return;                             // avoid any chance of overflow

    lstrcpy(lpSection, lpszDevName);
    lstrcat(lpSection, (LPSTR) ",");
    lstrcat(lpSection, lpszPort);
    len = lstrlen(lpSection) - 1;
    if (lpSection[len] == ':')
        lpSection[len] = '\0';

    /* Make dummy Pdevice */
    lppd->lpWPXblock = lpWPXblock;
    lppd->lpPSExtDevmode = lpDevmode;

    /* CustomPaper */
    if (lpPrinterInfo->devcaps.CustomPageSize != 0xffff)
    {
        WORD max;

        MergeFromProfile(lpSection, IDS_CUSTOMWIDTH, lpWPXblock, 
                         lpDevmode, lpProfile, lppd);
        MergeFromProfile(lpSection, IDS_CUSTOMHEIGHT, lpWPXblock, 
                         lpDevmode, lpProfile, lppd);
        MergeFromProfile(lpSection, IDS_CUSTOMTRANSVERSE, lpWPXblock, 
                         lpDevmode, lpProfile, lppd);
        MergeFromProfile(lpSection, IDS_CUSTOMWIDTHOFFSET, lpWPXblock, 
                         lpDevmode, lpProfile, lppd); 
        
        max = (WORD) lpPrinterInfo->custpageinfo.width.max;
        if (lpDevmode->dm.custPaper[0].customWidth + 
            lpDevmode->dm.custPaper[0].widthOffset > (int) max)
            lpDevmode->dm.custPaper[0].widthOffset = (int) max - 
                (int) lpDevmode->dm.custPaper[0].customWidth;

        MergeFromProfile(lpSection, IDS_CUSTOMHEIGHTOFFSET, lpWPXblock, 
                         lpDevmode, lpProfile, lppd);
        
        max = (WORD) lpPrinterInfo->custpageinfo.height.max;
        if (lpDevmode->dm.custPaper[0].customHeight + 
            lpDevmode->dm.custPaper[0].heightOffset > (int) max)
            lpDevmode->dm.custPaper[0].heightOffset = (int) max - 
                (int) lpDevmode->dm.custPaper[0].customHeight;
    }

    /* Display Units */
    MergeFromProfile(lpSection, IDS_DSPUNITS, lpWPXblock, lpDevmode, lpProfile,
                     lppd);
    
    /* Copies */
    MergeFromProfile(lpSection, IDS_COPIES, lpWPXblock, lpDevmode, lpProfile,
                     lppd);

    /* Paper Orientation */
    MergeFromProfile(lpSection, IDS_ORIENTATION, lpWPXblock, 
                     lpDevmode, lpProfile, lppd);
    
    /* Margin State */
    MergeFromProfile(lpSection, IDS_MARGINS, lpWPXblock, lpDevmode, lpProfile,
                     lppd);
    
    /* Color */
    MergeFromProfile(lpSection, IDS_COLOR, lpWPXblock, lpDevmode, lpProfile,
                     lppd);

    /* Screen Frequency */
    MergeFromProfile(lpSection, IDS_SCREENFREQUENCY, lpWPXblock,
                     lpDevmode, lpProfile, lppd);

    /* Screen Angle */
    MergeFromProfile(lpSection, IDS_SCREENANGLE, lpWPXblock,
                     lpDevmode, lpProfile, lppd);

    /* Miscellaneous BOOLS */
    MergeFromProfile(lpSection, IDS_ADVFLAGS, lpWPXblock, lpDevmode, lpProfile,
                     lppd);
    
    /* Scale */
    MergeFromProfile(lpSection, IDS_SCALE, lpWPXblock, lpDevmode, lpProfile,
                     lppd);
    
    /* Output Dialect */
    MergeFromProfile(lpSection, IDS_DOEPS, lpWPXblock, lpDevmode, lpProfile,
                     lppd);
    
    /* Job Timeout */
    MergeFromProfile(lpSection, IDS_JOBTIMEOUT, lpWPXblock,
                     lpDevmode, lpProfile, lppd);

    /* Wait Timeout */
    MergeFromProfile(lpSection, IDS_WAITTIMEOUT, lpWPXblock,
                     lpDevmode, lpProfile, lppd);
    
    /* Crossover point for Type 1 outlines */
    MergeFromProfile(lpSection, IDS_MINOUTLINEPPEM, lpWPXblock,
                     lpDevmode, lpProfile, lppd);
    
    /* Duplexing Info */
    MergeFromProfile(lpSection, IDS_DUPLEX, lpWPXblock, lpDevmode, lpProfile,
                     lppd);

    /* Input slot */
    MergeFromProfile(lpSection, IDS_PAPERSOURCE, lpWPXblock, 
                     lpDevmode, lpProfile, lppd);

    /* Paper size - this should be after Input slot */
    MergePaperSizeFromProfile(lpSection, lpWPXblock, lpDevmode, lpProfile, 
                              lppd);
    
    /* Resolution */
    MergeFromProfile(lpSection, IDS_RES, lpWPXblock, lpDevmode, lpProfile,
                     lppd);

    /* Y Resolution - Note: This should be done after Resolution */
    MergeFromProfile(lpSection, IDS_YRES, lpWPXblock, lpDevmode, lpProfile,
                     lppd);

    /* Output bin */
    {
        LPMAINKEYHDR     lpCurMainKeyHdr;
        LPGENERIC_OPTION lpOptionArray;
        int              len;

        if (DoesKeywordExistByIndex(lppd, ID_KEY_OUTPUTBIN) == TRUE)
        {
            BYTE  outputBin[MAXKEYLEN];
            LPSTR wpxOutputBin;
            int   i;

            lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + 
                IND_OUTPUTBININFO;

            lpOptionArray = (LPGENERIC_OPTION)
                        MAKELONG(lpCurMainKeyHdr->OptionKeyWords.w.offset, 
                                 HIWORD(lpWPXblock->WPXarrays));
        
            LoadString(ghDriverMod, IDS_OUTPUTBIN, idsBuf, sizeof(idsBuf));

            GetString(lpSection, idsBuf, (LPSTR) "", outputBin, 
                      sizeof(outputBin), lpProfile);

            if (outputBin[0])
            {
                //  verify string matches one of the ones in outputBinInfo
                for (i=0; i<(int)lpCurMainKeyHdr->OptionKeyWords.w.length; i++)
                {
                    wpxOutputBin = (LPSTR) 
                        MAKELONG(lpOptionArray->OptionTranslation.w.offset, 
                                 HIWORD(lpWPXblock->WPXstrings));
                    len = lpOptionArray->OptionTranslation.w.length;
                    if (! lstrcmpn(outputBin, wpxOutputBin, len) &&
                        (lstrlen(outputBin) == len))
                    {
                        KeywordSetCurrentOption(lppd , IND_OUTPUTBININFO, i);
                        break;
                    }
                    lpOptionArray++;
                }
            }
        }
    }

    /* Leading & trailing Control D */
    MergeFromProfile(lpSection, IDS_CONTROLD_LEADING, lpWPXblock, lpDevmode, 
                     lpProfile, lppd);
    MergeFromProfile(lpSection, IDS_CONTROLD_TRAILING, lpWPXblock, lpDevmode, 
                     lpProfile, lppd);
    
    /* Favor TrueType */
    MergeFromProfile(lpSection, IDS_FAVORTT, lpWPXblock, lpDevmode, lpProfile,
                     lppd);

    /* Download header per job */
    MergeFromProfile(lpSection, IDS_HEADER, lpWPXblock, lpDevmode, lpProfile,
                     lppd);

    /* VM Selection */
    MergeFromProfile(lpSection, IDS_PRINTERVM, lpWPXblock, 
                     lpDevmode, lpProfile, lppd);

    /* server loop password */
    {
        BYTE  buffer[MAXKEYLEN];

        LoadString(ghDriverMod, IDS_PASSWORD, idsBuf, sizeof(idsBuf));
        GetString(lpSection, idsBuf, (LPSTR) "", (LPSTR) buffer,
                  sizeof(lpDevmode->dm2.password), lpProfile);
        if (buffer[0])
            lstrcpy(lpDevmode->dm2.password, (LPSTR) buffer);
   }

   // Blow away entire section
   if(lpProfile)
      WritePrivateProfileString(lpSection,NULL,NULL,lpProfile);
   else
      WriteProfileString(lpSection,NULL,NULL);

   if (lppd)
      GlobalFreePtr(lppd);
}


