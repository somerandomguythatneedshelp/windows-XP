/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: UPGRADE.H                                              */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

/* From \ddk\printers\ps35\profile.h */
/* bit fields for booleans in advanced dialog */
#define ADVF_NEGIMAGE   1
#define ADVF_PERPAGE    2
#define ADVF_DSC        4
#define ADVF_TYPE1      8
#define ADVF_SUBFONTS   16
#define ADVF_MIRROR     32
#define ADVF_COLORTOBLACK   64 
#define ADVF_COMPRESS   128
#define ADVF_TRUETYPE   256
#define ADVF_ERRHANDLER 512
#define ADVF_NODOWNLOAD 1024
#define ADVF_TYPE3      2048

/* From adobeps.drv */
#define MAX_PPD_NICKNAME_LEN       127
// if you change MAX_PPD_MODELNAME_LEN, you also need to change
// the defination in the INSTALLER and ICMTOOLS.  jjia,  2/14/96
#define MAX_PPD_MODELNAME_LEN      127

/* Pscript string ID's */
#define IDS_PAPERX             12000
#define IDS_PAPERSOURCE        12001
#define IDS_ORIENTATION        12002
#define IDS_COLOR              12003
#define IDS_JOBTIMEOUT         12004
#define IDS_WAITTIMEOUT        12005
#define IDS_MARGINS            12006
#define IDS_HEADER             12007
#define IDS_SCALE              12008
#define IDS_DSPUNITS           12009
#define IDS_CONTROLD_LEADING   12010
#define IDS_CONTROLD_TRAILING  12011
#define IDS_CUSTOMTRANSVERSE   12012
#define IDS_CUSTOMWIDTHOFFSET  12013
#define IDS_CUSTOMHEIGHTOFFSET 12014
#define IDS_PASSWORD           12015
#define IDS_OUTPUTBIN          12016
#define IDS_DOEPS              12017
#define IDS_DUPLEX             12018
#define IDS_RES                12019
#define IDS_YRES               12020
#define IDS_SCREENFREQUENCY    12021
#define IDS_SCREENANGLE        12022
#define IDS_ADVFLAGS           12023
#define IDS_PRINTERVM          12024
#define IDS_CUSTOMWIDTH        12025
#define IDS_CUSTOMHEIGHT       12026
#define IDS_CUSTOMUNIT         12027
#define IDS_MINOUTLINEPPEM     12028
#define IDS_FAVORTT            12029
#define IDS_LANDSCAPEORIENT    12030
#define IDS_COPIES             12031
#define IDS_EPSFILE            12032

#define IDS_INI_PSCRIPT        12033
#define IDS_INI_INTL           12034
#define IDS_INI_INT_MEASURE    12035
#define IDS_INI_DECIMAL        12036

/* Misc ID's put here for now to avoid disturbing 2.1 development and
   making Chicago merges more difficult. Must move to proper places later. */
#define IDS_TRUEIMAGE          12100
#define ADDPRN_szModelName     12101
#define IDS_STANDARD_PAPER     12102
#define IDS_STANDARD_OUTPUT    12103
#define IDS_CUSTOM_SIZE_OPTION      12104
#define IDS_CUSTOM_SIZE_DISPLAY     12105
#define IDS_OUTPUT_SPEED            12106
#define IDS_OUTPUT_PORTABILITY      12107
#define IDS_OUTPUT_EPS              12108
#define IDS_OUTPUT_ARCHIVE          12109
#define IDS_OUTPUT_PJL_ARCHIVE      12110

/* New Microsoft required keywords */
#define ID_PPDSTR_KEY_MS_HEADER        11000
#define ID_PPDSTR_KEY_MS_FAVORTT       11001
#define ID_PPDSTR_KEY_MS_TRANSVERSE    11002
#define ID_PPDSTR_KEY_MS_COMPRESS_BM   11003
#define ID_PPDSTR_KEY_MS_CLEAR_VM_PP   11004
#define ID_PPDSTR_KEY_MS_MIN_OUTLINE   11005
#define ID_PPDSTR_KEY_MS_PRINTER_VM    11006
#define ID_PPDSTR_KEY_MS_PRINTMIRROR   11007
#define ID_PPDSTR_KEY_MS_PRINTNEGATIVE 11008

#define ID_PPDSTR_KEY_COLOR            11010
#define ID_PPDSTR_BASE_COLOR           11011
#define COLOR_GRAYSCALE                0
/* #define COLOR_ALLCOLORSTOBLACK         1 */
#define COLOR_FULLCOLOR                1
#define COLOR_MONITORCOLOR             2
#define COLOR_DEVICEINDEPENDENTCOLOR   3
#define COLOR_FIRST COLOR_GRAYSCALE
#define COLOR_LAST  COLOR_DEVICEINDEPENDENTCOLOR

#define ID_PPDSTR_KEY_CUSTOMWIDTH      11020
#define ID_PPDSTR_KEY_CUSTOMHEIGHT     11021
#define ID_PPDSTR_KEY_CUSTOMNAME       11022
#define CUSTOM_FIRST                   1
#define CUSTOM_LAST                    3
#define APP_DEFINED          CUSTOM_LAST

#define ID_PPDSTR_KEY_LAYOUT           11040
#define ID_PPDSTR_BASE_LAYOUT          11041
#define LAYOUT_1_UP                    0
#define LAYOUT_2_UP                    1
#define LAYOUT_4_UP                    2
#define LAYOUT_FIRST         LAYOUT_1_UP
#define LAYOUT_LAST          LAYOUT_4_UP

#define ID_PPDSTR_KEY_INSTALLEDMEMORY  11060
#define ID_PPDSTR_KEY_VMOPTION         11061
#define ID_PPDSTR_KEY_FREEVM           11062
#define ID_PPDSTR_KEY_TTSUBSFORMAT     11063
#define ID_PPDSTR_KEY_OUTPUTFORMAT     11064
#define ID_PPDSTR_KEY_DATAFORMAT       11065
#define ID_PPDSTR_KEY_USER_HALFTONING  11066
#define ID_PPDSTR_KEY_USER_SCREENFREQUENCY 11067
#define ID_PPDSTR_KEY_USER_SCREENANGLE     11068
#define ID_PPDSTR_KEY_SCREENFREQUENCY_RES  11069
#define ID_PPDSTR_KEY_SCREENANGLE_RES      11070
#define ID_PPDSTR_KEY_SCREENANGLE_RES      11070
#define ID_PPDSTR_KEY_SCREENANGLE_RES      11070
#define ID_PPDSTR_KEY_SCREENANGLE_RES      11070
#define ID_PPDSTR_KEY_PJL_PROTOCOL         11071
#define ID_PPDSTR_KEY_DSC_CONFORMANCE      11072
#define ID_PPDSTR_KEY_VM_TRACKING          11073
#define ID_PPDSTR_KEY_FACTORY_JOBTIMEOUT   11074
#define ID_PPDSTR_KEY_FACTORY_WAITTIMEOUT  11075


#define OUTPUTFORMAT_SPEED             0
#define OUTPUTFORMAT_PORTABILITY       1
#define OUTPUTFORMAT_EPS               2
#define OUTPUTFORMAT_ARCHIVE           3

#define DATAFORMAT_ASCII               0
#define DATAFORMAT_ASCII_NO_CTRL_D     1
#define DATAFORMAT_BCP                 2
#define DATAFORMAT_TBCP                3
#define DATAFORMAT_BINARY              4

/* Defaults and limits from dmg\drvstat4.c. Must put in common
   include file later */

#define DEF_SCALING_PERCENT 100
#define MIN_SCALING_PERCENT 25
#define MAX_SCALING_PERCENT 400
#define DEF_COPIES 1
#define MIN_COPIES 1
#define MAX_COPIES 32767
#define DEF_WAITTIMEOUT 240
#define MIN_WAITTIMEOUT 0
#define MAX_WAITTIMEOUT 999
#define DEF_JOBTIMEOUT  0
#define MIN_JOBTIMEOUT  0
#define MAX_JOBTIMEOUT  999

#ifdef ADOBE_DRIVER_42
#define MIN_PSLEVEL  2
#define MAX_PSLEVEL  3 
#endif

/* Misc defines */
#define NOT_FOUND               -1
#define MIN_OUTLINE_PPEM_LOW    10
#define MIN_OUTLINE_PPEM_HIGH   32000
#define MIN_OUTLINE_PPEM_DEF    100

/* All printer memory units are in K's */
#define PRINTER_VM_LOW   0
#define PRINTER_VM_HIGH  200000    //changed from 25600 for no apparent reasons
#define PRINTER_VM_DEF   256
#define INCR_VM          256

/* All printer font cache units are in K's */
#define PRINTER_FCACHE_LOW   0
#define PRINTER_FCACHE_HIGH  25600
#define PRINTER_FCACHE_DEF   256
#define INCR_FCACHE          256


/* Need to put into protos.h */
short FAR PASCAL PPDCreateBinaryKeyword(HANDLE pihdl, int keyword_id,
   BOOL val) ;
short FAR PASCAL PPDCreateIntParamKeyword(HANDLE pihdl, int keyword_id,
   int ival, int lo_lim, int hi_lim) ;

/* up_key.c */
short FAR PASCAL PPDInitPrinterRec(LPPDEVICE lppd, HANDLE pihdl);
short FAR PASCAL PPDInitPrinterRec21(LPPDEVICE lppd, HANDLE pihdl);
short FAR PASCAL PPDInitPrinterRecMicrosoft(HANDLE pihdl);

/* upgrade.c */
void FAR PASCAL MergeProfileWithDevmode(LPWPXBLOCKS lpWPXblock, 
                                        LPPSEXTDEVMODE lpDevmode, 
                                        LPSTR lpProfile,
                                        LPSTR lpszDevName,
                                        LPSTR lpszPort);

