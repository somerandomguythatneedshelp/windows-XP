/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PRNTRMGR.H                                                   */
/*                                                                           */
/* Description: This module contains the function prototypes for prntrmgr.c  */
/*                                                                           */
/*****************************************************************************/

typedef LPSTR FAR *LPLPSTR;

short FAR PASCAL OpenPrntrMgr  (LPSTR,LPSTR,HANDLE FAR *, HDC FAR *);
short FAR PASCAL WritePrntrMgr(LPSTR,WORD,HANDLE);
short FAR PASCAL WritePrntrMgrLine(short resid,HANDLE);
short FAR PASCAL WritePrntrMgrDSC(short sDSCid, LPSTR pInfoString,HANDLE);
short FAR PASCAL ClosePrntrMgr(HANDLE,HDC);
int  FAR PASCAL GetResource   (LONG,LPLPSTR,LPWORD,HANDLE FAR *);
void FAR PASCAL RemoveResource(HANDLE hMem);

