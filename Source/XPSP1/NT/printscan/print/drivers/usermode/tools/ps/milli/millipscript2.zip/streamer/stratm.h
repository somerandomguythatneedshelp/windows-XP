/* CM_VerSion atm.h atm05 1.4 10184.eco sum= 44600 */
/* CM_VerSion atm.h atm04 1.18 08340.eco sum= 15372 */
/*
  atm.h

Copyright (c) 1991-1993 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of
Adobe Systems Incorporated.  Many of the intellectual and
technical concepts contained herein are proprietary to Adobe,
are protected as trade secrets, and are made available only to
Adobe licensees for their internal use.  Any reproduction or
dissemination of this software is strictly forbidden unless
prior written permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks of
Adobe Systems Incorporated.

Original version:
Edit History:
John Nogrady: Thu May  7 10:17:16 1992
Ed Taft: Wed Sep 29 14:40:35 1993
Craig Rublee: Thu Nov  4 18:09:00 PST 1993
End Edit History.

*/

/*
This file includes definitions for ATM compiler switches, operating
system, client, and environment dependent macros, and macros common to
buildch and other ATM modules (font parser). This should be the first
include file for all ATM source modules. Any additional system or
environment dependent definitions should be included in this file.
Currently there is a copy of this file in the "buildch" package and
the "adobe bc" product. These copies should be kept identical.
*/

#ifndef ATM_H
#define ATM_H

/* In the PostScript development enviroment PACKAGE_SPECS is defined as
   a header file that defines the path and file names of all the
   header files.  In non PostScript development environments
   PACKAGE_SPECS is defined as the file package.h. Package.h then
   defines the path and files names for the header files use in
   the non PostScript enviroment. It also has includes for system depedent
   header files.

   PSENVIRONMENT is set to 0 if this is being compiled outside the
   PostScript Development Environment.

   NOTE: If this file is being used in the PostScript world
   the comments around #include ERROR and #include UTIL must be removed 
   and comments must be added around the two #includes of OSSYSLIB. 
   The ps_manager tools have problems with interfaces that do not exist in 
   the world that is being built.

   When switching between PostScript and non-PostScript environments,
   all lines containing the comment BUILDING FOR POSTSCRIPT must be
   switched as described in the comments.

*/

#ifndef PSENVIRONMENT
#define  PSENVIRONMENT (0) /* 1 WHEN BUILDING FOR POSTSCRIPT, ELSE 0 */
#endif

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif

#ifndef PACKAGE_SPECS_H
#include PACKAGE_SPECS
#endif

#include ENVIRONMENT
#include PUBLICTYPES
#include PROTOS
#if PSENVIRONMENT
/*  #include UTIL  */ /* UNCOMMENT THIS INCLUDE WHEN BUILDING FOR POSTSCRIPT */
/*  #include ERROR */ /* UNCOMMENT THIS INCLUDE WHEN BUILDING FOR POSTSCRIPT */
#include EXCEPT
#endif

#ifndef DEVICE_CONSISTENT
#define DEVICE_CONSISTENT 1
#endif /*DEVICE_CONSISTENT*/

#ifndef GLOBALCOLORING
#define GLOBALCOLORING (1)    /* Turn on code for hinting Kanji Characters */
#endif

#ifndef DEBUG
#define DEBUG (0)
#endif



#if !PSENVIRONMENT

/**********  System-dependent include files  *********/

#if OS==os_sun
/*  removed because of conflict with gcc built-in #include <memory.h> */
#define STRING_H /* added because of conflicts with gcc built-in */
#include <fcntl.h>              /* main.c needs this */
#include OSSYSLIB  /* COMMENT OUT THIS INCLUDE WHEN BUILDING FOR POSTSCRIPT */
#define labs(x) ((x)<0?-(x):(x))
#endif

#if OS==os_mach
#define MALLOC_H
#include <memory.h>
#include <fcntl.h>              /* main.c needs this */
#include <stdlib.h>
#include OSSYSLIB /* COMMENT OUT THIS INCLUDE WHEN BUILDING FOR POSTSCRIPT */
#endif

#if OS==os_aix
#include <memory.h>
#include <fcntl.h>              /* main.c needs this */
#include <stdlib.h>
#endif

#if OS==os_mri
#include <stdlib.h>
#include <math.h>
#include "relalloc.h"
#define MALLOC_H
#endif

#if OS==os_msdos || OS==os_os2 || OS==os_os2_32bit 
#include <stdlib.h>
#include <memory.h>
#include <fcntl.h>              /* main.c needs this */
#endif

#if OS==os_windows3
/* need strtol, atoi, atol, ...? */
#include <stdlib.h>
#include "atmtypes.h"
/* #define labs ABS */
#else /* OS!=os_windows3 */
#if OS!=os_os2_32bit
#define cdecl
#endif
#define FARFUNC
#define FARVAR
#define NEARFUNC
#define NEARVAR
#endif

#if OS==os_thinkc
#define MALLOC_H
#define STRING_H
#include <string.h>
#if 0 /* think c doesn't seem to need these anymore. rff 04/25/94 */
#include <unix.h>
#include "thinkclib.h"
#else
#include <stdio.h>
#endif /* if 0 */
#endif

#if OS==os_mpw
#include <stdlib.h>
#include <string.h>
#include OSSYSLIB /* COMMENT OUT THIS INCLUDE WHEN BUILDING FOR POSTSCRIPT */
#endif

/* Defaults */
#ifndef MALLOC_H                /* Include malloc if we haven't already */
#include <malloc.h>
#endif
#ifndef STRING_H                /* Include strings if we haven't already */
#include <string.h>
#endif



/* The following definitions are used by the buildch package and the
   ATM parse code
*/

/* Inline Procedures */

/**********  System-dependent procs *********/

#define CantHappen() BCERROR(BE_CANTHAPPEN) /* called by the macro Assert */
#define os_free         free
#define os_labs         labs
#define os_atof         atof
#define os_strlen       strlen
#define os_sqrt         sqrt
#define os_cos          cos
#define os_sin          sin
#define os_bcopy    	bcopy
#define os_bzero    	bzero
#define os_strcpy	strcpy
#define os_strncpy	strncpy
#define os_strcmp	strcmp
#define os_strncmp	strncmp
#define os_sprintf	sprintf
/* MEMMOVE doesn't check for overlap so I use memcpy here */
#define os_memcpy	memcpy
#define os_isspace	isspace

#if OS==os_msdos
#define os_malloc(x) malloc((size_t)x)
#define os_realloc(x,y) realloc(x,(size_t)y)
#else
#define os_malloc       malloc
#define os_realloc      realloc
#endif /* os_msdos */

#ifndef BCMAIN
#define BCMAIN (0)
#endif /* BCMAIN */

/* MEMMOVE(src, dest, len)  Copy a region of memory.  len in bytes. */
  /* WARNING: This does NOT check for overlapping memory areas */
/* MEMZERO(dest, len)  Zero out a region in memory.  len in bytes. */


#if OS==os_sun || OS==os_mri
#define MEMMOVE(src, dest, len) memcpy(dest, src, len)
#define MEMZERO(dest, len) memset(dest, 0, len)
#endif

#if OS==os_msdos || OS==os_os2 || OS==os_windows3 || OS==os_os2_32bit 
#define MEMMOVE(src, dest, len) memcpy(dest, src, (unsigned)(len))
#define MEMZERO(dest, len) memset(dest, 0, (unsigned)(len))
#endif



#if OS==os_thinkc
#define MEMMOVE(src, dest, len) \
  { register char *__s, *__d;  register long __l; \
    __s = (char *)(src); __d = (char *)(dest);  __l = (long)(len); \
    while (--__l >= 0) *__d++ = *__s++; \
  }
#define MEMZERO(dest, len) \
  { register char *__d;  register long __l; \
    __d = (char *)(dest);  __l = (long)(len); \
    while (--__l >= 0) *__d++ = 0; \
  }
#if 0  /* Think C does not like this definition */
extern char *os_malloc(long int nbytes);
#endif
/* If CScan cannot render the character with the initial cross buffer size,
   the client will get a callback to grow the buffer in increments of
   CSCAN_MIN_INCR to CSCAN_MAX_BUFSIZE.
   If the buffer is grown another attempt will be made to render a character.
   This will repeat for CSCAN_RETRIES number of times.
*/
/* Define how to alloc memory during cscan.                             */
#define CSCAN_MAX_BUFSIZE MAXInt32   /* Grow until there is no more memory */
#define CSCAN_BUF_INCR (7000)
#define CSCAN_RETRIES   500     /* Ken - Really, I don't _care_ how many times it retries.... */

#endif

/* DEFAULTS */
#ifndef MEMMOVE
#define MEMMOVE(src, dest, len) os_bcopy(src, dest, len)
#define MEMZERO(dest, len) os_bzero(dest, len)
#endif

/************* end non-postscript environment */

#else  /* PSENVIROMNEMT */

#define BCMAIN  (0) /* for 2ps environment */

/* If CScan cannot render the character with the initial cross buffer size,
   the client will get a callback to grow the buffer in increments of
   CSCAN_MIN_INCR to CSCAN_MAX_BUFSIZE.
   If the buffer is grown another attempt will be made to render a character.
   This will repeat for CSCAN_RETRIES number of times.
*/

#define CSCAN_MAX_BUFSIZE 65536   /* Grow to  64K bytes */
#define CSCAN_BUF_INCR 8192
#define CSCAN_RETRIES   6


/* MEMMOVE(src, dest, len)  Copy a region of memory.  len in bytes. */
  /* WARNING: This does NOT check for overlapping memory areas */
/* MEMZERO(dest, len)  Zero out a region in memory.  len in bytes. */

#define MEMMOVE(src, dest, len) os_bcopy(src, dest, len)
#define MEMZERO(dest, len) os_bzero(dest, len)

#endif /* PSENVIROMNEMT */

#define BC_DURING_HANDLER (!PSENVIRONMENT)
#if BC_DURING_HANDLER

/* Exception handler declarations */

#include <setjmp.h>
#if !WINATM
extern int setjmp ARGDECL1(jmp_buf, jb);
extern procedure longjmp ARGDECL2(jmp_buf, jb, int, rval);
#endif /*!WINATM*/
/* global exception handling values declared in buildch.c */

#define BC_DURING_MAX_NESTING 2    /* Nesting level for setjmp calls */
global jmp_buf bcBuildError[BC_DURING_MAX_NESTING];
global IntX bcErrorIndex;
global procedure BCERROR ARGDECL1(int, code); /* defined in buildch.c */

#if BCMAIN
global procedure PrintJmpBuf ARGDECL0();
#endif

#define BCOutOfMemory() BCERROR(BE_MEMORY) /* ATM definition */
#define BC_DURING { int bcJmpVal; if (0 == (bcJmpVal = setjmp(bcBuildError[bcErrorIndex++]))) {
#define BC_HANDLER --bcErrorIndex; } else {--bcErrorIndex; 
#define BC_RERAISE  return bcJmpVal
#define BC_END_HANDLER }  }
#define BC_ExceptionCode  bcJmpVal
#define BC_LimitCheck BE_MEMORY

#else /* !BC_DURING_HANDLER */
/* Mercury definition */
#define BCOutOfMemory() RAISE(ecLimitCheck, (char *) NIL)
/* use the definitions from except.h in the pslib package */
#define BC_DURING DURING
#define BC_HANDLER HANDLER
#define BC_RERAISE RERAISE
#define BC_END_HANDLER END_HANDLER
#define BC_ExceptionCode Exception.Code
#define BC_LimitCheck ecLimitCheck

#endif


#if ISP==isp_i80286 || OS==os_thinkc
#define MUL16(x, y) (Int32)((Int32)(x) * (Int32)(y))
#endif
/* Defaults */
#ifndef MUL16
#define MUL16(x, y) ((x) * (y))
#endif


#ifndef CSCAN_BUF_INCR
#define CSCAN_MAX_BUFSIZE 65504	/* Back off from 64K because overhead */
				/* usually mean actual 64K cann't be reached */
#define CSCAN_BUF_INCR (8188)	/* 1/8th the max.  Works with value below */
#define CSCAN_RETRIES   8 /* After 8 tries it CAN'T get more garuanteed! */
#endif

#define FixedZero   (Fixed)0x0L
#define FixedHalf       (Fixed)0x00008000L
#define FixedOne        (Fixed)0x00010000L
#define FixedTwo        (Fixed)0x00020000L

#define FIXEDZERO   FixedZero
#define FIXEDHALF       FixedHalf
#define FIXEDONE        FixedOne
#define FIXEDTWO        FixedTwo


#define MAXFixed MAXInt32
#define MINFixed MINInt32


/*
 SubtractPtr
   This macro is required for Microsoft C 6.x and 7.0 and possibly other Intel
   compilers that target the 80x86 64K segment architecture. When doing
   pointer arithmetic, only the segment offsets are used. The offsets
   are unsigned int16s, but the difference is represented as an int16.
   Therefore, when the pointers are more than 32767 bytes apart, the
   difference overflows. This happens even when the pointers point to
   structs that are larger than 2 bytes; the difference is calculated
   and put into an int16, no overflow check is performed, the int16 is
   extended to an int32 and divided by the struct size.

   Therefore, first get the byte difference between the pointers, cast
   the result to an unsigned, and then divide by the struct size.
   Nabeel Al-Shamma 9-Apr-1992
*/
#if ISP==isp_i80286
#define SubtractPtr(p0, p1)     \
        ((unsigned)((char *)(p0)-(char *)(p1))/sizeof(*(p0)))
#else
#define SubtractPtr(p0, p1)     ((p0) - (p1))
#endif

/*
** T1MODEL definitions -- these specify the type1 chip
** environment on which the code is being executed
** These definitions must included in both the non-postscript
** and postscript implementations.
*/

#define unknown_model 0x0  /* Unknown environment */
#define at_model      0x1  /* type 1 Chip on PC/AT bus board */
#define sw_model      0x2  /* Using Type 1 Chip Software Model */
#define mac_model     0x3  /* type 1 chip on NuBus board (Mac) */
#define mc_model      0x4  /* Type 1 chip on microchannel board */
#define nesa_model    0x5  /* Type 1 Chip on nesa board (PC/NEC bus) */
#define ps_model      0x6  /* Type 1 Chip in Level 2 PostScript */
#define pcdos_model   0x7  /* Generic IBM DOS model (isa/mc/eisa/nesa) */
#define pcwin3_model  0x8  /* Generic IBM WIN3 model */
#define eisa_model    0x9  /* PC/ EISA Bus */
#define psv_model     0xa  /* Level 2 Postscript using virtual memory */
#endif /* ATM_H */
