/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TSTUBS.C                                                     */
/*                                                                           */
/* Description: This module contains the functions for                       */
/*                                                                           */
/* Change History:                                                           */
/* L3_CLIP --  Level3 clipsave cliprestore support. 9/13/96 jjia             */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_TGRAPHSEG)


#define NOTSRCAND       (DWORD)0x00220326 // From MS Driver v. 3.5, strchblt.c


/***************************************************************************
*                               GetByteAddress
*  Purpose:
*       Returns pointer to the byte of the bitmap specified by lpDevBitmap
*       which contains the pixel with the coordinates (wX,wY).
*
*  Parameters:
*       LPBITMAP lpDevBitmap --
*       WORD        wX --
*       WORD        wY --
*    
*  Returns: LPSTR
*                                                                           
***************************************************************************/
LPSTR FAR PASCAL GetByteAddress(LPBITMAP lpDevBitmap, WORD wX, WORD wY)
{
   DWORD dwOffset;  // Offset for the beginning of the wY-the line    
   WORD  wSegFix;   // Segment fix
   WORD  wOffFix;   // Offset fix
   
   BYTE  huge *lpBits;    // Pointer to bits in the bitmap
   WORD  wScans;    // How many scan lines  per segment (may be 0)
   
   
   lpBits = (BYTE huge *) lpDevBitmap->bmBits;
   wScans = lpDevBitmap->bmScanSegment;
   
   
   if( lpDevBitmap->bmSegmentIndex != 0 )  // Huge bitmap
   {
      wSegFix = lpDevBitmap->bmSegmentIndex * ( wY / wScans ) ;
      wOffFix = (wY % wScans)  * lpDevBitmap->bmWidthBytes ; 
   }
   else 
   {
      //************************************************************
      //   CAUTION !!!!
      //   Because we convert DIBToDevice call to the DevStretchBlt
      //   call with fake bitmap structure which has bmSegmentIndex
      //   and bmScanSegment set to 0, we sometimes can have the bitmap
      //   which looks like non-Huge bitmap, but actually has more than
      //   64K bytes of data. 
      //   The special handling is added for this case:
      //      26-Feb-1993   -by-   [olegs]
      // also 03-Jun-1994   -by-   [olegs]
      dwOffset =   lpDevBitmap->bmWidthBytes * (DWORD) wY ; // Can be > 64K
      
      wSegFix =(WORD)( 8 * ( dwOffset / 0x10000L));// Actually we should take
                                                   // __AHIncr, but .....
      wOffFix =(WORD)( dwOffset % 0x10000L ) ;
   }
   
   lpBits = lpBits + wOffFix;                          // Fix the offset
   lpBits = (BYTE huge *) MAKELONG( LOWORD(lpBits),
                                                HIWORD(lpBits) + wSegFix );
   
   lpBits = lpBits +  ( wX >> 3 ) ;   // Point to the proper byte 
   return (lpBits);
   
}  // END GetByteAddress



/***************************************************************************
*                               TArcDirection
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       BYTE      Direction --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TArcDirection(LPPDEVICE lppd, BYTE Direction)
{
   lppd->graphics.bArcDirection=Direction; // CLOCKWISE or CCW
   return(RC_ok)                         ; // From ESCSetArcDirection

}  // END TArcDirection


/***************************************************************************
*                               TBackgroundMode
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       BYTE      BackgroundMode --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TBackgroundMode(LPPDEVICE lppd, BYTE BackgroundMode)
{
   lppd->graphics.bBackgroundMode=BackgroundMode;       // OPAQUE or TRANSPARENT
   return(RC_ok)                                ;

}  // END TBackgroundMode 


//***************************************************************************
//
//    Set of functions to output the bitmap
//
//***************************************************************************

#ifndef ADOBEPS42
/***************************************************************************
*                               TBitmapHeader
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       LPRECT    SrcRect --
*       LPRECT    DstRect --
*       DWORD     rop --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TBitmapHeader(LPPDEVICE lppd, LPRECT SrcRect,LPRECT DstRect,
                               DWORD rop)
{
   FLAG      Polarity                            ;
   
   int SrcX   = SrcRect->left                    ;       // Src rect dimensions
   int SrcY   = SrcRect->top                     ;       //     "         "      "
   int SrcXE  = SrcRect->right    - SrcX    ;       //     "         "      "
   int SrcYE  = SrcRect->bottom   - SrcY    ;       //     "         "      "
   
   int DestX  = DstRect->left                    ;       // Dest rect dimensions
   int DestY  = DstRect->top                     ;       //     "         "      "
   int DestXE = DstRect->right    - DestX       ;       //     "         "      "
   int DestYE = DstRect->bottom   - DestY       ;       //     "         "      "
   
   int byte_width =( SrcXE + 7 )>>3 ;
   short retval;
   LPASCIIBINPTRS tempptr;
   
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   retval = TokenNeedsProcset(lppd,BITBLT);
   if (RLEDecodeNeeded(lppd))
       TokenNeedsProcset(lppd, RLE_DECODE);
   
   switch(rop)                                           // containing bitmap
   {
   
      case NOTSRCAND :
      case NOTSRCCOPY:
      // EUDC Character is prited by BitBlt called from FE GDI.
      // This ROP have to be printed 1 = black and 0 = white.
      // This code have to be reviewed after application compatibility testing.
      case 0x00E20746:
         Polarity = TRUE                       ;       // 1 = black  0 = white
         break                                 ;
      
      default    :      // All other rops = SRCAND
         Polarity = FALSE                      ;       // 1 = white  0 = black
         break                                    ;
   }                                                     // End switch(rop)


   (*tempptr->PSSendShort)(lppd,SrcXE);          // Src width in pixels
   (*tempptr->PSSendShort)(lppd,SrcYE);          // Src height in scanlines
   (*tempptr->PSSendShort)(lppd,1);              // Bits per pixel
   (*tempptr->PSSendShort)(lppd,byte_width);     // Src bytes per scanline
   (*tempptr->PSSendShort)(lppd,DestXE);         // Dest width
   (*tempptr->PSSendShort)(lppd,DestYE);         // Dest height
   (*tempptr->PSSendShort)(lppd,DestX);          // Dest origin - x
   (*tempptr->PSSendShort)(lppd,DestY);          // Dest origin - y
   (*tempptr->PSSendBoolean)(lppd,FALSE);        // Smoothflag
   (*tempptr->PSSendBoolean)(lppd,Polarity);     // Polarity
   (*tempptr->PSSendBitMapType)(lppd,PPSLEVEL1); // Data type
   (*tempptr->PSSendCRLF)(lppd);
   
   return(retval)                                ;
   
}  // END TBitmapHeader

/***************************************************************************
*                               TBitmapOperator
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       DWORD     FGColor --
*       DWORD     BGColor --
*       DWORD     rop --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TBitmapOperator(LPPDEVICE lppd, BOOL bTransparent, DWORD FGColor,DWORD BGColor,
                     DWORD rop)
{
   FLAG fGray                                    ;
   short retval;
   LPASCIIBINPTRS tempptr;
   
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   if( (rop == SRCCOPY ) || (rop == NOTSRCCOPY ) )
   {
      fGray = PSSendColor(lppd,BGColor);       // Send gray -or- r g b
      (*tempptr->PSSendBoolean)(lppd,fGray);   // Send true -or- false
      (*tempptr->PSSendCRLF)(lppd);
      PSSendFragment(lppd,PSFRAG_begincopyimage);
   }else
   {
      PSSendFragment(lppd,PSFRAG_beginimage);
   }
   (*tempptr->PSSendCRLF)(lppd);
   
   retval = TokenNeedsProcset(lppd,BITBLT);
   if (RLEDecodeNeeded(lppd))
       TokenNeedsProcset(lppd, RLE_DECODE);
   
   fGray = PSSendColor(lppd,FGColor);       // Send gray -or- r g b
   (*tempptr->PSSendBoolean)(lppd,fGray);   // Send true -or- false
   (*tempptr->PSSendCRLF)(lppd);
   
   PSSendFragment(lppd,PSFRAG_bitmaskimage) ;
   //    Changed to PSSendCRLF
   //     01-Feb-1993  -by-    [olegs]
   //      .... and back again  26-Feb-1993  -by-  [olegs]
   (*tempptr->PSSendBitMapTerminator)(lppd);
   //   (*tempptr->PSSendCRLF)(lppd);
   
   return(retval)                                ;
}  // END TBitmapOperator


/***************************************************************************
*                               TBitmapData
*  Purpose:
*
*  Parameters:
*       LPPDEVICE   lppd --
*       LPBITMAP DevBitmap --
*       LPRECT      SrcRect --
*       SHORT       FirstSegScans --
*    
*  Returns: short
*
*  Note:
*       For Level 1 output we provide no compression, so we can
*       output our bitmap on line-by-line basis
*                                                                           
***************************************************************************/
short FAR PASCAL TBitmapData(LPPDEVICE lppd, LPBITMAP DevBitmap,
                             LPRECT SrcRect, SHORT FirstSegScans )
{
   short retval;
   BYTE  huge * lpBits;    // Pointer to row of bits in the source bitmap
   WORD  scans_this_seg;   // How many scan lines to output for this
                                 // particular segment before switching to another
   WORD  nCurrY;     // Current y-coordinate
   WORD  k;          // Line counter
   WORD  BMwidth;    // Bitmap width in bytes
   WORD  nBytes;     // Number of bytes to output on each line
   
   WORD  scans;      // How many scan lines to output
   
   WORD SrcX   = SrcRect->left                ;   // Src rect dimensions
   WORD SrcY   = SrcRect->top                 ;   //     "         "      "
   WORD SrcXE  = SrcRect->right  - SrcX  ;
   WORD SrcYE  = SrcRect->bottom - SrcY  ;
   BOOL bRLEncode = RLEDecodeNeeded(lppd);
   LPBYTE lpOutbuf = NULL;
   DWORD outBytes;
   LPASCIIBINPTRS tempptr;
   BOOL bAllocated = FALSE;
   
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   retval = TokenNeedsProcset(lppd,BITBLT);
   if (bRLEncode)
       TokenNeedsProcset(lppd, RLE_DECODE);
   
   BMwidth    = DevBitmap->bmWidthBytes ;    // Bytes per row in bitmap
   
   nBytes     = (SrcXE + 7 )>>3 ;
   scans      = SrcYE;               // Number of raster lines
   
   if(DevBitmap->bmSegmentIndex)   // If huge bitmap
   {
      scans_this_seg = DevBitmap->bmScanSegment -
                                    (SrcY % DevBitmap->bmScanSegment) ;
   }
   else
   {
      scans_this_seg = SrcYE ;
   }
   
   scans_this_seg = min( scans_this_seg, SrcYE );
   nCurrY = SrcY;    // Assign the current Y value
   
   if (bRLEncode)
   {
      lpOutbuf = (LPBYTE) GlobalAllocPtr(GDLLHND, 2 * nBytes + 2);
      bAllocated = TRUE;
      if (! lpOutbuf)
         return -1;
   }

   do
   {
      lpBits = (LPSTR)GetByteAddress(DevBitmap,SrcX,nCurrY);
      /* Loop for every scan on current segment and output that scan */
      for (k = 0; k < scans_this_seg; k++)
      {
         if (bRLEncode)
         {
            outBytes = RLEncode((BYTE huge*) lpBits, (long) nBytes, 
                                (BYTE huge*) lpOutbuf);
         }
         else
         {
            lpOutbuf = lpBits;
            outBytes = (DWORD) nBytes;
         }

         (*tempptr->PSSendBitMapDataLevel1)(lppd, lpOutbuf, outBytes);
         lpBits += BMwidth;
         nCurrY++ ;  // Bump current Y-coordinate
      } /* for */
   
      scans -= scans_this_seg;
      
      if(DevBitmap->bmSegmentIndex)   // If huge bitmap
      {
         /* Figure out the number of scans for the remaining segments */
         scans_this_seg = min(scans, DevBitmap->bmScanSegment);
      }
   } while( scans );
   
   (*tempptr->PSSendCRLF)(lppd);
   PSSendFragment(lppd,PSFRAG_endimage);
   (*tempptr->PSSendCRLF)(lppd);
   
   if (lpOutbuf && bAllocated)
      GlobalFreePtr(lpOutbuf);

   return(retval)                                ;
}  // END TBitmapData

//**********************************************************************
// Set of functions to deal with DIB output
//      send data in the following order:
//              Header
//              Operator
//              Data
//**********************************************************************

/***************************************************************************
*                               TDIBHeader
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       LPRECT    SrcRect --
*       LPRECT    DstRect --
*       short     BitsPerSample --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TDIBHeader(LPPDEVICE lppd, LPRECT SrcRect,LPRECT DstRect,
		    short BitsPerSample, BOOL bCMYK)
{
   FLAG      Polarity = TRUE                     ;
   int       byte_width                          ;
   int	     BppOutput				 ;
   
   int SrcX   = SrcRect->left                    ;       // Src rect dimensions
   int SrcY   = SrcRect->top                     ;       //     "         "      "
   int SrcXE  = SrcRect->right   - SrcX     ;       //     "         "      "
   int SrcYE  = SrcRect->bottom  - SrcY     ;       //     "         "      "
   
   int DestX  = DstRect->left                    ;       // Dest rect dimensions
   int DestY  = DstRect->top                     ;       //     "         "      "
   int DestXE = DstRect->right   - DestX    ;       //     "         "      "
   int DestYE = DstRect->bottom  - DestY    ;       //     "         "      "
   short retval;
   LPASCIIBINPTRS tempptr;
   
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   retval = TokenNeedsProcset(lppd,DIB);
   if (RLEDecodeNeeded(lppd))
       TokenNeedsProcset(lppd, RLE_DECODE);
   
   // If the user has selected no color and a 24 bit DIB is being
   // printed then the 24 bit DIB is converted to an 8 bit DIB.
   
   if((lppd->lpPSExtDevmode->dm.dm.dmColor != DMCOLOR_COLOR ) &&
      ((BitsPerSample == 16) || (BitsPerSample == 24) || (BitsPerSample == 32)))
   {
      BitsPerSample = 8;
   }
   
   BppOutput = BitsPerSample;

   if ((BitsPerSample == 24) || (BitsPerSample==16) || (BitsPerSample==32))
   {
   	byte_width = 3 * SrcXE;
   	BppOutput = 24;
   }
   else
   {
      byte_width = (SrcXE  +(8/BitsPerSample)-1) / (8/BitsPerSample);
   }
   
   (*tempptr->PSSendShort)(lppd,SrcXE);       // Src width in pixels
   (*tempptr->PSSendShort)(lppd,SrcYE);       // Src height in scanlines
   (*tempptr->PSSendShort)(lppd,BppOutput);   // Bits per sample - 4,8,24
   (*tempptr->PSSendShort)(lppd,byte_width);  // Src bytes per scanline
   (*tempptr->PSSendShort)(lppd,DestXE);      // Dest width
   (*tempptr->PSSendShort)(lppd,-DestYE);     // Dest height
   (*tempptr->PSSendShort)(lppd,DestX);       // Dest origin - x (left  )
   (*tempptr->PSSendShort)(lppd,DestY+DestYE);  // Dest origin - y (bottom)
   (*tempptr->PSSendBoolean)(lppd,FALSE);     // Smoothflag
   (*tempptr->PSSendBoolean)(lppd,Polarity);  // Polarity
   (*tempptr->PSSendBitMapType)(lppd,PPSLEVEL1);// Data type
   (*tempptr->PSSendCRLF)(lppd);
   PSSendFragment(lppd,PSFRAG_beginimage);
   (*tempptr->PSSendCRLF)(lppd);
   
   return(retval)                                ;
}  // END TDIBHeader


/***************************************************************************
*                               TDIBOperator
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       short     BitsPerSample --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TDIBOperator(LPPDEVICE lppd, short BitsPerSample)
{
   short retval;
   LPASCIIBINPTRS tempptr;
   
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   retval = TokenNeedsProcset(lppd,DIB);
   if (RLEDecodeNeeded(lppd))
       TokenNeedsProcset(lppd, RLE_DECODE);
   
   switch(BitsPerSample)
   {
      case 1:
      case 16:
      case 24:
      case 32:
        PSSendFragment(lppd,PSFRAG_doNimage);
        break                                   ;
      
      case 4:
      case 8:
        PSSendFragment(lppd,PSFRAG_doclutimage);
        break                   ;
   }

   //    Changed to PSSendCRLF
   //     01-Feb-1993  -by-    [olegs]
   //        ... and back again   26-Feb-1993  -by-  [olegs]
   (*tempptr->PSSendBitMapTerminator)(lppd);
   //   (*tempptr->PSSendCRLF)(lppd);
   
   return(retval)                                ;
}  // END TDIBOperator



/***************************************************************************
*                               TDIBDataBits
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       LPRECT    SrcRect --
*       LPSTR     lpDataBits --
*       LPBITMAPINFO lpBitmapInfo --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TDIBDataBits(LPPDEVICE lppd, LPRECT SrcRect,LPSTR lpDataBits,
                              LPBITMAPINFO lpBitmapInfo)
{
    DWORD      ScanWidth                          ;
    HANDLE     h  = 0                             ;
    BYTE huge  *lpLineStart  ; // Start of the DIB line
    BYTE huge  *lpBits       ; // Working pointer in DIB
    BYTE huge  *lpBitBuf     ; // Pointer to allocated buffer
    BYTE huge  *lpBuf        ; // Working pointer in buffer
    BYTE       Red,Green,Blue                     ;
    BYTE       Black = 0;
    BYTE       bRet;
    WORD       i,k,BytesPerPixel, wTemp, RealBytesPerPixel   ;
    DWORD     nBytes;    // Number of bytes to output on each line
    WORD      SrcX     = SrcRect->left            ;
    WORD      SrcY     = SrcRect->top             ;
    WORD      SrcXE    = SrcRect->right   - SrcX  ;
    WORD      SrcYE    = SrcRect->bottom  - SrcY  ;
    DWORD     ICMInputScanWidth;
    DWORD     ICMPixelFormatIn,ICMPixelFormatOut;
    WORD      PixelFormat = 0;
    WORD      BitCount  = lpBitmapInfo->bmiHeader.biBitCount;
    DWORD     Height    = (DWORD)lpBitmapInfo->bmiHeader.biHeight;
    DWORD     Width     = (DWORD)lpBitmapInfo->bmiHeader.biWidth;
    LPICMINFO  lpICMI;
    WORD huge   *lpBits16;     // Working pointer in DIB bits
    BOOL      bAllocated = FALSE;
    short retval;
    LPASCIIBINPTRS tempptr;
    BOOL bRLEncode = RLEDecodeNeeded(lppd);
    LPBYTE lpOutbuf = NULL;
    BYTE        Cyan,Magenta,Yellow;
    DWORD outBytes;
    
    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    
    retval = TokenNeedsProcset(lppd,DIB);
    if (bRLEncode)
        TokenNeedsProcset(lppd, RLE_DECODE);

   
    // ScanWidth is the width of one scan line. DIB scanlines are
    // multiples of DWORDs.
    //
    // 1.  Width[pixels] * BitCount[bits/pixel]       => Total number of bits in image line
    // 2.  Width * BitCount + 31[bits]                => Round up to nearest DWORD boundary
    // 3. (Width * BitCount + 31)/32[bits/DWORD]      => Total number of DWORDS
    // 4.((Width * BitCount + 31)/32) * 4[byts/DWORD] => Total number of bytes in a line
    
    ScanWidth = ((Width*BitCount + 31)/32) * 4    ;
    
    if((ScanWidth==0) || (lpDataBits==NULL))
    {
        return(RC_fail);
    }
    
    lpLineStart = (BYTE huge *) lpDataBits ;
    lpLineStart = lpLineStart + ScanWidth*SrcY;// Move to proper raster[in bytes]
    
    if((BitCount==1) || (BitCount==4) || (BitCount==8))
    {
        lpLineStart = lpLineStart +
            SrcX/(8/BitCount) ; // Move to proper pixel
   
        nBytes   = (SrcXE + (8/BitCount) - 1)/(8/BitCount) ;
        
        if (bRLEncode)
        {
            lpOutbuf = (LPBYTE) GlobalAllocPtr(GDLLHND, 2 * nBytes + 2);
            bAllocated = TRUE;
            if (! lpOutbuf)
                return -1;
        }

        for (i = 0; i < SrcYE; i++)        // for all raster lines
        {
            if (bRLEncode)
            {
                outBytes = RLEncode((BYTE huge*) lpLineStart, (long) nBytes, 
                                    (BYTE huge*) lpOutbuf);
            }
            else 
            {
                outBytes = nBytes;
                lpOutbuf = lpLineStart;
            }
            (*tempptr->PSSendBitMapDataLevel1)(lppd,lpOutbuf,outBytes);
            lpLineStart += ScanWidth           ;       //   Advance to next line
        }
    }
    // Here we handle 16, 24 and 32 bits per pixel
    else 
    {
        if( lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM )
        {
            lpICMI = (LPICMINFO) GlobalLock( (HANDLE) lppd->graphics.hCMTransform);
        }
        if (BitCount == 16)
        {
      	    if (lpBitmapInfo->bmiHeader.biCompression == BI_BITFIELDS)
         	 {
	             if(((BITMAPV4HEADER FAR *)lpBitmapInfo)->bV4GreenMask == 0x7E0)
         	        PixelFormat = 1;
      	    }
         	 if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR )
         	 {
	               BytesPerPixel	 = 4;
                  RealBytesPerPixel = 3;
      	         ICMPixelFormatIn  = CMS_XRGBQUADS;
	               ICMPixelFormatOut = CMS_QUADS;
           	      ICMInputScanWidth = ((Width * BytesPerPixel + 3)/4) * 4;
         	 }
         	 else
         	 {
      	       RealBytesPerPixel = 1;
                BytesPerPixel = 1;
         	 }
      	 
         	 lpBitBuf = (BYTE huge *)MGAllocLock(lppd, (LPHANDLE) &h,
	   	           (DWORD)(BytesPerPixel*(DWORD)SrcXE*(DWORD)SrcYE),
         		     GHND,TRUE);
             if (!lpBitBuf)
                return -1;
             
         	 lpLineStart = lpLineStart + 2*SrcX; // Move to proper pixel - 2 bytes per pixel

         	 lpBuf	= lpBitBuf;		     // Point to start of buffer

         	 for (i = 0; i < SrcYE; i++)
      	    {
   	          lpBits16 = (WORD huge *)lpLineStart; // Point to first pixel
         	    for (k = 0; k < SrcXE; k++)      // for all pixels in line
         	    {				     //   at 2 bytes per pixel
	                wTemp   = *lpBits16++;
      	          if (!PixelFormat)
   	             {
               		  Blue	  = (BYTE)(wTemp << 3) & 0xF8	;
               		  Green    = (BYTE)(wTemp >> 2) & 0xF8	;
               		  Red 	  = (BYTE)(wTemp >> 7) & 0xF8	;
      	          }
	                else
         	       {
               		  Blue	  = (BYTE)(wTemp << 3) & 0xF8	;
               		  Green    = (BYTE)(wTemp >> 3) & 0xFC	;
               		  Red 	  = (BYTE)(wTemp >> 8) & 0xF8	;
      	          }
         	       if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR )
	                {
                       if (!(lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM ))
                       {
                   		  *lpBuf++ = Red			  ;
                  		  *lpBuf++ = Green		  ;
               	   	  *lpBuf++ = Blue			  ;
                       }
                       else
                       {
                   		  *lpBuf++ = Blue			  ;
                  		  *lpBuf++ = Green		  ;
                  		  *lpBuf++ = Red			  ;
                          *lpBuf++ = 0            ;
                       }
         	       }else
	                {
               		  *lpBuf++ = INTENSITY(Red,Green,Blue); // Convert color to grayscale
      	          }
	             }
         	    lpLineStart += ScanWidth;
	          }
         	 lpBuf = lpBitBuf;
        }
        else if (BitCount == 24)
        {
           if(lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR)
           {
      	      BytesPerPixel	 = 4;
               RealBytesPerPixel = 3;
	            ICMPixelFormatOut = CMS_QUADS;
	            ICMInputScanWidth = ((Width * 3 + 3)/4) * 4;
      	      ICMPixelFormatIn = CMS_RGBTRIPLETS;
           }
           else
           {
               RealBytesPerPixel = 1;
               BytesPerPixel = 1                        ;
           }
        
      	  lpBitBuf = (BYTE huge *)MGAllocLock(lppd, (LPHANDLE) &h,
		           (DWORD)(BytesPerPixel*(DWORD)SrcXE*(DWORD)SrcYE),
      		     GHND,TRUE);
      	  if (!lpBitBuf)
	           return -1;

           lpLineStart = lpLineStart + 3*SrcX;// Move to proper pixel - 3 bytes per pixel
       	  lpBuf	= lpBitBuf;		     // Point to start of buffer
         
           for (i = 0; i < SrcYE; i++)
           {
               lpBits = lpLineStart         ;   /* Point to first pixel in line */
               for (k = 0; k < SrcXE; k++)      /* for all pixels in line */
               {                                /* at 3 bytes per pixel */
                   Blue     = *lpBits++               ;
                   Green    = *lpBits++               ;
                   Red      = *lpBits++               ;
                
                   if(lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR)
                   { 
                          if(!(lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM ))
               		  {
                          *lpBuf++ = Red                          ;
                          *lpBuf++ = Green                        ;
                          *lpBuf++ = Blue                         ;
                       }
                   } 
                   else
                   {
                       *lpBuf++ = INTENSITY(Red,Green,Blue) ;// Convert color to grayscale
                   }
                }
            	 lpLineStart += ScanWidth;
           }
           lpBuf = lpDataBits;
        }
        else if (BitCount == 32)
        {
      	  if (lpBitmapInfo->bmiHeader.biCompression == BI_BITFIELDS)
        	  {
	            if(((BITMAPV4HEADER FAR *)lpBitmapInfo)->bV4BlueMask != 0xFF)
      	         PixelFormat = 1;
      	  }
      	  if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR )
      	  {
	           ICMPixelFormatIn = CMS_XRGBQUADS;
              RealBytesPerPixel = 3;
              BytesPerPixel = 4;
     	        ICMPixelFormatOut = CMS_QUADS;
     	        ICMInputScanWidth = Width * 4;
       	     if ((lpBitmapInfo->bmiHeader.biSize > sizeof(BITMAPINFOHEADER))
		            && (((BITMAPV4HEADER FAR *)lpBitmapInfo)->bV4CSType
      		 	   == LCS_DEVICE_CMYK))
	           {
	              ICMPixelFormatIn = CMS_QUADS;
      	     } 
      	  }
      	  else
      	  {
              RealBytesPerPixel = 1;
	           BytesPerPixel = 1;
      	  }

           // Allocate size required in the worst casse which is 4 bytes/pixel
      	  lpBitBuf = (BYTE huge *)MGAllocLock(lppd, (LPHANDLE) &h,
		           (DWORD)(4*(DWORD)SrcXE*(DWORD)SrcYE),
      		     GHND,TRUE);
           if (!lpBitBuf)
              return -1;
             
           lpLineStart = lpLineStart + 4*SrcX; // Move to proper pixel - 4 bytes per pixel

      	  lpBuf	= lpBitBuf;		     // Point to start of buffer

      	  for (i = 0; i < SrcYE; i++)
      	  {    
	             lpBits = lpLineStart;	     // Point to first pixel
         	    for (k = 0; k < SrcXE; k++)      // for all pixels in line
         	    {				     //   at 2 bytes per pixel
	                if (!PixelFormat)
      	          {
               		  Blue	 = *lpBits++	;
      		           Green   = *lpBits++	;
      		           Red	    = *lpBits++	;
               		  Black   = *lpBits++	;
         	       }
	                else
      	          {
               		  Red	    = *lpBits++	;
      		           Green   = *lpBits++	;
      		           Blue	 = *lpBits++	;
               		  Black   = *lpBits++	;
         	       }

	                if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR )
         	       {    
                              if(!(lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM))
         		        {
                          if (ICMPixelFormatIn == CMS_QUADS)
                          {
                             // Convert CMYK into RGB components - see RedBook p.307
                             Red   = 255 - min(255, (Blue + Black));
                             Green = 255 - min(255, (Green + Black));
                             Blue  = 255 - min(255, (Red + Black));
                          }
                          // Got rgb/bgrquads. Send in RGB color space. 
                          // The PixelFormat check above takes care of RGB
                          // and BGR quad inputs.
        		              *lpBuf++ = Red;
                  		  *lpBuf++ = Green;
		                    *lpBuf++ = Blue;
            		     }
                       else
                       {
                          if (ICMPixelFormatIn == CMS_QUADS)
                          {
                              // ICM32.dll expects CMYK as KYMC
                              *lpBuf++ = Black;  // Black
                              *lpBuf++ = Red;    // Yellow
                              *lpBuf++ = Green;  // Magenta
                              *lpBuf++ = Blue;   // Cyan
                          }
                          else
                          {
                              // We send XRGBQUADS to ICM32.dll
                              *lpBuf++ = Blue;
                              *lpBuf++ = Green;
                              *lpBuf++ = Red;
                              *lpBuf++ = Black;
                          }
                       }
                   }
      	          else
	                {
      		           if (ICMPixelFormatIn == CMS_QUADS)
            		     {
		                     // Convert CMYK into RGB components - see RedBook p.307
                           Red   = 255 - min(255, (Blue + Black));
                           Green = 255 - min(255, (Green + Black));
                           Blue  = 255 - min(255, (Red + Black));
      	   	        }
      		           *lpBuf++ = INTENSITY(Red,Green,Blue); // Convert color to grayscale
	                }
      	       }
	             lpLineStart += ScanWidth;
      	  }
      	  lpBuf = lpBitBuf;
        }
    
        // EVERYTHING IS SETUP - NOW OUTPUT THE STUFF
        if(lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR )
        {
          if( lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM )
          {
	           bRet = ICMTranslateRGBs(lpICMI->hICMT,
		             (LPVOID)lpBuf, ICMPixelFormatIn,
      	   	    (DWORD)SrcXE, (DWORD)SrcYE,
		  		       (DWORD)ICMInputScanWidth,
      		       (LPVOID)lpBitBuf,
   		  		    ICMPixelFormatOut,
	   	          CMS_FORWARD );
             // Convert from CMYK to RGB. Slow code, but Level 2 does it similarly
             // and we'll fix it post RTM.
             lpBuf = lpBitBuf;		// Point to start of buffer
	          lpBits = lpBitBuf;		 // Point to start of buffer
             for (i = 0; i < SrcYE; i++)
       	    {
                  for (k = 0; k < SrcXE; k++)	// for all pixels in line
	               {				//   at 4 bytes per pixel
                       Black   = *lpBits++;
                       Yellow  = *lpBits++;
            		     Magenta = *lpBits++;
                 		  Cyan	  = *lpBits++;
                       Red   = 255 - min(255, Cyan+Black);
                       Green = 255 - min(255, Magenta+Black);
                       Blue  = 255 - min(255, Yellow+Black);
               		  *lpBuf++ = Red;
            	   	  *lpBuf++ = Green;
            		     *lpBuf++ = Blue;
         	       }
             }
          }
        }

        if (bRLEncode)
        {
            nBytes = (DWORD)((DWORD)RealBytesPerPixel*(DWORD)SrcXE);
            lpOutbuf = (LPBYTE)GlobalAllocPtr(GDLLHND, 2*nBytes + 2L);
            if (!lpOutbuf)
                goto EndDIBDataBits;
            bAllocated = TRUE;

            lpBuf = lpBitBuf;

            // For 16 & 32 bpp we always use the new buffer. For 24 bpp,
            // we use the new buffer if it is a monochrome device. So recompute
            // ScanWidth based on the way we are filling this buffer.
            // Note that we should use SrcXE instead of Width here.
            if ((BitCount == 16) || (BitCount == 32) ||
                ((BitCount == 24) && (lppd->lpPSExtDevmode->dm.dm.dmColor != DMCOLOR_COLOR)))
                ScanWidth = RealBytesPerPixel*SrcXE;  // we output RGB or Intensity

            // Encode and output line at a time.
            for (k=0; k<SrcYE; k++)
            {
                outBytes = RLEncode((BYTE huge*) lpBuf, (long)nBytes,
                                    (BYTE huge*) lpOutbuf);
                (*tempptr->PSSendBitMapDataLevel1)(lppd, lpOutbuf, outBytes);
                lpBuf += ScanWidth;
            }
        }
        else
        {
            nBytes = (DWORD)((DWORD)RealBytesPerPixel*(DWORD)SrcXE*(DWORD)SrcYE);
            (*tempptr->PSSendBitMapDataLevel1)(lppd,lpBitBuf, nBytes);
        }
        
      
        if( lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM )
        {
      	 GlobalUnlock( (HANDLE) lppd->graphics.hCMTransform);
        }
    }

    PSSendFragment(lppd,PSFRAG_endimage);
    (*tempptr->PSSendCRLF)(lppd);

EndDIBDataBits:
    if (h)
       MGUnlockFree(lppd, h, TRUE)		 ;
    if (lpOutbuf && bAllocated)
    {
        GlobalFreePtr(lpOutbuf);
    }
    return(retval)                                ;
    
}  // END TDIBDataBits

#endif
// End of ADOBEPS42

//**************************************************************************
//      Functions to send gray scale table and RGB table for 
//              DIB and Bitmap index translation
//      
//**************************************************************************
/***************************************************************************
*                               TColorTable
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       LPDWORD   ColorTable --
*       WORD      TableLen --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TColorTable(LPPDEVICE lppd, LPDWORD ColorTable,WORD TableLen)
{
   WORD i                                        ;
   short retval;
   LPASCIIBINPTRS tempptr;
   
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   retval = TokenNeedsProcset(lppd,DIB);
   
   PSSendFragment(lppd,PSFRAG_leftcaret);       // Enclose hex data with ">"
   (*tempptr->PSSendCRLF)(lppd);
   for (i = 0; i < TableLen; i++)
   {
      PSSendHexColor(lppd,ColorTable[i]);
      if((i & 0x7)==0x7)
      {
         (*tempptr->PSSendCRLF)(lppd);       // 8 values per row
      }
   }
   PSSendFragment(lppd,PSFRAG_rightcaret);       // Enclose hex data with ">"
   (*tempptr->PSSendCRLF)(lppd);       // End of line
   return(retval)                                ;

}  // END TColorTable


/***************************************************************************
*                               TGrayTable
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       LPBYTE    GrayTable --
*       WORD      TableLen --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TGrayTable(LPPDEVICE lppd, LPBYTE GrayTable,WORD TableLen)
{
   WORD i                                        ;
   short retval;
   LPASCIIBINPTRS tempptr;
   
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   retval = TokenNeedsProcset(lppd,DIB);
   
   PSSendFragment(lppd,PSFRAG_leftcaret);       // Enclose hex data with ">"
   (*tempptr->PSSendCRLF)(lppd);
   for (i = 0; i < TableLen; i++)
   {
      PSSendHexByte(lppd,GrayTable[i]);
      if((i & 0xF)==0xF)
      {
         (*tempptr->PSSendCRLF)(lppd);       // 16 values per row
      }
   }
   PSSendFragment(lppd,PSFRAG_rightcaret);       // Enclose hex data with ">"
   (*tempptr->PSSendCRLF)(lppd);       // End of line
   return(retval)                                ;

}  // END TGrayTable



/******************************************************************************
*                                TClipRect
*  Purpose:
*       This routine loads a rectangular clipping path into the printer.
*       It is also responsible for saving the current clipping path so that
*       when the next ClipEnd token is processed, the clipping path can be
*       restored.
*
*       By definition of this token, TClipRect .. TClipEnd sequences may not
*       nest.  This routine makes no attempt to check for nesting.  However,
*       because nesting isn't allowed, it is correct to check the requested
*       cliprect against the full imageable area, rather than against
*       lppd->lpGSStack->lpgGState->cliprect[].
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice pointer
*       LPRECT    lpRect - ptr to structure describing the clipping path
*
*  Returns: short
*       TRUE if no error, else FALSE.
*
******************************************************************************/
short FAR PASCAL TClipRect(LPPDEVICE lppd, LPRECT lpRect,
                           LPRECT lpRealRect, int Escapement)
{
   RECT rectMax;       // Maximum imageable area for this job
   LPRECT lpRectMax = (LPRECT) &rectMax;
   RECT rectInt;       // lpRect intersected with rectMax
   LPRECT lpRectInt = (LPRECT) &rectInt;
   
   short v1,v2,v3,v4;
   short NewX[4];
   short NewY[4];
   short tx, ty;
   BOOL  bClip = TRUE;
   int   i;

   // Determine the extent of the GDI coordinate system
   if (lppd->lpPSExtDevmode->dm.marginState == TRUE) //Full page is imageable.
   {
      SetRect(lpRectMax, 0, 0, lppd->ptPaperDim.x,
              lppd->ptPaperDim.y) ;
   }
   else
   {
      // drvState.imageRect is expressed with an origin at the top-left
      // corner of the paper.  Use OffsetRect to convert it so the origin
      // is at the top-left corner of the imageable area.
      // so left == top == 0.
      rectMax = lppd->imageRect ;
      OffsetRect(lpRectMax, -(lppd->imageRect.left), 
                       -(lppd->imageRect.top )   );
   }

   // Intersect desired clipping rect with imageable area (which is
   // the current clip rect).
   IntersectRect(lpRectInt, lpRect, lpRectMax);

   // Calculate real text rect
   if (lpRealRect)
   {
       tx = min(lpRealRect->left, lpRealRect->right);
       ty = min(lpRealRect->top, lpRealRect->bottom);
       NewX[0] = lpRealRect->right;
       NewX[1] = lpRealRect->right;
       NewX[2] = lpRealRect->left;
       NewX[3] = lpRealRect->left;
       NewY[0] = lpRealRect->bottom;
       NewY[1] = lpRealRect->top;
       NewY[2] = lpRealRect->top;
       NewY[3] = lpRealRect->bottom;
       if (Escapement)
       {
           short  tempX, tempY;

           for (i = 0; i < 4; i++)
           {
               NewX[i] -= tx;
               NewY[i] -= ty;
               tempX = RSin(NewY[i], Escapement) + RCos(NewX[i], Escapement);
               tempY = RCos(NewY[i], Escapement) - RSin(NewX[i], Escapement);
               NewX[i] = tempX + tx;
               NewY[i] = tempY + ty;
           }
       }
       bClip = FALSE;
       v1 = min(lpRectInt->left, lpRectInt->right);
       v2 = min(lpRectInt->top , lpRectInt->bottom);
       v3 = max(lpRectInt->left, lpRectInt->right);
       v4 = max(lpRectInt->top , lpRectInt->bottom);
       for (i = 0; i < 4; i++)
       {
           if ((NewX[i] < v1) || (NewX[i] > v3) ||
               (NewY[i] < v2) || (NewY[i] > v4) )
           {
               bClip = TRUE;
               break;
           }
       }
   }

   // Now, if the intersection is the same as the imageable area (i.e.
   // the current clip rect), clipping would be a no-op and we can skip
   // it.  If they are different, we go ahead and clip.
   if ((lpRealRect && bClip) ||
       (!lpRealRect && !EqualRect(lpRectInt, lpRectMax)))
   {
      // L3_CLIP
      if (lppd->lpPSExtDevmode->dm2.useLanguageLevel >= 3)
      {
          PSSendFragment(lppd, PSFRAG_clipsave);
          lppd->graphics.bClipSave = TRUE;
      }
      else
      {
          PSSendGSave(lppd) ; //Save current graphics state.
      }
      // Changed lpRect to lpRectInt
      //  14-Mar-1993  -by-  [olegs]
      v1 = min(lpRectInt->left, lpRectInt->right);
      v2 = min(lpRectInt->top , lpRectInt->bottom);
      v3 = ABS(lpRectInt->right - lpRectInt->left);
      v4 = ABS(lpRectInt->bottom - lpRectInt->top);
      
      PSSendClipRect(lppd,v1,v2,v3,v4);
      return ( 1 );
   }
   else
      return( 0 );
   
}  // END TClipRect

/******************************************************************************
*                                TClipEnd
*  function:
*       This routine restores the clipping path to the state is was in prior
*       to executing the last ClipRect token. Actually the entire graphics
*       state is restored.
*
*       It may be that the corresponding TClipRect() token did nothing,
*       because the requested clip was as large as the then-current clipping
*       rectangle.  Because TClipRect() tokens are not allowed to nest,
*       this means that the then-current clipping rectangle was the full
*       imageable area of the page, and the flag fClipIsMax was TRUE.  
*       That is why we check fClipIsMax to see whether to skip the grestore.
*
*  Parameters: 
*       LPPDEVICE lppd --
*
*  Returns: short 
*       RC_ok if no error, else RC_fail.
*
******************************************************************************/
short FAR PASCAL TClipEnd(LPPDEVICE lppd)
{
   if (!lppd->lpGSStack->lpgGState->fClipIsMax) 
   {
      // L3_CLIP
      if (lppd->lpPSExtDevmode->dm2.useLanguageLevel >= 3)
      {
          PSSendFragment(lppd, PSFRAG_cliprestore);
          lppd->graphics.bClipSave = FALSE;
      }
      else
      {
          PSSendGRestore(lppd); //Restore the graphics state.
      }
   }
   
   return(RC_ok);

}  // END TClipEnd

/***************************************************************************
*                               TColorBG
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       DWORD     Color --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TColorBG(LPPDEVICE lppd, DWORD Color)
{
   lppd->graphics.dBGColor = Color              ;       // From ESCSetBackgroundColor
   return(RC_ok)                                 ;

}  // END TColorBG


/***************************************************************************
*                               TColorFG
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TColorFG(LPPDEVICE lppd)
{
   return(RC_ok);

}   // END TColorFG


/***************************************************************************
*                               TPolyMode
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       BYTE      PolyMode --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TPolyMode(LPPDEVICE lppd, BYTE PolyMode)
{
   lppd->graphics.bPolyMode = PolyMode          ;       // PM_POLYLINE,PM_BEZIER or
   return(RC_ok)                                ;       // PM_POLYLINESEGMENT

}  // END TPolyMode


/*************************************************************************
*                   TMSRectHack   (A.K.A MSRectHack)
*  Purpose:
*       Works around app dependency on the rect code of MS PS Driver v.3.3
*       
*  Parameters:
*       LPPDEVICE lppd       -- pdevice pointer
*       BOOL      fClip      -- TRUE if we should send lpRectClip
*       LPRECT    lpRectClip -- parameters for 'CB (clip box) operator
*       LPRECT    lpRect     -- parameters for 'B (Box path) operator
*       
*  Returns: short
*       TRUE if successful
*       
**************************************************************************/
short FAR PASCAL TMSRectHack(LPPDEVICE lppd, BOOL fClip, LPRECT lpRectClip,
                             LPRECT lpRect)
{
   LPASCIIBINPTRS tempptr;
   
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   (*tempptr->PSSendCRLF)(lppd)                                    ;
   
   if (fClip) 
   {
      // Send "dx dy x y CB"
      
      (*tempptr->PSSendShort)(lppd, ABS(lpRectClip->right - lpRectClip->left));
      (*tempptr->PSSendShort)(lppd, ABS(lpRectClip->bottom - lpRectClip->top));
      
      (*tempptr->PSSendShort)(lppd, min( lpRectClip->right, lpRectClip->left));
      
      (*tempptr->PSSendShort)(lppd, min( lpRectClip->bottom, lpRectClip->top));
      PSSendString(lppd, " CB ");
   }
   
   // Send "dx dy x y B"
   
   (*tempptr->PSSendShort)(lppd,ABS(lpRect->right - lpRect->left)) ;
   (*tempptr->PSSendShort)(lppd,ABS(lpRect->bottom - lpRect->top)) ;
   (*tempptr->PSSendShort)(lppd,min(lpRect->right, lpRect->left))  ;
   (*tempptr->PSSendShort)(lppd,min(lpRect->bottom, lpRect->top))  ;
   PSSendString(lppd, " B ")                                       ;
   (*tempptr->PSSendCRLF)(lppd)                                    ;
   
   return( TRUE );
} /* TMSRectHack */


/*************************************************************************
*                             TClipPath
*  Purpose:
*       
*  Parameters:
*       LPPDEVICE lppd -- pdevice pointer
*       WORD      action --
*       WORD      mode --
*       
*  Returns: none
*       
**************************************************************************/
void FAR PASCAL TClipPath(LPPDEVICE lppd, WORD action, WORD mode)
{
   LPASCIIBINPTRS tempptr;
   short sRC;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   //Since we don't know what procsets may be needed while we have a
   //clip region, download everything.
   
   sRC = TokenNeedsProcset(lppd, PASST);
   if (sRC == RC_ok) 
   {
      // Fix bug 216467.   SAVE_RESTORE   6/17/97   jjia
      // The current font is changed to Courier in the procset COMPAT.
      // We have to clear current font information saved in host GSTATE 
      // to force the driver to re-select font after passthrough.
      lppd->lpGSStack->lpgGState->currentFontData.FontName[0] = (char)0;
      // Force the driver to re-send color after passthrough.
      lppd->lpGSStack->lpgGState->bColorSpaceChanged = TRUE;
   }

   switch(action)
   {
      case CP_RESTORE:
         // L3_CLIP
         if ((lppd->lpPSExtDevmode->dm2.useLanguageLevel == 3) &&
             (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS))
         {
             PSSendFragment(lppd, PSFRAG_cliprestore);
         }
         else
         {
             PSSendGRestore(lppd);
         }
         break;
      
      case CP_SAVE:
         // L3_CLIP
         if ((lppd->lpPSExtDevmode->dm2.useLanguageLevel == 3) &&
             (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS))
         {
             PSSendFragment(lppd, PSFRAG_clipsave);
         }
         else
         {
             PSSendGSave(lppd);
         }
         break;
      
      case CP_CLIP:
         if(mode)
         {
            PSSendFragment(lppd,PSFRAG_clip);
         }
         else
         {
            PSSendFragment(lppd,PSFRAG_eoclip);
         }
         PSSetNoCurrentPoint(lppd) ;
         break;
   }
}  // END TClipPath


/*************************************************************************
*                              SendMatrix
*  Purpose:
*       
*  Parameters:
*       LPPDEVICE lpDevice --
*       LPDWORD   lpMatrix --
*       
*  Returns: none
*       
**************************************************************************/
void FAR PASCAL SendMatrix(LPPDEVICE lpDevice, LPDWORD lpMatrix)
{
   int i;
   
   PSSendFragment(lpDevice, PSFRAG_leftbracket);
   for (i=0;i<9;++i)
   {
      if ((i % 3) != 2)  //Send all columns but the rightmost
      {
         (*((LPASCIIBINPTRS)(lpDevice->lpAsciiBinPtr))->PSSendFloat)(lpDevice, 
                                   (float)(lpMatrix[i]/65536.0));
      }
   }
   PSSendFragment(lpDevice, PSFRAG_rightbracket);

}  // END SendMatrix

/*************************************************************************
*                              TCTMTransform
*  Purpose:
*       
*  Parameters:
*       LPPDEVICE lpDevice --
*       LPDWORD   lpMatrix --
*       
*  Returns: none
*       
**************************************************************************/
void FAR PASCAL TCTMTransform(LPPDEVICE lpDevice, LPDWORD lpMatrix)
{
   LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lpDevice->lpAsciiBinPtr;
   
   SendMatrix(lpDevice, lpMatrix);
   PSSendFragment(lpDevice, PSFRAG_concat);
   (*tempptr->PSSendCRLF)(lpDevice);

}  // END TCTMTransform

/*************************************************************************
*                              TCTMSaveRestore
*  Purpose:
*       
*  Parameters:
*       LPPDEVICE lpDevice --
*       WORD      SaveOrRestore --
*       
*  Returns: none
*       
**************************************************************************/
void FAR PASCAL TCTMSaveRestore(LPPDEVICE lpDevice, WORD SaveOrRestore)
{
   LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lpDevice->lpAsciiBinPtr;

   if (SaveOrRestore == CTMSAVE)
   {
#ifdef ADOBE_DRIVER
      PSSendFragment(lpDevice, PSFRAG_CTMsave);
#else
      PSSendFragment(lpDevice, PSFRAG_saveCTM);
#endif
		lpDevice->graphics.XformLevel++;
   }
   else if(lpDevice->graphics.XformLevel)
   {
#ifdef ADOBE_DRIVER
      PSSendFragment(lpDevice, PSFRAG_CTMrestore);
#else
      PSSendFragment(lpDevice, PSFRAG_restoreCTM);
#endif
		lpDevice->graphics.XformLevel--;
      // note we never return -1 on failure, just 0 !
   }

   (*tempptr->PSSendCRLF)(lpDevice);

}  // END TCTMSaveRestore

/*************************************************************************
*                              TClipBox
*  Purpose:
*       
*  Parameters:
*       LPPDEVICE lpDevice --
*       LPRECT    lpRect --
*       
*  Returns: none
*       
**************************************************************************/
void FAR PASCAL TClipBox(LPPDEVICE lpDevice, LPRECT lpRect)
{
   if (lpRect)
   {
      TClipRect(lpDevice, lpRect, NULL, 0);
   }
   else
   {
      TClipEnd(lpDevice);
   }
}  // END TClipBox

/*************************************************************************
*                              TSetScreenFrequency
*  Purpose:
*       
*  Parameters:
*       LPPDEVICE lppd --
*       short     ScreenFrequency --
*       
*  Returns: short
*       
**************************************************************************/
short FAR PASCAL TSetScreenFrequency(LPPDEVICE lppd,short ScreenFrequency)
{
   LPASCIIBINPTRS tempptr;
   
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   PSSendFragment(lppd, PSFRAG_beginsafe);       
   
   (*tempptr->PSSendShort)(lppd, ScreenFrequency);
   (*tempptr->PSSendCRLF)(lppd);
   
   PSSendFragment(lppd, PSFRAG_setscreenfrequency);
   (*tempptr->PSSendCRLF)(lppd);
   
   
   PSSendFragment(lppd, PSFRAG_endsafe);
   (*tempptr->PSSendCRLF)(lppd);
   
   return ScreenFrequency;

}  // END TSetScreenFrequency

/*************************************************************************
*                              TSetScreenAngle
*  Purpose:
*       
*  Parameters:
*       LPPDEVICE lppd --
*       short     ScreenAngle --
*       
*  Returns: short
*       
**************************************************************************/
short FAR PASCAL TSetScreenAngle(LPPDEVICE lppd,short ScreenAngle)
{
   LPASCIIBINPTRS tempptr;
   
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   
   PSSendFragment(lppd, PSFRAG_beginsafe);       
   
   (*tempptr->PSSendShort)(lppd, ScreenAngle);
   (*tempptr->PSSendCRLF)(lppd);
   
   PSSendFragment(lppd, PSFRAG_setscreenangle);
   (*tempptr->PSSendCRLF)(lppd);
   
   
   PSSendFragment(lppd, PSFRAG_endsafe);
   (*tempptr->PSSendCRLF)(lppd);
   
   return ScreenAngle;
   
}  // END TSetScreenAngle
