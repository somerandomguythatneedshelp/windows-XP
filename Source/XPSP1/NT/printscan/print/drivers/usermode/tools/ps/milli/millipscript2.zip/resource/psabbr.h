/*------------------------------------------------------------------------
 * Adobe(R) PostScript(R) Language Printer Driver for Microsoft Windows (TM)
 *
 * Passion procsets: Abbreviations, for utils0.ps
 * $Header:   L:/PVCS/PS40/PSCRIPT/RESOURCE/PSABBR.H_V   1.8   27 Mar 1995 11:23:50   olegsher  $
 *
 * Copyright (C) 1991 Adobe Systems Incorporated.  All rights reserved.
 *
 * PostScript is a trademark of Adobe Systems, Inc.
 *
 * ADOBE SYSTEMS CONFIDENTIAL
 * NOTICE:  All information contained herein or attendant hereto is, and
 * remains, the property of Adobe Systems, Inc.  Many of the intellectual
 * and technical concepts contained herein are proprietary to Adobe Systems,
 * Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
 * are protected as trade secrets.  Any dissemination of this information or
 * reproduction of this material are strictly forbidden unless prior written
 * permission is obtained from Adobe Systems, Inc.
 *
 *
 * (Change Log at bottom.)
 *
 * This file uses C pre-processor commands to condense PostScript operator
 * names in to shorter abbreviations, in order to reduce the size and 
 * transmission times of the prolog.
 *
 * The abbreviations are in the file utils.ps.  An abbreviation and its 
 * corresponding entry in this file look like:
 *  /x /exch load def             #define exch x
 *
 * This is only worth doing if: the operator is frequent, the abbreviation
 * is shorter than the full operator name.  There is no performance penalty
 * in using the abbreviation rather than the full name: a name lookup is
 * performed in either case, and if the name is bound to an operator object,
 * 'bind will still put the operator object into procedure bodies.
 *
 * Beware of exporting names bound to operator objects.  They can trigger
 * errors in prologs of EPS files, which refer to the name in a bound 
 * procedure body.  We leave these names bound to operator objects
 * only while the procset resource is being defined.  compat.ps, 
 * included at the end, contains code to redefine all names that are 
 * bound to operator objects to one-element procs instead.
 *
 *
 * USABLE ABBREVIATIONS
 * 
 * To be usable, the original name must be a C identifier, and the 
 * abbreviation must be a whole C token or token(s).  Some legal PostScript
 * language names cannot be used as abbreviations because they are partial
 * C tokens.
 *
 * Abbreviatable names:
 *
 *     any identifier of the form [A-Za-z_][A-Za-z_0-9]*
 *
 * Usable abbreviations:
 *
 *     any single letter                [a-zA-Z]
 *     any of the following:            & + - ~ ! ^ | , $ : ; @ . ? `
 *     any combination of the above
 *     "0x" followed by any of the above
 *
 * Illegal abbreviations:
 *
 *     The following may not occur within an abbreviation:
 *     \ / *  # ' " / % < > ( ) { } * = [ ]
 *     ??=, ??/, ??', ??(, ??), ??!, ??<, ??>, ??-
 *
 *     Also, the name '.' is sometimes misinterpreted by the QMS 
 *     PS-410.  Do not use it as an abbreviation.
 *
 *
 * WARNINGS
 *
 * In some C compilers, // signals a comment that extends to the end of the
 * line.  In the PostScript language, // marks an immediately evaluated
 * name.  So, you cannot use C compilers to pre-process a PostScript
 * language file which contains immediately evaluated name.
 *
 *-------------------------------------------------------------------------
 */

#ifndef PSABBR_H
#define PSABBR_H

/* 
 * Abbreviations for names in the prolog which are long and/or frequent
 * enough that an abbreviation would save over 50 bytes.  Also, 
 * abbreviations for all operators in the PSOP table in TRAN\PSWTRANS.H.
 *
 * BE SURE TO CHECK PSWTRANS.H IF MODIFYING THESE ABBREVIATIONS!
 */

/* Abbreviations for PostScript language operators.  
 *
 * If flag DO_PSABBR_H is defined, emit PostScript language code to 
 * define the abbreviations in the procset
 * In any case, define the abbreviation for the C preprocessor.
 */

/* First, define abbreviations for load and def so that remaining 
 * definitions may use them.
 */

#ifdef DO_PSABBR_H

/d   /def       load def
/,   /load      load d

#endif /* DO_PSABBR_H */

#define       def               d
#define       load              ,


#ifdef DO_PSABBR_H

/* Primary abbreviations: to reduce size of header. */

/~      /exch           load def
/?      /ifelse         load def
/!      /pop            load def
/`      /begin          load def
/^      /index          load def
/@      /dup            load def
/+      /translate      load def
/$      /roll           load def
/U      /userdict       load def
/M      /moveto         load def
/-      /rlineto        load def
/&      /currentdict    load def
/:      /gsave          load def
/;      /grestore       load def
/F      /false          load def
/T      /true           load def
/N      /newpath        load def
/E      /end            load def

/* Secondary abbreviations: to reduce size of script (from PSOP table) */

/Ac     /arc            load def
/An     /arcn           load def
/A      /ashow          load def
/D      /awidthshow     load def
/C      /closepath      load def
/V      /div            load def
/O      /eofill         load def
/L      /fill           load def
/I      /lineto         load def
/-C     /rcurveto       load def
/-M     /rmoveto        load def
/+S     /scale          load def
/Ji     /setfont        load def
/Lc     /setlinecap     load def
/Lj     /setlinejoin    load def
/Lw     /setlinewidth   load def
/S      /show           load def
/LH     /showpage       load def
/K      /stroke         load def
/W      /widthshow      load def
/R      /rotate         load def
/XS     /xshow          load def

#endif /* DO_PSABBR_H */

#define       exch              ~
#define       ifelse            ?
#define       pop               !
#define       begin             `
#define       index             ^
#define       dup               @
#define       translate         +
#define       roll              $
#define       userdict          U
#define       moveto            M
#define       rlineto           -
#define       currentdict       &
#define       gsave             :
#define       grestore          ;
#define       false             F
#define       true              T
#define       newpath           N
#define       end               E

#define       arc               Ac
#define       arcn              An
#define       ashow             A
#define       awidthshow        D
#define       closepath         C
#define       div               V
#define       eofill            O
#define       fill              L
#define       lineto            I
#define       rcurveto          -C
#define       rmoveto           -M
#define       scale             +S
#define       setfont           Ji
#define       setlinecap        Lc
#define       setlinejoin       Lj
#define       setlinewidth      Lw
#define       show              S
#define       showpage          LH
#define       stroke            K
#define       widthshow         W
#define       rotate            R  
#define       xshow             XS

/* Abbreviations for procset's internal names.
 *
 * Since these names are defined and referenced in the procset, we
 * only need to define the abbreviation for the preprocessor.  Both
 * the definition of the name, and subsequent references, will use
 * the abbreviation.
 */

#define       Adobe_Windows_Font aF
#define       setupimageproc    s
#define       lookupandstore    a
#define       DefIf_B           g
#define       DefIf_E           e
#define       ncolors           c

/*  Added abbreviations for Bitmaps support     */
#define       BMFill            BZ
#define       begincopyimage    Q
#define       beginimage        X
#define       bitmaskimage      Y
#define       endimage          Z


/* Cleanup: undefine PS_ABBR_H to make sure that the PostScript language
 * definitions appear only once in a single (expanded) file.
 */

#undef DO_PSABBR_H

#endif /* PSABBR_H */



/*-------------------------------------------------------------------------
 * Change History
 *
 * $Log:   L:/PVCS/PS40/PSCRIPT/RESOURCE/PSABBR.H_V  $
 *- |
 *- |   Rev 1.8   27 Mar 1995 11:23:50   olegsher
 *- |Merged with Microsoft codedrop 03/20/95.
 *- |
 *- |   Rev 1.5   11 Apr 1994 14:01:14   olegs
 *- |Added new abbreviation for rotate.
 *- |
 *- |   Rev 1.4   23 Mar 1994 16:26:10   olegs
 *- |
 *- |   Rev 1.0   28 Jul 1993 10:57:02   JKEEFE
 *- |Initial revision.
 *- |
 *- |   Rev 3.3   03 May 1993 15:38:26   JKEEFE
 *- |Changed showpage define from SP to LH.
 *- |
 *- |   Rev 3.2   16 Mar 1993 16:36:06   olegs
 *- |Replaced the #define BMFill B to BZ, because Microsoft uses B
 *- |in MSRectHack.
 *- |
 *- |   Rev 3.1   09 Mar 1993 11:26:36   olegs
 *- |Added abbreviations for BMFill, beginimage , begincopyimage, endimage.
 *- |
 *- |   Rev 3.0   05 Aug 1992 15:38:34   JKEEFE
 *- |Initial revision.
 *- |
 *- |   Rev 1.3   08 May 1992 10:38:34   RAP
 *- |Changed def of Adobe_Windows_Font to /aF
 *- |
 *- |   Rev 1.2   06 Apr 1992 23:31:22   jdlh
 *- |Added enough abbreviations to cover the PSOP table in pswtrans.h.
 *- |
 *- |   Rev 1.1   08 Nov 1991 12:31:50   jdlh
 *- |Changed abbreviation for def from '.' to 'D' to avoid QMS PS-410 bug.
 *- |Changed definition for userdict from 'D' to 'U'.
 *- |
 *- |   Rev 1.0   24 Oct 1991 23:24:04   jdlh
 *- |Initial revision.
 * 
 *-------------------------------------------------------------------------
 */
