/*
  support.h

Copyright (c) 1991 Adobe Systems Incorporated.
All rights reserved.

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript is a registered trademark of Adobe Systems Incorporated.
Display PostScript is a trademark of Adobe Systems Incorporated.

Original version: Craig Rublee
Edit History:
End Edit History.
Revision History
  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/SUPPORT.H_V  $
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:07:28   unknown
 *- |Initial revision.
 * Revision 1.1  91/11/13  11:19:59  rublee
 * Initial revision
 * 
End Revision History.
*/

#ifndef	SUPPORT_H
#define	SUPPORT_H

/* Dummy header file to make ps_manager happy */

#endif	/* SUPPORT_H */
