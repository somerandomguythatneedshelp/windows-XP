#ifndef _REALIZE_H
#define _REALIZE_H  1

/* GDI return values for RealizeBrush (for 4.0 drivers) */
#define BRUSH_SUCCESS          0x8000
#define BRUSH_SOLID_MONOCHROME 0x0002
#define BRUSH_SOLID_COLOR      0x0001

/* Used fro font scoring */
#define NAME_EXACT_MATCH    4
#define NAME_ALIAS_MATCH    2
#define NAME_NO_MATCH       1

#define CHARSET_EXACT_MATCH 16
#define PITCH_EXACT_MATCH    8
#define FAMILY_EXACT_MATCH   4
#define COURIER_MATCH        2
#define PREFCJKFNT_MATCH     5

#define FONTS_NONE          1
#define FONTS_PRESENT       0

#define GDLLHND             (GHND | GMEM_SHARE)

//Append Show-Order substring to MSTT31... base name.
#define APPEND_SHOW_ORDER_SUBSTRING(lpName, HighByte)  \
      while (*((LPSTR)lpName))  \
        ((LPSTR)lpName)++;       \
      wsprintf((LPSTR)lpName, "S%2.2X", (HighByte >> 8) & 0x00FF); 

//Remove Show-Order substring to MSTT31... base name.
#define REMOVE_SHOW_ORDER_SUBSTRING(lpName)\
      while (*((LPSTR)lpName)) \
        ((LPSTR)lpName)++;     \
      *((LPSTR)lpName - 3) = '\0' ;


/* NEAR functions - segment "_REALIZE" */
BOOL NEAR REALIZESEG PASCAL AliasFace(WORD, LPSTR);
WORD NEAR REALIZESEG PASCAL  ScoreFontNames(WORD, LPLOGFONT,
                                            LPTEXTMETRIC, LPSTR, LPSTR);
WORD NEAR REALIZESEG PASCAL  ScorePitchAndFamily(WORD, LPLOGFONT,
                                                 LPTEXTMETRIC, LPSTR, LPSTR);
WORD NEAR REALIZESEG PASCAL  ScoreItalicsAndBold(WORD, LPLOGFONT,
                                                 LPTEXTMETRIC, LPSTR, LPSTR);
BYTE NEAR REALIZESEG PASCAL ScoreFonts(LPPDEVICE, LPLOGFONT, LPLOGFONT, WORD,
                            LPBYTE, NEARPROC, BYTE, WORD, WORD);
BYTE NEAR REALIZESEG PASCAL QuickScoreFonts(LPPDEVICE, LPLOGFONT, LPLOGFONT, WORD,
                            LPBYTE, NEARPROC, BYTE, WORD, WORD);
WORD NEAR REALIZESEG PASCAL RealizeFont(LPPDEVICE,LPLOGFONT,LPPSFONTINFO,
                             LPTEXTXFORM);
WORD  NEAR REALIZESEG PASCAL TTRealizeFont(LPPDEVICE, LPLOGFONT, LPTEXTXFORM,
                                LPLOGFONT, LPPSFONTINFO, LPWORD, BOOL);
WORD  NEAR REALIZESEG PASCAL GetTTFontID(LPPDEVICE, LPSTR);
void   FAR            PASCAL GetSubstitute(HANDLE, LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode, LPSTR lpTTFont, LPSTR lpPSFont);
WORD   FAR            PASCAL RealizePen(LPPDEVICE,LPLOGPEN,LPPPEN);
WORD   FAR            PASCAL RealizeBrush(LPPDEVICE,LPLOGBRUSH,LPPBRUSH, LPPOINT);
void   FAR            PASCAL FreeTTFontTable(LPPDEVICE);


/* FAR functions */

BOOL FAR PASCAL IsRealTTFont(LPLOGFONT lplf);
PSERROR    FAR PASCAL   initRefEMfont(LPPDEVICE lppd, LPPSFONTINFO lpFontInfo) ;
LPBYTE   FAR PASCAL   ReallocBuffer(WORD   wSize, WORD    mode,
         LPWORD  lpRecordedSize, LPBYTE  FAR  *  lplpBuf ) ;
PSERROR    FAR PASCAL   initlpdWidths(LPPDEVICE lppd, LPPSFONTINFO lpFontInfo,
      LPBYTE  textstr, WORD  count) ;
PSERROR    FAR PASCAL   initrgwWidths(LPPDEVICE lppd, LPPSFONTINFO lpFontInfo,
      LPBYTE  textstr, WORD  count) ;
PSERROR    FAR PASCAL   initDeviceWidths(LPPDEVICE lppd, LPPSFONTINFO lpFontInfo,
      LPBYTE  textstr, WORD  count) ;
BOOL FAR PASCAL IsType42Able(LPPDEVICE lppd, LPPSFONTINFO lpFontInfo);

/* Exported FAR functions */
WORD _loadds FAR PASCAL RealizeObject(LP,short,LP,LP,LP);

#endif /* ifndef _REALIZE_H */
