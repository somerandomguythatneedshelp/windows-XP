/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: STRETCHB.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for  ...                  */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_DIBSEG)

short _loadds FAR PASCAL Output(LP,short,short,LPPOINT,LPPPEN,LPPBRUSH,
                                LPDRAWMODE,LPRECT);
int   FAR PASCAL RoundUp(float);
BOOL  FAR PASCAL ShapeSource(LPBITMAP,BYTE,LPINT,LPINT,LPINT,LPINT);


#define PATAND      0x00A000C9
#define NOTPATAND   0x000A0329
#define NOTPATOR    0x00AF0229
#define NOTSRCAND   0x00220326
#define NOP         0x00AA0029

/****************************************************************************
*                        IsThisRowBkgnd                                           
*                                                                                                        
*  function  : Determines whether the row of pixels is all Bkgnd           
*                                                                             
*  prototype : BOOL PASCAL IsThisRowBkgnd(lpBits,Width)                            
*                                                                                             
*  paremeters: LPBYTE lpBits -- Pointer to the first pixel                    
*              WORD   Width  -- Width of the bitmap in pixels                   
*                                                                                             
*  returns:    TRUE   If the row is all Bkgnd                                       
*              FALSE  If the row is not all Bkgnd                              
*****************************************************************************/
BOOL PASCAL IsThisRowBkgnd(LPBYTE lpBits,BYTE Background, WORD Width)
{
   BYTE __huge *hp;
   WORD  i;
   BOOL AllBkgnd = TRUE;

   (LPBYTE) hp = lpBits; 
   for (i = 0; i < Width; i++)
   {
      if (*hp++ != Background)
      {
         AllBkgnd = FALSE;
         break;
      }
   }
   return(AllBkgnd);
}

/***************************************************************************
*                        ShapeSource                                                
*                                                                                            
*  function  : Determine the dimensions of the minimum rectangle which just
*              contains the bitmap.                                                    
*                                                                                            
*  prototype : BOOL FAR PASCAL ShapeSource(lpdbm,Background,lpSrcX,lpSrcY, 
*              lpSrcXE,lpSrcYE)                                                        
*                                                                                            
*  paremeters: LPBITMAP lpdbm       -- Pointer to the bitmap structure  
*              BYTE        Background -- Value of the background byte    
*              LPINT       lpSrcX     -- Pointer to the bitmap x coordinate
*              LPINT       lpSrcY     -- Pointer to the bitmap y coordinate
*              LPINT       lpSrcXE    -- Pointer to the bitmap x extent       
*              LPINT       lpSrcYE    -- Pointer to the bitmap y extent       
*                                                                                            
*  returns:    TRUE   If a smaller rectangle was found                       
*              FALSE  If a smaller rectangle was not found                    
****************************************************************************/
BOOL FAR PASCAL ShapeSource(LPBITMAP lpdbm, BYTE Background, LPINT lpSrcX,
                            LPINT lpSrcY, LPINT lpSrcXE, LPINT lpSrcYE)
{
   BOOL bFlag ;      // Boolean to control loops
   BOOL AllBkgnd;
   WORD  x, y;
   WORD  TopLeftx,TopLefty;               /* define region we are reducing */
   WORD  LowerRightx,LowerRighty;         /* define region we are reducing */
   WORD  dx_bytes;
   WORD  width_bytes;
   BYTE __huge *lpBits;
   WORD x_partial_byte;         /* first x bit coordinate in final,
                                 * partial data byte.  If final byte is
                                 * full (if scan is byte-aligned), this
                                 * contains LowerRightx + 1.  */

   TopLeftx    = *lpSrcX;
   TopLefty    = *lpSrcY;
   LowerRightx = *lpSrcX + *lpSrcXE - 1;
   LowerRighty = *lpSrcY + *lpSrcYE - 1;

   width_bytes = lpdbm->bmWidthBytes;
   x_partial_byte = 8 * (LowerRightx>>3)  ;
   dx_bytes    = (x_partial_byte>>3) - (TopLeftx>>3);

   if( 0 == dx_bytes ) return (FALSE);

   dx_bytes = min(dx_bytes, width_bytes);

   AllBkgnd = TRUE; // Assume that the bitmap is all background
   // Scan bitmap from top to the bottom
   for (y = TopLefty; y <= LowerRighty; y++) // Note: we specify all rects
   {                                         //  _INCLUSIVE_
      lpBits   = GetByteAddress(lpdbm, TopLeftx, y );

      if( !IsThisRowBkgnd(lpBits,Background,dx_bytes) )
      {
         AllBkgnd = FALSE;
         TopLefty = y;   // update top boundary
         break;
      }
   }

   if (AllBkgnd)  //This is an empty bitmap
   {
      *lpSrcXE = 0;
      *lpSrcYE = 0;
      return(TRUE);
   }

   // Scan bitmap from the bottom up
   for (y = LowerRighty; y >= TopLefty; y--)
   {
      lpBits = GetByteAddress(lpdbm, TopLeftx, y);
      if (!IsThisRowBkgnd(lpBits,Background,dx_bytes) )
      {
          LowerRighty = y;
          break;
      }
   }
   // Now we have the bitmap clipped from top and bottom
   // It's about time to parse it from left to right
   bFlag = TRUE;
   for (x = TopLeftx; bFlag && (x < x_partial_byte) ; x = ( (x>>3) + 1 )*8 )
   {
      for( y = TopLefty; y <= LowerRighty; y++ )
      {
         lpBits = GetByteAddress(lpdbm, x, y);
         if( *lpBits != Background )
         {
            TopLeftx = x;
            bFlag    = FALSE;   // Force the exit from outer loop
            break;
         }
      }
   }

   bFlag   = TRUE;
   for (x = LowerRightx ;bFlag && ( x > TopLeftx ); x = ((x>>3) - 1)*8 + 7)
   {
      for( y = TopLefty; y <= LowerRighty; y++ )
      {
         lpBits = GetByteAddress(lpdbm, x, y);
         if (*lpBits != Background)
         {
            LowerRightx = x;
            bFlag = FALSE;  // Force the exit from outer loop
            break;
         }
      }
   }
   // If any dimensions have changed then pass the new rectangle
   // back to the caller.

   if ( (TopLeftx - *lpSrcX) <= 0x10 && (*lpSrcY == (int)TopLefty))
        return (FALSE);

   if( (*lpSrcX  != (int)TopLeftx) || (*lpSrcY  != (int)TopLefty)   ||
               (*lpSrcXE != (int) ( LowerRightx - TopLeftx + 1 ) )  ||
               (*lpSrcYE != (int) ( LowerRighty - TopLefty + 1 ) ) )
   {
         *lpSrcX  = (int) TopLeftx;
         *lpSrcY  = (int) TopLefty;
         *lpSrcXE = (int) (LowerRightx - TopLeftx + 1);
         *lpSrcYE = (int) (LowerRighty - TopLefty + 1);
         return(TRUE);
   }
   return(FALSE);
}

/***************************************************************************
*                        DestOutsideClip                                            
*  function:                                                                             
*       Determines whether the Destination rectangle lies completely        
*       inside the Clipping rectangle. If the Destination rectangle is        
*       a subset of the Clipping rectangle then the CClipRect token         
*       does not need to be emmitted.                                               
*  prototype:                                                                            
*       BOOL FAR PASCAL DestOutsideClip(LPRECT Dest,LPRECT Clip)          
*  paremeters:                                                                           
*       LPRECT Dest -- the destination rectangle                              
*       LPRECT Clip -- the clipping rectangle                                      
*  returns:                                                                                 
*       BOOL        -- TRUE   Dest is outside the Clip rect                  
*                   -- FALSE  Dest is a subset of Clip rect                  
****************************************************************************/

BOOL FAR PASCAL DestOutsideClip(LPRECT Dest,LPRECT Clip)
{

   RECT  LocalDest;  // Normalized rectangle

   if( Clip == (LPRECT) NULL )
   {
      return ( FALSE );
   }

   NormalizeRect( (LPRECT) &LocalDest, Dest );


   if( (LocalDest.left >= Clip->left) && (LocalDest.right  <= Clip->right) &&
       (LocalDest.top  >= Clip->top ) && (LocalDest.bottom <= Clip->bottom) )
   {
      return FALSE;       // Dest inside Clip
   }
   else
   {
      return TRUE;        // Dest outside Clip
   }
}


/****************************************************************************
 * SHORT FAR PASCAL DevStretchBlt()                                         *
 *                                                                          *
 * This routine handles the the GDI StretchBlt routine.                     *
 * It uses the PostScript "image" operator to stretch a bitmap.             *
 *                                                                          *
 *                                                                          *
 * May be called anytime between StartDoc and EndDoc.                       *
 * May be disabled.  May change state to ST_MARKED_PAGE.                    *
 *                                                                          *
 * in:                                                                      *
 *      lpdv    points to the device to receive output                      *
 *                                                                          *
 * restrictions:                                                            *
 *      bmBitsPer pixel must be 1.  (use DIBs to get more)                  *
 *                                                                          * 
 *      dwRop supported:                                                    *
 *              SRCCOPY         src              -> dst                     *
 *              NOTSRCCOPY      (NOT src)        -> dst                     *
 *              SRCPAINT        src OR dst       -> dst                     *
 *              MERGEPAINT      (NOT src) OR dst -> dst                     *
 *                                                                          *
 * returns   : sRC = +1 Success
 *                 =  0 Failure
 *                 = -1 GDI should simulate
 ****************************************************************************/
SHORT _loadds FAR PASCAL DevStretchBlt(LP lpDest,SHORT DestX,SHORT DestY,       
                                       SHORT DestXE,SHORT DestYE,
                                       LPBITMAP DevBitmap,SHORT SrcX,SHORT SrcY,
                                       SHORT SrcXE,SHORT SrcYE,DWORD rop,
                                       LPPBRUSH lpPBrush,LPDRAWMODE lpDrawMode,
                                       LPRECT lpClip)
{
   LPPDEVICE lppd     =(LPPDEVICE)lpDest;
   SHORT     sMagic   =*((LPSHORT)lpDest);
   SHORT     sRC      = 1;                               // Success

   // If the first word of the DESTINATION structure( lpDest) is a 0
   // then the destination is a rectangle in main memory. We do not
   // print to main memory.

   if(sMagic==0)
   {
      sRC = -1;        // If dest = memory then GDI will simulate
   }   
   // If the Bitmap is not NULL and DevBitmap->bmType = 0
   // then the source rectangle is in main memory. This is the only
   // case allowed.
   else if (( DevBitmap && DevBitmap->bmType) &&
            (lppd->job.bfInWriteSpool == FALSE))
   {
      sRC = -1;         // SRC is a device, we cant do it.
   }
   else if ((sMagic == LUCAS) &&
            (lppd->job.bfInWriteSpool == FALSE))
   {
      if (!fInDocLppd(lppd))
      {
         // It isn't between StartDoc and EndDoc.  Return an error.
         sRC = 0;            // Return failure
      }else if (fDisableGDILppd(lppd))
      {
         // It's OK to call us, but GDI is disabled, so this is a NOP.
         sRC = 1;            // Return success
      }else if (!fChangeStateLppdSt(lppd, ST_MARKED_PAGE))
      {  
         // For some reason, the state machine can't move to the 
         // proper state.  Return failure.
         sRC = 0;            // Return failure
      }else
      {
          /* OK!  We are free to image the bitmap now! */
          sRC = 1;   // Success
          if (lppd->GlobalBuffer.handleBitmapNow)
          {
              sRC = DoDevStretchBlt(lpDest, DestX, DestY, DestXE, DestYE,
                                    DevBitmap, SrcX, SrcY, SrcXE, SrcYE,
                                    rop, lpPBrush, lpDrawMode, lpClip);
          }else if (DevBitmap == NULL)
          {
              HandleBufferedBitmap(lpDest);
              sRC = DoDevStretchBlt(lpDest, DestX, DestY, DestXE, DestYE,
                                    DevBitmap, SrcX, SrcY, SrcXE, SrcYE,
                                    rop, lpPBrush, lpDrawMode, lpClip);
          }else
          {
              if ((DevBitmap->bmBitsPixel != 1)        ||
                  (DevBitmap->bmPlanes != 1)           ||
                  ((SHORT)DevBitmap->bmHeight < SrcYE) || 
                  ((SHORT)DevBitmap->bmWidth  < SrcXE) ||
                  (!BufferBitmap(lpDest, DestX, DestY, DestXE, DestYE,
                                    SrcX, SrcY, SrcXE, SrcYE,
                                    NULL, NULL, DevBitmap,
                                    rop, lpPBrush, lpDrawMode, lpClip)))
              {
                  sRC = 0;
              }  
          }
        
      } // end else
   } // end else if (sMagic == LUCAS)
   return (sRC);                // sRC = 1 Success
}                               //     = 0 Unrecoverable error
                                //     =-1 GDI will simulate



LPBITMAP NEAR PASCAL CreateAlignedBitmap(LPBITMAP DevBitmap, WORD wShift)
{
    LPBITMAP lpNewBitmap;
    DWORD    dwSize;
    BYTE     __huge   *lpSrc;
    BYTE     __huge   *lpDest;
    WORD     wTemp;
    WORD     i, j, Height, Width, WidthBytes;

    Height = (WORD) DevBitmap->bmHeight ;
    Width =  DevBitmap->bmWidth;
    WidthBytes =  ( (Width + 31) /32 ) * 4 ;

    dwSize = (DWORD)dsizeof(BITMAP) +
             ( (DWORD) WidthBytes * (DWORD) Height);
    lpNewBitmap = (LPBITMAP)GlobalAllocPtr(GDLLHND, dwSize);
    if (NULL == lpNewBitmap)
        return NULL;

//  Fill out the bitmap - make it BIG!!!.
    lpNewBitmap->bmType = 0;
    lpNewBitmap->bmWidth = Width;
    lpNewBitmap->bmHeight = Height;

    lpNewBitmap->bmWidthBytes = WidthBytes;
    lpNewBitmap->bmPlanes = 1;
    lpNewBitmap->bmBitsPixel = 1;
    (BYTE __huge *)lpNewBitmap->bmBits =
            (BYTE __huge *)lpNewBitmap + sizeof(BITMAP);
    lpNewBitmap->bmWidthPlanes = (DWORD)WidthBytes * (DWORD) Height;
    lpNewBitmap->bmlpPDevice = DevBitmap->bmlpPDevice;
    lpNewBitmap->bmSegmentIndex = lpNewBitmap->bmScanSegment = 0;

    // WidthBytes--;   // We need it to stop one byte short of the end.
	WidthBytes = DevBitmap->bmWidthBytes - 1;
	// Fix bug #150496. Use WdithBytes of the non-alighed bitmap
	// instead of the newly created alighed bitmap since we are
	// copying the contents of the non-aligned bitmap to the
	// aligned bitmap.

    for (i=0; i < Height; i++)
    {
        lpSrc = GetByteAddress(DevBitmap, 0, i);
        lpDest = GetByteAddress(lpNewBitmap, 0, i);

        for (j=0; j < WidthBytes ; j++)
        {
            wTemp = *lpSrc<<8 | *(lpSrc+1);
            wTemp <<= wShift;
            *lpDest = HIBYTE(wTemp);
            lpSrc++;
            lpDest++;
        }
        *lpDest = *lpSrc << wShift;
    }
    return lpNewBitmap;
}


/****************************************************************************
 * SHORT FAR PASCAL DoDevStretchBlt()
 *
 * This routine handles the the GDI StretchBlt routine.
 * It uses the PostScript "image" operator to stretch a bitmap.
 *
 * Only called when state is ST_MARKED_PAGE.
 *
 * This is also called by the bitmap buffering stuff.
 * See stretchd.c.
 *
 * in:
 *      lpdv    points to the device to receive output
 *
 * restrictions:
 *      bmBitsPer pixel must be 1.  (use DIBs to get more)
 *
 *      dwRop supported:
 *              SRCCOPY         src              -> dst
 *              NOTSRCCOPY      (NOT src)        -> dst
 *              SRCPAINT        src OR dst       -> dst
 *              MERGEPAINT      (NOT src) OR dst -> dst
 *
 * returns   : sRC = +1 Success
 *                 =  0 Failure
 *                 = -1 GDI should simulate
 ***************************************************************************/
SHORT FAR PASCAL DoDevStretchBlt(LP lpDest, SHORT DestX, SHORT DestY,
                                SHORT DestXE, SHORT DestYE, LPBITMAP DevBitmap,
                                SHORT SrcX, SHORT SrcY, SHORT SrcXE, SHORT SrcYE,
                                DWORD rop, LPPBRUSH lpPBrush,
                                LPDRAWMODE lpDrawMode, LPRECT lpClip)
{
    RECT      DstRect,SrcRect,BitRect,NewDest;
    DWORD     rgb;
    BOOL      NeedClipToken, bNewBitmap = FALSE;
    LPPDEVICE lppd     =(LPPDEVICE)lpDest;
    SHORT     sMagic   =*((LPSHORT)lpDest);
    SHORT     sRC      = 1;                               // Success
    SHORT     wSrcX, wSrcY, wSrcXE, wSrcYE;
    SHORT     wDestX, wDestY, wDestXE, wDestYE;
    BOOL      bTransparent = FALSE;

    if( SrcXE < 0 )
    {
        wSrcX = SrcX + SrcXE;
        wSrcXE = -SrcXE;
        wDestX = DestX + DestXE;
        wDestXE = -DestXE;
    }else
    {
        wSrcX = SrcX;
        wSrcXE = SrcXE;
        wDestX = DestX;
        wDestXE = DestXE;
    }
    if( SrcYE < 0 )
    {
        wSrcY = SrcY + SrcYE;
        wSrcYE = -SrcYE;
        wDestY = DestY + DestYE;
        wDestYE = -DestYE;
    }else
    {
        wSrcY = SrcY;
        wSrcYE = SrcYE;
        wDestY = DestY;
        wDestYE = DestYE;
    }


    // Construct a destination rect structure and intersect it
    // with the clip rect. If there is no common area the clipping
    // rectangle is empty and we are done.
    SetRect((LPRECT) &DstRect,wDestX,wDestY,wDestX+wDestXE,wDestY+wDestYE);
    NeedClipToken = DestOutsideClip((LPRECT) &DstRect,lpClip);
    // Filxed interesting ICM bug -
    //   ClipRect uses --gsave--, and if we first use CClipRect and then
    //   CICMColor, the colorspace defined will be valid within
    //   --gsave-- --grestore-- brackets.
    //   fixed  14-Jul-1995  -by-  [olegsher]
    if( ((WORD)lpDrawMode->ICMCXform != (WORD)lppd->graphics.hCMTransform ) ||
        (lpDrawMode->ICMCXform) ||
        (lppd->graphics.hCMTransform ) ||
        (lpDrawMode->ICMCXform == NULL) && (lppd->graphics.hDefCMTransform)
      )
    {
        // ALWAYS_ICM
        if ((lpDrawMode->ICMCXform == NULL) &&
            (lppd->graphics.hDefCMTransform))
        {
            if ((WORD)lppd->graphics.hDefCMTransform != (WORD)lppd->graphics.hCMTransform)
                CICMColor(lppd, lppd->graphics.hDefCMTransform);
        }
        else
        {
            CICMColor(lppd, lpDrawMode->ICMCXform );
        }
    }

    if (NeedClipToken)
    {
        CClipRect(lppd,lpClip, NULL, 0);
    }

    // Pscript handles very few rops. Here is a summary:
    // 1. Rops dealing with patterns: We do a PATCOPY for all of them.
    // 2. Rops dealing with the source (no patterns): 
    //    We handle SRCCOPY, NOTSRCCOPY, SRCAND, NOTSRCAND.
    //    For everything else, we do SRCAND.
    // 3. Rops dealing only with the destination: We fail these.
    // 4. BLACKNESS, WHITENESS: We handle these of course.
    
    switch(rop)               // SRC = memory or brush
    {
        // The cases that we can code directly
        
        case BLACKNESS:                      // Dest pixels = 0
            rgb = 0x00000000L;              // Set rgb color
            COpaqueBox(lppd,(LPRECT) &DstRect,rgb, 0); // Send OpaqueBox token
            //CBMOpaqueBox(lppd,(LPRECT) &DstRect,rgb); // Send OpaqueBox token
            break;
        
        case WHITENESS:                      // Dest pixels = 1
            rgb = 0x00FFFFFFL;              // Set rgb color
            COpaqueBox(lppd,(LPRECT) &DstRect,rgb, 0); // Send OpaqueBox token
            //CBMOpaqueBox(lppd,(LPRECT) &DstRect,rgb); // Send OpaqueBox token
            break;

        // Do PATCOPY for all these.
        case PATCOPY:           // P
        case PATINVERT:         // Pn
        case PATAND:            // DPa
        case NOTPATAND:         // DPna
        case PATOR:             // DPo
        case NOTPATOR:          // DPno
            // Draw a rect with a brush
            Output((LP)lppd, OS_RECTANGLE, 2, (LPPOINT)&DstRect,
                   (LPPPEN)NULL, lpPBrush, lpDrawMode, NULL);
            break;

        case NOP:
            break;         // Do nothing

        default:            // All other rops = SRCAND as long as we get a source.

            if( DevBitmap == NULL )
            {
                 // No source - fail this.
                 sRC = 0;
            }else if( (DevBitmap->bmBitsPixel != 1) ||
                       (DevBitmap->bmPlanes != 1)       )
            {
                 sRC = -1;  // Simulate in GDI !!!
            }
                
            if (sRC == 1)  // We can work on this bitmap
            {
                 if ((wSrcX % 8) != 0)
                 {
                 // Bitmap doesn't start on a byte boundary. Create
                 // an equivalent bitmap that starts on the nearest
                 // previous byte boundary.
                    DevBitmap = CreateAlignedBitmap(DevBitmap, wSrcX%8);
                    if (!DevBitmap)
                    {
                        sRC = 0;
                        break;
                    }
                    bNewBitmap = TRUE;
                    wSrcX = (wSrcX>>3) * 8;
                 }            

                 SetRect((LPRECT)&SrcRect, wSrcX, wSrcY,
                         wSrcX+wSrcXE, wSrcY+wSrcYE);
                 CopyRect((LPRECT)&BitRect, (LPRECT)&SrcRect);
                 CopyRect((LPRECT)&NewDest, (LPRECT)&DstRect);
                 
                 if ((rop == SRCCOPY) || (rop == NOTSRCCOPY) )
                 {
                     BOOL bOnesBackgr;
                     BOOL NewShape;

                     NewShape = FALSE ;
                     bOnesBackgr = TRUE;    // Assume All Ones bkgr

                     // Apply ShapeSource  to any bitmap
                     // Fixed  03-Mar-1993   -by-    [olegs]
                     // Try two times to find the minimized rect:
                     // First time look for "all-ones" background
                     // Second time - for "all-zeroes".

                     // L3_MASK
                     // For Level3 & Transparent, we can not do ShapeSource,
                     // because ShapeSource use fill to print back ground which
                     // will remove the real background.
                     if ((lpDrawMode->bkMode == TRANSPARENT) &&
                         ((lppd->lpPSExtDevmode->dm.bL2MaskedImage) &&
                          (lppd->lpPSExtDevmode->dm2.useLanguageLevel == 2) ||
                          (lppd->lpPSExtDevmode->dm.bL3MaskedImage) &&
                          (lppd->lpPSExtDevmode->dm2.useLanguageLevel >= 3)
                         ))
                     {
                         bTransparent = TRUE;
                     }

                     if (!bTransparent)
                     {
                         NewShape = ShapeSource(DevBitmap, 0xFF,
                                            (LPWORD)&wSrcX, (LPWORD)&wSrcY,
                                            (LPWORD)&wSrcXE, (LPWORD)&wSrcYE);
                     
                         if (!NewShape)
                         {
                             bOnesBackgr = FALSE;   // Assume All Zeroes bkgr
                             NewShape = ShapeSource(DevBitmap, 0x00,
                                                (LPWORD)&wSrcX, (LPWORD)&wSrcY,
                                                (LPWORD)&wSrcXE, (LPWORD)&wSrcYE);
                         }
                     }
                     
                     // The smaller rectangle is found - now modify
                     // Source and destination rectangles
                     if (NewShape)
                     {
                         if(  ( (rop == SRCCOPY) && !bOnesBackgr ) ||
                              ( (rop == NOTSRCCOPY) && bOnesBackgr ) )
                         {
                             rgb = lpDrawMode->TextColor ;
                         }
                         else
                         {
                             rgb = lpDrawMode->bkColor ;
                         }
                         CBMOpaqueBox(lppd, (LPRECT) &DstRect, rgb);
                         SetRect((LPRECT) &BitRect,wSrcX,wSrcY,
                                 wSrcX+wSrcXE,wSrcY+wSrcYE);
                         TransformCoord((LPRECT) &NewDest,
                                        (LPRECT) &DstRect, (LPRECT) &BitRect,
                                        (LPRECT) &SrcRect);
                     }
                 }
                 if ( NULL == DevBitmap )
                 {
                    sRC = -1;
                 } else if (wSrcXE && wSrcYE)   // If non-empty rectangle
                 {
                     CBitmapHeader(lppd, (LPRECT)&BitRect,
                            (LPRECT)&NewDest, rop); // Send bitmap hdr token

// This block is added by Merging Pscript4.0 code drop on 10-20-1995.
   // EUDC Character is prited by BitBlt called from FE GDI.
   // ROP-0xe20746 has to be printed 1 = black and 0 = white.
   // ROP-0xb8074a has the opposit effect of ROP-0xe20746
   // This code have to be reviewed after application compatibility testing.
                     if ((rop == 0xe20746L) || (rop == 0xb8074aL))
                     {
                         CBitmapOperator( lppd, bTransparent,
                          lpPBrush->dFGColor,
                          lpPBrush->dBGColor,
                          rop); 
                           // Send image op and colors
                           /* 0x00000000L,  0x00FFFFFFL, */
                     }
                     else
                     CBitmapOperator(lppd, bTransparent, lpDrawMode->TextColor, 
                           lpDrawMode->bkColor, rop); // Send image op and colors

                     CBitmapData(lppd, DevBitmap,
                            (LPRECT)&BitRect, SrcYE ); // Send bitmap data
                 }
            }
            break;
    } // End switch(rop)
    if (NeedClipToken)
    {
       CClipEnd(lppd); // Remove clip rect.
    }
    if (bNewBitmap)
    {
        GlobalFreePtr(DevBitmap);
    }
   return(sRC);
}

/***********************************************************************
*                          HandleBufferedBitmap
*
*  function  : This function flush any buffered bitmap.
*            This is a public routine usually called in cases
*            like when the state machine changes state.
*
*  parameters: LP       lpDevice    --  PDEVICE structure
*
*  returns   : none
************************************************************************/
VOID FAR PASCAL HandleBufferedBitmap(LP lpDevice)
{
    LPBITMAPBUFFER lpBitmapBf = ((LPPDEVICE)lpDevice)->GlobalBuffer.lpBitmapBf;
    BYTE huge *lpBits;
    LPPBRUSH lpPBrush;
    LPDRAWMODE lpdm;
    LPRECT lpClip;
    
    // is there something buffered, if so, output it now
    if (((LPPDEVICE)lpDevice)->GlobalBuffer.hBitmapBf && lpBitmapBf &&
        !((LPPDEVICE)lpDevice)->GlobalBuffer.bFlushInProgress)
    {
        ((LPPDEVICE)lpDevice)->GlobalBuffer.handleBitmapNow = TRUE;
        ((LPPDEVICE)lpDevice)->GlobalBuffer.bFlushInProgress = TRUE;

        lpBits = MGLock((LPPDEVICE)lpDevice, lpBitmapBf->hBits, FALSE);
        if (lpBits)
        {
            lpPBrush = (lpBitmapBf->nullPBrush ? NULL
                        : &lpBitmapBf->pBrush);
            lpdm = (lpBitmapBf->nullDM ? NULL
                    : &lpBitmapBf->dm);

            // Fix bug 195632. jjia  2/20/97
            // Clear lppd in lpICMI data structure.
            if (lpdm && (lpdm->ICMCXform))
            {
                LPICMINFO  lpICMI;
                lpICMI = (LPICMINFO)GlobalLock((HANDLE)lpdm->ICMCXform);
                if (lpICMI)
                { 
                    lpICMI->lppd = NULL;
                    GlobalUnlock((HANDLE)lpdm->ICMCXform);
                }
            }

            lpClip = (lpBitmapBf->nullClip ? NULL
                      : &lpBitmapBf->clip);
            if (lpBitmapBf->dib)
            {
                StretchDIB(lpDevice, 0,
                           (WORD)lpBitmapBf->destX, (WORD)lpBitmapBf->destY,
                           (WORD)lpBitmapBf->destXE, (WORD)lpBitmapBf->destYE,
                           (WORD)lpBitmapBf->srcX, (WORD)lpBitmapBf->srcY,
                           (WORD)lpBitmapBf->srcXE, (WORD)lpBitmapBf->srcYE,
                           (LP)lpBits, (LPBITMAPINFO)&lpBitmapBf->bitmapInfo,
                           NULL, lpBitmapBf->rop, lpPBrush, lpdm, lpClip);
            }
            else
            {
                lpBitmapBf->devBitmap.bmBits = lpBits;
                DevStretchBlt(lpDevice,
                              (SHORT)lpBitmapBf->destX, 
                              (SHORT)lpBitmapBf->destY,
                              (SHORT)lpBitmapBf->destXE, 
                              (SHORT)lpBitmapBf->destYE,
                              &lpBitmapBf->devBitmap,
                              (SHORT)lpBitmapBf->srcX, 
                              (SHORT)lpBitmapBf->srcY,
                              (SHORT)lpBitmapBf->srcXE, 
                              (SHORT)lpBitmapBf->srcYE,
                              lpBitmapBf->rop, lpPBrush, lpdm, lpClip);
            }
        }
        MGUnlockFree((LPPDEVICE)lpDevice, lpBitmapBf->hBits, FALSE);
        MGUnlockFree((LPPDEVICE)lpDevice, 
                     ((LPPDEVICE)lpDevice)->GlobalBuffer.hBitmapBf, FALSE);
        ((LPPDEVICE)lpDevice)->GlobalBuffer.hBitmapBf = NULL;
        ((LPPDEVICE)lpDevice)->GlobalBuffer.lpBitmapBf = NULL;
        ((LPPDEVICE)lpDevice)->GlobalBuffer.bFlushInProgress = FALSE;
        ((LPPDEVICE)lpDevice)->GlobalBuffer.handleBitmapNow = FALSE;
    }
}

/***********************************************************************
*                          ColorOrGrayToDevice
*
*  function  : This function maps a DIB from a source rectangle
*              to a destination rectangle by performing:
*		 o - different data representations(4,8,16,24 or 32 bit data)
*                o - stripping out the the color information
*
*  Called : SHORT FAR PASCAL ColorOrGrayToDevice(lppd,DstRect,SrcRect,lpBits,lpDevBitmapInfo)
*
*  parameters: LPRECT       DstRect      -- Destination rectangle
*              LPRECT       SrcRect      -- Source rectangle
*              LPSTR        lpBits       -- Data bits
*              LPBITMAPINFO lpBitmapInfo -- Housekeeping data - Height,width,etc.
*
*  returns   : RC_ok
************************************************************************/
// L3_MASK
SHORT NEAR PASCAL ColorOrGrayToDevice(LPPDEVICE lppd, LPDRAWMODE lpdm,
                                      LPRECT DstRect,LPRECT SrcRect,
                                      LPSTR lpBits,LPBITMAPINFO lpBitmapInfo)
{
    WORD      i                                   ;
    WORD      TableLen                            ;
    BYTE      Red,Green,Blue                      ;
    BYTE      GrayTable[256]                      ;
    DWORD     ColorTable[256]                     ;
    RGBQUAD   Color                               ;
    RGBQUAD   NewColor                            ;
    SHORT     BitCount  = (SHORT)lpBitmapInfo->bmiHeader.biBitCount;
    LPRGBQUAD lppal = (LPRGBQUAD)((LPSTR)lpBitmapInfo + 
                                  lpBitmapInfo->bmiHeader.biSize);
    LPICMINFO lpICMI;
    BOOL      bCMYK = 0;
    BOOL      bRet;
    // FAST_IMAGE
    SHORT     FastImgType = 0;
    BOOL      bEnableFImage = FALSE;
    float     ResampleRatio[2];

    /*
     * For 4 and 8 we build a translate table from the dib color table.
     * here we build a gray scale palette from the RGB palette.
     * the values used here are from Foley Van Dam p. 613.
     *
     * Also note the line of code:
     *
     *    ColorTable[i] = (Red<<16) | (Green<<8) | Blue;
     *
     * is in PostScript order rather than GDI order which is a #define
     * in windows.h:
     *
     * #define RGB(r,g,b) \
     *          ((DWORD)(((BYTE)(r)|((WORD)(g)<<8))|(((DWORD)(BYTE)(b))<<16)))
     */

    if(  ( lpBitmapInfo->bmiHeader.biSize > sizeof(BITMAPINFOHEADER) ) &&
         ( ((BITMAPV4HEADER FAR *)lpBitmapInfo)->bV4CSType == LCS_DEVICE_CMYK) 
#ifndef ADOBE_DRIVER_42
           && lppd->lpPSExtDevmode->dm2.bfUseLevel2  
#endif
      )
    {
	  bCMYK = 1;
    }
    if ((int)lpBitmapInfo->bmiHeader.biHeight < 0)
    {
        int temp;

        // Upside down DIB - invert top and bottom of destination rectangle
        temp = DstRect->top;
        DstRect->top = DstRect->bottom;
        DstRect->bottom = temp;
    }

    // FAST_IMAGE  begin
    if (lppd->lpPSExtDevmode->dm.dm.dmColor != DMCOLOR_COLOR)
    {
        if ((lppd->lpPSExtDevmode->dm2.useLanguageLevel > 2) &&
            (lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED))
        {
            WORD KeywordIndex, OptionIndex;

            KeywordIndex = GetOpenUIKeywordIndex(lppd, "FastImage");
            if (KeywordIndex != 0xFFFF)
            {
                KeywordGetCurrentOption(lppd, KeywordIndex, (LPWORD)&OptionIndex);
                if ((OptionIndex == 1) || (OptionIndex == 2))
                    bEnableFImage = TRUE;
            }
        }

        if ((BitCount == 16 ) || (BitCount == 24) || (BitCount == 32))
            FastImgType |= COLORTOGRAY;        // Convert color to gray.
        //else if (((BitCount == 4) || (BitCount == 8)) && bEnableFImage)
        //Fix bug 193461.  jjia    2/6/97 
        else if ((BitCount == 4) || (BitCount == 8))  
            FastImgType |= INDEXCOLORTOGRAY;   // Convert indexed color to gray.

        if ((FastImgType != 0) && bEnableFImage)
        {
            DWORD  DestTotalPixel;
            DWORD  SrcTotalPixel;
            WORD   x_res, y_res;

            // Check to see if we need to do image resampling.
            // The idea is to resample if there are more image samples than
            // 150 per inch, and to resample so that the resulting image is
            // exactly 150 samples per inch.
            if (GetCurrentResolution(lppd, lppd->lpPSExtDevmode,
                 (LPINT)&x_res, (LPINT)&y_res) != RC_ok)
            {
                 x_res = 300;     // set default resolution
                 y_res = 300;
            }
            ResampleRatio[0] = x_res / 150;
            ResampleRatio[1] = y_res / 150;
            if (ResampleRatio[0] < 1)
                ResampleRatio[0] = 1;
            if (ResampleRatio[1] < 1)
                ResampleRatio[1] = 1;
            if (ResampleRatio[0] > 4) // Downsampling up to 1/4 device resolution.
                ResampleRatio[0] = 4;
            if (ResampleRatio[1] > 4)
                ResampleRatio[1] = 4;

            DestTotalPixel = ((DWORD)ABS(DstRect->bottom - DstRect->top)) * 
                     ((DWORD)ABS(DstRect->right - DstRect->left));
            SrcTotalPixel =  ((DWORD)(SrcRect->bottom - SrcRect->top)) * 
                     ((DWORD)(SrcRect->right - SrcRect->left));
            if ((DestTotalPixel/(ResampleRatio[0]*ResampleRatio[1])) < SrcTotalPixel)
            {
                FastImgType |= RESAMPLE;       // resample things to 1/4 of the device resolution
            }
        }
    }
    // FAST_IMAGE  end

    // L3_MASK
    if ((lpdm->bkMode == TRANSPARENT) &&
        (lppd->lpPSExtDevmode->dm.bL2MaskedImage) &&
        (lppd->lpPSExtDevmode->dm2.useLanguageLevel <= 2))
    {
        CDIBClipRgns(lppd, lpdm, DstRect, SrcRect,lpBits,lpBitmapInfo);
    }

    // L3_MASK FAST_IMAGE
    CDIBHeader(lppd, lpdm, SrcRect, DstRect, bCMYK, lpBitmapInfo,
               FastImgType, (float far *)ResampleRatio); // Send DIB hdr token
    if ((BitCount == 4) || (BitCount == 8))
    {
        if( lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM )
        {
            lpICMI  =  
                (LPICMINFO) GlobalLock( (HANDLE) lppd->graphics.hCMTransform);
        }
        TableLen   = (WORD)(1 << BitCount)        ;

        for (i = 0; i < TableLen; i++)
        {
            // Get color and separate components

            NewColor = Color = lppal[i] ;
            if( lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_DIB_IN )
            {
                // Convert CMYK into RGB components - see RedBook p.307
                //      Added 10-Jan-1994  -by-  [olegs]
                Color.rgbRed   = Red     = 255 -
                min(255, (Color.rgbRed+Color.rgbReserved));
                Color.rgbGreen = Green = 255 -
                    min(255, (Color.rgbGreen+Color.rgbReserved));
                Color.rgbBlue  = Blue = 255 -
                    min(255, (Color.rgbBlue+Color.rgbReserved));
            }else
            {
                Red   =  Color.rgbRed                ;
                Green =  Color.rgbGreen              ;
                Blue  =  Color.rgbBlue               ;
            }

            if( lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM )
            {
                Color.rgbRed  = NewColor.rgbBlue;   // palette RBG backward
                Color.rgbBlue = NewColor.rgbRed;    // from rgbColor
                bRet = ICMTranslateRGB(lpICMI->hICMT,
                        Color, 
                        (LPVOID) &NewColor, CMS_FORWARD);
                // Remember - ICMTranslateRGB always returns CMYK, so
                //  we have to extract RGBs for correct gray generation
                //  and to construct proper NewColor

                // No, - ICMTranslateRGB returns CMYK or RGB depends on
                // PCS of the ICC profile.
                if (lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT )   // 247974
                {
                    Red   = 255 - min(255, (NewColor.rgbReserved+NewColor.rgbBlue));
                    Green = 255 - min(255, (NewColor.rgbRed+NewColor.rgbBlue));
                    Blue  = 255 - min(255, (NewColor.rgbGreen+NewColor.rgbBlue));
                }
                else
                {
                    Red   = NewColor.rgbBlue   ;
                    Green = NewColor.rgbGreen  ;
                    Blue  = NewColor.rgbRed    ;
                    NewColor.rgbRed  = Red     ;
                    NewColor.rgbGreen= Green   ;
                    NewColor.rgbBlue = Blue    ;
                }
            }
            MemCopy( &ColorTable[i], &NewColor,    sizeof(DWORD)   );
            GrayTable [i] = INTENSITY(Red,Green,Blue);
        }
        // FAST_IMAGE
        if (!(FastImgType & INDEXCOLORTOGRAY))
        {
            CGrayTable(lppd,GrayTable ,TableLen);
            CColorTable(lppd,ColorTable,TableLen);
        }
    }

    if(  ( lpBitmapInfo->bmiHeader.biSize > sizeof(BITMAPINFOHEADER)) &&
         ( ((BITMAPV4HEADER FAR *)lpBitmapInfo)->bV4CSType == LCS_DEVICE_CMYK) )
    {
        lppd->lpGSStack->lpgGState->bColorMode |= CM_CMYK_DIB_IN;
    }

    // FAST_IMAGE
    CDIBOperator(lppd,BitCount, FastImgType);       // Send doNimage -or- doclutimage

    // L3_MASK  FAST_IMAGE    Send DIB data token
    CDIBDataBits(lppd, lpdm, SrcRect,DstRect, lpBits,lpBitmapInfo,
                 GrayTable, FastImgType, (float far *) ResampleRatio);

    lppd->lpGSStack->lpgGState->bColorMode &= ~CM_CMYK_DIB_IN;

    if( lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM )
    {
        GlobalUnlock( (HANDLE) lppd->graphics.hCMTransform);
    }
    
    return(RC_ok)                                 ;
}

