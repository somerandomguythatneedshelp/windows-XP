/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TGDIOBJ.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for  ...                  */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_TGRAPHSEG)
#pragma optimize("", off)


#define PI              3.1415926535
#define RAD2DEG         (float)(180.0/PI)
#define ColorId(flag)   ((flag) ? (6) :(8))
#define MINDIMENSION    (float)1.5              // For 0 width rectangles this
                                                //  is substituted
#define VALID_PATH      0x0001  // Do we have a valid path
#define LINETO_FLAG     0x0002  // If this flag is set - use lineto
                                //  instead of moveto for the first command

// Local procedures and types 

typedef struct {
     float xCent, yCent;
     int wRect, hRect;
     float angStart, angStop;
} ARCPARAMS, FAR *LPARCPARAMS;

void NEAR PASCAL CalcArcParams(LPRECT lpRect, LPPOINT Start, LPPOINT Stop, LPARCPARAMS lpAP);
void NEAR PASCAL TSendArc(LPPDEVICE lppd, LPARCPARAMS lpAP, BOOL fCCW);

// End of local procedures and types 

/*****************************************************************************/
/*                                                                           */          
/*                            PPSendPolyLine                                 */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPPOINT Point --                                                       */
/*    short sNumberPoints --                                                 */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

VOID  FAR PASCAL PSSendPolyLine (LPPDEVICE lppd, LPPOINT Point,short sNumPoints)
{
   short i, xdelta, ydelta;                         
   LPASCIIBINPTRS tempptr;
   short sLen = 0;
   short Flavor;
   BOOL  Binary;

   DetermineOutputCharacteristics(lppd, &Flavor, &Binary);
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   (*tempptr->PSSendCRLF)(lppd);       // Start the new polyline with newline
   sLen += (*tempptr->PSSendShort)(lppd,Point->x);
   sLen += (*tempptr->PSSendShort)(lppd,Point->y);                      

   if ( !( lppd->job.bfIsCurrentPoint & VALID_PATH) ) // No valid path
   {
      sLen += (*tempptr->PSSendBasic)(lppd,PSOP_newpath);
   }

   if ( lppd->job.bfIsCurrentPoint & LINETO_FLAG )
   {
      sLen += (*tempptr->PSSendBasic)(lppd,PSOP_lineto);
   }
   else
   {
      sLen += (*tempptr->PSSendBasic)(lppd,PSOP_moveto);
   }

   lppd->job.bfIsCurrentPoint = VALID_PATH | LINETO_FLAG;

   for (i=1; i<sNumPoints; i++)
   {
      xdelta = (Point+i)->x - (Point+i-1)->x;         // Relative x increment
      ydelta = (Point+i)->y - (Point+i-1)->y;         // Relative y increment
      if ( (xdelta | ydelta) != 0 )
      {
         sLen += (*tempptr->PSSendShort)(lppd,xdelta);
         sLen += (*tempptr->PSSendShort)(lppd,ydelta);
         sLen += (*tempptr->PSSendBasic)(lppd,PSOP_rlineto);
      }
      if ((sLen > 128) && !Binary)       // Fix bug 143183.  jjia  4/30/96
      {
         sLen = 0;
         (*tempptr->PSSendCRLF)(lppd);   // Send CR LF for every 10 points.
      }
   }
}

/*****************************************************************************/
/*                                                                           */          
/*                            PPSendBezier                                   */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPPOINT Point --                                                       */
/*    short sNumberPoints --                                                 */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

VOID  FAR PASCAL PSSendBezier(LPPDEVICE lppd, LPPOINT Point,short sNumPoints)
{
   short i,xi,yi;                                 
   LPASCIIBINPTRS tempptr;
   short sLen = 0;
   short Flavor;
   BOOL  Binary;

   DetermineOutputCharacteristics(lppd, &Flavor, &Binary);

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   (*tempptr->PSSendCRLF)(lppd);       // Start the new line with new line

   sLen += (*tempptr->PSSendShort)(lppd,Point->x);
   sLen += (*tempptr->PSSendShort)(lppd,Point->y);

   if ( !( lppd->job.bfIsCurrentPoint & VALID_PATH) ) // No valid path
   {
      sLen += (*tempptr->PSSendBasic)(lppd,PSOP_newpath);
   }

   if ( lppd->job.bfIsCurrentPoint & LINETO_FLAG )
   {
      sLen += (*tempptr->PSSendBasic)(lppd,PSOP_lineto);
   }
   else
   {
      sLen += (*tempptr->PSSendBasic)(lppd,PSOP_moveto);
   }

   lppd->job.bfIsCurrentPoint = VALID_PATH | LINETO_FLAG;

   for (i=0; i<sNumPoints-3; i+=3)
   {
      xi = (Point+i)->x;
      yi = (Point+i)->y;
      sLen += (*tempptr->PSSendShort)(lppd, ((Point+i+1)->x) - xi);
      sLen += (*tempptr->PSSendShort)(lppd, ((Point+i+1)->y) - yi);
      sLen += (*tempptr->PSSendShort)(lppd, ((Point+i+2)->x) - xi);
      sLen += (*tempptr->PSSendShort)(lppd, ((Point+i+2)->y) - yi);
      sLen += (*tempptr->PSSendShort)(lppd, ((Point+i+3)->x) - xi);
      sLen += (*tempptr->PSSendShort)(lppd, ((Point+i+3)->y) - yi);
      sLen += (*tempptr->PSSendBasic)(lppd, PSOP_rcurveto);

      if ((sLen > 128) && !Binary)       // Fix bug 143183.  jjia  4/30/96
      {
         (*tempptr->PSSendCRLF)(lppd);   // Send CR LF for every 10 points.
         sLen = 0;
      }
   }
   xi = (Point+i)->x;
   yi = (Point+i)->y;

   if (i == (sNumPoints-3))
   {
      (*tempptr->PSSendShort)(lppd, ((Point+i+1)->x) - xi);
      (*tempptr->PSSendShort)(lppd, ((Point+i+1)->y) - yi);
      (*tempptr->PSSendShort)(lppd, 2);
      PSSendFragment(lppd, PSFRAG_copy);
      (*tempptr->PSSendShort)(lppd, ((Point+i+2)->x) - xi);
      (*tempptr->PSSendShort)(lppd, ((Point+i+2)->y) - yi);
      (*tempptr->PSSendBasic)(lppd, PSOP_rcurveto);
   }
   else  if (i == (sNumPoints-2))
   {
      (*tempptr->PSSendShort)(lppd, ((Point+i+1)->x) - xi);
      (*tempptr->PSSendShort)(lppd, ((Point+i+1)->y) - yi);
      (*tempptr->PSSendBasic)(lppd, PSOP_rlineto);
   }
}

/*****************************************************************************/
/*                                                                           */          
/*                               PPSendRect                                  */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    int top --                                                             */
/*    int left --                                                            */
/*    int bottom --                                                          */
/*    int right --                                                           */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

VOID  FAR PASCAL PSSendRect(  LPPDEVICE lppd, int top, int left, int bottom,
                              int right)
{
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   (*tempptr->PSSendShort)(lppd, min(left,right));       // x
   (*tempptr->PSSendShort)(lppd, min(top, bottom));      // y

   if (ABS(right-left) != 0)
   {
      (*tempptr->PSSendShort)(lppd, ABS(right-left));    // Width
   }
   else
   {
      (*tempptr->PSSendFloat)(lppd,MINDIMENSION);        // Non zero width
   }

   if (ABS(bottom-top) != 0)
   {
      (*tempptr->PSSendShort)(lppd, ABS(bottom-top));    // Height
   }
   else
   {
      (*tempptr->PSSendFloat)(lppd,MINDIMENSION);        // Non zero height
   }
}

/*****************************************************************************/
/*                                                                           */          
/*                               Quadrant                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    float y  --                                                            */
/*    float x  --                                                            */
/*                                                                           */
/* Returns: float                                                            */
/*****************************************************************************/

float FAR Quadrant(float y, float x)
{
   float zero = (float)0.0;                      

   if ((y >= zero) && (x >= zero) )
   {
      return((float)   0.0);   // Quadrant 1
   }
   if( (y >= zero) && (x < zero) )
   {
      return((float) 180.0);   // Quadrant 2
   }
   if( (y < zero) && (x < zero) )
   {  
      return((float)-180.0);   // Quadrant 3
   }
   if( (y < zero) && (x >= zero) )
   { 
      return((float)   0.0);   // Quadrant 4
   }
}

/*****************************************************************************/
/*                                                                           */          
/*                            ArcTanDegrees                                  */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    float Number  --                                                       */
/*    float Denom  --                                                        */
/*                                                                           */
/* Returns: float                                                            */
/*****************************************************************************/

float FAR ArcTanDegrees(float Numer, float Denom)
{
   float angle;                                   

   if (Denom == (float)0.0)
   {
      if (Numer > (float)0.0)
      {
         angle = (float) 90.0;           // angle =  90
      }
      if (Numer < (float)0.0)
      {
         angle = (float)-90.0;           // angle = -90
      }
   }
   else
   {
      angle = (float)atan((double)(Numer/Denom));  // Arctan( Opposite/Adjacent )
      angle = RAD2DEG*angle+Quadrant(Numer,Denom); // Convert to degrees for PostScript
   }
   return(angle);                                 
}

/*****************************************************************************/
/*                                                                           */          
/*                            RectFill                                       */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPRECT lpRect --                                                       */
/*    short FillOp                                                           */
/*    LPSTR HatchOp --                                                       */
/*    LPSTR PatternOp --                                                     */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/
short FAR PASCAL RectFill(LPPDEVICE lppd, LPRECT lpRect,
                              short FillOp, LPSTR HatchOp, LPSTR PatternOp)
{
   LPASCIIBINPTRS tempptr;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
 
//   if (lppd->graphics.PathLevel == 0)       // Do Fill and Stroke only on base level
   {
      PSSendBrush(lppd, FillOp,HatchOp,PatternOp);// Solid,hatched or pattern
      PSSendRect(lppd, lpRect->top,lpRect->left,lpRect->bottom,lpRect->right);
      PSSendFragment(lppd, PSFRAG_rectfill);      // rectfill

      PSSetNoCurrentPoint(lppd);
   } // if (lppd->job.PathLevel == 0)

   return(RC_ok);
}


/*****************************************************************************/
/*                                                                           */          
/*                            RectStroke                                     */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPRECT lpRect --                                                       */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/
short FAR PASCAL RectStroke(LPPDEVICE lppd, LPRECT lpRect)
{
   LPASCIIBINPTRS tempptr;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

//   if (lppd->graphics.PathLevel == 0)       // Do Fill and Stroke only on base level
   {
       PSSendPenWidth(lppd, lppd->pen.ptWidth);        // Send linewidth
       PSSendPenCap(lppd, lppd->pen.bCap);             // Send cap
       PSSendPenJoin(lppd, lppd->pen.bJoin);           // Send the join
       PSSendPenMiter(lppd, lppd->pen.sMiterLimit);    // Send the miterlimit
       PSSendPenStyle(lppd, lppd->pen.bStyle, lppd->pen.ptWidth.x);
                                                       // Send solid or styled
       PSSendPenBGColor(lppd);
       PSSendPenFGColor(lppd);                         // Send foreground color

       // For non-square resolution printers, adjust CTM scaling factors now to
       //  be EQUAL so that stroked line width is uniform in X, Y directions. See
       //  "setlinewidth" and "rectstroke" operator documentation in the Red Book.

       if (lppd->DeviceRes.x_res != lppd->DeviceRes.y_res)
       {
           float flScaleY =  (float)lppd->DeviceRes.y_res / 
                             (float)lppd->DeviceRes.x_res;
           (*tempptr->PSSendBasic)(lppd, PSOP_gsave);   // Save graphics state
           PSSendOrientationMatrix(lppd, (float)1.0, flScaleY); // Emit correction CTM
           PSSendFragment(lppd, PSFRAG_concat);
           (*tempptr->PSSendCRLF)(lppd);
        }
        PSSendRect(lppd, lpRect->top,lpRect->left,lpRect->bottom,lpRect->right);
        PSSendFragment(lppd, PSFRAG_rectstroke);       // Stroke the path

        if (lppd->DeviceRes.x_res != lppd->DeviceRes.y_res)
        {
           (*tempptr->PSSendBasic)(lppd, PSOP_grestore);// Restore graphics state
        }

        PSSetNoCurrentPoint(lppd);
   } // if (lppd->job.PathLevel == 0)

   return(RC_ok);
}

/*****************************************************************************/
/*                                                                           */          
/*                            FillAndOrStroke                                */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    FLAG fFill --                                                          */
/*    FLAG fStroke --                                                        */
/*    short FillOp --                                                        */
/*    LPSTR HatchOp --                                                       */
/*    LPSTR PatternOp --                                                     */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/
short FAR PASCAL FillAndOrStroke(LPPDEVICE lppd, FLAG fFill, FLAG fStroke,
                                 short FillOp, LPSTR HatchOp, LPSTR PatternOp)
{
   LPASCIIBINPTRS tempptr;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
 
   if (lppd->graphics.PathLevel == 0)       // Do Fill and Stroke only on base level
   {
      fFill = fFill && (lppd->brush.bStyle != BS_HOLLOW) ;
      fStroke = fStroke && (lppd->pen.bStyle != LS_NOLINE) ;

      //  Fixed  08-Dec-1993  -by-   [olegs]
      //  We must issue --gsave-- and --grestore-- every time we use 
      //    patterned brush, otherwise it is possible that we will find 
      //    ourselves in Patterned colorspace,
      //    so any  calls to --setcolor-- or --setgray-- will generate 
      //    PostScript errors.

      // Another reason of sending -gsave- and -grestore- here is to save the
      // current path. Since -fill- will implicitly perform a -newpath-, we
      // have to save the path for the -stroke- operator.
      // If there is no -stroke- operator and the brush is solid(normal color),
      // we do not need to issue -gsave- and -grestore- here.   jjia  6/13/96
      if (fFill)
      {
         // If the brush style is solid, do not send gsave and grestore. jjia 6/4/96
         BYTE bBrushStyle;
         bBrushStyle = lppd->brush.bStyle;

         if ((bBrushStyle != BRUSHSTYLE_solid) || fStroke)
             PSSendGSave(lppd);                      // Save the graphics state
         PSSendBrush(lppd, FillOp,HatchOp,PatternOp);// Solid,hatched or pattern
         (*tempptr->PSSendBasic)(lppd, FillOp);      // eofill or fill
         if ((bBrushStyle != BRUSHSTYLE_solid) || fStroke)
             PSSendGRestore(lppd);                   // Restore the graphics state
      }            


      if (fStroke)
      {
         PSSendPenWidth(lppd, lppd->pen.ptWidth);        // Send linewidth
         PSSendPenCap(lppd, lppd->pen.bCap);             // Send cap
         PSSendPenJoin(lppd, lppd->pen.bJoin);           // Send the join
         PSSendPenMiter(lppd, lppd->pen.sMiterLimit);    // Send the miterlimit
         PSSendPenStyle(lppd, lppd->pen.bStyle, lppd->pen.ptWidth.x);
                                                         // Send solid or styled
         PSSendPenBGColor(lppd);
         PSSendPenFGColor(lppd);                         // Send foreground color

         // For non-square resolution printers, adjust CTM scaling factors now to
         //  be EQUAL so that stroked line width is uniform in X, Y directions. See
         //  "setlinewidth" and "rectstroke" operator documentation in the Red Book.

         if (lppd->DeviceRes.x_res != lppd->DeviceRes.y_res)
         {
            float flScaleY =  (float)lppd->DeviceRes.y_res / 
                              (float)lppd->DeviceRes.x_res;
            (*tempptr->PSSendBasic)(lppd, PSOP_gsave);   // Save graphics state
            PSSendOrientationMatrix(lppd, (float)1.0, flScaleY); // Emit correction CTM
            PSSendFragment(lppd, PSFRAG_concat);
            (*tempptr->PSSendCRLF)(lppd);
         }
         (*tempptr->PSSendBasic)(lppd, PSOP_stroke);     // Stroke the path

         if (lppd->DeviceRes.x_res != lppd->DeviceRes.y_res)
         {
            (*tempptr->PSSendBasic)(lppd, PSOP_grestore);// Restore graphics state
         }
      } // if (fStroke)

      PSSetNoCurrentPoint(lppd);
   } // if (lppd->job.PathLevel == 0)

   return(RC_ok);
}

// The following routines handle Brushes. The Brush structure for reference is:
//
//    typedef struct _PBRUSH
//    {
//        BYTE bStyle;   
//        BYTE bHatch;   
//        PAT pattern;   
//        DWORD dFGColor;
//        DWORD dBGColor;
//    }
//    PBRUSH;            

/*****************************************************************************/
/*                                                                           */ 
/*                            TBrushBGColor                                  */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    DWORD Color --                                                         */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TBrushBGColor(LPPDEVICE lppd, DWORD Color)
{
   lppd->brush.dBGColor = Color;                 
   return(RC_ok);                                 
}

/*****************************************************************************/
/*                                                                           */
/*                            TBrushFGColor                                  */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    DWORD Color --                                                         */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TBrushFGColor(LPPDEVICE lppd, DWORD Color)
{
   lppd->brush.dFGColor = Color;                 
   return(RC_ok);                                 
}

/*****************************************************************************/
/*                                                                           */
/*                            TBrushHatch                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    BYTE Hatch --                                                          */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TBrushHatch(LPPDEVICE lppd, BYTE Hatch)
{
   lppd->brush.bHatch = Hatch;                   
   return(RC_ok);                                 
}

/*****************************************************************************/
/*                                                                           */
/*                            TBrushPattern                                  */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPPAT Pattern --                                                       */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TBrushPattern(LPPDEVICE lppd, LPPAT Pattern)
{
   lppd->brush.pattern[0] = Pattern[0];          
   lppd->brush.pattern[1] = Pattern[1];          
   lppd->brush.pattern[2] = Pattern[2];          
   lppd->brush.pattern[3] = Pattern[3];          
   lppd->brush.pattern[4] = Pattern[4];          
   lppd->brush.pattern[5] = Pattern[5];          
   lppd->brush.pattern[6] = Pattern[6];          
   lppd->brush.pattern[7] = Pattern[7];          
   return(RC_ok);                                 
}

/*****************************************************************************/
/*                                                                           */
/*                            TBrushStyle                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    BYTE Style --                                                          */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TBrushStyle(LPPDEVICE lppd, BYTE Style)
{
   lppd->brush.bStyle = Style;                   
   return(RC_ok);                                 
}

                               
// The following routines handle Pens. The Pen structure for reference is:
//
//    typedef struct _PPEN
//    {
//        BYTE  bStyle;     
//        BYTE  bCap;       
//        BYTE  bJoin;      
//        BYTE  bSpare;     
//        POINT ptWidth;    
//        short sMiterLimit;
//        DWORD dColor;     
//    }
//    PPEN;                 

/*****************************************************************************/
/*                                                                           */
/*                               TPen                                        */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPPPEN Pen --                                                          */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TPen(LPPDEVICE lppd, LPPPEN Pen)
{
   lppd->pen.bCap        = Pen->bCap;            
   lppd->pen.dFGColor    = Pen->dFGColor;        
   lppd->pen.dBGColor    = Pen->dBGColor;        
   lppd->pen.bJoin       = Pen->bJoin;           
   lppd->pen.sMiterLimit = Pen->sMiterLimit;     
   lppd->pen.bStyle      = Pen->bStyle;          
   lppd->pen.ptWidth.x   = Pen->ptWidth.x;       
   lppd->pen.ptWidth.y   = Pen->ptWidth.y;       
   return(RC_ok);                                 
}

/*****************************************************************************/
/*                                                                           */
/*                              TPenCap                                      */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    BYTE Cap    --                                                         */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TPenCap(LPPDEVICE lppd, BYTE Cap)
{
   lppd->pen.bCap = Cap;                         
   return(RC_ok);                                 
}

/*****************************************************************************/
/*                                                                           */
/*                               TPenJoin                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    BYTE Join --                                                           */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TPenJoin(LPPDEVICE lppd, BYTE Join)
{
   lppd->pen.bJoin = Join;                       
   return(RC_ok);                                 
}

/*****************************************************************************/
/*                                                                           */
/*                            TPenMiterLimit                                 */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    DWORD Color --                                                         */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TPenMiterLimit(LPPDEVICE lppd, short MiterLimit)
{
   lppd->pen.sMiterLimit = MiterLimit;           
   return(RC_ok);                                 
}

/*****************************************************************************/
/*                                                                           */
/*                               TPenStyle                                   */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    DWORD Color --                                                         */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TPenStyle(LPPDEVICE lppd, BYTE Style)
{                                                   
   lppd->pen.bStyle = Style;                     
   return(RC_ok);                                 
}

/*****************************************************************************/
/*                                                                           */
/*                            TPenWidth                                      */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    DWORD Color --                                                         */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TPenWidth(LPPDEVICE lppd, POINT Point)
{
   lppd->pen.ptWidth.x = Point.x;                
   lppd->pen.ptWidth.y = Point.y;                
   return(RC_ok);                                 
}


/*****************************************************************************/
/*                                                                           */
/*                               TArc                                        */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPRECT lpRect --                                                       */
/*    LPPOINT Start --                                                       */
/*    LPPOINT Stop --                                                        */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TArc(LPPDEVICE lppd, LPRECT lpRect,LPPOINT Start,LPPOINT Stop)
{
   ARCPARAMS ap;
   BOOL fCCW = (lppd->graphics.bArcDirection == 0);  // TRUE if arcs are counter-clockwise
   short retval;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, GDIOBJ);

   CalcArcParams(lpRect, Start, Stop, (LPARCPARAMS) &ap);
   if ((Start->x == Stop->x) && (Start->y == Stop->y))
   {
       /* 
        * Need to draw complete ellipse/circle. So we have to have the start
        * and stop angles be 360 degrees apart.
        */
       if (fCCW)
       {
           ap.angStart = (float)360.0;
           ap.angStop = (float)0.0;
       }
       else
       {
           ap.angStart = (float)0.0;
           ap.angStop = (float)360.0;
       }
   }

   (*tempptr->PSSendCRLF)(lppd);
   if ( !( lppd->job.bfIsCurrentPoint & VALID_PATH) )        // No valid path
   {
      (*tempptr->PSSendBasic)(lppd,PSOP_newpath);
   }
   lppd->job.bfIsCurrentPoint = VALID_PATH | LINETO_FLAG;

   TSendArc(lppd, (LPARCPARAMS) &ap, fCCW);

//   FillAndOrStroke(lppd, FALSE, TRUE, PSOP_eofill,"hf","pf");
// Using fill instead of eofill. jjia   6/11/96
   FillAndOrStroke(lppd, FALSE, TRUE, PSOP_fill,"hf","pf");

   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                               TChord                                      */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPRECT lpRect --                                                       */
/*    FLAG fFill --                                                          */
/*    FLAG fStroke --                                                        */
/*    LPPOINT Start --                                                       */
/*    LPPOINT Stop --                                                        */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TChord(LPPDEVICE lppd, LPRECT lpRect, FLAG fFill, FLAG fStroke,
                        LPPOINT Start, LPPOINT Stop)
{
   ARCPARAMS ap;
   short retval;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, GDIOBJ);

   CalcArcParams(lpRect, Start, Stop, (LPARCPARAMS) &ap);
   if ((Start->x == Stop->x) && (Start->y == Stop->y))
   {
       /* 
        * Need to draw complete ellipse/circle. So we have to have the start
        * and stop angles be 360 degrees apart.
        */
       /* NOTE: We are drawing in the counter-clockwise direction */
       ap.angStart = (float)360.0;
       ap.angStop = (float)0.0;
   }

   (*tempptr->PSSendCRLF)(lppd);
   if (!( lppd->job.bfIsCurrentPoint & VALID_PATH) )        // No valid path
   {
      (*tempptr->PSSendBasic)(lppd,PSOP_newpath);
   }
   lppd->job.bfIsCurrentPoint = VALID_PATH | LINETO_FLAG;

   TSendArc(lppd, (LPARCPARAMS) &ap, TRUE);
        
   (*tempptr->PSSendBasic)(lppd, PSOP_closepath);

//   FillAndOrStroke(lppd, fFill,fStroke,PSOP_eofill,"hf","pf");
   FillAndOrStroke(lppd, fFill,fStroke,PSOP_fill,"hf","pf");
   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                               TEllipse                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPRECT lpRect --                                                       */
/*    FLAG fFill --                                                          */
/*    FLAG fStroke --                                                        */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TEllipse(LPPDEVICE lppd, LPRECT lpRect, FLAG fFill, FLAG fStroke)
{
   int top,bottom,right,left;                     
   short retval;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, GDIOBJ);

   top    = lpRect->top;                          
   bottom = lpRect->bottom;                       
   right  = lpRect->right;                        
   left   = lpRect->left;

   (*tempptr->PSSendCRLF)(lppd);
   if (!(lppd->job.bfIsCurrentPoint & VALID_PATH) )  // No valid path
   {
      (*tempptr->PSSendBasic)(lppd,PSOP_newpath);
   }
   lppd->job.bfIsCurrentPoint = VALID_PATH | LINETO_FLAG;

   (*tempptr->PSSendShort)(lppd, ABS(right-left));       // x Diameter
   (*tempptr->PSSendShort)(lppd, ABS(bottom-top));       // y Diameter
   (*tempptr->PSSendShort)(lppd, (right+left)/2);        // x Center
   // use USHORT to resolve the (int) negative value problem
   (*tempptr->PSSendShort)(lppd,((USHORT)(bottom+top))/2);  // y Center
   PSSendFragment(lppd, PSFRAG_ccwellipse);              // Construct the path

//   FillAndOrStroke(lppd, fFill,fStroke,PSOP_eofill,"hf","pf");
   FillAndOrStroke(lppd, fFill,fStroke,PSOP_fill,"hf","pf");
   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                               TCircle                                     */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPRECT lpRect --                                                       */
/*    FLAG fFill --                                                          */
/*    FLAG fStroke --                                                        */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TCircle(LPPDEVICE lppd, LPRECT lpRect,FLAG fFill,FLAG fStroke)
{
   int   top,bottom,right,left;
   float radius;
   short retval;
   LPASCIIBINPTRS tempptr;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, GDIOBJ);

   top    = lpRect->top;                          
   bottom = lpRect->bottom;                       
   right  = lpRect->right;                        
   left   = lpRect->left;                         

   (*tempptr->PSSendCRLF)(lppd);
   if ( !( lppd->job.bfIsCurrentPoint & VALID_PATH) ) // No valid path
   {
      (*tempptr->PSSendBasic)(lppd,PSOP_newpath);
   }
   lppd->job.bfIsCurrentPoint = VALID_PATH | LINETO_FLAG;

   radius = (float)(ABS(right-left)/2.0);                // Radius

   // use USHORT to resolve the (int) negative value problem
   (*tempptr->PSSendShort)(lppd,((USHORT)(right+left))/2);        // x Center # 286202
   (*tempptr->PSSendShort)(lppd,((USHORT)(bottom+top))/2);        // y Center
   (*tempptr->PSSendFloat)(lppd, radius);                // radius
   (*tempptr->PSSendShort)(lppd, 360);
   (*tempptr->PSSendShort)(lppd, 0);
   (*tempptr->PSSendBasic)(lppd, PSOP_arcn);             // Draw the circle
   (*tempptr->PSSendBasic)(lppd, PSOP_closepath);        // Close the path

//   FillAndOrStroke(lppd, fFill,fStroke,PSOP_eofill,"hf","pf");
   FillAndOrStroke(lppd, fFill,fStroke,PSOP_fill,"hf","pf");
   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                                  TLine                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPRECT lpRect --                                                       */
/*    FLAG fFill --                                                          */
/*    FLAG fStroke --                                                        */
/*    LPPOINT Start --                                                       */
/*    LPPOINT Stop --                                                        */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TLine(LPPDEVICE lppd, LPPOINT lppt)
{
   int   xStart,yStart,xDelta,yDelta;
   short retval;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, GDIOBJ);

   xStart = lppt[0].x;                          // Line starts here
   yStart = lppt[0].y;                          //   "    "     "
   xDelta = lppt[1].x - xStart;                 // Line stops here
   yDelta = lppt[1].y - yStart;                 //   "    "     "

   (*tempptr->PSSendCRLF)(lppd);
   (*tempptr->PSSendShort)(lppd, xStart);
   (*tempptr->PSSendShort)(lppd, yStart);

   if ( !( lppd->job.bfIsCurrentPoint & VALID_PATH) ) // No valid path
   {
      (*tempptr->PSSendBasic)(lppd,PSOP_newpath);
   }

   if ( lppd->job.bfIsCurrentPoint & LINETO_FLAG )
   {
      (*tempptr->PSSendBasic)(lppd,PSOP_lineto);
   }
   else
   {
      (*tempptr->PSSendBasic)(lppd,PSOP_moveto);
   }
   lppd->job.bfIsCurrentPoint = VALID_PATH | LINETO_FLAG;

   (*tempptr->PSSendShort)(lppd, xDelta);
   (*tempptr->PSSendShort)(lppd, yDelta);
   (*tempptr->PSSendBasic)(lppd, PSOP_rlineto);       // rlineto (xStop,yStop)

//   FillAndOrStroke(lppd, FALSE, TRUE, PSOP_eofill ,"hf","pf");
   FillAndOrStroke(lppd, FALSE, TRUE, PSOP_fill ,"hf","pf");
   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                                TPie                                       */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPRECT lpRect --                                                       */
/*    FLAG fFill --                                                          */
/*    FLAG fStroke --                                                        */
/*    LPPOINT Start --                                                       */
/*    LPPOINT Stop --                                                        */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TPie(  LPPDEVICE lppd, LPRECT lpRect,FLAG fFill,FLAG fStroke,
                        LPPOINT Start,LPPOINT Stop)
{
   ARCPARAMS ap;
   short retval;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, GDIOBJ);

   CalcArcParams(lpRect, Start, Stop, (LPARCPARAMS) &ap);

   if ((Start->x == Stop->x) && (Start->y == Stop->y))
   {
       /* 
        * Need to draw complete ellipse/circle. So we have to have the start
        * and stop angles be 360 degrees apart.
        */
       /* NOTE: We are drawing in the counter-clockwise direction */

       // keep the end point of the arc, it becomes current point 
       // stoke use it to draw correctly

       ap.angStart += (float)360.0;

       //ap.angStop = (float)0.0;
   }

   (*tempptr->PSSendCRLF)(lppd);
   (*tempptr->PSSendFloat)(lppd, ap.xCent);
   (*tempptr->PSSendFloat)(lppd, ap.yCent);

   if ( !( lppd->job.bfIsCurrentPoint & VALID_PATH) ) // No valid path
   {
      (*tempptr->PSSendBasic)(lppd,PSOP_newpath);
   }
   if ( lppd->job.bfIsCurrentPoint & LINETO_FLAG )
   {
      (*tempptr->PSSendBasic)(lppd,PSOP_lineto);
   }
   else
   {
      (*tempptr->PSSendBasic)(lppd,PSOP_moveto);
   }
   lppd->job.bfIsCurrentPoint = VALID_PATH | LINETO_FLAG;

   TSendArc(lppd, (LPARCPARAMS) &ap, TRUE);
        
   (*tempptr->PSSendBasic)(lppd, PSOP_closepath);

//   FillAndOrStroke(lppd, fFill,fStroke,PSOP_eofill,"hf","pf");
   FillAndOrStroke(lppd, fFill,fStroke,PSOP_fill,"hf","pf");
   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                               TPolygon                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPPOINT lppt --                                                        */
/*    FLAG fFill --                                                          */
/*    FLAG fStroke --                                                        */
/*    FLAG fEOFill --                                                        */
/*    short sNumPoints --                                                    */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TPolygon(LPPDEVICE lppd, LPPOINT lppt,FLAG fFill,FLAG fStroke,
                          FLAG fEOFill,short sNumPoints)
{
   short retval;
   LPASCIIBINPTRS tempptr;
   BYTE  PolyMode = lppd->graphics.bPolyMode;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, GDIOBJ);

   switch (PolyMode)
   {
      case PM_POLYLINE    :
         PSSendPolyLine(lppd, lppt,sNumPoints);
         (*tempptr->PSSendBasic)(lppd, PSOP_closepath);
      break;

      case PM_BEZIER      :
         PSSendBezier(lppd, lppt,sNumPoints);
         (*tempptr->PSSendBasic)(lppd, PSOP_closepath);
      break;

      case POLYLINESEGMENT:
         PSSendPolyLine(lppd, lppt,sNumPoints);
         fFill = FALSE ;
         // According to Microsoft code we should do it this way !!
         //  Fixed  17-Mar-1993  -by-  [olegs]
         //  PSSendLineSeg(lppd, lppt,sNumPoints);
      break;                                        
   }

   if (fEOFill == ALTERNATE)
   {
      FillAndOrStroke(lppd, fFill, fStroke, PSOP_eofill,"hf","pf");
   }
   else
   {
      FillAndOrStroke(lppd, fFill, fStroke, PSOP_fill,"hfW","pfW");
   }

   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                               TPolyLine                                   */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPPOINT lppt --                                                        */
/*    short sNumPoints --                                                    */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TPolyLine(LPPDEVICE lppd, LPPOINT lppt,short sNumPoints)
{
   short retval;
   BYTE  PolyMode = lppd->graphics.bPolyMode;
   retval = TokenNeedsProcset(lppd, GDIOBJ);

   switch (PolyMode)
   {
      // According to Microsoft code we should do it this way !!
      //  Fixed  17-Mar-1993  -by-  [olegs]
      case POLYLINESEGMENT :
      case PM_POLYLINE     :
         PSSendPolyLine(lppd, lppt, sNumPoints);
      break;                                   

      case PM_BEZIER      :
         PSSendBezier(lppd, lppt, sNumPoints);           
      break;                                   
   }

   FillAndOrStroke(lppd, FALSE, TRUE, PSOP_eofill,"hf","pf");
   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                            TpolyBezier                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPPOINT lppt --                                                        */
/*    short sNumPoints --                                                    */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TPolyBezier(LPPDEVICE lppd, LPPOINT lppt,short sNumPoints)
{
   short retval;

   retval = TokenNeedsProcset(lppd, GDIOBJ);

   PSSendBezier(lppd, lppt,sNumPoints);           
   FillAndOrStroke(lppd, FALSE, TRUE, PSOP_eofill,"hf","pf");
   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                               TRectangle                                  */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPRECT lpRect --                                                       */
/*    FLAG fFill --                                                          */
/*    FLAG fStroke --                                                        */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TRectangle(LPPDEVICE lppd, LPRECT lpRect,FLAG fFill,FLAG fStroke)
{
   int   top,bottom,right,left;
   LPASCIIBINPTRS tempptr;
   BYTE   bOldCap;
   BYTE   bOldJoin;
   short  retval;
   FLAG   fFill_1, fStroke_1;
   BYTE   bBrushStyle;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   retval = TokenNeedsProcset(lppd, GDIOBJ);

   top    = lpRect->top;
   bottom = lpRect->bottom;
   right  = lpRect->right;                        
   left   = lpRect->left;

   (*tempptr->PSSendCRLF)(lppd);

   fFill_1 = fFill && (lppd->brush.bStyle != BS_HOLLOW) ;
   fStroke_1 = fStroke && (lppd->pen.bStyle != LS_NOLINE) ;
   bBrushStyle = lppd->brush.bStyle;

   // performence improvement: using solid brush to fill a rect only.
   if (fFill_1 && !fStroke_1 &&
      (bBrushStyle == BRUSHSTYLE_solid) &&
      (lppd->graphics.PathLevel == 0))
   {
        RectFill(lppd, lpRect, PSOP_fill, "hf","pf");
   }
   // performence improvement: stroke only. 
   else if ((!fFill_1 && fStroke_1) &&
      (lppd->graphics.PathLevel == 0))
   {
       bOldCap =  lppd->pen.bCap ;
       bOldJoin = lppd->pen.bJoin ;
        
       TPenCap(lppd, 0);   // Send a butt cap
       TPenJoin(lppd, 0);  // Send a meter join

       RectStroke(lppd, lpRect);
       TPenCap(lppd, bOldCap);
       TPenJoin(lppd, bOldJoin); 
   }
   else
   {
       (*tempptr->PSSendShort)(lppd, left);
       (*tempptr->PSSendShort)(lppd, top);
        
       if ( !( lppd->job.bfIsCurrentPoint & VALID_PATH) ) // No valid path
       {
          (*tempptr->PSSendBasic)(lppd,PSOP_newpath);
       }
       if ( lppd->job.bfIsCurrentPoint & LINETO_FLAG )
       {
          (*tempptr->PSSendBasic)(lppd,PSOP_lineto);
       }
       else
       {
          (*tempptr->PSSendBasic)(lppd,PSOP_moveto);
       }
       lppd->job.bfIsCurrentPoint = VALID_PATH | LINETO_FLAG;
        
       (*tempptr->PSSendShort)(lppd, right - left);    // dx
       (*tempptr->PSSendShort)(lppd, bottom - top);    // dy
       PSSendFragment(lppd, PSFRAG_rectshape);
        
       // Fix for bug#371 - output rectangle with square butt
       //  Changed  23-Jun-1993  -by-  [olegs]
       bOldCap =  lppd->pen.bCap ;
       bOldJoin = lppd->pen.bJoin ;
        
       TPenCap(lppd, 0);   // Send a butt cap
       TPenJoin(lppd, 0);  // Send a meter join

       FillAndOrStroke(lppd, fFill,fStroke,PSOP_fill,"hf","pf");
       TPenCap(lppd, bOldCap);
       TPenJoin(lppd, bOldJoin); 
   }
   return(retval);
}

/******************************************************************************
*                                                                           
*                              TRoundRectangle
*               
*  Function:
*       This routine generates the PostScript for drawing rectangles with
*       round corners and sends it to the output stream.
*
*  Arguments:
*       LPPDEVICE lppd -- pdevice pointer
*       lpRect - ptr to structure describing the rectangle's size and location
*       point - ptr to ordered pair (x,y). x is horizontal radius of circular
*               corners, y is vertical radius
*       fFill - flag indicating that figure should be filled
*       sStroke - flag indicating that the figure outline should be drawn
*
*  Returns:
*       RC_ok if no error, else RC_fail.
*
******************************************************************************/

short FAR PASCAL TRoundRectangle(LPPDEVICE lppd, LPRECT lpRect,FLAG fFill,
                                 FLAG fStroke,LPPOINT point)
{
   int top,bottom,right,left;                     
   int x, y, tmpi;                                
   float tmpf;                                    
   short retval;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, GDIOBJ);

   top    = lpRect->top;                          
   bottom = lpRect->bottom;                       
   if (top > bottom)
   {
      tmpi = top;                                 
      top = bottom;                               
      bottom = tmpi;  //Moved [PPeng] fix from 2.2 driver. 11-Aug-1994 [olegs]
   }
   right  = lpRect->right;                        
   left   = lpRect->left;                         
   if (left > right)
   {
      tmpi = right;                               
      right = left;                               
      left = tmpi;                                
   }
   x = point->x;                             
   y = point->y;                             

   // If the dimension(s) of the round corner exceed the bounding box
   if (x == y)
   {
      x = min(x,right-left);                       
      x = min(x,bottom-top);                       
   }
   else
   {
      x = min(x,right-left);                       
      y = min(y,bottom-top);                       
   }

   if( (x == 0) || (y == 0) )
   {
      return (0);
   }

   (*tempptr->PSSendCRLF)(lppd);

   if ( !( lppd->job.bfIsCurrentPoint & VALID_PATH) ) // No valid path
   {
      (*tempptr->PSSendBasic)(lppd,PSOP_newpath);
   }
   lppd->job.bfIsCurrentPoint = VALID_PATH | LINETO_FLAG;

   // Create path outlining the object.
   if (x == y)                                           // Corners are round
   {
      (*tempptr->PSSendShort)(lppd, left);                       
      (*tempptr->PSSendShort)(lppd, top);                        
      (*tempptr->PSSendShort)(lppd, right);                      
      (*tempptr->PSSendShort)(lppd, bottom);                     
      tmpf = x;                                   
      tmpf = tmpf/2;                              
      (*tempptr->PSSendFloat)(lppd, tmpf);                       
      PSSendFragment(lppd, PSFRAG_rrp);                 
   }
   else                                                  // Corners are elliptical
   {
      tmpf = right - left;                        
      tmpf = tmpf/x;                              
      (*tempptr->PSSendFloat)(lppd, tmpf);                       

      tmpf = bottom - top;                        
      tmpf = tmpf/y;                              
      (*tempptr->PSSendFloat)(lppd, tmpf);                       
      (*tempptr->PSSendShort)(lppd, x);                          
      (*tempptr->PSSendShort)(lppd, y);                          
      (*tempptr->PSSendShort)(lppd, left);                       
      (*tempptr->PSSendShort)(lppd, top);                        
      PSSendFragment(lppd, PSFRAG_RRp);                 
   }
   (*tempptr->PSSendBasic)(lppd, PSOP_closepath);

//   FillAndOrStroke(lppd, fFill,fStroke,PSOP_eofill,"hf","pf");
   FillAndOrStroke(lppd, fFill,fStroke,PSOP_fill,"hf","pf");

   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                               TScanLine                                   */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPPOINT Points --                                                      */
/*    FLAG fFill --                                                          */
/*    FLAG fStroke --                                                        */
/*    short sCount --                                                        */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TScanLine(LPPDEVICE lppd, LPPOINT Points,FLAG fFill,
                           FLAG fStroke,short sCount)
{
   int   x, Length, i;
   float y;
   short retval;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, GDIOBJ);

   if (fFill)
   {
      fStroke = FALSE;    // Brush takes precedence over the pen
   }
                           // " ... brush is mighter than a pen ..."
   y = Points->y + (float).5 ;

   (*tempptr->PSSendCRLF)(lppd);

   for (i = 1 ; i < sCount ; i++)
   {
      x = Points[i].x;
      Length = Points[i].y - x;

      (*tempptr->PSSendBasic)(lppd,PSOP_newpath);
      (*tempptr->PSSendShort)(lppd, x);               // x
      (*tempptr->PSSendFloat)(lppd, y);               // x y
      (*tempptr->PSSendBasic)(lppd, PSOP_moveto);
      (*tempptr->PSSendShort)(lppd, Length);          // dx

      if (fFill)             // If there is a brush - use it
      {
         (*tempptr->PSSendShort)(lppd, 1);           // dx dy
         PSSendFragment(lppd, PSFRAG_rectshape );
      }
      else
      {
         (*tempptr->PSSendShort)(lppd, 0);          // dx dy
         (*tempptr->PSSendBasic)(lppd, PSOP_rlineto);
      }
//      FillAndOrStroke(lppd, fFill,fStroke,PSOP_eofill,"hf","pf");
      FillAndOrStroke(lppd, fFill,fStroke,PSOP_fill,"hf","pf");
   }
   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                            TScanLineBegin                                 */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TScanLineBegin(LPPDEVICE lppd)
{
   return(TokenNeedsProcset(lppd, GDIOBJ));
}

/*****************************************************************************/
/*                                                                           */
/*                            TScanLineEnd                                   */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TScanLineEnd(LPPDEVICE lppd)
{
   return(RC_ok);
}

/*****************************************************************************/
/*                                                                           */
/*                            TBMOpaqueBox                                   */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TBMOpaqueBox(LPPDEVICE lppd, LPRECT DstRect,DWORD rgb)
{
   FLAG fGray;                                    
   short retval;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, GDIOBJ);

   PSSendGSave(lppd);                              // Save the graphics state
   fGray = PSSendColor(lppd, rgb);                 // Send gray -or- r g b
   PSSendColorOP(lppd, fGray);                     // Send  sg  -or-  sco

   PSSendRect(lppd, DstRect->top,DstRect->left,
              DstRect->bottom,DstRect->right);     // Send x y width height
   PSSendFragment(lppd, PSFRAG_BMFill);            // Solid fill a'la Bitmaps

   PSSendGRestore(lppd);                           // Restore the graphics state
   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                               TOpaqueBox                                  */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPRECT DstRect --                                                      */
/*    DWORD rgb --                                                           */
/*    WORD  Angle --                                                         */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TOpaqueBox(LPPDEVICE lppd, LPRECT DstRect,DWORD rgb, WORD Angle)
{
   FLAG fGray;                                    
   short retval;
   LPASCIIBINPTRS tempptr;
   WORD   tx, ty;

   tx = ty = 0;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   retval = TokenNeedsProcset(lppd, GDIOBJ);

   PSSendGSave(lppd);                              // Save the graphics state
   fGray = PSSendColor(lppd, rgb);                 // Send gray -or- r g b
   PSSendColorOP(lppd, fGray);                     // Send  sg  -or-  sco
   
   // Added code to handle opaque boxes for rotated text.
   //  07-Apr-1994  -by-  [olegs]
   if( Angle)
   {
        tx =   min(DstRect->left, DstRect->right);
        ty =   min(DstRect->top, DstRect->bottom);
        
        (*tempptr->PSSendShort)(lppd, tx);
        (*tempptr->PSSendShort)(lppd, ty);
        (*tempptr->PSSendBasic)(lppd, PSOP_translate);               
        (*tempptr->PSSendFloat)(lppd, (float) -(Angle/10.0) );
        (*tempptr->PSSendBasic)(lppd, PSOP_rotate);               
   }

   PSSendRect(lppd, DstRect->top - ty, DstRect->left - tx,
             DstRect->bottom - ty ,DstRect->right - tx); // Send x y width height
   PSSendFragment(lppd, PSFRAG_rectfill);     // Solid fill

   PSSendGRestore(lppd);       // Restore the graphics state
   (*tempptr->PSSendCRLF)(lppd);       // end with newline bug # 270389

   return(retval);
}

/*****************************************************************************/
/*                                                                           */
/*                               TEndPath                                    */                                                     
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPPATHINFO lpPathInfo --                                               */
/*    LPDRAWMODE lpDrawMode --                                               */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void FAR PASCAL TEndPath(LPPDEVICE lppd, LPPATHINFO lpPathInfo, LPDRAWMODE lpDrawMode)
{
   FLAG  fFill;      // Should we fill the path
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   fFill = FALSE;

   switch (lpPathInfo->RenderMode)
   {
      case RM_NO_DISPLAY:
      break   ;           // Do nothing

      case RM_CLOSED :
         (*tempptr->PSSendBasic)(lppd, PSOP_closepath);
         fFill = TRUE;
         lppd->job.bfIsCurrentPoint |= LINETO_FLAG;      // Remove the 
         lppd->job.bfIsCurrentPoint ^= LINETO_FLAG;      //  lineto flag

                   /*   ...... fall thru .........   */
      case RM_OPEN :
         if (lpPathInfo->FillMode == ALTERNATE)
         {
            FillAndOrStroke(lppd, fFill, TRUE, PSOP_eofill, "hf", "pf");
         }
         else
         {
            FillAndOrStroke(lppd, fFill, TRUE, PSOP_fill, "hfW", "pfW");
         }
      break;

      default:
      break;
   } // switch (...)
}

/*****************************************************************************/
/*                                                                           */
/*                               TSendArc                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd --                                                       */
/*    LPARCPARAMS lpAP --                                                    */
/*    BOOL fCCW --                                                           */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL TSendArc(LPPDEVICE lppd, LPARCPARAMS lpAP, BOOL fCCW)
{
   short arcOp = (fCCW) ? PSOP_arcn : PSOP_arc;                               
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
                               
   if (lpAP->wRect == lpAP->hRect)                     // Circular arcs
   {
      
      (*tempptr->PSSendFloat)(lppd, lpAP->xCent);     // Center of rectangle.
      (*tempptr->PSSendFloat)(lppd, lpAP->yCent);            
      (*tempptr->PSSendFloat)(lppd, ((float)lpAP->wRect)/2); // Half width of rectangle
      (*tempptr->PSSendFloat)(lppd, lpAP->angStart);  // Arc starts here
      (*tempptr->PSSendFloat)(lppd, lpAP->angStop);   // Arc stops here
      (*tempptr->PSSendBasic)(lppd, arcOp);           // arcn(=CCW) or arc(=CW)
      (*tempptr->PSSendCRLF)(lppd);                          
   }
   else
   {                                                  // Elliptical arcs
      PSSendFragment(lppd, PSFRAG_CTMsave);           
      (*tempptr->PSSendCRLF)(lppd);                          

      (*tempptr->PSSendFloat)(lppd, lpAP->xCent);     // Center of rectangle.
      (*tempptr->PSSendFloat)(lppd, lpAP->yCent);                    
      (*tempptr->PSSendBasic)(lppd, PSOP_translate );          

      (*tempptr->PSSendShort)(lppd, lpAP->wRect);     // Width of rectangle
      (*tempptr->PSSendShort)(lppd, lpAP->hRect);     // Height of rectangle
      (*tempptr->PSSendBasic)(lppd, PSOP_scale);               
      (*tempptr->PSSendCRLF)(lppd);                          

      (*tempptr->PSSendShort)(lppd, 0);               // Centre: (0,0)
      (*tempptr->PSSendShort)(lppd, 0);
      (*tempptr->PSSendFloat)(lppd, (float)0.5);      // Radius: 0.5
      (*tempptr->PSSendFloat)(lppd, lpAP->angStart);  // Arc starts here
      (*tempptr->PSSendFloat)(lppd, lpAP->angStop);   // Arc stops here
      (*tempptr->PSSendBasic)(lppd, arcOp);           // arcn(=CCW) or arc(=CW)
      (*tempptr->PSSendCRLF)(lppd);                          
      PSSendFragment(lppd, PSFRAG_CTMrestore);        
      (*tempptr->PSSendCRLF)(lppd);                          
   }
}

/*****************************************************************************/
/*                                                                           */
/*                            TPenBGColor                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd -- pdevice                                               */
/*    DWORD Color --                                                         */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

short FAR PASCAL TPenBGColor(LPPDEVICE lppd, DWORD Color)
{
   lppd->pen.dBGColor = Color;                   
   return(RC_ok);                                 
}

/*****************************************************************************/
/*                                                                           */
/*                            TPenFGColor                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd -- pdevice                                               */
/*    DWORD Color --                                                         */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

short FAR PASCAL TPenFGColor(LPPDEVICE lppd, DWORD Color)
{
   lppd->pen.dFGColor = Color;                   
   return(RC_ok);                                 
}

/*****************************************************************************/
/*                                                                           */
/*                               CalcArcParams                               */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPRECT lpRect --                                                       */
/*    LPPOINT Start --                                                       */
/*    LPPOINT Stop --                                                        */
/*    LPARCPARAMS lpAP --                                                    */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

void NEAR PASCAL CalcArcParams(LPRECT lpRect, LPPOINT Start, LPPOINT Stop, LPARCPARAMS lpAP)
{
   int   top,bottom,right,left;
   int   xStart,yStart,xStop,yStop;
   float Numer,Denom;
   float aspectRatio;         // ratio of width to height of bounding rect

   left   = lpRect->left;     // This rectangle bounds the arc
   top    = lpRect->top;             
   bottom = lpRect->bottom;                       
   right  = lpRect->right;                        

   lpAP->wRect  = ABS(right - left);                // Width of rectangle
   lpAP->hRect  = ABS(top   - bottom);              // Height of rectangle

   aspectRatio = (float)lpAP->wRect/(float)lpAP->hRect;

   xStart = Start->x;                               // Arc starts here
   yStart = Start->y;                               //  "    "     "
   xStop  = Stop->x;                                // Arc stops here
   yStop  = Stop->y;                                //  "    "     "

   lpAP->xCent=((float)(right+left))/2;             // Center of the bounding
   lpAP->yCent=((float)(bottom+top))/2;             // rectangle

   Numer    = (float)yStart-lpAP->yCent;            // Leg opposite the angle
   Denom    = (float)xStart-lpAP->xCent;            // Leg adjacent to the angle
   Numer    *= aspectRatio;                         // Adjust fraction to compensate for non-square
   lpAP->angStart = ArcTanDegrees(Numer,Denom);     // Convert to degrees for PostScript

   Numer    = (float)yStop-lpAP->yCent;             // Leg opposite the angle
   Denom    = (float)xStop-lpAP->xCent;             // Leg adjacent to the angle
   Numer    *= aspectRatio;                         // Adjust fraction to compensate for non-square
   lpAP->angStop  = ArcTanDegrees(Numer,Denom);     // Convert to degrees for PostScript

   return;
}
                                                   
