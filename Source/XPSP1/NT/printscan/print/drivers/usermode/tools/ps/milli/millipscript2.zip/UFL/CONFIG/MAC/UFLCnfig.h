/*
 *	Universal Font Library
 *
 *	Copyright (c) 1996 Adobe Systems Inc.
 *	All Rights Reserved
 *
 *	UFLConfig.h
 *
 *		Macintosh version of UFLConfig
 *
 * $Header: $
 */

#ifndef _H_UFLConfig
#define _H_UFLConfig

#define MAC_ENV	1

#define UFLEXPORT
#define UFLEXPORTPTR
#define UFLCALLBACK
#define UFLCALLBACKDECL

#endif
