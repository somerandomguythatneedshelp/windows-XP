/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ENUMFONT.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for font enumeration      */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_ENUMSEG)


short FAR PASCAL dmEnumDFonts(LP,LPSTR,FARPROC,LP);


/****************************************************************************
*                       SearchFontList
*  function:
*       Searches a FONTLIST structure linearly from *lpIndex till it reaches
*       the end of the list or a font with the desired facename is found.
*       *lpIndex takes the value of the new location in the list.
*  prototype:
*       BOOL SearchFontList(LPPDEVICE, LPSTR, LPFONTLIST, WORD, LPWORD)
*  parameters:
*       lppd:         Pointer to PDEVICE structure.
*       lpszFaceName: Pointer to face name string (should be non null)
*       lpFontList:   Pointer to FONTLIST structure (stored in WPX structure)
*       wNumFonts:    Number of fonts in FontList.
*       lpIndex:      Pointer to index from which to begin search.
*       bFontName:    TRUE if lpszFontName is the facename, FALSE if it is not
*  returns:
*       TRUE if font found, else FALSE
****************************************************************************/
BOOL NEAR PASCAL SearchFontList(LPPDEVICE lppd, LPSTR lpszFaceName, 
                                LPFONTLIST lpFontList, WORD wNumFonts, 
                                LPWORD lpIndex, BOOL bFontName)
{
    LPFONTLIST  lpFL;
    LPSTRINGREF lpName;
    BOOL        rc = FALSE;

    if (*lpIndex >= wNumFonts)
        return FALSE;

    /* Adjust, as we may not be searching from the beginning */
    lpFL = lpFontList + *lpIndex;
    wNumFonts -= *lpIndex;

    if (lpszFaceName) 
    {
        while (wNumFonts--) 
        {
            lpName = 
                (LPSTRINGREF) (bFontName ? &lpFL->fontname : &lpFL->familyname);
            if (lstrcmpi(lpszFaceName, 
                         STRREF_TO_PTR(lppd->lpWPXblock->WPXstrings, 
                                       (*lpName))) == 0) 
            {
                rc = TRUE;
                break;
            }
            else 
            {
                (*lpIndex)++;
                lpFL++;
            }
        }
    }

    return rc;
}


/****************************************************************************
*                       EnumFontsCallback
*  function:
*       Gets called as the callback function when Enumerating fonts. It calls
*       the callback function provided by the caller of EnumDfonts with 
*       a Logfont and Textmetric structure for the font it is enumerating.
*       If the printer resolution is equal on both axes, it returns the values 
*       precomputed for 300x300, else it recomputes for current resolution.
*  parameters:
*       lpFontData: Pointer to Fontdata of current font.
*       lpClientData: Pointer to structure which has the callback function,
*                     its parameter, and a pointer to PDevice.
*  returns:
*       whatever the user call back returns.
****************************************************************************/
WORD FAR PASCAL EnumFontsCallback(LPFONTDIRECTORY lpFontDir, 
                                  LP lpClientData)
{
    LOGFONT          LogFont;
    LPCALLBACKSTRUCT lpCBStruct = (LPCALLBACKSTRUCT) lpClientData;
    LPPDEVICE        lppd = lpCBStruct->lppd;
    LPTEXTMETRIC     lpTextMetric;
    WORD             rc = 1;

    if (CreateTMandLogFont(lppd, lpFontDir, &LogFont, &lpTextMetric))
      {
         rc = (*lpCBStruct->lpCallbackProc)((LPLOGFONT) &LogFont, lpTextMetric, 
                                       MAGIC_FONTTYPE, lpCBStruct->lpClientData);
      }
   else
     rc = RC_ERROR;

    return rc;
}
WORD NEAR PASCAL CreateTMandLogFont (LPPDEVICE lppd, LPFONTDIRECTORY lpFontDir,
                                    LOGFONT *LogFont, LPTEXTMETRIC *lpTextMetric)
{
    int              xres, yres;
    WORD             rc = 1;
    
    if (lppd)
   {
      xres = lppd->DeviceRes.x_res;
      yres = lppd->DeviceRes.y_res;

      if (! lppd->lptm)
      {
         lppd->lptm = GlobalAllocPtr(GDLLHND, sizeof(TEXTMETRIC));
         if (!lppd->lptm)
               return rc;
      }
   }

    if ((xres == yres) && lppd)
    {
        *(lppd->lptm) = lpFontDir->defTextMetric;

    }
    //currently do not handle non-square resolution.

    *lpTextMetric = lppd ? lppd->lptm : (LPTEXTMETRIC) &(lpFontDir->defTextMetric);

    LogFont->lfHeight = (*lpTextMetric)->tmHeight;
    LogFont->lfWidth = (*lpTextMetric)->tmAveCharWidth;
    LogFont->lfEscapement = 0;
    LogFont->lfOrientation = 0;
    LogFont->lfWeight = (*lpTextMetric)->tmWeight;
    LogFont->lfItalic = (*lpTextMetric)->tmItalic;
    LogFont->lfUnderline = lpFontDir->underline;
    LogFont->lfStrikeOut = lpFontDir->strikeout;
    LogFont->lfCharSet = (*lpTextMetric)->tmCharSet;
    LogFont->lfOutPrecision = OUT_CHARACTER_PRECIS;
    LogFont->lfClipPrecision = CLIP_CHARACTER_PRECIS;
    LogFont->lfQuality = PROOF_QUALITY;
    LogFont->lfPitchAndFamily = (*lpTextMetric)->tmPitchAndFamily + 1;
    lstrcpy((LPSTR) LogFont->lfFaceName, (LPSTR) lpFontDir->szFaceName);
    
    return (rc);
}

WORD FAR PASCAL DoEnumFonts(LPPDEVICE lppd, ENUMTYPE etype, 
                                 LPSTR lpszFaceName, 
                                 FARPROC lpCallbackProc, 
                                 LP lpClientData)
{
    LPFONTCACHE     lpCache;
    HPFONTDIRECTORY hpFontDir;  // need to do huge pointer +;
    HPFONTDIRECTORY FAR *hpFontDirs;  // need to do huge pointer +;
    HPDIRINDEX hpDirIndex;  // need to do huge pointer +;
    HPDIRINDEX hpTempDirIndex;  // need to do huge pointer +;
    LPSTR           lpszPrevFace = NULL;
    WORD            rc = 1;
    LPPRINTERINFO   lpPI = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
    int             index = 0;
    WORD wNumDeviceFonts = lpPI->FontList.w.length;
    LPFONTLIST lpFontList = ARRREF_TO_PTR(lppd->lpWPXblock->WPXarrays, lpPI->FontList);
    LPPSEXTDEVMODE lpPSExtDevmode = lppd->lpPSExtDevmode;
    LPSTR lpszFriendlyName = (lpPSExtDevmode->dm).dm.dmDeviceName;
    WORD enumFlag = HIWORD(((LPCALLBACKSTRUCT)lpClientData)->lpClientData);

    
    lpCache = GetFontCache(lpszFriendlyName);
    if (! lpCache || !lpCache->wNumFonts) //no cache or 0 fonts.
    {
        if (lpCache)
           FreeCache(lpCache);
        return rc;
    }

    hpDirIndex = lpCache->hpDirIndex;
    hpFontDirs = lpCache->hpFontDirs;

    /* Enumerate fonts */
    switch (etype) 
    {
        case PS_FONTNAME:
            /* Enumerate all fonts with this family name */

            index = SearchFontIndexDir(lpCache, lpszFaceName, 
                                      lpCache->wNumFonts, FALSE, FONT_NOHINT);

            if (index >= 0  && (WORD)index < (lpCache->wNumFonts))
            {
                while (rc  
                       && (WORD)index < (lpCache->wNumFonts) 
                       && (hpTempDirIndex = hpDirIndex + index)
// assume one fontsdir.mfd
//                     && (hpFontDir = INDEX_TO_DIR(hpTempDirIndex, hpFontDirs) )
                       && (hpFontDir = ((HPFONTDIRECTORY) hpFontDirs[0]) + hpTempDirIndex->wDirRecIndex)
                       && lstrcmpi((LPSTR) hpFontDir->szFaceName, lpszFaceName) == 0) 
                {  
                   if ((hpTempDirIndex->statusFlag & MASK_PS_TT) == PS_FONT  &&     //don't enum TT fonts
                       (hpTempDirIndex->statusFlag & MASK_FONT_VISIBILTY) == ENUM_RLZE_VISIBLE)
                  {
                     rc = lpCallbackProc(hpFontDir, lpClientData);
                  }    
                  index++;
                }
            }
            break;
            
        case PS_FACENAME:
            /*EnumDFont is call w/ lpszFacename null */
            /* Enumerate one font per font family */
            /* no preference for rom fonts over soft fonts*/
            /* do not enumerate alias fonts */

            while (rc && ((WORD)index < lpCache->wNumFonts)) 
            {
               hpTempDirIndex = hpDirIndex + index;
               if ((hpTempDirIndex->statusFlag & MASK_PS_TT) == PS_FONT  && //don't enum TT fonts
                   (
                     (hpTempDirIndex->statusFlag & MASK_FONT_VISIBILTY) == ENUM_RLZE_VISIBLE ||
                     ( enumFlag == 1 &&  // enumeration for substitution table
                       (hpTempDirIndex->statusFlag & MASK_FONT_VISIBILTY) == RLZE_VISIBLE &&
                       (hpTempDirIndex->statusFlag & MASK_FONT_DL) == FONT_ON_DEVICE
                     )
                   )
                  )
                   
               {
// assume one FONTSDIR.MFD
//                     hpFontDir  = INDEX_TO_DIR(hpTempDirIndex, hpFontDirs);
                    hpFontDir = (HPFONTDIRECTORY) hpFontDirs[0] +hpTempDirIndex->wDirRecIndex;
                 if (hpFontDir  &&
                    (lpszPrevFace == NULL ||
                     lstrcmpi((LPSTR) hpFontDir->szFaceName, lpszPrevFace) != 0)) 
                  {
                     rc = lpCallbackProc(hpFontDir, lpClientData);
                     lpszPrevFace = (LPSTR) hpFontDir->szFaceName;
                  }
               }
               index++; 
            }
            break;

            case PS_ALL:
            /* Enumerate all fonts */
            /* irregardless of visiblity */
            while (rc) 
            {
                hpTempDirIndex = hpDirIndex + index;
//Assume 1 FONTSDIR.MFD
       //         hpFontDir = INDEX_TO_DIR(hpTempDirIndex, hpFontDirs);
               hpFontDir = (HPFONTDIRECTORY) hpFontDirs[0] +hpTempDirIndex->wDirRecIndex;
                if ((hpTempDirIndex->statusFlag & MASK_PS_TT) == PS_FONT) //don't enum TT fonts
                  rc = lpCallbackProc(hpFontDir, lpClientData);
                
                if ((WORD)index < (lpCache->wNumFonts - 1))
                    index++;
                 else
                    break;
            }
            break;
    }
    
    FreeCache(lpCache);
    
    return rc;
}


/*****************************************************************************
*                               EnumDFonts
*  function:
*       public entry point which enumerates fonts made available to apps
*       by the driver.
*  prototype:
*       short FAR PASCAL EnumDFonts(LP, LPSTR, FARPROC, LP)
*  parameters:
*       lpDevice:    PDEVICE struct.
*       lpzFaceName: pointer to face name to enumerate.
*                    if the pointer points to a face name, all fonts
*                       of that face are enumerated.
*                    if the pointer is NULL, one font of each face
*                       is enumerated.
*       lpCallbackProc: user supplied callback function.
*       lpClientData:   user supplied data, passed to callback function.
*  returns:
*       last return from callback function or 1 if callback never called.
***************************************************************************/

WORD _loadds FAR PASCAL EnumDFonts(LP lpDevice, LPSTR lpszFaceName, 
                                   FARPROC lpCallbackProc, LP lpClientData)
{
    CALLBACKSTRUCT  cbStruct;
    LPPDEVICE       lppd;
    ENUMTYPE        etype;
    WORD            rc = 1;     /* Default return value. See DDK */

    lppd = (LPPDEVICE)lpDevice;

    etype = lpszFaceName ? PS_FONTNAME : PS_FACENAME;

    rc = EngineEnumerateFont(lpszFaceName, lpCallbackProc, (DWORD)lpClientData);
    if (rc != 0) 
    {
        /* if this call to a memory bitmap? */
        if(lppd->sMagic == 0)
            rc = dmEnumDFonts(lpDevice, lpszFaceName, lpCallbackProc,
                              lpClientData);
        else if (lppd->sMagic==LUCAS) 
        {
#ifdef ENUMERATOR
            /* Call enumerator if present */
            if (IsEnumeratorPresent())
            {
                rc = Enum_EnumerateFonts(
                               lppd->lpPSExtDevmode->dm.dm.dmDeviceName, 
                               lppd->szPortName, ALL_FONTS,
                               lpszFaceName, lpCallbackProc, 
                               lpClientData);
            }
            else 
#endif
            {
                FARPROC lpCBProc = (FARPROC) EnumFontsCallback;

                cbStruct.lpCallbackProc = lpCallbackProc;
                cbStruct.lpClientData = lpClientData;
                cbStruct.lppd = lppd;



#ifdef PANEURO
                if(!(lppd->lpPSExtDevmode->dm.privateFlags & SUPPRESS_DEVICEFNT_ENUM))
#endif
                {
                  rc  = DoEnumFonts(lppd, etype, lpszFaceName, lpCBProc, 
                                          (LP) &cbStruct);
                }
            }
        }
    }
    return(rc);
}


WORD _loadds FAR PASCAL GetDevCharset(LP lpDevice, LPSTR lpszFaceName, 
                               FARPROC lpCallbackProc, LP lpClientData)
{
   CALLBACKSTRUCT  cbStruct;
   LPPDEVICE       lppd = (LPPDEVICE)lpDevice;
   WORD            rc = 1;
   LPFONTCACHE     lpCache;
   HPFONTDIRECTORY hpFontDir;       // need to do huge pointer +;
   HPFONTDIRECTORY FAR *hpFontDirs; // need to do huge pointer +;
   HPDIRINDEX      hpDirIndex;      // need to do huge pointer +;
   HPDIRINDEX      hpTempDirIndex;  // need to do huge pointer +;
   int             index = 0;
   LPSTR           lpszFriendlyName = lppd->lpPSExtDevmode->dm.dm.dmDeviceName;
   
   /* if this call to a memory bitmap? */
   if(lppd->sMagic == 0)
      rc = dmEnumDFonts(lpDevice, lpszFaceName, lpCallbackProc,
                        lpClientData);
   else if (lppd->sMagic==LUCAS) 
   {
      cbStruct.lpCallbackProc = lpCallbackProc;
      cbStruct.lpClientData = lpClientData;
      cbStruct.lppd = lppd;
      
      lpCache = GetFontCache(lpszFriendlyName);
      if (!lpCache || !lpCache->wNumFonts) //no cache or 0 fonts.
      {
         if (lpCache)
            FreeCache(lpCache);
         return rc;
      }

      hpDirIndex = lpCache->hpDirIndex;
      hpFontDirs = lpCache->hpFontDirs;

      /* Enumerate all fonts with this family name */
      index = SearchFontIndexDir(lpCache, lpszFaceName, 
                      lpCache->wNumFonts, FALSE, FONT_NOHINT);

      if (index >= 0  && (WORD)index < (lpCache->wNumFonts))
      {
         while (rc  
                && (WORD)index < (lpCache->wNumFonts) 
                && (hpTempDirIndex = hpDirIndex + index)
                && (hpFontDir = ((HPFONTDIRECTORY) hpFontDirs[0]) + hpTempDirIndex->wDirRecIndex)
                && lstrcmpi((LPSTR) hpFontDir->szFaceName, lpszFaceName) == 0) 
         {  
            if ((hpTempDirIndex->statusFlag & MASK_PS_TT) == PS_FONT  &&     //don't enum TT fonts
                ((hpTempDirIndex->statusFlag & MASK_FONT_VISIBILTY) == RLZE_VISIBLE ||
                 (hpTempDirIndex->statusFlag & MASK_FONT_VISIBILTY) == ENUM_RLZE_VISIBLE
                )
               )
            {
               rc = EnumFontsCallback(hpFontDir, (LP)&cbStruct);
            }    
            index++;
         }
      }
   
      FreeCache(lpCache);
   }
   
   return(rc);
}

#ifdef ENUMERATOR
BOOL FAR PASCAL IsEnumeratorPresent(void)
{
    /* Temporary. To be changed later */
    return FALSE;
}
#endif
   
   