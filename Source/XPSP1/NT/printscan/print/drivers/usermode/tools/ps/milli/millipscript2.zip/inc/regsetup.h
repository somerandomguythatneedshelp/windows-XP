/****************************************************************************\
*                                                                            *
*  REGSETUP.H -                                                              *
*                                                                            *
*  Copyright (c) Adobe Systems, Inc., 1996.  All Rights Reserved.            *
*                                                                            *
*  Author     John Patterson                                                 *
*  Date       01/01/96                                                       *
*  Revision   0.1�1                                                          *
*                                                                            *
\****************************************************************************/

int FAR PASCAL TTExtractPsName (LPLOGFONT lplf, LPSTR pszPostScriptName, HDC hDC);
int FAR PASCAL ExtractString(LPSTR szString, LPSTR szSubString, WORD wIString, WORD cbSize, char cDelimiter);
int FAR PASCAL ExistRegEntry (LPSTR lpSubKey, 
                              LPSTR lpKey);

WORD FAR PASCAL GetTrueTypeFonts(LPFONTFILE lpFontData, 
                                 FONTENUMPROC lpEnumProcEx,  
                                 WORD numFonts);

int CALLBACK EnumTTRoot (const ENUMLOGFONT FAR* elf, 
                      const NEWTEXTMETRIC FAR* ptm, 
                      int nFontType,
                      LPARAM lParam);

int CALLBACK EnumTTFamily (const ENUMLOGFONT FAR* elf, 
                        const NEWTEXTMETRIC FAR* ptm, 
                        int nFontType,
                        LPARAM lParam);

WORD FAR PASCAL GetTTInfo(LPFONTFILE lpFontData, 
                          FONTENUMPROC lpEnumProcEx,
                          LPLOGFONT lplf);

int CALLBACK TTPSName (const ENUMLOGFONT FAR*, 
                       const NEWTEXTMETRIC FAR*, 
                       int, LPARAM);

BOOL FAR PASCAL ExtractXUID (LPLOGFONT, LPSTR, BOOL);
WORD FAR PASCAL CGetMaxNumberOfGlyphs(LPLOGFONT lpLogFont);
int FAR PASCAL IsLocaTblFaulty(LPLOGFONT lpLogFont);
BOOL FAR PASCAL HasRequiredTables(LPLOGFONT lpLogFont);

