/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DMG.H                                                        */
/*                                                                           */
/* Description: This module contains the defines and structure definitions   */
/*              local to the dmg directory                                   */
/*                                                                           */
/*****************************************************************************/

// Number of Dialog pages
#ifdef ADOBE_DRIVER
#define DIALOG_PAGES   6
#else
#define DIALOG_PAGES   5
#endif

// These are the DIALOG_PAGES
// This order has to match the order of the Procs and Templates array defined in 
// the devmode.c.

#define DI_PAPER       0
#define DI_GRAPHICS    1
#define DI_FONTS       2
#define DI_DEVICE      3
#define DI_POSTSCRIPT  4
#ifdef ADOBE_DRIVER
#define DI_WATERMARK   5
#endif

typedef HICON (FAR PASCAL* GETICONRESOURCE)(int);

typedef struct
{
  LPPSEXTDEVMODE lpDM;
  HANDLE hSavedDevmode;
  LPPSEXTDEVMODE lpdmOutput;
  PSEXTDEVMODE   DMScratch;
  PSEXTDEVMODE   DMSave;
  PDEVICE        pDev;
  WORD           wFlags;
  WORD           wMode;
  HANDLE         ghDriverMod;
  HINSTANCE      hInstShell;
  DWORD          dwUIFlags[DIALOG_PAGES];
  int            iDocStickyIndex;
  int            iPrinterStickyIndex;

  /* The following is needed by every dialog box */
  BOOL fHelp;

  BOOL bValidateOptions;
  BOOL bChanged;   // TRUE if DMScratch is changed by the user through UI
  BOOL bPainting;  // If UI painting is in process.

  /* Store the currently selected paper */
  int Paper_opt_index;

  /* For UI constraint handling */
  UICONFLICT uiConflict;
  LPUICARRAY lpUICArray;
  BOOL       bAllowConstraint;
  BOOL       bShowIgnore;
  BOOL       bShowCancel;

  /* Iconmgr dll */
  HINSTANCE   hIconMgr;
  GETICONRESOURCE lpGetIconResource;

  BOOL       bSaveFontAssignments;

#ifdef ADOBE_DRIVER
  BOOL wmChanged;
//  int  wmPrevsel;
#endif

// OEMPLUGI Begin
#ifdef Adobe_Driver
  HANDLE hPSFax;
//#ifdef ADOBE_WEB
  HANDLE hWebPrinter;
//#endif
#endif
  HANDLE hOemCust;
  LPSTR lpszFriendly;
  LPSTR lpszPort;
// OEMPLUGI End

} DRIVERINFOT;

// Flags for wFlags
#define DI_INITIALIZED  0x0001
#define DI_VALIDATED    0x0002
#define DI_SAVED        0x0004
#define DI_EXTDEVMODE   0x0008
#define DI_REGISTERED   0x0010
#define DI_ADVSETUPDLG  0x0020
#define DI_PROPSHEET    0x0040

/* Flags for dwUIFlags */
// DI_PAPER
#define DI_PAPERSIZE       0x00000001
#define DI_PAPERSOURCE     0x00000002
#define DI_MEDIATYPE       0x00000004
#define DI_OUTPUTBIN       0x00000008
#define DI_REVERSEORDER    0x00000010
#define DI_COLLATE         0x00000020
#define DI_ORIENTATION     0x00000040
#define DI_DUPLEX          0x00000080
#define DI_CUSTOM          0x00000100

// DI_DEVICE
#define DI_PRINTERFTRS  0x00000001
#define DI_AVAILVM      0x00000002
#define DI_IOPTIONS     0x00000004
#define DI_AVAILFCACHE  0x00000008

// DI_FONTS
#define DI_DLPSCRIPT    0x00000001
#define DI_DLTT         0x00000002
#define DI_DLFMT        0x00000004
#define DI_FNTSUBS      0x00000008

// DI_GRAPHICS
#define DI_RESLN        0x00000001
#define DI_COLOR        0x00000002
#define DI_SPECIAL         0x00000004
#define DI_SCALE           0x00000008
#define DI_PRINTPAGEBORDER 0x00000010
#define DI_LAYOUT          0x00000020

// DI_POSTSCRIPT
#define DI_OUTFMT       0x00000001
#define DI_HEADER       0x00000002
#define DI_ERRORINFO    0x00000004
#define DI_JOBTOUT      0x00000008
#define DI_WAITTOUT     0x00000010
#define DI_ADVANCED     0x00000020

#ifdef ADOBE_DRIVER
// DI_WATERMARK
#define DI_PSTICKY  0x00000001
#define DI_DSTICKY  0x00000002
#endif

// Indices 
typedef DRIVERINFOT FAR *LPDRIVERINFO;

// This actually lives in devmode.c, but put it here until we straighten
// out the madness of these header files.
void FAR PASCAL UpdateGlobal(LPDRIVERINFO,BOOL);


// Macro to get the notification code from an lParam.
#define NOTIFY_CODE(a) (((LPNMHDR)(a))->code)

