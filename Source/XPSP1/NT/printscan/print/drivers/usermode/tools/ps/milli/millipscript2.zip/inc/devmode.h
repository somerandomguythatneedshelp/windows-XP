/* Prototypes */
#define ADOBE_DRIVER_42 1
#define ADOBEPS42       1
#define ADD_EURO        1

BOOL UsePropertySheet(void);

// ---------------------------- devmode structs ----------------------


/* OEMCUST -John Kwan begin */
#ifndef _INC_DEVMODE
#define _INC_DEVMODE
#endif
/* OEMCUST -John Kwan end */

typedef char BYTEFLAG;


//  All of these enumerations correspond to UI options.

#ifdef ADOBE_DRIVER
typedef  enum {ONE_UP, TWO_UP, FOUR_UP, SIX_UP, NINE_UP, SIXTEEN_UP,
               NUM_LAYOUTS} LAYOUT ;
#else
typedef  enum {ONE_UP, TWO_UP, FOUR_UP, NUM_LAYOUTS} LAYOUT ;
#endif
typedef  enum {OR_PORTRAIT, OR_LANDSCAPE, OR_ROTLANDSCAPE} PAP_ORIENT  ;
typedef  enum {DIA_SPEED, DIA_PORTABLE, DIA_EPS, DIA_ARCHIVE,
               DIA_PJL_ARCHIVE} DIALECT ;
typedef  enum {TTSUBSFORMAT_TABLE , TTSUBSFORMAT_USEPRINTER,
               TTSUBSFORMAT_DOWNLOADTT} FONTSUB ;

typedef  enum {COLOR_8BIT, COLOR_FULL_COLOR} COLOR ;

typedef  enum {ICM_DISABLE, ICM_ALLOW, ICM_ALWAYS} COLOR_ICM;

typedef  enum {COLOR_MATCH_DONT_CARE, COLOR_MATCH_NONE,
           COLOR_MATCHING_ON_HOST, COLOR_MATCHING_ON_PRINTER,
           COLOR_MATCHING_PRINTER_CALIBRATION, COLOR_MATCH_ACROSS_PRINTERS}
           COLOR_METHOD ;

typedef  enum {INTENT_DONT_CARE, INTENT_SATURATION, INTENT_CONTRAST,
               INTENT_COLORMETRIC} RENDERING_INTENT ;

typedef  enum {NO_MARGINS,  DEFAULT_MARGINS } MARGINS ;

typedef  enum {PS_DLFORMAT_OUTLINES = 1, PS_DLFORMAT_BITMAPS,
               PS_DLFORMAT_NATIVE, PS_DLFORMAT_DONT_SEND } PS_DLFMT ;

typedef  enum {TT_DLFORMAT_NONE, TT_DLFORMAT_TYPE1,  TT_DLFORMAT_TYPE3,
               TT_DLFORMAT_TYPE42, TT_DLFORMAT_TRUEIMAGE, TT_DLFORMAT_DONT_SEND} TT_DLFMT ;

typedef  enum {PROTOCOL_ASCII,
              PROTOCOL_BCP, PROTOCOL_TBCP, PROTOCOL_BINARY } PROTOCOLS ;

#define DEF_TTDOWNLOADFORMAT TT_DLFORMAT_TYPE3
#define MIN_TTDOWNLOADFORMAT TT_DLFORMAT_NONE
#define MAX_TTDOWNLOADFORMAT TT_DLFORMAT_TRUEIMAGE

#define RESETDC_PAGE_CONTINUE   1   // After ResetDC continue the same page
#define RESETDC_NEW_PAGE        2   // After ResetDC start the new page

#define SUPPRESS_DEVICEFNT_ENUM 0x0001  // set according to PanEuro UI
                     //   in privateFlags element of Devmode

#define CUSTOMNAMELEN  64
#define NUM_OUTPUT_DIALECTS   3        // PostScript, EPS, Other
#define MODULENAMELEN         10

typedef struct
{
   //  these fields are for custom paper size support.
   //  note all dimensions are in 1/72 th's of an inch
   //  note the defined axis do not necessarily align with public devmode
   //  definition of Width and Length.

   char CustomName[CUSTOMNAMELEN];
   float  customWidth ;     //  fast scan axis of printer
   float  customHeight ;    //  slow scan axis (parallel to paper feed direction)
    RECT   HWmargins;        //  cut-sheet margins
   BOOL  Transverse;        //  is paper x axis perpendicular to fast scan?
   int  widthOffset;        // add extra left margins for crop marks
   int  heightOffset;       // add extra top margins for crop marks
}  CUSTPAPER,  FAR *LPCUSTPAPER;

// first id for custom paper size
#define DMPAPER_CUST DMPAPER_USER+1

// number of user defined custom papersizes saved.
#define  NUM_CUST_SIZES      3
#define  CUST_IDS_RESERVED    NUM_CUST_SIZES+1 // number of custom paper size
                                              // ids reserved, including 3
                                              // custom paper sizes & 1 App defined

#ifdef MICROSOFT_DRIVER_VERSION
#define     MAXPAPERMARGINS  1
#else
#define     MAXPAPERMARGINS  100
#endif
   // size  of dm2.revisedPaperMargins[]  array

#define  MAXOPTIONSTATES  100
// each optionstate adds 4 bytes to PSDEVMODE struct.
// but you need at least  PRINTERINFO.numMainKeyHdrs
// this structure defines the all current options for MainKeywords.



//  kept optionState a fixed size to avoid devmode fluctuations
//  whenever user selects more options, or uses different printers


#ifdef ADOBE_DRIVER
//  Max length of WaterMark Name in 4.1
#define WMNAMELEN 18
#endif
typedef struct
{
   WORD  optionKeyIndex;// index to optionKey struct that is currently selected.
                        // if UI allows PICKMANY, then nextState contains ...

   WORD  nextState  ;  //  Index of next OPTIONSTATE element in array
                       // for this main keyword.  0xFFFF indicates no
                       // more options are selected for this keyword.
}   OPTIONSTATE, FAR *LPOPTIONSTATE ;  // what options are in effect
                                       // for each MainKeyword





typedef struct
{
   DEVMODE dm;

   WORD   check1;       // Checksum of PSDEVMODE
   WORD   check2;       // Checksum of PSEXTDEVMODE
   DWORD  dwTimeStamp,  // obtained from WPX  PRINTINFO structure.
          dwRandom;     // verifies we are dealing with the same printer
                        //  instance.

   // ------------  PAPER  PROPERTY  SHEET  -----------------------

   // Note: Custom paper has been moved below option state array, as it is
   // considered printer sticky for EXCEL.
   DSPUNITS    DspUnits;     // units in which to display papersizes in Dialog box.
   short       Copies;
   BOOL        bOutputOrder;
   PAP_ORIENT  PaperOrient;  // one to one correspondence to UI control
   MARGINS     marginState;  // margin state: default, zero

   //  to determine papersize, source, type, see optionState index.

   // ------------  GRAPHICS  PROPERTY  SHEET  -----------------------
   //
   //  to determine resolution, , see optionState index.

   LAYOUT           layout ;
   COLOR_ICM        useImageColorMatching; /* disable, allow or always */
   COLOR_METHOD     iColorMatchingMethod;  /* Type of color matching to use */
   RENDERING_INTENT iRenderingIntent;      /* Rendering Intent */
   short            iAbsoluteColorimetric; /* 0: intent is Colorimetric */
                                           /* 1: intent is Absolute Colorimetric */
   BOOL  useDefaultHalftoneParams ; // if true driver doesn't attempt to send
                                    // commands to alter halftone parameters
   //  These devmode halftone parameters hold only the user's settings
   //  not the defaults which are kept in the WPX structs on a per
   //  resolution basis.  (stored as tenths of units. ie
   //  an actual ScreenFreq of 60.0  is stored in the DWORD as 600.)

   DWORD ScreenFrequency;  /* halftone screen frequency */
   DWORD ScreenAngle;      /* halftone screen angle */

   BOOL  bNegImage;        /* TRUE if negative images requested */
   BOOL  bMirror;          /* TRUE if output should be mirrored */
   BOOL  bColorToBlack;    /* realize only black brushes and pens */
   // MASK_IMAGE
   BOOL  bL2MaskedImage;   /* TRUE if maksed image requested      */
   BOOL  bL3MaskedImage;
   short Scale;

   // ------------  POSTSCRIPT  PROPERTY  SHEET  -----------------------
   //

   //output flavor stuff
   DIALECT enumDialect ;    //Indicates type of output from Driver,
                            // eg. PostScript or AI3 generate EPS
                            // output is one of several possible modes

   // ------------  DEVICE OPTIONS  PROPERTY  SHEET  -----------------------

   WORD privateFlags ;  // was currentICM[2]

   // ------------- WATERMARKS PRPERTY SHEET -------------------------------

#ifdef ADOBE_DRIVER
  DWORD dwWatermarkID;   // an uniqu watermark id
  int WMFirstPageOnly, WMForeGround, WMOutline;
#endif

#ifdef Adobe_Driver
    // -----------  FAX OPTIONS PROPERTY SHEET  ------------------------
    BOOL    bFAXingD;       // TRUE -> call PSFax during StartDoc.
    char    appModulename[MODULENAMELEN];  // application filter DLL

#endif

   /*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/
   /****!!!! NOTE: DO NOT ADD ANY DOC STICKY FIELDS BELOW THIS. !!!!****/
   /*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/

   // Everything below except the first IND_NUMPREDEFINEDHDRS elements of
   //  the optionstate array are considered printer sticky for EXCEL.

   OPTIONSTATE  optionState[MAXOPTIONSTATES] ;

   //  you can determine if custom paper size is currently selected
   //  by comparing the current PAPERSIZE option using KeywordGetCurrentOption()
   //  to the value of CustomPageSize  in WPXinfo->PRINTERINFO.DEVCAPS
   //  If this is TRUE, then the value of currentCustPaper indicates
   //  which of the NUM_CUST_SIZES custPapers in the array should be selected.

   WORD       currentCustPaper ;  // which of the three sizes is selected?
   CUSTPAPER  custPaper[NUM_CUST_SIZES] ;
   // App defined custom sizes not equal to any of the sizes in  the array
   // above are stored here, and currentCustPaper is set to APP_DEFINED.
   float      appCustWidth ;
   float      appCustHeight ;

   // what options are in effect for each MainKeyword
   // the first n elements in this array always refer to the option
   // associated with mainkeyword n.
   // a subset of these n keywords is the InstallableOptions keywords
   // these will occupy indicies from
   //  PrinterInfo.InstallableOptions to n-1.
   // UI and devmode merging code should be aware of this division
   // so they may avoid changing these options.

   // ---------  The following have been moved to dm2  or deleted ---------

   //   BOOL  fHeader; see dm2.
   //   BOOL  bErrHandler;   seee dm2.
   //   iFreeVM  see dm2.


   //   char  EpsFile[_MAX_PATH];  // 4.0 driver doesn't use this.
   //   BOOL  bPerPage;            // TRUE if per page font downloads requested
   //   BOOL  bDSC;                // TRUE if output should conform to DSC
   //   BOOL  bSubFonts;    // TRUE if TrueType fonts should be substituted
   //   BOOL  bNoDownLoad;  // TRUE if use Device Fonts for TT
   //   BOOL  bFavorTT;     // TRUE if resolve font ambiguities in favor of TT

    // OEMPLUGI begin
  WORD        numOEMDocSticky;  // Number of DWORD reserved in the optionState array
                                // that is used by the OEM to save their DocSticky data.
    // OEMPLUGI end

} PSDEVMODE, *PPSDEVMODE, FAR *LPPSDEVMODE;



// These items should only be modified via ExtDeviceModePropSheet call
// Not advanced dialog setup or extDevMode!  Not via any app !
// these are not job specific settings - should be initialized only
// from win.ini (or driver should supply reasonable defaults).

typedef struct tagPSDEVMODE2
{

  // holds imageable areas for the first 40 papersizes.
  RECT  revisedPaperMargins[MAXPAPERMARGINS] ;

  BOOL  fHeader;          /* TRUE=download header per Job */
  BOOL  bErrHandler;      /* TRUE if we should use error handler */
  float fUserVMSelection; /* User selected amount of VM for VM Option */
  float fUserFCSelection; /* User selected amount of Font cache for corresponding VMOption */


  BYTE  password[MAXKEYLEN];   //  PPD supplied password for exitserver
  BYTE  defaultICM[2] ;  // placeholder

/* ------------  PAPER PROPERTY  SHEET  ----------------- */
   BOOL  bPrintPageBorder;   // if TRUE, print border around n-up pages

/* ------------  TT FONT DOWNLOADING  PROPERTY  SHEET  ----------------- */

   TT_DLFMT iDLFontFmt;       // font DL format (Type 3, Type 1, TrueType)
   PS_DLFMT iPS_DLFontFmt;    // font DL format for PS fonts
   FONTSUB  iTTSubsFmtSource; // Source of TT Subs (DL TT, use printer, etc.)
   WORD     iMinOutlinePPEM;  // crossover point for Type 1 outlines

   BOOL     bFullDown;       // 0- means incremental downloading
   BOOL     bTrueTypeWide;   // 0- means prefer Char-Code
   BOOL     bTrueTypeFast;    // = Convert Glyph-index to Show-order-index=As Fast As U Can
            // !!! bTrueTypeWide==0 or bFullDown==1 implies Fast=0;
            // !!! Fast only applies for Glyph-index based Incremental Downloading.!!

   BOOL     bEUDCAble;   // TRUE == fonts can handle EUDC chars, GDI doesn't give Bitmap

/* ------------ printer sticky fields in Postscript dialog ------------- */

  WORD iJobTimeout;            // The job timeout in seconds
  WORD iWaitTimeout;           // The wait timeout in seconds

/* ------------  ADVANCED  POSTSCRIPT  PROPERTY  SHEET  ----------------- */
#ifndef ADOBE_DRIVER_42
   BYTEFLAG bfUseLevel2 ;     // Flags that level 2 PostScript should be used
#else
   WORD  useLanguageLevel;          // Change the above flag to a WORD so that we support different PS level.
#endif

   //  ---- one of these doesn't have a dedicated UI control ---- !
#ifndef ADOBE_DRIVER_42
   BOOL  bCompress;                // TRUE if we should ALWAYS compress bitmaps
#endif
   PROTOCOLS  iDataOutputFormat;   // Output format (CRTL D or not, BCP, etc.)
   BOOL bSendCtrlDBefore;
   BOOL bSendCtrlDAfter;
   BOOL bIsRotated; // Flag to remember rotated state
   DWORD dwProfile;
#ifdef ADOBE_DRIVER
   BOOL bFax35FontsOnly;    // 35 fonts only flag when faxing
#endif

#ifdef Adobe_Driver
/* ------------  FAX OPTION  PROPERTY  SHEET  ----------------- */
   BOOL bFAXingP;           // Fax or Print checkbox on the Fax option property sheet THuynh  12/02/94
#endif

/* ------------ this space reserved for driver variables --------------- */

  BYTE  bHalftoneModified; //MODIFIED_NONE, MODIFIED_FREQ, MODIFIED_ANGLE, MODIFIED_BOTH

  /* Output dialect variable array */
  BYTE bOutputDialect ;  /* Indicates type of output from Driver,
                          * eg. PostScript or AI3 */
  BOOL bDSC;             /* TRUE if output should conform to DSC */
  BOOL bPJL_Protocol;
  BOOL bVM_Tracking;

  float fMinVM;                 // VMOption Lower bound
  float fMaxVM;                 // VMOption Upper bound

  float fMinFontCache;          // FontCache size Lower bound
  float fMaxFontCache;          // FontCache size Upper bound

  WORD  numSlots;               // number of input slots enum'ed in slotAssign
  BOOL bAllowExitServer;        // Allow exit server or not.
  BOOL bClearVMPerPage;         // TRUE if clear VM each page

  BOOL  bFavorTT;               // breaks name ties in favor of TT.

  // OEMPLUGI begin
#ifdef Adobe_Driver
// ????? BOOL          bOemPJLSupport; // This flag overides the devcaps.PJLsupport flag. ?????
  BOOL          bFaxExist;      // TRUE => call FAX DLL.

//#ifdef ADOBE_WEB
  BOOL   bWebPrinter;   // TRUE -> is a Web Printer
//#endif
  // PS3I
  BOOL   bPS3IPrinter;  // TRUE -> is a PS3I printer
#endif


  TTRAST_OPT    TTRasterizer;   // TT font rasterizer type.

/* ------------  FONT PROPERTY SHEET / FONT SUBSTITUTION DIALOG --------- */

  HGLOBAL    hPSFamilies;       // list of all postscript fonts available
  HGLOBAL    hTTFamilies;       // list of all true type fonts avaialble
  HGLOBAL    hTTAssignment;     // mappings from truetype to postscript
  int        iNumPSFamilies;    // number of postscript fonts
  int        iNumTTFamilies;    // number of true type fonts.
  HDC        hDCPrinter;        // used by the substitution dialog only
                                // kept open as an speed optimization for
                                // the EnumFontFamily calls that are made
  COLOR      iColorOption;      // type of color conversion used, DIC, etc.
                                // This is a printer sticky feature.
  // OEMPLUGI end

  BOOL  bAddEuro;               // Add Euro to PS Fonts?

}PSDEVMODE2, *PPSDEVMODE2, FAR *LPPSDEVMODE2;

#define DEVMODE_FILL_LENGTH 15328

typedef struct tagPSEXTDEVMODE
{
  PSDEVMODE  dm;
  PSDEVMODE2 dm2;
  BYTE       FillBytes[DEVMODE_FILL_LENGTH];
}PSEXTDEVMODE, *PPSEXTDEVMODE, FAR *LPPSEXTDEVMODE;

typedef struct tagPSEXTDEVMODENONFILL
{
  PSDEVMODE  dm;
  PSDEVMODE2 dm2;
}PSEXTDEVMODENONFILL, *PPSEXTDEVMODENONFILL, FAR *LPPSEXTDEVMODENONFILL;

// we will read/save the entire PSEXTDEVMODE into a file/registry.
// apps however should only be given a PSDEVMODE struct, since
// they are not allowed to modify or determine the PSDEVMODE2 struct.

