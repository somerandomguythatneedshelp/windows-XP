/* CM_VerSion framepixel.h atm04 1.4 07348.eco sum= 28005 */
/*
  framepixel.h

Copyright (c) 1988-91 Adobe Systems Incorporated.
All rights reserved.

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript is a registered trademark of Adobe Systems Incorporated.
Display PostScript is a trademark of Adobe Systems Incorporated.

Original version: Paul Rovner: Wed Apr 17 10:17:33 PDT 1991
Edit History:
Paul Rovner: Tue Aug 13 16:38:23 PDT 1991
End Edit History.

Revision History
  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/FRAMEPIX.H_V  $
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:07:16   unknown
 *- |Initial revision.
  Revision 6.3  91/11/13  11:17:22  rublee
  Added definitions of SWAPnnnn constants and DEVICE_CONSISTENT.
  
  Revision 6.2  91/10/07  18:22:37  rublee
   
  
  Revision 6.1  91/09/24  16:36:12  rublee
  Removed definitions of SWAPUNIT.
  
End Revision History.

*/

#ifndef FRAMEPIXEL_H
#define FRAMEPIXEL_H

#include PUBLICTYPES
#include ENVIRONMENT

/* DEVICE_CONSISTENT specifies the bit order used in character bitmaps
   produced by BCCharBitMap. If DEVICE_CONSISTENT == 1 the bits are in
   the native order of the ISP. If DEVICE_CONSISTENT == 0 the bits
   are in the reverse order of the bits of the ISP.
 */
#ifndef DEVICE_CONSISTENT
#define	DEVICE_CONSISTENT 1  /* Default: bitmap bits in native ISP order.*/
#endif  /* DEVICE_CONSISTENT */

#ifndef SCANUNIT
#define SCANUNIT 32
#endif

#if (SCANUNIT!=8) && (SCANUNIT!=16) && (SCANUNIT!=32)
#define SCANUNIT 32
#endif /* (SCANUNIT!=8) && (SCANUNIT!=16) && (SCANUNIT!=32) */

#if SCANUNIT==8
#define SCANSHIFT 3
#define SCANMASK 07
#define SCANTYPE Card8
#define LASTSCANVAL 0xFF
#endif /* SCANUNIT==8 */

#if SCANUNIT==16
#define SCANSHIFT 4
#define SCANMASK 017
#define SCANTYPE Card16
#define LASTSCANVAL 0xFFFF
#endif /* SCANUNIT==16 */

#if SCANUNIT==32
#define SCANSHIFT 5
#define SCANMASK 037
#define LASTSCANVAL 0xFFFFFFFF
#define SCANTYPE Card32
#endif /* SCANUNIT==32 */

typedef SCANTYPE *PSCANTYPE;

/* SWAPUNIT Definitions.  Swapunit is the unit that bits should
   be swapped when written to a mask
 */
#ifndef SWAPUNIT  
/* Default to SCANUNIT values */

#define SWAPUNIT SCANUNIT
#define SWAPSHIFT SCANSHIFT
#define SWAPMASK SCANMASK
#define SWAPTYPE SCANTYPE
#define LASTSWAPVAL LASTSCANVAL
#define PSWAPTYPE PSCANTYPE

#else /* SWAPUNIT */
#if (SWAPUNIT > SCANUNIT)
/* SWAPUNIT must be less than or equal to SCANUNIT */

#define SWAPUNIT SCANUNIT
#define SWAPSHIFT SCANSHIFT
#define SWAPMASK SCANMASK
#define SWAPTYPE SCANTYPE
#define LASTSWAPVAL LASTSCANVAL
#define PSWAPTYPE PSCANTYPE
#endif /* (SWAPUNIT > SCANUNIT) */

#if (SWAPUNIT!=8) && (SWAPUNIT!=16) && (SWAPUNIT!=32)
#define SWAPUNIT 32
#endif /* (SWAPUNIT!=8) && (SWAPUNIT!=16) && (SWAPUNIT!=32) */

#if SWAPUNIT==8
#define SWAPSHIFT 3
#define SWAPMASK 07
#define SWAPTYPE Card8
#define LASTSWAPVAL 0xFF
#endif /* SWAPUNIT==8 */

#if SWAPUNIT==16
#define SWAPSHIFT 4
#define SWAPMASK 017
#define SWAPTYPE Card16
#define LASTSWAPVAL 0xFFFF
#endif /* SWAPUNIT==16 */

#if SWAPUNIT==32
#define SWAPSHIFT 5
#define SWAPMASK 037
#define LASTSWAPVAL 0xFFFFFFFF
#define SWAPTYPE Card32
#endif /* SWAPUNIT==32 */

typedef SWAPTYPE *PSWAPTYPE;

#endif /* SWAPUNIT */

#if (SWAPBITS == DEVICE_CONSISTENT)
#define LSHIFT >>
#define RSHIFT <<
#define LSHIFTEQ >>=
#define RSHIFTEQ <<=
#else   /*  (SWAPBITS == DEVICE_CONSISTENT)  */
#define LSHIFT <<
#define RSHIFT >>
#define LSHIFTEQ <<=
#define RSHIFTEQ >>=
#endif  /*  (SWAPBITS == DEVICE_CONSISTENT)  */

/* Bit Array Stuff: defined in bitarray.c */

extern readonly SWAPTYPE leftBitArray[SWAPUNIT];
  /* For i in [0, SCANUNIT), i'th element is a mask consisting of i zero
     bits followed by SCANUNIT-i one bits (in device order).
   */
extern readonly SWAPTYPE rightBitArray[SWAPUNIT];
  /* For i in [0, SCANUNIT), i'th element is a mask consisting of i one
     bits followed by SCANUNIT-i zero bits (in device order).
   */


#endif /* FRAMEPIXEL_H */
