#ifndef _CUTILS_H
#define _CUTILS_H 1

#define BUF_SIZE    1024
#define ELEMENT(lpData, i, size)   (LPVOID) ((LPBYTE) lpData + (i * size))
// To handle Huge pointers. Fix bug 283
#define HUGEELEMENT(hpData, i, size)   (LPVOID) ((HPBYTE) (hpData) + ((LONG)(i) * (LONG)(size)))

char buffer[BUF_SIZE];

/* FAR functions */
VOID FAR PASCAL CInitPen(LPPDEVICE);
VOID FAR PASCAL CInitBrush(LPPDEVICE);
VOID FAR PASCAL FlopRect(LPPDEVICE, LPRECT, LPRECT);
VOID FAR PASCAL NormalizeRect(LPRECT,LPRECT);
void FAR PASCAL TransformCoord(LPRECT,LPRECT,LPRECT,LPRECT);
void FAR PASCAL DeviceToDefaultPS(LPPDEVICE, LPPOINT);
int FAR PASCAL lstrcmpn(LPSTR, LPSTR, WORD);
LPSTR FAR PASCAL lstrchr(LPSTR, int);
LPSTR FAR PASCAL lstrrchr(LPSTR, int);
void NEAR PASCAL Exchange(LPVOID, int, int, WORD);
void FAR PASCAL Qsort(LPVOID, int, int, WORD, 
                      int (FAR PASCAL *) (LPVOID, LPVOID));
int FAR PASCAL BSearch(LPVOID, int, int, WORD, 
                       int (FAR PASCAL * ) (LPVOID, LPVOID), LPVOID);
int FAR PASCAL SubsCompare(LPVOID, LPVOID);
PSERROR FAR PASCAL CreateFontSubsTable(LPPDEVICE);
FLAG FAR PASCAL CDoPen(LPPDEVICE,LPPPEN,LPDRAWMODE);
FLAG FAR PASCAL CDoBrush(LPPDEVICE,LPPBRUSH,LPDRAWMODE);
// Huge versions: fix bug 283. 6-12-1995:
void FAR PASCAL HugeExchange(HPVOID, int, int, WORD);
void FAR PASCAL HugeQsort(HPVOID, int, int, WORD, 
                      int (FAR PASCAL *) (LPVOID, LPVOID));
BOOL FAR PASCAL HugeIsort(HPVOID, int , WORD, 
            		      int (FAR PASCAL *Compare)(LPVOID, LPVOID));

BOOL FAR PASCAL HugeIsortByIndex(HPVOID lpData, int N, WORD wSize, 
		      int (FAR PASCAL *Compare)(LPVOID, LPVOID, HPVOID), HPVOID hpFontDirs);

/* Other FAR utility functions, not found in cutils.c */
int  FAR PASCAL RoundUp (float)                                  ;
void FAR PASCAL ClipBox(LPPDEVICE, LPRECT);
int FAR PASCAL Scale(int, int, int);    
LPSTR FAR PASCAL GetByteAddress(LPBITMAP lpDevBitmap, WORD wX, WORD wY);

void FAR PASCAL MemCopy(LPVOID, LPVOID, DWORD);        /* _fmemcpy */
void FAR PASCAL MemSet(LPVOID, int, DWORD);            /* _fmemset */
BOOL FAR PASCAL MemComp(LPVOID, LPVOID, DWORD);        /* _fmemcmp */

int FAR PASCAL PSSendColorSpace(LPPDEVICE lppd, LPLOGCOLORSPACE lpCS,
                        CSPACESET csCS) ;
void FAR PASCAL PSSelectCRD(LPPDEVICE lppd, LPICMINFO lpICM,
                                    DWORD   cCRD);

void FAR PASCAL PSSendAndSelectCRD(LPPDEVICE lppd, LPICMINFO lpICM,
                                    DWORD   cCRD, WORD bColorMode);

void FAR PASCAL HugeQsortByIndex(HPVOID, int, int, WORD, 
                      int (FAR PASCAL *) (LPVOID, LPVOID, HPVOID), HPVOID);
LPFONTDIRECTORY FAR PASCAL SearchFontDir(LPFONTDIRECTORY, LPSTR, WORD, 
                                         BOOL, WORD, BOOL, BYTE);

short int FAR PASCAL SearchFontIndexDir(LPFONTCACHE,
                                         LPSTR, WORD, 
                                         BOOL, WORD);
WORD FAR PASCAL CompositeString(HINSTANCE hInst, UINT uiRsc1, 
            UINT uiRsc2, UINT uiRsc3, LPSTR lpszBuff, int iBufSize);

BOOL FAR PASCAL IsCharSetSupported(BYTE dfCharSet);

//ALWAYS_ICM
BOOL  FAR   IsWin40();

#endif /* ifndef _CUTILS_H */
