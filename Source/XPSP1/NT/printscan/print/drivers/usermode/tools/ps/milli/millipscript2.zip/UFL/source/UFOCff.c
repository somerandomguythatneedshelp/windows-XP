/*
 *    Adobe Universal Font Library
 *
 *    Copyright (c) 1996 Adobe Systems Inc.
 *    All Rights Reserved
 *
 *    UFOCFF.c - Compress Font Format Object
 *
 ******************************************************************************
 *
 * Note about SUBSET_PREFIX and more comment for VRT2_FEATURE_DISABLED
 *
 * When we donwload a font, its /FontName or /CIDFontName can be any name we
 * want. If the name folows the following format:
 *     SUBSET_PREFIX+RealFontName
 * where SUBSET_PREFIX is a string consited of six characters, each of them is
 * either 'a' ~ 'p' or 'A' ~ 'P', then Distiller4 takes RealFontName part as
 * the font's real name. e.g. abcdef+Helvetica -> Distiller4 realizes that this
 * this font's real font name is Helvetica.
 * We, Adobe Windows Driver Group, decided to go for it (bug #291934). At the
 * same time, we also deciced to remve the code for 'vrt2' feature incapable
 * CJK OpenType font, that is, remove #ifdef/#endif with VRT2_FEATURE_DISABLED
 * because virtually any CJK OpenType fonts are supposed to have 'vrt2'
 * feature. Otherwise vertical version of such CJK OpenType font can't be
 * supported (by ATM or CoolType). Thus, there will be no #ifdef/#endif section
 * with VRT2_FEATURE_DISABLED keyword in this code and the sentence "But, just
 * in case, ....at compile time." in the following note is now obsolite.
 * You can retrieve the removed code from the version 16 or below of this file
 * in SourceSafe if you want.
 *
 * --- This note is now obsolete. ---------------------------------------------
 *
 * Note about 'vrt2' feature and VRT2_FEATURE_DISABLED
 *
 * OTF-based fonts will only have their "@" capability enabled if they have a
 * 'vrt2' feature in their 'GSUB' table; otherwise only horizontal typographic
 * rendering is enabled. When the 'vrt2' feature exists in a font, the font
 * vendor claims that all of the glyphs for the @ variant of the font should be
 * rotated before display / print. Thus, on neither NT4 nor W2K, the PostScript
 * driver doesn't even have to call GlyhAttrs to find out which @ glyphs are
 * rotated; they all are. But, just in case, the logic for rotating @ glyphs is
 * also provided and it will be enabled when VRT2_FEATURE_DISABLED flag is set
 * at compile time.
 *-----------------------------------------------------------------------------
 *
 * $Header:
 */

#include "UFOCff.h"
#include "UFLMem.h"
#include "UFLErr.h"
#include "UFLPriv.h"
#include "UFLVm.h"
#include "UFLStd.h"
#include "UFLMath.h"
#include "UFLPS.h"
#include "ParseTT.h"
#include "UFOt42.h"

#ifdef UNIX
#include <sys/varargs.h>
#include <assert.h>
#else
        #ifdef MAC_ENV
        #include <assert.h>
        #endif
        #include <stdarg.h>
#endif

static unsigned char *pSubrNames[4] =
{
    /* MWCWP1 doesn't like the implicit cast from char* to unsigned char*  --jfu */
    (unsigned char*) "F0Subr",
    (unsigned char*) "F1Subr",
    (unsigned char*) "F2Subr",
    (unsigned char*) "HSSubr"
};

#define  VER_WO_OTHERSUBRS      51


/***********************************
        Callback Functions
 ***********************************/

static unsigned long int
AllocateMem(
    void PTR_PREFIX *PTR_PREFIX *hndl,
    unsigned long int           size,
    void PTR_PREFIX             *clientHook
    )
{
    UFOStruct    *pUFO = (UFOStruct *)clientHook;

    if ((size == 0) && (*hndl == nil))
       return 1;

    if (size == 0)
    {
        UFLDeletePtr( pUFO->pMem, *hndl );
       *hndl = nil;
        return 1;
    } /* end if */

    if (*hndl == nil)
    {
        *hndl = UFLNewPtr( pUFO->pMem, size );
        return (unsigned long int)(ULONG_PTR)*hndl;
    } /* end if */
    else
    {
        return (unsigned long int)UFLEnlargePtr( pUFO->pMem, (void **) hndl, size, 1 );
    } /* end else */

    return 1;
} /* end AllocateMem() */


/* We do not support seeking for this function */
static int
PutBytesAtPos(
    unsigned char PTR_PREFIX *pData,
    long int                 position,
    unsigned short int       length,
    void PTR_PREFIX          *clientHook
    )
{
    if (position >= 0)
    {
        return 0;
    }

    if (length > 0)
    {
        UFOStruct *pUFO = (UFOStruct *)clientHook;

        /* MWCWP1 doesn't like the implicit cast from unsigned char* to const char*  --jfu */
        if ( kNoErr == StrmPutBytes ( pUFO->pUFL->hOut,
                                        (const char*) pData,
                                        (UFLsize_t)length,
                                        (const UFLBool)StrmCanOutputBinary(pUFO->pUFL->hOut) ) )
        {
            return 0;
        }
    }

    return 1;
}


static int
GetBytesFromPos(
    unsigned char PTR_PREFIX * PTR_PREFIX *ppData,
    long int           position,
    unsigned short int length,
    void PTR_PREFIX    *clientHook
    )
{
    UFOStruct     *pUFO;
    CFFFontStruct *pFont;
    int           retVal = 0;  /* Set retVal to failure */

    pUFO = (UFOStruct *)clientHook;
    pFont = (CFFFontStruct *) pUFO->pAFont->hFont;

    // Check to see if the client passes us a whole cff table.
    if ( nil == pFont->info.ppFontData )
    {
        if ( 0 == pFont->cbBuf )
        {
            pFont->pBuf = nil;
            pFont->pBuf = (unsigned char *)UFLNewPtr( pUFO->pMem, length );
        }
        else if ( length < pFont->cbBuf )
        {
            UFLEnlargePtr( pUFO->pMem, (void **) &pFont->pBuf, length, 0 );
            pFont->cbBuf = length;
        }
        /* Fall back to read from callback function */
        retVal = (int) GETTTFONTDATA( pUFO,
                                        (*(unsigned long*)"CFF "),
                                        position,
                                        pFont->pBuf,
                                        length,
                                        pFont->info.fData.fontIndex);  /* size of the table */
        *ppData = pFont->pBuf;
    }
    else
    {
        /* Get the data from the table ourself */
        if ((unsigned long int)(position + length) <= pFont->info.fontLength)
        {
            *ppData = (unsigned char *) *pFont->info.ppFontData + position;
            retVal = 1;
        }
    }

    return retVal;
}


/***********************************
        Private Functions
 ***********************************/

static short
FindFont(
    CFFFontStruct *pFont,
    char          *fontName
    )
{
#ifndef UFLWIN16
    short int          fontIndex = -1;
    unsigned short int i;
    unsigned int       fontCount;
    char               szName[256];

    if ( XCF_FontCount( pFont->hFont, &fontCount) == XCF_Ok )
    {
        for ( i = 0; i < fontCount; i++ )
        {
            if ( XCF_FontName( pFont->hFont, i, szName, sizeof(szName) ) == XCF_Ok )
            {
                if ( !UFLstrcmp( fontName, szName ) )
                {
                    fontIndex = (short int)i;
                    break;
                }
            }
            else break;
        }
    }

    return fontIndex;
#endif
   return 0;
}


static void *SetMemory( void *dest, int c, unsigned short int count )
{
    return UFLmemsetShort(dest, c, (size_t) count);
}


static unsigned short int StringLength( const char PTR_PREFIX *string )
{
    return (unsigned short int) UFLstrlen(string);
}


#ifndef UFLWIN16
static void
MemCpy(
     void PTR_PREFIX        *dest,
     const void PTR_PREFIX  *src,
     unsigned short int     count
     )
{
    memcpy( dest, (void*)src, (size_t)count );
}
#endif


static int
AsciiToInt(
    const char* string
    )
{
    return atoi(string);
}


static long
StringToLong(
    const char  *nptr,
    char        **endptr,
    int         base
    )
{
    return UFLstrtol(nptr, endptr, base);
}


static int StrCmp( const char PTR_PREFIX *string1, const char PTR_PREFIX *string2 )
{
    return UFLstrcmp( string1, string2 );
}


static int
GetCharName(
    XFhandle           handle,
    void               *client,
    XCFGlyphID         glyphID,
    char PTR_PREFIX    *charName,
    unsigned short int length
    )
{
#ifndef UFLWIN16
    unsigned short int i;
    if ( client )
    {
        //UFLsprintf( (char*)client, "%s", charName );

        //
        // Copy the charname by ourself because the name string returned from
        // XCF is not NULL terminated.
        //
        for (i = 0; i < length; i++)
            *((char *)client)++ = *charName++;

        *((char *)client) = '\0';
        return XCF_Ok;
    }
    else
        return XCF_InternalError;
#endif
    return 0;
}


static int
GIDToCID(
    XFhandle           handle,
    void PTR_PREFIX    *client,
    XCFGlyphID         glyphID,
    unsigned short int cid
    )
{
#ifndef UFLWIN16
    if ( client )
    {
        unsigned short int *pCid = (unsigned short int *)client;
        *pCid =  cid;
        return XCF_Ok;
    }
    else
        return XCF_InternalError;
#endif
    return 0;
}


static void
getFSType(
    XFhandle        h,
    long PTR_PREFIX *pfsType,
    void PTR_PREFIX *clientHook
    )
{
    UFOStruct* pUFO;
    long       fsType;

    if (!pfsType)
        return;
    else
        *pfsType = -1; // "Don't put FSType" by default.

    if (!(pUFO = (UFOStruct*)clientHook))
        return;

    if((fsType = GetOS2FSType(pUFO)) >= 0)
        *pfsType = fsType;
}

int
printfError(
    const char *format, ...
    )
{
    va_list arglist;
    int     retval;
    char    buf[512];

    va_start(arglist, format);
    retval = UFLsprintf(buf, format, arglist);
    va_end(arglist);
    return retval;

}


enum XCF_Result
InitFont(
    UFOStruct *pUFO
    )
{
#ifndef UFLWIN16
    CFFFontStruct *pFont;
    char szBuf[256];

    XCF_CallbackStruct callbacks = {0};
    XCF_ClientOptions  options   = {0};

    pFont = (CFFFontStruct *) pUFO->pAFont->hFont;

    /* Stream output functions */
    callbacks.putBytes     = PutBytesAtPos;
    callbacks.putBytesHook = (void *)pUFO;

    /* We don't support outputPos */

    callbacks.getBytes     = GetBytesFromPos;
    callbacks.getBytesHook = (void *)pUFO;
    callbacks.pFont        = 0;
    callbacks.fontLength   = 0;

    callbacks.allocate     = AllocateMem;
    callbacks.allocateHook = (void *)pUFO;

    /* C Standard library functions */
    callbacks.strlen      = (XCF_strlen)StringLength; //strlen;
    callbacks.memcpy      = (XCF_memcpy)MemCpy;
    callbacks.memset      = (XCF_memset)SetMemory; //memset;
    callbacks.sprintf     = (XCF_sprintf)UFLsprintf;
    callbacks.printfError = (XCF_printfError) printfError;
    callbacks.atoi        = (XCF_atoi)AsciiToInt;
    callbacks.strtol      = (XCF_strtol)StringToLong;

    /* We don't support callbacks.atof = (XCF_atof)atof; */
    callbacks.strcmp        = (XCF_strcmp)StrCmp;
    callbacks.gidToCharName = (XCF_GIDToCharName)GetCharName;
    callbacks.gidToCID      = (XCF_GIDToCID)GIDToCID;
    callbacks.getFSType     = (XCF_GetFSType)getFSType;
    callbacks.getFSTypeHook = (void *)pUFO;

    options.fontIndex         = 0;                            /* font index w/i a CFF font set */
    options.uniqueIDMethod    = pFont->info.uniqueIDMethod;   /* UniqueID method */
    options.subrFlatten       = ( pFont->info.subrFlatten == kFlattenSubrs ) ? XCF_FLATTEN_SUBRS : XCF_KEEP_SUBRS; /* Flatten subrs */
    options.eexecEncryption   = ( pUFO->pUFL->outDev.lPSLevel > kPSLevel1  ) ? 0 : 1;
    options.lenIV             = ( pUFO->pUFL->outDev.lPSLevel > kPSLevel1  ) ? (unsigned int)-1 : 4;
    options.hexEncoding       = StrmCanOutputBinary( pUFO->pUFL->hOut ) ? 0 : 1;
    options.maxBlockSize      = pFont->info.maxBlockSize;
    options.outputCharstrType = 1;
    // options.outputCharstrType = ( pUFO->pUFL->outDev.lPSLevel > kPSLevel2 ) ? 2 : 1;

    options.uniqueID = pFont->info.uniqueID;

    if (pFont->info.usePSName)
        options.dlOptions.notdefEncoding = 1;
    else
        options.dlOptions.notdefEncoding = 0;

    options.dlOptions.useSpecialEncoding = (pFont->info.useSpecialEncoding) ? 1 : 0;
    options.dlOptions.encodeName         = (unsigned char*)pUFO->pszEncodeName;

    if (pFont->info.escDownloadFace)
        options.dlOptions.fontName = (unsigned char*)pUFO->pszFontName;
    else
    {
        if (pFont->info.type1)
        {
            if (pFont->info.subfontNumber < 0x100)
                CREATE_ADCFXX_FONTNAME(UFLsprintf, szBuf, pFont->info.subfontNumber, pFont->info.baseName);
            else
                CREATE_ADXXXX_FONTNAME(UFLsprintf, szBuf, pFont->info.subfontNumber, pFont->info.baseName);
        }
        else
        {
            UFLsprintf(szBuf, "%s%s",
                        pFont->info.vertical ? PREFIX_V : PREFIX_H,
                        pFont->info.baseName);
            strcpy(pFont->info.cidFontName, szBuf);
        }

        options.dlOptions.fontName = (unsigned char*)szBuf;
    }

    options.dlOptions.otherSubrNames =
        (pUFO->pUFL->outDev.lPSVersion >= VER_WO_OTHERSUBRS)
            ? 0 : (unsigned char PTR_PREFIX * PTR_PREFIX *) pSubrNames;

    return XCF_Init( &pFont->hFont, &callbacks, &options );
#endif
 return 0;
}


/***********************************
        Public Functions
 ***********************************/

void
CFFFontCleanUp(
    UFOStruct      *pUFObj
    )
{
#ifndef UFLWIN16
    CFFFontStruct *pFont;

    if (pUFObj->pAFont == nil)
        return;

    pFont = (CFFFontStruct *) pUFObj->pAFont->hFont;

    if ( pFont )
    {
        if ( pFont->hFont )
        {
            XCF_CleanUp( &pFont->hFont );
        }

        if (pFont->cbBuf)
            UFLDeletePtr( pUFObj->pMem, pFont->pBuf );

    }
#endif
}

UFLErrCode
CFFUpdateEncodingVector1(
    UFOStruct           *pUFO,
    const UFLGlyphsInfo *pGlyphs,
    const short         cGlyphs,
    const UFLGlyphID    *pGlyphIndices
    )
{
#ifndef UFLWIN16
    char            *pHintName;
    char            *pGoodName;
    UFLHANDLE       stream;
    char            buf[256];
    UFLErrCode      retCode = kNoErr;
    short           i;
    CFFFontStruct *pFont;

    pFont = (CFFFontStruct *) pUFO->pAFont->hFont;

    if ( 0 == cGlyphs ) // Nothing to do ?
        return kNoErr;

    if ( 0 == pFont || 0 == pGlyphIndices )
        return kErrInvalidParam;


    stream = pUFO->pUFL->hOut;

    /* /FontName findfont /Encoding get */
    UFLsprintf( (char*)buf, "/%s findfont /Encoding get", pUFO->pszFontName );
    retCode = StrmPutStringEOL( stream, (const char*)buf );

    for (i = 0; retCode == kNoErr && i < cGlyphs && *pGlyphIndices; i++, pGlyphIndices++)
    {
        // if ( !IS_GLYPH_SENT( pUFO->pAFont->pDownloadedGlyphs, *pGlyphIndices) )
        {
            UFLsprintf(buf, "dup %d /", i);

            retCode = StrmPutString( stream, buf );
            if (retCode == kNoErr)
            {
                XCF_GlyphIDsToCharNames( pFont->hFont,
                                         1,
                                         (XCFGlyphID PTR_PREFIX *)pGlyphIndices, /* list of glyphIDs */
                                         buf );
                retCode = StrmPutString( stream, buf );
            }
            if (retCode == kNoErr)
                retCode = StrmPutStringEOL( stream, " put");

            // if ( kNoErr == retCode )
            //    SET_GLYPH_SENT_STATUS( pUFO->pAFont->pDownloadedGlyphs, *pGlyphIndices );
        }
    }
    StrmPutStringEOL(stream, "pop");

    return retCode;
#endif
  return 0;
}


UFLErrCode
CFFUpdateEncodingVector(
    UFOStruct            *pUFO,
    const short          cGlyphs,
    const UFLGlyphID     *pGlyphIndices,
    const unsigned short *pGlyphNameIndex
    )
{
#ifndef UFLWIN16
    UFLHANDLE       stream;
    char            buf[256];
    UFLErrCode      retCode = kNoErr;
    short           i;
    CFFFontStruct   *pFont;

    pFont = (CFFFontStruct *) pUFO->pAFont->hFont;

    if ( 0 == cGlyphs ) // Nothing to do ?
        return kNoErr;

    if ( 0 == pFont || 0 == pGlyphNameIndex || 0 == pGlyphIndices )
        return kErrInvalidParam;

    stream = pUFO->pUFL->hOut;

    /* /FontName findfont /Encoding get */
    UFLsprintf( (char*)buf, "/%s findfont /Encoding get", pUFO->pszFontName );
    retCode = StrmPutStringEOL( stream, (const char*)buf );

    for (i = 0; retCode == kNoErr && i < cGlyphs; i++, pGlyphNameIndex++, pGlyphIndices++)
    {
        if (*pGlyphNameIndex > 0 && *pGlyphNameIndex <= 255)
        {
            if ( !IS_GLYPH_SENT( pUFO->pUpdatedEncoding, *pGlyphNameIndex ) )
            {
                /* dup index /Charactername put */
                UFLsprintf( buf, "dup %d /", *pGlyphNameIndex);
                retCode =  StrmPutString( stream, (const char*)buf );
                if ( kNoErr == retCode )
                {
                    if ( XCF_GlyphIDsToCharNames( pFont->hFont,
                                                    1,
                                                    (XCFGlyphID PTR_PREFIX *)pGlyphIndices, /* list of glyphIDs */
                                                    buf
                                                ) == XCF_Ok )
                        retCode = StrmPutString( stream, (const char*)buf );
                    else
                        retCode = kErrUnknown;
                }
                if ( kNoErr == retCode )
                    retCode = StrmPutStringEOL( stream, " put" );

                if ( kNoErr == retCode )
                    SET_GLYPH_SENT_STATUS( pUFO->pUpdatedEncoding, *pGlyphNameIndex );
            }
        }
    }
    StrmPutStringEOL(stream, "pop");

    return retCode;
#endif
  return 0;
}


UFLErrCode
CFFSendCMapWinCharSetFFFF_V(
    UFOStruct*      pUFO,
    CFFFontStruct* pFont
    )
{
    char       tmpStr[256];
    UFLErrCode retCode = kErrUnknown;
    UFLHANDLE  stream  = pUFO->pUFL->hOut;

    retCode = StrmPutStringEOL(stream, "CMAP-WinCharSetFFFF-V");
    if (retCode != kNoErr) return retCode;

    retCode = StrmPutStringEOL(stream,
        "/CIDInit /ProcSet findresource begin 12 dict begin begincmap /WinCharSetFFFF-V usecmap");
    if (retCode != kNoErr) return retCode;

    // CIDSystemInfo
    {
        retCode = StrmPutStringEOL(stream, "/CIDSystemInfo [3 dict dup begin");
        if (retCode != kNoErr) return retCode;

        retCode = StrmPutStringEOL(stream, "/Registry (Adobe) def");
        if (retCode != kNoErr) return retCode;

        UFLsprintf(tmpStr, "/Ordering (WinCharSetFFFF-V%s) def", pFont->info.baseName);
        retCode = StrmPutStringEOL(stream, tmpStr);
        if (retCode != kNoErr) return retCode;

        retCode = StrmPutStringEOL(stream, "/Supplement 0 def");
        if (retCode != kNoErr) return retCode;

        retCode = StrmPutStringEOL(stream, "end dup] def");
        if (retCode != kNoErr) return retCode;
    }

    UFLsprintf(tmpStr,
        "/CMapName /WinCharSetFFFF-V%s def /CMapVersion 1 def /CMapType 1 def /WMode 1 def",
        pFont->info.baseName);
    retCode = StrmPutStringEOL(stream, tmpStr);
    if (retCode != kNoErr) return retCode;

    retCode = StrmPutStringEOL(stream, "endcmap CMapName currentdict /CMap defineresource pop end end");

    return retCode;
}


UFLErrCode
CFFFontDownloadIncr(
    UFOStruct           *pUFO,
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMUsage,
    unsigned long       *pFCUsage
    )
{
    enum XCF_Result status = XCF_Ok;
    CFFFontStruct   *pFont;
    UFLErrCode      retCode;

    if ( pFCUsage )
        *pFCUsage = 0;

    pFont = (CFFFontStruct *) pUFO->pAFont->hFont;

    if ( pFont == nil || pFont->hFont == nil )
        retCode = kErrInvalidHandle;
    else
    {
        if (pUFO->flState == kFontInit)
        {
            switch ( pUFO->lDownloadFormat )
            {
            case kCFF:
                if ( pUFO->pUFL->outDev.lPSVersion <= VER_WO_OTHERSUBRS)
                {
                    //
                    // Only download the required OtherSubr procset if the
                    // printer version is less than 51 and we have not
                    // download anything.
                    //
                    if ( pUFO->pUFL->outDev.pstream->pfDownloadProcset == 0 )
                        return kErrDownloadProcset;

                    if ( !pUFO->pUFL->outDev.pstream->pfDownloadProcset(pUFO->pUFL->outDev.pstream, kCFFHeader) )
                        return kErrDownloadProcset;
                }
                break;

            case kCFFCID_H:
            case kCFFCID_V:
                if ( !pUFO->pUFL->outDev.pstream->pfDownloadProcset(pUFO->pUFL->outDev.pstream, kCMap_FF) )
                    return kErrDownloadProcset;
            }
        }

        #ifndef UFLWIN16
        if ( pGlyphs->pCharIndex == 0 )  /* DownloadFace */
            status = XCF_DownloadFontIncr( pFont->hFont,
                                           pGlyphs->sCount,
                                           pGlyphs->pGlyphIndices,
                                           NULL,
                                           pVMUsage );
        else
            status = XCF_DownloadFontIncr( pFont->hFont,
                                           pGlyphs->sCount,
                                           pGlyphs->pGlyphIndices,
                                           (unsigned char PTR_PREFIX * PTR_PREFIX *)pGlyphs->ppGlyphNames,
                                           pVMUsage );
        #endif

        if ( status != XCF_Ok )
            retCode = kErrUnknown;
        else
        {
            retCode = kNoErr;

            if ( ( pUFO->flState == kFontInit ) &&
                 ( pUFO->lDownloadFormat == kCFFCID_H || pUFO->lDownloadFormat == kCFFCID_V ) )
            {
                UFLHANDLE stream = pUFO->pUFL->hOut;

                if (pUFO->lDownloadFormat == kCFFCID_H)
                {
                    // Create the H CMap.
                    retCode = StrmPutStringEOL(stream, "CMAP-WinCharSetFFFF-H");

                    if (retCode == kNoErr)
                    {
                        // Create the CID-Keyed font.
                        char tempStr[128];

                        UFLsprintf(tempStr, "/%s /WinCharSetFFFF-H [/%s] composefont pop",
                                    pUFO->pszFontName,
                                    pFont->info.cidFontName);

                        retCode = StrmPutStringEOL(stream, tempStr);
                    }
                }
                else
                {
                    // Create the V CMap.

                    retCode = CFFSendCMapWinCharSetFFFF_V(pUFO, pFont);

                    if (retCode == kNoErr)
                    {
                        char tempStr[256];

                        //
                        // When 'vrt2' feature is enabled (and which is default
                        // for OTF-based CJKV fonts), simply to compose the V
                        // identity CMap and the CIDFont downloaded suffice.
                        //
                        UFLsprintf(tempStr, "/%s /WinCharSetFFFF-V%s [/%s] composefont pop",
                                        pUFO->pszFontName,
                                        pFont->info.baseName,
                                        pFont->info.cidFontName);
                        retCode = StrmPutStringEOL(stream, tempStr);
                    }
                }
            }
            else if ( pFont->info.usePSName )
            {
                if ( pGlyphs->pCharIndex == 0 )
                    retCode = CFFUpdateEncodingVector1(
                                (UFOStruct *)pUFO,
                                pGlyphs,
                                pGlyphs->sCount,
                                pGlyphs->pGlyphIndices);
                else
                    retCode = CFFUpdateEncodingVector(
                                (UFOStruct *) pUFO,
                                pGlyphs->sCount,
                                pGlyphs->pGlyphIndices,
                                pGlyphs->pCharIndex);
            }

            if ( retCode == kNoErr )
                pUFO->flState = kFontHasChars;
        }
    }

    return retCode;
}


UFLErrCode
CFFVMNeeded(
    const UFOStruct     *pUFO,
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMNeeded,
    unsigned long       *pFCNeeded
    )
{
#ifndef UFLWIN16
    CFFFontStruct   *pFont;
    enum XCF_Result status = XCF_Ok;
    UFLErrCode      retCode;
    unsigned short  cDLGlyphs;

    pFont = (CFFFontStruct *) pUFO->pAFont->hFont;

    if ( pVMNeeded )
        *pVMNeeded = 0;

    if ( pFCNeeded )
        *pFCNeeded = 0;

    if ( pFont == nil || pFont->hFont == nil )
        retCode = kErrInvalidHandle;
    else
    {
        status = XCF_CountDownloadGlyphs( pFont->hFont,
                                          pGlyphs->sCount,
                                          (XCFGlyphID *)pGlyphs->pGlyphIndices,
                                          &cDLGlyphs );
        if ( status != XCF_Ok )
            retCode = kErrUnknown;
        else
        {
            *pVMNeeded = cDLGlyphs * kVMTTT1Char;

            if ( pUFO->flState == kFontInit )
                *pVMNeeded += kVMTTT1Header;

            retCode = kNoErr;
        }
    }

    return retCode;
#endif
    return 0;
}


UFLErrCode
CFFUndefineFont(
    UFOStruct   *pUFO
    )
{
    CFFFontStruct *pFont;
    UFLErrCode    retVal = kNoErr;
    char          buf[128];
    UFLHANDLE     stream;

    pFont = (CFFFontStruct *) pUFO->pAFont->hFont;

    if ( pFont == nil || pFont->hFont == nil )
        retVal = kErrInvalidHandle;
    else
    {
        if (pUFO->flState == kFontInit) return retVal;

        stream = pUFO->pUFL->hOut;

        if ( pUFO->lDownloadFormat == kCFFCID_H || pUFO->lDownloadFormat == kCFFCID_V )
        {
            UFLsprintf(buf, "/%s /CIDFont UDR", pFont->info.cidFontName );

            StrmPutStringEOL(stream, buf);
        }

        UFLsprintf( buf, "/%s UDF", pUFO->pszFontName );

        retVal = StrmPutStringEOL( stream, buf );
    }
    return retVal;
}


UFLErrCode
CFFGIDsToCIDs(
    const CFFFontStruct  *pFont,
    const short          cGlyphs,
    const UFLGlyphID     *pGIDs,
    unsigned short       *pCIDs
    )
{
#ifndef UFLWIN16
    enum XCF_Result     status = XCF_Ok;
    UFLErrCode          retCode;
    short               i;
    unsigned short int  *pCurCIDs = (unsigned short int *)pCIDs;
    UFLGlyphID          *pCurGIDs = (UFLGlyphID *)pGIDs;

    retCode = kNoErr;

    for ( i = 0; i < cGlyphs; i++ )
    {
        status = XCF_GlyphIDsToCIDs( pFont->hFont,
                                     1,
                                     (XCFGlyphID PTR_PREFIX *)pCurGIDs++, /* list of glyphIDs */
                                     pCurCIDs++ );

        if ( status != XCF_Ok )
        {
            retCode = kErrUnknown;
            break;
        }
    }

    return retCode;
#endif
    return 0;
}


UFOStruct *
CFFFontInit(
    const UFLMemObj  *pMem,
    const UFLStruct  *pUFL,
    const UFLRequest *pRequest,
    UFLBool          *pTestRestricted
    )
{
#ifndef UFLWIN16
    enum XCF_Result  status = XCF_InternalError;
    CFFFontStruct    *pFont = nil;
    UFLCFFFontInfo   *pInfo;
    UFOStruct        *pUFObj;

    /* MWCWP1 doesn't like the implicit cast from void* to UFOStruct*  --jfu */
    pUFObj = (UFOStruct*) UFLNewPtr( pMem, sizeof( UFOStruct ) );
    if (pUFObj == 0)
        return nil;


    /* Initialize data */
    UFOInitData(pUFObj, UFO_CFF, pMem, pUFL, pRequest,
                (pfnUFODownloadIncr)  CFFFontDownloadIncr,
                (pfnUFOVMNeeded)      CFFVMNeeded,
                (pfnUFOUndefineFont)  CFFUndefineFont,
                (pfnUFOCleanUp)       CFFFontCleanUp,
                (pfnUFOCopy)          CopyFont );

    /* pszFontName should be ready/allocated - if not FontName, cannot continue */
    if (pUFObj->pszFontName == nil || pUFObj->pszFontName[0] == '\0')
    {
        UFLDeletePtr(pMem, pUFObj);
        return nil;
    }

    pInfo = (UFLCFFFontInfo *)pRequest->hFontInfo;

    if ( NewFont(pUFObj, sizeof(CFFFontStruct), pInfo->fData.maxGlyphs) == kNoErr )
    {
        pFont = (CFFFontStruct*) pUFObj->pAFont->hFont;

        pFont->info = *pInfo;

        /* a convenience pointer */
        pUFObj->pFData = &(pFont->info.fData);

        pFont->info.fData.cNumGlyphs = GetNumGlyphs(pUFObj);

        if ( pUFObj->pUpdatedEncoding == 0 )
        {
            pUFObj->pUpdatedEncoding = (unsigned char *)UFLNewPtr( pMem, GLYPH_SENT_BUFSIZE(256) );
        }

        pFont->hFont = 0;
        pUFObj->flState = kFontInit;
        status = InitFont( pUFObj );
    }

    if ( status != XCF_Ok || pFont == nil || pFont->hFont == 0 )
    {
        vDeleteFont( pUFObj );
        UFLDeletePtr( pUFObj->pMem, pUFObj );
        return nil;
    }
    else
    {
        if ( pTestRestricted )
        {
            unsigned char uc;
            unsigned short int us;
            XCF_SubsetRestrictions( pFont->hFont, &uc, &us);
            *pTestRestricted = (BOOL)uc;
        }
        else
            status = XCF_ProcessCFF(pFont->hFont);

        if ( status != XCF_Ok )
        {
            vDeleteFont( pUFObj );
            UFLDeletePtr( pUFObj->pMem, pUFObj );

            return nil;
        }
        else
            pUFObj->flState = kFontInit;
    }

    return pUFObj;
#endif
    return 0;
}
