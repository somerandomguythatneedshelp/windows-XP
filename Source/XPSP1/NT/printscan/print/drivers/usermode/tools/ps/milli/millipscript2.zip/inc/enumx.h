/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ENUMX.H                                                      */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/

#if 0

typedef struct tagDEVLOGBRUSH
{
   LOGBRUSH logBrush; // Defined in windows.h
   DWORD lbBkColor;
} DEVLOGBRUSH;

typedef DEVLOGBRUSH FAR*  LPDEVLOGBRUSH;

#endif

