/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: VMEM.C                                                       */
/*                                                                           */
/* Description: This module contains the function                            */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "icmstr.h"
#include "ufoenc.h"

#pragma code_seg(_TRANSSEG)

// local routine prototypes
static float NEAR PASCAL vmEstimateUsage(LPPDEVICE lppd, WORD estimateWhat, DWORD size);
static VOID NEAR PASCAL vmPSSendCheck(LPPDEVICE lppd, float numBytes);
static VOID NEAR PASCAL UndefAllFonts(LPPDEVICE lppd);
static VOID NEAR PASCAL UndefAllCRDs(LPPDEVICE lppd);
static VOID NEAR PASCAL UndefCRD(LPPDEVICE lppd, LPSTR szNAme);
static VOID NEAR PASCAL UndefAllCSAs(LPPDEVICE lppd);
static VOID NEAR PASCAL UndefCSA(LPPDEVICE lppd, LPSTR szNAme);

// VM reserve for the following operations
#define VMRESERVE_DOCSTART     30000
#define VMRESERVE_PASSTHROUGH  30000
#define VMRESERVE_FONT         ((float)1.2) // percentage of usage to reserve
#define VMUSE_SAFETYFACTOR     ((float)1.5)

// numbers used to calculate VM usage
#define VMUSE_PROCSET      20000        // procset vm usage
                                        // with "Optimize for Speed",
                                        // even though procsets are downloaded
                                        // incrementally, the vm usage of
                                        // the entire procset is included
#define VMUSE_OTHER        50000        // a certain amount of vm is consumed
                                        // before starting a job and when
                                        // setting up a job
#define VMUSE_PFA_FONT     ((float)0.6) // percentage of PFA font file size
#define VMUSE_TTT42_FONT   ((float)1.2) // percentage of Type 42 font vm usage
#define VMUSE_TTT42_HEADER 10000        // synthetic Type 42 header vm usage
#define VMUSE_TTT1_HEADER  10000        // synthetic Type 1 header vm usage
#define VMUSE_TTT1_HEADER2 2600         // synthetic T1 header in T0 vm usage
#define VMUSE_TTT1_FONT    500          // size of characters being downloaded
#define VMUSE_TTT3_HEADER  15000        // synthetic Type 3 header vm usage
#define VMUSE_TT_FONT      ((float)1.2) // percentage of size of GetFontData
#ifdef ADOBE_DRIVER
#define VMUSE_PST1_HEADER  10240
#define VMUSE_CRD          ((float)1.1)
#endif
#ifdef T3OUTLINE
#define VMUSE_TTT3OL_HEADER  15000      // synthetic Type 3 header vm usage
#define VMUSE_TTT3OL_FONT    550        // size of characters being downloaded
#endif

#ifdef ADD_EURO
#define VMUSE_ADD_EURO     5000
#endif

#define  MAX_FONTDIR_L1    500         // Max number of entries in FontDirectory in Level1 printers

void FAR PASCAL T32ReleaseFontCache(LPPDEVICE lppd, LPFONTDATARECORD lpFontDataRecord);

/***************************************************************************
*                          VMResetEstimateUsed
*
*  Purpose: Reset the estimated amount of VM used.
*
*  Parameters: 
*      LPPDEVICE lppd - the current pdevice
*    
*  Returns: none
*                                                                           
***************************************************************************/
VOID FAR PASCAL VMResetEstimateUsed(LPPDEVICE lppd)
{
   lppd->vmEstimateUsed = (float)(VMUSE_PROCSET + VMUSE_OTHER)
                          + lppd->vmUsedPreStartDoc;
}

/***************************************************************************
*                          VMDisable
*
*  Purpose: Disable VM tracking.
*
*  Parameters: 
*      LPPDEVICE lppd - the current pdevice
*    
*  Returns: none
*                                                                           
***************************************************************************/
VOID FAR PASCAL VMDisable(LPPDEVICE lppd)
{
      lppd->doVMTracking--;
}

/***************************************************************************
*                          VMEnable
*
*  Purpose: Enable VM tracking.
*
*  Parameters: 
*      LPPDEVICE lppd - the current pdevice
*    
*  Returns: none
*                                                                           
***************************************************************************/
VOID FAR PASCAL VMEnable(LPPDEVICE lppd)
{
   lppd->doVMTracking++;
}

/***************************************************************************
*                          VMRecoverDisable
*
*  Purpose: Disable VM recovery when low VM detected.
*
*  Parameters: 
*      LPPDEVICE lppd - the current pdevice
*    
*  Returns: none
*                                                                           
***************************************************************************/
VOID FAR PASCAL VMRecoverDisable(LPPDEVICE lppd)
{
      lppd->doVMRecovery--;
}

/***************************************************************************
*                          VMRecoverEnable
*
*  Purpose: Enable VM recovery when low VM detected.
*
*  Parameters:
*      LPPDEVICE lppd - the current pdevice
*    
*  Returns: none
*                                                                           
***************************************************************************/
VOID FAR PASCAL VMRecoverEnable(LPPDEVICE lppd)
{
   lppd->doVMRecovery++;
}

/***************************************************************************
*                                 VMCheck
*
*  Purpose: Estimate the VM needed for this operation.  Compare the
*           amount of VM left to needed amount.  Recover VM if it is low.
*           Output Postscript to check for VM also just in case.
*           This is only an estimate of the printer VM, it is
*           difficult model the printer VM usage accuratly.
*
*  Parameters:
*      LPPDEVICE lppd - the current pdevice
*      WORD checkWhat - the Postscript operation that uses VM
*      DWORD size - variable meaning base on the operation,
*                     see vmEstimateUsage
*    
*  Returns: TRUE if low VM has been detected and tried to recovered VM.
*                                                                           
***************************************************************************/
BOOL FAR PASCAL VMCheck(LPPDEVICE lppd, WORD checkWhat, DWORD size)
{
   float estimateNeed;
   float vmEstimateLeft;
   BOOL lowVM = FALSE;

   if (!DoVMTracking(lppd))
      return(lowVM);

#ifdef PSDEBUG
{
   CHAR buf[64];

   if (GetProfileInt("PscriptDebug", "NoVMTracking", 0) == 1)
      {
      VMDisable(lppd);
      return(lowVM);
      }

   if (GetProfileInt("PscriptDebug", "NoVMRecovery", 0) == 1)
      VMRecoverDisable(lppd);

   wsprintf(buf, "(VMCheck %d )", checkWhat);

   PSDEBUG_VMPRINT(lppd, buf);
}
#endif

   // TODO device independent color
   // TODO bring up warning to continue job or abort

   // estimate VM usage
   estimateNeed = vmEstimateUsage(lppd, checkWhat, size);

   // add VM reserve
   switch (checkWhat)
      {
      case VM_DOCSTART:
         // starting a job, reset the vm used
         VMResetEstimateUsed(lppd);
         estimateNeed = VMRESERVE_DOCSTART;
         break;

      case VM_PASSTHROUGH:
         estimateNeed = VMRESERVE_PASSTHROUGH;
         break;

      case VM_PFB_FONT:
      case VM_PFA_FONT:
      case VM_TTT42_FONT:
      case VM_TTT1_HEADER:
      case VM_TTT1_FONT:
      case VM_TTT3_HEADER:
      case VM_TTT3_FONT:
      case VM_TT_FONT:
#ifdef ADOBE_DRIVER
      case VM_PST1_HEADER:
#endif
      case VM_TTT01_HEADER:
      case VM_TTT03_HEADER:
      case VM_TTT0CID_FONT:
#ifdef T3OUTLINE
      case VM_TTT3OL_HEADER:
      case VM_TTT3OL_FONT:
      case VM_TTT03OL_HEADER:
#endif
         estimateNeed *= VMRESERVE_FONT;
         break;

      case VM_GOODESTIMATE:   /* Don't add any other estimate factors */
         break;

      default:
         break;
      } // switch (checkWhat)

   // check for low VM
   vmEstimateLeft = lppd->lpPSExtDevmode->dm2.fUserVMSelection -
                    lppd->vmEstimateUsed;
   if ((vmEstimateLeft < estimateNeed)
       || (IsDBCSCharSet(DefaultCJKCharSet) &&
          (lppd->lpFontDataList->FontDataNextRecord > 30) ||
          // 293130 Force vmrecover.
          // Run out of FontDataRecord will cause memory leak.
          (lppd->lpFontDataList->FontDataNextRecord > (MAXFONTDATARECORDS - 10)))
#ifndef ADOBEPS42
   || (!lppd->lpPSExtDevmode->dm2.bfUseLevel2 &&
      ((lppd->lpFontDataList->FontDataNextRecord > 90) ||
       (lppd->lpFontDataList->iDefinedFonts[lppd->lpProcsetstuff->savelevel] > MAX_FONTDIR_L1) )
      )
#endif
      )
      {
      if (lppd->doVMRecovery > 0)
         {
         WORD savelevel = VMRecover(lppd);
         VMSetupAfterRecovery(lppd, checkWhat, savelevel);
         lowVM = TRUE;
         }
      }

   // send Postscript to do VM check
   vmPSSendCheck(lppd, estimateNeed);

   return(lowVM);
} // VMCheck

/***************************************************************************
*                                 VMUsed
*
*  Purpose: Keep track of the VM used.  Only operations that can use
*           up large amount of VM is tracked.  
*           This is only an estimate of the printer VM, it is
*           difficult model the printer VM usage accuratly.
*
*  Parameters:
*      LPPDEVICE lppd - the current pdevice
*      WORD usedWhat - the Postscript operation that uses VM
*      DWORD size - variable meaning base on the operation, 
*                     see vmEstimateUsage
*    
*  Returns: nothing
*                                                                           
***************************************************************************/
VOID FAR PASCAL VMUsed(LPPDEVICE lppd, WORD usedWhat, DWORD size)
{
   if (!DoVMTracking(lppd))
      return;
   lppd->vmEstimateUsed += vmEstimateUsage(lppd, usedWhat, size);

#ifdef PSDEBUG
{
   CHAR buf[64];

   wsprintf(buf, "(VMUsed %d )", usedWhat);

   PSDEBUG_VMPRINT(lppd, buf);
}
#endif

} // VMUsed

/***************************************************************************
*                                 VMRecover
*
*  Purpose: Recover VM by using Postscript operator restore to free up VM.
*
*  Parameters:
*      LPPDEVICE lppd - the current pdevice
*    
*  Returns: current savelevel
*                                                                           
***************************************************************************/

WORD FAR PASCAL VMRecover(LPPDEVICE lppd)
{
    WORD savelevel = 0;
    BOOL psSpeed = (lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED);
    BOOL done = FALSE;
    
    if (!DoVMTracking(lppd))
       return 0;

#ifdef ADOBE_DRIVER
   // Back up only upto the state accumulated on this page i.e.
   //	pagesave in the speed option and savelevel1 in case of
   //	portability

    while(lppd->lpProcsetstuff->savelevel > 1)
    {
        PSSendRestore(lppd);
        savelevel++;
    }

   // Since we do one less save, we need to bump up savelevel to set
   //	correct count (Failure to do this was causing bug 73)

    if (psSpeed && lppd->lpProcsetstuff->savelevel)
        savelevel++;

   // Use level 2 undefinefont operator to recover VM

    UndefAllFonts(lppd);
    UndefAllCRDs(lppd);
    UndefAllCSAs(lppd);
#else
    // restore VM back to the beginning before the first save
    while (lppd->lpProcsetstuff->savelevel > 0 && !done)
    {
        // need to stop before pagesave for portability
        if ((lppd->lpProcsetstuff->pagesaveLevel ==
             lppd->lpProcsetstuff->savelevel) &&
            !psSpeed)
            done = TRUE;
        else
        {
            PSSendRestore(lppd);
            savelevel++;
        }
    }
#endif

    VMResetEstimateUsed(lppd);
    return savelevel;

} // VMRecover


/***************************************************************************
*                                 VMSetupAfterRecovery
*
*  Purpose: Restores savelevel after recovering VM. Sends procset for required
*           operation down.
*
*  Parameters:
*      LPPDEVICE lppd - the current pdevice
*    
*  Returns: nothing
*                                                                           
***************************************************************************/
VOID FAR PASCAL VMSetupAfterRecovery(LPPDEVICE lppd, WORD recoverWhat, 
                                     WORD savelevel)
{
    BOOL psSpeed = (lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED);
    BOOL psSpeedRestore = TRUE;
    
    // put all the saves back
    while (savelevel > 0)
    {
        if (psSpeed && psSpeedRestore)
        {
#ifndef ADOBE_DRIVER
            // the first save for the Optimize for Speed option
            PSSendSave(lppd, FALSE);

            // If nup != 1, reinitialize it (speed mode).
            if (lppd->lpPSExtDevmode->dm.layout != ONE_UP)
            {
                PSSendNup(lppd);
            }
#endif
            // a useless save just so that down loading procsets work
            // since down loading procsets always do a restore/save
            // but if we got here that means we are in the middle of
            // down loading a font which already did a restore/save
            // PSSendSave(lppd, FALSE);
            TSetVMMark(lppd, 0, FALSE);
            switch (recoverWhat)
            {
                case VM_PFB_FONT:
                case VM_PFA_FONT:
#ifdef ADOBE_DRIVER
      		case VM_PST1_HEADER:
#endif
                    TokenNeedsProcset(lppd, TEXT);
                    break;
                case VM_TTT42_FONT:
                    TokenNeedsProcset(lppd, TEXT);
                    TokenNeedsProcset(lppd, TYPE42);
                    TokenNeedsProcset(lppd, TYPE0HDR);
                    break;
                case VM_TTT1_HEADER:
                case VM_TTT1_FONT:
                    TokenNeedsProcset(lppd, TEXT);
                    TokenNeedsProcset(lppd, TYPE1HDR);
                    break;
                case VM_TTT3_HEADER:
                case VM_TTT3_FONT:
                    TokenNeedsProcset(lppd, TEXT);
                    TokenNeedsProcset(lppd, TYPE3HDR);
                    break;
#ifdef T3OUTLINE
                case VM_TTT3OL_HEADER:
                case VM_TTT3OL_FONT:
                    TokenNeedsProcset(lppd, TEXT);
                    TokenNeedsProcset(lppd, TYPE3OLHDR);
                    break;
#endif
                case VM_TT_FONT:
                    TokenNeedsProcset(lppd, TEXT);
                    break;
                case VM_TTT01_HEADER:
                    TokenNeedsProcset(lppd, TEXT);
                    TokenNeedsProcset(lppd, TYPE1HDR);
                    TokenNeedsProcset(lppd, TYPE0HDR);
                    break;

                case VM_TTT03_HEADER:
                    TokenNeedsProcset(lppd, TEXT);
                    TokenNeedsProcset(lppd, TYPE3HDR);
                    TokenNeedsProcset(lppd, TYPE0HDR);
                    break;
#ifdef T3OUTLINE
                case VM_TTT03OL_HEADER:
                    TokenNeedsProcset(lppd, TEXT);
                    TokenNeedsProcset(lppd, TYPE3OLHDR);
                    TokenNeedsProcset(lppd, TYPE0HDR);
                    break;
#endif
                case VM_TTT0CID_FONT:
                    TokenNeedsProcset(lppd, TEXT);
                    TokenNeedsProcset(lppd, TYPE42);
                    TokenNeedsProcset(lppd, TYPE0HDR);
                    TokenNeedsProcset(lppd, lppd->iResIdCMap); //cmapID was saved in ttext.c's DownLoadFont().
                    break;
                    
                default:
                    break;
            } // switch (checkWhat)
            // PSSendRestore(lppd);
            TCleanToVMMark(lppd, 0);
            psSpeedRestore = FALSE;
        }
        else
        {
            PSSendSave(lppd, FALSE);
        }
        savelevel--;
    }
    
#ifdef PSDEBUG
    {
        CHAR buf[64];
        
        wsprintf(buf, "(vmRecovery after %d )", recoverWhat);
        PSDEBUG_VMPRINT(lppd, buf);
    }
#endif
    
} // VMSetupAfterRecovery

/***************************************************************************
*                                 vmEstimateUsage
*
*  Purpose: Estimate the VM usage base on the operation
*
*  Parameters:
*      WORD estimateWhat - the Postscript operation that uses VM
*      DWORD size - variable meaning base on the operation
*    
*  Returns: the estimate VM usage of the given operation
*                                                                           
***************************************************************************/
static float NEAR PASCAL vmEstimateUsage(LPPDEVICE lppd, WORD estimateWhat, DWORD size)
{
   float usage = 0;
#ifdef ADD_EURO
   BOOL  bAddEuro = FALSE;
   if (!(lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED) ||
      (lppd->lpPSExtDevmode->dm2.bAddEuro))
      bAddEuro = TRUE;
#endif

   switch (estimateWhat)
      {
      // size = size of font file
      case VM_PFB_FONT:
         usage = (float)size;
#ifdef ADD_EURO
         if (bAddEuro)
             usage += (float)VMUSE_ADD_EURO;
#endif
         break;
      // size = size of font file
      case VM_PFA_FONT:
         usage = (float)size * (float)VMUSE_PFA_FONT;
#ifdef ADD_EURO
         if (bAddEuro)
             usage += (float)VMUSE_ADD_EURO;
#endif
         break;
      // size = size of GetFontData
      case VM_TTT42_FONT:
         usage = (float)size * (float)VMUSE_TTT42_FONT;
      case VM_TTT0CID_FONT:
         usage = (float)size * (float)VMUSE_TTT42_HEADER;
         break;
      // size not used
      case VM_TTT1_HEADER:
         usage = (float)VMUSE_TTT1_HEADER;
         break;
#ifdef ADOBE_DRIVER
      case VM_PST1_HEADER:
         usage = (float)VMUSE_PST1_HEADER;
#ifdef ADD_EURO
         if (bAddEuro)
             usage += (float)VMUSE_ADD_EURO;
#endif
	 break;
      case VM_PST1_FONT:
	 usage = (float)size;
	 break;
#endif
      // size = number of characters being downloaded
      case VM_TTT1_FONT:
         usage = (float)size * (float)VMUSE_TTT1_FONT;
         break;
      // size not used
      case VM_TTT3_HEADER:
         usage = (float)VMUSE_TTT3_HEADER;
         break;
      // size = size of characters being downloaded
      case VM_TTT3_FONT:
         usage = (float)size;
         break;
      // size = size of GetFontData
      case VM_TT_FONT:
         usage = (float)size * (float)VMUSE_TT_FONT;
         break;
      case VM_CRD:
         usage = (float)size * (float)VMUSE_CRD;
         break;

      case VM_TTT01_HEADER:     // download TrueType as Type 0 /Type-1s
         //size = Number of child Type-1 fonts
         usage = (float) size* VMUSE_TTT1_HEADER2 + (float)16000;
         break;

      case VM_TTT03_HEADER:     // download TrueType as Type 0 /Type-3s
         //size = Number of child Type-3 fonts
         usage = (float) size* VMUSE_TTT3_HEADER;
         break;
#ifdef T3OUTLINE
      case VM_TTT3OL_HEADER:
         usage = (float)VMUSE_TTT3OL_HEADER;
         break;
      case VM_TTT3OL_FONT:
         usage = (float)size * (float)VMUSE_TTT3OL_FONT;
         break;
      case VM_TTT03OL_HEADER:   // download TrueType as Type 0 /Type-3 Outline
         //size = Number of child Type-3 fonts
         usage = (float) size* VMUSE_TTT3OL_HEADER;
         break;
#endif

      case VM_GOODESTIMATE:   /* Don't add any other estimate factors */
         usage = (float) size;
         break;

      default:
         break;
      } // switch (estimateWhat)

      if (estimateWhat == VM_GOODESTIMATE)  //UFL already put in the safty factor
         return(usage);
      else
         return(usage * VMUSE_SAFETYFACTOR);

} // vmEstimateUsage

/***************************************************************************
*                                 vmPSSendCheck
*
*  Purpose: Send Postscript to check VM.
*
*  Parameters:
*      LPPDEVICE lppd - the current pdevice
*      DWORD numBytes - number of bytes of VM wanted to check
*    
*  Returns: nothing
*                                                                           
***************************************************************************/
static VOID NEAR PASCAL vmPSSendCheck(LPPDEVICE lppd, float numBytes)
{
   LPASCIIBINPTRS tempptr;
   CHAR buf[64];

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   // send number of bytes of VM wanted
   wsprintf(buf, "%ld ", (LONG)numBytes);
   PSSendString(lppd, buf);
   // send "VM?"
   PSSendFragment(lppd, PSFRAG_VMCheck);
   (*tempptr->PSSendCRLF)(lppd);
} // vmPSSendCheck


#define NUM_CIDSUFFIX  4
static VOID NEAR PASCAL UndefDescendantFonts(LPPDEVICE lppd,  LPFONTDATARECORD lpFontDataRecord)
{
LPASCIIBINPTRS tempptr;
LPDBCSENCODE   lpEncoding;
int i, fontNameLen;
LPBYTE lpFontName;
char   cidFontName[50];
char   *cidSuffix[NUM_CIDSUFFIX]={"", "R", "32K", "32KR"};

    tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;
    lpEncoding = GetEncoding((int)lpFontDataRecord->CharSet,
                      lppd->lpPSExtDevmode->dm2.bEUDCAble);
   
    lpFontName = lpFontDataRecord->FontName; fontNameLen = 0;
    while(lpFontName && *lpFontName)
    {
        lpFontName++; fontNameLen++ ;  // save old fontname
    }

    if (lpFontDataRecord->fontDLType == CC_T01 ||
        lpFontDataRecord->fontDLType == CC_T03)
    {
        // UFLUndefineSubFonts() undefs all lowest level.T1 or T3 fonts
        
        // Double Byte Fonts: 8/8 mapping
        for (i=0; i<MAX_1STBRANGES; i++)
        {
            if (lpEncoding->Double[i].min==0 && lpEncoding->Double[i].max==0) break;
            
            // Undef the T0-8/8 mapping font. - inter-level Type0 fonts, see ttext.c
            // This only applies to Japanese fonts - see ttfonts2.c for non-0 Double[i].min/max
            lpFontName = &(lpFontDataRecord->FontName[fontNameLen]);
            //  tack on min-max as part of FontName - see ttext.c.
            AppNumToName5(lpFontName, (int)lpEncoding->Double[i].min, (int)lpEncoding->Double[i].max);   // add 5 chars
            PSSendString(lppd, " /");
            PSSendString(lppd, lpFontDataRecord->FontName);
            PSSendString(lppd, " undefinefont ");
            (*tempptr->PSSendCRLF)( lppd );
        }
    }
    else if (lpFontDataRecord->fontDLType == GI_CID )
    {
        // UFL handles all in this case
    }
    else if (lpFontDataRecord->fontDLType == CC_CID)
    {
        /* we did composefont - we have to undef them */
        lstrcpy(cidFontName, lpFontDataRecord->FontName); 
        AppNumToName3(cidFontName+fontNameLen, 0);   //MSTT31abcd000 !!! "000" is hard coded here
        // undefine all four related CIDFont resource:
        // "MSTT31abcd000, MSTT31abcd000R, MSTT31abcd00032K, MSTT31abcd00032KR" - see ttfonts.c for details
        for (i=0; i<NUM_CIDSUFFIX; i++)
        {
            PSSendString(lppd, " /");
            PSSendString(lppd, cidFontName);
            PSSendString(lppd, cidSuffix[i]);
            PSSendString(lppd, " /CIDFont undefineresource ");
            (*tempptr->PSSendCRLF)( lppd );
        }
    }

    // Restore the saved Font name:
    lpFontDataRecord->FontName[fontNameLen]='\0';

}


#ifdef ADOBE_DRIVER
/***************************************************************************
*                                 UndefAllFonts
*
*  Purpose: Undefine all fonts and delete from the fontdatalist
*	    structure. Only possible in Level2 printers
*
*  Parameters:
*      LPPDEVICE lppd - the current pdevice
*    
*  Returns: Amount of VM recovered
*                                                                           
***************************************************************************/
static VOID NEAR PASCAL UndefAllFonts(LPPDEVICE lppd)
{
    LPFONTDATARECORD currentrec;
    short           dex;
    int             temp;
    LPASCIIBINPTRS  tempptr;
    char            fname[128];
    int             PSVersion= GetPSVersion(lppd);

    // If VM recover is called for CSA or CRD, do not undef fonts.
    // Otherwise,we may delete the font just prepared for showing text.
    if ((lppd->graphics.CSAClear) || (lppd->graphics.CRDClear))
       return;

    tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;
    if (lppd->lpFontDataList->FontDataNextRecord > 0)
    {
        PSSendString(lppd, "Pscript_Windows_Font");
        (*tempptr->PSSendCRLF)(lppd);

        for ( currentrec = lppd->lpFontDataList->FontDataList +
           (dex = (lppd->lpFontDataList->FontDataNextRecord - 1));
           // dex >= 0;
           dex >= lppd->nPreStartDocFonts;  //do not undefine pre-startdoc fonts
           dex--, currentrec--
        )
        {
            FontInstName(fname, currentrec);
            PSSendString(lppd, "dup /");
            PSSendString(lppd, fname);
            if (!currentrec->xScale && !currentrec->yScale)
            {
                /* for each instance F0, F1, undefinefont  */
                PSSendString(lppd, " dup undefinefont");

                // Fix bug 149729 - should not undefine a RAM font!!!
                if (!currentrec->BoldFake && !currentrec->ItalicFake &&
                    !currentrec->addAscExt &&
                    currentrec->fontDLType )
                {

                    /* Ask UFL to undefine th eoriginal font MSTT31abcds01...
                     * UFL knows how to undefine its fonts - T42, CID...*/
                    if (currentrec->isMypSubFont && currentrec->pSubFont)
                    {
                        UFLUnDefineSubFonts(lppd, currentrec->pSubFont);
                    }
                    else
                    {
                        /* old fashion - a PFB/Type1 font */
                        PSSendString(lppd, " /");
                        PSSendString(lppd, currentrec->FontName);
                        PSSendString(lppd, " undefinefont");
                        (*tempptr->PSSendCRLF)(lppd);
#ifdef ADD_EURO
                        if (lppd->lpPSExtDevmode->dm2.bAddEuro)
                        {
                            PSSendString(lppd, "/");
                            PSSendString(lppd, currentrec->FontName);
                            PSSendString(lppd, "-Copy /Font resourcestatus {");  
                            PSSendString(lppd, "pop pop /");
                            PSSendString(lppd, currentrec->FontName);
                            PSSendString(lppd, "-Copy ");
                            PSSendString(lppd, " undefinefont} if");
                            (*tempptr->PSSendCRLF)(lppd);
                        }
#endif
                    }

                // remove all descendants of base font.
                if (currentrec->fontDLType == CC_T01 ||
                    currentrec->fontDLType == CC_T03 ||
                    currentrec->fontDLType == CC_CID ||
                    currentrec->fontDLType == GI_CID
                   )
                {
                    UndefDescendantFonts(lppd, currentrec);
                }
           }
		   
        }
        /* For scaled instances F0S123, F1S123..- just undef from our dict Pscript_Windows_Font */
    	PSSendString(lppd, " undef");
    	(*tempptr->PSSendCRLF)(lppd);
      }
      PSSendString(lppd, "pop");	/* pop Pscript_Windows_Font */
      (*tempptr->PSSendCRLF)(lppd);
   }
   temp = lppd->lpProcsetstuff->savelevel;
	/* Reset all the font bookkeeping */
	/* faking level 0	*/
   lppd->lpProcsetstuff->savelevel = 0;
   ResetFontDataList(lppd);
   lppd->lpProcsetstuff->savelevel = temp;

   // Fix bug 164116.   SAVE_RESTORE
   // After undef all fonts, we also need to clean GSTACK.
   lppd->lpGSStack->lpgGState->currentFontData.FontName[0] = (char)0;
   for (temp = 0; temp < lppd->lpGSStack->num_pushed; temp++)
      lppd->lpGSStack->elems[temp].currentFontData.FontName[0] = (char)0;

   // Fix bug 265334  ... reclaim VM
   PSSendFragment(lppd, PSFRAG_reclaimVM);
   (*tempptr->PSSendCRLF)(lppd);

}


/***************************************************************************
*                                 UndefAllCRDs
*
*  Purpose: Undefine all CRD and delete from the bCRDUsed
*	    structure. Only possible in Level2 printers
*
*  Parameters:
*      LPPDEVICE lppd - the current pdevice
*    
*  Returns: Amount of VM recovered
*                                                                           
***************************************************************************/
static VOID NEAR PASCAL UndefAllCRDs(LPPDEVICE lppd)
{
   DWORD cCRD = lppd->graphics.bCRDSent[lppd->lpProcsetstuff->savelevel] ;
   LPSTR   lpszEntry;
   WORD  temp;

   // If VM recover is called for creating CRD. Delete all unused CRD.
   if ((cCRD & LCS_GM_IMAGES) && (lppd->graphics.CRDClear & LCS_GM_IMAGES))
   {
        lpszEntry = "Perceptual";
        UndefCRD(lppd, lpszEntry);

   }
   if ((cCRD & LCS_GM_BUSINESS) && (lppd->graphics.CRDClear & LCS_GM_BUSINESS))
   {
        lpszEntry = "Saturation";
        UndefCRD(lppd, lpszEntry);
   }
   if ((cCRD & LCS_GM_GRAPHICS) && (lppd->graphics.CRDClear & LCS_GM_GRAPHICS))
   {
        lpszEntry = "Colorimetric";
        UndefCRD(lppd, lpszEntry);
   }
   // Go thru every CRD in the stack and invalidate all
   //    downloaded CRDs
   for( temp = 0; temp <= (WORD)lppd->lpProcsetstuff->savelevel ; ++temp)
   {
      lppd->graphics.bCRDSent[temp] &= ~(lppd->graphics.CRDClear);
   }
}

/***************************************************************************
*                                 UndefAllCSAs
*
*  Purpose: Undefine all CSA and delete from the bCSASent
*	    structure. Only possible in Level2 printers
*
*  Parameters:
*      LPPDEVICE lppd - the current pdevice
*    
*  Returns: Amount of VM recovered
*                                                                           
***************************************************************************/
static VOID NEAR PASCAL UndefAllCSAs(LPPDEVICE lppd)
{
   WORD  temp;

   // If VM recover is called for creating CSA. Delete all unused CSA.
   if (!(lppd->graphics.CSAClear))
       return;

   if(lppd->graphics.bCSASent[lppd->lpProcsetstuff->savelevel] )
   {
        UndefCSA(lppd, CSAName);
   }
   // Go thru every CSA in the stack and invalidate all
   //    downloaded CSAs
   for( temp = 0; temp <= (WORD)lppd->lpProcsetstuff->savelevel ; ++temp)
   {
      lppd->graphics.bCSASent[temp] = 0;
   }
}

/***************************************************************************
*                                 UndefCRD
*
*  Purpose: Undefine CRD specified by name
*
*  Parameters:
*      LPPDEVICE  lppd - the current pdevice
*      LPSTR      lpszName - CRD name
*
*  Returns: none
*                                                                           
***************************************************************************/
static VOID NEAR PASCAL UndefCRD(LPPDEVICE lppd, LPSTR szName)
{
   LPASCIIBINPTRS tempptr;
   tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;

   (*tempptr->PSSendCRLF)(lppd);
   PSSendString(lppd, "/");
   PSSendString(lppd, szName);
   PSSendString(lppd, " /ColorRendering undefineresource");
   (*tempptr->PSSendCRLF)(lppd);
}

/***************************************************************************
*                                 UndefCSA
*
*  Purpose: Undefine CSA specified by name
*
*  Parameters:
*      LPPDEVICE  lppd - the current pdevice
*      LPSTR      lpszName - CSA name
*
*  Returns: none
*                                                                           
***************************************************************************/
static VOID NEAR PASCAL UndefCSA(LPPDEVICE lppd, LPSTR szName)
{
   LPASCIIBINPTRS tempptr;
   tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;

   (*tempptr->PSSendCRLF)(lppd);
//   PSSendString(lppd, "/");
   PSSendString(lppd, szName);
   PSSendString(lppd, " /ColorSpace undefineresource");
   (*tempptr->PSSendCRLF)(lppd);
}

#endif

