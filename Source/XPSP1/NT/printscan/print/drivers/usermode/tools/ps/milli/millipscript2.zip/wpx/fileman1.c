/*   fileman1.c -  WPX  file access and indexing functions  */

#include  "generic.h"
#include <ctype.h>
#include <string.h>

#pragma code_seg(_FILEMAN1SEG)

#define _MAX_PATH             260
#define MYFONT                258
#define GDLLHND               (GHND | GMEM_SHARE)



#define  MAXINDEXENTRIES  300
#define  MAXSPECIFERSIZE  128


typedef  struct
{
   WORD  specifierOffset;  // to single NULL terminated string
   WORD  filenameOffset;   // to double NULL terminated string
} INDEXMAP , far * LPINDEXMAP;

// didn't want to declare INDEXMAP everywhere so the
// function addIndexEntry() had to be excluded from fproto.h

WORD   NEAR  PASCAL  addIndexEntry(
   LPBYTE  modelName,
   LPBYTE  dsBuffer,
   LPINDEXMAP  lpIndexmap,
   WORD    numEntries ,
   LPBYTE  lpStringTable) ;

BOOL  indexSubDir(
   LPBYTE   dsBuffer ,
   LPBYTE   filespec ,
   LPINDEXMAP   lpIndexmap ,
   LPWORD   lpNumEntries ,
   LPBYTE   lpStringTable ,
   BOOL   (NEAR  PASCAL  *extractModelName)(LPBYTE, LPBYTE, WORD) ) ;




/* 
/ ------------------------- verifyTree() -----------------------------------
/  creates if necessary a writable subtree \pscript\wpxfiles
/  determines if the three required subdirs exist:
/     pscript\ppdfiles
/     pscript\pfmfiles
/     pscript\entryppd
/  each subdir may reside either in the Windows or System subdir.
/
/  Return value:  upon success: in lpdsWritableSubdir -
/           Full path to \pscript\wpxfiles  (writable subdir)
/           Returns TRUE
/     upon Failure:  Return FALSE.
/
/  C libs functions called:  _mkdir(), _access().
/  Note:  arg must reside in DS else C lib functs will fail
/         Thanks to davidtry for choosing a small data model.
/
/ Revision:  ChrisG insists that all branches of tree be lopped off.
/ more revisions:  we will be working only in one directory.
/ for now use the Windows directory.  Later, use a dedicated printers
/ subdir.
/
/  see pstt\wpx for full blown version of verifyTree.
/
*/

BOOL   NEAR  PASCAL  verifyTree(
LPBYTE   lpdsWritableSubdir)
{
   GetWindowsDirectory(lpdsWritableSubdir,_MAX_PATH);

#if 0
   WORD  length;


   length = lstrlen(lpdsWritableSubdir);

   //  determine writability of this dir.   
   {
      OFSTRUCT   OpenBuf ;  // for OpenFile()
      HFILE  file ;  

      appendPath(lpdsWritableSubdir, "testfile.tst");

      file = OpenFile(lpdsWritableSubdir, &OpenBuf, OF_CREATE | OF_WRITE);

      if(file == HFILE_ERROR) 
     return(FALSE);

      _lclose(file);
   }

   lpdsWritableSubdir[length] = '\0' ;

#endif
   
   return(TRUE);  // at least one good tree exists.
}



void   NEAR  PASCAL  appendPath(
LPBYTE  lpRootPath ,
LPBYTE  lpSubPath  )
{
   WORD  length;

   length = lstrlen(lpRootPath);

   if(!length)  //  no root!
      return;
   if(lpRootPath[length - 1] != '\\')
   {
      lpRootPath[length]   = '\\' ;   //  add terminating slash
      lpRootPath[length+1] = '\0' ;
   }
   if(lpSubPath[0] == '\\')
      lpSubPath++ ;  // eliminate first slash
   lstrcat(lpRootPath, lpSubPath);
}


//  CALLER specifies ModelName and function fills in FileName
//  or returns FALSE  if not found in Index
//  This function is used to access all indicies since they all 
//  have the same format!
//  format of each index entry is ModelName string terminated by comma
//  followed by full pathname of associated file terminated by \r\n.


BOOL  NEAR  PASCAL  extractFileNameFromIndex(
LPBYTE  lpModelName,
LPBYTE  lpFileName ,
WORD    Bufsize    ,  // size of lpFileName  (dest buffer)
LPBYTE  lpIndex )     // full path where indexfile is expected.
{
   HPBYTE  hpBuf, hpCur ;
   WORD  refLen, j;
   long  fileSize, i;


   lpFileName[0] = '\0' ;  //  NULL terminate string

   hpBuf = ReadFileIntoHBuf(lpIndex, &fileSize) ;
   if(!hpBuf)
      goto abortExtractFromIndex;

   refLen = lstrlen(lpModelName);
   //  now search for lpModelName.
   //  note lpModelName must be a NULL terminated string.

   for(i = 0 ; i < fileSize ; i++)
   {
      if( !i || hpBuf[i-1] == 10 || hpBuf[i-1] == 13 ) //  start of newline
      {  // every model string will be preceeded by newline except the
     // one at i = 0.
     for(j = 0 ; j < refLen ; j++)
     {
        if(i+refLen >= fileSize)
        {
           lpFileName[0] = '\0' ;  //  NULL terminate string
           goto abortExtractFromIndex;  // reached end of index
        }
        if(hpBuf[i+j] != lpModelName[j])
           break;
     }
     if(j < refLen  ||  ( *(hpBuf+i+j) != ','))
        continue;  //  didn't match.

     hpCur = hpBuf+i+j+1 ;  // points after comma


     for(j = 0 ; j < Bufsize ; j++ )
     {
        if(hpCur[j] == 10 || hpCur[j] == 13 )  // we are depending on this!!
        {
           lpFileName[j] = '\0' ;  //  Null terminate
           break;
        }
        lpFileName[j] = hpCur[j] ;
     }
     if(j >= Bufsize)
     {
        errorMsg(EXTRACTFILENAMEFROMINDEX, ERR_BUFFER_OVERFLOW);

        lpFileName[0] = '\0' ;  //  NULL terminate string
     }
     else 
     {
        HFILE  hfile ;

        hfile = _lopen(lpFileName, READ) ;
        if(hfile == HFILE_ERROR) 
           lpFileName[0] = '\0' ;  //  file doesn't actually exist
        else
           _lclose(hfile);
     }
     break;  // no need to search further.
      }
      // continue drops you here at bottom of for loop.
   }

abortExtractFromIndex:
   if(hpBuf)
   {
      GlobalFreePtr(hpBuf);   
   }
   if(lpFileName[0])
      return(TRUE);  // Modelname found!
   return(FALSE);
}




/*  this function opens the specified file
   reads its entire contents into a buffer that it
   allocates and returns a pointer to this buffer
   to caller.  The caller is then responsible for
   freeing the buffer.
*/

HPBYTE   NEAR  PASCAL  ReadFileIntoHBuf(
LPBYTE  lpFileName ,  // file to read
LPDWORD  lpnbytes  )  // Num bytes read.
{
   HPBYTE  hpBuf ;  // Points to very start of buffer (offset zero)
   long    fileSize ;  // total size of buffer.
   HFILE  hfile ;

   hpBuf = NULL;

   hfile = _lopen(lpFileName, READ | OF_SHARE_DENY_WRITE);
   if(hfile == HFILE_ERROR) 
   {
      errorMsg(READFILEINTOHBUF, ERR_FILE_READACCESS);
      errorString(lpFileName);
      fileSize = 0 ;
      goto  exitReadFile;
   }
   //  determine fileSize;
   fileSize = _llseek(hfile, 0L, 2);   //  seek end of file
   _llseek(hfile, 0L, 0);              //  seek beginning of file.


   if(!fileSize)  // nothing in index!
      goto  exitReadFile;  

   hpBuf = GlobalAllocPtr(GHND, fileSize );  //  alloc buffer to hold entire file
   if(!hpBuf)
   {
      errorMsg(READFILEINTOHBUF, ERR_GLOBALALLOC_FAILED);
      fileSize = 0 ;
      goto  exitReadFile;
   }
   if(fileSize != _hread(hfile, hpBuf,  fileSize))
   {
      errorMsg(READFILEINTOHBUF, ERR_FILE_READ_FAILED);
      errorString(lpFileName);

      if(hpBuf)
      {
     GlobalFreePtr(hpBuf);   
     hpBuf = NULL;
      }
      fileSize = 0 ;
   }

exitReadFile:

   *lpnbytes = fileSize ;
   if(hfile != HFILE_ERROR)
      _lclose(hfile);
   return(hpBuf);
}



#ifndef ADOBE_DRIVER
//  return value indicates if index file was
//  created.  Failure is a fatal error since
//  driver and rest of make WPX code depends on it.


BOOL   NEAR  PASCAL  indexWPXs(
LPBYTE   lpIndexPath )  // caller supplies full path and name of index.
            // and of course verifies subdir is writable.
{
   static  BYTE    dsBuffer[_MAX_PATH];
   static  BOOL    done = FALSE ;

   BOOL  status = FALSE;
   LPBYTE  lpStringTable ;
   LPINDEXMAP  lpIndexmap;
   WORD    numEntries;   // check to see if max limit was reached.

   // possible errors:  overflow indexmap

   if(done)
      return(TRUE);  // don't waste time rebuilding indicies.
   done = TRUE;

   // allocate 2 blocks of memory

   lpStringTable = NULL;

   lpIndexmap = (LPINDEXMAP)GlobalAllocPtr(GHND, MAXINDEXENTRIES * sizeof(INDEXMAP)); 
   if(!lpIndexmap)
      goto  endIndexWPXs;

   lpStringTable = GlobalAllocPtr(GHND, 0x10000L);
   if(!lpStringTable)
      goto  endIndexWPXs;

   numEntries = 0 ;

   //  create two paths that WPXs can be found in starting with the
   //  highest priority first.
   GetWindowsDirectory(dsBuffer,_MAX_PATH);

   status = indexSubDir(dsBuffer, "*.wpx", lpIndexmap, &numEntries, 
               lpStringTable, extractWPXmodelName) ;
   if(!status)
      goto  endIndexWPXs;



   //  this block just restricts scope of local variables
   {  //  writing stringTable to file.
      WORD   count;
      OFSTRUCT   OpenBuf ;  // for OpenFile()
      HFILE  hIndex ;  //  holds handle to Index file

      hIndex = OpenFile(lpIndexPath, &OpenBuf, 
          OF_CREATE | OF_WRITE | OF_SHARE_DENY_WRITE);

      if(numEntries)  
      {

     count =  lpIndexmap[numEntries-1].filenameOffset - OFFSETOF(lpStringTable);
     count += lstrlen((LPBYTE)MAKELONG(lpIndexmap[numEntries-1].filenameOffset, 
                      HIWORD(lpStringTable)));
     if(count != _lwrite(hIndex, lpStringTable,  count))
     {
        errorMsg(INDEXWPXS, ERR_FILE_WRITE_FAILED) ;
        errorMsg(INDEXWPXS, ERR_CREATING_WPX_INDEX) ;
        status = FALSE;
     }
      }
      else
      {
     errorMsg(INDEXWPXS, ERR_CANT_FIND_WPX_FILES) ;
      }
      _lclose(hIndex);
   }

endIndexWPXs:
   if(lpIndexmap)
      GlobalFreePtr(lpIndexmap);
   if(lpStringTable)
      GlobalFreePtr(lpStringTable);   
   return(status);
}
#endif


BOOL  indexSubDir(
   LPBYTE   dsBuffer ,
   LPBYTE   filespec ,
   LPINDEXMAP   lpIndexmap ,
   LPWORD   lpNumEntries ,
   LPBYTE   lpStringTable ,
   BOOL   (NEAR  PASCAL  *extractModelName)(LPBYTE, LPBYTE, WORD) ) 
{
   WORD  length;
   BYTE  modelName[MAXSPECIFERSIZE];  // reasonably large value.

   //  commence search of this subdir now!
   length = lstrlen(dsBuffer);  // length of subdir only.

   if(!EnumFilesInDirectory(dsBuffer, filespec))
      return(TRUE);  // no files found!

   do
   {
      if(!(*extractModelName)(modelName, dsBuffer, MAXSPECIFERSIZE))
      {
     dsBuffer[length] = '\0' ;  // truncate filename leaving just subdir.
     continue;  // drop to end of loop.
      }
      if(*lpNumEntries >= MAXINDEXENTRIES)
      {
     errorMsg(INDEXSUBDIR, ERR_TOOMANY_TO_INDEX);
     return(FALSE);
      }
      *lpNumEntries = addIndexEntry(modelName, dsBuffer, lpIndexmap, *lpNumEntries, 
        lpStringTable);  //  checks for duplication before adding
      dsBuffer[length] = '\0' ;  // truncate filename leaving just subdir.
   }
   while(EnumFilesInDirectory(dsBuffer, NULL));  //  findNext

   return(TRUE);
}




//------------------*EnumFilesInDirectory*------------------------
// Action: return pointer to a filename residing in specified
//         directory conforming to fileSpec.
//         On successive calls, pass in a NULL pointer
//         for filespec.  Then dosFindNext is used to
//         enumerate other filenames (if any) 
//
// Return: A far pointer to lpDir which contains the dir + file name 
//       if successful, NULL if not.
//       this memory will be overwritten the next time function
//       is called.
//
// Warning:  caller supplied lpDirectory must lie in local DS seg
//          if using small Data Model.
//---------------------------------------------------------------------
LPBYTE NEAR PASCAL EnumFilesInDirectory(LPSTR lpDirectory,
                    LPSTR fileSpec)
{
   static struct _find_t fileinfo;

   if(!lpDirectory)
      return(NULL);  // forgot to pass in directory.
   if(fileSpec)
   {
      WORD  length;
      BOOL  bDone;

      length = lstrlen(lpDirectory);
      appendPath(lpDirectory, fileSpec);
#ifdef ADOBE_DRIVER
      if (sizeof(char *) == 4)
      {
          bDone=(BOOL)_dos_findfirst(lpDirectory,
                                     _A_RDONLY, &fileinfo);
      }
      else
#endif
      {
          bDone=(BOOL)_dos_findfirst((char *)OFFSETOF(lpDirectory),
                                     _A_RDONLY, &fileinfo);
      }

      lpDirectory[length] = '\0' ; // restore lpDirectory

      if(bDone)
    return(NULL); //  failed
   }
   else if (_dos_findnext(&fileinfo))
     return(NULL);
   appendPath(lpDirectory, (LPSTR)fileinfo.name);
   return(lpDirectory);
}



/*  note:  the string modelName will have a comma
   tacked onto them.  this function
   does not expect modelName to already be comma terminated  */

WORD   NEAR  PASCAL  addIndexEntry(
   LPBYTE  modelName,
   LPBYTE  dsBuffer,
   LPINDEXMAP  lpIndexmap,
   WORD    numEntries ,
   LPBYTE  lpStringTable)
{
   WORD   i, length;
   static  LPBYTE  lpCurPos;

   if(!numEntries)
      lpCurPos = lpStringTable ;  // point to start of string table
   
   length = lstrlen(modelName);
   modelName[length++] = ',';   // tack on a comma
   modelName[length] = '\0';

   //  check for duplication
   for(i = 0 ; i < numEntries ; i++)
   {
      if(!pwstrncmp(modelName, 
        (LPBYTE)MAKELONG(lpIndexmap[i].specifierOffset, 
        HIWORD(lpStringTable)), length)  )
     return(numEntries);  // model name already exists
   }
   //  add entry to table.

   lpIndexmap[numEntries].specifierOffset = OFFSETOF(lpCurPos);
   lpCurPos = pwstrcpy(lpCurPos, modelName);  //  comma already included
   lpIndexmap[numEntries].filenameOffset = OFFSETOF(lpCurPos);
   lpCurPos = pwstrcpy(lpCurPos, dsBuffer);
   lpCurPos = pwstrcpy(lpCurPos, "\r\n");
   *lpCurPos = '\0' ;  //  NULL terminate so strlen can be determined.
   return(++numEntries);
}



WORD  NEAR  PASCAL  pwstrncmp(
LPBYTE    lpStr1 ,
LPBYTE    lpStr2 ,
WORD   count )
{
   while(count--)  
   {
      if(*lpStr1++ != *lpStr2++)
     return(1);  // no match;
   }
   return(0) ;    // match;   
}


/*  copies srcString to destBuf and returns position in destBuf
   immediately after last byte copied (No NULL termination added) */

LPBYTE    NEAR  PASCAL  pwstrcpy(
LPBYTE    destBuf,
LPBYTE    srcString )
{
   while(*srcString)
      *destBuf++ = *srcString++ ;
   return(destBuf);
}


#ifndef ADOBE_DRIVER
BOOL   NEAR  PASCAL  extractWPXmodelName(
LPBYTE   lpModelName ,  //  fills in this string.  Caller must supply
            //  large enough buffer.
LPBYTE   lpFileName  ,  //  briefly opens this for reading.
WORD     Bufsize )      //  size of lpModelName .
{
   long  fileLoc;
   HFILE  hfile ;
   WORD   count ;
   WPX_HEADER  wpxHeader;   // table of contents for wpx file.
   PRINTERINFO  PrinterInfo;

   lpModelName[0] = '\0' ;  //  NULL terminate string

   count = sizeof(WPX_HEADER);
   hfile = _lopen(lpFileName, READ | OF_SHARE_DENY_WRITE);
   if(hfile == HFILE_ERROR) 
   {
      errorMsg(EXTRACTWPXMODELNAME, ERR_FILE_READACCESS) ;
      errorString(lpFileName);
      return(FALSE);
   }

   if(count != _lread(hfile, &wpxHeader,  count))
   {
      errorMsg(EXTRACTWPXMODELNAME, ERR_FILE_READ_FAILED) ;
      errorMsg(EXTRACTWPXMODELNAME, ERR_READING_WPX_HEADER) ;
      errorString(lpFileName);
      goto  abortExtractWPX;
   }

   //  locate  and read in PRINTINFO struct

   _llseek(hfile, wpxHeader.PrinterInfo_loc, 0);   //  seek to pos byte

   count = sizeof(PRINTERINFO);

   if(count != _lread(hfile,  &PrinterInfo, count))
   {
      errorMsg(EXTRACTWPXMODELNAME, ERR_FILE_READ_FAILED) ;
      errorMsg(EXTRACTWPXMODELNAME, ERR_READING_WPX_PRINTINFO) ;
      errorString(lpFileName);
      goto  abortExtractWPX;
   }

   if(PrinterInfo.versionNum != WPXVERSION)
   {
      errorMsg(EXTRACTWPXMODELNAME, ERR_INCOMPATIBLE_WPX_VER) ;
      goto  abortExtractWPX;
   }

   fileLoc =  wpxHeader.stringtab_loc;  //  strings table
   fileLoc += PrinterInfo.modelname.w.offset;  

   _llseek(hfile, fileLoc, 0);   //  seek to pos byte

   count = PrinterInfo.modelname.w.length;
   if(Bufsize <= count)
   {
      errorMsg(EXTRACTWPXMODELNAME, ERR_BUFFER_OVERFLOW) ;
      errorMsg(EXTRACTWPXMODELNAME, ERR_MODELNAME_TOO_LONG) ;
      goto  abortExtractWPX;
   }
   if(count != _lread(hfile, lpModelName,  count))
   {
      errorMsg(EXTRACTWPXMODELNAME, ERR_FILE_READ_FAILED) ;
      errorMsg(EXTRACTWPXMODELNAME, ERR_READING_MODELNAME) ;

      goto  abortExtractWPX;
   }
   
   lpModelName[count] = '\0' ;  //  NULL terminate string

abortExtractWPX:

   _lclose(hfile);
   if(lpModelName[0])
      return(TRUE);  // Modelname found!
   return(FALSE);
}



BOOL   NEAR  PASCAL  appendEntryToIndex(
LPBYTE  lpModelName,
LPBYTE  lpFileName,
LPBYTE  lpIndex )
{
   BOOL   status;
   OFSTRUCT   OpenBuf ;  // for OpenFile()
   WORD   count;
   HFILE  indexFile ;


   status = FALSE;  
   indexFile = OpenFile(lpIndex, &OpenBuf, OF_WRITE | OF_SHARE_DENY_WRITE);

   if(indexFile == HFILE_ERROR) 
   {
      indexFile = OpenFile(lpIndex, &OpenBuf, OF_CREATE | OF_WRITE | OF_SHARE_DENY_WRITE);

      if(indexFile == HFILE_ERROR)
     goto   abortAppendEntry;
   }
   _llseek(indexFile, 0L, 2);   //  seek end of file - append new entries

   if(count != _lwrite(indexFile, lpModelName,  count = lstrlen(lpModelName)))
      goto   abortAppendEntry;

   if(count != _lwrite(indexFile, ",",  count = 1))
      goto   abortAppendEntry;

   if(count != _lwrite(indexFile, lpFileName,  count = lstrlen(lpFileName)))
      goto   abortAppendEntry;

   if(count != _lwrite(indexFile, "\r\n",  count = 2))
      goto   abortAppendEntry;


   status = TRUE;

abortAppendEntry:
   if(indexFile != HFILE_ERROR)
      _lclose(indexFile);

   if(status == FALSE)
   {
      errorMsg(APPENDENTRYTOINDEX, ERR_APPENDING_ENTRY) ;
   }
   return(status);
}

#endif
/*  lpModelName is caller supplied, 
   lpFileName is set by caller to point to subdir
   the new WPX file should be placed in.  Upon successful
   return, it is appended with the name of the WPX file,
   generating a full pathname.  */

BOOL NEAR PASCAL  
createWPXfile(LPBYTE lpModelName, LPBYTE lpFileName, 
              LPBYTE lpIndexSubDir,  // the subdir where indicies are found.
              WORD   wBufSize )      // Length of buffer containing pathname
{
   if(createWPXfileFromPPDs(lpModelName, lpFileName, lpIndexSubDir))
      return(TRUE);  // success
   if(ConvertOldWPD(lpModelName, lpFileName, wBufSize))
      return(TRUE);  // success
   return(FALSE);
}


#ifdef ADOBE_DRIVER
static char FILEMAN1SEG achDriverSubKey[] = "System\\CurrentControlSet\\Control\\Print\\Environments\\Windows 4.0\\Drivers\\";
static char FILEMAN1SEG achWPXKey[]       = "WPX File";
static char FILEMAN1SEG achPPDKey[]       = "Data File";
static char FILEMAN1SEG achHelpKey[]      = "Help File";
static char FILEMAN1SEG achDriverKey[]    = "Driver";

/****************************************************************************/
/* static LONG NEAR PASCAL GetFieldFromModelName
**
** Description:     Returns one of the strings from the printer models's
**                  registry entry. This can be "Configuration File", 
**                  "Data File", "Data Type", "Dependent Files",
**                  "Driver", "Help File", "Monitor", or "WPX File".
**
**                  The resulting string is placed in <lpString> which
**                  is a max <wBufSize> bytes long.
**
** Returns:         number of bytes placed in buffer. 0 error.
*/
static LONG NEAR PASCAL
GetFieldFromModelName(LPBYTE lpModelName, LPBYTE achKey, LPBYTE lpString, WORD wBufSize)
{
    char    achSubKey[512];
    HKEY    hKey;
    LONG    cb = 0;
    LONG    lResult;
                        
    lstrcpy(achSubKey, achDriverSubKey);
    lstrcat(achSubKey, lpModelName);
    lResult = RegOpenKey(HKEY_LOCAL_MACHINE, achSubKey, &hKey);
    if (lResult == ERROR_SUCCESS) 
    {    
        cb = (long)wBufSize;       
        lResult = RegQueryValueEx(hKey, achKey, NULL, NULL, 
                                  (LPBYTE)lpString, (LPDWORD)&cb);
        if (ERROR_SUCCESS != lResult) 
            cb = 0;
        RegCloseKey(hKey);
    }                
    return(cb);
}    

LONG FAR PASCAL 
GetPPDNameFromModelName(LPBYTE lpModelName, LPBYTE lpPPDName, WORD wBufSize)
{
    return(GetFieldFromModelName(lpModelName, achPPDKey, lpPPDName, wBufSize));
}    

LONG NEAR PASCAL 
GetWPXNameFromModelName(LPBYTE lpModelName, LPBYTE lpWPXName, WORD wBufSize)
{
    return(GetFieldFromModelName(lpModelName, achWPXKey, lpWPXName, wBufSize));
}

LONG PASCAL 
GetHelpNameFromModelName(LPBYTE lpModelName, LPBYTE lpHelpName, WORD wBufSize)
{
    return(GetFieldFromModelName(lpModelName, achHelpKey, lpHelpName, wBufSize));
}    

LONG PASCAL 
GetDriverNameFromModelName(LPBYTE lpModelName, LPBYTE lpDriverName, WORD wBufSize)
{
    return(GetFieldFromModelName(lpModelName, achDriverKey, lpDriverName, wBufSize));
}
    

/****************************************************************************/
/* LONG PASCAL GetIniCreatorFromModuleName
**
** Description:     Returns a string like "ADOBEPS.DRV Version 4.1" which
**                  is used in the creater field of the postscript output
**                  job.
*/
LONG PASCAL
GetIniCreatorFromModelName(LPBYTE lpModelName, LPBYTE lpIniCreatorName, WORD wBufSize)
{
    char    *sp1, *sp2, szVersionStr[128];
    char    szDrvFullName[PATHSIZE];
    
    *lpIniCreatorName = 0;
    szDrvFullName[0]='\0';
                                                            /* adobeps.drv */
    if (GetDriverNameFromModelName(lpModelName, lpIniCreatorName, wBufSize)) 
    {
        //lpIniCreator has only the driver name, we need the full path to get version: see bug 199236
        // So, use the original Driver's full path fileanme to get the version:
        GetModuleFileName(ghDriverMod, szDrvFullName, PATHSIZE-1);

        if (ProdVersionStr(szDrvFullName, szVersionStr)) 
        {
            lstrcat(lpIniCreatorName, " Version ");
            if (sp1 = strchr(szVersionStr, '.')) 
            {
                if (sp2 = strchr(sp1+1, '.'))   /* version str is "4.10.147 */
                    *sp2 = 0;                   /* reduce to "4.10          */
            }
            lstrcat(lpIniCreatorName, szVersionStr);
  
        }
    }
    return(lstrlen(lpIniCreatorName));
}

        
// Check to see if the file exist in the specify lpszDir.
// lpszDir will have the full path after the function returns.
BOOL 
IsFileExist(LPSTR lpszDir, LPSTR lpszFile)
{
    BOOL    bRetVal = FALSE;
    struct _find_t fileinfo;

    if(!lpszDir)
        return(FALSE);                      // forgot to pass in directory.
      
    if(lpszFile)
    {
        appendPath(lpszDir, lpszFile);
        if (sizeof(char *) == 4)
            bRetVal = (BOOL)(_dos_findfirst(lpszDir, _A_RDONLY, &fileinfo) == ERROR_SUCCESS);
        else
            bRetVal = (BOOL)(_dos_findfirst((char *)OFFSETOF(lpszDir), _A_RDONLY, &fileinfo) == ERROR_SUCCESS);
    }
    return bRetVal;        
}

BOOL NEAR PASCAL 
GetPPDFileNameEx(LPSTR lpszModelName, LPSTR lpszPPDFileName, WORD wSize)
{
    BOOL    bRetVal = FALSE;
    CHAR    szDir[_MAX_PATH];
        
    if (GetPPDNameFromModelName(lpszModelName, lpszPPDFileName, wSize))
    {
        if(GetDriverDirectory(szDir, sizeof(szDir)))
            bRetVal = IsFileExist(szDir, lpszPPDFileName);
        if (!bRetVal) 
        {   
            if (GetWindowsDirectory(szDir, sizeof(szDir)))
                bRetVal = IsFileExist(szDir, lpszPPDFileName);
        }            
    }
    
    if (bRetVal)
    {
        lstrcpy(lpszPPDFileName, szDir);
    }
    else
    {
       // if PPD doesn't exist, use default PPD
       char  szDefault[16];

       LoadString(ghDriverMod, IDS_DEFAULTPPD, szDefault, sizeof(szDefault));
       GetDriverDirectory(szDir, sizeof(szDir));
       lstrcpy(lpszPPDFileName, szDir);
       lstrcat(lpszPPDFileName, "\\");  
       lstrcat(lpszPPDFileName, szDefault);  
       bRetVal = 1;
    }
    return(bRetVal);    
}

BOOL NEAR PASCAL 
IsWPXFileExist(LPSTR lpszModelName, LPSTR lpszWPXFileName, WORD wSize)
{
    char    szFileName[256];
    BOOL    bRetVal = FALSE;
                    
    if (GetWPXNameFromModelName(lpszModelName, szFileName, sizeof(szFileName)))
    {                             /* appends <szFileName> to windows dir    */
        if (GetWindowsDirectory(lpszWPXFileName, wSize))
            bRetVal = IsFileExist(lpszWPXFileName, szFileName);
    }
    return(bRetVal);
}
/*  static BOOL NEAR PASCAL IsUniqueWPXName

    Returns TRUE if the given WPX name is unique. This means that it is
    found neither under the "WPX File" entries of all of the printer 
    drivers currently in the registry.
    
    Also checks colision with "Data File" entry -- which is the name of the
    PPD/SPD file -- to insure that we don't overlap a PSCRIPT installed PPD.

    Does not check for existing files by this name in the windows directory
    because they are not deleted when the printer is removed. This function
    makes the assumption that nobody else is going to be creating wpx files.
*/
static BOOL NEAR PASCAL
IsUniqueWPXName(LPSTR lpszWPXName)
{
    long    len, idx = 0;
    char    szDriver[256], szValue[256];
    HKEY    hKey, hKeyDrv;
    BOOL    bRet = TRUE;
    
    if (RegOpenKey(HKEY_LOCAL_MACHINE, achDriverSubKey, &hKey) == ERROR_SUCCESS) {
        while(RegEnumKey(hKey, idx++, szDriver, sizeof(szDriver)) == ERROR_SUCCESS) {
            if (RegOpenKey(hKey, szDriver, &hKeyDrv) == ERROR_SUCCESS) {
                len = sizeof(szValue);
                if (RegQueryValue(hKeyDrv, achWPXKey, szValue, &len) == ERROR_SUCCESS) {
                    if (!lstrcmp(szValue, lpszWPXName))
                        bRet = FALSE;                       /* not unique   */
                }
                else {
                    len = sizeof(szValue);
                    if (RegQueryValue(hKeyDrv, achPPDKey, szValue, &len) == ERROR_SUCCESS) {
                        if (!lstrcmp(szValue, lpszWPXName))
                            bRet = FALSE;                   /* not unique   */
                    }
                }
                RegCloseKey(hKeyDrv);
            }
            if (!bRet)
                break;
        }
        RegCloseKey(hKey);
    }
    return(bRet);
}
/*  static void ModPPDName

    modifies a ppd name by changing bumping up the last
    character of that name. Used to obtain a unique ppd
    name
*/
static void  
ModPPDName(LPSTR lpszName, LPSTR *ppMod)
{
    BOOL    bDec;
    LPSTR   pMod = *ppMod;

    for (bDec = FALSE; pMod > lpszName;) {
        if (isalpha(*(pMod)))
            bDec = (*(pMod) == 'z' || *(pMod) == 'Z');
        else if (isdigit(*(pMod)))
            bDec = (*(pMod) == '9');
        else if (*pMod == '$')
            *pMod = 'A' - 1;
        else bDec = TRUE;
                
        if (bDec) {
            *ppMod--;
            pMod--;
        }
        else
            break;
    }
    *(pMod) += 1;                           /* bump up unique character     */
}

/*  static BOOL CreateUniqueWPXName

    Called when no WPX name has been determined for this piticular printer.
    In other words, the "WPX File" entry in the printer driver registry
    entry was empty. Based initially upon a psuedo random value obtained
    from the timer. It scans all of the other printer driver registry entries 
    in order to make sure that this "WPX File" name is unique, and increments 
    it by one character as needed. The unique name is placed into the registry 
    before returning.

    When called on a printer driver that allready has a "WPX File" entry,
    that original entry is deleted.   
*/ 
static BOOL 
CreateUniqueWPXName(LPSTR lpszModelName)
{
    char    szWPXName[256];
    char    achSubKey[512];
    HKEY    hKey;
    LONG    cb = 0;
    LONG    lResult;
    int     safety = 0;
    LPSTR   pMod;
    int     bRet = FALSE;

                                    /****************************************/
                                    /* remove any existing wpx key of driver*/
                                    /****************************************/

    if (GetWPXNameFromModelName(lpszModelName, szWPXName, sizeof(szWPXName))) {
        lstrcpy(achSubKey, achDriverSubKey);
        lstrcat(achSubKey, lpszModelName);
        lResult = RegOpenKey(HKEY_LOCAL_MACHINE, achSubKey, &hKey);
        if (lResult == ERROR_SUCCESS) {
            RegDeleteKey(hKey, achWPXKey);
            RegCloseKey(hKey);
        }
    }                
        
                                    /****************************************/
                                    /* generate a psuedo unique name by     */
                                    /* filling start of name with '$'.      */
                                    /****************************************/

    wsprintf(szWPXName, "%08lx.wpx", GetTickCount());
    *szWPXName = '$';                           /* first char set to '$'    */
    
    pMod = lstrchr(szWPXName, '.') - 1;         /* last char before the '.' */
        
    while(safety++ < 100) {
        if (IsUniqueWPXName(szWPXName))
            break;
        ModPPDName(szWPXName, &pMod);
    }
                                    /****************************************/
                                    /* write unique WPX name into registry  */
                                    /****************************************/

    lstrcpy(achSubKey, achDriverSubKey);
    lstrcat(achSubKey, lpszModelName);
    if (RegOpenKey(HKEY_LOCAL_MACHINE, achSubKey, &hKey) == ERROR_SUCCESS) {
        RegSetValueEx(hKey, achWPXKey, 0, REG_SZ, szWPXName, lstrlen(szWPXName)+1);
        RegCloseKey(hKey);
        bRet = TRUE;
    }   
    return(bRet); 
}
#endif

BOOL FAR PASCAL 
GetPPDFileName(LPBYTE lpModelName, LPBYTE lpPPDFileName, WORD wSize,
               LPBYTE  lpIndexSubDir)
{   
#ifdef ADOBE_DRIVER
    return(GetPPDFileNameEx(lpModelName, lpPPDFileName, wSize));
#else
    appendPath(lpIndexSubDir, "ppdindex.lst");

                        // init PPDName  if any can be found.
    if(!extractFileNameFromIndex(lpModelName, lpPPDFileName, 
                                 wSize, lpIndexSubDir))
    {
        if(!indexPPDs(lpIndexSubDir))
            return(FALSE);          // can't even create an index. give up now.
        if(!extractFileNameFromIndex(lpModelName, lpPPDFileName, 
                                    _MAX_PATH, lpIndexSubDir))
            return(FALSE);          // can't find PPD file. give up now.
   }
    return(TRUE);
#endif
}


BOOL NEAR  PASCAL  
createWPXfileFromPPDs(LPBYTE lpModelName, LPBYTE lpFileName, LPBYTE lpIndexSubDir)
{
    BYTE    PPDName[_MAX_PATH];  // will contain path to root ppd file.

    if (!GetPPDFileName(lpModelName, PPDName, _MAX_PATH, lpIndexSubDir))
        return(FALSE);

#ifdef ADOBE_DRIVER 
                        // ADOBEPS: WPX file is verified to be unique 
                        // reguardless of initial PPD name that is used
    {                   // WPX name for this modelname held in registry
        char   szWPXName[_MAX_PATH];

        if (!GetWPXNameFromModelName(lpModelName, szWPXName, sizeof(szWPXName))) {
            CreateUniqueWPXName(lpModelName);   /* result left in registry  */
            if (!GetWPXNameFromModelName(lpModelName, szWPXName, sizeof(szWPXName)))
                return(FALSE);    
        }
        appendPath(lpFileName, szWPXName);  /* append to windows dir name   */
    }
#else
                        //  PSCRIPT: WPX file takes on the same filename as 
                        //  the PPD file but with a wpx extension.

    appendPath(lpFileName, filenameonly(PPDName));
    lstrcat(lpFileName, ".wpx") ;
#endif
                        //  lpFileName now contains the full path for the 
                        //  soon to be created WPX file.


   if(createWPXfileFromPPDnow(PPDName, lpFileName))
      return(TRUE);  // success
   return(FALSE);    // failed
}

#ifndef ADOBE_DRIVER
//  return value indicates if index file was
//  created.  Failure is a fatal error since
//  driver and rest of make WPX code depends on it.


BOOL NEAR  PASCAL  
indexPPDs(LPBYTE lpIndexPath)  // caller supplies full path and name of idx.
                               // and of course verifies subdir is writable.
{
   static  BYTE    dsBuffer[_MAX_PATH];
   static  BOOL    done = FALSE ;

   BOOL  status = FALSE;
   LPBYTE  lpStringTable ;
   LPINDEXMAP  lpIndexmap;
   WORD    numEntries;   // check to see if max limit was reached.

   // possible errors:  overflow indexmap

   if(done)
      return(TRUE);  // don't waste time rebuilding indicies.
   done = TRUE;

   // allocate 2 blocks of memory

   lpIndexmap = (LPINDEXMAP)GlobalAllocPtr(GHND, MAXINDEXENTRIES * sizeof(INDEXMAP)); 
   if(!lpIndexmap)
      goto  endIndexPPDs;

   lpStringTable = GlobalAllocPtr(GHND, 0x10000L);
   if(!lpStringTable)
      goto  endIndexPPDs;

   numEntries = 0 ;

   //  create four paths that PPDs can be found in, starting with
   //  highest priority first.
   GetWindowsDirectory(dsBuffer,_MAX_PATH);
//   appendPath(dsBuffer, "pscript");
   if(_access(dsBuffer, 0))  // zero return means exists
      goto PPDsubdir2;


   status = indexSubDir(dsBuffer, "*.ppd", lpIndexmap, &numEntries, 
               lpStringTable, extractPPDmodelName) ;
   if(!status)
      goto  endIndexPPDs;
   status = indexSubDir(dsBuffer, "*.spd", lpIndexmap, &numEntries, 
               lpStringTable, extractPPDmodelName) ;
   if(!status)
      goto  endIndexPPDs;


PPDsubdir2:


   GetDriverDirectory(dsBuffer, _MAX_PATH);

//   appendPath(dsBuffer, "pscript");
   if(_access(dsBuffer, 0))  // zero return means exists
      goto PPDsubdir3;

   status = indexSubDir(dsBuffer, "*.ppd", lpIndexmap, &numEntries, 
               lpStringTable, extractPPDmodelName) ;
   if(!status)
      goto  endIndexPPDs;
   status = indexSubDir(dsBuffer, "*.spd", lpIndexmap, &numEntries, 
               lpStringTable, extractPPDmodelName) ;
   if(!status)
      goto  endIndexPPDs;


PPDsubdir3:

   
   status = TRUE;  // if you got to this point.
    

   //  this block just restricts scope of local variables
   {  //  writing stringTable to file.
      WORD   count;
      OFSTRUCT   OpenBuf ;  // for OpenFile()
      HFILE  hIndex ;  //  holds handle to Index file

      hIndex = OpenFile(lpIndexPath, &OpenBuf, 
          OF_CREATE | OF_WRITE | OF_SHARE_DENY_WRITE);

      if(numEntries)  
      {

     count =  lpIndexmap[numEntries-1].filenameOffset - OFFSETOF(lpStringTable);
     count += lstrlen((LPBYTE)MAKELONG(lpIndexmap[numEntries-1].filenameOffset, 
                      HIWORD(lpStringTable)));
     if(count != _lwrite(hIndex, lpStringTable,  count))
     {
        errorMsg(INDEXPPDS, ERR_FILE_WRITE_FAILED) ;
        errorMsg(INDEXPPDS, ERR_CREATING_PPD_INDEX) ;
        status = FALSE;
     }
      }
      else
      {
     errorMsg(INDEXPPDS, ERR_CANT_FIND_PPD_FILES) ;
      }

      _lclose(hIndex);
   }

endIndexPPDs:

   if(lpIndexmap)
      GlobalFreePtr(lpIndexmap);

   if(lpStringTable)
      GlobalFreePtr(lpStringTable);   
   return(status);
}





BOOL   NEAR  PASCAL  extractPPDmodelName(
LPBYTE   lpModelName ,  //  fills in this string.  Caller must supply
            //  large enough buffer.
LPBYTE   lpFileName  ,  //  briefly opens this for reading.
WORD     Bufsize  )     //  size of lpModelName .
{
   HPBYTE  hpCur, hpBuf ;  // Points to very start of buffer (offset zero)
   long    i, fileSize ;  // total size of buffer.
   WORD   refLen, j,
       strikes = 0 ;  //  get three passes through code 

   LPBYTE  refStr  ;

   lpModelName[0] = '\0' ;  //  NULL terminate string

   hpBuf = ReadFileIntoHBuf(lpFileName, &fileSize);
   if(!hpBuf)
      return(FALSE);  // can't read in PPD file!

   while(1)
   {

      switch  (strikes)
      {
     case (0):
        refStr = "*ShortNickName:" ;
        break;
     case (1):
        refStr = "*ModelName:" ;
        break;
     case (2):
        refStr = "*NickName:" ;
        break;
     case (3): 
        goto  abortExtractPPD;
      }
      refLen = lstrlen(refStr);
      strikes++;

      //  scan for keyword "*ModelName:" or "*NickName:"
      for(i = 0 ; i < fileSize ; i++)
      {
     if(  hpBuf[i] == '*'  &&  (!i || 
           hpBuf[i-1] == 10 || hpBuf[i-1] == 13 )) //  start of newline
     {  // every keyword will be preceeded by newline except the
        // one at i = 0.
        for(j = 0 ; j < refLen ; j++)
        {
           if(hpBuf[i+j] != refStr[j])
          break;
        }
        if(j < refLen)
           continue;  //  didn't match.

        hpCur = hpBuf+i+j;  // points just after colon.
        hpCur = extractQuotedLiteral(&hpCur, FALSE);
        if(!hpCur)
        {
           errorMsg(EXTRACTPPDMODELNAME, ERR_INDEXING_PPD);
           errorMsg(EXTRACTPPDMODELNAME, ERR_PPD_SYNTAX_MODELNAME);
           errorString(hpBuf+i+j);

           goto  abortExtractPPD;
        }

        addQuotedStringToTable(hpCur, lpModelName, Bufsize);
        goto  abortExtractPPD;  // success!
     }
     // continue drops you here at bottom of for loop.
      }
   }

abortExtractPPD:

   if(hpBuf)
   {
      GlobalFreePtr(hpBuf);   
   }
   if(lpModelName[0])
      return(TRUE);  // Modelname found!
   return(FALSE);
}

#endif

/*  this function returns a pointer to a small static buffer
   which will contain only the 8 char filename (w/o ext)
   portion of the supplied fullPathName  - will obviously be
   overwritten by the next call  */

LPBYTE  NEAR  PASCAL  filenameonly(
LPBYTE  fullPathName )
{
   static  BYTE  filename[9];
   WORD   length, i, j;

   length = lstrlen(fullPathName);

   for(i = length ; i ; i--)
   {
      if(fullPathName[i] == '\\')
     break;
   }
   i++ ;
   for(j = 0 ; fullPathName[i+j] && fullPathName[i+j] != '.'; j++)
      filename[j] = fullPathName[i+j] ;

   filename[j] = '\0' ;
   return(filename);
}




static  HFILE  errfile = HFILE_ERROR ;  //  holds error log file
          //  only the following functions should
          //  be aware of its existence.




/*  writes error string or error Message to error log file.  
   caller may pass far or huge pointer to string
   or a resource stringID. */

VOID  FAR   PASCAL  errorMsg(
WORD     function,
WORD     error)
{
   BYTE  buffer[20];

   if(errfile == HFILE_ERROR)
      return;

   wsprintf(buffer, "\r\n%d: %d", function, error);
   _lwrite(errfile, buffer, lstrlen(buffer)) ;
}


VOID  FAR   PASCAL  errorString(
HPBYTE     string)
{
   BYTE  buffer[80], let;
   LPBYTE  lpPtr;
   int  i;

   if(!string  ||  errfile == HFILE_ERROR)
      return;

   lpPtr = buffer ;

   *lpPtr++ = ' ';
   *lpPtr++ = '>';

   for(i = 0 ; i < 75 ; i++)
   {
      let = *string++ ;
      if(!let  ||  let == '\n' ||  let == '\r')
     break;
      *lpPtr++ = let ;
   }

   *lpPtr = '\0' ;

   _lwrite(errfile, buffer, lstrlen(buffer)) ;
}




/*  this is the entry point to the DLL  
   the caller passes in a pointer to the ModelName it
   wishes to obtain a WPX file for and this function
   will write the full pathname of the WPX file in the
   caller supplied buffer - lpFileName.  The caller also
   supplies Bufsize, which obtainWPXfile uses to avoid
   overwriting lpFileName.  The return value indicates
   the version of the WPX files generated by this DLL, or
   NULL if we fail.
   If difficulties are encountered reading the WPX file provided by
   this call, the caller should delete the offending WPX file and
   call obtainWPXfile a second time. This gives obtainWPXfile an
   opportunity to rebuild the WPX file from lower level sources.
   If that fails to resolve the situation, default to another
   WPX file.
*/

WORD FAR PASCAL  
obtainWPXfile(LPBYTE lpModelName, LPBYTE  lpFileName ,
              WORD   Bufsize,     // size of lpFileName  (dest buffer)
              BOOL   bNukeIndex)  // If true, force rebuild (delete WPX index)
{  
   static  BYTE    dsSubdir[_MAX_PATH];  // will be filled by verifyTree
   // these don't need to be static, but just to reduce the
   // demand on stack space.
   static  BYTE    wpxindex[_MAX_PATH];
   static  BYTE    root[_MAX_PATH];      //  points to writable root of pscript subtree
   WORD    status = NULL;
   WORD    length;  

   OFSTRUCT   OpenBuf ;  // for OpenFile()
   
   if(!verifyTree(dsSubdir))      // requires arg to reside in DS.
      return(NULL);  // can't even create errorlog yet!
      
   // dsSubdir is now initialized to writable root of pscript subtree.
   lstrcpy(root, dsSubdir);                     

   length = lstrlen(dsSubdir);  // allows this path to be restored.

#ifndef ADOBE_DRIVER
   lstrcpy(wpxindex, dsSubdir);
   appendPath(wpxindex, "wpxindex.lst");

   if(bNukeIndex)
      remove(wpxindex);
   else if (extractFileNameFromIndex(lpModelName, lpFileName, Bufsize, wpxindex))
      return (WPXVERSION);
#else
    if (!bNukeIndex && IsWPXFileExist(lpModelName, lpFileName, Bufsize))
        return WPXVERSION;
#endif

   appendPath(dsSubdir, "wpxerror.log");  

   errfile = OpenFile(dsSubdir, &OpenBuf, OF_WRITE | OF_SHARE_DENY_WRITE);

   if(errfile == HFILE_ERROR) 
   {
      errfile = OpenFile(dsSubdir, &OpenBuf, OF_CREATE | OF_WRITE | OF_SHARE_DENY_WRITE);

      if(errfile == HFILE_ERROR) 
        return(NULL);  //  Can't even write an error message!
   }
   _llseek(errfile, 0L, 2);   //  seek end of file - append new entries
   errorString(lpModelName);  //  identify modelname involved.

   dsSubdir[length] = '\0';  //  restore to root of tree.

#ifndef ADOBE_DRIVER
   if(!indexWPXs(wpxindex))
   {
      errorMsg(OBTAINWPXFILE, ERR_CREATING_WPX_INDEX);
      status = NULL;
      goto   exitDLL;
   }

   if(extractFileNameFromIndex(lpModelName, lpFileName, Bufsize, wpxindex))
   {
      status = WPXVERSION;
      goto   exitDLL;
   }
#endif
   // dsSubdir points to subdir where you want wpx file to reside!

   // if this function succeeds, dsSubdir will have wpxfilename tacked on
   if(!createWPXfile(lpModelName, dsSubdir, root, Bufsize) )
   {
      errorMsg(OBTAINWPXFILE, ERR_CREATING_WPX_FILE);
      errorString(lpModelName);
      status = NULL;   // don't have the sources to create a WPX!
      goto   exitDLL;
   }

#ifndef ADOBE_DRIVER
   // at this point, dsSubdir contains full path to newly created wpx file.
   if(appendEntryToIndex(lpModelName, dsSubdir, wpxindex))
      status = WPXVERSION;
#else
      status = WPXVERSION;      
#endif

   lstrcpy(lpFileName, dsSubdir);
exitDLL:
   if(!status)
   {
      errorMsg(OBTAINWPXFILE, ERR_CREATING_WPX_FILE);
      errorString(lpModelName);
   }
   // close errorlog
   _lwrite(errfile, "\r\n", 2) ;
   _lclose(errfile);
   errfile = HFILE_ERROR ;

#ifdef ADOBE_DRIVER
   {
    HANDLE hOemCust = NULL;

    if (status != 0)
    {
        char PCFileName[14];

        if (GetPCFileNameFromWPX(dsSubdir, PCFileName))
        {                        
            hOemCust = AdobeOEMInitDllStub(NULL, PCFileName, DLL_TYPE_OEM_CUST, DEVINSTALL);
            if (hOemCust) {
                AdobeOEMDevInstallStub(hOemCust,NULL,lpModelName,NULL,NULL);
                AdobeOEMTermDllStub(hOemCust);
            }
        }    
     }
   }
#endif

   return(status);
}


/* PFM File Indexing */

#define _FONT_NO_FPROTO_
#include "fonthdr.h"

BOOL   NEAR  PASCAL  extractPFMfaceName(
LPBYTE   lpFaceName ,   //  fills in this string.  Caller must supply
            //  large enough buffer.
LPBYTE   lpFileName  ,  //  briefly opens this for reading.
WORD     Bufsize  )     //  size of lpFaceName .
{
   HPBYTE  hpCur, hpBuf ;  // Points to very start of buffer (offset zero)
   long    i, fileSize ;   // total size of buffer.
   LPPFMEXTENSION lpPFMExt;

   lpFaceName[0] = '\0';   // Null terminate lpFaceName

   hpBuf = ReadFileIntoHBuf(lpFileName, &fileSize);
   if(!hpBuf)
      return(FALSE);  // can't read in PFM file!

   lpPFMExt = (LPPFMEXTENSION) (hpBuf + sizeof(PFMPROLOG) + sizeof(PFMHEADER));
   hpCur = hpBuf + lpPFMExt->dfDriverInfo;
   i = 0;
   while (*hpCur)
      lpFaceName[i++] = *hpCur++;
   lpFaceName[i] = '\0';

   return TRUE;
}

BOOL  FAR  PASCAL  indexPFMs(
LPBYTE   lpIndexPath )  // caller supplies full path and name of index.
            // and of course verifies subdir is writable.
{
   static  BYTE    dsBuffer[_MAX_PATH];
   static  BOOL    done = FALSE ;

   BOOL  status = FALSE;
   LPBYTE  lpStringTable ;
   LPINDEXMAP  lpIndexmap;
   WORD    numEntries;   // check to see if max limit was reached.

   // possible errors:  overflow indexmap

   if(done)
      return(TRUE);  // don't waste time rebuilding indicies.
   done = TRUE;

   // allocate 2 blocks of memory

   lpStringTable = NULL;

   lpIndexmap = (LPINDEXMAP)GlobalAllocPtr(GHND, MAXINDEXENTRIES * sizeof(INDEXMAP)); 
   if(!lpIndexmap)
      goto  endIndexPFMs;

   lpStringTable = GlobalAllocPtr(GHND, 0x10000L);
   if(!lpStringTable)
      goto  endIndexPFMs;

   numEntries = 0 ;

   //  create two paths that PFMs can be found in starting with the
   //  highest priority first.
   GetWindowsDirectory(dsBuffer,_MAX_PATH);

   status = indexSubDir(dsBuffer, "*.pfm", lpIndexmap, &numEntries, 
               lpStringTable, extractPFMfaceName) ;
   if(!status)
      goto  endIndexPFMs;

   GetDriverDirectory(dsBuffer, _MAX_PATH);

   status = indexSubDir(dsBuffer, "*.pfm", lpIndexmap, &numEntries, 
               lpStringTable, extractPFMfaceName) ;

   if(!status)
      goto  endIndexPFMs;

   //  this block just restricts scope of local variables
   {  //  writing stringTable to file.
      WORD   count;
      OFSTRUCT   OpenBuf ;  // for OpenFile()
      HFILE  hIndex ;  //  holds handle to Index file

      hIndex = OpenFile(lpIndexPath, &OpenBuf, 
          OF_CREATE | OF_WRITE | OF_SHARE_DENY_WRITE);

      if(numEntries)  
      {

     count =  lpIndexmap[numEntries-1].filenameOffset - OFFSETOF(lpStringTable);
     count += lstrlen((LPBYTE)MAKELONG(lpIndexmap[numEntries-1].filenameOffset, 
                      HIWORD(lpStringTable)));
     if(count != _lwrite(hIndex, lpStringTable,  count))
     {
        errorMsg(INDEXPFMS, ERR_CREATING_PFM_INDEX);
        errorMsg(INDEXPFMS, ERR_FILE_WRITE_FAILED);
        status = FALSE;
     }
      }
      else
      {
     errorMsg(INDEXPFMS, ERR_CANT_FIND_PFM_FILES);
      }
      _lclose(hIndex);
   }

endIndexPFMs:
   if(lpIndexmap)
      GlobalFreePtr(lpIndexmap);
   if(lpStringTable)
      GlobalFreePtr(lpStringTable);   
   return(status);
}

BOOL FAR PASCAL GetPFMFileName(LPBYTE  lpFaceName,
LPBYTE  lpFileName ,
WORD    Bufsize    ,  // size of lpFileName  (dest buffer)
LPBYTE  lpIndex )     // full path where indexfile is expected.
{
   return extractFileNameFromIndex(lpFaceName, lpFileName, Bufsize, lpIndex);
}

void GetCustomMFDFileName(LPSTR lpszWPXFileName, LPSTR lpszMFDFileName)
{
    WPX_HEADER    wpxHeader;
    LPWPXBLOCKS   lpWPXblocks;
    LPPRINTERINFO lpPInfo;
    LPSTR         lpszFile;
    HANDLE        hfile;
    WORD          count;

   lpszMFDFileName[0] = '\0';

   hfile = _lopen(lpszWPXFileName, READ) ;
   if(hfile == HFILE_ERROR )
      goto  EndOfFunction ;

   count = sizeof(WPX_HEADER);

   if(count != _lread(hfile, &wpxHeader,  count))
      goto  EndOfFunction ;

   lpWPXblocks = (LPWPXBLOCKS) GlobalAllocPtr(GDLLHND, 
                          (long) sizeof(WPXBLOCKS));
   if (! lpWPXblocks)
     goto EndOfFunction;
   count = wpxHeader.PrinterInfo_len;
   lpWPXblocks->WPXprinterInfo = GlobalAllocPtr(GDLLHND, (long)count);
   count = wpxHeader.stringtab_len;
   lpWPXblocks->WPXstrings = GlobalAllocPtr(GDLLHND, (long)count);

   if(!(lpWPXblocks->WPXprinterInfo  &&  lpWPXblocks->WPXstrings))
      goto  EndOfFunction ;

   _llseek(hfile, wpxHeader.PrinterInfo_loc, SEEK_SET);   //  seek to pos byte

   count = wpxHeader.PrinterInfo_len;
   if(count != _lread(hfile,  lpWPXblocks->WPXprinterInfo, count))
      goto  EndOfFunction ;

   _llseek(hfile, wpxHeader.stringtab_loc, SEEK_SET);   //  seek to pos byte

   count = wpxHeader.stringtab_len;
   if(count != _lread(hfile,  lpWPXblocks->WPXstrings, count))
      goto  EndOfFunction ;

   _lclose(hfile);

    lpPInfo = (LPPRINTERINFO) lpWPXblocks->WPXprinterInfo;
    lpszFile = lpPInfo->CustomFontFile.w.length == 0 ? NULL :
      (LPSTR) (((LPBYTE) lpWPXblocks->WPXstrings) + 
           lpPInfo->CustomFontFile.w.offset);

    if (lpszFile)
      lstrcpy(lpszMFDFileName, lpszFile);

EndOfFunction:
    /* clean up */
    if (lpWPXblocks) {
    if (lpWPXblocks->WPXprinterInfo)
      GlobalFreePtr(lpWPXblocks->WPXprinterInfo);
    if (lpWPXblocks->WPXstrings)
      GlobalFreePtr(lpWPXblocks->WPXstrings);
    GlobalFreePtr(lpWPXblocks);
    }

   return;
}


BOOL FAR PASCAL CreateNewWPXFile(LPSTR lpszModelName, BOOL bCreate)
{
    WORD    rc = FALSE;
    static  char FileName[_MAX_PATH]; /* Should be in DS for remove() */
    static  char MFDFileName[_MAX_PATH];

#ifdef ADOBE_DRIVER
    if (IsWPXFileExist(lpszModelName, FileName, sizeof(FileName))) {
#else
    char    wpxindex[_MAX_PATH];

    GetWindowsDirectory((LPSTR) wpxindex, PS_FILE_PATH_LENGTH);
    if (wpxindex[lstrlen(wpxindex)] != '\\')
      lstrcat((LPSTR) wpxindex, "\\");
    lstrcat(wpxindex, "wpxindex.lst");

    if (extractFileNameFromIndex(lpszModelName, FileName, 
                 _MAX_PATH, wpxindex)) {
#endif                 
        GetCustomMFDFileName(FileName, MFDFileName);

        /* Delete WPX file */
        remove(FileName);
        if (MFDFileName[0])
            remove(MFDFileName);

        rc = TRUE;
    }

    /* Create new WPX file if requested */
    if (bCreate) {
        rc = FALSE;             /* Reset rc */
        if (obtainWPXfile((LPBYTE) lpszModelName, FileName, 
              _MAX_PATH, FALSE) == WPXVERSION)
            rc = TRUE;
    }
    return rc;
}

