/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: SYSRSRC.H                                              */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

VOID FAR PASCAL SysRsrcLoosen(VOID) ;
BOOL FAR PASCAL SysRsrcCleanUp(VOID) ;
BOOL FAR PASCAL SysRsrcMemAddHandle(HANDLE memhdl, BOOL JmpFlag) ;
BOOL FAR PASCAL SysRsrcMemDelHandle(HANDLE memhdl, BOOL JmpFlag) ;
