/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TRANS.C                                                      */
/*                                                                           */
/* Description: This module contains the functions for                       */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_TRANSSEG)


#define NUM_TOKENS   65

#ifndef ADOBEPS42
#define EPSPRINToff_LVL1   0
#define EPSPRINToff_LVL2   1
#define EPSPRINTon_LVL1    2
#define EPSPRINTon_LVL2    3
#else
#define EPSPRINToff   0
#define EPSPRINTon    1
#endif

#define AVAILFONTCACHE   60     //YCT temprary


/******************************************************************************
*
*                            StartTranslation
*
*  Function:
*       This routine is responsible for all the housekeeping associated with
*       initiating translation. Note that no data is actually sent into
*       the output stream by this routine. It is called by ESCStartDoc().
*
*  Arguments:
*       lppd - ptr to control layer's PDEVICE structure.
*
*  returns:
*       RC_ok if no error, else RC_fail.
*
******************************************************************************/

SHORT FAR PASCAL StartTranslation(LPPDEVICE lppd, LPDOCINFO lpDocInfo)
{
   short    Flavor;
   BOOL     Binary;
   short    NumBytes;
   FARPROC  lpStartDLLFunc;
   short    assignret;
   BOOL     usedll;
   char szDialectFilename[ PATHSIZE ];
   PSERROR rc;
   
   DetermineOutputCharacteristics(lppd, &Flavor, &Binary);

   // Check if we are going to use an external dll
   if( ( lppd->lpPSExtDevmode->dm2.bOutputDialect != DIALECT_EPS ) &&
       ( lppd->lpPSExtDevmode->dm2.bOutputDialect != DIALECT_PS  ) )
   {
      usedll = TRUE;
   }
   else
   {
      usedll = FALSE;
   }

   if (usedll == TRUE)
   {
      //  Get the Dialect file name.
      NumBytes = LoadString(ghDriverMod,
                            INI_DIALECTFILENAME_BASE + lppd->lpPSExtDevmode->dm2.bOutputDialect,
                            &szDialectFilename[ 0 ], PATHSIZE );

      assignret = RC_fail;
      if (NumBytes != 0)
      {
                  // Load the DLL for the particular DIALECT
         if (LoadDrvrLibrary( &szDialectFilename[ 0 ], &(lppd->hDriverTokenDLL) ) == RC_ok )
         {
            // Initialize function returns a handle to the
            //  global data structure.
            lpStartDLLFunc = GetProcAddress( (HINSTANCE)lppd->hDriverTokenDLL, (LPCSTR)"StartDLL" );
            if( lpStartDLLFunc != NULL )
            {
               if( (*lpStartDLLFunc)( lppd ) == RC_ok )
               {
                  assignret = AssignDLLTokens(lppd, lppd->hDriverTokenDLL );
               }
            }

            if( assignret == RC_fail )
            {
               FreeDrvrLibrary( &(lppd->hDriverTokenDLL) );
            }
         }
      } // if (NumBytes != 0)

      // Deal with error in starting up the dll
      if  (assignret == RC_fail)
      {
         usedll = FALSE;
         Flavor = PPSLEVEL1;
         Binary = FALSE;
      }
   }

   if (usedll == FALSE)
   {
      // Allocation of translate layer data structures.
      rc = AllocTranslateLayerData( lppd );
      if (PS_ERROR(rc))
          return RC_fail;
          
      // Make sure dll handle is null
      lppd->hDriverTokenDLL = NULL;

      // Set the token function ptr table
      FlavorOfPostScript(lppd, Flavor);

      // Set the PSSend function ptr table
      AsciiOrBinary( Flavor, Binary,lppd );

      // init GSTATE stack.
      GSStackCreate(lppd) ;

      // Init the list of font data records
     if (lppd->SmsStartDoc!=SECOND_SD)
        {
         // Don't free the Font list for second StartDOC call because there are fonts
         // downloaded before StartDoc() - where we artificially make first StartDoc() call
         // This tweak is to fix bug 123510 - keep DSC as well as FontDataList record
         InitFontDataList( lppd );
        }
                                                   
      // Open destination port.
      // Open the port only if this call comes from a real StartDoc() call:
      if (lppd->SmsStartDoc != FIRST_SD){
         if (!PortOpen(lppd,(LPSTR)lppd->szTitle, lppd->hdc, lpDocInfo))
         {
            return(RC_userabort);
         }
         else if (lppd->lpPSExtDevmode->dm.enumDialect != DIA_PORTABLE)  
         {
            // do this here only when it is not Portability mode
            // for Portability mode, do this at the end of TDocumentBegin()
            PortFirstStartSpoolPage(lppd); 
         }
      }
   }

   // We used to set here a flag indicating that translation had started.
   // Now the control-side state machine keeps track of that state.

   return( RC_ok );
}

/******************************************************************************
*
*                           EndTranslation
*
*  Function:
*       This routine is responsible for the housekeeping associated with
*       completing translation.
*
*  Arguments:
*       lppd - ptr to control layer's PDEVICE structure.
*
*  Returns: None
*
******************************************************************************/
VOID FAR PASCAL EndTranslation(LPPDEVICE lppd)
{
   FARPROC fnEndFunc;

   // We used to set here a flag indicating that translation had ended.
   // Now the control-side state machine keeps track of that state.

   if (lppd->hDriverTokenDLL != NULL)
   {
      // Using the external translator, call the DLL clean-up function
      fnEndFunc = GetProcAddress( (HINSTANCE)lppd->hDriverTokenDLL, (LPCSTR)"EndDLL" );
      if (fnEndFunc != NULL)
      {
         (*fnEndFunc)(lppd);
      }
      FreeDrvrLibrary(&(lppd->hDriverTokenDLL));
      lppd->hDriverTokenDLL = NULL;
   }
   else
   {
     // Using the internal translator, close destination port
     if(lppd->lpPSExtDevmode->dm.enumDialect != DIA_PORTABLE)
     {
        // do this here only when it is not the Portability mode
        // for Portability mode, do this in the TDocumentEnd()
        PortLastEndSpoolPage(lppd);  
     }
     PortClose(lppd);

     FreeTranslateLayerData( lppd );
   }
}

 /* ********************
  * Save the GlyphData for Pre-StartDoc() fonts. So every page can see the same 
  * Downloaded Char/glyph-list
 **/
void SaveGlyphData0(LPPDEVICE lppd, int Num)
{
   int  i;
   LPFONTDATARECORD currentrec;
   DWORD dwSize;

   // Save the GlyphData for fonts Before Num to GlyphData0 - new buffers
   currentrec = lppd->lpFontDataList->FontDataList;
   for(i = 0 ; i < Num ; i++, currentrec++)
   {
      if (currentrec->GlyphData  &&  currentrec->IsGlyphDataOurs){
         if (IsDBCSCharSet(currentrec->CharSet))
            dwSize = SIZE_GLYPHDATA_CJK;
         else
            dwSize = SIZE_GLYPHDATA_US;
         currentrec->GlyphData0 = (LPWORD)GlobalAllocPtr(GHND, dwSize);
         if (!currentrec->GlyphData0) continue; // alloc failed - cannot save the info.
         MemCopy(currentrec->GlyphData0, currentrec->GlyphData, dwSize);
      }
      
   }
}

 /* ********************
  * Restore the GlyphData for Pre-StartDoc() fonts. So every page can see the same 
  * Downloaded Char/glyph-list
 **/
void RestoreGlyphData0(LPPDEVICE lppd, int Num)
{
   int  i;
   LPFONTDATARECORD currentrec;
   DWORD dwSize;

   // Save the GlyphData for fonts Before Num to GlyphData0 - new buffers
   currentrec = lppd->lpFontDataList->FontDataList;
   for(i = 0 ; i < Num ; i++, currentrec++)
   {
      if (currentrec->GlyphData  &&  currentrec->IsGlyphDataOurs){
         if (!currentrec->GlyphData) continue; // No buffer,- cannot restore the info.
         if (IsDBCSCharSet(currentrec->CharSet))
            dwSize = SIZE_GLYPHDATA_CJK;
         else
            dwSize = SIZE_GLYPHDATA_US;
         MemCopy(currentrec->GlyphData, currentrec->GlyphData0, dwSize);
      }
   }
}


/************************************************************************
*
*                       InitFontDataList
*
*  Function:
*       inits font name list
*
*  Called:
*       VOID FAR PASCAL InitFontDataList( LPPDEVICE lppd);
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice pointer
*       none
*
*  Returns:
*       nothing
************************************************************************/

VOID FAR PASCAL InitFontDataList(LPPDEVICE lppd)
{
   WORD  i;
   LPFONTDATARECORD currentrec;

   // Keep the fonts downloaded at Pre-StartDoc() time. CJK only - will be moved to 4.2US
   currentrec = (lppd->lpFontDataList->FontDataList)+(lppd->nPreStartDocFonts);
   RestoreGlyphData0(lppd, lppd->nPreStartDocFonts);
   
   for(i = lppd->nPreStartDocFonts ; i < MAXFONTDATARECORDS ; i++, currentrec++)
   {
      if(currentrec->GlyphData  &&  currentrec->IsGlyphDataOurs)
          GlobalFreePtr((LPBYTE)currentrec->GlyphData);

//#ifdef STREAMER
      if (currentrec->PSFontRecPtr != NULL)
      {
	      StreamerReleaseFontRec(&currentrec->PSFontRecPtr);
          // Fix bug 118873  jjia   9/11/95
          currentrec->PSFontRecPtr = NULL;
      }
//#endif

      if(currentrec->GlyphData0  &&  currentrec->IsGlyphDataOurs)
          GlobalFreePtr((LPBYTE)currentrec->GlyphData0);
      currentrec->GlyphData0 = NULL ;

      if(currentrec->lpW1ByteGI &&  currentrec->IsGlyphDataOurs)
         {
         GlobalFreePtr(currentrec->lpW1ByteGI);
         currentrec->lpW1ByteGI = NULL ;
         }
      currentrec->GlyphData = NULL ;
      currentrec->IsGlyphDataOurs = FALSE ;
      // Free the GlyphIndex Table allocated in ttext.c
      if (currentrec->lpGITable && currentrec->isMylpGITable && currentrec->lpGITable->lpwGI){
         GlobalFreePtr(currentrec->lpGITable->lpwGI); // table
         GlobalFreePtr(currentrec->lpGITable);  // table struct itself
      }
      currentrec->lpGITable = NULL;
      DeleteSubFont(lppd, currentrec); //for UFL
   }

   lppd->lpFontDataList->GlyphData  =  NULL ;

   // don't overwrite pre-startdoc fonts
   lppd->lpFontDataList->FontDataNextRecord = lppd->nPreStartDocFonts;
   
   lppd->lpFontDataList->currentulpos = -1;     // init underlining parameters
   lppd->lpFontDataList->currentulwidth = -1;   //  to impossible values

   lppd->lpFontDataList->currentstpos = -1;     // init underlining parameters
   lppd->lpFontDataList->currentstwidth = -1;   //  to impossible values

   lppd->lpFontDataList->iDefinedFonts[0] = 0;  // initialize
   // Set initial FontCache size YCT
   // This value will be updated with FCacheSize from PPD
	if (((LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo))->devcaps.bFontCacheSize)
   { 
      if (lppd->lpPSExtDevmode->dm2.fUserFCSelection != 
                ((LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo))->devcaps.iFontCacheSize * 1024)
         lppd->lpFontDataList->TFontCacheAvail = 
								(long)lppd->lpPSExtDevmode->dm2.fUserFCSelection;  
      else
         lppd->lpFontDataList->TFontCacheAvail = 
                ((LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo))->devcaps.iFontCacheSize * 1024;
   }
   else // no *FCacheSize in PPD
      lppd->lpFontDataList->TFontCacheAvail = (long) AVAILFONTCACHE * (long)1024;


}

/***********************************************************************
*
*                       ResetFontDataList
*
*  Function:
*       deletes all font data records down to the current save level
*
*  Called:
*       VOID FAR PASCAL ResetFontDataList( LPPDEVICE lppd );
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice pointer
*
*  Returns:
*       nothing
************************************************************************/

VOID FAR PASCAL ResetFontDataList(LPPDEVICE lppd)
{
   LPFONTDATARECORD currentrec;
   short dex;

   if (lppd->lpFontDataList->FontDataNextRecord > 0)
   {
      dex = (lppd->lpFontDataList->FontDataNextRecord - 1);
      currentrec = lppd->lpFontDataList->FontDataList;
      currentrec += dex;


   // Keep the fonts downloaded at Pre-StartDoc() time. CJK only - will be moved to 4.2US
      RestoreGlyphData0(lppd, lppd->nPreStartDocFonts);
      while ((dex >= lppd->nPreStartDocFonts) &&
             (currentrec->StackLevel > lppd->lpProcsetstuff->savelevel))
      {
         if(currentrec->GlyphData  &&  currentrec->IsGlyphDataOurs)
               GlobalFreePtr((LPBYTE)currentrec->GlyphData);

         if(currentrec->lpW1ByteGI &&  currentrec->IsGlyphDataOurs)
            {
            GlobalFreePtr(currentrec->lpW1ByteGI);
            currentrec->lpW1ByteGI = NULL ;
            }

//#ifdef STREAMER
	  if (currentrec->PSFontRecPtr != NULL)
      {
	 	  StreamerReleaseFontRec(&currentrec->PSFontRecPtr);
          // Fix bug 118873  jjia   9/11/95
          currentrec->PSFontRecPtr = NULL;
      }
//#endif
         currentrec->GlyphData = NULL ;
         currentrec->IsGlyphDataOurs = FALSE ;

          // Free the GlyphIndex Table allocated in ttext.c
         // Added here to fix a Memory leak bug. 8-7-95
          if (currentrec->lpGITable && currentrec->isMylpGITable && currentrec->lpGITable->lpwGI){
             GlobalFreePtr(currentrec->lpGITable->lpwGI); // table
             GlobalFreePtr(currentrec->lpGITable);  // table struct itself
          }
          currentrec->lpGITable = NULL;
          DeleteSubFont(lppd, currentrec); //UFL

         currentrec --;
         dex --;
      }

      lppd->lpFontDataList->FontDataNextRecord = dex + 1;

   }
}

/*****************************************************************************
*
*                           LoadDrvrLibrary
*
*  Function: 
*     To load or not to load a .DLL.
*     The idea of the function is to avoid the dialog box that says
*     the DLL could not be found please insert diskette in drive a:.
*     to do this we will check that path that windows would check for
*     the file DLL if found we will then do a LoadLibrary.  If not
*     found the handle will be 2 file not found;
*
*  Arguments: 
*     LPSTR lpLibraryName - Points to a string that names the library file.
*     LPHANDLE lphLibrary - library handle returned.
*
*  Returns:
*     See LoadLibrary in the SDK
*
*****************************************************************************/
HANDLE FAR PASCAL LoadDrvrLibrary(LPSTR lpLibraryName, LPHANDLE lphLibrary)
{
   HANDLE   hRetValue;      // Library handle to be returned 
   OFSTRUCT ofLocal;        // File structure used py OpenFile

   if (OpenFile( lpLibraryName, &ofLocal, OF_EXIST | OF_READ ) != -1 )
   {
      // File found so open the library 
      *lphLibrary = LoadLibrary(lpLibraryName);
      hRetValue = (*lphLibrary > 2 ? RC_ok : RC_not_found );
   }
   else
   {
      hRetValue = RC_not_found;           // File Not found 
   }

   return( hRetValue );
} 

/*****************************************************************************
*
*                             FreeDrvrLibrary
*
*  FUNCTION: 
*     Free the library and change the value of the pointed to handle.
*
*  Arguments:
*     LPHANDLE lphLibrary - Pointer to the library handle to FREE
*
*  Returns:
*     N/A
*
*****************************************************************************/
VOID FAR PASCAL FreeDrvrLibrary(LPHANDLE lphLibrary)
{
   FreeLibrary( *lphLibrary );
   *lphLibrary = NULL;
   return;
}

/***************************************************************************
*
*                     DetermineOutputCharacteristics
*
*  Function:
*     Determines the output dialect (flavor) and whether the output
*     should be in binary or not.
*     NOTE: If output is EPS, binary is forcibly disabled here to prevent
*     rest of the driver from using any binary related functions.
*
*  Called:
*     VOID NEAR PASCAL DetermineOutputCharacteristics(LPPDEVICE lppd,
*                                          LPSHORT flavor, LPBOOL binary);
*  Parameters:
*     LPSHORT flavor -- the output type (EPS, PS1, PS2, etc)
*     LPBOOL binary -- binary output or not.
*
*  Returns:
*       nothing
***************************************************************************/

#ifdef ADOBE_DRIVER
VOID FAR PASCAL DetermineOutputCharacteristics(LPPDEVICE lppd, LPSHORT Flavor,
                                                LPBOOL Binary)
#else
VOID NEAR PASCAL DetermineOutputCharacteristics(LPPDEVICE lppd, LPSHORT Flavor,
                                                LPBOOL Binary)
#endif
{
   short FlavorCode;
   BOOL bfBinaryOutput =
      (lppd->lpPSExtDevmode->dm2.iDataOutputFormat != PROTOCOL_ASCII);

// The following table is implemented in the flavor selection,
// and whether binary compression is allowed. X means "don't care".
//
// Dialect = PostScript
//
//    JobEPS   Binary   Level |  Flavor     Binary
//    -------|-------|--------| ---------   ------
//     off   |  off   |  1     |  PPSLEVEL1     off
//     off   |  off   |  2      |  PPSLEVEL2    off
//     off   |  on    |  1      |  PPSLEVEL1    on
//     off   |  on    |  2      |  PPSLEVEL2    on
//     on    |  X     |  X      |  MINIMALHDR   off
//
//
// Dialect = EPS
//
//    JobEPS   Binary   Level |  Flavor         Binary
//    -------|-------|--------| ---------       ------
//     off   |  off   |  1     |  EPSLEVEL1          off
//     off   |  off   |  2      |  EPSLEVEL2         off
//     off   |  on    |  1      |  EPSLEVEL1         on
//     off   |  on    |  2      |  EPSLEVEL2        on
//     on    |  X     |  X      |  EPSFILE_EPSPRINT off
//
// Dialect = Carousel
//
//    JobEPS   Binary   Level   |  Flavor     Binary
//    -------|-------|-------   | ---------   ------
//     off   |  X     |  X      |  AI3          off
//     on    |  X     |  X      |  MINIMALHDR    off


// IF OpenChannel, then use LEVEL1 and ASCII, see CONT\Escapes.c's, PPeng.
// fix a bug where Type1hdr thinks it's Binary but PSSendBitmap() thinks it's Hex.
   if (lppd->job.bfESCOpenChannel){
      *Binary = FALSE;
      *Flavor = PPSLEVEL1;
      return; // No more thing to figure out.
   }


   // Figure out which flavor of translation to use.

   *Binary = bfBinaryOutput;

#ifndef ADOBEPS42
   FlavorCode  =   (fIsMinHeaderLppd(lppd) << 1)
                     | (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) ;

   switch (lppd->lpPSExtDevmode->dm2.bOutputDialect)
   {
      case DIALECT_EPS:

         switch (FlavorCode)
         {
            case EPSPRINToff_LVL1: 
               *Flavor = EPSLEVEL1;
               *Binary = FALSE;
            break;

            case EPSPRINToff_LVL2:
#ifdef ADOBE_DRIVER
               *Flavor = EPSLEVEL2;
               *Binary = FALSE;   
#else
               *Flavor = EPSLEVEL1; // Changed 24-Mar-1994  -by-  [olegs]
               *Binary = FALSE;     //  always use LEVEL1 in EPS
#endif
            break;

            case EPSPRINTon_LVL1:
            case EPSPRINTon_LVL2:  
               *Flavor = EPSFILE_EPSPRINT;
               *Binary = FALSE;
            break;
         }
      break;


      default:        
         switch (FlavorCode)
         {
            case EPSPRINToff_LVL1: 
               *Flavor = PPSLEVEL1;
            break;

            case EPSPRINToff_LVL2:
               *Flavor = PPSLEVEL2;
            break;

            case EPSPRINTon_LVL1:
            case EPSPRINTon_LVL2:  
               *Flavor = MINIMALHDR;
               *Binary = FALSE;
            break;
         }
      break;

   } // switch(lppd->lpPSExtDevmode->dm2.bOutputDialect)
#else
   FlavorCode  =   fIsMinHeaderLppd(lppd);

   switch (lppd->lpPSExtDevmode->dm2.bOutputDialect)
   {
      case DIALECT_EPS:

         switch (FlavorCode)
         {
            case EPSPRINToff:
               *Flavor = EPSLEVEL2;
               *Binary = FALSE;   
            break;

            case EPSPRINTon:  
               *Flavor = EPSFILE_EPSPRINT;
               *Binary = FALSE;
            break;
         }
      break;


      default:        
         switch (FlavorCode)
         {
            case EPSPRINToff:
               *Flavor = PPSLEVEL2;
            break;

            case EPSPRINTon:  
               *Flavor = MINIMALHDR;
               *Binary = FALSE;
            break;
         }
      break;

   } // switch(lppd->lpPSExtDevmode->dm2.bOutputDialect)
#endif
}
