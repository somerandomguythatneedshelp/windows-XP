/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: CFUNCS.H                                                     */
/*                                                                           */
/* Description: This module contains                                         */
/*                                                                           */
/* Change History:                                                           */
/* L3_MASK -- Support level3 transparent image.   9/19/96    jjia            */
/*                                                                           */
/*****************************************************************************/

/* Macro's deal with ResetDC flag */
#define fIsDeviceReset( lppd )   ((BOOL) ((lppd)->job.bfReset))
#define fDeviceReset( lppd, f);  (lppd)->job.bfReset  = (BYTEFLAG) (f)  


SHORT FAR PASCAL CArcDirection  (LPPDEVICE,BYTE);
SHORT FAR PASCAL CBackgroundMode(LPPDEVICE,BYTE);
SHORT FAR PASCAL CBlt(LPPDEVICE);

//              -----   Brushes  -----

SHORT FAR PASCAL CBrush       (LPPDEVICE);
SHORT FAR PASCAL CBrushBGColor(LPPDEVICE,DWORD    );
SHORT FAR PASCAL CBrushFGColor(LPPDEVICE,DWORD    );
SHORT FAR PASCAL CBrushHatch  (LPPDEVICE,BYTE     );
SHORT FAR PASCAL CBrushPattern(LPPDEVICE,LPPAT    );
SHORT FAR PASCAL CBrushStyle  (LPPDEVICE,BYTE     );

//              -----   Shapes   -----

SHORT FAR PASCAL CArc           (LPPDEVICE,LPRECT ,LPPOINT,LPPOINT            );
SHORT FAR PASCAL CChord         (LPPDEVICE,LPRECT ,FLAG,FLAG,LPPOINT,LPPOINT  );
SHORT FAR PASCAL CEllipse       (LPPDEVICE,LPRECT ,FLAG,FLAG                  );
SHORT FAR PASCAL CCircle        (LPPDEVICE,LPRECT ,FLAG,FLAG                  );
SHORT FAR PASCAL CLine          (LPPDEVICE,LPPOINT                            );
SHORT FAR PASCAL CPie           (LPPDEVICE,LPRECT ,FLAG,FLAG,LPPOINT,LPPOINT  );
SHORT FAR PASCAL CPolygon       (LPPDEVICE,LPPOINT,FLAG,FLAG,FLAG,SHORT       );
SHORT FAR PASCAL CPolyBezier    (LPPDEVICE,LPPOINT,SHORT                      );
SHORT FAR PASCAL CPolyLine      (LPPDEVICE,LPPOINT,SHORT                      );
SHORT FAR PASCAL CRectangle     (LPPDEVICE,LPRECT ,FLAG,FLAG                  );
SHORT FAR PASCAL CRoundRectangle(LPPDEVICE,LPRECT ,FLAG,FLAG,LPPOINT          );
SHORT FAR PASCAL CScanLine      (LPPDEVICE,LPPOINT,FLAG,FLAG,SHORT            );
SHORT FAR PASCAL CScanLineBegin (LPPDEVICE);
SHORT FAR PASCAL CScanLineEnd   (LPPDEVICE);

//              ----- Bitmaps & DIBS -----

SHORT FAR PASCAL CBMOpaqueBox   (LPPDEVICE,LPRECT,DWORD                       );
SHORT FAR PASCAL COpaqueBox     (LPPDEVICE,LPRECT,DWORD,WORD                  );
SHORT FAR PASCAL CBitmapHeader  (LPPDEVICE,LPRECT ,LPRECT,DWORD               );
SHORT FAR PASCAL CBitmapOperator(LPPDEVICE,BOOL,DWORD,DWORD,DWORD             );
SHORT FAR PASCAL CBitmapData    (LPPDEVICE,LPBITMAP,LPRECT,SHORT              );
// L3_MASK FAST_IMAGE
SHORT FAR PASCAL CDIBDataBits   (LPPDEVICE,LPDRAWMODE,LPRECT,LPRECT,LPSTR,
                                 LPBITMAPINFO,LPSTR, SHORT, float far *       );
SHORT FAR PASCAL CDIBHeader     (LPPDEVICE,LPDRAWMODE,LPRECT,LPRECT,BOOL,
                                 LPBITMAPINFO,SHORT, float far *              );
SHORT FAR PASCAL CDIBOperator   (LPPDEVICE,SHORT,SHORT                        );

SHORT FAR PASCAL CGrayTable     (LPPDEVICE,LPBYTE  ,WORD                      );
SHORT FAR PASCAL CColorTable    (LPPDEVICE,LPDWORD ,WORD                      );
SHORT FAR PASCAL CICMColor      (LPPDEVICE,DWORD                              );
// L3_MASK
SHORT FAR PASCAL CDIBClipRgns   (LPPDEVICE,LPDRAWMODE,LPRECT, LPRECT, LPSTR, LPBITMAPINFO);

//              ----- Text and Fonts -----

SHORT FAR PASCAL CTextBegin  (LPPDEVICE,LPPOINT,LPPSFONTINFO,LPTEXTXFORM           );
SHORT FAR PASCAL CTextRun    (LPPDEVICE,LPSTR ,int, double, double,LPPSFONTINFO,
                              LPTEXTXFORM, LPINT);
SHORT FAR PASCAL CTextEnd    (LPPDEVICE,LPPSFONTINFO,LPTEXTXFORM, int);
PSERROR FAR PASCAL CSoftFontLoad(LPPDEVICE,LPPSFONTINFO,LPTEXTXFORM,LPSTR,short      );
#ifdef ADD_EURO
PSERROR FAR PASCAL CDeviceFontLoad(LPPDEVICE,LPPSFONTINFO,LPTEXTXFORM                );  
#endif

#ifdef ADOBE_DRIVER
SHORT FAR PASCAL CTextRunWide(LPPDEVICE, LPWORD, int, double, double,
                              LPPSFONTINFO, LPTEXTXFORM, LPINT);
#endif

SHORT FAR PASCAL CClipRect(LPPDEVICE,LPRECT, LPRECT,int);
SHORT FAR PASCAL CClipEnd(LPPDEVICE);
SHORT FAR PASCAL CColorBG(LPPDEVICE,DWORD);

SHORT FAR PASCAL CDocumentBegin(LPPDEVICE);
SHORT FAR PASCAL CDocumentEnd(LPPDEVICE);
SHORT FAR PASCAL CDocumentAbort(LPPDEVICE);
SHORT FAR PASCAL CDocumentFlush(LPPDEVICE);
SHORT FAR PASCAL CDocumentPageBegin(LPPDEVICE);
SHORT FAR PASCAL CDocumentPageEnd(LPPDEVICE);
SHORT FAR PASCAL CDriverData(LPPDEVICE);
SHORT FAR PASCAL CDriverState(LPPDEVICE);
SHORT FAR PASCAL CExtra(LPPDEVICE,FLAG);
SHORT FAR PASCAL CExtraBegin(LPPDEVICE);
SHORT FAR PASCAL CExtraEnd(LPPDEVICE);
SHORT FAR PASCAL CExtraPtrs(LPPDEVICE);

SHORT FAR PASCAL CJobCopies(LPPDEVICE,WORD);
SHORT FAR PASCAL CJobDuplex(LPPDEVICE,WORD);
SHORT FAR PASCAL CJobHold(LPPDEVICE);
SHORT FAR PASCAL CJobTitle(LPPDEVICE,LPSTR);
SHORT FAR PASCAL CJobType(LPPDEVICE,SHORT);

SHORT FAR PASCAL CMapGeneral(LPPDEVICE);
SHORT FAR PASCAL COptimize(LPPDEVICE);


//              -----   Pens     -----

SHORT FAR PASCAL CPen          (LPPDEVICE,LPPPEN );
SHORT FAR PASCAL CPenCap       (LPPDEVICE,BYTE   );
SHORT FAR PASCAL CPenFGColor   (LPPDEVICE,DWORD  );
SHORT FAR PASCAL CPenBGColor   (LPPDEVICE,DWORD  );
SHORT FAR PASCAL CPenJoin      (LPPDEVICE,BYTE   );
SHORT FAR PASCAL CPenMiterLimit(LPPDEVICE,SHORT  );
SHORT FAR PASCAL CPenStyle     (LPPDEVICE,BYTE   );
SHORT FAR PASCAL CPenWidth     (LPPDEVICE,POINT  );


SHORT FAR PASCAL CPolyMode(LPPDEVICE,BYTE);
SHORT FAR PASCAL CQuasifile(LPPDEVICE);
SHORT FAR PASCAL CQuasifileEnd(LPPDEVICE);
SHORT FAR PASCAL CRawPrinterStart(LPPDEVICE);
SHORT FAR PASCAL CRawPrinterData(LPPDEVICE,LP,WORD);
SHORT FAR PASCAL CRawPrinterEnd(LPPDEVICE);

//              -----   Page Level  -----
SHORT FAR PASCAL CPageOrientation(LPPDEVICE, WORD);

//              -----   Paper    -----
SHORT FAR PASCAL CPaperSource(LPPDEVICE,LPSTR);
SHORT FAR PASCAL CPaperSize(LPPDEVICE,LPSTR);

//              -----   Paths    -----
void FAR PASCAL CGraphSave(LPPDEVICE);
void FAR PASCAL CGraphRestore(LPPDEVICE);
void FAR PASCAL CClip(LPPDEVICE,WORD);
void FAR PASCAL CEndPath(LPPDEVICE, LPPATHINFO, LPDRAWMODE);
void FAR PASCAL CSaveCTM(LPPDEVICE);
void FAR PASCAL CRestoreCTM(LPPDEVICE);
void FAR PASCAL CTransformCTM(LPPDEVICE, LPDWORD);
void FAR PASCAL CClipBox(LPPDEVICE, LPRECT);

//              -----   Hacks    -----
SHORT FAR PASCAL CMSRectHack( LPPDEVICE, BOOL, LPRECT, LPRECT );

// MGX escapes
short FAR PASCAL CSetScreenAngle(LPPDEVICE,LP );
short FAR PASCAL CSetScreenFrequency(LPPDEVICE,LPFREQUENCY,LPFREQUENCY);
short FAR PASCAL CSetSpread(LPPDEVICE,short);
short FAR PASCAL CSetGDIXForm(LPPDEVICE lppd);
short FAR PASCAL CDownLoadHeader(LPPDEVICE lppd, WORD wHeaderID);
