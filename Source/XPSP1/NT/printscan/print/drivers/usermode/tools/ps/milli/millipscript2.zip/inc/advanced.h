/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: ADVANCED.H                                             */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

#define DEFAULT_SHOW_ALERT  0

BOOL _loadds FAR PASCAL CHAdvancedDlg(HWND hDlg, unsigned imsg, WORD wParam, 
                                      LONG lParam);

void FAR PASCAL RestoreAdvancedDefaults(LPPSEXTDEVMODE lpPSExtDevmode,
                                        LPWPXBLOCKS lpWPXBlock);
