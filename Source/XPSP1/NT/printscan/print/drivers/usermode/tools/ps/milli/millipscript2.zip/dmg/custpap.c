/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: CUSTPAP.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for the Custom Paper Size */
/*              Dialog box                                                   */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "apd42map.hh"

#pragma code_seg(_DIALOGSSEG)

/*****************************************************************************/
/*                                                                           */
/* Minimum sizes regardless of what the printer manufacturer tries to say.   */
/* (in points)                                                               */
/*****************************************************************************/

#define MIN_CUST_SIZE              72
#define MIN_CUST_OFFSET            0

// Indices of the 4 element value arrays you'll see a lot of in this file.
#define IDX_X_OFFSET               0
#define IDX_Y_OFFSET               1
#define IDX_X_SIZE                 2
#define IDX_Y_SIZE                 3

/*****************************************************************************/
/*                 DoDisplayRealValues                                       */
/* Purpose:                                                                  */
/*   Displays the real values in the edit controls from ictrl to             */
/*   ictrl+nitems-1. The values are given in lpValue.                        */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   lpValue   -- pointer to array of values.                                */
/*   nitems    -- Number of elements in lpValue array.                       */
/*   ictrl     -- ID of the first control (edit box).                        */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing                                                                 */
/*****************************************************************************/
void NEAR PASCAL DoDisplayRealValue(HWND hDlg, DWORD Value,int ictrl, BOOL bInches)
{
    WORD x, y, whole, part;
    int  nDecimals;

    if (bInches)
    {
        x = 72;
        y = 1;
        nDecimals = 2;
    }
    else
    {
        x = 720;
        y = 254;
        nDecimals = 1;
    }

        FixedMulDiv(Value, y, x, nDecimals, &whole, &part);
        DisplayFixedPointNumber(hDlg, ictrl, whole, part,
                                decimalSeparator, nDecimals);

}


/*****************************************************************************/
/*                 SetCustomSpinRange                                        */
/* Purpose:                                                                  */
/*   Sets the range of the spin controls in the custom paper dialog          */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   lpDrvInfo -- Pointer to DRIVERINFO structure                            */
/*   bInches   -- TRUE if currently displaying in inches.                    */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing.                                                                */
/*****************************************************************************/

void NEAR PASCAL SetCustomSpinRange(HWND hDlg, LPDRIVERINFO lpDrvInfo,
                                    BOOL bInches)
{
    LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    WORD           minval[4], maxval[4], x, y, minpart, maxpart, factor = 1;
    int            i, nDecimals, index = lpPSExtDevmode->dm.currentCustPaper;
    char           format[60], buffer[128];

    minval[IDX_X_OFFSET] = lpPrinterInfo->custpageinfo.widthOffset.min;
    minval[IDX_Y_OFFSET] = lpPrinterInfo->custpageinfo.heightOffset.min;
    minval[IDX_X_SIZE] = max(lpPrinterInfo->custpageinfo.width.min, MIN_CUST_SIZE);
    minval[IDX_Y_SIZE] = max(lpPrinterInfo->custpageinfo.height.min, MIN_CUST_SIZE);
    maxval[IDX_X_SIZE] = lpPrinterInfo->custpageinfo.width.max;
    maxval[IDX_Y_SIZE] = lpPrinterInfo->custpageinfo.height.max;
    maxval[IDX_X_OFFSET] = lpPrinterInfo->custpageinfo.widthOffset.max;
    maxval[IDX_Y_OFFSET] = lpPrinterInfo->custpageinfo.heightOffset.max;

    if( index < CUSTOM_LAST &&
        lpPSExtDevmode->dm.custPaper[index].Transverse )
    {
        WORD temp= maxval[IDX_X_SIZE];

        maxval[IDX_X_SIZE] = maxval[IDX_Y_SIZE];
        maxval[IDX_Y_SIZE] = temp;

        temp = minval[IDX_X_SIZE];
        minval[IDX_X_SIZE] = minval[IDX_Y_SIZE];
        minval[IDX_Y_SIZE] = temp;
/* do not swap offsets
        temp = maxval[IDX_X_OFFSET];
        maxval[IDX_X_OFFSET] = maxval[IDX_Y_OFFSET];
        maxval[IDX_Y_OFFSET] = temp;

        temp = minval[IDX_X_OFFSET];
        minval[IDX_X_OFFSET] = minval[IDX_Y_OFFSET];
        minval[IDX_Y_OFFSET] = temp;
*/
    }

     /* Convert from points to display units */
    if (bInches)
    {
        x = 72;
        y = 1;
        nDecimals = 2;
    }
    else
    {
        x = 720;
        y = 254;
        nDecimals = 1;
    }

    wsprintf((LPSTR)format, "[%%d%%s%%0%d.%dd ... %%d%%s%%0%d.%dd]",
             nDecimals, nDecimals, nDecimals, nDecimals);

    for (i=0; i<nDecimals; i++)
    {
        factor *= 10;
    }

    for (i=0; i<4; i++)
    {
        if( index < CUSTOM_LAST )
        {
           if ( i == 0 )
           {
              if(minval[i] == 0 && maxval[i] == 0)
              {
                 EnableWindow(GetDlgItem(hDlg, ID_CUST_X_OFFSET_SPN), FALSE);
                 DoDisplayRealValue(hDlg, minval[i], ID_CUST_X_OFFSET, bInches);

              }
              else
                 EnableWindow(GetDlgItem(hDlg, ID_CUST_X_OFFSET_SPN), TRUE);
           }

           if ( i == 1)
           {
              if(minval[i] == 0 && maxval[i] == 0)
              {
                 EnableWindow(GetDlgItem(hDlg, ID_CUST_Y_OFFSET_SPN), FALSE);
                 DoDisplayRealValue(hDlg, minval[i], ID_CUST_Y_OFFSET, bInches);
              }
              else
                EnableWindow(GetDlgItem(hDlg, ID_CUST_Y_OFFSET_SPN), TRUE);
           }
        }
        else
        {
           if ( i == 0 )
           {
              if(minval[i] == 0 && maxval[i] == 0)
                 DoDisplayRealValue(hDlg, minval[i], ID_CUST_X_OFFSET, bInches);
           }

           if ( i == 1)
           {
              if(minval[i] == 0 && maxval[i] == 0)
                 DoDisplayRealValue(hDlg, minval[i], ID_CUST_Y_OFFSET, bInches);
           }
        }
        FixedMulDiv(minval[i], y, x, nDecimals, &minval[i], &minpart);
        FixedMulDiv(maxval[i], y, x, nDecimals, &maxval[i], &maxpart);

        wsprintf(buffer, format, minval[i], (LPSTR) decimalSeparator,
                 minpart, maxval[i], (LPSTR) decimalSeparator, maxpart);
        SetDlgItemText(hDlg, ID_CUST_X_OFFSET_RANGE+i, (LPSTR)buffer);

        /* Set the spin range only if it is not app defined paper size dialog */
        if (lpPSExtDevmode->dm.currentCustPaper < NUM_CUST_SIZES)
        {
            /* Convert value from the real "x.y" form to the integer "xy" */
            minval[i] *= factor;
            minval[i] += minpart;
            maxval[i] *= factor;
            maxval[i] += maxpart;

            SendDlgItemMessage(hDlg, ID_CUST_X_OFFSET_SPN+i, UDM_SETRANGE, NULL,
                               MAKELPARAM(maxval[i], minval[i]));
        }
    }

}


/*****************************************************************************/
/*                 InitCustomPaperDlg                                        */
/* Purpose:                                                                  */
/*   Initialize the custom paper dialog                                      */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   lpDrvInfo -- Pointer to DRIVERINFO structure                            */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing                                                                 */
/*****************************************************************************/
void NEAR PASCAL InitCustomPaperDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    int            iUnits, index = lpPSExtDevmode->dm.currentCustPaper;

    /* Now initialize the dialog's widgets */
    iUnits = GetMeasurementUnit(FALSE);
    CheckRadioButton(hDlg, ID_CP_INCHES, ID_CP_MILLIMETERS, iUnits);

    // There are two custom dialog box templates: CH_CUSTOMPAPER for driver defined
    // custom paper (currentCustPaper < CUSTOM_LAST) and CH_CUSTOMOTHERPAPER for
    // application definedcustom paper. They should be initialized differently.

    /* Set scroll range */
    SetCustomSpinRange(hDlg, lpDrvInfo, iUnits == ID_CP_INCHES);

    // Allow entry of UserWOffset & UserHOffset whenever WidthOffsetMin/Max
    // or HeightOffsetMin/Max allow control of either.
    // Disable x & y offsets if it is not allowed.
    if((lpPrinterInfo->custpageinfo.widthOffset.min
              == lpPrinterInfo->custpageinfo.widthOffset.max)
         && (lpPrinterInfo->custpageinfo.heightOffset.min
              == lpPrinterInfo->custpageinfo.heightOffset.max))
    {
        RECT  rc;
        int   yoffset;
        DWORD flag;

        EnableWindow(GetDlgItem(hDlg,ID_OFFSET_GROUP), FALSE);
        EnableWindow(GetDlgItem(hDlg,ID_CUST_X_OFFSET), FALSE);
        EnableWindow(GetDlgItem(hDlg,ID_CUST_X_OFFSET_TEXT), FALSE);
        EnableWindow(GetDlgItem(hDlg,ID_CUST_X_OFFSET_RANGE), FALSE);
        EnableWindow(GetDlgItem(hDlg,ID_CUST_Y_OFFSET), FALSE);
        EnableWindow(GetDlgItem(hDlg,ID_CUST_Y_OFFSET_TEXT), FALSE);
        EnableWindow(GetDlgItem(hDlg,ID_CUST_Y_OFFSET_RANGE), FALSE);
        if( index < CUSTOM_LAST )
        {
           EnableWindow(GetDlgItem(hDlg,ID_CUST_X_OFFSET_SPN), FALSE);
           EnableWindow(GetDlgItem(hDlg,ID_CUST_Y_OFFSET_SPN), FALSE);
        }

        /* Move all the offset controls below, out of the window */
        GetWindowRect(GetDlgItem(hDlg,ID_OFFSET_GROUP), (LPRECT)&rc);
        yoffset = rc.top - rc.bottom;

                                    /* should items be moved or deleted?    */
        flag = TRUE;                /* TRUE move, FALSE delete              */

        PositionControls(hDlg, NULL, &yoffset, flag, ID_OFFSET_GROUP, ID_OFFSET_GROUP, NULL);
        PositionControls(hDlg, NULL, &yoffset, flag, ID_CUST_X_OFFSET, ID_CUST_Y_OFFSET, NULL);
        PositionControls(hDlg, NULL, &yoffset, flag, ID_CUST_X_OFFSET_RANGE, ID_CUST_Y_OFFSET_RANGE, NULL);
        PositionControls(hDlg, NULL, &yoffset, flag, ID_CUST_X_OFFSET_TEXT, ID_CUST_Y_OFFSET_TEXT, NULL);
        if( index < CUSTOM_LAST )
           PositionControls(hDlg, NULL, &yoffset, flag, ID_CUST_X_OFFSET_SPN, ID_CUST_Y_OFFSET_SPN, NULL);

        /* Move buttons up, and resize the window */
        yoffset = -yoffset;
        if( index < CUSTOM_LAST )
        {
           PositionControls(hDlg, NULL, &yoffset, TRUE, IDOK, IDCANCEL, NULL);
#ifndef USE_WHATSTHIS_HELP
           PositionControls(hDlg, NULL, &yoffset, TRUE, ID_HELP, ID_HELP, NULL);
#endif
           PositionControls(hDlg, NULL, &yoffset, TRUE, ID_RESTORE_DEFAULTS, ID_RESTORE_DEFAULTS,
                         NULL);
        }
        else
           PositionControls(hDlg, NULL, &yoffset, TRUE, IDCANCEL, IDCANCEL, NULL);

        GetWindowRect(hDlg, (LPRECT)&rc);
        MoveWindow(hDlg, rc.left, rc.top, rc.right-rc.left, rc.bottom-rc.top-yoffset, FALSE);
    }
}


/*****************************************************************************/
/*                 GetCustomPageDimensions                                   */
/* Purpose:                                                                  */
/*   Get the custom page size in points                                      */
/*                                                                           */
/* Parameters:                                                               */
/*   LPDRIVERINFO lpDrvInfo -- pointer to DRIVERINFO sturcture               */
/*   double FAR *lpXSize -- buffer to store X size                           */
/*   double FAR *lpYSize -- buffer to store Y size                           */
/*   double FAR *lpXOffset -- buffer to store X Offset                       */
/*   double FAR *lpYOffset -- buffer to store Y Offset                       */
/*                                                                           */
/* Returns: int                                                              */
/*   nothing.                                                                */
/*****************************************************************************/

void NEAR PASCAL GetCustomPageDimensions(LPDRIVERINFO lpDrvInfo,
                                        LPWORD lpXSize,
                                        LPWORD lpYSize,
                                        LPWORD lpXOffset,
                                        LPWORD lpYOffset)
{
    LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    int            index = lpPSExtDevmode->dm.currentCustPaper;

    if (index < CUSTOM_LAST)
    {
        *lpXSize   = (WORD) lpPSExtDevmode->dm.custPaper[index].customWidth;
        *lpXOffset = lpPSExtDevmode->dm.custPaper[index].widthOffset;
        *lpYSize   = (WORD) lpPSExtDevmode->dm.custPaper[index].customHeight;
        *lpYOffset = lpPSExtDevmode->dm.custPaper[index].heightOffset;
    }
    else
    {
        *lpXSize   = (WORD) lpPSExtDevmode->dm.appCustWidth;
        *lpYSize   = (WORD) lpPSExtDevmode->dm.appCustHeight;
        *lpXOffset = 0;
        *lpYOffset = 0;
    }
}


/*****************************************************************************/
/*                 DisplayCustomPaperDlg                                     */
/* Purpose:                                                                  */
/*   Displays the custom paper dialog                                        */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   lpDrvInfo -- Pointer to DRIVERINFO structure                            */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing                                                                 */
/*****************************************************************************/
void NEAR PASCAL DisplayCustomPaperDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    WORD           custom[4];
    int            index = lpPSExtDevmode->dm.currentCustPaper;
    BOOL           bInches = IsDlgButtonChecked(hDlg, ID_CP_INCHES);
    BOOL           bTransverse;

    if (index < CUSTOM_LAST)
    {
        /* Initialize the transverse checkbox */
        bTransverse = lpPSExtDevmode->dm.custPaper[index].Transverse;
        CheckDlgButton(hDlg, ID_CUST_TRANSVERSE, bTransverse);

        if((lpPrinterInfo->custpageinfo.Orientation.min > 0)
            || (lpPrinterInfo->custpageinfo.Orientation.min
                 == lpPrinterInfo->custpageinfo.Orientation.max))
        {
           EnableWindow(GetDlgItem(hDlg,ID_CUST_TRANSVERSE), FALSE);
        }
        else
        {
           EnableWindow(GetDlgItem(hDlg,ID_CUST_TRANSVERSE), TRUE);
        }

        /* Set paper name */
        SetDlgItemText(hDlg, ID_CUST_NAME,
                       lpPSExtDevmode->dm.custPaper[index].CustomName);
        SendDlgItemMessage(hDlg, ID_CUST_NAME, EM_LIMITTEXT,
                           MAX_CUST_PAPER_NAME - 1, NULL);
    }
    else
    {
        char strBuff[MAX_CUST_PAPER_NAME];

        LoadDrvrString(ghDriverMod, IDS_CUSTOM_OTHER_PAPER, strBuff,
                       sizeof(strBuff));
        SetDlgItemText(hDlg, ID_CUST_NAME, strBuff);
    }

    GetCustomPageDimensions(lpDrvInfo, &custom[IDX_X_SIZE], &custom[IDX_Y_SIZE],
                            &custom[IDX_X_OFFSET], &custom[IDX_Y_OFFSET]);

    DoDisplayDialogValues(hDlg, custom, 4, ID_CUST_X_OFFSET, bInches);
    if (index < CUSTOM_LAST)
       SetCurrentSpinPos(hDlg, ID_CUST_X_OFFSET_SPN, ID_CUST_X_OFFSET, 4,
                      bInches ? 2 : 1);
}



BOOL NEAR PASCAL SaveCustomPaperDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    WORD           custom[4], xhi, xlow, yhi, ylow;
    int            id, index = lpPSExtDevmode->dm.currentCustPaper;
    char           strBuff[MAX_CUST_PAPER_NAME];
    BOOL           bTransverse, rc = FALSE;

    if (index >= CUSTOM_LAST)
      return (FALSE);

    bTransverse = IsDlgButtonChecked(hDlg,ID_CUST_TRANSVERSE);

    if (!RetrieveDialogValues(hDlg, custom, 4, ID_CUST_X_OFFSET,
                              IsDlgButtonChecked(hDlg, ID_CP_INCHES)))
    {
        DrvrStringMessageBox(hDlg, DLGS_CUSTOM_SIZE_ERROR, NULL,
                             MB_ICONSTOP | MB_OK);

        return FALSE;
    }

    xlow = max(lpPrinterInfo->custpageinfo.width.min, MIN_CUST_SIZE);
    xhi  = lpPrinterInfo->custpageinfo.width.max;
    ylow = max(lpPrinterInfo->custpageinfo.height.min, MIN_CUST_SIZE);
    yhi  = lpPrinterInfo->custpageinfo.height.max;

    if (bTransverse)
    {
        /*
         * Switch xsize & ysize so that we don't have to duplicate the
         * computation below.
         */
        WORD temp = custom[IDX_X_SIZE];

        custom[IDX_X_SIZE] = custom[IDX_Y_SIZE];
        custom[IDX_Y_SIZE] = temp;
/* do not swap offsets
        temp = custom[IDX_X_OFFSET];
        custom[IDX_X_OFFSET] = custom[IDX_Y_OFFSET];
        custom[IDX_Y_OFFSET] = temp;
*/
    }

    if ((custom[IDX_X_OFFSET] < (WORD)lpPrinterInfo->custpageinfo.widthOffset.min) ||
        (custom[IDX_X_OFFSET] > (WORD)lpPrinterInfo->custpageinfo.widthOffset.max) ||
        (custom[IDX_Y_OFFSET] < (WORD)lpPrinterInfo->custpageinfo.heightOffset.min) ||
        (custom[IDX_Y_OFFSET] > (WORD)lpPrinterInfo->custpageinfo.heightOffset.max))
    {
        /* Offsets out of range */
        id = ((((custom[IDX_X_OFFSET] < (WORD)lpPrinterInfo->custpageinfo.widthOffset.min)
                || (custom[IDX_X_OFFSET] > (WORD)lpPrinterInfo->custpageinfo.widthOffset.max)) && !bTransverse) ||
              (((custom[IDX_Y_OFFSET] < (WORD)lpPrinterInfo->custpageinfo.heightOffset.min)
                  || (custom[IDX_Y_OFFSET] > (WORD)lpPrinterInfo->custpageinfo.heightOffset.max)) && bTransverse)) ?
              ID_CUST_X_OFFSET : ID_CUST_Y_OFFSET;
        DrvrStringMessageBox(hDlg, DLGS_CUSTOM_OFFSET_ERROR, NULL,
                             MB_ICONSTOP | MB_OK);
    }
    else if ((custom[IDX_X_SIZE] < xlow) || (custom[IDX_X_SIZE] > xhi) ||
             (custom[IDX_Y_SIZE] < ylow) || (custom[IDX_Y_SIZE] > yhi))
    {
        /* Page dimensions not in the specified range */
        id = ((((custom[IDX_X_SIZE] < xlow) || (custom[IDX_X_SIZE] > xhi)) && !bTransverse) ||
              (((custom[IDX_Y_SIZE] < ylow) || (custom[IDX_Y_SIZE] > yhi)) && bTransverse)) ?
              CUST_X_SIZE : CUST_Y_SIZE;
        DrvrStringMessageBox(hDlg, DLGS_CUSTOM_SIZE_ERROR, NULL,
                             MB_ICONSTOP | MB_OK);
    }
    else if ((custom[IDX_X_SIZE] + custom[IDX_X_OFFSET] > xhi)  ||
             (custom[IDX_Y_SIZE] + custom[IDX_Y_OFFSET] > yhi))
    {
        int  sizeID, directionID;
        char text[150], output[150], dir[20], sz[15];

        /* Sum of lenght/width and offset parallel/perpendicular to feed
           direction not within the length/width range specified */
        id = ((custom[IDX_X_SIZE] + custom[IDX_X_OFFSET] > xhi && !bTransverse) ||
              (custom[IDX_Y_SIZE] + custom[IDX_Y_OFFSET] > yhi && bTransverse)) ?
              CUST_X_SIZE : CUST_Y_SIZE;
        if (id == CUST_X_SIZE)
        {
            sizeID = DLGS_WIDTH;
            directionID = bTransverse ? DLGS_PARALLEL : DLGS_PERPENDICULAR;
        }
        else
        {
            sizeID = DLGS_LENGTH;
            directionID = bTransverse ? DLGS_PERPENDICULAR : DLGS_PARALLEL;
        }
        LoadString(ghDriverMod, DLGS_CUSTOM_SUM_ERROR, text, sizeof(text));
        LoadString(ghDriverMod, sizeID, sz, sizeof(sz));
        LoadString(ghDriverMod, directionID, dir, sizeof(dir));
        wsprintf(output, text, (LPSTR) sz, (LPSTR) dir, (LPSTR) sz);
        MessageBox(hDlg, output, NULL, MB_ICONSTOP | MB_OK);
    }
    else if (lpPrinterInfo->custpageinfo.isCutSheet)
    {
       RECT *lpMargins = &(lpPSExtDevmode->dm.custPaper[index].HWmargins);
       RECT *lpHWMargins = &(lpPrinterInfo->custpageinfo.HWmargins);
       int  minval[4];

       minval[0] = bTransverse ? lpHWMargins->bottom : lpHWMargins->left;
       minval[1] = bTransverse ? lpHWMargins->top    : lpHWMargins->right;
       minval[2] = bTransverse ? lpHWMargins->right  : lpHWMargins->bottom;
       minval[3] = bTransverse ? lpHWMargins->left   : lpHWMargins->top;

       rc = TRUE;

       if (lpMargins->left   < minval[0] ||
           lpMargins->right  < minval[1] ||
           lpMargins->bottom < minval[2] ||
           lpMargins->top    < minval[3])
       {
          if (IDYES == DrvrStringMessageBox(hDlg, DLGS_TRANSVERSE_ERROR, NULL,
                                            MB_ICONSTOP | MB_YESNO))
          {   // fix the margins
              if (lpMargins->left < minval[0])
                 lpMargins->left = minval[0];
              if (lpMargins->right < minval[1])
                 lpMargins->right = minval[1];
              if (lpMargins->bottom < minval[2])
                 lpMargins->bottom = minval[2];
              if (lpMargins->top < minval[3])
                 lpMargins->top = minval[3];
          }
          else
          {
              id = ID_CUST_TRANSVERSE;
              rc = FALSE;
          }
       }
    }
    else
        rc = TRUE;

    if (! rc)
    {
        SetFocus(GetDlgItem(hDlg, id));
        SendDlgItemMessage(hDlg, id, EM_SETSEL, 0, MAKELPARAM(0,-1));

        return FALSE;
    }

    if (bTransverse)
    {
        /* Switch xsize & ysize back */
        WORD temp = custom[IDX_X_SIZE];

        custom[IDX_X_SIZE] = custom[IDX_Y_SIZE];
        custom[IDX_Y_SIZE] = temp;
/* do not swap offsets
        temp = custom[IDX_X_OFFSET];
        custom[IDX_X_OFFSET] = custom[IDX_Y_OFFSET];
        custom[IDX_Y_OFFSET] = temp;
*/
    }


    if (GetDlgItemText(hDlg, ID_CUST_NAME, strBuff, sizeof(strBuff)))
    {
        lpPSExtDevmode->dm.custPaper[index].customWidth  = (float)custom[IDX_X_SIZE];
        lpPSExtDevmode->dm.custPaper[index].customHeight = (float)custom[IDX_Y_SIZE];

        lpPSExtDevmode->dm.custPaper[index].widthOffset  = custom[IDX_X_OFFSET];
        lpPSExtDevmode->dm.custPaper[index].heightOffset = custom[IDX_Y_OFFSET];

        lstrcpyn(lpPSExtDevmode->dm.custPaper[index].CustomName,strBuff,
                 sizeof(lpPSExtDevmode->dm.custPaper[index].CustomName));

        lpPSExtDevmode->dm.custPaper[index].Transverse =
            IsDlgButtonChecked(hDlg,ID_CUST_TRANSVERSE);

        if (lpPrinterInfo->custpageinfo.isCutSheet)
        {
           // make sure that margins are less than paper dimentions
           WORD  maxval[2];
           WORD  qdimx;
           RECT  * lpHWmargins = &(lpPSExtDevmode->dm.custPaper[index].HWmargins);

           // if custom paper size and cut-sheet paper
            GetCustomPageDimensions(lpDrvInfo, &maxval[0], &maxval[1], &qdimx, &qdimx);

           maxval[0] >>= 1;                 /* Max margin is half paper width */
           maxval[1] >>= 1;

           lpHWmargins->left   = min(lpHWmargins->left,   (int)maxval[0]);
           lpHWmargins->top    = min(lpHWmargins->top,    (int)maxval[1]);
           lpHWmargins->right  = min(lpHWmargins->right,  (int)maxval[0]);
           lpHWmargins->bottom = min(lpHWmargins->bottom, (int)maxval[1]);
        }

        return TRUE;
    }
    else
        DrvrStringMessageBox(hDlg, DLGS_CUSTOM_SIZE_ERROR, NULL,
                             MB_ICONSTOP | MB_OK);
}

#pragma  optimize ("se", off)
#pragma  optimize ("d", on)


/*****************************************************************************/
/*                 RestoreCustPapDefaults                                    */
/* Purpose:                                                                  */
/*   Restores and displays the default custom paper dialog                   */
/*                                                                           */
/* Parameters:                                                               */
/*   lpPSExtDevmode -- pointer to devmode                                    */
/*   lpWPXBlock     -- pointer to wpx block                                  */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing                                                                 */
/*****************************************************************************/

void FAR PASCAL RestoreCustPapDefaults(LPPSEXTDEVMODE lpPSExtDevmode,
                                       LPWPXBLOCKS lpWPXBlock)
{
    unsigned char tmpstring[CUSTOMNAMELEN];
    LPPRINTERINFO  lpPrinterInfo ;
    int iCurCustPap;

    iCurCustPap = lpPSExtDevmode->dm.currentCustPaper;
    lpPrinterInfo = (LPPRINTERINFO)(lpWPXBlock->WPXprinterInfo);

    if (iCurCustPap >= CUSTOM_LAST)
        return;

    LoadString(ghDriverMod, IDS_BASE_CUSTOM_NAME, tmpstring,
               sizeof(tmpstring));
    wsprintf(lpPSExtDevmode->dm.custPaper[iCurCustPap].CustomName, tmpstring,
             iCurCustPap+1);

    if(lpPrinterInfo->custpageinfo.Orientation.max < 1)
    {
       // Only long edge feed is allowed.
       lpPSExtDevmode->dm.custPaper[iCurCustPap].Transverse = TRUE;
    }
    else if(lpPrinterInfo->custpageinfo.Orientation.min > 0)
    {
       // Only short edge feed is allowed.
       lpPSExtDevmode->dm.custPaper[iCurCustPap].Transverse = FALSE;
    }
    else
    {
       // Can do both, start with FALSE.
       lpPSExtDevmode->dm.custPaper[iCurCustPap].Transverse = FALSE;
    }

    if(!lpPSExtDevmode->dm.custPaper[iCurCustPap].Transverse)
    {
       lpPSExtDevmode->dm.custPaper[iCurCustPap].customWidth =
           (float)max(lpPrinterInfo->custpageinfo.width.min, MIN_CUST_SIZE);
       lpPSExtDevmode->dm.custPaper[iCurCustPap].customHeight =
           (float)max(lpPrinterInfo->custpageinfo.height.min, MIN_CUST_SIZE);
//       lpPSExtDevmode->dm.custPaper[iCurCustPap].widthOffset =
//           lpPrinterInfo->custpageinfo.widthOffset.min ;
//       lpPSExtDevmode->dm.custPaper[iCurCustPap].heightOffset =
//           lpPrinterInfo->custpageinfo.heightOffset.min ;
    }
    else
    {
       lpPSExtDevmode->dm.custPaper[iCurCustPap].customWidth =
           (float)max(lpPrinterInfo->custpageinfo.height.min, MIN_CUST_SIZE);
       lpPSExtDevmode->dm.custPaper[iCurCustPap].customHeight =
           (float)max(lpPrinterInfo->custpageinfo.width.min, MIN_CUST_SIZE);
// do not swap offsets
//       lpPSExtDevmode->dm.custPaper[iCurCustPap].widthOffset =
//           lpPrinterInfo->custpageinfo.heightOffset.min ;
//       lpPSExtDevmode->dm.custPaper[iCurCustPap].heightOffset =
//           lpPrinterInfo->custpageinfo.widthOffset.min ;
    }
    lpPSExtDevmode->dm.custPaper[iCurCustPap].widthOffset =
                lpPrinterInfo->custpageinfo.widthOffset.min ;
    lpPSExtDevmode->dm.custPaper[iCurCustPap].heightOffset =
                lpPrinterInfo->custpageinfo.heightOffset.min ;
}

#pragma  optimize ("d", off)
#pragma  optimize ("se", on)


/*****************************************************************************/
/*                 CHCustomPaperDlg                                          */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the Custom Paper Size dialog box                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHCustomPaperDlg(HWND hDlg, unsigned imsg,
                                         WORD wParam, LONG lParam)
{
    LPDRIVERINFO   lpDrvInfo;
    LPPSEXTDEVMODE lpPSExtDevmode, lpPSExtSavedDevmode;

    if(lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
    {
#ifdef USEHOOKPROC
        /* Process hook function stuff */
        if(DrvProcessHookProc(&(lpDrvInfo->pDev),hDlg,imsg,wParam,lParam,
                              "HookSetup"))
        {
            return TRUE;
        }
#endif
        lpPSExtDevmode = lpDrvInfo->lpDM;
    }

    switch (imsg)
    {
        case WM_INITDIALOG:
            lpDrvInfo=(LPDRIVERINFO)lParam;
            SetWindowLong(hDlg, DWL_USER, (LPARAM)lpDrvInfo);
            lpPSExtDevmode=lpDrvInfo->lpDM;

            lpDrvInfo->hSavedDevmode = GlobalAlloc(GHND, sizeof(PSEXTDEVMODE));
            lpPSExtSavedDevmode =
                (LPPSEXTDEVMODE)GlobalLock(lpDrvInfo->hSavedDevmode);
            *lpPSExtSavedDevmode = *lpPSExtDevmode;
            GlobalUnlock(lpDrvInfo->hSavedDevmode);

            InitCustomPaperDlg(hDlg, lpDrvInfo);
            DisplayCustomPaperDlg(hDlg, lpDrvInfo);
            break;

        case WM_CONTEXTMENU:
            if (wParam != -1)
            {
                WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                        (DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_HELP:
            if (((LPHELPINFO) lParam)->hItemHandle != -1)
            {
                WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                        HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                    if (lpPSExtDevmode->dm.currentCustPaper < CUSTOM_LAST)
                    {
                        if(!SaveCustomPaperDlg(hDlg,lpDrvInfo))
                            break;

                        GlobalFree(lpDrvInfo->hSavedDevmode);

                        EndDialog(hDlg, wParam) ;
                    }
                    break;

                case IDCANCEL:
                    /* Reset the Data */
                    lpPSExtSavedDevmode =
                        (LPPSEXTDEVMODE)GlobalLock(lpDrvInfo->hSavedDevmode);
                    *lpPSExtDevmode = *lpPSExtSavedDevmode;
                    GlobalUnlock(lpDrvInfo->hSavedDevmode);
                    GlobalFree(lpDrvInfo->hSavedDevmode);

                    EndDialog(hDlg, wParam) ;
                    break ;

                case ID_RESTORE_DEFAULTS:
                    RestoreCustPapDefaults(lpDrvInfo->lpDM,
                                           lpDrvInfo->pDev.lpWPXblock);
                    SetCustomSpinRange(hDlg, lpDrvInfo, IsDlgButtonChecked(hDlg,ID_CP_INCHES));
                    DisplayCustomPaperDlg(hDlg, lpDrvInfo);
                    break;

                case ID_CUST_TRANSVERSE:
                    {
                        BOOL  bInches = IsDlgButtonChecked(hDlg, ID_CP_INCHES);

                        lpPSExtDevmode->dm.custPaper[lpPSExtDevmode->dm.currentCustPaper].Transverse
                                   = IsDlgButtonChecked(hDlg,ID_CUST_TRANSVERSE);

                        SetCustomSpinRange(hDlg, lpDrvInfo, bInches);

                        SetCurrentSpinPos(hDlg, ID_CUST_X_OFFSET_SPN,
                                          ID_CUST_X_OFFSET, 4, bInches ? 2 : 1);

                    }
                    break;

                case ID_CP_INCHES:
                case ID_CP_MILLIMETERS:
                    /*
                     * These two controls don't use the AUTORADIOBUTTON
                     * style. This lets us retrieve the current size
                     * in the old units, then change the units and
                     * display the units in the new size. It also means
                     * that we need to explicitly set the new state.
                     * Don't do anything if the button for the current
                     * state is being pressed.
                     */
                    if(!IsDlgButtonChecked(hDlg,wParam))
                    {
                        WORD custom[4];

                        HandleMetricChange(hDlg,custom,4,ID_CUST_X_OFFSET_SPN,
                                           ID_CUST_X_OFFSET, wParam,
                                           SetCustomSpinRange, lpDrvInfo);
                    }
                    break;

                case ID_CUST_X_OFFSET:
                case ID_CUST_Y_OFFSET:
                case CUST_X_SIZE:
                case CUST_Y_SIZE:
                    if (HIWORD(lParam) == EN_CHANGE)
                    {
                        HandleEditControlChange(hDlg, ID_CUST_X_OFFSET_SPN,
                                        ID_CUST_X_OFFSET, wParam,
                                        IsDlgButtonChecked(hDlg, ID_CP_INCHES));
                    }
                    break;

#ifndef USE_WHATSTHIS_HELP
                case ID_HELP:
                    WinHelp(hDlg, szHelpFile, HELP_CONTEXT,
                            IDH_PSCRIPT_DFN_CUSTOM);
                    break;
#endif

                default:
                    return FALSE;

            } /* switch(wParam) */
            break ;

        case WM_VSCROLL:
            {
                WORD wID;

                switch (wID = GetDlgCtrlID(HIWORD(lParam)))
                {
                    case ID_CUST_X_OFFSET_SPN:
                    case ID_CUST_Y_OFFSET_SPN:
                    case CUST_X_SIZE_SPN:
                    case CUST_Y_SIZE_SPN:
                        HandleSpinControlChange(hDlg, ID_CUST_X_OFFSET_SPN,
                                         ID_CUST_X_OFFSET, wID, LOWORD(lParam),
                                         IsDlgButtonChecked(hDlg,ID_CP_INCHES));
                        break;
                }
            }
            break;

        default:
            return FALSE;
    } /* switch(imsg) */

    return TRUE;
}
