/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: ADDPRN.H                                               */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

UINT CALLBACK AddPrinterHookProc(HWND hDlg, UINT msg, WPARAM wParam,
                                 LPARAM lParam);
BOOL AddPPDFile(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode,
                HWND hDlg, LPSTR lpPathToPPD, LPSTR lpszDevType);
LPSTR GetPPDNickname(LPSTR FilePathToPPD);
