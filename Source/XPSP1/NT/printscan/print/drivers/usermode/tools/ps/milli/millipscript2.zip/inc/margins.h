/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: MARGINS.H                                              */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHMarginsDlg(HWND hDlg, unsigned imsg,
                                     WORD wParam, LONG lParam);

