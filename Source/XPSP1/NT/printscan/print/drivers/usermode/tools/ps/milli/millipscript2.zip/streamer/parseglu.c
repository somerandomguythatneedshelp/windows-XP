/*
  streamer.c

  Stream characters from an Adobe Type 1 font.

           Copyright 1994 -- Adobe Systems Incorporated
    PostScript is a registered trademark of Adobe Systems Incorporated.

    NOTICE:  All information contained herein or attendant hereto is, and
    remains, the property of Adobe Systems, Inc.  Many of the intellectual
    and technical concepts contained herein are proprietary to Adobe Systems,
    Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
    are protected as trade secrets.  Any dissemination of this information or
    reproduction of this material are strictly forbidden unless prior written
    permission is obtained from Adobe Systems, Inc.

Original version: Ron Fischer, Wednesday March 2nd, 1994

Return values:  Parser callbacks return 1 (true) if OK, 0 (false) on failure.
		The parse itself return PE_NOERR (0) on success, and a 
		non-zero PE_????? value (listed in parse.h) on failure.
*/


#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif

#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES
#include BUILDCH
#include PARSE
#include BLEND

#include STREAMER

#if CID
#include CIDGLUE
#include DECO_LIB
#endif

#define BAD_FONT_NAMES       PE_READ
#define PAINT_TYPE_NOT_ZERO  PE_BADFILE

/* Until there is an official way to do this, use this definition */
#define SIZEOF_DESIGNSPACE	3

/* ".notdef" only needs to be defined once if it is never freed. */
#define NOTDEF	".notdef"

/* When allocating othersubrs add a little more to each actual alloc call to 
   prevent too many from occuring.  Keep track of the current allocated size */
#define OTHERSUBR_EXTRA	256
PRIVATE Card16 otherSubrAlloc;


/*
   The procedures contained in this file implement a sample 'glue' over the
   raw ParseFont interface to ATM.  A standard set of call-back procedures,
   required by ParseFont, are provided in order to simplify usage.
   The main entry points are T1FontParse and T1FontRelease.
   T1FontParse returns a pointer to a T1FontRec structure (defined in
   parseglue.h).  The memory required by the pieces of the structure are
   allocated through a call-back routine passed into ??.
   T1FontRelease releases the memory occupied by all the components of
   the T1FontRec whose pointer is passed in.

*/

/* A pointer or handle to the newly allocated T1FontRec structure to be filled
   in.  It must be cleared out so that all of the pointers contained within
   the struture start out as NULL.  If an error occurs during parsing,
   recovery consists of releasing any allocated memory.  Any pointer which is
   not NULL is assumed allocated.  */

PRIVATE T1FontHandle      newFontHandle = NULL;
PRIVATE boolean         isStdEncoding;
PRIVATE Int16           nextOpenSlot;
extern  boolean         debug_parse;
extern  char            *stdEnc[];
PRIVATE IntX            curBaseFont;    /* used by call backs */
PRIVATE FontDesc        *fontDPtr;      /* used by call backs */

#if CID 
PRIVATE IntX usefontId;
PRIVATE IntX numCodes = 0;
PRIVATE deco_Record *codeList = NULL;
PRIVATE CMapHandle 	newCMapHandle;	/* used by call backs */
#endif /* CID */

/*************** PROCEDURE DECLARATIONS *************/

boolean GrowBuff ARGDECL4(PGrowableBuffer, pgb, Int32, minMore, boolean, copy,
   void *, pClientHook);

/* Forward procedure declarations for the standard call-back procedures.   */

PRIVATE void KillMem ARGDECL1(void **, handle);
PRIVATE boolean NewMem ARGDECL2(void **, handle, Card32, len);

PRIVATE boolean UseStandardEncoding ARGDECL0();
PRIVATE boolean UseSpecialEncoding ARGDECL1(IntX, count);
PRIVATE boolean SpecialEncoding ARGDECL2(IntX, i, char *, s);
PRIVATE boolean UseStandardAccentEncoding ARGDECL0();
PRIVATE boolean UseSpecialAccentEncoding ARGDECL1(IntX, count);
PRIVATE boolean SpecialAccentEncoding ARGDECL2(IntX, i, char *, charname);
PRIVATE boolean StartEexecSection ARGDECL0();
PRIVATE boolean FontType ARGDECL1(Int32, fontType);
PRIVATE boolean FontName ARGDECL1(char *, name);
PRIVATE boolean BaseMMFontName ARGDECL1(char *, name);
PRIVATE boolean Notice ARGDECL1(char *, str);
PRIVATE boolean FullName ARGDECL1(char *, name);
PRIVATE boolean FamilyName ARGDECL1(char *, name);
PRIVATE boolean Weight ARGDECL1(char *, str);
PRIVATE boolean Version ARGDECL1(char *, str);
PRIVATE boolean ItalicAngle ARGDECL1(Fixed, p);
PRIVATE boolean isFixedPitch ARGDECL1(boolean, flg);
PRIVATE boolean UnderlinePosition ARGDECL1(Fixed, p);
PRIVATE boolean UnderlineThickness ARGDECL1(Fixed, p);
PRIVATE boolean PublicUniqueID ARGDECL1(Int32, id);
PRIVATE boolean OtherSubrs ARGDECL2(Card8 *, s, Card16, count);
PRIVATE boolean AllocCharStrings ARGDECL1(IntX, count);
PRIVATE boolean CommonAllocCharStrings ARGDECL2(IntX, count, boolean, lengthsFlag);

#if RANDOMACCESS
PRIVATE boolean CharString ARGDECL6(CardX, buffNum, CardX, byteNum,
                                    Card32, cryptNum, char *, key,
                                    CharDataPtr, val, CardX, len);
#else
PRIVATE boolean CharString ARGDECL3(char *,key, CharDataPtr, val, CardX, len);
#endif

PRIVATE boolean ShareCharStrings ARGDECL1(char *, fontname);
PRIVATE boolean AllocSubroutines ARGDECL1(IntX, count);
PRIVATE boolean Subroutine ARGDECL3(IntX, index, CharDataPtr, val, CardX, len);
PRIVATE boolean ShareSubroutines ARGDECL1(char *, fontname);
PRIVATE boolean WeightVector ARGDECL2(Fixed *, wv, IntX, wvlen);
PRIVATE boolean ResizeFontDesc ARGDECL2(FontDesc **, fontdescp, Card32, size);
PRIVATE boolean BlendNumberDesigns ARGDECL1(CardX, n);
PRIVATE boolean BlendNumberAxes ARGDECL1(CardX, n);
PRIVATE boolean BlendAxisType ARGDECL2(CardX, axis, char *,name);
PRIVATE boolean BlendDesignMapping ARGDECL4(CardX, axis, int, n,
                                            Fixed *, from, Fixed *,to);
PRIVATE boolean BlendDesignPositions ARGDECL2(int, blend, Fixed, *pos);
PRIVATE boolean BlendUnderlinePosition ARGDECL2(int, blend, Fixed, x);
PRIVATE boolean BlendUnderlineThickness ARGDECL2(int, blend, Fixed, x);
PRIVATE boolean BlendItalicAngle ARGDECL2(int, blend, Fixed, x);

#if CID

/* new composite font support */
PRIVATE boolean GDBytes ARGDECL1(Int32, n);
PRIVATE boolean FDBytes ARGDECL1(Int32, n);
PRIVATE boolean CIDCount ARGDECL1(Int32, n);
PRIVATE boolean CIDMapOffset ARGDECL1(Int32, n);
PRIVATE boolean CIDFontVersion ARGDECL1(Int32, n);
PRIVATE boolean Registry ARGDECL1(char *, name);
PRIVATE boolean Ordering ARGDECL1(char *, name);
PRIVATE boolean Supplement ARGDECL1(Int32, n);
PRIVATE boolean FDArrayFontName ARGDECL1(char *, name);
PRIVATE boolean CIDFDArray ARGDECL1(Int32, n);
PRIVATE boolean CIDStartData ARGDECL2(CardX, buffNum, CardX, byteNum);
PRIVATE boolean BeginCIDFontDict ARGDECL2(Int32, i, FontDesc **, fontp);
PRIVATE boolean EndCIDFontDict ARGDECL1(Int32, i);
PRIVATE boolean UIDBase ARGDECL1(Int32, n);
PRIVATE boolean XUID ARGDECL3(Int32, v1, Int32, v2, Int32, v3);

PRIVATE boolean SDBytes ARGDECL1(Int32, n);
PRIVATE boolean SubrMapOffset ARGDECL1(Int32, n);
PRIVATE boolean SubrCount ARGDECL1(Int32, n);

/* encoding files and rearranged font */
PRIVATE boolean cidrange ARGDECL5(Card32, srcCodeLo, IntX, srcCodeLoLen,
                 Card32, srcCodeHi, IntX, srcCodeHiLen, Card32, dstGlyphIDLo);

PRIVATE  boolean cidchar ARGDECL3(Card32, srcCode, IntX, srcCodeLen, 
                    Card32, dstGlyphID);
PRIVATE  boolean notdefchar ARGDECL3(Card32, srcCode, IntX, srcCodeLen, 
                    Card32, dstGlyphID); 
PRIVATE  boolean notdefrange ARGDECL5(Card32, srcCodeLo, IntX, srcCodeLoLen, 
                 Card32, srcCodeHi, IntX, srcCodeHiLen, Card32, dstGlyphIDLo);
PRIVATE  boolean codespacerange ARGDECL4(Card32, srcCode1, IntX, srcCode1Len, 
                    Card32, srcCode2, IntX, srcCode2Len);
PRIVATE  boolean rearrangedfont ARGDECL1(char *, name);
PRIVATE  boolean componentfont ARGDECL2(IntX, i, char *, name);
PRIVATE  boolean endcomponentfont ARGDECL1(IntX, i);
PRIVATE  boolean usematrix ARGDECL2(IntX, i, FixMtx, *m);
PRIVATE  boolean usefont ARGDECL1(Card16, i);
PRIVATE  boolean bfrange_code ARGDECL5(Card32, srcCodeLo, IntX, srcCodeLoLen,
                     Card32, srcCodeHi, IntX, srcCodeHiLen, Card32, dstCodeLo);
PRIVATE  boolean bfrange_name ARGDECL6(Card32, srcCodeLo, IntX, srcCodeLoLen, 
            Card32, srcCodeHi, IntX, srcCodeHiLen, IntX, i, char *, dstChar);
PRIVATE  boolean bfchar_code ARGDECL3(Card32, srcCode, IntX, srcCodeLen, 
                    Card32, dstCode);
PRIVATE  boolean bfchar_name ARGDECL3(Card32, srcCode, IntX, srcCodeLen, 
                    char *, dstCharName);
PRIVATE  boolean UseCMap ARGDECL1(char *, name);
PRIVATE boolean GetCIDSubrs ARGDECL0();

#endif /* CID */


/* parseProcs is a structure containing the call-back procedures used by
   ParseFont.  It is filled in with the glue's standard call-back procedures. */

PRIVATE ParseFontProcs parseProcs = {
   NULL,		/* GetBytes initialized by T1FontParse() */
   GrowBuff,
   UseStandardEncoding,
   UseSpecialEncoding,
   SpecialEncoding,
   UseStandardAccentEncoding,
   UseSpecialAccentEncoding,
   SpecialAccentEncoding,

   StartEexecSection,
   FontType,
   FontName,
   BaseMMFontName,
   Notice,
   FullName,
   FamilyName,
   Weight,
   Version,
   ItalicAngle,
   isFixedPitch,
   UnderlinePosition,
   UnderlineThickness,
   PublicUniqueID,
   OtherSubrs,
#if STREAMFONT
   NULL,		/* These are set it T1FontParse() */
   NULL,
   NULL,
#endif /* STREAMFONT */
   AllocCharStrings,
   CharString,
   ShareCharStrings,
   AllocSubroutines,
   Subroutine,
   ShareSubroutines,
   WeightVector,
   ResizeFontDesc,
   BlendNumberDesigns,
   BlendNumberAxes,
   BlendAxisType,
   BlendDesignMapping,
   BlendDesignPositions,
   BlendUnderlinePosition,
   BlendUnderlineThickness,
   BlendItalicAngle,

#if CID
/* new composite font support */
    GDBytes,
    FDBytes,
    CIDCount,
    CIDMapOffset,
    CIDFontVersion,
    Registry,
    Ordering,
    Supplement,
    FDArrayFontName,
    CIDFDArray,
    BeginCIDFontDict,
    EndCIDFontDict,
    CIDStartData,
    UIDBase,
    XUID,
    SDBytes,
    SubrMapOffset,
    SubrCount,
    cidrange,
    cidchar,
    notdefchar,
    notdefrange,
    codespacerange,
    rearrangedfont,
    componentfont,
    endcomponentfont,
    usematrix,
    usefont,
    bfrange_code,
    bfrange_name,
    bfchar_code,
    bfchar_name,
    UseCMap
    
#endif /* CID */
  };

/*
   Memory handling routines.

   All memory handling is funneled through the following routines, to keep
   the general code simple, readable, and maintainable.
*/


PRIVATE MemoryRec memoryBuf;
PRIVATE GrowableBuffer gbuff[5];
/* Realloc routine provided by application */
PRIVATE ReallocFunc MemoryRealloc;  


/*************************************************************************

Function name:  T1ParseInit()

**************************************************************************

Date:           01/22/93
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Init the growable buffers.
Description:    Inits the growable buffers and establishes the
                application's memory reallocation function.  Also calls
                InitParseTables().

Parameters:     MemRealloc - the memory reallocation function.
Return Values:  ST_NOERR if no error, PE_CALLER if out of memory,
                otherwise, returns the code from InitParseTables().

Notes:          The return value in the manual is described incorrectly.
See also:       InitParseTables().
**************************************************************************/

IntX T1ParseInit ARGDEF1(ReallocFunc, MemRealloc)
{
  Card32 len[5];
  IntX i;
  IntX code;

  MemoryRealloc = MemRealloc;

  len[0] = 16 * 1024;
  len[1] =  2 * 1024;
  len[2] =  3 * 1024;
  len[3] =  0 * 1024;           /* Unused, save the memory! */
  len[4] =  0 * 1024;

  if ((code = InitParseTables()) != PE_NOERR) return code;

  for(i = 0; i < 5; i++) {
    gbuff[i].ptr = NULL;
    gbuff[i].len = len[i];
    if(len[i] == 0) continue;
    if(!(*MemoryRealloc)((void **)&(gbuff[i].ptr), len[i])) return PE_CALLER;
  }
  memoryBuf.b1 = &gbuff[0];
  memoryBuf.b2 = &gbuff[1];
  memoryBuf.b3 = &gbuff[2];
  memoryBuf.b4 = &gbuff[3];
  memoryBuf.b5 = &gbuff[4];

  return ST_NOERR;
} /* end T1ParseInit() */


/*************************************************************************

Function name:  T1ParseDeinit()

**************************************************************************

Date:           01/22/93
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Frees the growable buffers
Description:    Frees the growable buffers and calls Terminate to free
                any mem the render may be hogging.

Parameters:     none
Return Values:  none
See also:       T1ParseInit()
**************************************************************************/

void T1ParseDeinit ARGDEF0()
{
  IntX i;

  for(i = 0; i < 5; i++) {
    if(gbuff[i].ptr != NULL) {
      (*MemoryRealloc)((void **)&(gbuff[i].ptr),(Card32)0);
      gbuff[i].len = (Card32)0;
    }
  }
} /* end T1ParseDeinit() */


/*************************************************************************

Function name:  GrowBuff()

**************************************************************************

Date:           01/22/93
Author:         Ron Fischer (rff)
Prototype in:   none
Summary:        Expands a buffer.
Description:    

Takes the address of one of the growable buffers and the minimum size which
the growable buffer should be grown to.  The buffer is then made to be at
least the minimum size. The size is doubled, if possible, but the size of
the buffer is not allowed to increase by more than ATM_MAX_GROWTH.

If the buffer was expanded, GrowBuffer returns true.  Otherwise, it
returns false.  If it returns false, the buffer should not have changed. The
contents of the buffer must be preserved.

This code assumes CSCAN_MAX_BUFSIZE is set to the maximum size any grow buffer
can get.  For instance, in the case of the PC (in non-flat mode), the value
would be something like 65504.  Note that 65536 could be a poor choice to 
check for because most allocation routines take up some overhead space, and 
that value would assume none was taken.

Parameters:     pgb - Pointer to the growable buffer structure.
		minMore - The minimum more to expand the buffer by (should be
			chosen with efficiency considerations in mind).
		copy - flag indicating that an attempt should be made to save
			the data when expanding the buffer.
		pClientHook - client data passed around.
Return Values:  false if it fails, true if it succeeds.
Notes: 		
See also:       
**************************************************************************/

boolean GrowBuff ARGDEF4(PGrowableBuffer, pgb, Int32, minMore, boolean, copy,
   void *, pClientHook)
{
Card32 growSize;

growSize = pgb->len + minMore;
if (growSize > CSCAN_MAX_BUFSIZE) 
   return false;

if (copy)  				/* Resize  the buffer */
 { if (!(*MemoryRealloc)((void **)&(pgb->ptr), growSize)) 
      return false;
 } /* end if */
else    /* is this faster than the copy branch ? */
 { (*MemoryRealloc)((void **)&(pgb->ptr),(Card32)0);
   (*MemoryRealloc)((void **)&(pgb->ptr),(Card32)growSize);
   if(pgb->ptr == NULL) return false;
 } /* end else */
pgb->len = (Card32)growSize;

return true;
} /* end GrowBuff() */



PRIVATE void KillMem ARGDEF1(void **, handle)
  {
   if(*handle == NULL) return;
   (*MemoryRealloc)(handle, 0L);
   *handle = NULL;
  }

PRIVATE boolean NewMem ARGDEF2(void **, handle, Card32, len)
  {
   return((*MemoryRealloc)(handle, len));
  }

/*
   NEWDATA

   Every call to NEWDATA allocates memory.

   Note that some of the call-backs may give back pointers which already
   point to the beginning of the growable buffer area.  This is checked for
   as an optimization.  Also note that the pointer can never point to just
   before the beginning of the growable buffer area.  The only overlap which
   can occur between the source and the destination areas in the first
   buffer move is one in which the move will succeed.
*/

#if OS!=os_thinkc	/* Think C doesn't like this macro */
#define NEWDATA(handle, data, len)  (NewMem(handle, len) ?    \
         (MEMMOVE(((const char *)data), *(handle), len), true) : false)
#else  /* OS == os_thinkc */

PRIVATE boolean NEWDATA ARGDEF3(void **, handle, Card8 *, data, Card32, len)  
{
if (NewMem(handle, len))
 { MEMMOVE(((const char *)data), *(handle), len);
   return true;
 } /* end if */
else
   return false;
} /* end NEWDATA() */
#endif /* OS == os_thinkc */


#if OS!=os_thinkc	/* Think C doesn't like this macro */
#define NEWMEM(handle, len)  (NewMem(handle, len) ?           \
                              (MEMZERO(*(handle), len), true) : false)
#else  /* OS == os_thinkc */

PRIVATE boolean  NEWMEM ARGDEF2(void **, handle, Card32, len)  
{
if (NewMem(handle, len))
 { MEMZERO(*(handle), len);
   return true;
 } /* end if */
else
   return false;
} /* end NEWMEM() */

#endif /* OS == os_thinkc */


/*************************************************************************

Function name:  AllocSubStructs()

**************************************************************************

Date:           10/21/92
Author:         Ron Fischer (rff)
Prototype in:   none
Summary:        Allocates the sub structures in a T1FontRec
Description:    
                
Parameters:     
                
Return Values:  
See also:       

**************************************************************************/

PRIVATE IntX AllocSubStructs ARGDEF1(T1FontPointer, fontP)
{
IntX i;

if (!NEWMEM((void **)&fontP->pFontDict, sizeof(FontDesc *) * 
            fontP->numBaseFonts))
   return PE_CALLER;

if (!NEWMEM((void **)&fontP->pFontInst, sizeof(FontInst *) *
             fontP->numBaseFonts))
   return PE_CALLER;

if (!NEWMEM((void **)&fontP->subrLengths, sizeof(Card16 *) *
             fontP->numBaseFonts))
   return PE_CALLER;

if (!NEWMEM((void **)&fontP->pSubrArray, sizeof(CharDataPtr *) *
             fontP->numBaseFonts))
   return PE_CALLER;

for (i = 0; i < fontP->numBaseFonts; i++) 
   if (!NEWMEM((void **)&(fontP->pFontDict[i]), sizeof(FontDesc))) 
      return PE_CALLER;

#if CID /* CID fonts only.  */
if (fontP->isCID)
 { /* Name of each dictionary */
   if (!NEWMEM((void **)&fontP->FDArrayFontName, sizeof(char *) * 
            fontP->numBaseFonts))
      return PE_CALLER;

   if (!NEWMEM((void **)&fontP->SDBytes, sizeof(Int32 *) * 
            fontP->numBaseFonts))
      return PE_CALLER;

   if (!NEWMEM((void **)&fontP->subrMapOffset, sizeof(Int32 *) * 
            fontP->numBaseFonts))
      return PE_CALLER;

   if (!NEWMEM((void **)&fontP->subrCount, sizeof(Int32 *) * 
            fontP->numBaseFonts))
      return PE_CALLER;

   /* Note that this fills the memory with zeros, thus initializing the */
   /* doubleEncryption array entries to false. */
   if (!NEWMEM((void **)&fontP->doubleEncryption, sizeof(Card8) * 
            fontP->numBaseFonts))
      return PE_CALLER;
 } /* end if */
#endif /* CID */

return PE_NOERR;
} /* end AllocSubStructs() */



/*************************************************************************

Function name:  T1FontParse()

**************************************************************************

Date:           01/14/93 (comments added)
                03/06/94 Modified for streamer program
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Create and fill in in a T1FontRec structure.
Description:    This routine reads a font file and parses it, setting up
		the T1FontRec and other important structures and arrays.
                
Parameters:     font - the handle to the font to create
		GetBytesFunc - The call-back that reads in the raw data.
                
Return Values:  PE_NOERR if all is OK, PE_CALLER if a generic error is found.
		Other return values come from the parser.
Notes:   	The T1FontHandle can be moved around but the buffer from
		GetBytesFunc and the first growable buffer cannot.  (The
		low-level parser assumes that these structures are locked
		down).

See also:       T1FontRelease()

**************************************************************************/
 
IntX T1FontParse ARGDEF9(T1FontHandle, font, GetBytesFunc, GetBytes,
     AllocCharStringsFunc, UAllocCharStrings, CharStringFunc, UCharString,
     AllocSubroutinesFunc, UAllocSubroutines, SubroutineFunc, USubroutine,
     FontDataStreamFunc, FontDataStream, KeyPositionFunc, KeyPosition,
	 FontAttributeFunc, FontAttribute)
{
   IntX retValue;
   IntX charIndex;

   newFontHandle = font;
   parseProcs.GetBytes = GetBytes;

   /* Does the user want the full font data stream? */
   parseProcs.FontDataStream = FontDataStream;
   parseProcs.KeyPosition = KeyPosition;
   parseProcs.FontAttribute = FontAttribute;
   /* Does the user want to handle these?  (or should I) */
   if ((UAllocCharStrings != NULL) && (UCharString != NULL))
    { parseProcs.AllocCharStrings = UAllocCharStrings;
      parseProcs.CharString = UCharString;
    } /* end if */
   else
    { parseProcs.AllocCharStrings = AllocCharStrings;
      parseProcs.CharString = CharString;
    } /* end if */

   if ((UAllocSubroutines != NULL) && (USubroutine != NULL))
    { parseProcs.AllocSubroutines = UAllocSubroutines;
      parseProcs.Subroutine = USubroutine;
    } /* end if */
   else
    { parseProcs.AllocSubroutines = AllocSubroutines;
      parseProcs.Subroutine = Subroutine;
    } /* end if */

/* Allocate the new T1FontRec structure and clear it out.  When doing memory
   recovery, it is assumed that anything non-NULL has been allocated and
   must be released.
*/
   *newFontHandle = (T1FontPointer)NULL;
   if (!NEWMEM((void **)newFontHandle, sizeof(T1FontRec)))
     return PE_CALLER;

   (*newFontHandle)->numBaseFonts = MAX_ROMAN_FONTS;
   (*newFontHandle)->isCID = false;

   /* The buildChar array is initialized at run time */
   (*newFontHandle)->buildCharArray = NULL;
   /* Initially this is not a synthetic font */
   (*newFontHandle)->baseFontName = NULL;
   /* This is just a default.  This value should be set by an application */
   (*newFontHandle)->standardSubrs = true;
   otherSubrAlloc = 0;		/* No other subrs alloced yet */

   /*Init base font name for mm Master. Will be use by 
   TektonMM-Oblique that uses TektonMM. Not for actual MM instance*/
   (*newFontHandle)->baseMMFontName = NULL;


   if (AllocSubStructs(*newFontHandle) != PE_NOERR)
    { T1FontRelease(newFontHandle);
      return PE_CALLER;
    } /* end if */

   /* Parse the font. */
   curBaseFont = 0;
   fontDPtr = (*newFontHandle)->pFontDict[0];
   retValue = ParseFont(&((*newFontHandle)->pFontDict[0]), &parseProcs,
                        memoryBuf.b2, memoryBuf.b3, NULL);

   if (retValue != PE_NOERR) {
      T1FontRelease(font);
      return retValue;
     }

   /* This code may no longer be valid.  Since I take the charstrings in */
   /* on a first come-first serve basis I don't try to put them in a standard*/
   /* order... */
   (*newFontHandle)->hasStandardCharacters = true;

   for (charIndex = 0; (charIndex < ATM_NUMBER_GLYPHS) &&
                       (charIndex < (*newFontHandle)->numCharStrings); 
                       charIndex++) 
    { if ((((*newFontHandle)->charNames)[charIndex] == NULL) ||
          (((*newFontHandle)->charNames)[charIndex] !=
           standardGlyphList[charIndex])) 
       { (*newFontHandle)->hasStandardCharacters = false;
         break;
       } /* end if */
    } /* end for */

     /* Set the Encoding pointer to the standard or special encoding */
   (*newFontHandle)->hasStandardEncoding = isStdEncoding;
   if (isStdEncoding)
      (*newFontHandle)->encoding = standardEncoding;
 /* If it's not standard encoding the specialEncoding structure should be set*/

   return retValue;
} /* end T1FontParse() */


#if CID

/*************************************************************************

Function name:  ATMGetCIDFont()

**************************************************************************

Date:           03/05/93
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Create and fill in in a T1FontRec structure for CID fonts.
Description:    This routine reads a font file and parses it, setting up
		the T1FontRec and other important structures and arrays.
		The T1FontRec for CID fonts takes up considerably more
		space than the "Roman" T1FontRec.
                
Parameters:     font - the handle to the font to create
		GetBytesFunc - The call-back that reads in the raw data.
		fontPath - The full name/path for the font file.
                
Return Values:  PE_NOERR if all is OK, PE_CALLER if an error is found.
Notes:   	The T1FontHandle can be moved around but the buffer from
		GetBytesFunc and the first growable buffer cannot.  (The
		low-level parser assumes that these structures are locked
		down).

See also:       T1FontParse(), T1FontRelease()
		Adobe CID-Keyed Font Files Specification

**************************************************************************/


#if HC386 /* HC refuses to convert char to const char, even with casts */
IntX ATMGetCIDFont ARGDEF3(T1FontHandle, font, GetBytesFunc, GetBytes,
                           char *, fontPath)
#else
IntX ATMGetCIDFont ARGDEF3(T1FontHandle, font, GetBytesFunc, GetBytes,
                           Card8 *, fontPath)
#endif
{
IntX i,code;
FontDesc        dummyDesc;      /* Parse requires a FontDesc.  But for CID
				fonts there will be multiple font descs,
				allocated after parsing begins (and the
				correct number of descs is determined). */

newFontHandle = font;
parseProcs.GetBytes = GetBytes;

/* Allocate the new T1FontRec structure and clear it out.  When doing memory
   recovery, it is assumed that anything non-NULL has been allocated and
   must be released.  */

*newFontHandle = (T1FontPointer)NULL;
if (!NEWMEM((void **)newFontHandle, sizeof(T1FontRec)))
   return PE_CALLER;

(*newFontHandle)->numBaseFonts = 0; 
(*newFontHandle)->isDBCS = false;
(*newFontHandle)->isCID = true;

/* Save the font path */
if (!NEWDATA((void **)&((*newFontHandle)->fontPath), fontPath,
             os_strlen((char *)fontPath) + 1))
 { T1FontRelease(newFontHandle);
   return PE_CALLER;
 } /* end if */

curBaseFont = -1;
i = IOFuncs.OpenFunc((char *)fontPath, READ_MODE | BINARY_DATA);
if (i == -1)
 { T1FontRelease(newFontHandle);
   return(PE_READ);
 } /* end if */

    /* Parse the font */
fontDPtr = &dummyDesc;
code = ParseFont(&fontDPtr, &parseProcs, memoryBuf.b2, memoryBuf.b3, NULL);
if (code != PE_NOERR) 
 { T1FontRelease(font);
   return code;
 } /* end if */

/* Subrs are no longer hooked to the dicts -- I've got to manually read */
/* them in...  */
if (!GetCIDSubrs())
   return PE_BADFILE;

IOFuncs.CloseFunc();

/* Make sure the number of dictionary index bytes and glyph ID index bytes */
/* are in a valid range. */
if (((*newFontHandle)->FDBytes > MAX_FDBYTES) ||
    ((*newFontHandle)->GDBytes > MAX_GDBYTES) || ((*newFontHandle)->GDBytes < 1))
   return PE_BADFILE;

return PE_NOERR;
} /* end ATMGetCIDFont() */


/*************************************************************************

Function name:  ATMGetCMap()

**************************************************************************

Date:           03/05/93
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Read in a CMap or rearranged font for CIDFonts
Description:    This routine reads a CMap file and parses it, setting up
                a mapping for fonts (usually CID fonts).  It also reads
		rearranged fonts since their syntax is basically the
		same as a CMap.

		Rearranged fonts and "used" (included) CMaps are handled
		by the same technic--recursive calls to this routine.
		The decoder requires it's data to be in a certain order
		so at the end of recursion the data must be reordered with
		the latest block of data going to the head of the list
		(and the 2nd latest next, etc.).
 
Parameters:     cMap - the handle to the cMap to create
		GetBytesFunc - The call-back that reads in the raw data.
		cMapPath - The full name/path for the font file.
                
Return Values:  PE_NOERR if all is OK, PE_CALLER if an error is found.
		Note that the errors should parallel those of 
		ATMGetCIDFont(), although 'font' errors may not seem
		appropriate for a CMap.

Notes:   	On DOS/Windows systems it will try to convert any
		PostScript style names to DOS style names.

See also:       ATMGetCIDFont(), FindDOSFontName()
		Adobe CID-Keyed Font Files Specification

**************************************************************************/


#if HC386 /* HC refuses to convert char to const char, even with casts */
IntX ATMGetCMap ARGDEF3(CMapHandle, cMap, GetBytesFunc, GetBytes, 
		        char *, cMapPath)
#else
IntX ATMGetCMap ARGDEF3(CMapHandle, cMap, GetBytesFunc, GetBytes, 
		        Card8 *, cMapPath)
#endif
{
static int level = 0;			/* Recursion control */

IntX code = PE_NOERR;			/* Return code */
deco_Record range;			/* Record for the sentinel value */
IntX tempNumCodes;			/* Number of codes at this recursion */
deco_Record *tempCodeList;		/* Code list at this recursion */

#if OS==os_msdos || OS==os_os2_32bit
int i;					/* Counter variable */
char *DOSName;				/* DOS file name found */
#endif /* OS==os_msdos || OS==os_os2_32bit */

if (level == 0)				/* Don't do this on recursive calls. */
 { newFontHandle = NULL;		/* Don't use the font handle! */
   /* (Some routines would use this handle if it were non-NULL) */

   newCMapHandle = cMap;		/* My global copy of the cMap */
   *newCMapHandle = (CMapPointer)NULL;
   if (!NEWMEM((void **)newCMapHandle, sizeof(CMapRec)))
      return PE_CALLER;

   parseProcs.GetBytes = GetBytes;

   if (!NEWDATA((void **)&((*newCMapHandle)->cMapPath), cMapPath,
              os_strlen((char *)cMapPath) + 1))
    { KillMem((void **)newCMapHandle);	/* Free the CMap */
      return PE_CALLER;
    } /* end if */
   (*newCMapHandle)->cMapUsed = NULL;	/* Initially no CMap used */

					/* Make some space for the encoding */
   if (!NEWMEM((void **)&(*newCMapHandle)->encoding, sizeof(deco_Encoding)))
    { KillMem((void **)newCMapHandle);	/* Free the CMap */
      return PE_CALLER;
    } /* end if */
 } /* end if */

numCodes = 0;				/* These start out empty (each level)*/
codeList = NULL;

if (IOFuncs.OpenFunc((char *)cMapPath, READ_MODE | BINARY_DATA) == -1)
 { KillMem((void **)newCMapHandle);	/* Free the CMap */
   return PE_READ; 		/* This doesn't free substructs tho! */
 } /* end if */

usefontId = 0;
					/* Reset the cMapUsed field each call */
if ((*newCMapHandle)->cMapUsed != NULL)
   MemoryRealloc((void **)&(*newCMapHandle)->cMapUsed, 0);

/* Parse the CMap */
code = ParseEncoding(&parseProcs, memoryBuf.b2, memoryBuf.b3, NULL);
if (code != PE_NOERR) 
 { KillMem((void **)newCMapHandle);	/* Free the CMap */
   return code;
 } /* end if */

IOFuncs.CloseFunc();

/* If there is a used cmap save the codeList info and recursively call this */
/* Also catches template fonts for rearranged fonts so that they are parsed */
if ((*newCMapHandle)->cMapUsed != NULL)
 { tempCodeList = codeList;		/* Save the current code list */
   tempNumCodes = numCodes;

#if OS==os_msdos || OS==os_os2_32bit

   /* Try to find a DOS equivalent name.  If one isn't found try to use */
   /* the given PostScript name (which will probably fail on open) */
   DOSName = NULL;

   /* If a name is found deallocate PS name and point to DOS name */
   if (!FindDOSFontName((*newCMapHandle)->cMapUsed, &DOSName, CIDFontPath, 
                        CIDDataFile))
    { MemoryRealloc((void **)&(*newCMapHandle)->cMapUsed, 0);
      (*newCMapHandle)->cMapUsed = DOSName;
    } /* end if */

#endif /* OS==os_msdos || OS==os_os2_32bit */

   level++;				/* Going into recursive calls */
   code = ATMGetCMap(cMap, GetBytes, (*newCMapHandle)->cMapUsed);
   level--;

   if (code == PE_NOERR)	 	/* Make the enlarged codeList */
    { if (!(*MemoryRealloc)((void **)&codeList, (numCodes + tempNumCodes) *
                                        sizeof(deco_Record)))
         return false;
					/* Copy codeLists together */
      os_memcpy(codeList+numCodes, tempCodeList, tempNumCodes*sizeof(deco_Record));
      numCodes += tempNumCodes;		/* CodeList is now this long */
    } /* end if */

   (*MemoryRealloc)((void **)&tempCodeList, 0);	/* Free the temp codeList */
 } /* end if */

if ((level == 0) && (code == PE_NOERR))	/* Finish up when back to lowest level*/
 { range.mapType = deco_MAP_END;	
   AddDecoderRange(&range);		/* Encoding requires an END sentinel*/

   /* Make the encoding string that the decoder will be able to use.  This */
   /* function reuses the memory in the codeList so that can't be dealloced.*/
   if (deco_NewEncoding((*newCMapHandle)->encoding, codeList, numCodes))
      return PE_READ;

   codeList = NULL; /* Make sure it doesn't point to the decoding data */
   numCodes = 0;

#if OS==os_msdos || OS==os_os2_32bit

   /* Try to find a DOS equivalent name.  If one isn't found try to use */
   /* the given PostScript name (which will probably fail on open) */
   if ((*newCMapHandle)->encoding->localFontTable != NULL)
    { i = 0;
      while (((*newCMapHandle)->encoding->localFontTable[i] != NULL) &&
             (i < MAX_COMPONENT_FONTS))
       { DOSName = NULL;

	 /* If a name is found deallocate PS name and point to DOS name */
         if (!FindDOSFontName((*newCMapHandle)->encoding->localFontTable[i], 
                              &DOSName, CIDFontPath, CIDDataFile))
          { MemoryRealloc((void **)&(*newCMapHandle)->encoding->localFontTable[i], 0);
            (*newCMapHandle)->encoding->localFontTable[i] = DOSName;
          } /* end if */
         i++;
       } /* end while */
    } /* end if */
 
#endif /* OS==os_msdos || OS==os_os2_32bit */

 } /* end if */

return code;
} /* end ATMGetCMap() */


/*************************************************************************

Function name:  ATMReleaseCMapHandle()

**************************************************************************

Date:           03/08/93 
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Release CMap structure
Description:    
Parameters:     cMap - the handle to the cMap to release.
                
Return Values:  none.

See also:       ATMGetCMap()

**************************************************************************/


void ATMReleaseCMapHandle ARGDEF1(CMapHandle, cMap)
{
int i;
int freeMtx = false,
    freeEncoding = false;

if ((*cMap)->cMapPath != NULL)
   KillMem((void **)&(*cMap)->cMapPath);

if ((*cMap)->registry != NULL)
   KillMem((void **)&(*cMap)->registry);

if ((*cMap)->ordering != NULL)
   KillMem((void **)&(*cMap)->ordering);

if ((*cMap)->cMapUsed != NULL)
   KillMem((void **)&(*cMap)->cMapPath);

if ((*cMap)->useMtx != NULL)
   freeMtx = true;

if (((*cMap)->encoding != NULL) && ((*cMap)->encoding->localFontTable != NULL))
   freeEncoding = true;

for (i = 0; i < MAX_COMPONENT_FONTS; i++)
 { if (freeMtx && ((*cMap)->useMtx[i] != NULL))
      KillMem((void **)&(*cMap)->useMtx[i]);

   if (freeEncoding && ((*cMap)->encoding->localFontTable[i] != NULL))
      KillMem((void **)&(*cMap)->encoding->localFontTable[i]);
   
 } /* end for */

if (freeMtx)
   KillMem((void **)&(*cMap)->useMtx);

if ((*cMap)->encoding != NULL)
 { if ((*cMap)->encoding->localFontTable != NULL)
      KillMem((void **)&(*cMap)->encoding->localFontTable);

   if ((*cMap)->encoding->decoderString != NULL)
      KillMem((void **)&(*cMap)->encoding->decoderString);

   KillMem((void **)&(*cMap)->encoding);
 } /* end if */

KillMem((void **)cMap);
} /* end ATMReleaseCMapHandle() */



/*************************************************************************

Function name:  ATMVerifyCIDVersion()

**************************************************************************

Date:           06/05/93
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Checks to make sure the CID and CMAP file version 
		information is compatible.
Description:    If the font is not a CID font returns false immediately.
		If it is, the Registry and Ordering fields are compared.
		If the fields are identical in both the CID font and the
		CMAP font, true is returned, otherwise false is returned.
                
Parameters:     font - the (CID) font to check
		cMap - the cMap to check
                
Return Values:  true if the versions are compatible, false if they are not.
Notes:          
See also:       ATMGetCMap(), ATMGetCIDFont()
		Adobe CID-Keyed Font Files Specification

**************************************************************************/


CardX ATMVerifyCIDVersion ARGDEF2(T1FontHandle, font, CMapHandle, cMap)
{
/* Pretty severe error -- a NULL pointer passed */
if ((font == NULL) || (*font == NULL))
   return false;
if ((cMap == NULL) || (*cMap == NULL))
   return false;

/* Medium severe -- font passed isn't even a CID font */
if (!(*font)->isCID)
   return false;

/* Compare the registry and ordering */
if (os_strcmp((*font)->registry, (*cMap)->registry) || 
    os_strcmp((*font)->ordering, (*cMap)->ordering))
   return false;

return true;
} /* end ATMVerifyCIDVersion() */

#endif /* CID */


/*************************************************************************

Function name:  T1FontRelease()

**************************************************************************

Date:           01/14/93 (comments added)
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Release Type1 or CID T1FontRec structures.
Description:    When a font is no longer needed this routine will release
		a T1FontRec structure and all of it's substructures and arrays.
		It will not release shared structures if they're usage pointers
		indicate that they are still in use.
                It will free the encoding array if it does not point to
                the standardEncoding array (which is permanent).
                
Parameters:     font - the handle to the font to release.
                
Return Values:  none.

See also:       T1FontParse(), ATMGetCIDFont()

**************************************************************************/

void T1FontRelease ARGDEF1(T1FontHandle, font)
{
register IntX i, j;
boolean  releaseSubrs;

/* *** Release the character strings.  *** */
/* Note that CID do not use the char strings */

KillMem((void **)&((*font)->charLengths));

if ((*font)->charStrings != NULL) 
 { /* Release the individual character strings. */
   for (i = 0 ; i < ((*font)->numCharStrings) ; i++)
   KillMem((void **)&(((*font)->charStrings)[i]));

   /* Release the character string array itself. */
   KillMem((void **)&((*font)->charStrings));
 } /* end if */

/* Release the character names.  Now this is a little more
   tricky.  Some of the character names may actually refer back into
   the standardGlyphList, and these obviously should not be released.
   So the address is checked against the bounds of the standardGlyphList
   array.  And the character string is released only if it is outside
   those boundaries.  */

/* Check to see if the array itself was ever allocated */
if ((*font)->charNames != NULL) 
 { if ((*font)->charNames != standardGlyphList) 
    { for (i = 0; i < ((*font)->numCharStrings); i++)
       { if (((*font)->charNames)[i] != standardGlyphList[i])
           KillMem((void **)&(((*font)->charNames)[i]));
       } /* end for */

      /* Release the array itself. */
      KillMem((void **)&((*font)->charNames));  
    } /* end if */
   else 
      (*font)->charNames = NULL;

 } /* end if */

releaseSubrs = true;

/* For each base font: */
for (j = 0; j < (*font)->numBaseFonts; j++) 
 { /**** Release the subroutines  ****/
   if(releaseSubrs)
    { /* Check to see if the array itself was ever allocated. */
      if ((*font)->pSubrArray[j] != NULL) 
       { /* If the subroutines were allocated, deallocate them */
         if ((*font)->subrLengths[j] != NULL)
          { for (i=0; i<(IntX)((*font)->pFontDict[j]->lenSubrArray); i++)
               KillMem((void **)&((*font)->pSubrArray[j][i]));
            KillMem((void **)&((*font)->subrLengths[j]));
          } /* end if */

         KillMem((void **)&((*font)->pSubrArray[j]));
       } /* end if */
    } /* end if */

   /* Release the fontDicts */
   KillMem((void **)&((*font)->pFontDict[j]));

  if ((*font)->pFontInst[j] != NULL) 
    KillMem((void **)&(*font)->pFontInst[j]);

#if CID
   if ((*font)->isCID)			/* CID fonts use this field */
    { if ((*font)->FDArrayFontName[j])
         KillMem((void **)&(*font)->FDArrayFontName[j]);
    } /* end if */
#endif

 } /* end for */

/* Release the otherSubrs, if there are any */
if ((*font)->pOtherSubrs != NULL)
   KillMem((void **)&((*font)->pOtherSubrs));
 
#if CID
if ((*font)->isCID)
 { /**** Release the font path. ****/
   KillMem((void **)&((*font)->fontPath));
 
   KillMem((void **)&(*font)->registry);
   KillMem((void **)&(*font)->ordering);
   KillMem((void **)&(*font)->SDBytes);
   KillMem((void **)&(*font)->FDArrayFontName);
   KillMem((void **)&(*font)->doubleEncryption);
   KillMem((void **)&(*font)->subrMapOffset);
   KillMem((void **)&(*font)->subrCount);
 } /* end if */
#endif

/* Release the BlendMaps */
for (i = 0; i < (IntX)(*font)->numAxes; i++) 
 { KillMem((void **)&((*font)->blendMap[i].userSpace));
   KillMem((void **)&((*font)->blendMap[i].designSpace));
 } /* end for */

/* Release the multiple master design space */
KillMem((void **)&((*font)->ds));

/* *** Release the font name. *** */
KillMem((void **)&((*font)->fontName));
KillMem((void **)&((*font)->Notice));
KillMem((void **)&((*font)->FullName));
KillMem((void **)&((*font)->FamilyName));
KillMem((void **)&((*font)->Version));
KillMem((void **)&((*font)->Weight));
KillMem((void **)&((*font)->baseFontName));
KillMem((void **)&((*font)->baseMMFontName));

/* Release all the pointers to pointers */
KillMem((void **)&(*font)->pFontDict);
KillMem((void **)&(*font)->pFontInst);
KillMem((void **)&(*font)->subrLengths);
KillMem((void **)&(*font)->pSubrArray);

/* NOTE:  Do not free the  NOTDEF (".notdef") character. */
if (((*font)->encoding != standardEncoding) && ((*font)->specialEncoding!=NULL))
 { for (i = 0; i < 256; i++)		/* 256 is the REQUIRED encoding size */
      if (os_strcmp((*font)->specialEncoding[i], NOTDEF) && 
          ((*font)->specialEncoding[i] != NULL))
         KillMem((void **)&(*font)->specialEncoding[i]);
   KillMem((void **)&(*font)->specialEncoding);
 } /* end if */

/* Normally this will be NULL by now--this is only used at run time */
if ((*font)->buildCharArray != NULL)
   KillMem((void **)&(*font)->buildCharArray);

/* Now that all of the sub-structures belonging to the font have been
   released, the font itself can be released without any memory leaking out. */
KillMem((void **)font);

} /* end T1FontRelease() */


/*
   Call-back procedures.
*/


PRIVATE boolean UseStandardEncoding ARGDEF0()
{
isStdEncoding = true;

return true;
} /* end UseStandardEncoding() */


/* Called when the font contains a special encoding.  This special encoding
   comes into play when a character is read which is not in the
   standardGlyphList.                                                    */

PRIVATE boolean UseSpecialEncoding ARGDEF1(IntX, count)
{
IntX i;
isStdEncoding = false;

/* Regardless of count, encoding vectors are 256 entries long, always. */
(*newFontHandle)->specialEncoding = NULL;
if (!NEWMEM((void **)&(*newFontHandle)->specialEncoding, 256*sizeof(char *)))
 { (*newFontHandle)->specialEncoding = NULL;
   return false;
 } /* end if */

for (i = 0; i < 256; i++)		/* Init all entries to .notdef */
   (*newFontHandle)->specialEncoding[i] = NOTDEF;

return true;
} /* end UseSpecialEncoding() */


/* Gets one entry in the special encoding vector */

PRIVATE boolean SpecialEncoding ARGDEF2(IntX, i, char *, s)
{
if ((i >= 0) && (i < 256))
 { (*newFontHandle)->specialEncoding[i] = NULL; /* Don't overwrite notdef! */
   if (!NEWDATA((void **)&((*newFontHandle)->specialEncoding[i]), (Card8 *)s, os_strlen(s)+1))
      return false;
 } /* end if */
else
   return false;			/* index out of range */

return true;
} /* end SpecialEncoding() */


PRIVATE boolean UseStandardAccentEncoding ARGDEF0()
{

return true;
} /* end UseStandardAccentEncoding() */


PRIVATE boolean UseSpecialAccentEncoding ARGDEF1(IntX, count)
{

return true;
} /* end UseSpecialAccentEncoding() */


PRIVATE boolean SpecialAccentEncoding ARGDEF2(IntX, i, char *, charname)
{

return true;
} /* end SpecialAccentEncoding() */


/* Just started eexec stuff */
PRIVATE boolean StartEexecSection ARGDEF0()
{

return true;
}


/* Gets the font type */
PRIVATE boolean FontType ARGDEF1(Int32, fontType)
{

(*newFontHandle)->fontType = fontType;

return true;
}


/* Gets a pointer to the font name. */
PRIVATE boolean FontName ARGDEF1(char *, name)
{
IntX length = os_strlen(name) + 1;

if (length & 0x01) 
   length++;

return NEWDATA((void **)&((*newFontHandle)->fontName), (Card8 *)name, length);
} /* end FontName() */

/* Gets a pointer to the font name. */
PRIVATE boolean BaseMMFontName ARGDEF1(char *, name)
{
IntX length = 0;

  //get the name from the string.
  while (name[length] != ' ')
    length++;

  length++; //for null terminator


 if (length & 0x01) 
   length++;

 if (!(NEWDATA((void **)&((*newFontHandle)->baseMMFontName), (Card8 *)name, length)))
   return false;

 //else allocation was successful
  ((*newFontHandle)->baseMMFontName)[length-1] = '\0'; //add null terminator.

 return true;

} /* end BaseMMFontName() */



/* Gets the copyright notice present in the font. */
PRIVATE boolean Notice ARGDEF1(char *, str)
{
IntX length = os_strlen(str) + 1;

if (length & 0x01) 
   length++;

return NEWDATA((void **)&((*newFontHandle)->Notice), (Card8 *)str, length);
} /* end Notice() */


/* Gets the full name of the font. */
PRIVATE boolean FullName ARGDEF1(char *, name)
{
IntX length = os_strlen(name) + 1;

if (length & 0x01) 
   length++;

return NEWDATA((void **)&((*newFontHandle)->FullName), (Card8 *)name, length);
} /* end FullName() */


/* Gets the family name of the font. */
PRIVATE boolean FamilyName ARGDEF1(char *, name)
{
IntX length = os_strlen(name) + 1;

if (length & 0x01) 
   length++;

return NEWDATA((void **)&((*newFontHandle)->FamilyName), (Card8 *)name, length);
} /* end FamilyName() */


/* Gets the name of the weight (boldness) of the font. */
PRIVATE boolean Weight ARGDEF1(char *, str)
{
IntX length = os_strlen(str) + 1;

if (length & 0x01) 
   length++;

return NEWDATA((void **)&((*newFontHandle)->Weight), (Card8 *)str, length);
} /* end Weight() */


  /* Gets a string containing the version of the font. */
PRIVATE boolean Version ARGDEF1(char *, str)
{
IntX length = os_strlen(str) + 1;

if (length & 0x01) 
   length++;

return NEWDATA((void **)&((*newFontHandle)->Version), (Card8 *)str, length);
} /* end Version() */


  /* Gets the general italic angle of the font. */
PRIVATE boolean ItalicAngle ARGDEF1(Fixed, p)
{
(*newFontHandle)->ItalicAngle = p;

return true;
} /* end ItalicAngle() */


  /* Gets a flag indicating if the font is fixed pitch. */
PRIVATE boolean isFixedPitch ARGDEF1(boolean, flg)
{
(*newFontHandle)->isFixedPitch = flg;

return true;
} /* end isFixedPitch() */



PRIVATE boolean UnderlinePosition ARGDEF1(Fixed, p)
{
(*newFontHandle)->UnderlinePosition = p;

return true;
} /* end UnderlinePosition() */


PRIVATE boolean UnderlineThickness ARGDEF1(Fixed, p)
{
(*newFontHandle)->UnderlineThickness = p;

return true;
} /* end UnderlineThichkness() */


/* Gets the PUBLIC unique ID of the font.  If the uniqueID has not been
   set, set it.  If it has been set, then it has been set to the PRIVATE
   uniqueID.  If they do not match, clear the uniqueID.                   */

PRIVATE boolean PublicUniqueID ARGDEF1(Int32, id)
{

if ((*newFontHandle)->uniqueID == 0) 
 { (*newFontHandle)->uniqueID = id;
   return true;
 } /* end if */

if ((*newFontHandle)->uniqueID != id)
   (*newFontHandle)->uniqueID = 0;

return true;
}

PRIVATE boolean OtherSubrs ARGDEF2(Card8 *, s, Card16, count)
{
Card16 size;
T1FontPointer f = *newFontHandle;

if (f->pOtherSubrs == NULL)
 { if (!NEWMEM((void **)&(f->pOtherSubrs), count+OTHERSUBR_EXTRA))
    { f->pOtherSubrs = NULL;
      return false;
    } /* end if */
   os_strncpy((char *)f->pOtherSubrs, (char *)s, count);
   otherSubrAlloc = count + OTHERSUBR_EXTRA;
   f->otherSubrSize = count;
 } /* end if */
else
 { size = f->otherSubrSize + count;
   if (size > otherSubrAlloc)
    { if (!NewMem((void **)&(f->pOtherSubrs), size+OTHERSUBR_EXTRA))
       { f->pOtherSubrs = NULL;
          return false;
       } /* end if */
      otherSubrAlloc = size+OTHERSUBR_EXTRA;
    } /* end if */

   os_strncpy((char *)f->pOtherSubrs+f->otherSubrSize, (char *)s, count);
   f->otherSubrSize = size;
 } /* end else */

return true;
} /* end OtherSubrs() */


/* Reserve storage for the character string array.  The array is allocated
   as a separate block which can be shrunk later to the true end of the
   array.  The array consists of pointers to character data.            */

PRIVATE boolean AllocCharStrings ARGDEF1(IntX, count)
{

return CommonAllocCharStrings(count, true);
}


PRIVATE boolean CommonAllocCharStrings ARGDEF2(IntX,count,boolean,lengthsFlag)
{
Card32       dataPtrLength, lengthArrayLength, conservativeGuess;

			/* CID get the charstring at build time */
if ((*newFontHandle)->isCID)
   return true;

conservativeGuess = count;

 dataPtrLength = conservativeGuess * sizeof(CharDataPtr);
 lengthArrayLength = conservativeGuess * sizeof(Card16);

if (!NEWMEM((void **)&((*newFontHandle)->charStrings), dataPtrLength))
 {  (*newFontHandle)->charStrings = NULL;
    return false;
 } /* end if */

if (!NEWMEM((void **)&((*newFontHandle)->charNames), dataPtrLength))
 { (*newFontHandle)->charNames = NULL;
   return false;
 } /* end if */

if (lengthsFlag)
 { if (!NEWMEM((void **)&((*newFontHandle)->charLengths), lengthArrayLength)) 
    { (*newFontHandle)->charLengths = NULL;
      return false;
    } /* end if */
 } /* end if */
else
   (*newFontHandle)->charLengths = NULL;

(*newFontHandle)->numCharacters = count;
 (*newFontHandle)->numCharStrings = (Int16) conservativeGuess;

/* OEMATM has this start at 1.  I have no idea why! */
nextOpenSlot = 0;

return true;
} /* end CommonAllocCharStrings() */


#define C1              ((Card16) 52845)
#define C2              ((Card16) 22719)
#define key_charstring  ((Card16) 4330)

PRIVATE procedure DecryptString ARGDEF3(register Card8 *, s, IntX, lenIV, 
                                       CardX *, len) 
{
register unsigned cipher, key;
register  Card8 *bufend, *sdecrypt;
int i;

if (lenIV > -1)		/* -1 is no encryption */
 { key = key_charstring;
   bufend = s + *len;
   sdecrypt = s;
   for (i = lenIV; i > 0; i--)
      key = (Card16)((Card16) (*s++) + key) * C1 + C2;

   while (s < bufend) 
    { cipher = *s++;
      *sdecrypt++ = (Card8) (cipher ^ (key >> 8));
      key = (Card16)((Card16) (cipher) + key) * C1 + C2;
    } /* end while */
   *len -= lenIV;
 } /* end if */

/* Note that for lenIV==-1 I don't change the string length! */
} /* end DecryptString() */


  /* CharString takes the individual character descriptions from the parser,
     and places them into the proper spot. */

#if RANDOMACCESS
PRIVATE boolean CharString ARGDEF6(CardX, buffNum, CardX, byteNum,
                                   Card32, cryptNum, char *, key,
                                   CharDataPtr, val, CardX, len)
#else
PRIVATE boolean CharString ARGDEF3(char *,key, CharDataPtr, val, CardX, len)
#endif
{
IntX index, keyLen;

/* CID gets the charstring at build time */
if ((*newFontHandle)->isCID)
   return true;

DecryptString(val, fontDPtr->lenIV, &len);

keyLen = os_strlen(key) + 1;

/* Store the charstring in the next open spot. */

if ((index = nextOpenSlot++) < (*newFontHandle)->numCharStrings) 
 { if (!NEWDATA((void **)&((*newFontHandle)->charStrings[index]), (Card8 *)val, len))
      return false;

   if (!NEWDATA((void **)&((*newFontHandle)->charNames[index]), (Card8 *)key, keyLen))
      return false;

   (*newFontHandle)->charLengths[index] = (Card16)len;
 } /* end if */

return true;
} /* end CharString() */



/* Use this as a synthetic font indicator and store the base font name */

PRIVATE boolean ShareCharStrings ARGDEF1(char *, fontname)
{
	if (!NEWDATA((void **)&((*newFontHandle)->baseFontName), (Card8 *)fontname, 
             strlen(fontname)+1))
    return false;
return false;
} /* end ShareCharStrings() */


/* Gets the number of subroutines which will be parsed and allocates
   memory for them */
PRIVATE boolean AllocSubroutines ARGDEF1(IntX, count)
{

/* If we don't know how many subroutines are going to be seen, start with
    an assumption of at least 200 for Roman fonts. */

if (count == 0) 
    count = (((*newFontHandle)->isCID) ? 5 : 200);

if (!NEWMEM((void **)&((*newFontHandle)->pSubrArray[curBaseFont]),
                (count * sizeof(CharDataPtr)))) 
 { (*newFontHandle)->pSubrArray[curBaseFont] = NULL;
   return false;
 } /* end if */

fontDPtr->lenSubrArray = count;

/* We also have to allocate the array which holds the length of the
   subroutines, in case we have to grow the array containing the pointers
   to the subroutines. */
if (!NEWMEM((void **)&((*newFontHandle)->subrLengths[curBaseFont]),
                (count * sizeof(Card16)))) {
   (*newFontHandle)->subrLengths[curBaseFont] = NULL;
   return false;
 } /* end if */

return true;
} /* end AllocSubroutines() */


/* Gets a subroutine and an index to place it at */

PRIVATE boolean Subroutine ARGDEF3(IntX, index, CharDataPtr, val, CardX, len)
{

/* Put the index into absolute terms. */
index += fontDPtr->subroutineNumberBias;
if (index < 0)			/* Out of range! */
   return false;

/* If we got an index which is high, we have to expand two arrays - the
   array containing pointers and the array containing lengths.  */

  while(index >=
        (IntX)(fontDPtr->lenSubrArray))
  {
    Card16    newMax;
    Int32     locindex;

    /* Round up to the next 200. */
    newMax = fontDPtr->lenSubrArray;
    while(newMax <= (Card16) index) newMax += 200;

    if(!NewMem((void **)&((*newFontHandle)->pSubrArray[curBaseFont]),
               (newMax * sizeof(CharDataPtr))))
      return false;

    /* Now reallocate the lengths array. */
    if(!NewMem((void **)&((*newFontHandle)->subrLengths[curBaseFont]),
               (newMax * sizeof(Card16))))
      return false;

    /* Clear out the pointers and the lengths in the new parts of the
       arrays. */
    for (locindex = fontDPtr->lenSubrArray;
         locindex < (Int32) newMax;
         locindex++) {
      (*newFontHandle)->pSubrArray[curBaseFont][locindex] = NULL;
      (*newFontHandle)->subrLengths[curBaseFont][locindex] = 0;
    }
    fontDPtr->lenSubrArray = newMax;
  }

#if CID
  if ((*newFontHandle)->isCID)
   { if (fontDPtr->lenIV > -1)
        DecryptString(val, fontDPtr->lenIV, &len);
   } /* end if */
  else
#endif
    DecryptString(val, fontDPtr->lenIV, &len);

  if(!NEWDATA((void **)&((*newFontHandle)->pSubrArray[curBaseFont][index]), (Card8 *)val, len))
    return false;

  /* Store the length. */
  (*newFontHandle)->subrLengths[curBaseFont][index] = len;

  return true;
} /* end Subroutine() */


/* No sharing subroutines in this program! */

PRIVATE boolean ShareSubroutines ARGDEF1(char *, fontname)
{
   return false;
} /* end ShareSubroutines() */


PRIVATE boolean WeightVector ARGDEF2(PFixed, wv, IntX, wvlen)
{
IntX i;

for (i = 0; i < wvlen; i++)
  (*newFontHandle)->weightVector[i] = wv[i];

return true;
} /* end WeightVector() */


PRIVATE boolean ResizeFontDesc ARGDEF2(FontDesc **, fontdescp, Card32, size)
{

if (!NewMem((void **)&((*newFontHandle)->pFontDict[curBaseFont]), size))
   return false;
*fontdescp = fontDPtr = (*newFontHandle)->pFontDict[curBaseFont];

return true;
} /* end ResizeFontDesc() */


/* Makes MemoryRealloc look like a DS_allocfunc  */
PRIVATE void *BlendAlloc ARGDEF2(IntX, nbytes, void *, tag)
{
void *x;

x = NULL;
if ((*MemoryRealloc)((void **)&x,nbytes))
   return(x);
else 
   return(NULL);
} /* end BlendAlloc() */


PRIVATE boolean BlendNumberDesigns ARGDEF1(CardX, n)
{
fontDPtr->numMasters = n;
if ((*newFontHandle)->numAxes != 0)
 { (*newFontHandle)->ds = MakeDesignSpace((IntX)(*newFontHandle)->numAxes, n,
                                           (DS_allocfunc) BlendAlloc, NULL);
   if ((*newFontHandle)->ds == NULL) 
      return false;
 } /* end if */

return true;
} /* end BlendNumberDesigns() */


PRIVATE boolean BlendNumberAxes ARGDEF1(CardX, n)
{
(*newFontHandle)->numAxes = (Card16)n;
if (fontDPtr->numMasters != 0)
 { (*newFontHandle)->ds = MakeDesignSpace(n, fontDPtr->numMasters,
                                          (DS_allocfunc) BlendAlloc, NULL);
   if ((*newFontHandle)->ds == NULL)
      return false;
 } /* end if */

return true;
} /* end BlendNumberAxes() */


PRIVATE boolean BlendAxisType ARGDEF2(CardX, axis, char *, name)
{
strcpy((*newFontHandle)->axisNames[axis], name);

return true;
} /* end BlendAxisType() */


#define FLT_FIX  65536.0

PRIVATE boolean BlendDesignMapping ARGDEF4(CardX, axis, int, n,
                                           Fixed *, from, Fixed *, to)
{
(*newFontHandle)->blendMap[axis].numMaps = n;
if (!NEWDATA((void **)&((*newFontHandle)->blendMap[axis].userSpace), (Card8 *)from, 
			n * sizeof(Fixed)))
    return false;
if (!NEWDATA((void **)&((*newFontHandle)->blendMap[axis].designSpace), (Card8 *)to, 
			n * sizeof(Fixed)))
    return false;

return true;
} /* end BlendDesignMapping() */


PRIVATE boolean BlendDesignPositions ARGDEF2(int, blend, Fixed *, pos)
{
SetMasterDesignPosition((*newFontHandle)->ds, blend, pos);

return true;
} /* end BlendDesignPositions() */


PRIVATE boolean BlendUnderlinePosition ARGDEF2(int, blend, Fixed, x)
{
return true;
} /* end BlendUnderlinePosition() */


PRIVATE boolean BlendUnderlineThickness ARGDEF2(int, blend, Fixed, x)
{
return true;
} /* end BlendUnderlineThickness() */


PRIVATE boolean BlendItalicAngle ARGDEF2(int, blend, Fixed, x)
{
return true;
} /* end BlendItalicAngle() */

#if CID
PRIVATE boolean RunInt ARGDEF1( char *, key )
{ 
/* In theory Old Composite Fonts should have this check also, but it has
alway been assumed to be true there before, and isn't checked for OCFs */
if ((*newFontHandle)->isCID)
  (*newFontHandle)->doubleEncryption[curBaseFont] = (Card8)!os_strcmp(key, "eCCRun");
/* NOTE: if key isn't "eCCRun" it should be "CCRun" */
return true;
} /* end RunInt() */
#endif /* CID */

/* CID specific callbacks */
#if CID

PRIVATE boolean GDBytes ARGDEF1(Int32, n)
{ 
(*newFontHandle)->GDBytes = n;
return true;
} /* end GDBytes */


PRIVATE boolean FDBytes ARGDEF1(Int32, n)
{ 
(*newFontHandle)->FDBytes = n;
return true;
} /* end FDBytes */


PRIVATE boolean CIDCount ARGDEF1(Int32, n)
{
(*newFontHandle)->CIDCount = n;
return true;
} /* end CIDCount() */


PRIVATE boolean CIDMapOffset ARGDEF1(Int32, n)
{
(*newFontHandle)->CIDMapOffset = n;
return true;
} /* end CIDMapOffset() */


PRIVATE boolean CIDFontVersion ARGDEF1(Int32, n)
{
(*newFontHandle)->CIDFontVersion = n;
return true;
} /* end CIDMapOffset() */


PRIVATE boolean Registry ARGDEF1(char *, name)
{ 
if (newFontHandle)
 { if (!NEWDATA((void **)&(*newFontHandle)->registry, (Card8 *)name, os_strlen(name)+1))
      return false;
 } /* end if */
else if (newCMapHandle)
 { if ((*newCMapHandle)->registry == NULL)
    { if (!NEWDATA((void **)&(*newCMapHandle)->registry, (Card8 *)name, os_strlen(name)+1))
         return false;
    } /* end if */
   else /* If there's an entry already this must be a usecmap.  The new */
	/* entry should be identical to the old one. */
    { if (os_strcmp((*newCMapHandle)->registry, name))
         return false;			/* Incompatible Registries */
      /* No need to allocate new name--their identical! */ 
    } /* end else */ 
 } /* end if */

return true;
} /* end Registry */


PRIVATE boolean Ordering ARGDEF1(char *, name)
{ 
if (newFontHandle)
 { if (!NEWDATA((void **)&(*newFontHandle)->ordering, (Card8 *)name, os_strlen(name)+1))
      return false;
 } /* end if */
else if (newCMapHandle)
 { if ((*newCMapHandle)->ordering == NULL)
    { if (!NEWDATA((void **)&(*newCMapHandle)->ordering, (Card8 *)name, os_strlen(name)+1))
         return false;
    } /* end if */
   else /* If there's an entry already this must be a usecmap.  The new */
	/* entry should be identical to the old one. */
    { if (os_strcmp((*newCMapHandle)->ordering, name))
         return false;			/* Incompatible Orderings */
      /* No need to allocate new name--their identical! */ 
    } /* end else */ 
 } /* end if */

return true;
} /* end Ordering */


PRIVATE boolean Supplement ARGDEF1(Int32, n)
{ 
if (newFontHandle)
   (*newFontHandle)->supplement = n;
else if (newCMapHandle)
   (*newCMapHandle)->supplement = n;
   
return true;
} /* end CDBytes */


PRIVATE boolean FDArrayFontName ARGDEF1(char *, name)
{ 
if (curBaseFont != -1)
 { if (!NEWDATA((void **)&(*newFontHandle)->FDArrayFontName[curBaseFont], (Card8 *)name, 
           os_strlen(name)+1))
      return false;
 } /* end if */

return true;
} /* end FDArrayFontName() */


/* Assumes that the length of memoryBuf.b1 does NOT change while parsing is
   going on! */
PRIVATE boolean CIDStartData ARGDEF2(CardX, buffNum, CardX, byteNum)
{
(*newFontHandle)->dataStart = byteNum + buffNum * memoryBuf.b1->len;
return true;
} /* end CIDStartData() */


PRIVATE boolean SDBytes ARGDEF1(Int32, n)
{ 
(*newFontHandle)->SDBytes[curBaseFont] = n;
return true;
} /* end SDBytes */


PRIVATE boolean SubrMapOffset ARGDEF1(Int32, n)
{ 
(*newFontHandle)->subrMapOffset[curBaseFont] = n;
return true;
} /* end SubrMapOffset */


PRIVATE boolean SubrCount ARGDEF1(Int32, n)
{ 
(*newFontHandle)->subrCount[curBaseFont] = n;
return true;
} /* end SubrCount */


PRIVATE boolean CIDFDArray ARGDEF1(Int32, n)
{ 
(*newFontHandle)->numBaseFonts = (IntX)n;
if (AllocSubStructs(*newFontHandle) == PE_CALLER)
   return false;

return true;
} /* end CIDFDArray() */


PRIVATE boolean BeginCIDFontDict ARGDEF2(Int32, i, FontDesc **, fontp)
{ 
if (i >= (*newFontHandle)->numBaseFonts)
   return false;
curBaseFont = (IntX)i;

fontDPtr = *fontp = (*newFontHandle)->pFontDict[i];

return true;
} /* end BeginCIDFontDict() */



PRIVATE boolean EndCIDFontDict ARGDEF1(Int32, i)
{ 

if ((*newFontHandle)->SDBytes[curBaseFont] > MAX_SDBYTES)
   return false;

curBaseFont = -1;

return true;
} /* EndCIDFontDict() */


PRIVATE boolean UIDBase ARGDEF1(Int32, n)
{ 
(*newFontHandle)->UIDBase = n;
return true;
} /* end SDBytes */


PRIVATE boolean XUID ARGDEF3(Int32, v1, Int32, v2, Int32, v3)
{ 
(*newFontHandle)->XUID[0] = v1;
(*newFontHandle)->XUID[1] = v2;
(*newFontHandle)->XUID[2] = v3;
return true;
} /* end SDBytes */

/* Assumes file is still open, newFontHandle is valid */

PRIVATE boolean GetCIDSubrs ARGDEF0()
{
Card32 i;
Card32 numSubrs;
Card32 subrMapOffset, SDBytes;
Card32 curSubrOffset, nextSubrOffset;
Card32 subrLength = 0;
T1FontPointer theFont = *newFontHandle;
char *tempSubr = NULL;
Card32 tempSubrLength = 0;
Card8 *subrOffsetTable = NULL;

if (theFont == NULL)
   return false;

/* Use the global curBaseFont as the index because it is used by AllocSubroutines() */
for (curBaseFont = 0; curBaseFont < theFont->numBaseFonts; curBaseFont++)
 { subrMapOffset = theFont->subrMapOffset[curBaseFont] + theFont->dataStart;
   numSubrs = theFont->subrCount[curBaseFont];
   SDBytes = theFont->SDBytes[curBaseFont];
   /* Used by Subroutine() callback */
   fontDPtr = theFont->pFontDict[curBaseFont];

   /* Allocate room for all the subr offsets + 1 (extra subroffset for len)*/
   if (!NewMem((void **)&subrOffsetTable, SDBytes*(numSubrs+1)))
      return false;

   /* Allocate space for the subroutines */
   if (!AllocSubroutines((IntX)numSubrs))
      return false;

   /* Get 1st offset value */
   if (IOFuncs.SeekFunc(subrMapOffset, SEEK_FROM_START) == -1)
      return false;
   if (IOFuncs.ReadFunc(subrOffsetTable, (Card16)(SDBytes*(numSubrs+1))) == -1)
      return false;
   BytesToCard32(subrOffsetTable, &curSubrOffset, SDBytes);
   curSubrOffset += theFont->dataStart;

   for (i = 0; i < numSubrs; i++)
    { /* Seek to the start of the subr data */
      if (IOFuncs.SeekFunc(curSubrOffset, SEEK_FROM_START) == -1)
         return false;

      /* Get next offset value */
      BytesToCard32(subrOffsetTable+(i+1)*SDBytes, &nextSubrOffset, SDBytes);
      nextSubrOffset += theFont->dataStart;

      /* Get the actual subr data */
      subrLength = nextSubrOffset - curSubrOffset;

      /* Make sure there's enough room for subr */
      if (subrLength > tempSubrLength)
       { if (!NewMem((void **)&tempSubr, subrLength))
            return false;
         tempSubrLength = subrLength;
       } /* end if */

      /* Read the subr in */
      if (IOFuncs.ReadFunc(tempSubr, (Card16)(nextSubrOffset-curSubrOffset)) == -1)
         return false;
     
      /* Store the subr in the correct location */
      if (!Subroutine((IntX)i, (CharDataPtr)tempSubr, (CardX)subrLength))
         return false;

      curSubrOffset = nextSubrOffset;
    } /* end for */

   /* Next font gets its own table */
   if (subrOffsetTable != NULL)
      NewMem((void **)&subrOffsetTable, 0);

 } /* end for */

/* Free up any temporary memory used. */
if (tempSubr != NULL)
   NewMem((void **)&tempSubr, 0);

return true;
} /* end GetCIDSubrs() */


/* encoding files and rearranged font */


PRIVATE boolean AddDecoderRange(deco_Record *range)
{

numCodes++;
if (!(*MemoryRealloc)((void **)&codeList, numCodes*sizeof(deco_Record)))
   return false;
os_memcpy(codeList+(numCodes-1), range, sizeof(deco_Record));

return true;
} /* end AddDecoderRange() */


PRIVATE boolean cidrange ARGDEF5(Card32, srcCodeLo, IntX, srcCodeLoLen,
               Card32, srcCodeHi, IntX, srcCodeHiLen, Card32, dstGlyphIDLo)
{ 
deco_Record range;

range.lo.bytes = (Card8)srcCodeLoLen;
range.lo.value = srcCodeLo;
range.hi.bytes = (Card8)srcCodeHiLen;
range.hi.value = srcCodeHi;
range.mapType = deco_MAP_CODERANGE_GIDLO;
range.u.numberLo = dstGlyphIDLo;
range.fontId = 0;

return AddDecoderRange(&range);
} /* end cidrange() */


PRIVATE  boolean cidchar ARGDEF3(Card32, srcCode, IntX, srcCodeLen, 
   Card32, dstGlyphID)
{
deco_Record range;

range.lo.bytes = (Card8)srcCodeLen;
range.lo.value = srcCode;
range.mapType = deco_MAP_CODE_GID;
range.u.numberLo = dstGlyphID;
range.fontId = 0;

return AddDecoderRange(&range);
} /* end cidchar */


PRIVATE boolean notdefchar ARGDEF3(Card32, srcCode, IntX, srcCodeLen, 
   Card32, dstGlyphID)
{ 
return true;
} /* end notdefchar() */

 
PRIVATE boolean notdefrange ARGDEF5(Card32, srcCodeLo, IntX, srcCodeLoLen, 
                 Card32, srcCodeHi, IntX, srcCodeHiLen, Card32, dstGlyphIDLo)
{ 
deco_Record range;

range.lo.bytes = (Card8)srcCodeLoLen;
range.lo.value = srcCodeLo;
range.hi.bytes = (Card8)srcCodeHiLen;
range.hi.value = srcCodeHi;
range.mapType = deco_MAP_CODERANGE_NOTDEFGID;
range.u.numberLo = dstGlyphIDLo;
range.fontId = 0;

return AddDecoderRange(&range);
} /* end notdefrange() */


PRIVATE  boolean codespacerange ARGDEF4(Card32, srcCode1, IntX, srcCode1Len, 
   Card32, srcCode2, IntX, srcCode2Len)
{ 
deco_Record range;

range.lo.bytes = (Card8)srcCode1Len;
range.lo.value = srcCode1;
range.hi.bytes = (Card8)srcCode2Len;
range.hi.value = srcCode2;
range.mapType = deco_MAP_CODESPACE;
range.u.numberLo = 0;
range.fontId = 0;

return AddDecoderRange(&range);
} /* end codespacerange() */


PRIVATE  boolean rearrangedfont ARGDEF1(char *, name)
{
return true;
} /* end rearrangedfont() */


PRIVATE  boolean componentfont ARGDEF2(IntX, i, char *, name)
{ 
if (i == 0)
 { if ((*newCMapHandle)->encoding->localFontTable != NULL)
      return false;	/* Either nested rearranged fonts or just error */

   /* Notice I allocate AND clear memory at once! */
   if (!NEWMEM((void **)&(*newCMapHandle)->encoding->localFontTable, sizeof(Card8 *) * MAX_COMPONENT_FONTS))
      return false;

   if (!NEWMEM((void **)&(*newCMapHandle)->useMtx, sizeof(FixMtx *) * MAX_COMPONENT_FONTS))
      return false;

   if ((*newCMapHandle)->cMapUsed != NULL)
      return false;	/* Can't have a used AND a rearranged */   
 } /* end if */

if (!NEWDATA((void **)&(*newCMapHandle)->encoding->localFontTable[i], (Card8 *)name, os_strlen(name)+1))
   return false;

if (i == 0) 		/* Save the template font name is the used struct */
   (*newCMapHandle)->cMapUsed = (char *)(*newCMapHandle)->encoding->localFontTable[0];

return true;
} /* end componentfont() */


PRIVATE  boolean endcomponentfont ARGDEF1(IntX, i)
{ 
return true;
} /* end endcomponentfont() */


PRIVATE  boolean usematrix ARGDEF2(IntX, i, FixMtx *,m)
{ 
if (!NEWDATA((void **)&(*newCMapHandle)->useMtx[i], (Card8 *)m, sizeof(FixMtx)))
   return false;

return true;
} /* end usmatrix() */


PRIVATE  boolean usefont ARGDEF1(Card16, i)
{ 

usefontId = i;

return true;
} /* end usefont() */


PRIVATE  boolean bfrange_code ARGDEF5(Card32, srcCodeLo, IntX, srcCodeLoLen,
                     Card32, srcCodeHi, IntX, srcCodeHiLen, Card32, dstCodeLo)
{
deco_Record range;

range.lo.bytes = (Card8)srcCodeLoLen;
range.lo.value = srcCodeLo;
range.hi.bytes = (Card8)srcCodeHiLen;
range.hi.value = srcCodeHi;
range.mapType = deco_MAP_CODERANGE_CODELO;
range.u.numberLo = dstCodeLo;
range.fontId = usefontId;

return AddDecoderRange(&range);
} /* end bfrange_code() */


PRIVATE  boolean bfrange_name ARGDEF6(Card32, srcCodeLo, IntX, srcCodeLoLen, 
             Card32, srcCodeHi, IntX, srcCodeHiLen, IntX, i, char *, dstChar)
{ 
deco_Record range;

range.lo.bytes = (Card8)srcCodeLoLen;
range.lo.value = srcCodeLo;
range.hi.bytes = (Card8)srcCodeHiLen;
range.hi.value = srcCodeHi;
range.mapType = deco_MAP_CODE_NAME;
range.fontId = usefontId;

return AddDecoderRange(&range);
}


PRIVATE  boolean bfchar_code ARGDEF3(Card32, srcCode, IntX, srcCodeLen, 
             Card32, dstCode)
{ 
deco_Record range;

range.lo.bytes = (Card8)srcCodeLen;
range.lo.value = srcCode;
range.mapType = deco_MAP_CODE_CODE;
range.u.numberLo = dstCode;
range.fontId = usefontId;

return AddDecoderRange(&range);
}


PRIVATE  boolean bfchar_name ARGDEF3(Card32, srcCode, IntX, srcCodeLen, 
            char *, dstCharName)
{ 
deco_Record range;

range.lo.bytes = (Card8)srcCodeLen;
range.lo.value = srcCode;
range.mapType = deco_MAP_CODE_NAME;
range.fontId = usefontId;

return AddDecoderRange(&range);
} /* end bfchar_name() */


PRIVATE  boolean UseCMap ARGDEF1(char *, name)
{
if (!NEWDATA((void **)&(*newCMapHandle)->cMapUsed, (Card8 *)name, os_strlen(name)+1))
   return false;

return true;
} /* end UseCMap() */


#endif /* CID */


