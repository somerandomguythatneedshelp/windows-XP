#include "generic.h"
#include "UFL.h"
#include "UFLPS.h"
#include "UFLMath.h"
#include "UFLErr.h"
#include "UFOEnc.h"
#include "UFLTypes.h"

extern BYTE HexTable[16];

enum
{
    kOutlineBegin,
    kOutlinePath,
    kOutlineEnd
};


typedef struct
{
    UFO         pufo;
    LONG        xCurrent;
    LONG        yCurrent;
    LPPOLYGONHEADER   lpPoly;
    LPFDPOLYCURVE     lpfdPoly;
    ULONG       cbPoly;
    ULONG       cbRem;
    LONG        state;
    LPTTTOTYPE1STUFF  lpTTtoT1stuff;
    WORD        counter;
} DRVTTT1INFO;

typedef struct
{
    UFO            pufo;
    unsigned char *pFontData;
    unsigned long ulOffset;
} DRVCFFINFO;

#define ttcf_TABLE  (*(unsigned long*)"ttcf")
#define GSUB_TABLE  (*(unsigned long*)"GSUB")
#define mort_TABLE  (*(unsigned long*)"mort")


#define HAS_TTFILE(pSubFont) ((pSubFont)->pDLFont->pTTFile)
#define POST_TABLE  (*(unsigned long*)"post")


// TrueType related stuff:
#define GLYPHSIZE    50   // YCT
// Macro to compute no. of bytes bi bits takes when aligned on an al-byte boundary
#define BiToByAl(bi,al) (((bi)+(al)*8-1)/((al)*8)*(al))


static char *pszG00GFFEncoding = "G00GFFEncoding";

/* a global buffer - use with care */
static WORD    aWordArray[WARRAY0SIZE];
LPWORD  gWordArray0 = (LPWORD)&aWordArray[0];

#define GDITOUFLFIX(x) (x)

// BUGBUG - for test only
BOOL  gbUseG00GFF = 0;
//

void GetEncodingArray(LPPDEVICE pdev,  LPSUBFONT43 pSubFont, UFLRequest *pRequest);

unsigned long
BHasPostTable(
    LPSUBFONT43   pSubFont,
)
{

    LPPSFONTINFO FontInfo = (LPPSFONTINFO)pSubFont->FontInfo;
    LPTTFONTINFO lpttfi = (LPTTFONTINFO) ((LPSTR) FontInfo + FontInfo->dfBitsOffset);
    LPLOGFONT lplf = &(lpttfi->lfCopy);
    unsigned long rc = 0;
    DWORD nFontSize;
    HDC hDC = NULL ;
    HFONT hFont = NULL ;
    HFONT hPrevFont = NULL ;

    // GetFontData requires a screen DC to operate
    if ((hDC = GetDC (NULL)) == NULL) goto exit ;
    if ((hFont = CreateFontIndirect (lplf)) == NULL) goto exit ;
    if ((hPrevFont = SelectObject (hDC, hFont)) == NULL) goto exit ;

    nFontSize = GetFontData(hDC, (DWORD)POST_TABLE, (DWORD)0, (LPVOID) NULL,(DWORD) 0);
    if (nFontSize >= 0xFFFFFFFFL)
      nFontSize = 0;

exit:
    if (hPrevFont != NULL)
        SelectObject (hDC, hPrevFont) ;
    if (hFont != NULL)
        DeleteObject (hFont) ;
    if (hDC != NULL)
        ReleaseDC (NULL, hDC) ;

    rc = nFontSize; //non-zero return value means ok.
    return (rc);
}


/***********************************
        Callback Functions
 ***********************************/
static void
Put(
    UFLStream *thisStream,
    long selector,
    void *pData,
    size_t *pLen
    )
{
//    DWORD cbWritten;

    if ( NULL == pData || NULL == pLen )
        return;

    if ( NULL == thisStream )
        *pLen = 0;

    if (*pLen > 0)
    {
        OUTSTREAM    *out;

        out = (OUTSTREAM *)thisStream;
        switch ( selector ) {
        case kUFLStreamPutBinary:
            PSSendBitMapDataLevel1Binary( out->pdev, (BYTE huge *) pData, (DWORD)*pLen);
            break;
        case kUFLStreamPut:
            if (out->pdev->lpPSExtDevmode->dm2.iDataOutputFormat == PROTOCOL_TBCP ||
               out->pdev->lpPSExtDevmode->dm2.iDataOutputFormat == PROTOCOL_BCP)
                 PSSendBitMapDataLevel1Binary( out->pdev, (BYTE huge *) pData, (DWORD)*pLen);
            else
               PortWrite(out->pdev, pData, *pLen);
            break;
        default:
            *pLen = 0;
            break;
        }
    }
}



static void *
UFOMemAlloc(
    unsigned long size,
    void    *userData
    )
{

//    return malloc(size );
      return GlobalAllocPtr(GHND|GMEM_DDESHARE, (DWORD) size) ;

}

static void UFOMemFree(
    void* ptr,
    void *userData
    )
{
    //free( ptr );
    if (ptr)
       GlobalFreePtr(ptr);

}

static void UFOMemCopy(
    void* destination,
    void* source,
    unsigned long size,
    void *userData
    )
{
    if (destination && source)
       MemCopy (destination, source, (DWORD) size);

}

static void UFOMemSet(
    void* destination,
    unsigned int value,
    unsigned long size,
    void *userData
    )
{
    if (destination )
       MemSet (destination, value, (DWORD) size);

}


/********************** FONT HANDLERS **************************/

char GetGlyphBmp(
    UFLHANDLE   handle,
    UFLGlyphID  glyphID,
    UFLGlyphMap **bmp,
    UFLFixed    *xWidth,
    UFLFixed    *yWidth,
    UFLFixed    *bbox
    )
{
    LPSUBFONT43   pSubFont;
    LPPDEVICE    lppd;
    LPPSFONTINFO FontInfo;
    LPTTTOTYPE1STUFF lpTTtoT1stuff; //borrow the T1 buffer to store type 3 bitmaps temporary.
    long  rc;
    DWORD  bufsizNeeded, scanlen;
    WORD  wToEngine;    // WORD used to ask engin the glyph data. 9-26-95
    LPBYTE lpBuf;
    DWORD dwBufSize;
    int PSVersion ;
    BITMAPMETRICS bmm;
    LPFONTDATARECORD lpFontData;
    DWORD  DWUFLGLYPHMAP = (DWORD) sizeof(UFLGlyphMap);

    pSubFont = (LPSUBFONT43)handle;
    lppd = (LPPDEVICE) pSubFont->lppd;
    lpFontData = (LPFONTDATARECORD) pSubFont->lpFontData;
    FontInfo = (LPPSFONTINFO)pSubFont->FontInfo;
    lpTTtoT1stuff = (LPTTTOTYPE1STUFF)&(lppd->GlobalBuffer.TTtoT1stuff);
    dwBufSize = lpTTtoT1stuff->wOutlineBufSize;
    lpBuf = lpTTtoT1stuff->lpOutlineBuf;
    PSVersion = GetPSVersion(lppd);

    if (FontInfo->dfType & PF_GLYPH_INDEX)
    {
        wToEngine = (WORD) (glyphID & 0x0000FFFF);  /* the LoWord is the Gid */
    }
    else
    {
        wToEngine = (WORD) ((glyphID & 0xFFFF0000) >> 16 );  /* the HiWord is the str to Engine */
    }

    EngineSetFontContext( FontInfo, 0);

    //make sure we have enough space to store the bitmap plus UFLGlyphMap Structure
    bufsizNeeded = DWUFLGLYPHMAP +  GLYPHSIZE;
    if ( bufsizNeeded  > dwBufSize)
    {
        LPBYTE    lpNewBuffer = NULL ;
        lpNewBuffer = GlobalReAllocPtr(lpTTtoT1stuff->lpOutlineBuf, bufsizNeeded, GMEM_MOVEABLE);
        if (lpNewBuffer)
        {
                lpTTtoT1stuff->wOutlineBufSize = (WORD)bufsizNeeded ;
                dwBufSize = (DWORD) bufsizNeeded;
        }
        else
        {
                return 0;  // failure.
        }
        lpTTtoT1stuff->lpOutlineBuf = lpBuf = lpNewBuffer;
   }


TryAgain:

   //We are using lpTTtoT1stuff->lpOutlineBuf to store UFLGlpyMap structure
   //and a variable size bitmap.  Actural dwBufSize is less UFLGlyphMap struc.
  dwBufSize -= DWUFLGLYPHMAP;
  lpBuf = (LPBYTE) lpBuf + (WORD) DWUFLGLYPHMAP - (WORD) sizeof(char);

   // Ask the TrueType rasterizer for the bitmap
   if (FontInfo->dfType & TYPE_ATMFONT)
   {
       rc = EngineGetGlyphBmp( lppd->hdc, FontInfo, wToEngine, FD_QUERY_CHARIMAGE,
                   lpBuf, dwBufSize, &bmm);
   }
   else
   {
       rc = EngineGetGlyphBmpExt( lppd->hdc, FontInfo, wToEngine, FD_QUERY_CHARIMAGE,
                   lpBuf, dwBufSize, &bmm);
   }

   if (rc == -1)     // failed
   {
     if (FontInfo->dfType & TYPE_ATMFONT)
     {
          rc = EngineGetGlyphBmp( lppd->hdc, FontInfo, 0, FD_QUERY_CHARIMAGE,
                  lpBuf, dwBufSize, &bmm);
     }
     else
     {
          rc = EngineGetGlyphBmpExt( lppd->hdc, FontInfo, 0, FD_QUERY_CHARIMAGE,
                  lpBuf, dwBufSize, &bmm);
     }
   }

   if (rc == -1)     // still failed
   {
        return 0;
   }

   scanlen = BiToByAl(bmm.sizlExtent.cx, 4);  // force to lie on DWORD boundary
   bufsizNeeded =  (DWORD) (scanlen * bmm.sizlExtent.cy) + DWUFLGLYPHMAP ;
   rc = (dwBufSize + DWUFLGLYPHMAP);
   if ( bufsizNeeded  > (dwBufSize + DWUFLGLYPHMAP) )
   {
        LPBYTE    lpNewBuffer = NULL ;
        lpNewBuffer = GlobalReAllocPtr(lpTTtoT1stuff->lpOutlineBuf, bufsizNeeded, GMEM_MOVEABLE);
        if (lpNewBuffer)
        {
                lpTTtoT1stuff->wOutlineBufSize = (WORD)bufsizNeeded ;
                dwBufSize = (DWORD) bufsizNeeded;
        }
        else
        {
                return 0;  // failure.
        }
        lpTTtoT1stuff->lpOutlineBuf = lpBuf = lpNewBuffer;
        goto TryAgain;
   }

   if (PSVersion >= 2016) //YCT  type 32
   {
        lpFontData->FontCacheUsed += (bufsizNeeded + GLYPHSIZE);
        lppd->lpFontDataList->TFontCacheAvail -= (bufsizNeeded + GLYPHSIZE);
   }

    *xWidth = bmm.pfxCharInc.x;
    *yWidth = bmm.pfxCharInc.y;

//    bbox[0] = bmm.pfxOrigin.x;
//    bbox[1] = bmm.pfxOrigin.y - ((LONG)bmm.sizlExtent.cy << 16);
//    bbox[2] = bmm.pfxOrigin.x + ((LONG)bmm.sizlExtent.cx <<16);
//    bbox[3] = bmm.pfxOrigin.y;

    bbox[0] = bmm.pfxOrigin.x;
    bbox[1] = -bmm.pfxOrigin.y;
    bbox[2] = bmm.pfxOrigin.x + ((LONG)bmm.sizlExtent.cx <<16);
    bbox[3] = ((LONG)bmm.sizlExtent.cy << 16) - bmm.pfxOrigin.y;

    *bmp = (UFLGlyphMap *)lpTTtoT1stuff->lpOutlineBuf;
    (*bmp)->xOrigin = -(UFLTruncFixedToShort(bmm.pfxOrigin.x));
    (*bmp)->yOrigin = UFLTruncFixedToShort(bmm.pfxOrigin.y);
    (*bmp)->byteWidth = bmm.sizlExtent.cx;
    (*bmp)->height = bmm.sizlExtent.cy;

   //don't have to worry about non-marking glyphs.  ie space
   if (bmm.sizlExtent.cx && bmm.sizlExtent.cy)
    {
       HANDLE hBuffer;
       LPBYTE lpDataStart, lpData;
       WORD bpl, bpl32, nLines;
       WORD i;

       bpl = (LOWORD(bmm.sizlExtent.cx) +7) /8;
       bpl32 = (LOWORD(bmm.sizlExtent.cx) +31) /32 *4;
       nLines = LOWORD(bmm.sizlExtent.cy);

       hBuffer = GlobalAlloc(GHND, (DWORD) nLines * (DWORD) bpl);
       lpData = lpDataStart = GlobalLock(hBuffer);

       if (!hBuffer)
         return(0);

       for (i = 0; i < nLines; i++)
       {
         MemCopy (lpData, (lpBuf + (i* bpl32)), (DWORD) bpl);
         lpData += bpl;
       }

       MemCopy(lpBuf, lpDataStart, (DWORD) nLines * (DWORD) bpl);
       GlobalUnlock (hBuffer);
       GlobalFree (hBuffer);
    }

    return 1;
}


void
DeleteGlyphBmp(
    UFLHANDLE handle
    )
{
}


char
CreateGlyphOutlineIter(
    UFLHANDLE    handle,
    UFLGlyphID  glyphID,
    UFLFixed    *xWidth,
    UFLFixed    *yWidth,
    UFLFixed    *xSB,
    UFLFixed    *ySB,
    UFLBool        *bYAxisNegative
    )
{
    LPSUBFONT43   pSubFont;
    DRVTTT1INFO *pttt1Info;
    BITMAPMETRICS     bmm;
    LPTTTOTYPE1STUFF lpTTtoT1stuff;
    LPPSFONTINFO      lpdfRef = NULL;
    LPPSFONTINFO      lpdfRefOrig = NULL;
    LPPSFONTINFO      FontInfo;
    LPTTFONTINFO      lpttfi;
    WORD            wToEngine;
    ULONG           cbPoly;
    LPBYTE          lpOutlineBuf;
    LPFONTDATARECORD lpFontDataRecord;
    LPPDEVICE       lppd;

    pSubFont = (LPSUBFONT43)handle;
    lpFontDataRecord= (LPFONTDATARECORD) pSubFont->lpFontData;
    lppd = (LPPDEVICE) pSubFont->lppd;
    pttt1Info = (DRVTTT1INFO *)pSubFont->pufo;
    FontInfo = (LPPSFONTINFO)pSubFont->FontInfo;
    lpTTtoT1stuff = (LPTTTOTYPE1STUFF)&(lppd->GlobalBuffer.TTtoT1stuff);
    lpttfi = (LPTTFONTINFO) ((LPSTR) FontInfo + FontInfo->dfBitsOffset);


    // tell GDI to get ready for some font partying
    lpdfRefOrig = TTGetBaseFont(lppd, FontInfo, lpFontDataRecord);
    lpdfRef = GlobalAllocPtr(GHND|GMEM_DDESHARE, lpttfi->wXFontInfoSize) ;
    if (lpdfRefOrig)
        MemCopy((LP)lpdfRef, (LP) lpdfRefOrig, lpttfi->wXFontInfoSize);

    if (FontInfo->dfType & PF_GLYPH_INDEX)
    {
        wToEngine = (WORD) (glyphID & 0x0000FFFF);  /* the LoWord is the Gid */
    }
    else
    {
        wToEngine = (WORD) ((glyphID & 0xFFFF0000) >> 16 );  /* the HiWord is the str to Engine */
    }

    EngineSetFontContext(lpdfRef, 0 /*  Escapement  */);

  // Get font outline using two-stage process - ask for requested buffer
   //  size by calling EngineGetGlyphBmp with NULL buffer, allocate buffer
   //  and then make call to EngineGetGlyphBmp with allocated buffer.
   //  Changed  12-Apr-1993  -by-   [olegs]
   if (FontInfo->dfType & TYPE_ATMFONT)
   {
       cbPoly = EngineGetGlyphBmp(lppd->hdc, lpdfRef, wToEngine, FD_QUERY_OUTLINE,
                 (LPBYTE)NULL, 0, &bmm);
   }
   else
   {
       cbPoly = EngineGetGlyphBmpExt(lppd->hdc, lpdfRef, wToEngine, FD_QUERY_OUTLINE,
                 (LPBYTE)NULL, 0, &bmm);
   }
   if( cbPoly == -1 )
   {
      // I don't know what to do - hang, display message, ... ?
      // Anyhow - I just return doing nothing
      return 0;
   }

   // Added  20-Apr-1993  -by-  [olegs]
   //  because MGAllocLock returns an error if asked to allocate
   //  block of memory of 0 bytes.
   if ( cbPoly == 0 )            // Empty character  - allocate minimum block
   {
      cbPoly = 16;
   }

   if(lpTTtoT1stuff->wOutlineBufSize < cbPoly)
   {
        LPBYTE    lpNewBuffer ;

        lpNewBuffer = GlobalReAllocPtr(lpTTtoT1stuff->lpOutlineBuf, cbPoly, GMEM_MOVEABLE);
        if (lpNewBuffer)
            lpTTtoT1stuff->wOutlineBufSize = (WORD)cbPoly ;
        else
            return 0;  // failure.
   }
   lpOutlineBuf = lpTTtoT1stuff->lpOutlineBuf ;

    if (FontInfo->dfType & TYPE_ATMFONT)
    {
        cbPoly = EngineGetGlyphBmp(lppd->hdc, /* FontInfo */ lpdfRef,
              wToEngine, FD_QUERY_OUTLINE, (LPBYTE) lpOutlineBuf,
              cbPoly, &bmm);
    }
    else
    {
        cbPoly = EngineGetGlyphBmpExt(lppd->hdc, /* FontInfo */ lpdfRef,
              wToEngine, FD_QUERY_OUTLINE, (LPBYTE) lpOutlineBuf,
              cbPoly, &bmm);
    }



    pttt1Info->state = kOutlineBegin;
    pttt1Info->cbRem = pttt1Info->cbPoly =cbPoly;
    pttt1Info->lpPoly = (LPPOLYGONHEADER) lpTTtoT1stuff->lpOutlineBuf;
    pttt1Info->lpfdPoly = (LPFDPOLYCURVE)lpTTtoT1stuff->lpOutlineBuf;
    pttt1Info->xCurrent = bmm.pfxOrigin.x;
    pttt1Info->yCurrent = bmm.pfxOrigin.y;
    *xSB = GDITOUFLFIX(bmm.pfxOrigin.x);
    *ySB = (GDITOUFLFIX(bmm.pfxOrigin.y));
    *xWidth = GDITOUFLFIX(bmm.pfxCharInc.x);
    *yWidth = GDITOUFLFIX(bmm.pfxCharInc.y);
    *bYAxisNegative = 0; //false

//       test new code.   this will make w95 ufl inverted.
//        *bYAxisNegative = 1; //false


    if (lpdfRef)
        GlobalFreePtr(lpdfRef);
    return 1;
}

long
NextOutlineSegment(
    UFLHANDLE        handle,
    UFLFixedPoint    *p0,
    UFLFixedPoint    *p1,
    UFLFixedPoint    *p2
    )
{
    LPSUBFONT43    pSubFont;
    DRVTTT1INFO *pttt1Info;
    long        cmd;
    USHORT      us;
    LPTTTOTYPE1STUFF lpTTtoT1stuff;
    LPPOLYGONHEADER lpPoly;
    LPFDPOLYCURVE   lpfdPoly;
    LPPDEVICE       lppd;
    ULONG           cbPoly, cbRem;
    WORD            counter;
    BOOL            bAdvanceNextPoint = TRUE;

    pSubFont = (LPSUBFONT43)handle;
    lppd = (LPPDEVICE) pSubFont->lppd;
    lpTTtoT1stuff = (LPTTTOTYPE1STUFF)&(lppd->GlobalBuffer.TTtoT1stuff);
    pttt1Info = (DRVTTT1INFO *)pSubFont->pufo;
    lpPoly = (LPPOLYGONHEADER) pttt1Info->lpPoly;
    lpfdPoly = (LPFDPOLYCURVE)pttt1Info->lpfdPoly;
    cbPoly = pttt1Info->cbPoly;
    cbRem = pttt1Info->cbRem;
    counter = pttt1Info->counter;

    cmd = kUFLOutlineIterDone;


    if (pttt1Info)
    {
        switch ( pttt1Info->state )
        {
            case kOutlineBegin:
            {
                pttt1Info->state = kOutlineEnd; //begin subpath.
                cmd = kUFLOutlineIterBeginGlyph;
                break;
            }

            case kOutlineEnd:
            {
              if (cbRem > 0)
              {
                  lpPoly = (LPPOLYGONHEADER) lpfdPoly;
                  lpfdPoly = (LPFDPOLYCURVE) ((LPSTR)lpPoly + sizeof(POLYGONHEADER));
                  cbPoly = lpPoly->cb - sizeof(POLYGONHEADER);
                  cbRem -= sizeof(POLYGONHEADER);
                  p0->x =  GDITOUFLFIX(lpPoly->pteStart.x);
                  p0->y =  (GDITOUFLFIX(lpPoly->pteStart.y));
                  pttt1Info->xCurrent = lpPoly->pteStart.x;
                  pttt1Info->yCurrent = lpPoly->pteStart.y;
                  counter = 0; //set for next subroutine
                  pttt1Info->state = kOutlinePath;
                  cmd = kUFLOutlineIterMoveTo;
              }
              else
              {  //no more outlines.
                  cmd = kUFLOutlineIterDone;
              }
              break;
            }

            case kOutlinePath:
            {
tryAgain:
               if (cbPoly > 0)
               {
                   switch (lpfdPoly->iType)
                   {
                       case FD_PRIM_QSPLINE: //curveto
                       if (counter+1 < lpfdPoly->cptfx)
                       {
                          if ((counter+2) < lpfdPoly->cptfx)
                          {
                              p2->x = ((lpfdPoly->pte[counter].x + lpfdPoly->pte[counter+1].x) >> 1);
                              p2->y = ((lpfdPoly->pte[counter].y + lpfdPoly->pte[counter+1].y) >> 1);
                          }
                          else
                          {
                              p2->x = lpfdPoly->pte[counter+1].x;
                              p2->y = lpfdPoly->pte[counter+1].y;
                          }
                           p0->x = GDITOUFLFIX((pttt1Info->xCurrent + (lpfdPoly->pte[counter].x << 1)) / 3);
                           p0->y = (GDITOUFLFIX((pttt1Info->yCurrent + (lpfdPoly->pte[counter].y << 1)) / 3));
                           p1->x = GDITOUFLFIX((p2->x + (lpfdPoly->pte[counter].x << 1)) / 3);
                           p1->y = (GDITOUFLFIX((p2->y + (lpfdPoly->pte[counter].y << 1)) / 3));
                           pttt1Info->xCurrent = p2->x;
                           pttt1Info->yCurrent = p2->y;
                           p2->x = GDITOUFLFIX(p2->x);
                           p2->y = (GDITOUFLFIX(p2->y));
                           counter++;
                           cmd = kUFLOutlineIterCurveTo;
                           bAdvanceNextPoint = FALSE;
                       }
                       break;

                       default: //lineto
                       {
                           if (counter < lpfdPoly->cptfx)
                           {
                               pttt1Info->xCurrent = lpfdPoly->pte[counter].x;
                               pttt1Info->yCurrent = lpfdPoly->pte[counter].y;
                               p0->x = GDITOUFLFIX(lpfdPoly->pte[counter].x);
                               p0->y = (GDITOUFLFIX(lpfdPoly->pte[counter].y));
                               cmd = kUFLOutlineIterLineTo;
                               counter++; //move to next point
                               bAdvanceNextPoint = FALSE;
                            }
                        }
                        break;
                   } //end switch

                   if (bAdvanceNextPoint)
                   {
                     counter = 0; //reset for next subroutine
                     us = (lpfdPoly->cptfx - 1) * sizeof(TTPOINTFX) + sizeof(FDPOLYCURVE);
                     lpfdPoly = (LPFDPOLYCURVE) ((LPSTR)lpfdPoly + us);
                     cbPoly -= us;
                     cbRem -= us;
                     goto tryAgain;
                   }

               }
               else
               {
                    cmd = kUFLOutlineIterClose;
                    pttt1Info->state = kOutlineEnd;
               }//else
               break;
            }//case kOutlinePath:

        }//switch
    }//if

    pttt1Info->lpfdPoly = (LPFDPOLYCURVE)lpfdPoly;
    pttt1Info->lpPoly = (LPPOLYGONHEADER) lpPoly;
    pttt1Info->cbPoly = cbPoly;
    pttt1Info->cbRem = cbRem;
    pttt1Info->counter = counter;



    return cmd;
}


void DeleteGlyphOutlineIter(
    UFLHANDLE    handle
    )
{

}


unsigned long
GetFontData_TTF(
    VOID    *pTTFile,           // the Font FileMap handle
    unsigned long ulTable,      /* metric table to query */
    unsigned long cbOffset,     /* offset into table being queried */
    void          *pvBuffer,    /* address of buffer for returned data  */
    unsigned long cbData,       /* length of data to query */
    unsigned short index        /* Font Index in a TTC file */
    )
{

#if 0

    ULONG   size;
    unsigned char *p = NULL;

    if (pTTFile)  // safe-proof
    {
        p = (unsigned char *)pTTFile;
        if ( 0 == ulTable )
        {
            if ( pvBuffer )
            {
                memcpy( pvBuffer, p + cbOffset, cbData );
            }
            return cbData;
        }
        else
        {
            ULONG   ulSize;
            ULONG   ulTblOffset;

            ulSize = GetFontDataOT( pTTFile,       // Handle to view of memmapped TT Font File
                                    ulTable,       // metric table to query
                                    &ulTblOffset,  // Offset from pTTFile of requested table
                                    (ULONG)index );

            if ( pvBuffer )
            {
                if ( cbData <= ulSize )
                    memcpy( pvBuffer, p + ulTblOffset + cbOffset, cbData );
                else
                    ulSize = 0;
            }

            return ulSize;
        }
    }
#endif

    return 0;
}




unsigned long
GetTTFontData(
    UFLHANDLE     handle,       /* Handle of client's private data */
    unsigned long ulTable,    /* metric table to query */
    unsigned long cbOffset,     /* offset into table being queried */
    void          *pvBuffer,    /* address of buffer for returned data  */
    unsigned long cbData,       /* length of data to query */
    unsigned short index        /* Font Index in a TTC file */
    )
{
    SUBFONT43 *pSubFont = (SUBFONT43 *)handle;
    LPFONTDATARECORD lpFontDataRecord= (LPFONTDATARECORD) pSubFont->lpFontData;
    LPPDEVICE lppd = (LPPDEVICE) pSubFont->lppd;
    LPPSFONTINFO FontInfo = (LPPSFONTINFO)pSubFont->FontInfo;
    LPTTFONTINFO lpttfi = (LPTTFONTINFO) ((LPSTR) FontInfo + FontInfo->dfBitsOffset);
    LPLOGFONT lplf = &(lpttfi->lfCopy);
    unsigned long rc = 0;
    DWORD nFontSize;
    HDC hDC = NULL ;
    HFONT hFont = NULL ;
    HFONT hPrevFont = NULL ;
    int iDLFontFormat;

    iDLFontFormat = lpttfi->iDLFontFormat;

    // GetFontData requires a screen DC to operate
    if ((hDC = GetDC(NULL)) == NULL) goto exit ;
    if ((hFont = CreateFontIndirect (lplf)) == NULL) goto exit ;
    if ((hPrevFont = SelectObject (hDC, hFont)) == NULL) goto exit ;

    nFontSize = GetFontData(hDC, (DWORD)ulTable, (DWORD) cbOffset, (LPVOID) pvBuffer ,(DWORD) cbData);
    if (nFontSize >= 0xFFFFFFFFL)
      nFontSize = 0;

exit:
    if (hPrevFont != NULL)
        SelectObject (hDC, hPrevFont) ;
    if (hFont != NULL)
        DeleteObject (hFont) ;
    if (hDC != NULL)
        ReleaseDC (NULL, hDC) ;

    rc = nFontSize; //non-zero return value means ok.
    return (rc);

}



unsigned long
TTGetGlyphID(
    UFLHANDLE       handle,       /* Handle of client's private data */
    unsigned short  unicode,      /* not used here on Win95 */
    unsigned short  localCode
    )
{
    SUBFONT43           *pSubFont = (SUBFONT43 *)handle;
    LPFONTDATARECORD    lpFontDataRecord= (LPFONTDATARECORD) pSubFont->lpFontData;
    LPPSFONTINFO        FontInfo = (LPPSFONTINFO)pSubFont->FontInfo;
    LPTTFONTINFO        lpttfi = (LPTTFONTINFO) ((LPSTR) FontInfo + FontInfo->dfBitsOffset);
    LPLOGFONT           lplf = &(lpttfi->lfCopy);
    HDC                 hDC = NULL ;
    HFONT               hFont = NULL ;
    HFONT               hPrevFont = NULL ;
    unsigned short      gid = 0;
    char                str[4];
    GCP_RESULTS results;

    // Use Screen DC.
    hDC=GetDC(NULL);
    hFont = CreateFontIndirect(lplf);
    hPrevFont = SelectObject(hDC, hFont);

    results.lStructSize = sizeof(GCP_RESULTS);
    results.lpOutString = NULL;
    results.lpOrder = NULL;
    results.lpOutString = NULL;
    results.lpOrder = NULL;
    results.lpDx = NULL;
    results.lpCaretPos = NULL;
    results.lpClass = NULL;
    results.lpGlyphs = &gid;
    results.nGlyphs = results.nMaxFit = 1;
    str[0] = (char) localCode & 0x00FF;
    str[1] = (char) localCode >> 8;
    str[2]='\0';

    GetCharacterPlacement(hDC, (LPSTR)str, 1, 1, &results, 0);

    if (hPrevFont != NULL)
        SelectObject (hDC, hPrevFont) ;
    if (hFont != NULL)
        DeleteObject (hFont) ;
    if (hDC != NULL)
        ReleaseDC (NULL, hDC) ;

    return (gid);

}


/* If is trick to figure out the inde xin a TTC file. Bodin suggested follwoing:
From: Bodin Dresevic <bodind@MICROSOFT.com>
Date: Fri, 18 Apr 1997 16:00:23 -0700
...
If TTC file supports vertical writing (mort or gsub table are present),
then you can get to the index in the ttf file within TTC as follows:

	iTTC = (pfo.iFace - 1) / 2; // pfo.iFace iz 1 based, iTTC is
zero based.

If the font does not support vertical writing (do not know of any ttc's
like that, but they could exist in principle) than iTTC is just
            iTTC = pfo.iFace - 1;

In principle, one could have a mixture of faces, some supporting
vertical writing and some not, but I doubt that any such fonts really
exist. ...
*/

unsigned short
sGetTTCFontIndex(
/*
    LPPDEVICE            pdev,
    FONTOBJ         *pfo
*/
)
{
#if 0
DWORD           dwSize;
VOID            *pTTFile = NULL;
CHAR            buf[5];
unsigned short  sIndex =0;

    if ( pfo )
    {
        pTTFile = FONTOBJ_pvTrueTypeFontFile(pfo, &dwSize );
    }

    if (!pTTFile)
    {
        return 0;
    }
    else
    {

        dwSize = GetFontData_TTF(pTTFile, 0, 0, (VOID *)&buf, 4, 0);
        if (dwSize==0 || dwSize==0xFFFFFFFFL)
            return 0;

        if ( (*((unsigned long*) ((char *)&buf))) == ttcf_TABLE )
        {
            /* really a TTC file, check if vertical is supported  - "GSUB" or "mort" */

            dwSize = GetFontData_TTF(pTTFile, GSUB_TABLE, 0, (VOID *)&buf, 4, 0);

            if (dwSize==0 || dwSize==0xFFFFFFFFL)
            {
                dwSize = GetFontData_TTF(pTTFile, mort_TABLE, 0, (VOID *)&buf, 4, 0);
            }

            if (dwSize ==0 || dwSize==0xFFFFFFFFL)
            {
                /* no "GSUB" nor "mort" */
                sIndex = (unsigned short) ((long)pfo->iFace - 1);
            }
            else
            {
                sIndex = (unsigned short) ((long)pfo->iFace - 1)/2;
            }
        }
        else
            sIndex = 0;
    }


    return sIndex;
#endif

   return 0;
}



BOOL
BSetFontDataInfo(
    LPPDEVICE           pdev,
    LPPSFONTINFO        lpFontInfo,
    UFLFontDataInfo     *pFData,
    DWORD               dwMaxGlyphs
    )

/*++

Routine Description:

    Set FontData Info for UFL from the font object.

Arguments:

    pdev          Pointer to DEVDATA structure
    pfo           Pointer to FONTOBJ
    pFData        pointer where to set the Data
    dwMaxGlyph    max number of glyphs in this font

Return Value:

    TRUE if success, otherwise, FALSE

--*/
{
    LPTTFONTINFO lpttfi = (LPTTFONTINFO) ((LPSTR)lpFontInfo  + lpFontInfo->dfBitsOffset);

    if (pFData == NULL)
        return FALSE;

    /* Next item will be initialized by UFL */
    pFData->offsetToTableDir = 0 ;

    /* num of maximal glyphs in this PS font to be created - e.g.,255 for T1/T3 */
    pFData->maxGlyphs = dwMaxGlyphs;

    /* num of glyphs in this TT font - FONTOBJ_cGetAllGlyphHandles( pfo, NULL ) is not reliable */
    if (lpttfi->dwProperties & TTFI_IS_REAL_TT)
    {
        pFData->cNumGlyphs = 0; // set to 0, so UFL will figure it out
    }
    else
    {
        if (pdev->fDBCS & DBCS_FONT)
            pFData->cNumGlyphs = MAX_NUM_CHARS_CJK;
        else
            pFData->cNumGlyphs = MAX_NUM_CHARS_US;
    }

    pFData->pUniqueNameA = NULL;
    pFData->pUniqueNameW = NULL;

    /* stuff to handle TTC - provided by client */

//    pFData->fontIndex = sGetTTCFontIndex(pdev);
      pFData->fontIndex = 0;


#if 0
    if (pFData->fontIndex == FONTINDEX_UNKNOWN)
    {
        // Set up the unique name string for UFL to select fontIndex in a TTC
        // On Windows, the Unicode string is used.
        if ( ( pifiTT = FONTOBJ_pifi( pfo ) ) == NULL )
        {
            WARNING(("Failing FONTOBJ_pifi.\n"));
        }
        else
        {
            /* info.pUniqueNameW is a constant pointer, no need to free it.
             * !!! Its life time is only as long as this InitT42 call !!! */
            pFData->pUniqueNameW = (unsigned short *)((BYTE *)pifiTT + pifiTT->dpwszUniqueName);
        }
    }

#endif
    /* Set the XUID inof to 0, so UFL will figure it out when needed */
    pFData->xuid.sSize = 0;
    pFData->xuid.pXUID = NULL;

    return TRUE;
}


BOOL FAR PASCAL
BNewType3Font(
    LPPDEVICE       pdev,
    LPSUBFONT43     pSubFont,
    DWORD           cGlyphs,
    DLFONT_FORMAT   type3or332
    )

/*++

Routine Description:

    Create a font type 3 object.

Arguments:

    pdev        Pointer to DEVDATA structure
    pSubFont    Pointer to SUBFONT
    cGlyphs     Number of glyphs to be downloaded

Return Value:

    TRUE if success, otherwise, FALSE

--*/
{
    UFLRequest      request;
    UFLTTT3FontInfo info;
    LPPSFONTINFO FontInfo = (LPPSFONTINFO)pSubFont->FontInfo;
    LPTTFONTINFO lpttfi;
    WORD  dfFirstChar, dfLastChar ;
    LONG EmPels;            // # pels per EM

    lpttfi = (LPTTFONTINFO) ((LPSTR)FontInfo  + FontInfo->dfBitsOffset);
    dfFirstChar = 0 ;
    dfLastChar      = *(LPWORD)&FontInfo->dfFirstChar - 1 ;
    if(lpttfi->HighByte == (dfLastChar & 0xFF00) )
        dfLastChar &= 0x00ff ;
    else
        dfLastChar = 0x00ff ;

    cGlyphs = (DWORD) dfLastChar - dfFirstChar;

    //size of largest glyph
    info.cbMaxGlyphs =  BiToByAl(FontInfo->dfMaxWidth, 4);
    info.cbMaxGlyphs *= FontInfo->dfPixHeight;

    // Changed 29-Mar-1993  -by-   [olegs] in order to fix the
    //  text alignment problems. When defining the basic font we should
    //  use size of font in pixels, not calculate it from the size in points.
    EmPels = ((LONG) lpttfi->sy) << 16 ;
    info.matrix.a = EmPels; //UFLShortToFixed(EmHeight);
    info.matrix.b = 0;
    info.matrix.c = 0;
    info.matrix.d = EmPels; //UFLShortToFixed(EmHeight);
    info.matrix.e = 0;
    info.matrix.f = 0;

    // Define the bounding box for the font, defined in 1 unit
    // character space (since FontMatrix = identity).
    info.bbox[0] = -EmPels; //UFLShortToFixed(0);
    info.bbox[1] = -EmPels; //UFLShortToFixed(0);
    info.bbox[2] = EmPels;  //UFLShortToFixed(0);
    info.bbox[3] = EmPels;  //UFLShortToFixed(0);

    // Initialize the FontData related struture:
    BSetFontDataInfo(pdev, FontInfo, &(info.fData), cGlyphs );


    // Initialize the font request structure
    if (DLFONT_TYPE332 == type3or332 )
    {
        request.lDownloadFormat = kTTType332;   /* Type 3 or Type3/32 */
        pSubFont->iUFLDLFormat = DLFONT_TYPE332 ;
    }
    else
    {
        request.lDownloadFormat = kTTType3;     /* Type 3-Only */
        pSubFont->iUFLDLFormat = DLFONT_TYPE3 ;
    }

    request.pszFontName = pSubFont->strPSName;
    request.hFontInfo = (UFLHANDLE)&info;
    request.hData = (UFLHANDLE)pSubFont;
    request.bUseHheaForVhea = 0; //bug 287084 always want to check vhea  T42 thing, place here for completeness

    // Fix 309482
    request.nT42VObliqueElementIndex = kUFLT42VFontMatrixElement2;
    request.pszT42VObliqueTangentTheta = kUFLT42VObliqueTangent12;

    if (MacGlyphNameList == NULL)
        request.pMacGlyphNameList = NULL;
    else
        request.pMacGlyphNameList = (LPBYTE) MacGlyphNameList;

    // Use my Encoding vector or not
    if (gbUseG00GFF /*|| !BHasPostTable(pSubFont)*/)
    {
        request.pszEncodeName = pszG00GFFEncoding;
        request.useMyGlyphName = 1 ;
    }
    else
    {
        request.pszEncodeName = NULL;
        request.useMyGlyphName = 0 ;
    }

    // Fix bug #274008
    GetEncodingArray(pdev, pSubFont, &request);

    pSubFont->pufo = (LPVOID)UFLNewFont(pdev->pufl, &request);

    // Checking the result
    return ( pSubFont->pufo ) ? TRUE : FALSE;
}

VOID FAR PASCAL
DeleteType3Font(
    LPSUBFONT43    pSubFont
    )
{
    if ( pSubFont->pufo )
    {
        UFLDeleteFont( (UFO)pSubFont->pufo );
        pSubFont->pufo = NULL;
    }
}


VOID SetType42CIDInfo(
    LPPDEVICE       pdev,
    UFLTTFontInfo   *pInfo,
    LPPSFONTINFO    FontInfo,
    FONTTYPE        t42Format
    )
{

    LPCMAPINFO  lpCMapInfo;
    BOOL        bEUDC =pdev->lpPSExtDevmode->dm2.bEUDCAble;

    if (t42Format == CID_H || t42Format == CID_V )
    {
        // let UFL do the magic
        pInfo->bUseIdentityCMap = 1;

        /* CMap and so on are ignored by UFL in this case */
        pInfo->CMap.CMapName[0] = 0;
        pInfo->CMap.Registry[0] = 0;
        pInfo->CMap.Ordering[0] = 0;
        pInfo->CIDCount = 0;
        pInfo->bUpdateCIDMap = 0; /* use Identity as in  UFL */
        return;
    }

    lpCMapInfo = GetCMAPInfo((int)FontInfo->dfCharSet,
                    ((pdev->fDBCS & DBCS_VERT)>0)?1:0 );

    pInfo->bUseIdentityCMap = 0; /* Don't use the Identity CMap */

    lstrcpy(pInfo->CMap.CMapName, lpCMapInfo->CMapName);
    lstrcpy(pInfo->CMap.Registry, lpCMapInfo->Registry);
    lstrcpy(pInfo->CMap.Ordering, lpCMapInfo->Ordering);

    pInfo->CMap.CMapVersion = lpCMapInfo->CMapVersion;
    pInfo->CMap.CMapType = lpCMapInfo->CMapType;
    pInfo->CMap.Supplement = lpCMapInfo->Supplement;

    pInfo->CIDCount = GetCIDCount((int)FontInfo->dfCharSet, bEUDC);

    /* Always ask UFL to update CIDMap - we don't provide CIDMap at definefont time*/
    pInfo->bUpdateCIDMap = 1;

    return;
}


BOOL
BNewType42Font(
    LPPDEVICE       pdev,
    LPSUBFONT43     pSubFont,
    DWORD           cGlyphs,
    FONTTYPE        t42Format
    )

/*++

Routine Description:

    Create a type 42 font object.

Arguments:

    pdev        Pointer to DEVDATA structure
    pSubFont    Pointer to SUBFONT
    pfo         Pointer to FONTOBJ
    cGlyphs     Number of glyphs to be downloaded
    t42Format   Type42 format: 0-plain42, 1-CID/42-H, 2-CID/42-V, may add for other formats

Return Value:

    TRUE if success, otherwise, FALSE

--*/
{
    UFLTTFontInfo   info;
    UFLRequest      request;
    LPPSFONTINFO    FontInfo = (LPPSFONTINFO)pSubFont->FontInfo;

#if 0
    Maybe change this code later to check if we need to bailout.
    if ( NULL == pSubFont->pDLFont->pTTFile )
    {
        // Cannot do T42 if the TT File map handle is NULL
        return FALSE;
    }
#endif

    // Initialize the font info structure
    BSetFontDataInfo(pdev, FontInfo, &(info.fData), cGlyphs );

    SetType42CIDInfo(pdev, &info, FontInfo, t42Format);

    // Initialize the font request structure
    if (t42Format == CID_H)
    {
        request.lDownloadFormat = kTTType42CID_H;
        pSubFont->iUFLDLFormat = DLFONT_TYPE42 ;
    }
    else if (t42Format == CID_V)
    {
        request.lDownloadFormat = kTTType42CID_V;
        pSubFont->iUFLDLFormat = DLFONT_TYPE42 ;
    }
    else if (t42Format == CID_RESOURCE_H)
    {
        request.lDownloadFormat = kTTType42CID_Resource_H;
        pSubFont->iUFLDLFormat = DLFONT_TYPE42_CID ;
    }
    else if (t42Format == CID_RESOURCE_V)
    {
        request.lDownloadFormat = kTTType42CID_Resource_V;
        pSubFont->iUFLDLFormat = DLFONT_TYPE42_CID ;
    }
    else
    {
        request.lDownloadFormat = kTTType42;
        pSubFont->iUFLDLFormat = DLFONT_TYPE42 ;
    }

    request.pszFontName = pSubFont->strPSName;
    request.hFontInfo = (UFLHANDLE)&info;
    request.hData = (UFLHANDLE)pSubFont;
    request.bUseHheaForVhea = 0; //bug 287084 always want to check vhea

    // Fix 309482
    request.nT42VObliqueElementIndex = kUFLT42VFontMatrixElement2;
    request.pszT42VObliqueTangentTheta = kUFLT42VObliqueTangent12;

    if (MacGlyphNameList == NULL)
        request.pMacGlyphNameList = NULL;
    else
        request.pMacGlyphNameList = (LPBYTE) MacGlyphNameList;

    // Use my Encoding vector or not for Type42 only (not for 42/CID)
    if (gbUseG00GFF || request.lDownloadFormat != kTTType42 )
    {
        request.pszEncodeName = pszG00GFFEncoding;
        request.useMyGlyphName = 1 ;
    }
    else
    {
        request.pszEncodeName = NULL;
        request.useMyGlyphName = 0 ;
    }

    // Fix bug #274008
    GetEncodingArray(pdev, pSubFont, &request);

    // Create a UFO
    pSubFont->pufo = UFLNewFont( pdev->pufl, &request );

    // Checking the result
    return ( pSubFont->pufo ) ? TRUE : FALSE;
}


VOID
DeleteType42Font(
   LPSUBFONT43    pSubFont
    )
{
    if ( pSubFont->pufo )
    {
        UFLDeleteFont( (UFO)pSubFont->pufo );
        pSubFont->pufo = NULL;
    }
}


#if 0
BOOL
BTestCFFRestricted(
    PDEV        pdev,
    PVOID       pTTFile,
    DWORD       cGlyphs,
    FONTTYPE    tCFFFormat
    )

/*++

Routine Description:

    Create a CFF Font object and test restrictions on it.

Arguments:

    pdev        Pointer to DEVDATA structure
    pSubFont    Pointer to SUBFONT
    cGlyphs     Number of glyphs to be downloaded
    tCFFFormat  Format type:
		    0 - type 1
		    1 - CID Horiziontal
		    2 - CID Vertical

Return Value:

    TRUE if success, otherwise, FALSE

--*/
{
    DRVCFFINFO       *pCff;
    UFLCFFFontInfo   info = {0};
    UFLRequest       request;
    BOOL             bRetVal;


    pCff = MemAlloc( sizeof( DRVCFFINFO ) );
    if ( NULL == pCff )
	return FALSE;

    bRetVal = FALSE;

    // Initialize the FontData related struture:
    BSetFontDataInfo(pdev, &(info.fData), cGlyphs );

    info.fontLength = GetFontDataOT( pTTFile,       // Handle to view of memmapped TT Font File
			    (*(unsigned long*)"CFF "),       // metric table to query
			    &pCff->ulOffset,  // Offset from pTTFile of requested table
			    0 );              //BUGBUG - is there TTC for CFF fonts? 0==first font in this file

    // Initialize the font info structure
    if ( info.fontLength )
    {
	pCff->pFontData = (char *)pTTFile + pCff->ulOffset;

	info.ppFontData = &pCff->pFontData;
	info.fontIndex = 0;
	info.uniqueIDMethod = kUndefineUID;

	if (TARGET_PSLEVEL(pdev) < 2 )
	    info.subrFlatten = kKeepSubrs;
	else
	    info.subrFlatten = kFlattenSubrs;

	info.maxBlockSize = 512;
	info.useSpecialEncoding = 0;

	switch ( tCFFFormat )
	{
	case BASE_FONT:
	    request.lDownloadFormat = kCFF;
	    info.usePSName = 1;
	    break;
	case CID_H:
	    request.lDownloadFormat = kCFFCID_H;
	    info.usePSName = 0;
	    break;
	case CID_V:
	    request.lDownloadFormat = kCFFCID_H;
	    info.usePSName = 0;
	    break;
	}

	request.pszFontName = "Dummy";
	request.hFontInfo = (UFLHANDLE)&info;
	request.hData = (UFLHANDLE)NULL;
   request.bUseHheaForVhea = 0; //bug 287084 always want to check vhea  T42 thing, place here for completeness

   // Fix 309482
   request.nT42VObliqueElementIndex = kUFLT42VFontMatrixElement2;
   request.pszT42VObliqueTangentTheta = kUFLT42VObliqueTangent12;

	request.pszEncodeName = NULL;

	bRetVal = bUFLTestRestricted( pdev->pufl, &request );
	}
	MemFree( pCff );

    return bRetVal;

}
#endif

#if 0
BOOL
BNewCFFFont(
    LPPDEVICE        pdev,
    LPSUBFONT43    pSubFont,
    FONTOBJ     *pfo,
    DWORD       cGlyphs,
    FONTTYPE    tCFFFormat
    )

/*++

Routine Description:

    Create a CFF Font object.
    The routine creates a DRVCFFINFO structure so that it can save the font
    data information.  This structure contains the real UFO handle.
    The handle that it returns in the SubFont is the DRVCFFINFO handle.

Arguments:

    pdev        Pointer to DEVDATA structure
    pSubFont    Pointer to SUBFONT
    pfo         Pointer to FONTOBJ
    cGlyphs     Number of glyphs to be downloaded
    tCFFFormat  Format type:
                    0 - type 1
                    1 - CID Horiziontal
                    2 - CID Vertical

Return Value:

    TRUE if success, otherwise, FALSE

--*/
{
    DRVCFFINFO       *pCff;
    UFLCFFFontInfo   info = {0};
    UFLRequest       request;
    ULONG            size;
    BOOL             bRetVal;


    if ( NULL == pSubFont->pDLFont->pTTFile )
        return FALSE;

    pCff = MemAlloc( sizeof( DRVCFFINFO ) );
    if ( NULL == pCff )
        return FALSE;

    bRetVal = FALSE;

    // Initialize the FontData related struture:
    BSetFontDataInfo(pdev, pfo, &(info.fData), cGlyphs );

    info.fontLength = GetFontDataOT( pSubFont->pDLFont->pTTFile,       // Handle to view of memmapped TT Font File
                            (*(unsigned long*)"CFF "),       // metric table to query
                            &pCff->ulOffset,  // Offset from pTTFile of requested table
                            0 );              //BUGBUG - is there TTC for CFF fonts? 0==first font in this file

    // Initialize the font info structure
    if ( info.fontLength )
    {
        pCff->pFontData = (char *)pSubFont->pDLFont->pTTFile + pCff->ulOffset;

        info.ppFontData = &pCff->pFontData;
        info.fontIndex = 0;
        info.uniqueIDMethod = kUndefineUID;

        if (TARGET_PSLEVEL(pdev) < 2 )
            info.subrFlatten = kKeepSubrs;
        else
            info.subrFlatten = kFlattenSubrs;

        info.maxBlockSize = 512;
        info.useSpecialEncoding = 0;

        switch ( tCFFFormat )
        {
        case BASE_FONT:
            request.lDownloadFormat = kCFF;
            info.usePSName = 1;
            break;
        case CID_H:
            request.lDownloadFormat = kCFFCID_H;
            info.usePSName = 0;
            break;
        case CID_V:
            request.lDownloadFormat = kCFFCID_H;
            info.usePSName = 0;
            break;
        }

        request.pszFontName = pSubFont->strPSName;
        request.hFontInfo = (UFLHANDLE)&info;
        request.hData = (UFLHANDLE)pSubFont;
        request.bUseHheaForVhea = 0; //bug 287084 always want to check vhea  T42 thing, place here for completeness

        // Fix 309482
        request.nT42VObliqueElementIndex = kUFLT42VFontMatrixElement2;
        request.pszT42VObliqueTangentTheta = kUFLT42VObliqueTangent12;

        if (MacGlyphNameList == NULL)
           request.pMacGlyphNameList = NULL;
        else
            request.pMacGlyphNameList = (LPBYTE)MacGlyphNameList;

        request.pszEncodeName = NULL;

        // Create a UFO
        pCff->pufo = UFLNewFont( pdev->pufl, &request );
        if ( pCff->pufo )
        {
            pSubFont->pufo = pCff;
            bRetVal = TRUE;
        }
    }

    if ( FALSE == bRetVal )
        MemFree( pCff );

    return bRetVal;
}
#endif

#if 0
VOID
DeleteCFFFont(
    LPSUBFONT43    pSubFont
    )
{
    if ( pSubFont->pufo )
    {
        DRVCFFINFO       *pCff = (DRVCFFINFO *)pSubFont->pufo;
        if ( pCff )
        {
            UFLDeleteFont( (UFO)pCff->pufo );
            MemFree( pSubFont->pufo );
            pSubFont->pufo = NULL;
        }
    }
}
#endif


#define  SHIFTBITS  0

BOOL FAR PASCAL
BNewType1Font(
    LPPDEVICE   pdev,
    LPSUBFONT43   pSubFont,
    DWORD       cGlyphs // num of maximal glyphs in this PS font to be created -eg255 for T1/T3
    )

/*++

Routine Description:

    Create a type 1 font object

Arguments:

    pdev        Pointer to DEVDATA structure
    pSubFont    Pointer to SUBFONT
    pfo         Pointer to FONTOBJ
    pifi        Pointer to font IFIMETRICS
    cGlyphs     Number of glyphs to be downloaded

Return Value:

    TRUE if success, otherwise, FALSE

--*/
{
    UFLTTT1FontInfo info;
    UFLRequest        request;
    DRVTTT1INFO     *pttt1Info;
    WORD  dfFirstChar, dfLastChar ;
    WORD  TTRefEM ;         // Local copy of TTRefEM
//    LONG EmPels;
    LPTTTOTYPE1STUFF lpTTtoT1stuff = (LPTTTOTYPE1STUFF) &pdev->GlobalBuffer.TTtoT1stuff;
    PSERROR rc = PS_SUCCESS;
    LPPSFONTINFO FontInfo = (LPPSFONTINFO)pSubFont->FontInfo;
    LPTTFONTINFO lpttfi;


    lpttfi = (LPTTFONTINFO) ((LPSTR)FontInfo + FontInfo->dfBitsOffset);
    if( FontInfo->dfType & PF_GLYPH_INDEX )
    {
	  dfFirstChar = 0 ;
	  dfLastChar      = *(LPWORD)&FontInfo->dfFirstChar - 1 ;

	  if(lpttfi->HighByte == (dfLastChar & 0xFF00) )
		 dfLastChar &= 0x00ff ;
	  else
		 dfLastChar = 0x00ff ;
    }
    else
    {
	  dfFirstChar = FontInfo->dfFirstChar ;
	  dfLastChar = FontInfo->dfLastChar ;
    }


    TTRefEM = lpttfi->TTRefEM;
//    EmPels = ((long) TTRefEM) << SHIFTBITS;

    // Allocate driver's TTT1FontInfo
    pttt1Info = (DRVTTT1INFO *)GlobalAllocPtr( GHND|GMEM_DDESHARE, sizeof( DRVTTT1INFO) );
    if ( NULL == pttt1Info )
        return FALSE;


    // Initialize the FontData related struture:
    BSetFontDataInfo(pdev, FontInfo, &(info.fData), cGlyphs );

#if 0
    if (TARGET_PSLEVEL(pdev) < 2 ||
        GetPSVersion(pdev) < 2000 ||
        (pdev->pPpdData->dwFlags & PPDFLAG_REQEEXEC) ||
        (pdev->dwDebugFlags & PSDBG_FORCE_EEXEC))
    {
        info.bEExec = 1;
    }
    else
#endif
        info.bEExec = 0;

    info.matrix.a = UFLShortToFixed( TTRefEM );
    info.matrix.b = 0;
    info.matrix.c = 0;
    info.matrix.d = UFLShortToFixed( TTRefEM );
    info.matrix.e = 0;
    info.matrix.f = 0;

    // Initialize the font request structure
    request.lDownloadFormat = kTTType1;
    request.pszFontName = pSubFont->strPSName;
    request.hFontInfo = (UFLHANDLE)&info;
    request.hData = (UFLHANDLE)pSubFont;
    request.bUseHheaForVhea = 0; //bug 287084 always want to check vhea  T42 thing, place here for completeness

    // Fix 309482
    request.nT42VObliqueElementIndex = kUFLT42VFontMatrixElement2;
    request.pszT42VObliqueTangentTheta = kUFLT42VObliqueTangent12;

    if (MacGlyphNameList == NULL)
        request.pMacGlyphNameList = NULL;
    else
        request.pMacGlyphNameList = (LPBYTE) MacGlyphNameList;

    // Use my Encoding vector or not
    if (gbUseG00GFF  /*|| !BHasPostTable(pSubFont)*/)
    {
        request.pszEncodeName = pszG00GFFEncoding;
        request.useMyGlyphName = 1 ;
    }
    else
    {
        request.pszEncodeName = NULL;
        request.useMyGlyphName = 0 ;
    }

    // Fix bug #274008
    GetEncodingArray(pdev, pSubFont, &request);

    // Create a UFO
    pttt1Info->pufo = UFLNewFont( pdev->pufl, &request );

    // Checking the result
    if ( pttt1Info->pufo )
    {
        pSubFont->pufo = (LPVOID)pttt1Info;
        pSubFont->iUFLDLFormat = DLFONT_TYPE1 ;
        return TRUE;
    }
    else
    {
        GlobalFreePtr( pttt1Info );
        return FALSE;
    }

}

VOID FAR PASCAL
DeleteType1Font(
    LPSUBFONT43    pSubFont
    )
{
    DRVTTT1INFO *pttt1Info;

    pttt1Info = (DRVTTT1INFO *)pSubFont->pufo;
    if ( pttt1Info )
    {
        if ( pttt1Info->pufo )
        {
            UFLDeleteFont( (UFO)pttt1Info->pufo );
            pSubFont->pufo = NULL;
        }
        GlobalFreePtr( pttt1Info );
    }
}

BOOL FAR PASCAL
BUFODownload(
    ULONG           ulPSFontFmt,
    LPSUBFONT43     pSubFont,
    SHORT           cGlyphs,
    unsigned long   *phgList,
    unsigned char   **glyphNames,
    USHORT          *pCharIndex,
    WORD            *pUnicode,
    unsigned long   *pVMUsage,
    unsigned long   *pFCUsage
    )

/*++

Routine Description:

    Download a font

Arguments:

    pdev        Pointer to DEVDATA structure
    ulPSFontFmt Font format
    pSubFont    Pointer to SUBFONT structure
    cGlyphs     Number of glyphs to be downloaded
        	Pointer to array of HGLYPH's to be downloaded
	glyphNames  Pointer to list of glyph naes
    pCharIndex	Pointer to list of glyph character index
    VMUsage		Pointer to the VM usage for this request

Return Value:

    TRUE if success, otherwise, FALSE

--*/
{
UFLGlyphsInfo   glyphsInfo;

    if ( NULL == pSubFont )
        return FALSE;

    glyphsInfo.sCount         = cGlyphs;
    glyphsInfo.pGlyphIndices  = (UFLGlyphID *)phgList;
    glyphsInfo.pCharIndex     = pCharIndex,
    glyphsInfo.ppGlyphNames   = glyphNames;
    glyphsInfo.pCode          = (unsigned short *) pUnicode;

    switch ( ulPSFontFmt )
    {

        case DLFONT_TYPE1:
        {
            DRVTTT1INFO *pttt1Info;

            pttt1Info = (DRVTTT1INFO *)pSubFont->pufo;

            return ( kNoErr == UFLDownloadIncr( (const UFO)pttt1Info->pufo,
                                    (const UFLGlyphsInfo *) &glyphsInfo,
                                    pVMUsage, pFCUsage ) );
        }


		case DLFONT_PS_TYPE0:
        {
            DRVCFFINFO  *pCff = (DRVCFFINFO *)pSubFont->pufo;
            return ( kNoErr == UFLDownloadIncr( (const UFO)pCff->pufo,
                                    (const UFLGlyphsInfo *) &glyphsInfo,
                                    pVMUsage, pFCUsage ) );
        }

        case DLFONT_CFF:
        {
#if 0
            DRVCFFINFO  *pCff = (DRVCFFINFO *)pSubFont->pufo;
            BOOL        bRetVal = FALSE;
            DWORD       i;

            /* Reset the font data pointer. This pointer is only valid per DrvTextOut */
            pCff->pFontData = (char *)pSubFont->pDLFont->pTTFile + pCff->ulOffset;

            bRetVal = ( kNoErr == UFLDownloadIncr( (const UFO)pCff->pufo,
                                    (const UFLGlyphsInfo *) &glyphsInfo,
                                    pVMUsage, pFCUsage ) );

            return bRetVal;
#endif
            return 0;
        }


        case DLFONT_TYPE3:
        case DLFONT_TYPE32:
        case DLFONT_TYPE332:
        case DLFONT_TYPE42:
        case DLFONT_TYPE42_CID:
        {
           return ( kNoErr == UFLDownloadIncr( (const UFO)pSubFont->pufo,
                                    (const UFLGlyphsInfo *) &glyphsInfo,
                                    pVMUsage,pFCUsage ) );
        }


        default:
            return FALSE;

    }

}


BOOL FAR PASCAL
BUFOVMNeeded(
    ULONG           ulPSFontFmt,
    LPSUBFONT43     pSubFont,
    SHORT           cGlyphs,
    unsigned long   *phgList,
    unsigned char   **glyphNames,
    USHORT          *pCharIndex,
    WORD            *pUnicode,
    unsigned long   *pVMUsage,
    unsigned long   *pFCUsage
    )
{
UFLGlyphsInfo   glyphsInfo;
BOOL            bRetVal = FALSE;

    if ( NULL == pSubFont )
        return FALSE;

    glyphsInfo.sCount         = cGlyphs;
    glyphsInfo.pGlyphIndices  = (UFLGlyphID *)phgList;
    glyphsInfo.pCharIndex     = pCharIndex,
    glyphsInfo.ppGlyphNames   = glyphNames;
    glyphsInfo.pCode          = NULL;  // don't need it for VM?

    switch ( ulPSFontFmt )
    {

        case DLFONT_TYPE1:
        {
            DRVTTT1INFO *pttt1Info;

            pttt1Info = (DRVTTT1INFO *)pSubFont->pufo;

            bRetVal = ( kNoErr == UFLVMNeeded( (const UFO)pttt1Info->pufo,
                                    (const UFLGlyphsInfo *) &glyphsInfo,
                                    pVMUsage, pFCUsage ) );
            return bRetVal;
        }


        case DLFONT_PS_TYPE0:
        case DLFONT_CFF:
        {
#if 0
            DWORD       i;
            DRVCFFINFO  *pCff = (DRVCFFINFO *)pSubFont->pufo;

            /* Reset the font data pointer. This pointer is only valid per DrvTextOut */
            pCff->pFontData = (char *)pSubFont->pDLFont->pTTFile + pCff->ulOffset;

            bRetVal = ( kNoErr == UFLVMNeeded( (const UFO)pCff->pufo,
                                    (const UFLGlyphsInfo *) &glyphsInfo,
                                    pVMUsage, pFCUsage) );
#endif
            return bRetVal;

        }

        case DLFONT_TYPE3:
        case DLFONT_TYPE32:
        case DLFONT_TYPE332:
        case DLFONT_TYPE42:
        case DLFONT_TYPE42_CID:
        {
            bRetVal = ( kNoErr == UFLVMNeeded( (const UFO)pSubFont->pufo,
                                    (const UFLGlyphsInfo *) &glyphsInfo,
                                    pVMUsage, pFCUsage ) );
            return bRetVal;
        }

        default:
            return FALSE;
    }
}



BOOL
DownloadProcset(
    UFLStream *thisStream,
    unsigned long   procsetID
    )
{
    short  psNum;
    OUTSTREAM    *out;

    out = (OUTSTREAM *)thisStream;

    psNum = 0;

    switch ( procsetID )
    {
    case kT3Header:
        psNum = UFLT3HEADER;    //PSPROC_ufl_type3hdr_ps2;
        break;
    case kT42Header:
        psNum = UFLT42HEADER;   //PSPROC_ufl_type42_ps2;
        break;

    case kCFFHeader:
        psNum = UFLCFFHEADER;   //PSPROC_ufl_cffnt_ps2;
        break;

    case kCMap_FF:
        psNum = UFLCMAPFE;      //PSPROC_ufl_cmap_FFFF_ps2;
        break;
    }

    if ( psNum )
        if (TokenNeedsProcset(out->pdev, psNum) == RC_ok)
 	   return TRUE;
        else
           return FALSE;
    else
        return FALSE;
}




unsigned long
AddFontInfo(
    UFLHANDLE       handle,       /* Handle of client's private data */
    char            *bufOut,
    int             bufLen
    )
{
   SUBFONT43           *pSubFont = (SUBFONT43 *)handle;
   LPFONTDATARECORD    FontData= (LPFONTDATARECORD) pSubFont->lpFontData;
   LPPSFONTINFO        FontInfo = (LPPSFONTINFO)pSubFont->FontInfo;
   LPTTFONTINFO        lpttfi = (LPTTFONTINFO) ((LPSTR) FontInfo + FontInfo->dfBitsOffset);
   char                *kvPairs = bufOut;
   char                FontName[128];
   LPPDEVICE           lppd = (LPPDEVICE) pSubFont->lppd;
   FONTDATARECORD      tmpFontData;
   int                 len,i;
   CHAR                buffer[3];
   WORD                cBytes;
   CHAR                *pch;
   unsigned char       ch;

   lstrcpy(kvPairs, "\0");
   switch (FontData->fontDLType)
   {
      case CC_42:
      case CC_CID:
      case CC_T042:

         //WinCharSet
         len = wsprintf(FontName, "/WinCharSet %d def\n", (int)FontInfo->dfCharSet);
         lstrcat(kvPairs, FontName);

         //WinPitchAndFamily
         len = wsprintf(FontName, "/WinPitchAndFamily %d def\n", (int)lpttfi->lfCopy.lfPitchAndFamily);
         lstrcat(kvPairs, FontName);

      case GI_42:
      case GI_CID:
      case GI_T042:

         //OrigFontType
         lstrcat(kvPairs, "/OrigFontType /TrueType def \n");

         //OrigFontName
         lstrcat(kvPairs, "/OrigFontName <");
         lstrcpy((LPSTR)FontName, lpttfi->lfCopy.lfFaceName);
         FixWinSubsFontName(FontName, (int)FontInfo->dfCharSet);

	      //Convert font name to hex string
	      i = -1;
	      buffer[2] = '\0';
	      cBytes = (WORD)lstrlen(FontName);
	      pch = FontName;
	      while ( cBytes-- )
	      {
	         ch = *pch++;
	         i++;

	         // Convert ch to HEX representation
	         buffer[0] = HexTable[(ch >> 4) & 0x0f];
	         buffer[1] = HexTable[ch & 0x0f];
	         lstrcat(kvPairs, buffer);
	      }

         lstrcat(kvPairs, "> def \n");

         //OrigFontStyle
         lstrcat(kvPairs, "/OrigFontStyle (");
         CheckDLType(lppd, &(lpttfi->lfCopy), FontInfo, &tmpFontData);
         if ( ((lpttfi->lfCopy.lfWeight >= 700) || (FontInfo->dfWeight >= 700))
              && (!tmpFontData.BoldFake) )
            lstrcat(kvPairs, "Bold");
         if ( (lpttfi->lfCopy.lfItalic || FontInfo->dfItalic)
              && !tmpFontData.ItalicFake )
            lstrcat(kvPairs, "Italic");
         lstrcat(kvPairs, ") def \n");

      default:
         break;
   }
   return (1);
}


BOOL FAR PASCAL
BInitUFL(
    LPPDEVICE    pdev
    )
{
    UFLFontProcs    fp;
    UFLMemObj        memObj;
    OUTSTREAM        *out;
    UFLOutputDevice outDev;

    if (pdev->pufl)
    {
        // Already initialized - some apps may call JobInit() again at ResetDC() time
        return TRUE;
    }

    fp.pfGetGlyphBmp            = (UFLGetGlyphBmp)GetGlyphBmp;
    fp.pfDeleteGlyphBmp         = (UFLDeleteGlyphBmp)0;
    fp.pfCreateGlyphOutlineIter = (UFLCreateGlyphOutlineIter)CreateGlyphOutlineIter;
    fp.pfNextOutlineSegment     = (UFLNextOutlineSegment)NextOutlineSegment;
    fp.pfDeleteGlyphOutlineIter = (UFLDeleteGlyphOutlineIter)0;
    fp.pfGetTTFontData          = (UFLGetTTFontData)GetTTFontData;
    fp.pfGetCIDMap              = (UFLGetCIDMap)0;
    fp.pfGetGlyphID             = (UFLGetGlyphID)TTGetGlyphID;
    fp.pfGetRotatedGIDs         = (UFLGetRotatedGIDs)0;
    fp.pfGetRotatedGSUBs        = (UFLGetRotatedGSUBs)0;
    fp.pfAddFontInfo            = (UFLAddFontInfo)AddFontInfo;

    memObj.alloc = (UFLMemAlloc)UFOMemAlloc;
    memObj.free     = (UFLMemFree)UFOMemFree;
    memObj.copy = (UFLMemCopy) UFOMemCopy;
    memObj.set = (UFLMemSet) UFOMemSet;
    memObj.userData = (void *)0;

    if (MacGlyphNameList == NULL)
        LoadMacGlyphNameList();

    if (EncodeNameList == NULL)
        LoadEncodeNameList();
    if (pdev->pwCommonEncode == NULL)
        pdev->pwCommonEncode = (LPWORD)LoadFontResource(
                               ID_ENCODE_INDEX, &(pdev->hCommonEncode));

    out = (OUTSTREAM *)GlobalAllocPtr ( GHND|GMEM_DDESHARE, sizeof( OUTSTREAM ) );
    if ( out )
    {
        SHORT flavor;
        BOOL binary = 0;

        out->downloadProcset = (LPVOID)DownloadProcset;
        out->put = (LPVOID)Put;
        out->pdev = (LPPDEVICE) pdev;

        if (TARGET_PSLEVEL(pdev) < 2 )
            outDev.lPSLevel = kPSLevel1;
        else if (TARGET_PSLEVEL(pdev) == 2 )
            outDev.lPSLevel = kPSLevel2;
        else
            outDev.lPSLevel = kPSLevel3;

        DetermineOutputCharacteristics(pdev, &flavor, &binary);
        outDev.lPSVersion = GetPSVersion( pdev );
        outDev.bAscii = !(binary);
        outDev.pstream = (UFLStream *)out;

        pdev->pufl = (void *) UFLInit( TRUE, (const UFLMemObj *) &memObj,
                                   (const UFLFontProcs *) &fp,
                                   (const UFLOutputDevice *) &outDev );
        pdev->pout = (void *)out;

        return ( pdev->pufl ) ? TRUE : FALSE;
    }
    else
        return FALSE;
}

BOOL FAR PASCAL
BTermUFL(
    LPPDEVICE    pdev
    )
{

#if 0
    Don't need this for now.  Wait till i implement DLfont stuff.
    if ( pdev->pDLFonts )
    {
        DeleteDLFonts( pdev );
        pdev->pDLFonts = NULL;
    }
#endif

    if ( pdev->pufl )
    {
        UFLCleanUp( pdev->pufl );
        pdev->pufl = NULL;
    }

    if ( pdev->pout )
    {
        GlobalFreePtr( pdev->pout );
        pdev->pout = NULL;
    }

    if (pdev->pwCommonEncode)
    {
        UnloadFontResource(pdev->hCommonEncode);
        pdev->pwCommonEncode = NULL;
    }


    return TRUE;

}

#if 0
VOID
VDeletePSType1(
    LPPDEVICE        pdev,
    LPSUBFONT43    pSubFont
    )
{
    CHAR    buf[MAX_PSFONT_NAME+10];
    DWORD   dwLen;

    dwLen = OPSprintf( buf, "/%s %s\n", pSubFont->strPSName, PSFRAG_undefinefont );
    (VOID)OPSendRawData( pdev, buf, dwLen );
}
#endif



VOID
UFLUnDefineSubFonts(
    LPPDEVICE       pdev,
    LPSUBFONT43     pSubFont
)
/*++

Routine Description:

    Download a Piece of PostScript to undefine all PostScript fonts created
    by the driver from pSubFont:
    /MSTT31abcdefo0, /MSTT31abcdefo1, /MSTT31abcdefo0cid ....

Arguments:

    pdev        Pointer to DEVDATA structure
    pSubFont    Pointer to SUBFONT43

Return Value:

    None.

--*/

{
DRVTTT1INFO  *pttt1Info;
UFO          *pUfo;

    // Traverse the SubFont list
    while (1)
    {
        if (pSubFont == NULL)
            break;
        pUfo = NULL;
        switch ( pSubFont->iUFLDLFormat )
        {

            case DLFONT_TYPE1:
                pttt1Info = (DRVTTT1INFO *)pSubFont->pufo;
                if (pttt1Info)
                    pUfo = pttt1Info->pufo;
                break;

/*
            case DLFONT_PS_TYPE0:
            case DLFONT_CFF:
            {
                DRVCFFINFO  *pCff = (DRVCFFINFO *)pSubFont->pufo;
                if ( pCff )
                    pUfo = pCff->pufo;
                break;
            }
*/
            case DLFONT_TYPE3:
            case DLFONT_TYPE32:
            case DLFONT_TYPE332:
            case DLFONT_TYPE42:
            case DLFONT_TYPE42_CID:
                pUfo = pSubFont->pufo;
                break;

            default:
                break;
        }

        if (pUfo)
            UFLUndefineFont((const UFO)pUfo);

        pSubFont = pSubFont->pNext;
    }

    return ;
}


#if 0
VOID
VGetCIDFromGID(
    LPSUBFONT43        pSubFont,
    WORD            cGlyphs,
    WORD            *pGIDs,
    WORD            *pCIDs
    )
/*++

Routine Description:

    Obtain CID of a list of GIDs.

Arguments:

    pSubFont    Pointer to PSUBFONT
    cGlyphs     Number of glyphs in pGID
    pGID        Pointer to the list of GIDs that we need to determine the CIDs.
    pCID        Buffer pointer for the results.

Return Value:

    None.

--*/

{
    DRVCFFINFO  *pCff = (DRVCFFINFO *)pSubFont->pufo;

    if (pCff)
        UFLGIDsToCIDs(pCff->pufo, cGlyphs, (const UFLGlyphID *)pGIDs, pCIDs);
}
#endif



BOOL
BCopyFont(
    LPPDEVICE        pdev,
    LPSUBFONT43    pSubFontFrom,
    LPSUBFONT43    pSubFontTo,
    ULONG       ulPSFontFmt
    )

/*++

Routine Description:

    Create a font with new Encoding from another font

Arguments:

    pdev            Pointer to DEVDATA structure
    pSubFontFrom    Pointer to SUBFONT - has old UFObj
    pSubFontTo      Pointer to SUBFONT - creats a copy of the old UFObj
    pfo             Pointer to FONTOBJ
    cGlyphs         Number of glyphs to be downloaded
    ulPSFontFmt Font format

Return Value:

    TRUE if success, otherwise, FALSE

--*/
{
    UFLRequest  request = {0};

    if ( pSubFontFrom == NULL || pSubFontTo == NULL )
        return FALSE;

    // Use my Encoding vector or not
    if (gbUseG00GFF  || /* !BHasPostTable(pSubFontFrom) || */
         IS_TYPE42_CID(ulPSFontFmt) || IS_CFF_CID(ulPSFontFmt) )
    {
        request.pszEncodeName = pszG00GFFEncoding;
    }
    else
        request.pszEncodeName = NULL;

    /* For CopyFont, also need the ClientHandle -- hData and FontName */
    request.pszFontName = pSubFontTo->strPSName;
    request.hData = (UFLHANDLE)pSubFontTo;
    request.bUseHheaForVhea = 0; //bug 287084 always want to check vhea  T42 thing, place here for completeness
    // Fix 309482
    request.nT42VObliqueElementIndex = kUFLT42VFontMatrixElement2;
    request.pszT42VObliqueTangentTheta = kUFLT42VObliqueTangent12;

    switch ( ulPSFontFmt )
    {

        case DLFONT_TYPE1:
        {
            // This case is twisted - because of DRVTTT1INFO structure
            DRVTTT1INFO     *pttt1InfoFrom;
            DRVTTT1INFO     *pttt1InfoTo;

            // Allocate driver's TTT1FontInfo
            pttt1InfoTo = (DRVTTT1INFO *)GlobalAllocPtr( GHND|GMEM_DDESHARE, sizeof( DRVTTT1INFO) );

            if ( NULL == pttt1InfoTo )
                return FALSE;

            pttt1InfoFrom = (DRVTTT1INFO *)pSubFontFrom->pufo;

            pttt1InfoTo->pufo = (LPVOID)UFLCopyFont(
                                (const UFO)pttt1InfoFrom->pufo,
                                &request
                                );


            // Checking the result
            if ( pttt1InfoTo->pufo )
            {
                pSubFontTo->pufo = (LPVOID)pttt1InfoTo;
                return TRUE;
            }
            else
            {
                GlobalFreePtr( pttt1InfoTo );
                return FALSE;
            }

        }

        break;


        case DLFONT_TYPE3:
        case DLFONT_TYPE32:
        case DLFONT_TYPE332:
        case DLFONT_TYPE42:
        {
            pSubFontTo->pufo = (LPVOID)UFLCopyFont(
                                (const UFO)pSubFontFrom->pufo,
                                &request
                                );

            // Checking the result
            return ( pSubFontTo->pufo ) ? TRUE : FALSE;
        }

        break;


        case DLFONT_TYPE42_CID:
            // We don't copy (and reencode) CID/42 font

        case DLFONT_PS_TYPE0:
        case DLFONT_CFF:
            // not implemented yet - don't know if we ever need to do that
        default:
            return FALSE;

    }

    return FALSE;


}


BOOL BGrowUFLBuffers (
    LPUFLBUFFER lpUflBuffer,
    WORD        wNewDLGLyphSize,    /* size if the number of LONGs, not bytes */
    WORD        wNewCharIndexSize,
    WORD        wNewUnicodeSize,
    )
{
    VOID    *lpNewBuffer = NULL ;

    /* We don't need to keep the original contents - do Free() and Allocate()
     * Faster than ReAllocate() */
    if (wNewDLGLyphSize > lpUflBuffer->wDLGlyphSize )
    {

        lpNewBuffer = (VOID *)GlobalAllocPtr(GHND|GMEM_DDESHARE,
                        wNewDLGLyphSize * sizeof(DWORD) );

        if (lpNewBuffer)
        {
            GlobalFreePtr(lpUflBuffer->lpDLGlyph);
            lpUflBuffer->wDLGlyphSize = (WORD)wNewDLGLyphSize ;
            lpUflBuffer->lpDLGlyph = (LPDWORD) lpNewBuffer;
        }
        else
        {
            return FALSE;  // failure.
        }
    }

    if (wNewCharIndexSize > lpUflBuffer->wCharIndexSize )
    {
        lpNewBuffer = (VOID *)GlobalAllocPtr(GHND|GMEM_DDESHARE,
                        wNewCharIndexSize * sizeof(SHORT) );

        if (lpNewBuffer)
        {
            GlobalFreePtr(lpUflBuffer->lpCharIndex);
            lpUflBuffer->wCharIndexSize = (WORD)wNewCharIndexSize ;
            lpUflBuffer->lpCharIndex = (USHORT *) lpNewBuffer;
        }
        else
        {
            return FALSE;  // failure.
        }
    }

    if (wNewUnicodeSize > lpUflBuffer->wUnicodeSize)
    {
        lpNewBuffer = (VOID *)GlobalAllocPtr(GHND|GMEM_DDESHARE,
                        wNewUnicodeSize * sizeof(LONG) );

        if (lpNewBuffer)
        {
            GlobalFreePtr(lpUflBuffer->lpUnicode);
            lpUflBuffer->wUnicodeSize = (WORD)wNewUnicodeSize ;
            lpUflBuffer->lpUnicode = (LPWORD)lpNewBuffer;
        }
        else
        {
             return FALSE;  // failure.
        }
    }

    return TRUE; // success
}


/* TODO -- finish this here OR put his function in UFL -- TODO
int GetUnicodeFromGidStr(
    LPLONG      lpGid,
    int         numGlyph,
    LPLOGFONT   lplf,
    LPWORD      lpUnicode,
    int         iUnicode
    )
{
    HFONT hFont1, hOldFont1;
    HDC hDC;

    if (lpUnicode == NULL)
        return numGlyph;

    //
    // Get the unicode cmap sub table
    //
    hDC=GetDC(NULL);
    hFont1 = CreateFontIndirect(lplf);
    hOldFont1 = SelectObject(hDC, hFont1);

    //
    // parse cmap table for Unicode for each glyphID
    //

    SelectObject(hDC, hOldFont1);
    DeleteObject(hFont1);
    ReleaseDC(NULL, hDC);
}
*/


void FAR PASCAL FillUFLGIArray(
    LPPDEVICE       lppd,
    LPPSFONTINFO    FontInfo,
    WORD            wNumGlyphs,     /* number of glyphs/CharIndex/Unicode - a guess */
    LPDWORD         *lplpGid,         /* pointer to glyphID array */
    LPWORD          *lplpCharIndex,   /* pointer to CharIndex array */
    LPWORD          *lplpUnicode,     /* pointer to Unicode array */
    LPFONTDATARECORD lpFontDataRecord,
    LPSTR           lpStr,          /* Original Char String from TextOut() */
    int             *cb             /* Number of Glyphs after processing lpStr */
    )
{
    LPTTFONTINFO    lpttfi = (LPTTFONTINFO)((LPSTR)FontInfo + FontInfo->dfBitsOffset);
    WORD            HighByte = lpttfi->HighByte;
    WORD            ch2;
    DWORD           dw2HighBytes;
    int             i, j;
    int             iDLFontFormat = lppd->lpPSExtDevmode->dm2.iDLFontFmt;
    int             strLen = *cb;
    LPBYTE          tmp;
    LPDWORD         lpDLGlyph = NULL;
    LPWORD          lpCharIndex= NULL;
    LPWORD          lpUnicode = NULL;
    WORD            wGid;

    iDLFontFormat = lpttfi->iDLFontFormat;

    if (!BGrowUFLBuffers ( &(lppd->GlobalBuffer.UFLBuffers),
            wNumGlyphs,     /* size if the number of DWORDs, not bytes */
            wNumGlyphs,     /* number of CharIndex */
            wNumGlyphs      /* number of Unicode == number of glyphs */
            ) )
            return ; // failed

    /* BGrowUFLBuffers() may re-allocate these pointers */
    lpDLGlyph = lppd->GlobalBuffer.UFLBuffers.lpDLGlyph;
    lpCharIndex= lppd->GlobalBuffer.UFLBuffers.lpCharIndex;

    if (FontInfo->dfType & PF_GLYPH_INDEX)  //GI already
    {
//      In w95/422 T42(roman)GI only use straight GI, in 4.3 we changed it so that
//      T42(roman)GI will use Show order index like T1 and T3.
//      For FE font, we don't use show order index.
        if ((lppd->fDBCS & DBCS_FONT) && (iDLFontFormat == TT_DLFORMAT_TYPE42))
        {
            /* strLen is the Number of Glyph Indices */
            for (i = 0 ; i < strLen ; i++)
            {
                tmp = (LPBYTE) &wGid;
                *(tmp) = *(lpStr+(i*2));
                *(tmp+1) = *(lpStr+1+(i*2));
                lpDLGlyph[i] = wGid;
            }
        }
        //this is for T1/T3, T0-T1, T0/T3 and T42&!DBCS
        else
        {
            //sometime we are asked not to do show order index.
            //in such cases we will use straight GI
            if ( (!lppd->lpPSExtDevmode->dm2.bTrueTypeFast) ||
                 (lpFontDataRecord->lpGAS == NULL) )
            {
                for (i = 0 ; i < strLen ; i++)
                {
                    ch2 =  *(lpStr+i) & 0x00FF; //mask off high byte
                    wGid = HighByte | (WORD) ch2;
                    lpDLGlyph[i] = (long) wGid ;
                    lpCharIndex[i] = (USHORT) ch2;
                }
            }
            else
            {  //we are can use show order index.
                for (i = 0 ; i < strLen ; i++)
                {
                    ch2 =  *(lpStr+i) & 0x00FF; //mask off high byte
                    lpDLGlyph[i] = (long) GetGIFromAssignmentID(lpFontDataRecord->lpGAS , (WORD) (HighByte |(WORD)ch2));
                    lpCharIndex[i] = ch2; //one base.  //show order index
                }
            }
        }//else
    }
    else //convert CC to GI
    {
        WORD  wPrimaryIndex=0;
        BOOL  bEUDC = FALSE;
        LOGFONT logfont = lpttfi->lfCopy;
        WORD  oid;
        LPSTR lpTmp;

        /*
        * Mark this LOGFONT copy as TT_only realizable to prevent
        * ATM from realizing this font when we call CreateFontIndirect
        * and ATM has the PS font with the same name.
        * Fixed 27-May-1993  -by-  [olegs]
        */
        logfont.lfOutPrecision = OUT_TT_ONLY_PRECIS;
        bEUDC = lppd->lpPSExtDevmode->dm2.bEUDCAble;
        j = 0;

        for (i = strLen, lpTmp = lpStr; i>0; --i, ++lpTmp)
        {
            oid = GetOIDFromChar(lpTmp, FontInfo->dfCharSet, bEUDC);

            if (oid>255)
            {
                // must be a DBC - this is our OID's property
                dw2HighBytes = ((DWORD)*lpTmp) & 0x000000FF;
                dw2HighBytes = dw2HighBytes << 8;
                dw2HighBytes = dw2HighBytes | (((DWORD)*(lpTmp+1)) & 0x000000FF);
                lpTmp++;
                i--;
                (*cb)--;
            }
            else
                dw2HighBytes = *lpTmp & 0x00FF; /* takes one byte only */

            /* For non-TT font, we cannot depend on GetCharacterPlacement() */
            if (lpttfi->dwProperties & TTFI_IS_REAL_TT)
            {
                // This function works fine for non-dbcs fonts
                wPrimaryIndex = GetOIDGlyphIndexDirect(lppd, lpFontDataRecord, oid,
                        (LPLOGFONT)&(logfont), bEUDC);
            }
            else
            {
                wPrimaryIndex = oid;  /* a fake GID - in CC mode, GID is used for
                                      tracking and Glyphname purpose only */
            }

            /* LoWORD is the GID and HiWord is ToEngine */
            dw2HighBytes = dw2HighBytes << 16;
            lpDLGlyph[j] = wPrimaryIndex | dw2HighBytes;

            if (lpCharIndex)
            {
                if (CC_CID == lpFontDataRecord->fontDLType)
                    lpCharIndex[j] = oid; // pass the cid to UFL
                else
                {
                    /* Fix bug 294001 when downloading as OCF. The char code in the
                     *  second Single byte range should be the charcode-Starting code
                     *  wToEngine is set and so we can change ch now.
                     */
                    WORD ch;
                    ch = (WORD) (*lpTmp & 0x00FF); //the lower byte
                    if ((lppd->fDBCS & DBCS_FONT) &&
                        (lpFontDataRecord->fontDLType == CC_1 ||
                         lpFontDataRecord->fontDLType == CC_3) &&
                        (HighByte==0))
                    {
	                    LPDBCSENCODE   lpEncoding;
	                    int i;
	                    lpEncoding = GetEncoding((int)FontInfo->dfCharSet, lppd->lpPSExtDevmode->dm2.bEUDCAble);
	                    // Search Single Byte fonts:
	                    for (i=0; i<MAX_1STBRANGES; i++)
                        {
                            if (lpEncoding->Single[i].min==0 &&
                                lpEncoding->Single[i].max==0)  break;
	                        if (ch<lpEncoding->Single[i].min ||
		                        ch>lpEncoding->Single[i].max ) continue;
	                        // ch is indeed In this range:
                            ch = ch - lpEncoding->Single[i].min;
                            break;
                        }
                    }
                    lpCharIndex[j] = ch;
                }
            }
            j++;

        } //for
     }//convert CC to GI

    /* TODO -- get Unicode str from GlyphIDs
    lpUnicode= lppd->GlobalBuffer.UFLBuffers.lpUnicode;
    GetUnicodeFromGidStr()...
    */

    /* Before return, set the pointers to these arrays - no one other than
     * this function needs to know we use the GlobalBuffer stuff */
    *lplpGid = lpDLGlyph;
    *lplpCharIndex = lpCharIndex;
    *lplpUnicode = lpUnicode;

    return;
}


void FAR PASCAL ResetSubFont(LPPDEVICE lpOld, LPPDEVICE lpNew )
{
LPSUBFONT43      pSubFont;
LPFONTDATARECORD currentptr = lpOld->lpFontDataList->FontDataList;
   int dex = 0;

   while ( dex < lpOld->lpFontDataList->FontDataNextRecord )
   {
       if (currentptr->isMypSubFont)
       {
           pSubFont = currentptr->pSubFont;
           while(pSubFont)
           {
               pSubFont->lppd = lpNew;
               pSubFont = pSubFont->pNext;
           }

       }
       currentptr ++ ;
       dex++;
    }

}


void FAR PASCAL UpdateUFLObj(LPPDEVICE lpOld, LPPDEVICE lpNew )
{

   OUTSTREAM    *out;
   out = lpOld->pout;
   out->pdev = lpNew;

}

void GetEncodingArray(LPPDEVICE pdev,  LPSUBFONT43 pSubFont, UFLRequest *pRequest)
{
    LPPSFONTINFO FontInfo = (LPPSFONTINFO)pSubFont->FontInfo;

    if ((EncodeNameList == NULL) || !pdev->pwCommonEncode ||
        !(pSubFont->bFullFont) || (FontInfo->dfType & PF_GLYPH_INDEX))
    {
        pRequest->pEncodeNameList = NULL;
        pRequest->pwCommonEncode = NULL;
        pRequest->pwExtendEncode = NULL;
        return;
    }

    pRequest->pEncodeNameList = (LPBYTE)EncodeNameList;
    pRequest->pwCommonEncode = pdev->pwCommonEncode;
    switch (FontInfo->dfCharSet)
    {
        case EASTEUROPE_CHARSET:
            //CodePage = 1250;
            pRequest->pwExtendEncode = pdev->pwCommonEncode + 128;
            break;
        case RUSSIAN_CHARSET:
            //CodePage = 1251;
            pRequest->pwExtendEncode = pdev->pwCommonEncode + 256;
            break;
        case ANSI_CHARSET:
            //CodePage = 1252;
            pRequest->pwExtendEncode = pdev->pwCommonEncode + 384;
            break;
        case GREEK_CHARSET:
            //CodePage = 1253;
            pRequest->pwExtendEncode = pdev->pwCommonEncode + 512;
            break;
        case TURKISH_CHARSET:
            //CodePage = 1254;
            pRequest->pwExtendEncode = pdev->pwCommonEncode + 640;
            break;
        case HEBREW_CHARSET:
            //CodePage = 1255;
            pRequest->pwExtendEncode = pdev->pwCommonEncode + 768;
            break;
        case ARABIC_CHARSET:
            //CodePage = 1256;
            pRequest->pwExtendEncode = pdev->pwCommonEncode + 896;
            break;
        case BALTIC_CHARSET:
            //CodePage = 1257;
            pRequest->pwExtendEncode = pdev->pwCommonEncode + 1024;
            break;
        default:
            pRequest->pEncodeNameList = NULL;
            pRequest->pwCommonEncode = NULL;
            pRequest->pwExtendEncode = NULL;
            break;
    }
}

