/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PRNTRMGR.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for the PostScript        */
/*              Printer Manager                                              */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_PORTSEG)


#define  MAX_SPOOL_BLK 0x7FFF


/***********************************************************************
*                           HandleError
*
*  function : This function is called when a spooler error is detected. If
*             a user abort or application abort has occurred, the current job
*             is deleted and subsequent PortWrite's for the current job are
*             simply ignored. Note that this is not considered a fatal error.
*             All other errors are regarded as fatal - we longjmp() back after
*             recording them.
*
*  arguments: sError - error code
*             hJob -- Handle to job
*
*  returns  : None
*
*************************************************************************/
VOID NEAR PASCAL HandleError(short sError, HANDLE hJob)
{
   if ((sError==SP_APPABORT) || (sError==SP_USERABORT))
   {
       if (hJob) //Delete the job.
       {
          DeleteJob(hJob, 0) ;
          hJob = 0 ;
       }
   }
}





/***********************************************************************
*                       OpenPrntrMgr
*
*  function : This function performs the necessary calls to establish
*             commumnication with the MicroSoft Spooler. The first call
*             ( to OpenJob() ) get a handle to the print job. All future
*             references to this job are through the job handle.
*             The second call instructs the Spooler to start a logical page.
*
*  prototype: short FAR PASCAL OpenPrntrMgr(lpPort,lpzTitle,lphJob)
*
*  arguments: LPSTR lpPort   - A structure containing the port name & job handle
*             LPSTR lpzTitle - Job title
*             HANDLE FAR *lphJob - Handle to job
*             HDC FAR *lphDC -- Handle to Display Context
*
*  returns  : None
*************************************************************************/

short FAR  PASCAL OpenPrntrMgr(LPSTR lpzPort,LPSTR lpzTitle, HANDLE FAR *lphJob,
                               HDC FAR *lphDC)
{
  short sError = 1;
  short retval;

  retval = RC_ok;
  *lphDC    = GetDC((HWND)0);
  *lphJob   = OpenJob(lpzPort,lpzTitle,*lphDC) ;  // Open the print job.
  sError = *lphJob;                            // We need to convert to

                                               // signed to check for errors.
  

  if (sError <= 0)
  {
     HandleError(sError, *lphJob) ;
     if ((sError==SP_APPABORT) || (sError==SP_USERABORT))
     {
        return(RC_userabort);
     }
  }
  else
  {
     sError = StartSpoolPage(*lphJob) ;        // Begin a logical page
     if (sError < 0)HandleError(sError, *lphJob);
  }

  if (sError < 0)
    retval = RC_fail;

   return(retval);
}

/***********************************************************************
*                       WritePrntrMgr
*
*  function : This function accepts a pointer to a buffer and the length
*             of the buffer and sends the data to the spooler.
*
*  prototype: short FAR PASCAL WritePrntrMgr(lpData,sNumBytes,hJob)
*
*  arguments: LPSTR lpData   - A buffer containing the data to send to the spooler
*             WORD  NumBytes - The number of bytes to write to the spooler
*             HANDLE hJob - Job Handle
*
*  returns  : None
*************************************************************************/

short FAR PASCAL WritePrntrMgr(LPSTR lpData,WORD NumBytes, HANDLE hJob)
{
  short sError = 1 ;
  short retval;

  retval = RC_ok;
  if(hJob>0)
  {
     while ((NumBytes > MAX_SPOOL_BLK) && (sError > 0))
     {
        sError    =WriteSpool((HANDLE)hJob,(LPSTR)lpData,MAX_SPOOL_BLK);
        NumBytes -= MAX_SPOOL_BLK ;
        lpData   += MAX_SPOOL_BLK ;
     }

     if (sError > 0)
        sError=WriteSpool((HANDLE)hJob,(LPSTR)lpData,NumBytes);

     if (sError <= 0)
        HandleError(sError, hJob) ;
  }
  if (sError <= 0)
    retval = RC_fail;

  return(retval);
}



/***********************************************************************
*                       ClosePrntrMgr
*
*  function : This function closes the job. An EndSpoolPage() is issued
*             followed by a CloseJob().
*
*  prototype: short FAR PASCAL ClosePrntrMgr(VOID)
*
*  arguments: None
*
*  returns  : None
*************************************************************************/
short FAR PASCAL ClosePrntrMgr(HANDLE hJob, HDC hDC)
{
  short sError;
  short retval;

  retval = RC_fail;
  if(hJob>0)
  {
     sError = EndSpoolPage(hJob);           // End the logical page

     if (sError >= 0)
        sError = CloseJob(hJob);            // Close the job

     if (sError >= 0)
        hJob = 0 ;
     else
        HandleError(sError, hJob);

     if ( ReleaseDC((HWND)0, hDC) && (sError >= 0) )
        retval = RC_ok;                      // release display context got
  }                                          // via GetDC(), in OpenPrntrMgr()
  return(retval);
}


/***********************************************************************
*                           GetResource
*
*  function : This gets a resource and returns the string and length
*             to the caller for an outside the server loop print job.
*
*  prototype: int FAR PASCAL GetResource(ProcID,Res,wLen,lphMem)
*
*  arguments: LONG    ProcID -- ID of the resource
*             LPLPSTR Res    -- Pointer to the resource string
*             LPWORD  wLen   -- Length of the resource string
*             HANDLE FAR *lphMem -- Handle to resource memory
*
*  returns  : RC_ok   if successful
*             RC_fail if unsuccessful
*
*************************************************************************/

int FAR PASCAL GetResource(LONG ProcID,LPLPSTR Res,LPWORD wLen, HANDLE FAR *lphMem)
{
  HANDLE        hRes;
  DWORD          Len;
  LPSTR         lpRes;
  int           status = RC_ok;

  hRes=FindResource(ghDriverMod,(LPSTR)ProcID,(LPSTR)((LONG)PS_proc));
  if(hRes != NULL)
  {
     *lphMem=LoadResource(ghDriverMod,hRes);
     if(*lphMem != NULL)
     {
        lpRes=(LP)LockResource(*lphMem);
        if(lpRes != NULL)
        {
            Len=SizeofResource(ghDriverMod,hRes);
            if(!lpRes[Len-1]) Len=lstrlen((LPSTR)lpRes);
           *wLen = (WORD)Len;
           *Res  = lpRes;
        }
        else
           status = RC_fail;
     }
     else
        status = RC_fail;
  }
  else
     status = RC_fail;

  return(status);
}

/***********************************************************************
*                           RemoveResource
*
*  function : This frees a resource which has been gotten by
*             GetResource().
*
*  prototype: void FAR PASCAL RemoveResource(HANDLE hMem)
*
*  arguments:
*    HANDLE hMem -- Handle to resource memory
*
*  returns  : None
*
*************************************************************************/
#undef GlobalUnlock
void FAR PASCAL RemoveResource(HANDLE hMem)
{
   UnlockResource(hMem);  // This is actually a GlobalUnlock()
}
#define GlobalUnlock(h)   
/***********************************************************************
*                           WritePrntrMgrLine
*  function:
*       this function takes a resource id and emits the line, followed by
*       a CRLF.
*  prototype:
*       short FAR PASCAL WritePrntrMgrLine(short resid,hJob);
*  parameter:
*       short resid -- resource id
*       HANDLE hJob -- Job handle
*  returns:
*       short -- RC_ok or RC_fail
***********************************************************************/

short FAR PASCAL WritePrntrMgrLine(short resid,HANDLE hJob)
    {
    short retval;
    WORD          wLen;
    char tempstr[256];

    retval = RC_fail;
    wLen = LoadString(ghDriverMod,resid,tempstr,sizeof(tempstr));
    if (wLen > 0)
        retval = WritePrntrMgr(tempstr,wLen,hJob);
    if (retval == RC_ok)
        {
        wLen = LoadString(ghDriverMod,PSFRAG_crlf,tempstr,sizeof(tempstr));
        if (wLen > 0)
            retval = WritePrntrMgr(tempstr,wLen,hJob);
        }

    return (retval);
    }




/***********************************************************************
*                           WritePrntrMgrDSC
*  function:
*       this function takes a DSC comment id and emits that DSC comment,
*       followed by an info string if present, followed by a CRLF.
*  prototype:
*       short FAR PASCAL WritePrntrMgrDSC(short sDSCid, LPSTR pInfoString,
*                                         HANDLE hJob);
*  parameter:
*       short sDSCid -- resource id of DSC comment
*       LPSTR pInfoString -- pointer to optional info string; may be NULL
*       HANDLE hJob -- Job Handle
*  returns:
*       short -- RC_ok or RC_fail
***********************************************************************/

short FAR PASCAL WritePrntrMgrDSC(short sDSCid, LPSTR pInfoString, HANDLE hJob)
{
    short retval;
    char zTemp[64];
    LPSTR lpzTemp=(LPSTR)zTemp;
    short wLen = 0;


    retval = RC_fail;

    //first send the basic comment
    //
    if(sDSCid<=DSC_begin || sDSCid>=DSC_end) return(RC_fail);
    if(sDSCid>DSC_null)
    {
        wLen = LoadString(ghDriverMod,sDSCid,lpzTemp,sizeof(zTemp));
        if (wLen > 0)
            retval = WritePrntrMgr(lpzTemp, wLen,hJob);
    }


    // Send the information string if there is one.
    if( (retval == RC_ok) && (pInfoString != NULL) )
    {
        retval = WritePrntrMgr(pInfoString, lstrlen( pInfoString ),hJob);
    }
    if (retval == RC_ok)
        {
        wLen = LoadString(ghDriverMod,PSFRAG_crlf,lpzTemp,sizeof(zTemp));
        if (wLen > 0)
            retval = WritePrntrMgr(lpzTemp,wLen,hJob);
        }

    return (retval);
}
