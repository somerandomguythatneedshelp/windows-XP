//------------------------------------------------------------------------
//  Adobe(R) PostScript(R) Language Printer Driver for Microsoft Windows (TM)
// 
//  Passion procsets: Abbreviations, for utils0.ps
//  $Header:   L:/PVCS/PS40/PSCRIPT/RESOURCE/PSABBR.H_V   1.8   27 Mar 1995 11:23:50   olegsher  $
// 
//  Copyright (C) 1991 Adobe Systems Incorporated.  All rights reserved.
// 
//  PostScript is a trademark of Adobe Systems, Inc.
// 
//  ADOBE SYSTEMS CONFIDENTIAL
//  NOTICE:  All information contained herein or attendant hereto is, and
//  remains, the property of Adobe Systems, Inc.  Many of the intellectual
//  and technical concepts contained herein are proprietary to Adobe Systems,
//  Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
//  are protected as trade secrets.  Any dissemination of this information or
//  reproduction of this material are strictly forbidden unless prior written
//  permission is obtained from Adobe Systems, Inc.
//------------------------------------------------------------------------
 
#define PSVER 4.2 0  // define procset version

//Fix bug 120000. jjia. 10/20/95
// All ProcSet dict name are defined here
#define P_W_D          AdobePS_Win_Driver_V4.20
#define P_W_D_OC       AdobePS_Win_Driver_OC
#define P_W_D_L2       AdobePS_Win_Driver_L2
#define P_W_D_Incr     AdobePS_Win_Driver_Incr
#define P_W_D_Incr_L2  AdobePS_Win_Driver_Incr_L2
#define P_W_D_Min      AdobePS_Win_Driver_Min
#define P_W_CalRGB     AdobePS_Win_CalRGB
#define P_W_PT         AdobePS_Win_PassThrough
#define P_W_Compat     AdobePS_Win_Compat

//Add "AdobePS" before each DSC name. 
#define DSC_NAME(a)    AdobePS##a

#define Convert2String(a)  #a
#define AppendSlash(a)     /##a
//End 10/20/95

