/* CM_VerSion blend.c atm05 1.2 10076.eco sum= 02790 */
/* CM_VerSion blend.c atm04 1.11 07518.eco sum= 18797 */
/*
  blend.c - convert normalized design vector to weight vector, NO INTERIOR POINTS version

Copyright (c) 1990,1991 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks
of Adobe Systems Incorporated.

Original version: Paul Haahr: November 8, 1990
Edit History:
Paul Haahr: Fri Oct 23 12:40:27 1992
Craig Rublee: Tue Aug  6 18:59:45 1991
Tom Malloy: Feb 5, 1992
End Edit History.
*/

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif

#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES
#include FP
#include PROTOS
#include BLEND
#include "fxl.h"


#define	FixedIsInfinity(x)	((x) == FixedPosInf || (x) == FixedNegInf)


/*
 * FXL_FONTFIT -- define this if you want to use the Fxl (our own cheap floating
 *	point routines) version of FontFit2().  If your platform is guaranteed
 *	to have hardware floating point, turn this off.
 */

#ifndef	FXL_FONTFIT
#define	FXL_FONTFIT	1
#endif

/*
 * DEBUG_FONTFIT -- when this flag is turned on, every call to FontFit2 is
 *	duplicated, with one call to the double version and one to the Fxl
 *	version.  an error is raised if the results diverge too much.
 */

#ifndef	DEBUG_FONTFIT
#define	DEBUG_FONTFIT	BCMAIN
#endif
#define THRESHOLD 0x10			/* 28 bits of accuaracy? */


/* offsetof should be in <stddef.h>, but not all machines have one */
#ifndef	offsetof
#define offsetof(type,identifier) ((long)&((type *)0)->identifier)
#endif

#define	DoubleToFixed(n)	((Fixed) ((n) * 65536.0))
#define	FixedToDouble(n)	(((double) (n)) / 65536.0)


#if DEBUG_FONTFIT
#define	FD(n)		FixedToDouble(n)
#define	CD(p)		FD((p).x), FD((p).y)
boolean debug_fontfit2 = false;
char *debug_sidename[MAXAXES][2];
#endif


/******************* D A T A   S T R U C T U R E S *******************/



/*
 * DesignSpace -- this describes the problem domain, for a particular font
 *
 *	corner, inner, and inner_dv point to the middle of the DesignSpace struct
 *	if there are no inner points, inner and inner_dv are overwritten by *corner
 *
 * DO NOT change the layout of this structure haphazardly!!!!
 * TODO: make DesignSpace relocatable (adjust pointers explicitly)
 */

struct DesignSpace {
  Card8 ndimen;		/* number of dimensions of the design space */
  Card8 nmasters;	/* the number of base designs (elements in the weight vector) */
  Card8 corner[1];	/* indices for corner points */
};

#define	BADMASTER 255	/* not yet filled in field of inner[] or corner[] */


/*
 * MakeDesignSpace
 *	create the initial global state, with no coordinates filled in
 */

DesignSpace *MakeDesignSpace ARGDEF4(int, ndimen, int, nmasters, DS_allocfunc, alloc, void *, tag) {
  int i;
  DesignSpace *ds;

  if (ndimen <= 0 || MAXAXES < ndimen || MAXWEIGHT < nmasters)
    return NULL;
  if (nmasters != 1 << ndimen)
    return NULL;

  ds = (DesignSpace*)((*alloc) ((IntX)offsetof(DesignSpace, corner[nmasters]), tag));


  if (ds == NULL)
    return NULL;

  ds->ndimen = ndimen;
  ds->nmasters = nmasters;
  for (i = 0; i < nmasters; i++)
    ds->corner[i] = BADMASTER;

  return ds;
}


/*
 * CornerMask
 *	return the corner bit mask for a design vector, or -1 for
 *	an interior point.  for each coordinate in the design vector,
 *	the mask is on if the coordinate is 1, and off if it is 0
 */

PRIVATE int CornerMask ARGDEF2(DesignSpace *, ds, Fixed *, dv) {
  int i, mask, bit;
  for (i = 0, mask = 0, bit = 1; i < ds->ndimen; bit <<= 1, i++) {
    Fixed x = dv[i];
    if (x == FixedOne)
      mask |= bit;
    else if (x != 0)
      return -1;
  }
  return mask;
}


/*
 * SetMasterDesignPosition
 *	public entry point for identifying the design vectors for
 *	master in the font
 */

PUBLIC boolean SetMasterDesignPosition ARGDEF3(DesignSpace *, ds, unsigned, n, Fixed *, dv) {
  int i;
  if (n >= ds->nmasters)
    return false;
  i = CornerMask(ds, dv);
  if (i < 0)
    return false;
  if (ds->corner[i] != BADMASTER)
    return false;
  ds->corner[i] = n;
  return true;
}


/*
 * CheckDesignSpace
 *	verify that the design space has been filled in
 */

PRIVATE boolean CheckDesignSpace ARGDEF1(DesignSpace *, ds) {
  int i;
  for (i = 0; i < ds->nmasters; i++)
    if (ds->corner[i] >= ds->nmasters)
      return false;
  return true;
}


/******************* G E T   W E I G H T   V E C T O R *******************/


/*
 * CornersOnly
 *	compute a weight vector using only the corners of the design space.
 *	this is used if either of two conditions hold:  the design vector is
 *	outside the space or the design space has only corners.
 *
 *	the result of this routine is a vector of the products of simple
 *	linear interpolations (or extrapolations)
 */

PRIVATE boolean CornersOnly ARGDEF3(DesignSpace *, ds, Fixed *, wv, Fixed *, dv) {
  int i;
  for (i = 0; i < ds->nmasters; i++) {
    int j, bit;
    Fixed x = FixedOne;
    for (j = 0, bit = 1; j < ds->ndimen; j++, bit <<= 1)
      x = fixmul(x, (i & bit) ? dv[j] : FixedOne - dv[j]);
    wv[ds->corner[i]] = x;
  }
  return true;
}


/*
 * GetWV
 *	does the design vector to weight vector translation for
 *	the simple cases (when the design is one of the masters)
 *	and dispatches to the appropriate routine for harder cases.
 *
 *	THIS VERSION IGNORES THE HARD CASES
 */

PRIVATE boolean GetWV ARGDEF3(DesignSpace *, ds, Fixed *, wv, Fixed *, dv) {
  int i, n;
  n = CornerMask(ds, dv);
  if (n >= 0) {
    for (i = 0; i < ds->nmasters; i++)
      wv[i] = 0;
    wv[ds->corner[n]] = FixedOne;
    return true;
  }
  return CornersOnly(ds, wv, dv);
}


/*
 * GetWeightVector
 *	this is just a protective wrapper around GetWV(); it has responsibility for
 *	passing GetWV() a clean design space, and freeing any memory that may have
 *	been allocated in the computation
 */

PUBLIC boolean GetWeightVector ARGDEF3(DesignSpace *, ds, Fixed *, wv, Fixed *, dv) {
  if (!CheckDesignSpace(ds))
    return false;
  return GetWV(ds, wv, dv);
}



/******************* F O N T   F I T *******************/


/*
 * utility functions and macros
 */

#define	INRANGE(n, lo, hi)		((lo) <= (n) && (n) <= (hi))
#define	INRECT(p, xlo, xhi, ylo, yhi)	(INRANGE((p).x, xlo, xhi) && INRANGE((p).y, ylo, yhi))
#define	DIST(p, q)			(ABS((p).x - (q).x) + ABS((p).y - (q).y))

PRIVATE Fixed Blend ARGDEF3(Fixed, x, Fixed, y, Fixed *, m) {
  return fixmul(m[0], fixmul(FixedOne - x, FixedOne - y))
       + fixmul(m[1], fixmul(x, FixedOne - y))
       + fixmul(m[2], fixmul(FixedOne - x, y))
       + fixmul(m[3], fixmul(x, y));
}

PRIVATE Fixed Try ARGDEF3(FCd, p, Fixed, t, Fixed *, m) {
  Fixed delta = t - Blend(p.x, p.y, m);
  return ABS(delta);
}


/*
 * FontFit1
 *	1 dimensional solutions with no internal points, normalized to a unit design space.
 */

PRIVATE boolean FontFit1 ARGDEF5(
  Fixed *, result,
  Fixed, target,
  Fixed *, metric,
  Fixed, lo,
  Fixed, hi
) {
  Fixed m0 = metric[0], m1 = metric[1], p;

  /*
   * if the metrics are the same, either they equal the target, so we succeed,
   * or they will never, so we fail.  in case of success, we just don't alter
   * the design vector.
   */

  if (m0 == m1)
    return (target == m0);

  p = fixdiv(target - m0, m1 - m0);
  if (p == FixedPosInf || p == FixedNegInf)
    return false;

  if (p < lo)
    p = lo;
  else if (p > hi)
    p = hi;

  *result = p;
  return true;
}


/*
 * FindTargetLimits2
 *	find the intersections of the curve (t, m) with the clamping
 *	region.  return t if the curves touch the clamping rectangle,
 *	or the closest value to t among the corners if not.
 */

PRIVATE Fixed FindTargetLimits2 ARGDEF5(
  FontFitDomain *,	dom,
  Int16 *,		nextrema,
  FCd *,		extrema,
  Fixed,		t,
  Fixed *,		m
) {
  Fixed xlo = dom->clamp[0].lo, xhi = dom->clamp[0].hi, ylo = dom->clamp[1].lo, yhi = dom->clamp[1].hi;

  if (FixedIsInfinity(xlo) || FixedIsInfinity(xhi) || FixedIsInfinity(ylo) || FixedIsInfinity(yhi)) {
    *nextrema = 0;
    return t;
  }

  /* horizontal */
  if (m[0] == m[1] && m[2] == m[3]) {
    Fixed y;
    y = m[2] - m[0];
    if (y == 0) {
      *nextrema = 0;
      return m[0];
    }
    y = fixdiv(t - m[0], y);
    *nextrema = 2;
    if (!INRANGE(y, ylo, yhi))
      if (y < ylo) {
        y = ylo;
	t = m[0];
      } else {
        /* assert y > yhi */
        y = yhi;
	t = m[2];
      }
    extrema[0].x = xlo;
    extrema[0].y = y;
    extrema[1].x = xhi;
    extrema[1].y = y;
    return t;
  }

  /* vertical */
  else if (m[0] == m[2] && m[1] == m[3]) {
    Fixed x;
    x = m[1] - m[0];
    if (x == 0) {
      *nextrema = 0;
      return m[0];
    }
    x = fixdiv(t - m[0], x);
    *nextrema = 2;
    if (!INRANGE(x, xlo, xhi))
      if (x < xlo) {
        x = xlo;
	t = m[0];
      } else {
        /* assert x > xhi */
        x = xhi;
	t = m[1];
      }
    extrema[0].x = x;
    extrema[0].y = ylo;
    extrema[1].x = x;
    extrema[1].y = yhi;
    return t;
  }

  else {
    IntX found = 0;

#define	TESTPOINT(X, Y, WHICH, LO, HI) \
  if (INRANGE((WHICH), (LO), (HI))) { \
    extrema[found].x = (X); \
    extrema[found].y = (Y); \
    found++; \
  }
#define	TESTPOINTX(X, Y)	TESTPOINT(X, Y, x, xlo, xhi)
#define	TESTPOINTY(X, Y)	TESTPOINT(X, Y, y, ylo, yhi)

    /* diagonal */
    if (m[1] - m[0] == m[3] - m[2]) {
      Fixed a = m[1] - m[0], b = m[2] - m[0];
      Fixed slope, inter, x, y;

      /* vertical intercepts */

      slope = fixdiv(-a, b);
      inter = fixdiv(t - m[0], b);
      y = fixmul(xlo, slope) + inter;
      TESTPOINTY(xlo, y);
      y = fixmul(xhi, slope) + inter;
      TESTPOINTY(xhi, y);

      /* horizontal intercepts */

      slope = fixdiv(-b, a);
      inter = fixdiv(t - m[0], a);
      x = fixmul(ylo, slope) + inter;
      TESTPOINTX(x, ylo);
      x = fixmul(yhi, slope) + inter;
      TESTPOINTX(x, yhi);
    }

    /* arbitrary curve */
    else {
      Fixed msum = m[0] - m[1] - m[2] + m[3];
      Fixed d;

      d = m[2] - m[0] + fixmul(xlo, msum);
      if (d != 0) {
	Fixed y = fixdiv(t - m[0] - fixmul(xlo, m[1] - m[0]), d);
	TESTPOINTY(xlo, y);
      }

      d = m[2] - m[0] + fixmul(xhi, msum);
      if (d != 0) {
	Fixed y = fixdiv(t - m[0] - fixmul(xhi, m[1] - m[0]), d);
	TESTPOINTY(xhi, y);
      }

      d = m[1] - m[0] + fixmul(ylo, msum);
      if (d != 0) {
	Fixed x = fixdiv(t - m[0] - fixmul(ylo, m[2] - m[0]), d);
	TESTPOINTX(x, ylo);
      }

      d = m[1] - m[0] + fixmul(yhi, msum);
      if (d != 0) {
	Fixed x = fixdiv(t - m[0] - fixmul(yhi, m[2] - m[0]), d);
	TESTPOINTX(x, yhi);
      }
    }

#undef	TESTPOINT
#undef	TESTPOINTX
#undef	TESTPOINTY

    if (found > 0) {
      *nextrema = found;
      return t;
    } else {
      Fixed lo = FixedPosInf, hi = FixedNegInf;

#define	TESTCORNER(X, Y) { \
    Fixed u = Blend((X), (Y), m); \
    if (t < u) { \
      if (u <= lo) { \
        if (u < lo) { \
	  found = 0; \
	  lo = u; \
	} \
	extrema[found].x = (X); \
	extrema[found].y = (Y); \
	found++; \
      } \
    } else { \
      if (u >= hi) { \
        if (u > hi) { \
	  found = 0; \
	  hi = u; \
	} \
	extrema[found].x = (X); \
	extrema[found].y = (Y); \
	found++; \
      } \
    } \
  }

      TESTCORNER(xlo, ylo);
      TESTCORNER(xhi, ylo);
      TESTCORNER(xlo, yhi);
      TESTCORNER(xhi, yhi);

#undef TESTCORNER

      *nextrema = found;
      return (lo != FixedPosInf) ? lo : hi;
    }
  }
}

PRIVATE Fixed FindTargetLimits ARGDEF4(
  FontFitDomain *,	dom,		/* problem domain */
  Int16,		axis,		/* for which we are finding limits */
  Fixed,		target,		/* the metric to match */
  Fixed *,		basis		/* the collapsed base metric values */
) {
  /* assert axis < dom->nvary */
  if (dom->nvary == 2)
    return FindTargetLimits2(dom, &dom->nextrema[axis], dom->extrema[axis], target, basis);
  dom->nextrema[axis] = 0;
  return target;
}


/*
 * DegenerateFontFit2
 *	solve the FontFit2 problem for the case where the two hyperbolas are identical
 */

PRIVATE IntX DegenerateFontFit2 ARGDEF4(
  FCd *,	orig,
  FCd *,	result,
  Fixed,	target,
  Fixed *,	base
) {
  Fixed x = orig->x, m[2];
  m[0] = fixmul(FixedOne - x, base[0]) + fixmul(x, base[1]);
  m[1] = fixmul(FixedOne - x, base[2]) + fixmul(x, base[3]);
  if (FontFit1(&result->y, target, m, FixedNegInf, FixedPosInf)) {
    result->x = x;
    return 1;
  }
  return 0;
}


/*
 * QuadraticFontFit2
 *	2 dimensional solutions with no internal points, normalized to a unit design space.
 *	two versions are provided, one using Fxls (simulated floating point) and one using
 *	doubles; if DEBUG_FONTFIT is enabled, every FontFit2 call actually does both and
 *	ensures that their results are similar.
 *
 *	FontFit2 solves for the intersection of the hyperbolas defined by
 *		target-metric == weight-vector * base-metrics
 *	for each (target, base) pair, where the multiplication is a dot product
 */

#if !FXL_FONTFIT || DEBUG_FONTFIT
PRIVATE IntX DoubleFontFit2 ARGDEF6(
  FCd *, orig,		/* original design vector */
  FCd *, result,	/* solution */
  Fixed, ft0,		/* target[0] */
  Fixed, ft1,		/* target[1] */
  Fixed *, fm0,		/* metrics[0] */
  Fixed *, fm1		/* metrics[1] */	
) {
  IntX i;
  double t0, t1, m0[4], m1[4],
	 x0, y0, x1, y1, a, b, c, disc, mt1, mt2, mt3, mt4, nt1, nt2, nt3, nt4;

  t0 = FixedToDouble(ft0);
  t1 = FixedToDouble(ft1);
  for (i = 0; i < 4; i++) {
    m0[i] = FixedToDouble(fm0[i]);
    m1[i] = FixedToDouble(fm1[i]);
  }

  mt1 = t0    - m0[0];		nt1 = t1    - m1[0];
  mt2 = m0[0] - m0[2];		nt2 = m1[0] - m1[2];
  mt3 = m0[1] - m0[0];		nt3 = m1[1] - m1[0];
  mt4 = m0[3] - m0[1] + mt2;	nt4 = m1[3] - m1[1] + nt2;

  a = mt2 * nt4 - mt4 * nt2;
  b = mt1 * nt4 + mt2 * nt3 - mt3 * nt2 - mt4 * nt1;
  c = mt1 * nt3 - mt3 * nt1;

  if (a == 0.0) {
    if (b == 0.0)
      return c == 0.0 ? DegenerateFontFit2(orig, result, ft0, fm0) : 0;
    y0 = -c / b;
    goto one_root;
  }

  b = b / a;
  c = c / a;
  disc = b * b - 4.0 * c;
  if (disc < 0.0)
    return 0;
  if (disc == 0.0) {
    y0 = -b * 0.5;
    goto one_root;
  }

  disc = os_sqrt(disc);
  y0 = (-b - disc) * 0.5;	x0 = mt3 + y0 * mt4;
  y1 = (-b + disc) * 0.5;	x1 = mt3 + y1 * mt4;
  if (x0 == 0.0) {
    y0 = y1;
    goto one_root;
  }
  if (x1 == 0.0)
    goto one_root;
  x0 = (mt1 + y0 * mt2) / x0;
  x1 = (mt1 + y1 * mt2) / x1;

  result[0].x = DoubleToFixed(x0);
  result[0].y = DoubleToFixed(y0);
  result[1].x = DoubleToFixed(x1);
  result[1].y = DoubleToFixed(y1);
  return 2;

one_root:
  x0 = mt3 + y0 * mt4;
  if (x0 == 0.0)
    return 0;
  result->x = DoubleToFixed((mt1 + y0 * mt2) / x0);
  result->y = DoubleToFixed(y0);
  return 1;
}
#endif /* !FXL_FONTFIT || DEBUG_FONTFIT */

#if FXL_FONTFIT || DEBUG_FONTFIT
PRIVATE boolean FxlFontFit2 ARGDEF6(
  FCd *, orig,		/* original design vector */
  FCd *, result,	/* solution */
  Fixed, ft0,		/* target[0] */
  Fixed, ft1,		/* target[1] */
  Fixed *, fm0,		/* metrics[0] */
  Fixed *, fm1		/* metrics[1] */	
) {
  Fxl x0, y0, x1, y1, a, b, c, disc, mt1, mt2, mt3, mt4, nt1, nt2, nt3, nt4;

  mt1 = FixedToFxl(ft0 - fm0[0]);
  nt1 = FixedToFxl(ft1 - fm1[0]);
  mt2 = FixedToFxl(fm0[0] - fm0[2]);
  nt2 = FixedToFxl(fm1[0] - fm1[2]);
  mt3 = FixedToFxl(fm0[1] - fm0[0]);
  nt3 = FixedToFxl(fm1[1] - fm1[0]);
  mt4 = fxladd(FixedToFxl(fm0[3] - fm0[1]), mt2);
  nt4 = fxladd(FixedToFxl(fm1[3] - fm1[1]), nt2);

  /*
   * a = mt2 * nt4 - mt4 * nt2
   * b = mt1 * nt4 + mt2 * nt3 - mt3 * nt2 - mt4, nt1
   * c = mt1 * nt3 - mt3 * nt1
   */

  a = fxlsub(fxlmul(mt2, nt4), fxlmul(mt4, nt2));
  b = fxlsub(fxladd(fxlmul(mt1, nt4), fxlmul(mt2, nt3)), fxladd(fxlmul(mt3, nt2), fxlmul(mt4, nt1)));
  c = fxlsub(fxlmul(mt1, nt3), fxlmul(mt3, nt1));

  if (FxlIsZero(a)) {
    if (FxlIsZero(b))
      return FxlIsZero(c) ? DegenerateFontFit2(orig, result, ft0, fm0) : 0;
    /* y0 = -c/b */
    y0 = fxldiv(c, b);
    y0.mantissa = -y0.mantissa;
    y0 = fxlnormalize(y0);
    goto one_root;
  }

  b = fxldiv(b, a);
  c = fxldiv(c, a);
  /* disc = b*b - 4c */
  disc = c;
  disc.exp += 2;
  disc = fxlsub(fxlmul(b, b), disc);
  if (disc.mantissa < 0)
    return 0;
  if (FxlIsZero(disc)) {
    /* y0 = -b/2; */
    y0.mantissa = -b.mantissa;
    y0.exp = b.exp - 1;
    y0 = fxlnormalize(y0);
    goto one_root;
  }
  disc = fxlsqrt(disc);

  /*
   * y0 = (-b - disc) / 2
   * y1 = (-b + disc) / 2
   * x0 = (mt1 + y0 * mt2) / (mt3 + y0 * mt4)
   * x1 = (mt1 + y1 * mt2) / (mt3 + y1 * mt4)
   */

  y0.mantissa = -b.mantissa;
  y0.exp = b.exp;
  y0 = fxlsub(y0, disc);
  y0.exp--;

  y1.mantissa = -b.mantissa;
  y1.exp = b.exp;
  y1 = fxladd(y1, disc);
  y1.exp--;

  x0 = fxladd(mt3, fxlmul(y0, mt4));
  if (FxlIsZero(x0)) {
    y0 = y1;
    goto one_root;
  }
  x0 = fxldiv(fxladd(mt1, fxlmul(y0, mt2)), x0);

  x1 = fxladd(mt3, fxlmul(y1, mt4));
  if (FxlIsZero(x1))
    goto one_root;
  x1 = fxldiv(fxladd(mt1, fxlmul(y1, mt2)), x1);

  result[0].x = FxlToFixed(x0);
  result[0].y = FxlToFixed(y0);
  result[1].x = FxlToFixed(x1);
  result[1].y = FxlToFixed(y1);
  return 2;

one_root:
  /* x0 = (mt1 + y0 * mt2) / (mt3 + y0 * mt4) */
  x0 = fxladd(mt3, fxlmul(y0, mt4));
  if (FxlIsZero(x0))
    return 0;
  result->x = FxlToFixed(fxldiv(fxladd(mt1, fxlmul(y0, mt2)), x0));
  result->y = FxlToFixed(y0);
  return 1;
}
#endif /* FXL_FONTFIT || DEBUG_FONTFIT */

#if DEBUG_FONTFIT
PRIVATE IntX QuadraticFontFit2 ARGDEF6(
  FCd *, orig,		/* original design vector */
  FCd *, result,	/* solution */
  Fixed, ft0,		/* target[0] */
  Fixed, ft1,		/* target[1] */
  Fixed *, fm0,		/* metrics[0] */
  Fixed *, fm1		/* metrics[1] */
) {
  IntX nroot1, nroot2;
  FCd result2[2];

  nroot1 = FxlFontFit2(orig, result, ft0, ft1, fm0, fm1);
  nroot2 = DoubleFontFit2(orig, result2, ft0, ft1, fm0, fm1);

  if (nroot1 != nroot2) {
    fprintf(stderr, "FontFit2 nroot mismatch\n");
    exit(1);
  }

#if __STDC__
#define	CHECK(arg) \
  do { \
    Fixed d = result arg - result2 arg; \
    if (ABS(d) > ((ABS(result arg) < FixInt(100)) ? THRESHOLD : 10 * THRESHOLD)) { \
      fprintf(stderr, "FontFit2 result mismatch on result\n"); \
      exit(1); \
    } \
  } while (0)
#else
#define	CHECK(arg) \
  do { \
    Fixed d = result arg - result2 arg; \
    if (ABS(d) > ((ABS(result arg) < FixInt(100)) ? THRESHOLD : 10 * THRESHOLD)) { \
      fprintf(stderr, "FontFit2 result mismatch\n"); \
      exit(1); \
    } \
  } while (0)
#endif

  switch (nroot1) {
    case 2:
      CHECK([1].x);
      CHECK([1].y);
    case 1:
      CHECK([0].x);
      CHECK([0].y);
  }

#undef CHECK

  return nroot1;
}

#else	/* !DEBUG_FONTFIT */
#if FXL_FONTFIT
#define	QuadraticFontFit2 FxlFontFit2
#else	/* !FXL_FONTFIT */
#define	QuadraticFontFit2 DoubleFontFit2
#endif	/* !FXL_FONTFIT */
#endif	/* !DEBUG_FONTFIT */


/*
 * FastestFontFit2
 *	handles the degenerate case where both of the curves through
 *	the design space are lines.  this is truly simple---we've got
 *	two linear equations in two unknowns.
 *
 *	the equations have the form
 *		     t - m[0] - x(m[1] - m[0])
 *		y = ---------------------------
 *			    m[2] - m[0]
 *	for each of (t0, m0) and (t1, m1).
 */

PRIVATE IntX FastestFontFit2 ARGDEF5(
  FCd *, result,	/* solution */
  Fixed, t0,		/* target[0] */
  Fixed, t1,		/* target[1] */
  Fixed *, m0,		/* metrics[0] */
  Fixed *, m1		/* metrics[1] */
) {
  Fixed x, m00, m10, dt0, dm01, dm02, dt1, dm11, dm12;

  m00 = m0[0];
  m10 = m1[0];

  /* invariant base metrics */
  if (m00 == m0[3] || m10 == m1[3])
    return 0;

  dm02 = m0[2] - m00;
  dm12 = m1[2] - m10;
  if (dm02 == 0)
    if (dm12 == 0)
      return 0;		/* parallel lines */
    else
      x = fixdiv(t0 - m00, m0[1] - m00);
  else if (dm12 == 0)
    x = fixdiv(t1 - m10, m1[1] - m10);
  else {
    dt0 = fixdiv(t0 - m00, dm02);
    dt1 = fixdiv(t1 - m10, dm12);
    dm01 = fixdiv(m0[1] - m00, dm02);
    dm11 = fixdiv(m1[1] - m10, dm12);

    if (dm01 == dm11)
      return 0;			/* parallel lines -- real failure case */
    x = fixdiv(dt1 - dt0, dm11 - dm01);
  }

  if (dm02 != 0)
    result->y = fixdiv(t0 - m00 - fixmul(x, m0[1] - m00), dm02);
  else if (dm12 != 0)
    result->y = fixdiv(t1 - m10 - fixmul(x, m1[1] - m10), dm12);
  else
    return 0;			/* can't happen -- parallel line case */
  result->x = x;
  return 1;
}


/*
 * FastFontFit2
 *	handles the degenerate case where one (t0 = m0 * wv), but not both,
 *	of the curves through the design space is a line.  that is,
 *		m0[3] = m0[2] + m0[1] - m0[0]
 *	and the above relationship does not hold for m1.
 *
 *	switchtargets is true if the given relationship was true in the original
 *	data for (t1, m1) and not for (t0, m0), thus those constraints have been
 *	reversed for this call.
 */

PRIVATE IntX FastFontFit2 ARGDEF7(
  FCd *, orig,		/* original position */
  FCd *, result,	/* solution */
  Fixed, t0,		/* target[0] */
  Fixed, t1,		/* target[1] */
  Fixed *, m0,		/* metrics[0] -- defines a line */
  Fixed *, m1,		/* metrics[1] -- defines a hyperbola */
  boolean, switchtargets
) {
  /* invariant base metrics */
  if (m0[0] == m0[3])
    return 0;		/* TODO */

  /* horizontal line */
  if (m0[0] == m0[1]) {
    Fixed y, d;
    y = fixdiv(t0 - m0[0], m0[2] - m0[0]);
    d = m1[1] - m1[0] + fixmul(y, m1[0] - m1[2] - m1[1] + m1[3]);
    if (d == 0)
      return 0;
    result->x = fixdiv(t1 - m1[0] + fixmul(y, m1[0] - m1[2]), d);
    result->y = y;
    return 1;
  }

  /* vertical line */
  if (m0[0] == m0[2]) {
    Fixed x, d;
    x = fixdiv(t0 - m0[0], m0[1] - m0[0]);
    d = m1[2] - m1[0] + fixmul(x, m1[0] - m1[1] - m1[2] + m1[3]);
    if (d == 0)
      return 0;
    result->y = fixdiv(t1 - m1[0] + fixmul(x, m1[0] - m1[1]), d);
    result->x = x;
    return 1;
  }

  /*
   * we're doing a little too much work in this general case,
   * but it's safe and we still need to do the square root.
   * this should be relatively uncommon, unlike the previous
   * two cases.
   */

  return switchtargets
  	   ? QuadraticFontFit2(orig, result, t1, t0, m1, m0)
	   : QuadraticFontFit2(orig, result, t0, t1, m0, m1);
}


/*
 * FindBest
 *	return the point of a set which minimizes the difference between
 *	a target and a metric.
 */

PRIVATE boolean FindBest ARGDEF5(FCd *, result, IntX, n, FCd *, p, Fixed, t, Fixed *, m) {
  if (n == 0)
    return false;
  if (n == 1)
    *result = *p;
  else {
    Int16 i;
    Fixed best = FixedPosInf;
    for (i = 0; i < n; i++) {
      Fixed delta = Try(p[i], t, m);
      if (delta < best) {
        best = delta;
	*result = p[i];
      }
    }
  }
  return true;
}


/*
 * ClampedFontFit2
 *	this version of fontfit handles the case where there is no solution
 *	inside the design space.  due to the work done in FindTargetLimits,
 *	we are guaranteed that the curve wv * m0 == t0 intersects the design
 *	space, and the intersections (extreme points) have been identified.
 *	here we pick the intersection that minimizes (wv * m1 - t1).
 */

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameters 't0 and m0' not used */
PRIVATE boolean ClampedFontFit2 ARGDEF6(
  FontFitDomain *, dom,		/* problem domain */
  FCd *, result,		/* solution */
  Fixed, t0,			/* target[0] */
  Fixed, t1,			/* target[1] */
  Fixed *, m0,			/* metrics[0] */
  Fixed *, m1			/* metrics[1] */
) {
  return FindBest(result, dom->nextrema[0], dom->extrema[0], t1, m1);
}


/*
 * IsLeftOf
 *	is this coordinate to the left of (or on) the given line?
 */

PRIVATE boolean IsLeftOf ARGDEF6(
  Fixed, x,	Fixed, y,	/* the coordinate */
  Fixed, x0,	Fixed, y0,	/* the bottom */
  Fixed, x1,	Fixed, y1	/* the top */
) {
  return (x0 == x1)
	    ? (x <= x0)
	    : (fixmul(x - x0, y1 - y0) <= fixmul(x1 - x0, y - y0));
}


/*
 * IsInTrap
 *	is this coordinate inside the given trapezoid?
 */

PRIVATE boolean IsInTrap ARGDEF8(
  Fixed, x,	Fixed, y,			/* the coordinate */
  Fixed, xbl,	Fixed, xbr,	Fixed, yb,	/* the bottom */
  Fixed, xtl,	Fixed, xtr,	Fixed, yt	/* the top */
) {
  return yb <= y
      && y  <= yt
      && !IsLeftOf(x + 1, y, xbl, yb, xtl, yt)
      &&  IsLeftOf(x    , y, xbr, yb, xtr, yt);
}

#if 0
PRIVATE boolean IsInTrapDebug ARGDEF8(
  Fixed, x,	Fixed, y,			/* the coordinate */
  Fixed, xbl,	Fixed, xbr,	Fixed, yb,	/* the bottom */
  Fixed, xtl,	Fixed, xtr,	Fixed, yt	/* the top */
) {
  boolean result = IsInTrap(x, y, xbl, xbr, yb, xtl, xtr, yt);
  printf("IsInTrap((%g, %g), (%g ... %g, %g), (%g ... %g, %g)) = %s\n",
  		 FD(x), FD(y), FD(xbl), FD(xbr), FD(yb), FD(xtl), FD(xtr), FD(yt),
		 result ? "TRUE" : "FALSE");
  return result;
}
#define	IsInTrap	IsInTrapDebug
#endif


/*
 * IsInExtra
 *	is this coordinate inside the extrapolation region?
 */

PRIVATE boolean IsInExtra ARGDEF3(FCd *, p, FontFitDomain *, dom, FontFitExtra *, extra) {
  FontFitExtra *xe = &extra[0], *ye = &extra[1];
  Fixed xlo = dom->clamp[0].lo, xhi = dom->clamp[0].hi, ylo = dom->clamp[1].lo, yhi = dom->clamp[1].hi;

  return IsInTrap(p->x, p->y, xe->lo0, xe->hi0, ylo, xe->lo1, xe->hi1, yhi)
      || IsInTrap(p->y, p->x, ye->lo0, ye->hi0, xlo, ye->lo1, ye->hi1, xhi);
}


/*
 * Intersection procedures
 *	find the intersections of the curve (t, m), which is guaranteed to be
 *	of the named type, with the line (p, q).  a count of intersections is
 *	returned.
 */

PRIVATE IntX IntersectHorizontal ARGDEF5(FCd *, inter, FCd *, p, FCd *, q, Fixed, t, Fixed *, m) {
  Fixed y = fixdiv(t - m[0], m[2] - m[0]);
  if (p->y == q->y)
    if (y == p->y) {
      inter[0] = *p;
      inter[1] = *q;
      return 2;
    } else
      return 0;
  if (p->y < q->y ? (p->y <= y && y <= q->y) : (q->y <= y && y <= p->y)) {
    inter->x = fixdiv(fixmul(p->x, y - q->y) - fixmul(q->x, y - p->y), p->y - q->y);
    inter->y = y;
    return 1;
  }
  return 0;
}

PRIVATE IntX IntersectVertical ARGDEF5(FCd *, inter, FCd *, p, FCd *, q, Fixed, t, Fixed *, m) {
  Fixed x = fixdiv(t - m[0], m[1] - m[0]);
  if (p->x == q->x)
    if (x == p->x) {
      inter[0] = *p;
      inter[1] = *q;
      return 2;
    } else
      return 0;
  if (p->x < q->x ? (p->x <= x && x <= q->x) : (q->x <= x && x <= p->x)) {
    inter->y = fixdiv(fixmul(p->y, x - q->x) - fixmul(q->y, x - p->x), p->x - q->x);
    inter->x = x;
    return 1;
  }
  return 0;
}

#if 0
PRIVATE IntX IntersectDiagonal ARGDEF5(FCd *, inter, FCd *, p, FCd *, q, Fixed, t, Fixed *, m) {
  Fixed a, b, denom, x;
  a = m[1] - m[0];
  b = m[2] - m[0];
  if (p->x == q->x) {
  } else if (p->y == q->y) {
  }
  denom = fixmul(a, q->x - p->x) + fixmul(b, q->y - p->y);
  if (denom == 0)
    return 0;	/* WRONG!!! */
  x = fixdiv(fixmul(m[0], p->x - q->x) + fixmul(t, q->x - p->x)
	   + fixmul(b, fixmul(p->x, q->y) - fixmul(p->y, q->x)), denom);
  if (p->x < q->x ? (p->x <= x && x <= q->x) : (q->x <= x && x <= p->x)) {
    inter->x = x;
    inter->y = fixdiv(t - m[0] - fixmul(a, x), b);
    return 1;
  }
  return 0;
}
#endif

#define	IntersectDiagonal	IntersectHyperbola

PRIVATE IntX IntersectHyperbola ARGDEF5(FCd *, inter, FCd *, p, FCd *, q, Fixed, t, Fixed *, m) {
  IntX i, nroot, result;
  FCd orig, root[2];
  Fixed xlo, xhi, ylo, yhi, t1, m1[4];

  if (p->x < q->x) {
    xlo = p->x;
    xhi = q->x;
  } else {
    xlo = q->x;
    xhi = p->x;
  }
  if (p->y < q->y) {
    ylo = p->y;
    yhi = q->y;
  } else {
    ylo = q->y;
    yhi = p->y;
  }

  if (xlo == xhi) {		/* vertical line */
    if (ylo == yhi)
      return 0;
    m1[0] = m1[2] = 0;
    m1[1] = m1[3] = FixedOne;
    t1 = xlo;
  } else if (ylo == yhi) {	/* horizontal line */
    m1[0] = m1[1] = 0;
    m1[2] = m1[3] = FixedOne;
    t1 = ylo;
  } else {			/* diagonal line */
    Fixed denom = fixmul(xlo, yhi) - fixmul(xhi, ylo);
    if (denom == 0)
      return 0;		/* do we have to worry about this case? */
    m1[0] = 0;
    m1[1] = fixdiv(yhi - ylo, denom);
    m1[2] = fixdiv(xlo - xhi, denom);
    m1[3] = m1[1] + m1[2];
    t1 = FixedOne;
  }

  orig.x = FixedNegInf;
  orig.y = FixedNegInf;

  nroot = (xlo == xhi || ylo == yhi)
	    ? FastFontFit2(&orig, root, t1, t, m1, m, true)
	    : QuadraticFontFit2(&orig, root, t, t1, m, m1);

  for (i = 0, result = 0; i < nroot; i++)
    if (INRECT(root[i], xlo, xhi, ylo, yhi))
      inter[result++] = root[i];
  return result;
}

#if 0
PRIVATE IntX DebugIntersectHyperbola ARGDEF5(FCd *, inter, FCd *, p, FCd *, q, Fixed, t, Fixed *, m) {
  IntX i, result = IntersectHyperbola(inter, p, q, t, m);
  printf("%% IntersectHyperbola((%g, %g), (%g, %g)) = %d\n", CD(*p), CD(*q), result);
  for (i = 0; i < result; i++)
    printf("%%	%g, %g\n", CD(inter[i]));
  return result;
}
#define	IntersectHyperbola	DebugIntersectHyperbola
#endif


/*
 * ExtraClampedFontFit2
 *	this version of fontfit handles the case where there is no solution
 *	inside the design space or the extrapolation region.  this routine
 *	has the same preconditions as ClampedFontFit2, except that there is
 *	also an extrapolation region, and therefore the domain does not
 *	necessarily contain the values we need.
 */

typedef (* Intersect_t)  ARGDECL5(FCd *, inter, FCd *, p, FCd *, q, Fixed, t, Fixed *, m);

PRIVATE boolean ExtraClampedFontFit2 ARGDEF7(
  FontFitDomain *, dom,		/* problem domain */
  FCd *, result,		/* solution */
  Fixed, t0,			/* target[0] */
  Fixed, t1,			/* target[1] */
  Fixed *, m0,			/* metrics[0] */
  Fixed *, m1,			/* metrics[1] */
  FontFitExtra *, extra		/* extrapolation region */
) {
#define	EDGES	12

  IntX i, intersections;
  FCd corner[EDGES + 1], inter[2 * EDGES];
  FontFitExtra *xe = &extra[0], *ye = &extra[1];
  Fixed xlo = dom->clamp[0].lo, xhi = dom->clamp[0].hi, ylo = dom->clamp[1].lo, yhi = dom->clamp[1].hi;
  IntX (*proc) ARGDECL5(FCd *, inter, FCd *, p, FCd *, q, Fixed, t, Fixed *, m);

  corner[ 0].x = xlo;		corner[ 0].y = ylo;
  corner[ 1].x = xe->lo0;	corner[ 1].y = ylo;
  corner[ 2].x = xe->lo1;	corner[ 2].y = yhi;
  corner[ 3].x = xlo;		corner[ 3].y = yhi;
  corner[ 4].x = xlo;		corner[ 4].y = ye->hi0;
  corner[ 5].x = xhi;		corner[ 5].y = ye->hi1;
  corner[ 6].x = xhi;		corner[ 6].y = yhi;
  corner[ 7].x = xe->hi1;	corner[ 7].y = yhi;
  corner[ 8].x = xe->hi0;	corner[ 8].y = ylo;
  corner[ 9].x = xhi;		corner[ 9].y = ylo;
  corner[10].x = xhi;		corner[10].y = ye->lo1;
  corner[11].x = xlo;		corner[11].y = ye->lo0;
  corner[12].x = xlo;		corner[12].y = ylo;

  proc =
    (m0[1] - m0[0] == m0[3] - m0[2])
      ? ( (m0[0] == m0[1])
        ? ( (m0[0] == m0[2])
	  ? (Intersect_t) NULL
	  : (Intersect_t) IntersectHorizontal
          )
	: ( (m0[0] == m0[2])

	  ? (Intersect_t) IntersectVertical
	  : (Intersect_t) IntersectDiagonal
	  ))
      : (Intersect_t) IntersectHyperbola;
  if (proc == NULL)
    return false;

  for (i = 0, intersections = 0; i < EDGES; i++)
    intersections += (*proc)(inter + intersections, corner + i, corner + i + 1, t0, m0);
  return FindBest(result, intersections, inter, t1, m1);

#undef EDGES
}


/*
 * ExtrapolateAndClamp
 *	this is the main routine for dealing with the FontFitExtra
 *	data structure, which is used for controlled extrapolation
 *	from the clamping region.  if we got here, we know that
 *	nroot is 1 or 2 and neither of the roots lies within the
 *	clamping rectangle.
 */

PRIVATE IntX ExtrapolateAndClamp ARGDEF8(
  FontFitDomain *,	dom,		/* problem domain */
  IntX,			nroot,		/* the number of roots to pick among */
  FCd *,		root,		/* the roots */
  Fixed,		t0,		/* target[0] */
  Fixed,		t1,		/* target[1] */
  Fixed *,		m0,		/* metrics[0] */
  Fixed *,		m1,		/* metrics[1] */
  FontFitExtra *,	extra		/* extrapolation specifier */
) {
  IntX i;

  /* if any of the roots are inside the extra region, just return them */

  for (i = 0; i < nroot;)
    if (IsInExtra(root + i, dom, extra))
      ++i;
    else
      root[i] = root[--nroot];
  if (nroot > 0)
    return nroot;
  return ExtraClampedFontFit2(dom, root, t0, t1, m0, m1, extra) ? 1 : 0;
}


/*
 * FontFit2
 *	entry point to the collection of routines which deal with 2 axis
 *	fontfitting.  dispatches to smarter routines and picks the best
 *	result by not very smart criteria.
 */

PRIVATE boolean FontFit2 ARGDEF8(
  FontFitDomain *,	dom,		/* problem domain */
  Fixed *,		xp,		/* designvector[0] */
  Fixed *,		yp,		/* designvector[1] */
  Fixed,		t0,		/* target[0] */
  Fixed,		t1,		/* target[1] */
  Fixed *,		m0,		/* metrics[0] */
  Fixed *,		m1,		/* metrics[1] */
  FontFitExtra *,	extra		/* extrapolation specifier */
) {
  IntX nroot, i;
  FCd *result, orig, root[2];
  Fixed xlo = dom->clamp[0].lo, xhi = dom->clamp[0].hi, ylo = dom->clamp[1].lo, yhi = dom->clamp[1].hi;

  t0 = (dom->npreset == 0) ? FindTargetLimits(dom, 0, t0, m0) : dom->target[0];

  orig.x = *xp;
  orig.y = *yp;

  nroot = (m0[1] - m0[0] == m0[3] - m0[2])
	    ? (m1[1] - m1[0] == m1[3] - m1[2])
	      ? FastestFontFit2(root, t0, t1, m0, m1)
	      : FastFontFit2(&orig, root, t0, t1, m0, m1, false)
	    : (m1[1] - m1[0] == m1[3] - m1[2])
	      ? FastFontFit2(&orig, root, t1, t0, m1, m0, true)
	      : QuadraticFontFit2(&orig, root, t0, t1, m0, m1);

  for (i = 0; i < nroot; i++) {
    result = &root[i];
    if (FixedIsInfinity(result->x) || FixedIsInfinity(result->y)) {
      --nroot;
      result->x = root[nroot].x;
      result->y = root[nroot].y;
      --i;
    }
  }

  switch (nroot) {

    case 0:
      result =
        ((extra == NULL)
	    ? ClampedFontFit2(dom, root, t0, t1, m0, m1)
	    : ExtraClampedFontFit2(dom, root, t0, t1, m0, m1, extra))
	  ? root
	  : NULL;
      break;        

    case 1:
      result =
        INRECT(*root, xlo, xhi, ylo, yhi)
	  ? root
	  : ((extra == NULL)
	  	? ClampedFontFit2(dom, root, t0, t1, m0, m1)
		: ExtrapolateAndClamp(dom, 1, root, t0, t1, m0, m1, extra) == 1)
	      ? root
	      : NULL;
      break;

    case 2:
      result =
	INRECT(root[0], xlo, xhi, ylo, yhi)
	  ? INRECT(root[1], xlo, xhi, ylo, yhi)
	    ? (DIST(root[0], orig) < DIST(root[1], orig))
	      ? &root[0]
	      : &root[1]
	    : &root[0]
	  : INRECT(root[1], xlo, xhi, ylo, yhi)
	    ? &root[1]
	    : (extra == NULL)
	      ? ClampedFontFit2(dom, root, t0, t1, m0, m1)
		? root
		: NULL
	      : ((i = ExtrapolateAndClamp(dom, 2, root, t0, t1, m0, m1, extra)) == 2)
	        ? (DIST(root[0], orig) < DIST(root[1], orig))
		  ? &root[0]
		  : &root[1]
		: i == 1
		  ? root
		  : NULL;
      break;

    default:
      result = NULL;
      break;
  }

#if DEBUG_FONTFIT
  if (debug_fontfit2) {
    IntX i;
    printf("x0 = %g\ny0 = %g\n", FD(*xp), FD(*yp));
    printf("xlo = %g\nylo = %g\n", FD(xlo), FD(ylo));
    printf("xhi = %g\nyhi = %g\n", FD(xhi), FD(yhi));
    printf("targ1 = %g\ntarg2 = %g\n", FD(t0), FD(t1));
    if (result != NULL)
      printf("x = %g\ny = %g\n", FD(result->x), FD(result->y));
    for (i = 0; i < 4; i++)
      printf("base1 %d = %g\nbase2 %d = %g\n", i, FD(m0[i]), i, FD(m1[i]));
    printf("fontfit\n");
  }
#endif

  if (result == NULL)
    return false;
  *xp = result->x;
  *yp = result->y;
  return true;
}


/*
 * Collapse
 *
 *	this routine finds the intercepts of the region that we
 *	are varying with the surface defined by the design vector
 *	coordinates that do not vary.
 */

PRIVATE Fixed Collapse ARGDEF6(
  DesignSpace *,	ds,
  IntX,			nvary,
  Int16 *,		vary,
  IntX,			loc,
  Fixed *,		metric,
  Fixed *,		dv
) {
  int i, corner, dimen, dbit, varymask, locmask;
  Fixed result = 0;

  varymask = 0;
  locmask = 0;
  for (i = 0; i < nvary; i++) {
    int vbit = (1 << vary[i]);
    varymask |= vbit;
    if (loc & (1 << i))
      locmask |= vbit;
  }

  for (corner = 0; corner < ds->nmasters; corner++)
    if ((corner & varymask) == locmask) {
      Fixed m = metric[ds->corner[corner]];
      for (dimen = 0, dbit = 1; dimen < ds->ndimen; dimen++, dbit <<= 1)
        if ((varymask & dbit) == 0)
	  if (corner & dbit)
	    m = fixmul(m, dv[dimen]);
	  else
	    m = fixmul(m, FixedOne - dv[dimen]);
      result += m;
    }

  return result;
}


/*
 * public interfaces
 */

PUBLIC boolean SetupFontFit ARGDEF9(
  FontFitDomain *,	domain,
  DesignSpace *,	ds,
  Fixed *,		origdv,
  IntX,			nvary,
  Int16 *,		vary,
  FontFitBounds *,	clamp,
  IntX,			npreset,
  Fixed *,		target,
  Fixed **,		metric
) {
  IntX i, j;

  if (!CheckDesignSpace(ds))
    return false;

  if (nvary > MAXFONTFIT)
    nvary = MAXFONTFIT;

  if (npreset > nvary - 1)
    return false;

  for (i = 0; i < ds->ndimen; i++)
    domain->origdv[i] = origdv[i];

  for (i = 0; i < nvary; i++) {
    IntX axis = vary[i];
    if (axis >= ds->ndimen)
      return false;
    domain->vary[i] = axis;
    if (clamp == NULL) {
      domain->clamp[i].lo = 0;
      domain->clamp[i].hi = FixedOne;
    } else if (clamp[i].lo > clamp[i].hi)
      return false;
    else
      domain->clamp[i] = clamp[i];
  }
  domain->nvary = nvary;

  for (i = 0; i < npreset; i++) {
    IntX nvary2 = 1 << nvary;
    for (j = 0; j < nvary2; j++)
      domain->collapsed[i][j] = Collapse(ds, nvary, vary, j, metric[i], origdv);
    /* assert nvary == 1 || nvary == 2 */
    domain->target[i] = FindTargetLimits(domain, i, target[i], domain->collapsed[i]);
  }
  domain->npreset = npreset;

  return true;
}

PUBLIC boolean ExtrapolateFontFit ARGDEF7(
  FontFitDomain *,	dom,
  DesignSpace *,	ds,
  Fixed *,		dv,
  Fixed *,		wv,
  Fixed *,		argtarget,
  Fixed **,		argmetric,
  FontFitExtra *,	extra
) {
  IntX i, j, nvary = dom->nvary;
  Fixed target[MAXFONTFIT], *metric[MAXFONTFIT], dvtemp[MAXAXES];
  Fixed m[MAXFONTFIT][1 << MAXFONTFIT];

  if (dv == NULL)
    dv = dvtemp;
  for (i = 0; i < ds->ndimen; i++)
    dv[i] = dom->origdv[i];

  for (i = 0; i < dom->npreset; i++) {
    target[i] = dom->target[i];
    metric[i] = dom->collapsed[i];
  }
  for (j = 0; i < nvary; i++, j++) {
    IntX k, nvary2 = 1 << nvary;
    for (k = 0; k < nvary2; k++)
      m[j][k] = Collapse(ds, nvary, dom->vary, k, argmetric[j], dom->origdv);
    metric[i] = m[j];
    target[i] = argtarget[j];
  }

  if (!CheckDesignSpace(ds))
    return false;

#if DEBUG_FONTFIT
  if (debug_fontfit2) {
    int i, j;
    char *name[MAXAXES];
    for (i = 0; i < (1 << nvary); i++) {
      printf("corner %d", i);
      for (j = 0; j < MAXAXES; j++)
	name[j] = NULL;
      for (j = 0; j < nvary; j++)
	name[dom->vary[j]] = debug_sidename[dom->vary[j]][(i & (1 << j)) == 0 ? 0 : 1];
      for (j = 0; j < MAXAXES; j++)
	if (name[j] != NULL)
	  printf(" %s", name[j]);
      printf("\n");
    }
    if (extra != NULL) {
      printf("extra");
      for (i = 0; i < 2; i++)
        printf(" %g %g %g %g", FD(extra[i].lo0), FD(extra[i].lo1), FD(extra[i].hi0), FD(extra[i].hi1));
      printf("\n");
    }
  }
#endif

  switch (nvary) {

    case 2:
      if (
      	!FontFit2(dom, &dv[dom->vary[0]], &dv[dom->vary[1]],
		  target[0], target[1], metric[0], metric[1], extra)
      )
	return false;
      break;

    case 1: {
      if (!FontFit1(&dv[dom->vary[0]], *target, *metric, dom->clamp->lo, dom->clamp->hi))
	return false;
      break;
    }

    case 0:
      break;

    default:
      return false;

  }

  if (wv == NULL)
    return true;

  return GetWV(ds, wv, dv);
}

PUBLIC boolean SolveFontFit ARGDEF6(
  FontFitDomain *,	domain,
  DesignSpace *,	ds,
  Fixed *,		dv,
  Fixed *,		wv,
  Fixed *,		target,
  Fixed **,		metric
) {
  return ExtrapolateFontFit(domain, ds, dv, wv, target, metric, NULL);
}

PUBLIC boolean FontFit ARGDEF8(
  DesignSpace *, ds,
  Fixed *, dv,
  Fixed *, wv,
  IntX, nvary,
  Int16 *, vary,
  FontFitBounds *, clamp,
  Fixed *, target,
  Fixed **, metric
) {
  FontFitDomain domain;
  return SetupFontFit(&domain, ds, dv, nvary, vary, clamp, 0, NULL, NULL)
      && SolveFontFit(&domain, ds, dv, wv, target, metric);
}
