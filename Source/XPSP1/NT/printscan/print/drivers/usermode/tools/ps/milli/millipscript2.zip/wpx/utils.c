/***********************************************************************

    MODULE:  utils.c

    PROGRAM: 

    PURPOSE: Contains utility functions for the PScript driver.

    FUNCTIONS:

***********************************************************************/

#include <windows.h>
#include <memory.h>
#include <string.h>

#define PRIVATE     static
#define PUBLIC
#define BUF_SIZE    1024

#define ELEMENT(lpData, i, size)   (LPVOID) ((LPBYTE) lpData + (i * size))

char buffer[BUF_SIZE];

PRIVATE void Exchange(LPVOID lpData, int i, int j, WORD wSize)
{
    if ( i != j) {
	_fmemcpy((LPVOID) buffer, ELEMENT(lpData, i, wSize), wSize);
	_fmemcpy(ELEMENT(lpData, i, wSize), ELEMENT(lpData, j, wSize), wSize);
	_fmemcpy(ELEMENT(lpData, j, wSize), (LPVOID) buffer, wSize);
    }
}


PUBLIC void FAR PASCAL Qsort(LPVOID lpData, int start, int end, WORD wSize,
			     int (*Compare)(LPVOID, LPVOID))
{
    int i, j;

    if (start < end) {
	i = start;
	j = end + 1;

	while (1) {
	    while (i < j) {
		i++;
		if (Compare(ELEMENT(lpData, i, wSize), ELEMENT(lpData, start, wSize)) >= 0)
		  break;
	    }
	    
	    while(1) {
		j--;
		if (Compare(ELEMENT(lpData, j, wSize), ELEMENT(lpData, start, wSize)) <= 0)
		  break;
	    }

	    if (i < j) 
	      Exchange(lpData, i, j, wSize);
	    else
	      break;
	}

	Exchange(lpData, start, j, wSize);
	Qsort(lpData, start, j-1, wSize, Compare);
	Qsort(lpData, j+1, end, wSize, Compare);
    }
}
