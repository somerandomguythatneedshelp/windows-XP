/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ENCODE.C                                                     */
/*                                                                           */
/* Description: This module contains the function                            */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_TUTILSSEG)


#define START           0       /* states of the compression state machine */
#define IN_RUN          1       /* building a run of repeating chars */
#define IN_NON_RUN      2       /* building a run of non repeating chars */
#define DONE            3       /* all chars have been processed */
#define TERM            4       /* end of a run or non-run */
#define QUIT            5       /* get out of the program */

#define PS_RUN_LEN      128     /* PS runs can be a max of 128 */
#define PS_NON_RUN_LEN  128     /* PS non-runs (no char the same) can be 128 */

#define LINELENGTH      60      /* maximum length of a line */

static void  Output85(LPPDEVICE,unsigned long, int, int FAR *);

/***************************************************************************
*                               RLEncode
*  Purpose:
*       This function performs run length encoding of the binary input stream
*       pointed to by lpinbytes (length inlen).  The encoded data is output
*       to lpoutbytes and the length of the encoded data is returned.  The
*       encoding scheme used is equivalent to the RunLengthEncode filter
*       in Level II Postscript.  Consult the Red Book for more information.
*
*  Parameters:
*       BYTE huge *lpHugeBuf --
*       long      inlen --
*       BYTE huge *lpoutbytes --
*    
*  Returns: DWORD
*                                                                           
***************************************************************************/
DWORD FAR PASCAL RLEncode(BYTE huge *lpHugeBuf, long inlen, 
                          BYTE huge *lpoutbytes)
{
   BYTE huge * lpfirst;
   BYTE huge * lpchar;
   BYTE huge * lpoutnext;
   BYTE huge * lpinbytes = (BYTE huge * )lpHugeBuf;
   DWORD runcount;
   int   state;
   DWORD outcount;
   
   lpfirst   = lpinbytes;
   state     = START;
   lpoutnext = lpoutbytes;
   outcount  = 0;
   
   
   while (state != QUIT)
   {
      switch (state)
      {
         case IN_RUN:
            if ((lpchar + 1) >= (lpinbytes + inlen))
            {  /* off the end? */
               state = DONE;
               break;
            }
            
            if (*lpchar != *(lpchar + 1))
            {
               state = TERM;
               break;
            }
            
            lpchar++;
            
            runcount++;
            
            if (runcount >= PS_RUN_LEN)
            {
               state = TERM;
            }
            break;
         
         case IN_NON_RUN:
            if ((lpchar + 1) >= (lpinbytes + inlen))
            {  /* off the end? */
               state = DONE;
               break;
            }
            
            if (*lpchar == *(lpchar + 1))
            {
               lpchar--;       /* back up to give */
               runcount--;        /* upcomming run more */
               state = TERM;
               break;
            }
            else
            {
               lpchar++;
            }
            runcount++;
            
            if (runcount >= PS_NON_RUN_LEN)
            {
               state = TERM;
            }
            break;
         
         
         case START:
            /* special case, one char (last in string) */
            if ((lpfirst + 1) >= (lpinbytes + inlen))
            {
               runcount = 1;         /* minimal case */
               state = DONE;
            }
            else
            {
               lpchar = lpfirst + 1; /* not over end */
               
               /* in_run = FALSE; */
               runcount = 2; /* start with strings of 2 */
               
               if (*lpchar == *lpfirst)
               {
                  state = IN_RUN;
               }
               else
               {
                  state = IN_NON_RUN;
               }
            }
            break;
         
         case TERM:
         case DONE:
            /* is it the minimal case of a single char or
             * a non run */
            if ((runcount < 2) || (*lpchar != *(lpchar - 1)))
            {
               /* this is a non run (non repeating chars) */
               /* output value in rage of 0 - 127 -> 1 - 128 */
               *lpoutnext++ = (BYTE)(runcount - 1); /* the runcount */
               outcount ++;
               while (runcount--)   /* the values */
               {
                  *lpoutnext++ = (BYTE)*lpfirst++;
                  outcount++;
               }
            }
            else
            {
               /* we just came from a run */
               /* output value in range 129 - 255 -> 128 - 2 */
               *lpoutnext++ = (BYTE)(257 - runcount);    /* the runcount */
               outcount ++;
               *lpoutnext++ = (BYTE)*lpchar; /* the value */
               outcount ++;
            }
            if (state == DONE)
            {
               state = QUIT;
            }
            else
            {
               lpfirst = lpchar + 1;
               if (lpfirst >= (lpinbytes + inlen))
               {
                  state = QUIT;
               }
               else
               {
                  state = START;
               }
            }
            break;
      }
   }
   return(outcount);

}  // END RLEncode 

/***************************************************************************
*                               ASCII85Output
*  Purpose:
*       This function performs ASCII85 encoding of the binary input stream
*       pointed to by lpin (length inlen).  The encoded data is output
*       to the device via PrintChannel.  The encoding scheme used is
*       equivalent to the ASCII85Encode filter in Level II Postscript.
*       Consult the Red Book for more information.
*
*  Parameters:
*       LPPDEVICE lppd --
*       BYTE huge *lpin --
*       DWORD     inlen --
*    
*  Returns: none
*                                                                           
***************************************************************************/
VOID FAR PASCAL ASCII85Output(LPPDEVICE lppd, BYTE huge *lpin,   DWORD inlen,
                              int FAR * lpcharcount)
{
   DWORD incount;
   BYTE  huge *cptr;
   int   rem;
   int   bcount;
   int   dex;
   unsigned long word;
   
   /* encode the initial 4-tuples */
   cptr   = lpin;
   word   = 0UL;
   bcount = 0;

   for (incount = 0; incount < inlen; incount ++)
   {
      word = (word<<8);
      word |= (BYTE)*cptr++;
      if (bcount == 3)
      {
         Output85(lppd, word, 5, lpcharcount);
         word = 0UL;
         bcount = 0;
      }
      else
      {
         bcount ++;
      }
   }
   
   /* now do the last partial 4-tuple -- if there is one */
   /* see the Red Book spec for the rules on how this is done */
   if (bcount > 0)
   {
      rem = 4 - bcount;  /* count the remaining bytes */
      for (dex = 0; dex < rem; dex ++) /* shift left for each of them */
      {
         word = (word<<8);      /* (equivalent to adding in ZERO's)*/
      }
      Output85(lppd, word, (bcount + 1), lpcharcount);  /* output only meaningful
                                                           bytes + 1 */
   }
}  // END ASCII85Output

/************************************************************************
*                            Output85
*  Purpose
*       Outputs a long of ascii85 encoded data.
*       
*  Parameters:
*       LPPDEVICE lppd --
*       unsigned long inword -- word containing data to be output
*       int nbytes -- # of ascii bytes to output (1 - 5)
*       
*  Returns: none
*       
************************************************************************/
void Output85(LPPDEVICE lppd, unsigned long inword, int nbytes, 
              int FAR *lpcharcount)
{
   unsigned long divisor;
   int  bcount;
   BYTE outchar[5];    // Fix bug 153076. Performance improvement.
   LPASCIIBINPTRS tempptr;
   
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   if ((inword == 0UL) && (nbytes == 5))
   {
      PSSendString(lppd,"z");
      (*lpcharcount)++;
   }
   else
   {
      divisor = 52200625UL;
      for (bcount = 0; bcount < nbytes; bcount ++)
      {
         outchar[bcount] = (BYTE)((int)(inword/divisor) + (int)'!');
         if (bcount < 4)
         {
            inword = (inword % divisor);
            divisor =(divisor / 85);
         }
      }
      *lpcharcount += nbytes;
      PSSendData(lppd,(LPSTR)outchar, nbytes);
   }
   if (*lpcharcount >= LINELENGTH)
   {
      (*tempptr->PSSendCRLF)(lppd);
      *lpcharcount = 0;
   }
}  // END Output85

/************************************************************************
*                            PSSendBitMapDataLevel2Ascii7
*  Purpose
*      This function performs run length encoding followed by ASCII85
*      encoding of the input string.  The resulting stream is then output
*      to the device VIA PrintChannel.  This stream is intended to be read
*      by the PS level 2 filters ASCII85Decode followed by RunLengthDecode.
*      They should therefore be equivalent to the output of the
*      RunLengthEncode followed by the ASCII85Encode PS filters.  See the
*      Red Book for a description of these filters.
*       
*  Parameters:
*       LPPDEVICE lppd --
*       BYTE huge *lpBytes --
*       DWORD     len --
*       
*  Returns: none
*       
*  Note:
*       the input buffer to this function should contain the complete data
*       stream for the image to be printed.  Therefore, the image generation
*       code should buffer the data an pass the buffer to this function.
*
************************************************************************/
VOID FAR PASCAL PSSendBitMapDataLevel2Ascii7(LPPDEVICE lppd, BYTE huge *lpBytes,
                                             DWORD len)
{

   DWORD  rlelen, rlelen2;
   BYTE huge *intrbuf;
   HANDLE intrhandle;
   BOOL   retval = TRUE;
   LPASCIIBINPTRS tempptr;
   int charcount;
   DWORD fragLen, fragment;
   BYTE  tempStrHldr[4];
   int   i,j, offset;
   int   count;
   BYTE huge *tempP;


   tempP = lpBytes;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   // Slice up the bitmap.
   fragment = 32768;

   if (len <= fragment) {
      count = 1;
      fragLen = fragment = len;
   }
   else {
      count = (int) ((len + fragment - 1) / fragment);
      fragLen = fragment;
   }   
   /* globally allocate the intermediate buffer. */
   rlelen = (DWORD) (2 * fragLen) + 2; /* a little padding on top
                                      of the worst case */
   intrhandle = GlobalAlloc(GHND,rlelen);
   if (intrhandle == NULL)
   {
      retval = FALSE;
   }
   
   if (retval) 
   {
      intrbuf = (BYTE huge * ) GlobalLock(intrhandle);
      if (intrbuf == NULL)
      {
         retval = FALSE;
      }
      else
      {
         offset = 0;
         for (i=0;i<count;i++) 
         {
            retval = TRUE;
         
            if (len < (fragLen * (i+1))) 
            {
               fragLen = len - (fragLen * i);
            }

            rlelen = RLEncode (lpBytes, fragLen, intrbuf+offset);
         

            if (i == (count -1)) //last loop
            {
               rlelen2 = rlelen + offset;
               /* put the terminator ((char)128) on the rle stream */
               *(intrbuf + rlelen2) = (BYTE)128;
               rlelen2++;
            }
            else 
            {
               rlelen2 = ((rlelen+offset) / 4) * 4;
               for (j=0; j< (int)(rlelen+offset - rlelen2); j++) 
               {
                  tempStrHldr[j] = *(intrbuf+rlelen2+j);
               }
            }

            /* everything is now in intrbuf -- now ASCII85 encode it and
            ship it out (to avoid having to allocate another buffer) */
            charcount = 0;
            ASCII85Output(lppd,intrbuf,rlelen2,&charcount);
         
            for (j=0; j< (int)(rlelen+offset - rlelen2); j++) 
            {
               *(intrbuf+j) = tempStrHldr[j];
            }
            offset = j;
            lpBytes = lpBytes + fragLen;
         }
      }
      /* get rid of the intermediate buffer */
      GlobalUnlock(intrhandle);
   }
   lpBytes = tempP;
   GlobalFree(intrhandle);
   /* stick on the ASCII85 terminator */
   if (charcount > 0)
   {
      (*tempptr->PSSendCRLF)(lppd);
   }
   /* put terminator on its own line */
   PSSendString(lppd,"~>");
   (*tempptr->PSSendCRLF)(lppd);

} // END PSSendBitMapDataLevel2Ascii7


/************************************************************************
*                        PSSendBitMapDataLevel2Binary
*  Purpose:
*       This function performs run length encoding. The resulting stream is
*       then output to the device .  This stream is intended
*       to be read by the PS level 2 filter RunLengthDecode.
*       
*  Parameters:
*       LPPDEVICE lppd --
*       BYTE huge *lpBytes --
*       DWORD     len --
*       
*  Returns: none
*       
*  Note:
*       the input buffer to this function should contain the complete data
*       stream for the image to be printed.  Therefore, the image generation
*       code should buffer the data an pass the buffer to this function.
*
************************************************************************/
VOID FAR PASCAL PSSendBitMapDataLevel2Binary(LPPDEVICE lppd, BYTE huge *lpBytes,
                                             DWORD len)
{
   DWORD rlelen;
   BYTE huge *intrbuf;
   HANDLE intrhandle;
   LPASCIIBINPTRS tempptr;
   int count, i;
   DWORD fragment, fragLen;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   // Slice up the bitmap.
   fragment = 32768;

   if (len <= fragment) {
      count = 1;
      fragLen = fragment = len;
   }
   else {
      count = (int) ((len + fragment - 1) / fragment);
      fragLen = fragment;
   }
      
   /* globally allocate the intermediate buffer. */
   rlelen = (DWORD) (2 * fragLen) + 2; /* a little padding on top
                                      of the worst case */
   intrhandle = GlobalAlloc(GHND,rlelen);
   if (intrhandle == NULL)
   {
      return;
   }
   
   intrbuf = (BYTE huge * ) GlobalLock(intrhandle);
   if (intrbuf == NULL)
   {
      GlobalFree(intrhandle);
      return;
   }
   else
   {
      for (i=0;i<count;i++) 
      {
         if (len < (fragLen * (i+1))) 
         {
            fragLen = len - (fragLen * i);
         }
         rlelen = RLEncode (lpBytes, fragLen, intrbuf);
        
         if (i == (count -1)) //last loop
         {
            /* put the terminator ((char)128) on the rle stream */
            *(intrbuf + rlelen) = (BYTE)128;
            rlelen++;
         }

         /* everything is now in intrbuf --
         ship it out (to avoid having to allocate another buffer) */
         PSSendBitMapDataLevel1Binary(lppd,intrbuf,rlelen);
         lpBytes = lpBytes + fragLen;
      }
   }

   /* get rid of the intermediate buffer */
   GlobalUnlock(intrhandle);
   GlobalFree(intrhandle);
   
   (*tempptr->PSSendCRLF)(lppd);

} // END PSSendBitMapDataLevel2Binary



/************************************************************************
*                        PSSendBitMapDataLevel1Binary
*  Purpose:
*       
*  Parameters:
*       LPPDEVICE lppd --
*       BYTE huge *buf --
*       DWORD     NumBytes --
*       
*  Returns: none
*       
************************************************************************/
VOID FAR PASCAL PSSendBitMapDataLevel1Binary(LPPDEVICE lppd, BYTE huge *buf,
                                             DWORD NumBytes)
{
   WORD   Number;
   LPBYTE BinaryData;
   LPASCIIBINPTRS tempptr;
   WORD   MaxSize    = 0x2000;
   DWORD  DblMaxSize = (DWORD)(MaxSize * 2);

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   // This variable allocated at startdoc time is used only by this function.
   if (!lppd->GlobalBuffer.lpBitMapDataLevel1Binary)
       return;
       
   // Check if Memory Block allocated (and kept track of in PDevice) is sufficient.
   if (lppd->GlobalBuffer.dBitMapDataLevel1Binary < DblMaxSize)
   {
      MGUnlockFree(lppd, lppd->GlobalBuffer.hBitMapDataLevel1Binary, TRUE);
      if (lppd->GlobalBuffer.lpBitMapDataLevel1Binary = 
                                 (LPBYTE) MGAllocLock(lppd,
                                 (LPHANDLE)&lppd->GlobalBuffer.hBitMapDataLevel1Binary,
                                 DblMaxSize,GHND,TRUE))
          lppd->GlobalBuffer.dBitMapDataLevel1Binary = DblMaxSize;

      if (lppd->GlobalBuffer.hBitMapDataLevel1Binary == NULL)
      {
         lppd->GlobalBuffer.dBitMapDataLevel1Binary = 0;
         return;
      }
   }

   BinaryData = (LPBYTE)lppd->GlobalBuffer.lpBitMapDataLevel1Binary;

   if( BinaryData == NULL )
   {
      return;
   }

   while (NumBytes > MaxSize)
   {
      Number = MaxSize;
      Number = (*tempptr->ConvertToBinary)((LPBYTE)buf,(LPBYTE)BinaryData,Number);

      PSSendData(lppd,BinaryData,Number);
      NumBytes -= MaxSize;
      buf      += MaxSize;
   }

   if(NumBytes > 0)
   {
      Number = (WORD) NumBytes;
      Number = (*tempptr->ConvertToBinary)((LPBYTE)buf,(LPBYTE)BinaryData,Number);
      PSSendData(lppd, BinaryData, Number);
   }
}

