/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: CONTROL.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for Control()             */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "krnlcmn.h"  // For GetProcessDword()

#pragma code_seg(_ESCAPESSEG)

/************************************************************************
*                               Control
*  function:
*       this function is called by GDI for each escape function.
*  prototype:
*       WORD FAR PASCAL Control(LP lpDevice,WORD wEscNum,LP lpInData,
*                                LP lpOutData);
*  parameters:
*       LP lpdevice -- PDEVICE for this device context
*       WORD wEscNum -- escape type
*       LP lpInData  -- pointer to input data for the escape
*       LP lpOutData -- pointer to data output from the escape function
*  returns:
*       WORD -- escape function dependent
***********************************************************************/

WORD _loadds FAR PASCAL Control(LP lpDevice,WORD wEscNum,LP lpInData,
                                LP lpOutData)
{
    LPPDEVICE lppd;
    WORD wRC=0;

    // ResetDC puts the old pdevice into "lpInData"
    lppd=(LPPDEVICE) lpDevice;

    // make sure its our pdevice
    if (lppd->sMagic == LUCAS)
    {
        if ( fEnabledLppd( lppd ) )
        {
          // Control() never causes state transitions, though
          // individual ESC handlers may.

          // if we have a buffered bitmap, flush it before any path changing
          // operation is done - check for presence of buffered bitmap before
          // calling function to prevent loading the DIB segment unless
          // necessary.
          if (lppd->GlobalBuffer.hBitmapBf && lppd->GlobalBuffer.lpBitmapBf)
          {
              HandleBufferedBitmap((LP)lppd);
          }

            switch(wEscNum)
            {
              case NEWFRAME:
               wRC = ESCNewFrame(lppd,lpInData,lpOutData);
              break;

              case ABORTDOC:
               wRC = ESCAbortDoc(lppd,lpInData,lpOutData);
              break;

              case NEXTBAND:
               wRC = ESCNextBand(lppd,lpInData,lpOutData);
              break;

              case SETCOLORTABLE:
               wRC = ESCSetColorTable(lppd,lpInData,lpOutData);
              break;

              case GETCOLORTABLE:
               wRC = 0;
              break;

              case FLUSHOUTPUT:
               wRC = ESCFlushOutput(lppd,lpInData,lpOutData);
              break;

              case DRAFTMODE:
               wRC = 0;
              break;

              case QUERYESCSUPPORT:
               wRC = ESCQueryEscSupport(lppd,lpInData,lpOutData);
              break;

              case SETABORTPROC:
               wRC = ESCSetAbortProc(lppd,lpInData,lpOutData);
              break;

              case STARTDOC:
               wRC = ESCStartDoc(lppd,lpInData,lpOutData);
              break;

              case ENDDOC:
               wRC = ESCEndDoc(lppd,lpInData,lpOutData);
              break;

              case GETPHYSPAGESIZE:
               wRC = ESCGetPhysPageSize(lppd,lpInData,lpOutData);
              break;

              case GETPRINTINGOFFSET:
               wRC = ESCGetPrintingOffset(lppd,lpInData,lpOutData);
              break;

              case GETSCALINGFACTOR:
               wRC = ESCGetScalingFactor(lppd,lpInData,lpOutData);
              break;

              case SETCOPYCOUNT:
               wRC = ESCSetCopyCount(lppd,lpInData,lpOutData);
              break;

              case SELECTPAPERSOURCE:
               wRC = 0;
              break;

              case PASSTHROUGH:
               if (lppd->job.bfESCOpenChannel)
                  wRC = ESCPostScriptPass(lppd,lpInData,lpOutData);
               else
                  wRC = ESCPassThrough(lppd,lpInData,lpOutData);
              break;

              case GETTECHNOLOGY:
               wRC = ESCGetTechnology(lppd,lpInData,lpOutData);
              break;

              case SETLINECAP:
               wRC = ESCSetLineCap(lppd,lpInData,lpOutData);
              break;

              case SETLINEJOIN:
               wRC = ESCSetLineJoin(lppd,lpInData,lpOutData);
              break;

              case SETMITERLIMIT:
               wRC = ESCSetMiterLimit(lppd,lpInData,lpOutData);
              break;

              case BANDINFO:
               wRC = 0;
              break;

              case DRAWPATTERNRECT:
               wRC = 0;
              break;

              case GETVECTORPENSIZE:
               wRC = 0;
              break;

              case GETVECTORBRUSHSIZE:
               wRC = 0;
              break;

              case ENABLEDUPLEX:
               wRC = ESCEnableDuplex(lppd,lpInData,lpOutData);
              break;

              case GETSETPAPERBINS:
               wRC = ESCGetSetPaperBins(lppd,lpInData,lpOutData);
              break;

              case GETSETPAPERORIENTATION:
               wRC = ESCGetSetPaperOrientation(lppd,lpInData,lpOutData);
              break;

              case ENUMPAPERBINS:
               wRC = ESCEnumPaperBins(lppd,lpInData,lpOutData);
              break;

              case SETDIBSCALING:
               wRC = ESCSetDIBScaling(lppd,lpInData,lpOutData);
              break;

              case EPSPRINTING:
               VMDisable(lppd);
               wRC = ESCEPSPrinting(lppd,lpInData,lpOutData);
              break;

              case ENUMPAPERMETRICS:
               wRC = ESCEnumPaperMetrics(lppd,lpInData,lpOutData);
              break;

              case GETSETPAPERMETRICS:
               wRC = ESCGetSetPaperMetrics(lppd,lpInData,lpOutData);
              break;

              case GETVERSION:
               wRC = 0;
              break;

          case GETSETSCREENPARAMS:
               wRC = ESCGetSetScreenParams(lppd,lpInData,lpOutData);
              break;

          case GETDIBSUPPORT:
           wRC = ESCGetDIBSupport(lppd,lpInData,lpOutData);
              break;

              case POSTSCRIPTDATA:
#if 0
               // For 16 bit 3.1 apps always call ESCPassThrough.
               // Otherwise call ESCPostScriptPass if openchannel
               // has been called.
               if (!lppd->job.bfESCOpenChannel ||
                   ((GetProcessDword(NULL, GPD_FLAGS) &
                   GPF_WIN16_PROCESS) &&
                   (GetProcessDword(NULL, GPD_EXP_WINVER) < 0x0400)))
               {
                   wRC = ESCPassThrough(lppd,lpInData,lpOutData);
               }
               else
                   wRC = ESCPostScriptPass(lppd, lpInData, lpOutData);
#else
               wRC = ESCPassThrough(lppd,lpInData,lpOutData);
#endif
              break;

              case POSTSCRIPTIGNORE:
               wRC = ESCPostScriptIgnore(lppd,lpInData,lpOutData);
              break;

              case GETEXTENDEDTEXTMETRICS:
               wRC = ESCGetExtendedTextMetrics(lppd,lpInData,lpOutData);
              break;

              case GETEXTENTTABLE:
               wRC = 0 ;  // ESCGetExtentTable(lppd,lpInData,lpOutData);
              break;

              case GETPAIRKERNTABLE:
               wRC = ESCGetPairKernTable(lppd,lpInData,lpOutData);
              break;

              case GETTRACKKERNTABLE:
               wRC = 0;
              break;

              case EXTEXTOUT:
               wRC = 0;
              break;

              case GETFACENAME:
               wRC = ESCGetFaceName(lppd,lpInData,lpOutData);
              break;

              case DOWNLOADFACE:
               wRC = ESCDownLoadFace(lppd,lpInData,lpOutData);
              break;

              case ENABLERELATIVEWIDTHS:
               wRC = 0;
              break;

              case ENABLEPAIRKERNING:
               wRC = ESCEnablePairKerning(lppd,lpInData,lpOutData);
              break;

              case SETKERNTRACK:
               wRC = ESCSetKernTrack(lppd,lpInData,lpOutData);
              break;

              case SETALLJUSTVALUES:
               wRC = ESCSetAllJustValues(lppd,lpInData,lpOutData);
              break;

              case SETCHARSET:
               wRC = ESCSetCharset(lppd,lpInData,lpOutData);
              break;

              case BEGINPATH:
               wRC = ESCBeginPath(lppd,lpInData,lpOutData);
              break;

              case CLIPTOPATH:
               wRC = ESCClipToPath(lppd,lpInData,lpOutData);
              break;

              case ENDPATH:
               wRC = ESCEndPath(lppd,lpInData,lpOutData);
              break;

              case EXTDEVICECAPS:
               wRC = ESCExtDeviceCaps(lppd,lpInData,lpOutData);
              break;

              case RESTORECTM:
               wRC = ESCRestoreCTM(lppd,lpInData,lpOutData);
              break;

              case SAVECTM:
               wRC = ESCSaveCTM(lppd,lpInData,lpOutData);
              break;

              case SETARCDIRECTION:
               wRC = ESCSetArcDirection(lppd,lpInData,lpOutData);
              break;

              case SETBACKGROUNDCOLOR:
               wRC = ESCSetBackgroundColor(lppd,lpInData,lpOutData);
              break;

              case SETPOLYMODE:
               wRC = ESCSetPolyMode(lppd,lpInData,lpOutData);
              break;

              case SETSCREENANGLE:
               wRC = ESCSetScreenAngle(lppd,lpInData,lpOutData);
              break;

              case SETSPREAD:
               wRC = ESCSetSpread(lppd,lpInData,lpOutData);
              break;

              case TRANSFORMCTM:
               wRC = ESCTransformCTM(lppd,lpInData,lpOutData);
              break;

              case SETCLIPBOX:
               wRC = ESCSetClipBox(lppd,lpInData,lpOutData);
              break;

              case SETBOUNDS:
               wRC = ESCSetBounds(lppd,lpInData,lpOutData);
              break;

//********* New Aldus Escapes **********************************

              case OPENCHANNEL:
               VMDisable(lppd);
               wRC = ESCOpenChannel(lppd,lpInData,lpOutData);
              break;

              case DOWNLOADHEADER:
               wRC = ESCDownLoadHeader(lppd,lpInData,lpOutData);
              break;

              case CLOSECHANNEL:
               wRC = ESCCloseChannel(lppd,lpInData,lpOutData);
               VMEnable(lppd);
              break;

              case SETGDIXFORM:
               wRC = ESCSetGDIXForm(lppd,lpInData,lpOutData);
              break;

              case RESETPAGE:
               wRC = ESCResetPage(lppd,lpInData,lpOutData);
              break;

             case POSTSCRIPT_PASSTHROUGH:
#if 0
               // For 16 bit 3.1 apps, always call ESCPostScriptPass
               // Otherwise call it only if openchannel has been called.
               if (lppd->job.bfESCOpenChannel ||
                   ((GetProcessDword(NULL, GPD_FLAGS) &
                   GPF_WIN16_PROCESS) &&
                   (GetProcessDword(NULL, GPD_EXP_WINVER) < 0x0400)))
               {
                   wRC = ESCPostScriptPass(lppd,lpInData,lpOutData);
               }
               else
                   wRC = ESCPassThrough(lppd, lpInData, lpOutData);
#else
               // App hack for Photoshop 3.0 - 32bit NT version.
               // They should have called ESCPassThrough - simulate it.
               if (!(GetProcessDword(NULL, GPD_FLAGS) & GPF_WIN16_PROCESS) &&
                   (GetAppCompatFlags(0) & GACF_FORCEREGPASSTHRU))
               {
                   wRC = ESCPassThrough(lppd, lpInData, lpOutData);
               }
               else
               {
                  wRC = ESCPostScriptPass(lppd,lpInData,lpOutData);
               }
#endif
              break;

              case RESETDC:
               wRC = ESCResetDC(lppd,(LPPDEVICE)lpInData);
              break;

              // Special Passthrough, 5-1-1995
              case SPCLPASSTHROUGH:  // kept for AdobePS 3.01's backward compatible
               wRC = ESCSpecialPass(lpDevice, lpInData, lpOutData);
               break;
            
              case SPCLPASSTHROUGH2:  // callable by multiple times - new ID to diff from 3.0.1
               // In this case, the first 4 bytes is a DWORD to sepcify vmUsage.
               lppd->vmUsedPreStartDoc += (float) *((LPDWORD)lpInData) ;
               wRC = ESCSpecialPass(lpDevice, (LP)((LPBYTE)lpInData+sizeof(DWORD)), lpOutData);
               break;

#ifndef MICROSOFT_DRIVER_VERSION
           case SPCLPSINJECTION:   // callable by multiple times      new ID for 4.2
                  // The first 4 bytes is a DWORD to sepcify length of PSData
                  wRC = ESCPSInjection(lpDevice, lpInData, lpOutData);
               break;

            
              case DOWNLOADFACESTR:  // send the string for Next (Incremental) Escape(DOWNLOADFACE), added 11-27-95
               wRC = ESCDownLoadFaceStr(lpDevice,lpInData,lpOutData);
               break;
#endif
              default:
               wRC = 0;        // not implemented
              break;
            }
        }
        else
        {   // if (fEnabled...) ... else
              // i.e. we are being called at an illegal time.
            wRC = (WORD)-1;   // Return a general "failure" code.
        }

        if(lppd->wSpoolError < 0  &&  lppd->wSpoolError > -6)
          return(lppd->wSpoolError) ;
    }

    return(wRC);
}
