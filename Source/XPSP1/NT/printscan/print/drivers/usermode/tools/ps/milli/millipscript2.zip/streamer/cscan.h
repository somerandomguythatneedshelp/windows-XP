/* CM_VerSion cscan.h atm05 1.5 10796.eco sum= 52034 */
/* CM_VerSion cscan.h atm04 1.3 04398.eco sum= 03284 */
/*
  cscan.h -- interface to intelligent center-scan fill

Copyright (c) 1991-1993 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of
Adobe Systems Incorporated.  Many of the intellectual and
technical concepts contained herein are proprietary to Adobe,
are protected as trade secrets, and are made available only to
Adobe licensees for their internal use.  Any reproduction or
dissemination of this software is strictly forbidden unless
prior written permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks of
Adobe Systems Incorporated.

Original version: Craig Rublee June 28, 1991
Edit History:
Paul Haahr: Fri Apr 10 12:38:10 1992
Craig Rublee: Thu Nov  4 18:13:45 PST 1993
End Edit History.

*/

#ifndef	CSCAN_H
#define	CSCAN_H

/* CScanArgs -- Argument to ResetCScan  and FixedFltn */
typedef struct {
  void    *pClientHook;	/* this must be first. coordinate with t1interp.h */
  boolean fixupOK;	/* Do "fixup" (white connectivity) if appropriate */
  boolean locking;	/* Some part of the char may be "locked" in fontbuild */
  boolean offsetCenterFill;	/* True: do offset-center algorithm */
  Fixed len1000;	/* Approximation of point size */
  Fixed idealwidth;	/* Actual stem width */
  DevBBoxRec *clipBBox;	/* if not NULL, rectangle to clip to */
  Fixed     flatness;
  PathProcs *path; 
} CScanArgs, *PCScanArgs;

/*
 * cscan procedures
 *	IniCScan -- called at the dawn of time
 *	ResetCScan -- called once per character
 *	CSNewPoint -- moveto operation
 *	CSNewLine -- lineto operation
 *	CSClose -- closepath
 *	CScan -- endchar and rasterize
 */

extern procedure IniCScan ARGDECL1(PGrowableBuffer, pCrossBuf);
extern procedure ResetCScan ARGDECL1(PCScanArgs, resetArgs);
extern procedure CSNewPoint ARGDECL2(FCd *, pc, PCScanArgs, arg);
extern procedure CSNewLine ARGDECL2(FCd *, pc, PCScanArgs, arg);
extern procedure CSClose ARGDECL1(PCScanArgs, arg);
extern IntX CScan ARGDECL4(
  RunRec  *, runData, 
  FCdBBox *, charBBox,
  PBCProcs , bcprocs,
  void    *, pClientHook
  );

/*
 * the fixed-point flattener
 */

extern procedure FixedFltn ARGDECL5(FCd *, pc0, FCd *, pc1, FCd *, pc2, FCd *, pc3,
				    PCScanArgs , arg);

/*
 * from bcruns.c
 */

extern IntX ConvertBitMap 
  ARGDECL4(
    BitMapRec *, pBitMap,
    RunRec *, pRun, 
    BCProcs *, procs,
    void    *, pClientHook
   );
extern IntX ConvertRuns 
  ARGDECL4(
    RunRec *, pRun, 
    BitMapRec *, pBitMap, 
    BCProcs *, procs,
    void    *, pClientHook
  );
extern IntX MergeRuns 
  ARGDECL7(
    DevRun *, run1, 
    DevRun *, run2,  
    IntX, xOffset, 
    IntX, yOffset,
    RunRec *, dest, 
    BCProcs *, procs,
    void    *, pClientHook
  );

#endif /* CSCAN_H */
