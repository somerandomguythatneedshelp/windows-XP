/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: CESCAPES.C                                                   */
/*                                                                           */
/* Description: This module contains ...                                     */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_TESCAPESSEG)


#if 0

short FAR PASCAL CCTMRestore(LPPDEVICE lppd)
{

        return(TRUE);
}
short FAR PASCAL CCTMSave(LPPDEVICE lppd)
{
        return(TRUE);
}
short FAR PASCAL CCTMTransform(LPPDEVICE lppd)
{
        return(TRUE);
}

#endif


short FAR PASCAL CDocumentBegin(LPPDEVICE lppd)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   CInitPen(lppd);                                       // Initialize pen
   CInitBrush(lppd);                                     // Initialize brush
    // Could be NULL if we failed AllocTranslateLayerData()
   if (tempptr && tempptr->rTDocumentBegin)  
       (*tempptr->rTDocumentBegin)(lppd);  // Execute proper T function

  return(TRUE);
}

/*****************************************************************************
*                               CDocumentAbort
*  function:
*       sends a token to abort the current document.
*  prototype:
*       short FAR PASCAL CDocumentAbort(LPPDEVICE lppd);
*  paremeters:
*       LPPDEVICE lppd -- pdevice passed in
*  returns:
*       short RC_ok => success, RC_fail => failure
*****************************************************************************/

short FAR PASCAL CDocumentAbort(LPPDEVICE lppd)
    {
    short retval;
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
    if (tempptr && tempptr->rTDocumentAbort)
        retval = (*tempptr->rTDocumentAbort)(lppd);  // Execute proper T function

    return(retval);
    }

/*****************************************************************************
*                               CDocumentEnd
*  function:
*       sends a token to end the current document.
*  prototype:
*       short FAR PASCAL CDocumentEnd(LPPDEVICE lppd);
*  paremeters:
*       LPPDEVICE lppd -- pdevice passed in
*  returns:
*       short RC_ok => success, RC_fail => failure
*****************************************************************************/

short FAR PASCAL CDocumentEnd(LPPDEVICE lppd)
    {
    short retval;
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
    if (tempptr && tempptr->rTDocumentEnd)
        retval = (*tempptr->rTDocumentEnd)(lppd);  // Execute proper T function

    return(retval);
    }


/*****************************************************************************
*                               CSetGDIXForm
*  function:
*       sends a correct CTM for the passthru escape.
*  prototype:
*       short FAR PASCAL CSetGDIXForm(LPPDEVICE lppd);
*  paremeters:
*       LPPDEVICE lppd -- pdevice passed in
*  returns:
*       short RC_ok => success, RC_fail => failure
*****************************************************************************/

short FAR PASCAL CSetGDIXForm(LPPDEVICE lppd)
{
   short retval;
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   retval = (*tempptr->rTSetGDIXForm)(lppd);     // Execute proper T function

   return(retval);
}

/*****************************************************************************
*                               CDownLoadHeader
*  function:
*       sends a token to download the proper header.
*  prototype:
*       short FAR PASCAL CDownLoadHeader(LPPDEVICE lppd, WORD wID);
*  paremeters:
*       LPPDEVICE lppd -- pdevice passed in
*       WORD      wID  -- header ID
*  returns:
*       short RC_ok => success, RC_fail => failure
*****************************************************************************/

short FAR PASCAL CDownLoadHeader(LPPDEVICE lppd, WORD wID)
{
   short retval;
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   retval = (*tempptr->rTDownLoadHeader)(lppd, wID);    // Execute proper T function

   return(retval);
}




/*****************************************************************************
*                               CDocumentFlush
*  function:
*       sends a token to flush any buffered data in the current document.
*  prototype:
*       short FAR PASCAL CDocumentFlush(LPPDEVICE lppd);
*  paremeters:
*       LPPDEVICE lppd -- pdevice passed in
*  returns:
*       short RC_ok => success, RC_fail => failure
*****************************************************************************/

short FAR PASCAL CDocumentFlush(LPPDEVICE lppd)
    {
    short retval;
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
    retval = (*tempptr->rTDocumentFlush)(lppd);             // Execute proper T function

    return(retval);
    }

short FAR PASCAL CDocumentPageBegin(LPPDEVICE lppd)
    {
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
    CInitPen(lppd);                                       // Initialize pen
    CInitBrush(lppd);                                     // Initialize brush
    if (tempptr && tempptr->rTDocumentPageBegin)
        (*tempptr->rTDocumentPageBegin)(lppd);                // Execute proper T function

    return(TRUE);
    }

short FAR PASCAL CDocumentPageEnd(LPPDEVICE lppd)
    {
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
    if (tempptr && tempptr->rTDocumentPageEnd)
        (*tempptr->rTDocumentPageEnd)(lppd);                  // Execute proper T function

    return(TRUE);
    }

short FAR PASCAL CDriverData(LPPDEVICE lppd)
    {
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
    if (tempptr && tempptr->rTDriverData)
        (*tempptr->rTDriverData)(lppd,sizeof(PDEVICE));                // Execute proper T function

    return(TRUE);
    }
/*****************************************************************************
*                               CJobCopies
*  function:
*       sends a token for the number of copies.
*  prototype:
*       short FAR PASCAL CJobCopies(LPPDEVICE lppd, WORD wCopies);
*  paremeters:
*       LPPDEVICE lppd -- pdevice passed into Control
*       WORD wCopies -- number of copies
*  returns:
*       short RC_ok => success, RC_fail => failure
*****************************************************************************/

short FAR PASCAL CJobCopies(LPPDEVICE lppd, WORD wCopies)
    {
    short retval;
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;

    retval = (*tempptr->rTJobCopies)(lppd,wCopies);

    return(retval);
    }

/*****************************************************************
*                       CJobTitle
*  function:
*       creates a token for the job title
*  prototype:
*       short FAR PASCAL CJobTitle(LPPDEVICE lppd, LPSTR szTitle)
*  parameters:
*       LPPDEVICE lppd -- pdevice from control side
*       LPSTR szTitle -- title string -- limited to 64 bytes including null
*  returns:
*       short RC_ok => success, RC_fail => failure
*******************************************************************/

short FAR PASCAL CJobTitle(LPPDEVICE lppd, LPSTR szTitle)
    {
    short retval;
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
    retval = (*tempptr->rTJobTitle)(lppd,szTitle);

    return(retval);
    }

/*****************************************************************
*                       CJobType
*  function:
*       sets the job type -- one of NORMAL or EPS
*  prototype:
*       short FAR PASCAL CJobType(LPPDEVICE lppd, short type)
*  parameters:
*       LPPDEVICE lppd -- pdevice from control side
*       short type -- one of NORMAL or EPS
*  returns:
*       short RC_ok => success, RC_fail => failure
*******************************************************************/

short FAR PASCAL CJobType(LPPDEVICE lppd, short type)
    {
    int retval;
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
    retval = (*tempptr->rTJobType)(lppd,type);
    return(retval);
    }

/*****************************************************************
*                       CJobDuplex
*  function:
*       sets the job duplex type
*  prototype:
*       short FAR PASCAL CJobDuplex(LPPDEVICE lppd, WORD type)
*  parameters:
*       LPPDEVICE lppd -- pdevice from control side
*       WORD type -- 0=>simplex, 1=>vertical, 2=>horizontal
*  returns:
*       short RC_ok => success, RC_fail => failure
*******************************************************************/

short FAR PASCAL CJobDuplex(LPPDEVICE lppd, WORD type)
    {
    int retval;
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
    retval = (*tempptr->rTJobDuplex)(lppd,type);
    return(retval);
    }

/*****************************************************************
*                       CRawPrinterStart
*  function:
*       creates a token which precedes sending raw data to the printer
*       (for PostScript sends a GSAVE)
*  prototype:
*       short FAR PASCAL CRawPrinterStart(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice from control side
*  returns:
*       short RC_ok => success, RC_fail => failure
*******************************************************************/

short FAR PASCAL CRawPrinterStart(LPPDEVICE lppd)
    {
    short retval;
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
    retval = (*tempptr->rTRawPrinterStart)(lppd);
    return(retval);
    }

/*****************************************************************
*                       CRawPrinterData
*  function:
*       creates a token full of raw data to be sent to the printer
*  prototype:
*       short FAR PASCAL CRawPrinterData(LPPDEVICE lppd, LP lpData, WORD nbytes)
*  parameters:
*       LPPDEVICE lppd -- pdevice from control side
*       LP lpData -- pointer to the data
*       WORD nbytes -- # of bytes of data
*  returns:
*       short RC_ok => success, RC_fail => failure
*******************************************************************/

short FAR PASCAL CRawPrinterData(LPPDEVICE lppd,LP lpData,WORD nbytes)
    {
    short retval;
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
    retval = (*tempptr->rTRawPrinterData)(lppd,lpData,nbytes);
    return(retval);
    }

/*****************************************************************
*                       CRawPrinterEnd
*  function:
*       creates a token which follows raw data sent to the printer
*       (in PostScript sends a GRESTORE)
*  prototype:
*       short FAR PASCAL CRawPrinterEnd(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice from control side
*  returns:
*       short RC_ok => success, RC_fail => failure
*******************************************************************/

short FAR PASCAL CRawPrinterEnd(LPPDEVICE lppd)
    {
    short retval;
    LPTFUNCTIONPTRS tempptr;

    tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
    retval = (*tempptr->rTRawPrinterEnd)(lppd);
    return(retval);
    }

/*****************************************************************
*                       CSetScreenAngle
*  function:
*       sends screen angle for color separation
*       
*  prototype:
*       short FAR PASCAL CSetScreenAngle(LPPDEVICE lppd,LP lpInData)
*  parameters:
*       LPPDEVICE lppd -- pdevice from control side
*       LP               lpInData - long pointer to short
*  returns:
*       short  previous screen angle
*******************************************************************/
short FAR PASCAL CSetScreenAngle(LPPDEVICE lppd,LP lpInData)
{ 
      
    short ScreenAngle;
    short OldScreenAngle;

    ScreenAngle    = *(short FAR *)lpInData;
    OldScreenAngle = lppd->sScreenAngle; 
    
    lppd->sScreenAngle = ScreenAngle;

    return(OldScreenAngle);
}

/*****************************************************************
*                       CSetScreenFrequency
*  function:
*       sends screen frequency for color separation
*       
*  prototype:
*       short FAR PASCAL CSetScreenFrequency(LPPDEVICE lppd,LP lpInData)
*  parameters:
*       LPPDEVICE lppd -- pdevice from control side
*       LP               lpInData - long pointer to struct frequency
*       LP        lpOutData - long pointer to old struct frequeny
*  returns:
*       short  previous screen angle
*******************************************************************/

short FAR PASCAL CSetScreenFrequency(LPPDEVICE lppd,LPFREQUENCY lpInData,LPFREQUENCY lpOutData)
{ 
      
        
      // return old value
      if (lpOutData != NULL)
               *lpOutData = lppd->ScreenFrequency;

       // update PDevice
    if (lpInData != NULL)
          lppd->ScreenFrequency = *lpInData;

    return((lpInData) ? TRUE : FALSE);
}


/*****************************************************************
*                       CSetSpread
*  function:
*       sends screen angle for color separation
*       
*  prototype:
*       short FAR PASCAL CSetSpread(LPPDEVICE lppd,LP lpInData)
*  parameters:
*       LPPDEVICE lppd -- pdevice from control side
*       LP               lpInData - long pointer to short
*  returns:
*       short  previous screen angle
*******************************************************************/
short FAR PASCAL CSetSpread(LPPDEVICE lppd,short iSpread)
{ 
      
      short OldSpread;

      // return old spread
    OldSpread = lppd->sSetSpread; 
    
    // update spread value
    lppd->sSetSpread = iSpread;
       
     return(OldSpread);
}



