/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: UIC.C                                                        */
/*                                                                           */
/* Description: This module contains the functions for the UIconstraints     */
/*              Dialog                                                       */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_DIALOGSSEG)

#define UIC_BUFSIZE 2048
#define TAB_POS1    86
#define TAB_POS2    152

void NEAR PASCAL AddToUICList(LPDRIVERINFO lpDrvInfo, HWND hDlg, WORD keyword, 
                              LPSTR buffer, WORD size)
{
    WORD       extra;

    if (keyword <= IND_MEDIATYPEINFO)
    {
        LoadString(ghDriverMod, IDS_BASE_UIC_NAME + keyword, buffer, size);
    }
    else
    {
        KeywordGetKeywordTranslation(&lpDrvInfo->pDev, keyword, buffer, size);
    }

    TruncateToTabStop(hDlg, buffer, TAB_POS1);
    lstrcat(buffer, "\t");
        
    extra = lstrlen(buffer);

    // Get old option translation string
    if (keyword == IND_DUPLEXINGINFO)
    {
        LoadString(ghDriverMod, IDS_BASE_DUPLEX_NAME + 
                   lpDrvInfo->lpUICArray[keyword].wOldOption, 
                   buffer + extra, size - extra);
    }
    else
    {
        KeywordGetOptionTranslation(&lpDrvInfo->pDev, keyword,
                                    lpDrvInfo->lpUICArray[keyword].wOldOption,
                                    buffer + extra, size - extra);
    }

    TruncateToTabStop(hDlg, buffer + extra, TAB_POS2 - TAB_POS1);
    lstrcat(buffer, "\t");

    extra = lstrlen(buffer);
    // Get new option translation string
    if (keyword == IND_DUPLEXINGINFO)
    {
        LoadString(ghDriverMod, IDS_BASE_DUPLEX_NAME + 
                   lpDrvInfo->lpUICArray[keyword].wNewOption, 
                   buffer + extra, size - extra);
    }
    else
    {
        KeywordGetOptionTranslation(&lpDrvInfo->pDev, keyword,
                                    lpDrvInfo->lpUICArray[keyword].wNewOption,
                                    buffer + extra, size - extra);
    }
}


void NEAR PASCAL ShowUICOnScreen(LPDRIVERINFO lpDrvInfo, HWND hDlg)
{
    LPPRINTERINFO lpPrinterInfo;
    int   i, iTabPos[2];
    LPSTR uicbuf;

    uicbuf = (LPSTR)GlobalAllocPtr(GHND, UIC_BUFSIZE);
    if (!uicbuf)
        return;

    /* Display invalid selections */
    if (lpDrvInfo->uiConflict.wMainConstrainer <= IND_MEDIATYPEINFO)
    {
        LoadString(ghDriverMod, IDS_BASE_UIC_NAME + 
                   lpDrvInfo->uiConflict.wMainConstrainer, uicbuf, UIC_BUFSIZE);
    }
    else
    {
        KeywordGetKeywordTranslation(&lpDrvInfo->pDev, 
                                     lpDrvInfo->uiConflict.wMainConstrainer, 
                                     uicbuf, UIC_BUFSIZE);
    }
    SetDlgItemText(hDlg, ID_SELECTION1, uicbuf);
        
    // Get option translation string
    if (lpDrvInfo->uiConflict.wMainConstrainer == IND_DUPLEXINGINFO)
    {
        LoadString(ghDriverMod, IDS_BASE_DUPLEX_NAME + 
                   lpDrvInfo->uiConflict.wOptionConstrainer, 
                   uicbuf, UIC_BUFSIZE);
    }
    else
    {
        KeywordGetOptionTranslation(&lpDrvInfo->pDev, 
                                    lpDrvInfo->uiConflict.wMainConstrainer, 
                                    lpDrvInfo->uiConflict.wOptionConstrainer, 
                                    uicbuf, UIC_BUFSIZE);
    }
    SetDlgItemText(hDlg, ID_OPTION1, uicbuf);

    if (lpDrvInfo->uiConflict.wMainConstrained <= IND_MEDIATYPEINFO)
    {
        LoadString(ghDriverMod, IDS_BASE_UIC_NAME + 
                   lpDrvInfo->uiConflict.wMainConstrained, uicbuf, UIC_BUFSIZE);
    }
    else
    {
        KeywordGetKeywordTranslation(&lpDrvInfo->pDev, 
                                     lpDrvInfo->uiConflict.wMainConstrained, 
                                     uicbuf, UIC_BUFSIZE);
    }
    SetDlgItemText(hDlg, ID_SELECTION2, uicbuf);
        
    // Get option translation string
    if (lpDrvInfo->uiConflict.wMainConstrained == IND_DUPLEXINGINFO)
    {
        LoadString(ghDriverMod, IDS_BASE_DUPLEX_NAME + 
                   lpDrvInfo->uiConflict.wOptionConstrained, 
                   uicbuf, UIC_BUFSIZE);
    }
    else
    {
        KeywordGetOptionTranslation(&lpDrvInfo->pDev, 
                                    lpDrvInfo->uiConflict.wMainConstrained, 
                                    lpDrvInfo->uiConflict.wOptionConstrained, 
                                    uicbuf, UIC_BUFSIZE);
    }
    SetDlgItemText(hDlg, ID_OPTION2, uicbuf);

    if (!lpDrvInfo->bShowIgnore)
    {
        RECT       rc2, rc;
        POINT      pt;

        /*
         * Move Cancel and OK buttons to the right, and remove the Ignore button
         */
        GetWindowRect(GetDlgItem(hDlg, IDIGNORE), &rc);
        DestroyWindow(GetDlgItem(hDlg, ID_IGNORE_OPTION));
        DestroyWindow(GetDlgItem(hDlg, IDIGNORE));

        GetWindowRect(GetDlgItem(hDlg, IDCANCEL), &rc2);
        pt.x = rc.left;
        pt.y = rc.top;
        ScreenToClient(hDlg, &pt);
        MoveWindow(GetDlgItem(hDlg, IDCANCEL), pt.x, pt.y, 
                   rc.right - rc.left, rc.bottom - rc.top, FALSE);

        pt.x = rc2.left;
        pt.y = rc2.top;
        ScreenToClient(hDlg, &pt);
        MoveWindow(GetDlgItem(hDlg, IDOK), pt.x, pt.y, 
                   rc2.right - rc2.left, rc2.bottom - rc2.top, FALSE);

        /*
         * If showing cancel, increase space for string. Cancel string 2 is
         * longer than default string
         */
        if (lpDrvInfo->bShowCancel)
        {
            GetWindowRect(GetDlgItem(hDlg, ID_CANCEL_OPTION), &rc);
            pt.x = rc.left;
            pt.y = rc.top;
            ScreenToClient(hDlg, &pt);
            MoveWindow(GetDlgItem(hDlg, ID_CANCEL_OPTION), pt.x, pt.y, 
                       rc.right - rc.left, 2*(rc.bottom - rc.top), TRUE);
        }
    }

    if (!lpDrvInfo->bShowCancel)
    {
        RECT  rc, rc2;
        POINT pt;

        /* Move OK button to the right and remove the Cancel button */
        GetWindowRect(GetDlgItem(hDlg, IDCANCEL), &rc);
        GetWindowRect(GetDlgItem(hDlg, ID_CANCEL_OPTION), &rc2);
        DestroyWindow(GetDlgItem(hDlg, ID_CANCEL_OPTION));
        DestroyWindow(GetDlgItem(hDlg, IDCANCEL));

        pt.x = rc.left;
        pt.y = rc.top;
        ScreenToClient(hDlg, &pt);
        
        MoveWindow(GetDlgItem(hDlg, IDOK), pt.x, pt.y,
                   rc.right-rc.left, rc.bottom-rc.top, FALSE);

        if (lpDrvInfo->bShowIgnore)
        {
            /* Move text for ignore up */
            GetWindowRect(GetDlgItem(hDlg, ID_IGNORE_OPTION), &rc);
            pt.x = rc2.left;
            pt.y = rc2.top;
            ScreenToClient(hDlg, &pt);
        
            MoveWindow(GetDlgItem(hDlg, ID_IGNORE_OPTION), pt.x, pt.y,
                       rc.right-rc.left, rc.bottom-rc.top, FALSE);
        }
    }
    else 
    {
        /* Show correct instructions */
        LoadString(ghDriverMod, lpDrvInfo->bShowIgnore ? IDS_CANCEL_STRING1 :
                   IDS_CANCEL_STRING2, uicbuf, UIC_BUFSIZE);
        SetDlgItemText(hDlg, ID_CANCEL_OPTION, uicbuf);
    }


    // Fill in the listbox
    iTabPos[0] = TAB_POS1; iTabPos[1] = TAB_POS2;
    SendDlgItemMessage(hDlg, ID_UIC_EDITBOX, EM_SETTABSTOPS, (WPARAM)2,
                       (LPARAM)(int FAR *)&iTabPos[0]);

    lpPrinterInfo = (LPPRINTERINFO)lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;
    uicbuf[0] = '\0';
    for (i=0; (WORD)i<lpPrinterInfo->numMainKeyHdrs; i++)
    {
        if (lpDrvInfo->lpUICArray[i].wOldOption != 
            lpDrvInfo->lpUICArray[i].wNewOption)
        {
            /* Add CR to end of previous line */
            if (uicbuf[0])
                lstrcat(uicbuf, "\r\n");
            AddToUICList(lpDrvInfo, hDlg, i, uicbuf + lstrlen(uicbuf), 
                         UIC_BUFSIZE - lstrlen(uicbuf));
        }
    }
    SetDlgItemText(hDlg, ID_UIC_EDITBOX, uicbuf);
    GlobalFreePtr(uicbuf);
}


/*****************************************************************************/
/*                 CHUICDlg                                                  */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the UIconstraints dialog box.                     */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHUICDlg(HWND hDlg, unsigned imsg, WORD wParam, 
                                 LONG lParam)
{
    LPDRIVERINFO   lpDrvInfo;
    
    switch (imsg)
    {
        case WM_INITDIALOG:
            // Note that since this is a modal dialog, lpDrvInfo is passed
            // directly, rather than via LPPROPSHEETPAGE->lParam.
            lpDrvInfo=(LPDRIVERINFO)lParam;
            
            /* Now initialize the dialog's widgets */
            ShowUICOnScreen(lpDrvInfo, hDlg);
            break ;
            
        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                case IDCANCEL:
                case IDIGNORE:
                    EndDialog(hDlg, wParam) ;
                    break ;

                default:
                    return FALSE;
            } /* switch(wParam) */
            break ;
            
        default:
            return FALSE;
    } /* switch(imsg) */
    
    return TRUE;
} /* End CHUICDlg */
