/*
 * pshrink.c
 *
 * $Header:   L:/PVCS/PS40/PSCRIPT/RESOURCE/PSHRINK.C_V   1.7   27 Mar 1995 11:23:34   olegsher  $
 * 
 * Copyright (c) 1989-1991 Adobe Systems Incorporated.
 * All rights reserved.
 *
 * This file may be freely copied and redistributed as long as:
 *   1) This entire notice continues to be included in the file, 
 *   2) If the file has been modified in any way, a notice of such
 *      modification is conspicuously indicated.
 *
 * PostScript, Display PostScript, and Adobe are registered trademarks of
 * Adobe Systems Incorporated.
 * 
 * ************************************************************************
 * THE INFORMATION BELOW IS FURNISHED AS IS, IS SUBJECT TO CHANGE WITHOUT
 * NOTICE, AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY ADOBE SYSTEMS
 * INCORPORATED. ADOBE SYSTEMS INCORPORATED ASSUMES NO RESPONSIBILITY OR 
 * LIABILITY FOR ANY ERRORS OR INACCURACIES, MAKES NO WARRANTY OF ANY 
 * KIND (EXPRESS, IMPLIED OR STATUTORY) WITH RESPECT TO THIS INFORMATION, 
 * AND EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR PARTICULAR PURPOSES AND NONINFINGEMENT OF THIRD PARTY RIGHTS.
 * ************************************************************************
 *
 * $Log:   L:/PVCS/PS40/PSCRIPT/RESOURCE/PSHRINK.C_V  $
 *- |
 *- |   Rev 1.7   27 Mar 1995 11:23:34   olegsher
 *- |Merged with Microsoft codedrop 03/20/95.
 *- |
 *- |   Rev 1.0   28 Jul 1993 15:08:08   JKEEFE
 *- |Initial revision.
 *- |
 *- |   Rev 3.0   05 Aug 1992 15:38:42   JKEEFE
 *- |Initial revision.
 *- |
 *- |   Rev 1.1   11 Nov 1991 18:04:54   jdlh
 *- |Made mode of output file (text or binary) depend on whether output is ASCII
 *- |or binary.  This has repercussions in terms of cbEOL throughout the code
 *- |which are not fixed.  This is just a hack to permit binary output.
 *- |
 *- |   Rev 1.0   23 Oct 1991 14:45:54   jdlh
 *- |Initial revision.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <limits.h>
#include "encoding.h"

#ifndef DEBUG
#define DEBUG 0
#endif  /*DEBUG*/

/* Functions in this module.
 */
void ParseArguments( int argc, char *argv[] );

char    *psFile = NULL;
char    *tokenFile = NULL;
int  formatSpecified = false;
int  byteOrderSpecified = false;
int  levelSpecified = false;
int  binarySpecified = false;
int  opSpecified = false;
int  countSpecified = false;

unsigned long rgcbIn[SC_MAX], rgcbOut[SC_MAX];

extern int yylex(void);

void FatalError( char *message, ... )
 /*
   Print message with prefix and followed by newline.  Exit indicating error.
  */
{
  va_list args;

  va_start(args, message);
  fprintf (stderr, "pshrink: ");
  vfprintf (stderr, message, args);
  fprintf (stderr, "\n");
  va_end(args);
  exit (1);
}

/* void FatalError (message, arg1, arg2, arg3, arg4)
  char *message;
  int arg1, arg2, arg3, arg4;
{

  fprintf (stderr, "pshrink: ");
  fprintf (stderr, message, arg1, arg2, arg3, arg4);
  fprintf (stderr, "\n");
  exit (1);
}
 */

void ParseArguments (argc, argv)
  int argc;
  char *argv[];
{
  while (--argc > 0) {
    char   *arg = *++argv;

    if (arg[0] == '-') {
      if (arg[2] != (char) NULL)
    FatalError ("Arguments must be single character: %s", arg);
      else {
    switch (arg[1]) {
     case 's':
     case 't':
      if (!opSpecified) {
        if (arg[1] == 's')
          iOperation = OP_STATISTICS;
        else
          iOperation = OP_TOKENSEQ;
        opSpecified = true;
      } else
        FatalError ("%s operation already specified (%s)", 
            ( (iOperation == OP_STATISTICS) ? "Print statistics" : 
                ((iOperation == OP_TOKENSEQ) ? "Print token sequences" : "Unknown")),
            arg);
      break;

     case 'c':
      {

        fKeepDSC = true;
        break;
      }

     case 'g':
      {

        fSubstGeneric = true;
        break;
      }

     case '1':
     case '2':
      if (!levelSpecified) {
        fLevel2 = (arg[1] == '2');
        levelSpecified = true;
      } else
        FatalError ("PostScript(R) language, Level %d, already specified (%s)", 
                    (fLevel2 ? 2 : 1), arg                              );
      break;

     case 'a':
     case 'b':
      if (!binarySpecified) {
        fBinary = (arg[1] == 'b');
        binarySpecified = true;
      } else
        FatalError ("%s format already specified (%s)", 
                    (fBinary ? "Binary" : "ASCII"), arg);
      break;

     case 'i':
     case 'n':
      if (!formatSpecified) {
        ieeeFormat = (arg[1] == 'i');
        formatSpecified = true;
      } else
        FatalError ("%s floating point format already specified (%s)", (ieeeFormat ? "IEEE" : "Native"), arg);
      break;

     case 'h':
     case 'l':
      if (!byteOrderSpecified) {
        highByteFirst = (arg[1] == 'h');
        byteOrderSpecified = true;
      } else
        FatalError ("%s-byte-first already specified (%s).", (highByteFirst ? "High" : "Low"), arg);
      break;

     case 'o':
      if (tokenFile == NULL) {
        if (--argc > 0) {
          tokenFile = *++argv;
          if (*tokenFile == '-')    /* Do not assume "-" begins filename */
        tokenFile = NULL;
        }
        if (tokenFile == NULL)
          FatalError ("Output filename missing (-o).");
      } else
        FatalError ("Only one output file allowed (%s).", tokenFile);
      break;

     case '#':
      if (cTokenSeq == 0) {
        if (--argc > 0) {
          cTokenSeq = atoi(*++argv);
          if ((*tokenFile == '-')    /* Do not assume "-" begins filename */
              || (cTokenSeq == INT_MAX) || (cTokenSeq == INT_MIN))
            cTokenSeq = 0;
        }
        if (cTokenSeq == 0)
          FatalError ("Length of token sequence missing or unreadable (-#).");
      } else
        FatalError ("Only one token sequence length allowed (%d).", cTokenSeq);
      break;

     default:
      fprintf (stderr, "usage: pshrink [-s | -t [-# count]] [-o outputfile] [-{1|2}] [-{a|b}] \n" );
      fprintf (stderr, "          [-c] [-g] [-{i|n}] [-{h|l}] inputfile\n");
      exit (1);

    }
      }
    } else if (psFile == NULL)
      psFile = arg;
    else
      FatalError ("Only one input file allowed (%s).", psFile);
  }

  if (cTokenSeq == 0) 
    cTokenSeq = 2;

#if DEBUG
  fprintf (stderr, "Input: %s, output: %s, operation %s, level %d, %s, \n",
       (psFile == NULL ? "stdin" : psFile),
       (tokenFile == NULL ? "stdout" : tokenFile),
       (iOperation == OP_EMIT ? "emitting" : 
          (iOperation == OP_TOKENSEQ ? "token sequence" : "statistics")),
       (fLevel2 ? 2 : 1),
       (fBinary ? "binary" : "ASCII")  );
  fprintf (stderr, "  DSC %s, token seq. len %d, generic tokens %ssubstituted,\n",
       (fKeepDSC ? "kept" : "discarded"),
       cTokenSeq,
       (fSubstGeneric ? "" : "not ") );
  fprintf (stderr, "  %s byte first, %s floating point.\n",
       (highByteFirst ? "high" : "low"),
       (ieeeFormat ? "IEEE" : "native"));
#endif  /* DEBUG */
}

/* InitStatistics(): initialise the data structures which count statistics.
 */

void InitStatistics(void)
{
    enum StatisticsCategory sc;

    for (sc = SC_FIRST; sc < SC_MAX; sc++) {
       rgcbIn[sc] = rgcbOut[sc] = 0;
    }

}

void PrintStatistics(void)
{
    enum StatisticsCategory sc;
    unsigned long cbSumIn = 0, cbSumOut = 0;

    /* This array contains printable titles for summary table */
    char *rgszSC[SC_MAX] = {
      "Numbers",            // SC_NUMBERS
      "Names",              // SC_NAMES
      "Strings",            // SC_STRINGS
      "DSC Comments",       // SC_DSC
      "Whitespace, filler", // SC_FILLER
      "%%Binary data"       // SC_DATA
    };

    #if DEBUG
        Trace( "\n\n" );    /* To seperate trace from stats */
    #endif
    

    printf("Statistics for file %s:\n", (psFile == NULL) ? "stdin" : psFile );
    printf("%22s      %-14s  %-14s\n", "", "bytes read", "bytes written");
    for (sc = SC_FIRST; sc < SC_MAX; sc++ ) {
        printf("%22s      %9ld       %9ld\n", 
                rgszSC[sc], rgcbIn[sc], rgcbOut[sc]);
        cbSumIn  += rgcbIn [sc];
        cbSumOut += rgcbOut[sc];
    }
    printf("\n%22s      %9ld       %9ld\n", "TOTAL:", cbSumIn, cbSumOut);

    printf("\nAssumption: all newlines are a constant %d bytes.\n", cbEOL);
}

void main (argc, argv)
  int argc;
  char *argv[];
{
  ParseArguments (argc, argv);

  InitParser ();
  InitEncoding ();
  InitStatistics ();

  if (psFile == NULL)
    psFile = "stdin";
  else if (freopen (psFile, "r", stdin) == NULL)
    FatalError ("Failed to open %s for input.", psFile);

  if (tokenFile == NULL)
    tokenFile == "stdout";
  else if (freopen (tokenFile, (fBinary ? "wb" : "w"), stdout) == NULL)
    FatalError ("Failed to open %s for output.", tokenFile);

  while (yylex ());    

  SendEOL();   /* Finish with a newline */

  if (iOperation == OP_STATISTICS) 
    PrintStatistics();

  exit (0);
}
