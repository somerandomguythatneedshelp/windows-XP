/*  parse3.c  - some functions used to load the WPX structures   */

#include  "generic.h"

#pragma code_seg(_PARSE3SEG)

BOOL  FAR   PASCAL  initOpenUIstructs(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable )
{
   WORD   numMainKeyHdrs, i, j , k, curIndex ;
   DWORD  lengthOffset ;
   LPMAINKEYHDR  lpMainKeyHdrs ;
   LPGENERIC_OPTION   lpOptionInfo ;
   BYTE   Buffer[256];  // holds string value for parsing into tokens
   HPBYTE   hpCur ;     
   LPBYTE  lpBuf;      // scratch pointers.
   BOOL   noneNotRead ;


   numMainKeyHdrs  = lpPrinterInfo->numMainKeyHdrs ;
   lpMainKeyHdrs = lpPrinterInfo->mainKeyHdrs  ;


   for( i = IND_NUMPREDEFINEDHDRS ; i < numMainKeyHdrs ; i++)
   {
      LPMAINKEYHDR      lpCurMainKeyHdr ;
      WORD              numOptions , keyword, defaultKeyword, queryKeyword;  

      lpCurMainKeyHdr = lpMainKeyHdrs + i ;

      lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
         lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

      keyword = lpCurMainKeyHdr->MainKeyID ;

      queryKeyword = findQueryAndDefaultKeyword(keyword, &defaultKeyword, 
                                                lpStringTable);

      if(queryKeyword != GARBAGE)
      {
         for(j = 0 ; j < numKeywords ; j++)
         {
            if(lpKeyEntry[j].keyword == queryKeyword)
            {
               if(lpKeyEntry[j].flags & JCLKEYWORD)
                  lpCurMainKeyHdr->OptionQuery.dword = 
                     addQuotedStringToTable(lpKeyEntry[j].value, NULL, 0);
               else
                  lpCurMainKeyHdr->OptionQuery.dword = 
                     addStringToTable(lpKeyEntry[j].value);  // invocations are
               break;                                    // simple strings
            }
         }
      }

      numOptions = 0 ;
      noneNotRead = FALSE;

      if(lpCurMainKeyHdr->UItype == PICKMANY)
      {
         //  always reserve the first slot for NONE option
         //  fills it with invocation string (if any) later.
         //  if selected, UI code must unselect all other options.

         lpOptionInfo[numOptions].OptionKey.dword = 
                     addStringToTable("None");

         lpOptionInfo[numOptions].OptionTranslation.dword = 0L ;
         lpOptionInfo[numOptions].Invocation.dword = 0L ;
         
         numOptions++ ;
         noneNotRead = TRUE;
      }


      for( j = 0 ; j < numKeywords ; j++)
      {
         if(lpKeyEntry[j].keyword != keyword)
            continue ;   //  should drop to end of for loop.
         if(!(hpCur = lpKeyEntry[j].option))  //  missing option keyword
            continue ;   //  should drop to end of for loop.

         if(noneNotRead  &&  !hstrcmp("None", hpCur) )
         {
            curIndex = 0 ;
            noneNotRead = FALSE;
         }
         else
         {
            curIndex = numOptions ;

            for(k = 0 ; k < numOptions ; k++)
            {
               lengthOffset = lpOptionInfo[k].OptionKey.dword ;
               if(!strtblcmp(lengthOffset, lpStringTable, hpCur))
                  break;
            }
            if(k < numOptions)
               continue;   //  this entry has already been added.
         }

         lpOptionInfo[curIndex].OptionKey.dword = 
                     addStringToTable(hpCur);

         lpOptionInfo[curIndex].OptionTranslation.dword =
            addTransStringToTable(lpKeyEntry[j].optionTrans) ;


         //  value is Invocation string 
         hpCur = lpKeyEntry[j].value;
         if(!hpCur)
         {
            errorMsg(INITOPENUISTRUCTS, ERR_OPENUI);
            errorMsg(INITOPENUISTRUCTS, ERR_KEYWORD_HAS_NO_VALUE);
            continue ;   //  should drop to end of for loop.
         }
         if(!(lpKeyEntry[j].bValueQuoted))
         {
            errorMsg(INITOPENUISTRUCTS, ERR_OPENUI);
            errorMsg(INITOPENUISTRUCTS, ERR_EXPCTD_QUOTED_NOT_STRING);
            errorString(hpCur);
            continue ;   //  should drop to end of for loop.
         }

         if(lpKeyEntry[j].flags & JCLKEYWORD)
            lpOptionInfo[curIndex].Invocation.dword = 
               addQuotedStringToTable(hpCur, NULL, 0);
         else
            lpOptionInfo[curIndex].Invocation.dword = 
               addStringToTable(hpCur);  // invocations are

         lpCurMainKeyHdr->flags |= lpKeyEntry[j].flags;

         if(curIndex == numOptions)  // tricky !
            numOptions++ ;
      }

      if(lpCurMainKeyHdr->UItype == BOOLEAN  &&  numOptions != 2)
      {
         errorMsg(INITOPENUISTRUCTS, ERR_OPENUI);
         errorMsg(INITOPENUISTRUCTS, ERR_BOOLEAN_NEEDS_TWO_OPTIONS);
      }

         
      lpCurMainKeyHdr->OptionKeyWords.w.length = numOptions ;


      // ---  set default option here. ---  init to first slot.

      lpCurMainKeyHdr->DefaultOptionIndex = 0 ;

      if(defaultKeyword != GARBAGE)
      {
         for(k = 0 ; k < numKeywords ; k++)
         {
            if(lpKeyEntry[k].keyword == defaultKeyword)
               break;  //   scan for this keyword.  stop at first occurance
         }

         //  if no default found use the default-default: the entry[0]!
         if(k >= numKeywords)
            continue;

         hpCur = lpKeyEntry[k].value;
         if(!hpCur)
         {
            errorMsg(INITOPENUISTRUCTS, ERR_DEFAULTOPENUI);
            errorMsg(INITOPENUISTRUCTS, ERR_KEYWORD_HAS_NO_VALUE);
            continue;
         }
         if((lpKeyEntry[k].bValueQuoted))
         {
            errorMsg(INITOPENUISTRUCTS, ERR_DEFAULTOPENUI);
            errorMsg(INITOPENUISTRUCTS, ERR_EXPCTD_STRING_NOT_QUOTED);
            errorString(hpCur);
            continue;
         }
         hstrcpyn(Buffer, hpCur, 255);
         lpBuf = Buffer;
         lpBuf = extractStringToken(&lpBuf);

         for(j = 0 ; j < numOptions ; j++)
         {
            lengthOffset = lpOptionInfo[j].OptionKey.dword ;
            if(!strtblcmp(lengthOffset, lpStringTable, lpBuf))
            {
               lpCurMainKeyHdr->DefaultOptionIndex = j ;
               break;
            }
         }
      }

   }

   return(TRUE);
}


/* 
if Custom page , Manual feed must adhere to PPD ordering conventions
then I can always just reserve a MainKeyHdr for it
and its only purpose would be to order this Invocation value


SendSetup code must be aware it shouldn't send every command
in the chain, for example either PageSize or PageRegion should be
sent, but not both.  (depends if autoselect is selected).
*/


BOOL  FAR   PASCAL  initOrderDependency(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable )
{
   WORD   numMainKeyHdrs, i, j , k, mainKeyIndex;
   LPMAINKEYHDR  lpMainKeyHdrs ;
   LPGENERIC_OPTION   lpOptionInfo ;

   numMainKeyHdrs  = lpPrinterInfo->numMainKeyHdrs ;
   lpMainKeyHdrs   = lpPrinterInfo->mainKeyHdrs  ;


   lpPrinterInfo->OrderListRoot.ExitServer =
   lpPrinterInfo->OrderListRoot.Prolog =
   lpPrinterInfo->OrderListRoot.Unassigned =  // emit this after pagesetup.
   lpPrinterInfo->OrderListRoot.DocumentSetup =
   lpPrinterInfo->OrderListRoot.PageSetup =
   lpPrinterInfo->OrderListRoot.JCLSetup =  
   lpPrinterInfo->OrderListRoot.AnySetup =  0xFFFF;


   for( i = 0 ; i < numMainKeyHdrs ; i++)
   {
      LPMAINKEYHDR      lpCurMainKeyHdr ;
      WORD              numOptions ;

      lpCurMainKeyHdr = lpMainKeyHdrs + i ;

      lpCurMainKeyHdr->OrderListRoot = 0xFFFF ;
      lpCurMainKeyHdr->order.ArrayIndex = 0xFFFE ;  // uninitialized.

      lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
         lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

      numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

      for(k = 0 ; k < numOptions ; k++)
      {
         lpOptionInfo[k].order.ArrayIndex = 0xFFFE ;  // uninitialized.
         //  PPDorderValue  is meaningless.
      }
   }


   for( i = 0 ; i < numKeywords ; i++)
   {
      long  orderValue ;  // should be using doubles to handle the range!
      DWORD  lengthOffset ;
      SECTION  section ;
      LPMAINKEYHDR      lpCurMainKeyHdr ;
      WORD              numOptions ,  optionIndex;
      HPBYTE   hpCur;
      BYTE   Buffer[256];  // holds string value for parsing into tokens
      LPBYTE  lpBuf, lpTok1 ;      // scratch pointers.

      if(lpKeyEntry[i].keyword != ORDERDEPENDENCY)
         continue ;   //  should drop to end of for loop.

      //  parse value

      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITORDERDEPENDENCY, ERR_ORDERDEPENDENCY);
         errorMsg(INITORDERDEPENDENCY, ERR_KEYWORD_HAS_NO_VALUE);
         return(FALSE);
      }
      if((lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITORDERDEPENDENCY, ERR_ORDERDEPENDENCY);
         errorMsg(INITORDERDEPENDENCY, ERR_EXPCTD_STRING_NOT_QUOTED);
         errorString(hpCur);
         return(FALSE);
      }
      hstrcpyn(Buffer, hpCur, 255);
      lpBuf = Buffer;


      if((lpTok1 = extractStringToken(&lpBuf))  &&
                        convStrToInt(&orderValue, (HPBYTE)lpTok1, 2))
         ;
      else
         continue ;

      if(lpBuf  &&  (lpTok1 = extractStringToken(&lpBuf)) )
      {
         if(!hstrcmp(lpTok1, "ExitServer"))
            section = ATEXITSERVER;
         else if(!hstrcmp(lpTok1, "Prolog"))
            section = PROLOG;
         else if(!hstrcmp(lpTok1, "DocumentSetup"))
            section = DOCSETUP;
         else if(!hstrcmp(lpTok1, "PageSetup"))
            section = PAGESETUP;
         else if(!hstrcmp(lpTok1, "JCLSetup"))
            section = JCLSETUP;
         else if(!hstrcmp(lpTok1, "AnySetup"))
            section = ANYSETUP;
         else
         {
            errorMsg(INITORDERDEPENDENCY, ERR_ORDERDEPENDENCY);
            errorMsg(INITORDERDEPENDENCY, ERR_UNKNOWNSECTION);
            errorString(lpTok1);
            continue ;
         }
      }
      else
         continue ;


      if(lpBuf  &&  (lpTok1 = extractStringToken(&lpBuf)) )
      {
         for( k = 0 ; k < numMainKeyHdrs ; k++)
         {
            lpCurMainKeyHdr = lpMainKeyHdrs + k ;

            lengthOffset = lpCurMainKeyHdr->MainKey.dword ;
            if(!strtblcmp(lengthOffset, lpStringTable, lpTok1+1))
            {
               mainKeyIndex = k ;
               break;    //  MainKeyword matches !  (skip leading *)
            }
         }
         if(k >= numMainKeyHdrs)
            continue ;   //  This keyword isn't supported !
      }
      else
         continue ;

      optionIndex = 0xFFFF ;  // no option specified.

      if(lpCurMainKeyHdr->UItype == PICKMANY   &&  
         lpBuf  &&  (lpTok1 = extractStringToken(&lpBuf)) )
      {
         //  only worry about option ordering in this case

         numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;
         lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
            lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

         for( j = 0 ; j < numOptions ; j++)
         {
            lengthOffset = lpOptionInfo[j].OptionKey.dword ;
            if(!strtblcmp(lengthOffset, lpStringTable, lpTok1))
            {
               optionIndex = j ;
               break;    //  optionKeyword matches !  
            }
         }
      }

      if(lpCurMainKeyHdr->order.ArrayIndex == 0xFFFE)
      {
         LPWORD  lpOrderListRoot ;
         WORD    prevsj  ;

         lpCurMainKeyHdr->order.PPDorderValue = (double)orderValue ;

         // add to the correct root section!

         switch(section)
         {
            case  ATEXITSERVER:
               lpOrderListRoot = &lpPrinterInfo->OrderListRoot.ExitServer ;
               break;
            case  PROLOG:
               lpOrderListRoot = &lpPrinterInfo->OrderListRoot.Prolog ;
               break;
            case  DOCSETUP:
               lpOrderListRoot = &lpPrinterInfo->OrderListRoot.DocumentSetup ;
               break;
            case  PAGESETUP:
               lpOrderListRoot = &lpPrinterInfo->OrderListRoot.PageSetup ;
               break;
            case  JCLSETUP:
               lpOrderListRoot = &lpPrinterInfo->OrderListRoot.JCLSetup ;
               break;
            case  ANYSETUP:
            default:
               lpOrderListRoot = &lpPrinterInfo->OrderListRoot.AnySetup ;
               break;
         }


         j = *lpOrderListRoot ;

         if(j == 0xFFFF  ||  
            (double)orderValue <= lpMainKeyHdrs[j].order.PPDorderValue)
         {
            *lpOrderListRoot = mainKeyIndex ;
            lpMainKeyHdrs[mainKeyIndex].order.ArrayIndex = j ;
         }
         else
         {
            prevsj = *lpOrderListRoot ;
            j = lpMainKeyHdrs[prevsj].order.ArrayIndex ;

            while (1)
            {
               if(j == 0xFFFF  || 
                  (double)orderValue <= lpMainKeyHdrs[j].order.PPDorderValue)
               {
                  lpMainKeyHdrs[prevsj].order.ArrayIndex = mainKeyIndex ;
                  lpMainKeyHdrs[mainKeyIndex].order.ArrayIndex = j ;
                  break;
               }
            
               prevsj = j ;
               j = lpMainKeyHdrs[prevsj].order.ArrayIndex ;
            }
         }

      }
      if(optionIndex != 0xFFFF  &&
         lpOptionInfo[optionIndex].order.ArrayIndex == 0xFFFE)
         //  this option needs to be ordered.
      {
         WORD   prevsj ;

         lpOptionInfo[optionIndex].order.PPDorderValue = 
                     (double)orderValue ;

         //  addoptiontolist(); 

         j = lpCurMainKeyHdr->OrderListRoot ;

         if(j == 0xFFFF  ||  
            (double)orderValue <= lpOptionInfo[j].order.PPDorderValue)
         {
            lpCurMainKeyHdr->OrderListRoot = optionIndex ;
            lpOptionInfo[optionIndex].order.ArrayIndex = j ;
         }
         else
         {
            prevsj = lpCurMainKeyHdr->OrderListRoot ;
            j = lpOptionInfo[prevsj].order.ArrayIndex ;

            while (1)
            {
               if(j == 0xFFFF  || 
                  (double)orderValue <= lpOptionInfo[j].order.PPDorderValue)
               {
                  lpOptionInfo[prevsj].order.ArrayIndex = optionIndex ;
                  lpOptionInfo[optionIndex].order.ArrayIndex = j ;
                  break;
               }
            
               prevsj = j ;
               j = lpOptionInfo[prevsj].order.ArrayIndex ;
            }
         }
      }

   }

   //  link all unresolved references:


   for( i = 0 ; i < numMainKeyHdrs ; i++)
   {
      LPMAINKEYHDR      lpCurMainKeyHdr ;
      WORD              numOptions ;

      lpCurMainKeyHdr = lpMainKeyHdrs + i ;

      //  add node to Unassigned list.

      if(lpCurMainKeyHdr->order.ArrayIndex == 0xFFFE)
      {
         if(lpCurMainKeyHdr->flags & JCLKEYWORD)
         {
            // add to end of JCL list
            LPWORD  lpOrderListRoot ;
            WORD    prevsj  , j;

            lpOrderListRoot = &lpPrinterInfo->OrderListRoot.JCLSetup ;

            j = *lpOrderListRoot ;

            if(j == 0xFFFF)
            {
               *lpOrderListRoot = i ;
               lpMainKeyHdrs[i].order.ArrayIndex = j ;
            }
            else
            {
               prevsj = *lpOrderListRoot ;
               j = lpMainKeyHdrs[prevsj].order.ArrayIndex ;

               while (1)
               {
                  if(j == 0xFFFF)
                  {
                     lpMainKeyHdrs[prevsj].order.ArrayIndex = i ;
                     lpMainKeyHdrs[i].order.ArrayIndex = j ;
                     break;
                  }
            
                  prevsj = j ;
                  j = lpMainKeyHdrs[prevsj].order.ArrayIndex ;
               }
            }
         }
         else   // add to start of Unassigned list.
         {
            lpCurMainKeyHdr->order.ArrayIndex = 
               lpPrinterInfo->OrderListRoot.Unassigned ;
            lpPrinterInfo->OrderListRoot.Unassigned = i ;
         }
      }

      if(lpCurMainKeyHdr->UItype != PICKMANY)
         continue ;


      lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
         lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

      numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

      for(k = 0 ; k < numOptions ; k++)
      {
         if(lpOptionInfo[k].order.ArrayIndex == 0xFFFE)
         {
            lpOptionInfo[k].order.ArrayIndex = 
               lpCurMainKeyHdr->OrderListRoot ;
            lpCurMainKeyHdr->OrderListRoot = k ;
         }
      }
   }

   //  reassign all AnySetup sections to either Page or DocumentSetup

   while((mainKeyIndex = lpPrinterInfo->OrderListRoot.AnySetup) != 0xFFFF)
   {
      LPMAINKEYHDR      lpCurMainKeyHdr ;
      WORD              prevsj;
      double  orderValue ;
      LPWORD  lpOrderListRoot ;

      lpCurMainKeyHdr = lpMainKeyHdrs + mainKeyIndex ;

      lpPrinterInfo->OrderListRoot.AnySetup =
            lpCurMainKeyHdr->order.ArrayIndex ;

      orderValue = lpCurMainKeyHdr->order.PPDorderValue ;

#if 0
      // place all anysetups into page setup regardless
      // to allow ResetDC the greatest chance of success
      //  see bug #11525.   

      //  Adobe thinks this is too slow.  Revert to previous
      //  behavior.

      lpOrderListRoot = &lpPrinterInfo->OrderListRoot.PageSetup ;

#else

      lpOrderListRoot = &lpPrinterInfo->OrderListRoot.DocumentSetup ;

      if((j = lpPrinterInfo->OrderListRoot.PageSetup) != 0xFFFF)
      {
         lpCurMainKeyHdr = lpMainKeyHdrs + j ;
         if( orderValue > lpCurMainKeyHdr->order.PPDorderValue )
            lpOrderListRoot = &lpPrinterInfo->OrderListRoot.PageSetup ;
      }
#endif

      j = *lpOrderListRoot ;

      if(j == 0xFFFF  ||  
         orderValue <= lpMainKeyHdrs[j].order.PPDorderValue)
      {
         *lpOrderListRoot = mainKeyIndex ;
         lpMainKeyHdrs[mainKeyIndex].order.ArrayIndex = j ;
      }
      else
      {
         prevsj = *lpOrderListRoot ;
         j = lpMainKeyHdrs[prevsj].order.ArrayIndex ;

         while (1)
         {
            if(j == 0xFFFF  || 
               orderValue <= lpMainKeyHdrs[j].order.PPDorderValue)
            {
               lpMainKeyHdrs[prevsj].order.ArrayIndex = mainKeyIndex ;
               lpMainKeyHdrs[mainKeyIndex].order.ArrayIndex = j ;
               break;
            }
         
            prevsj = j ;
            j = lpMainKeyHdrs[prevsj].order.ArrayIndex ;
         }
      }
   }

   removeZeroOptions(lpPrinterInfo, lpOptionsBlock, 
         &lpPrinterInfo->OrderListRoot.ExitServer) ;

   removeZeroOptions(lpPrinterInfo, lpOptionsBlock, 
         &lpPrinterInfo->OrderListRoot.Prolog) ;

   removeZeroOptions(lpPrinterInfo, lpOptionsBlock, 
         &lpPrinterInfo->OrderListRoot.Unassigned) ;

   removeZeroOptions(lpPrinterInfo, lpOptionsBlock, 
         &lpPrinterInfo->OrderListRoot.DocumentSetup) ;

   removeZeroOptions(lpPrinterInfo, lpOptionsBlock, 
         &lpPrinterInfo->OrderListRoot.PageSetup) ;

   removeZeroOptions(lpPrinterInfo, lpOptionsBlock, 
         &lpPrinterInfo->OrderListRoot.JCLSetup) ;


   return(TRUE);
}


void  FAR   PASCAL     removeZeroOptions(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock,
LPWORD     lpSection)
{
   WORD   numOptions , prevsNode , Node;
   LPMAINKEYHDR  lpMainKeyHdrs , lpCurMainKeyHdr ;
   // don't pass MainKeyHdrs that have zero options to the driver
   // the driver can't do anything with them.  So filter them out 
   //  here.

   lpMainKeyHdrs   = lpPrinterInfo->mainKeyHdrs  ;

   Node = *lpSection;

   while(Node != 0xFFFF)
   {
      lpCurMainKeyHdr = lpMainKeyHdrs + Node ;
      numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;
      if(!numOptions)
      {   // remove this node from the list
         if(Node == *lpSection)  // first node
         {
            Node = *lpSection = lpCurMainKeyHdr->order.ArrayIndex ;
         }
         else
         {
            Node = (lpMainKeyHdrs + prevsNode)->order.ArrayIndex =
                  lpCurMainKeyHdr->order.ArrayIndex ;
            //  prevsNode remains unchanged.
         }
         continue ;
      }
      prevsNode = Node ;
      Node = lpCurMainKeyHdr->order.ArrayIndex ;
   }
}


// ignore keyword-value constraints unless special case
// processing code is provided.
// assumes no option keyword may start with * !

BOOL  FAR   PASCAL  initUIConstraints(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable )
{
   WORD   numMainKeyHdrs, i, k;
   LPMAINKEYHDR  lpMainKeyHdrs ;
   LPGENERIC_OPTION   lpOptionInfo ;
   WORD              numOptions ;

   numMainKeyHdrs  = lpPrinterInfo->numMainKeyHdrs ;
   lpMainKeyHdrs   = lpPrinterInfo->mainKeyHdrs  ;

   curConstraint = 0 ;


   //  initialize all constraints to none.

   for( i = 0 ; i < numMainKeyHdrs ; i++)
   {
      LPMAINKEYHDR      lpCurMainKeyHdr ;

      lpCurMainKeyHdr = lpMainKeyHdrs + i ;

      lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
         lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

      numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

      for(k = 0 ; k < numOptions ; k++)
      {
         lpOptionInfo[k].UIconstraintIndex = 0xFFFF ;  // no constraints
      }
   }


   if(bAutoSelect)
   {
      WORD  numEntries ;
      LPMAINKEYHDR  lpPaperInfoHdr, lpInputSlotInfoHdr ;
      LPGENERIC_OPTION  lpPaperInfo, lpInputSlotInfo;

      //  paper sizes lacking PageSize invocations
      //  cannot use AutoSelect (for example Customsize)
      //  Constrain them accordingly.


      lpPaperInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;
      lpInputSlotInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;

      lpPaperInfo = (LPGENERIC_OPTION)MAKELONG(
                           lpPaperInfoHdr->OptionKeyWords.w.offset, 
                           HIWORD(lpOptionsBlock));

      lpInputSlotInfo = (LPGENERIC_OPTION)MAKELONG(
                        lpInputSlotInfoHdr->OptionKeyWords.w.offset, 
                        HIWORD(lpOptionsBlock) );

      numEntries = lpPaperInfoHdr->OptionKeyWords.w.length  ;

      for(i = 0 ; i < numEntries ; i++)
      {
         if(i == lpPrinterInfo->devcaps.CustomPageSize)
            continue ;

         if(! HIWORD(lpPaperInfo[i].Invocation.dword))
         {
            lpPaperInfo[i].UIconstraintIndex = 
               addConstraint(lpPaperInfo[i].UIconstraintIndex, 
                              IND_INPUTSLOTINFO, 0);

            //  reciprocate the constraint.

            lpInputSlotInfo[0].UIconstraintIndex = 
               addConstraint(lpInputSlotInfo[0].UIconstraintIndex, 
                              IND_PAPERINFO, i);
         }
      }
   }

   //  read customsize and manual feed constraints from PPD file
   //  if any.  -  postpone for later.

/* -----
   4 possible syntaxes:
   *UIConstraints:  *MainKeyA  OptionM  *MainKeyB OptionN

   add to optionM's UI list a reference to *MainKeyB OptionN

   *UIConstraints:  *MainKeyA  OptionM  *MainKeyB 

   add to optionM's UI list a reference to all options for *MainKeyB
     except none or false.  a special value can be used to denote.

   *UIConstraints:  *MainKeyA  *MainKeyB OptionN

   add to every option under MainKeyA except none or false
      references to  *MainKeyB OptionN.


   *UIConstraints:  *MainKeyA  *MainKeyB 

   add to every option under MainKeyA except none or false
   a reference to all options for *MainKeyB
     except none or false.  a special value can be used to denote.
--------*/

   for( i = 0 ; i < numKeywords ; i++)
   {
      #define APPLY_ALL_EXCEPT_NONE_FALSE -1
      #define APPLY_ALL_EXCEPT_MANUAL_FEED 9999

      LPMAINKEYHDR      lpCurMainKeyHdr ;
      DWORD   lengthOffset ;
      HPBYTE   hpCur;
      BYTE   Buffer[256];  // holds string value for parsing into tokens
      LPBYTE  lpBuf, lpTok1 ;      // scratch pointers.
      WORD    MainConstrainer, OptionConstrainer,
              MainConstrainee;
      int     OptionConstrainee;
      LPGENERIC_OPTION   lpConstraineeOptionInfo ;


      if(lpKeyEntry[i].keyword != UICONSTRAINT)
         continue ;   //  should drop to end of for loop.
      
      //  parse value

      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITUICONSTRAINTS, ERR_UICONSTRAINT);
         errorMsg(INITUICONSTRAINTS, ERR_KEYWORD_HAS_NO_VALUE);
         return(FALSE);
      }
      if((lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITUICONSTRAINTS, ERR_UICONSTRAINT);
         errorMsg(INITUICONSTRAINTS, ERR_EXPCTD_STRING_NOT_QUOTED);
         errorString(hpCur);
         return(FALSE);
      }
#if 0
      hstrcpyn(Buffer, hpCur, 255);
#else
      {
         BYTE   tBuffer[256];   // compose new constraint string
         LPBYTE   lpTok[4] ;
         WORD   index ;
         LPMAINKEYHDR      lpInputSlotInfoHdr ;

         hstrcpyn(tBuffer, hpCur, 255);
         lpBuf = tBuffer ;

         lpTok[0] = lpTok[1] = lpTok[2] = lpTok[3] = NULL ;

         // read in all tokens from tBuffer

         for(index = 0 ; (index < 4) && lpBuf; index++)
         {
            lpTok[index] = extractStringToken(&lpBuf) ;
         }

         for(index = 0 ; (index < 3) && lpTok[index]; index++)
         {
            if(!lstrcmp(lpTok[index], "*ManualFeed" ))  // use strtblcmp()
            {
               if(!lstrcmp(lpTok[index+1], "True"))  // use strtblcmp()
               {
                  lpTok[index] = "*InputSlot ManualFeed" ;
                  if(lpTok[index+1]  && *lpTok[index+1] != '*')
                     *lpTok[index+1] = '\0' ;  // null out!
                  break ;
               }
               else
               if(!lstrcmp(lpTok[index+1], "False"))  // use strtblcmp()
               {
                  lpTok[index] = "*InputSlot" ;
                  // assume InputSlot does not have None/False option
                  lpInputSlotInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;
                  if(lpInputSlotInfoHdr->NoneOptionIndex == 0xFFFF )
                     lpInputSlotInfoHdr->NoneOptionIndex = APPLY_ALL_EXCEPT_MANUAL_FEED;

                  *lpTok[index+1] = '\0' ;  // null out!
                  break ;
               }

            }
            if(!lstrcmp(lpTok[index], "*InstalledMemory") && 
                lpPrinterInfo->PrinterSticky.w.length > 0)    //Installable Option
            {
                  lpTok[index] = "*VMOption" ;
            }

         }

         Buffer[0] = '\0' ;  // null out before catting.

         for(index = 0 ; index < 4  &&  lpTok[index] ; index++)
         {

            lstrcat(Buffer, lpTok[index]);
            lstrcat(Buffer, " ");
         }
      }

#endif

      lpBuf = Buffer;

      MainConstrainer = OptionConstrainer =
            MainConstrainee = OptionConstrainee = 0xFFFF;  // uninitialized

      if(lpTok1 = extractStringToken(&lpBuf)) 
      {
         //  extract constrainer's MainKeyword.

         for( k = 0 ; k < numMainKeyHdrs ; k++)
         {
            lpCurMainKeyHdr = lpMainKeyHdrs + k ;

            lengthOffset = lpCurMainKeyHdr->MainKey.dword ;
            if(!strtblcmp(lengthOffset, lpStringTable, lpTok1+1))
            {
               MainConstrainer = k ;
               break;    //  MainKeyword matches !  (skip leading *)
            }
         }
         if(k >= numMainKeyHdrs)
            continue ;   //  This keyword isn't supported !
      }
      else
         continue ;  // should be unforgiving and return(FALSE);

      if(lpBuf  &&  (lpTok1 = extractStringToken(&lpBuf)) )
      {
         if(*lpTok1 == '*')
         {        // no option keyword exists
            if(lpCurMainKeyHdr->NoneOptionIndex == 0xFFFF )
               continue ;   // can't apply generic constrainer if False or None
                           //  doesn't exist !
            OptionConstrainer = 0xFFFE ;  // for all options except
                                          // 'False' or 'None'
         }
         else
         {
            numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;
            lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
               lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

            for( k = 0 ; k < numOptions ; k++)
            {
               lengthOffset = lpOptionInfo[k].OptionKey.dword ;
               if(!strtblcmp(lengthOffset, lpStringTable, lpTok1))
               {
                  OptionConstrainer = k ;
                  break;    //  optionKeyword matches !  
               }
            }
            if(k >= numOptions)
               continue ;   //  This option doesn't exist.
         }
      }
      else
         continue ;  // should be unforgiving and return(FALSE);

      if(OptionConstrainer == 0xFFFE)
         ;  //  lpTok1 is the Constrainee's MainKeyword and hasn't
            //  yet been parsed.
      else  if(lpBuf  &&  (lpTok1 = extractStringToken(&lpBuf)) )
         ;  //  parse new lpTok1.
      else
         continue ;  // should be unforgiving and return(FALSE);


      for( k = 0 ; k < numMainKeyHdrs ; k++)
      {
         lpCurMainKeyHdr = lpMainKeyHdrs + k ;

         lengthOffset = lpCurMainKeyHdr->MainKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, lpTok1+1))
         {
            MainConstrainee = k ;
            break;    //  MainKeyword matches !  (skip leading *)
         }
      }
      if(k >= numMainKeyHdrs)
         continue ;   //  This keyword isn't supported !


      if(lpBuf  &&  (lpTok1 = extractStringToken(&lpBuf)) )
      {
         numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;
         lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
            lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

         for( k = 0 ; k < numOptions ; k++)
         {
            lengthOffset = lpOptionInfo[k].OptionKey.dword ;
            if(!strtblcmp(lengthOffset, lpStringTable, lpTok1))
            {
               OptionConstrainee = k ;
               break;    //  optionKeyword matches !  
            }
            else if(lpTok1[0] == '\0')      
            {                            
               if ((MainConstrainee == IND_INPUTSLOTINFO) &&
                   (lpCurMainKeyHdr->NoneOptionIndex == APPLY_ALL_EXCEPT_MANUAL_FEED))
               {
                  OptionConstrainee = APPLY_ALL_EXCEPT_MANUAL_FEED ;     
                  lpCurMainKeyHdr->NoneOptionIndex == 0xFFFF; // reset it
               }
               else
                  OptionConstrainee = APPLY_ALL_EXCEPT_NONE_FALSE ;     
               lpConstraineeOptionInfo = lpOptionInfo ;
               break;    //  optionKeyword is empty
            }                               
         }
         if(k >= numOptions)
            continue ;   //  This option doesn't exist.
      }
      else      // no option keyword exists
      {
         if(lpCurMainKeyHdr->NoneOptionIndex == 0xFFFF )
            continue ;   // can't apply generic constraint if False or None
                        //  doesn't exist !
         OptionConstrainee = 0xFFFE ;  // for all options except
                                          // 'False' or 'None'
      }


      //  add this constraint to option list or lists!

      lpCurMainKeyHdr = lpMainKeyHdrs + MainConstrainer ;

      lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
         lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

      if(OptionConstrainer == 0xFFFE)
      {
         numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

         for( k = 0 ; k < numOptions ; k++)
         {
            if(lpCurMainKeyHdr->NoneOptionIndex == k )
               continue ;  // nothing happens
            
            //exclude manualfeed

            if(lpCurMainKeyHdr->NoneOptionIndex == APPLY_ALL_EXCEPT_MANUAL_FEED
               && lpPrinterInfo->devcaps.ManualFeed == k)
               continue;

            lpOptionInfo[k].UIconstraintIndex = 
               addConstraint(lpOptionInfo[k].UIconstraintIndex, 
                              MainConstrainee, OptionConstrainee);
         }
         // reset the setting
         if(lpCurMainKeyHdr->NoneOptionIndex == APPLY_ALL_EXCEPT_MANUAL_FEED)
            lpCurMainKeyHdr->NoneOptionIndex = 0xFFFF;

      }

      else
      {
         if(OptionConstrainee == APPLY_ALL_EXCEPT_MANUAL_FEED)
         {
            // apply to all Except "ManualFeed"
            WORD j;

            for(j=0; j < numOptions; j++)
            {
               lengthOffset = lpConstraineeOptionInfo[j].OptionKey.dword ;
               if(strtblcmp(lengthOffset, lpStringTable, "ManualFeed"))
               {
                  OptionConstrainee = j ;
                  lpOptionInfo[OptionConstrainer].UIconstraintIndex = 
                  addConstraint(lpOptionInfo[OptionConstrainer].UIconstraintIndex, 
                              MainConstrainee, OptionConstrainee);
               }
            }

         }
         if(OptionConstrainee == APPLY_ALL_EXCEPT_NONE_FALSE)
         {
            // apply to all Except "None" and "False"
            WORD j;

            for(j=0; j < numOptions; j++)
            {
               lengthOffset = lpConstraineeOptionInfo[j].OptionKey.dword ;
               if(strtblcmp(lengthOffset, lpStringTable, "None")
                  && strtblcmp(lengthOffset, lpStringTable, "False"))
               {
                  OptionConstrainee = j ;
                  lpOptionInfo[OptionConstrainer].UIconstraintIndex = 
                  addConstraint(lpOptionInfo[OptionConstrainer].UIconstraintIndex, 
                              MainConstrainee, OptionConstrainee);
               }
            }
         }
         else
         {
            lpOptionInfo[OptionConstrainer].UIconstraintIndex = 
               addConstraint(lpOptionInfo[OptionConstrainer].UIconstraintIndex, 
                              MainConstrainee, OptionConstrainee);
         }
      }
   }
    
   return(TRUE);
}


BOOL  FAR   PASCAL     initJCLinfo(LPJCLINFO  lpJCLinfo)
{
   WORD  i ;
   HPBYTE   hpCur ;     



   lpJCLinfo->JCLBegin.dword =
   lpJCLinfo->JCLToPSInterpreter.dword =
   lpJCLinfo->JCLEnd.dword = 0L ;


   for( i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == JCLBEGIN)
      {
         if(lpJCLinfo->JCLBegin.dword)
            continue ;  // already initialized.

         //  value is Invocation string 
         hpCur = lpKeyEntry[i].value;
         if(!hpCur)
            continue ;   //  should drop to end of for loop.

         if(!(lpKeyEntry[i].bValueQuoted))
            continue ;   //  should drop to end of for loop.

         lpJCLinfo->JCLBegin.dword = 
            addQuotedStringToTable(hpCur, NULL, 0) ;
      }
      else  if(lpKeyEntry[i].keyword == JCLTOPS)
      {
         if(lpJCLinfo->JCLToPSInterpreter.dword)
            continue ;  // already initialized.

         //  value is Invocation string 
         hpCur = lpKeyEntry[i].value;
         if(!hpCur)
            continue ;   //  should drop to end of for loop.

         if(!(lpKeyEntry[i].bValueQuoted))
            continue ;   //  should drop to end of for loop.

         lpJCLinfo->JCLToPSInterpreter.dword = 
            addQuotedStringToTable(hpCur, NULL, 0) ;
      }
      else  if(lpKeyEntry[i].keyword == JCLEND)
      {
         if(lpJCLinfo->JCLEnd.dword)
            continue ;  // already initialized.

         //  value is Invocation string 
         hpCur = lpKeyEntry[i].value;
         if(!hpCur)
            continue ;   //  should drop to end of for loop.

         if(!(lpKeyEntry[i].bValueQuoted))
            continue ;   //  should drop to end of for loop.

         lpJCLinfo->JCLEnd.dword = 
            addQuotedStringToTable(hpCur, NULL, 0) ;
      }
   }  


   //  if still not initialized, use hard coded defaults

   if(!lpJCLinfo->JCLBegin.dword)
   {
      lpJCLinfo->JCLBegin.dword = 
            addQuotedStringToTable("<1B>%-12345X@PJL JOB<0A>", NULL, 0) ;
   }
   if(!lpJCLinfo->JCLToPSInterpreter.dword)
   {
      lpJCLinfo->JCLToPSInterpreter.dword = 
            addQuotedStringToTable("@PJL ENTER LANGUAGE=POSTSCRIPT<0A>",
                                    NULL, 0) ;
   }
   if(!lpJCLinfo->JCLEnd.dword)
   {
      lpJCLinfo->JCLEnd.dword = 
            addQuotedStringToTable("<1B>%-12345X@PJL EOJ<0A><1B>%-12345X", 
                                    NULL, 0) ;
   }

   return(TRUE);
}


BOOL FAR PASCAL SupportedEncoding(LPBYTE lpEncoding )
{
    WORD wstrlen;

    wstrlen = lstrlen(lpEncoding);

    // Throw away what we don't need.
    // This is the list that we know for sure the "Encoding" we don't need.
    // There might be more to add to the list though.
    // The space char at the end of the each encoding string is to make sure 
    // that we don't throw away the future new encodeings which might start 
    // with those encodings. e.g. Hxxxx-xxxx 
    if (!lstrcmpn(lpEncoding,"EUC ",4))       // older Composite fonts encoding
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"JIS ",4))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"78-H ",5)) // Jananese CID-keyed fonts encoding 
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"78-V ",5))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"78-EUC-H ",9))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"78-EUC-V ",9))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"Add-H ",6))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"Add-V ",6))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"Ext-H ",6))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"Ext-V ",6))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"EUC-H ",6))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"EUC-V ",6))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"Hankaku ",8))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"Hiragana ",9))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"Katakana ",9))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"Roman ",6))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"WP-Symbol ",10))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"H ",2))
        return(FALSE);
    else if (!lstrcmpn(lpEncoding,"V ",2))
        return(FALSE);

    return (TRUE);
}

BOOL  FAR  PASCAL     IsMinchoOrGothic(
LPBYTE   lpFontname )
{
   switch(*lpFontname)
      {
      case  'R':
         return !lstrcmpn(lpFontname,"Ryumin-Light",12);
      case  'G':
         return !lstrcmpn(lpFontname,"GothicBBB-Medium",16);
      }
   return FALSE;
}
#define LEN_83PV 11 // "83pv-RKSJ-H"
BOOL  FAR  PASCAL     IsDBCSPFont(
LPBYTE   lpFontname )
{
    WORD wstrlen;

    wstrlen = lstrlen(lpFontname);
    if (!lstrcmpn((LPSTR)(lpFontname+wstrlen-LEN_83PV),"83pv",4))
        return TRUE;
    
    return FALSE;
}
#define LEN_90MS 11 // "90ms-RKSJ-H"
#define LEN_RKSJ 6  // "RKSJ-H"
BOOL FAR PASCAL Is90ms(
LPBYTE lpFontname)
{
    WORD wstrlen;

    wstrlen = lstrlen(lpFontname);
    if (!lstrcmpn((LPSTR)(lpFontname+wstrlen-LEN_90MS),"90ms",4))
        return TRUE;
    
    return FALSE;
}

BOOL FAR PASCAL IsRKSJ(
LPBYTE lpFontname)
{
    WORD wstrlen;

    wstrlen = lstrlen(lpFontname);
    if (lstrcmpn((LPSTR)(lpFontname+wstrlen-LEN_RKSJ),"RKSJ",4))
        return FALSE;

    if (lstrcmpn((LPSTR)(lpFontname+wstrlen-LEN_90MS),"90ms",4)
    && lstrcmpn((LPSTR)(lpFontname+wstrlen-LEN_83PV),"83pv",4))
        return TRUE;
    return FALSE;
}


BOOL  FAR   PASCAL     initFontList(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable )
{
   LPFONTLIST  lpFontList ;
   DWORD  lengthOffset ;
   WORD  i, j, numEntries ;
   HPBYTE   hpCur ;     

   lpFontList = (LPFONTLIST)MAKELONG(lpPrinterInfo->FontList.w.offset, 
                           HIWORD(lpOptionsBlock));

   //  remove redundant font entries
   for(numEntries = i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword != FONT)
         continue ;   //  should drop to end of for loop.

      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      // if the font encoding is not supported by our driver, don't 
      // bother to save it so we don't waste string table's space
      if(!SupportedEncoding(lpKeyEntry[i].value)) // font encoding is not supported
         continue;    //  should drop to end of for loop.

      for(j = 0 ; j < numEntries ; j++)
      {
         lengthOffset = lpFontList[j].fontname.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, hpCur))
            break;
      }
      if(j < numEntries) //  duplicate option
         continue;   //  this option has already been added.

      // Japanese DBCS Font 90ms(CID Font) support.
      if(IsRKSJ(lpKeyEntry[i].option))
      {
          WORD wlen,k;
          BYTE Buff[64];

          wlen = lstrlen(lpKeyEntry[i].option);
          MemCopy(Buff, lpKeyEntry[i].option, wlen-6);
          MemCopy(&Buff[wlen-6],"90ms-RKSJ-",10);
          Buff[wlen+4] = *(lpKeyEntry[i].option+wlen-1);
          Buff[wlen+5] = NULL;

          for(k = 0 ; k < numKeywords ; k++)
          {
             if(lpKeyEntry[k].keyword == FONT 
             && !lstrcmp(Buff, lpKeyEntry[k].option))
                break;
          }

          if(k < numKeywords)
              continue;
          
      }

      lpFontList[j].fontname.dword =
         addStringToTable(lpKeyEntry[i].option);

      lpFontList[j].version.dword =
         addParenStringToTable(lpKeyEntry[i].value, NULL, 0);


      // Japanese DBCS Prop font support
      if(IsDBCSPFont(lpKeyEntry[i].option))
      {
         lpFontList[j+1].fontname.dword = 
            addStringToTable(lpKeyEntry[i].option);
         numEntries++;
      }
      else
      // Japanese PostScript Printer have to support Mincho and Gothic
      // Family name for RyuminL-KL and GothicBBB.
      if(IsMinchoOrGothic(lpKeyEntry[i].option))
      {
         lpFontList[j+1].fontname.dword =
            addStringToTable(lpKeyEntry[i].option);
         numEntries++;
      }

// --- if need be we can pick up other font info here ----

      numEntries++ ;
   }

   lpPrinterInfo->FontList.w.length = numEntries;

   return InstallPrinterFonts(lpPrinterInfo, lpStringTable, lpOptionsBlock);

}



 
//  this function returns the index of the queryKeyword
//  if found in the lpMainKeyWordsTable - GARBAGE otherwise.
//  the index for the DefaultKeyword is returned in the
//  WORD pointed to by  lpDefaultKeyword.

WORD  FAR   PASCAL  findQueryAndDefaultKeyword(
WORD   baseKeyword,   // index of base Keyword
LPWORD  lpDefaultKeyword, 
LPBYTE  lpStringTable)
{
   BYTE  keyword[MAXKEYLEN+1] ;
   LPBYTE  existingKey ;

   existingKey = StringRefToLP(lpMainKeyWordsTable[baseKeyword]) ;

   lstrcpy(keyword, "*Default");
   lstrcat(keyword, existingKey);
   *lpDefaultKeyword = searchKeywordValue(keyword) ;

   lstrcpy(keyword, "*?");
   lstrcat(keyword, existingKey);

   return(searchKeywordValue(keyword)) ;
}



WORD  NEAR   PASCAL  addConstraint(
WORD  UIconstraintIndex,     //  index to first UI_constraints element in link
WORD  constrainedMainIndex,
WORD  constrainedOptionIndex)
{
   LPUI_CONSTRAINTS   lpUI_constraintEntry ;

   if(curConstraint >= max_constraints)
   {
      LPBYTE  lpTmpBuf;
      WORD    actualSize ;

      actualSize = (max_constraints + 50) * sizeof(UI_CONSTRAINTS) ;

      lpTmpBuf = GlobalReAllocPtr(lpUI_constraints, actualSize , GMEM_MOVEABLE);

      if (lpTmpBuf)
      {
         max_constraints += 50 ;
         lpUI_constraints = (LPUI_CONSTRAINTS)lpTmpBuf ;
      }
      else
         return(UIconstraintIndex);  // failure
   }

   lpUI_constraintEntry = lpUI_constraints + curConstraint ;

   lpUI_constraintEntry->MainKeyIndex = constrainedMainIndex ;
   lpUI_constraintEntry->OptionKeyIndex = constrainedOptionIndex ;
   lpUI_constraintEntry->nextIndex = UIconstraintIndex ;

   curConstraint++ ;  //  officially add this entry
   return(curConstraint - 1);
}


BOOL  FAR   PASCAL     initNoneOptionIndex(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable )
{
   WORD   i, k, numMainKeyHdrs, numOptions ;
   DWORD   lengthOffset ;
   LPMAINKEYHDR  lpMainKeyHdrs, lpCurMainKeyHdr ;
   LPGENERIC_OPTION   lpOptionInfo ;

   numMainKeyHdrs  = lpPrinterInfo->numMainKeyHdrs ;
   lpMainKeyHdrs   = lpPrinterInfo->mainKeyHdrs  ;


   for( i = 0 ; i < numMainKeyHdrs ; i++)
   {
      lpCurMainKeyHdr = lpMainKeyHdrs + i ;
      numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;
      lpOptionInfo = (LPGENERIC_OPTION)MAKELONG(
         lpCurMainKeyHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );
      lpCurMainKeyHdr->NoneOptionIndex = 0xFFFF ;  // until shown otherwise

      for( k = 0 ; k < numOptions ; k++)
      {
         lengthOffset = lpOptionInfo[k].OptionKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, "None")  ||
               !strtblcmp(lengthOffset, lpStringTable, "False"))
         {
            lpCurMainKeyHdr->NoneOptionIndex = k ;
            break;    //  found  None or False option!  
         }
      }
   }
   return(TRUE);  // what other choice is possible?
}


