/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: TTEXT.H                                                */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

#ifdef T3OUTLINE
// Moved from ttext.c
#define UPDATE_FAILURE  -1
#define UPDATE_LOWVM    0
#define UPDATE_SUCCESS  1
// # bytes free left in buffer. Moved from ttext.c
#define RemCSBuffer()   (lpTTtoT1stuff->lpCSEnd - lpTTtoT1stuff->lpCSPos)
// Macro to truncate the fraction from 16-16 fixed pt numbers
#define TRUNC(fixed)  ((LONG)fixed & 0xffff0000)
#endif

BOOL NEAR TTEXTSEG PASCAL PSSendFontPFA(LPPDEVICE lppd, int fh, int length, 
                                          LPSTR buf);
PSERROR FAR PASCAL DownLoadFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, 
                                            LPFONTDATARECORD lpFontData,
                                            BOOL bFullFont,
					    BOOL minHeader);
int FAR PASCAL PSDownLoadFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, 
                                            LPFONTDATARECORD lpFontData,
                                            BOOL bFullFont,
					    BOOL minHeader);
PSERROR NEAR TTEXTSEG PASCAL TTDownLoadT1Font(LPPDEVICE lppd, 
                                            LPPSFONTINFO FontInfo, 
                                            LPFONTDATARECORD lpFontData,
                                            BOOL bFullFont,
                                            unsigned long maxNumGlyphs);
PSERROR NEAR TTEXTSEG PASCAL TTDownLoadT3Font(LPPDEVICE lppd, 
                                            LPPSFONTINFO FontInfo,
                                            LPFONTDATARECORD lpFontData, 
                                            BOOL bFullFont,
                                            unsigned long maxNumGlyphs);
int FAR PASCAL UpdateFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                                          LPSTR lpStr, int cb,
                                          LPFONTDATARECORD lpFontData,
					  BOOL minHeader);
int NEAR TTEXTSEG PASCAL TTUpdateT1Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                                          LPFONTDATARECORD lpFontData,
                                          LPBYTE lpStr, int cb);
int NEAR TTEXTSEG PASCAL TTUpdateT3Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                                          LPFONTDATARECORD lpFontData,
                                          LPBYTE lpStr, int cb);
#ifdef ADOBE_DRIVER
int FAR PASCAL PSUpdateFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPSTR lpStr,
                           int cb, LPFONTDATARECORD lpFontDataRecord);
int FAR PASCAL StreamerDownLoadT1Font(LPPDEVICE lppd, LPSTR fontname,
					LPSTR fontpointer, LPSTR *pglyphdata, 
					BOOL binary, BYTE charset);
int FAR PASCAL StreamerUpdateT1Font(LPPDEVICE lppd, LPSTR fontpointer,
					LPSTR glyphdata, 
					LPSTR lpStr, int cb, 
					BOOL binary, BYTE charset);

void FAR PASCAL StreamerReleaseFontRec(LPVOID FAR *PSFontRecPtr);
BOOL FAR PASCAL StreamerAble(LPSTR inFontName, LPSTR *fontpointer, LPSTR undefFont);
#endif

LPSTR FAR PASCAL GetResourceData(LPPDEVICE lppd, LPHANDLE lphData, short sProcID);
BOOL  FAR PASCAL UnGetResourceData(HANDLE hData);
BOOL AllocateGlyfData(LPPDEVICE lppd, LPFONTDATARECORD lpFontDataRecord);
VOID FAR PASCAL TSendFontDSC(LPPDEVICE,LPSTR);
short FAR PASCAL PSSendFixedAscii7(LPPDEVICE lppd, long FixedNum);

PSERROR FAR PASCAL AllocGIAssigned(LPPDEVICE lppd, LPSTR lpFontName, LPGIASSIGNED lpGAS);
VOID FAR PASCAL FreeGIAssigned(LPPDEVICE lppd, LPGIASSIGNED lpGAS);
BOOL FAR PASCAL AddGIAssignedRecord(LPPDEVICE lppd, LPGIASSIGNED lpGAS);
int  FAR PASCAL CheckGIAssignedRecord(LPPDEVICE lppd, LPSTR lpFontName, LPGIASSIGNED *lpMatchGA);
WORD FAR PASCAL GetGIFromAssignmentID(LPGIASSIGNED lpGAS, WORD asi);
BOOL FAR PASCAL GetGIAssignmentStr(LPPDEVICE lppd, LPSTR lpFontName, LPWORD lpgi, LPWORD lpwNew, int count);

PSERROR FAR PASCAL TTDownLoadT0Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo, 
					 BOOL bFullFont, LPFONTDATARECORD lpFontDataRecord);
int FAR PASCAL TTUpdateT0Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPSTR lpStr,
						   int cb, LPFONTDATARECORD lpFontDataRecord);

void FAR PASCAL CreateReEncodedFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, BOOL bReEncode);
VOID FAR PASCAL FixWinSubsFontName(LPSTR lpFontName, int lfCharSet);

#ifdef T3OUTLINE
BOOL FAR PASCAL GrowCSBuffer(LPPDEVICE lppd);
DWORD FAR CharString_T3OL(LPPDEVICE lppd, DWORD dwCmd, ...);
PSERROR FAR PASCAL TTDownLoadT3OutlineFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                               LPFONTDATARECORD lpFontData, BOOL bFullFont);
PSERROR NEAR TTEXTSEG PASCAL TTDownLoadT1OutlineFont(LPPDEVICE lppd, 
                               LPPSFONTINFO FontInfo, 
                               LPFONTDATARECORD lpFontData, BOOL bFullFont);
int FAR PASCAL TTUpdateT3OutlineFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, 
                               LPFONTDATARECORD lpFontData, LPBYTE lpStr, int cb);
int NEAR TTEXTSEG PASCAL TTUpdateT1OutlineFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                               LPFONTDATARECORD lpFontData, LPBYTE lpStr, int cb);
PSERROR NEAR TTEXTSEG PASCAL TTDownLoadT1OutlineFontExt(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                               LPFONTDATARECORD lpFontData, BOOL bFullFont, 
                               LPSTR lpCopyFrom, BOOL bCopy);
PSERROR FAR PASCAL TTDownLoadT3OutlineFontExt(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                               LPFONTDATARECORD lpFontData, BOOL bFullFont, 
                               LPSTR lpCopyFrom, BOOL bCopy);
void FAR PASCAL PutT3OutlineCharDown(LPPDEVICE lppd, LPPSFONTINFO FontInfo, 
                               LPTTFONTINFO lpTTFontInfo, LPFONTDATARECORD lpFontData,
                               int ch);
#endif
void FAR PASCAL DeleteSubFont(LPPDEVICE lppd, LPFONTDATARECORD lpFontDataRecord);

void FAR PASCAL UpdateUFLSubFont(
    LPSUBFONT43         pSubFont,
    LPPDEVICE           lppd,
    LPPSFONTINFO        lpFontInfo,
    LPFONTDATARECORD    lpFontDataRecord
    );
