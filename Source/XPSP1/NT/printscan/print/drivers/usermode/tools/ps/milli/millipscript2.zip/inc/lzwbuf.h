/*
  lzwbuf.h

  Ed McCreight
  Adobe Systems Inc.
  Special cut-down version of LZW AS filters for Matt Jacobs
  19 Feb 99

*/

#ifndef LZWBUF_H
#define LZWBUF_H

#define ASFAR 

typedef unsigned short ASUns16;
typedef unsigned char ASUns8;
typedef ASUns8 * ASUns8P;
typedef ASUns8 ASFAR * ASUns8FP;
typedef unsigned ASBool;
#define true 1
#define false 0

#define ASDebugAssert(x)

/*
  Simplifications of AS LZW code:
    earlyChange = 0
    retainFullTable = 1
    unitLen = 8
*/

typedef struct _t_BitBuf
{
  ASBool overflowed;
  unsigned int residue; /* at least 16 bits */
  int residueLen; /* 0 <= residueLen < 8 */
  ASUns8FP buf;
  long size, ix;
}
BitBufRec, *BitBuf;

/*----------------  LZW  Filters ----------------------*/

/*
*  The LZW compression method is said to be the subject of patents
*  owned by the Unisys Corporation.  For further information, consult
*  the PostScript Language Reference Manual, second edition
*  (Addison Wesley, 1990, ISBN 0-201-18127-4).
*/

#ifndef CHKSYNCH
#define CHKSYNCH  0  /* for debugging */
#endif /* CHKSYNCH */
#define SYNCHPAT  0x0C
#define SYNCHLEN  4

#define LZWMAXCODE   4096 /* codes */
#define LZWMAXCODELEN   12 /* bits */

/* decode supports basic codes n in [2,8]
   encoder supports 8 bit codes only (as in the TIFF 5.0 spec)

   Codes 0 .. (2 ^ n - 1)) represent their literal byte values
   Code (2 ^ n) is the "Clear" code
   Code (1 + (2 ^ n)) is the "EOD" code
   Codes > "EOD" represent multi-byte sequences
*/

#define LZW_CLEAR(n)  (1 << (n))
#define LZW_EOD(n)    (1 + (1 << (n)))
#define NLITCODES(n)  (2 + (1 << (n)))
#define LZWMINCODELEN(n) ((n) + 1) /* bits */

typedef struct _t_LZWCode {
  ASUns16 prevCodeWord;
  ASUns8 finalChar;
  ASUns8 seqLen;
    /* 0 means length 1,
       1 means length 2,
       ...,
       253 means length 254 or longer,
       254 means special code (LZW_CLEAR, LZW_EOD),
       255 means undefined
    */
}
LZWCodeRec, ASFAR * LZWCode;

#define LZW_SEQLEN_LONG 253
#define LZW_INCREMENT_SEQLEN(x) \
  (((x) < LZW_SEQLEN_LONG) ? ((x) + 1) : LZW_SEQLEN_LONG)
  /* seqLen limits at LZW_SEQLEN_LONG */
#define LZW_SEQLEN_SPECIAL 254
#define LZW_SEQLEN_UNDEF 255



#define LZW_RESULT_FORMAT_ERR   -1
#define LZW_RESULT_ALLOC_ERR    -2


/****************************************/
/*        Procedures                    */

extern size_t LZWCompressWorkSpaceSize(void);
  /* returns number of bytes of workspace needed by LZWCompressBuf */

extern long LZWCompressBufInner(ASUns8FP inBuf, long inCnt, ASUns8FP outBuf, long outCnt,
  ASUns8FP ws);
  /* returns number of chars of output, or LZW_RESULT_x.  If result > outCnt,
    chars beyond outCnt are not written to outBuf.  ws is a working space
    of size >= LZWCompressWorkSpaceSize() */

extern long LZWCompressBuf(ASUns8FP inBuf, long inCnt, ASUns8FP outBuf, long outCnt);
  /* LZWCompressBufInner with a stack working space. */

extern size_t LZWDecompressWorkSpaceSize(void);
  /* returns number of bytes of workspace needed by LZWDecompressBuf */

extern long LZWDecompressBufInner(ASUns8FP inBuf, long inCnt,
  ASUns8FP outBuf, long outCnt, ASUns8FP ws);
  /* returns number of chars of output, or LZW_RESULT_x.  If result > outCnt,
    chars beyond outCnt are not written to outBuf.  ws is a working space
    of size >= LZWDecompressWorkSpaceSize() */

extern long LZWDecompressBuf(ASUns8FP inBuf, long inCnt, ASUns8FP outBuf, long outCnt);
  /* LZWDecompressBufInner with a stack working space. */

#endif /* ndef LZWBUF_H */
