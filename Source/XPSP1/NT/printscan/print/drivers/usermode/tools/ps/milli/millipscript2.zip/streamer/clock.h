/* For compatability with the CLOCK interface in the printer PostScript 
   environment
*/
#include <time.h>
