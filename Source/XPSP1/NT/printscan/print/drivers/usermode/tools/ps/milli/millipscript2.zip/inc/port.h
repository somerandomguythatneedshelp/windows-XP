/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PORT.H                                                       */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/


//driver port management routines
//

VOID  FAR PASCAL PortClose      (LPPDEVICE            );
VOID  FAR PASCAL PortLastEndSpoolPage(LPPDEVICE       );
VOID  FAR PASCAL PortPage       (LPPDEVICE            );
VOID  FAR PASCAL PortWrite      (LPPDEVICE,LP    ,WORD);
VOID  FAR PASCAL PortWriteString(LPPDEVICE,LP         );
BOOL  FAR PASCAL PortOpen       (LPPDEVICE,LPSTR ,HDC,LPDOCINFO);
BOOL  FAR PASCAL PortFirstStartSpoolPage(LPPDEVICE);
VOID  FAR PASCAL PortClean      (LPPDEVICE);
BOOL  FAR PASCAL PortDirtyQuery (LPPDEVICE);
VOID NEAR PASCAL HandlePortError(LPPDEVICE lppd, short sError);

int FlushToSpool( LPPDEVICE lppd );
int WriteToSpool( LPPDEVICE lppd, LPSTR lpData, WORD count );



