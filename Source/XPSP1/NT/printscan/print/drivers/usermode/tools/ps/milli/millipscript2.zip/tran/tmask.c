/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1996,1997 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TMASK.C                                                      */
/*                                                                           */
/* Description: This module contains the functions for  ...                  */
/*                                                                           */
/* Change History:                                                           */
/* L3_MASK -- Support level3 transparent image.  9/19/96   jjia              */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
//L3_MASK
#include "tmask.h"

#pragma code_seg(_LEVEL2SEG)

#define   QDRGNEND   0xFFFF
#define   MaskedBit(p, i) !(BOOL)(((*((BYTE huge *)(p)+((int)(i))/8)) >> (7-((int)(i))%8)) & 0x01)


short CreateMaskBmp(LPPDEVICE lppd, LPDRAWMODE lpdm,
                  WORD SrcXE, WORD SrcYE, DWORD DIBScanWidth,
                  LPSTR lpDataBits, WORD MskScanWidth,
                  BYTE huge *lpMaskBits, LPBITMAPINFO lpBitmapInfo);
BOOL PixelIsMaskedColorIdx(BYTE huge *lpCurtPx, DWORD BitPos,
                  DWORD BitCount, WORD BkColorIdx);
BOOL PixelIsMaskedColor(LPBITMAPINFO lpBitmapInfo, BYTE huge *lpCurPx,
                  DWORD BitCount, RGBQUAD BkColor);
void BitOn(BYTE huge *lpMask, DWORD shift);
DWORD  FindQDRgns(LPSTR lpLn, WORD wMslScanWidth, WORD wCurtLn,
                  WORD huge *lpQDRgns, DWORD far *lpdwIndex);
BOOL BitMapToRegion(WORD wSrcYE, WORD wMskScanWidth,
                  BYTE huge *lpMaskBits,
                  WORD huge *lpQDRgns, DWORD far *lpNumRgns);
BOOL PSShiftScale(LPPDEVICE lppd, LPRECT SrcRect, LPRECT DstRect);
BOOL PSSendClipRgns(LPPDEVICE lppd, WORD wMskScanWidth,
                  WORD huge *lpQDRgns, DWORD dwQDRgns);
VOID ChangePix(BYTE huge *LpFromLn, BYTE huge *LpToLn,
                  WORD wFrom, WORD wTo, WORD wBitCount);
VOID ChangePixIdx(BYTE huge *LpFromLn, BYTE huge *LpToLn,
                  WORD wFrom, WORD wTo, WORD wBitCount);
short ReColorDIBPixel(WORD SrcXE, WORD SrcYE, DWORD DIBScanWidth,
                  LPSTR lpDataBits, WORD MskScanWidth,
                  BYTE huge *lpMaskBits, LPBITMAPINFO lpBitmapInfo);

/*****************************************************************************/

void BitOn(BYTE huge *lpMask, DWORD shift)
{
   lpMask += (shift / 8);
   *lpMask = *lpMask | (1 << (7 - (shift % 8)));
}

BOOL PixelIsMaskedColorIdx(BYTE huge *lpCurtPx, DWORD BitPos,
                           DWORD BitCount, WORD BkColorIdx)
{
    WORD   wIndex = 0;

    if (BitCount == 1)
    {
        wIndex = ((*lpCurtPx) >> (7 - BitPos)) & 0x01;
    }
    else if (BitCount == 4)
    {
        wIndex = ((*lpCurtPx) >> (4 - BitPos)) & 0x0F;
    }

    if (wIndex == BkColorIdx)
        return TRUE;
    else
        return FALSE;
}

/*****************************************************************************/
/*                                                                           */
/*                           PixelIsMaskedColor                              */
/* Purpose: Get the color for a given pixel and compare this color with      */
/*          background color to see if it is background color or not.        */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPDEVICE  lppd --                                                      */
/*   LPSTR      lpCurPX                                                      */
/*   DWORD      BitCount                                                     */
/*   RGBQUAD    BkColor                                                      */
/*                                                                           */
/* Returns:     TRUE  -- the current pixel color is background color.        */
/*              FALSE -- otherwise.                                          */
/*****************************************************************************/

BOOL PixelIsMaskedColor(LPBITMAPINFO lpBitmapInfo, BYTE huge *lpCurPx,
                        DWORD BitCount, RGBQUAD BkColor)
{
    WORD huge *lpWordPtr;
    WORD      wTemp;
    RGBQUAD   CurtColor;
    BOOL      Success = TRUE;

    if (BitCount == 16)
    {
        BOOL   RGB565 = FALSE;
        if (lpBitmapInfo->bmiHeader.biCompression == BI_BITFIELDS)
        {
            if (((BITMAPV4HEADER FAR *)lpBitmapInfo)->bV4GreenMask == 0x7e0)
                RGB565 = TRUE;
        }
        lpWordPtr = (WORD huge *)lpCurPx;
        wTemp = *lpWordPtr;
        if (!RGB565)
        {
            CurtColor.rgbBlue  = (BYTE)(wTemp << 3) & 0xF8;
            CurtColor.rgbGreen = (BYTE)(wTemp >> 2) & 0xF8;
            CurtColor.rgbRed   = (BYTE)(wTemp >> 7) & 0xF8;
        }
        else
        {
            CurtColor.rgbBlue  = (BYTE)(wTemp << 3) & 0xF8;
            CurtColor.rgbGreen = (BYTE)(wTemp >> 3) & 0xFC;
            CurtColor.rgbRed   = (BYTE)(wTemp >> 8) & 0xF8;
        }
    }
    else if (BitCount == 24)
    {
        CurtColor.rgbBlue  = *lpCurPx++;
        CurtColor.rgbGreen = *lpCurPx++;
        CurtColor.rgbRed   = *lpCurPx++;
    }
    else if (BitCount == 32)
    {
        if (lpBitmapInfo->bmiHeader.biCompression == BI_BITFIELDS)
        {
            if (((BITMAPV4HEADER FAR *)lpBitmapInfo)->bV4BlueMask != 0xFF)
                Success = FALSE;
        }
        if (Success)
        {
            // RGB888
            CurtColor.rgbBlue  = *lpCurPx++;
            CurtColor.rgbGreen = *lpCurPx++;
            CurtColor.rgbRed   = *lpCurPx++;
            lpCurPx++;
        }
    }

    if (Success &&
       (CurtColor.rgbBlue == BkColor.rgbBlue) &&
       (CurtColor.rgbGreen == BkColor.rgbGreen) &&
       (CurtColor.rgbRed == BkColor.rgbRed))
        return TRUE;
    else
        return FALSE;
}

/*****************************************************************************/
/*                                                                           */
/*                             CreateMaskBmp                                 */
/* Purpose:  Create a 1 bot deep bitmap which represents masked image.       */
/*           Each pixel in this Bitmap is calculated from source Bitmap.     */
/*           The pixel is set to 1 for the color other than transparent one; */
/*           The pixel is set to 0 for the transparent color.                */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPDEVICE  lppd --                                                      */
/*   LPDRAWMODE lpdm --                                                      */
/*   WORD       SrcXE                                                        */
/*   WORD       SrcYE                                                        */
/*   DWORD      DIBScanWidth                                                 */
/*   LPSTR      lpDataBits                                                   */
/*   WORD       MskScanWidth                                                 */
/*   BYTE huge    *lpMaskBits                                                */
/*   LPBITMAPINFO lpBitmapInfo                                               */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short CreateMaskBmp(LPPDEVICE lppd, LPDRAWMODE lpdm,
                  WORD SrcXE, WORD SrcYE, DWORD DIBScanWidth,
                  LPSTR lpDataBits, WORD MskScanWidth,
                  BYTE huge *lpMaskBits, LPBITMAPINFO lpBitmapInfo)
{
    BYTE huge    *lpMask;
    BYTE huge    *lpCurLn;
    BYTE huge    *lpCurPx;
    DWORD        i, j;
    DWORD        BitPos = 0;
    WORD         BitCount = lpBitmapInfo->bmiHeader.biBitCount;
    RGBQUAD      BkColor;
    WORD         BkColorIdx;
    LPRGBQUAD    lppal = (LPRGBQUAD)((LPSTR)lpBitmapInfo +
                                     lpBitmapInfo->bmiHeader.biSize);
    WORD         TableLen;

    // Initiall mask bitmap to 0.
    lpMask = lpMaskBits;
    for (i = 0; i < (DWORD)MskScanWidth * (SrcYE + 1); i++)
        *lpMask++ = 0x00;

    // Get Background color and Background color index
    BkColor.rgbBlue = GetBValue((DWORD)(lpdm->bkColor));
    BkColor.rgbGreen = GetGValue((DWORD)(lpdm->bkColor));
    BkColor.rgbRed = GetRValue((DWORD)(lpdm->bkColor));
    if (BitCount <= 8)
    {
        TableLen = (WORD)(1 << BitCount);
        for (i = 0; i < (DWORD)TableLen; i++)
        {
            if ((lppal[i].rgbBlue == BkColor.rgbBlue) &&
                (lppal[i].rgbGreen == BkColor.rgbGreen) &&
                (lppal[i].rgbRed == BkColor.rgbRed))
            {
                BkColorIdx = (WORD)i;
                break;
            }
        }
    }

    lpCurLn = (BYTE huge *)lpDataBits;
    lpMask = lpMaskBits;
    if (BitCount < 8)
    {
        // Handle Indexed color
        for (i = 0; i < SrcYE; i++)
        {
            for (j = 0; j < SrcXE; j++)
            {
                lpCurPx = lpCurLn + j * BitCount / 8;
                BitPos = (j * BitCount) % 8;
                if (!PixelIsMaskedColorIdx(lpCurPx, BitPos, BitCount, BkColorIdx))
                    BitOn(lpMask, j);
            }
            lpCurLn += DIBScanWidth;
            lpMask += MskScanWidth;
        }
    }
    else if (BitCount == 8)
    {
        // Handle Indexed color
        for (i = 0; i < SrcYE; i++)
        {
            for (j = 0; j < SrcXE; j++)
            {
                lpCurPx = lpCurLn + j;
                if (*lpCurPx != BkColorIdx)
                    BitOn(lpMask, j);
            }
            lpCurLn += DIBScanWidth;
            lpMask += MskScanWidth;
        }
    }
    else
    {
        // Handle color data.
        for (i = 0; i < SrcYE; i++)
        {
            for (j = 0; j < SrcXE; j++)
            {
                lpCurPx = lpCurLn + j * BitCount / 8;
                if (!PixelIsMaskedColor(lpBitmapInfo, lpCurPx, BitCount, BkColor))
                    BitOn(lpMask, j);
            }
            lpCurLn += DIBScanWidth;
            lpMask += MskScanWidth;
        }
    }
    return 1;
}

/*****************************************************************************/

DWORD  FindQDRgns(LPSTR lpLn, WORD wMskScanWidth, WORD wCurtLn,
                  WORD huge *lpQDRgns, DWORD far *lpdwIndex)
{
    WORD  i, j;
    BOOL  bInRgn = FALSE;
    BYTE  bCurtPx, bCurtByte;
    DWORD dwIndex;
    DWORD dwNumRgns = 0;

    dwIndex = *lpdwIndex;
    for (i = 0; i < wMskScanWidth; i++)
    {
        bCurtByte = lpLn[i];
        if (bCurtByte == 0)
        {
            if (bInRgn)
            {
                bInRgn = FALSE;
                if (lpQDRgns)
                {
                    lpQDRgns[dwIndex++] = (WORD)(i * 8);
                }
            }
            continue;
        }
        else if (bCurtByte == 0xFF)
        {
            if (!bInRgn)
            {
                bInRgn = TRUE;
                if (lpQDRgns)
                {
                    // Output line number only for the first region.
                    if (!dwNumRgns)
                        lpQDRgns[dwIndex++] = wCurtLn;
                    lpQDRgns[dwIndex++] = (WORD)(i * 8);
                }
                dwNumRgns ++;
            }
            continue;
        }

        bCurtPx = 128;
        for (j = 0; j < 8; j++)
        {
            // Pixel is 1
            if (bCurtByte & bCurtPx)
            {
                // Region begine
                if (!bInRgn)
                {
                    bInRgn = TRUE;
                    if (lpQDRgns)
                    {
                        // Output line number only for the first region.
                        if (!dwNumRgns)
                            lpQDRgns[dwIndex++] = wCurtLn;
                        lpQDRgns[dwIndex++] = (WORD)(i * 8 + j);
                    }
                    dwNumRgns ++;
                }
            }
            else
            {
                if (bInRgn)
                {
                    bInRgn = FALSE;
                    if (lpQDRgns)
                    {
                        lpQDRgns[dwIndex++] = (WORD)(i * 8 + j);
                    }
                }
            }
            bCurtPx = bCurtPx >> 1;
        }
    }
    if (bInRgn)
    {
        bInRgn = FALSE;
        if (lpQDRgns)
        {
            lpQDRgns[dwIndex++] = (WORD)(wMskScanWidth * 8);
        }
    }
    if (dwNumRgns && lpQDRgns)
        lpQDRgns[dwIndex++] = QDRGNEND;

    *lpdwIndex = dwIndex;

    return dwNumRgns;
}

/*****************************************************************************/
/*                                                                           */
/*                             BitMapToRegion                                */
/* Purpose: Find the regions(QuickRegion) from bitmap.                       */
/*                                                                           */
/* Parameters:                                                               */
/*   WORD   SrcXE   --                                                       */
/*   WORD   SrcYE   --                                                       */
/*   WORD   MskScanWidth --                                                  */
/*   BYTE     huge *lpMaskBits --                                            */
/*   QDREGION huge *lpQDRgns   --                                            */
/*   DWORD    far  *lpNumrgns  --                                            */
/*                                                                           */
/* Returns: BOOL                                                             */
/*****************************************************************************/

BOOL BitMapToRegion(WORD wSrcYE, WORD wMskScanWidth,
                     BYTE huge *lpMaskBits,
                     WORD huge *lpQDRgns, DWORD far *lpNumRgns)
{
    BYTE   huge *lpCurtLn;
    BYTE   huge *lpPreLn;
    LPSTR  lpCurtStat;
    WORD   i, j;
    DWORD  dwNumRgns = 0;
    DWORD  dwIndex = 0;
    BOOL   bSuccess = TRUE;

    lpCurtStat = GlobalAllocPtr(GHND, wMskScanWidth);
    if (!lpCurtStat)
    {
        bSuccess = FALSE;
        goto Done;
    }

    lpPreLn = lpMaskBits;
    for (j = 0; j < wMskScanWidth; j++)
        lpCurtStat[j] = lpPreLn[j];
    dwNumRgns += FindQDRgns(lpCurtStat, wMskScanWidth,
                 0, lpQDRgns, &dwIndex);

    for (i = 1; i < wSrcYE + 1; i++)
    {
        lpCurtLn = lpPreLn + wMskScanWidth;
        for (j = 0; j < wMskScanWidth; j++)
            lpCurtStat[j] = lpCurtLn[j] ^ lpPreLn[j];
        dwNumRgns += FindQDRgns(lpCurtStat, wMskScanWidth,
                     i, lpQDRgns, &dwIndex);
        lpPreLn = lpCurtLn;
    }

    if (lpQDRgns)
        lpQDRgns[dwIndex++] = QDRGNEND;
Done:
    *lpNumRgns = dwNumRgns;
    if (lpCurtStat)
        GlobalFreePtr(lpCurtStat);
    return bSuccess;
}

/*****************************************************************************/

BOOL PSShiftScale(LPPDEVICE lppd, LPRECT SrcRect, LPRECT DstRect)
{
    LPASCIIBINPTRS  tempptr;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_CTMsave);
    (*tempptr->PSSendShort)(lppd, DstRect->left);
    (*tempptr->PSSendShort)(lppd, DstRect->bottom);
    (*tempptr->PSSendBasic)(lppd, PSOP_translate);
    (*tempptr->PSSendFloat)(lppd, (((float)(DstRect->right - DstRect->left))/
                                   (SrcRect->right - SrcRect->left)));
    (*tempptr->PSSendFloat)(lppd, (-((float)(DstRect->bottom - DstRect->top))/
                                   (SrcRect->bottom - SrcRect->top)));
    (*tempptr->PSSendBasic)(lppd, PSOP_scale);
    (*tempptr->PSSendCRLF)(lppd);
    return TRUE;
}

/*****************************************************************************/
/* Purpose: This function takes a QuickDraw region, and steps through its    */
/*          internal structure and discovers a set of rectangles that will   */
/*          exactly define the regions. Each time it find a rectangle,       */
/*          it emits the rectangle as part of a rectangle array.             */
/*****************************************************************************/

BOOL PSSendClipRgns(LPPDEVICE lppd, WORD wMskScanWidth,
                    WORD huge *lpQDRgns, DWORD dwQDRgns)
{
    WORD far   *lpwEdges;
    DWORD      i;
    WORD       j;
    BOOL       bSuccess = TRUE;
    WORD       scanV;
    WORD       x1, x2;
    RECT       TempRect;
    LPASCIIBINPTRS  tempptr;
    short      sLineLeng = 0;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    lpwEdges = (WORD far *)GlobalAllocPtr(GHND, wMskScanWidth * 8 * sizeof(WORD));
    if (!lpwEdges)
    {
        bSuccess = FALSE;
        goto Done;
    }
    for (i = 0; i < wMskScanWidth * 8; i++)
        lpwEdges[i] = QDRGNEND;

    PSSendFragment(lppd, PSFRAG_beginsafe);
    PSSendFragment(lppd, PSFRAG_leftbracket);

    // Loop to increment the scanline.
    for (i = 0; lpQDRgns[i] != QDRGNEND; i ++)
    {
        // Record the vertical position of the current scanline.
        scanV = lpQDRgns[i++];
        // Loop to increment which horizontal pair we're looking at.
        while (lpQDRgns[i] != QDRGNEND)
        {
            x1 = lpQDRgns[i++];
            x2 = lpQDRgns[i++];
            // Loop through vertical coordinate array, checking all position
            // in the array that correspond to a position between the two
            // horizontal coordinates in the pair recorded above.
            j = x1;
            while (j < x2)
            {
                // If the value in the array is not set, then we have found a
                // top edge. he location of this edge is to be stored in the
                // array. Recall that this position was recorded earlier
                // as vertical position of the current scanline.
                if (lpwEdges[j] == QDRGNEND)
                {
                    lpwEdges[j] = scanV;
                    j++;
                }
                // If the value is set, and it is less than (higher than) the
                // current region scanline, then we've found a bottom adge to
                // go with the top edge recorded in the array.
                else if (scanV > lpwEdges[j])
                {
                    TempRect.top = lpwEdges[j];
                    TempRect.bottom = scanV;
                    TempRect.left = j;
                    while ((j < x2) && (lpwEdges[j] == (WORD)TempRect.top))
                    {
                        lpwEdges[j] = QDRGNEND;
                        j++;
                    }
                    TempRect.right = j;
                    // we have finished filling out the rectangle.
                    // Now emit PostScript.
                    sLineLeng += (*tempptr->PSSendShort)(lppd, TempRect.left);
                    sLineLeng += (*tempptr->PSSendShort)(lppd, TempRect.top);
                    sLineLeng += (*tempptr->PSSendShort)(lppd,
                                  TempRect.right - TempRect.left);
                    sLineLeng += (*tempptr->PSSendShort)(lppd,
                                  TempRect.bottom - TempRect.top);
                    if (sLineLeng > 128)
                    {
                        sLineLeng = 0;
                        (*tempptr->PSSendCRLF)(lppd);
                    }
                }
                else
                    j++;
            }
        }
    }

    PSSendFragment(lppd, PSFRAG_rightbracket);
    PSSendFragment(lppd, PSFRAG_rectclip);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_endsafe);
    PSSendFragment(lppd, PSFRAG_space);
Done:
    if (lpwEdges)
        GlobalFreePtr(lpwEdges);

    return bSuccess;
}

/*****************************************************************************/
/*                                                                           */
/*                             ChangePixIdx                                  */
/* Purpose: Update the pixel in the lpToLn wTo position based on the         */
/*          lpFromLn wFrom position                                          */
/*                                                                           */
/* Parameters:                                                               */
/*   BYTE huge *LpFromLn -- A pointer to scan line buffer.                   */
/*   BYTE huge *LpToLn   -- A pointer to scan line buffer.                   */
/*   WORD      wFrom     -- The pixel distance from scan line beginning.     */
/*   WORD      wTo       -- The pixel distance from scan line beginning.     */
/*   WORD      BitCount  --                                                  */
/*                                                                           */
/* Returns: None                                                             */
/*****************************************************************************/

VOID ChangePixIdx(BYTE huge *lpFromLn, BYTE huge *lpToLn,
               WORD wFrom, WORD wTo, WORD wBitCount)
{
    BYTE huge *lpFromP = lpFromLn + wFrom * wBitCount / 8;
    BYTE huge *lpToP = lpToLn + wTo * wBitCount / 8;
    WORD      wFromPos = wFrom * wBitCount % 8;
    WORD      wToPos = wTo * wBitCount % 8;

    if (wBitCount == 1)
    {
        (*lpToP) -= (*lpToP) & (0x01 << (7 - wToPos));
        (*lpToP) += (((*lpFromP) >> (7-wFromPos)) & 0x01) << (7 - wToPos);
    }
    else if (wBitCount == 4)
    {
        (*lpToP) -= (*lpToP) & (0x0F << (4 - wToPos));
        (*lpToP) += (((*lpFromP) >> (4-wFromPos)) & 0x0F) << (4 - wToPos);
    }
}

/*****************************************************************************/
/*                                                                           */
/*                             ChangePix                                     */
/* Purpose: Update the pixel in the lpToLn wTo position based on the         */
/*          lpFromLn wFrom position                                          */
/*                                                                           */
/* Parameters:                                                               */
/*   BYTE huge *LpFromLn -- A pointer to scan line buffer.                   */
/*   BYTE huge *LpToLn   -- A pointer to scan line buffer.                   */
/*   WORD      wFrom     -- The pixel distance from scan line beginning.     */
/*   WORD      wTo       -- The pixel distance from scan line beginning.     */
/*   WORD      BitCount  --                                                  */
/*                                                                           */
/* Returns: None                                                             */
/*****************************************************************************/

VOID ChangePix(BYTE huge *lpFromLn, BYTE huge *lpToLn,
               WORD wFrom, WORD wTo, WORD wBitCount)
{
    BYTE huge *lpFromP = lpFromLn + wFrom * wBitCount / 8;
    BYTE huge *lpToP = lpToLn + wTo * wBitCount / 8;

    if (wBitCount == 16)
    {
        *lpToP++ = *lpFromP++;
        *lpToP++ = *lpFromP++;
    }
    else if (wBitCount == 24)
    {
        *lpToP++ = *lpFromP++;
        *lpToP++ = *lpFromP++;
        *lpToP++ = *lpFromP++;
    }
    else if (wBitCount == 32)
    {
        *lpToP++ = *lpFromP++;
        *lpToP++ = *lpFromP++;
        *lpToP++ = *lpFromP++;
        *lpToP++ = *lpFromP++;
    }
}

/*****************************************************************************/
/*                                                                           */
/*                             ReColorDIBPixel                               */
/* Purpose:  If there is a mask, but no Level3 PostScript, the out going     */
/*           is modified slightly to cover some PostScript clipping          */
/*           inaccuracies. This function is designed to soomth the clipping  */
/*           edge and make the the clipping looks good.                      */
/*           The basic idea is to change the samples which are on the edge   */
/*           of the clipping rect. In order to do this, we check each pixel  */
/*           in the masked image. If the pixel is OFF( should be masked),    */
/*           then we check the surrounding bits to see of they are off. If   */
/*           one of them is on, then we use the color value corresponding to */
/*           that sample as the color value for the current sample.          */
/*                                                                           */
/* Parameters:                                                               */
/*   WORD       SrcXE                                                        */
/*   WORD       SrcYE                                                        */
/*   DWORD      DIBScanWidth                                                 */
/*   LPSTR      lpDataBits                                                   */
/*   WORD       MskScanWidth                                                 */
/*   BYTE huge    *lpMaskBits                                                */
/*   LPBITMAPINFO lpBitmapInfo                                               */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short ReColorDIBPixel(WORD SrcXE, WORD SrcYE, DWORD DIBScanWidth,
                  LPSTR lpDataBits, WORD MskScanWidth,
                  BYTE huge *lpMaskBits, LPBITMAPINFO lpBitmapInfo)
{
    BYTE huge    *lpMask;
    BYTE huge    *lpPreMaskLn;
    BYTE huge    *lpNextMaskLn;
    BYTE huge    *lpCurLn;
    WORD         i, j, k, l;
    WORD         BitCount = lpBitmapInfo->bmiHeader.biBitCount;
    WORD         SrcXE_1 = SrcXE - 1;
    WORD         SrcYE_1 = SrcYE - 1;

    if ((SrcXE <= 1) || (SrcYE <= 1))
        return 1;

    lpCurLn = (BYTE huge *)lpDataBits;
    lpMask = lpMaskBits;

    lpPreMaskLn = lpMask - MskScanWidth;
    lpNextMaskLn = lpMask + MskScanWidth;

    if (BitCount < 8)
    {
        for (i = 0; i < SrcYE; i++)
        {
            for (k = 0; k < MskScanWidth; k++)
            {
                if (lpMask[k] == 0xFF)
                    continue;

                l = ((k + 1) * 8 < SrcXE)? (k + 1) * 8 : SrcXE;
                for (j = k * 8; j < l; j++)
                {
                    if (MaskedBit(lpMask, j))
                    {
                        if ((j > 0) && !(MaskedBit(lpMask, j - 1)))
                            ChangePixIdx(lpCurLn, lpCurLn, j-1, j, BitCount);
                        else if ((j < SrcXE_1) && !(MaskedBit(lpMask, j + 1)))
                            ChangePixIdx(lpCurLn, lpCurLn, j+1, j, BitCount);
                        else if ((i > 0) && !(MaskedBit(lpPreMaskLn, j)))
                            ChangePixIdx(lpCurLn - DIBScanWidth , lpCurLn, j, j, BitCount);
                        else if ((i < SrcYE_1) && !(MaskedBit(lpNextMaskLn, j)))
                            ChangePixIdx(lpCurLn + DIBScanWidth , lpCurLn, j, j, BitCount);
    /*                  else if ((j > 0) && (i > 0) && !(MaskedBit(lpPreMaskLn, j - 1)))
                            ChangePixIdx(lpCurLn - DIBScanWidth , lpCurLn, j-1, j, BitCount);
                        else if ((j < SrcXE_1) && (i > 0) && !(MaskedBit(lpPreMaskLn, j + 1)))
                            ChangePixIdx(lpCurLn - DIBScanWidth , lpCurLn, j+1, j, BitCount);
                        else if ((j > 0) && (i < SrcYE_1) && !(MaskedBit(lpNextMaskLn, j - 1)))
                            ChangePixIdx(lpCurLn + DIBScanWidth , lpCurLn, j-1, j, BitCount);
                        else if ((j < SrcXE_1) && (i < SrcYE_1) && !(MaskedBit(lpNextMaskLn, j + 1)))
                            ChangePixIdx(lpCurLn + DIBScanWidth , lpCurLn, j+1, j, BitCount);
    */
                    }
                }
            }
            lpCurLn += DIBScanWidth;
            lpMask += MskScanWidth;
            lpPreMaskLn += MskScanWidth;
            lpNextMaskLn += MskScanWidth;
        }
    }
    else if (BitCount == 8)
    {
        for (i = 0; i < SrcYE; i++)
        {
            for (k = 0; k < MskScanWidth; k++)
            {
                if (lpMask[k] == 0xFF)
                    continue;

                l = ((k + 1) * 8 < SrcXE)? (k + 1) * 8 : SrcXE;
                for (j = k * 8; j < l ; j++)
                {
                    if (MaskedBit(lpMask, j))
                    {
                        if ((j > 0) && !(MaskedBit(lpMask, j - 1)))
                            lpCurLn[j] = lpCurLn[j-1];
                        else if ((j < SrcXE_1) && !(MaskedBit(lpMask, j + 1)))
                            lpCurLn[j] = lpCurLn[j+1];
                        else if ((i > 0) && !(MaskedBit(lpPreMaskLn, j)))
                            lpCurLn[j] = *(lpCurLn - DIBScanWidth + j);
                        else if ((i < SrcYE_1) && !(MaskedBit(lpNextMaskLn, j)))
                            lpCurLn[j] = *(lpCurLn + DIBScanWidth + j);
/*                      else if ((j > 0) && (i > 0) && !(MaskedBit(lpPreMaskLn, j - 1)))
                            lpCurLn[j] = *(lpCurLn - DIBScanWidth + j - 1);
                        else if ((j < SrcXE_1) && (i > 0) && !(MaskedBit(lpPreMaskLn, j + 1)))
                            lpCurLn[j] = *(lpCurLn - DIBScanWidth + j + 1);
                        else if ((j > 0) && (i < SrcYE_1) && !(MaskedBit(lpNextMaskLn, j - 1)))
                            lpCurLn[j] = *(lpCurLn + DIBScanWidth + j - 1);
                        else if ((j < SrcXE_1) && (i < SrcYE_1) && !(MaskedBit(lpNextMaskLn, j + 1)))
                            lpCurLn[j] = *(lpCurLn + DIBScanWidth + j + 1);
*/
                    }
                }
            }
            lpCurLn += DIBScanWidth;
            lpMask += MskScanWidth;
            lpPreMaskLn += MskScanWidth;
            lpNextMaskLn += MskScanWidth;
        }
    }
    else
    {   // This part can be merged to (BitCount < 8). But that will slow
        // down the speed since too may compparison will be handled in
        // function ChangePix.
        for (i = 0; i < SrcYE; i++)
        {
            for (k = 0; k < MskScanWidth; k++)
            {
                if (lpMask[k] == 0xFF)
                    continue;

                l = ((k + 1) * 8 < SrcXE)? (k + 1) * 8 : SrcXE;
                for (j = k * 8; j < l; j++)
                {
                    if (MaskedBit(lpMask, j))
                    {
                        if ((j > 0) && !(MaskedBit(lpMask, j - 1)))
                            ChangePix(lpCurLn, lpCurLn, j-1, j, BitCount);
                        else if ((j < SrcXE_1) && !(MaskedBit(lpMask, j + 1)))
                            ChangePix(lpCurLn, lpCurLn, j+1, j, BitCount);
                        else if ((i > 0) && !(MaskedBit(lpPreMaskLn, j)))
                            ChangePix(lpCurLn - DIBScanWidth , lpCurLn, j, j, BitCount);
                        else if ((i < SrcYE_1) && !(MaskedBit(lpNextMaskLn, j)))
                            ChangePix(lpCurLn + DIBScanWidth , lpCurLn, j, j, BitCount);
/*                      else if ((j > 0) && (i > 0) && !(MaskedBit(lpPreMaskLn, j - 1)))
                            ChangePix(lpCurLn - DIBScanWidth , lpCurLn, j-1, j, BitCount);
                        else if ((j < SrcXE_1) && (i > 0) && !(MaskedBit(lpPreMaskLn, j + 1)))
                            ChangePix(lpCurLn - DIBScanWidth , lpCurLn, j+1, j, BitCount);
                        else if ((j > 0) && (i < SrcYE_1) && !(MaskedBit(lpNextMaskLn, j - 1)))
                            ChangePix(lpCurLn + DIBScanWidth , lpCurLn, j-1, j, BitCount);
                        else if ((j < SrcXE_1) && (i < SrcYE_1) && !(MaskedBit(lpNextMaskLn, j + 1)))
                            ChangePix(lpCurLn + DIBScanWidth , lpCurLn, j+1, j, BitCount);
*/
                    }
                }
            }
            lpCurLn += DIBScanWidth;
            lpMask += MskScanWidth;
            lpPreMaskLn += MskScanWidth;
            lpNextMaskLn += MskScanWidth;
        }
    }

    return 1;
}

/*****************************************************************************/
/*                                                                           */
/*                              TDIBClipRgns                                 */
/* Purpose: Backward compatible. Support transparent for Level2 PS Printer.  */
/*          The basic idea is to use clip to do transparent.                 */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPDEVICE lppd --                                                       */
/*   LPPDEVICE lpdm --                                                       */
/*   LPRECT DstRect --                                                       */
/*   LPRECT SrcRect --                                                       */
/*   LPSTR lpDataBits --                                                     */
/*   LPBITMAPINFO lpBitmapInfo --                                            */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL TDIBClipRgns(LPPDEVICE lppd, LPDRAWMODE lpdm,
                              LPRECT DstRect, LPRECT SrcRect,
                              LPSTR lpDataBits, LPBITMAPINFO lpBitmapInfo)
{
    BYTE huge    *lpMaskBits;     // A pointer to masked image.
    HANDLE       hMaskBits;
    DWORD        dwDIBScanWidth;
    WORD         wMskScanWidth;

    WORD         wSrcXE = SrcRect->right - SrcRect->left;
    WORD         wSrcYE = SrcRect->bottom - SrcRect->top;
    WORD         wBitCount = lpBitmapInfo->bmiHeader.biBitCount;
    DWORD        dwDIBHeight= (DWORD)lpBitmapInfo->bmiHeader.biHeight;
    DWORD        dwDIBWidth = (DWORD)lpBitmapInfo->bmiHeader.biWidth;

    DWORD        dwNumQDRgns;
    HANDLE       hQDRgns;
    WORD         huge *lpQDRgns;
    BOOL         bSuccess = TRUE;
    LPASCIIBINPTRS  tempptr;

    if (TokenNeedsProcset(lppd, DIB) == RC_fail)
    {
        bSuccess = FALSE;
        goto Done;
    }

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    dwDIBScanWidth = ((dwDIBWidth * wBitCount + 31) / 32) * 4;
    wMskScanWidth = (wSrcXE + 7 ) / 8;
    lpMaskBits = NULL;
    lpQDRgns = NULL;


    // Alloc buffer for mask bitmap -- 1bit deep bitmap.
    // Add 1 to the height of the mask bitmap.
    lpMaskBits = (BYTE huge *)MGAllocLock(lppd, (LPHANDLE) &hMaskBits,
                 (DWORD)wMskScanWidth * (wSrcYE + 1), GHND, TRUE);
    if (!lpMaskBits)
    {
        hMaskBits = 0;
        bSuccess = FALSE;
        goto Done;
    }

    // Set mask bitmap -- Set the bits to 0 if the pixel should be masked.
    CreateMaskBmp(lppd, lpdm, wSrcXE, wSrcYE, dwDIBScanWidth, lpDataBits,
                 wMskScanWidth, lpMaskBits, lpBitmapInfo);


    // Build QuickDraw rect from mask bitmap
    bSuccess = BitMapToRegion( wSrcYE, wMskScanWidth,
               lpMaskBits, NULL, &dwNumQDRgns);
    if (!bSuccess)
        goto Done;

    lpQDRgns = (WORD huge *)MGAllocLock(lppd, (LPHANDLE) &hQDRgns,
               (dwNumQDRgns + wSrcYE + wSrcXE + 4) * 2 * sizeof(WORD),
               GHND, TRUE);
    if (!lpQDRgns)
    {
        hQDRgns = NULL;
        bSuccess = FALSE;
        goto Done;
    }
    bSuccess = BitMapToRegion( wSrcYE, wMskScanWidth,
               lpMaskBits, lpQDRgns, &dwNumQDRgns);
    if (!bSuccess)
        goto Done;


    // Build and send clip regions from QuickDraw region
    if (dwNumQDRgns && (lpQDRgns[0] != QDRGNEND))
    {
        bSuccess = PSShiftScale(lppd, SrcRect, DstRect);
        if (bSuccess)
            bSuccess = PSSendClipRgns(lppd, wMskScanWidth,
                                      lpQDRgns, dwNumQDRgns);
        if (bSuccess)
        {
            PSSendFragment(lppd, PSFRAG_CTMrestore);
            (*tempptr->PSSendCRLF)(lppd);
        }
    }

    ReColorDIBPixel(wSrcXE, wSrcYE, dwDIBScanWidth,lpDataBits,
                    wMskScanWidth, lpMaskBits, lpBitmapInfo);

Done:
    if (hMaskBits)    
        MGUnlockFree(lppd, hMaskBits, TRUE);
    if (hQDRgns)    
        MGUnlockFree(lppd, hQDRgns, TRUE);

    return bSuccess;
}


