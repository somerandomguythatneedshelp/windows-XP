/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ESCAPES.H                                                    */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/

/* the following is the list of escapes defined in the DDK.  These are the
   ones we will support, for now
*/

#define NEWFRAME                1
#define ABORTDOC                2
#define NEXTBAND                3
#define SETCOLORTABLE           4
#define GETCOLORTABLE           5
#define FLUSHOUTPUT             6
#define DRAFTMODE               7
#define QUERYESCSUPPORT         8
#define SETABORTPROC            9
#define STARTDOC                10
#define ENDDOC                  11
#define GETPHYSPAGESIZE         12
#define GETPRINTINGOFFSET       13
#define GETSCALINGFACTOR        14

#define SETCOPYCOUNT            17
#define SELECTPAPERSOURCE       18
#define PASSTHROUGH             19
#define GETTECHNOLOGY           20
#define SETLINECAP              21
#define SETLINEJOIN             22
#define SETMITERLIMIT           23
#define BANDINFO                24
#define DRAWPATTERNRECT         25
#define GETVECTORPENSIZE        26
#define GETVECTORBRUSHSIZE      27
#define ENABLEDUPLEX            28
#define GETSETPAPERBINS         29
#define GETSETPAPERORIENTATION  30
#define ENUMPAPERBINS           31
#define SETDIBSCALING           32
#define EPSPRINTING             33
#define ENUMPAPERMETRICS        34
#define GETSETPAPERMETRICS      35
#define GETVERSION              36      // not in DDK  -- not implemented
#define POSTSCRIPTDATA          37      // not in DDK
#define POSTSCRIPTIGNORE        38      // not in DDK

#define RESETDC                 128 

#define GETEXTENDEDTEXTMETRICS  256
#define GETEXTENTTABLE          257
#define GETPAIRKERNTABLE        258
#define GETTRACKKERNTABLE       259

#define EXTEXTOUT               512
#define GETFACENAME             513
#define DOWNLOADFACE            514     // not in DDK
#define ATMINFO                 520     // not in DDK

#define ENABLERELATIVEWIDTHS    768
#define ENABLEPAIRKERNING       769
#define SETKERNTRACK            770
#define SETALLJUSTVALUES        771
#define SETCHARSET              772     // not in DDK

#define GETSETSCREENPARAMS	3072
#define GETDIBSUPPORT		3073	// new!

#define BEGINPATH               4096
#define CLIPTOPATH              4097
#define ENDPATH                 4098
#define EXTDEVICECAPS           4099
#define RESTORECTM              4100
#define SAVECTM                 4101
#define SETARCDIRECTION         4102
#define SETBACKGROUNDCOLOR      4103     // not in DDK
#define SETPOLYMODE             4104
#define SETSCREENANGLE          4105
#define SETSPREAD               4106
#define TRANSFORMCTM            4107
#define SETCLIPBOX              4108
#define SETBOUNDS               4109
/* Micrografx escapes that conflict with nre Aldus escapes */
#define SETMIRRORMODE           4110
#define SETSCREENFREQUENCY      4111     // not in DDK
#define GETSCANORIENTATION      4112     // not in DDK
#define SCANFILL                4113     // not in DDK
#define POLYSET                 4114     // not in DDK
#define DRAWBITMAP              4115     // not in DDK
// New Aldus escapes
#define OPENCHANNEL             4110
#define DOWNLOADHEADER          4111     // not in DDK
#define CLOSECHANNEL            4112     // not in DDK
#define SETGDIXFORM             4113     // not in DDK
#define RESETPAGE               4114     // not in DDK
#define POSTSCRIPT_PASSTHROUGH  4115     // not in DDK
#define ENCAPSULATED_POSTSCRIPT 4116     // not in DDK

// New AdobePS escapes.
#define DOWNLOADFACESTR  	    4565     // not in DDK, String in next Escape(DOWNLOADFACE) call
#define SPCLPASSTHROUGH  	    4567     // not in DDK, special pass through. same as in AdobePS 3.0
#define SPCLPASSTHROUGH2  	    4568     // not in DDK, special pass through 2, callable for multiple times.
// to be the same as NT4/NT5 PS Injection
#define SPCLPSINJECTION  	    4118     // not in DDK, PostScript Injection, callable for multiple times.


SHORT FAR PASCAL ESCNotImplemented(LPPDEVICE,LP,LP);

SHORT FAR PASCAL ESCNewFrame(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCAbortDoc(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCNextBand(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetColorTable(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCFlushOutput(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCQueryEscSupport(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetAbortProc(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCStartDoc(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCEndDoc(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetPhysPageSize(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetPrintingOffset(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetScalingFactor(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetCopyCount(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCPassThrough(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetTechnology(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetLineCap(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetLineJoin(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetMiterLimit(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCEnableDuplex(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetSetPaperBins(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetSetPaperOrientation(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCEnumPaperBins(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetDIBSupport(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetDIBScaling(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCEPSPrinting(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCEnumPaperMetrics(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetSetPaperMetrics(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetVersion(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCPostScriptData(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCPostScriptIgnore(LPPDEVICE,LP,LP);

short FAR PASCAL ESCGetSetScreenParams(LPPDEVICE  lpdv,LP lpbIn ,LP lpbOut);

SHORT FAR PASCAL ESCGetExtendedTextMetrics(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetExtentTable(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetPairKernTable(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetTrackKernTable(LPPDEVICE,LP,LP);

SHORT FAR PASCAL ESCExtTextOut(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCGetFaceName(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCDownLoadFace(LPPDEVICE,LP,LP);

SHORT FAR PASCAL ESCEnablePairKerning(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetKernTrack(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetAllJustValues(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetCharset(LPPDEVICE,LP,LP);

SHORT FAR PASCAL ESCBeginPath(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCClipToPath(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCEndPath(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCExtDeviceCaps(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCRestoreCTM(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSaveCTM(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetArcDirection(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetBackgroundColor(LPPDEVICE,LP,LP);       /* ? */
SHORT FAR PASCAL ESCSetPolyMode(LPPDEVICE,LP,LP);

SHORT FAR PASCAL ESCSetSpread(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCTransformCTM(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetClipBox(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetBounds(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetMirrorMode(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCResetDC(LPPDEVICE,LPPDEVICE);
SHORT FAR PASCAL ESCSetScreenFrequency(LPPDEVICE,LPFREQUENCY,LPFREQUENCY);
SHORT FAR PASCAL ESCSetScreenAngle(LPPDEVICE,LP,LP);

SHORT FAR PASCAL ESCDownLoadHeader(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCOpenChannel(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCCloseChannel(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCSetGDIXForm(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCResetPage(LPPDEVICE,LP,LP);
SHORT FAR PASCAL ESCPostScriptPass(LPPDEVICE,LP,LP);
#ifdef ADOBE_DRIVER
int GetWM_NUP_Confirmation(LPPDEVICE);
int ConfirmWM_NUP(LPPDEVICE);
int FAR PASCAL ProdVersionStr(LPSTR szExeName, LPSTR szExeVer);
short FAR PASCAL ESCSpecialPass(LP,LP,LP);

short FAR PASCAL ESCDownLoadFaceStr(LP,LP,LP);
short FAR PASCAL ESCSpecialPass(LP,LP,LP);
short FAR PASCAL ESCPSInjection(LP,LP,LP);
#endif
