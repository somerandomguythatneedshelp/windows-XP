/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1994 Adobe Systems, Inc. All rights reserved.               */
/*                                                                           */
/* Include File Name: WATERMAR.H                                             */
/*                                                                           */
/* Description: Include for Watermar.c                                       */
/*                                                                           */
/*****************************************************************************/

#define     MAXSECTNAME     32      /* ini file section heading, AdobePS WaterMarks */
#define     MAXWMNAME       19
#define     MAXINIFNAME     13      /* ini filename */
#define     MAXWMTXT        256     /* max text length in a wm record */
#define     MAXWMNAMEBFR    32000  /* was 4096. size of buffer for reading WM names */
#define     MAXWMOTHERS     64    /* lenght for other settings: color, pos-x, ... */

#define     MAXINISTR   MAXWMTXT+LF_FACESIZE+MAXWMOTHERS /* ini file string buffer  */
#define     MAXWMFIELDS 14      /* # of fields in a Watermark */

typedef struct {                /* watermark record */
  DWORD     dwWatermarkID;
  long      xpos;
  long      ypos;
// added for Adobeps
  BYTE      R;
  BYTE      G;
  BYTE      B;      // was int gray;
  int       outline;    // flag for outline watermark
  int       background;
  int       passthrough;  // flag for pass through PS code, not used today
  LOGFONT   lf;
  char      text[MAXWMTXT];
} WM, FAR* LPWM;

BOOL WINAPI ReadWatermark(DWORD dwWatermarkID,LPWM pwm);
void PASCAL WriteWatermark(LPWM pwm);
// Function to free the memory for Watermark stuff
short FAR PASCAL FreeWaterMark(LPPDEVICE lppd);


extern char decimalSeparator[4];

BOOL _loadds FAR PASCAL CHWaterMarksDlg(HWND hdlg, unsigned msg, WORD wParam, 
                                   LONG lParam);

