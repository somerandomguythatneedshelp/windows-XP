/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DMEMORY.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for Driver Memory usage.  */
/*                                                                           */
/*****************************************************************************/

#include "ps.h"         // Also includes PRINT.H, WINDOWS.H, GDIDEFS.INC etc..
#include "memory.h"


HANDLE FAR PASCAL MGAlloc(LPPDEVICE lppd, DWORD dSize, WORD wFlags, BOOL JmpFlag)
/******************************************************************************

  function:
       This routine calls GlobalAlloc() to allocate a block of memory from the
       global heap. If an error occurs, it is reported to the error manager.

  arguments:
       lppd - pdevice pointer
       dSize - # of bytes to allocate
       wFlags - flags passed on to GlobalAlloc. This should usually be set to
         GHND, which is defined in windows.h as GMEM_MOVEABLE | GMEM_ZEROINIT
       JmpFlag - if TRUE then EJmpOut on error

  returns:
       If allocation succeeds, then the handle to the memory block is returned.
       If allocation fails, 0 is returned.
       Note that we don't return at all if JmpFlag==TRUE and the routine fails.

******************************************************************************/
{
   return (GlobalAlloc(wFlags, dSize) ) ;
}

//
LPSTR FAR PASCAL MGLock(LPPDEVICE lppd, HANDLE handle, BOOL JmpFlag)
/******************************************************************************

  function:
       This routine locks the global memory block associated with a specified
       handle. If an error occurs, it is reported to the error manager.

  arguments:
       lppd - pdevice pointer
       handle - handle to the memory block
       JmpFlag - if TRUE then EJmpOut on error

  returns:
       If lock succeeds, then the ptr to the memory block is returned.
       If lock fails, NULL is returned.
       Note that we don't return at all if JmpFlag==TRUE and the routine fails.

******************************************************************************/
{
   return(GlobalLock(handle));
}

//
LPSTR FAR PASCAL MGAllocLock(LPPDEVICE lppd, LPHANDLE lpHandle, DWORD dSize,
                             WORD wFlags, BOOL JmpFlag)
/******************************************************************************

  function:
       This routine allocates a global memory block of a specified size and
       then locks it. If an error occurs, it is reported to the error manager.

  arguments:
       lppd - pdevice pointer
       lpHandle - ptr to handle to the memory block
       dSize - # of bytes to allocate
       wFlags - flags passed on to GlobalAlloc. This should usually be set to
         GHND, which is defined in windows.h as GMEM_MOVEABLE | GMEM_ZEROINIT
       JmpFlag - if TRUE then EJmpOut on error

  returns:
       If success, then the ptr to the memory block is returned.
       If failure, NULL is returned.
       Note that we don't return at all if JmpFlag==TRUE and the routine fails.

******************************************************************************/
{
   LPSTR lpMem = NULL ;

   if (*lpHandle=GlobalAlloc(wFlags,dSize))
   {
       lpMem = GlobalLock(*lpHandle) ;
       if (!lpMem) //Cannot lock, so free block just allocated.
       {
          GlobalFree(*lpHandle) ;
          *lpHandle = 0 ;
       }
   }
   return(lpMem);
}

//
HANDLE FAR PASCAL MGReAlloc(LPPDEVICE lppd, HANDLE oldhdl, DWORD dSize,
                            WORD wFlags, BOOL JmpFlag)
/******************************************************************************

  function:
       This routine calls GlobalReAlloc() to reallocate a block of memory from
       the global heap. If an error occurs, it is reported to the error manager.
       This routine will fail if the memory block is locked.

  arguments:
       lppd - pdevice pointer
       oldhdl - handle to the memory block that is to be reallocated.
       dSize - # of bytes to allocate
       wFlags - flags passed on to GlobalAlloc. This should usually be set to
         GHND, which is defined in windows.h as GMEM_MOVEABLE | GMEM_ZEROINIT
       JmpFlag - if TRUE then EJmpOut on error

  returns:
       If reallocation succeeds, then the handle to the memory block is returned.
       If reallocation fails, 0 is returned.
       Note that we don't return at all if JmpFlag==TRUE and the routine fails.

******************************************************************************/
{
   HANDLE newhdl = 0 ;

     if (oldhdl == NULL)
       newhdl = GlobalAlloc( wFlags, dSize);
     else
       newhdl = GlobalReAlloc(oldhdl, dSize, wFlags);

   return(newhdl) ;
}

//
HANDLE FAR PASCAL MGFree(LPPDEVICE lppd, HANDLE handle, BOOL JmpFlag)
/******************************************************************************

  function:
       This routine frees a specified memory block.
       If an error occurs, it is reported to the error manager.

  arguments:
       LPPDEVICE lppd - pdevice pointer
       handle - handle to the memory block
       JmpFlag - if TRUE then EJmpOut on error

  returns:
       If success, NULL is returned,
       else handle is returned.
       Note that we don't return at all if JmpFlag==TRUE and the routine fails.

******************************************************************************/
{
   return(GlobalFree(handle)) ;
}

//
VOID FAR PASCAL MGUnlock(HANDLE handle)
/******************************************************************************

  function:
       This routine calls GlobalUnlock to unlock a specified memory block.
       This routine should be called instead of GlobalUnlock. It is provided
       to facillitate debugging.

  arguments:
       handle - handle to the memory block

  returns: None

******************************************************************************/
{
   GlobalUnlock(handle) ;
}

//
HANDLE FAR PASCAL MGUnlockFree(LPPDEVICE lppd, HANDLE handle, BOOL JmpFlag)
/******************************************************************************

  function:
       This routine unlocks a memory block and then frees it.
       If an error occurs, it is reported to the error manager.

  arguments:
       lppd - pdevice pointer
       handle - handle to the memory block
       JmpFlag - if TRUE then EJmpOut on error

  returns:
       If success, NULL is returned,
       else handle is returned.
       Note that we don't return at all if JmpFlag==TRUE and the routine fails.

******************************************************************************/
{

      GlobalUnlock(handle) ;
      return(GlobalFree(handle)) ;
}

