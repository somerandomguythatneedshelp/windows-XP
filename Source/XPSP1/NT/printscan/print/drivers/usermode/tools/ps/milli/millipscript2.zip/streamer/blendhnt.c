/*
  blendhnt.c

Original code taken from bcsetup.c

Copyright (c) 1994 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of
Adobe Systems Incorporated.  Many of the intellectual and
technical concepts contained herein are proprietary to Adobe,
are protected as trade secrets, and are made available only to
Adobe licensees for their internal use.  Any reproduction or
dissemination of this software is strictly forbidden unless
prior written permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks of
Adobe Systems Incorporated.

Original version: Ron Fischer  Apr 8, 1994
Edit History:

End Edit History.


*/

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif

#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES
#include FP
#include BUILDCH
#include "bcmatrix.h"


/* ---------------------------------------------------------------------------
    NAME: GetHintData

    PURPOSE: Initialize the fields of  FontValues to their default values.

   ---------------------------------------------------------------------------
*/
PRIVATE FontValues *GetHintData ARGDEF2(FontDesc *, pFontData, CardX, i)
{
  return (FontValues *) &pFontData->values[0] + i;
}

/* ---------------------------------------------------------------------------
    NAME: InitHintData

    PURPOSE: Initialize the fields of a FontValues to their default values.

   ---------------------------------------------------------------------------
*/

PRIVATE procedure InitHintData ARGDEF1(FontValues *, pHintBlock)
{
  register int j;

  pHintBlock->stdHW = 0;
  pHintBlock->stdVW = 0;
  pHintBlock->defaultSidebearingX = 0;
  pHintBlock->defaultSidebearingY = 0;
  pHintBlock->defaultWidthX = 0;
  pHintBlock->defaultWidthY = 0;
  pHintBlock->blueScale = 0;
  pHintBlock->blueFuzz = 0;
  pHintBlock->blueShift = 0;
  pHintBlock->fontBBox.bl.x = 0;
  pHintBlock->fontBBox.bl.y = 0;
  pHintBlock->fontBBox.tr.x = 0;
  pHintBlock->fontBBox.tr.y = 0;
  for (j = 0; j < MAXSTEMS; j++)
    pHintBlock->stemSnapH[j] = 0;
  for (j = 0; j < MAXSTEMS; j++)
    pHintBlock->stemSnapV[j] = 0;
  for (j = 0; j < MAXBLUES; j++) {
    pHintBlock->blueValues[j].topEdge = 0;
    pHintBlock->blueValues[j].botEdge = 0;
    pHintBlock->familyBlueValues[j].topEdge = 0;
    pHintBlock->familyBlueValues[j].botEdge = 0;
  }
}

/* ---------------------------------------------------------------------------
    NAME: BlendHintData

    PURPOSE: Apply the weight vector to the the hint data of a multi master
    font.

    DESCRIPTION: A multi master font has seperate hint data for each base
    font. The blended value is the dot product of the weight vector with the
    values from each base font.

   ---------------------------------------------------------------------------
*/
PUBLIC procedure BlendHintData
  ARGDEF3(
  FontDesc *, pFontData,
  Fixed *, pWeightVector,
  register FontValues *, pHintBlock
 )
{

  register FontValues  *pHBlk;
  register Fixed weightVal;
  register int j;
  int i, len, nBlues;
  CardX lenWV = pFontData->numMasters;
  Fixed fbSum = 0;

  InitHintData(pHintBlock);

  /*
     Calculate the blended value for each field in FontValues.
     The following loop sums the product of the WeightVector and the
     value of the field for each base font. This assumes that the
     length of the WeightVector is the same as the number of base fonts.
  */
  for (i = 0; i < (int)lenWV; i++) {

     /* Get pointer to the hint data for the basefont */
     pHBlk = GetHintData(pFontData, i);
     weightVal = pWeightVector[i];
     /* stdHW, stdVW, blueScale, blueFuzz, blueShift */
     pHintBlock->stdHW += fixmul(weightVal,pHBlk->stdHW);
     pHintBlock->stdVW += fixmul(weightVal,pHBlk->stdVW);
     pHintBlock->defaultSidebearingX += 
	fixmul(weightVal,pHBlk->defaultSidebearingX);
     pHintBlock->defaultSidebearingY += 
        fixmul(weightVal,pHBlk->defaultSidebearingY);
     pHintBlock->defaultWidthX += fixmul(weightVal,pHBlk->defaultWidthX);
     pHintBlock->defaultWidthY += fixmul(weightVal,pHBlk->defaultWidthY);
     pHintBlock->blueScale += fixmul(weightVal,pHBlk->blueScale);
     pHintBlock->blueFuzz += fixmul(weightVal,pHBlk->blueFuzz);
     pHintBlock->blueShift += fixmul(weightVal,pHBlk->blueShift);
     pHintBlock->fontBBox.bl.x += fixmul(weightVal,pHBlk->fontBBox.bl.x);
     pHintBlock->fontBBox.bl.y += fixmul(weightVal,pHBlk->fontBBox.bl.y);
     pHintBlock->fontBBox.tr.x += fixmul(weightVal,pHBlk->fontBBox.tr.x);
     pHintBlock->fontBBox.tr.y += fixmul(weightVal,pHBlk->fontBBox.tr.y);

     len = pFontData->lenStemSnapH;
     for (j = 0; j < len; j++)
       pHintBlock->stemSnapH[j] +=
         fixmul(weightVal, pHBlk->stemSnapH[j]);

     len = pFontData->lenStemSnapV;
     for (j = 0; j < len; j++)
       pHintBlock->stemSnapV[j] +=
         fixmul(weightVal, pHBlk->stemSnapV[j]);

     /* BlueValues and familyBlueValues */

     nBlues = pFontData->numBlueValues;
     for (j = 0; j < nBlues; j++) {
       pHintBlock->blueValues[j].topEdge +=
         fixmul(weightVal, pHBlk->blueValues[j].topEdge);
       pHintBlock->blueValues[j].botEdge +=
         fixmul(weightVal, pHBlk->blueValues[j].botEdge);
     }
     /* Fix 05/26/94 by rff.  Purify complained because this was part of */
     /* the regular blues loop.  If there were no family blues they were not */
     /* initialized, but were used in the loop. */
     for (j = 0; j < (int)pFontData->numFamilyBlues; j++) {
       pHintBlock->familyBlueValues[j].topEdge +=
         fixmul(weightVal, pHBlk->familyBlueValues[j].topEdge);
       pHintBlock->familyBlueValues[j].botEdge +=
         fixmul(weightVal, pHBlk->familyBlueValues[j].botEdge);
     }
     if (pHBlk->flags & FONT_FORCEBOLD)
       fbSum += weightVal;
   } /* for i <= lenWV */

  /* Sort both stem snap arrays */
  if (pHintBlock->stdHW < 0)
    pHintBlock->stdHW = 0;
  if (pHintBlock->stdVW < 0)
    pHintBlock->stdVW = 0;

  /* blendFlags */
  pHintBlock->flags = pFontData->values[0].flags;
  if (fbSum > pFontData->boldThreshold)
    pHintBlock->flags |= FONT_FORCEBOLD;

}

