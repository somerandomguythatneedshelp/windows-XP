
// CJKFonts.h

#ifndef _CJKFONTS_H_IN
#define _CJKFONTS_H_IN

// Stuff defined for cjkfonts.c

#define MAX_DBRANGES  7   // In ALL CJK, only 6 ranges are maximal
#define MAX_SBRANGES  4   // maximal 4-single byte ranges in Johab

#define MAX_1STBRANGES 5  // Max 1st byte ranges for single or double byte fonts

#define LIMIT_32K  (LONG)0x7FFF
// Following are for CJK/DBCS only.
#define MAX_NUM_CHARS_CJK   ((LONG)24200)   // maximal possible chars inCJK. XGB-extended GB
#define MAX_NUM_CHARS_US    ((LONG)256)   // maximal possible chars in all western charset

typedef struct tagGITABLE
{
   LOGFONT lf;     // the log font structure - used to identify a table
   BOOL   bEUDC;   // include EUDC chars ?
   LPWORD lpwGI;
   WORD  n;         // maximal OID for this charset: 0 to n-1
 } GITABLE, FAR *LPGITABLE;


typedef struct tagDBCSRANGE
{
  BYTE min_1;
  BYTE max_1;    // range for Byte-1
  BYTE min_2;
  BYTE max_2;    // range for Byte-2
  WORD start;    // base ID for this range
  WORD end;      // IDs are [start, end-1].
} DBCSRANGE;

typedef struct tagFIRSTBYTERANGE
{
  BYTE min;
  BYTE max;    // range for Byte-1
} FIRSTBYTERANGE;


typedef struct tagDBCSENCODE
{
   BYTE charset;
   int  numDBRange;  // Number of discountinuous 2-Byte ranges
   DBCSRANGE DBCSRanges[MAX_DBRANGES]; 
   int  numSBRange;
   DBCSRANGE SBRanges[MAX_SBRANGES];   // only 2 ranges are maximal - in SJIS
   WORD n;           // maximal OID for this charset: 0 to n-1
   FIRSTBYTERANGE Single[MAX_1STBRANGES];
   FIRSTBYTERANGE Double[MAX_1STBRANGES];
 } DBCSENCODE, FAR *LPDBCSENCODE;

typedef struct tagCMAPInfo
{
   char CMapName[30];    // Our names are limited to 30 chars
   int  CMapVersion;     // This is an integer. see CMAP doc.
   int  CMapType;
   char Registry[20];    // Ours are limited to 20 chars
   char Ordering[20];    // Ours are limited to 20 chars
   int  Supplement;
} CMAPINFO, FAR  *LPCMAPINFO;



enum {
   ONEBYTE, BIG5, GB80, SJIS, KS87, KS92,
   GI_FFFF,  // for Glyph-Index based CID: 0 upto 0xFFFE
   DBCS_LAST};// 1byte, C-T, C-S, J, K-W, K-J


LPDBCSENCODE FAR PASCAL GetEncoding(int charset, BOOL bEUDC);
WORD FAR PASCAL GetOIDFromChar(LPBYTE lpStr, BYTE charset, BOOL bEUDC);
int FAR PASCAL FillGlyphIndexTable(HWND hwnd, LPGITABLE lpGITable);
LPCMAPINFO FAR PASCAL GetCMAPInfo(int charset, int bVertical);
int FAR PASCAL Fill1ByteGlyphIndexTable(LPLOGFONT lf, LPWORD lpW1ByteGI);
int FAR PASCAL GetCIDCount(int charset, BOOL bEUDC);
WORD FAR PASCAL GetGlyphIndexFromOID(LPLOGFONT lf, WORD oid, BOOL bEUDC);

#endif
