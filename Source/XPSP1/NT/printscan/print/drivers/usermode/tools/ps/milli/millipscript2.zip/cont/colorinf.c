/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: COLORINF.C                                                   */
/*                                                                           */
/* Description: This module contains the function for converting logical     */
/*              colors to physical colors on the device and visa versa.      */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_REALIZESEG)


DWORD FAR PASCAL dmColorInfo(LP,DWORD,LPPCOLOR);

/***************************************************************************
*                               ColorInfo
*  function:
*       this is the functions which maps logical colors to physical
*       colors on the device and vice versa.
*  prototype:
*       DWORD FAR PASCAL ColorInfo(LP lp,DWORD dColorIn,LPPCOLOR lpPColor);
*  parameters:
*       LP       lp -- pointer to PDEVICE or BITMAP
*       DWORD    dColorIn -- incoming color value (RGB) to be mapped
*       LPPCOLOR lpPColor -- pointer to the location in which to return
*                            the physical color (if logical to physical)
*  returns:
*       DWORD == the logical color
*  note:
*       this function must be expanded if we are going to do indexed color
*       and the issue of the number of logical colors to allow must be
*       revisited
*                                                                           
***************************************************************************/

DWORD _loadds FAR PASCAL ColorInfo(LP lp,DWORD dColorIn,LPPCOLOR lpPColor)
{
   LPPDEVICE lpdv = (LPPDEVICE)lp;
   short     sMagic;
   DWORD     colorout;
   
   sMagic=*((LPSHORT)lpdv);  // first word is PDEVICE or BITMAP flag
   
   if (sMagic != LUCAS)      // check for BITMAP
   {
      colorout = dmColorInfo(lp,dColorIn,lpPColor);
   }
   else
   {
         // are we converting logical to physical?
         if (lpPColor != NULL)
         {
            *lpPColor = dColorIn;  // yes -- physical
                                   // color is the same
                                   // as logical
         }
         if ( lpdv->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR)
         {
            // this code assumes an 8 color device
            // (which is what the MS driver does)
            // note: The number of colors assumed should be
            // reflected in the number of colors reported
            // to GDI in the GDIINFO struct returned by
            // Enable.
            //
            // set each of the RGB values to on or off --
            // gives a total of 8 colors

            colorout = RGB_BLACK;
            if (GetRValue(dColorIn) > 127)
            {
               colorout |= 0x000000FF;
            }
            if (GetGValue(dColorIn) > 127)
            {
               colorout |= 0x0000FF00;
            }
            if (GetBValue(dColorIn) > 127)
            {
               colorout |= 0x00FF0000;
            }
         }
         else
         {
            // monochrome device
            // this mapping formula comes from the DDK,
            // page 12-15
            colorout   = (DWORD)(GetGValue(dColorIn) * 5);
            colorout  += (DWORD)(GetRValue(dColorIn) * 3);
            colorout  += (DWORD)GetBValue(dColorIn);
            colorout  += 4;
            colorout >>= 3;

            if (colorout > 128)
            {
               colorout = RGB_WHITE;
            }
            else
            {
               colorout = RGB_BLACK;
            }
         }
   }
   return(colorout);
} // END Colorinfo


