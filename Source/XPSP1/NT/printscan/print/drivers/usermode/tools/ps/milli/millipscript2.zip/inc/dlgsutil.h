/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: DLGSUTIL.H                                             */
/*                                                                           */
/* Description: This include contains the prototypes for dlgsutil.c          */
/*                                                                           */
/*****************************************************************************/

#define ID_DEV_PRINTER_STICKY  1
#define ID_DEV_DOCUMENT_STICKY 2

#define SCREENUPDATE_NONE          1
#define SCREENUPDATE_CURRENT       2
#define SCREENUPDATE_UICONSTRAINTS 3
#define SCREENUPDATE_ALL           4

#ifdef OLDAdobe_Driver
// Return value of UICCheckAllOptions()
#define UIC_NO_CONSTRAINT   1
#define UIC_CONSTRAINT      2
#define UIC_IGNORE_CONSTRAINT   3
#define UIC_RESOLVE_CONSTRAINT  4
#endif

#ifdef ADOBE_DRIVER
#define NUM_CUSTOM_PAPER_ICON 5
#endif

typedef enum BNSTATE_T { NOFOCUS, FOCUS, PUSHED } BNSTATE;

typedef void (NEAR PASCAL *SPINRANGEPROC)(HWND hDlg, LPDRIVERINFO lpDrvInfo,
                                          BOOL bInches);

VOID FAR PASCAL ShowErrorValueMessage(HWND hDlg, WORD ctrl_id, long minVal, long maxVal);

void NEAR DIALOGSSEG PASCAL ReSizeComboBox(HWND hDlg, int iCtrlID);
int  NEAR DIALOGSSEG PASCAL GetMeasurementUnit(BOOL bFlipped);

#ifdef ADOBE_DRIVER
void FAR DIALOGSSEG PASCAL FixedMulDiv(DWORD number, int mult, int div,
                                        int nDecimals, LPINT quotient,
                                        LPINT remainder);
#else
void NEAR DIALOGSSEG PASCAL FixedMulDiv(DWORD number, int mult, int div,
                                        int nDecimals, LPINT quotient,
                                        LPINT remainder);
#endif
void NEAR DIALOGSSEG PASCAL DisplayFixedPointNumber(HWND hDlg, int iCtrlID,
                                                    int whole, int part,
                                                    LPSTR  lpDecimal,
                                                    int iNumDecimals);

void FAR PASCAL SetDlgItemLong(HWND hDlg, int iCtrlID, DWORD number, BOOL bBeep);  

#ifdef ADOBE_DRIVER
DWORD FAR DIALOGSSEG PASCAL GetDlgItemReal(HWND hDlg, int ictrl, int nDecimals,
                                           LPSTR decimalSeparator,
                                           LPBOOL lpbSuccess, BOOL bBeep);
#else
DWORD NEAR DIALOGSSEG PASCAL GetDlgItemReal(HWND hDlg, int ictrl, int nDecimals,
                                           LPSTR decimalSeparator,
                                           LPBOOL lpbSuccess, BOOL bBeep);
#endif

BOOL NEAR DIALOGSSEG PASCAL RetrieveDialogValues(HWND hDlg, LPWORD lpValue,
                                                 int nitems,
                                                 int ictrl, BOOL bInches);

void NEAR DIALOGSSEG PASCAL DoDisplayDialogValues(HWND hDlg, LPWORD lpValue,
                                                  int nitems,
                                                  int ictrl, BOOL bInches);

#ifdef ADOBE_DRIVER
void FAR DIALOGSSEG PASCAL SetCurrentSpinPos(HWND hDlg, int spinCtrl,
                                              int editCtrl, int nitems,
                                              int nDecimals);
#else
void NEAR DIALOGSSEG PASCAL SetCurrentSpinPos(HWND hDlg, int spinCtrl,
                                              int editCtrl, int nitems,
                                              int nDecimals);
#endif

void NEAR DIALOGSSEG PASCAL HandleMetricChange(HWND hDlg, LPWORD lpValue,
                                              int nitems, int spinCtrl,
                                              int editCtrl, WORD wParam,
                                              SPINRANGEPROC fnSetRange,
                                              LPDRIVERINFO lpDrvInfo);

void NEAR DIALOGSSEG PASCAL HandleEditControlChange(HWND hDlg, int spinCtrl,
                                                    int editCtrl,
                                                    WORD wParam, BOOL bInches);

void NEAR DIALOGSSEG PASCAL HandleSpinControlChange(HWND hDlg, int spinCtrl,
                                                    int editCtrl, WORD wID,
                                                    DWORD value, BOOL bInches);

WORD NEAR DIALOGSSEG PASCAL UICSetCurrentOption(LPDRIVERINFO lpDrvInfo,
                                                WORD keyword, WORD option,
                                                HWND hDlg);

#ifdef ADOBE_DRIVER
BOOL FAR DIALOGSSEG PASCAL UICCheckAllOptions(LPDRIVERINFO lpDrvInfo,
                                               HWND hDlg, BOOL bRestoreDefaults,
                                               WORD wFlags);
#else
BOOL NEAR DIALOGSSEG PASCAL UICCheckAllOptions(LPDRIVERINFO lpDrvInfo,
                                               HWND hDlg, BOOL bRestoreDefaults,
                                               WORD wFlags);
#endif


void NEAR DIALOGSSEG PASCAL HandleMeasureItem(HWND hDlg,
                                              LPDRIVERINFO lpDrvInfo,
                                              int iCtrl,
                                              LPMEASUREITEMSTRUCT lpmi);

void NEAR DIALOGSSEG PASCAL HandleDrawItem(HWND hDlg,
                                           LPDRIVERINFO lpDrvInfo,
                                           int iCtrl,
                                           LPDRAWITEMSTRUCT lpdi);

void NEAR DIALOGSSEG PASCAL TruncateToTabStop(HWND hDlg,
                                              LPSTR buffer,
                                              int iTabStop);

#ifdef ADOBE_DRIVER
void FAR DIALOGSSEG PASCAL GetDecimalSeparator(LPSTR lpDecimalSeparator,
                                                int iMaxBuffLen);
#else
void NEAR DIALOGSSEG PASCAL GetDecimalSeparator(LPSTR lpDecimalSeparator,
                                                int iMaxBuffLen);
#endif

void FAR PASCAL TruncateToFitControl(HWND hDlg, int iCtrlID,
                                                 LPSTR lpSrc, LPSTR lpDest);

WORD _loadds FAR PASCAL DevInstall(HWND  hWnd, LPSTR lpszModelName,
                                   LPSTR lpszOldPort,
                                   LPSTR lpszNewPort );

VOID NEAR DIALOGSSEG PASCAL PositionControls(HWND  hDlg,
                                             LPINT lpxOffset,
                                             LPINT lpyOffset,
                                             DWORD dwFlags,
                                             WORD  wFirstID,
                                             WORD  wLastID,
                                             WORD  wRefID);

void FAR PASCAL ValidatePicture(HWND hDlg, WORD idcPicture, BOOL validate);
void FAR PASCAL DrawPicture( HWND hDlg, int id, int nBmp, int nMaskBmp, 
                             int mode, int xoffset, int yoffset );
void FAR PASCAL HandleDrawButton( HWND hDlg, LPDRAWITEMSTRUCT lpdis, BNSTATE state,
                                  int xoffset, int yoffset );
LPSTR FAR PASCAL ExtractFileName( LPSTR lpszFileNameWithPath );

#ifdef ADOBE_DRIVER
WORD NEAR PASCAL GetCustomPaperID(LPDRIVERINFO lpDrvInfo, int nIndex);
#endif

#if 0
LRESULT _loadds CALLBACK KeyboardHookProc(int code, WPARAM wParam,
                                          LPARAM lParam);
int _loadds FAR PASCAL Keyboard30HookProc(int code, WPARAM wParam,
                                          LPARAM lParam);
void WriteProfileInt(LPSTR section, LPSTR entry, int i);

BOOL OemDllExists(LPPDEVICE lppd);
void SetOemDllExists(HANDLE hPrinter, LPPDEVICE lppd, BOOL bExists);
BOOL OemHelpExists(LPPDEVICE lppd);
void SetOemHelpExists(HANDLE hPrinter, LPPDEVICE lppd, BOOL bExists);
void GetOemBaseName(LPPDEVICE lppd, LPSTR lpBaseName, int BaseNameBufSize);
int CallOEMInstall(HWND hWnd, LPSTR lpDevType, LPSTR lpOldPort, LPSTR lpNewPort,
                     LPPDEVICE lppd);
void InitOEMExistanceFlags(LPPDEVICE lppd);
void SetOEMHelpFileName(LPPDEVICE lppd);

int DrvModalDialogBox(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode, HANDLE ghDriverMod,
                      HWND hDlg, DLGPROC fnDlg, LPSTR lpDlgName,
                      LPSTR lpOemDlgName, LPSTR lpOemFnName);
BOOL DrvProcessHookProc(LPPDEVICE lppd, HWND hDlg, unsigned uMsg,
                      WORD wParam, LONG lParam, LPSTR lpOemHookFnName);

VOID FAR PASCAL AbortDevmodeDlg(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode,
                  LPPSEXTDEVMODE lpArgDevmode, HWND hdlg, int status);
BOOL FAR IsWin31(void);
BOOL FAR IsWin40(void);

HANDLE MakeFakePDevice(LPSTR lpszModelName, LPSTR lpszNewPort);

// from DLGS2.H
int FAR PASCAL AdvancePastViableKeywords(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode,
                     int iViableKeywordIndex);

#endif
