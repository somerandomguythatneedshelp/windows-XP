/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993, 1994 Microsoft Corporation. All rights reserved.      */
/*                                                                           */
/* Module Name: T3OUTLN.C                                                    */
/*                                                                           */
/* Description: This module contains TRANSLATE layer functions for font      */
/*              download, font instantiations such as basic font, bold font, */
/*              italic font, bolditalic font and a scaled font. Also, all    */
/*              text output functions invoked by the CONTROL layer function  */
/*              DevExtTextOut() are in this module. Almost all functions in  */
/*              this module generate output sent with the job stream.        */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include <string.h>

#pragma code_seg(_TTEXTSEG)

#ifdef T3OUTLINE

LONG NEAR PASCAL CSAddNumber_T3(LPPDEVICE lppd, LONG dw);
LONG NEAR PASCAL CSAddString_T3(LPPDEVICE lppd, LPSTR lpStr);

/***************************************************************************
*
*                               CharString
*
*    Function:  Translates symbolic Type 1 character commands into
*               their encoded, encrypted equivalent.  The list of
*               available commands is in pst1enc.h.  They are used
*               by passing the command constant followed by the long
*               arguments required by the function.
*
*               Example: CharString(lppd, RMOVETO, lx, ly);
*
*               To make a character definition use STARTCHAR, followed
*               by all of the Type 1 character commands, and ending with
*               ENDCHAR.  The return value from CharString(ENDCHAR) is a
*               DWORD containing the local handle in the high word and the
*               length in the low word.  The buffer contains the CharString
*               encrypted/encoded representation.  Given the length and the
*               properly encrypted data, the caller has enough information
*               to generate PS code that will add the character to a font
*               definition.  For more detail see Chapters 2 and 6 in the
*               Black Book.
*
*               *** This routine must be FAR (not FAR PASCAL) since it
*               *** uses a variable argument list.
*
*    Called:  DWORD FAR CharString(LPPDEVICE lppd, DWORD dwCmd, ...)
*
*    Parameters:  LPPDEVICE lppd
*                 DWORD dwCmd
*                 ...
*    Returns:   0L if the command succeeded, -1L if the command failed.  If
*               dwCmd == ENDCHAR, the return value is -1L for failure and
*               a DWORD where the low word is the buffer length and the high
*               word is the buffer handle if the command succeeded.
*
***************************************************************************/
// 'e' optimization option will cause the "internal compiler error,
// restartable" warning message. Turn it off for this function.
#pragma optimize("e", off)

DWORD FAR       CharString_T3OL(LPPDEVICE lppd, DWORD dwCmd,...)
{
    LPTTTOTYPE1STUFF lpTTtoT1stuff =
    (LPTTTOTYPE1STUFF) & lppd->GlobalBuffer.TTtoT1stuff;

    LPLONG          lpArgs = (LPLONG) (((LPDWORD) & dwCmd) + 1);
    WORD            wArgCount;
    LONG            lRet;
    static BOOL     bHavePath;
    static BOOL     bClosePath;
    static LONG     lSize;

    switch (dwCmd)
    {
    case STARTCHAR:
        // Allocate the buffer
        if (lpTTtoT1stuff->wCSSize < 4 && !GrowCSBuffer(lppd))
        {
            return ((DWORD) - 1L);
        }
        lpTTtoT1stuff->lpCSPos = lpTTtoT1stuff->lpCSBuffer;

        lSize = 6L;
        bHavePath = FALSE;
        bClosePath = FALSE;
        return 0L;

    case PUSHNUMBER:
        lRet = CSAddNumber_T3(lppd, *lpArgs);
        if (lRet > 0)
            lSize += lRet;
        return lRet;

    default:
        // Attempt to optimize the command

        wArgCount = 0;
        switch (dwCmd)
        {
        case SBW:
            wArgCount = 2;
            break;

        case RMOVETO:
        case RLINETO:
            wArgCount = 2;
            break;

        case RRCURVETO:
            lpArgs[2] = lpArgs[2] + lpArgs[0];
            lpArgs[3] = lpArgs[3] + lpArgs[1];
            lpArgs[4] = lpArgs[4] + lpArgs[2];
            lpArgs[5] = lpArgs[5] + lpArgs[3];
            wArgCount = 6;
            break;
        }                       // switch (dwCmd)

        // If buffer isn't big enough to hold this command expand buffer
        // first.
        // Exit if we can't grow buffer.
        // Note: The formula (wArgCount * 5 + 2) assumes the worst case size
        // requirement for the current command (all arguments stored
        // as full longs and a two byte command).

        if (RemCSBuffer() < (int) (wArgCount * 5 + 10) && !GrowCSBuffer(lppd))
        {
            return ((DWORD) - 1L);
        }
        // If a closepath have been send, We have to send moveto
        // after closepath to reset the current point.
        if ((bClosePath) && (dwCmd != ENDCHAR))
        {
            lRet = CSAddString_T3(lppd, "M ");  // moveto
            if (lRet > 0)
                lSize += lRet;
            bClosePath = FALSE;
        }
        // Push the numbers onto the stack
        while (wArgCount--)
        {
            if ((lRet = CSAddNumber_T3(lppd, *lpArgs++)) < 0)
            {
                return ((DWORD) - 1L);
            } else
            {
                lSize += lRet;
                if (lSize > 80)
                {
                    lRet = CSAddString_T3(lppd, "\n");
                    lSize = 0;
                }
            }
        }

        // Push the command onto the stack
        switch (dwCmd)
        {
        case SBW:
            lRet = CSAddString_T3(lppd, "M ");  // moveto
            break;
        case RMOVETO:
            lRet = CSAddString_T3(lppd, "-M "); // rmoveto
            bHavePath = TRUE;
            break;
        case RLINETO:
            lRet = CSAddString_T3(lppd, "- ");  // rlineto
            bHavePath = TRUE;
            break;
        case CLOSEPATH:
            lRet = CSAddString_T3(lppd, "P C ");    // currentpoint closepath
            bHavePath = TRUE;
            bClosePath = TRUE;
            break;
        case RRCURVETO:
            lRet = CSAddString_T3(lppd, "-C "); // rcurveto
            bHavePath = TRUE;
            break;
        case ENDCHAR:
            if (bHavePath)
            {
                if (bClosePath)
                {
                    lRet = CSAddString_T3(lppd, "! ! L ");  // pop pop fill
                    bClosePath = FALSE;
                } else
                {
                    lRet = CSAddString_T3(lppd, "L ");  // fill
                }

                bHavePath = FALSE;
            }
            break;
        default:
            lRet = 0;
        }                       // switch (dwCmd)

        if (lRet < 0)
            return ((DWORD) - 1L);
        else
        {
            lSize += lRet;
            if (lSize > 80)
            {
                lRet = CSAddString_T3(lppd, "\n");
                lSize = 0;
            }
        }

        // If this isn't the end of a character definition return success
        if (dwCmd != ENDCHAR)
            return 0L;

    }                           // switch (dwCmd)
}
#pragma optimize("e", on) // Turn the optimization back on

/***************************************************************************/
#define  SHIFTBITS  0

LONG NEAR PASCAL CSAddNumber_T3(LPPDEVICE lppd, LONG dw)
{
    LPTTTOTYPE1STUFF lpTTtoT1stuff =
    (LPTTTOTYPE1STUFF) & lppd->GlobalBuffer.TTtoT1stuff;

    int             i;
    BYTE            TempBuffer[10];

    // This line is a test!
    dw >>= 16 - SHIFTBITS;      // Truncate fraction - see ttfont.c

    i = wsprintf((LPSTR) TempBuffer, "%ld ", dw);

    // Make sure buffer has room
    if (RemCSBuffer() < (i + 2) && !GrowCSBuffer(lppd))
    {
        return -1L;
    }
    MemCopy(lpTTtoT1stuff->lpCSPos, TempBuffer, lstrlen(TempBuffer));
    lpTTtoT1stuff->lpCSPos += lstrlen(TempBuffer);
    return ((LONG) lstrlen(TempBuffer));
}

/***************************************************************************/

LONG NEAR PASCAL CSAddString_T3(LPPDEVICE lppd, LPSTR lpStr)
{
    LPTTTOTYPE1STUFF lpTTtoT1stuff =
    (LPTTTOTYPE1STUFF) & lppd->GlobalBuffer.TTtoT1stuff;

    int             i;

    i = lstrlen(lpStr);
    // Make sure buffer has room
    if ((RemCSBuffer() < i + 2) && !GrowCSBuffer(lppd))
    {
        return -1L;
    }
    MemCopy(lpTTtoT1stuff->lpCSPos, lpStr, i);
    lpTTtoT1stuff->lpCSPos += i;
    return ((LONG) i);
}

/***************************************************************************
 *
 *                          TTDownLoadT3OutlineFont
 *
 *    Function:  Generates the necessary font definition code to create a
 *               new Type 3 outline font. The parameters are the same as TTDownloadFont.
 *
 *    Called:    int NEAR PASCAL TTDownLoadT3OutlineFont(LPPDEVICE lppd,
 *                                        LPPSFONTINFO FontInfo,
 *                               LPFONTDATARECORD lpFontData, BOOL bFullFont)
 *    Parameters: LPPDEVICE   lppd               Pointer to PDEVICE structure
 *                LPPSFONTINFO  FontInfo
 *                BOOL        bFullFont
 *                LPFONTDATARECORD  lpFontDataRecord
 *
 *    Returns:    PSERROR
 *
 ***************************************************************************/

PSERROR FAR PASCAL TTDownLoadT3OutlineFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                                LPFONTDATARECORD lpFontData, BOOL bFullFont)

{
    LPTTFONTINFO    lpttfi = NULL;
    PSSCALABLEFONTINFO FAR *lpScaFnt;
    LPFONTEXTRA     FontExtra = NULL;
    LPASCIIBINPTRS  tempptr = NULL;

    LONG            EmPels;     // # pels per EM
    int             ch;         // character index
    PSERROR         rc = PS_SUCCESS;
    char            buf[512];   // temporary buffer to hold formatted strings
    DWORD           vmSize;
    WORD            dfFirstChar,
                    dfLastChar;
    LPTTTOTYPE1STUFF lpTTtoT1stuff =
    (LPTTTOTYPE1STUFF) & lppd->GlobalBuffer.TTtoT1stuff;

    lpttfi = (LPTTFONTINFO) ((LPSTR) FontInfo + FontInfo->dfBitsOffset);

    if (FontInfo->dfType & PF_GLYPH_INDEX)
    {
        dfFirstChar = 0;
        dfLastChar = *(LPWORD) & FontInfo->dfFirstChar - 1;

        if (lpttfi->HighByte == (dfLastChar & 0xFF00))
            dfLastChar &= 0x00ff;
        else
            dfLastChar = 0x00ff;
    } else
    {

        dfFirstChar = FontInfo->dfFirstChar;
        dfLastChar = FontInfo->dfLastChar;
    }

    // Need to be recalculated later !!!!!
    if (bFullFont)
    {
        vmSize = (DWORD) (dfLastChar - dfFirstChar + 1);
        VMCheck(lppd, VM_TTT3OL_FONT, vmSize);    // check full font size.
    } else
    {
        VMCheck(lppd, VM_TTT3OL_HEADER, 0);   // check header size only.
    }

    FontExtra = (LPFONTEXTRA) BUMPFAR(FontInfo, FontInfo->dfDriverInfo);
    tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;

    lpScaFnt = (PSSCALABLEFONTINFO FAR *) FontInfo;

    // Changed 29-Mar-1993  -by-   [olegs] in order to fix the
    // text alignment problems. When defining the basic font we should
    // use size of font in pixels, not calculate it from the size in points.
    // EmPels = ((LONG) lpttfi->sy) << 16 ;

    EmPels = ((long) lpttfi->TTRefEM) << SHIFTBITS;

    // Output the command to generate the Type 3 outline font
    // Font Names
    wsprintf(buf, "/%s ", (LPSTR) lpttfi->PSName);
    PSSendString(lppd, buf);
    (*tempptr->PSSendCRLF) (lppd);

    // T3 Metrics
    wsprintf(buf, "[%ld 0 0 0 0 0] ", EmPels);
    PSSendString(lppd, buf);

    // T3/T32 Matrix
    wsprintf(buf, "[1 %ld div 0 0 1 %ld div 0 0]", EmPels, EmPels);
    PSSendString(lppd, buf);

    // T3/T32 FontBBox
    wsprintf(buf, "[%ld %ld %ld %ld]", -EmPels, -EmPels, EmPels, EmPels);
    PSSendString(lppd, buf);
    (*tempptr->PSSendCRLF) (lppd);

    // send XUID if appropriate
    if (lpFontData->lpGAS ||
        !lpFontData->xuidRec.locaCkSum ||
        !lpFontData->xuidRec.glyfCkSum ||
        !lpFontData->xuidRec.os2CkSum)
    {
        wsprintf((LPSTR) buf, "false ");
    } else
    {
        wsprintf((LPSTR) buf, "[%u 16#%08lX 16#%08lX 16#%08lX %u %u %lu] true ",
                 lpFontData->xuidRec.dlType,
                 lpFontData->xuidRec.locaCkSum,
                 lpFontData->xuidRec.glyfCkSum,
                 lpFontData->xuidRec.os2CkSum,
                 lpFontData->xuidRec.x,
                 lpFontData->xuidRec.y,
                 lpFontData->xuidRec.pixelSize);
    }
    PSSendString(lppd, buf);

    // OrigFontName OrigFontStyle OrigFontType lfCharset AddFlag
    PSSendOrigFont(lppd, FontInfo, lpFontData);
    (*tempptr->PSSendCRLF) (lppd);

    // fix bug 143139, 2-16-1996
    wsprintf(buf, "GreNewFontT3_OL ");
    PSSendString(lppd, buf);
    (*tempptr->PSSendCRLF) (lppd);

    // If a full font download is requested, do it now
    // Need to be modifies later !!!!
    if (bFullFont)
    {
        for (ch = (int) dfFirstChar; ch <= (int) dfLastChar; ++ch)
        {
            PutT3OutlineCharDown(lppd, FontInfo, lpttfi, lpFontData, ch);
        }
    }
    if (bFullFont)
    {
        VMUsed(lppd, VM_TTT3OL_FONT, vmSize);
    } else
    {
        VMUsed(lppd, VM_TTT3OL_HEADER, 0);
    }

    return rc;
}

/***************************************************************************
 *
 *                          TTUpdateT3OutlineFont
 *
 *    Function: Adds all of the characters from lpStr that aren't already
 *              downloaded for the TrueType font in FontInfo.
 *
 *    Called:   int NEAR PASCAL TTUpdateT1Font(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPFONTDATARECORD lpFontData, LPBYTE lpStr, int cb)
 *
 *    Parameters:  LPPDEVICE        lppd
 *                 LPPSFONTINFO       FontInfo
 *                 LPFONTDATARECORD lpFontData
 *                 LPBYTE           lpStr
 *                 int              cb
 *
 *    Returns:   UPDATE_FAILURE, UPDATE_LOWVM or UPDATE_SUCCESS
 *
 ***************************************************************************/

int FAR PASCAL  TTUpdateT3OutlineFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, LPFONTDATARECORD lpFontData, LPBYTE lpStr, int cb)
{
    LPTTFONTINFO    lpttfi;
    LPASCIIBINPTRS  tempptr;

    LPBYTE          lpTmp;
#ifdef ENCRYPT
    LPSTR           lpHeader;
    HANDLE          hData;
#endif
    int             i,
                    cbMac;
    BOOL            bNoUpdate = TRUE;
    char            buf[256];
    WORD            numChar = 0;
    DWORD           vmSize;
    WORD            oid;
    BOOL            bEUDC = lppd->lpPSExtDevmode->dm2.bEUDCAble;

    tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;
    lpttfi = (LPTTFONTINFO) ((LPSTR) FontInfo + FontInfo->dfBitsOffset);

    if (!lpStr)
    {
        return (UPDATE_SUCCESS);
    }
    // count how many characters need to be downloaded first
    // to do a vm check
    for (lpTmp = lpStr, i = 0; i < cb; ++i, ++lpTmp)
    {
        if (lpFontData->fontDLType == CC_1 || lpFontData->fontDLType == CC_3)
            oid = GetOIDFromChar(lpTmp, FontInfo->dfCharSet, bEUDC);
        else
            oid = *lpTmp;       // Don't mess up with Glyph-Index case
        if (oid > 255)
        {
            // must be a DBC - this is our OID's property
            lpTmp++;
            i++;                // skip trailing byte
        }
        if (ISCHARDOWN(lpttfi, oid))
        {
            continue;
        }
        numChar++;
    }
    if (numChar > 0)
    {
        vmSize = numChar;
        if (VMCheck(lppd, VM_TTT3OL_FONT, vmSize))
            return (UPDATE_LOWVM);
    }
    // Download the new glyphs
    for (lpTmp = lpStr, i = 0; i < cb; ++i, ++lpTmp)
    {
        if (lpFontData->fontDLType == CC_1 || lpFontData->fontDLType == CC_3)
            oid = GetOIDFromChar(lpTmp, FontInfo->dfCharSet, bEUDC);
        else
            oid = *lpTmp;       // Don't mess up with Glyph-Index case
        if (oid > 255)
        {
            // must be a DBC - this is our OID's property
            lpTmp++;
            i++;                // skip Leading byte - it is HighByte ..
        }
        if (ISCHARDOWN(lpttfi, oid))
        {
            continue;
        }
        if (bNoUpdate)
        {
            TCleanToVMMark(lppd, 1);
            bNoUpdate = FALSE;
        }                       // if (bNoUpdate)
        PutT3OutlineCharDown(lppd, FontInfo, lpttfi, lpFontData, *lpTmp);
        (*tempptr->PSSendCRLF) (lppd);

        cbMac = wsprintf(buf, "/%s ", lpttfi->PSName);
        PSSendString(lppd, buf);

        cbMac = wsprintf(buf, " AddT3OLChar");
        PSSendString(lppd, buf);
        (*tempptr->PSSendCRLF) (lppd);

        SETCHARDOWN(lpttfi, oid);   // mark glyph as downloaded

    }                           // for (lpTmp...)

    if (!bNoUpdate)
    {
        TSetVMMark(lppd, 1, TRUE);
    }                           // if (!bNoUpdate)
    if (numChar > 0)
    {
        VMUsed(lppd, VM_TTT3OL_FONT, vmSize);
    }
    return (UPDATE_SUCCESS);
}

/***************************************************************************/

PSERROR FAR PASCAL TTDownLoadT3OutLineFontExt(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                                       LPFONTDATARECORD lpFontData, BOOL bFullFont, 
									   LPSTR lpCopyFrom, BOOL bCopy)
{
    LPTTFONTINFO    lpttfi;
    LPASCIIBINPTRS  tempptr;
    LONG            EmPels;
    char            buf[128];
    PSERROR         rc = PS_SUCCESS;

    // If this is Not Copy. Call TTDownloadT1Font() Function as before
    // We can only copy Hdr. So if full downloading still use old function
    if (!bCopy || bFullFont)
    {
        rc = TTDownLoadT3OutlineFont(lppd, FontInfo, lpFontData, bFullFont);
        return rc;
    } else
    {
        // Copy the font hdr and then download all chars if bFull.
        tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;
        lpttfi = (LPTTFONTINFO) ((LPSTR) FontInfo + FontInfo->dfBitsOffset);

        VMCheck(lppd, VM_TTT3OL_HEADER, 0);

        // Changed 29-Mar-1993  -by-   [olegs] in order to fix the
        // text alignment problems. When defining the basic font we should
        // use size of font in pixels, not calculate it from the size in
        // points.
        // EmPels = ((LONG) lpttfi->sy) << 16 ;
        EmPels = ((long) lpttfi->TTRefEM) << SHIFTBITS;

        // Output the command to Copy a Type 3 font from lpCopyFrom

        // FontName
        wsprintf(buf, "/%s ", (LPSTR) lpttfi->PSName);
        PSSendString(lppd, buf);

        // Metrics
        wsprintf(buf, "[%ld 0 0 0 0 0] ", EmPels);
        PSSendString(lppd, buf);

        // Matrix
        wsprintf(buf, "[1 %ld div 0 0 1 %ld div 0 0]", EmPels, EmPels);
        PSSendString(lppd, buf);
        (*tempptr->PSSendCRLF) (lppd);

        // FontBBox
        wsprintf(buf, "[%ld %ld %ld %ld]", -EmPels, -EmPels, EmPels, EmPels);
        PSSendString(lppd, buf);
        (*tempptr->PSSendCRLF) (lppd);

        // send XUID if appropriate
        if (lpFontData->lpGAS ||
            !lpFontData->xuidRec.locaCkSum ||
            !lpFontData->xuidRec.glyfCkSum ||
            !lpFontData->xuidRec.os2CkSum)
        {
            wsprintf((LPSTR) buf, "false ");
        } else
        {
            wsprintf((LPSTR) buf, "[%d 16#%08lX 16#%08lX 16#%08lX %u %u %lu] true ",
                     lpFontData->xuidRec.dlType,
                     lpFontData->xuidRec.locaCkSum,
                     lpFontData->xuidRec.glyfCkSum,
                     lpFontData->xuidRec.os2CkSum,
                     lpFontData->xuidRec.x,
                     lpFontData->xuidRec.y,
                     lpFontData->xuidRec.pixelSize);
        }
        PSSendString(lppd, buf);

        // fix bug 143139, 2-16-1996, remove the extra psName
        wsprintf(buf, "/%s  CopyT3OLHdr ", lpCopyFrom);
        PSSendString(lppd, buf);
        (*tempptr->PSSendCRLF) (lppd);

        VMUsed(lppd, VM_TTT3OL_HEADER, 0);
        return rc;
    }                           // else bCopy
}

/***************************************************************************
 *
 *                          PutT3OutlineCharDown
 *
 *    Function:     Generates the necessary font definition code to create a
 *                  new Type 1 font.  The parameters are the same as TTDownloadFont.
 *
 *    Called:       void PASCAL PutT1CharDown(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
 *                     LPTTFONTINFO lpttfi, LPFONTDATARECORD lpFontData, int ch)
 *
 *    Parameters:   LPPDEVICE    lppd               Pointer to PDEVICE structure
 *                  LPPSFONTINFO   FontInfo
 *                  BOOL         bFullFont
 *                  LPFONTDATARECORD  lpFontDataRecord
 *
 *    Returns:      1 if successful, 0 otherwise
 *
 ***************************************************************************/

void FAR PASCAL PutT3OutlineCharDown(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
									  LPTTFONTINFO lpttfi,
									  LPFONTDATARECORD lpFontData, int ch)
{
   LPBYTE            lpBuf;
   BITMAPMETRICS     bmm;
   LPPOLYGONHEADER   lpPoly;
   LPFDPOLYCURVE     lpfdPoly;
   ULONG             cbPoly, cbRem;
   LONG              xCurrent, yCurrent;
   WORD              wBufLen, HighByte;
   USHORT            us;
   TTPOINTFX         fxpt[3];
   LPPSFONTINFO      lpdfRef = NULL;
   LPPSFONTINFO      lpdfRefOrig = NULL;
   LPBYTE            lpOutlineBuf;   // Pointer to the outline buffer
   WORD  wToEngine;    // WORD used to ask engin the glyph data. 9-26-95
   char  buf[128];     // temporary buffer, for wsprintf()

   LPASCIIBINPTRS   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   LPTTTOTYPE1STUFF lpTTtoT1stuff =
		 (LPTTTOTYPE1STUFF)&lppd->GlobalBuffer.TTtoT1stuff;

   if (!lpTTtoT1stuff->lpCSBuffer)
       return;   // fail

   // tell GDI to get ready for some font partying
   lpdfRefOrig = TTGetBaseFont(lppd, FontInfo, lpFontData);
   lpdfRef = GlobalAllocPtr(GHND|GMEM_DDESHARE, lpttfi->wXFontInfoSize) ;
   if (lpdfRefOrig)
      MemCopy((LP)lpdfRef, (LP) lpdfRefOrig, lpttfi->wXFontInfoSize);

   ch &= 0x00ff ;  // mask off HighByte.

   HighByte = (WORD)lpttfi->HighByte  ;

   wToEngine = HighByte | (WORD)ch ;
   if (lpFontData->lpGAS)
   {
      wToEngine = GetGIFromAssignmentID(lpFontData->lpGAS, wToEngine);
   }

/* Fix a bug when downloading as OCF. The char code in the
 *  second Single byte range should be the charcode-Starting code
 *  wToEngine is set and so we can change ch now.
 */
   if (IsDBCSCharSet(FontInfo->dfCharSet) &&
       (lpFontData->fontDLType == CC_1 || lpFontData->fontDLType == CC_3) &&
       HighByte==0){
	  LPDBCSENCODE   lpEncoding;
	  int i;
	  lpEncoding = GetEncoding((int)FontInfo->dfCharSet, lppd->lpPSExtDevmode->dm2.bEUDCAble);
	  // Search Single Byte fonts:
	  for (i=0; i<MAX_1STBRANGES; i++){
	     if (lpEncoding->Single[i].min==0 && lpEncoding->Single[i].max==0) break;
	     if (ch<lpEncoding->Single[i].min ||
		 ch>lpEncoding->Single[i].max ) continue;
		// ch is indeed In this range:
	     ch = ch - lpEncoding->Single[i].min;
	     }
       }

   EngineSetFontContext(lpdfRef, 0 /*  Escapement  */);

   // Get font outline using two-stage process - ask for requested buffer
   //  size by calling EngineGetGlyphBmp with NULL buffer, allocate buffer
   //  and then make call to EngineGetGlyphBmp with allocated buffer.
   //  Changed  12-Apr-1993  -by-   [olegs]
   if (FontInfo->dfType & TYPE_ATMFONT)
   {
       cbPoly = EngineGetGlyphBmp(lppd->hdc, lpdfRef, wToEngine, FD_QUERY_OUTLINE,
					 (LPBYTE)NULL, 0, &bmm);
   }
   else
   {
       cbPoly = EngineGetGlyphBmpExt(lppd->hdc, lpdfRef, wToEngine, FD_QUERY_OUTLINE,
					 (LPBYTE)NULL, 0, &bmm);
   }
   if( cbPoly == -1 )
   {
	  // I don't know what to do - hang, display message, ... ?
	  // Anyhow - I just return doing nothing
	  return;
   }

   // Added  20-Apr-1993  -by-  [olegs]
   //  because MGAllocLock returns an error if asked to allocate
   //  block of memory of 0 bytes.
   if ( cbPoly == 0 )            // Empty character  - allocate minimum block
   {
	  cbPoly = 16;
   }

   if (!lpTTtoT1stuff->lpOutlineBuf)
       return;   // failure

   if(lpTTtoT1stuff->wOutlineBufSize < cbPoly)
   {
	  LPBYTE    lpNewBuffer ;

	  lpNewBuffer = GlobalReAllocPtr(lpTTtoT1stuff->lpOutlineBuf,
								 cbPoly, GMEM_MOVEABLE);
	  if (lpNewBuffer)
		 lpTTtoT1stuff->wOutlineBufSize = (WORD)cbPoly ;
	  else
		 return;  // failure.
   }
   lpOutlineBuf = lpTTtoT1stuff->lpOutlineBuf ;

   if (FontInfo->dfType & TYPE_ATMFONT)
   {
       cbPoly = EngineGetGlyphBmp(lppd->hdc, /* FontInfo */ lpdfRef,
							  wToEngine, FD_QUERY_OUTLINE, (LPBYTE) lpOutlineBuf,
							  cbPoly, &bmm);
   }
   else
   {
       cbPoly = EngineGetGlyphBmpExt(lppd->hdc, /* FontInfo */ lpdfRef,
							  wToEngine, FD_QUERY_OUTLINE, (LPBYTE) lpOutlineBuf,
							  cbPoly, &bmm);
   }
   if (cbPoly == -1)
   {
	  SETCHARDOWN(lpttfi, ch);
	  return;
   }

   // Signal start of character definition
   CharString_T3OL(lppd, STARTCHAR);

   // Output the sidebearing and width information.  Use the horizontal
   //  side bearing/width operator if the Y origin and widths are 0.

   xCurrent = bmm.pfxOrigin.x;
   yCurrent = bmm.pfxOrigin.y;

   CharString_T3OL(lppd, SBW, xCurrent, yCurrent, bmm.pfxCharInc.x, bmm.pfxCharInc.y);

   if (!cbPoly)  //  if no Glyph exists in case of blank characters...
   {
	  goto DoneOutlineDefinition;
   }
   cbRem = cbPoly;
   lpfdPoly = (LPFDPOLYCURVE)lpOutlineBuf;

   do
   {
	  lpPoly = (LPPOLYGONHEADER) lpfdPoly;
	  lpfdPoly = (LPFDPOLYCURVE) ((LPSTR)lpPoly + sizeof(POLYGONHEADER));

	  cbPoly = lpPoly->cb - sizeof(POLYGONHEADER);
	  cbRem -= sizeof(POLYGONHEADER);

	  // Remember last point so we can generate relative commands
	  CharString_T3OL( lppd, RMOVETO,
			TRUNC(lpPoly->pteStart.x) - TRUNC(xCurrent),
			TRUNC(lpPoly->pteStart.y) - TRUNC(yCurrent));

	  xCurrent = lpPoly->pteStart.x;
	  yCurrent = lpPoly->pteStart.y;

	  while (cbPoly > 0)
	  {
		 switch (lpfdPoly->iType)
		 {
			case FD_PRIM_QSPLINE:
			   for (us = 0; (us+1) < lpfdPoly->cptfx; ++us)
			   {
				  if ((us + 2) < lpfdPoly->cptfx)
				  {
					 fxpt[2].x = (lpfdPoly->pte[us].x + lpfdPoly->pte[us+1].x) >> 1;
					 fxpt[2].y = (lpfdPoly->pte[us].y + lpfdPoly->pte[us+1].y) >> 1;
				  }
				  else
				  {
					 fxpt[2] = lpfdPoly->pte[us+1];
				  }
				  fxpt[0].x = (xCurrent + (lpfdPoly->pte[us].x << 1)) / 3;
				  fxpt[0].y = (yCurrent + (lpfdPoly->pte[us].y << 1)) / 3;
				  fxpt[1].x = (fxpt[2].x + (lpfdPoly->pte[us].x << 1)) / 3;
				  fxpt[1].y = (fxpt[2].y + (lpfdPoly->pte[us].y << 1)) / 3;

				  CharString_T3OL( lppd, RRCURVETO,
							  TRUNC(fxpt[0].x) - TRUNC(xCurrent),
							  TRUNC(fxpt[0].y) - TRUNC(yCurrent),
							  TRUNC(fxpt[1].x) - TRUNC(fxpt[0].x),
							  TRUNC(fxpt[1].y) - TRUNC(fxpt[0].y),
							  TRUNC(fxpt[2].x) - TRUNC(fxpt[1].x),
							  TRUNC(fxpt[2].y) - TRUNC(fxpt[1].y));

				  xCurrent = fxpt[2].x;
				  yCurrent = fxpt[2].y;
			   }  // for(...)
			break;

			default:
			   for (us = 0; us < lpfdPoly->cptfx; ++us)
			   {
				  CharString_T3OL( lppd, RLINETO,
							  TRUNC(lpfdPoly->pte[us].x) - TRUNC(xCurrent),
							  TRUNC(lpfdPoly->pte[us].y) - TRUNC(yCurrent));

				  xCurrent = lpfdPoly->pte[us].x;
				  yCurrent = lpfdPoly->pte[us].y;
			   }
			break;
		 }  // switch (lpfdPoly->iType)

		 us = (lpfdPoly->cptfx - 1) * sizeof(TTPOINTFX) + sizeof(FDPOLYCURVE);
		 lpfdPoly = (LPFDPOLYCURVE) ((LPSTR)lpfdPoly + us);
		 cbPoly -= us;
		 cbRem -= us;
	  }  // while (cbPoly > 0)

	  CharString_T3OL(lppd, CLOSEPATH);
   }  while (cbRem > 0);

DoneOutlineDefinition:
   CharString_T3OL(lppd, ENDCHAR);

   wBufLen = lpTTtoT1stuff->lpCSPos - lpTTtoT1stuff->lpCSBuffer ;
   lpBuf = lpTTtoT1stuff->lpCSBuffer ;
   if (lpdfRefOrig)
         MemCopy((LP)lpdfRefOrig, (LP) lpdfRef, lpttfi->wXFontInfoSize);
   if (lpdfRef)
     GlobalFreePtr(lpdfRef);

   // Send T3 Matrics
   wsprintf(buf, "/G%2.2X [", ch);
   PSSendString(lppd, buf);
   PSSendFixedAscii7(lppd, bmm.pfxCharInc.x);
   PSSendFixedAscii7(lppd, bmm.pfxCharInc.y);
   PSSendFixedAscii7(lppd, bmm.pfxOrigin.x);
   PSSendFixedAscii7(lppd, bmm.pfxOrigin.y - ((LONG)bmm.sizlExtent.cy << 16));
   PSSendFixedAscii7(lppd, bmm.pfxOrigin.x + ((LONG)bmm.sizlExtent.cx << 16));
   PSSendFixedAscii7(lppd, bmm.pfxOrigin.y);
   PSSendString(lppd, "]");
   (*tempptr->PSSendCRLF)(lppd);

	   // Send T3 char outline proc.
   efprintf(lppd, "/G%2.2X {", ch);
   PSSendBitMapDataLevel1Binary(lppd, lpBuf, (DWORD)wBufLen);
   PSSendString(lppd, "} bind ");
}

#endif  // T3OUTLINE
