/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: THEADER.C                                                    */
/*                                                                           */
/* Description:This module contains functions for tokens that emit PostScript*/
/*             for downloading the header, setting up the print job etc. Any */
/*             initialization for the job is done here. PostScript and JCL   */
/*             code for the following sections of the job are emitted.       */
/*                                                                           */
/*                JCL section                                                */
/*                   *JCLBegin...*JCLEnd
/*                Job general header section                                 */
/*                   %!PS-Adobe-3.0    %%Title: ....etc                      */
/*                Job prolog section                                         */
/*                   %%BeginProlog - %%EndProlog                             */
/*                Job setup section                                          */
/*                   %%BeginSetup         and in this section,               */
/*                      For every printer feature used                       */
/*                      ... %%BeginFeature: - %%EndFeature                   */
/*                      ... %%BeginFeature: - %%EndFeature etc               */
/*                   %%EndSetup                                              */
/*                At the beginning of every page                             */
/*                   %%BeginPageSetup  - %%EndPageSetup                      */
/*                At the end of every page                                   */
/*                   %%PageTrailer          (if there is PostScript for this)*/
/*                At the end of the job                                      */
/*                   %%Trailer                                               */
/*                And finally                                                */
/*                   %%EOF                                                   */
/*                                                                           */
/* Change History:                                                           */
/* L3_CLIP -- Level3 clipsave cliprestore support. 9/13/96 jjia              */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"


#pragma code_seg(_TSTARTSEG)

struct
{
   int  num1;
   int  num2;
   int  num3;
   int  num4;
}  ViewOrientTable[12] = 
{
   { 1,  0,  0,  1},   // Port, NoFlip, 1/4/9/16-up
   { 0, -1,  1,  0},   // Port, NoFlip, 2/6-up
   { 0,  1, -1,  0},   // Land, NoFlip, 1/4/9/16-up
   { 1,  0,  0,  1},   // Land, NoFlip, 2/6-up
   { 0, -1,  1,  0},   // RotatedLand, NoFlip, 1/4/9/16-up
   {-1,  0,  0, -1},   // RotatedLand, NoFlip, 2/6-up
//-----------------------------------------------------
   {-1,  0,  0,  1},   // Port, Mirror, 1/4/9/16-up
   { 0, -1, -1,  0},   // Port, Mirror, 2/6-up
   { 0, -1, -1,  0},   // Land, Mirror, 1/4/9/16-up
   { 1,  0,  0, -1},   // Land, Mirror, 2/6-up
   { 0,  1,  1,  0},   // RotatedLand, Mirror, 1/4/9/16-up
   {-1,  0,  0,  1},   // RotatedLand, Mirror, 2/6-up
} ;

BOOL FAR PASCAL AddFeatureDSCEntry(LPPDEVICE lppd, LPSTR lpFeatureName, BOOL bfSupplied,
BOOL bNonPPDFeature);
BOOL FAR PASCAL GetCurrUserName(LPPDEVICE lppd, LPSTR buffer, int *cb);
// Next function is used by Cont\alert.c to access registry
BOOL FAR PASCAL GetKeyVal(HKEY hv, LPSTR path_key, LPSTR val_key, LPSTR buffer, long *cl);
void FAR PASCAL SendPSInjectionData(LPPDEVICE lppd, PSInjectionPoint PSInjectID,
                                                    LPSTR FAR *lplpDriverPS,
                                            unsigned FAR *lpDriverPSLen); 
    
short FAR PASCAL PSGetFragmentLength(LPPDEVICE lppd, WORD FragId);
WORD  FAR  PASCAL  KeywordGetOption( LPPDEVICE  lppd,
                                    WORD  MainKeywordIndex,
                                    WORD  OptionKeywordIndex,
                                    LPSTR lpOption,
                                    WORD Len);
BOOL FAR PASCAL ValidateClean7BitData(LPSTR lpstr);
short FAR PASCAL ReturnHexOrEscapedCharString(LPPDEVICE lppd, LPSTR lpstr, int DSCstr);
int FAR PASCAL TSendFontDSCStuff(LPPDEVICE lppd, BOOL fEPSformat);
BOOL FAR PASCAL IsKodakPPD(LPPDEVICE lppd);

// Convenient defines

#define STRREF_TO_PTR(strheap, strref) ((LPSTR) (strref.w.length == 0 ? "" : \
                               (LPBYTE) strheap + strref.w.offset))

#define STRINGBUFSIZE 1024
#define PS_BUFSIZE     ((WORD) 5000)
#define PS_BUFSIZE_BIG ((WORD) 65535)   // Because a PostScript string may be this big
#define CONTROL_T (char)20
#define CONTROL_A (char)1

// Some Nup related stuff
#define  TwoUpRotation    -90.0
#define  FourUpRotation    0

static char tempbuf[256];

/***********************************************************************/
//      Some functions to handle Aldus-specific escapes.
//  They include:  SetGDIXForm  and    DownLoadHeader

/***********************************************************************
*                      TSetGDIXForm
*  function:
*       token function to setup the standard GDI->PS coordinate space
*
*  prototype:
*       short FAR PASCAL TSetGDIXForm(LPPDEVICE lppd)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       RC_ok
***********************************************************************/

short FAR PASCAL TSetGDIXForm(LPPDEVICE lppd)
{
    LPASCIIBINPTRS tempptr;
    RECT    rect;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    //Construct the coordinate transformation matrix(CTM).

    SetRect(&rect, 0, 0, lppd->ptPaperDim.x,
           lppd->ptPaperDim.y) ;
    PSSendMySetup(lppd,&rect, SETUP_XGDI_COORDS );
    (*tempptr->PSSendCRLF)(lppd);

    PSSendFragment(lppd, PSFRAG_mysetup);
    PSSendFragment(lppd, PSFRAG_concat);
    (*tempptr->PSSendCRLF)(lppd);

    return RC_ok;         
}


/***********************************************************************
*                      TDownLoadHeader
*  function:
*       token function to setup the standard GDI->PS coordinate space
*
*  prototype:
*       short FAR PASCAL TDownLoadHeader(LPPDEVICE lppd, WORD wID)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*       WORD      wID  -- Header ID:
*                           = 1 - Full PS header 
*                           = 4 - Send header check code
*                           = 8 - Minimal PS header
*                           = 13- TrueImage header - we don't care
*  returns:
*       RC_ok
***********************************************************************/

short FAR PASCAL TDownLoadHeader(LPPDEVICE lppd, WORD wID)
{
    int    rc;
    LPASCIIBINPTRS tempptr;
    BYTE    bTempOrient   ;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    rc = 1; // Success

    // init the procset management list
    InitProcsetList(lppd);
    TInitGraphicState(lppd);

    switch( wID)
    {
     case 1:
     case 8:
         TSendHeaderOpenChannel(lppd);
         (*tempptr->PSSendCRLF)(lppd);
         // fall thru
     case 4:
         bTempOrient = lppd->lpPSExtDevmode->dm.dm.dmOrientation ;
         lppd->lpPSExtDevmode->dm.dm.dmOrientation == DMORIENT_PORTRAIT ;
         
         PSSendOrientationMatrix(lppd, (float) 1.0, (float) 1.0 );
         
         PSSendFragment(lppd,PSFRAG_initprocset_OC);
         (*tempptr->PSSendCRLF)( lppd );

         PSSendFragment(lppd,PSFRAG_slash);
         PSSendFragment(lppd,PSFRAG_mysetup);
         PSSendOrientationMatrix(lppd, (float) 1.0, (float) 1.0 );
         PSSendString( lppd, " def " );
         (*tempptr->PSSendCRLF)( lppd );
         lppd->lpPSExtDevmode->dm.dm.dmOrientation = bTempOrient;

         break;

     default:
         rc = 0;
         break;
    }
                                              
    rc = FlushToSpool( lppd );
    //Reset the port's dirty flag.
//    PortClean(lppd);

    return(rc);         
}

void FAR PASCAL EmitStringRef(LPPDEVICE lppd, DWORD    dwstringref)
{
   LPBYTE   lpString ;
   STRINGREF  stringRef ;

   stringRef.dword = dwstringref ;

   lpString = StringRefToLPBYTE(lppd, dwstringref);  
   if(lpString)
      PSSendData(lppd, lpString, stringRef.w.length) ;
}



/***********************************************************************
*                      TDocumentBegin
*  function:
*       Token function which begins a job.  This function
*       initializes the graphics state, outputs the initial DSC comments,
*       the prolog section, the document setup section.
*  prototype:
*       short FAR PASCAL TDocumentBegin(LPPDEVICE lppd)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       RC_ok
***********************************************************************/
short FAR PASCAL TDocumentBegin(LPPDEVICE lppd)
{
   LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
   LPBYTE lpStringBlock = lppd->lpWPXblock->WPXstrings;
   LPSTR  szAtend = "(atend)";
   BOOL   bEPS ;
   int    rc;
   WORD   KeywordIndex, index, len;
   WORD   CurrentKeywordIndex, OptionIndex;
   HANDLE bufhdl = NULL ;
   LPSTR  buf    = NULL ;
   LPASCIIBINPTRS tempptr;                
   char buffer[80];
   char strBuff[256];
   char tmpBuff[256];
   PROTOCOLS iDataOutputFormat;
   LPSTR lpTempPS;
   int   iTempLen;
   LPSTR lpFileName= NULL;
                             
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    bEPS = (lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS) ;

   buf = MGAllocLock(lppd, &bufhdl, PS_BUFSIZE_BIG, GHND, TRUE) ;

   PSDEBUG_VMPRINT(lppd, NULL);

   iDataOutputFormat = lppd->lpPSExtDevmode->dm2.iDataOutputFormat;

   // Remember these settings. Useful for Nup & %%ViewingOrientation DSC
   lppd->startingLayout = lppd->lpPSExtDevmode->dm.layout;
   lppd->startingOrient = lppd->lpPSExtDevmode->dm.PaperOrient;
   lppd->startingMirror = lppd->lpPSExtDevmode->dm.bMirror;

   // Init the procset management list
   InitProcsetList(lppd);

   // Init the graphics state for the document
   TInitGraphicState(lppd);
   TSetPen(lppd);
   TSetBrush(lppd);

   //
   // PS injection point IPS_BEGINSTREAM goes here
   //
   SendPSInjectionData(lppd, IPS_BEGINSTREAM, &lpTempPS, &iTempLen);

   // Emit any protocol invocations if necessary, for example, TBCP, PJL etc
   PSSendBeginProtocol(lppd);

   // Send the Normal DSC header comments

   // %!PS-Adobe-3.0
   (*tempptr->PSSendDSC)(lppd, DSC_adobe, (LPSTR)NULL);     

   // %%Title:  Clean7Bit for any data format
   // make sure the lppd->szTitle is Cleant7Bit string.  # 188694 yct
   // convert to hex or escape character string

   if (ValidateClean7BitData(lppd->szTitle))
         (*tempptr->PSSendDSC)(lppd, DSC_title, lppd->szTitle); 
   else
   {  
      ReturnHexOrEscapedCharString(lppd, lppd->szTitle, DSC_title);
      //(*tempptr->PSSendDSC)(lppd, DSC_title, (LPSTR)lpzNonAscii7); 
    }
   // %%Creator:
                                    // %%Creator: ADOBEPS4.DRV Version 4.1
   (*tempptr->PSSendDSC)(lppd, DSC_creator, szIniCreator);        

   // %%CreationDate:   Build up and send the job creation date
   l_strdate( tempbuf );
   lstrcat((LPSTR)tempbuf,BLANK);
   l_strtime( &tempbuf[lstrlen(tempbuf)] );
   (*tempptr->PSSendDSC)(lppd, DSC_date, tempbuf );         

    rc=sizeof(buffer);
    GetCurrUserName(lppd, (LPSTR)buffer, &rc);  // rc contains the actual length of username
//   (*tempptr->PSSendDSC)(lppd, DSC_for, buffer);      // %%For: UserName
   // %%For:   
   // make sure the buffer is Clean7Bit string.  # 188694 yct

   if (ValidateClean7BitData(buffer))
      (*tempptr->PSSendDSC)(lppd, DSC_for, buffer); 
   else
      // show Hex value of the character on %%For: 
      ReturnHexOrEscapedCharString(lppd, buffer, DSC_for);
      // (*tempptr->PSSendDSC)(lppd, DSC_for, nonAscii7); 

   // %%BoundingBox:
   (*tempptr->PSSendDSC)(lppd, DSC_bbox, szAtend);// %%BoundingBox: (atend)
   //(*tempptr->PSSendDSCBBox)(lppd, DSC_bbox, (LPRECT)&lppd->bbox);

    // %%Pages:
   (*tempptr->PSSendDSC)(lppd, DSC_pages_atend, szAtend);        

   // %%PageOrder:   
   
   buffer[0] = 0;   //Fix bug 120006. PageOrder is not set properly.  jjia. 10/6/95
   if (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE ||
       lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE ||
       lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE)
   {
      // Portability
      if (lppd->lpPSExtDevmode->dm.layout != ONE_UP)
      {
         LoadDrvrString(ghDriverMod, DSC_special, buffer, sizeof(buffer));
      }
      else
      {
         LoadDrvrString(ghDriverMod, DSC_ascending, buffer, sizeof(buffer));
      }
   }
   else if (lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED)
   {
      // Speed
      LoadDrvrString(ghDriverMod, DSC_special, buffer, sizeof(buffer));
   }
   (*tempptr->PSSendDSC)(lppd, DSC_pageorder    , buffer);

   // %%DocumentMedia:
   //(*tempptr->PSSendDSC)(lppd, DSC_docpapersizes, (LPSTR)"???????");

   // %%Requirements:

   // The requirements string should be driven by actual language requirements
   // of the job, e.g. manualfeed, numcopies(1), duplex, duplex(tumble)
   // delete in DSc 3.1
   //(*tempptr->PSSendDSC)(lppd, DSC_requirements , (LPSTR)NULL );

    // %%DocumentNeededResources: font
   //   (*tempptr->PSSendDSC)(lppd, DSC_docneedresfont, szAtend);
   (*tempptr->PSSendDSC)(lppd, DSC_docneededres, szAtend);
                                                  
   // %%DocumentSuppliedResources: font
   //   (*tempptr->PSSendDSC)(lppd, DSC_docsuppresfont, szAtend);
   (*tempptr->PSSendDSC)(lppd, DSC_docsuppliedres, szAtend);

   // %%DocumentSuppliedFeatures:   new in DSC 3.1
   (*tempptr->PSSendDSC)(lppd, DSC_docsuppliedfeatures, szAtend);

        //*************************************************************
    //   Fix for Bug#101 (MSFT 12258) - we need some un-documented
    //   DSC for Novell print server in order for it to swallow binary data
    // Added 17-nov-1994  -by- [olegsher]
   if ( (iDataOutputFormat == PROTOCOL_BINARY) ||
        (iDataOutputFormat == PROTOCOL_BCP) ||
        (iDataOutputFormat == PROTOCOL_TBCP) )
   {
      LoadDrvrString(ghDriverMod, DSC_Netware_ATPS, buffer, sizeof(buffer));
      // Since the strin start with %% string, send it as DSC 
      AdobeOEMSendPSStub(lppd, PS_INDEX_P8BIT, buffer, lstrlen(buffer)); 

        // PSSendString(lppd,  (LPSTR) buffer);
      (*tempptr->PSSendCRLF)(lppd);
   }

   // %%DocumentData:
   if (iDataOutputFormat == PROTOCOL_BINARY)
   {
      // We are sending in pure binary, or no protocol is being used
      LoadDrvrString(ghDriverMod, DSC_binary, buffer, sizeof(buffer));
   }
   else if ((iDataOutputFormat == PROTOCOL_BCP) || 
            (iDataOutputFormat == PROTOCOL_TBCP) )
   {
       LoadDrvrString(ghDriverMod, DSC_clean8bit, buffer, sizeof(buffer));
   }
   else             // Anything else must be ASCII
   {
       LoadDrvrString(ghDriverMod, DSC_clean7bit, buffer, sizeof(buffer));
    }
   (*tempptr->PSSendDSC)(lppd, DSC_documentdata, buffer);

   // %%LanguageLevel:

#ifndef ADOBEPS42
  if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS  ))
   {
      (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szTwo);
   }
   else
   {
      (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szOne);
   }
#else
  // L3_CLIP
  if (lppd->lpPSExtDevmode->dm2.useLanguageLevel == 2)
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szTwo);
  else if (lppd->lpPSExtDevmode->dm2.useLanguageLevel == 3)
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szThree);
#endif

   // %%Extensions:
   //(*tempptr->PSSendDSC)(lppd, DSC_extensions   , (LPSTR)"???????");

   // %%Orientation:
   //(*tempptr->PSSendDSC)(lppd, DSC_orientation  , (LPSTR)"???????");

   // %%TagetDevice:   new in DSC 3.1
   // Get product name and PSversion
   buffer[0] = 0;
   lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->Product.dword);
   if (lpFileName)
      lstrcpy(buffer, lpFileName);
   lstrcat (buffer, BLANK);  
   lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->PSVersion.dword);
   if (lpFileName)
         lstrcat(buffer, lpFileName);
   (*tempptr->PSSendDSC)(lppd, DSC_targetdevice, (LPSTR)buffer);

   // for NT compatibility
   // give app or OEM a chance to emit their %%DocumentProcessColorsAtEnd:
   //
   (*tempptr->PSSendDSC)(lppd, DSC_documentprocesscolorsatend, NULL);

   // %%EndComments
   (*tempptr->PSSendDSC)(lppd, DSC_endcomments  , (LPSTR)NULL );
   (*tempptr->PSSendCRLF)(lppd);

   (*tempptr->PSSendDSC)(lppd, DSC_begindefaults  , (LPSTR)NULL );
   // %%PageBoundingBox:    new DSC 3.1
   (*tempptr->PSSendDSCBBox)(lppd, DSC_pagebbox, (LPRECT)&lppd->bbox);

   TSendViewingOrientation(lppd, TRUE);

   // %%PageFeatures: list default option
   
   if (buf != NULL &&
       lppd->lpPSExtDevmode->dm.enumDialect != DIA_ARCHIVE &&
       lppd->lpPSExtDevmode->dm.enumDialect != DIA_PJL_ARCHIVE)
   {   // Get first keyword index
      rc = KeywordNextOrderedKeyword(lppd,(LPWORD)&KeywordIndex, FIRST_LAST_KEYWORD-DOCSETUP);
     (*tempptr->PSSendDSC)(lppd, DSC_pagefeatures , (LPSTR)NULL );

     while (rc == TRUE && KeywordIndex != FIRST_LAST_KEYWORD)
     {
      
       len = KeywordGetMainKeyword (lppd, KeywordIndex, buf, PS_BUFSIZE_BIG);
       KeywordGetDefaultOption(lppd, KeywordIndex, (LPWORD) &OptionIndex);
       if ((lstrcmp(buf, "Collate") == 0) && lppd->lpPSExtDevmode->dm2.bWebPrinter)
           goto  nextkey;
       // output the default option for each mainkeyword
       if (OptionIndex != 0xFFFF) {     // Option present
            int len2;

         lstrcpyn( tmpBuff, buf, len+1 ); // when 
         len2 = KeywordGetOption(lppd, KeywordIndex, OptionIndex, 
                          buf, PS_BUFSIZE_BIG);
         lstrcat( tmpBuff, BLANK );
         lstrcpyn( &tmpBuff[len+1], (LPSTR) buf, len2+1 );  // get option keyword
         }
       // if it is input slot and the slot id is DMBIN_AUTO
       // The DSC %%BeginFeature use the unlocalized string instead of
       // getting it from option string. #194358
        if (KeywordIndex == IND_INPUTSLOTINFO)
        {

         LPPRINTERINFO lpPrinterInfo;
         LPBYTE      lpOptionsBlock;
         LPMAINKEYHDR  lpInputSlotInfoHdr ;
         LPINPUTSLOTINFO   lpExtraInputSlotInfo ;

         lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo ;
         lpOptionsBlock = lppd->lpWPXblock->WPXarrays ;
         lpInputSlotInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;
         lpExtraInputSlotInfo = (LPINPUTSLOTINFO)MAKELONG(
         lpInputSlotInfoHdr->extraOptionArray, HIWORD(lpOptionsBlock) );
         if (lpExtraInputSlotInfo[OptionIndex].slotID == DMBIN_AUTO)
         {
            LoadString(ghDriverMod, ID_DSCSTR_AUTOSELECTTRAY, strBuff, sizeof(strBuff));
            lstrcat( tmpBuff, BLANK );
            lstrcpy( &tmpBuff[len+1], (LPSTR) strBuff);  // get DSC string
         }

        }
        lstrcpy(strBuff, "*");
        lstrcat(strBuff, tmpBuff);
        AddFeatureDSCEntry(lppd, tmpBuff, TRUE, FALSE); // TRUE = supplied
        (*tempptr->PSSendDSC)(lppd, DSC_plus,strBuff);        // %%+ *page feature
       
nextkey:
        // Get next keyword index
        CurrentKeywordIndex = KeywordIndex;
        rc = KeywordNextOrderedKeyword(lppd, (LPWORD)&KeywordIndex, CurrentKeywordIndex);

      } //end while
   }
   (*tempptr->PSSendDSC)(lppd, DSC_enddefaults  , (LPSTR)NULL );
   (*tempptr->PSSendCRLF)(lppd);

   // Emit Patch file string if it exists 

   if (lpPrinterInfo->PatchFile.w.length  &&  !bEPS)
   {
      (*tempptr->PSSendDSC)(lppd, DSC_begin_patchfile  , (LPSTR)NULL);

      EmitStringRef(lppd, lpPrinterInfo->PatchFile.dword) ;
      (*tempptr->PSSendCRLF)(lppd);
      (*tempptr->PSSendDSC)(lppd, DSC_end_patchfile, (LPSTR)NULL);
      (*tempptr->PSSendCRLF)(lppd);
   }

   // Emit Job Patch file string if it exists

   for (index = 0 ; index < lpPrinterInfo->nJobPatchFiles  &&  !bEPS ; index++)
   {
      char   zTemp[8] ;

      wsprintf((LPSTR)zTemp,(LPSTR)"%d",
         lpPrinterInfo->JobPatchFile[index].order);

//      PSSendFragment(lppd,PSFRAG_beginsafe);
      // At this jobpatch file time, beginsafe/endsafe is not defined yet
      // - they are in utils0.ps sent after this point.
      // So, use the old simple safe way without cleanup dictstack. fix bug 142806, 2-7-96
      PSSendString( lppd, "[{" );
      (*tempptr->PSSendCRLF)(lppd);

      (*tempptr->PSSendDSC)(lppd, DSC_begin_jobpatchfile  , (LPSTR)zTemp);

      EmitStringRef(lppd, lpPrinterInfo->JobPatchFile[index].invoc.dword) ;
      (*tempptr->PSSendCRLF)(lppd);
      (*tempptr->PSSendDSC)(lppd, DSC_end_jobpatchfile    , (LPSTR)NULL);
//      PSSendFragment(lppd,PSFRAG_endsafe);
      PSSendString( lppd, "} stopped cleartomark" );
      (*tempptr->PSSendCRLF)(lppd);
   }

   // Emit PostScript for the job prolog section

   // %%BeginProlog
   (*tempptr->PSSendDSC)(lppd,DSC_beginprolog , (LPSTR)NULL );
   // Send the featurecleanup def in userdict right after BegineProlog - fix bug 145235
   PSSendProc(lppd,PSPROC_feature_safe);

   // Send the FatalErrorIf & PrtVMMsg because error handler uses it
   PSSendProc(lppd,PSPROC_fatalerr_ps1);
   TSendHeaderPrtVMMsg(lppd);

   if(lppd->lpPSExtDevmode->dm2.bErrHandler == TRUE)
   {
      PSSendProc(lppd,PSPROC_ehandler);
   }
   else
   {
      PSSendProc(lppd, PSPROC_vmehandler);
   }

   // Send PostScript for 'public' keywords from the PPD file.
   // Send only the stuff from the job section "PROLOG"

   if (buf != NULL)
   {
      // Get first keyword index
      rc = KeywordNextOrderedKeyword(lppd,(LPWORD)&KeywordIndex, FIRST_LAST_KEYWORD-PROLOG);
      
      while (rc == TRUE && KeywordIndex != FIRST_LAST_KEYWORD)
      {
         //if ((_fstrstr((LPSTR)buf, "Collate") != NULL) && lppd->lpPSExtDevmode->dm2.bWebPrinter)
      //    goto nextIndex;
      KeywordGetCurrentOption(lppd, KeywordIndex, (LPWORD) &OptionIndex);
      TSendPPD(lppd, KeywordIndex, OptionIndex, buf, PS_BUFSIZE_BIG, 0, 0); // Send PostScript
//nextIndex:

      // Get next keyword index
      CurrentKeywordIndex = KeywordIndex;
      rc = KeywordNextOrderedKeyword(lppd, (LPWORD)&KeywordIndex, CurrentKeywordIndex);

      }

      /******************************************************************
    
       We'll omit OEM Customization stuff for now

      // Send PostScript for 'public' keywords under *OEMOpenUI feature

      rc = KeywordListSeek(lppd, &(lppd->PPDList), 0, OEM_FLAG,
                  KWSEEK_JOBORDER, PROLOG);
      while (rc == RC_ok)
      {
      KeywordListGetCurrentKeyword(lppd, &(lppd->PPDList), keyword,
                           sizeof(keyword), NULL, 0, &tmpi) ;
      TSendPPD(lppd, keyword, NULL, buf, 0, 0);

      // Get next keyword.
      rc = KeywordListAdvance(lppd, &(lppd->PPDList), OEM_FLAG,
                     KWSEEK_JOBORDER, PROLOG);
      }
    **********************************************************************/

   } // if (buf != NULL)

   TSendHeader(lppd, FALSE);        // send the header for non-EPS format

    // before EndProlog, send special PASSTHROUGH PS data, 5-1-95
    TSendSpecialPSData(lppd);
   // %%EndProlog
   (*tempptr->PSSendDSC)(lppd,DSC_endprolog, (LPSTR)NULL );
   (*tempptr->PSSendCRLF)(lppd);

   lppd->lpProcsetstuff->currpagenumber = 1;       // initialize page number
   lppd->lpProcsetstuff->nuppagenumber = 0;       // initialize N-up page number
 
   // Emit PostScript for the job setup section
   // %%BeginSetup  ...%%BeginFeature: %%EndFeature...  etc....   %%EndSetup

   TSendSetup(lppd); 

   // Flush out whatever is in the spool buffer upto this point. Some apps,
   // such as Aldus Freehand (bug313) take a long time until they issue the
   // first NewFrame where we flush following document setup. This is OK,
   // except that some printers, such as Comet, time out because they still
   // have not received the user's timeout settings.  Hence the printer's
   // default timeout (usually 40 secs) applies, often resulting in a job timeout.
   // - bug313 - [FIXED] - ShyamV - 5/21/93.
 
   rc = FlushToSpool(lppd);

   if (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE)
   {
     // if it is NOT Portability mode, do it in the StartTranslation()
      PortFirstStartSpoolPage(lppd); 
   }
   // ALWAYS_ICM
   if (lppd->lpPSExtDevmode->dm.useImageColorMatching == ICM_ALWAYS)
       lppd->graphics.hDefCMTransform = CreateDefTransform(lppd);

   MGUnlockFree(lppd, bufhdl, TRUE) ;
   return(rc);    // return code was forced to RC_ok before. Seems incorrect.
            // I changed it while fixing bug313 - ShyamV - 5/21/93.
}

/***********************************************************************
*                      TDocumentAbort
*  function:
*       Token function which aborts the current job
*  prototype:
*       short FAR PASCAL TDocumentAbort(LPPDEVICE lppd)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       RC_ok
***********************************************************************/
short FAR PASCAL TDocumentAbort(LPPDEVICE lppd)
{
   // Emit protocol code -- if necessary
   PSSendEndProtocol(lppd);

   return(RC_ok);
}

/***********************************************************************
*                      TDocumentEnd
*  function:
*       Token function which finishes and closes the current job
*  prototype:
*       short FAR PASCAL TDocumentEnd(LPPDEVICE lppd)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       RC_ok
***********************************************************************/
short FAR PASCAL TDocumentEnd(LPPDEVICE lppd)
{
  LPSTR lpTempPS;
  int   iTempLen;

  if ((lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) ||
      // Fix bug 204185. 
      (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
      (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE))

  {
     // if it is NOT Portability mode, do it in the TSendTrailer()

     // If doing Nup, issue finalpage procedure.
     if ((lppd->lpPSExtDevmode->dm.layout != ONE_UP) &&
         (lppd->disableNUP == 0))
     { 
        LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
        PSSendFragment(lppd, PSFRAG_finalpageNup);
        (*tempptr->PSSendCRLF)(lppd);
        // Fix bug 204185.
        // Send "pagesave restore" at physical page end.
        PSSendRestore(lppd);
        (*tempptr->PSSendCRLF)(lppd);
     }

     // call OEM for last physical page index
     AdobeOEMSendPSStub(lppd, PS_INDEX_PHYSICAL_PAGES, NULL, 0);  

     // if it is NOT Portability mode, do it in the EndTranslation()
     PortLastEndSpoolPage(lppd);  
   }
 
   TSendTrailer(lppd, FALSE);  // trailer for non-EPS format

   // do protocol -- if necessary
   PSSendEndProtocol(lppd);

   // ALWAYS_ICM
   if (lppd->graphics.hDefCMTransform)
   {
       DeleteDefTransform(lppd->graphics.hDefCMTransform);
       lppd->graphics.hDefCMTransform = 0;
   }

   // PS Injection point IPS_ENDSTREAM goes here
   SendPSInjectionData(lppd, IPS_ENDSTREAM, &lpTempPS, &iTempLen);
   
   return(RC_ok);
}

/***********************************************************************
*                      TDocumentFlush
*  function:
*       Token function which flushes the output of the current job
*       to the spooler.  There is currently no buffering done so
*       this is a noop.
*  prototype:
*       short FAR PASCAL TDocumentFlush(LPPDEVICE lppd)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       RC_ok
***********************************************************************/
short FAR PASCAL TDocumentFlush(LPPDEVICE lppd)
{
   return(RC_ok);
}

/***********************************************************************
*                      TDocumentPageBegin
*  function:
*       Token function which initializes a new page
*
*       Note: we do PortPage() here, instead of in TDocumentPageEnd.
*       This is OK (we could actually do it in either place).
*       PortPage will cause everything sent so far to be released to
*       the spooler, and potentially to the printer.  If this is the
*       PageBegin of the first page, that means the prolog will be 
*       released to the printer while we work on the output of the first
*       page.  That is a good parallelism to achieve.
*
*  prototype:
*       short FAR PASCAL TDocumentPageBegin(LPPDEVICE lppd)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       RC_ok
***********************************************************************/
short FAR PASCAL TDocumentPageBegin(LPPDEVICE lppd)
{
#ifdef ADOBE_DRIVER
LPPSDEVMODE psdm = (LPPSDEVMODE) &lppd->lpPSExtDevmode->dm;
void TSendWaterMark(LPPDEVICE);
#endif

   if ((lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) ||
       // Fix bug 204185. 
       (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
       (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE))
   {
      // if it is NOT Portability mode, do it in the TSendPageSetup()
      BOOL SendDeviceFeatures = 
                  (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS ) ;
      BOOL bNupEnabled = SendDeviceFeatures &&
                      (lppd->disableNUP == 0) &&
                      ( lppd->lpPSExtDevmode->dm.layout != ONE_UP ) ;
      
      // page boundry start with page 1+
      //
      if ( !bNupEnabled &&
          (lppd->lpProcsetstuff->currpagenumber > 1))
      {
         AdobeOEMSendPSStub(lppd, PS_INDEX_PHYSICAL_PAGES, NULL, 0); 
      }
      else if( bNupEnabled )
      {
          WORD    nUp;
          switch(lppd->lpPSExtDevmode->dm.layout)
          {
              case TWO_UP:
                  nUp = 2;
                  break;
              case FOUR_UP:
                  nUp = 4;
                  break;
              case SIX_UP:
                  nUp = 6;
                  break;
              case NINE_UP:
                  nUp = 9;
                  break;
              case SIXTEEN_UP:
                  nUp = 16;
                  break;
              default:
                  nUp = 1;
                  break;
          }
      
          if(!(( fIsDeviceReset(lppd) != RESETDC_NEW_PAGE ) &&
               ( lppd->lpProcsetstuff->nuppagenumber % nUp )))
          {
             // Finish the old page
             if (lppd->lpProcsetstuff->currpagenumber != 1)
             {
                LPASCIIBINPTRS tempptr;
                
                tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
                PSSendFragment(lppd, PSFRAG_finalpageNup);
                (*tempptr->PSSendCRLF)(lppd);
                 AdobeOEMSendPSStub(lppd, PS_INDEX_PHYSICAL_PAGES, NULL, 0);

                // Fix bug 204185.
                // Send "pagesave restore" at physical page end.
                PSSendRestore(lppd);
                (*tempptr->PSSendCRLF)(lppd);
             }
          }
      }

      PortPage(lppd);      // Send endspoolpage then startspoolpage

    }  

   if (TSendPageSetup(lppd) != RC_ok)
       return RC_fail;

   TInitGraphicState(lppd);

   if ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_PORTABLE) &&
       // Fix bug 204185. 
       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_ARCHIVE) &&
       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_PJL_ARCHIVE))
   {
      PortPage(lppd);      // Send endspoolpage then startspoolpage
   }

#ifdef ADOBE_DRIVER
   if (psdm->dwWatermarkID && (!psdm->WMForeGround) &&
        (psdm->enumDialect != DIA_EPS ) && (lppd->disableWMark == 0))
   {
         TSendWaterMark(lppd);
   }
#endif

   return(RC_ok);
}

/***********************************************************************
*                      TDocumentPageEnd
*  function:
*       Token function which terminates the current page
*  prototype:
*       short FAR PASCAL TDocumentPageEnd(LPPDEVICE lppd)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       RC_ok
***********************************************************************/
short FAR PASCAL TDocumentPageEnd(LPPDEVICE lppd)
{
#ifdef ADOBE_DRIVER
LPPSDEVMODE psdm = (LPPSDEVMODE) &lppd->lpPSExtDevmode->dm;
#endif
   // Get the value for user selection of Speed vs Portability
   // Fix bug 164116(1) EPS use incremental header download.
   BOOL nodribble = ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED) &&
                     (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS));

   if (psdm->dwWatermarkID && (psdm->WMForeGround) &&
         (lppd->disableWMark == 0) && (psdm->enumDialect != DIA_EPS ))
    TSendWaterMark(lppd);

   TSendPageTrailer(lppd,TRUE);

   (lppd->lpProcsetstuff->currpagenumber)++;   // roll the page number here
   (lppd->lpProcsetstuff->nuppagenumber)++;    // bump N-up page number

   if ( (nodribble == TRUE) ||
        fIsMinHeaderLppd(lppd) )
   {
      // Clear out the font data list (font records) for the new page
      // We need to do this for Min-headers as well - Currently (5-16-95) only 
      // Acrobat 2.1 call this function in the midlle of a job. Fix bug 213
      InitFontDataList( lppd );  
   }

   return(RC_ok);
}

/***********************************************************************
*                      TDriverData
*  function:
*       Token function to pass data from CONTROL to TRANSLATE layer.
*       Currently unused.
*  prototype:
*       short FAR PASCAL TDriverData(LPPDEVICE lppd, short size)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*       short size -- number of bytes passed
*  returns:
*       RC_ok
***********************************************************************/
short FAR PASCAL TDriverData(LPPDEVICE lppd,short size)
{  // What is the size argument for??!!

   return(RC_ok);
}


/***********************************************************************
*                      TJobType
*  function:
*       Sets the job type (currently NORMAL or EPS)
*  prototype:
*       short FAR PASCAL TJobType(LPPDEVICE lppd, short type)
*  parameter:
*       short type -- either NORMAL or EPS
*  returns:
*       RC_ok
***********************************************************************/
short FAR PASCAL TJobType(LPPDEVICE lppd, short type)
{
   /* here is where we will set flags, etc. based on
    * the job type (PS,EPS,AI3,overlay, etc.)
    * AI3 is a special case...call a separate interpreter
    */
   if (type == EPS)
   {
      lppd->lpPSExtDevmode->dm2.bOutputDialect = DIALECT_EPS;
   }

   return(RC_ok);
}

/***********************************************************************
*                      TPageOrientation
*  function:
*       Sets the Orientation
*  prototype:
*       short FAR PASCAL TPageOrientation(LPPDEVICE lppd, WORD Orient )
*  parameter:
*       WORD Orient -- Portrait, Landscape or Rotated Landscape
*  returns:
*       Whatever KeywordSetCurrentOption returns
***********************************************************************/

short FAR PASCAL TPageOrientation(LPPDEVICE lppd, WORD Orient )
{
   return KeywordSetCurrentOption(lppd, ID_KEY_BASE_ORIENT, Orient);
}


/***********************************************************************
*                      TPaperSource
*  function:
*       Set the paper source to the specified slot.
*  prototype:
*       short FAR PASCAL TPaperSource(LPPDEVICE lppd, WORD slot)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*       slot - index to paper source, eg. Upper Tray.
*  returns:
*       Whatever KeywordSetCurrentOption returns
*       
***********************************************************************/

short FAR PASCAL TPaperSource(LPPDEVICE lppd, LPSTR slot)
{
//  THIS IS A DEAD FUNCTION, NEVER REFER TO PAPERS VIA NAMES
//  instead use option index  or menuitem ID.
   return(0) ;
}

/***********************************************************************
*  function:
*       Set the paper size to the specified media type.
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*       media_name - index to paper size, eg. Envelope.
*  returns:
*       Whatever KeywordSetCurrentOption returns
***********************************************************************/

short FAR PASCAL TPaperSize(LPPDEVICE lppd, LPSTR media_name)
{
//  THIS IS A DEAD FUNCTION, NEVER REFER TO PAPERS VIA NAMES
//  instead use option index  or menuitem ID.
   return(0) ;
}

/******************************************************************************
*                               TSendSetup
*  function:
*       This routine sends out the job setup portion of the PostScript job.
*       Job setup info from the Printer Instance database and the PPD files
*       is inserted into the job stream here.
*  prototype:
*       short NEAR PASCAL TSendSetup(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       RC_ok if no error, else RC_fail.
******************************************************************************/

SHORT NEAR PASCAL TSendSetup(LPPDEVICE lppd)
{
   LPASCIIBINPTRS tempptr;
   BOOL bNupEnabled =
                    (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS) &&
                    (lppd->disableNUP == 0) &&
                    (lppd->lpPSExtDevmode->dm.layout != ONE_UP ) ;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   (*tempptr->PSSendDSC)(lppd, DSC_beginsetup, (LPSTR)NULL );

   // Echo product on back-channel
   PSSendFragment(lppd, PSFRAG_productname);
   (*tempptr->PSSendCRLF)(lppd);

   PSSendFragment(lppd, PSFRAG_CSLCompMode1); // NO \r\n after this line because J-doesn't have them
   PSSendFragment(lppd, PSFRAG_CSLCompMode2);
   (*tempptr->PSSendCRLF)(lppd);

   // init the procset (and CalRGB stuff), not EPS format
   TSendPrologInit(lppd, FALSE);        

   // Send Device Feature PostScript (Manual Feed, InputSlot, # copies, etc.

   TSendDeviceFeatures(lppd);

   PSSendFragment(lppd,PSFRAG_setdefaults);   // set color and line defaults
   (*tempptr->PSSendCRLF)(lppd);

   PSSendMySetup(lppd, NULL , SETUP_GDI_COORDS );

    // Fix bug 194247. This part is moved from TSendPageSetup. jjia  2/14/97
    // We are doing nup, setup the nup matrix.
    if ( bNupEnabled)
    {
        PSSendNupMatrix(lppd);
        PSSendFragment(lppd, PSFRAG_initializeNup);
        (*tempptr->PSSendCRLF)(lppd);
    }
    // For "Optimize for Speed", send a save before page 1
    // so VM used can be recovered by a restore.
    // For "Optimize for Portability", it is done per page.
    if ((lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED) &&
        (DoVMTracking(lppd)))
    {
        PSSendSave(lppd, FALSE);
    }

   (*tempptr->PSSendDSC)(lppd, DSC_endsetup, (LPSTR)NULL );
   (*tempptr->PSSendCRLF)(lppd);

   return(RC_ok);
}

//bMixedBins is not used

BOOL NEAR PASCAL SendPublicKeywords(LPPDEVICE lppd, LPSTR buf, WORD bufSize, 
                                    int section, BOOL bReqsPageRegion,
                                    BOOL autotrayselect_flg, BOOL bMixedBins)
{
    WORD KeywordIndex;
    WORD OptionIndex, CurrentKeywordIndex;
    int  rc, rc1;
    BOOL keywordSend = FALSE;
    double currOrderValue, nextOrderValue;
    int  mergeSPD = 0;
    LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    BOOL  bEnableMergeSPD = !IsKodakPPD(lppd);
    LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo;

    // Get first keyword index
    rc = KeywordNextOrderedKeyword(lppd, (LPWORD)&KeywordIndex, 
                                   FIRST_LAST_KEYWORD - section);
        
    while (rc == TRUE && KeywordIndex != FIRST_LAST_KEYWORD)
    {
        if ((autotrayselect_flg && (KeywordIndex == IND_PAGEREGIONINFO)) ||
            (! autotrayselect_flg && (KeywordIndex == IND_PAPERINFO)))
            rc = FALSE;   // Autotray => PageSize, otherwise PageRegion.
              
        // Check if page region is required
        if (rc && (KeywordIndex == IND_PAGEREGIONINFO))
            rc = bReqsPageRegion;

        if (rc && ( (KeywordIndex == IND_COLLATIONINFO   && !lpPrinterInfo->devcaps.bCollateSupport)   ||  
                    (KeywordIndex == IND_DUPLEXINGINFO   && !lpPrinterInfo->devcaps.SupportsDuplexing) ||
                    (KeywordIndex == IND_OUTPUTORDERINFO && !lpPrinterInfo->devcaps.bOutputOrderSupport)))
            rc = 0; 
                          
        if (rc) 
        {
            // begin merge setpagedevice
            rc1 = KeywordGetPPDOrderValue(lppd, KeywordIndex, &currOrderValue, &nextOrderValue);
            if (bEnableMergeSPD &&
                !mergeSPD && rc1 && (currOrderValue == nextOrderValue))
            {
                PSSendFragment(lppd, PSFRAG_beginsafe);
                PSSendFragment(lppd, PSFRAG_beginmergespd);
                (*tempptr->PSSendCRLF)(lppd);
                mergeSPD = 1;
            }

            KeywordGetCurrentOption(lppd, KeywordIndex, (LPWORD)&OptionIndex);
            // If input slot is being selected, turn off manual feed
            if (KeywordIndex == IND_INPUTSLOTINFO)
            {
                if (!mergeSPD)
                {
                    // start of PostScript error recovery
                    PSSendFragment(lppd, PSFRAG_beginsafe);
                    (*tempptr->PSSendCRLF)(lppd);
                }
                EmitStringRef(lppd, lpPrinterInfo->disableManFeed.dword) ;
                (*tempptr->PSSendCRLF)(lppd);
                if (!mergeSPD)
                {
                    // end of PostScript error recovery
                    PSSendFragment(lppd, PSFRAG_endsafe);
                    (*tempptr->PSSendCRLF)(lppd);
                }
            }    
            // Send PostScript

               if (TSendPPD(lppd, KeywordIndex, OptionIndex, buf, bufSize, mergeSPD, 1))
                  keywordSend = TRUE;
            // end of merge setpagedevice
            if (bEnableMergeSPD &&
                mergeSPD && (rc1 && (currOrderValue != nextOrderValue) || !rc1))
            {
                PSSendFragment(lppd, PSFRAG_endmergespd);
                PSSendFragment(lppd, PSFRAG_endsafe);
                (*tempptr->PSSendCRLF)(lppd);
                mergeSPD = 0;
            }
        }

        // Get next keyword index
        CurrentKeywordIndex = KeywordIndex;
        rc = KeywordNextOrderedKeyword(lppd, (LPWORD)&KeywordIndex, 
                                       CurrentKeywordIndex); 
    }

    // end of merge setpagedevice
    if (bEnableMergeSPD && mergeSPD)
    {
        PSSendFragment(lppd, PSFRAG_endmergespd);
        PSSendFragment(lppd, PSFRAG_endsafe);
        (*tempptr->PSSendCRLF)(lppd);
    }

    return(keywordSend);
}


VOID NEAR PASCAL SendPagePublicKeywords(LPPDEVICE lppd) 
{
    WORD KeywordIndex;
    WORD OptionIndex, CurrentKeywordIndex, DefaultOptionIndex;
    char strBuff[256], tmpBuff[256], buf[256];
    int  rc, len, len2;
    LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    // Get first keyword index
    rc = KeywordNextOrderedKeyword(lppd, (LPWORD)&KeywordIndex, 
                                   FIRST_LAST_KEYWORD - DOCSETUP);
        
    while (rc == TRUE && KeywordIndex != FIRST_LAST_KEYWORD)
    {
       // out put the %%PageFeatures string
       KeywordGetCurrentOption(lppd, KeywordIndex, (LPWORD)&OptionIndex);
       KeywordGetDefaultOption(lppd, KeywordIndex, (LPWORD)&DefaultOptionIndex);
       if (OptionIndex != DefaultOptionIndex)
       {
          (*tempptr->PSSendCRLF)(lppd);
          len = KeywordGetMainKeyword (lppd, KeywordIndex, buf, PS_BUFSIZE_BIG);
          if ((lstrcmp(buf, "Collate") == 0) && lppd->lpPSExtDevmode->dm2.bWebPrinter)
              goto skipkey;
          
          // Copying an extra byte for the NULL char that lstrcpyn supplies
          lstrcpyn( strBuff, buf, len+1 );

          len2 = KeywordGetOption(lppd, KeywordIndex, OptionIndex, 
                          buf, PS_BUFSIZE_BIG);
          lstrcat( strBuff, BLANK );
          lstrcpyn( &strBuff[len+1], (LPSTR) buf, len2+1 );  // get option keyword

             (*tempptr->PSSendDSC)(lppd, DSC_pagefeatures , (LPSTR)NULL );
          lstrcpy(tmpBuff, "*");
          lstrcat(tmpBuff, strBuff);
          (*tempptr->PSSendDSC)(lppd, DSC_plus ,tmpBuff);   // %%+ *page feature
       }
skipkey:
       // Get next keyword index
       CurrentKeywordIndex = KeywordIndex;
       rc = KeywordNextOrderedKeyword(lppd, (LPWORD)&KeywordIndex, 
                                       CurrentKeywordIndex); 
    }
}
/******************************************************************************
!!!!!!!
!!!!!!!   PROBABLY WE'LL SCRAP MOST OF THIS ROUTINE     !!!!!!!!!!!
!!!!!!!
*                               TSendDeviceFeatures
*  function:
*       This routine sends out the device setup portion of the PostScript job.
*       Device setup info from the Printer Instance database and the PPD files
*       is inserted into the job stream here.
*  prototype:
*       short FAR PASCAL TSendDeviceFeatures(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       RC_ok if no error, else RC_fail.
******************************************************************************/

SHORT FAR PASCAL TSendDeviceFeatures(LPPDEVICE lppd)
{
   LPPRINTERINFO lpPrinterInfo=(LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
   LPASCIIBINPTRS tempptr;
   LPSTR buf = NULL ;
   LPPSEXTDEVMODE lpdm = lppd->lpPSExtDevmode;
   WORD paperIndex, slotIndex ;
   WORD jobtimeout;
   WORD waittimeout;
   WORD copies;
   HANDLE bufhdl = NULL ;
   BOOL bIsCustomPaper;
   BOOL autotrayselect_flg, bMixedBins, bReqsPageRegion;
   char szTmp[256];

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   // make a work buffer
   buf = MGAllocLock(lppd, &bufhdl, PS_BUFSIZE_BIG, GHND, TRUE) ;

   //Get current tray option (Upper, Lower etc) from InputSlot.
   KeywordGetCurrentOption(lppd , IND_INPUTSLOTINFO, &slotIndex) ;

   // find out if we are dealing with a custom paper size
   KeywordGetCurrentOption(lppd , IND_PAPERINFO, &paperIndex) ;

   bIsCustomPaper = (paperIndex == lpPrinterInfo->devcaps.CustomPageSize);
   bMixedBins     = (slotIndex == lpPrinterInfo->devcaps.MixedBins);
   autotrayselect_flg = (slotIndex == lpPrinterInfo->devcaps.AutoSense);

   {
       LPINPUTSLOTINFO lpInputSlotInfo;
       LPMAINKEYHDR    lpCurMainKeyHdr;
       LPBYTE          lpOptionsBlock = lppd->lpWPXblock->WPXarrays;
       
       lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO;
       
       lpInputSlotInfo = 
           (LPINPUTSLOTINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray, 
                                     HIWORD(lpOptionsBlock));
       bReqsPageRegion = lpInputSlotInfo[slotIndex].ReqsPageRegion;
   }

   bReqsPageRegion = bReqsPageRegion && !bIsCustomPaper;

   if (bIsCustomPaper && (buf != NULL))
   {
       // send the custom paper invocation
       TSendCustomPaper(lppd, buf, PS_BUFSIZE_BIG);
   }
    jobtimeout =  lppd->lpPSExtDevmode->dm2.iJobTimeout;
    // add JobTimeout #
    wsprintf((LPSTR)szTmp, (LPSTR)"JobTimeout %d", jobtimeout);
   (*tempptr->PSSendDSC)(lppd, DSC_beginnonPPDfeature, (LPSTR)szTmp );
   AddFeatureDSCEntry(lppd, szTmp, TRUE, TRUE); // TRUE = supplied, nonPPDfeature
   //Send the jobtimeout value but do error recovery first
   PSSendFragment(lppd,PSFRAG_beginsafe);
   
   (*tempptr->PSSendShort)(lppd, jobtimeout);
   (*tempptr->PSSendCRLF)(lppd);
   
   PSSendFragment(lppd, PSFRAG_jobtimeout);
   (*tempptr->PSSendCRLF)(lppd);
   
   PSSendFragment(lppd, PSFRAG_endsafe);
   (*tempptr->PSSendCRLF)(lppd);

   (*tempptr->PSSendDSC)(lppd, DSC_endnonPPDfeature, (LPSTR)NULL );
   // add WaitTimeout #
   waittimeout = lppd->lpPSExtDevmode->dm2.iWaitTimeout;
   wsprintf((LPSTR)szTmp, (LPSTR)"WaitTimeout %d", waittimeout);
   (*tempptr->PSSendDSC)(lppd, DSC_beginnonPPDfeature, (LPSTR)szTmp );
   AddFeatureDSCEntry(lppd, szTmp, TRUE, TRUE); // TRUE = supplied, nonPPDFeature

   //Now send the waittimeout value with error recovery of course
   PSSendFragment(lppd, PSFRAG_beginsafe);
   
   (*tempptr->PSSendShort)(lppd, waittimeout);
   (*tempptr->PSSendCRLF)(lppd);
   
   PSSendFragment(lppd, PSFRAG_waittimeout);
   (*tempptr->PSSendCRLF)(lppd);
   
   PSSendFragment(lppd, PSFRAG_endsafe);
   (*tempptr->PSSendCRLF)(lppd);
   (*tempptr->PSSendDSC)(lppd, DSC_endnonPPDfeature, (LPSTR)NULL );

   //Send the copies value
   {
       BOOL           bCopies;

       // Send copies for the foll. cases
       //  - Portability OR
       //  - Speed & (Copies != 1 || Copies!=currentCopies) OR
       //  - Archive/PJL Archive & (Copies != 1 || Copies!=currentCopies)
       bCopies = (lpdm->dm.enumDialect == DIA_PORTABLE) ||
                     ((lpdm->dm.enumDialect != DIA_EPS) && 
                        (lppd->iCurrentCopies != lpdm->dm.Copies || lpdm->dm.Copies != 1) &&
                        !lpdm->dm2.bWebPrinter);
       
       if (bCopies)
       {
           copies = lppd->lpPSExtDevmode->dm.dm.dmCopies ;
           
           lppd->iCurrentCopies = copies;
       // add Numcopies #
           wsprintf((LPSTR)szTmp, (LPSTR)"NumCopies %d", copies);
           (*tempptr->PSSendDSC)(lppd, DSC_beginnonPPDfeature, (LPSTR)szTmp );
           AddFeatureDSCEntry(lppd, szTmp, TRUE, TRUE); // TRUE = supplied, nonPPDFeature

           PSSendFragment(lppd,PSFRAG_beginsafe);
           
           (*tempptr->PSSendShort)(lppd,copies);
           (*tempptr->PSSendCRLF)(lppd);
           
           PSSendProc(lppd,PSPROC_copies);
           (*tempptr->PSSendCRLF)(lppd);
           
           PSSendFragment(lppd,PSFRAG_endsafe);
           (*tempptr->PSSendCRLF)(lppd);
           (*tempptr->PSSendDSC)(lppd, DSC_endnonPPDfeature, (LPSTR)NULL );
       }
   }

   //Send PostScript for 'public' keywords in the DocumentSetup section
   //from the PPD file. Done only if not EPS output.
   if (buf &&
       lppd->lpPSExtDevmode->dm.enumDialect != DIA_ARCHIVE &&
       lppd->lpPSExtDevmode->dm.enumDialect != DIA_PJL_ARCHIVE)
   {
       SendPublicKeywords(lppd, (LPSTR) buf, PS_BUFSIZE_BIG, DOCSETUP,
                          bReqsPageRegion, autotrayselect_flg, bMixedBins);

   }  // if (buf != NULL)

   MGUnlockFree(lppd, bufhdl, TRUE) ;

   return(RC_ok);
}


/******************************************************************************
*                               TSendPrologInit
*  function:
*       This routine sends commands to initialise the prolog downloaded
*       with this job.  This handles four cases: L1L2 complete, L1L2 incre-
*       mental, L2only complete, L2only incremental.  
*       It does not handle a pre-downloaded header or a minimal (EPSPRINTING)
*       header.
*  prototype:
*       void FAR PASCAL TSendPrologInit(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing.
******************************************************************************/
void FAR PASCAL TSendPrologInit(LPPDEVICE lppd, BOOL fEPSformat)
    {
    LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    BOOL DownLoadHdr = lppd->lpPSExtDevmode->dm2.fHeader;
    BOOL bfBinaryOutput =
      (lppd->lpPSExtDevmode->dm2.iDataOutputFormat != PROTOCOL_ASCII);

    // Fix bug 164116(1) EPS use incremental header download.
    BOOL nodribble = ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED) &&
                      (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS));

    // Initialize the Compat ProcSet if the user selected Portability.
    // Once initialized, it stays until terminated in the job trailer.
    // For Speed option, it is initialized on the first ESCPassThrough() call.
    if (nodribble == TRUE)
    {
      // MS_Win_Compat dup /initialize get exec
      PSSendFragment(lppd,PSFRAG_initcompatprocset);
      (*tempptr->PSSendCRLF)(lppd);
      lppd->job.bfESCPassThrough = TRUE; // set flag that /initialize done
    }

    PSSendOrientationMatrix(lppd, (float)( (float)(lppd->lpPSExtDevmode->dm.dm.dmScale)/(float)100.0),
                      (float)( (float)(lppd->lpPSExtDevmode->dm.dm.dmScale)/(float)100.0) );
    if (DownLoadHdr == TRUE || fEPSformat)
    {

#ifndef ADOBEPS42
     if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
          (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS) &&
           bfBinaryOutput)
     {
#endif
         if (nodribble == FALSE)
         {
          // AdobePS_Win_Driver_Incr_L2 dup /initialize get exec
          PSSendFragment(lppd,PSFRAG_initdribble_L2);
         }
         else // complete header
         {
          // AdobePS_Win_Driver_L2 dup /initialize get exec
          PSSendFragment(lppd,PSFRAG_initprocset_L2);
         }
#ifndef ADOBEPS42
     }
     else
     {
         if (nodribble == FALSE)
         {
            // MS_Win_Driver_Incr dup /initialize get exec
            PSSendFragment(lppd,PSFRAG_initdribble);
         }
         else
         {
            // /MS_Win_Driver /ProcSet findresource dup /initialize get exec
            PSSendFragment(lppd,PSFRAG_initprocset);
         }
     }
#endif
    } // if(DownLoadHdr...

    else
    {
     // Case 6 -- header had been already down there, initialise it.

     // /MS_Win_Driver /ProcSet findresource dup /initialize get exec
     PSSendFragment(lppd,PSFRAG_initprocset);
    }
    (*tempptr->PSSendCRLF)(lppd);

    // init calrgb procset if (color_matching == TRUE)
    if (lppd->lpPSExtDevmode->dm.iColorMatchingMethod ==  COLOR_MATCH_ACROSS_PRINTERS)
     {
     (*tempptr->PSSendCRLF)(lppd);
     // Look for non-standard Colour Space Descriptor here.

     // If not found, use PSPROC_calrgbsp_ps1.
     PSSendProc(lppd, PSPROC_calrgbsp_ps1);

     // /MS_Win_CalRGB /ProcSet findresource dup /initialize get exec
     PSSendFragment(lppd,PSFRAG_initcalrgb);
     (*tempptr->PSSendCRLF)(lppd);
     }
    (*tempptr->PSSendCRLF)(lppd);
    }

/******************************************************************************
*                       TSendPPD
*  function:
*       This routine sends PostScript into the job stream for a specified
*       PPD keyword option. If no option is specified, then the 'current'
*       option for the keyword is used.  The PostScript is surrounded by
*        Begin Feature/End Feature DSC comments.
*
*  arguments:
*       LPPDEVICE lppd -- pdevice pointer
*       WORD KeywordIndex - integer identifying keyword
*       WORD OptionIndex -  integer identifying option, may be NULL
*       LPSTR buf - ptr to work buffer allocated by caller
*       BOOL  mergeSPD - merge setpagedevice, don't send feature save.
*       BOOL  bPageOnly - device feature for current page only.
*                       
*  returns:
*       RC_ok if successful, else RC_fail.
*
******************************************************************************/

short FAR PASCAL TSendPPD(LPPDEVICE lppd, WORD KeywordIndex, WORD OptionIndex,
                          LPSTR buf, WORD bufSize, BOOL mergeSPD, BOOL bPageOnly)
{
   WORD len ;
   LPASCIIBINPTRS tempptr;
   char strBuff[256];
   char tmpBuff[256];
   
   short rc = 0;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
/*
   if (!mergeSPD)
   {
       // start of PostScript error recovery
       PSSendFragment(lppd, PSFRAG_beginsafe);
       (*tempptr->PSSendCRLF)(lppd);
   }
*/
   //Send DSC stuff.
//   len = KeywordGetKeywordTranslation (lppd, KeywordIndex, buf, bufSize);
   // Get  main keyword only, no translation string # 185476
   len = KeywordGetMainKeyword (lppd, KeywordIndex, buf, bufSize);
   if ((lstrcmp(buf, "Collate") == 0) && lppd->lpPSExtDevmode->dm2.bWebPrinter)
   {
      goto ppdexit;
   }    
   if (!mergeSPD)
   {
       // start of PostScript error recovery
       PSSendFragment(lppd, PSFRAG_beginsafe);
       (*tempptr->PSSendCRLF)(lppd);
   }

   // Copying an extra byte for the NULL char that lstrcpyn supplies
   lstrcpyn( strBuff, buf, len+1 );
/* 
   if (OptionIndex != 0xFFFF) {
       // Option present
       int len2;

       len2 = KeywordGetOptionTranslation(lppd, KeywordIndex, OptionIndex, 
                          buf, bufSize);
      lstrcat( strBuff, BLANK );
      lstrcpyn( &strBuff[len+1], (LPSTR) buf, len2+1 );  // get option (or translation)
   }
*/

   // use option keyword instead of option translation string
   // fix bug 184118 yct

   if (OptionIndex != 0xFFFF) {
       // Option present
       int len2;

       len2 = KeywordGetOption(lppd, KeywordIndex, OptionIndex, 
                          buf, bufSize);
      lstrcat( strBuff, BLANK );
      lstrcpyn( &strBuff[len+1], (LPSTR) buf, len2+1 );  // get option keyword
   }


   // if it is input slot and the slot id is DMBIN_AUTO
   // The DSC %%BeginFeature use the unlocalized string instead of
   // getting it from option string. #194358
   if (KeywordIndex == IND_INPUTSLOTINFO)
   {
      LPPRINTERINFO lpPrinterInfo;
      LPBYTE      lpOptionsBlock;
      LPMAINKEYHDR  lpInputSlotInfoHdr ;
      LPINPUTSLOTINFO   lpExtraInputSlotInfo ;

      lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo ;
      lpOptionsBlock = lppd->lpWPXblock->WPXarrays ;
      lpInputSlotInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;
      lpExtraInputSlotInfo = (LPINPUTSLOTINFO)MAKELONG(
      lpInputSlotInfoHdr->extraOptionArray, HIWORD(lpOptionsBlock) );
      if (lpExtraInputSlotInfo[OptionIndex].slotID == DMBIN_AUTO)
      {
          LoadString(ghDriverMod, ID_DSCSTR_AUTOSELECTTRAY, tmpBuff, sizeof(tmpBuff));
          lstrcat( strBuff, BLANK );
          lstrcpy( &strBuff[len+1], (LPSTR) tmpBuff);  // get DSC string
      }
   }
   lstrcpy(tmpBuff, strBuff);
   AddFeatureDSCEntry(lppd, tmpBuff, TRUE, FALSE); // TRUE = supplied

   /* OEMCUST begin */
   LoadDrvrString(ghDriverMod,DSC_beginfeature,buf,64);
   lstrcat(buf,strBuff);
   LoadDrvrString(ghDriverMod, PSFRAG_crlf, strBuff, sizeof(strBuff));
   lstrcat(buf, strBuff);
   len = lstrlen(buf);

   //Send PPD PostScript.
   bufSize -= len;
   rc = KeywordGetOptionPS(lppd, KeywordIndex, OptionIndex, (buf+len),
                           (LPWORD) &bufSize) ;
//   PSSendData(lppd, buf, len) ;
//   (*tempptr->PSSendCRLF)(lppd) ;

   LoadDrvrString(ghDriverMod, PSFRAG_crlf, strBuff, sizeof(strBuff));
   lstrcat(buf, strBuff);

   //More DSC stuff.
   LoadDrvrString(ghDriverMod,DSC_endfeature,strBuff,sizeof(strBuff));
   lstrcat(buf, strBuff);
   LoadDrvrString(ghDriverMod, PSFRAG_crlf, strBuff, sizeof(strBuff));
   lstrcat(buf, strBuff);
   len = lstrlen(buf);

   AdobeOEMSendPSStub(lppd, PS_INDEX_FEATURE, buf, len);
   /* OEMCUST end */

   if (!mergeSPD)
   {
       // end of PostScript error recovery
       PSSendFragment(lppd, PSFRAG_endsafe);
       (*tempptr->PSSendCRLF)(lppd);
   }
ppdexit:    

   return(rc) ;
}

/******************************************************************************
*                       TSendPPDJCL
*  function:
*       This routine sends JCL into the job stream for a specified
*       PPD keyword option. If no option is specified, then the 'current'
*       option for the keyword is used. No DSC comments are sent.
*
*  arguments:
*       LPPDEVICE lppd -- pdevice pointer
*       keyword - ptr to string identifying keyword
*       option - ptr to string identifying option, may be NULL
*       buf - ptr to work buffer allocated by caller
*
*  returns:
*       RC_ok if successful, else RC_fail.
*
******************************************************************************/

short FAR PASCAL TSendPPDJCL(LPPDEVICE lppd, WORD KeywordIndex, WORD OptionIndex,
                  LPSTR buf)
{
   short rc = RC_ok ;
   int len;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

      if (!OptionIndex) //Get current option.
      KeywordGetCurrentOption(lppd, KeywordIndex, (LPWORD)&OptionIndex);

      //Send JCL from PPD 

      KeywordGetOptionPS(lppd, KeywordIndex, OptionIndex, buf, &len) ;

   /* OEMCUST begin -John Kwan */
//      PSSendData(lppd, buf, len) ;
   AdobeOEMSendPSStub(lppd, PS_INDEX_JCL_FEATURE, buf, len);
   /* OEMCUST end -John Kwan */


   return(rc) ;
}

void FAR PASCAL PSSendNup(LPPDEVICE lppd)
{
    WORD  cols, rows, x, y, page;
    float rotation;
    char  temp[10];
    BOOL  bSwap;
    LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
     int nUp, nup_border;

    switch(lppd->lpPSExtDevmode->dm.layout)
    {
      case TWO_UP:
         rotation = (float)TwoUpRotation;
         cols = 2;
         rows = 1;
         nUp = 2;
         break;
      case FOUR_UP:
         rotation = (float)FourUpRotation;
         cols = 2;
         rows = 2;
         nUp = 4;
         break;
      case SIX_UP:
         rotation = (float)TwoUpRotation;
         cols = 3;
         rows = 2;
         nUp = 6;
         break;
      case NINE_UP:
         rotation = (float)FourUpRotation;
         cols = 3;
         rows = 3;
         nUp = 9;
         break;
      case SIXTEEN_UP:
         rotation = (float)FourUpRotation;
         cols = 4;
         rows = 4;
         nUp = 16;
         break;

      case ONE_UP:  /* This shouldn't really happen. We just */
      default:      /*  put it in as a catch-all case    */
         rotation = (float)FourUpRotation;
         cols = 1;
         rows = 1;
         nUp = 1;
         break;
    }

    if(nUp!=1)
    {
       if(lppd->lpPSExtDevmode->dm2.bPrintPageBorder)
       {
          nup_border = 1;
       }
       else
       {
          nup_border = 0;
       }
    }
    else
    {
       nup_border = 0;
    }

    PSSendNupMatrix(lppd);
    PSSendFragment(lppd, PSFRAG_initializeNup);
    (*tempptr->PSSendCRLF)(lppd);

    (*tempptr->PSSendFloat)(lppd, rotation);
    (*tempptr->PSSendShort)(lppd, nup_border);
    (*tempptr->PSSendShort)(lppd,lppd->bbox.right);
    (*tempptr->PSSendShort)(lppd,lppd->bbox.top);
    (*tempptr->PSSendShort)(lppd,cols);
    (*tempptr->PSSendShort)(lppd,rows);
    PSSendFragment(lppd, PSFRAG_beginNup);
    (*tempptr->PSSendCRLF)(lppd);

   // Both x, y should be 0: because we want next physical page start at first slot.
   // Fix bug 241. 6-2-95
    if (fIsDeviceReset(lppd) == RESETDC_NEW_PAGE){
       x=0; y=0;
       lppd->lpProcsetstuff->nuppagenumber=0;  // Re-initial n-up page number to 0;
      }
    else{
       page = lppd->lpProcsetstuff->nuppagenumber % (cols*rows) ;
       x = page % cols;
       y = page / cols;
    }

    /* 
     * If we are doing any of the landscape modes in 2-up printing, 
     * x & y exchange meaning. So we swap them. Actaully we need to
     * check if we started in landscape mode. (It doesn't matter 
     * what orientation we are in now, because we don't want to 
     * change Nup order in the middle of a job).
     */
    bSwap = ((lppd->lpPSExtDevmode->dm.layout == TWO_UP) ||
             (lppd->lpPSExtDevmode->dm.layout == SIX_UP)) &&
            (lppd->startingOrient != OR_PORTRAIT);
    wsprintf(temp, "%d %d ", bSwap ? y : x, bSwap ? x : y);
    PSSendString(lppd, temp);
    PSSendFragment(lppd, PSFRAG_firstpageNup);
    (*tempptr->PSSendCRLF)(lppd);
}


/***********************************************************************
*                      TSendPageSetup
*  function:
*       send out the page setup portion of the PS job
*  prototype:
*       short NEAR PASCAL TSendPageSetup(LPPDEVICE lppd)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       RC_ok
***********************************************************************/

short NEAR PASCAL TSendPageSetup(LPPDEVICE lppd)
{
    LPPRINTERINFO lpPrinterInfo = 
        (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
    LPSTR buf = NULL ;
    LPASCIIBINPTRS tempptr;
    int  tmpi;
    WORD KeywordIndex;
    WORD OptionIndex;
    WORD slotIndex, savelevel =0;
    HANDLE bufhdl = NULL ;
    BOOL autotrayselect_flg, bMixedBins, bReqsPageRegion, bIsCustomPaper;
    BOOL SendDeviceFeatures = 
                (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS );
    BOOL NotArchiveMode = lppd->lpPSExtDevmode->dm.enumDialect != DIA_ARCHIVE &&
                          lppd->lpPSExtDevmode->dm.enumDialect != DIA_PJL_ARCHIVE;
    BOOL PageFeaturesSent = FALSE;
    BOOL bNupEnabled = (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS) &&
                       (lppd->disableNUP == 0) &&
                       (lppd->lpPSExtDevmode->dm.layout != ONE_UP);

    int PSVersion = GetPSVersion(lppd);
    // Fix bug 204185
    WORD    nUp;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    // make a work buffer
    buf = MGAllocLock(lppd, &bufhdl, PS_BUFSIZE_BIG, GHND, TRUE) ;
    if (buf == NULL)
        return RC_fail;

    // send page number and begin setup section
    tmpi = lppd->lpProcsetstuff->currpagenumber;
    wsprintf(buf, "%d %d", tmpi, tmpi);
    (*tempptr->PSSendDSC)(lppd, DSC_page, (LPSTR)buf);

    // Fix bug 197396
    if( bNupEnabled )
    {
        switch(lppd->lpPSExtDevmode->dm.layout)
        {
            case TWO_UP:
                nUp = 2;
                break;
            case FOUR_UP:
                nUp = 4;
                break;
            case SIX_UP:
                nUp = 6;
                break;
            case NINE_UP:
                nUp = 9;
                break;
            case SIXTEEN_UP:
                nUp = 16;
                break;
            default:
                nUp = 1;
                break;
        }
    }

    // Fix bug 197396
    // For portability mode, we have to send pagesave at the beginning
    // of each page to make reverse order printing work.

    if ((lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) ||
        // Fix bug 204185. Send pagesave at the beginning of the page.
        (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
        (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE))
    {
        // fix bug 204185
        // Send "/pagesave save def" at the physical page begin
        if (!bNupEnabled ||       // 1Up  page begin

            bNupEnabled &&        // Nup  physical page begin
            !((fIsDeviceReset(lppd) != RESETDC_NEW_PAGE) &&
            (lppd->lpProcsetstuff->nuppagenumber % nUp )))
        {
            PSSendSave(lppd, 4);
        }
    }
    // same as NT
    (*tempptr->PSSendDSC)(lppd, DSC_platecolor, (LPSTR)NULL );

    TSendViewingOrientation(lppd, FALSE);
    // new in DSC 3.1
    // add it back for NT compatibility
    (*tempptr->PSSendDSC)(lppd, DSC_endpagecomments, (LPSTR)NULL );

    // add %%PageFeature here if it is not defaultoption
    if (NotArchiveMode)
       SendPagePublicKeywords(lppd);

    (*tempptr->PSSendDSC)(lppd, DSC_beginpagesetup, (LPSTR)NULL );

    // page boundry start with page 1+
    //
    if ( !bNupEnabled &&
        (lppd->lpProcsetstuff->currpagenumber > 1))
    {
       if ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_PORTABLE) &&
           // Fix bug 204185. 
           (lppd->lpPSExtDevmode->dm.enumDialect != DIA_ARCHIVE) &&
           (lppd->lpPSExtDevmode->dm.enumDialect != DIA_PJL_ARCHIVE))
       {
          // if it is Portability mode, do it in TDocumentPageBegin()
          AdobeOEMSendPSStub(lppd, PS_INDEX_PHYSICAL_PAGES, NULL, 0); 
       }
  
       // Do Font cache and VM recovery if necessary YCT
       // VMRecover will invoke font cache recovery
       // Get current font cache size specified in dm2.fUserFCSelection

       if ( PSVersion >= 2016 && lppd->lpFontDataList->TFontCacheAvail < 
                (lppd->lpPSExtDevmode->dm2.fUserFCSelection/2))
       {
            savelevel = VMRecover(lppd);
       }    
    }
         
    //Get current tray option (Upper, Lower etc) from InputSlot.
    KeywordGetCurrentOption(lppd , IND_INPUTSLOTINFO, &slotIndex) ;
                 
    bIsCustomPaper = (slotIndex == lpPrinterInfo->devcaps.CustomPageSize);
    autotrayselect_flg = (slotIndex == lpPrinterInfo->devcaps.AutoSense);
    bMixedBins         = (slotIndex == lpPrinterInfo->devcaps.MixedBins);

    {
        LPINPUTSLOTINFO lpInputSlotInfo;
        LPMAINKEYHDR    lpCurMainKeyHdr;
        LPBYTE          lpOptionsBlock = lppd->lpWPXblock->WPXarrays;
 
        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO;
        
        lpInputSlotInfo = 
            (LPINPUTSLOTINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray, 
                                      HIWORD(lpOptionsBlock));
        bReqsPageRegion = lpInputSlotInfo[slotIndex].ReqsPageRegion;
    }

    bReqsPageRegion = bReqsPageRegion && ! bIsCustomPaper;

    if( bNupEnabled )
    {
        bMixedBins = FALSE;    // Suppress MixedBins while doing Nup.

        // If we continue on the same page and page is not filled
        //    yet - don't send any page features which possibly can
        //    contain --setpagedevice-- operator
        if( ( fIsDeviceReset(lppd) != RESETDC_NEW_PAGE )    &&
            ( lppd->lpProcsetstuff->nuppagenumber % nUp )
          )
        {
            SendDeviceFeatures = FALSE;
        }else
        {
            // Finish the old page
            if (lppd->lpProcsetstuff->currpagenumber != 1)
            {
               if ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_PORTABLE) &&
                   // Fix bug 204185. 
                   (lppd->lpPSExtDevmode->dm.enumDialect != DIA_ARCHIVE) &&
                   (lppd->lpPSExtDevmode->dm.enumDialect != DIA_PJL_ARCHIVE))
               {
                  // if it is Portability mode, do it in TDocumentPageBegin()
                  PSSendFragment(lppd, PSFRAG_finalpageNup);
                  (*tempptr->PSSendCRLF)(lppd);
                  AdobeOEMSendPSStub(lppd, PS_INDEX_PHYSICAL_PAGES, NULL, 0); 
               }

        // Do Font cache and VM recovery if necessary YCT
        // VMRecover will invoke font cache recovery

                if ( PSVersion >= 2016 && lppd->lpFontDataList->TFontCacheAvail < 
                (lppd->lpPSExtDevmode->dm2.fUserFCSelection/2))
        {
                    savelevel = VMRecover(lppd);
        }
         }
        }
    }

    if (  (lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED ) &&
          DoVMTracking(lppd))
    {
        // If a ResetDC() has been called, clear VM and start
        // again after doc setup features are sent.
        // Note: This should be done after "finalpage" is sent
        // if we are doing Nup, and a new physical page is starting.
        if (DoVMRecovery(lppd) && fIsDeviceReset(lppd))
        {
            savelevel = VMRecover(lppd);
        }
    }

    //  If MixedBins is selected, we start (page 1) with the Upper tray,
    //    then switch to Lower tray for page 2 on;
    if( SendDeviceFeatures && NotArchiveMode && bMixedBins  )       // MixedBins ON
    {
        if (lppd->lpProcsetstuff->currpagenumber == 1) 
        {
            // Check if Duplex is ON and turn it OFF for page 1

            if (lppd->lpPSExtDevmode->dm.dm.dmDuplex != DUPLEX_NONE)
            {    // DuplexTumble (or) DuplexNoTumble is ON. Turn it OFF. 
                KeywordIndex = IND_DUPLEXINGINFO;
                 OptionIndex =  DUPLEX_NONE;   // Simplex
                 if (TSendPPD(lppd, KeywordIndex, OptionIndex, buf, 
                              PS_BUFSIZE_BIG, 0, 1))
                     PageFeaturesSent = TRUE;
             }

            // Send InputSlot PostScript to switch to Upper tray
            KeywordIndex = IND_INPUTSLOTINFO;
            OptionIndex =  GetInputSlotOptionIndex(lppd, DMBIN_UPPER); 
            if (TSendPPD(lppd, KeywordIndex, OptionIndex, buf, PS_BUFSIZE_BIG, 0, 1))
                PageFeaturesSent = TRUE;
        }     // end of Page 1
        else if (lppd->lpProcsetstuff->currpagenumber == 2) 
        {
            if (lppd->lpPSExtDevmode->dm.dm.dmDuplex != DUPLEX_NONE)
            {  
                KeywordGetCurrentOption(lppd, IND_DUPLEXINGINFO, 
                                        (LPWORD)&OptionIndex);
                if (TSendPPD(lppd, IND_DUPLEXINGINFO, OptionIndex, buf, 
                             PS_BUFSIZE_BIG, 0, 1))
                    PageFeaturesSent = TRUE;
            }

            // Send InputSlot PostScript to switch to Lower tray
            KeywordIndex = IND_INPUTSLOTINFO;
            OptionIndex =  GetInputSlotOptionIndex(lppd, DMBIN_LOWER); 
            if (TSendPPD(lppd, KeywordIndex, OptionIndex, buf, PS_BUFSIZE_BIG, 0, 1))
                PageFeaturesSent = TRUE;
        }     // end of else
   }    // Mixed bins on

    // Send Device features on every ResetDC except changing the
    //     paper orientation or scaling between pages for N-up enabled.
    // Added  26-Oct-1994  -by-  [olegsher]
    if( SendDeviceFeatures && NotArchiveMode )
    {
    // 1. Send all device features        
    // add this to accomodate the MSWord does not send numCopies in
    // the StartDoc() time, send this to every page for PORTABLE mode
       if ( fIsDeviceReset(lppd) == RESETDC_NEW_PAGE ||
         ((lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE ) && 
           lppd->iDefaultCopies != lppd->lpPSExtDevmode->dm.dm.dmCopies) )
       {
           TSendDeviceFeatures (lppd);
       } 
    // 2. Then all page-level features
       PageFeaturesSent = PageFeaturesSent ||
                SendPublicKeywords(lppd, (LPSTR) buf,
                          PS_BUFSIZE_BIG, PAGESETUP,
                          bReqsPageRegion, autotrayselect_flg, bMixedBins);

    // 3. And finally send PostScript for 'public' keywords that do not
    //     have Order Dependency
       PageFeaturesSent = PageFeaturesSent ||
                SendPublicKeywords(lppd, (LPSTR) buf,
                          PS_BUFSIZE_BIG, ANYWHERE,
                          bReqsPageRegion, autotrayselect_flg, bMixedBins);
    } 

    // After every ResetDC recalculate and send new CTM just to be safe 
    // bug # 258056, if portability mode, send CTM for each page.
    if(  fIsDeviceReset(lppd) || (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) )
  //  if(  fIsDeviceReset(lppd) )
    {
       //Construct the coordinate transformation matrix(CTM).
       //Surpsize! Min-header can also do ResetDC -see bug142200, 1-23-95, Ppeng
       if( fIsMinHeaderLppd(lppd) ){
          PSSendMySetup(lppd, NULL, SETUP_PS_COORDS );
          }
       else{
          PSSendMySetup(lppd, NULL, SETUP_GDI_COORDS );
          }
    }
  
 
   // Send screen frequency & angle if necessary
    if ( SendDeviceFeatures &&
            !lppd->lpPSExtDevmode->dm.useDefaultHalftoneParams )
    {
       char buffer1[512];
       char buffer2[512];
       
       LoadString(ghDriverMod, PSFRAG_setscreen, buffer1, 512);
       wsprintf((LPSTR) buffer2, (LPSTR) buffer1, 
                lppd->lpPSExtDevmode->dm.ScreenFrequency, 
                lppd->lpPSExtDevmode->dm.ScreenAngle);
       PortWrite(lppd,buffer2,lstrlen(buffer2));
       (*tempptr->PSSendCRLF)(lppd);
    }

    // If "Optimize for Speed" and a ResetDC() was seen, we would have 
    // recovered VM, so setup the savelevel's back again.
    if (savelevel)
    {
        VMSetupAfterRecovery(lppd, VM_NONE, savelevel);
    }

    // Because we started a new page the N-up may have a different
    //   orientation - send new N-up setup for the new page
    if( SendDeviceFeatures &&
        bNupEnabled )
    {
    BOOL psSpeed = (lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED);
    // put all the saves back

#ifndef ADOBEPS42
    if (savelevel && psSpeed && 
        !(lppd->lpPSExtDevmode->dm2.bfUseLevel2) &&
        (lppd->lpPSExtDevmode->dm.layout != ONE_UP) &&
        (lppd->disableNUP == 0)){
        // N-up is already sent in This case in VMSetupAfterRecovery()-- Ugly!!!
        // Remember to update the conditions here if we ever change it in VMSetupAfterRecovery()
        // This is for bug fix 244 - startnup twice scales the first page twice. 6-5-95
        ;
        }
    else
#endif
      {
        PSSendNup(lppd);
      }
    }

    // now send the driver supplied page setup stuff.
    // if we are not doing VM tracking in speed mode, send only
    // mysetup related stuff - do not send a save.
    if ((DoVMTracking(lppd) &&
        (lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED)) ||  // SAVE_RESTORE
        (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) ||
        // Fix bug 204185. 
        (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
        (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE))
    {
        // 2: PageSetup, PageFeature Not Send.
        // 3: PageSetup, PageFeature Sent.
        PSSendSave(lppd, (PageFeaturesSent? 3 : 2));
    }
    // Otherwise send mysetup, and background fill for negative image.
    else
    {
        // ADOBE_SPOOLER
        PSSendFragment(lppd, PSFRAG_pagesetup);
//        PSSendFragment(lppd, PSFRAG_ResetEnv);

        (*tempptr->PSSendCRLF)(lppd);
        // Color space may be changed.  jjia   5/30/96
        lppd->lpGSStack->lpgGState->bColorSpaceChanged = TRUE;

        // fix bug 200486. jjia   3/27/97
        if (!bNupEnabled &&
            !(lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) &&
            !(lppd->lpProcsetstuff->currpagenumber == 1) &&
            !(PageFeaturesSent))    // setpagedevice may remove settransfer.
            PSSendNegativeImage(lppd, FALSE);
        else
            PSSendNegativeImage(lppd, TRUE);
    }

    // For "Optimize for Speed", a save is sent before page 1
    // so VM used can be recovered by a restore.
    // For "Optimize for Portability", it is done per page.
    if (((lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) ||
        // Fix bug 204185
        (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
        (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE)) &&
        (DoVMTracking(lppd)))
    {
        PSSendSave(lppd, FALSE);
    }
    
    // For "Optimize for Speed", if there are page features,
    // since the save for VM tracking is at the beginning of
    // page 1, doing any VM recovery will blow it away.
    // Therefore, VM recovery is turn off.
    // For "Optimize for portability, it is done per page os
    // it doesn't matter.

#ifndef ADOBEPS42
    if (lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED &&
        (!lppd->lpPSExtDevmode->dm2.bfUseLevel2) &&
        PageFeaturesSent)
      {
#ifdef PSDEBUG
          if (DoVMRecovery(lppd))
          {
              MessageBox(NULL, (LPSTR)"Page Level Features found.\r\nVM recovery disabled.",
                         (LPSTR)"Debug Message", MB_OK | MB_ICONEXCLAMATION);
          }
#endif
          VMRecoverDisable(lppd);
      }
#endif

    if( fIsMinHeaderLppd(lppd) )
      {
      (*tempptr->PSSendCRLF)(lppd);
      PSSendFragment(lppd, PSFRAG_watermark_4_L2); // save CTM not modified by App's passthrough, fix bug 261
      (*tempptr->PSSendCRLF)(lppd);
      }
    
    
    // and we are done with page setup
    (*tempptr->PSSendDSC)(lppd, DSC_endpagesetup, (LPSTR)NULL );
    (*tempptr->PSSendCRLF)(lppd);
    
    // get rid of the work buffer
    MGUnlockFree(lppd, bufhdl, TRUE) ;
    
    // clear ResetDC flag 
    fDeviceReset( lppd, 0);

    PSDEBUG_VMPRINT(lppd, NULL);
    
    return(RC_ok);
}

/***********************************************************************
*                      TSendPageTrailer
*  function:
*       send out the page termination portion of the PS job
*  prototype:
*       short NEAR PASCAL TSendPageTrailer(LPPDEVICE lppd, FLAG fShowPage);
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
/*       FLAG fShowPage -- TRUE => page has data, do showpage
*  returns:
*       RC_ok
***********************************************************************/

short NEAR PASCAL TSendPageTrailer(LPPDEVICE lppd, BOOL fShowPage)
{
   LPASCIIBINPTRS tempptr;
   WORD len;
   char tempbuffer[STRINGBUFSIZE+1];
   char outBuff[STRINGBUFSIZE+1];
   int NumBytes;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   (*tempptr->PSSendCRLF)(lppd);


   // If doing Nup, restore has to be before showpage - ShyamV - 12/08/93
   if ((lppd->lpPSExtDevmode->dm.layout != ONE_UP) &&
#ifdef ADOBE_DRIVER
       (lppd->disableNUP == 0) &&
#endif
       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS))
   {
      // For "Optimize for Speed", send a restore at the end
      // since a save is send at the beginning of page 1
      // so that VM can be recovered if needed.
      // For "Optimize for Portability", it is done per page.
      if (((lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) ||
          // Fix bug 204185
          (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
          (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE)) &&
          (DoVMTracking(lppd)))
      {
         PSSendRestore(lppd);
         VMResetEstimateUsed(lppd);
      }

#if 0
      // fix bug 204185.
      // Do not send "pagesace restore" at the logical page end.
      if ((DoVMTracking(lppd) &&
          (lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED))  ||   //SAVE_RESTORE
          (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) ||
          // Fix bug 204185
          (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
          (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE))
      {
          PSSendRestore(lppd); // Moved this restore after showpage 
                               //  for compatibility with FreeHand 
      }
#endif

      if (fShowPage)
      {

         len = lstrlen(gPSop[PSOP_showpage].lpzName);

         AdobeOEMSendPSStub(lppd, PS_INDEX_SHOWPAGE,
                      gPSop[PSOP_showpage].lpzName, len);
         (*tempptr->PSSendCRLF)(lppd);

      }
   } 
   else
   {
      if (fShowPage)
      {

         len = lstrlen(gPSop[PSOP_showpage].lpzName);

         AdobeOEMSendPSStub(lppd, PS_INDEX_SHOWPAGE,
                      gPSop[PSOP_showpage].lpzName, len);
         (*tempptr->PSSendCRLF)(lppd);

      }
      // For "Optimize for Speed", send a restore at the end
      // since a save is send at the beginning of page 1
      // so that VM can be recovered if needed.
      // For "Optimize for Portability", it is done per page.
      if (((lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) ||
          // Fix bug 204185
          (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
          (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE)) &&
          (DoVMTracking(lppd)))
      {
         PSSendRestore(lppd);
         VMResetEstimateUsed(lppd);
      }

      if ((DoVMTracking(lppd) &&
          (lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED)) ||     // SAVE_RESTORE
          (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) ||
          (lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS) ||
          // Fix bug 204185
          (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
          (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE))
      {
          PSSendRestore(lppd);  
      }
   }
   if( fShowPage && ( lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS ) )
   {
      CHAR  szTemp[32];
      WORD  sLen ;
      sLen=wsprintf((LPSTR)szTemp,(LPSTR)"%%%%[ Page: %d ]%%%%",
               lppd->lpProcsetstuff->currpagenumber);
      (*tempptr->PSSendCRLF)(lppd);

      NumBytes = LoadDrvrString(ghDriverMod,PSFRAG_openbracket,tempbuffer,STRINGBUFSIZE);
      lstrcpyn(outBuff, tempbuffer, NumBytes+1);
      lstrcat(outBuff, szTemp);
      NumBytes = LoadDrvrString(ghDriverMod,PSFRAG_closebracket,tempbuffer,STRINGBUFSIZE);
      lstrcat(outBuff, tempbuffer);
      lstrcat(outBuff, (LPSTR) " = flush");
      lstrcat(outBuff, (LPSTR) "\r\n");
      AdobeOEMSendPSStub(lppd, PS_INDEX_ECHO, outBuff, lstrlen(outBuff)); 

/*
      PSSendFragment(lppd,PSFRAG_openbracket);
      PSSendString(lppd,  (LPSTR)szTemp );
      PSSendFragment(lppd,PSFRAG_closebracket);
      PSSendString(lppd,  (LPSTR) " =");
      (*tempptr->PSSendCRLF)(lppd);
*/
   }

   (*tempptr->PSSendDSC)(lppd, DSC_pagetrailer, (LPSTR)NULL );
   (*tempptr->PSSendCRLF)(lppd);

   // If VMtracking has been disabled due to passthroughs in portability
   // mode, we can reenable it now, so that subsequent pages can still
   // have VM tracking if more passthroughs are not seen.
   if (lppd->VMDisabledOnPassThru &&
       (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE))
   {
       VMEnable(lppd);
       lppd->VMDisabledOnPassThru = FALSE;
   }

   return(RC_ok);
}

/***********************************************************************
*                      TSendFontDSCStuff
*  function:
*       Sends out the %%DocumentNeededFonts & %%DocumentSuppliedFonts
*       in the %%Trailer section (of course, it could send them anywhere)      
*  prototype:
*       VOID NEAR PASCAL TSendFontDSCStuff(LPPDEVICE lppd)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
***********************************************************************/
int FAR PASCAL TSendFontDSCStuff(LPPDEVICE lppd, BOOL fEPSformat)
{
    LPFONTDSCENTRY currentptr;
    LPFILEDSCENTRY currentfileptr;
    LPFEATUREDSCENTRY currentfeatureptr;
    char buf[256];
    int dex, iDSCCount;
    BOOL first;
    LPASCIIBINPTRS tempptr;
    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    // %%DocumentNeededResources: font
    currentptr = lppd->lpFontDSCList->FontDSCList;
    dex = iDSCCount = 0;
    first = TRUE;
  
    while (dex < lppd->lpFontDSCList->FontDSCNextEntry)
    {
      if (currentptr->bfSupplied == FALSE)  // Looking for Fonts Needed
      {
            if (first == TRUE)
         {
            (tempptr->PSSendDSC)(lppd, DSC_docneededres,NULL);        // %%DocumentNeededResources:
            iDSCCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
                first = FALSE;
         }
         // new DSC 3.1
         lstrcpy(buf, currentptr->FontName);
         (*tempptr->PSSendDSC)(lppd, DSC_plus_font,buf);        // %%+ font fontname
         iDSCCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
         
      }
      currentptr++;
      dex++;
    } // while (dex...)
    if (first == TRUE) // If still TRUE list was empty
    {
       (*tempptr->PSSendDSC)(lppd, DSC_docneededres,NULL);        // %%DocumentNeededResources: font
       iDSCCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
     }
    // %%DocumentNeededResources: file
    currentfileptr = lppd->lpFileDSCList->FileDSCList;
    dex = 0;
  
    while (dex < lppd->lpFileDSCList->FileDSCNextEntry)
    {
      if (currentfileptr->bfileSupplied == FALSE)  // Looking for Fonts Needed
      {
         lstrcpy(buf, currentfileptr->FileName);
         (*tempptr->PSSendDSC)(lppd, DSC_plus,buf);        // %%+ name
                                                  // for pre-enclosed file/procset
         iDSCCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
        }
      currentfileptr++;
      dex++;
    } // while (dex...)


    // %%DocumentSuppliedResources: font
    currentptr = lppd->lpFontDSCList->FontDSCList;
    dex = 0;
    first = TRUE;
  
    while (dex < lppd->lpFontDSCList->FontDSCNextEntry)
    {
      if (currentptr->bfSupplied == TRUE)  // Looking for Fonts supplied
      {
            if (first == TRUE)
         {
            (*tempptr->PSSendDSC)(lppd, DSC_docsuppliedres,NULL);  // %%DocumenteSuppliedResource:
            iDSCCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
               first = FALSE;
         }
         //  new DSC 3.1
         lstrcpy(buf, currentptr->FontName);
           (*tempptr->PSSendDSC)(lppd, DSC_plus_font,buf);     // %%+ font fontname
         iDSCCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);

      }
      currentptr++;
      dex++;
    } // while (dex...)
    if (first == TRUE) // If still TRUE list was empty
    {
       (*tempptr->PSSendDSC)(lppd, DSC_docsuppliedres,NULL);        // %%DocumentSuppliedResources: font
       iDSCCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
     }
    // %%DocumentSuppliedResources: file
    currentfileptr = lppd->lpFileDSCList->FileDSCList;
    dex = 0;
  
    while (dex < lppd->lpFileDSCList->FileDSCNextEntry)
    {
      if (currentfileptr->bfileSupplied == TRUE)  // Looking for Files Needed
      {
         lstrcpy(buf, currentfileptr->FileName);
         (*tempptr->PSSendDSC)(lppd, DSC_plus,buf);        // %%+ file/procset name
                                                  // for pre-enclosed file/procset
         iDSCCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
        }
      currentfileptr++;
      dex++;
    } // while (dex...)

    if (!fEPSformat)  // if EPS do not send the following
    {
//    new in DSC 3.1  to be complete
    // %%DocumentSuppliedFeatures: 
    currentfeatureptr = lppd->lpFeatureDSCList->FeatureDSCList;
    dex = 0;
    first = TRUE;
  

    while (dex < lppd->lpFeatureDSCList->FeatureDSCNextEntry)
    {
      if (currentfeatureptr->bfeatureSupplied == TRUE)  // Looking for Files Needed
      {
         if (first == TRUE)
         {
           (*tempptr->PSSendDSC)(lppd, DSC_docsuppliedfeatures,NULL);  // %%DocumentSuppliedFeatures:
           iDSCCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
              first = FALSE;
         }
         if (currentfeatureptr->bNonPPDFeature == TRUE)
            lstrcpy(buf, currentfeatureptr->FeatureName);
         else 
         {
            lstrcpy(buf, "*");
            lstrcat(buf, currentfeatureptr->FeatureName);
         }
         (*tempptr->PSSendDSC)(lppd, DSC_plus,buf);        // %%+ *feature name
         iDSCCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
        }
      currentfeatureptr++;
      dex++;
    } // while (dex...)

     if ( first == TRUE)
    {
       (*tempptr->PSSendDSC)(lppd, DSC_docsuppliedfeatures,NULL);// %%DocumentSuppliedFeatures:
       iDSCCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
     }
   }
     return (iDSCCount);
}     
/***********************************************************************
*                      TSendTrailer
*  function:
*       send out the job termination portion of the PS job
*  prototype:
*       short FAR PASCAL TSendTrailer(LPPDEVICE lppd, BOOL fEPSformat)
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*       BOOL fEPSformat -- TRUE if we are generating EPS format header
*                          (not related to minimal header a.k.a. EPSPRINTING)
*  returns:
*       RC_ok
***********************************************************************/
short FAR PASCAL TSendTrailer(LPPDEVICE lppd, BOOL fEPSformat)
{
   LPASCIIBINPTRS tempptr;
   int cb;
   char  szTemp[256];
   int iCount = 0;

   BOOL DownLoadHdr = lppd->lpPSExtDevmode->dm2.fHeader;
   BOOL bfBinaryOutput =
      (lppd->lpPSExtDevmode->dm2.iDataOutputFormat != PROTOCOL_ASCII);

   // Fix bug 164116(1) EPS use incremental header download.
   BOOL nodribble = ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED) &&
                     (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS));

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   (*tempptr->PSSendDSC)(lppd, DSC_trailer, (LPSTR) NULL );

   // for NT compatibility
   // give app or OEM a chance to enter their %%DocumentProcessColors:
   //
   (*tempptr->PSSendDSC)(lppd, DSC_documentprocesscolors, (LPSTR)NULL);     

   iCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);

   if (!fEPSformat)
   {  
      (*tempptr->PSSendDSCBBox)(lppd, DSC_bbox, (LPRECT)&lppd->bbox);
      iCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);

   }

   if ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_PORTABLE) &&
       // Fix bug 204185. 
       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_ARCHIVE) &&
       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_PJL_ARCHIVE))
   {
      // if it is Portability mode, do it in the TDocumentEnd()

      // If doing Nup, issue finalpage procedure.
      if ((lppd->lpPSExtDevmode->dm.layout != ONE_UP) &&
          (lppd->disableNUP == 0) &&
          (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS))
      { 
         PSSendFragment(lppd, PSFRAG_finalpageNup);
         iCount += PSGetFragmentLength( lppd, PSFRAG_finalpageNup);
         (*tempptr->PSSendCRLF)(lppd);
         iCount += 2;

      }
   }

   // If VM tracking was disabled in the middle of the job
   // (on seeing a passthrough for example) in speed mode, 
   // we have to send restore to match all outstanding saves.
   if (!DoVMTracking(lppd) && lppd->VMDisabledOnPassThru &&
       (lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED))
   {
       while (lppd->lpProcsetstuff->savelevel > 0) {
       // return # of bytes send  (YCT) 
         iCount += PSSendRestore(lppd);
       }
   }
   lppd->VMDisabledOnPassThru = FALSE;

   iCount += TSendFontDSCStuff(lppd, fEPSformat);  // %%DocumentNeededFonts & %%DocumentSuppliedFonts
                            
   // terminate calrgb procset if (color_matching == TRUE)
   if (lppd->lpPSExtDevmode->dm.iColorMatchingMethod ==  COLOR_MATCH_ACROSS_PRINTERS)
   {
      // /MS_Win_CalRGB /ProcSet findresource dup /terminate get exec
      PSSendFragment(lppd,PSFRAG_termcalrgb);
      iCount += PSGetFragmentLength(lppd, PSFRAG_termcalrgb);
      (*tempptr->PSSendCRLF)(lppd);
   }

   // Check to see whether we send the header down seperately

   if ((DownLoadHdr == TRUE) || fEPSformat)
   {
#ifndef ADOBEPS42
      if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
           (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS) &&
           bfBinaryOutput )
      {
#endif
         if (nodribble == FALSE)
         {
            // AdobePS_Win_Driver_Incr_L2 dup /terminate get exec
            PSSendFragment(lppd,PSFRAG_termdribble_L2);
            iCount += PSGetFragmentLength(lppd,PSFRAG_termdribble_L2);
         }
         else // complete header was downloaded
         {
            // AdobePS_Win_Driver_L2 dup /terminate get exec
            PSSendFragment(lppd,PSFRAG_termprocset_L2);
            iCount += PSGetFragmentLength(lppd,PSFRAG_termprocset_L2);
         }
#ifndef ADOBEPS42
      }
      else
      {
         if (nodribble == FALSE)
         {
            // MS_Win_Driver_Incr dup /terminate get exec
            PSSendFragment(lppd,PSFRAG_termdribble);
            iCount += PSGetFragmentLength(lppd,PSFRAG_termdribble);
         }
         else
         {
            // /MS_Win_Driver /ProcSet findresource dup /terminate get exec
            PSSendFragment(lppd,PSFRAG_termprocset);
            iCount += PSGetFragmentLength(lppd,PSFRAG_termprocset);
         }
      }
#endif
   }
   else
   {
      // Case 6 -- header had been already down there, just /terminate it.

      // /MS_Win_Driver /ProcSet findresource dup /terminate get exec
      PSSendFragment(lppd,PSFRAG_termprocset);
      iCount += PSGetFragmentLength(lppd,PSFRAG_termprocset);
   }
   (*tempptr->PSSendCRLF)(lppd);
   iCount += 2;

   // terminate Compat ProcSet, if it was initialized
   // MS_Win_Compat dup /terminate get exec

   if (lppd->job.bfESCPassThrough == TRUE)
   {
      PSSendFragment(lppd, PSFRAG_termcompatprocset);
      iCount += PSGetFragmentLength(lppd, PSFRAG_termcompatprocset);
      (*tempptr->PSSendCRLF)(lppd);
      iCount += 2;
   }

   // For "Optimize for Speed", send a restore at the end
   // since a save is send at the beginning of page 1
   // so that VM can be recovered if needed.
   // For "Optimize for Portability", it is done per page.
   if ((lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED) &&
       DoVMTracking(lppd))
   {
      iCount += PSSendRestore(lppd);
   }
   // %%DataCount:    new DSC3.1
   // %%+ Jrandom 32 

   iCount += PrintPassthroughInfo(lppd, iCount);
  
   if(lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS )
   {
      // Send %%Pages: DSC we promised in the Job Header section (remember atend ?) 
      // Do this only for Non EPS files as EPS files already have this sent 
      // at the beginning of the document.
      cb = wsprintf(szTemp, "%d", (lppd->lpProcsetstuff->currpagenumber - 1));
      (*tempptr->PSSendDSC)(lppd, DSC_pages, (LPSTR)szTemp);
      iCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);      
      
      PSSendFragment(lppd,PSFRAG_openbracket);
      iCount += PSGetFragmentLength(lppd,PSFRAG_openbracket);
      PSSendString(lppd,  (LPSTR)"%%[ LastPage ]%%" );
      iCount += 16;
      PSSendFragment(lppd,PSFRAG_closebracket);
      iCount += PSGetFragmentLength(lppd,PSFRAG_closebracket);
      PSSendString(lppd,  (LPSTR) " = flush");
      (*tempptr->PSSendCRLF)(lppd);
      iCount += 10;
   }
   wsprintf(szTemp, "%d", iCount);
   (*tempptr->PSSendDSC)(lppd, DSC_trailerlength, (LPSTR)szTemp);
   (*tempptr->PSSendDSC)(lppd, DSC_eof, (LPSTR)NULL );

   return(RC_ok);
}


/******************************************************************************
*                          TSendCustomPaper
*  function:
*       This routine sends PostScript into the job stream to invoke
*       a custom paper size.
*  prototype:
*       void NEAR PASCAL TSendCustomPaper(LPPDEVICE lppd, LPSTR buf);
*  arguments:
*       LPPDEVICE lppd -- pdevice pointer
*       buf - ptr to work buffer allocated by caller
*  returns:
*       nothing
******************************************************************************/
void NEAR PASCAL TSendCustomPaper(LPPDEVICE lppd, LPSTR buf, int bufSize)
{
    LPASCIIBINPTRS tempptr;
    LPPSEXTDEVMODE lpdm = lppd->lpPSExtDevmode;
    LPPRINTERINFO  lpPrinterInfo;
    LPCUSTPAGEINFO lpCustPageInfo;
    char           temp[256];
    char           tmpBuff[256];
    LPSTR          lpPPDVersion;
    BOOL           bRotated;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    lpPrinterInfo = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
    lpCustPageInfo = (LPCUSTPAGEINFO) &lpPrinterInfo->custpageinfo;

    // put out beginsafe
    PSSendFragment(lppd, PSFRAG_beginsafe);
    (*tempptr->PSSendCRLF)(lppd);

    LoadDrvrString(ghDriverMod,DSC_beginfeature,temp,64);
    lstrcpy(buf, temp);
    LoadString(ghDriverMod, ID_PPDSTR_KEY_CUSTOMPAGE, (LPSTR) temp, 256);
    lstrcat(buf,temp);
    lstrcpy(tmpBuff, temp);
    LoadDrvrString(ghDriverMod, PSFRAG_crlf, temp, sizeof(temp));
    lstrcat(buf,temp);
    /*
     * loop thru the parameters and send 'em
     * NOTE: this code assumes that the parameters will be looped
     * thru in order (that is, in the order specified by the "order"
     * variable in the .PPD).  
     */

    {
        int custArr[5];
        int i;

        if (lpdm->dm.currentCustPaper == 0xffff)
            return;

        if (lpdm->dm.currentCustPaper == APP_DEFINED)
        {
            custArr[lpCustPageInfo->width.order - 1] = 
                (int) lpdm->dm.appCustWidth;
            custArr[lpCustPageInfo->height.order - 1] = 
                (int) lpdm->dm.appCustHeight;
            custArr[lpCustPageInfo->widthOffset.order - 1] = 
                (int) lpCustPageInfo->widthOffset.min;
            custArr[lpCustPageInfo->heightOffset.order - 1] = 
                (int) lpCustPageInfo->heightOffset.min;
            custArr[lpCustPageInfo->Orientation.order - 1] = 
                (int) lpCustPageInfo->Orientation.min;
        }
        else
        {
            lpPPDVersion = StringRefToLPBYTE(lppd, lpPrinterInfo->PPDVersion.dword);

            i = lpdm->dm.currentCustPaper;
            bRotated = (lpdm->dm.custPaper[i].Transverse & 01);

            custArr[lpCustPageInfo->width.order - 1] = 
                bRotated ? (int) lpdm->dm.custPaper[i].customHeight :
                (int) lpdm->dm.custPaper[i].customWidth;
            custArr[lpCustPageInfo->height.order - 1] = 
                bRotated ? (int) lpdm->dm.custPaper[i].customWidth :
                (int) lpdm->dm.custPaper[i].customHeight;
// do not swap offset               
            custArr[lpCustPageInfo->widthOffset.order - 1] = 
//              bRotated ? (int) lpdm->dm.custPaper[i].heightOffset :
                (int) lpdm->dm.custPaper[i].widthOffset;
            custArr[lpCustPageInfo->heightOffset.order - 1] = 
//              bRotated ? (int) lpdm->dm.custPaper[i].widthOffset :
                (int) lpdm->dm.custPaper[i].heightOffset;

            // This value has effect only on (PPD-43 || roll-fed) devices.
            // On ((PPD-42 or older) && cut-sheet) devices, this parameter
            // has no effect , so the *CustomPageSize code will discard it.
            // (PPD spec 4.2 p.78)
            custArr[lpCustPageInfo->Orientation.order - 1] =
                !(int) lpdm->dm.custPaper[i].Transverse;
        }

        for (i=0; i<5; i++)
        {
            //(*tempptr->PSSendShort)(lppd, (int) custArr[i]);
             
            // add the ascii string of these value
            _ltoa((int)custArr[i], temp, 10);
            lstrcat(buf, temp);
            lstrcat(buf, " ");
            lstrcat(tmpBuff, temp);
            lstrcat(tmpBuff, " ");

        }
    }
    AddFeatureDSCEntry(lppd,tmpBuff, TRUE, FALSE); // TRUE = supplied
    // send the custom paper invocation
    {
        LPSTR lpStr;

        lpStr = STRREF_TO_PTR(lppd->lpWPXblock->WPXstrings,
                              lpCustPageInfo->Invocation);
//        PSSendData(lppd, lpStr, lpCustPageInfo->Invocation.w.length);
//        (*tempptr->PSSendCRLF)(lppd);

        lstrcat(buf, lpStr);
        LoadDrvrString(ghDriverMod, PSFRAG_crlf, temp, sizeof(temp));
        lstrcat(buf, temp);
        LoadDrvrString(ghDriverMod,DSC_endfeature,temp,64);
        lstrcat(buf, temp);
        
        LoadDrvrString(ghDriverMod, PSFRAG_crlf, temp, sizeof(temp));
        lstrcat(buf, temp);

        AdobeOEMSendPSStub(lppd, PS_INDEX_FEATURE, buf, lstrlen(buf));

    }
        
    // end of error recovery
    PSSendFragment(lppd, PSFRAG_endsafe);
    (*tempptr->PSSendCRLF)(lppd);
}

/******************************************************************************
*                          TSendHeader
*  function:
*       This routine sends the correct header (or portions of the header) into
*       the job stream based on the settings of the various user interface
*       switches.
*  prototype:
*       void FAR PASCAL TSendHeader(LPPDEVICE lppd, BOOL fEPSformat);
*  arguments:
*       LPPDEVICE lppd; -- pdevice pointer
*       BOOL fEPSformat -- TRUE if we are generating EPS format header
*                          (not related to minimal header a.k.a. EPSPRINTING)
*  returns:
*       nothing
*  note:
*       see \rel2\doc\hdrstrat.txt for more info
******************************************************************************/

void FAR PASCAL TSendHeader(LPPDEVICE lppd, BOOL fEPSformat)
{
    BOOL DownLoadHdr = lppd->lpPSExtDevmode->dm2.fHeader ||
                       lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE ||
                       lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE;
    BOOL bfBinaryOutput =
      (lppd->lpPSExtDevmode->dm2.iDataOutputFormat != PROTOCOL_ASCII);

    // Fix bug 164116(1) EPS use incremental header download.
    BOOL nodribble = ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED) &&
                      (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS));

    if ((DownLoadHdr == TRUE) || fEPSformat)
     {
     // the header has not be downloaded yet, or we are generating an
     // EPS format file which always has a header. Decide what type
     // of header to send
     // the min_header case is taken care of by a substitute function (case 5)
     // the remaining 4 cases are as follows:
     //  case 1:  level independent -- total header
     //  case 2:  level 2 only -- total header
     //  case 3:  level independent -- incremental download
     //  case 4:  level 2 only -- incremental download


     // check for the conditions in which we can use L2

#ifndef ADOBEPS42
      if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
          (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS ) &&
           bfBinaryOutput )
      {
#endif
         // Level 2 only
         if (nodribble == FALSE)
          TSendHeaderL2OnlyDribble(lppd);
         else
          TSendHeaderL2OnlyALL(lppd);
#ifndef ADOBEPS42
      }else
      {
         // Level1 / Level 2 Compat
         if (nodribble == FALSE)
          TSendHeaderL1L2CompatDribble(lppd);
         else
          TSendHeaderL1L2CompatALL(lppd);
      }
#endif
     }else
     {
     // case 6 -- header already downloaded, initialize it.
     TSendHeaderInitAlreadyDown(lppd);
     }

}

/******************************************************************************
*                  TSendHeaderInitAlreadyDown
*  function:
*       This routine inits the header which was supposed to be already
*       in the printer
*  prototype:
*       void NEAR PASCAL TSendHeaderInitAlreadyDown(LPPDEVICE lppd);
*  arguments:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
******************************************************************************/

void NEAR PASCAL TSendHeaderInitAlreadyDown(LPPDEVICE lppd)
{
   LPASCIIBINPTRS tempptr;
   char   buffer[80];
//   char   tmpbuf[256];

   BOOL bfBinaryOutput =
   (lppd->lpPSExtDevmode->dm2.iDataOutputFormat != PROTOCOL_ASCII);

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   (*tempptr->PSSendCRLF)(lppd);

   //Fix bug 120000. jjia. 10/13/95
//   lstrcpy(tmpbuf, szProcset);
//   lstrcpy(tmpbuf, "file "); remove the extra "file"
   LoadDrvrString(ghDriverMod, PSFRAG_dscincludeprocset, buffer, sizeof(buffer));
   // delete includeprocset in DSC 3.1
   // use %%IncludeResource add file 
   //
   //   lstrcat (tmpbuf, buffer);

   (*tempptr->PSSendDSC)(lppd, DSC_includeresource, (LPSTR)buffer);
    // Add file name to list for DSC %%DocumentNeededResource
   AddFileDSCEntry(lppd,buffer,FALSE);  //FALSE == File needed

   PSSendSave(lppd, FALSE);

   //Move fatalerr to userdict and send download before err handler
   //PSSendProc(lppd,PSPROC_fatalerr_ps1);

   // "prolog not present" error
   TSendHeaderProNotPresentError(lppd);

   // protocol-related errors
   TSendProtocolError(lppd);

#ifndef ADOBEPS42
   if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
        (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS) &&
        bfBinaryOutput)
   {
      TSendHeaderOnlyL2Error(lppd);
   }
#else
   TSendHeaderOnlyL2Error(lppd);
#endif

   PSSendRestore(lppd);

   // "Not enough VM" Error
   TSendHeaderVMError(lppd);  // Send PS to handle low VM error

   VMRecoverDisable(lppd);
    VMCheck(lppd, VM_DOCSTART, 0);
   VMRecoverEnable(lppd);

#ifndef ADOBEPS42
   // level2 images error
   if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS  ))
   {
      TSendHeaderL2ImageError(lppd);
   }
#endif

   lppd->lpProcsetstuff->allthere = TRUE;
}

/******************************************************************************
*                      TSendHeaderL2OnlyDribble
*  function:
*       This routine sends the Level2 only incremental header and sets up
*       for incremental procset downloading
*  prototype:
*       void NEAR PASCAL TSendHeaderL2OnlyDribble(LPPDEVICE lppd);
*  arguments:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
******************************************************************************/

void NEAR PASCAL TSendHeaderL2OnlyDribble(LPPDEVICE lppd)
    {
    LPASCIIBINPTRS tempptr;
    char buf[80];

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    // Resource emulation package.
    // We don't need it, since we already require Level 2 here.

    // Omit %%Begin...EndProcset, but if you need it it goes here.
    // (*tempptr->PSSendDSC)(lppd,DSC_beginprocset,(LPSTR)"Adobe_Win_Driver_Incr_L2 2.0 0");

    // Fix bug 177406.  DSC clean up: Remove hard coded DSC string.  jjia 10/14/96 
    //(*tempptr->PSSendDSC)(lppd,DSC_beginresource,(LPSTR)"file Adobe_Win_Driver_Incr_L2 2.0 0");
    //     lstrcpy(buf,"Adobe_Win_Driver_Incr_L2 2.0 0");
    LoadDrvrString(ghDriverMod, PSFRAG_dscbeginresource_Incr_L2, buf, sizeof(buf));
    (*tempptr->PSSendDSC)(lppd, DSC_beginresource, (LPSTR)buf);

    // Add file name to list for DSC %%DocumentSuppliedResource
    AddFileDSCEntry(lppd,buf,TRUE);  //TRUE == File Supplied

    // userdict /MS_Win_Driver_Incr_L2 200 dict dup begin put
    PSSendFragment(lppd,PSFRAG_incrdict_L2);
    (*tempptr->PSSendCRLF)(lppd);

      
    //Move fatalerr to userdict and send download before err handler
    //PSSendProc(lppd,PSPROC_fatalerr_ps1);

    // Send error checks related to protocol
    TSendProtocolError(lppd);

    // L2 only error
    TSendHeaderOnlyL2Error(lppd);

    // "Not enough VM" Error
    TSendHeaderVMError(lppd);  // Send PS to handle low VM error

    VMRecoverDisable(lppd);
    VMCheck(lppd, VM_DOCSTART, 0);
    VMRecoverEnable(lppd);

    PSSendProc(lppd, PSPROC_utils0_ps2); 
    if (lppd->job.bfJobMinHeader)
      PSSendProc(lppd, PSPROC_mhutils2_ps2);
    else
      PSSendProc(lppd, PSPROC_utils2_ps2);

    //L3_CLIP
    if (lppd->lpPSExtDevmode->dm2.useLanguageLevel >= 3)
        PSSendProc(lppd, PSPROC_clipsave_ps3);

    // Don't download Nup header for plain old ONE_UP (or) EPS
    if ((lppd->lpPSExtDevmode->dm.layout != ONE_UP) &&
#ifdef ADOBE_DRIVER
        (lppd->disableNUP == 0) &&
#endif
        (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS))
    {
       PSSendProc(lppd, PSPROC_nup_ps2);
    }  

    // if (color_matching == TRUE)
//    if (GetCurrBinPPDVal(lppd, PPDList,ID_PPDSTR_KEY_MATCHCOLOR) == TRUE)

    if (lppd->lpPSExtDevmode->dm.iColorMatchingMethod == COLOR_MATCH_ACROSS_PRINTERS)
     PSSendProc(lppd, PSPROC_calrgb_ps2);

    // Fix bug 200377. Send this header for QuarkXpress EPS.  jjia  3/27/97
    if (lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS)
    {
        procsetsendprocs(lppd, PASST);
        lppd->lpProcsetstuff->procsetlist[PASST]=lppd->lpProcsetstuff->savelevel;
    }

    PSSendFragment(lppd, PSFRAG_end);
    (*tempptr->PSSendCRLF)(lppd);

    // Omit %%Begin...EndProcset, but if you need it it goes here.
    // (*tempptr->PSSendDSC)(lppd, DSC_endprocset,(LPSTR)NULL);
    (*tempptr->PSSendDSC)(lppd, DSC_endresource,(LPSTR)NULL);

    }

/******************************************************************************
*                      TSendHeaderL2OnlyALL
*  function:
*       This routine sends the Level2 only complete header
*  prototype:
*       void NEAR PASCAL TSendHeaderL2OnlyALL(LPPDEVICE lppd)
*  arguments:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
******************************************************************************/

void NEAR PASCAL TSendHeaderL2OnlyALL(LPPDEVICE lppd)
    {
    LPASCIIBINPTRS tempptr;
    char           buffer[80];

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    // Resource emulation package.
    // We don't need it, since we already require Level 2 here.

    // %% BeginResource: procset Adobe_Win_Driver_L2 2.0 0
    // Fix bug 120000. jjia. 10/13/95
    LoadDrvrString(ghDriverMod, PSFRAG_dscbeginresource_L2, buffer, sizeof(buffer));
    (*tempptr->PSSendDSC)(lppd, DSC_beginresource, (LPSTR)buffer);
    // Add file name to list for DSC %%DocumentSuppliedResource
    AddFileDSCEntry(lppd,buffer,TRUE);  //TRUE == File Supplied

    // /MS_Win_Driver_L2 200 dict dup begin
    PSSendFragment(lppd, PSFRAG_declaredict_L2);
    (*tempptr->PSSendCRLF)(lppd);
   
    //Move fatalerr to userdict and send download before err handler
    //PSSendProc(lppd, PSPROC_fatalerr_ps1);

    // Send error checks related to protocol
    TSendProtocolError(lppd);

    // L2 only error
    TSendHeaderOnlyL2Error(lppd);

    // "Not enough VM" Error
    TSendHeaderVMError(lppd);  // Send PS to handle low VM error

    VMRecoverDisable(lppd);
    VMCheck(lppd, VM_DOCSTART, 0);
    VMRecoverEnable(lppd);

    // the Level 2 only procsets
    PSSendProc(lppd,PSPROC_utils0_ps2);
    if (lppd->job.bfJobMinHeader)
       PSSendProc(lppd,PSPROC_mhutils2_ps2);
    else
       PSSendProc(lppd,PSPROC_utils2_ps2);

    //L3_CLIP
    if (lppd->lpPSExtDevmode->dm2.useLanguageLevel >= 3)
        PSSendProc(lppd, PSPROC_clipsave_ps3);

#ifdef ADOBEPS42
    if ((lppd->lpPSExtDevmode->dm.layout != ONE_UP) &&
#ifdef ADOBE_DRIVER
        (lppd->disableNUP == 0) &&
#endif
        (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS))
#endif
    {
        PSSendProc(lppd,PSPROC_nup_ps2);
    }
    PSSendProc(lppd,PSPROC_text_ps2);
    PSSendProc(lppd,PSPROC_textenc_ps2);
    PSSendProc(lppd,PSPROC_textbold_ps2);

#ifdef ADD_EURO
    if (!(lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED) ||
         (lppd->lpPSExtDevmode->dm2.bAddEuro))
        PSSendProc(lppd,PSPROC_euro_ps2);
#endif

    PSSendProc(lppd,PSPROC_kanji_ps2);
    PSSendProc(lppd,PSPROC_kanji2_ps2);

    // Use level 1 for patterns for speed.
    PSSendProc(lppd,PSPROC_graph0_ps2);
    PSSendProc(lppd,PSPROC_graph1_ps1);

    PSSendProc(lppd,PSPROC_imagebw0_ps2);
    PSSendProc(lppd,PSPROC_imageco2_ps2);
   // PSSendProc(lppd,PSPROC_itype3hdr_ps2);
    PSSendProc(lppd,PSPROC_ufl_type3hdr_ps2);  // use UFL version
    PSSendProc(lppd,PSPROC_type1hdr_ps2);
#ifdef T3OUTLINE
    PSSendProc(lppd,PSPROC_type3olhdr_ps2);
#endif
    // Fix bug 164116 (2)
    PSSendProc(lppd, PSPROC_type0hdr_ps2);
    //Do this only if printer allows type 42
    if (lppd->lpPSExtDevmode->dm2.iDLFontFmt == TT_DLFORMAT_TYPE42)
    {
        LANGID  LangID;
        LangID = GetSystemDefaultLangID();
        PSSendProc(lppd,PSPROC_ufl_type42_ps2);

        // We may need to query the languages supported on the host
        // to only download 1 or 2 (Korean) cmaps.
        if (LangID == LANGUAGE_CS)
        {
            PSSendProc(lppd, PSPROC_cmap_134_ps2);
            AddProcsetRecord(lppd, CMAP_134);
        }
        else if (LangID == LANGUAGE_CT)
        {
            PSSendProc(lppd, PSPROC_cmap_136_ps2);
            AddProcsetRecord(lppd, CMAP_136);
        }
        else if (LangID == LANGUAGE_J)
        {
            PSSendProc(lppd, PSPROC_cmap_128_ps2);
            AddProcsetRecord(lppd, CMAP_128);
        }
        else if (LangID == LANGUAGE_K)
        {
            PSSendProc(lppd, PSPROC_cmap_129_ps2);
            PSSendProc(lppd, PSPROC_cmap_130_ps2);
            AddProcsetRecord(lppd, CMAP_129);
            AddProcsetRecord(lppd, CMAP_130);
        }
        PSSendProc(lppd, PSPROC_cmap_FFFF_ps2);
        AddProcsetRecord(lppd, CMAP_FFFF);
    }
    // PSSendProc(lppd, PSPROC_kanji_ps2);  -- conditional for
    //                                   vertical text

    PSSendProc(lppd, PSPROC_compat_ps2);

    // Fix bug 164116 (3) 
    // end
    PSSendFragment(lppd, PSFRAG_end);
    (*tempptr->PSSendCRLF)(lppd);

    // %% EndResource
    (*tempptr->PSSendDSC)(lppd, DSC_endresource, (LPSTR)NULL);

    lppd->lpProcsetstuff->allthere = TRUE;

//    if (GetCurrBinPPDVal(lppd, PPDList,ID_PPDSTR_KEY_MATCHCOLOR) == TRUE)

    if (lppd->lpPSExtDevmode->dm.iColorMatchingMethod == COLOR_MATCH_ACROSS_PRINTERS)
     {
     // Fix bug 164116 (3)
     // /Adobe_Win_Driver_L2 begin
     PSSendFragment(lppd, PSFRAG_beginprocset_L2);
     (*tempptr->PSSendCRLF)(lppd);

     PSSendProc(lppd, PSPROC_calrgb_ps2);

     // end
     PSSendFragment(lppd, PSFRAG_end);
     (*tempptr->PSSendCRLF)(lppd);
     }

    }

#ifndef ADOBEPS42
/******************************************************************************
*                      TSendHeaderL1L2CompatDribble
*  function:
*       This routine sends the Level1 / Level2 compatible incremental header
*       and sets up for incremental procset downloading.
*  prototype:
*       void NEAR PASCAL TSendHeaderL1L2CompatDribble(LPPDEVICE lppd);
*  arguments:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
******************************************************************************/

void NEAR PASCAL TSendHeaderL1L2CompatDribble(LPPDEVICE lppd)
    {
    LPASCIIBINPTRS tempptr;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    // Resource emulation package.
    //
    // Since the main prolog dict is an old-style procset, it doesn't need
    // the resource emulation.  However, the calibrated RGB code is a 
    // procset resource, so send the emulation if we're using calibrated RGB.
    //
    // if (color_matching == TRUE)
//    if (GetCurrBinPPDVal(lppd, PPDList,ID_PPDSTR_KEY_MATCHCOLOR) == TRUE)

      if (lppd->lpPSExtDevmode->dm.iColorMatchingMethod == COLOR_MATCH_ACROSS_PRINTERS)
     PSSendProc(lppd, PSPROC_resemul_ps1);


    // Omit %%Begin...EndProcset, but if you need it it goes here.
    // (*tempptr->PSSendDSC)(lppd, DSC_beginprocset,(LPSTR)"Adobe_Win_Driver_Incr 2.0 0");

    // userdict /Adobe_Win_Driver_Incr 150 dict dup begin put
    PSSendFragment(lppd, PSFRAG_incrdict);
    (*tempptr->PSSendCRLF)(lppd);

    //Move fatalerr to userdict and send download before err handler
    //PSSendProc(lppd,PSPROC_fatalerr_ps1);
                          
    // Send protocol-related error checks
    TSendProtocolError(lppd);

    // "Not enough VM" Error
    TSendHeaderVMError(lppd);  // Send PS to handle low VM error

    VMRecoverDisable(lppd);
    VMCheck(lppd, VM_DOCSTART, 0);
    VMRecoverEnable(lppd);

    PSSendProc(lppd,PSPROC_utils0_ps1);
    PSSendProc(lppd,PSPROC_utils1_ps1);
    PSSendProc(lppd,PSPROC_utils2_ps1);

    // Don't download Nup header for plain old ONE_UP (or) EPS
    if ((lppd->lpPSExtDevmode->dm.layout != ONE_UP) &&
#ifdef ADOBE_DRIVER
        (lppd->disableNUP == 0) &&
#endif
        (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS))
    {
       PSSendProc(lppd, PSPROC_nup_ps1);
    }

//            COLOR STUFF

    // if (color matching across printers == TRUE)
    if (lppd->lpPSExtDevmode->dm.iColorMatchingMethod ==  COLOR_MATCH_ACROSS_PRINTERS)
     PSSendProc(lppd, PSPROC_calrgb_ps1);

    PSSendFragment(lppd, PSFRAG_end);
    (*tempptr->PSSendCRLF)(lppd);

    // Omit %%Begin...EndProcset, but if you need it it goes here.
    // (*tempptr->PSSendDSC)(lppd, DSC_endprocset,(LPSTR)NULL);

    }

/******************************************************************************
*                      TSendHeaderL1L2CompatALL
*  function:
*       This routine sends the Level1 / Level2 compatible complete header
*  prototype:
*       void NEAR PASCAL TSendHeaderL1L2CompatALL(LPPDEVICE lppd);
*  arguments:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
******************************************************************************/

void NEAR PASCAL TSendHeaderL1L2CompatALL(LPPDEVICE lppd)
    {
    LPASCIIBINPTRS tempptr;
    char           buffer[80];

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    // this is the level 1 complete header
    PSSendProc(lppd, PSPROC_resemul_ps1);

    // %% BeginResource: procset Adobe_Win_Driver 2.0 0
    // Fix bug 120000. jjia. 10/13/95
    LoadDrvrString(ghDriverMod, PSFRAG_dscbeginresource, buffer, sizeof(buffer));
    (*tempptr->PSSendDSC)(lppd, DSC_beginresource, (LPSTR)buffer);
    // Add file name to list for DSC %%DocumentSuppliedResource
    AddFileDSCEntry(lppd,buffer,TRUE);  //TRUE == File Supplied

                                              // /Adobe_Win_Driver 150 dict dup begin
    PSSendFragment(lppd, PSFRAG_declaredict);
    (*tempptr->PSSendCRLF)(lppd);

    //Move fatalerr to userdict and send download before err handler
    //PSSendProc(lppd, PSPROC_fatalerr_ps1);
                          
    // Send protocol-related error checks
    TSendProtocolError(lppd);

    // "Not enough VM" Error
    TSendHeaderVMError(lppd);  // Send PS to handle low VM error

    VMRecoverDisable(lppd);
    VMCheck(lppd, VM_DOCSTART, 0);
    VMRecoverEnable(lppd);

    PSSendProc(lppd, PSPROC_utils0_ps1);

    // level2 images error
     if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
          (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS  ))
     {
     TSendHeaderL2ImageError(lppd);
     }

    PSSendProc(lppd, PSPROC_utils1_ps1);
    PSSendProc(lppd, PSPROC_utils2_ps1);
    if ((lppd->lpPSExtDevmode->dm.layout != ONE_UP) &&
#ifdef ADOBE_DRIVER
        (lppd->disableNUP == 0) &&
#endif
        (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS))
    {
        PSSendProc(lppd, PSPROC_nup_ps1);
    }
    PSSendProc(lppd, PSPROC_text_ps1);
    PSSendProc(lppd, PSPROC_textenc_ps1);
    PSSendProc(lppd, PSPROC_textbold_ps1);

    PSSendProc(lppd,PSPROC_kanji_ps1);
    PSSendProc(lppd,PSPROC_kanji2_ps1);

    PSSendProc(lppd, PSPROC_graph0_ps1);
    PSSendProc(lppd, PSPROC_graph1_ps1);
    PSSendProc(lppd, PSPROC_graph2_ps1);
    PSSendProc(lppd, PSPROC_imagebw0_ps1);
    PSSendProc(lppd, PSPROC_imagebw1_ps1);
    PSSendProc(lppd, PSPROC_imageco1_ps1);
    PSSendProc(lppd, PSPROC_imageco2_ps1);
    PSSendProc(lppd, PSPROC_type3hdr_ps1);
    PSSendProc(lppd, PSPROC_type1hdr_ps1);
    PSSendProc(lppd, PSPROC_rledecode);
    PSSendProc(lppd, PSPROC_type0hdr_ps1);

//    if (GetCurrBinPPDVal(lppd, &lppd->drvState.PPDList, 
//            ID_PPDSTR_KEY_TTDOWNLOADFORMAT) == TT_DLFORMAT_TYPE42)

    if (lppd->lpPSExtDevmode->dm2.iDLFontFmt == TT_DLFORMAT_TYPE42){

       PSSendProc(lppd,PSPROC_ufl_type42_ps2);

    // We may need to query the languages supported on the host
    // to only download 1 or 2 (Korean) cmaps.
       PSSendProc(lppd, PSPROC_cmap_128_ps2);
       PSSendProc(lppd, PSPROC_cmap_129_ps2);
       PSSendProc(lppd, PSPROC_cmap_130_ps2);
       PSSendProc(lppd, PSPROC_cmap_134_ps2);
       PSSendProc(lppd, PSPROC_cmap_136_ps2);
       PSSendProc(lppd, PSPROC_cmap_FFFF_ps2);
      }

    // while no known level 1 printer supports Type42, this check leaves
    // nothing to chance....

    // PSSendProc(lppd, PSPROC_kanji_ps1);  -- conditional for
    //                                   vertical text

    PSSendProc(lppd, PSPROC_compat_ps1);

    // end /ProcSet defineresource pop
    PSSendFragment(lppd, PSFRAG_enddefresource);
    (*tempptr->PSSendCRLF)(lppd);

    // %% EndResource
    (*tempptr->PSSendDSC)(lppd, DSC_endresource, (LPSTR)NULL);

    lppd->lpProcsetstuff->allthere = TRUE;

    // if (color matching across printers == TRUE)
    if (lppd->lpPSExtDevmode->dm.iColorMatchingMethod ==  COLOR_MATCH_ACROSS_PRINTERS)

// NOTE:  This may not be the correct vaue for iColorOption, or we may not
//        even want to send PSPROC_calrgb_ps1 at all

      if (lppd->lpPSExtDevmode->dm.iColorOption == COLOR_FULL_COLOR)
     {
     // /Adobe_Win_Driver /ProcSet findresource begin
     PSSendFragment(lppd, PSFRAG_beginprocset);
     (*tempptr->PSSendCRLF)(lppd);

     PSSendProc(lppd, PSPROC_calrgb_ps1);

     // end
     PSSendFragment(lppd, PSFRAG_end);
     (*tempptr->PSSendCRLF)(lppd);
     }

    }


/******************************************************************************
*                      TSendHeaderOpenChannel
*  function:
*       This routine sends the Aldus OpenChannel complete header
*  prototype:
*       void NEAR PASCAL TSendHeaderOpenChannel(LPPDEVICE lppd);
*  arguments:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
******************************************************************************/

void NEAR PASCAL TSendHeaderOpenChannel(LPPDEVICE lppd)
{
    LPASCIIBINPTRS tempptr;
    char           buffer[80];

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;


    // put fatalerrorIf and PrtVMMsg in userdict.
    PSSendProc(lppd, PSPROC_fatalerr_ps1);
    TSendHeaderPrtVMMsg(lppd);
    
    // %% BeginResource: procset Adobe_Win_Driver 2.0 0
    // Fix bug 120000. jjia. 10/13/95
    LoadDrvrString(ghDriverMod, PSFRAG_dscbeginresource, buffer, sizeof(buffer));
    (*tempptr->PSSendDSC)(lppd, DSC_beginresource, (LPSTR)buffer);
    // Add file name to list for DSC %%DocumentSuppliedResource
    AddFileDSCEntry(lppd,buffer,TRUE);  //TRUE == File Supplied

    // userdict /Adobe_Win_Driver_OC 300 dict dup begin put
    PSSendFragment(lppd, PSFRAG_declaredict_OC);
    (*tempptr->PSSendCRLF)(lppd);
                          
    // Send protocol-related error checks
    TSendProtocolError(lppd);

    // "Not enough VM" Error
    TSendHeaderVMError(lppd);  // Send PS to handle low VM error

    VMRecoverDisable(lppd);
    VMCheck(lppd, VM_DOCSTART, 0);
    VMRecoverEnable(lppd);

    PSSendProc(lppd, PSPROC_utils0_ps1);

    // level2 images error
    if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
         (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS  ))
    {
     TSendHeaderL2ImageError(lppd);
    }

    PSSendProc(lppd, PSPROC_utils1_ps1);
    PSSendProc(lppd, PSPROC_ocutils2_ps1);
    if ((lppd->lpPSExtDevmode->dm.layout != ONE_UP) &&
#ifdef ADOBE_DRIVER
        (lppd->disableNUP == 0) &&
#endif
        (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS))
    {
        PSSendProc(lppd, PSPROC_nup_ps1);
    }
    PSSendProc(lppd, PSPROC_text_ps1);
    PSSendProc(lppd, PSPROC_textenc_ps1);
    PSSendProc(lppd, PSPROC_textbold_ps1);

    PSSendProc(lppd,PSPROC_kanji_ps1);
    PSSendProc(lppd,PSPROC_kanji2_ps1);

    PSSendProc(lppd, PSPROC_graph0_ps1);
    PSSendProc(lppd, PSPROC_graph1_ps1);
    PSSendProc(lppd, PSPROC_graph2_ps1);
    PSSendProc(lppd, PSPROC_imagebw0_ps1);
    PSSendProc(lppd, PSPROC_imagebw1_ps1);
    PSSendProc(lppd, PSPROC_imageco1_ps1);
    PSSendProc(lppd, PSPROC_imageco2_ps1);
    PSSendProc(lppd, PSPROC_type3hdr_ps1);
    PSSendProc(lppd, PSPROC_type1hdr_ps1);
    PSSendProc(lppd, PSPROC_type0hdr_ps1);
 
//    if (GetCurrBinPPDVal(lppd, &lppd->drvState.PPDList, 
//        ID_PPDSTR_KEY_TTDOWNLOADFORMAT) == TT_DLFORMAT_TYPE42)

      if (lppd->lpPSExtDevmode->dm2.iDLFontFmt == TT_DLFORMAT_TYPE42){
       PSSendProc(lppd,PSPROC_ufl_type42_ps2);

    // We may need to query the languages supported on the host
    // to only download 1 or 2 (Korean) cmaps.
       PSSendProc(lppd, PSPROC_cmap_128_ps2);
       PSSendProc(lppd, PSPROC_cmap_129_ps2);
       PSSendProc(lppd, PSPROC_cmap_130_ps2);
       PSSendProc(lppd, PSPROC_cmap_134_ps2);
       PSSendProc(lppd, PSPROC_cmap_136_ps2);
       PSSendProc(lppd, PSPROC_cmap_FFFF_ps2);
      }

    // while no known level 1 printer supports Type42, this check leaves
    // nothing to chance....

    // PSSendProc(lppd, PSPROC_kanji_ps1);  -- conditional for
    //                                   vertical text

    PSSendProc(lppd, PSPROC_compat_ps1);

    // end 
    PSSendFragment(lppd, PSFRAG_end);
    (*tempptr->PSSendCRLF)(lppd);
    // %% EndResource
    (*tempptr->PSSendDSC)(lppd, DSC_endresource, (LPSTR)NULL);

    lppd->lpProcsetstuff->allthere = TRUE;

}
#endif

#ifdef ADOBEPS42
/******************************************************************************
*                      TSendHeaderOpenChannel
*  function:
*       This routine sends the Aldus OpenChannel complete header
*  prototype:
*       void NEAR PASCAL TSendHeaderOpenChannel(LPPDEVICE lppd);
*  arguments:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
******************************************************************************/

void NEAR PASCAL TSendHeaderOpenChannel(LPPDEVICE lppd)
{
    LPASCIIBINPTRS tempptr;
    char           buffer[80];

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    // put fatalerrorIf and PrtVMMsg in userdict.
    PSSendProc(lppd, PSPROC_fatalerr_ps1);
    TSendHeaderPrtVMMsg(lppd);
    
    // %% BeginResource: procset Adobe_Win_Driver 2.0 0
    // Fix bug 120000. jjia. 10/13/95
    LoadDrvrString(ghDriverMod, PSFRAG_dscbeginresource, buffer, sizeof(buffer));
    (*tempptr->PSSendDSC)(lppd, DSC_beginresource, (LPSTR)buffer);
    // Add file name to list for DSC %%DocumentSuppliedResource
    AddFileDSCEntry(lppd,buffer,TRUE);  //TRUE == File Supplied

    // userdict /Adobe_Win_Driver_OC 300 dict dup begin put
    PSSendFragment(lppd, PSFRAG_declaredict_OC);
    (*tempptr->PSSendCRLF)(lppd);

    // Send protocol-related error checks
    TSendProtocolError(lppd);

    // L2 only error
    TSendHeaderOnlyL2Error(lppd);

    // "Not enough VM" Error
    TSendHeaderVMError(lppd);  // Send PS to handle low VM error

    VMRecoverDisable(lppd);
    VMCheck(lppd, VM_DOCSTART, 0);
    VMRecoverEnable(lppd);

    PSSendProc(lppd, PSPROC_utils0_ps2);
    PSSendProc(lppd, PSPROC_ocutils2_ps2);

    //L3_CLIP
    if (lppd->lpPSExtDevmode->dm2.useLanguageLevel >= 3)
        PSSendProc(lppd, PSPROC_clipsave_ps3);

    if ((lppd->lpPSExtDevmode->dm.layout != ONE_UP) &&
#ifdef ADOBE_DRIVER
        (lppd->disableNUP == 0) &&
#endif
        (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS))
    {
        PSSendProc(lppd, PSPROC_nup_ps2);
    }
    PSSendProc(lppd, PSPROC_text_ps2);
    PSSendProc(lppd, PSPROC_textenc_ps2);
    PSSendProc(lppd, PSPROC_textbold_ps2);

#ifdef ADD_EURO
    if (lppd->lpPSExtDevmode->dm2.bAddEuro)
        PSSendProc(lppd,PSPROC_euro_ps2);
#endif

    PSSendProc(lppd,PSPROC_kanji_ps2);
    PSSendProc(lppd,PSPROC_kanji2_ps2);

    // Use level 1 for patterns for speed.
    PSSendProc(lppd, PSPROC_graph0_ps2);
    PSSendProc(lppd, PSPROC_graph1_ps1);

    PSSendProc(lppd, PSPROC_imagebw0_ps2);
    PSSendProc(lppd, PSPROC_imageco2_ps2);
    PSSendProc(lppd, PSPROC_ufl_type3hdr_ps2);
    PSSendProc(lppd, PSPROC_type1hdr_ps2);
    PSSendProc(lppd, PSPROC_type0hdr_ps2);
#ifdef T3OUTLINE
    PSSendProc(lppd,PSPROC_type3olhdr_ps2);
#endif
 
//    if (GetCurrBinPPDVal(lppd, &lppd->drvState.PPDList, 
//        ID_PPDSTR_KEY_TTDOWNLOADFORMAT) == TT_DLFORMAT_TYPE42)

    PSSendProc(lppd,PSPROC_ufl_type42_ps2);

    // We may need to query the languages supported on the host
    // to only download 1 or 2 (Korean) cmaps.
    PSSendProc(lppd, PSPROC_cmap_128_ps2);
    PSSendProc(lppd, PSPROC_cmap_129_ps2);
    PSSendProc(lppd, PSPROC_cmap_130_ps2);
    PSSendProc(lppd, PSPROC_cmap_134_ps2);
    PSSendProc(lppd, PSPROC_cmap_136_ps2);
    PSSendProc(lppd, PSPROC_cmap_FFFF_ps2);

    // Fix bug 198997, send encoding vactors.
    PSSendProc(lppd, PSPROC_textenc_ps2);
    PSSendProc(lppd, PSPROC_greek_encoding);
    PSSendProc(lppd, PSPROC_turkish_encoding);
    PSSendProc(lppd, PSPROC_hebrew_encoding);
    PSSendProc(lppd, PSPROC_arabic_encoding);
    PSSendProc(lppd, PSPROC_baltic_encoding);
    PSSendProc(lppd, PSPROC_russian_encoding);
    PSSendProc(lppd, PSPROC_ee_encoding);

    // while no known level 1 printer supports Type42, this check leaves
    // nothing to chance....

    // PSSendProc(lppd, PSPROC_kanji_ps2);  -- conditional for
    //                                   vertical text

    PSSendProc(lppd, PSPROC_compat_ps2);

    // end 
    PSSendFragment(lppd, PSFRAG_end);
    (*tempptr->PSSendCRLF)(lppd);
    // %% EndResource
    (*tempptr->PSSendDSC)(lppd, DSC_endresource, (LPSTR)NULL);

    lppd->lpProcsetstuff->allthere = TRUE;

}
#endif

/*************************************************************************
*                   TSendProtocolError
*  function:
*       Sends the error messages which check for correct protocol usage.
*       Becomes a no-op if no binary data is being used, since protocol
*       isn't an issue in that case.
*  prototype:
*       void NEAR PASCAL TSendProtocolError(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
**************************************************************************/
void NEAR PASCAL TSendProtocolError(LPPDEVICE lppd)
{
   switch (lppd->lpPSExtDevmode->dm2.iDataOutputFormat)
   {
      case PROTOCOL_BCP:
         // BCP error check
         TSendHeaderBinBCP_A_Error(lppd);
         TSendHeaderBinBCP_B_Error(lppd);
      break;

      case PROTOCOL_BINARY:
         // Pure Binary (AppleTalk)  error check
         TSendHeaderBinNoProtError(lppd);
      break;
   }
}
/*************************************************************************
*                   TSendHeaderVMError
*  function:
*       Sends the /VM? error message which checks for the insufficient
*       memory to download a font problem
*  prototype:
*       void FAR PASCAL TSendHeaderVMError(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
**************************************************************************/

void NEAR PASCAL TSendHeaderVMError(LPPDEVICE lppd)
    {
    LPASCIIBINPTRS tempptr;
    int pntAtTrueVMErr=0;
    char tempbuffer[STRINGBUFSIZE+1];

    if (GetPSVersion(lppd) >= 2016)
      pntAtTrueVMErr = 1;
    else
      pntAtTrueVMErr = 0;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    if (pntAtTrueVMErr) {  /* VM error message is printed when actual VMerror
                              occurs.  So /VM? is simply a pop */
      lstrcpy(tempbuffer, (LPSTR)"/VM? {pop} bind def");
      PSSendData(lppd, (LPSTR)tempbuffer, lstrlen((LPSTR)tempbuffer));
      (*tempptr->PSSendCRLF)(lppd);
    }
    else {                 /* VM error message is printed when driver detects
                              a possibillity that available VM < VM needed. */
      lstrcpy(tempbuffer, (LPSTR)"/VM? {vmstatus exch sub exch pop gt {PrtVMMsg}if} bind def");
      PSSendData(lppd, (LPSTR)tempbuffer, lstrlen((LPSTR)tempbuffer));
      (*tempptr->PSSendCRLF)(lppd);
    }

    }

/*************************************************************************
*                   TSendHeaderPrtVMMsg
*  function:
*       Sends the error message which checks for the insufficient
*       memory to download a font.
*  prototype:
*       void FAR PASCAL TSendHeaderVMError(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
**************************************************************************/

void FAR PASCAL TSendHeaderPrtVMMsg(LPPDEVICE lppd)
    {
    LPASCIIBINPTRS tempptr;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    PSSendFragment(lppd, PSFRAG_PSERR_VMHeader);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_VM_1);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_VM_2);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_VM_3);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_VM_4);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_VM_5);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_VM_6);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_VM_7);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_VM_8);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_VMTrailr);
    (*tempptr->PSSendCRLF)(lppd);
    }


/*************************************************************************
*                   TSendHeaderL2ImageError
*  function:
*       Sends the error message which checks for the L2 image problem
*  prototype:
*       void FAR PASCAL TSendHeaderL2ImageError(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
**************************************************************************/

void FAR PASCAL TSendHeaderL2ImageError(LPPDEVICE lppd)
    {
    LPASCIIBINPTRS tempptr;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    PSSendFragment(lppd, PSFRAG_PSERR_l2iheader);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_l2images1);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_l2images2);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_l2images3);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_l2images4);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_l2images5);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_l2itrailr);
    (*tempptr->PSSendCRLF)(lppd);
    }

/*************************************************************************
*                   TSendHeaderOnlyL2Error
*  function:
*       Sends the error message which checks L2
*  prototype:
*       void NEAR PASCAL TSendHeaderOnlyL2Error(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
**************************************************************************/

void NEAR PASCAL TSendHeaderOnlyL2Error(LPPDEVICE lppd)
    {
    LPASCIIBINPTRS tempptr;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    PSSendFragment(lppd, PSFRAG_PSERR_onlyL2_1);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_onlyL2_2);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_onlyL2_3);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_onlyL2_4);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_onlyL2_5);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_onlyL2_6);
    (*tempptr->PSSendCRLF)(lppd);
    }

/*************************************************************************
*                   TSendHeaderBinNoProtError
*  function:
*       Sends the error message which says "set driver to use serial/parallel
*       protocol.
*  prototype:
*       void NEAR PASCAL TSendHeaderBinNoProtError(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
**************************************************************************/

void NEAR PASCAL TSendHeaderBinNoProtError(LPPDEVICE lppd)
    {
    LPSTR strptr;
    LPASCIIBINPTRS tempptr;
    char tempbuffer[STRINGBUFSIZE+1];
    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    PSSendFragment(lppd, PSFRAG_PSERR_binnone_1);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binnone_2);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binnone_3);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binnone_4);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binnone_5);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binnone_6);
    (*tempptr->PSSendCRLF)(lppd);

    // send some magic characters -- "(^T@)"
    lstrcpy(tempbuffer,(LPSTR)"( @) ");
    strptr = (LPSTR)tempbuffer;
    *(strptr+1) = CONTROL_T;
    PSSendData(lppd, strptr,lstrlen(strptr)) ;

    PSSendFragment(lppd,PSFRAG_PSERR_binnone_7);
    (*tempptr->PSSendCRLF)(lppd);
    }

/*************************************************************************
*                   TSendHeaderBinBCP_A_Error
*  function:
*       Sends the error message which says "printer can't receive binary
*       on this channel".
*  prototype:
*       void NEAR PASCAL TSendHeaderBinBCP_A_Error(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
**************************************************************************/

void NEAR PASCAL TSendHeaderBinBCP_A_Error(LPPDEVICE lppd)
    {
    LPSTR strptr;
    LPASCIIBINPTRS tempptr;
    char tempbuffer[STRINGBUFSIZE+1];

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    lstrcpy(tempbuffer,(LPSTR)"(  T@) ");

    PSSendFragment(lppd, PSFRAG_PSERR_binBCPA_1);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binBCPA_2);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binBCPA_3);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binBCPA_4);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binBCPA_5);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binBCPA_6);
    (*tempptr->PSSendCRLF)(lppd);

    // send some magic characters -- "(^T^AC@)"
    lstrcpy(tempbuffer,(LPSTR)"(  C@) ");
    strptr = (LPSTR)tempbuffer;
    *(strptr+1) = CONTROL_T;
    *(strptr+2) = CONTROL_A;
    PSSendData(lppd, strptr,lstrlen(strptr)) ;

    PSSendFragment(lppd, PSFRAG_PSERR_binBCPA_7);
    (*tempptr->PSSendCRLF)(lppd);
    }

/*************************************************************************
*                   TSendHeaderBinBCP_B_Error
*  function:
*       Sends the error message which says "set driver to use NO protocol"
*  prototype:
*       void NEAR PASCAL TSendHeaderBinBCP_B_Error(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
**************************************************************************/

void NEAR PASCAL TSendHeaderBinBCP_B_Error(LPPDEVICE lppd)
    {
    LPSTR strptr;
    LPASCIIBINPTRS tempptr;
    char tempbuffer[STRINGBUFSIZE+1];

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    PSSendFragment(lppd, PSFRAG_PSERR_binBCPB_1);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binBCPB_2);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binBCPB_3);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binBCPB_4);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binBCPB_5);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_binBCPB_6);
    (*tempptr->PSSendCRLF)(lppd);

    // send some magic characters -- "(^T^AC@)"
    lstrcpy(tempbuffer,(LPSTR)"(  C@) ");
    strptr = (LPSTR)tempbuffer;
    *(strptr+1) = CONTROL_T;
    *(strptr+2) = CONTROL_A;
    PSSendData(lppd, strptr, lstrlen(strptr)) ;

    PSSendFragment(lppd, PSFRAG_PSERR_binBCPB_7);
    (*tempptr->PSSendCRLF)(lppd);
    }

/*************************************************************************
*                   TSendHeaderProNotPresentError
*  function:
*       Sends the error message which says "prolog is not present"
*  prototype:
*       void NEAR PASCAL TSendHeaderProNotPresentError(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       nothing
**************************************************************************/

void NEAR PASCAL TSendHeaderProNotPresentError(LPPDEVICE lppd)
    {
    LPASCIIBINPTRS tempptr;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    PSSendFragment(lppd, PSFRAG_PSERR_NOPRO_1);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_NOPRO_2);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_NOPRO_3);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_NOPRO_4);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_NOPRO_5);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_NOPRO_6);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_NOPRO_7);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_NOPRO_8);
    (*tempptr->PSSendCRLF)(lppd);
    PSSendFragment(lppd, PSFRAG_PSERR_NOPRO_9);
    (*tempptr->PSSendCRLF)(lppd);
    }


/*****************************************************************************
*
* FUNCTION: PSSendOrientationMatrix
*
* DESCRIPTION: Send the Orientation (CTM) Matrix.  
*
* PSEUDO CODE
* -----------
*   Routine sets up the Orientation (CTM) Matrix for input to /initialize.
*   This routine is also used to adjust CTM scaling factors by concatenating
*   a new CTM before doing a stroke, for non-square resolution printers.
*
*   This matrix is needed only for Standard PostScript output jobs
*
* PARAMETERS        TYPE          PURPOSE
* ----------        ----          -------
* lppd              LPPDEVICE     PDevice pointer
* xScale            float         X Scale Factor
* yScale            float         Y Scale Factor
*
* RETURNS           MEANING
* -------           -------
* short             RC_ok
*
*****************************************************************************/
short FAR PASCAL PSSendOrientationMatrix(LPPDEVICE lppd, float xScale, float yScale)
{
   LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
   float     ZERO_Trans;        // value 0.0, in appropriate type.
   PSMATRIX  Matrix;
   int       i;
   WORD     wOrientation = lppd->lpPSExtDevmode->dm.dm.dmOrientation;
   BOOL bLandscapePlus90 = lpPrinterInfo->devcaps.landscapeOrientPlus90; 
   LPASCIIBINPTRS tempptr= (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;

   ZERO_Trans = (float) 0.0;

   // Create the Orientation Matrix

   if ( wOrientation == DMORIENT_PORTRAIT )
   {
       Matrix[0] = xScale;
       Matrix[1] = ZERO_Trans;
       Matrix[2] = ZERO_Trans;
       Matrix[3] = yScale;
       Matrix[4] = ZERO_Trans;
       Matrix[5] = ZERO_Trans;
   }
   else
   {
      if (   ((wOrientation == DMORIENT_LANDSCAPE) && bLandscapePlus90) ||
             ((wOrientation == DMORIENT_ROT_LANDSCAPE) && !bLandscapePlus90)  )
      {
       Matrix[0] = ZERO_Trans; 
       Matrix[1] = yScale;
       Matrix[2] = -xScale;
       Matrix[3] = ZERO_Trans; 
       Matrix[4] = ZERO_Trans;
       Matrix[5] = ZERO_Trans;
      }else   
      {      
       Matrix[0] = ZERO_Trans;
       Matrix[1] = -yScale;    
       Matrix[2] = xScale;    
       Matrix[3] = ZERO_Trans;
       Matrix[4] = ZERO_Trans;
       Matrix[5] = ZERO_Trans;
      }
   }  // not DMORIENT_PORTRAIT

   // Emit the Matrix now
          
   PSSendFragment(lppd,PSFRAG_leftbracket);
   for(i=0;i<6;i++)
   {
     (*tempptr->PSSendFloat)(lppd,Matrix[i]);
   }
   PSSendFragment( lppd,PSFRAG_rightbracket );
   
   return( RC_ok );

}  /* PSSendOrientationMatrix() */

/*****************************************************************************
*
* FUNCTION: PSSendNupMatrix
*
* DESCRIPTION: Send the Nup (CTM) Matrix.  
*
* PSEUDO CODE
* -----------
*   Routine sets up the Nup (CTM) Matrix for input to /definenup.
*
*   This matrix is needed only for Standard PostScript output jobs
*
* PARAMETERS        TYPE          PURPOSE
* ----------        ----          -------
* lppd              LPPDEVICE     PDevice pointer
*
* RETURNS           MEANING
* -------           -------
* short             RC_ok
*
*****************************************************************************/
void FAR PASCAL PSSendNupMatrix(LPPDEVICE lppd)
{
   RECT     ImageRect ;  //  what the driver thinks is the imageable area
   POINT     PaperDim;    // Paper size in points
   double   a, b, c, d, tx, ty ;
   PAP_ORIENT  bOrientation;   //  Orientation of image on paper, eg. landscape
   BOOL     bMinHeader ;
   BOOL     bLandscapePlus90 ;
   WORD     x_res, y_res;
   WORD     paperIndex ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   LPPAPERINFO  lpPaperInfo ;
   LPBYTE   lpOptionsBlock = lppd->lpWPXblock->WPXarrays;
   LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
   LPASCIIBINPTRS tempptr= (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;
   LPPSEXTDEVMODE lpPSExtDevmode = lppd->lpPSExtDevmode ;
   int      RetValue = RC_ok;

   bMinHeader = lppd->job.bfJobMinHeader ;
   bOrientation = lppd->startingOrient;
   bLandscapePlus90 = lpPrinterInfo->devcaps.landscapeOrientPlus90;


   ImageRect = lppd->imageRect ;

   RetValue = GetCurrentResolution(lppd, lpPSExtDevmode, (LPINT) &x_res,
                        (LPINT) &y_res );
   if (RetValue != RC_ok)
   {
      x_res = RES;                   // plug in default (300x300) resolution
      y_res = RES;
      RetValue = RC_ok;
   }
   KeywordGetCurrentOption(lppd , IND_PAPERINFO, &paperIndex) ;
   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;
   lpPaperInfo = (LPPAPERINFO)MAKELONG(
          lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );

   if (paperIndex == lpPrinterInfo->devcaps.CustomPageSize)
   {
      // Check if it is not app defined custom paper
      if (lpPSExtDevmode->dm.currentCustPaper != APP_DEFINED)
      {
          PaperDim.x =
            (int) (lpPSExtDevmode->dm.custPaper[lpPSExtDevmode->dm.currentCustPaper]).customWidth;
          PaperDim.y =
              (int) (lpPSExtDevmode->dm.custPaper[lpPSExtDevmode->dm.currentCustPaper]).customHeight;
      }
      else
      {
          // App defined.
          PaperDim.x = (int)lpPSExtDevmode->dm.appCustWidth;
          PaperDim.y = (int)lpPSExtDevmode->dm.appCustHeight;
      }
   }
   else
   {
      PaperDim.y = lpPaperInfo[paperIndex].length; 
      PaperDim.x = lpPaperInfo[paperIndex].width; 
   }

   AdjustResolution(lpPSExtDevmode, (LPINT) &x_res, (LPINT) &y_res, 
            (LPPOINT) &PaperDim);

   if (lpPSExtDevmode->dm.marginState == NO_MARGINS   ||  bMinHeader)
   {  // Custom paper selected  or  NO_MARGINS specified.
      //  in  default PS coords  (left, top, right, bottom)
      ImageRect.left = 0;
      ImageRect.top = PaperDim.y;
      ImageRect.right = PaperDim.x;
      ImageRect.bottom = 0;
      //  note minimal header flag also activates No Margins 
   }
   else if (paperIndex == lpPrinterInfo->devcaps.CustomPageSize)
   {
      // Custom paper
      RECT  hwMargins = 
      lpPSExtDevmode->dm.custPaper[lpPSExtDevmode->dm.currentCustPaper].HWmargins;

      ImageRect.left   = hwMargins.left;
      ImageRect.bottom = hwMargins.bottom;
      ImageRect.top    = PaperDim.y - hwMargins.top ;
      ImageRect.right  = PaperDim.x - hwMargins.right ;
   }
   else
   {
      // Standard paper
      if(paperIndex < MAXPAPERMARGINS)
         ImageRect = lpPSExtDevmode->dm2.revisedPaperMargins[paperIndex];
      else
         ImageRect = lpPaperInfo[paperIndex].imageableArea ;
   }


   if (bLandscapePlus90)
   {
    if (bOrientation == OR_LANDSCAPE)
        bOrientation = OR_ROTLANDSCAPE;
    else if (bOrientation == OR_ROTLANDSCAPE)
        bOrientation = OR_LANDSCAPE;
   }

   if(lpPSExtDevmode->dm.bMirror)
   {
      switch (bOrientation)
      {
     case  OR_LANDSCAPE:     //  rotate minus 90 degs
        a = 0.0 ;
        b = -1.0 ;
        c = 1.0 ;
        d = 0.0 ;
        tx = ImageRect.left ;
        ty = ImageRect.top ;
        break;

     case  OR_ROTLANDSCAPE:  // rotate plus 90 degs
        a = 0.0 ;
        b = 1.0 ;
        c = -1.0 ;
        d = 0.0 ;
        tx = ImageRect.right ;
        ty = ImageRect.bottom ;
        break;
     case  OR_PORTRAIT:
     default:
        a = -1.0 ;
        b = 0.0 ;
        c = 0.0 ;
        d = -1.0 ;
        tx = ImageRect.right ;
        ty = ImageRect.top ;
        break;
      }
   }
   else
   {
      switch (bOrientation)
      {
     case  OR_LANDSCAPE:     //  rotate minus 90 degs
        a = 0.0 ;
        b = -1.0 ;
        c = -1.0 ;
        d = 0.0 ;
        tx = ImageRect.right ;
        ty = ImageRect.top ;
        break;
     case  OR_ROTLANDSCAPE:  // rotate plus 90 degs
        a = 0.0 ;
        b = 1.0 ;
        c = 1.0 ;
        d = 0.0 ;
        tx = ImageRect.left ;
        ty = ImageRect.bottom ;
        break;
     case  OR_PORTRAIT:
     default:
        a = 1.0 ;
        b = 0.0 ;
        c = 0.0 ;
        d = -1.0 ;
        tx = ImageRect.left ;
        ty = ImageRect.top ;
        break;
      }
   }
   if(FALSE == bMinHeader )
   {
      //  convert  CTM from  points to log resolution
      a *= 72.0 / x_res ;
      c *= 72.0 / x_res ;
      b *= 72.0 / y_res ;
      d *= 72.0 / y_res ;
   }

   // Emit the Matrix now
   PSSendFragment(lppd,PSFRAG_leftbracket);
   (*tempptr->PSSendFloat)(lppd,(float) a);
   (*tempptr->PSSendFloat)(lppd,(float)b);
   (*tempptr->PSSendFloat)(lppd,(float)c);
   (*tempptr->PSSendFloat)(lppd,(float)d);
   (*tempptr->PSSendFloat)(lppd,(float)tx);
   (*tempptr->PSSendFloat)(lppd,(float)ty);
   PSSendFragment( lppd,PSFRAG_rightbracket );
   
}  /* PSSendNupMatrix() */





/* This function returns TRUE if the current user name is found in the registry.
 * Returns false if not. The Username is returned in the buffer.
 * lppd   -- the PDEVICE. Not used today.
 * buffer -- where to return the Username
 * cb     -- size of buffer. On return, this is the size of the user name.
 */
// These defs are copied from Win'95 SDK's regstr.h:
#define REGSTR_PATH_CURRENT_CONTROL_SET "System\\CurrentControlSet\\Control"
#define REGSTR_VAL_CURRENT_USER         "Current User"
#define REGSTR_PATH_SETUP               "Software\\Microsoft\\Windows\\CurrentVersion"
#define REGSTR_VAL_REGOWNER             "RegisteredOwner"
#define BUF_8K   8193   // 8K+1 size.
BOOL FAR PASCAL GetCurrUserName(LPPDEVICE lppd, LPSTR buffer_nm, int *c){
   BOOL  bRet=TRUE; 
   long  cb;
   char  path_User[60];
   char  current_User[20];
   LPSTR buf = NULL ;
   HANDLE bufhdl = NULL ;
 
    // Some User may have a LONG name (up to 128). OR RegisteredOwmer may be 8K long.
    // SO, to be safe, allocate a buf first -- THis is to safe guard abnormal users.
    buf = MGAllocLock(lppd, &bufhdl, BUF_8K, GHND, TRUE) ;

    if (buf!=NULL) buf[0]='\0'; // initialize.
    // First locate User name in the Current Login User:
    lstrcpy(path_User, (LPSTR)REGSTR_PATH_CURRENT_CONTROL_SET);
    lstrcpy(current_User, (LPSTR)REGSTR_VAL_CURRENT_USER);
    cb = BUF_8K;
    bRet=GetKeyVal(HKEY_LOCAL_MACHINE, (LPSTR)path_User, (LPSTR)current_User, buf, &cb);
    
    // If not found, locate Win'95 Register-ed User name:
    if (bRet==FALSE){
       lstrcpy(path_User, (LPSTR)REGSTR_PATH_SETUP);
       lstrcpy(current_User, (LPSTR)REGSTR_VAL_REGOWNER);
       cb = BUF_8K;
       bRet=GetKeyVal(HKEY_LOCAL_MACHINE, (LPSTR)path_User, (LPSTR)current_User, buf, &cb);
       }

    *c = (int) min(*c, (int)cb);
    lstrcpyn(buffer_nm, buf, *c); // copy back first *c bytes.

   MGUnlockFree(lppd, bufhdl, TRUE) ;

  return bRet;
}

/*****************************************************************************
*
* FUNCTION: TSendViewingOrientation
*
* DESCRIPTION: This routine sends out the %%ViewingOrienation DSC at appropriate
*              time  
*
*
*****************************************************************************/
void FAR PASCAL TSendViewingOrientation(LPPDEVICE lppd, BOOL bSendDefault)
{
    LAYOUT     curLayout=0;
    BOOL       curMirror=0;
    PAP_ORIENT curPaperOrient=0;
    int  id = 0;
    int  length;
    char szTemp[6], szOutBuff[128];

    
    // output ViewingOrientation matrix DSC if the following conditions occur:
    // ResetDC is called and current document settings are different from
    // the starting document settings

    curLayout = lppd->lpPSExtDevmode->dm.layout;
    curPaperOrient = lppd->lpPSExtDevmode->dm.PaperOrient;
    curMirror= lppd->lpPSExtDevmode->dm.bMirror;

    if(bSendDefault || 
       ((curLayout != lppd->startingLayout) 
        || (curMirror != lppd->startingMirror) 
        || (curPaperOrient != lppd->startingOrient)))
    {
       // the following algorithm is based on the following typedef in the 
       // devmode.h and the design of the ViewOrientTable[].
       // "typedef enum {OR_PORTRAIT, OR_LANDSCAPE, OR_ROTLANDSCAPE} PAP_ORIENT;"

       id = curPaperOrient * 2;
       if(curLayout == TWO_UP || curLayout == SIX_UP)
       {
          id++;
       }
       if(curMirror)
       {
          id += 6;
       }
       LoadDrvrString(ghDriverMod, DSC_viewingorientation, szOutBuff, 128);

       wsprintf((LPSTR)szTemp,(LPSTR)"%d ", ViewOrientTable[id].num1);
       lstrcat(szOutBuff,szTemp);
       
       wsprintf((LPSTR)szTemp,(LPSTR)"%d ",ViewOrientTable[id].num2);
       lstrcat(szOutBuff,szTemp);
       
       wsprintf((LPSTR)szTemp,(LPSTR)"%d ",ViewOrientTable[id].num3);
       lstrcat(szOutBuff,szTemp);
       
       wsprintf((LPSTR)szTemp,(LPSTR)"%d",ViewOrientTable[id].num4);
       lstrcat(szOutBuff,szTemp);
       
       length = lstrlen(szOutBuff);
       LoadDrvrString(ghDriverMod, PSFRAG_crlf, szOutBuff+length, 128-length);
       length += 2;
       
       PortWrite(lppd, szOutBuff, length);
    }
} // END TSendViewingOrientation()

/************************************************************************
*
*                       CheckFileDSCEntry
*  Function:
*       Checks to see if a record for a given font has already been
*       added to the font DSC comment list --
*
*  Called:
*       BOOL FAR PASCAL CheckFileDSCEntry(LPPDEVICE lppd, LPSTR lpFileName);
*
*  Parameters:
*       LPPDEVICE lppd  -- pdevice pointer
*       LPSTR lpFileName  -- Name of font to be added
*
*  Returns:
*       BOOL -- TRUE => Name is on list
*               FALSE => Name is not on list
*
*************************************************************************/

BOOL FAR PASCAL CheckFileDSCEntry(LPPDEVICE lppd, LPSTR lpFileName)
{
   LPFILEDSCENTRY currentptr;
   BOOL retval;
   int dex;

   retval = FALSE;
   currentptr = lppd->lpFileDSCList->FileDSCList;
   dex = 0;

   while (retval == FALSE && (dex < lppd->lpFileDSCList->FileDSCNextEntry))
   {
      if (lstrcmpi(currentptr->FileName,lpFileName) == 0)
      {
         retval = TRUE;
      }
      currentptr ++ ;
      dex ++;
   }

   return (retval);
}

/************************************************************************
*                       AddFileDSCEntry
*  Function:
*       Adds a record to the font DSC comment list --
*
*  Called:
*       BOOL FAR PASCAL AddFileDSCEntry(LPPDEVICE lppd,
*                                         LPSTR lpFileName, BOOL bfSupplied);
*  Parameters:
*       LPPDEVICE lppd  -- pdevice pointer
*       LPSTR FileName  -- Name of font to be added
*       BOOL bfSupllied -- Supplied/Needed Flag (pass value along to entry)
*
*  Returns:
*       BOOL -- TRUE => success
*
*************************************************************************/

BOOL FAR PASCAL AddFileDSCEntry(LPPDEVICE lppd, LPSTR lpFileName, BOOL bfSupplied)
{
   LPFILEDSCENTRY currententry;
   BOOL retval;

   retval = FALSE;

   if (retval = CheckFileDSCEntry(lppd, lpFileName) == FALSE)
   {                // Name not is already in list
      if (lppd->lpFileDSCList->FileDSCNextEntry < MAXFONTDATARECORDS)
      {
         currententry = lppd->lpFileDSCList->FileDSCList;
         currententry += lppd->lpFileDSCList->FileDSCNextEntry;
         lstrcpy(currententry->FileName, lpFileName);
         currententry->bfileSupplied = bfSupplied;
         lppd->lpFileDSCList->FileDSCNextEntry ++;
      }
   }

   return (retval);
 }




