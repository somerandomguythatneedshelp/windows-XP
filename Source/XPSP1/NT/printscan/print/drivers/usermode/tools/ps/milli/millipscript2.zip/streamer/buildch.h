/* CM_VerSion buildch.h atm05 1.5 10184.eco sum= 19253 */
/* CM_VerSion buildch.h atm04 1.12 07436.eco sum= 49755 */
/*
  buildch.h

Copyright (c) 1991-1993 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of
Adobe Systems Incorporated.  Many of the intellectual and
technical concepts contained herein are proprietary to Adobe,
are protected as trade secrets, and are made available only to
Adobe licensees for their internal use.  Any reproduction or
dissemination of this software is strictly forbidden unless
prior written permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks of
Adobe Systems Incorporated.

Original version: Craig Rublee Mar 14, 1991
Edit History:
Paul Haahr: Fri Apr 10 12:38:10 1992
John Nogrady: Tue May  5 18:36:43 1992
Craig Rublee: Sun Nov  1 18:33:36 PST 1992
Ed Taft: Wed Sep 29 10:38:51 1993
Terry Dowling: Tue Apr 6 11:43:52 1993
End Edit History.

*/

#ifndef	BUILDCH_H
#define	BUILDCH_H

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif

#ifndef	PACKAGE_SPECS_H
#include PACKAGE_SPECS
#endif

#include PROTOS
#include PUBLICTYPES
#include DEVICETYPES
#include FP

#define MAXSTEMS   (12)
#define MAXBLUES   (12)
#define MAXWEIGHTS (16)

/* Data Structures */


typedef unsigned char *CharDataPtr ;


/* matrix types */

typedef struct {
  Fixed a, b, c, d, tx, ty;
} FixMtx, *PFixMtx;

typedef struct {
  Frac a, b, c, d, tx, ty;
} FracMtx, *PFracMtx;


/* BBoxRec bounding box of character */
typedef struct _t_FCdBBox {
  FCd 		bl;		   /* bottom left x,y value */
  FCd 		tr; 		   /* top right x,y value */
} FCdBBox, *PFCdBBox;


typedef struct _t_BlueValueRec {
  Fixed   topEdge;	 /* Top Edge of zone in Character Space */
  Fixed   botEdge;	 /* Bottom Edge of zone in Character Space */
} BlueValueRec, *PBlueValueRec;

/* Structure for buffers that can grow (see GrowBuff callback proc) */

typedef struct _t_GrowableBuffer {
  char *ptr;            /* Ptr to bytes in buffer */
  Card32 len;           /* Number of bytes in buffer */
  } GrowableBuffer, *PGrowableBuffer;


typedef struct _t_MemoryRec {
  PGrowableBuffer b1, b2, b3, b4, b5;
} MemoryRec, *PMemoryRec;

/* CharSBW:  width and side bearing info (RW) */
typedef struct _t_CharSBW {
  struct {
    FCd         sideBearing; /* SideBearing */
    FCd         width;       /* Character Width */
  } argument;                /* (RW) -character space units-
                                     override data input if present
                                     sideBearing and width output */
  Card32        override;    /* (RW) sidebearing and width override */
/* IMPORTANT NOTE: data item order is important. the data above is
   read/written by the type 1 chip. If this data is changed or
   re-ordered, chip microcode needs to be changed as well.
*/
  struct {
    FCd         sideBearing; /* SideBearing */
    FCd         width;       /* Character Width */
  } result;                  /* (W) -device space units-
                                     sideBearing and width output */
} CharSBW, *PCharSBW;

/* Constants for the override field in the CharSBW record. If the
   override field is non zero the renderer will use the
   width and/or sidebearing values supplied in the CharSBW record
   for the character.
*/
#define DEFAULT_SBW  ((Card32)0L) /* Use default width and sidebearing  */
                                   /* defined in the charstring. */
#define FORCE_WID_X  ((Card32)1L)  /* Override x component of width */
#define FORCE_SBW_X  ((Card32)2L)  /* Override x component of sidebearing and width */
#define FORCE_SBW_XY ((Card32)4L)  /* Override x and y components of */
                                   /* both the side bearing and width */




/* Opaque pointer to FontInst, FontInst is defined in the buildch
   package in bcpriv.h 
*/
typedef struct _t_FontInst FontInst, *PFontInst;

/* ========= Renderer  structures ============= */
/* Character renderer parameters - Font Technology dependent  */

/* TrueType data structures */
typedef struct _t_TTFontDesc {
  short         xDevRes;  /* X device resolution */
  short         yDevRes;  /* Y device resolution */
} TTFontDesc, *PTTFontDesc;

typedef enum {
        CHARACTER_CODE,
        GLYPH_ID
} TTGlyphType;


typedef struct _t_TTCharDataDesc {
  TTGlyphType type;
  Card32      code;
  Card32      offset;
  Card32      length;
  Card8      *returnDataPtr;
} TTCharDataDesc, *PTTCharDataDesc;

typedef struct _t_T1CharDataDesc {
  CharDataPtr   pCharString;     /* Pntr to Charstring to be rendered (R) */
  CharDataPtr   pSubrData;       /* base of SubrData (R) */
  CharDataPtr   pSubrArray;      /* array of offsets to SubrData (R) */
  CharDataPtr   pAccentData; 	 /* base of AccentData (R) */
  CharDataPtr   pAccentArray;	 /* array of offsets to AccentData (R) */
  Card32	index;		 /* CString request (W) */
  Card16        nSubrOffsetBytes;/* number of bytes in each Subr offset (R) */
                                 /*        supported values are 2, 3, 4     */
  Card16        nCSOffsetBytes;  /* number of bytes in each Accent offset (R) */
                                 /*        supported values are 2, 3, 4     */
} T1CharDataDesc, *PT1CharDataDesc;


/* Subroutine (and Accent) pointer computation.

          CAUTION ---- NOTICE ---- WARNING

   This design specifies the byte order of some multi-byte
   quantities. We are, in effect, requiring that ALL implementations
   support a specific (BigEndian, Motorola, Most Significant Byte
   first) data ordering (NOT LittleEndian, Intel, DEC, Least Significant
   Byte first). In addition, this design specifies that the data may be
   aligned on arbitrary byte address boundaries and that no implementation
   may require alignment.

          CAUTION ---- NOTICE ---- WARNING

   The intent of this design is to flexibly support fonts in ROM
   and ROM cartridges that can be executed in place, as well as
   supporting disk based systems in a manner that requires the smallest
   memory possible without requiring any direct involvment by the
   renderer in memory management and/or cache issues.

   The T1CharDataDesc structure is central to this design. The renderer depends
   on this data structure to locate information and the T1CharDataDesc structure
   data (and things it points to) may be modified between calls to the
   renderer, during the GetCString callback (but not during rendering or 
   during any other callback).

   With apology for data type confusion, the address of a subroutine
   will be computed as:


   pSubroutine = pSubrData[Offset];

   where Offset is computed as:

   switch(nSubrOffsetBytes) {
        case 2: Offset = (pSubrArray[n*2]<<8) + (pSubrArray[n*2+1]);
                break;
        case 3: Offset = (pSubrArray[n*3]<<16) + (pSubrArray[n*3+1]<<8) +
                         (pSubrArray[n*3+2]);
                break;
        case 4: Offset = (pSubrArray[n*4]<<24) + (pSubrArray[n*4+1]<<16) +
                         (pSubrArray[n*4+2]<<8) + (pSubrArray[n*4+3]);
                break;
        default:
                CantHappen();
                break;
        }


   This specification specifically allows pCharString and/or pSubrArray
   and/or pAccentArray to be NULL, or that if pSubrArray or pAccentArray
   is not NULL, for Offset (as computed above) to equal 0. In these cases, 
   the renderer will then use the new callback GetCString to obtain the 
   address of the CharString or Subroutine. The GetCString callback is 
   permitted to modify any or all data in the T1CharDataDesc structure.

*/


/* Character renderer parameters - Font Technology independent */

typedef struct _t_CharIO {
  MemoryRec    *pMemoryBuf;      /* Memory Buffer (RW) */
  CharSBW      *pCharInfo;       /* Character width and sidebearing data (RW) */
  FCdBBox      *pCharBBox;       /* Character Bounding Box; (W) */
} CharIO, *PCharIO;


/*  NOTE:
    The following version number MUST be incremented anytime either
    the FontValues or the FontDesc structure is modified.

    All clients MUST assign the version number to the FontDesc
    structure before it is passed to the SetUpValues routine.
*/

#define FontDescVersion 2L

typedef struct _t_FontValues {
  FCdBBox	fontBBox;		/* Font bounding box. */
  Fixed		stdHW;			/* Dominant Horizontal stem width */
  Fixed		stdVW;			/* Dominant Vertical stem width */
  Fixed         defaultSidebearingX;
  Fixed         defaultSidebearingY;
  Fixed         defaultWidthX;
  Fixed         defaultWidthY;
  Fixed		stemSnapH[MAXSTEMS];	/* StemSnapH array  */
  Fixed		stemSnapV[MAXSTEMS];	/* StemSnapV array  */
  Fixed		blueScale;		/* Blue Scale value */
  Fixed		blueFuzz;		/* Blue Fuzz value */
  Fixed		blueShift;		/* Blue Shift Start Value */
  BlueValueRec	blueValues[MAXBLUES];	/* Array of blue values top and bottom*/
  BlueValueRec	familyBlueValues[MAXBLUES];/* Array of family  blue values */
  Card32	flags;			/* see below */
} FontValues, *PFontValues;

/* Constants for flags field in FontValues */
#define	FONT_FORCEBOLD		0x1	/* artificially make the font bolder */
#define	FONT_FORCEBOLD_USED	0x2	/* Force bold flag present in font */


/* FontDesc: Static Font information known at findfont or definefont */
typedef struct _t_FontDesc { 
  Card32	versionNum;	/* Structure version number */
  FracMtx	fontMatrix;	/* Font matrix */
  Card32	privUniqueId;	/* Private dict UniqueId */
  Card32 	blueZones;	/* Bits to identify bottom zones */
  Card32	familyBlueZones;/* Bits to identify bottom zones */
  Fixed         strokeWidth;    /* Stroke width value */
  Fixed         expansionFactor;/* GlobalColoring expansion factor */
  Fixed         boldThreshold;  /* Multi-Master font ForceBold threshold */
  Fixed         initialRandomSeed;/* 0 sets random seed. must be 0<= v < 1 */
  Int16		lenIV;		/* number of encryption header bytes */
  Card16        lenSubrArray;   /* length of subr Array */
  Card16        paintType;      /* Font paint type */
  Card16        lenStemSnapH;   /* Number of elements in StemSnapH Array */
  Card16        lenStemSnapV;   /* Number of elements in StemSnapV Array */
  Card16        numBlueValues;  /* Number of blue values top and bottom */
  Card16        numFamilyBlues; /* Number of family blue values */
  Card16        languageGroup;  /* Font language group */
  Card16        numMasters;     /* Number of masters in a multi-master font */
  Card16        subroutineNumberBias;/* Bias added to encoded subroutine
                                 * number to index into subroutine
                                 * array. Default is 0. This permits
                                 * use of compact number encodings that
                                 * are negative (ie. -1131 to -1) to
                                 * further reduce the size of font files. */
  Card16	lenBuildCharArray;/* number of (Fixed) storage locations for
				 * the get/put othersubrs. Default is 32 */
  Card16        FILLER;		/* alignment */
  FontValues	values[1];	/* Unique values for each master font.
   				 * This must be the last field in the
                          	 * structure. One FontValue record is
				 * allocated for each master in the font */
} FontDesc, *PFontDesc;


/* BitMapRec - Bitmap storage info */
typedef struct _t_BitMapRec {
  Card8		*pBase;	           /* pntr to base of the bit map */
				   /* THIS ADDRESS MUST BE LONG WORD ALIGNED */
  Card32	bMSize; 	   /* number of bytes of memory available */
  Card32	lineWidth;	   /* number of bytes per scanline */
  Card32	xStart;            /* x coord for corner of clipping region */
  Card32	yStart;		   /* y coord for corner of clipping region */
  Card32	scanLines;	   /* number of scanlines */
  Card32	bitWidth;	   /* number of bits in scanline */
  Int32		xOffset;	   /* X offset from base to char origin */
  Int32		yOffset;	   /* Y offset from base to char origin */
  Card32	writeMode;	   /* Logical Writing Mode (and, or, xor) */ 
} BitMapRec, *PBitMapRec;


/* Constants for the writeMode field of the BitMapRec struct */
#define OVER_WRITE_MODE ((Card32)0L)  /* Overwrite data with mask bits */
#define OR_MODE ((Card32)1L)	      /* OR mask bits with data */
#define AND_MODE ((Card32)2L)         /* AND mask bits with data */
#define XOR_MODE ((Card32)3L)         /* XOR mask bits with data */

/* RunRec: Run data */
typedef struct _t_RunRec {
  DevRun	run;		   /* Beginning of run array */
  Int32		xOffset;	   /* X offset from base to char origin */
  Int32		yOffset;	   /* Y offset from base to char origin */
  Card32	dataSize;	   /* Amount of memory needed for character */
} RunRec, *PRunRec;


/* ======================= CALLBACK PROCEDURES =========================== */ 
/*
    The following typedefs define callback procedures that are used by the 
    following character rendering routines: CharBitMap, CharRuns, CharOutLine, 
    PollMetricsDone, PollRenderingDone, WaitMetricsDone, WaitRenderingDone,
    AbortRendering, and GetCStringMetrics.  The call back procedures are 
    defined by the client to the buildch package. Pointers to the procedures
    are assigned to the appropriate fields in a variable of type BCProcs. 
*/

/* ========== DoOtherSubr ==========  */

typedef boolean (*DoOtherSubr_t)
     ARGDECL3(
      Card32     , StackTop,
      Fixed  	*, pStackArray,
      void	*, pClientHook 
     );

/*
    The DoOtherSubr callback procedure is called if an othersubr
    is encountered in the charstring that has no definition in the 
    type 1 interpreter. It is used to execute the PostScript code 
    located in the corresponding entry in the fonts /OtherSubrs array.
    This procedure should only be implemented by PostScript 
    clients of the buildch package. Other clients should assign
    NULL to this callback procedure.

    The pStackArray will contain the arguments to the callothersubr, 
    the number of arguments, and the othersubr number in fixed format 
    in the following order:

	    StackArray[0]   	argument 1
		  ...
	    StackArray[StackTop-2]  argument n
	    StackArray[StackTop-1]  number of arguments (n)
	    StackArray[StackTop]    othersubr number

    When the procedure returns, StackArray should contain the results 
    of the DoOtherSubr in fixed format. StackArray[0] should contain 
    the first result, StackArray[1] the second, etc. The number of 
    results should not exceed the number of original arguments.

    The DoOtherSubr routine should take the arguments
    from the StackArray, convert them to PostScript objects and push 
    them onto the PostScript stack. Then the PostScript code in the 
    OtherSubrs array at the element specified by the othersubr number
    should be executed. When the PostScript code has finished
    executing, the number of elements that have been pushed
    on the PostScript stack should be moved to the StackArray.
    The numbers must be put in the array in fixed format.

    If execution of the PostScript procedure completes without error,
    the client should return true. Otherwise false should be returned.
    If false is returned the rendering routine will abort with
    the BE_CALLBACK_FAILED error.

    The memory used by renderer should not be moved or altered during 
    execution of the callback. The pointer to StackArray will not be valid
    after the  callback returns. If the procedure pointer is NULL then 
    the OtherSubr will be ignored.
*/


/* ========== GrowBuff ==========  */

typedef boolean (*GrowBuff_t)
     ARGDECL4(
      PGrowableBuffer, b,   /* The buffer descriptor */
      Int32, minMore,       /* Minimum number of additional bytes */
      boolean, copyflg,     /* True => copy contents of old to new */
      void   *, pClientHook
     );

/*
    The GrowBuff callback procedure is called by the rendering routines
    to ask the cleint to allocate more memory. 

    b is a pointer to the growable buffer that needs additional memory.
    minMore is the minimum number of additional bytes that should be allocated
    for this growable buffer. The buffer allocated should be at least
    minMore _ b->len bytes in length.

    copyflg is a flag to indicaet if the cntents of the old buffer should be
    copied to the contents of the new buffer. If copyflg is true the callback
    routine must copy the contents.

    If memory request is successful then the callback should return true.

    If not enough memory is available to grow the buffer, the routine 
    must return false. Rendering will then stop and the error BE_MEMORY
    will be returned. memory used by other growable buffers, the charstrings,
    bitmap, or run array must not be moved during the execution of this
    callback.
 */   

/* ========== GetBitMapMemory ==========  */

typedef boolean (*GetBitMapMemory_t)
     ARGDECL3(
      Card32     , nBytes,   /* Number of bytes needed to store bit map */
      BitMapRec *, pBitMap,  /* pBitMap parameter to CharBitMap */ 
      void      *, pClientHook 
     );
/*
    The GetBitMapMemory callback routine will be called during the 
    CharBitMap routine to request memory for the bitmap. It will
    not be called by the other rendering routines.

    NOTE: The call will only be made in the
    case that the lineWidth field of the pBitMap struct is initialized to
    zero by the client before calling CharBitMap.


    nBytes will indicate the number of bytes needed to store the bitmap. 
    pBitMap is the pBitMap parameter to the CharBitMap routine. The
    pBitMap->bMSize and pBitMap->pBase fields must be updated with the size
    and address of the newly allocated memory by the client's implementation
    of this routine.

    The pBitMapMemArg provides a hook for the client.
    If memory can be allocated for the bitmap, the routine should return
    true. If it cannot the routine should return false and CharBitMap
    will return a BE_BITMAPMEMORY error.

    The number of bytes requested is not quaranteed to be the minimum 
    number of bytes needed for the bitmap.  In the case of the 
    T1C Renderer, the number of bytes may be calculated using the FontBBox. 
    Also in the case of the T1C Renderer, nBytes will be rounded up to 
    the nearest 32 bit word boundary.


    The total number of bytes for the bitmap will be calculated by the formula:

      lineWidth = (bitWidth + SCANUNIT - 1) & ~SCANMASK) >> 3;
      nBytes = scanLines * lineWidth

    If nBytes is greater than the bmSize field of the pBitMap parameter
    to CharBitMap then the GetBitMapMemory procedure will be called.

    SCANUNIT is a compile time switch. Scanlines must be an even
    multiple of SCANUNIT bits. The values can be 8, 16, and 32 with
    32 as the default.

    SCANMASK is dependent on the value of SCANUNIT and is set to
    Octal 07, 017, or 037 for SCANUNITS equal to 8, 16, and 32
    respectively.
*/

/* ========== GetRunMemory ==========  */

typedef boolean (*GetRunMemory_t) 
     ARGDECL4(
      Card32  , nBytes,   /* Number of additional bytes needed to store run array */
      RunRec *,	pRunData, /* pRunData parameter to BCCharRuns */
      boolean , copyflg,  /* True => copy contents of old to new */
      void   *, pClientHook 
    );

/*
    The GetRunMemory routine is called during execution
    of the BCCharRuns routine if more memory is needed to store the
    runs for the character. This routine may be called more than
    once during the rendering of a single character.

    nBytes is an estimate of the number of additional bytes needed to 
    store the run array. 

    pRunData is the parameter supplied to the CharRuns procedure. The
    pRunData->datasize and pRunData->run.data fields must be updated with 
    the size and address of the newly allocated memory.

    NOTE: The datasize field of the pRunData parameter to BCCharRuns will
    no longer be updated with the estimate of bytes needed. This will
    be maintained by the client and should indicate the total number of
    bytes available for storing the run array.

    If copyflg is true the client should copy the contents of the existing
    run data to the newly allocated memory. pRunMemArg is a hook for
    client data.

    If the routine fails to allocate memory it should return false. In this
    case BCCharRuns will terminate with the BE_RUNMEMORY error.

*/

/* ========== GetMemory ==========  */
typedef Card8* (* GetMemory_t) 
  ARGDECL2 (
    Card32	 , nBytes, 	/* Number of bytes needed */
    void 	*, pClientHook 
  );

/*
GetMemory is called to allocate a block of nBytes of memory.  This routine
is called during SetUpValues and TTInitBC. The memory returned by GetMemory
must not be moved during the lifetime of FontInst for which it is being 
allocated. The client's only recourse is to destroy and recreate the
FontInst (by calling FreeFontInst and SetUpValues).
*/

/* ========== FreeMemory ==========  */
typedef procedure (* FreeMemory_t) 
  ARGDECL2 (
    Card8	*, data,	  /* Ptr to data returned by GetMemory */
    void 	*, pClientHook 
  );

/*

FreeMemory is called to free the memory allocated by GetMemory. It is called
during the exection of FreeFontInst.

*/

/* ========== ManageCString ==========  */

typedef enum {
      ManageCString_T1SUBROUTINE,
      ManageCString_T1CHARSTRING,
      ManageCString_T1ACCENT,
      ManageCString_TTGET_DATA,
      ManageCString_TTRELEASE_DATA
} ManageCStringIndexType;

typedef CharDataPtr (*ManageCString_t)
  ARGDECL3(
  ManageCStringIndexType , type,
  void                  *, pCharDataDesc,
  void                  *, pClientHook
);


/*
    The ManageCString callback procedure is used to request client
    management of Font Program data. This is font technology dependent
    so pCharDataDesc is of type (void *)  and processed by the client
    as a type appropriate to the font data (PT1CharDataDesc or 
    PTTCharDataDesc).

    The argument, type, defines the nature of the request. If a
    callback gets a request that it cannot process, or fails for
    any other reason it should return NULL. Note that no error
    is detected for ManageCString_TTRELEASE_FONT_DATA. NULL will
    always be returned.

For Type 1 fonts:

    The ManageCString callback procedure is called to get the address
    of the CharString, one of its subroutines, or the address of
    a CharString based on its character code. This routine
    may be called if pCharString is NULL, if pSubrArray is NULL,
    if an offset in pSubrArray is zero, if pAccentArray is NULL, or 
    if an offset in pAccentArray is zero.


    index in the T1CharDataDesc is interpreted according to the value 
    of the argument type. If type == ManageCString_T1SUBROUTINE,
    then the address of the subroutine index should be returned. If
    type == ManageCString_T1CHARSTRING, then the address of the 
    CharString should be returned. If type == ManageCString_T1ACCENT,
    then the address of the CharString represented by index in the
    Adobe StandardEncoding vector or AccentEncoding vector should be
    returned.

    The callback procedure may change any entry in the T1CharDataDesc
    structure during the callback. This means that the callback
    may move any or all subroutines and the charstring or remove
    any entry. The renderer must not depend on data being in the
    same location upon return. The callback must correctly
    update all the information in the T1CharDataDesc structure or pointed
    to by it that was changed by the callback.

    With this mechanism, no more than one CharString is required to
    be in memory at any one time. (Although that CharString could be
    64Kb in length.) It should be assumed that if a callback is
    required for each subroutine call and return that renderer
    performance will suffer greatly.

    This functionality must be provided unless every valid subroutine,
    accent encoding and charstring has a non-NULL pointer (or offset).


For TrueType fonts:

    The ManageCString callback procedure is used to retrieve data
    from the font file or other data source.  The routine must return 
    a pointer to the data.  The buffer that is used to store the data 
    must not be overwritten or moved until it is explicitly released or
    until this character rendering request is completed.

    If the routine is not able to satisfy the request or the requested buffer
    is not in  the font file a NULL pointer must be returned. For example
    if the requested offset + length is greater than the length of the font data,
    a NULL pointer must be returned.

    offset  is the byte offset from the beginning of the font data. If the font is
    stored in a file this is the offset from the beginning of the file.

    length is the number of bytes that must be returned from the font.

    returnDataPtr is a pointer to the data to be released if type is 
    ManageCString_TTRELEASE_FONT_DATA. This pointer is expected to be 
    one of the return values of a previous call to this callback.
    If type is ManageCString_TTGET_FONT_DATA then the procedure return 
    value is also stored in this location.

For all font types:

    pClientHook is a pointer to the client's data. When ManageCString is called 
    the renderer passes the pClientHook argument from the rendering call
    as this parameter.  This field is completely at the client's discretion and
    is not examined by the renderer.

    If the callback is NULL or the callback returns a NULL pointer when asked to
    locate font data then the rendereing procedure will abort with the error 
    BE_CALLBACK_FAILED. For the case ManageCString_TTRELEASE_FONT_DATA, no errors
    are reported. The return value will always be NULL and this should not be 
    treated as an error.

*/


/* ========== BCProcs ==========  */
typedef struct _t_BCProcs 
 {
   DoOtherSubr_t       DoOtherSubr;
   GrowBuff_t          GrowBuff;
   GetBitMapMemory_t   GetBitMapMemory;
   GetRunMemory_t      GetRunMemory; 
   GetMemory_t         GetMemory;	
   FreeMemory_t	       FreeMemory;      
   ManageCString_t     ManageCString;
   Fixed	       unityScaleFactor;/* see BCSetUpValues */
 } BCProcs, *PBCProcs;


/* ======================= PATH CALLBACK PROCEDURES ======================== */ 
/* The following callback procedures are used by the CharOutline rendering
   routine to provide the outline data to the client. The typedef PathProcs
   defines a structure containing pointers to these routines.
 */

typedef procedure (*NewPath_t) 
  ARGDECL1(
  void *, pClientHook
);
typedef procedure (*MoveTo_t) 
  ARGDECL2(
  FCd *, p, 
  void *, pClientHook
);
typedef procedure (*LineTo_t) 
  ARGDECL2(
  FCd *, p, 
  void *, pClientHook
);
typedef procedure (*CurveTo_t) 
  ARGDECL5(
  FCd *, p0, 
  FCd *, p1, 
  FCd *, p2, 
  FCd *, p3,
  void *, pClientHook
);
typedef procedure (*ClosePath_t) 
  ARGDECL1(
  void *, pClientHook
);
typedef procedure (*EndChar_t)
  ARGDECL1(
  void *, pClientHook
);

/* ========== PathProcs ==========  */

typedef struct _t_PathProcs {
  NewPath_t	NewPath;
  MoveTo_t	MoveTo;
  LineTo_t	LineTo;
  CurveTo_t	CurveTo;
  ClosePath_t	ClosePath;
  EndChar_t     EndChar;
} PathProcs, *PPathProcs;


/* ------------------ Exported Procedures ------------------------------ */



/* ========== BCCnctMtx ==========  */
/* Concatenate a Frac Matrix with a Fixed Matrix 

   This is primarily used in concatenating the Font Matrix with the User Mtx
*/
extern procedure BCCnctMtx 
   ARGDECL3(
   register PFracMtx, pFMtx,  /* Font matrix from font Dictionary */
   register PFixMtx, pUMtx,   /* Transformation from user to device space */
   register PFixMtx, pRMtx    /* Result of concatenation */
   );


/* ========== BCTfmP ==========  */
/* Transform a point from character to device space coordinates */

typedef procedure (*_t_BCTfmP)
  ARGDECL3(
   PFontInst,	pFontInst,
   FCd,		c,
   FCd *,	ct
  );

/* ========== SetUpValues ==========  */

typedef IntX (*_t_BCSetUpValues)
  ARGDECL8(
   FontDesc     *, pFontData,      /* Font data  (R) */
   FixMtx	*, pTfmMtx,    	   /* Transform Matrix (R) */
   Fixed	*, pWeightVector,  /* weight vector (R) */
   Fixed	 , xSpotSize, 	   /* X device spot size in pels (R) */
   Fixed	 , ySpotSize,	   /* Y device spot size in pels (R) */
				   /* if either of these values are less than
				    * FIXEDONE, then FONT_WHITE_WRITE
				    * processing will be done. Some
				    * later version of the renderer
				    * may make more sophisticated
				    * use of these values. These
				    * values should be engine
				    * dependent with current 300 dpi
				    * printers typically having values
				    * of sqrt(2) */
   BCProcs 	*, procs,	   /* Callback procedures (W) */ 
   PFontInst    *, ppFontInst,     /* Transformed font data (W) */
   void         *, pClientHook
  );

 /*

  Function:
	Creates a FontInst record that can be passed to the routines 
	for character rendering. The contents of the record are dependent 
	on the font and transformation matrix for showing the character. 
	They are independent of the character being rendered and only need 
	to be recomputed if a different font or different scale is being used.


	pFontData is a pointer to renderer specific font data.

	pTfmMtx is a pointer to the matrix converting from character
	space to device space. It is the concatenation of the FontMatrix,
	Scale and Rotation Matrix, and the User to Device space matrix.

	pWeightVector is a pointer to the weightvector for a multiple 
	master font. This pointer will be ignored if numMasters == 0
        in the FontDesc.

	procs is a pointer to the client's callback procedures. SetUpValues
	will call GetMemory one or more times to allocate memory for 
	the FontInst structure. FreeMemory may be called to release the 
	memory for the FontInst if an error occurrs.

	ppFontInst is pointer to the location to store the pointer to the
	FontInst record. Unless SetUpValues returns BE_NOERR or BE_TOOBIG
	this location will be set to valid pointer otherwise it will be
	set to NULL.

 	If the error BE_FIXEDOVFL is returned then the current matrix
 	could cause device space coordinates to overflow. None of the
	character rendering routines will succeed with this matrix.
	unityScaleFactor will be set to a best estimate scale factor
        that should be used to render this character. The matrix should 
        be set using this information and SetUpValues should be called 
	again. Then CharOutline should be used to get the outline of the
	character. And scaling can then be done on the coordinates that
	come back using real arithmetic. 

  Return Values:
	BE_NOERR	routine completed sucessfully
	BE_UNDEF	Matrix inversion undefined 
        BE_CANTHAPPEN   An internal assert condition failed.
        BE_TOOBIG	The character is too large to be rendered by 
			CharBitMap or CharRuns. CharOutline can be used.
	BE_FIXEDOVFL	The matrix could cause Fixed point overflow.
			No rendering routine can be used. 
	BE_CALLBACK_FAILED  Callback procedure returned false. 
	BE_INVLMTX	Invalid matrix (tx and ty are greater than 0.5)

 */	

/* ========== BCFreeFontInst ==========  */
typedef IntX (*_t_BCFreeFontInst) 
  ARGDECL3(
   PFontInst , inst,
   PBCProcs  , procs,
   void     *, pClientHook
  );
/*
  Return Values:
        BE_NOERR        routine completed sucessfully
	BE_INVLFONT	
        BE_BUSY		rendering still in progress on this inst
*/

/* ========== SetWeightVector ==========  */

/* SetWeightVector  Initializes the weightVector for a blended multi-master
   font. This call allows the weightVector in a fontInstance to be changed
   without doing all the work involved in SetUpValues. It initializes just
   the weightVector and does not blend the fontwide values. This procedure is
   used by the implementation of the setweightvector operator that is in
   internaldict.
   Note that this procedure marks the fontInst as changed to notify the 
   Type1 Chip that it must read the fontInst.
*/
typedef IntX (*_t_BCSetWeightVector)
  ARGDECL3(
   Fixed	*, pWeightVector,  /* weight vector (R) */
   unsigned      , len,            /* Length of weight vector (R) */
   PFontInst     , pFontInst       /* Transformed font data (W) */
  );
/*
  Return Values:
        BE_NOERR        routine completed successfully
	BE_INVLFONT
        BE_BUSY         rendering still in progress on this inst
*/


/* ========== GetCStringMetrics ==========  */

typedef IntX (*_t_BCGetCStringMetrics)
 ARGDECL5(
  PFontInst     , pFontInst,       /* Record from SetupValues (R) */
  BCProcs      *, pCallbackProc,   /* Pntrs to call back procedures (R) */
  void         *, pCharDataDesc,   /* Pntr to input data structure (R) */
  CharIO       *, pCharIO,         /* Pntr to i/o data structure (RW) */
  void         *, pClientHook
 );


/*
  Function
	Return the the width and sidebearing from of the character found in
        the CharString data. The results are provided in character
	space  and device space units. This routine waits for completion
        of the request. There is no asynchronous version of this function.

  Return Value:
	BE_BUSY		routine started successfully
	BE_INVLFONT
        BE_CALLBACK_FAILED One of the callback procedures returned false
                        or was not defined when it was needed.
	BE_INVLFONT 	Invalid data in the font
        BE_CANTHAPPEN   An internal assert condition failed.
        BE_ALREADYBUSY  There is an unfinished request outstanding.

*/

/* ========== CharBitMap ==========  */

typedef IntX (*_t_BCCharBitMap)
 ARGDECL7(
  PFontInst     , pFontInst,	   /* Record from SetupValues (R) */
  BCProcs      *, pCallbackProc,   /* Pntrs to call back procedures (R) */
  void         *, pCharDataDesc,   /* Pntr to input data structure (R) */
  CharIO       *, pCharIO,         /* Pntr to i/o data structure (RW) */
  DevBBoxRec   *, pClipBBox,	   /* if not NULL, rectangle to clip to (R) */
  BitMapRec    *, pBitMap, 	   /* BitMap data for the character (RW) */
  void         *, pClientHook
 );


/*

  Function
	Creates the bitmap for the character specified by the charstring.
	The bitmap can be returned as a bitmap mask or written directly into
	frame memory depending on the values of the pBitMap record.

	PFontInst     	pFontInst	Record from BCSetupValues (RW)

	This record is initialized by SetUpValues.  It contains the font
	data that is specific to the scale of the font and current 
	transformation matrix. It also contains all other fontdata for
	rendering the character. This same record can be used for all 
	characters from this font displayed at the same scale and 
	transformation matrix.


	BCProcs	     	*pProcs	(R)

	This parameter is a pointer to a record containing the callback
	procedures and pointers to client data. The callback procedures are
	used to request information and or services from the client.
	The callback procedures are described above under the typedef
	for each of the call backs in the BCProcs Struct.

	NOTE: The GetRunMemory callback is not used by this routine.

  	DevBBoxRec   	*pClipBBox (R)	

	This parameter defines a clipping rectangle in device coordinates.
	If the pointer is NULL then no clipping will be performed.


  Output Parameters: 
	CharSBW	     *pCharInfo;	Character Data (RW)

	This record contains read/write fields for the left side bearing
	vector and the character width vector. Normally these fields will
	be written with the default width and sidebearing of the character.
	However if the appropriate bits are set in the overrideFlags parameter
	the default sidebearing and/or width will be overridden with
	values in width and sideBearing. In the case where the sidebearing
	and width are to be overridden, the vectors should be initialized
	with character space units.

	In either case, the output values for the sidebearing and
	width will be in both character space and device space units.


	FCdBBox     *pCharBBox;	Character Bounding Box; (W)

	This returns the bounding box of the character relative to the 
	Character's origin.

	BitMapRec    *pBitMap; 		BitMap data for the character (RW)

	The BitMapRec specifies where in memory the bitMap data should
	be stored. The following figure shows how the fields of the 
	record are used.

				(bitWidth + xStart, scanLines + yStart)
			------------------------+
			|			|
			|			|
			|			|  Clipping Rectangle
			|			|
			|			|
			|			|
			|			|
			| + (xOffset, yOffset)  |
			|    Char origin	|
			+------------------------
 	           (xStart, yStart)

             + (0,1) pBase + lineWidth 
             + (0,0) pBase           


	pBase is the base address of the memory used for the bitmap.
	NOTE: This address must be long word aligned (This is a requirement
	of the Type 1 Chip).
        This defines the device space origin for the bitmap. lineWidth
	is the length of one scanline in the frame in bytes. xStart
	and yStart give the offset from the origin to the lower left
	corner of the clipping region. Only values greater than or equal
	to 0 are allowed for xStart or yStart. The upper right corner of the
	clipping rectangle is given by (bitWidth + XStart,scanLines + yStart).
	The character origin is placed at xOffset, yOffset relative
	to the base address.

	Depending on the initial values of these fields, this record
	can be used to write bit maps directly to a frame buffer or to
	a contiguous block of memory appropriate for a bitmap cache. 

	For creating a bitmap for a cache lineWidth should be set to 0.
	In this case the bitmap will be written starting at the base memory.
        bmSize will give the amount of contiguous memory available
	for the bitmap.  xStart, yStart will be ignored (i.e. set to 0)
	The initial values of bitWidth, scanLines, xOffset, yOffset 
	will also be ignored. These values will be set according to the
	actual bitmap that is generated. Additionally lineWidth will be
	set to the number of bytes per scanline. writeMode will be 
	ignored in this case. The bitmap will overwrite any existing
	data in the memory block. If there is not enough memory for the 
	bitmap the error BE_BITMAPMEMORY will be returned. 
	NOTE: if the same bitMap record is used repeatedly as scratch pad
	for the bitmaps, lineWidth should be reset to 0 before each call to 
	this routine.

	When using this routine to create bitMaps for cacheing, a scratch
	buffer for bitmaps should be allocated. This buffer should be large
	enough for the bitmaps for most characters. In the software 
	implementation, the CharBBox callback procedure is called before
	creating the bitmap. More memory can be allocated when this routine
	is called.

	Type 1 Chip Implementations:
	In products that use the Type 1 chip, the amount of memory for
	the BitMap scratch buffer should be the same as the amount of 
	back channel memory the chip uses for its tile.

	If the bitmap is  being written directly to the frame buffer, 
        lineWidth should be set to the number of bytes in one scanline.
	The clipping rectangle should be specified by setting 
	xStart, yStart, bitWidth, and scanLines.  Also the position of
	the character origin needs to be set relative to the base 
	address. If the character is clipped, BE_CLIPPED will
	be returned.

  Return Values:
	BE_BUSY		routine started rasterizer execution successfully
	BE_INVLFONT 	Invalid data in the font
        BE_CANTHAPPEN   An internal assert condition failed.
	BE_MEMORY	The GrowBuff callback procedure failed to get
			enough memory to render the character.
	BE_BITMAPMEMORY The GetBitMapMemory callback failed to get
			enough memory for the character bitmap. 
	BE_CLIPPED	Character clipped in tile specified by the BitMapRec.
        BE_TOOBIG	The character is too large to be rendered by this
			routine
	BE_CALLBACK_FAILED One of the callback procedures returned false
			or was not defined when it was needed.
	BE_ALREADYBUSY  The rasteriser is not finished processing a previous
			request using this fontInst

*/

/* ========== CharRuns ==========  */

typedef IntX (*_t_BCCharRuns)
  ARGDECL7(
  PFontInst     , pFontInst,       /* Record from SetupValues (R) */
  BCProcs      *, pCallbackProc,   /* Pntrs to call back procedures (R) */
  void         *, pCharDataDesc,   /* Pntr to input data structure (R) */
  CharIO       *, pCharIO,         /* Pntr to i/o data structure (RW) */
  DevBBoxRec   *, pClipBBox,       /* if not NULL, rectangle to clip to (R) */
  RunRec       *, pRunData, 	   /* Run data for the character (W) */
  void         *, pClientHook
  );

/*
  Function
	Creates the runs for the character described in the character record.

	The parameters are the same as decribed for CharBitMap
	with the exception of RunRec.

	RunRec 	     *pRunData; 	Run data for the character

	The data for the character is returned in the buffer pointed to 
	by the data field in RunRec.  The datalen field contains the
	number of elements in the run array.  The run data is grouped
	by scanlines. The data for one scaline consists of a pair count
	followed by that number of pairs of data. The pairs give the
	starting and ending x pixel value to paint. The bounds of the
	run array are given in the pCharBBox.

	If there is not enough memory to store the run array, the routine
	will return the BE_RUNMEMORY error.  The dataSize field of the
	RunRec will contain the number of elements needed to store the
	run data.  This amount of memory should be allocated and
	BCCharRuns should be called again to render the character.


  Return Values:
	BE_BUSY 	routine started rasterization successfully
	BE_INVLFONT 	Invalid data in the font
        BE_CANTHAPPEN   An internal assert condition failed.
	BE_MEMORY	The GrowBuff callback procedure failed to get
			enough memory to render the character.
	BE_RUNMEMORY    The GetRunMemory callback failed to get
			enough memory for the run array. 
	BE_CLIPPED	Character clipped in tile specified by the BitMapRec.
        BE_TOOBIG	The character is too large to be rendered by this
			routine
	BE_CALLBACK_FAILED One of the callback procedures returned false
			or was not defined when it was needed.
	BE_ALREADYBUSY  There is an outstanding unfinished request on this fontInst
*/

/* ========== CharOutline ==========  */

typedef IntX (*_t_BCCharOutline)
 ARGDECL7(
  PFontInst     , pFontInst,       /* Record from SetupValues (RW) */
  BCProcs      *, pCallbackProc,   /* Pntrs to call back procedures (R) */
  void         *, pCharDataDesc,   /* Pntr to input data structure (R) */
  CharIO       *, pCharIO,         /* Pntr to i/o data structure (RW) */
  PathProcs    *, pPathProcs,      /* Pntrs to path call back procudures */
  boolean       , hinted,          /* True => outline will be hinted. */
  void         *, pClientHook
);



/*
  Function
	Parses the charstring and calls the path callback procedures describing
	the character outline. The coordinates returned by the outline
	are in device space in fixed format.

	The parameters are the same as described for BCCharMap with the
	exception of the pointer to the PathProcs record.

	PathProcs *pPathProcs

	The PathProcs record contains pointers to the path call backs 
	described below.  The path callbacks are called to create the 
	outline for the character.

  	procedure    (*NewPath)(void *pClientHook);

	NewPath is a pointer to a callback procedure. The procedure is called
	before any of the other path callback procedures are called.  It is
	also called if the path is reset. In this case the data from all
	previous callbacks should be discarded and any variables needed by
	the callback procedures should be reinitialized. 

  	procedure    (*MoveTo)(FCd *pc, void *pClientHook);

	MoveTo is a pointer to a callback procedure. The 
	currentpoint should be set to the coordinates of pc.

  	procedure    (*LineTo)(FCd *pc, void *pClientHook);

	LineTo is a pointer to a callback procedure. It indicates the
	character outline has a line from the current point to pc.

   	procedure    (*CurveTo)(FCd *pc0, FCd *pc1, FCd *pc2, FCd *pc3, 
				void *pClientHook);

	CurveTo is a pointer to callback procedure. It indicates that
	the outline contains a curve from the current point to pc3 with
	pc1 and pc2 as control points fo Bezier curves.

   	procedure    (*ClosePath)(void *pClientHook);

	ClosePath is a pointer to a callback procedure. It indicates 
	that the current subpath in the character outline is finished.
	And that the outline is completed by drawing a straight line
	from the current point to the start point of the subpath.

	boolean	     hinted;		

	The paramter hinted determines if the outline should be hinted
	or unhinted.	


  Return Values:
	BE_BUSY 	routine started rasterization successfully
	BE_INVLFONT 	Invalid data in the font
        BE_CANTHAPPEN   An internal assert condition failed.
	BE_MEMORY	Not enough memory in pMemoryBuf to render character
        BE_TOOBIG	The character is too large to be rendered by this 
		        routine
	BE_ALREADYBUSY  The rasterizer is processing an uncompleted request on
			this fontInst
*/

/* ========== PollMetricsDone WaitMetricsDone ========  */

typedef IntX (*_t_BCPollMetricsDone)
 ARGDECL4(
  PFontInst     , pFontInst,       /* Record from SetupValues (RW) */
  BCProcs      *, pCallbackProc,   /* Pntrs to call back procedures (R) */
  PathProcs    *, pPathProcs,      /* Pntrs to path call back procudures */
  void         *, pClientHook
);

typedef IntX (*_t_BCWaitMetricsDone)
 ARGDECL4(
  PFontInst     , pFontInst,       /* Record from SetupValues (RW) */
  BCProcs      *, pCallbackProc,   /* Pntrs to call back procedures (R) */
  PathProcs    *, pPathProcs,      /* Pntrs to path call back procudures */
  void         *, pClientHook
);

/*

  Function:
        Poll or Wait until the rasterization process has finished determining
        the character metrics information.

        This function may call any of the callback procedures. It may execute
        host processor code for a significant time if there is work to be done
        by the host to obtain metrics information. It will not return until
	the metrics information is available or an error is detected.

  Return Values:
	BE_BUSY         data is not yet available.(returned only by Poll)
        BE_METRICSDONE  The metrics data is available, rendering is still
                        in progress. this was not a metrics only request.
	BE_NOERR	The metrics data is available, rendering has finished.
			Either this was a metrics only request or the 
			bitmap/runs/outlines are also completed. Subsequent
			Poll/Wait(Metrics/Rendering)Done will return
			BE_NOREQUEST because the current request is now
			considered complete.
        BE_NOREQUEST    There is no outstanding unfinished request on this 
			fontInst

	See Rendering function for additional errors.
*/

/* ========== PollRenderingDone WaitRenderingDone ========  */

typedef IntX (*_t_BCPollRenderingDone)
 ARGDECL4(
  PFontInst     , pFontInst,       /* Record from SetupValues (RW) */
  BCProcs      *, pCallbackProc,   /* Pntrs to call back procedures (R) */
  PathProcs    *, pPathProcs,      /* Pntrs to path call back procudures */
  void         *, pClientHook
);

typedef IntX (*_t_BCWaitRenderingDone)
 ARGDECL4(
  PFontInst     , pFontInst,       /* Record from SetupValues (RW) */
  BCProcs      *, pCallbackProc,   /* Pntrs to call back procedures (R) */
  PathProcs    *, pPathProcs,      /* Pntrs to path call back procudures */
  void         *, pClientHook
);

/*

  Function:
        Poll or Wait until the rasterization process has finished.

        This function may call any of the callback procedures. It may execute
        host processor code for a significant time if there is work to be done
        by the host to process the rasterization request. It will not return 
        until the rasterization process is finished or an error is detected.

  Return Values:
	BE_BUSY		data is not yet available. (only Poll)
        BE_NOERR        Rasterization request is complete, all data is available
        BE_NOREQUEST    There is no outstanding unfinished request on this fontInst

	See Rendering function for additional errors.
*/

/* ========== AbortRendering ========  */

typedef IntX (*_t_BCAbortRendering)
 ARGDECL4(
  PFontInst     , pFontInst,       /* Record from SetupValues (RW) */
  BCProcs      *, pCallbackProc,   /* Pntrs to call back procedures (R) */
  PathProcs    *, pPathProcs,      /* Pntrs to path call back procudures */
  void         *, pClientHook
);

/*

  Function:
        Stop the current rendering request as quickly as possible, clean
        up and release resources as appropriate.

        This function may call any of the callback procedures. It may execute
        host processor code for a significant time if there is work that must
	be done by the host to terminate the rendering request. It will not 
	return until the rendering request has been stopped or an 
	unrecoverable error is detected. This call should not be exercised in 
	the normal processing path. It is possible that this procedure may take
	some time to execute.

  Return Values:
        BE_NOERR        Rendering request has been successfully terminated.
	BE_NOREQUEST    There is no outstanding unfinished request on this 
			fontInst
	BE_BUSY		The rendering request could not be terminated.
			This probably indicates some hardware error. The
			client should probably do whatever CANTHAPPEN means
			in its environment because new rendering requests
			will almost certainly fail.
*/

/* ========== MemoryBufSize ==========  */

typedef procedure (*_t_BCMemoryBufSize) 
  ARGDECL5(Card32 *, pSizeB1, 
   	   Card32 *, pSizeB2, 
	   Card32 *, pSizeB3, 
	   Card32 *, pSizeB4, 
	   Card32 *, pSizeB5);
/*  
    This routine should be called after renderer specific initialization 
    to get the recommended size of the memory buffers used by the renderer.
    The values returned will probably be different depending on the 
    specific renderer used.
*/

/* ========== Terminate ==========  */

typedef IntX (*_t_BCTerminate) 
  ARGDECL2(
   PBCProcs  , procs,
   void     *, pClientHook
  );

/* 
    This routine is called to terminate the use of the renderer that
    returned these BCProcs. Any memory allocated during this renderer's
    initialization routine will be deallocated at this time using the 
    client's FreeMemory routine. Before using this renderer again the 
    renderer specific xxxInitBC must be called.
*/

/* ========== BCRenderProcs ==========  */
/*  
   The following struct is used to store pointer's to the renderering routines
   described above. 

    The xxxInitBC routines initialize the fields of the PBCRenderProcs
    structure passed as a parameter. The client then access the
    Character Rendering calls using the pointers to the procedures
    contained in the struct.

    The renderer specific initialization routines other than ATM are
    not defined in this file, but rather are defined in their unique
    xxxxx.h files.

    There are renderer specific routines for each renderer. The current
    mechanism for determining which renderer code is part of a particular
    system is controlled in product code by calling the appropriate
    initialization routines.

    This mechanism is imperfect and there are some dependencies that may
    not be obvious. The most complex conditions occur when there is a
    requirement for more than one renderer, especially more than one 
    Type 1 renderer (ATMInitBC, T1CInitBC, OEMInitBC...) since it may
    be desirable to use one renderer for WriteBlack (ATM) and another
    for WriteWhite (OEM) and both requirements could occur with a 
    WriteWhite engine coupled with FAX capability.
*/

typedef struct _t_BCRenderProcs {
  _t_BCSetUpValues       SetUpValues;
  _t_BCFreeFontInst	 FreeFontInst;
  _t_BCCharRuns          CharRuns;    
  _t_BCCharBitMap        CharBitMap;   
  _t_BCCharOutline       CharOutline;
  _t_BCGetCStringMetrics GetCStringMetrics;   
  _t_BCMemoryBufSize     MemoryBufSize;
  _t_BCSetWeightVector   SetWeightVector;
  _t_BCTfmP		 TfmP;
  _t_BCTerminate	 Terminate;
  _t_BCPollMetricsDone	 PollMetricsDone;
  _t_BCWaitMetricsDone	 WaitMetricsDone;
  _t_BCPollRenderingDone PollRenderingDone;
  _t_BCWaitRenderingDone WaitRenderingDone;
  _t_BCAbortRendering	 AbortRendering;

  CardX                  rendererVersion; /* Version of renderer */
} BCRenderProcs, *PBCRenderProcs;

/* ========== ATMInitBC ==========  */

extern IntX ATMInitBC ARGDECL1(PBCRenderProcs, rprocs);
/*
    Based on the renderer to be used (ATM or ATMsi), the
    appropriate initialization routine must be called.  ATMInitBC()
    is the initialization routine for the ATM software renderer.
    If using the type 1 chip (ATMsi), the initialization routine
    would be T1CInitBC().  This routine is defined in t1chip.h

    These routines should be called during system initialization and should not 
    be called each time a font is accesssed.

*/

PUBLIC procedure BlendHintData ARGDECL3(FontDesc *, pFontData,
                Fixed *, pWeightVector, register FontValues *, pHintBlock);


/* Inline Procedures */

/* ========== BotZone and SetBotZone ==========  */

#define BotZone(zoneBits, bit) (boolean)(((zoneBits) & (1L << bit)) != 0)
#define SetBotZone(zoneBits, bit) zoneBits |= (1L << bit)

/* Exported Data */


/* ========== Error return codes ==========  */

#define BE_NOERR		0	/* Normal return */
#define BE_INVLFONT		(-1)	/* Font not consistent */
#define BE_CANTHAPPEN		(-2)	/* "Assert" failed */
#define BE_UNDEF		(-3)	/* Matrix inversion undefined */
#define BE_MEMORY		(-4)	/* Ran out of memory */
#define BE_RUNMEMORY            (-5)    /* Ran out of memory for runs */
#define BE_BITMAPMEMORY         (-6)    /* Ran out of memory for bitmap */
#define BE_CLIPPED              (-7)    /* Character was clipped */
#define BE_INVLCHARSTRING       (-8)    /* Character string invalid */
#define BE_TOOBIG		(-9)	/* Character cannot be rendered */
#define BE_FIXEDOVFL		(-10)   /* Fixed point overflow */
#define BE_CALLBACK_FAILED	(-11)   /* Callback procedure returned false */
#define BE_INVLMTX		(-12)   /* Invalid matrix */
#define BE_BUSY			(-13)	/* Rastrizer started but not finished */
#define BE_NOREQUEST		(-14)	/* no current request for the rasterizer
					   in progress on this fontInst */
#define BE_ALREADYBUSY		(-15)	/* rasterizer is currently processing 
					   a request on this fontInst, more than
					   one concurrent request per fontInst
					   is not supported */
#define BE_METRICSDONE		(-16)	/* Character metrics data is available*/
#endif	/* BUILDCH_H */

