/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: RESOURCE.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for resource handling     */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_UTILSSEG)


#ifndef RELEASE
/*****************************************************************************
*
* FUNCTION: LoadDrvrString
*
* DESCRIPTION: A LoadString shell.
*
* PSUEDO CODE
* -----------
*
* PARAMETERS        TYPE          PURPOSE
* ----------        ----          -------
* hInstance         HANDLE        Instance of module whose file contains resource string
* wId               WORD          Integer identifier of the string to be loaded
* lpBuffer          LPSTR         Points to the buffer that recieves the string.
* nBufferMax        int           the max number of chars that may be loaded into lpBuffer
*
* RETURNS           MEANING
* -------           -------
* NON-ZERO          String  Loaded and return value is the number of chars copied.
* ZERO              Error loading the string.
*
*****************************************************************************/
int FAR PASCAL LoadDrvrString( HANDLE hInstance, WORD wId, LPSTR lpBuffer, int nBufferMax )
{
   int       iCharsCopied;

   iCharsCopied = LoadString( hInstance, wId, lpBuffer, nBufferMax );

   if( iCharsCopied == 0 )
   {
      // let special DSC get by this message
      if (wId != DSC_platecolor && wId != DSC_documentprocesscolors &&
          wId != DSC_documentprocesscolorsatend)
        MessageBox( NULL, "LoadString Returned 0", "LoadDrvrString Error", MB_ICONEXCLAMATION | MB_OK );

   }

   return( iCharsCopied );
} /* LoadDrvrString */
#endif

/*****************************************************************************/
/*                 DrvrStringMessageBox                                      */
/* Purpose:                                                                  */
/*   Puts up message box by string ID.                                       */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND parent -- Handle to parent window                                  */
/*   int TextID -- String ID for text to be displayed                        */
/*   int CaptionID -- String ID for caption text                             */
/*   WORD Type -- Message box type flags                                     */
/*                                                                           */
/* Returns: int                                                              */
/*   return value from MessageBox call                                       */
/*****************************************************************************/

int FAR PASCAL DrvrStringMessageBox( HWND parent, int TextID, int CaptionID, WORD Type)
{
  char caption[80];
  char text[300];
  LPSTR lpCaption;

  if (CaptionID != NULL)
    {
    LoadString(ghDriverMod, CaptionID, caption, sizeof(caption));
    lpCaption = caption;
    }
  else
    lpCaption = NULL;

  LoadString(ghDriverMod, TextID, text, sizeof(text));
  return MessageBox(parent, text, lpCaption, Type);
}

/*****************************************************************************
*
* FUNCTION: ReturnDrvrString
*
* DESCRIPTION: Same as LoadString except we return a pointer to a string.
*
*
* PARAMETERS        TYPE          PURPOSE
* ----------        ----          -------
* hInstance         HANDLE        Instance of module whose file contains resource string
* wId               WORD          Integer identifier of the string to be loaded
* lpBuffer          LPSTR         Points to the buffer that recieves the string.
* nBufferMax        int           the max number of chars that may be loaded into lpBuffer
*
* RETURNS           MEANING
* -------           -------
* NON-ZERO          pointer to string.
* NULL              Error loading the string.
*
*****************************************************************************/
LPSTR FAR PASCAL ReturnDrvrString( HANDLE hInstance, WORD wId, LPSTR lpBuffer, int nBufferMax )
{
   int       iCharsCopied;

   iCharsCopied = LoadString( hInstance, wId, lpBuffer, nBufferMax );
   if( iCharsCopied == 0 )
   {
#ifndef RELEASE
/*
 * don't compile this code if we are releasing
 */
      MessageBox( NULL, "LoadString Returned 0", "LoadString Error", MB_ICONEXCLAMATION | MB_OK );

#endif
   }

   return( (iCharsCopied == 0) ? NULL : lpBuffer );
} /* ReturnDrvrString */


/***************************************************************************
*                    LoadFontResource
*  function:
*
*  prototype:
*       LPBYTE FAR PASCAL LoadFontResource(int nFontID, HGLOBAL* phgblRcData)
*  parameters:
*       HGLOBAL* phgblRcData - pointer to a HGLOBAL object
*  returns:
*       LPBYTE
*
***************************************************************************/

LPBYTE FAR PASCAL LoadFontResource(int nFontID, HGLOBAL* phgblRcData)
{
   HRSRC hresRcData;
   LPBYTE   lpbyRcData;

   lpbyRcData = NULL;

   hresRcData = FindResource(ghDriverMod, MAKEINTRESOURCE(nFontID), RT_RCDATA);

   if (hresRcData != NULL)
   {
      *phgblRcData = LoadResource(ghDriverMod, hresRcData);

      if (*phgblRcData != NULL)
      {
         lpbyRcData = (LPBYTE)LockResource(*phgblRcData);

         if (lpbyRcData == NULL)
         {
            FreeResource(*phgblRcData);
         }
      }
   }

   return lpbyRcData;
}

/***************************************************************************
*                    UnloadFontResource
*  function:
*
*  prototype:
*       VOID FAR PASCAL UnoadFontResource(HGLOBAL hgblRcData)
*  parameters:
*       HGLOBAL hgblRcData - Handle to RC_DATA object
*  returns:
*       none
*
***************************************************************************/

VOID FAR PASCAL UnloadFontResource(HGLOBAL hgblRcData)
{
   UnlockResource(hgblRcData);
   FreeResource(hgblRcData);
}

/***************************************************************************
*                    LoadFontList
*  function:
*
*  prototype:
*  BOOL FAR PASCAL LoadFontList(int nIdFontRcData, LPSTR** pplpStrPtr)
*
*  parameters:
*  int      nIdFontRcData
*  LPSTR**  pplpStrPtr
*
*  returns:
*  BOOL  TRUE  : successful
*        FALSE : failed to load the specified RCDATA resource or
*                 allocate global memory
*
***************************************************************************/

BOOL FAR PASCAL LoadFontList(int nIdFontRcData, LPSTR** pplpStrPtr)
{
   BOOL  bResult;
   int      nNumFont;
   HGLOBAL  hgblRcData;
   LPBYTE   lpbyRcData;
   LPBYTE   lpby;

   *pplpStrPtr = NULL;

   bResult = FALSE;

   // First, load specified resource into memory.

   lpbyRcData = LoadFontResource(nIdFontRcData, &hgblRcData);

   if (lpbyRcData == NULL)
   {
      return FALSE;
   }

   // Count the number of the font names and get the total size of
   // the names (including null terminators).

   nNumFont = 0;

   lpby = lpbyRcData;

   while (*lpby != RCDATA_TERMINATOR)
   {
      lpby += lstrlen(lpby) + 1;

      nNumFont++;
   }

   if (nNumFont > 0)
   {
      WORD  wTotalFontSize;
      WORD  wIndexTableSize;
      DWORD dwAllocSize;
      LPVOID   lpvGlobalMemory;

      wTotalFontSize = lpby - lpbyRcData;

      wIndexTableSize = sizeof (LPSTR) * (nNumFont + 1);

      // Allocate one block of memory that is large enough to
      // contain the pointers to the fonts and the fonts
      // themselves.

      dwAllocSize = wIndexTableSize + wTotalFontSize;

      // Allocate a required size of memory. Do not forget to specify
      // GMEM_SHARE, or the memory will be discared when the first
      // application that loads the driver exits.

      lpvGlobalMemory = GlobalAllocPtr(GHND | GMEM_SHARE, dwAllocSize);

      if (lpvGlobalMemory != NULL)
      {
         LPSTR*   lpIndexTable;
         LPSTR lpFontName;

         lpIndexTable = (LPSTR*)lpvGlobalMemory;

         lpFontName = (LPSTR)((LPBYTE)lpvGlobalMemory + wIndexTableSize);

         lpby = lpbyRcData;

         while (*lpby != RCDATA_TERMINATOR)
         {
            int nSize;

            *lpIndexTable++ = lstrcpy(lpFontName, lpby);

            nSize = lstrlen(lpFontName) + 1;

            lpFontName += nSize;
            lpby += nSize;
         }

         *lpIndexTable = NULL;

         // Finally, we associate the global memory to the pointer to
         // a string table.

         *pplpStrPtr = (LPSTR*)lpvGlobalMemory;

         bResult = TRUE;
      }
   }
   else
   {
      // There is no font listed. We can live with that.

      bResult = TRUE;
   }

   UnloadFontResource(hgblRcData);

   return bResult;
}

/***************************************************************************
*                    LoadAliasTable
* function:
*                 Group Index Table
*  AliasTable -> |---------------|    Font Index Table     Alias Font Names
*                 | Ptr to Group0 | -> |---------------|
*                 |---------------|    | Ptr to Font01 | -> 'Tms_Rmn\0'
*                 | Ptr to Group1 |    |---------------| -> 'Times_Roman\0'
*                 |---------------|    | Ptr to Font02 | -> 'TimesRoman\0'
*                 //             //    |---------------|
*                 |---------------|    //             //
*                 | Ptr to GroupN |    |---------------|
*                 |---------------|    | Ptr to Font0N | -> 'TimesNewRomanPS\0'
*                 |     NULL      |    |---------------|
*                 |---------------|    |     NULL      |
*                                      |---------------|
*
* prototype:
*  BOOL FAR PASCAL LoadAliasTable(VOID)
*
* parameters:
*  None
*
* returns:
*  BOOL  TRUE  : successful
*        FALSE : loading of RCDATA resource or memory allocation failed
*
***************************************************************************/

BOOL FAR PASCAL LoadAliasTable(VOID)
{
   BOOL  bResult;
   HGLOBAL  hgblRcData;
   LPBYTE   lpbyRcData;
   LPBYTE   lpby;
   LPBYTE   lpbyHead;
   int      nGroup;
   int      nFontName;
   WORD  wTotalNameSize;
   DWORD dwAllocSize;

   FreeAliasTable();

   // First, load ID_FNT_ALIAS resource into memory.

   lpbyRcData = LoadFontResource(ID_FNT_ALIAS, &hgblRcData);

   if (lpbyRcData == NULL)
   {
      return FALSE;
   }

   // Count the number of the groups, the number of the font names,
   // and the total size of the font name strings (including null
   // terminator).

   bResult = FALSE;

   nGroup = 0;
   nFontName = 0;
   wTotalNameSize = 0;

   lpby = lpbyHead = lpbyRcData;

   while (*lpby != RCDATA_TERMINATOR)
   {
      lpby += lstrlen(lpby) + 1;

      // End of a font name string

      wTotalNameSize += lpby - lpbyHead;
      nFontName++;

      if (*lpby == ALIAS_GROUP_TERMINATOR)
      {
         // End of a group

         nGroup++;
         lpby++;
      }

      lpbyHead = lpby;
   }

   if (nGroup > 0)
   {
      DWORD dwGroupIndexTableSize;
      DWORD dwFontIndexTableSize;
      LPVOID   lpvGlobalMemory;

      // Allocate a block of memory which is large enough to
      // contain the Group table, each GroupN tables, and all of
      // the alias font name strings in it.

      dwGroupIndexTableSize = sizeof (LPSTR*) * (nGroup + 1);

      dwFontIndexTableSize = sizeof (LPSTR) * (nFontName + nGroup);

      dwAllocSize =
         dwGroupIndexTableSize + dwFontIndexTableSize + wTotalNameSize;

      lpvGlobalMemory = GlobalAllocPtr(GHND | GMEM_SHARE, dwAllocSize);

      if (lpvGlobalMemory != NULL)
      {
         // Create AliasTable having structure described above
         // into the one block of memory.

         LPSTR**  lpppGroupIndexTable;
         LPSTR*   lppFontIndexTable;
         LPSTR lpFontName;

         lpppGroupIndexTable = (LPSTR**)lpvGlobalMemory;

         lppFontIndexTable =
            (LPSTR*)((LPBYTE)lpvGlobalMemory + dwGroupIndexTableSize);

         lpFontName =
            (LPSTR)((LPBYTE)lpvGlobalMemory +
                     dwGroupIndexTableSize + dwFontIndexTableSize);

         *lpppGroupIndexTable++ = lppFontIndexTable;

         lpby = lpbyRcData;

         while (*lpby != RCDATA_TERMINATOR)
         {
            int nSize;

            *lppFontIndexTable++ = lstrcpy(lpFontName, lpby);

            nSize = lstrlen(lpFontName) + 1;

            lpFontName += nSize;
            lpby += nSize;

            // lpby points next char of the end of a string.

            if (*lpby == ALIAS_GROUP_TERMINATOR)
            {
               // End of a group

               *lppFontIndexTable++ = NULL;
               *lpppGroupIndexTable++ = lppFontIndexTable;
               lpby++;
            }
         }

         *(lpppGroupIndexTable - 1) = NULL;

         // Finally, associate the pointer to the global memory to
         // AliasTable.

         AliasTable = (LPSTR**)lpvGlobalMemory;

         bResult = TRUE;
      }
   }
   else
   {
      // No group found but we can go.

      bResult = TRUE;
   }

   UnloadFontResource(hgblRcData);

   return bResult;
}

/***************************************************************************
*                    FreeAliasTable
*  function:
*
*  prototype:
*       VOID FAR PASCAL FreeAliasTable(VOID)
*  parameters:
*       None
*  returns:
*       None
*
***************************************************************************/

VOID FAR PASCAL FreeAliasTable(VOID)
{
   if (AliasTable != NULL)
   {
      GlobalFreePtr(AliasTable);
      AliasTable = NULL;
   }
}

/***************************************************************************
*                    LoadDefSubsFont
*  function:
*
*  prototype:
*       PSERROR FAR PASCAL LoadDefSubsFont(LPSTR lpSubsFontTable,
                                 int nFontNameSize)
*  parameters:
*       LPSTR lpSubsFontTable
*  returns:
*     PS_GENERIC_FAIL
*
***************************************************************************/

PSERROR FAR PASCAL LoadDefSubsFont(LPSTR lpSubsFontTable, int nFontNameSize)
{
   HGLOBAL  hgblRcData;
   LPBYTE   lpbyRcData;
   LPBYTE   lpby;
   int      nNumDefSubsFont;

   // First, get the number of the default substitution fonts.

   nNumDefSubsFont = GetNumDefSubsFont();

   if (nNumDefSubsFont < 0)
   {
      return PS_GENERIC_FAIL;
   }

   // Load ID_FNT_DEF_SUBS_FONT resource into memory.

   lpbyRcData = LoadFontResource(ID_FNT_DEF_SUBS_FONT, &hgblRcData);

   if (lpbyRcData == NULL)
   {
      return PS_GENERIC_FAIL;
   }

   // Read TT/PS font name pairs and put them into the table.

   lpby = lpbyRcData;

   while (nNumDefSubsFont-- > 0)
   {
      lstrcpy(lpSubsFontTable, lpby);

      lpSubsFontTable += nFontNameSize;
      lpby += lstrlen(lpby) + 1;
   }

   UnloadFontResource(hgblRcData);

   return PS_SUCCESS;
}

/***************************************************************************
*                    GetNumDefSubsFont
*  function:
*  Return the number of the default substitution font names. This function
*  does a sanity check so that the returned value is guaranteed that it
*  has an even number.
*
*  prototype:
*  int FAR PASCAL GetNumDefSubsFont(VOID)
*
*  parameters:
*  None
*
*  returns:
*  The number of the substitution font registered in resource, or -1 if
*  failed to find and/or load the resource, or the number is not even.
*
***************************************************************************/

int FAR PASCAL GetNumDefSubsFont(VOID)
{
   static int nNumDefSubsFont = -1;

   HGLOBAL  hgblRcData;
   LPBYTE   lpbyRcData;

   // If the number is already counted, give it back to the caller
   // immediately.

   if (nNumDefSubsFont > 0)
   {
      return nNumDefSubsFont;
   }

   // First, load ID_FNT_DEF_SUBS_FONT resource into memory.

   lpbyRcData = LoadFontResource(ID_FNT_DEF_SUBS_FONT, &hgblRcData);

   if (lpbyRcData == NULL)
   {
      return -1;
   }

   for (nNumDefSubsFont = 0;
         *lpbyRcData != RCDATA_TERMINATOR;
            nNumDefSubsFont++)
   {
      lpbyRcData += lstrlen(lpbyRcData) + 1;
   }

   // Sanity check. There must be at least one TT/PS pair.

   if (nNumDefSubsFont <= 0)
   {
      nNumDefSubsFont = -1;
   }
   else if ((nNumDefSubsFont % 2) != 0)
   {
      nNumDefSubsFont = -1;
   }

   UnloadFontResource(hgblRcData);

   return nNumDefSubsFont;
}

/***************************************************************************
*                 LoadIncorrectFixedFontList
*  function:
*
*  prototype:
*  BOOL FAR PASCAL LoadIncorrectFixedFontList(VOID)
*
*  parameters:
*  None
*
*  returns:
*  BOOL  TRUE  : successful
*        FALSE : loading of RCDATA resource or memory allocation failed
*
***************************************************************************/

BOOL FAR PASCAL LoadIncorrectFixedFontList(VOID)
{
   BOOL bResult;

   FreeIncorrectFixedFontList();

   bResult = LoadFontList(ID_FNT_INCRCT_FIXED, &IncorrectFixedFontList);

   return bResult;
}

/***************************************************************************
*                 FreeIncorrectFixedFontList
*  function:
*
*  prototype:
*  VOID FAR PASCAL FreeIncorrectFixedFontList(VOID)
*
*  parameters:
*  None
*
*  returns:
*  None
*
***************************************************************************/

VOID FAR PASCAL FreeIncorrectFixedFontList(VOID)
{
   if (IncorrectFixedFontList != NULL)
   {
      GlobalFreePtr(IncorrectFixedFontList);
      IncorrectFixedFontList = NULL;
   }
}

/***************************************************************************
*                        LoadPreferredCJKFontList
*  function:
*  Load default preferred CJK font list. TRUE could be returned even if
*  no memory is allocated. That could happen if no font name resource is
*  defined in the resource file.
*
*  prototype:
*  BOOL FAR PASCAL AllocPreferredCJKFontList(VOID)
*
*  parameters:
*  None
*
*  returns:
*  BOOL  TRUE  : successful
*        FALSE : memory allocation failed
*
***************************************************************************/

BOOL FAR PASCAL LoadPreferredCJKFontList(VOID)
{
   BOOL bResult;

   FreePreferredCJKFontList();

   bResult = LoadFontList(ID_FNT_PREF_CJK, &PrefCJKFontList);

   return bResult;
}

/***************************************************************************
*                        FreePreferredCJKFontList
*  function:
*    Free memory allocated for storing default proeferred CJK font list,
*    then initialize related global variables.
*
*  prototype:
*       VOID FAR PASCAL FreePreferredCJKFontList(VOID)
*  parameters:
*       None
*  returns:
*       None
*
***************************************************************************/

VOID FAR PASCAL FreePreferredCJKFontList(VOID)
{
   if (PrefCJKFontList != NULL)
   {
      GlobalFreePtr(PrefCJKFontList);
      PrefCJKFontList = NULL;
   }
}

//LoadEncodeNameList and UnloadEncodeNameList has been moved out of streamer
// to UFL.
/***************************************************************************
*                        LoadEncodeNameList
*  function:
*  Load the master encoding name table. TRUE could be returned even if
*  no memory is allocated. That could happen if no font name resource is
*  defined in the resource file.
*
*  prototype:
*  BOOL FAR PASCAL LoadEncodeNameList(VOID)
*
*  parameters:
*  None
*
*  returns:
*  BOOL  TRUE  : successful
*        FALSE : memory allocation failed
*
***************************************************************************/

BOOL FAR PASCAL LoadEncodeNameList(VOID)
{
   BOOL bResult;

   FreeEncodeNameList();

   bResult = LoadFontList(ID_ENCODE_NAMES, &EncodeNameList);

   return bResult;
}

/***************************************************************************
*                        FreeEncodeNameList
*  function:
*    Free memory allocated for storing Encode Name list.
*    then initialize related global variables.
*
*  prototype:
*       VOID FAR PASCAL FreeEncodeNameList(VOID)
*  parameters:
*       None
*  returns:
*       None
*
***************************************************************************/

VOID FAR PASCAL FreeEncodeNameList(VOID)
{
   if (EncodeNameList != NULL)
   {
      GlobalFreePtr(EncodeNameList);
      EncodeNameList = NULL;
   }
}

/***************************************************************************
*                        LoadMacGlyphNameList
*  function:
*  Load the master encoding name table. TRUE could be returned even if
*  no memory is allocated. That could happen if no font name resource is
*  defined in the resource file.
*
*  prototype:
*  BOOL FAR PASCAL LoadMacGlyphNameList(VOID)
*
*  parameters:
*  None
*
*  returns:
*  BOOL  TRUE  : successful
*        FALSE : memory allocation failed
*
***************************************************************************/

BOOL FAR PASCAL LoadMacGlyphNameList(VOID)
{
   BOOL bResult;

   FreeMacGlyphNameList();

   bResult = LoadFontList(ID_MAC_GLYPH_NAMES, &MacGlyphNameList);

   return bResult;
}

/***************************************************************************
*                        FreeMacGlyphNameList
*  function:
*    Free memory allocated for storing Encode Name list.
*    then initialize related global variables.
*
*  prototype:
*       VOID FAR PASCAL FreeMacGlyphNameList(VOID)
*  parameters:
*       None
*  returns:
*       None
*
***************************************************************************/

VOID FAR PASCAL FreeMacGlyphNameList(VOID)
{
   if (MacGlyphNameList != NULL)
   {
      GlobalFreePtr(MacGlyphNameList);
      MacGlyphNameList = NULL;
   }
}


#ifdef ADD_EURO
BOOL FAR PASCAL LoadEuroFontList(int EuroResID, LPSTR** EuroFontNames)
{
	BOOL bResult;

        FreeEuroFontList(EuroFontNames);

        bResult = LoadFontList(EuroResID, EuroFontNames);

	return bResult;
}

VOID FAR PASCAL FreeEuroFontList(LPSTR** EuroFontNames)
{
        if (*EuroFontNames != NULL)
	{
            GlobalFreePtr(*EuroFontNames);
            *EuroFontNames = NULL;
	}
}
#endif


