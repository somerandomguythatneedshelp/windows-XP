/* faux.c - code to handle faux fonts

              Copyright 1994 -- Adobe Systems, Inc.
            PostScript is a trademark of Adobe Systems, Inc.
NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

Original version: Ron Fischer, Mon May 2nd, 1994
*/

/* -------------------------------------------------------------------------
     Header Includes
   ------------------------------------------------------------------------- */

#include PACKAGE_SPECS
#include ATM
#include BLEND
#include STREAMER
#include STREAMER_FAUX
#include "buffglue.h"


GetFauxInfoFunc GetFauxInfo;


/* The bounding box stored with the Faux font is from the original font. */
/* Since fauxing is not perfect that bounding box turns out to be */
/* incorrect. */

PRIVATE IntX MakeFauxBBox ARGDEF2(T1FontPointer, fp, FauxInfoPointer, fauxInfo)
{
Card16 i;
Int32  blx,
      bly,
      trx,
      tryval;
FontValues *fvp;
Int32 *weightP;
Fixed weightVector[MAXWEIGHT];
Int32  maxExpand;

blx = bly = trx = tryval = 0L;


/* This is going to be hard.  We have to guess at the largest BBox */
/* necessary for this font, even though we will blend each CharString */
/* separately.  Step 1 is to construct a box that is the union of all */
/* the different masters. */

fvp = fp->pFontDict[0]->values;
for (i = 0; i < fp->pFontDict[0]->numMasters; i++, fvp++)
 { register Int32 t;

   t = fvp->fontBBox.bl.x;
   if (t < blx)
      blx = t;
   t = fvp->fontBBox.bl.y;
   if (t < bly)
      bly = t;
   t = fvp->fontBBox.tr.x;
   if (t > trx)
      trx = t;
   t = fvp->fontBBox.tr.y;
   if (t > tryval)
      tryval = t;
 } /* end for */

/* Step 2: Pre-flight the DVT table to find extrapolations.  Then expand */
/* the box if necessary.  The DVT contains normalized coordinates, the */
/* best way to spot one is to look for val not between 0 and 1.0! */
/* TheScalerFontP->NumGlyphs has the number of glyphs encoded for this */
/* faux, but we are after the number of glyphs in the Chameleon. */

 { boolean doingExtrap;
   Card16 j;
   Fixed designVector[2];
   Card8 isLower;

   maxExpand = 0;
   for (i = 0; i < (Card16)fauxInfo->glyphCount; i++)
    { Int32 *valP;
      doingExtrap = false;

      if (fauxInfo->expand > maxExpand)        /* Get the max expand */
         maxExpand = fauxInfo->expand;

      j = 0;
      if (!GetFauxInfo(i, INDEX_IS_CHARINDEX, NULL, designVector, &isLower))
         continue;				/* Couldn't get info */
      valP = designVector;
      while ((doingExtrap == false) && (j++ < fp->numAxes))
       { doingExtrap = ((*valP < 0L) || (*valP > 0x00010000));
         valP++;
       } /* end while */

      if (doingExtrap)                            /* Blend the BBox */
       { Int32  newblx,
                newbly,
                newtrx,
                newTry = 0L;
         Card16 k;

         newblx = newbly = newtrx = newTry = 0L;

         if (GetWeightVector(fp->ds, weightVector, designVector))
          { fvp = fp->pFontDict[0]->values;
            weightP = weightVector;

         for (k = 0; k < fp->pFontDict[0]->numMasters; k++, fvp++, weightP++)
             { newblx += fixmul(fvp->fontBBox.bl.x, *weightP);
               newbly += fixmul(fvp->fontBBox.bl.y, *weightP);
               newtrx += fixmul(fvp->fontBBox.tr.x, *weightP);
               newTry += fixmul(fvp->fontBBox.tr.y, *weightP);
             } /* end for */

            if (newblx < blx)
               blx = newblx;
            if (newbly < bly)
               bly = newbly;
            if (newtrx > trx)
               trx = newtrx;
            if (newTry > tryval)
               tryval = newTry;

          } /* If GetWeightVector */
       } /* doingExtrap */
    } /* For every glyph */
 } /* Step 2 */

/* Step 3 is to add 1/2 of the maximum 'expand' value1/2
   corresponds to left side bearing. */

trx += (maxExpand >> 1);

fp->defaultVals.fontBBox.tr.x = trx;
fp->defaultVals.fontBBox.tr.y = tryval;
fp->defaultVals.fontBBox.bl.x = blx;
fp->defaultVals.fontBBox.bl.y = bly;

return ST_NOERR;
} /* end MakeFauxBBox() */


/* Blend the values and scale them by X-Height matching scale if glyph is
   lowercase. */

static Int32 BlendFauxValsData ARGDEF4(T1FontPointer, fp, Int16 **, dataPP,
                               boolean, horizontal, FauxInfoPointer, fauxInfo)
{
register Int32 val;
register Int16 *dataP;
register Int16 j;
Int32 *weightP;
Card8 isLower;
Fixed weightVector[MAXWEIGHT];
Fixed designVector[2];

dataP = *dataPP;

j = GetFauxInfo(*dataP++, INDEX_IS_ENCODING, NULL, designVector, &isLower);

if (j && GetWeightVector(fp->ds, weightVector, designVector))
 { val = 0L;            /* Blend the values using the weightVector */
   weightP = weightVector;
   j = fp->pFontDict[0]->numMasters;
   while (--j >= 0)
      val += ((Int32) (*dataP++) * *weightP++);
 } /* end if */
else
 { val = (Int32) *dataP << 16;   /* Could not get WV, just use the first val */
   dataP += fp->pFontDict[0]->numMasters;          /* Skip the blend values. */
 } /* end else */

*dataPP = dataP;

if (isLower && fauxInfo->LowercaseScale)
   val = fixmul(val, fauxInfo->LowercaseScale);

if (horizontal && fauxInfo->condense)
   val = fixmul(val, fauxInfo->condense);

return val;
} /* end BlendFauxValsData() */


static void SetFauxValsData ARGDEF7(T1FontPointer, fp, Int16 **, dataPP, 
       boolean, blended, Int16, argCount, boolean, horizontal, 
       FauxInfoPointer, fauxInfo, Fixed *, output)
{
register Int16 i;

if (blended)
 { for (i = 0; i < argCount; i++)       /* Blend the args...   */
      *(output+i) = BlendFauxValsData(fp, dataPP, horizontal, fauxInfo);
 } /* end if */
else
 { register Int16 *dataP = *dataPP;    /* Each arg is one value */
   for (i = 0; i < argCount; i++)
      *(output+i) = *dataP++;

   *dataPP = dataP;
 } /* end else */

} /* end SetFauxValsData() */


/* Some lists such as the StemSnap data must be sorted from low to high....  */

static void SortList ARGDEF2(Int32 *, valList, Int16, argCount)
{
IntX i, j;
Int32 temp;

for (i = 0; i < argCount-1; i++)
  for (j = i+1; j < argCount; j++)
     if (valList[i] > valList[j])
      { temp = valList[i];
        valList[i] = valList[j];
        valList[j] = temp;
      } /* end if */

} /* end SortList() */


/* Warning--blue values and other blues need to be properly combined into */
/* one structure. */

PRIVATE IntX MakeFauxHints ARGDEF3(T1FontPointer, fp, FauxValsPointer, fauxVals,
                           FauxInfoPointer, fauxInfo)
{
Int16 *dataP;
boolean blended;
Card16 argCount;
Card16 code;
Int32  forceBoldThreshold;
Int16 i, j, numBlues = 0, numFamily = 0;
Int32  valueArray[12];
Fixed temp1, temp2, maxBlueZone = 0;

/* This would come from the fauxVals header */
forceBoldThreshold = 0;
fp->pFontDict[0]->blueZones = 0;
fp->pFontDict[0]->familyBlueZones = 0;

for (i = 0; i < (Int16)fauxInfo->fauxValsCount; i++)
 { code = fauxVals->code;
   argCount = fauxVals->argCount;
   dataP = fauxVals->data;
   blended = false;

   switch (code)
    { case FAUX_BLUE_VALUES_BLEND:
         blended = true;

      case FAUX_BLUE_VALUES:
         /* I pass in the address of the topEdge because it occurs first in */
         /* the BlueValueRec structure (and with an argCount of 2 it and the */
         /* botEdge should both be set). */
         SetFauxValsData(fp, &dataP, blended, argCount, false, fauxInfo, &fp->defaultVals.blueValues[numBlues].topEdge);
         /* Put the blue values in the correct order, scaled. */
         for (j = numBlues; j < numBlues + (Int16)(argCount>>1); j++)
          { temp1 = fp->defaultVals.blueValues[j].topEdge*65536;
            fp->defaultVals.blueValues[j].topEdge = 
                                 fp->defaultVals.blueValues[j].botEdge * 65536;
            fp->defaultVals.blueValues[j].botEdge = temp1;
          } /* end for */
         numBlues += (argCount>>1);
         break;

      case FAUX_OTHER_BLUES_BLEND:
         blended = true;

      case FAUX_OTHER_BLUES:
         SetFauxValsData(fp, &dataP, blended, argCount, false, fauxInfo, &fp->defaultVals.blueValues[numBlues].topEdge);
         for (j = numBlues; j < numBlues + (Int16)(argCount>>1); j++)
          { fp->pFontDict[0]->blueZones |= (1<<j);
            temp1 = fp->defaultVals.blueValues[j].topEdge*65536;
            fp->defaultVals.blueValues[j].topEdge = 
                                 fp->defaultVals.blueValues[j].botEdge * 65536;
            fp->defaultVals.blueValues[j].botEdge = temp1;
          } /* end for */
         numBlues += (argCount>>1);
         break;

      case FAUX_STHW_BLEND:
         blended = true;

      case FAUX_STHW:
         SetFauxValsData(fp, &dataP, blended, argCount, false, fauxInfo, &fp->defaultVals.stdHW);
         break;

      case FAUX_STVW_BLEND:
         blended = true;

      case FAUX_STDVW:
         SetFauxValsData(fp, &dataP, blended, argCount, true, fauxInfo, &fp->defaultVals.stdVW);
         break;

      case FAUX_STEM_SNAP_H_BLEND:
         blended = true;

      case FAUX_STEM_SNAP_H:
       { if (blended)
          { for (j = 0; j < (Int16)argCount; j++)
               valueArray[j] = BlendFauxValsData(fp, &dataP, false, fauxInfo);

            SortList(valueArray, argCount);
          } /* end if */
         else
            SetFauxValsData(fp, &dataP, true, argCount, false, fauxInfo, fp->defaultVals.stemSnapH);
         break;
       } /* end FAUX_STEM_SNAP_H */

      case FAUX_STEM_SNAP_V_BLEND:
         blended = true;

      case FAUX_STEM_SNAP_V:
       { if (blended)
          { for (j = 0; j < (Int16)argCount; j++)
               valueArray[j] = BlendFauxValsData(fp, &dataP, true, fauxInfo);

            SortList(valueArray, argCount);
          } /* end if */
         else
            SetFauxValsData(fp, &dataP, true, argCount, true, fauxInfo, fp->defaultVals.stemSnapV);
         break;
       } /* end case FAUX_STEM_SNAP_V */

      case FAUX_BLUE_SCALE_BLEND:
         blended = true;

      case FAUX_BLUE_SCALE:
       { Int32  PtSize;

         if (blended)                   /* Will advance DataP */
            PtSize = BlendFauxValsData(fp, &dataP, false, fauxInfo);
         else
            PtSize = (Int32) *dataP++ << 16;   /* Advance DataP */

         /* (Pt - 0.49) / 240 (from Black Book!!) */
         fp->defaultVals.blueScale = fixdiv(PtSize - 0x00007D71, 0x00F00000);
         /* Also from black book--use this to check blue zone width */
         maxBlueZone = fixdiv(0x00F00000, (PtSize - 0x00007D71));
       } /* end case FAUX_BLUE_SCALE */

         break;

      case FAUX_BLUE_FUZZ_BLEND:
         blended = true;

      case FAUX_BLUE_FUZZ:
         SetFauxValsData(fp, &dataP, blended, argCount, false, fauxInfo, &fp->defaultVals.blueFuzz);
         break;

      case FAUX_BLUE_SHIFT:
       { fp->defaultVals.blueShift = *(Int32 *) dataP;
         dataP += 2;                /* DataP is a Int16 P, so skip 4 bytes */

         break;
       } /* end case FAUX_BLUE_SHIFT */

      case FAUX_FAMILY_BLUES_BLEND:
         blended = true;

      case FAUX_FAMILY_BLUES:
         SetFauxValsData(fp, &dataP, blended, argCount, false, fauxInfo, &fp->defaultVals.familyBlueValues[numFamily].topEdge);
         numFamily += (argCount>>1);
         for (j = numFamily; j < numFamily + (Int16)(argCount>>1); j++)
          { temp1 = fp->defaultVals.familyBlueValues[j].topEdge*65536;
            fp->defaultVals.familyBlueValues[j].topEdge = 
                        fp->defaultVals.familyBlueValues[j].botEdge * 65536;
            fp->defaultVals.familyBlueValues[j].botEdge = temp1;
          } /* end for */
         break;

      case FAUX_FAMILY_OTHER_BLEND:
         blended = true;

      case FAUX_FAMILY_OTHER:
         SetFauxValsData(fp, &dataP, blended, argCount, false, fauxInfo, &fp->defaultVals.familyBlueValues[numFamily].topEdge);
         for (j = numFamily; j < numFamily + (Int16)(argCount>>1); j++)
          { fp->pFontDict[0]->familyBlueZones |= (1<<j);
            temp1 = fp->defaultVals.familyBlueValues[j].topEdge*65536;
            fp->defaultVals.familyBlueValues[j].topEdge = 
                        fp->defaultVals.familyBlueValues[j].botEdge * 65536;
            fp->defaultVals.familyBlueValues[j].botEdge = temp1;
          } /* end for */
         numFamily += (argCount>>1);
         break;

      case FAUX_FORCE_BOLD_THRESHOLD:
         fp->pFontDict[0]->boldThreshold = (Int32) *dataP;
         dataP += 2;
         break;

      case FAUX_FORCE_BOLD_BLEND:
         blended = true;

      case FAUX_FORCE_BOLD:
       { Int32  forceBold;

         if (blended)
            forceBold = BlendFauxValsData(fp, &dataP, false, fauxInfo);/* Will advance DataP */
         else
            forceBold = (Int32) *dataP++ << 16;        /* Advance DataP */

         if (forceBold > forceBoldThreshold)
            fp->defaultVals.flags |= FONT_FORCEBOLD | FONT_FORCEBOLD_USED;
         else
            fp->defaultVals.flags |= (0xFFFFFFFFL ^ FONT_FORCEBOLD);
         break;
       }

      default:
         break;
    } /* end switch */

   fauxVals = (FauxValsPointer) dataP;        /* We are at the beginning
                                                   of the next one */
 } /* end for() */

/* Make sure my new Blue Values are valid */
fp->pFontDict[0]->numBlueValues = numBlues;

/* Assumes BlueScale was set at some point */
for (i = 0; i < numBlues; i++)
 { temp1 = fp->defaultVals.blueValues[i].topEdge - 
           fp->defaultVals.blueValues[i].botEdge; 
   if (temp1 > maxBlueZone)
    { fp->defaultVals.blueValues[i].topEdge -= ((temp1-maxBlueZone) >> 1);
      fp->defaultVals.blueValues[i].botEdge += ((temp1-maxBlueZone) >> 1);
    } /* end if */
 } /* end for */

/* Number of blues is so small that this will be quick */
/* Assumes no completely overlapping blue zones */
for (i = 0; i < numBlues-1; i++)
   for (j = i+1; j < numBlues; j++)
      if (fp->defaultVals.blueValues[i].topEdge > fp->defaultVals.blueValues[j].botEdge)
       { temp1 = fp->defaultVals.blueValues[i].botEdge;
         temp2 = fp->defaultVals.blueValues[i].topEdge;
         fp->defaultVals.blueValues[i].botEdge = fp->defaultVals.blueValues[j].botEdge;
         fp->defaultVals.blueValues[i].topEdge = fp->defaultVals.blueValues[j].topEdge;
         fp->defaultVals.blueValues[j].botEdge = temp1;
         fp->defaultVals.blueValues[j].topEdge = temp2;
         temp1 = ((fp->pFontDict[0]->blueZones & (1 << i)) != 0);
         temp2 = ((fp->pFontDict[0]->blueZones & (1 << j)) != 0);

         if (temp1)
          { fp->pFontDict[0]->blueZones |= (1 << j);
            if (!temp2)
               fp->pFontDict[0]->blueZones ^= (1 << i);
          } /* end if */

         if (temp2)
          { fp->pFontDict[0]->blueZones |= (1 << i);
            if (!temp1)
               fp->pFontDict[0]->blueZones ^= (1 << j);
          } /* end if */
       } /* end if */

/* See the black book description of blue fuzz */
if (fp->defaultVals.blueFuzz == 0)
   temp1 = FixInt(3);
else
   temp1 = (fp->defaultVals.blueFuzz << 1) + FixedOne;

/* Assumes resulting hint is not too small. */
for (i = 0; i < numBlues-1; i++)
 { temp2 = fp->defaultVals.blueValues[i+1].botEdge - 
           fp->defaultVals.blueValues[i].topEdge;
   if (temp2 < temp1)
    { fp->defaultVals.blueValues[i].topEdge -= ((temp1 - temp2) >> 1);
      fp->defaultVals.blueValues[i+1].botEdge += ((temp1 - temp2) >> 1);
    } /* end if */
 } /* end for */

/* Assumes BlueScale was set at some point */
for (i = 0; i < numFamily; i++)
 { temp1 = fp->defaultVals.familyBlueValues[i].topEdge - 
           fp->defaultVals.familyBlueValues[i].botEdge; 
   if (temp1 > maxBlueZone)
    { fp->defaultVals.familyBlueValues[i].topEdge -= ((temp1-maxBlueZone)>> 1);
      fp->defaultVals.familyBlueValues[i].botEdge += ((temp1-maxBlueZone)>> 1);
    } /* end if */
 } /* end for */

fp->pFontDict[0]->numFamilyBlues = numFamily;
for (i = 0; i < numBlues-1; i++)
   for (j = i+1; j < numBlues; j++)
      if (fp->defaultVals.familyBlueValues[i].topEdge > fp->defaultVals.familyBlueValues[j].botEdge)
       { temp1 = fp->defaultVals.familyBlueValues[i].botEdge;
         temp2 = fp->defaultVals.familyBlueValues[i].topEdge;
         fp->defaultVals.familyBlueValues[i].botEdge = fp->defaultVals.familyBlueValues[j].botEdge;
         fp->defaultVals.familyBlueValues[i].topEdge = fp->defaultVals.familyBlueValues[j].topEdge;
         fp->defaultVals.familyBlueValues[j].botEdge = temp1;
         fp->defaultVals.familyBlueValues[j].topEdge = temp2;
         temp1 = ((fp->pFontDict[0]->familyBlueZones & (1 << i)) != 0);
         temp2 = ((fp->pFontDict[0]->familyBlueZones & (1 << j)) != 0);

         if (temp1)
          { fp->pFontDict[0]->familyBlueZones |= (1 << j);
            if (!temp2)
               fp->pFontDict[0]->familyBlueZones ^= (1 << i);
          } /* end if */

         if (temp2)
          { fp->pFontDict[0]->familyBlueZones |= (1 << i);
            if (!temp1)
               fp->pFontDict[0]->familyBlueZones ^= (1 << j);
          } /* end if */
       } /* end if */

/* Assumes resulting hint is not too small. */
for (i = 0; i < numFamily-1; i++)
 { temp2 = fp->defaultVals.familyBlueValues[i+1].botEdge - 
           fp->defaultVals.familyBlueValues[i].topEdge;
   if (temp2 < temp1)
    { fp->defaultVals.familyBlueValues[i].topEdge -= ((temp1 - temp2) >> 1);
      fp->defaultVals.familyBlueValues[i+1].botEdge += ((temp1 - temp2) >> 1);
    } /* end if */
 } /* end for */

return ST_NOERR;
} /* end MakeFauxHints() */


/*************************************************************************

Function name:  ModifyFontMatrix()

**************************************************************************

Date:           
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        Use the italic angle to change the font matrix.
Description:    
                
Parameters:     
                
Return Values:  
Notes:          
See also:       

**************************************************************************/

PRIVATE IntX ModifyFontMatrix ARGDEF2(T1FontPointer, fp, FauxInfoPointer, fauxInfo)
{
if (fauxInfo->ItalicAngle != 0)
 { fp->pFontDict[0]->fontMatrix.c += fixmul(fp->pFontDict[0]->fontMatrix.a, fauxInfo->ItalicAngle);
   fp->pFontDict[0]->fontMatrix.d += fixmul(fp->pFontDict[0]->fontMatrix.b, fauxInfo->ItalicAngle);
 } /* end if */

return ST_NOERR;
} /* end ModifyFontMatrix() */


/*************************************************************************

Function name:  SetFauxFont()

**************************************************************************

Date:           05/02/94
Author:         Ron Fischer (rff)
Prototype in:   faux.h
Summary:        Set faux font data in the FontRecord
Description:    Uses the fauxInfo structure and the fauxVals data to modify
                the FontRecord information.  On entry the FontRecord should
                contain the information for the MM chameleon font being 
                used.  Upon successful completion the FontRecord will contain
                fields that pertain to the faux font to be substituted
                (the defaultVals field in particular is affected).  The
                fields set will allow the Streamer functions to produce a
                valid Type 1 font.  
                
Parameters:     fp - the pointer to the FontRecord structure to modify
                fauxVals - the pointer to the faux font values data
                fauxInfo - the pointer to the faux font information struct
                
Return Values:  ST_NOERR if all is OK, one of the ST_ errors if a problem
                is encountered.
Notes:          Modifies data in the T1FontPointer it is given.
                It's the user's responsibility to get the fauxInfo and
                fauxVals information.  The faux info comes mostly from the
                faux database (although note that most of the values should
                be converted to fixed point).  The design vector information
                comes from the FontFit code.  The fauxVals info comes from
                small, special data files which contain information about
                the creation of font level hints.  See GetFauxData() in
                getfaux.c in the stream product to learn how to read in these
                files.
                Also note that you may want to change additional fields by
                hand.  For instance, if the faux font should have a special
                encoding you would want to change the standard encoding
                flag and the special encoding array.
See also:       

**************************************************************************/


IntX SetFauxFont ARGDEF4(T1FontPointer, fp, FauxValsPointer, fauxVals, 
                    FauxInfoPointer, fauxInfo, GetFauxInfoFunc, g)
{
GetFauxInfo = g;		/* Set the global function pointer */

if (!MemoryRealloc((void **)&fp->fontName, os_strlen(fauxInfo->FontName)+1))
   return ST_OUT_OF_MEM;
os_strcpy(fp->fontName, fauxInfo->FontName);
if (!MemoryRealloc((void **)&fp->FullName, os_strlen(fauxInfo->FullName)+1))
   return ST_OUT_OF_MEM;
os_strcpy(fp->FullName, fauxInfo->FullName);
if (!MemoryRealloc((void **)&fp->FamilyName, os_strlen(fauxInfo->FamilyName)+1))
   return ST_OUT_OF_MEM;
os_strcpy(fp->FamilyName, fauxInfo->FamilyName);

/* Although version and weight are constants I go through this procedure
   because the memory will be freed eventually. */
if (!MemoryRealloc((void **)&fp->Version, os_strlen("001.000")+1))
   return ST_OUT_OF_MEM;
os_strcpy(fp->Version, "001.000");
if (!MemoryRealloc((void **)&fp->Weight, os_strlen("Faux Font")+1))
   return ST_OUT_OF_MEM;
os_strcpy(fp->Weight, "Faux Font");

fp->ItalicAngle = fauxInfo->ItalicAngle;
fp->isFixedPitch = fauxInfo->IsFixedPitch;
fp->UnderlinePosition = fauxInfo->UnderlinePos;
fp->UnderlineThickness = fauxInfo->UnderlineThickness;
fp->pFontDict[0]->paintType = 0;

MakeFauxBBox(fp, fauxInfo);

MakeFauxHints(fp, fauxVals, fauxInfo);

ModifyFontMatrix(fp, fauxInfo);

return ST_NOERR;
} /* end SetFauxFont() */






