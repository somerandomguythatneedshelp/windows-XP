/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: CHICAGO.H                                                    */
/*                                                                           */
/* Description: This module contains the #defines needed to go from Win 3.1  */
/*              to Chicago                                                   */
/*                                                                           */
/*****************************************************************************/

#define  MIN_SCREEN_FREQ        1
#define  MAX_SCREEN_FREQ     9999

#define  MIN_SCREEN_ANGLE       0
#define  MAX_SCREEN_ANGLE    3600

#define MAX_CUST_PAPER_NAME  64

#define WARN_COPIES_THRESHOLD 20

#define MIN_VM          (float)0.0
#define MAX_VM          (float)99999999.0
