/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: STRETCHD.H                                             */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

SHORT _loadds FAR PASCAL StretchDIB(LP,WORD,WORD,WORD,WORD,WORD,WORD,WORD,
                                    WORD,WORD,
                                    LP,LPBITMAPINFO,
                                    LPSTR,DWORD,LPPBRUSH,
                                    LPDRAWMODE,LPRECT);
VOID FAR PASCAL HandleBufferedBitmap(LP lpDevice);

BOOL NEAR DIBSEG PASCAL BufferBitmap(LP, LONG, LONG, LONG, LONG, LONG, LONG, LONG, 
                              LONG,LP, LPBITMAPINFO, LPBITMAP, DWORD, LPPBRUSH,
                              LPDRAWMODE, LPRECT);
BOOL NEAR DIBSEG PASCAL HandleBitmapNow(VOID);
VOID NEAR DIBSEG PASCAL doStretchDIB(LP, WORD, WORD, WORD, WORD,
                              WORD, WORD, WORD, WORD,
                              LP, LPBITMAPINFO,
                              DWORD, LPPBRUSH, LPDRAWMODE, LPRECT);
VOID NEAR DIBSEG PASCAL doBitmapNow(LP, LONG, LONG, LONG, LONG,
                             LONG, LONG, LONG, LONG,
                             LP, LPBITMAPINFO, LPBITMAP,
                             DWORD, LPPBRUSH, LPDRAWMODE, LPRECT);
BOOL NEAR DIBSEG PASCAL flushBufferedBitmap(LP);
BOOL NEAR DIBSEG PASCAL bufferBitmapData(LP, LONG, LONG, LONG, LONG,
                                  LONG, LONG, LONG, LONG,
                                  LP, LPBITMAPINFO, LPBITMAP,
                                  DWORD, LPPBRUSH, LPDRAWMODE, LPRECT);
//L3_MASK
//SHORT NEAR DIBSEG PASCAL ColorOrGrayToDevice(LPPDEVICE,LPRECT,
//                                      LPRECT,LPSTR,LPBITMAPINFO);
SHORT NEAR DIBSEG PASCAL ColorOrGrayToDevice(LPPDEVICE, LPDRAWMODE, LPRECT,
                                      LPRECT, LPSTR, LPBITMAPINFO);

VOID NEAR DIBSEG PASCAL DeCompressedRLE4OrRLE8DIB(LPPDEVICE lppd, DWORD width,
                                      BYTE huge *lpNewBitsBf, BYTE huge *lpBitsSrc ,LPBITMAPINFO lpBitmapInfo);

