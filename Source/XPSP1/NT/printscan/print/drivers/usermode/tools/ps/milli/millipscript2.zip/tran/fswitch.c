/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: FSWITCH.C                                                    */
/*                                                                           */
/* Description: This module contains the function                            */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_TSTARTSEG)

BOOL FAR PASCAL CheckFeatureDSCEntry(LPPDEVICE lppd, LPSTR lpFeatureName);

/***************************************************************************
*                               AsciiOrBinary
*  Purpose:
*
*  Parameters:
*       short     Flavor --
*       BOOL      Binary --
*       LPPDEVICE lppd --
*
*  Returns: none
*
***************************************************************************/
VOID FAR PASCAL AsciiOrBinary(short Flavor, BOOL Binary, LPPDEVICE lppd)
{
   BOOL  fLevel2;           // TRUE if Flavor involves PS Level 2.
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   tempptr->PSSendBasic            = PSSendBasicAscii7     ;
   tempptr->PSSendShort            = PSSendShortAscii7     ;
   tempptr->PSSendFloat            = PSSendFloatAscii7     ;
   tempptr->PSSendEx6Float         = PSSendEx6FloatAscii7  ;
   tempptr->PSSendCRLF             = PSSendCRLFAscii7      ;
   tempptr->PSSendDSC              = PSSendDSCAscii7       ;
   tempptr->PSSendDSCBBox          = PSSendDSCBBoxAscii7   ;
   tempptr->PSSendBoolean          = PSSendBooleanAscii7   ;
   tempptr->PSSendBitMapType       = PSSendBitMapTypeAscii7;
   tempptr->PSSendBitMapDataLevel2 = PSSendBitMapDataLevel2Ascii7;
   tempptr->PSSendBitMapDataLevel1 = PSSendBitMapDataLevel1Ascii7;
   tempptr->PSSendBitMapTerminator = PSSendBitMapTerminatorAscii7;
   tempptr->PSSendFontType2        = PSSendFontType2Ascii  ;

   tempptr->ConvertToBinary        = NOConvertToBinary;

   fLevel2 = ( (Flavor == PPSLEVEL2) || (Flavor == EPSLEVEL2) );

   if(Binary == TRUE)
   {
      // Functions for sending binary data regardless of PostScript level.

      tempptr->PSSendCRLF             = PSSendCRLFBinary      ;
      tempptr->PSSendBitMapType       = PSSendBitMapTypeBinary;
      tempptr->PSSendBitMapDataLevel2 = PSSendBitMapDataLevel2Binary;

      // Added support for PSSendBitMapDataLevel1Binary
      tempptr->PSSendBitMapDataLevel1 = PSSendBitMapDataLevel1Binary;
      tempptr->PSSendBitMapTerminator = PSSendBitMapTerminatorBinary;
      tempptr->PSSendFontType2        = PSSendFontType2Binary;

      if (fLevel2)
      {
         // We are sending binary and level 2.  Use binary encodings
         // for operators.

#ifdef ADOBE_DRIVER
         if ((lppd->lpPSExtDevmode->dm.layout == ONE_UP) ||
         (lppd->disableNUP))
#else
         if (lppd->lpPSExtDevmode->dm.layout == ONE_UP)
#endif
         {
            tempptr->PSSendBasic         = PSSendBasicBinary;
         }  // Suppress binary encoding for operators if doing Nup since
            //  header is not binary encoded - ShyamV - M6 fix - 03/24/94

         tempptr->PSSendShort            = PSSendShortBinary;
         tempptr->PSSendFloat            = PSSendFloatBinary;
         tempptr->PSSendBoolean          = PSSendBooleanBinary;
      }

      // now check the type of protocol
      switch(lppd->lpPSExtDevmode->dm2.iDataOutputFormat)
      {
        case PROTOCOL_TBCP:
            tempptr->ConvertToBinary = EBCPConvertToBinary;
            break;

        case PROTOCOL_BCP:
            tempptr->ConvertToBinary = BCPConvertToBinary;
            break;

        case PROTOCOL_ASCII:
        case PROTOCOL_BINARY:
        default:
            tempptr->ConvertToBinary = NOConvertToBinary;
            break;
      }
   }
}  // END AsciiOrBinary

/***************************************************************************
*
*                              IsKodakPPD
*
*    Parameter:  LPPDEVICE lppd
*
***************************************************************************/
BOOL FAR PASCAL IsKodakPPD(LPPDEVICE lppd)
{

   LPBYTE   lpPCFileNameStr;
   int      i=0;

   // Get PCFileName fro WPX struct.
   lpPCFileNameStr = StringRefToLPBYTE(lppd,
                     ((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->PCFileName.dword);
   if ( lpPCFileNameStr &&
       (lpPCFileNameStr[0] == 'K') && (lpPCFileNameStr[1] == 'D'))
   {
       return TRUE;
   }
   else
   {
       return FALSE;
   }
}
BOOL FAR PASCAL GetKeyVal(HKEY hv, LPSTR path_key, LPSTR val_key, LPSTR buffer, long *cl)
{
   BOOL  bRet=TRUE;
   HKEY  hKey;
   long  cb, ret;

     ret=RegOpenKey(hv, (LPSTR)path_key, &hKey);
     if (ret==ERROR_SUCCESS){
        cb = *cl;
        ret = RegQueryValueEx(hKey, (LPSTR)val_key, NULL, NULL, buffer, &cb);
        if (ret==ERROR_SUCCESS){
           *cl = cb;
           }
        else bRet=FALSE;
        RegCloseKey(hKey);
     }
     else bRet=FALSE;
  return bRet;
}
/************************************************************************
*                       AddFeatureDSCEntry
*  Function:
*       Adds a record to the font DSC comment list --
*
*  Called:
*       BOOL FAR PASCAL AddFeatureDSCEntry(LPPDEVICE lppd,
*                                         LPSTR lpFeatureName, BOOL bfSupplied);
*  Parameters:
*       LPPDEVICE lppd  -- pdevice pointer
*       LPSTR FeatureName  -- Name of font to be added
*       BOOL bfSupllied -- Supplied/Needed Flag (pass value along to entry)
*   BOOL bNonPPDFeature - Supplied  non PPD features
*  Returns:
*       BOOL -- TRUE => success
*
*************************************************************************/

BOOL FAR PASCAL AddFeatureDSCEntry(LPPDEVICE lppd, LPSTR lpFeatureName, BOOL bfSupplied,
BOOL bNonPPDFeature)
{
   LPFEATUREDSCENTRY currententry;
   BOOL retval;

   retval = FALSE;

   if (retval = CheckFeatureDSCEntry(lppd, lpFeatureName) == FALSE)
   {                // Name not is already in list
      if (lppd->lpFeatureDSCList->FeatureDSCNextEntry < MAXFONTDATARECORDS)
      {
         currententry = lppd->lpFeatureDSCList->FeatureDSCList;
         currententry += lppd->lpFeatureDSCList->FeatureDSCNextEntry;
         lstrcpy(currententry->FeatureName, lpFeatureName);
         currententry->bfeatureSupplied = bfSupplied;
                 currententry->bNonPPDFeature = bNonPPDFeature;

         lppd->lpFeatureDSCList->FeatureDSCNextEntry ++;
      }
   }

   return (retval);
 }
/************************************************************************
*
*                       CheckFeatureDSCEntry
*  Function:
*       Checks to see if a record for a given font has already been
*       added to the font DSC comment list --
*
*  Called:
*       BOOL FAR PASCAL CheckFeatureDSCEntry(LPPDEVICE lppd, LPSTR lpFeatureName);
*
*  Parameters:
*       LPPDEVICE lppd  -- pdevice pointer
*       LPSTR lpFeatureName  -- Name of font to be added
*
*  Returns:
*       BOOL -- TRUE => Name is on list
*               FALSE => Name is not on list
*
*************************************************************************/

BOOL FAR PASCAL CheckFeatureDSCEntry(LPPDEVICE lppd, LPSTR lpFeatureName)
{
   LPFEATUREDSCENTRY currentptr;
   BOOL retval;
   int dex;

   retval = FALSE;
   currentptr = lppd->lpFeatureDSCList->FeatureDSCList;
   dex = 0;

   while (retval == FALSE && (dex < lppd->lpFeatureDSCList->FeatureDSCNextEntry))
   {
      if (lstrcmpi(currentptr->FeatureName,lpFeatureName) == 0)
      {
         retval = TRUE;
      }
      currentptr ++ ;
      dex ++;
   }

   return (retval);
}
