/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: LV2FUNCS.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for  ...                  */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_LEVEL2SEG)

// #define TESTING 1
#ifdef TESTING
static char OutputFile[] = "c:\\Time42.txt";
DWORD tickCountStart;
DWORD tickCountEnd;
char tempbuf[256];
WORD bufSize;
OFSTRUCT ofFS;
HFILE hFile;
#endif

// From MS Driver v. 3.5, strchblt.c
#define NOTSRCAND        (DWORD)0x00220326

// FAST_IMAGE
VOID 
Resampling_8Bit_A (LPPDEVICE lppd, BYTE huge * lpBitBuf, BYTE huge * lpNewBitBuf,
                 WORD SrcXE, WORD SrcYE, WORD DstXE, WORD DstYE, DWORD ScanWidth);
VOID 
Resampling_8Bit (LPPDEVICE lppd, BYTE huge * lpBitBuf, BYTE huge * lpNewBitBuf,
                 WORD SrcXE, WORD SrcYE, WORD DstXE, WORD DstYE, DWORD ScanWidth);
VOID 
Resampling_4Bit (LPPDEVICE lppd, BYTE huge * lpBitBuf, BYTE huge * lpNewBitBuf,
                 WORD SrcXE, WORD SrcYE, WORD DstXE, WORD DstYE, DWORD ScanWidth);
VOID 
ResampleAndSend (LPPDEVICE lppd, BYTE huge * lpBitBuf, LPRECT DstRect,
                 WORD SrcXE, WORD SrcYE, WORD BitCount, DWORD ScanWidth,
                 float far * ResampleRatio);
VOID
IndexColorToGray(LPPDEVICE lppd, BYTE huge *lpBitBuf,
                 BYTE huge *lpLineStart, DWORD ScanWidth,
                 WORD nBytes, WORD SrcYE, WORD BitCount, LPSTR lpGrayTable);

//**********************************************************************
//    Set of functions to deal with Device-Dependent Bitmaps output
//    Data is sent in the following order:
//              Header
//              Operator
//              Data
//**********************************************************************

/*****************************************************************************/
/*                                                                           */
/*                           TBitmapHeader2                                  */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPDEVICE lppd --                                                       */
/*   LPRECT SrcRect --                                                       */
/*   LPRECT DstRect --                                                       */
/*   DWORD rop --                                                            */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL 
TBitmapHeader2 (LPPDEVICE lppd, LPRECT SrcRect, LPRECT DstRect,
                DWORD rop)
{
    short retval;
    LPASCIIBINPTRS tempptr;

    FLAG Polarity;

    WORD SrcX = SrcRect->left;          // Src rect dimensions
    WORD SrcY = SrcRect->top;           // "         "      "
    WORD SrcXE = SrcRect->right - SrcX; // "         "      "
    WORD SrcYE = SrcRect->bottom - SrcY;// "         "      "

    WORD DestX = DstRect->left;         // Dest rect dimensions
    WORD DestY = DstRect->top;          // "         "      "
    WORD DestXE = DstRect->right - DestX;   // "         "      "
    WORD DestYE = DstRect->bottom - DestY;  // "         "      "

 // This will be correct in a future, but now we
 // output the bitmap data without bit alignment.
 // WORD byte_width = (SrcX + SrcXE - 1)/8 - SrcX/8 + 1 ;
 // Fixed  24-Feb-1993  -by-  [olegs]

    WORD byte_width = (SrcXE + 7) >> 3;
    tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;

    retval = TokenNeedsProcset (lppd, BITBLT);

    switch (rop)
    {
        case NOTSRCAND:
        case NOTSRCCOPY:
    // EUDC Character is prited by BitBlt called from FE GDI.
    // This ROP have to be printed 1 = black and 0 = white.
    // This code have to be reviewed after application compatibility testing.
        case 0x00E20746:
            Polarity = TRUE;            // 1 = black  0 = white
            break;

        default:                        // All other rops = SRCAND
            Polarity = FALSE;           // 1 = white  0 = black
            break;
    }                                   // End switch(rop)

    (*tempptr->PSSendShort) (lppd, SrcXE);  // Src width in pixels
    (*tempptr->PSSendShort) (lppd, SrcYE);  // Src height in scanlines
    (*tempptr->PSSendShort) (lppd, 1);  // Bits per pixel
    (*tempptr->PSSendShort) (lppd, byte_width); // Src bytes per scanline
    (*tempptr->PSSendShort) (lppd, DestXE); // Dest width
    (*tempptr->PSSendShort) (lppd, DestYE); // Dest height
    (*tempptr->PSSendShort) (lppd, DestX);  // Dest origin - x
    (*tempptr->PSSendShort) (lppd, DestY);  // Dest origin - y
    (*tempptr->PSSendBoolean) (lppd, FALSE);    // Smoothflag
    (*tempptr->PSSendBoolean) (lppd, Polarity); // Polarity

 // L3_MASK
    (*tempptr->PSSendBoolean) (lppd, FALSE);    // Masked images

    (*tempptr->PSSendBitMapType) (lppd, PPSLEVEL2); // Data type
    (*tempptr->PSSendCRLF) (lppd);
    return (retval);
}
/*****************************************************************************/
/*                                                                           */
/*                           TBitmapOperator2                                */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPDEVICE lppd --                                                       */
/*   DWORD FGColor --                                                        */
/*   DWORD BGColor --                                                        */
/*   DWORD rop --                                                            */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

SHORT FAR PASCAL 
TBitmapOperator2 (LPPDEVICE lppd, BOOL bTransparent,
                  DWORD FGColor, DWORD BGColor, DWORD rop)
{
    FLAG fGray;
    short retval;
    LPASCIIBINPTRS tempptr;
    tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;

    if (((rop == SRCCOPY) || (rop == NOTSRCCOPY)) && !bTransparent)
    {
        fGray = PSSendColor (lppd, BGColor);    // Send gray -or- r g b
        (*tempptr->PSSendBoolean) (lppd, fGray);    // Send true -or- false
        (*tempptr->PSSendCRLF) (lppd);
        PSSendFragment (lppd, PSFRAG_begincopyimage);
    } else
    {
        PSSendFragment (lppd, PSFRAG_beginimage);
    }
    (*tempptr->PSSendCRLF) (lppd);

    retval = TokenNeedsProcset (lppd, BITBLT);

    fGray = PSSendColor (lppd, FGColor);// Send gray -or- r g b
    (*tempptr->PSSendBoolean) (lppd, fGray);    // Send true -or- false

    // we use "save/restore" to print BITMAP. So, the color send here will
    // be restored.But the driver don't know that, because the "save/restore"
    // are sent from procset, not from driver.
    lppd->lpGSStack->lpgGState->bColorSpaceChanged = TRUE;

    (*tempptr->PSSendCRLF) (lppd);
    PSSendFragment (lppd, PSFRAG_bitmaskimage);

 // Changed to PSSendCRLF
 // 01-Feb-1993  -by-    [olegs]
 // .... and reverted back  26-Feb-1993  -by-  [olegs]

    (*tempptr->PSSendBitMapTerminator) (lppd);
//  (*tempptr->PSSendCRLF)(lppd);

    return (retval);
}
/*****************************************************************************/
/*                                                                           */
/*                           TBitmapData2                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* NOTE:                                                                     */
/*    Level 2 function for bitmap data output is different from              */
/*    the Level 1 function. In Level 2 we compress data, so all              */
/*    output goes first to one big buffer, and then this buffer              */
/*    is dumped to the compressor.                                           */
/*                                                                           */
/* Parameters:                                                               */
/*    LPPDEVICE lppd --                                                      */
/*    LPBITMAP DevBitmap --                                               */
/*    LPRECT DstRect --                                                      */
/*    SHORT FirstSegScans --                                                 */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL 
TBitmapData2 (LPPDEVICE lppd, LPBITMAP DevBitmap, LPRECT SrcRect,
              SHORT FirstSegScans)
{
    short retval;
    BYTE huge *lpBits;                  // Pointer to row of bytes in the
                                        // Bitmap
    BYTE huge *lpBuff;                  // Pointer to the beginning of the
                                        // buffer
    BYTE huge *lpData;                  // Pointer to the current position in
                                        // the buffer
    HANDLE h;                           // Handle to the allocated buffer

    WORD scans_this_seg;                // How many scan lines to output for
                                        // this
 // particular segment before switching to another
    WORD nCurrY;                        // Current y-coordinate
    WORD k;                             // Line counter
    WORD BMwidth;                       // Bitmap width in bytes
    WORD nBytes;                        // Number of bytes to output on each
                                        // line

    WORD scans;                         // How many scan lines to output

    WORD SrcX = SrcRect->left;          // Src rect dimensions
    WORD SrcY = SrcRect->top;           // "         "      "
    WORD SrcXE = SrcRect->right - SrcX;
    WORD SrcYE = SrcRect->bottom - SrcY;

    LPASCIIBINPTRS tempptr;
    tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;

    retval = TokenNeedsProcset (lppd, BITBLT);

    BMwidth = DevBitmap->bmWidthBytes;  // Bytes per row in bitmap

    nBytes = (SrcXE + 7) >> 3;
    scans = SrcYE;                      // Number of raster lines

 // Allocate the buffer to keep all pixels from the bitmap

    lpBuff = (BYTE huge *) MGAllocLock (lppd, (LPHANDLE) & h,
                              ((DWORD) nBytes * (DWORD) scans), GHND, TRUE);
    if (!lpBuff)
        return -1;

    if (DevBitmap->bmSegmentIndex)      // If huge bitmap
    {
        scans_this_seg = DevBitmap->bmScanSegment - (SrcY % DevBitmap->bmScanSegment);
    } else
    {
        scans_this_seg = SrcYE;
    }

    scans_this_seg = min (scans_this_seg, SrcYE);
    nCurrY = SrcY;                      // Assign the current Y value
    lpData = lpBuff;                    // Set up pointer at the beginning of
                                        // the buffer

    do
    {
        lpBits = (LPSTR) GetByteAddress (DevBitmap, SrcX, nCurrY);

 // Loop for every scan on current segment and output that scan
        for (k = 0; k < scans_this_seg; k++)
        {
            MemCopy (lpData, lpBits, (DWORD) nBytes);   // copy from bitmap to
                                                        // buffer
            lpBits += BMwidth;
            lpData += nBytes;           // Bump pointers and counter
            nCurrY++;
        }

        scans -= scans_this_seg;

        if (DevBitmap->bmSegmentIndex)  // If huge bitmap
        {
    // Figure out the number of scans for the remaining segments
            scans_this_seg = min (scans, DevBitmap->bmScanSegment);
        }
    } while (scans);

 // Buffer is ready - dump it to the compressor
    (*tempptr->PSSendBitMapDataLevel2) (lppd, lpBuff,
                                  (DWORD) ((DWORD) nBytes * (DWORD) SrcYE));
    MGUnlockFree (lppd, h, TRUE);

    (*tempptr->PSSendCRLF) (lppd);
    PSSendFragment (lppd, PSFRAG_endimage);
    (*tempptr->PSSendCRLF) (lppd);

    return (retval);
}
//**********************************************************************
//    Set of functions to deal with Device-Independent Bitmaps output
//    Send data in the following order:
//              Header
//              Operator
//              Data
//    Added DIB Level2 functions  on 28-Jan-1993  -by-   [olegs]
//**********************************************************************

/*****************************************************************************/
/*                                                                           */
/*                           TDIBHeader2                                     */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPPDEVICE lppd --                                                      */
/*    LPRECT SrcRect --                                                      */
/*    LPRECT DstRect --                                                      */
/*    SHORT BitsPerSample --                                                 */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

// L3_MASK FAST_IMAGE
//short FAR PASCAL TDIBHeader2( LPPDEVICE lppd, LPRECT SrcRect, LPRECT DstRect,
//                              short BitsPerSample, BOOL bCMYK)
short FAR PASCAL 
TDIBHeader2 (LPPDEVICE lppd, LPDRAWMODE lpdm, LPRECT SrcRect,
             LPRECT DstRect, BOOL bCMYK,
             LPBITMAPINFO lpBitmapInfo, SHORT FastImgType,
             float far * ResampleRatio)
{
    LPASCIIBINPTRS tempptr;
    short retval;

    FLAG Polarity = TRUE;
    int byte_width;
    int BppOutput;

    int SrcX = SrcRect->left;           // Src rect dimensions
    int SrcY = SrcRect->top;            // "         "      "
    int SrcXE = SrcRect->right - SrcX;  // "         "      "
    int SrcYE = SrcRect->bottom - SrcY; // "         "      "

    int DestX = DstRect->left;          // Dest rect dimensions
    int DestY = DstRect->top;           // "         "      "
    int DestXE = DstRect->right - DestX;// "         "      "
    int DestYE = DstRect->bottom - DestY;   // "         "      "

 // L3_MASK
    SHORT BitsPerSample = (SHORT) (lpBitmapInfo->bmiHeader.biBitCount);
    tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;

    retval = TokenNeedsProcset (lppd, DIB);

 // If the user has selected no color and a 24 bit DIB is being
 // printed then the 24 bit DIB is converted to an 8 bit DIB.

 // FAST_IMAGE
    if (FastImgType != 0)
    {
        if (BitsPerSample >= 16)
            BitsPerSample = 8;
        if (FastImgType & RESAMPLE)
        {
            if (SrcXE > 0)
                SrcXE = (int)ABS(DestXE / ResampleRatio[0]);
            else
                SrcXE = -(int)ABS(DestXE / ResampleRatio[0]);
            if (SrcYE > 0)
                SrcYE = (int)ABS(DestYE / ResampleRatio[1]);
            else
                SrcYE = -(int)ABS(DestYE / ResampleRatio[1]);
        }
    }
    BppOutput = BitsPerSample;

    if ((BitsPerSample == 24) || (BitsPerSample == 16) || (BitsPerSample == 32))
    {
        if ((lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT) || bCMYK)
        {
            byte_width = 4 * SrcXE;
            BppOutput = 32;
        } else
        {
            byte_width = 3 * SrcXE;
            BppOutput = 24;
        }
    } else
    {
        byte_width = (SrcXE + (8 / BitsPerSample) - 1) / (8 / BitsPerSample);
    }

    (*tempptr->PSSendShort) (lppd, SrcXE);  // Src width in pixels
    (*tempptr->PSSendShort) (lppd, SrcYE);  // Src height in scanlines
    (*tempptr->PSSendShort) (lppd, BppOutput);  // Bits per sample -
                                                // 4,8,24,32
    (*tempptr->PSSendShort) (lppd, byte_width); // Src bytes per scanline
    (*tempptr->PSSendShort) (lppd, DestXE); // Dest width
    (*tempptr->PSSendShort) (lppd, -DestYE);    // Dest height
    (*tempptr->PSSendShort) (lppd, DestX);  // Dest origin - x (left)
    (*tempptr->PSSendShort) (lppd, DestY + DestYE); // Dest origin - y
                                                    // (bottom)
    (*tempptr->PSSendBoolean) (lppd, FALSE);    // Smoothflag
    (*tempptr->PSSendBoolean) (lppd, Polarity); // Polarity

 // L3_MASK
    if ((lpdm->bkMode == TRANSPARENT) &&
        (lppd->lpPSExtDevmode->dm.bL3MaskedImage) &&       
        (lppd->lpPSExtDevmode->dm2.useLanguageLevel > 2))
    {
        (*tempptr->PSSendBoolean) (lppd, TRUE); // Masked image
    } else
    {
        (*tempptr->PSSendBoolean) (lppd, FALSE);    // Masked image
    }

 // If 24-bit bitmap - use no compression
 // 01-Feb-1993    -by-   [olegs]

    if (((BitsPerSample == 24) | (BitsPerSample == 16) || (BitsPerSample == 32)) &&
        (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR))
    {
        (*tempptr->PSSendBitMapType) (lppd, PPSLEVEL1); // Data type
    } else
    {
        (*tempptr->PSSendBitMapType) (lppd, PPSLEVEL2); // Data type
    }

    (*tempptr->PSSendCRLF) (lppd);
    PSSendFragment (lppd, PSFRAG_beginimage);

 // L3_MASK begin
 // Output background color
    if ((lpdm->bkMode == TRANSPARENT) &&
        (lppd->lpPSExtDevmode->dm.bL3MaskedImage) &&       
        (lppd->lpPSExtDevmode->dm2.useLanguageLevel > 2))
    {
        RGBQUAD Color;
        DWORD ICMPixelFormatIn, ICMPixelFormatOut;
        BYTE pBufIn[4], pBufOut[4];
        LPICMINFO lpICMI;
 // Get background color
        if ((lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_DIB_IN) || bCMYK)
        {
    // Get CMYK background color
    // Need more test. bkColor is CMYK or RGB?
            Color.rgbRed = ((BYTE) (lpdm->bkColor));            // GetCValue
            Color.rgbGreen = ((BYTE) ((lpdm->bkColor) >> 8));   // GetMValue
            Color.rgbBlue = ((BYTE) ((lpdm->bkColor) >> 16));   // GetYValue
            Color.rgbReserved = ((BYTE) ((lpdm->bkColor) >> 24));   // GetKValue
        } else
        {
    // Get RGB background color
            Color.rgbBlue = GetBValue ((DWORD) (lpdm->bkColor));
            Color.rgbGreen = GetGValue ((DWORD) (lpdm->bkColor));
            Color.rgbRed = GetRValue ((DWORD) (lpdm->bkColor));
            if (BitsPerSample == 16)
            {
                Color.rgbBlue = Color.rgbBlue & 0xF8;
                Color.rgbRed = Color.rgbRed & 0xF8;
                if ((lpBitmapInfo->bmiHeader.biCompression == BI_BITFIELDS) &&
                    (((BITMAPV4HEADER FAR *) lpBitmapInfo)->bV4GreenMask == 0x7e0))
                {
            // RGB565
                    Color.rgbGreen = Color.rgbGreen & 0xFC;
                } else
                {
            // RGB555
                    Color.rgbGreen = Color.rgbGreen & 0xF8;
                }
            }
        }

        PSSendString (lppd, SPACE);

        if (lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM)
            lpICMI = (LPICMINFO) GlobalLock ((HANDLE) lppd->graphics.hCMTransform);

 // Output back ground color
        if ((BitsPerSample == 32) &&
        ((lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_DIB_IN) || bCMYK))
        {
    // Output 32-bit CMYK color
            if (!(lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM))
            {
                (*tempptr->PSSendShort) (lppd, Color.rgbRed);
                (*tempptr->PSSendShort) (lppd, Color.rgbGreen);
                (*tempptr->PSSendShort) (lppd, Color.rgbBlue);
                (*tempptr->PSSendShort) (lppd, Color.rgbReserved);
            } else
            {
                ICMPixelFormatIn = CMS_QUADS;
                if (lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT)
                    ICMPixelFormatOut = CMS_QUADS;
                else
                    ICMPixelFormatOut = CMS_RGBTRIPLETS;

                pBufIn[0] = Color.rgbReserved;
                pBufIn[1] = Color.rgbRed;
                pBufIn[2] = Color.rgbGreen;
                pBufIn[3] = Color.rgbBlue;

                ICMTranslateRGBs (lpICMI->hICMT,
                                  (LPVOID) pBufIn, ICMPixelFormatIn, 1, 1, 4,
                          (LPVOID) pBufOut, ICMPixelFormatOut, CMS_FORWARD);

                (*tempptr->PSSendShort) (lppd, pBufOut[3]);
                (*tempptr->PSSendShort) (lppd, pBufOut[2]);
                (*tempptr->PSSendShort) (lppd, pBufOut[1]);
                (*tempptr->PSSendShort) (lppd, pBufOut[0]);
            }
        } else if ((BitsPerSample == 32) || (BitsPerSample == 24) || (BitsPerSample == 16))
        {
    // Output 24-bit RGB color
            if (!(lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM))
            {
                (*tempptr->PSSendShort) (lppd, Color.rgbRed);
                (*tempptr->PSSendShort) (lppd, Color.rgbGreen);
                (*tempptr->PSSendShort) (lppd, Color.rgbBlue);
            } else
            {
                if (lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT)
                    ICMPixelFormatOut = CMS_QUADS;
                else
                    ICMPixelFormatOut = CMS_RGBTRIPLETS;
                ICMPixelFormatIn = CMS_RGBTRIPLETS;

                pBufIn[0] = Color.rgbRed;
                pBufIn[1] = Color.rgbGreen;
                pBufIn[2] = Color.rgbBlue;

                ICMTranslateRGBs (lpICMI->hICMT,
                                  (LPVOID) pBufIn, ICMPixelFormatIn, 1, 1, 4,
                          (LPVOID) pBufOut, ICMPixelFormatOut, CMS_FORWARD);

                (*tempptr->PSSendShort) (lppd, pBufOut[3]);
                (*tempptr->PSSendShort) (lppd, pBufOut[2]);
                (*tempptr->PSSendShort) (lppd, pBufOut[1]);
                (*tempptr->PSSendShort) (lppd, pBufOut[0]);
            }
        }
 // FAST_IMAGE
        else if (FastImgType != 0)
        {
    // Output 8-bit or 4-bit Gray
            BYTE bGray;
            if ((lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_DIB_IN) || bCMYK)
            {
        // CMYK to Gray
        // Convert CMYK into RGB components - see RedBook p.307
                Color.rgbRed = 255 - min (255, (Color.rgbReserved + Color.rgbRed));
                Color.rgbGreen = 255 - min (255, (Color.rgbReserved + Color.rgbGreen));
                Color.rgbBlue = 255 - min (255, (Color.rgbReserved + Color.rgbBlue));
            }
            bGray = INTENSITY (Color.rgbRed, Color.rgbGreen, Color.rgbBlue);
            if (BitsPerSample == 4)
                bGray = bGray >> 4;
            (*tempptr->PSSendShort) (lppd, bGray);
        } else
        {
    // Output Indexed color
            LPRGBQUAD lppal = (LPRGBQUAD) ((LPSTR) lpBitmapInfo +
                                           lpBitmapInfo->bmiHeader.biSize);
            int iTableLen = (1 << BitsPerSample);
            int i, iColorIdx;
            iColorIdx = iTableLen - 1;
            if ((lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_DIB_IN) || bCMYK)
            {
        // CMYK color table
                for (i = 0; i < iTableLen; i++)
                {
                    if ((lppal[i].rgbBlue == Color.rgbBlue) &&
                        (lppal[i].rgbGreen == Color.rgbGreen) &&
                        (lppal[i].rgbRed == Color.rgbRed) &&
                        (lppal[i].rgbReserved == Color.rgbReserved))
                    {
                        iColorIdx = i;
                        break;
                    }
                }
            } else
            {
        // RGB color table
                for (i = 0; i < iTableLen; i++)
                {
                    if ((lppal[i].rgbBlue == Color.rgbBlue) &&
                        (lppal[i].rgbGreen == Color.rgbGreen) &&
                        (lppal[i].rgbRed == Color.rgbRed))
                    {
                        iColorIdx = i;
                        break;
                    }
                }
            }
            (*tempptr->PSSendShort) (lppd, iColorIdx);
        }
        if (lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM)
        {
            GlobalUnlock ((HANDLE) lppd->graphics.hCMTransform);
        }
    }
 // L3_MASK End

    (*tempptr->PSSendCRLF) (lppd);

    return (retval);
}
/*****************************************************************************/
/*                                                                           */
/*                           TDIBOperator2                                   */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*    LPPDEVICE lppd --                                                      */
/*    SHORT BitsPerSample --                                                 */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/

short FAR PASCAL 
TDIBOperator2 (LPPDEVICE lppd, short BitsPerSample,
               SHORT FastImgType)
{
    short retval;
    LPASCIIBINPTRS tempptr;
    tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;

    retval = TokenNeedsProcset (lppd, DIB);
 // why no rledecode as in level 1? dnw
    switch (BitsPerSample)
    {
        case 1:
        case 16:
        case 24:
        case 32:
            if ((lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT) ||
                (lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_DIB_IN))
            {
        // Fix bug 160292.  jjia    8/14/96
                if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR)
                    PSSendFragment (lppd, PSFRAG_doCMYKimage);
                else
                    PSSendFragment (lppd, PSFRAG_doNimage);
            } else
            {
                PSSendFragment (lppd, PSFRAG_doNimage);
            }
            break;

        case 4:
        case 8:
    // FAST_IMAGE
            if (FastImgType & INDEXCOLORTOGRAY)
                PSSendFragment (lppd, PSFRAG_doNimage);
            else if (lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT)
                PSSendFragment (lppd, PSFRAG_doCMYKclutimage);
            else
                PSSendFragment (lppd, PSFRAG_doclutimage);
            break;
    }

    (*tempptr->PSSendBitMapTerminator) (lppd);
//  (*tempptr->PSSendCRLF)(lppd);

    return (retval);
}
// FAST_IMAGE begin
/*****************************************************************************/
/*                              Resampling                                   */
/* Purpose: Fast image support.                                              */
/* this path does resampling.                                                */
/*   dictionary of local variables:                                          */
/*    sr  - 'source row': current row (fixed point) in source space          */
/*    sc  - 'source column': current column (fixed point) in source space    */
/*    dr  - 'delta row': fixed point increment in source space for 1 pixel   */
/*		difference from top to bottom in destination space                   */
/*    dc  - 'delta column': fixed point increment in source space for 1 pixel*/
/*		difference from left to right in destination space                   */
/*    lc  - 'left column': leftmost source column actually used              */
/*    r	  - current destination row number                                   */
/*    c   - current destination column                                       */
/*    or  - 'old row': the source row number of the previous raster output   */
/*    oc  - 'old column': the source column of the previous sample output    */
/*    lw  - width of source raster, in bytes                                 */
/*    lo  - beginning of current line of source                              */
/*    sp  - current source sample                                            */
/* Returns: None                                                             */
/*****************************************************************************/

VOID 
Resampling_8Bit_A (LPPDEVICE lppd, BYTE huge * lpBitBuf, BYTE huge * lpNewBitBuf,
                 WORD SrcXE, WORD SrcYE, WORD DstXE, WORD DstYE, DWORD ScanWidth)
{
    DWORD sr, dr, dc, lc;
    WORD r, c;
    BYTE huge *sp;
    BYTE huge *sp1;
    BYTE huge *CurSrcLine;

    DWORD dwLeft, dwTop;
    DWORD dwLT, dwRT, dwLB, dwRB;
    DWORD dwNewColor;
    WORD  wTopRect, wBottomRect;
    WORD  wLeftPix, wTopPix;
    WORD  wLeftOff, wTopOff;
    WORD  wTopOff_m;

    dr = (((DWORD) SrcYE) << 16) / DstYE;
    dc = (((DWORD) SrcXE) << 16) / DstXE;
    sr = dr >> 1, lc = dc >> 1;

    dwTop = sr - 0x7FFF; 
    for (r = 0; r < DstYE; r++)
    {
        wTopOff = (WORD)dwTop;
        wTopOff_m = 0xFFFF - wTopOff;
        wTopPix = (WORD)(dwTop >> 16);
        if ((wTopPix + 1) >= SrcYE)
            wTopPix = SrcYE - 2;
        CurSrcLine = lpBitBuf + wTopPix * ScanWidth;
        dwLeft   = lc - 0x7FFF;
        wTopRect = (WORD)(((DWORD)wTopOff_m * 0xFFFF) >> 16);
        wBottomRect = 0xFFFF - wTopRect;
        for (c = 0; c < DstXE; c++)
        {
            wLeftOff = (WORD)dwLeft;
            wLeftPix = (WORD)(dwLeft >> 16);

            sp = CurSrcLine + wLeftPix;
            sp1 = sp + ScanWidth;

            dwRT = ((DWORD)wLeftOff   * wTopOff_m) >> 16;
            dwRB = ((DWORD)wLeftOff   * wTopOff  ) >> 16;
            dwLT = (DWORD)wTopRect    - dwRT;
            dwLB = (DWORD)wBottomRect - dwRB;

            dwNewColor = (dwLT *  *sp++  +
                          dwRT *  *sp    +
                          dwLB *  *sp1++ +
                          dwRB *  *sp1
                         ) >> 16;
            *lpNewBitBuf++ = (BYTE)dwNewColor;
            dwLeft += dc;
        }
        dwTop += dr;
    }
}

/***************************************************************************/

VOID 
Resampling_8Bit (LPPDEVICE lppd, BYTE huge * lpBitBuf, BYTE huge * lpNewBitBuf,
                 WORD SrcXE, WORD SrcYE, WORD DstXE, WORD DstYE, DWORD ScanWidth)
{
    DWORD sr, sc, dr, dc, lc;
    WORD r, c, or, oc, lw;
    BYTE huge *lo;
    BYTE huge *sp;
    or = oc = 0;
    lo = lpBitBuf;

    dr = (((DWORD) SrcYE) << 16) / DstYE;
    dc = (((DWORD) SrcXE) << 16) / DstXE;
    sr = dr >> 1, lc = dc >> 1;
    lw = (WORD)ScanWidth;
    lo += (lc >> 16);

    for (r = 0; r < DstYE; r++, sr += dr)
    {
        if ((sr >> 16) > or)            /* new source row? */
        {
            lo += lw * ((sr >> 16) - or);
            or = (WORD) (sr >> 16);
        }
        sp = lo;
        sc = lc, oc = (WORD) (lc >> 16);
        for (c = 0; c < DstXE; c++, sc += dc)
        {
            if ((sc >> 16) > oc)        /* new source column? */
            {
                sp += ((sc >> 16) - oc);
                oc = (WORD) (sc >> 16);
            }
            *lpNewBitBuf++ = *sp;
        }
    }
}

/*****************************************************************************/

VOID 
Resampling_4Bit (LPPDEVICE lppd, BYTE huge * lpBitBuf, BYTE huge * lpNewBitBuf,
                 WORD SrcXE, WORD SrcYE, WORD DstXE, WORD DstYE, DWORD ScanWidth)
{
    DWORD sr, sc, dr, dc, lc;
    WORD r, c, or, oc, lw, olw;
    BYTE huge *lo;
    BYTE huge *sp;
    BYTE huge *lpDstLine = lpNewBitBuf;
    WORD wInPixPos = 0, wOutPixPos = 0;
    or = oc = 0;
    lo = lpBitBuf;

    dr = (((DWORD) SrcYE) << 16) / DstYE;
    dc = (((DWORD) SrcXE) << 16) / DstXE;
    sr = dr >> 1, lc = dc >> 1;
    lw = (WORD)ScanWidth;             // bytes per line (Source image).
    olw = (DstXE + 1) / 2;            // bytes per line (Destination image).

    lo += (lc >> 16) / 2 ;            // Move to start byte in the line.
    wInPixPos = (WORD)(((lc >> 16) % 2) * 4);
                                      // Find the right position in the byte.

    for (r = 0; r < DstYE; r++, sr += dr)
    {
        if ((sr >> 16) > or)            /* new source row? */
        {
            lo += lw * ((sr >> 16) - or);
            or = (WORD) (sr >> 16);
            lpDstLine = lpNewBitBuf + ((DWORD) r) * ((DWORD) olw);
            wInPixPos = (WORD)(((lc >> 16) % 2) * 4);
            wOutPixPos = 0;
        }
        sp = lo;
        sc = lc, oc = (WORD) (lc >> 16);
        for (c = 0; c < DstXE; c++, sc += dc)
        {
            if ((sc >> 16) > oc)        /* new source column? */
            {
                oc = (WORD) (sc >> 16);
                sp = lo + (oc / 2);     // Find right byte.
                wInPixPos = (WORD) (oc % 2) * 4;    // Find right position in
                                                    // the byte;
            }
            (*lpDstLine) = (*lpDstLine) & (0x0F << (wOutPixPos));   // Clearn old bits
            (*lpDstLine) += (((*sp) >> (4 - wInPixPos)) & 0x0F) << (4 - wOutPixPos);
            wOutPixPos = (wOutPixPos + 4) % 8;
            if (wOutPixPos == 0)
                lpDstLine++;
        }
    }
}
/***************************************************************************/

VOID 
ResampleAndSend (LPPDEVICE lppd, BYTE huge * lpBitBuf, LPRECT DstRect,
                 WORD SrcXE, WORD SrcYE, WORD BitCount, DWORD ScanWidth,
                 float far * ResampleRatio)
{
    HANDLE hResample;
    BYTE huge *lpNewBitBuf;
    WORD nDstBytes;
    WORD DstXE = (WORD)(ABS(DstRect->right - DstRect->left) / ResampleRatio[0]);
    WORD DstYE = (WORD)(ABS(DstRect->bottom - DstRect->top) / ResampleRatio[1]);
    LPASCIIBINPTRS tempptr;
    tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;
    nDstBytes = (DstXE + (8 / BitCount) - 1) / (8 / BitCount);
    lpNewBitBuf = (BYTE huge *) MGAllocLock (lppd, (LPHANDLE) & hResample,
                   (DWORD) ((DWORD) nDstBytes * (DWORD) DstYE), GHND, TRUE);

    if (BitCount == 4)
    {
        if (lpNewBitBuf)
        {
            Resampling_4Bit (lppd, lpBitBuf, lpNewBitBuf,
                             SrcXE, SrcYE, DstXE, DstYE, ScanWidth);
            (*tempptr->PSSendBitMapDataLevel2) (lppd, lpNewBitBuf,
                                         (DWORD) nDstBytes * (DWORD) DstYE);
            MGUnlockFree (lppd, hResample, TRUE);
        } else
        {
            Resampling_4Bit (lppd, lpBitBuf, lpBitBuf,
                             SrcXE, SrcYE, DstXE, DstYE, ScanWidth);
            (*tempptr->PSSendBitMapDataLevel2) (lppd, lpBitBuf,
                                         (DWORD) nDstBytes * (DWORD) DstYE);
        }
    } else if (BitCount == 8)
    {
        BOOL  bAverage = FALSE;   // FALSE : simple resampling
                                  // TRUE  : average resampling
        if (((SrcXE % DstXE) > (DstXE >> 5)) ||
            ((SrcYE % DstYE) > (DstYE >> 5)))
            bAverage = TRUE;

        if (lpNewBitBuf)
        {
            if (bAverage)
            {
                Resampling_8Bit_A (lppd, lpBitBuf, lpNewBitBuf,
                             SrcXE, SrcYE, DstXE, DstYE, ScanWidth);
            }
            else
            {
                Resampling_8Bit (lppd, lpBitBuf, lpNewBitBuf,
                             SrcXE, SrcYE, DstXE, DstYE, ScanWidth);
            }
            (*tempptr->PSSendBitMapDataLevel2) (lppd, lpNewBitBuf,
                                         (DWORD) nDstBytes * (DWORD) DstYE);
            MGUnlockFree (lppd, hResample, TRUE);
        } else
        {
            if (bAverage)
            {
                Resampling_8Bit_A (lppd, lpBitBuf, lpBitBuf,
                             SrcXE, SrcYE, DstXE, DstYE, ScanWidth);
            }
            else
            {
                Resampling_8Bit (lppd, lpBitBuf, lpBitBuf,
                             SrcXE, SrcYE, DstXE, DstYE, ScanWidth);
            }

            (*tempptr->PSSendBitMapDataLevel2) (lppd, lpBitBuf,
                                         (DWORD) nDstBytes * (DWORD) DstYE);
        }
    }
}

/***************************************************************************/
VOID
IndexColorToGray (LPPDEVICE lppd, BYTE huge *lpBitBuf,
                  BYTE huge *lpLineStart, DWORD ScanWidth,
                  WORD nBytes, WORD SrcYE, WORD BitCount, LPSTR lpGrayTable)
{
    BYTE huge *lpBuf;
    BYTE huge *lpBits;
    WORD      i,k;
    WORD      wTemp;

    #ifdef TESTING
        tickCountStart = GetTickCount(); 
    #endif
    lpBuf = lpBitBuf;           // Point to start of buffer
    if (BitCount == 4)
    {
        BYTE t1, t2;
        for (i = 0; i < SrcYE; i++) // for all raster lines
        {
            lpBits = lpLineStart;   // move to first pixel
            for (k = 0; k < nBytes; k++)    // for all bytes in line
            {
                wTemp = *lpBits++;
                t1 = (BYTE) (lpGrayTable[wTemp >> BitCount]);
                t2 = (BYTE) (lpGrayTable[wTemp & 0x0F] >> BitCount);
                *lpBuf++ = (t1 & 0xF0) | (t2 & 0x0F);
            }
            lpLineStart += ScanWidth;   // Advance to next line
        }
    } else if (BitCount == 8)
    {
        for (i = 0; i < SrcYE; i++) // for all raster lines
        {
            lpBits = lpLineStart;   // move to first pixel
            for (k = 0; k < nBytes; k++)    // for all bytes in line
            {
                *lpBuf++ = lpGrayTable[*lpBits++];
            }
            lpLineStart += ScanWidth;   // Advance to next line
        }
    }
    #ifdef TESTING
        tickCountEnd = GetTickCount(); 
        wsprintf(tempbuf,"");
        wsprintf(tempbuf, "Total Time :  %u\n",(tickCountEnd-tickCountStart));  
        if(OpenFile(OutputFile, (LPOFSTRUCT) &ofFS, OF_EXIST) != HFILE_ERROR)
        {
            hFile = OpenFile(OutputFile, (LPOFSTRUCT) &ofFS, OF_WRITE);
            if (_llseek(hFile, 0, SEEK_END) == -1)
            {
                MessageBox(NULL,"Cannot read file c:\\Timelog.txt", NULL, MB_ICONHAND|MB_OK);
                goto end;
            }
        }
        else
            hFile = OpenFile(OutputFile, (LPOFSTRUCT) &ofFS, OF_WRITE|OF_CREATE);
        bufSize = lstrlen(tempbuf);   
        if ( _lwrite(hFile, tempbuf, bufSize) != (UINT) bufSize)
            MessageBox(NULL,"Cannot write data to file c:\\Timelog.txt", NULL, MB_ICONHAND|MB_OK);
        wsprintf(tempbuf,"");
        bufSize = lstrlen(tempbuf);   
        _lwrite(hFile, tempbuf, bufSize);
        _lclose(hFile);
        end:
        ;
    #endif
}
// FAST_IMAGE end

/*****************************************************************************/
/*                                                                           */
/*                              TDIBDataBits2                                */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPDEVICE lppd --                                                       */
/*   LPRECT SrcRect --                                                       */
/*   LPSTR lpDataBits --                                                     */
/*   LPBITMAPINFO lpBitmapInfo --                                            */
/*                                                                           */
/* Returns: short                                                            */
/*****************************************************************************/
// L3_MASK  FAST_IMAGE
short FAR PASCAL 
TDIBDataBits2 (LPPDEVICE lppd, LPDRAWMODE lpdm,
               LPRECT SrcRect, LPRECT DstRect,
               LPSTR lpDataBits, LPBITMAPINFO lpBitmapInfo,
               LPSTR lpGrayTable, SHORT FastImgType,
               float far * ResampleRatio)
{
    DWORD ScanWidth;
    WORD nBytes;                        // Number of bytes to output on one
                                        // line
    HANDLE h;
    BYTE huge *lpLineStart;             // Start of the 1st line in DIB
    BYTE huge *lpBits;                  // Working pointer in DIB bits
    WORD huge *lpBits16;                // Working pointer in DIB bits
    BYTE huge *lpBitBuf;                // Pointer to the beginning of the
                                        // buffer
    BYTE huge *lpBuf;                   // Working pointer in the buffer
    BYTE Red, Green, Blue;
    BYTE Cyan, Magenta, Yellow, Black;
    WORD i, k, BytesPerPixel, wTemp;
    BYTE bRet;
    DWORD ICMInputScanWidth,ICMOutputScanWidth;              // 247974
    DWORD OutputScanWidth;         
    DWORD ICMPixelFormatIn, ICMPixelFormatOut;

    WORD SrcX = SrcRect->left;
    WORD SrcY = SrcRect->top;
    WORD SrcXE = SrcRect->right - SrcX;
    WORD SrcYE = SrcRect->bottom - SrcY;
    LPICMINFO lpICMI;

    WORD PixelFormat = 0;
    WORD BitCount = lpBitmapInfo->bmiHeader.biBitCount;
    DWORD Height = (DWORD) lpBitmapInfo->bmiHeader.biHeight;
    DWORD Width = (DWORD) lpBitmapInfo->bmiHeader.biWidth;
 // L3_MASK
    BOOL bColor2GrayTrans = FALSE;
    RGBQUAD BGColor;
    BYTE bBGGray;
    BYTE bGray;

    short retval;
    LPASCIIBINPTRS tempptr;
    tempptr = (LPASCIIBINPTRS) lppd->lpAsciiBinPtr;

    retval = TokenNeedsProcset (lppd, DIB);


// ScanWidth is the width of one scan line. DIB scanlines are
// multiples of DWORDs.
//
// 1.  Width[pixels] * BitCount[bits/pixel]	  => Total # bits in image line
// 2.  Width * BitCount + 31[bits]		  => Round up to DWORD boundary
// 3. (Width * BitCount + 31)/32[bits/DWORD]	  => Total number of DWORDS
// 4.((Width * BitCount + 31)/32) * 4[byts/DWORD] => Total # bytes in a line

    ScanWidth = ((Width * BitCount + 31) / 32) * 4;

    if ((ScanWidth == 0) || (lpDataBits == NULL))
    {
        return (RC_fail);
    }
    lpLineStart = (BYTE huge *) lpDataBits; // Beginning of the buffer
    lpLineStart = lpLineStart + ScanWidth * SrcY;   // Move to proper raster[
                                                    // in bytes]

    if ((BitCount == 1) || (BitCount == 4) || (BitCount == 8))
    {
        lpLineStart = lpLineStart + SrcX / (8 / BitCount);  // Move to proper pixel

        nBytes = (SrcXE + (8 / BitCount) - 1) / (8 / BitCount);

 // The bitmap output algorithm was changed - in Level1 the bitmap
 // is sent on line-by-line basis. It's OK if there is no
 // compression, but it's wrong when there is one. So for Level2
 // bitmaps output bytes are placed in buffer and then sent as one block.
 // Changed on 28-Jan-1993  -by-  [olegs]

 // Allocate buffer to keep all output data
        lpBitBuf = (BYTE huge *) MGAllocLock (lppd, (LPHANDLE) & h,
                                   (DWORD) ((DWORD) nBytes * (DWORD) SrcYE),
                                              GHND, TRUE);
        if (!lpBitBuf)
            return -1;

 // FASE_IMAGE Copy indexed color image to output buffer.
        if (!(FastImgType & INDEXCOLORTOGRAY))
        {
            lpBuf = lpBitBuf;           // Point to start of buffer
            for (i = 0; i < SrcYE; i++) // for all raster lines
            {
                lpBits = lpLineStart;   // move to first pixel
                for (k = 0; k < nBytes; k++)    // for all bytes in line
                {
                    *lpBuf++ = *lpBits++;   // get byte and place in buffer
                }
                lpLineStart += ScanWidth;   // Advance to next line
            }
        }
 // FAST_IMAGE  Convert indexed color to 4-bit or 8-bit gray.
        else
        {
            IndexColorToGray (lppd, lpBitBuf, lpLineStart, ScanWidth,
                            nBytes, SrcYE, BitCount, lpGrayTable);
        }
 // FAST_IMAGE  Resampling
        if (FastImgType & RESAMPLE)
            ResampleAndSend (lppd, lpBitBuf, DstRect, SrcXE, SrcYE,
                             BitCount, nBytes, ResampleRatio);
        else
            (*tempptr->PSSendBitMapDataLevel2) (lppd, lpBitBuf, nBytes * (DWORD) SrcYE);

        MGUnlockFree (lppd, h, TRUE);
    }
 // If here then we have a 16, 24, or 32 bpp dib.

    else
    {
        if (lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM)
        {
            lpICMI = (LPICMINFO) GlobalLock ((HANDLE) lppd->graphics.hCMTransform);
        }
 // L3_MASK
        if ((lpdm->bkMode == TRANSPARENT) &&
            (lppd->lpPSExtDevmode->dm.bL3MaskedImage) &&       
            (lppd->lpPSExtDevmode->dm2.useLanguageLevel > 2) &&
            (FastImgType & COLORTOGRAY))
            bColor2GrayTrans = TRUE;

        if (BitCount == 16)
        {
            if (lpBitmapInfo->bmiHeader.biCompression == BI_BITFIELDS)
            {
                if (((BITMAPV4HEADER FAR *) lpBitmapInfo)->bV4GreenMask == 0x7E0)
                    PixelFormat = 1;
            }
    // L3_MASK  Get Background color.
            if (bColor2GrayTrans)
            {
                BGColor.rgbRed = GetRValue ((DWORD) (lpdm->bkColor)) & 0xF8;
                BGColor.rgbBlue = GetBValue ((DWORD) (lpdm->bkColor)) & 0xF8;
                if (PixelFormat)
                    BGColor.rgbGreen = GetGValue ((DWORD) (lpdm->bkColor)) & 0xFC;
                else
                    BGColor.rgbGreen = GetGValue ((DWORD) (lpdm->bkColor)) & 0xF8;
                bBGGray = INTENSITY (BGColor.rgbRed, BGColor.rgbGreen, BGColor.rgbBlue);
            }
            if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR)
            {
                if (lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT)
                {
                    BytesPerPixel = 4;
                    ICMPixelFormatIn = CMS_XRGBQUADS;
                    ICMPixelFormatOut = CMS_QUADS;
                } else
                {
                    BytesPerPixel = 3;
                    ICMPixelFormatIn = CMS_RGBTRIPLETS;
                    ICMPixelFormatOut = CMS_BGRTRIPLETS;  // 247974 output BGR not RGB.
                }
                ICMInputScanWidth = ((Width * BytesPerPixel + 3) / 4) * 4;
            } else
            {
                BytesPerPixel = 1;
            }

            ICMOutputScanWidth =  ((BytesPerPixel * (DWORD) SrcXE + 3) / 4) * 4;    // 247974
            lpBitBuf = (BYTE huge *) MGAllocLock (lppd, (LPHANDLE) & h,
                    (DWORD) (ICMOutputScanWidth * (DWORD) SrcYE), GHND, TRUE);

            if (!lpBitBuf)
                return -1;

            lpLineStart = lpLineStart + 2 * SrcX;   // Move to proper pixel -
                                                    // 2 bytes per pixel

            lpBuf = lpBitBuf;           // Point to start of buffer

            for (i = 0; i < SrcYE; i++)
            {
                lpBits16 = (WORD huge *) lpLineStart;   // Point to first pixel
                for (k = 0; k < SrcXE; k++) // for all pixels in line
                {                       // at 2 bytes per pixel
                    wTemp = *lpBits16++;
                    if (!PixelFormat)
                    {
                        Blue = (BYTE) (wTemp << 3) & 0xF8;
                        Green = (BYTE) (wTemp >> 2) & 0xF8;
                        Red = (BYTE) (wTemp >> 7) & 0xF8;
                    } else
                    {
                        Blue = (BYTE) (wTemp << 3) & 0xF8;
                        Green = (BYTE) (wTemp >> 3) & 0xFC;
                        Red = (BYTE) (wTemp >> 8) & 0xF8;
                    }

                    if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR)
                    {
                        if (!(lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM))
                        {
                            *lpBuf++ = Red;
                            *lpBuf++ = Green;
                            *lpBuf++ = Blue;
                        } else
                        {
                            *lpBuf++ = Blue;
                            *lpBuf++ = Green;
                            *lpBuf++ = Red;
                        }
                        if (lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT)
                        {
                            *lpBuf++ = 0;
                        }
                    } else
                    {
                // L3_MASK
                // *lpBuf++ = INTENSITY(Red,Green,Blue); // Convert color to
                // grayscale
                        bGray = INTENSITY (Red, Green, Blue);   // Convert color to
                                                                // grayscale
                        if ((bColor2GrayTrans) && (bGray == bBGGray) &&
                            (BGColor.rgbRed != Red ||
                             BGColor.rgbGreen != Green ||
                             BGColor.rgbBlue != Blue))
                        {
                            if (bGray > 0)
                                bGray--;
                            else
                                bGray++;
                        }
                        *lpBuf++ = bGray;

                    }
                }
                lpLineStart += ScanWidth;

                // 247974
                if ((lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR) &&
                    (lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM) &&
                    !(lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT))
                {
                    lpBuf += (ICMOutputScanWidth - (BytesPerPixel * (DWORD) SrcXE));
                }
            }
            lpBuf = lpBitBuf;
        } else if (BitCount == 24)
        {
            if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR)
            {
                if (lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT)
                {
                    BytesPerPixel = 4;
                    ICMPixelFormatOut = CMS_QUADS;
                } else
                {
                    BytesPerPixel = 3;
                    ICMPixelFormatOut = CMS_BGRTRIPLETS;    // 247974 output BGR not RGB.
                }
                ICMInputScanWidth = ((Width * 3 + 3) / 4) * 4;
                ICMPixelFormatIn = CMS_RGBTRIPLETS;
            } else
            {
                BytesPerPixel = 1;
            }

    // L3_MASK  Get Background color.
            if (bColor2GrayTrans)
            {
                BGColor.rgbRed = GetRValue ((DWORD) (lpdm->bkColor));
                BGColor.rgbGreen = GetGValue ((DWORD) (lpdm->bkColor));
                BGColor.rgbBlue = GetBValue ((DWORD) (lpdm->bkColor));
                bBGGray = INTENSITY (BGColor.rgbRed, BGColor.rgbGreen, BGColor.rgbBlue);
            }

            ICMOutputScanWidth = ((BytesPerPixel * (DWORD) SrcXE + 3) / 4) * 4; // 247974
            lpBitBuf = (BYTE huge *) MGAllocLock (lppd, (LPHANDLE) & h,
                    (DWORD) (ICMOutputScanWidth * (DWORD) SrcYE), GHND, TRUE);

            if (!lpBitBuf)
                return -1;

            lpLineStart = lpLineStart + 3 * SrcX;   // Move to proper pixel -
                                                    // 3 bytes per pixel

            lpBuf = lpBitBuf;           // Point to start of buffer
            for (i = 0; i < SrcYE; i++)
            {
                lpBits = lpLineStart;   // Point to first pixel
                for (k = 0; k < SrcXE; k++) // for all pixels in line
                {                       // at 3 bytes per pixel
                    Blue = *lpBits++;
                    Green = *lpBits++;
                    Red = *lpBits++;

                    if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR)
                    {
                        if (!(lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM))
                        {
                            *lpBuf++ = Red;
                            *lpBuf++ = Green;
                            *lpBuf++ = Blue;
                        }
                    } else
                    {
                // L3_MASK
                // *lpBuf++ = INTENSITY(Red,Green,Blue); // Convert color to
                // grayscale
                        bGray = INTENSITY (Red, Green, Blue);   // Convert color to
                                                                // grayscale
                        if ((bColor2GrayTrans) && (bGray == bBGGray) &&
                            (BGColor.rgbRed != Red ||
                             BGColor.rgbGreen != Green ||
                             BGColor.rgbBlue != Blue))
                        {
                            if (bGray > 0)
                                bGray--;
                            else
                                bGray++;
                        }
                        *lpBuf++ = bGray;

                    }
                }
                lpLineStart += ScanWidth;
            }
            lpBuf = lpDataBits;
        } else if (BitCount == 32)
        {
            if (lpBitmapInfo->bmiHeader.biCompression == BI_BITFIELDS)
            {
                if (((BITMAPV4HEADER FAR *) lpBitmapInfo)->bV4BlueMask != 0xFF)
                    PixelFormat = 1;
            }
    // L3_MASK  Get Background color.
            if (bColor2GrayTrans)
            {
        // We assume the background color is always RGB. (more test needed)
                if (PixelFormat)
                {
                    BGColor.rgbRed = ((BYTE) (lpdm->bkColor));  // GetCValue
                    BGColor.rgbGreen = ((BYTE) ((lpdm->bkColor) >> 8)); // GetMValue
                    BGColor.rgbBlue = ((BYTE) ((lpdm->bkColor) >> 16)); // GetYValue
                    BGColor.rgbReserved = ((BYTE) ((lpdm->bkColor) >> 24)); // GetKValue
                    bBGGray = INTENSITY (255 - min (255, (BGColor.rgbReserved + BGColor.rgbRed)),
                                         255 - min (255, (BGColor.rgbReserved + BGColor.rgbGreen)),
                                         255 - min (255, (BGColor.rgbReserved + BGColor.rgbBlue)));
                } else
                {
                    BGColor.rgbRed = GetRValue ((DWORD) (lpdm->bkColor));
                    BGColor.rgbGreen = GetGValue ((DWORD) (lpdm->bkColor));
                    BGColor.rgbBlue = GetBValue ((DWORD) (lpdm->bkColor));
                    bBGGray = INTENSITY (BGColor.rgbRed,
                                         BGColor.rgbGreen, BGColor.rgbBlue);
                }
            }
            if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR)
            {
                ICMPixelFormatIn = CMS_XRGBQUADS;
                ICMInputScanWidth = Width * 4;
                if ((lpBitmapInfo->bmiHeader.biSize > sizeof (BITMAPINFOHEADER))
                    && (((BITMAPV4HEADER FAR *) lpBitmapInfo)->bV4CSType
                        == LCS_DEVICE_CMYK))
                {
                    BytesPerPixel = 4;
                    ICMPixelFormatIn = CMS_QUADS;
                    ICMPixelFormatOut = CMS_QUADS;
                } else if (lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT)
                {
                    BytesPerPixel = 4;
                    ICMPixelFormatOut = CMS_QUADS;
                } else
                {
                    BytesPerPixel = 3;
                    ICMPixelFormatOut = CMS_BGRTRIPLETS;
                }
            } else
            {
        // Fix bug 160292.  jjia    8/14/96
                if ((lpBitmapInfo->bmiHeader.biSize > sizeof (BITMAPINFOHEADER)) &&
                    (((BITMAPV4HEADER FAR *) lpBitmapInfo)->bV4CSType == LCS_DEVICE_CMYK))
                    ICMPixelFormatIn = CMS_QUADS;

                BytesPerPixel = 1;
            }

            ICMOutputScanWidth = ((BytesPerPixel * (DWORD) SrcXE + 3) / 4) * 4;  //247974
            lpBitBuf = (BYTE huge *) MGAllocLock (lppd, (LPHANDLE) & h,
                    (DWORD) (4 * (DWORD)SrcXE * (DWORD) SrcYE), GHND, TRUE);

            if (!lpBitBuf)
                return -1;

            lpLineStart = lpLineStart + 4 * SrcX;   // Move to proper pixel -
                                                    // 4 bytes per pixel

            lpBuf = lpBitBuf;           // Point to start of buffer

            for (i = 0; i < SrcYE; i++)
            {
                lpBits = lpLineStart;   // Point to first pixel
                for (k = 0; k < SrcXE; k++) // for all pixels in line
                {                       // at 2 bytes per pixel
                    if (!PixelFormat)
                    {
                        Blue = *lpBits++;
                        Green = *lpBits++;
                        Red = *lpBits++;
                        Black = *lpBits++;
                    } else
                    {
                        Red = *lpBits++;
                        Green = *lpBits++;
                        Blue = *lpBits++;
                        Black = *lpBits++;
                    }

                    if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR)
                    {
                        if (ICMPixelFormatIn == CMS_QUADS)
                        {
                        // We output the same order as !PixelFormat above
                        // in CMYK color space - app asked for it.
                            *lpBuf++ = Blue;    // Cyan
                            *lpBuf++ = Green;   // Magenta
                            *lpBuf++ = Red; // Yellow
                            *lpBuf++ = Black;   // Black
                        }
                        else if (!(lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM))
                        {
                        // Got rgb/bgrquads. Send in RGB color space.
                        // The PixelFormat check above takes care of RGB
                        // and BGR quad inputs.
                            *lpBuf++ = Red;
                            *lpBuf++ = Green;
                            *lpBuf++ = Blue;
                        }
                        else
                        {
                        // Send XRGBQUADS to ICM32.dll
                            *lpBuf++ = Blue;
                            *lpBuf++ = Green;
                            *lpBuf++ = Red;
                            *lpBuf++ = Black;
                        }
                    } else
                    {
                        if (ICMPixelFormatIn == CMS_QUADS)
                        {
                    // L3_MASK
                            Yellow = Blue;
                            Magenta = Green;
                            Cyan = Red;

                    // Convert CMYK into RGB components - see RedBook p.307
                            Red = 255 - min (255, (Black + Red));
                            Green = 255 - min (255, (Black + Green));
                            Blue = 255 - min (255, (Black + Blue));
                        }
                // L3_MASK
                // *lpBuf++ = INTENSITY(Red,Green,Blue); // Convert color to
                // grayscale
                        bGray = INTENSITY (Red, Green, Blue);   // Convert color to
                                                                // grayscale
                        if ((bColor2GrayTrans) && (bGray == bBGGray) &&
                            (!(PixelFormat) &&
                             (BGColor.rgbRed != Red ||
                              BGColor.rgbGreen != Green ||
                              BGColor.rgbBlue != Blue) ||
                             (PixelFormat) &&
                             (BGColor.rgbRed != Cyan ||
                              BGColor.rgbGreen != Magenta ||
                              BGColor.rgbBlue != Yellow ||
                              BGColor.rgbReserved != Black)
                             ))
                        {
                            if (bGray > 0)
                                bGray--;
                            else
                                bGray++;
                        }
                        *lpBuf++ = bGray;

                    }
                }
                // 247974
                if ((lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR) &&
                    (lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM) &&
                    (ICMPixelFormatIn == CMS_RGBTRIPLETS))
                {
                    lpBuf += (ICMOutputScanWidth - (BytesPerPixel * (DWORD) SrcXE));
                }
                lpLineStart += ScanWidth;
            }
            lpBuf = lpBitBuf;
        }
 // If 24-bits image and full color output - no compression
 // 01-Feb-1993	 -by-	[olegs]

 // EVERYTHING IS SETUP - NOW OUTPUT THE STUFF
        if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR)
        {
            if ((lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM) &&
                (ICMPixelFormatIn != CMS_QUADS))
            {
                bRet = ICMTranslateRGBs (lpICMI->hICMT,
                                         (LPVOID) lpBuf, ICMPixelFormatIn,
                                         (DWORD) SrcXE, (DWORD) SrcYE,
                                         (DWORD) ICMInputScanWidth,
                                         (LPVOID) lpBitBuf,
                                         ICMPixelFormatOut,
                                         CMS_FORWARD);

        // oleg! this is shitty stupid slow code, i don't even want
        // to think what the C compiler is going to produce, this
        // belongs in pssendbitmapdata or even better to have the
        // ICM dll give you the proper format! dnw

                if (lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT)
                {
                    lpBuf = lpBitBuf;       // Point to start of buffer
                    lpBits = lpBitBuf;      // Point to start of buffer
                    for (i = 0; i < SrcYE; i++)
                    {
                        for (k = 0; k < SrcXE; k++) // for all pixels in line
                        {                   // at 4 bytes per pixel
                            Black = *lpBits++;
                            Yellow = *lpBits++;
                            Magenta = *lpBits++;
                            Cyan = *lpBits++;
                            *lpBuf++ = Cyan;
                            *lpBuf++ = Magenta;
                            *lpBuf++ = Yellow;
                            *lpBuf++ = Black;
                        }
                    }
                }
                else
                {
                    OutputScanWidth = BytesPerPixel * (DWORD)SrcXE;
                    if ( OutputScanWidth != ICMOutputScanWidth)
                    {
                        lpBuf = lpBitBuf;       // Point to start of buffer
                        lpBits = lpBitBuf;      // Point to start of buffer
                        for (i = 0; i < SrcYE; i++)
                        {
                            MemCopy(lpBuf, lpBits, OutputScanWidth);
                            lpBuf += OutputScanWidth;
                            lpBits += ICMOutputScanWidth;
                        }
                    }
                }
            }
            (*tempptr->PSSendBitMapDataLevel1) (lppd, lpBitBuf,
                   (DWORD) (BytesPerPixel * (DWORD) SrcXE * (DWORD) SrcYE));
        } else
        {
    // FAST_IMAGE
            if ((FastImgType & RESAMPLE) && (BytesPerPixel == 1))
            {
                ResampleAndSend (lppd, lpBitBuf, DstRect, SrcXE, SrcYE,
                                 BytesPerPixel * 8, SrcXE, ResampleRatio);
            } else
            {
                (*tempptr->PSSendBitMapDataLevel2) (lppd, lpBitBuf,
                   (DWORD) (BytesPerPixel * (DWORD) SrcXE * (DWORD) SrcYE));
            }
        }

        MGUnlockFree (lppd, h, TRUE);
        if (lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM)
        {
            GlobalUnlock ((HANDLE) lppd->graphics.hCMTransform);
        }
    }
    PSSendFragment (lppd, PSFRAG_endimage);
    (*tempptr->PSSendCRLF) (lppd);
    return (retval);
}
