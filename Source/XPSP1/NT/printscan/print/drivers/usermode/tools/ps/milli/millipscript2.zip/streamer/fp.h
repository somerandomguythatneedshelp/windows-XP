/* CM_VerSion fp.h atm05 1.2 10076.eco sum= 26817 */
/* CM_VerSion fp.h atm04 1.6 07436.eco sum= 64835 */
/* 
  fp.h	-- Interface to Floating/Fixed package.

	      Copyright 1986, 1991 -- Adobe Systems, Inc.
	    PostScript is a trademark of Adobe Systems, Inc.
NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

Original version: 
Edit History:
Craig Rublee: Mon Aug 19 19:29:50 1991
Ivor Durham: Wed Jan 28 14:42:44 1987
Ed Taft: Wed Oct  7 14:13:03 1987
Doug Brotz: Wed Mar  1 10:32:00 1989
Bill Paxton: Mon Mar  5 11:53:46 1990
End Edit History.

*/

#ifndef	FP_H
#define	FP_H

#include PROTOS
#include PUBLICTYPES
/*
 * Math Library Interface
 */

/* This interface incorporates, by reference, the following procedures
   from the standard C math library, as documented in most C manuals;
   it may include others as well, but is not required to.

   acos, asin, atan, atan2, atod, atof, ceil, cos, ecvt, exp, fcvt,
   floor, frexp, ldexp, log, log10, modf, pow, sin, sqrt
 */

#if VAXC
#include math
#else /* VAXC */
#include <math.h>
#endif /* VAXC */


typedef long int Frac, UFrac, *PFrac;


#ifdef WINATM

/* These weird defines set everything up for multiple copies of the
** fixed routines, both near and far (for debugging)
*/

#include "atmtypes.h"

#ifdef FxBC1

/* Do this for segment BC1 of the engine code. */
#define fixmul    BC1fixmul
#define fixdiv    BC1fixdiv
#define fixratio  BC1fixratio
#define fracmul   BC1fracmul
#define fracratio BC1fracratio
#define fracsqrt  BC1fracsqrt
#define fracdiv   BC1fracdiv
#define fxfrmul   BC1fxfrmul

#define FIXEDFUNC cdecl NEARFUNC

#else  /* ifdef FxBC1 */

#ifdef FxBC2

/* Do this for segment BC2 of the engine code. */
#define fixmul    BC2fixmul
#define fixdiv    BC2fixdiv
#define fixratio  BC2fixratio
#define fracmul   BC2fracmul
#define fracratio BC2fracratio
#define fracsqrt  BC2fracsqrt
#define fracdiv   BC2fracdiv
#define fxfrmul   BC2fxfrmul

#define FIXEDFUNC cdecl NEARFUNC

#else  /* ifdef FxBC2 */

#ifdef FxG12

/* Do this for segments G1 and G2 of the system glue code. */
#define fixmul    G12fixmul
#define fixdiv    G12fixdiv
#define fixratio  G12fixratio
#define fracmul   G12fracmul
#define fracratio G12fracratio
#define fracsqrt  G12fracsqrt
#define fracdiv   G12fracdiv
#define fxfrmul   G12fxfrmul

#define FIXEDFUNC cdecl NEARFUNC

#else  /* ifdef FxG12 */

/* For all other segments we use the names straight! */
#define FIXEDFUNC cdecl FARFUNC

#endif  /* ifdef FxG12 */

#endif  /* ifdef FxBC2 */

#endif  /* ifdef FxBC1 */

#else  /* ifdef WINATM */

#define FIXEDFUNC

#endif  /* ifdef WINATM */


/*
 * Floating Point Interface
 */

/* Exported Procedures */

extern int /*boolean*/ isinf(/* double d */);
/* Returns true if the argument d represents "infinity", either positive
   or negative. */

extern int /*boolean*/ isnan(/* double d */);
/* Returns true if the argument d is an invalid floating point number
   other than infinity. */

/* Inline Procedures */

/* The following macros implement comparisons of real (float) values
   with zero. If IEEESOFT is true (defined in environment.h), these
   comparisons are done more efficiently than the general floating
   point compare subroutines would typically do them.
   Note: the argument r must be a simple variable (not an expression)
   of type real (float); it must not be a formal parameter
   of a procedure, which is a double even if declared to be a float.
 */

#if IEEESOFT
#define RtoILOOPHOLE(r) (*(integer *)(&(r)))
#define RealEq0(r) ((RtoILOOPHOLE(r)<<1)==0)
#define RealNe0(r) ((RtoILOOPHOLE(r)<<1)!=0)
#define RealGt0(r) (RtoILOOPHOLE(r)>0)
#define RealGe0(r) ((RtoILOOPHOLE(r)>=0)||RealEq0(r))
#define RealLt0(r) ((RtoILOOPHOLE(r)<0)&&RealNe0(r))
#define RealLe0(r) (RtoILOOPHOLE(r)<=0)
#else /* IEEESOFT */
#define RealEq0(r) ((r)==0.0)
#define RealNe0(r) ((r)!=0.0)
#define RealGt0(r) ((r)>0.0)
#define RealGe0(r) ((r)>=0.0)
#define RealLt0(r) ((r)<0.0)
#define RealLe0(r) ((r)<=0.0)
#endif /* IEEESOFT */

#ifndef fabs
#define fabs(x) (RealLt0(x)?-(x):(x))
/* Returns the absolute value of x, which must be a simple variable
   of type real (float), as described above. */
#endif /* fabs */

#define RAD(a) ((a)*1.745329251994329577e-2)
/* Converts the float or double value a from degrees to radians. */


/*
 * Fixed Point interface
 */

/* Data Structures */

/* A fixed point number consists of a sign bit, i integer bits, and f
   fraction bits; the underlying representation is simply an integer.
   The integer n represents the fixed point value n/(2**f). The current
   definition is pretty heavily dependent on an integer being 32 bits.

   There are three kinds of fixed point numbers:
	Fixed	i = 15, f = 16, range [-32768, 32768)
	Frac	i = 1, f = 30, range [-2, 2)
	UFrac	i = 2, f = 30, unsigned, range [0, 4)
   The type "Fixed", defined in the basictypes interface, is simply
   a typedef for integer and is type-equivalent to integer as far
   as the C compiler is concerned.

   Within the fp interface, the types Fixed, Frac, and UFrac are used to
   document the kinds of fixed point numbers that are the arguments
   and results of procedures. However, most clients of this interface
   declare variables to be of type Fixed, or occasionally of type integer,
   without specifying which kind of fixed point number is actually
   intended. Most Fixed numbers are of the first kind; the other two
   are provided as a convenience to certain specialized algorithms in
   the graphics machinery.

   All procedures, including the conversions from real, return a
   correctly signed "infinity" value FixedPosInf or FixedNegInf
   if an overflow occurs; they return zero if an underflow occurs.
   No overflow or underflow traps ever occur; it is the caller's
   responsibility either to detect an out-of-range result or to
   prevent it from occurring in the first place.

   All procedures compute exact intermediate results and then round
   according to some consistent rule such as IEEE "round to nearest".
 */

#define FixedPosInf MAXinteger
#define FixedNegInf MINinteger

/* Exported Procedures */

extern Fixed FIXEDFUNC fixmul ARGDECL2(Fixed, x, Fixed, y);
/* Multiples two Fixed numbers and returns a Fixed result. */

extern Frac FIXEDFUNC fracmul ARGDECL2(Frac, x, Frac, y);
/* Multiples two Frac numbers and returns a Frac result. */

extern Fixed FIXEDFUNC fxfrmul ARGDECL2(Fixed, x, Frac, y);
/* Multiplies a Fixed number with a Frac number and returns a Fixed
   result. The order of the Fixed and Frac arguments does not matter. */

extern Fixed FIXEDFUNC fixdiv ARGDECL2(Fixed, x, Fixed, y);
/* Divides the Fixed number x by the Fixed number y and returns a
   Fixed result. */

extern Frac FIXEDFUNC fracdiv ARGDECL2(Frac, x, Frac, y);
/* Divides two Frac numbers and returns a Frac result. */

extern Fixed FIXEDFUNC fracratio ARGDECL2(Frac, x, Frac, y);
/* Divides the Frac number x by the Frac number y and returns a
   Fixed result. */

extern Fixed ufixratio ARGDECL2(Card32, x, Card32, y);
/* Divides the unsigned integer x by the unsigned integer y and
   returns a Fixed result. */

extern Frac FIXEDFUNC fixratio ARGDECL2(Fixed, x, Fixed, y);
/* Divides the Fixed number x by the Fixed number y and returns a
   Frac result. */

extern UFrac FIXEDFUNC fracsqrt ARGDECL1(UFrac, x);
/* Computes the square root of the UFrac number x and returns a
   UFrac result. */

/* The following type conversions pass their float arguments and results
   by value; the C language forces them to be of type double.
 */

extern double fixtodbl ARGDECL1(Fixed, x);
/* Converts the Fixed number x to a double. */

extern Fixed dbltofix ARGDECL1(double, d);
/* Converts the double d to a Fixed. */

extern double fractodbl ARGDECL1(Frac, x);
/* Converts the Frac number x to a double. */

extern Frac dbltofrac ARGDECL1(double, d);
/* Converts the double d to a Frac. */

/* The following type conversions pass their float arguments and results
   by pointer. This circumvents C's usual conversion of float arguments
   and results to and from double, which can have considerable
   performance consequences. Caution: do not call these procedures
   with pointers to float ("real") formal parameters, since those are
   actually of type double!
 */

extern procedure fixtopflt ARGDECL2(Fixed, x, float *, pf);
/* Converts the Fixed number x to a float and stores the result at *pf. */

extern Fixed pflttofix ARGDECL1(float *, pf);
/* Converts the float number at *pf to a Fixed and returns it. */

extern procedure fractopflt ARGDECL2(Frac, x, float *, pf);
/* Converts the Frac number x to a float and stores the result at *pf. */

extern Frac pflttofrac ARGDECL1(float *, pf);
/* Converts the float number at *pf to a Frac and returns it. */


/* Inline Procedures */

#define FixInt(x) ((Fixed)((Card32)(x) << 16))
/* Converts the integer x to a Fixed and returns it. */

#define FTrunc(x) ((integer)((x)>>16))
/* Converts the Fixed number x to an integer, truncating it to the
   next lower integer value, and returns it. */

#define FTruncF(x) ((integer)((x) & 0xFFFF0000))
/* Returns the Fixed value that represents the next lower integer value. */

#define FRound(x) ((integer)(((x)+(FIXEDHALF))>>16))
/* Converts the Fixed number x to an integer, rounding it to the
   nearest integer value, and returns it. */

#define FRoundF(x) ((integer)(((x)+(FIXEDHALF)) & 0xFFFF0000))
/* Returns x as a Fixed number, with its integer part rounded to the
   nearest integer value, and its fraction part 0. */

#define FCeil(x) (FTrunc((x) + 0xFFFF))
#define FCeilF(x) (FTruncF((x) + 0xFFFF)) 

#define FracToFixed(f) ((f) >> 14)
#define FixedToFrac(f) ((f) << 14)

#endif	/* FP_H */
/* v004 taft Tue Nov 22 14:09:28 PST 1988 */
/* v005 brotz Fri Feb 17 11:16:46 PST 1989 */
