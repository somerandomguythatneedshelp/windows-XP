/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: SPOOLER.H                                              */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

// Microsoft spooler (print manager) prototypes
//
HANDLE FAR  PASCAL OpenJob(LPSTR, LPSTR, HANDLE);
short FAR   PASCAL StartSpoolPage(HANDLE);
short FAR   PASCAL EndSpoolPage(HANDLE);
short FAR   PASCAL WriteSpool(HANDLE, LPSTR, short);
short FAR   PASCAL CloseJob(HANDLE);
short FAR   PASCAL DeleteJob(HANDLE, short);
short FAR   PASCAL WriteDialog(HANDLE, LPSTR, short);

