/* CM_VerSion encmap.c atm05 1.2 09045.eco sum= 51013 */
/* CM_VerSion encmap.c atm04 1.2 07592.eco sum= 22950 */
#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES

Int16 standardEncoding[256] = {
     0, /*          UNENC =   0 */        0,    /*         UNENC =   1 */
     0, /*          UNENC =   2 */        0,    /*         UNENC =   3 */
     0, /*          UNENC =   4 */        0,    /*         UNENC =   5 */
     0, /*          UNENC =   6 */        0,    /*         UNENC =   7 */
     0, /*          UNENC =   8 */        0,    /*         UNENC =   9 */
     0, /*          UNENC =  10 */        0,    /*         UNENC =  11 */
     0, /*          UNENC =  12 */        0,    /*         UNENC =  13 */
     0, /*          UNENC =  14 */        0,    /*         UNENC =  15 */
     0, /*          UNENC =  16 */        0,    /*         UNENC =  17 */
     0, /*          UNENC =  18 */        0,    /*         UNENC =  19 */
     0, /*          UNENC =  20 */        0,    /*         UNENC =  21 */
     0, /*          UNENC =  22 */        0,    /*         UNENC =  23 */
     0, /*          UNENC =  24 */        0,    /*         UNENC =  25 */
     0, /*          UNENC =  26 */        0,    /*         UNENC =  27 */
     0, /*          UNENC =  28 */        0,    /*         UNENC =  29 */
     0, /*          UNENC =  30 */        0,    /*         UNENC =  31 */
   202, /*          space =  32 */      116,    /*         exclam = 33 */
   184, /*       quotedbl =  34 */      155,    /*     numbersign = 35 */
   102, /*         dollar =  36 */      175,    /*        percent = 37 */
    69, /*      ampersand =  38 */      189,    /*     quoteright = 39 */
   173, /*      parenleft =  40 */      174,    /*     parenright = 41 */
    73, /*       asterisk =  42 */      179,    /*           plus = 43 */
    93, /*          comma =  44 */      135,    /*         hyphen = 45 */
   176, /*         period =  46 */      201,    /*          slash = 47 */
   228, /*           zero =  48 */      163,    /*            one = 49 */
   211, /*            two =  50 */      206,    /*          three = 51 */
   123, /*           four =  52 */      120,    /*           five = 53 */
   200, /*            six =  54 */      199,    /*          seven = 55 */
   110, /*          eight =  56 */      153,    /*           nine = 57 */
    92, /*          colon =  58 */      198,    /*      semicolon = 59 */
   144, /*           less =  60 */      114,    /*          equal = 61 */
   128, /*        greater =  62 */      182,    /*       question = 63 */
    74, /*             at =  64 */        1,    /*              A = 65 */
     9, /*              B =  66 */       10,    /*              C = 67 */
    12, /*              D =  68 */       13,    /*              E = 69 */
    19, /*              F =  70 */       20,    /*              G = 71 */
    21, /*              H =  72 */       22,    /*              I = 73 */
    27, /*              J =  74 */       28,    /*              K = 75 */
    29, /*              L =  76 */       31,    /*              M = 77 */
    32, /*              N =  78 */       34,    /*              O = 79 */
    42, /*              P =  80 */       43,    /*              Q = 81 */
    44, /*              R =  82 */       45,    /*              S = 83 */
    47, /*              T =  84 */       49,    /*              U = 85 */
    54, /*              V =  86 */       55,    /*              W = 87 */
    56, /*              X =  88 */       57,    /*              Y = 89 */
    60, /*              Z =  90 */       81,    /*    bracketleft = 91 */
    77, /*      backslash =  92 */       82,    /*   bracketright = 93 */
    71, /*    asciicircum =  94 */      218,    /*     underscore = 95 */
   188, /*      quoteleft =  96 */       62,    /*              a = 97 */
    76, /*              b =  98 */       86,    /*              c = 99 */
    96, /*              d = 100 */      105,    /*              e =101 */
   118, /*              f = 102 */      125,    /*              g =103 */
   133, /*              h = 104 */      136,    /*              i =105 */
   141, /*              j = 106 */      142,    /*              k =107 */
   143, /*              l = 108 */      147,    /*              m =109 */
   152, /*              n = 110 */      156,    /*              o =111 */
   171, /*              p = 112 */      181,    /*              q =113 */
   192, /*              r = 114 */      195,    /*              s =115 */
   204, /*              t = 116 */      213,    /*              u =117 */
   219, /*              v = 118 */      220,    /*              w =119 */
   221, /*              x = 120 */      222,    /*              y =121 */
   226, /*              z = 122 */       79,    /*      braceleft =123 */
    78, /*            bar = 124 */       80,    /*     braceright =125 */
    72, /*     asciitilde = 126 */        0,    /*         UNENC = 127 */
     0, /*          UNENC = 128 */        0,    /*         UNENC = 129 */
     0, /*          UNENC = 130 */        0,    /*         UNENC = 131 */
     0, /*          UNENC = 132 */        0,    /*         UNENC = 133 */
     0, /*          UNENC = 134 */        0,    /*         UNENC = 135 */
     0, /*          UNENC = 136 */        0,    /*         UNENC = 137 */
     0, /*          UNENC = 138 */        0,    /*         UNENC = 139 */
     0, /*          UNENC = 140 */        0,    /*         UNENC = 141 */
     0, /*          UNENC = 142 */        0,    /*         UNENC = 143 */
     0, /*          UNENC = 144 */        0,    /*         UNENC = 145 */
     0, /*          UNENC = 146 */        0,    /*         UNENC = 147 */
     0, /*          UNENC = 148 */        0,    /*         UNENC = 149 */
     0, /*          UNENC = 150 */        0,    /*         UNENC = 151 */
     0, /*          UNENC = 152 */        0,    /*         UNENC = 153 */
     0, /*          UNENC = 154 */        0,    /*         UNENC = 155 */
     0, /*          UNENC = 156 */        0,    /*         UNENC = 157 */
     0, /*          UNENC = 158 */        0,    /*         UNENC = 159 */
     0, /*          UNENC = 160 */      117,    /*     exclamdown =161 */
    90, /*           cent = 162 */      203,    /*       sterling =163 */
   124, /*       fraction = 164 */      225,    /*            yen =165 */
   122, /*         florin = 166 */      197,    /*        section =167 */
    95, /*       currency = 168 */      191,    /*    quotesingle =169 */
   186, /*   quotedblleft = 170 */      129,    /*  guillemotleft =171 */
   131, /*  guilsinglleft = 172 */      132,    /* guilsinglright =173 */
   119, /*             fi = 174 */      121,    /*             fl =175 */
     0, /*          UNENC = 176 */      113,    /*         endash =177 */
    97, /*         dagger = 178 */       98,    /*      daggerdbl =179 */
   177, /* periodcentered = 180 */        0,    /*         UNENC = 181 */
   172, /*      paragraph = 182 */       85,    /*         bullet =183 */
   190, /* quotesinglbase = 184 */      185,    /*   quotedblbase =185 */
   187, /*  quotedblright = 186 */        0,    /*         UNENC = 187 */
   111, /*       ellipsis = 188 */      178,    /*    perthousand =189 */
     0, /*          UNENC = 190 */      183,    /*   questiondown =191 */
     0, /*          UNENC = 192 */      127,    /*          grave =193 */
    65, /*          acute = 194 */       91,    /*     circumflex =195 */
   209, /*          tilde = 196 */      148,    /*         macron =197 */
    83, /*          breve = 198 */      103,    /*      dotaccent =199 */
   100, /*       dieresis = 200 */        0,    /*         UNENC = 201 */
   194, /*           ring = 202 */       89,    /*        cedilla =203 */
     0, /*          UNENC = 204 */      134,    /*   hungarumlaut =205 */
   161, /*         ogonek = 206 */       87,    /*          caron =207 */
   112, /*         emdash = 208 */        0,    /*         UNENC = 209 */
     0, /*          UNENC = 210 */        0,    /*         UNENC = 211 */
     0, /*          UNENC = 212 */        0,    /*         UNENC = 213 */
     0, /*          UNENC = 214 */        0,    /*         UNENC = 215 */
     0, /*          UNENC = 216 */        0,    /*         UNENC = 217 */
     0, /*          UNENC = 218 */        0,    /*         UNENC = 219 */
     0, /*          UNENC = 220 */        0,    /*         UNENC = 221 */
     0, /*          UNENC = 222 */        0,    /*         UNENC = 223 */
     0, /*          UNENC = 224 */        2,    /*             AE =225 */
     0, /*          UNENC = 226 */      167,    /*    ordfeminine =227 */
     0, /*          UNENC = 228 */        0,    /*         UNENC = 229 */
     0, /*          UNENC = 230 */        0,    /*         UNENC = 231 */
    30, /*         Lslash = 232 */       40,    /*         Oslash =233 */
    35, /*             OE = 234 */      168,    /*   ordmasculine =235 */
     0, /*          UNENC = 236 */        0,    /*         UNENC = 237 */
     0, /*          UNENC = 238 */        0,    /*         UNENC = 239 */
     0, /*          UNENC = 240 */       67,    /*             ae =241 */
     0, /*          UNENC = 242 */        0,    /*         UNENC = 243 */
     0, /*          UNENC = 244 */      104,    /*       dotlessi =245 */
     0, /*          UNENC = 246 */        0,    /*         UNENC = 247 */
   146, /*         lslash = 248 */      169,    /*         oslash =249 */
   160, /*             oe = 250 */      126,    /*     germandbls =251 */
     0, /*          UNENC = 252 */        0,    /*         UNENC = 253 */
     0, /*          UNENC = 254 */        0,    /*         UNENC = 255 */
        };

