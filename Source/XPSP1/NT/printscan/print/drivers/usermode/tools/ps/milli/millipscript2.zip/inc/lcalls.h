/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: LCALLS.H                                                     */
/*                                                                           */
/* Description: This module contains the prototypes for the long calls       */
/*              to otherwise C Runtime Library calls that don't accept       */
/*              long pointer arguments.                                      */
/*                                                                           */
/*****************************************************************************/

/* Need to also include dos.h and errno.h before this. -John Kwan */

double latof(LPSTR);
int latoi(LPSTR);

unsigned l_dos_findfirst(LPSTR, unsigned, struct find_t FAR *);
unsigned l_dos_findnext(struct find_t FAR *);

int lint86x(int, union REGS FAR *, union REGS FAR *, struct SREGS FAR *);

LPSTR l_strdate(LPSTR);
LPSTR l_strtime(LPSTR);
