/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: EPSFUNCS.C                                                   */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/* Change History:                                                           */
/* L3_CLIP  -- Level3 clipsave cliprestory support. 9/13/96  jjia            */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_EPSFUNCSSEG)

#define PS_BUFSIZE_BIG ((WORD) 65535)   // Because a PostScript string may be this big

void FAR PASCAL EmitStringRef(LPPDEVICE lppd, DWORD    dwstringref); // in theader.c
BOOL FAR PASCAL GetCurrUserName(LPPDEVICE lppd, LPSTR buffer, int *cb);
void FAR PASCAL SendPSInjectionData(LPPDEVICE lppd, PSInjectionPoint PSInjectID,
                                                    LPSTR FAR *lplpDriverPS,
                                          unsigned FAR *lpDriverPSLen); 
   
short FAR PASCAL PSGetFragmentLength(LPPDEVICE lppd, WORD FragId);
BOOL FAR PASCAL ValidateClean7BitData(LPSTR lpstr);
DWORD FAR PASCAL CToPSStr(BYTE huge *lpzPS, BYTE huge *lpzC, DWORD dwLen);
short FAR PASCAL ReturnHexOrEscapedCharString(LPPDEVICE lppd, LPSTR lpstr, int DSCstr);
WORD  FAR  PASCAL  KeywordGetOption( LPPDEVICE  lppd,
                                    WORD  MainKeywordIndex,
                                    WORD  OptionKeywordIndex,
                                    LPSTR lpOption,
                                    WORD Len);
int FAR PASCAL TSendFontDSCStuff(LPPDEVICE lppd, BOOL fEPSformat);

static char tempbuf[20];
#define MAXDATARECORD 200

/***************************************************************************
*                               TSoftFontLoadEPS
*  Purpose:
*
*  Parameters:
*       LPPDEVICE   lppd --
*       LPPSFONTINFO  FontInfo --
*       LPTEXTXFORM TextXForm --
*       LPSTR       String --
*       short       sCount --
*    
*  Returns: PSERROR
*                                                                           
***************************************************************************/
PSERROR FAR PASCAL TSoftFontLoadEPS(LPPDEVICE lppd, LPPSFONTINFO FontInfo,
                   LPTEXTXFORM TextXForm, LPSTR String,short sCount )
{
   return PS_SUCCESS;

}  // END TSoftFontLoadEPS


/***************************************************************************
*                              TDocumentBeginEPS
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TDocumentBeginEPS(LPPDEVICE lppd)
{
  RECT rect ;
  LPASCIIBINPTRS tempptr;
  char buffer[80];
  int rc;
  LPSTR lpTempPS;
  int iTempLen;
  
  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

  // Remember these settings. Useful for Nup & %%ViewingOrientation DSC
  lppd->startingLayout = lppd->lpPSExtDevmode->dm.layout;
  lppd->startingOrient = lppd->lpPSExtDevmode->dm.PaperOrient;
  lppd->startingMirror = lppd->lpPSExtDevmode->dm.bMirror;

  // init the procset management list
  InitProcsetList(lppd);

  TInitGraphicState(lppd);
  TSetPen(lppd);
  TSetBrush(lppd);

   //
   // PS injection point IPS_BEGINSTREAM goes here
   //
   SendPSInjectionData(lppd, IPS_BEGINSTREAM, &lpTempPS, &iTempLen);

// Send the Normal DSC header comments

  (*tempptr->PSSendDSC)(lppd, DSC_epsf         , (LPSTR)NULL);             // %!PS-Adobe-2.0 EPSF-2.0

   // make sure the lppd->szTitle is Cleant7Bit string.  # 188694 yct
   // EPS is always ascii data format.
      
   if (ValidateClean7BitData(lppd->szTitle))
      (*tempptr->PSSendDSC)(lppd, DSC_title, lppd->szTitle); 
   else
      // show Hex value or escape characters on %%Title: 
      ReturnHexOrEscapedCharString(lppd, lppd->szTitle, DSC_title);
//         (*tempptr->PSSendDSC)(lppd, DSC_title, nonAscii7); 

  rect = lppd->bbox ;
  if( lppd->lpPSExtDevmode->dm.PaperOrient != OR_PORTRAIT)
  {
      int   temp = rect.top;
      rect.top = rect.right;
      rect.right = temp;
  }
  (*tempptr->PSSendDSCBBox)(lppd, DSC_bbox     , &rect);// %%BoundingBox:

//  (*tempptr->PSSendDSCBBox)(lppd, DSC_bbox     , &lppd->bbox);// %%BoundingBox:

   // %%Creator: ADOBEPS4.DRV Version 4.1
  (*tempptr->PSSendDSC)(lppd, DSC_creator, szIniCreator);        

  l_strdate( tempbuf );
  lstrcat((LPSTR)tempbuf,(LPSTR)" ");
  l_strtime( &tempbuf[lstrlen(tempbuf)] );
  (*tempptr->PSSendDSC)(lppd, DSC_date         , tempbuf );                // %%CreationDate:

    // Add For: User name. Fix bug 83. We may choose not do this for EPS, if there is a reason
   rc=sizeof(buffer);
   GetCurrUserName(lppd, (LPSTR)buffer, &rc);  // rc contains the actual length of username
//   (*tempptr->PSSendDSC)(lppd, DSC_for, buffer);      // %%For: UserName

   // make sure the buffer is Cleant7Bit string.  # 188694 yct
   // EPS is always ascii data format.
   if (ValidateClean7BitData(buffer))
      (*tempptr->PSSendDSC)(lppd, DSC_for, buffer); 
   else
      // show Hex value or escape characters on %%For: 
      ReturnHexOrEscapedCharString(lppd, buffer, DSC_for);
      //(*tempptr->PSSendDSC)(lppd, DSC_for, nonAscii7); 

  (*tempptr->PSSendDSC)(lppd, DSC_pages        , (LPSTR)szOne);              // %%Pages:
  // delete in DSC 3.1
//  (*tempptr->PSSendDSC)(lppd, DSC_requirements , (LPSTR)szNone );          // %%Requirements:

//  (*tempptr->PSSendDSC)(lppd, DSC_docneedresfont, (LPSTR)"(atend)");        // %%DocumentNeededResources: font
//  (*tempptr->PSSendDSC)(lppd, DSC_docsuppresfont, (LPSTR)"(atend)");        // %%DocumentSuppliedResources: font

  (*tempptr->PSSendDSC)(lppd, DSC_docneededres, (LPSTR)"(atend)");        // %%DocumentNeededResources: font
  (*tempptr->PSSendDSC)(lppd, DSC_docsuppliedres, (LPSTR)"(atend)");        // %%DocumentSuppliedResources: font


#ifndef ADOBEPS42
  // Fix bug 120631. jjia. 11/1/95
  // EPS files created with adobe driver should include level2 feature.
#ifdef ADOBE_DRIVER
  if (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE)
#else
  if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS  ))
#endif
  {
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szTwo);           // %%LanguageLevel: 2
  }else
  {
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szOne);           // %%LanguageLevel: 1
  }
#else
//  (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szTwo);           // %%LanguageLevel: 2
  if (lppd->lpPSExtDevmode->dm2.useLanguageLevel == 2) 
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szTwo);           // %%LanguageLevel: 2
  else if (lppd->lpPSExtDevmode->dm2.useLanguageLevel == 3)
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szThree);         // %%LanguageLevel: 3

#endif

//(*tempptr->PSSendDSC)(lppd, DSC_extensions   , (LPSTR)szQuestion);        // %%Extensions:

   // for NT compatibility
   // give app or OEM a chance to emit their %%DocumentProcessColorsAtEnd:
   //
   (*tempptr->PSSendDSC)(lppd, DSC_documentprocesscolorsatend, NULL);

  (*tempptr->PSSendDSC)(lppd, DSC_endcomments  , (LPSTR)NULL );            // %%EndComments"
  (*tempptr->PSSendDSC)(lppd, DSC_begindefaults  , (LPSTR)NULL );
  TSendViewingOrientation(lppd, TRUE);
  (*tempptr->PSSendDSC)(lppd, DSC_enddefaults  , (LPSTR)NULL );
  (*tempptr->PSSendCRLF)(lppd);

// Send the Prolog

  (*tempptr->PSSendDSC)(lppd, DSC_beginprolog , (LPSTR)NULL );             // %%BeginProlog

  // Fix bug 126385. JJIA.  1/17/96
  // Error handler should be suppressed in EPS.
#if 0
  if(lppd->lpPSExtDevmode->dm2.bErrHandler == TRUE)
  {
     // send the error handler
     PSSendProc(lppd,PSPROC_ehandler);
  }
#endif
  PSSendProc(lppd,PSPROC_fatalerr_ps1);

  TSendHeader(lppd, TRUE);  // Send header, EPS format

  // before EndProlog, send special PASSTHROUGH PS data, 5-1-95
  TSendSpecialPSData(lppd);

  (*tempptr->PSSendDSC)(lppd, DSC_endprolog   , (LPSTR)NULL );             // %%EndProlog"
  (*tempptr->PSSendCRLF)(lppd);

  (*tempptr->PSSendDSC)(lppd, DSC_beginsetup, (LPSTR)NULL );               // %%BeginSetup

  // Echo product on back-channel
  PSSendFragment(lppd, PSFRAG_productname);
  (*tempptr->PSSendCRLF)(lppd);

   PSSendFragment(lppd, PSFRAG_CSLCompMode1); // NO \r\n after this line because J-doesn't have them
   PSSendFragment(lppd, PSFRAG_CSLCompMode2);
   (*tempptr->PSSendCRLF)(lppd);

  TSendPrologInit(lppd, TRUE);      // Init prolog (and CalRGB stuff), EPS format
  (*tempptr->PSSendCRLF)(lppd);

   // new in DSC 3.1
   // Add DSC_begindocumentsetup
   //(*tempptr->PSSendDSC)(lppd, DSC_begindocumentsetup, (LPSTR)NULL );
   //(*tempptr->PSSendCRLF)(lppd);

// Construct the coordinate transformation matrix(CTM).

  if (lppd->lpPSExtDevmode->dm.marginState == NO_MARGINS) //Full page is imageable.
      SetRect(&rect, 0, 0,lppd->ptPaperDim.x,lppd->ptPaperDim.y) ;
  else
      rect = lppd->imageRect ;

  PSSendMySetup( lppd, &rect, SETUP_EPS_COORDS );

  // ADOBE_SPOOLER
  // PSSendFragment(lppd, PSFRAG_InitEnv);

   // new in DSC 3.1
   // Add DSC_enddocumentsetup
   //(*tempptr->PSSendDSC)(lppd, DSC_enddocumentsetup, (LPSTR)NULL );
   //(*tempptr->PSSendCRLF)(lppd);

  (*tempptr->PSSendDSC)(lppd, DSC_endsetup, (LPSTR)NULL );     // %%EndSetup
  (*tempptr->PSSendCRLF)(lppd);

  lppd->lpProcsetstuff->currpagenumber = 1;          // initialize page number

//Reset the port's dirty flag.
  PortClean(lppd);

  return(1);
}


/***************************************************************************
*                              TDocumentEndEPS
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*    
*  Returns: short
*                                                                           
***************************************************************************/
short FAR PASCAL TDocumentEndEPS(LPPDEVICE lppd)
{
   // Page trailer now sent by TDocumentPageEnd

   // Send Trailer
   TSendTrailer(lppd, TRUE);   // TRUE means Trailer is EPS format

   return(1);

}  // END TDocumentEndEPS


/***********************************************************************
*                      TDocumentPageBeginEPS
*  Purpose:
*       token function which inits a new page, for EPS format output
*
*       Note: we do PortPage() in TDocumentPageBegin(), the printer
*       format token-handler, but not here.  The only sensible destination
*       for EPS format output is to FILE:, and we don't need to 
*       send the header out early for that.
*
*  Parameter:
*       LPPDEVICE lppd -- pdevice pointer
*
*  Returns: short
*       RC_ok
*
***********************************************************************/
short FAR PASCAL TDocumentPageBeginEPS(LPPDEVICE lppd)
{
   LPASCIIBINPTRS tempptr;
   
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   // The following is TSendPageSetup(lppd), without device features.
   
   // %%Page: 1 1
   // (We don't need real page numbers; there should only be one page
   //  in EPS format output anyhow.)
   (*tempptr->PSSendDSC)(lppd, DSC_page, (LPSTR)"1 1");
    // same as NT
    (*tempptr->PSSendDSC)(lppd, DSC_platecolor, (LPSTR)NULL );

   TSendViewingOrientation(lppd, FALSE);

    // new in DSC 3.1
    // add it back for NT compatibility
    (*tempptr->PSSendDSC)(lppd, DSC_endpagecomments, (LPSTR)NULL );

   // %%BeginPageSetup
   (*tempptr->PSSendDSC)(lppd, DSC_beginpagesetup, (LPSTR)NULL );
   
   // Send screen frequency & angle if necessary
   if (! lppd->lpPSExtDevmode->dm.useDefaultHalftoneParams)
   {
       char buffer1[512];
       char buffer2[512];
       
       LoadString(ghDriverMod, PSFRAG_setscreen, buffer1, 512);
       wsprintf((LPSTR) buffer2, (LPSTR) buffer1, 
                lppd->lpPSExtDevmode->dm.ScreenFrequency, 
                lppd->lpPSExtDevmode->dm.ScreenAngle);
       PortWrite(lppd,buffer2,lstrlen(buffer2));
       (*tempptr->PSSendCRLF)(lppd);
   }
    
   // now send the driver supplied page setup stuff.
   PSSendSave(lppd, TRUE);
   
   // and we are done with page setup
   (*tempptr->PSSendDSC)(lppd, DSC_endpagesetup, (LPSTR)NULL );
   (*tempptr->PSSendCRLF)(lppd);
   
   
   TInitGraphicState(lppd);
   return(RC_ok);

}  // END TDocumentPageBeginEPS



/***********************************************************************
*                      TDocumentBeginMinHeader
*  Purpose:
*       Handle TDocumentBegin token for printable PostScript format
*       in minimal header (EPSPrinting) mode.
*
*  Parameter:
*       LPPDEVICE lppd -- pdevice pointer
*
*  Returns: short
*       1 if successful.
*
***********************************************************************/
short FAR PASCAL TDocumentBeginMinHeader(LPPDEVICE lppd)
{
  RECT rect ;
  LPASCIIBINPTRS tempptr;
  short rc;
  WORD   KeywordIndex, index, len;
  WORD   CurrentKeywordIndex, OptionIndex;
  HANDLE  bufhdl  = NULL ;
  LPSTR  buf = NULL ;

  char buffer[80];
  char strBuff[256];
  char tmpBuff[256];
  LPSTR lpTempPS;
  int   iTempLen;
  LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
  LPBYTE lpStringBlock = lppd->lpWPXblock->WPXstrings;
  BOOL  bEPS = (lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS) ;
  LPSTR lpFileName= NULL;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

  // Remember these settings. Useful for Nup & %%ViewingOrientation DSC
  lppd->startingLayout = lppd->lpPSExtDevmode->dm.layout;
  lppd->startingOrient = lppd->lpPSExtDevmode->dm.PaperOrient;
  lppd->startingMirror = lppd->lpPSExtDevmode->dm.bMirror;

  buf = MGAllocLock(lppd, &bufhdl, PS_BUFSIZE_BIG, GHND, TRUE) ;

  // init the procset management list
  InitProcsetList(lppd);

  TInitGraphicState(lppd);
  TSetPen(lppd);
  TSetBrush(lppd);

   //
   // PS injection point IPS_BEGINSTREAM goes here
   //
   SendPSInjectionData(lppd, IPS_BEGINSTREAM, &lpTempPS, &iTempLen);

// do protocol -- if necessary
   PSSendBeginProtocol(lppd);

// Send the Normal DSC header comments

  (*tempptr->PSSendDSC)(lppd, DSC_adobe        , (LPSTR)NULL);             // %!PS-Adobe-2.0

   // make sure the lppd->szTitle is Cleant7Bit string.  # 188694 yct
   if (ValidateClean7BitData(lppd->szTitle))
      (*tempptr->PSSendDSC)(lppd, DSC_title, lppd->szTitle); 
   else
      // show Hex value or escape characters on %%Title: 
      ReturnHexOrEscapedCharString(lppd, lppd->szTitle, DSC_title);
      //(*tempptr->PSSendDSC)(lppd, DSC_title, szNonAscii); 

  (*tempptr->PSSendDSC)(lppd, DSC_bbox, (LPSTR)"(atend)");// %%BoundingBox: (atend)

  l_strdate( tempbuf );
  lstrcat((LPSTR)tempbuf,(LPSTR)" ");
  l_strtime( &tempbuf[lstrlen(tempbuf)] );
  (*tempptr->PSSendDSC)(lppd, DSC_date         , tempbuf );                // %%CreationDate:

  // Fix bug 83. Add %%For: UserName.
  rc=sizeof(buffer);
  GetCurrUserName(lppd, (LPSTR)buffer, &rc);  // rc contains the actual length of username
//  (*tempptr->PSSendDSC)(lppd, DSC_for, buffer);      // %%For: UserName

   // make sure the buffer is Cleant7Bit string.  # 188694 yct
   // EPS is always ascii data format.
   if (ValidateClean7BitData(buffer))
      (*tempptr->PSSendDSC)(lppd, DSC_for, buffer); 
   else
      // show Hex value or escape characters on %%For: 
      ReturnHexOrEscapedCharString(lppd, buffer, DSC_for);
      //(*tempptr->PSSendDSC)(lppd, DSC_for, szNonAscii); 

  // Fix bug 117504. Change %%Pages from 1 to (atend) for min-header apps.
  // 8/2/95   jjia
  (*tempptr->PSSendDSC)(lppd, DSC_pages_atend, (LPSTR)"(atend)");                // %%Pages: (atend)
  // delete in DSC 3.1
  //(*tempptr->PSSendDSC)(lppd, DSC_requirements , (LPSTR)szNone );          // %%Requirements:

#ifndef ADOBEPS42
  if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS  ))
  {
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szTwo);           // %%LanguageLevel: 2
  }else
  {
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szOne);           // %%LanguageLevel: 1
  }
#else
  // L3_CLIP
  if (lppd->lpPSExtDevmode->dm2.useLanguageLevel == 2) 
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szTwo);           // %%LanguageLevel: 2
  else if (lppd->lpPSExtDevmode->dm2.useLanguageLevel == 3)
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szThree);         // %%LanguageLevel: 3
#endif

//(*tempptr->PSSendDSC)(lppd, DSC_extensions   , (LPSTR)szQuestion);        // %%Extensions:

   // %%TagetDevice:   new in DSC 3.1
   // Get product name and PSversion
   buffer[0] = 0;
   lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->Product.dword);
   if (lpFileName)
      lstrcpy(buffer, lpFileName);
   lstrcat (buffer, BLANK);  
   lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->PSVersion.dword);
   if (lpFileName)
         lstrcat(buffer, lpFileName);
   (*tempptr->PSSendDSC)(lppd, DSC_targetdevice, (LPSTR)buffer);

   // for NT compatibility
   // give app or OEM a chance to emit their %%DocumentProcessColorsAtEnd:
   //
   (*tempptr->PSSendDSC)(lppd, DSC_documentprocesscolorsatend, NULL);

  (*tempptr->PSSendDSC)(lppd, DSC_endcomments  , (LPSTR)NULL );            // %%EndComments"
  (*tempptr->PSSendCRLF)(lppd);

   (*tempptr->PSSendDSC)(lppd, DSC_begindefaults  , (LPSTR)NULL );
   // %%PageBoundingBox:    new DSC 3.1
   (*tempptr->PSSendDSCBBox)(lppd, DSC_pagebbox, (LPRECT)&lppd->bbox);

   TSendViewingOrientation(lppd, TRUE);

   // add %%PageFeature here DSC 3.1 new    
   //(*tempptr->PSSendDSC)(lppd, DSC_pagefeature  , (LPSTR)NULL );


   // %%PageFeatures: defaultoption
   // list all the default option
   if (buf != NULL)
   {   // Get first keyword index
      rc = KeywordNextOrderedKeyword(lppd,(LPWORD)&KeywordIndex, FIRST_LAST_KEYWORD-DOCSETUP);
     (*tempptr->PSSendDSC)(lppd, DSC_pagefeatures , (LPSTR)NULL );

     while (rc == TRUE && KeywordIndex != FIRST_LAST_KEYWORD)
     {
      
       len = KeywordGetMainKeyword (lppd, KeywordIndex, buf, PS_BUFSIZE_BIG);
       KeywordGetDefaultOption(lppd, KeywordIndex, (LPWORD) &OptionIndex);
       // output the default option for each mainkeyword
       if (OptionIndex != 0xFFFF) {     // Option present
         int len2;
         if ((lstrcmp(buf, "Collate") == 0) && lppd->lpPSExtDevmode->dm2.bWebPrinter)
            goto  nextkey;

         lstrcpyn( tmpBuff, buf, len+1 ); // when 
         len2 = KeywordGetOption(lppd, KeywordIndex, OptionIndex, 
                          buf, PS_BUFSIZE_BIG);
         lstrcat( tmpBuff, BLANK );
         lstrcpyn( &tmpBuff[len+1], (LPSTR) buf, len2+1 );  // get option keyword
       }
       // if it is input slot and the slot id is DMBIN_AUTO
       // The DSC %%BeginFeature use the unlocalized string instead of
       // getting it from option string. #194358
        if (KeywordIndex == IND_INPUTSLOTINFO)
        {

         LPPRINTERINFO lpPrinterInfo;
         LPBYTE      lpOptionsBlock;
         LPMAINKEYHDR  lpInputSlotInfoHdr ;
         LPINPUTSLOTINFO   lpExtraInputSlotInfo ;

         lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo ;
         lpOptionsBlock = lppd->lpWPXblock->WPXarrays ;
         lpInputSlotInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;
         lpExtraInputSlotInfo = (LPINPUTSLOTINFO)MAKELONG(
         lpInputSlotInfoHdr->extraOptionArray, HIWORD(lpOptionsBlock) );
         if (lpExtraInputSlotInfo[OptionIndex].slotID == DMBIN_AUTO)
         {
            LoadString(ghDriverMod, ID_DSCSTR_AUTOSELECTTRAY, strBuff, sizeof(strBuff));
            lstrcat( tmpBuff, BLANK );
            lstrcpy( &tmpBuff[len+1], (LPSTR) strBuff);  // get DSC string
         }

        }
        lstrcpy(strBuff, "*");
        lstrcat(strBuff, tmpBuff);
        AddFeatureDSCEntry(lppd, tmpBuff, TRUE, FALSE); // TRUE = supplied
        (*tempptr->PSSendDSC)(lppd, DSC_plus,strBuff);        // %%+ *page feature
       
nextkey:
       // Get next keyword index
       CurrentKeywordIndex = KeywordIndex;
       rc = KeywordNextOrderedKeyword(lppd, (LPWORD)&KeywordIndex, CurrentKeywordIndex);

      } //end while
   }

   (*tempptr->PSSendDSC)(lppd, DSC_enddefaults  , (LPSTR)NULL );
   (*tempptr->PSSendCRLF)(lppd);

// Patch code - begin
   // Emit Patch file string if it exists
   if (lpPrinterInfo->PatchFile.w.length  &&  !bEPS)
   {
      (*tempptr->PSSendDSC)(lppd, DSC_begin_patchfile  , (LPSTR)NULL);

      EmitStringRef(lppd, lpPrinterInfo->PatchFile.dword) ;
      (*tempptr->PSSendCRLF)(lppd);
      (*tempptr->PSSendDSC)(lppd, DSC_end_patchfile, (LPSTR)NULL);
      (*tempptr->PSSendCRLF)(lppd);
   }

   // Emit Job Patch file string if it exists

   for (index = 0 ; index < lpPrinterInfo->nJobPatchFiles  &&  !bEPS ; index++)
   {
      char   zTemp[8] ;

      wsprintf((LPSTR)zTemp,(LPSTR)"%d",
         lpPrinterInfo->JobPatchFile[index].order);

//      PSSendFragment(lppd,PSFRAG_beginsafe);
      // At this jobpatch file time, beginsafe/endsafe is not defined yet
      // - they are in utils0.ps sent after this point.
      // So, use the old simple safe way without cleanup dictstack. fix bug 142806, 2-7-96
      PSSendString( lppd, "[{" );
      (*tempptr->PSSendCRLF)(lppd);

      (*tempptr->PSSendDSC)(lppd, DSC_begin_jobpatchfile  , (LPSTR)zTemp);

      EmitStringRef(lppd, lpPrinterInfo->JobPatchFile[index].invoc.dword) ;
      (*tempptr->PSSendCRLF)(lppd);
      (*tempptr->PSSendDSC)(lppd, DSC_end_jobpatchfile    , (LPSTR)NULL);
//      PSSendFragment(lppd,PSFRAG_endsafe);
      PSSendString( lppd, "} stopped cleartomark" );
      (*tempptr->PSSendCRLF)(lppd);
   }
// PatchFile code - end


// Send the Prolog

  (*tempptr->PSSendDSC)(lppd, DSC_beginprolog , (LPSTR)NULL );             // %%BeginProlog

   // Send the featurecleanup def in userdict right after BegineProlog - fix bug 145235
   PSSendProc(lppd,PSPROC_feature_safe);

   // Send the FatalErrorIf & PrtVMMsg because error handler uses it
   PSSendProc(lppd,PSPROC_fatalerr_ps1);
   TSendHeaderPrtVMMsg(lppd);

  if(lppd->lpPSExtDevmode->dm2.bErrHandler == TRUE)
  {
     // send the error handler
     PSSendProc(lppd,PSPROC_ehandler);
  }
  else
  {
     // send the error handler that only handle VMerror
     PSSendProc(lppd,PSPROC_vmehandler);
  }

  PSSendProc(lppd, PSPROC_minheader);                       // %%BeginResource:
                                                            //    :
                                                            //   procset
                                                            //    :
                                                            // %%EndResource
  // Send Utils resources, fix bug 139 (forAcrobat and other Min_header apps)
#ifndef ADOBEPS42
  // LEVEL 2 ONLY
  if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS  ))
  {
     PSSendProc(lppd, PSPROC_min_utils0_ps2);
     PSSendProc(lppd,PSPROC_mhutils2_ps2);
  }else
  {
     PSSendProc(lppd,PSPROC_min_utils0_ps1);
     PSSendProc(lppd,PSPROC_utils1_ps1);
     PSSendProc(lppd,PSPROC_utils2_ps1);
  }
#else
  PSSendProc(lppd, PSPROC_min_utils0_ps2);
  PSSendProc(lppd,PSPROC_mhutils2_ps2);
  // L3_CLIP
  if (lppd->lpPSExtDevmode->dm2.useLanguageLevel >= 3)
      PSSendProc(lppd,PSPROC_clipsave_ps3);
#endif

#ifndef ADOBEPS42
  // Send watermark defs, fix bug 187, 5-3-1995
   if ( (lppd->lpPSExtDevmode->dm.layout != ONE_UP ) &&
       (lppd->disableNUP == 0) ){
      PSSendProc(lppd,PSPROC_nup_ps1);  // PSPROC_nup_ps2 is the same.
         }
#else
  // Send nup defs, fix bug 187, 5-3-1995
   if ( (lppd->lpPSExtDevmode->dm.layout != ONE_UP ) &&
       (lppd->disableNUP == 0) ){
      PSSendProc(lppd,PSPROC_nup_ps2);
         }
#endif

  PSSendFragment(lppd, PSFRAG_end);      // Fix bug 142366
  (*tempptr->PSSendCRLF)(lppd);

  // before EndProlog, send special PASSTHROUGH PS data, 5-1-95
  TSendSpecialPSData(lppd);


  (*tempptr->PSSendDSC)(lppd, DSC_endprolog   , (LPSTR)NULL );             // %%EndProlog"
  (*tempptr->PSSendCRLF)(lppd);


  lppd->lpProcsetstuff->currpagenumber = 1;           // initialize page number
 
  // now do the document setup section

  (*tempptr->PSSendDSC)(lppd, DSC_beginsetup, (LPSTR)NULL );               // %%BeginSetup
   // new in DSC 3.1
   // Add DSC_begindevicesetup
  // (*tempptr->PSSendDSC)(lppd, DSC_begindevicesetup, (LPSTR)NULL );
  // (*tempptr->PSSendCRLF)(lppd);


  // Echo product on back-channel
  PSSendFragment(lppd, PSFRAG_productname);
  (*tempptr->PSSendCRLF)(lppd);

  PSSendFragment(lppd, PSFRAG_epsprintsetup);                     // "Adobe_Passion_0.1_Min etc.

  (*tempptr->PSSendCRLF)(lppd);

//Send Device Feature PostScript (Manual Feed, InputSlot, # copies, etc.

  rc = TSendDeviceFeatures(lppd);

   // new in DSC 3.1
   // Add DSC_enddevicesetup
   //(*tempptr->PSSendDSC)(lppd, DSC_enddevicesetup, (LPSTR)NULL );
   //(*tempptr->PSSendCRLF)(lppd);

   // new in DSC 3.1
   // Add DSC_begindocumentsetup
   //(*tempptr->PSSendDSC)(lppd, DSC_begindocumentsetup, (LPSTR)NULL );
   //(*tempptr->PSSendCRLF)(lppd);


//Construct the coordinate transformation matrix(CTM).

  if (lppd->lpPSExtDevmode->dm.marginState == NO_MARGINS) //Full page is imageable.
      SetRect(&rect, 0, 0,lppd->ptPaperDim.x,lppd->ptPaperDim.y) ;
  else
      rect = lppd->imageRect ;

// Send PostScript proc that defines the coordinate transformation
//  matrix(CTM).
  PSSendMySetup( lppd, &rect, SETUP_PS_COORDS );

  // ADOBE_SPOOLER
  // PSSendFragment(lppd, PSFRAG_InitEnv);

   // new in DSC 3.1
   // Add DSC_enddocumentsetup
   //(*tempptr->PSSendDSC)(lppd, DSC_enddocumentsetup, (LPSTR)NULL );
   //(*tempptr->PSSendCRLF)(lppd);


  (*tempptr->PSSendDSC)(lppd, DSC_endsetup, (LPSTR)NULL );                 // %%EndSetup"
  (*tempptr->PSSendCRLF)(lppd);

  if(lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE)
  {
     // if it is NOT Portability mode, do it in the StartTranslation()
     rc = FlushToSpool(lppd);   
     PortFirstStartSpoolPage(lppd); 
  }

  MGUnlockFree(lppd, bufhdl, TRUE) ;

//Reset the port's dirty flag.
  PortClean(lppd);

  return(1);
}


/***********************************************************************
*                      TDocumentEndMinHeader
*  Purpose:
*       Handle TDocumentEnd token for printable PostScript format
*       in minimal header (EPSPrinting) mode.
*
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*
*  returns: short
*       1 if successful.
*
***********************************************************************/
short FAR PASCAL TDocumentEndMinHeader(LPPDEVICE lppd)
{
   LPASCIIBINPTRS tempptr;
   int cb;
   CHAR  szTemp[64];
   short CurrPageNumber;
   LPSTR lpTempPS;
   int   iTempLen;
   int   iCount;

   iCount = 0;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

  // Send watermark final page, because showpage is replaced by nupshowpage.
  // we need this in case the job ends in the middle of a physical page. fix bug 187, 5-3-1995
   if ( (lppd->lpPSExtDevmode->dm.layout != ONE_UP ) &&
       (lppd->disableNUP == 0) )
   { 
     PSSendFragment(lppd, PSFRAG_finalpageNup);
     (*tempptr->PSSendCRLF)(lppd);
   }
   
   if(lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE)
   {
      // if it is NOT Portability mode, do it in the EndTranslation()
      // call OEM for last physical page index
      AdobeOEMSendPSStub(lppd, PS_INDEX_PHYSICAL_PAGES, NULL, 0);  
      PortLastEndSpoolPage(lppd);  
   }

   (*tempptr->PSSendDSC)(lppd, DSC_trailer, (LPSTR) NULL );
   iCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
   
   // for NT compatibility
   // give app or OEM a chance to enter their %%DocumentProcessColors:
   //
   (*tempptr->PSSendDSC)(lppd, DSC_documentprocesscolors, (LPSTR)NULL);     


   (*tempptr->PSSendDSCBBox)(lppd, DSC_bbox, (LPRECT)&lppd->bbox);
   iCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
   
   PSSendFragment(lppd,PSFRAG_termMinHdr);
   iCount += PSGetFragmentLength(lppd, PSFRAG_termMinHdr);
   (*tempptr->PSSendCRLF)(lppd);
   iCount += 2;

   // Need this for minheader app.
   iCount += TSendFontDSCStuff(lppd, FALSE);  // %%DocumentNeededFonts & %%DocumentSuppliedFonts

   // %%DataCount:    new DSC3.1
   // %%+ Jrandom 32 
   iCount += PrintPassthroughInfo(lppd, iCount);

   // Fix bug 117504. Change %%Pages from 1 to (atend) for min-header apps.
   // 8/2/95   jjia
   if(lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS )
   {
      // Send %%Pages: DSC we promised in the Job Header section (remember atend ?) 
      // Do this only for Non EPS files as EPS files already have this sent 
      // at the beginning of the document.
      CurrPageNumber = lppd->lpProcsetstuff->currpagenumber;
      if (CurrPageNumber < 2)
          CurrPageNumber = 2;
      cb = wsprintf(szTemp, "%d", (CurrPageNumber - 1));
      (*tempptr->PSSendDSC)(lppd, DSC_pages, (LPSTR)szTemp);
      iCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);      
      PSSendFragment(lppd,PSFRAG_openbracket);
      iCount += PSGetFragmentLength(lppd, PSFRAG_openbracket);
      
      PSSendString(lppd,  (LPSTR)"%%[ LastPage ]%%" );
      iCount += 16;
      PSSendFragment(lppd,PSFRAG_closebracket);
      iCount += PSGetFragmentLength(lppd,PSFRAG_closebracket);

      PSSendString(lppd,  (LPSTR) " = flush");
      (*tempptr->PSSendCRLF)(lppd);
      iCount += 10;
   }
   // new in DSC 3.1 %%TrailerLength count
   // add len after %%Trailer
   wsprintf(szTemp, "%d", iCount);
   (*tempptr->PSSendDSC)(lppd, DSC_trailerlength, (LPSTR)szTemp);

   (*tempptr->PSSendDSC)(lppd, DSC_eof, (LPSTR)NULL );
   
   // do protocol -- if necessary
   PSSendEndProtocol(lppd);

   // PS Injection point IPS_ENDSTREAM goes here
   SendPSInjectionData(lppd, IPS_ENDSTREAM, &lpTempPS, &iTempLen);

   return(RC_ok);

}  // END TDocumentEndMinHeader


/***********************************************************************
*                      TDocumentBeginMinHeaderEPS
*  Purpose:
*       Handle TDocumentBegin token for EPS format output in minimal
*       header (EPSPrinting) mode. We don't need to do anything, since 
*       in MinHeader mode the literal PostScript data emitted by the 
*       application is already well-formed EPS (or should be).  However, 
*       we do a bit of initialisation just to be on the safe side.
*
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*
*  returns: short
*       1 if successful.
*
***********************************************************************/
short FAR PASCAL TDocumentBeginMinHeaderEPS(LPPDEVICE lppd)
{
  RECT rect ;
  LPASCIIBINPTRS tempptr;
  char buffer[80]; 
  int rc;
  LPSTR lpTempPS;
  int iTempLen;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

  // Remember these settings. Useful for Nup & %%ViewingOrientation DSC
  lppd->startingLayout = lppd->lpPSExtDevmode->dm.layout;
  lppd->startingOrient = lppd->lpPSExtDevmode->dm.PaperOrient;
  lppd->startingMirror = lppd->lpPSExtDevmode->dm.bMirror;

  // init the procset management list
  InitProcsetList(lppd);

  TInitGraphicState(lppd);
  TSetPen(lppd);
  TSetBrush(lppd);

   //
   // PS injection point IPS_BEGINSTREAM goes here
   //
   SendPSInjectionData(lppd, IPS_BEGINSTREAM, &lpTempPS, &iTempLen);

// Send the Normal DSC header comments

  (*tempptr->PSSendDSC)(lppd, DSC_epsf         , (LPSTR)NULL);             // %!PS-Adobe-2.0 EPSF-2.0
   // make sure the lppd->szTitle is Cleant7Bit string.  # 188694 yct
   // EPS is always ascii data format.
   if (ValidateClean7BitData(lppd->szTitle))
      (*tempptr->PSSendDSC)(lppd, DSC_title, lppd->szTitle); 
   else
      // show Hex value or escape characters on %%Title: 
      ReturnHexOrEscapedCharString(lppd, lppd->szTitle, DSC_title);
      //(*tempptr->PSSendDSC)(lppd, DSC_title, szNonAscii); 

  rect =  lppd->bbox ;
  if( lppd->lpPSExtDevmode->dm.PaperOrient != OR_PORTRAIT)
  {
      int   temp = rect.top;
      rect.top = rect.right;
      rect.right = temp;
  }
  (*tempptr->PSSendDSCBBox)(lppd, DSC_bbox     , &rect);// %%BoundingBox:
//  (*tempptr->PSSendDSCBBox)(lppd, DSC_bbox     , &lppd->bbox);// %%BoundingBox:

                                    // %%Creator: ADOBEPS4.DRV Version 4.1
  (*tempptr->PSSendDSC)(lppd, DSC_creator, szIniCreator);        

  l_strdate( tempbuf );
  lstrcat((LPSTR)tempbuf,(LPSTR)" ");
  l_strtime( &tempbuf[lstrlen(tempbuf)] );
  (*tempptr->PSSendDSC)(lppd, DSC_date         , tempbuf );                // %%CreationDate:

   // Add For: User name. Fix bug 83. We may choose not do this for EPS, if there is a reason
  rc=sizeof(buffer);
  GetCurrUserName(lppd, (LPSTR)buffer, &rc);  // rc contains the actual length of username
  //(*tempptr->PSSendDSC)(lppd, DSC_for, buffer);      // %%For: UserName

   // make sure the buffer is Cleant7Bit string.  # 188694 yct
   // EPS is always ascii data format.
   if (ValidateClean7BitData(buffer))
      (*tempptr->PSSendDSC)(lppd, DSC_for, buffer); 
   else
      // show Hex value or escape characters on %%For: 
      ReturnHexOrEscapedCharString(lppd, buffer, DSC_for);
      //(*tempptr->PSSendDSC)(lppd, DSC_for, szNonAscii); 

  (*tempptr->PSSendDSC)(lppd, DSC_pages        , (LPSTR)szOne);              // %%Pages:
  // delete in DSC 3.1
//  (*tempptr->PSSendDSC)(lppd, DSC_requirements , (LPSTR)szNone );          // %%Requirements:

#ifndef ADOBEPS42
  // Fix bug 120631. jjia. 11/1/95
  // EPS files created with adobe driver should include level2 feature.
#ifdef ADOBE_DRIVER
  if (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE)
#else
  if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS  ))
#endif
  {
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szTwo);           // %%LanguageLevel: 2
  }else
  {
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szOne);           // %%LanguageLevel: 1
  }
#else
//  (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szTwo);           // %%LanguageLevel: 2
  if (lppd->lpPSExtDevmode->dm2.useLanguageLevel == 2) 
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szTwo);           // %%LanguageLevel: 2
  else if (lppd->lpPSExtDevmode->dm2.useLanguageLevel == 3)
     (*tempptr->PSSendDSC)(lppd, DSC_languagelevel, (LPSTR)szThree);         // %%LanguageLevel: 3

#endif

   // for NT compatibility
   // give app or OEM a chance to emit their %%DocumentProcessColorsAtEnd:
   //
   (*tempptr->PSSendDSC)(lppd, DSC_documentprocesscolorsatend, NULL);

//(*tempptr->PSSendDSC)(lppd, DSC_extensions   , (LPSTR)szQuestion);        // %%Extensions:
  (*tempptr->PSSendDSC)(lppd, DSC_endcomments  , (LPSTR)NULL );            // %%EndComments"
  (*tempptr->PSSendCRLF)(lppd);

  (*tempptr->PSSendDSC)(lppd, DSC_begindefaults  , (LPSTR)NULL );
  TSendViewingOrientation(lppd, TRUE);
  (*tempptr->PSSendDSC)(lppd, DSC_enddefaults  , (LPSTR)NULL );
  (*tempptr->PSSendCRLF)(lppd);

// Send the (minimal) Prolog

  (*tempptr->PSSendDSC)(lppd, DSC_beginprolog , (LPSTR)NULL );             // %%BeginProlog

  // Fix bug 126385. JJIA.  1/17/96
  // Error handler should be suppressed in EPS.
#if 0
  if(lppd->lpPSExtDevmode->dm2.bErrHandler == TRUE)
  {
     // send the error handler
     PSSendProc(lppd,PSPROC_ehandler);
  }
#endif

  PSSendProc(lppd, PSPROC_minheader);                       // %%BeginResource:
                                                            //    :
                                                            //   procset
                                                            //    :
                                                            // %%EndResource
  // Send Utils resources, fix bug 139 (forAcrobat and other Min_header apps)
#ifndef ADOBEPS42
  // LEVEL 2 ONLY
  if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS  ))
  {
     PSSendProc(lppd, PSPROC_min_utils0_ps2);
     PSSendProc(lppd,PSPROC_mhutils2_ps2);
  }else
  {
     PSSendProc(lppd,PSPROC_min_utils0_ps1);
     PSSendProc(lppd,PSPROC_utils1_ps1);
     PSSendProc(lppd,PSPROC_utils2_ps1);
  }
#else
  PSSendProc(lppd, PSPROC_min_utils0_ps2);
  PSSendProc(lppd,PSPROC_mhutils2_ps2);
  // L3_CLIP
  if (lppd->lpPSExtDevmode->dm2.useLanguageLevel >= 3)
      PSSendProc(lppd,PSPROC_clipsave_ps3);
#endif

  PSSendFragment(lppd, PSFRAG_end);      // Fix bug 142366
  (*tempptr->PSSendCRLF)(lppd);

  // before EndProlog, send special PASSTHROUGH PS data, 5-1-95
  TSendSpecialPSData(lppd);

  (*tempptr->PSSendDSC)(lppd, DSC_endprolog   , (LPSTR)NULL );             // %%EndProlog"
  (*tempptr->PSSendCRLF)(lppd);

  (*tempptr->PSSendDSC)(lppd, DSC_beginsetup, (LPSTR)NULL );               // %%BeginSetup
  
  // Echo product on back-channel
  PSSendFragment(lppd, PSFRAG_productname);
  (*tempptr->PSSendCRLF)(lppd);

  // Add DSC_begindocumentsetup
  //(*tempptr->PSSendDSC)(lppd, DSC_begindocumentsetup, (LPSTR)NULL );
  //(*tempptr->PSSendCRLF)(lppd);

  PSSendFragment(lppd, PSFRAG_epsprintsetup);                     // "Adobe_Passion_0.1_Min etc.
  (*tempptr->PSSendCRLF)(lppd);

//Construct the coordinate transformation matrix(CTM).

  if (lppd->lpPSExtDevmode->dm.marginState == NO_MARGINS) //Full page is imageable.
      SetRect(&rect, 0, 0,lppd->ptPaperDim.x,lppd->ptPaperDim.y) ;
  else
      rect = lppd->imageRect ;

  // Fix for #17791 - ShyamV - 03/14/94
  {
     PAP_ORIENT temp;

     temp = lppd->lpPSExtDevmode->dm.PaperOrient;
     lppd->lpPSExtDevmode->dm.PaperOrient = OR_PORTRAIT;  // Force portrait
     PSSendMySetup( lppd, &rect, SETUP_PS_COORDS );// Send CTM for min header EPS.
     lppd->lpPSExtDevmode->dm.PaperOrient = temp;
  }

  // ADOBE_SPOOLER
  // PSSendFragment(lppd, PSFRAG_InitEnv);

   // new in DSC 3.1
   // Add DSC_enddocumentsetup
   //(*tempptr->PSSendDSC)(lppd, DSC_enddocumentsetup, (LPSTR)NULL );
   //(*tempptr->PSSendCRLF)(lppd);

  (*tempptr->PSSendDSC)(lppd, DSC_endsetup, (LPSTR)NULL );      // %%EndSetup"
  (*tempptr->PSSendCRLF)(lppd);

  lppd->lpProcsetstuff->currpagenumber = 1;           // initialize page number
 
//Reset the port's dirty flag.
  PortClean(lppd);

  return(1);
}

/***********************************************************************
*                      TDocumentEndMinHeaderEPS
*  Purpose:
*       Handle TDocumentEnd token for EPS format output in minimal 
*       header (EPSPrinting) mode. 
*       We don't need to do anything, since in MinHeader mode the 
*       literal PostScript data emitted by the application is already
*       well-formed EPS (or should be).
*
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*
*  returns: short
*       1 if successful.
*
***********************************************************************/
short FAR PASCAL TDocumentEndMinHeaderEPS(LPPDEVICE lppd)
{
   LPASCIIBINPTRS tempptr;
   LPSTR lpTempPS;
   int iTempLen;
   int iCount;
   char szTemp[64];

   iCount = 0;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   (*tempptr->PSSendDSC)(lppd, DSC_trailer, (LPSTR) NULL );

   // for NT compatibility
   // give app or OEM a chance to enter their %%DocumentProcessColors:
   //
   (*tempptr->PSSendDSC)(lppd, DSC_documentprocesscolors, (LPSTR)NULL);     

   iCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
   
   PSSendFragment(lppd,PSFRAG_termMinHdr);
   iCount += PSGetFragmentLength(lppd,PSFRAG_termMinHdr);

   (*tempptr->PSSendCRLF)(lppd);
   iCount += 2;

   // %%DataCount:    new DSC3.1
   // %%+ Jrandom 32 

   iCount += PrintPassthroughInfo(lppd, iCount);
   // The last entry is NULL

  
   // new in DSC 3.1 %%TrailerLength count
   wsprintf(szTemp, "%d", iCount);
   (*tempptr->PSSendDSC)(lppd, DSC_trailerlength, (LPSTR)szTemp);
   (*tempptr->PSSendDSC)(lppd, DSC_eof, (LPSTR)NULL );
   
   // PS Injection point IPS_ENDSTREAM goes here
   SendPSInjectionData(lppd, IPS_ENDSTREAM, &lpTempPS, &iTempLen);

   return(RC_ok);

}  // END TDocumentEndMinHeaderEPS


/***********************************************************************
*                      TDocumentPageBeginMinHeaderEPS
*  Purpose:
*       Handle TDocumentPageBegin token for EPS format output in 
*       minimal header (EPSPrinting) mode.
*       We don't need to do anything, since in MinHeader mode the 
*       literal PostScript data emitted by the application is already
*       well-formed EPS (or should be).
*
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*
*  returns: short
*       1 if successful.
*
***********************************************************************/
short FAR PASCAL TDocumentPageBeginMinHeaderEPS(LPPDEVICE lppd)
{
   return( 1 );

}  // END TDocumentPageBeginMinHeaderEPS



/***********************************************************************
*                      TDocumentPageEndMinHeaderEPS
*  Purpose:
*       Handle TDocumentPageEnd token for EPS format output in minimal 
*       header (EPSPrinting) mode.
*       We don't need to do anything, since in MinHeader mode the 
*       literal PostScript data emitted by the application is already
*       well-formed EPS (or should be).
*
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*
*  returns: short
*       1 if successful.
*
***********************************************************************/
short FAR PASCAL TDocumentPageEndMinHeaderEPS(LPPDEVICE lppd)
{
   return( 1 );

}  // END TDocumentPageEndMinHeaderEPS

/***********************************************************************
*                       TRawPrinterStart_MinHdr
*  Purpose:
*       Performs startup processing for Raw Printer Data in minimal 
*       header mode.
*
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*
*  returns: short
*       short RC_ok => success, RC_fail => failure
*
************************************************************************/
short FAR PASCAL TRawPrinterStart_MinHdr(LPPDEVICE lppd)
{
   short sRC=RC_ok;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   // start new entry
   sRC = SavePassthroughInfo(lppd);

   return(sRC);

}  // END TRawPrinterStart_MinHdr


/***********************************************************************
*                       TRawPrinterEnd_MinHdr
*  Purpose:
*
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*
*  returns: short
*       short RC_ok => success, RC_fail => failure
*
************************************************************************/
short FAR PASCAL TRawPrinterEnd_MinHdr(LPPDEVICE lppd)
{

   PrintPassthroughEndDSC(lppd);

   return(RC_ok);

}  // END TRawPrinterEnd_MinHdr

/*****************************************************************************
*                               TJobCopiesEPS
*  Purpose:
*       Dummy function to processes a token for the number of copies 
*       for EPS if apps. call ESCSetCopyCount, while outputting EPS
*
*  paremeters:
*       LPPDEVICE lppd -- pdevice pointer
*       WORD wCopies -- number of copies
*
*  returns: short
*       always returns RC_ok => success
*
*****************************************************************************/
short FAR PASCAL TJobCopiesEPS(LPPDEVICE lppd, WORD wCopies)
{
   return(RC_ok);

}  // END TJobCopiesEPS


/*****************************************************************************
*                               TJobDuplexEPS
*  Purpose:
*       Dummy function to processes a token for Duplex 
*       if apps. call ESCSetDuplex, while outputting EPS
*
*  paremeters:
*       LPPDEVICE lppd -- pdevice pointer
*       WORD      type --
*
*  returns: short
*       RC_ok => success
*
*****************************************************************************/
short FAR PASCAL TJobDuplexEPS(LPPDEVICE lppd, WORD type )
{
   return(RC_ok);

}  // END TJobDuplexEPS

/***********************************************************************
*                          TPaperSourceEPS
*  Purpose:
*       Dummy function to processes a token for setting the Paper Source
*       if apps. call ESCGetSetPaperBins, while outputting EPS
*
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*       LPSTR slot_name - ptr to string identifying paper source, eg. Upper Tray.
*
*  returns: short
*       RC_ok
*
***********************************************************************/
short FAR PASCAL TPaperSourceEPS(LPPDEVICE lppd, LPSTR slot_name)
{
   return(RC_ok) ;

} // END TPaperSourceEPS

/***********************************************************************
*                           TPaperSizeEPS
*  Purpose:
*       Dummy function to set the paper size to the specified media type.
*
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*       LPSTR media_name - ptr to string identifying paper size, eg. Envelope.
*
*  returns: short
*       RC_ok
*
***********************************************************************/
short FAR PASCAL TPaperSizeEPS(LPPDEVICE lppd, LPSTR media_name)
{
   return(RC_ok) ;

}  // END TPaperSizeEPS

/***********************************************************************
*                           TPageOrientationEPS
*  Purpose:
*
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*       LPSTR Orient --
*
*  returns: short
*
***********************************************************************/
short FAR PASCAL TPageOrientationEPS(LPPDEVICE lppd, WORD Orient )
{
   return(RC_ok) ;

}   // END TPageOrientationEPS

/***********************************************************************
*                           ValidateClean7BitData
*  Purpose: validate the input string is Clear&Bit data
*
*  parameter:
*       LPSTR lpstr -- input string
*
*  returns: BOOL  FALSE - contains non Clear&Bit data
*                 TRUE  - all Clear&bit data
*                         lpstr with nonClear&bit data stripped 
*
***********************************************************************/
BOOL FAR PASCAL ValidateClean7BitData(LPSTR lpstr)
{
   LPSTR tmp1;
   BOOL  bAscii7Bit=TRUE;

   tmp1 = lpstr;
      
   if( *tmp1 && *tmp1 == '(' )
      bAscii7Bit = FALSE;

   while (*tmp1 && bAscii7Bit)
   {
      if (*tmp1 < 0x20 || *tmp1 > 0x7E ) 
          bAscii7Bit = FALSE;
      else
          tmp1++;
   }
   return (bAscii7Bit);
}
/***********************************************************************
*                       ReturnHexOrEscapedCharString
*  Purpose: return either all Hex or escaped char string data
*
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*       LPSTR lpstr -- input string
*
*  returns: short - contains the size of the output data
*
***********************************************************************/
short FAR PASCAL ReturnHexOrEscapedCharString(LPPDEVICE lppd, LPSTR lpstr, int DSCstr)
{
   int  i, count;
   LONG aii=0, hex=0;
   BYTE b;
   LPSTR tmp1, tmp2;
   LPBYTE lpTemp;                               
   char  NumString[4];
   short dwLen;
   LPASCIIBINPTRS tempptr;            
 
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
     count = lstrlen(lpstr);
   hex = count*2;
   // Check the chars in lpstr to decide which way to go: Ascii7 or Hex.
   for (i=0; i<count; i++){
      b = *((LPBYTE)lpstr + i);
      if (b<0x20 || b>0x7E) aii += 4; // if sent as Ascii7, need four bytes "\001"  
      else if( b == '(' || b == '(' || b == '\\' ) aii += 2;
      else aii +=1; 
   }
   tmp1 = lpstr;
   lpTemp = GlobalAllocPtr(GHND, count * 4L+2); // consider for worst case
   tmp2 = lpTemp;
   if ( hex < aii )   // Send all Hex value
   {
      lstrcpy(tmp2, (LPSTR)"<");

      // send one-byte at a time:
      for (i=0; i<count; i++){
         b = *((LPBYTE)tmp1 + i);
         wsprintf(NumString, "%2.2X", b);       // Convert byte to Hex
         lstrcat(tmp2, NumString);       // Write to the buffer
      }
      //insert a right Hex-parenthesis
      lstrcat(tmp2, (LPSTR)">");
      dwLen = lstrlen(tmp2);
   }
   else   // ascii with possible escape sequence (\000)
   {
      //insert a left parenthesis
      lstrcpy(lpTemp, (LPSTR)"(");

      dwLen = (short)CToPSStr( lpTemp+1, (BYTE huge *) tmp1, (DWORD) count );
      //insert a right parenthesis
      lstrcat(lpTemp, (LPSTR)")");
      dwLen += 2;
   }
   (*tempptr->PSSendDSC)(lppd, DSCstr, (LPSTR)lpTemp); 

//   (*tempptr->PSSendDSC)(lppd, DSC_title, (LPSTR)lpTemp); 

   GlobalFreePtr(lpTemp) ;

   return (dwLen);
      
}
