/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: psdebug.h                                                    */
/*                                                                           */
/* Description: This module contains ...                                     */
/*                                                                           */
/*****************************************************************************/

#ifndef PSDEBUG_H
#define PSDEBUG_H

#ifdef PSDEBUG

#include <assert.h>

VOID PSDebugVMStatus(LPPDEVICE lppd);
VOID PSDebugVMPrint(LPPDEVICE lppd, LPSTR lpStr);

#define PSDEBUG_ASSERT(exp) \
	(assert(exp))

#define PSDEBUG_VMSTATUS(lppd) \
	(PSDebugVMStatusCheck(lppd))

#define PSDEBUG_VMPRINT(lppd, lpStr) \
	(PSDebugVMPrint(lppd, lpStr))

#else

#define PSDEBUG_ASSERT(exp) ((VOID)0)
#define PSDEBUG_VMSTATUS(lppd) ((VOID)0)
#define PSDEBUG_VMPRINT(lppd, lpStr) ((VOID)0)

#endif // PSDEBUG

#endif // PSDEBUG_H
