/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1994 Adobe Systems, Inc. All rights reserved.               */
/*                                                                           */
/* Module Name: WATERMAR.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for Watermark property    */
/*              sheet.                                                       */
/*                                                                           */
/*****************************************************************************/
#include "generic.h"
#include "apd42map.hh"

#pragma code_seg(_WATERMARKSEG)

#pragma check_stack (on)

#define TB_TIC_FREQ  5

#define MAX_COLOR   255
#define MIN_COLOR   0

// WM Font Size: 7 to 600
#define MAXWMSIZE 600
#define MINWMSIZE 7
#define MAXXPOS   9999
#define MINXPOS   -9999
#define MAXANG   90
#define MINANG   -90
#define MAXTEXTLEN 256


//    We repeat some definitions from windows.h here as they are
//    not visible to our code due to mysteries of nested include files

HBRUSH  WINAPI CreateSolidBrush(COLORREF);
HBITMAP WINAPI CreateBitmap(int, int, UINT, UINT, const void FAR*);
BOOL    WINAPI BitBlt(HDC, int, int, int, int, HDC, int, int, DWORD);
int     WINAPI GetDIBits(HDC, HBITMAP, UINT, UINT, void FAR*, BITMAPINFO FAR*, UINT);
int     WINAPI StretchDIBits(HDC, int, int, int, int, int,
                        int, int, int, const void FAR*, LPBITMAPINFO, UINT, DWORD);

HGDIOBJ WINAPI GetStockObject(int);
/* Stock brushes for use with GetStockObject() */
#define WHITE_BRUSH    0
#define LTGRAY_BRUSH   1
#define GRAY_BRUSH     2
#define DKGRAY_BRUSH   3
#define BLACK_BRUSH    4
#define NULL_BRUSH     5
#define HOLLOW_BRUSH   NULL_BRUSH

/* Stock pens for use with GetStockObject(); */
#define WHITE_PEN       6
#define BLACK_PEN       7
#define NULL_PEN        8
#define STYLE_LEN      40
/* DIB color table identifiers */
#define DIB_RGB_COLORS  0
#define DIB_PAL_COLORS  1


#define MALLOC(x)   WMalloc(x)  /* use macros for portability */
#define FREE(x)     WFree(x)

typedef BOOL (WINAPI *LPCHOOSECOLORFUN)(CHOOSECOLOR FAR*);

typedef struct
{
LPDRIVERINFO  lpDrvInfo;
int           IamEditing;          // 1==Edit, 0==New
DWORD         dwWatermarkID;
} EDITWM, FAR *LPEDITWM;

//  Locally used data structure and functions
typedef struct {                /* extra info for font enum proc */
    BYTE        eeMode;
    int         eeTypeMask;
    int         eeFamFound;
    int         eeStyIx;
    LPLOGFONT   eelf;
    LPSTR       eeStyle;
    HWND        eehDlg;
    WORD        eeIdcName;
    WORD        eeIdcStyle;
    WORD        eeIdcSize;
} ENUMEXTRA, FAR* LPENUMEXTRA;

int SetWMFontByType(HWND hDlg,HDC inhdc,LPLOGFONT plf,int FontType);

static BOOL NEAR PASCAL CheckWatermarkValues(HWND);
static void BuildWaterMarkDlg(HWND, LPDRIVERINFO);
static void ShowWaterMarkInfo(HWND, DWORD dwWatermarkID);
static void makefixed(LPSTR, int, int);
static void DisplayWaterMark(HWND hDlg, HDC hDC, LPPAINTSTRUCT ps, LPWM lpwm, WORD idcDisplay);
static void DisplayBlankWaterMark(HWND, HDC, LPPAINTSTRUCT, WORD);
static void GetWaterMarkDisplayArea(HWND, LPRECT, WORD);

static int CALLBACK FillFontComboBox(const ENUMLOGFONT FAR* elf, const NEWTEXTMETRIC FAR* ptm,
int type, LPARAM lParam);

static void ShowWaterMarkList(HWND hDlg, LPDRIVERINFO lpDrvInfo);
BOOL _loadds FAR PASCAL NewOrEditWMarkDlg(HWND hDlg, unsigned imsg, WORD wParam, LONG lParam);
BOOL  FAR PASCAL WMarkDelFn(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);
int FAR PASCAL InvalidatePreview(HWND hDlg, WORD idcDisplay, BOOL eraseBk);
int UnQuoteWMText(LPSTR s);
void PASCAL DeleteWatermark(DWORD dwWatermarkID);

int PASCAL GetIntFromStr(LPSTR FAR* pp);
void SetStyle(HWND hDlg, LPLOGFONT plf, WORD idcStyle);
void GetStyle(HWND hDlg, LPLOGFONT plf, WORD idcStyle);
int NEAR PASCAL SliderAngle(int iEs);
int NEAR PASCAL AngleSlider(int iSl);
void EnableEdits(HWND hDlg, LPDRIVERINFO lpDrvInfo, BOOL fl);

static VOID AddFontToComboBox(long, LPSTR);

static void UpdatePosControls(HWND);
static int GetCurrentInfo(HWND, LPWM);

static void EnumWMFonts(LPPDEVICE, HWND);

void FAR PASCAL FixedMulDivInt(int number, int mult, int div, int nDecimals,
                             LPINT quotient, LPINT remainder);
long FAR PASCAL GetDlgItemRealSigned(HWND hDlg, int ictrl, int nDecimals,
                                LPSTR decimalSeparator, LPBOOL lpbSuccess,
                                BOOL bBeep);
COLORREF NearestPhysicalColor(HDC hdc_in, BYTE R,BYTE G, BYTE B);
BOOL WINAPI ShowWatermark(HDC hdc,LPWM pwm, LPRECT lpr, SIZE sLogPage,BOOL FastMode);
void DefaultWm(LPWM pwm);
DWORD NEAR PASCAL GenerateWatermarkID(VOID);

// Bug fix for 143208, 143209, 143210, 143211. Moved from in 4.1CJK
int NEAR PASCAL GetMeasure(void);
long ConvertToUserUnit(long x);
long ConvertTo100thInch(long x);
void FAR PASCAL SignedSetCurrentSpinPos(HWND hDlg, int spinCtrl, int editCtrl,
                                   int nitems, int nDecimals);


// the following two are defined in trigs.c:
void PASCAL TransformRect(int a, LPRECT r, POINT o);
POINT PASCAL TransformPtbyAngle(POINT p,int a);

// global constant strings: make this driver localizable. PPeng, 3-8-1995

#define PS_REGULAR      0
#define PS_BOLD         1
#define PS_ITALIC       2
#define PS_BOLDITALIC   3

typedef struct {                /* Font info for watermark */
    char   FontName[50];
    char   DispName[50];    // used to show watermark if ATm is not on to rotate FontName
    int    UseDisp;
} WMFONTNAME, FAR* LPWMFONTNAME;

// These font names are localizable in PSWRITER.RC
static WMFONTNAME  StdFonts[IDS_WM_FONT_MAX-IDS_WM_FONT_MIN+1];
static char DefaultWMFont[50];   // used to be "Arial" - localizable now. 10-2-95

/*  Windows versions of malloc & free
 */
void FAR* PASCAL WMalloc(DWORD size) {
    HGLOBAL     h;
    void FAR*   p;

    h = GlobalAlloc(GMEM_MOVEABLE,size);
    if (!h) return NULL;

    p=GlobalLock(h);
    if (!p)
        GlobalFree(h);

    return p;
}

void PASCAL WFree(void FAR* p) {
    HGLOBAL     h;
    h = (HGLOBAL)LOWORD(GlobalHandle(SELECTOROF(p)));
    GlobalUnlock(h);
    GlobalFree(h);
}




/*****************************************************************************/
/*                 CHWaterMarksDlg                                                */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the Watermarks Features property sheet dialog box.     */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE -- If procedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/
BOOL _loadds FAR PASCAL CHWaterMarksDlg(HWND hDlg, unsigned imsg, WORD wParam,
                                   LONG lParam)
{
    LPDRIVERINFO   lpDrvInfo;
    BOOL           result = TRUE ;
    int index;
    HDC hDC;
    PAINTSTRUCT ps;
    EDITWM  editWM;
    LPEDITWM lpEditWM;
    DWORD dwUIFlags;
    LPPSEXTDEVMODE lpPSExtDevmode;
    WM wm;
    LPWM lpwm;
    char  sEmpty[] = "";          /* use wherever we need a ptr to a null */
    DWORD dwWatermarkID;

    /* Process hook function stuff */
    if(lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
    {
#ifdef USEHOOKPROC
  What is This ?????
        if(DrvProcessHookProc(&(lpDrvInfo->pDev),hDlg,imsg,wParam,lParam,
                              "HookSetup"))
        {
            return TRUE;
        }
#endif

        lpPSExtDevmode = lpDrvInfo->lpDM;
          dwUIFlags = lpDrvInfo->dwUIFlags[DI_WATERMARK];
    }

    switch (imsg)
    {
        case WM_INITDIALOG:
           lpDrvInfo=(LPDRIVERINFO)(((LPPROPSHEETPAGE)lParam)->lParam);
           SetWindowLong(hDlg,DWL_USER,(LPARAM)lpDrvInfo);
           lpPSExtDevmode=lpDrvInfo->lpDM;
           dwUIFlags = lpDrvInfo->dwUIFlags[DI_WATERMARK];

 // ??????, Test WM Edit from 16-bit apps.
//  dwUIFlags &= DI_PSTICKY;
 // ???????
           {
            char tmpName[128]; // to read "WMFontName,DisplaySubstituteName"
            LPSTR lpch;
            int i;
           // Initialize global Default WM Font List - read from resource:
           for (i=0; i<sizeof(StdFonts)/sizeof(StdFonts[0]); i++){
              StdFonts[i].FontName[0]='\0'; StdFonts[i].DispName[0]='\0'; // intial
              StdFonts[i].UseDisp=0;
              LoadString(ghDriverMod, i+IDS_WM_FONT_MIN, (LPSTR)tmpName, sizeof(tmpName));
              // If comma "," is present in tmpName, the second name is DisplaySubstitute Name
              if (lpch = lstrchr((LPSTR) tmpName, ',')) {
                  *lpch = '\0';
                  lpch++;
                  while (*lpch == ' ') lpch++; // skip spaces
                  lstrcpy((LPSTR)StdFonts[i].DispName, (LPSTR) lpch);
                  // By default - always use display-font if available. Fix a bug found by Kei Suzuki. PPeng, 11-13-95
                  if (lpch!=NULL && lpch[0]!='\0') StdFonts[i].UseDisp=1;
                  }
              lstrcpy((LPSTR)StdFonts[i].FontName, (LPSTR)tmpName);
              }
           }

           LoadString(ghDriverMod, IDS_WM_DEFAULT_FONT, (LPSTR)DefaultWMFont, sizeof(DefaultWMFont));

           ShowWaterMarkList(hDlg, lpDrvInfo);
           // delete 3 buttons if in App mode:
           if (dwUIFlags & DI_DSTICKY)
            {
             DestroyWindow(GetDlgItem(hDlg, ID_WATERMARK_NEW));
             DestroyWindow(GetDlgItem(hDlg, ID_WATERMARK_EDIT));
             DestroyWindow(GetDlgItem(hDlg, ID_WATERMARK_DELETE));
            }
           // Force re-paint preview:
           InvalidatePreview(hDlg, ID_WATERMARK_DISPLAY, TRUE);

        break ;

        case WM_CONTEXTMENU:
            if (wParam != -1)
            {
                WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                        (DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_HELP:
            if (((LPHELPINFO) lParam)->hItemHandle != -1)
            {
                WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                        HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_NOTIFY:
            switch (NOTIFY_CODE(lParam))
            {
               case PSN_APPLY:
                  UpdateGlobal(lpDrvInfo,TRUE);
                  SetWindowLong(hDlg,DWL_MSGRESULT,FALSE);
                  if ((lpDrvInfo != NULL))
                       {
                          lpDrvInfo->bPainting = FALSE;
                          lpDrvInfo->bChanged  = FALSE;
                          lpDrvInfo->wmChanged = FALSE;
                       }

                  WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
                  break;

               case PSN_RESET:
                  // If canceling, set lpDrvInfo->lpDM back to the
                  // saved devmode
                  lpDrvInfo->lpDM=&(lpDrvInfo->DMSave);
                  WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
                  break;
            }
            break;

    case WM_COMMAND:

           switch (wParam)
           {
         case ID_WATERMARK_EDIT:
            if (HIWORD(lParam) != BN_CLICKED)
               return result;
             index = (int) SendDlgItemMessage(hDlg, ID_WATERMARK_LIST, LB_GETCURSEL, 0, 0);
             if (index==LB_ERR)
             {
                index=0;
             }
             editWM.dwWatermarkID = (DWORD)SendDlgItemMessage(hDlg,ID_WATERMARK_LIST,
                                                   LB_GETITEMDATA, index, 0L);
             editWM.IamEditing=1;
             editWM.lpDrvInfo=lpDrvInfo;
             lpEditWM = (LPEDITWM)&editWM;

            DialogBoxParam(ghDriverMod, MAKEINTRESOURCE(IDD_EDITWATERMARK),
                  hDlg, NewOrEditWMarkDlg, (LPARAM)lpEditWM);
            ShowWaterMarkList(hDlg, lpDrvInfo);
            InvalidatePreview(hDlg, ID_WATERMARK_DISPLAY, TRUE);
            break;
            // We could fall through to call dialogboxparam, but OEM may want to only replace Edit....

         case ID_WATERMARK_NEW:
            if (HIWORD(lParam) != BN_CLICKED)
            {
               return result;
            }
            editWM.IamEditing=0;
            editWM.lpDrvInfo=lpDrvInfo;
            editWM.dwWatermarkID = 0;
            lpEditWM = (LPEDITWM)&editWM;

            DialogBoxParam(ghDriverMod, MAKEINTRESOURCE(IDD_EDITWATERMARK),
                  hDlg, NewOrEditWMarkDlg, (LPARAM)lpEditWM);
            ShowWaterMarkList(hDlg, lpDrvInfo);
            InvalidatePreview(hDlg, ID_WATERMARK_DISPLAY, TRUE);
           break;

         case ID_WATERMARK_DELETE:
            if (HIWORD(lParam) != BN_CLICKED)
            {
               return result;
            }
            index = (int) SendDlgItemMessage(hDlg, ID_WATERMARK_LIST, LB_GETCURSEL, 0, 0);
            if (index==LB_ERR) index=0;
            dwWatermarkID = (DWORD)SendDlgItemMessage(hDlg, ID_WATERMARK_LIST, LB_GETITEMDATA,
                                                      index, 0L);
            ReadWatermark(dwWatermarkID, (LPWM)&wm);

            if (DialogBoxParam(ghDriverMod, MAKEINTRESOURCE(IDD_WMDEL),
                 hDlg,WMarkDelFn, (LPARAM)(LPSTR)wm.text)==IDCANCEL)
            {
               return TRUE;
            }

            /* remove record from .INI file */
            DeleteWatermark(dwWatermarkID);

            // current selection is gone, default to [None]:
            lpPSExtDevmode->dm.dwWatermarkID = 0;  // Special

            if (lpDrvInfo != NULL)
            {
               lpDrvInfo->wmChanged = TRUE;
            }
            ShowWaterMarkList(hDlg, lpDrvInfo);
            InvalidatePreview(hDlg, ID_WATERMARK_DISPLAY, TRUE);

            // Fix bug 191151. 1/23/97   jjia
            // After deleting watermark, set focus to
            // the LIST box to allow keyboard movement.
            SetFocus(GetDlgItem(hDlg, ID_WATERMARK_LIST));

            break;

         case ID_WATERMARK_LIST:
            if (HIWORD(lParam) != LBN_SELCHANGE)
            {
               break;
            }
            index = (int)SendDlgItemMessage(hDlg, ID_WATERMARK_LIST, LB_GETCURSEL, 0, 0);
            if (index==LB_ERR)
            {
               index=0;
            }
            dwWatermarkID = SendDlgItemMessage(hDlg, ID_WATERMARK_LIST,
                                   LB_GETITEMDATA, index, 0L);
            if (index!=0)
            {
               lpPSExtDevmode->dm.dwWatermarkID = dwWatermarkID;
            }
            else
            {
               lpPSExtDevmode->dm.dwWatermarkID = 0;  // Special
            }
            InvalidatePreview(hDlg, ID_WATERMARK_DISPLAY, TRUE);
            if (lpDrvInfo != NULL)
            {
               lpDrvInfo->wmChanged = TRUE;
            }
            break;

#ifndef USE_WHATSTHIS_HELP
         case ID_HELP:
            WinHelp(hDlg, szHelpFile, HELP_CONTEXT,
                    IDH_PSCRIPT_CREATE_WATERMARK);
            break;
#endif

        case ID_WATERMARK_FIRSTPAGEONLY:
            if (HIWORD(lParam) != BN_CLICKED)
               return result;
            lpPSExtDevmode->dm.WMFirstPageOnly =
                SendDlgItemMessage(hDlg, ID_WATERMARK_FIRSTPAGEONLY,
                       BM_GETCHECK, 0, 0L) ? 1:0;
            lpDrvInfo->bChanged = TRUE;
            break;

        case ID_WATERMARK_BACKGROUND:
            if (HIWORD(lParam) != BN_CLICKED)
               return result;
            lpPSExtDevmode->dm.WMForeGround =
                SendDlgItemMessage(hDlg, ID_WATERMARK_BACKGROUND,
                       BM_GETCHECK, 0, 0L) ? 0:1;
            lpDrvInfo->bChanged = TRUE;
            break;

        case ID_WATERMARK_OUTLINE:
            if (HIWORD(lParam) != BN_CLICKED)
               return result;
            lpPSExtDevmode->dm.WMOutline =
                SendDlgItemMessage(hDlg, ID_WATERMARK_OUTLINE,
                       BM_GETCHECK, 0, 0L) ? 1:0;
            lpDrvInfo->bChanged = TRUE;
            break;

         default:
            result = FALSE ;
                    break ;
         } /* switch(wParam)  For case WM_COMMAND*/
         break ;

    case WM_PAINT:
       // We saved the user's selection in lpPSExtDevmode->dm.dwWaterMarkID
        dwWatermarkID = lpPSExtDevmode->dm.dwWatermarkID;
        lpwm = (LPWM)&wm;
        ReadWatermark(dwWatermarkID, lpwm);
        hDC = BeginPaint(hDlg, &ps);
        if (dwWatermarkID == 0)
        {
           DisplayBlankWaterMark(hDlg, hDC, &ps, ID_WATERMARK_DISPLAY);
           EnableEdits(hDlg, lpDrvInfo, FALSE);
        }
        else
        {
           DisplayWaterMark(hDlg, hDC, &ps, lpwm, ID_WATERMARK_DISPLAY);
           EnableEdits(hDlg, lpDrvInfo, TRUE);
        }
        EndPaint(hDlg, &ps);
        break;

    default:
        lpDrvInfo = NULL;
        result = FALSE ;
        break ;
    } /* switch(imsg) */

    if ((lpDrvInfo != NULL) && (lpDrvInfo->wmChanged || lpDrvInfo->bChanged))
        PropSheet_Changed( GetParent(hDlg), hDlg );
    return result ;
}

void EnableEdits(HWND hDlg, LPDRIVERINFO lpDrvInfo, BOOL fl)
{
DWORD dwUIFlags;
   dwUIFlags = lpDrvInfo->dwUIFlags[DI_WATERMARK];
    if (!(dwUIFlags & DI_DSTICKY))
    { // these three are not available for doc
       EnableWindow(GetDlgItem(hDlg,ID_WATERMARK_DELETE), fl);
       EnableWindow(GetDlgItem(hDlg,ID_WATERMARK_EDIT), fl);
    }
    EnableWindow(GetDlgItem(hDlg,ID_WATERMARK_FIRSTPAGEONLY), fl);
    EnableWindow(GetDlgItem(hDlg,ID_WATERMARK_BACKGROUND), fl);
    EnableWindow(GetDlgItem(hDlg,ID_WATERMARK_OUTLINE), fl);
}


/*****************************************************************************/
/*                 NewOrEditWMarkDlg                                           */
/* Purpose:                                                                  */
/*   Dialog Proceedure for Edit or New a Watermark called from WM Prop sheet */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE -- If procedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/
BOOL _loadds FAR PASCAL NewOrEditWMarkDlg(HWND hDlg, unsigned imsg, WORD wParam,
                                   LONG lParam)
{
    LPDRIVERINFO   lpDrvInfo;
    BOOL           result = TRUE ;
    HDC hDC;
    PAINTSTRUCT ps;
    int x, dx, neg;
    char buffer[64];// a temp str, used for a RGB string "255,255,255" and Caption
    BOOL success;
    int red, green, blue;
    CHOOSECOLOR cc;
    COLORREF aclrCust[16], clr;
    HINSTANCE hCommDlg = NULL;
    LPCHOOSECOLORFUN lpChooseColorFn =NULL;
    int i, val;
    LPEDITWM lpEditWM;
    LPPSEXTDEVMODE lpPSExtDevmode;
    WM wm;
    LPWM lpwm;
    char  s[16];    // used for Entry name only for Custom Color: "Color??"
    LPSTR lps;      // a pointer
    long  j;
    char    szCustomColorKey[256];  // watermark key path in registry
    HKEY    hKey;
    DWORD   typecode;

    /* Get saved lpEditWM back */
    if(lpEditWM=(LPEDITWM)GetWindowLong(hDlg,DWL_USER))
    {
        lpDrvInfo = lpEditWM->lpDrvInfo;
        lpPSExtDevmode = lpDrvInfo->lpDM;
    }
    switch (imsg)
    {
        case WM_INITDIALOG:
           lpEditWM=(LPEDITWM)lParam;
           SetWindowLong(hDlg,DWL_USER,(LPARAM)lpEditWM);
           lpDrvInfo=lpEditWM->lpDrvInfo;
           lpPSExtDevmode=lpDrvInfo->lpDM;
           // Init a global str:decimalSeparator
           GetDecimalSeparator(decimalSeparator, sizeof(decimalSeparator));

           BuildWaterMarkDlg(hDlg, lpDrvInfo);
           ShowWaterMarkInfo(hDlg, lpEditWM->dwWatermarkID);
           if (lpEditWM->IamEditing==0)
           {  // I am new
              LoadString(ghDriverMod, IDS_NEWWM_TITLE, buffer, sizeof(buffer));
              SetWindowText(hDlg, buffer);
           }
           InvalidatePreview(hDlg, ID_WATERMARK_PREVIEW, TRUE);
           break ;

        case WM_CONTEXTMENU:
           if (wParam != -1)
           {
               WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                       (DWORD)(LPDWORD)dwHelpMap);
           }
           break;

        case WM_HELP:
           if (((LPHELPINFO) lParam)->hItemHandle != -1)
           {
               WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                       HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
           }
           break;


        case WM_COMMAND:
           switch (wParam)
           {
           case IDOK:
              if (!CheckWatermarkValues(hDlg))
              {
                 SetWindowLong(hDlg,DWL_MSGRESULT,TRUE);
                 return TRUE;
              }
               // else save the changes:
              if (lpEditWM->IamEditing)   /* delete original watermark if editing */
              {
                  DeleteWatermark(lpEditWM->dwWatermarkID);
              }

              /* fill WM record from controls */
              lpwm=(LPWM)&wm;
              GetCurrentInfo(hDlg, lpwm);
              if(!lpEditWM->dwWatermarkID)
              {
                 lpwm->dwWatermarkID = GenerateWatermarkID();
              }
              else
              {
                 lpwm->dwWatermarkID = lpEditWM->dwWatermarkID;
              }

              if (lpwm->dwWatermarkID)    /* don't write blank records */
              {
                 WriteWatermark(lpwm);
              }

              if (lpDrvInfo != NULL)
              {
                 lpPSExtDevmode->dm.dwWatermarkID = lpwm->dwWatermarkID;
                 lpDrvInfo->wmChanged = TRUE;
              }

            // Fall through to CANCEL:

           case IDCANCEL:
              EndDialog(hDlg, wParam);
              WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
              break;

           case ID_WATERMARK_CHOOSECOLOR:
              lpwm = (LPWM)&wm;
              /* Set all structure fields to zero. and then initialize */
              memset(&cc, 0, sizeof(CHOOSECOLOR));
              cc.lStructSize = sizeof(CHOOSECOLOR);
              cc.hwndOwner = hDlg;
              // read Custom color back

             CompositeString(ghDriverMod, IDS_REGSTR_PATH_WATERMARK_CUSTOMCOLOR,
                  IDS_DRIVER_MANUFACTURER, 0,
                  szCustomColorKey, sizeof(szCustomColorKey));
              if(RegOpenKey(HKEY_LOCAL_MACHINE, szCustomColorKey, &hKey)
                                              == ERROR_SUCCESS)
              {
                 for (i = 0; i < 16; i++)
                 {
                    wsprintf(s, "Color%c\0", i+'A');
                    j = sizeof(buffer);
                    if(RegQueryValueEx(hKey, s, 0, &typecode, buffer, &j)
                         != ERROR_SUCCESS)
                    {
                       lstrcpy(buffer, "FFFFFF");
                       j = lstrlen(buffer);
                    }
                    buffer[j+1]=0;
                    UnQuoteWMText(buffer);
                    lps = buffer;    // borrow w's RGB to store the current value
                    lpwm->R   = (BYTE) GetIntFromStr(&lps);     /* read field r */
                    lpwm->G   = (BYTE) GetIntFromStr(&lps);     /* read field g */
                    lpwm->B   = (BYTE) GetIntFromStr(&lps);     /* read field b */
                    aclrCust[i] = RGB(lpwm->R,lpwm->G,lpwm->B);
                 }
                 RegCloseKey(hKey);
              }
              cc.lpCustColors = aclrCust;

              cc.Flags = CC_ENABLETEMPLATE | CC_FULLOPEN | CC_RGBINIT;
              cc.hInstance = ghDriverMod ;

              // substitute with our modified ChooseColor commdlg
              (LPCSTR)cc.lpTemplateName = "ModifiedChooseColor";

              red = GetDlgItemInt(hDlg, ID_WATERMARK_RED, (LPBOOL)&success, FALSE);
              green = GetDlgItemInt(hDlg, ID_WATERMARK_GREEN, (LPBOOL)&success, FALSE);
              blue = GetDlgItemInt(hDlg, ID_WATERMARK_BLUE,   (LPBOOL)&success, FALSE);

              cc.rgbResult = RGB(red, green, blue);
              /* Call the standard ChooseColor dialog */
              hCommDlg = LoadLibrary("COMMDLG.DLL");
              if ((UINT) hCommDlg > 32)
              {  /* Grab the proc if one exists */
                 lpChooseColorFn = (LPCHOOSECOLORFUN)GetProcAddress(hCommDlg, "ChooseColor");
              }
              if (lpChooseColorFn != NULL)
              { /* Execute the hook proc */
                 if ((*lpChooseColorFn)(&cc))
                 { // success, save the custome color and change the spinners

                  CompositeString(ghDriverMod, IDS_REGSTR_PATH_WATERMARK_CUSTOMCOLOR,
                     IDS_DRIVER_MANUFACTURER, 0,
                     szCustomColorKey, sizeof(szCustomColorKey));
                   if(RegCreateKey(HKEY_LOCAL_MACHINE, szCustomColorKey,
                         &hKey) == ERROR_SUCCESS)
                   {
                      for (i = 0; i < 16; i++)
                      {
                         wsprintf(s, "Color%c\0", i+'A');
                         clr = aclrCust[i] ;
                         wsprintf(buffer,"%d,%d,%d", (int)GetRValue(clr),
                                   (int)GetGValue(clr), (int)GetBValue(clr));
                         RegSetValueEx(hKey, s, 0, REG_SZ, (LPBYTE)buffer, lstrlen(buffer));
                      }
                      RegCloseKey(hKey);
                   }
                   clr = cc.rgbResult;
                   red = (int)GetRValue(cc.rgbResult);
                   wsprintf(buffer,"%d", red);
                   SendDlgItemMessage(hDlg,ID_WATERMARK_RED,
                    WM_SETTEXT, 0, (long)(LPSTR)buffer);
                   green = (int)GetGValue(cc.rgbResult);
                   wsprintf(buffer,"%d", green);
                   SendDlgItemMessage(hDlg,ID_WATERMARK_GREEN,
                        WM_SETTEXT, 0, (long)(LPSTR)buffer);
                   blue = (int)GetBValue(cc.rgbResult);
                   wsprintf(buffer,"%d", blue);
                   SendDlgItemMessage(hDlg,ID_WATERMARK_BLUE,
                        WM_SETTEXT, 0, (long)(LPSTR)buffer);
                 }
              }
              if ((UINT) hCommDlg > 32)
              {
                 FreeLibrary(hCommDlg);
              }
              InvalidatePreview(hDlg, ID_WATERMARK_PREVIEW, TRUE);
              break;


        case ID_WATERMARK_XPOS:
        case ID_WATERMARK_YPOS:
            // Make the systemn remember the changes in XPOS and YPOS so spinner knows the change
            UpdatePosControls(hDlg);
            // Fall though ...
        case ID_WATERMARK_TEXT:
        case ID_WATERMARK_SIZE:
        case ID_WATERMARK_RED:
        case ID_WATERMARK_GREEN:
        case ID_WATERMARK_BLUE:
        case ID_WATERMARK_ANGLE:

           if (HIWORD(lParam) != EN_CHANGE)
               return result;

           if(wParam == ID_WATERMARK_ANGLE)
             {
             x = GetDlgItemInt(hDlg, ID_WATERMARK_ANGLE, (LPBOOL)&success, TRUE);
               SendDlgItemMessage(hDlg, ID_WATERMARK_ANGLE_TRACKBAR,
                       TBM_SETPOS, TRUE, (long) (x - MINANG));
             }
           InvalidatePreview(hDlg, ID_WATERMARK_PREVIEW, TRUE);
           break;

        case ID_WATERMARK_FONT:
        case ID_WATERMARK_STYLE:
           if (HIWORD(lParam) != CBN_SELCHANGE)
               return result;

           InvalidatePreview(hDlg, ID_WATERMARK_PREVIEW, TRUE);
           break;

        case ID_WATERMARK_AUTOCENTER:
            if (HIWORD(lParam) != BN_CLICKED)
               return result;
            makefixed(buffer, 0, 2);
            SetDlgItemText(hDlg,ID_WATERMARK_XPOS, (LPSTR)buffer);
            SetDlgItemText(hDlg,ID_WATERMARK_YPOS, (LPSTR)buffer);
           /* Fall through to next case */
        case ID_WATERMARK_RELCENTER:
            if (HIWORD(lParam) != BN_CLICKED)
               return result;
            UpdatePosControls(hDlg);
           InvalidatePreview(hDlg, ID_WATERMARK_PREVIEW, TRUE);
            break;


#ifndef USE_WHATSTHIS_HELP
        case ID_HELP:
            WinHelp(hDlg, szHelpFile, HELP_CONTEXT,
                    IDH_PSCRIPT_CREATE_WATERMARK);
            break;
#endif
        default:
            result = FALSE ;
            break ;
        } /* switch(wParam) */
        break ;

        case WM_VSCROLL:
           {
          WORD wID;

          switch (wID = GetDlgCtrlID(HIWORD(lParam)))
            {
            case ID_WATERMARK_XPOSSPN:
            case ID_WATERMARK_YPOSSPN:
             neg = 0;
             FixedMulDivInt(LOWORD(lParam), 1, 100, 2, &x, &dx);
             if (dx < 0)
              {
               neg = 1;
               dx = -dx;
              }
             if (x < 0)
              {
               neg = 1;
               x = -x;
              }
             wsprintf(buffer, "%s%d%s%02.2d", (neg ? "-":""),
                 x,decimalSeparator,dx);
             SetDlgItemText(hDlg, wID - ID_WATERMARK_XPOSSPN + ID_WATERMARK_XPOS, (LPSTR)buffer);
             // Make the system remember the new values
             UpdatePosControls(hDlg);
             InvalidatePreview(hDlg, ID_WATERMARK_PREVIEW, TRUE);
             break;

           case ID_WATERMARK_ANGLESPN:
              wsprintf(buffer,"%d",x = (int)LOWORD(lParam));
              SetDlgItemText(hDlg,ID_WATERMARK_ANGLE,(LPSTR)buffer);
              SendDlgItemMessage(hDlg, ID_WATERMARK_ANGLE_TRACKBAR,
                    TBM_SETPOS, TRUE,
                    (long) (x - MINANG));
              // WM_Text will triger re-paint.
              break;
             }

          }  // end V_SCROLL
          break;

        case WM_HSCROLL:
          if (GetDlgCtrlID(HIWORD(lParam))==ID_WATERMARK_ANGLE_TRACKBAR)
            {
            int val_saved;
            GetDlgItemText(hDlg, ID_WATERMARK_ANGLE, (LPSTR) buffer,5);
            val = atoi(buffer);
            val_saved=val;
            switch(wParam)
            {
             case TB_BOTTOM:
                  val = 90;
                  break;
             case TB_TOP:
                  val = -90;
               break;
             case TB_LINEDOWN:
               val += 1;
             if (val > MAXANG)  val = MAXANG;
             break;

           case TB_PAGEDOWN:
               val += TB_TIC_FREQ;
              if (val > MAXANG) val = MAXANG;
               break;
           case TB_LINEUP:
              val -= 1;
               if (val < MINANG) val = MINANG;
               break;
           case TB_PAGEUP:
              val -= TB_TIC_FREQ;
             if (val < MINANG) val = MINANG;
               break;
           case TB_THUMBPOSITION:
           case TB_THUMBTRACK:
               val = LOWORD(lParam)+MINANG;
             break;
           default:
               break;
         }
         SendDlgItemMessage(hDlg, ID_WATERMARK_ANGLE_TRACKBAR,
                    TBM_SETPOS, TRUE,  (long) (val - MINANG));
          wsprintf(buffer, "%d", val);
          // Add this check to prevent needless repainting -- flickerings, fix bug 249. 5-24-95
          // This will triger re-paint.
          if (val!=val_saved)
             SetDlgItemText(hDlg, ID_WATERMARK_ANGLE, (LPSTR) buffer);
          }
          break;

    case WM_PAINT:
        lpwm=(LPWM)&wm;
        GetCurrentInfo(hDlg, lpwm);
        hDC = BeginPaint(hDlg, &ps);
        DisplayWaterMark(hDlg, hDC, &ps, lpwm, ID_WATERMARK_PREVIEW);
        EndPaint(hDlg, &ps);
        break;

    default:
       lpDrvInfo = NULL;
        result = FALSE ;
        break ;
      } /* switch(imsg) */

    return result ;
}


int FAR PASCAL InvalidatePreview(HWND hDlg, WORD idcDisplay, BOOL eraseBk)
{
RECT rectp;
   GetWindowRect( GetDlgItem(hDlg, idcDisplay), (LPRECT)&rectp);
   InflateRect(&rectp, -1, -1); // don't re-draw the border.
   MapWindowPoints(NULL, hDlg, (POINT FAR*)&rectp, 2);
   InvalidateRect(hDlg, &rectp, eraseBk);
//   UpdateWindow(hDlg);
   return 1;
}


static void ShowWaterMarkList(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
LPPDEVICE lppd = &(lpDrvInfo->pDev);
char  qwmname[MAXWMNAME*2+2];  // quoted name as shown in INI file.
long  index = -1;
LPPSEXTDEVMODE lpPSExtDevmode;
char  szWatermarkKey[256];  // watermark key path in registry
char  noneName[MAXWMNAME];
WM    wm;
long  i, j, nItem;
DWORD dwWatermarkID;
HKEY  hKey = NULL;

    lpPSExtDevmode = lpDrvInfo->lpDM;
    SendDlgItemMessage(hDlg, ID_WATERMARK_LIST, LB_RESETCONTENT,0,0L);

    LoadString(ghDriverMod, IDS_WM_NONE, (LPSTR)noneName, sizeof(noneName));
    CompositeString(ghDriverMod, IDS_REGSTR_PATH_WATERMARK,
                  IDS_DRIVER_MANUFACTURER, 0,
                  szWatermarkKey, sizeof(szWatermarkKey));
    qwmname[0]='\0';

    if (RegOpenKey(HKEY_LOCAL_MACHINE, szWatermarkKey, &hKey) != ERROR_SUCCESS)
    {
        //
        // the watermark key does not exist -> this must be a new installation
        // create a few default watermarks as Adobe does in the installer
        //
        if (RegCreateKey(HKEY_LOCAL_MACHINE, szWatermarkKey, &hKey)
                           == ERROR_SUCCESS)
        {
            char *pszWmValues[] = {
                "0,0,255,0,0,1,0,0,450,700,0,24,Helvetica,CONFIDENTIAL",
                "0,0,0,0,255,1,0,0,450,700,0,24,Helvetica,COPY",
                "0,0,0,255,0,1,0,0,450,700,0,24,Helvetica,DRAFT",
                NULL
            };
            char szValueName[10];
            int i;

            for (i=0; pszWmValues[i] != NULL; i++)
            {
                wsprintf(szValueName, "%u", i+1);
                RegSetValueEx(hKey, szValueName, NULL, REG_SZ, pszWmValues[i], lstrlen(pszWmValues[i])+1);
            }
        }
    }

    if (hKey != NULL)
    {
       DWORD typecode;
       DWORD cb;

       cb = sizeof(qwmname);

       for(i=0, j=-1; RegEnumValue(hKey, i, qwmname, &cb, 0, &typecode, 0, 0)==ERROR_SUCCESS;
           i++)
       {
           // add the watermark text and dwWatermarkID associates with the text
           dwWatermarkID = atol(qwmname);
           ReadWatermark(dwWatermarkID, &wm);

           j = SendDlgItemMessage(hDlg,ID_WATERMARK_LIST,LB_ADDSTRING, 0,
                              (long)(LPSTR)wm.text);
           SendDlgItemMessage(hDlg,ID_WATERMARK_LIST,LB_SETITEMDATA, (WPARAM)j,
                                               (LPARAM)((DWORD)dwWatermarkID));
           cb = sizeof(qwmname);
       }
       RegCloseKey(hKey);
    }

    // find out which watermark is currently selected
    nItem = SendDlgItemMessage(hDlg, ID_WATERMARK_LIST, LB_GETCOUNT, 0, 0);
    for(i=0; i<nItem; i++)
    {
       dwWatermarkID = (DWORD)SendDlgItemMessage(hDlg, ID_WATERMARK_LIST,
                              LB_GETITEMDATA, (WPARAM)i, 0L);
       if(lpPSExtDevmode->dm.dwWatermarkID == dwWatermarkID)
       {
          // find the current selected to hilite
          index = i;
          break;
       }
    }

    if (index == LB_ERR)
    {
       index=0;
    }
    else
    {
       index++;  // We will add [None] next. Must be done after this point to allow [None] in WM list
    }

    // Insert the special entry as first one = 0th, use insert.. 3-9-95, PPeng .
    SendDlgItemMessage(hDlg,ID_WATERMARK_LIST,LB_INSERTSTRING, 0, (long)(LPSTR)noneName);

    if (index==0 && lpPSExtDevmode->dm.dwWatermarkID)
    {
       // Old Watermark is not available any more, default to [none]:
       lpPSExtDevmode->dm.dwWatermarkID = 0;
       lpDrvInfo->wmChanged = TRUE;
    }
    SendDlgItemMessage(hDlg, ID_WATERMARK_LIST, LB_SETCURSEL, (WPARAM)index, 0L);

    /* First Page Only ? */
    SendDlgItemMessage(hDlg, ID_WATERMARK_FIRSTPAGEONLY, BM_SETCHECK,
            lpPSExtDevmode->dm.WMFirstPageOnly, 0L);
    /* Foreground ? */
    SendDlgItemMessage(hDlg, ID_WATERMARK_BACKGROUND, BM_SETCHECK,
            1 - lpPSExtDevmode->dm.WMForeGround, 0L);
    /* Outline ? */
    SendDlgItemMessage(hDlg, ID_WATERMARK_OUTLINE,    BM_SETCHECK,
            lpPSExtDevmode->dm.WMOutline, 0L);

}

// This function sets the proper range and fill in Font/Style list boxes.
static void
BuildWaterMarkDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
LPPDEVICE lppd = &(lpDrvInfo->pDev);
int i;
struct {
    char str[STYLE_LEN];
    int weight;
    int italic;
}StdStyles[4] = {{"R",400,0},  // Regular
          {"B",700,0},      // Bold
          {"I",400,1},      // Italic
          {"BI",700,1}};    // BoldItalic.
// Style names will be loaded from resource. Localizable. 3-9-95, PPeng

    LoadString(ghDriverMod, IDS_FONT_REGULAR, (LPSTR)StdStyles[PS_REGULAR].str, STYLE_LEN);
    LoadString(ghDriverMod, IDS_FONT_BOLD, (LPSTR)StdStyles[PS_BOLD].str, STYLE_LEN);
    LoadString(ghDriverMod, IDS_FONT_ITALIC, (LPSTR)StdStyles[PS_ITALIC].str, STYLE_LEN);
    LoadString(ghDriverMod, IDS_FONT_BOLDITALIC, (LPSTR)StdStyles[PS_BOLDITALIC].str, STYLE_LEN);

    /* Populate the font and style combo boxes */
    for(i = 0; i<sizeof(StdStyles)/sizeof(StdStyles[0]); i++)
       SendDlgItemMessage(hDlg, ID_WATERMARK_STYLE, CB_ADDSTRING, 0,
                (long)(LPSTR)StdStyles[i].str);

    /* Only allow host fonts and soft fonts. No printer fonts */
    EnumWMFonts(lppd, hDlg);

    // Set the limit for these controls
    SendDlgItemMessage(hDlg, ID_WATERMARK_TEXT,EM_LIMITTEXT,MAXTEXTLEN,0L);
    SendDlgItemMessage(hDlg, ID_WATERMARK_SIZESPN,UDM_SETRANGE,NULL,
                MAKELPARAM(MAXWMSIZE, MINWMSIZE));
    SendDlgItemMessage(hDlg, ID_WATERMARK_SIZE, EM_LIMITTEXT, 3, 0) ;

    SendDlgItemMessage(hDlg, ID_WATERMARK_REDSPN,UDM_SETRANGE,NULL,
                MAKELPARAM(255, 0));
    SendDlgItemMessage(hDlg, ID_WATERMARK_RED, EM_LIMITTEXT, 3, 0) ;
    SendDlgItemMessage(hDlg, ID_WATERMARK_GREENSPN,UDM_SETRANGE,NULL,
                MAKELPARAM(255, 0));
    SendDlgItemMessage(hDlg, ID_WATERMARK_GREEN, EM_LIMITTEXT, 3, 0) ;
    SendDlgItemMessage(hDlg, ID_WATERMARK_BLUESPN,UDM_SETRANGE,NULL,
                MAKELPARAM(255, 0));
    SendDlgItemMessage(hDlg, ID_WATERMARK_BLUE, EM_LIMITTEXT, 3, 0) ;

    // Bug fix for 143208, 143209, 143210, 143211. Moved from in 4.1CJK
    SendDlgItemMessage(hDlg, ID_WATERMARK_XPOSSPN,UDM_SETRANGE,NULL,
                MAKELPARAM(ConvertToUserUnit(MAXXPOS), ConvertToUserUnit(MINXPOS)));
    SendDlgItemMessage(hDlg, ID_WATERMARK_XPOS, EM_LIMITTEXT, 11, 0) ; //-123.45
    SendDlgItemMessage(hDlg, ID_WATERMARK_YPOSSPN,UDM_SETRANGE,NULL,
                MAKELPARAM(ConvertToUserUnit(MAXXPOS), ConvertToUserUnit(MINXPOS)));
    SendDlgItemMessage(hDlg, ID_WATERMARK_YPOS, EM_LIMITTEXT, 11, 0) ;
    // Set the Unit - (in) or (cm) for xy position:
    {
     char str[32];
    if (GetMeasure()== ID_CP_INCHES)
       LoadString(ghDriverMod, IDS_UNIT_INCH, (LPSTR)str, sizeof(str)-1);
    else
       LoadString(ghDriverMod, IDS_UNIT_CM, (LPSTR)str, sizeof(str)-1);
    SendDlgItemMessage(hDlg,IDC_WM_UNIT,WM_SETTEXT, 0, (long)(LPSTR)str);
    }

    SendDlgItemMessage(hDlg, ID_WATERMARK_ANGLESPN,UDM_SETRANGE,NULL,
                MAKELPARAM(90, -90));
    SendDlgItemMessage(hDlg, ID_WATERMARK_ANGLE, EM_LIMITTEXT, 3, 0) ;

    SendDlgItemMessage(hDlg, ID_WATERMARK_ANGLE_TRACKBAR,TBM_SETRANGE,TRUE,
                MAKELPARAM(0,(MAXANG - MINANG)));
    SendDlgItemMessage(hDlg, ID_WATERMARK_ANGLE_TRACKBAR,TBM_SETTICFREQ,
               TB_TIC_FREQ, 0L);
}

static void ShowWaterMarkInfo(HWND hDlg, DWORD dwWatermarkID)
{
BOOL center;
char str[60];
int strind, iangle;
WM   wMark;

    ReadWatermark(dwWatermarkID, (LPWM)&wMark);

    /* Initialize the various fields of the dialog.*/
    /* First X,Y.... */

    if (wMark.xpos || wMark.ypos) center=FALSE;
    else  center = TRUE;

    makefixed(str, (int)wMark.xpos, 2);
    SendDlgItemMessage(hDlg,ID_WATERMARK_XPOS,WM_SETTEXT, 0, (long)(LPSTR)str);

    makefixed(str, (int)wMark.ypos, 2);
    SendDlgItemMessage(hDlg,ID_WATERMARK_YPOS,WM_SETTEXT, 0, (long)(LPSTR)str);

    SendDlgItemMessage(hDlg,ID_WATERMARK_AUTOCENTER, BM_SETCHECK,
                       center ? 1:0, 0L);
    SendDlgItemMessage(hDlg,ID_WATERMARK_RELCENTER,  BM_SETCHECK,
                       center ? 0:1, 0L);
    UpdatePosControls(hDlg);
    /* Next R, G, B.... */

    wsprintf(str,  "%d", (int)wMark.R);
    SendDlgItemMessage(hDlg,ID_WATERMARK_RED,WM_SETTEXT, 0, (long)(LPSTR)str);

    wsprintf(str,  "%d", (int)wMark.G);
    SendDlgItemMessage(hDlg,ID_WATERMARK_GREEN,WM_SETTEXT, 0, (long)(LPSTR)str);

    wsprintf(str,  "%d", (int)wMark.B);
    SendDlgItemMessage(hDlg,ID_WATERMARK_BLUE,WM_SETTEXT, 0, (long)(LPSTR)str);

    /* Angle */
    /* In 3.0 driver, LOGFONT's reason. Pos Angles (0 to 90) are from 0 to 900
     * and Neg angles (-90 to 0) are from  2700 to 3600. */
    iangle= SliderAngle(wMark.lf.lfEscapement);
    wsprintf(str,"%d", iangle);
    SendDlgItemMessage(hDlg,ID_WATERMARK_ANGLE,WM_SETTEXT, 0, (long)(LPSTR)str);
    SendDlgItemMessage(hDlg,ID_WATERMARK_ANGLE_TRACKBAR, TBM_SETPOS,TRUE,
                       (long)(iangle - MINANG));

    /* Style is combination of weight and italicity - handled in SetStyle()*/
    SetStyle(hDlg, &(wMark.lf), ID_WATERMARK_STYLE);

    /* Size. (Does it matter ?) */
    wsprintf(str,  "%d", (int)wMark.lf.lfHeight);
    SendDlgItemMessage(hDlg,ID_WATERMARK_SIZE,WM_SETTEXT, 0, (long)(LPSTR)str);

    /* Font */
    if ((strind=(int)SendDlgItemMessage(hDlg,ID_WATERMARK_FONT, CB_FINDSTRINGEXACT,(WORD)-1,
               (long)(LPSTR)wMark.lf.lfFaceName)) == CB_ERR)
       strind = 0;
    // Courier is handled in DisplayWatermark() is ATM is off
    SendDlgItemMessage(hDlg, ID_WATERMARK_FONT, CB_SETCURSEL, strind, 0L);

    /* Text */
    SendDlgItemMessage(hDlg,ID_WATERMARK_TEXT,WM_SETTEXT,
                       0, (long)(LPSTR)wMark.text);

}

static void makefixed(LPSTR dest, int org, int precision)
{
int n, i;
char temp[10], src[20];
   // Bug fix for 143208, 143209, 143210, 143211. Moved from in 4.1CJK
   // convert from 1/100 inch to user/100 units (in Inch or cm)
   org = (int) ConvertToUserUnit(org);  // to display in User Units

    if (org<0){
        // get the sign right first
        dest[0]='-'; dest++;
        org = -org; // we don't need the sign again
    }
    wsprintf(src, "%d", org);
    GetDecimalSeparator(decimalSeparator, sizeof(decimalSeparator));
    if ((n = lstrlen(src)) <= precision)
    {
        for(i = n; i <= precision;i++)
           dest[i-n] = '0';
        lstrcpy(dest + precision+1 -n, src);
    }
    else
        lstrcpy(dest, src);
    lstrcpy(temp,dest + lstrlen(dest) - precision);
    wsprintf(dest+lstrlen(dest)-precision,"%s%s",decimalSeparator,temp);
}


static void DisplayWaterMark(HWND hDlg, HDC hDC, LPPAINTSTRUCT ps, LPWM lpwm, WORD idcDisplay)
{
RECT  dsprect;
SIZE  sPhysPage;  /* size of Physical page we're representing */
HRGN  hrPage;
int   i, dispRep=0;
char  realName[50];

    // Erase old watermark first:
    DisplayBlankWaterMark(hDlg, hDC, ps, idcDisplay);

    GetWaterMarkDisplayArea(hDlg, (LPRECT)&dsprect, idcDisplay);

   /* set clipping region to page boundaries */
   hrPage = CreateRectRgnIndirect(&dsprect);
   SelectClipRgn(ps->hdc,hrPage);
   DeleteObject(hrPage);

    SetMapMode(hDC, MM_TWIPS);
    DPtoLP(hDC, (LPPOINT)&dsprect, 2);

    // use fixed size page (11x8.5):
    sPhysPage.cx=MulDiv(612, 300, 72);  // from points to 300 DPI
    sPhysPage.cy=MulDiv(792, 300, 72);
    // Convert to twips unit used in ShowWaterMark()
    sPhysPage.cx = MulDiv(sPhysPage.cx, 1200, 300);  // from dpi to twips
    sPhysPage.cy = MulDiv(sPhysPage.cy, 1200, 300);

    // Check for the cases when a Font is not rotatable, e.g. Courier is added by
    // basic 13 then it may not be rotatable - if ATM is not on.
    // this substitution only applies for ShowWatermark().
    for (i=0; i<sizeof(StdFonts)/sizeof(StdFonts[0]); i++){
      if (StdFonts[i].UseDisp &&
              lstrcmpi((LPSTR)lpwm->lf.lfFaceName, (LPSTR)StdFonts[i].FontName)==0){
         lstrcpy((LPSTR)realName, (LPSTR)lpwm->lf.lfFaceName);
         lstrcpy((LPSTR)lpwm->lf.lfFaceName, (LPSTR)StdFonts[i].DispName);
        dispRep = 1;
        break;
         }
      }

   // ATM has a bug with TextOut() when the angle is not 0. Use the method used in 3.0 driver:
    ShowWatermark(ps->hdc, lpwm, (LPRECT)&dsprect, sPhysPage,TRUE);

    if (dispRep==1) lstrcpy((LPSTR)lpwm->lf.lfFaceName, (LPSTR)realName);  // copy back the real name

}


static void DisplayBlankWaterMark(HWND hDlg, HDC hDC, LPPAINTSTRUCT ps, WORD idcDisplay)
{
HPEN hPen, oldPen;
HBRUSH hBr, oldBr;
RECT prect;
HBRUSH  br;
RECT prvw;

    GetWindowRect(GetDlgItem(hDlg, idcDisplay), (LPRECT)&prvw);
    InflateRect(&prvw, -1, -1); // don't re-draw the border.
    MapWindowPoints(NULL, hDlg, (POINT FAR*)&prvw, 2);
   br = CreateSolidBrush(RGB(128,128,128));
   FillRect(ps->hdc, &prvw, br);
   DeleteObject(br);

    GetWaterMarkDisplayArea(hDlg, (LPRECT)&prect, idcDisplay);
    hPen = GetStockObject(BLACK_PEN);
    oldPen = SelectObject(hDC, hPen);
    hBr = GetStockObject(WHITE_BRUSH);
    oldBr = SelectObject(hDC, hBr);
    Rectangle(hDC, prect.left, prect.top, prect.right, prect.bottom);
    SelectObject(hDC, oldPen);
    SelectObject(hDC, oldBr);
}

static void GetWaterMarkDisplayArea(HWND hDlg, LPRECT pRect, WORD idcDisplay)
{
HWND childwnd;
HDC hDC;
RECT childrect, orig;
int width, height, pwidth, pheight;

    childwnd = GetDlgItem(hDlg, idcDisplay);
    hDC = GetDC(childwnd);
    SetMapMode(hDC, MM_LOENGLISH);
    GetClientRect(childwnd, (LPRECT)&childrect);
    DPtoLP(hDC, (LPPOINT)&childrect, 2);
    width = childrect.right - childrect.left;
    height = childrect.top - childrect.bottom;
    if (22*width <= 17*height)
    {
        pwidth = width-2;
        pheight = (22*pwidth)/17;
    }
    else
    {
        pheight = height-2;
        pwidth = (17*pheight)/22;
    }
    childrect.left += (width-pwidth)/2;
    childrect.right = childrect.left + pwidth;
    childrect.bottom += (height-pheight)/2;
    childrect.top = childrect.bottom + pheight;
    LPtoDP(hDC, (LPPOINT)&childrect, 2);
    ReleaseDC(childwnd,hDC);
    GetWindowRect(childwnd, (LPRECT)&orig);
    ScreenToClient(hDlg,(POINT FAR *)&orig);
    pRect->left = orig.left + childrect.left;
    pRect->right = orig.left + childrect.right;
    pRect->top = orig.top + childrect.top;
    pRect->bottom = orig.top + childrect.bottom;

}



static void UpdatePosControls(HWND hDlg)
{
BOOL buttonstate;
    // Fix bug 143209 - singed values for XY-Position
    SignedSetCurrentSpinPos(hDlg, ID_WATERMARK_XPOSSPN, ID_WATERMARK_XPOS, 1, 2);
    SignedSetCurrentSpinPos(hDlg, ID_WATERMARK_YPOSSPN, ID_WATERMARK_YPOS, 1, 2);

    buttonstate = (IsDlgButtonChecked(hDlg, ID_WATERMARK_RELCENTER)!=0);
    EnableWindow(GetDlgItem(hDlg,ID_WATERMARK_XPOS), buttonstate);
    EnableWindow(GetDlgItem(hDlg,ID_WATERMARK_YPOS), buttonstate);
    EnableWindow(GetDlgItem(hDlg,ID_WATERMARK_XPOSSPN), buttonstate);
    EnableWindow(GetDlgItem(hDlg,ID_WATERMARK_YPOSSPN), buttonstate);

}

static int GetCurrentInfo(HWND hDlg, LPWM lpwm)
{
int index;
BOOL success;
char buf[32];

#define GET_REAL_OR_ERROR(val, ctlid, numdecimals)    \
        val = GetDlgItemRealSigned(hDlg, ctlid, numdecimals, \
            decimalSeparator,(LPBOOL)&success, FALSE); \
        if (!success) return 0;
#define GET_INT_OR_ERROR(val, ctlid)    \
        val = (int)GetDlgItemInt(hDlg, ctlid, (LPBOOL)&success, TRUE); \
        if (!success) return 0;

    DefaultWm(lpwm);      /* init to defaults first */

    GetDecimalSeparator(decimalSeparator, sizeof(decimalSeparator));

    GetDlgItemText(hDlg, ID_WATERMARK_ANGLE, buf, sizeof(buf));
    lpwm->lf.lfEscapement = AngleSlider(atoi(buf));

    GetStyle(hDlg, (LPLOGFONT)&(lpwm->lf), ID_WATERMARK_STYLE);

    GET_INT_OR_ERROR(lpwm->lf.lfHeight, ID_WATERMARK_SIZE);

    index = (int)SendDlgItemMessage(hDlg,ID_WATERMARK_FONT, CB_GETCURSEL, 0, 0L);
    SendDlgItemMessage(hDlg,ID_WATERMARK_FONT, CB_GETLBTEXT,index,
                  (long)(LPSTR)lpwm->lf.lfFaceName);

    SendDlgItemMessage(hDlg,ID_WATERMARK_TEXT,WM_GETTEXT,
               MAXTEXTLEN, (long)(LPSTR)lpwm->text);

    GET_REAL_OR_ERROR(lpwm->xpos, ID_WATERMARK_XPOS, 2);
    GET_REAL_OR_ERROR(lpwm->ypos, ID_WATERMARK_YPOS, 2);

    // Bug fix for 143208, 143209, 143210, 143211. Moved from in 4.1CJK
    lpwm->xpos = ConvertTo100thInch(lpwm->xpos);  // save in 1/100 inch
    lpwm->ypos = ConvertTo100thInch(lpwm->ypos);

    GET_INT_OR_ERROR(lpwm->R, ID_WATERMARK_RED);
    GET_INT_OR_ERROR(lpwm->G, ID_WATERMARK_GREEN);
    GET_INT_OR_ERROR(lpwm->B, ID_WATERMARK_BLUE);

    return 1;
}



/*  'delete watermark' confirmation dialog function
 */
BOOL  FAR PASCAL WMarkDelFn(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam) {
   switch (msg) {

   case WM_INITDIALOG:
      SetDlgItemText(hDlg,IDC_WMDNAME,(LPSTR)lParam);
      return TRUE;

   case WM_COMMAND:
      switch(wParam) {
      case IDOK:
      case IDCANCEL:
         EndDialog(hDlg,wParam);
         return TRUE;
      }
      break;
   }
   return FALSE;
}


// Copied from dlgutils.c. This one works form INT. 3-10-95, PPeng
void FAR PASCAL FixedMulDivInt(int number, int mult, int div, int nDecimals,
                             LPINT quotient, LPINT remainder)
{
    long temp, factor = 10L;
    int  i;

    for (i=0; i<nDecimals; i++)
    {
        factor *= 10L;
    }

    temp = ((long)number * (long)mult * factor) / (long)div;
    if (temp>0) temp += 5L;                 /* Add 5 to round off to nearest digit */
    if (temp<0) temp -= 5L;  // trick!!!! Otherwise -0.01 will stay as -0.01 forever!!

    *quotient = (int)(temp/factor);
    temp = temp - ((long)(*quotient) * factor);

    *remainder = (int)(temp / 10);
}

/* GetDlgItemReal(), copied from dlgsutil.c. Able to handle signed number */
long FAR PASCAL GetDlgItemRealSigned(HWND hDlg, int ictrl, int nDecimals,
                                LPSTR decimalSeparator, LPBOOL lpbSuccess,
                                BOOL bBeep)
{
    LPSTR ptr;
    long  num = 1;
    int   imult = 1;
    int   i, neg=0;
    char  buf[32], ch;

    *lpbSuccess = FALSE;

    for (i=0; i<nDecimals; i++)
    {
        imult *= 10;
    }

    if (!GetDlgItemText(hDlg, ictrl, ptr=buf, sizeof(buf)))
        goto EndGetDlgItemReal;

    // Skip signs (- or +)
    ch = *ptr;
    if (ch=='+') ptr++;
    if (ch=='-') { ptr++; neg=1;}

    for (num=0; ch=*ptr; ptr++)
    {
        if (ch >= '0' && ch <= '9')
        {
            num = (num * 10) + (WORD)(ch - '0');
        }
        else
            break;
    }

    num *= imult;

    if (ch == *decimalSeparator)
    {
        while ((imult = imult / 10) && (ch = *++ptr))
        {
            if (ch >= '0' && ch <= '9')
                num += (imult * (WORD)(ch - '0'));
            else
                break;
        }
    }

    while (ch >= '0' && ch <= '9')
        ch = *++ptr;

    if (!ch)
        *lpbSuccess=TRUE;

EndGetDlgItemReal:
    if (!*lpbSuccess && bBeep)
    {
        SetFocus(GetDlgItem(hDlg, ictrl));
        SendDlgItemMessage(hDlg, ictrl, EM_SETSEL,0,MAKELPARAM(0,-1));
        MessageBeep(0);
    }

    if (neg) return (-num);
    else return (num);
}


// Watermark display. get around ATm problem
BOOL WINAPI ShowWatermark(HDC hdc,LPWM pwm, LPRECT lpr, SIZE sLogPage,BOOL FastMode) {

    int         OrgPts;
    COLORREF    oldTextColor,oldBKColor, disp_color;
    BYTE        disp_R, disp_G, disp_B;
    DWORD       vpx,wnx;
    SIZE        sLogRect;
    RECT        physRect;               /* physical version of lpr */
    SIZE        sPhysRect;              /* size of " */
    int         ptsTwv;                 /* pointsize in 1200ths */
    HDC         hsDC,hMemDC;
    HFONT       hOldf;
    HBRUSH      hOldbr;
    int         sl;
    DWORD       txx;
    POINT       pLogOrg;
    POINT       pText;
    POINT       pCurrent;
    int         l;
    LPSTR       p;
    RECT        rChar;
    TEXTMETRIC  tm;
    POINT       pChar;
    SIZE        sPhysbm;
    HBITMAP     hOldbm;
    POINT       pCharVect;
    SIZE        sLogbm;
    POINT       pLogbm;
    LOGFONT     lfUnRot;
    HFONT       hRotf,hUnRotf;

    OrgPts       = pwm->lf.lfHeight;
    oldTextColor = SetTextColor(hdc,RGB(0,0,0));
    oldBKColor   = SetBkColor(hdc,RGB(255,255,255));

    vpx = GetViewportExt(hdc);          /* get mapping ratio */
    wnx = GetWindowExt(hdc);

    sLogRect.cx = lpr->right-lpr->left; /* size in dest DC's logical units */
    sLogRect.cy = lpr->bottom-lpr->top;
                                        /* compute physical version of lpr */
    physRect.left   = MulDiv(lpr->left,  LOWORD(vpx),LOWORD(wnx));
    physRect.right  = MulDiv(lpr->right, LOWORD(vpx),LOWORD(wnx));
    physRect.top    = MulDiv(lpr->top,   HIWORD(vpx),HIWORD(wnx));
    physRect.bottom = MulDiv(lpr->bottom,HIWORD(vpx),HIWORD(wnx));
    sPhysRect.cx = physRect.right  - physRect.left;
    sPhysRect.cy = physRect.bottom - physRect.top;

                                        /* compute pointsize in 1200ths */
    ptsTwv = MulDiv(pwm->lf.lfHeight,50,3);
                                        /* compute lfHeight in physical dots */
    pwm->lf.lfHeight = -MulDiv(ptsTwv,sPhysRect.cy,sLogPage.cy);
    //If the lfHeight is 0, the GDI will realize it using default height.
    // This causes bug 469. Fix is to check 0 here: 2-20-1995
    if (pwm->lf.lfHeight==0) pwm->lf.lfHeight=-1;

    hsDC = GetDC(NULL);                 /* create a memory DC */
    hMemDC = CreateCompatibleDC(hsDC);
    ReleaseDC(NULL,hsDC);

    // First call display.drv to convert the current color to
    // a display-able color.
    disp_color=NearestPhysicalColor(hMemDC,(BYTE)pwm->R,(BYTE)pwm->G,(BYTE)pwm->B);
    disp_R = (BYTE) GetRValue(disp_color);
    disp_G = (BYTE) GetGValue(disp_color);
    disp_B = (BYTE) GetBValue(disp_color);

   /* & select our font & brush. */
   lfUnRot = pwm->lf;
   lfUnRot.lfEscapement = 0;
   hUnRotf = CreateFontIndirect(&lfUnRot);
   hRotf = CreateFontIndirect(&pwm->lf);
    hOldf = SelectObject(hMemDC,hUnRotf);

// use color brush, PPeng
        hOldbr = SelectObject(hMemDC,CreateSolidBrush(RGB(pwm->R,pwm->G,pwm->B)));

    /*---------- Metrics calculations -----------*/

    sl = lstrlen(pwm->text);
    txx = GetTextExtent(hMemDC,pwm->text,sl);
    GetTextMetrics(hMemDC,&tm);

    /* compute the watermark origin in 1200ths
       & then convert to dest DC's logical units
     */

    // fixed bug 179894 -- watermark offsets cause watermark to re-appear.
    // Caused by "int" value overflow. So instead of multiplying 12 first, we
    // now do it later after we do the MulDiv().
    pLogOrg.x = (int)pwm->xpos;
    pLogOrg.y = (int)pwm->ypos;
    pLogOrg.x = MulDiv(pLogOrg.x,sLogRect.cx,sLogPage.cx);
    pLogOrg.y = MulDiv(pLogOrg.y,sLogRect.cy,sLogPage.cy);
    pLogOrg.x *= 12;
    pLogOrg.y *= 12;


    /* compute baseline text starting point relative to center of text
       rect
     */
    pText.x = (LOWORD(txx)>>1);
    pText.x = - pText.x;
    pText.y = (HIWORD(txx)>>1);
    pText.y = -pText.y + tm.tmDescent;

    /*  rotate it
     */
    pText = TransformPtbyAngle(pText,pwm->lf.lfEscapement);

    /*  convert to dest DC's logical units
     */
    pText.x = MulDiv(pText.x,LOWORD(wnx),LOWORD(vpx));
    pText.y = MulDiv(pText.y,HIWORD(wnx),HIWORD(vpx));

    /* & translate by the watermark origin (this is now a vector from
       the center of the page.)
     */
    pText.x += pLogOrg.x;
    pText.y += pLogOrg.y;

    /* Finally we translate from the center of the page to get the
       actual starting point in the Dest DC's logical units. (note that
       increasing Y now moves down).
     */
    pText.x = lpr->left + (sLogRect.cx>>1) + pText.x;
    pText.y = lpr->top  + (sLogRect.cy>>1) - pText.y;

    /* ------------ innerloop ------------ */

    pCurrent = pText;                   /* starting point  */
    SetTextAlign(hMemDC,TA_LEFT|TA_BASELINE|TA_UPDATECP);

    l = (FastMode) ? sl : 1;
    for (p=pwm->text; p<&pwm->text[sl]; p+=l) {

        /*  When I do this, GetTextExtent() always returns reports as if the
            font were not rotated (the same regardless of lfEscapement).
            Will this always be the case?  -If not we can create an
            unrotated font to get the dimensions & then a rotated one for
            final output.
         */
        txx = GetTextExtent(hMemDC,p,l);

        rChar.left   = 0;               /* get the character's rect */
        rChar.top    = 0;
        rChar.right  = LOWORD(txx);
        rChar.bottom = HIWORD(txx);

        rChar.top    += tm.tmDescent;   /* adjust for descenders */
        rChar.bottom += tm.tmDescent;
        pChar.x = 0;                    /* rotate about baseline point */
        pChar.y = HIWORD(txx);
        TransformRect(pwm->lf.lfEscapement,&rChar,pChar);
        sPhysbm.cx = rChar.right-rChar.left;
        sPhysbm.cy = rChar.bottom-rChar.top;
        pChar.x -=rChar.left;           /* baseline pt within the memory DC */
        pChar.y -=rChar.top;

        /*  round up to multiple of 16 bits for Tom Sawyer
         */
        sPhysbm.cx = ((sPhysbm.cx+15) & 0xFFF0);

        /*  draw the text into our memory dc.
         */
        hOldbm = SelectObject(hMemDC,CreateBitmap(sPhysbm.cx,sPhysbm.cy,1,1,NULL));
        BitBlt(hMemDC,0,0,sPhysbm.cx,sPhysbm.cy,NULL,0,0,WHITENESS);

        MoveTo(hMemDC,pChar.x,pChar.y);
      SelectObject(hMemDC,hRotf);
        TextOut(hMemDC,0,0,p,l);
      SelectObject(hMemDC,hUnRotf);
#if 0 // Cant use this as ATM returns a different value for the next point
        GetCurrentPositionEx(hMemDC,&pCharVect);
        pCharVect.x-=pChar.x;           /* movement vector in physical dots */
        pCharVect.y-=pChar.y;
#endif
    pCharVect.x = LOWORD(txx);
    pCharVect.y = 0;
      pCharVect = TransformPtbyAngle(pCharVect,pwm->lf.lfEscapement);
    pCharVect.y = -pCharVect.y;

        /* compute this bitmap's size in dest DC's logical units
         */
        sLogbm.cx = MulDiv(sPhysbm.cx,LOWORD(wnx),LOWORD(vpx));
        sLogbm.cy = MulDiv(sPhysbm.cy,HIWORD(wnx),HIWORD(vpx));

        /* compute the vector from the character origin to the upperleft
           corner of the bitmap in Dest DC's logical units
         */
        pLogbm.x = -MulDiv(pChar.x,LOWORD(wnx),LOWORD(vpx));
        pLogbm.y = -MulDiv(pChar.y,HIWORD(wnx),HIWORD(vpx));

        /*  now combine with the current point
         */
        pLogbm.x += pCurrent.x;
        pLogbm.y += pCurrent.y;


        /* instead, blit our bm into the dest dc (combining with contents)
         */
        {
            LPSTR      bits;
            char       bminfo[sizeof(BITMAPINFO) + sizeof(RGBQUAD)];
            HBITMAP    hNewbm;

#define LPBMI ((LPBITMAPINFO)(LPSTR)bminfo)

            hNewbm = SelectObject(hMemDC,hOldbm);

            /*  allocate a buffer to construct the DIB bits in
             */
            bits = MALLOC((LONG)sPhysbm.cy *(LONG)(((sPhysbm.cx + 31) & 0xFFE0) >>3));


            /* 64K max here? */

            LPBMI->bmiHeader.biSize     = sizeof(BITMAPINFOHEADER);
            LPBMI->bmiHeader.biWidth    = sPhysbm.cx;
            LPBMI->bmiHeader.biHeight   = sPhysbm.cy;
            LPBMI->bmiHeader.biPlanes   = 1;
            LPBMI->bmiHeader.biBitCount = 1;

            LPBMI->bmiHeader.biCompression  = BI_RGB;
            LPBMI->bmiHeader.biSizeImage    = 0;
            LPBMI->bmiHeader.biXPelsPerMeter= 0;
            LPBMI->bmiHeader.biYPelsPerMeter= 0;
            LPBMI->bmiHeader.biClrUsed      = 0;
            LPBMI->bmiHeader.biClrImportant = 0;

            LPBMI->bmiColors[0].rgbBlue = 0;    /* black */
            LPBMI->bmiColors[0].rgbGreen= 0;
            LPBMI->bmiColors[0].rgbRed  = 0;
            LPBMI->bmiColors[1].rgbBlue = 0xFF; /* white */
            LPBMI->bmiColors[1].rgbGreen= 0xFF;
            LPBMI->bmiColors[1].rgbRed  = 0xFF;

            GetDIBits(hMemDC,hNewbm,0,sPhysbm.cy,bits,LPBMI,DIB_RGB_COLORS);

// use color for the Watermark: PPeng
                LPBMI->bmiColors[0].rgbRed = disp_R;
                LPBMI->bmiColors[0].rgbGreen= disp_G;
                LPBMI->bmiColors[0].rgbBlue = disp_B;

            StretchDIBits(hdc,pLogbm.x,pLogbm.y,sLogbm.cx,sLogbm.cy,
                0,0,sPhysbm.cx,sPhysbm.cy,bits,LPBMI,DIB_RGB_COLORS,SRCAND);

            DeleteObject(hNewbm);
            FREE(bits);
        }

        /*  & advance current point by scaled character vector
         */
        pCurrent.x += MulDiv(pCharVect.x,LOWORD(wnx),LOWORD(vpx));
        pCurrent.y += MulDiv(pCharVect.y,HIWORD(wnx),HIWORD(vpx));
    }

    DeleteObject(SelectObject(hMemDC,hOldbr));
    SelectObject(hMemDC,hOldf);
    DeleteObject(hUnRotf);
    DeleteObject(hRotf);
    DeleteDC(hMemDC);

    SetTextColor(hdc,oldTextColor);
    SetBkColor(hdc,oldBKColor);
    pwm->lf.lfHeight = OrgPts;

    return TRUE;
}



COLORREF NearestPhysicalColor(HDC hdc_in, BYTE R,BYTE G, BYTE B)
{
#define  DEC_BY  2   // decrease by 2
#define MIN_INTENSITY  245  // was 255 in 3.0 driver. 4.1's display area is smaller

   BYTE Rp, Gp, Bp;

   // handle special case first:
   Rp=R; Gp=G; Bp=B;
   if ( ((Rp>=255) && (Gp>=255) && (Bp>=255)) ||
        ((Rp<=200) || (Gp<=200) || (Bp<=200)) )
      return (RGB(Rp,Gp,Bp));

   while( (((5*Gp+3*Rp+Bp)+4)>>3)>=MIN_INTENSITY){
       if ((Rp<=200) || (Gp<=200) || (Bp<=200)) break; // in case dead loop
       Rp=(BYTE)(Rp-DEC_BY);
       Gp=(BYTE)(Gp-DEC_BY);
       Bp=(BYTE)(Bp-DEC_BY);
   }
   return (RGB(Rp,Gp,Bp));
}


static int CALLBACK FillFontComboBox(const ENUMLOGFONT FAR* elf, const NEWTEXTMETRIC FAR* ptm,
int type, LPARAM lParam) {
    LPENUMEXTRA pfe;

    pfe = (LPENUMEXTRA)lParam;

    type &= pfe->eeTypeMask;            /* skip undesired font types */
    if (!type)
        return TRUE;

    AddFontToComboBox(pfe->eehDlg, (LPSTR)elf->elfLogFont.lfFaceName);
    return 1;
}

static VOID AddFontToComboBox(long hDlg, LPSTR fontname)
{
    if (SendDlgItemMessage((HWND)hDlg, ID_WATERMARK_FONT,
                CB_FINDSTRINGEXACT,
                (WORD)-1,
                (long)fontname) == CB_ERR)
       SendDlgItemMessage((HWND)hDlg, ID_WATERMARK_FONT, CB_ADDSTRING, 0,
                (long)fontname);
}

static void EnumWMFonts(LPPDEVICE lppd, HWND hDlg)
{
    int i, j;
    LOGFONT        lf;
    LPLOGFONT      plf;

    plf=(LPLOGFONT)&lf;  // temporary work pointer.

    SetWMFontByType(hDlg, NULL, plf, TRUETYPE_FONTTYPE);  // fill with TRUETYPE fonts.
    SetWMFontByType(hDlg, NULL, plf, DEVICE_FONTTYPE);  // fill with device fonts -- ATM fonts.

    // Initialize UseDisp flags in Default WM Font List -
    for (i=0; i<sizeof(StdFonts)/sizeof(StdFonts[0]); i++){
       if ((j=(int)SendDlgItemMessage(hDlg, ID_WATERMARK_FONT, CB_FINDSTRINGEXACT,
                   (WORD)-1, (long)(LPSTR)StdFonts[i].FontName) ) != CB_ERR)
          StdFonts[i].UseDisp=0;  // The font is added as TrueType - rotatable.
       else StdFonts[i].UseDisp=1;  // Use DispName to display in Watermark Dialog.
       }
    // Add four special families: courier, helvetica, times-roman, symbol:
    for(i = 0; i<sizeof(StdFonts)/sizeof(StdFonts[0]);i++)
       if (StdFonts[i].FontName[0]!='\0') AddFontToComboBox(hDlg, StdFonts[i].FontName);
}


int SetWMFontByType(HWND hDlg,HDC inhdc,LPLOGFONT plf,int FontType){

    HDC         hdc;
    ENUMEXTRA   ee;
    FONTENUMPROC lpfnEnumFonts;

    hdc = (inhdc) ? inhdc : GetDC(hDlg);

    /* if necessary, maybe we can create a font from the logfont, select
       it & get textmetrics.  To insure that our logfont matches a
       physical font.
     */
    ee.eehDlg       = hDlg;
    ee.eeFamFound   = FALSE;
    ee.eelf         = plf;
    ee.eeTypeMask   = FontType;
    // Other fields are not used here

    lpfnEnumFonts = (FONTENUMPROC) MakeProcInstance((FARPROC)FillFontComboBox, ghDriverMod);
    if (lpfnEnumFonts != NULL)
      {
       EnumFontFamilies(hdc,NULL, lpfnEnumFonts,(LPARAM)(LPSTR)&ee);
       FreeProcInstance((FARPROC)lpfnEnumFonts);
      }

    if (!inhdc) ReleaseDC(hDlg,hdc);
    return (1);
}

/*****************************************************************************/
/*                 CheckWatermarkValues
/* Purpose:                                                                  */
/*   Checks the validity of certain user entered data in the                 */
/*   Watermark features dialog box. The first invalid or out of range entry   */
/*   causes failure and the item in question will be highlighted.            */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog                       */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE  => if success, entered values are fine                            */
/*   FALSE => if failure, at least one entered value is invalid              */
/*****************************************************************************/
BOOL NEAR PASCAL CheckWatermarkValues(HWND hDlg)
{
    int            ctrl_id = 0;
    long           i;
    BOOL           bOK = FALSE;
    int            minVal, maxVal;

    /* Check size */
    ctrl_id = ID_WATERMARK_SIZE;
    i = GetDlgItemInt(hDlg, ctrl_id, &bOK, FALSE);
    if(bOK && (i < MINWMSIZE || i > MAXWMSIZE))
    {
       bOK = FALSE;
    }
    if (!bOK)
    {
       minVal = MINWMSIZE;
       maxVal = MAXWMSIZE;
       goto Errors;
    }

    /* Check Angle */
    ctrl_id = ID_WATERMARK_ANGLE;
    i = GetDlgItemRealSigned(hDlg, ctrl_id, 0, decimalSeparator, &bOK, TRUE);
    if (bOK && (i < MINANG || i > MAXANG))
    {
        bOK = FALSE;
    }
    if (!bOK)
    {
        minVal = MINANG;
        maxVal = MAXANG;
        goto Errors;
    }

    /* Check X pos */

    // Bug fix for 143208, 143209, 143210, 143211. Moved from in 4.1CJK
    ctrl_id = ID_WATERMARK_XPOS;
    i = GetDlgItemRealSigned(hDlg, ctrl_id, 2, decimalSeparator, &bOK, TRUE);
    if (bOK && (i < (long)ConvertToUserUnit(MINXPOS) ||
                i > (long)ConvertToUserUnit(MAXXPOS)) )
    {
        bOK = FALSE;
    }
    if (!bOK)
    {
        minVal = (int)ConvertToUserUnit(MINXPOS)/100;
        maxVal = (int)ConvertToUserUnit(MAXXPOS)/100;
        goto Errors;
    }

    /* Check Y pos */
    ctrl_id = ID_WATERMARK_YPOS;
    i = GetDlgItemRealSigned(hDlg, ctrl_id, 2, decimalSeparator, &bOK, TRUE);
    if (bOK && (i < (long)ConvertToUserUnit(MINXPOS) ||
                i > (long)ConvertToUserUnit(MAXXPOS) ))
    {
        bOK = FALSE;
    }
    if (!bOK)
    {
        minVal = (int)ConvertToUserUnit(MINXPOS)/100;
        maxVal = (int)ConvertToUserUnit(MAXXPOS)/100;
        goto Errors;
    }

    /* Check Red */
    ctrl_id = ID_WATERMARK_RED;
    i = GetDlgItemInt(hDlg, ctrl_id, &bOK, FALSE);
    if (bOK && (i < MIN_COLOR || i > MAX_COLOR))
    {
        bOK = FALSE;
    }
    if (!bOK)
    {
        minVal = MIN_COLOR;
        maxVal = MAX_COLOR;
        goto Errors;
    }

    /* Check Green */
    ctrl_id = ID_WATERMARK_GREEN;
    i = GetDlgItemInt(hDlg, ctrl_id, &bOK, FALSE);
    if (bOK && (i < MIN_COLOR || i > MAX_COLOR))
    {
        bOK = FALSE;
    }
    if (!bOK)
    {
        minVal = MIN_COLOR;
        maxVal = MAX_COLOR;
        goto Errors;
    }

    /* Check Blue */
    ctrl_id = ID_WATERMARK_BLUE;
    i = GetDlgItemInt(hDlg, ctrl_id, &bOK, FALSE);
    if (bOK && (i < MIN_COLOR || i > MAX_COLOR))
    {
        bOK = FALSE;
    }
    if (!bOK)
    {
        minVal = MIN_COLOR;
        maxVal = MAX_COLOR;
        goto Errors;
    }

Errors:
    if (!bOK)
    {
        ShowErrorValueMessage(hDlg, ctrl_id, minVal, maxVal);
    }

    return bOK;
}

// Watermar.ini manage functions
/*-------------------- Watermark support routines ----------------------------*/

/*  get integer value from string, bump string pointer past terminator
 */
int PASCAL GetIntFromStr(LPSTR FAR* pp) {
    LPSTR   p;
    BOOL    neg;
    int     n;

    n = 0;
    neg = FALSE;

    for (p=*pp;*p;p++) {
        if (*p=='-') {
            neg=TRUE;
            continue;
        }
        if (*p<'0'||*p>'9')
            return 0;
        n=n*10+*p-'0';
    }
    *pp = p+1;
    return neg ? -n : n;
}



/*  process quotes & convert unquoted commas to nulls
    returns & of nulls that were inserted
 */
int UnQuoteWMText(LPSTR s) {
    LPSTR   d;
    int     rc;

    d=s;
    rc=0;
    while (*s) {
        if (*s=='\\')       { s++;    *d++=*s++;   }
        else if (*s==',')   { s++;    *d++=0; rc++;}
        else                *d++=*s++;
    }
    *d++=0;
    return rc;
}


/*  quote commas & backslashes in string
 */
void QuoteWMText(LPSTR str) {
    LPSTR   s,d;
    int     i;

    i=0;

    for (d=str;*d;d++)                  /* count # of quotes to insert */
        if (*d=='\\' || *d==',') i++;

    if (!i) return;                     /* exit if none */

    s=d;
    d+=i;
    while (s>=str) {                    /* insert them, moving backwards */
        *d--=*s;
        if (*s=='\\' || *s==',')
            *d--='\\';
        s--;
    }
}


/*  Delete a Watermark from .INI file
 * Pass-ed in name is Un-quoted.
 */
void PASCAL DeleteWatermark(DWORD dwWatermarkID)
{
   char  szEntryName[40];  /* ini file entry str */
   char  szWatermarkKey[256];  // watermark key path in registry
   HKEY  hKey;

   CompositeString(ghDriverMod, IDS_REGSTR_PATH_WATERMARK,
                  IDS_DRIVER_MANUFACTURER, 0,
                  szWatermarkKey, sizeof(szWatermarkKey));
   if(RegOpenKey(HKEY_LOCAL_MACHINE, szWatermarkKey, &hKey) == ERROR_SUCCESS)
   {
      _ltoa(dwWatermarkID, szEntryName, 10);
      RegDeleteValue(hKey, szEntryName);
      RegCloseKey(hKey);
   }
}

/*  Write Watermark to .INI file
 */
void PASCAL WriteWatermark(LPWM pwm)
{
char    bfr[MAXINISTR+MAXWMTXT];  // long enough to hold quoted text + other stuffs
char    szEntryName[40];  /* ini file entry heading */
char    szWatermarkKey[256];
HKEY    hKey;
long    ret;
char    bf1[MAXWMTXT*2+2];  // long enough to hold quoted text.

    lstrcpy(bf1,pwm->text);
    QuoteWMText(bf1);

    wsprintf(bfr,"%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%s,%s",
        (int)pwm->xpos,
        (int)pwm->ypos,
        (int)pwm->R,
        (int)pwm->G,
        (int)pwm->B,
        pwm->outline,
        pwm->background,
        pwm->passthrough,
        pwm->lf.lfEscapement,
        pwm->lf.lfWeight,
        (WORD)pwm->lf.lfItalic,
        pwm->lf.lfHeight,
        (LPSTR)pwm->lf.lfFaceName,
        (LPSTR)bf1);

    CompositeString(ghDriverMod, IDS_REGSTR_PATH_WATERMARK,
                  IDS_DRIVER_MANUFACTURER, 0,
                  szWatermarkKey, sizeof(szWatermarkKey));
    ret=RegCreateKey(HKEY_LOCAL_MACHINE, szWatermarkKey, &hKey);
    if (ret==ERROR_SUCCESS)
    {
       ret = RegSetValueEx(hKey, _ltoa(pwm->dwWatermarkID, szEntryName, 10),
                           0, REG_SZ, (LPBYTE)bfr, lstrlen(bfr));
       RegCloseKey(hKey);
    }
}


/*  Read a Watermark record from .INI file
 */
BOOL WINAPI ReadWatermark(DWORD dwWatermarkID, LPWM pwm)
{
char    bfr[MAXINISTR+MAXWMTXT];
LPSTR   s;
char    szEntryName[40];  /* ini file entry str */
char    szWatermarkKey[256];  // watermark key path in registry
long    cb;
HKEY    hKey;
DWORD   typecode;

   if (pwm==NULL) return FALSE;

    DefaultWm(pwm);                         /* init to defaults in case we fail */

    pwm->dwWatermarkID = dwWatermarkID;   /* make sure name isn't too long */

    CompositeString(ghDriverMod, IDS_REGSTR_PATH_WATERMARK,
                  IDS_DRIVER_MANUFACTURER, 0,
                  szWatermarkKey, sizeof(szWatermarkKey));
    cb = sizeof(bfr) - 1;

    if (RegOpenKey(HKEY_LOCAL_MACHINE, szWatermarkKey, &hKey) != ERROR_SUCCESS)
        return FALSE;

    _ltoa(pwm->dwWatermarkID, szEntryName, 10);
    RegQueryValueEx(hKey, szEntryName, 0, &typecode, bfr, &cb);
    RegCloseKey(hKey);
    bfr[cb+1]='\0';

    if (UnQuoteWMText(bfr) != MAXWMFIELDS-1)
        return FALSE;            /* error if not enough fields */

    s = bfr;
    pwm->xpos               = (long)GetIntFromStr(&s);     /* read fields */
    pwm->ypos               = (long)GetIntFromStr(&s);
    pwm->R                  = (BYTE)GetIntFromStr(&s); // was gray
    pwm->G                  = (BYTE)GetIntFromStr(&s);
    pwm->B                  = (BYTE)GetIntFromStr(&s);
    pwm->outline            = GetIntFromStr(&s);
    pwm->background         = GetIntFromStr(&s);
    pwm->passthrough        = GetIntFromStr(&s);
    pwm->lf.lfEscapement    = GetIntFromStr(&s);
    pwm->lf.lfWeight        = GetIntFromStr(&s);
    pwm->lf.lfItalic        = (BYTE)GetIntFromStr(&s);
    pwm->lf.lfHeight        = GetIntFromStr(&s);
    lstrcpyn(pwm->lf.lfFaceName,s,LF_FACESIZE);
    pwm->lf.lfFaceName[LF_FACESIZE-1] = '\0';
    s+=lstrlen(s)+1;
    lstrcpyn(pwm->text,s,MAXWMTXT);
    pwm->text[MAXWMTXT-1] = '\0';
    return TRUE;
}

void DefaultWm(LPWM pwm) {
char  newName[MAXWMNAME];

    LoadString(ghDriverMod, IDS_WM_NEW, (LPSTR)newName, sizeof(newName));

    pwm->lf.lfWidth         = 0;
    pwm->lf.lfOrientation   = 0;
    pwm->lf.lfUnderline     = 0;
    pwm->lf.lfStrikeOut     = 0;
    pwm->lf.lfCharSet       = DEFAULT_CHARSET;
    pwm->lf.lfOutPrecision  = OUT_DEFAULT_PRECIS;
    pwm->lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
    pwm->lf.lfQuality       = DEFAULT_QUALITY;
    pwm->lf.lfPitchAndFamily= DEFAULT_PITCH;

    pwm->xpos               = 0;
    pwm->ypos               = 0;
    pwm->R                  = (BYTE)120;
    pwm->G                  = (BYTE)120;
    pwm->B                  = (BYTE)120;
    pwm->outline            =0;
    pwm->background         =1;
    pwm->passthrough        =0;
    pwm->lf.lfHeight        = 72;
    pwm->lf.lfWeight        = FW_BOLD;
    pwm->lf.lfItalic        = 0;
    pwm->lf.lfEscapement    = 0;
    lstrcpy(pwm->lf.lfFaceName, (LPSTR)DefaultWMFont);
    lstrcpy(pwm->text,newName);
    pwm->text[MAXTEXTLEN - 1] = '\0';
}


/*  Fill in font style listbox & select matching style.
    From Logfont struct
 */
void SetStyle(HWND hDlg,LPLOGFONT plf, WORD idcStyle)
{
    int StyIx;
    /*  & select the appropriate style */
    if (plf->lfWeight > FW_NORMAL){ // bold ..
       if (plf->lfItalic & 1) StyIx = PS_BOLDITALIC;
       else StyIx = PS_BOLD;
       }
    else {  // normal
       if (plf->lfItalic & 1) StyIx = PS_ITALIC;
       else StyIx = PS_REGULAR;
       }
   SendDlgItemMessage(hDlg, idcStyle,CB_SETCURSEL, StyIx,0L);
}


/*  Get bold/italic attributes from font style listbox
    return the style in the LogFont struct
*/
void GetStyle(HWND hDlg,LPLOGFONT plf, WORD idcStyle)
{
    int StyIx;

    StyIx = (int) SendDlgItemMessage(hDlg, idcStyle, CB_GETCURSEL,0,0L);

    switch (StyIx){
      case PS_REGULAR:
         plf->lfWeight = FW_NORMAL;
         plf->lfItalic = 0;
         break;
      case PS_BOLD:
         plf->lfWeight = FW_BOLD;
         plf->lfItalic = 0;
         break;
      case PS_ITALIC:
         plf->lfWeight = FW_NORMAL;
         plf->lfItalic = 1;
         break;
      case PS_BOLDITALIC:
         plf->lfWeight = FW_BOLD;
         plf->lfItalic = 1;
         break;
      }
}


/*  return angle for LOGFONT escapement from slider
 * +Angles (0 to 90) are from 0 to 900 and
 * -Angles (-90 to 0) are from  2700 to 3600.
 */
int NEAR PASCAL AngleSlider(int iSl) {
   iSl *= 10;
   if (iSl < 0) iSl += 3600;  // 2700 to 3600
    return iSl;
}


/*  return angle for slider from LOGFONT escapement
 */
int NEAR PASCAL SliderAngle(int iEs) {

   iEs /= 10;
   if (iEs<=90) return iEs;
   else         return iEs-360;
}


//***************************************************************************
//                            GenerateWatermarkID
//
//  PURPOSE:  Generate the unique watermark id.
//
//  PARAMETERS:
//
//  RETURNS:      DWORD
//
//***************************************************************************
DWORD NEAR PASCAL GenerateWatermarkID(VOID)
{
   long  lTime;


   time(&lTime);

   lTime += GetTickCount();

   return(((3141592621 * lTime + 1) % 1073741824) & 0x3fffffff | 0x40000000);

}// END GenerateWatermarkID




// Bug fix for 143208, 143209, 143210, 143211. Moved from in 4.1CJK

/*****************************************************************************/
/*                 GetMeasurementUnit                                        */
/* Purpose:                                                                  */
/*   Gets the unit system to be used from the control panel Win.ini entry    */
/* Returns: int                                                              */
/*   ID_CP_INCHES, ID_CP_MILLIMETERS if units are Imperial units or SI units */
/*****************************************************************************/
// This function was in DLGUtils.c - but it is NEAR there - cannot use from here.
int NEAR PASCAL GetMeasure()
{
    char section[16], entry[16];
    int iMeas;
    LoadString(ghDriverMod, IDS_INI_INTL, section, sizeof(section)) ;
    LoadString(ghDriverMod, IDS_INI_INT_MEASURE, entry, sizeof(entry)) ;
    iMeas = GetProfileInt(section, entry, 0);
    return (iMeas == 0) ?
            ID_CP_MILLIMETERS : ID_CP_INCHES;
}


// convert from 1/100 inch to user/100 units (in Inch or cm)
long ConvertToUserUnit(long x)
{
    int iMeas;
    long y;
    float  ftmp;
    iMeas = GetMeasure();
    if (iMeas == ID_CP_INCHES) // INCHES
    {
        y = x;
    }
    else  // millimeters
    {
        ftmp = ((float)x) * ((float)2.54);
        if (x>0) ftmp = ftmp + (float)0.5;
        if (x<0) ftmp = ftmp - (float)0.5;
        y = (long) (ftmp);
    }

    return y;
}


// convert from user/100 units (in Inch or cm) to 1/100 inch
long ConvertTo100thInch(long x)
{
    int iMeas;
    long y;
    float ftmp;
    iMeas = GetMeasure();
    if (iMeas == ID_CP_INCHES) // INCHES
    {
        y = x;
    }
    else  // millimeters
    {
        ftmp = ((float)x) / ((float)2.54);
        if (x>0) ftmp = ftmp + (float)0.5;
        if (x<0) ftmp = ftmp - (float)0.5;
        y = (long) (ftmp);
    }

    return y;
}



// Singed version of SetCurrentSpinPos() in DMG\slgsutil.c, 3-19-1996
/*****************************************************************************/
/*                 SignedSetCurrentSpinPos                                   */
/* Purpose:                                                                  */
/*   Sets the current spin positions by reading the value from the edit      */
/*   control and setting the spin control.                                   */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   spinCtrl  -- ID of the first spin control.                              */
/*   editCtrl  -- ID of the first edit control.                              */
/*   nitems    -- Number of elements in lpValue array.                       */
/*   nDecimals -- Number of decimal places to retrieve the number from the   */
/*                edit box.                                                  */
/*                                                                           */
/* Returns:                                                                  */
/*   nothing                                                                 */
/*****************************************************************************/
void FAR PASCAL SignedSetCurrentSpinPos(HWND hDlg, int spinCtrl, int editCtrl,
                                   int nitems, int nDecimals)
{
    LONG temp;
    int  i;
    BOOL bOK;
    for (i=0; i<nitems; i++)
    {
        temp = GetDlgItemRealSigned(hDlg, editCtrl+i, nDecimals, decimalSeparator,
                              &bOK, FALSE);
        SendDlgItemMessage(hDlg, spinCtrl+i, UDM_SETPOS, NULL,
                           MAKELPARAM(temp, NULL));
    }
}


