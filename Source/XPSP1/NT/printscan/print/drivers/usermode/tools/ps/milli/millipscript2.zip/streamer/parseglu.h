/*
  parseglue.h

  Header file for the parse glue functions.

             Copyright (c) 1990-1992 -- Adobe Systems Incorporated
    PostScript is a registered trademark of Adobe Systems Incorporated.

NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

Edit History:
Scott Byer: Mon Dec  3 17:00:09 1990
Paul Sholtz: Wed Jan 29 15:11:00 1992
Mike Shupe: Fri Jan 31 1992
Ron Fischer: Thu Jan 14 12:19:08 1993
End History.

NOTE: This implementation supports multiple master fonts roman fonts and
      dbcs fonts but not multiple master dbcs fonts.
      Also, this implementation supports shared roman fonts but not shared
      dbcs fonts.
*/

#ifndef PARSEGLUE_H
#define PARSEGLUE_H

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif
#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES
#include BUILDCH
#include PARSE
#include BLEND
#if CID
#include DECO_LIB
#endif


#define MAXAXISNAMELEN  	20  /* maximum length of a name of an axis */
#define MAX_ROMAN_FONTS     	 1  /* number of ROMAN pgfonts */
#define EMPTY_CELL		0   /* Index value for empty cell */

/* If an implementation is to have a custom standard glyph list, then the
   following line should be changed to 'extern char *standardGlyphList[]',
   and the definition of the custom glyph list needs to here.  Note that the
   first entry in the glyph list (at index 0) should be '.notdef', so that
   it can be used to indicate an unencoded character.  ATM_NUMBER_GLYPHS
   should be defined to be the number of names in the glyph list, including
   the '.notdef'  */

#define standardGlyphList               standardCharacters
#define ATM_NUM_STANDARD_CHARACTERS     229

#ifndef ATM_NUMBER_GLYPHS
#define ATM_NUMBER_GLYPHS               229
#endif  /* ATM_NUMBER_GLYPHS */
                    
                    /* Standard 229 character names, defined in charmap.c */
extern char *standardCharacters[ATM_NUM_STANDARD_CHARACTERS]; 

extern Int16 standardEncoding[256];                 /* found in encmap.c */


/* Types for the subr4 field.  See the description of the field for more */
/* information about these types. */
#define NOTSTANDARDV	0
#define STANDARDV1	1
#define STANDARDV2	2




typedef struct 	   /* Values that define mapping from user to design space */
 { short numMaps;	/* NUmber of from and to maps */
   Fixed *userSpace;	/* Array of values in user space   */
   Fixed *designSpace;	/* Array of values in design space */
 } BlendMap;       /* Used with Multiple Masters */

typedef struct	  /* Info used for saving general PostScript as strings */
 { Card8 *name;		/* Name of the PostScript def */
   Card8 *data;		/* Raw characters for the PostScript */
   IntX dict;		/* The dictionary the data came from */
 } PostScriptInfo;


#if CID
#define MAX_FDBYTES		4	
#define MAX_GDBYTES		4	
#define MAX_SDBYTES		4L	
#define MAX_COMPONENT_FONTS	32 /* Max allowed in this implementation */

typedef struct _t_CMapRec	/* Contains all important cmap info */
{ char          *cMapPath;	/* The path to the cmap file */
  char		*registry;	/* The registry version info for the cmap */
  char		*ordering;	/* The ordering version info for the cmap */
  Int32		supplement;	/* The supplement version info for the cmap */
  deco_Encoding	*encoding;	/* The encoding information.  See deco_lib.h */
  FixMtx	**useMtx;	/* The usematrix info (rearranged fonts only)*/
  char		*cMapUsed;	/* The cmapused file name */
} CMapRec, *CMapPointer, **CMapHandle;
#endif


/* Type for the GetBytesFunc call-back.  This is the call-back that reads
   the raw data from the system specific (Mac, PC, Unix, etc) font file.
   The pHandle is a pointer to a handle to the data buffer.  maxLen is the
   maximum amount of bytes to read (you can return less data).  Returns true
   if successful, false on error.  SEE EXAMPLES IN streamtst.c  */

typedef CardX (*GetBytesFunc) ARGDECL2(char ***, pHandle, CardX, *maxLen);


/* Type for the memory reallocation function. All memory access for streamer
   go through this call-back.  Required functionality: When size == 0
   free the handle (if it is non-NULL).  When size > 0 and handle != NULL
   reallocate memory, PRESERVING the data.  When size > 0 and handle == NULL
   allocate the memory (it does not have to be cleared).  When size == 0
   and handle == 0 don't do anything!  Return true on success, false on
   failure. */

typedef boolean (*ReallocFunc) ARGDECL2(void **, handle, Card32, size);


/* Optional callbacks for controlling the storage of charstrings and subrs */

/* If these callbacks are passed as NULLs to T1FontParse() the charstrings   
   and subrs will be stored in the T1FontRec structure with all of the other
   font information.  Charstrings and subrs take up the vast majority of 
   the storage requirements--the user may want to manage that process. */

/* Type for the callback that is told how the maximum number of charstrings to expect */
typedef boolean (*AllocCharStringsFunc) ARGDECL1(IntX, count);

/* Type for the callback that gets the actual charstrings */
typedef boolean (*CharStringFunc) ARGDECL3(char *, name, CharDataPtr, val, CardX, len);

/* Type for the callback that is told the maximum number of  subroutines to expect */
typedef boolean (*AllocSubroutinesFunc) ARGDECL1(IntX, count);

/* Type for the callback that gets the actual subroutines */
typedef boolean (*SubroutineFunc) ARGDECL3(IntX, index, CharDataPtr, val, CardX, len);

/* Type for the callback that streams all of the font data to the user */
typedef  boolean (*FontDataStreamFunc) ARGDECL2(char, c, Card32, count);

/* Type for the callback that informs the user of the position of a key value */
typedef  boolean (*KeyPositionFunc) ARGDECL2(Card8, type, Card32, count);

/* Type for the callback that informs the user that the font attribute (hybrid font, i.e.,
   Streamer cannot support this font).
*/
typedef boolean (*FontAttributeFunc) ARGDECL1(Card16, type);

/* Description of the T1FontRec (*T1FontPointer, **T1FontHandle)

The T1FontRec contains all the data that the OEM/ATM glue code needs to know
about a font. If multiple masters are not supported those fields
could be removed for additional space savings.  Note that a some of the
fields are hidden ("opaque") structures.  In general they are not intended
to be modified by OEMs and are subject to change is different version of
the ATM core.

fontName	char*  -- Pointer to null terminated ASCII string
		Contains the actual font name (not the font file name).

fontType	Int32 -- numeric font type

pFontDict	FontDesc** -- Array of pointers to FontDesc.  Currently 
		there are MAX_ROMAN_FONTS number
		of entries.  This structure isn't normally modified by
		OEMs.  See the ATM core code (buildch.h) for more info.

pFontInst	FontInst** -- Array of pointers to FontInst, same number as
		FontDescs.  This structure isn't normally modified by OEMs.
		See the ATM core code (buildch.h) for more info.

uniqueID	Int32 -- A unique font id useful for caching bitmaps accross
		jobs (for instance). Adobe maintains a registry of ids and
		names for Type 1 fonts.  See the "Adobe Type 1 Font Format"
		book for more information.

FCdBBox		fontBBox -- The bounding box big enough for all characters
		in the font.

hasStandardCharacters	boolean bitfield -- Flag indicating if the font has
		the standard 228 characters-there may also be additional
		characters in the font.

hasStandardEncoding	boolean bitfield -- Flag indicating if the font uses
		the Adobe standard character encoding.  The implementation
		should set this flag to false if the encoding is modified.

isFixedPitch	boolean bitfield -- Indicates that the font is fixed pitch.

standardSubrs   boolean bitfield -- Identifies whether or not the 1st 5 subrs 
                (subrs0-4) are the standard flex/hint substitution subrs or 
                not.  This is not set by the parser (it defaults to true).  
                It should be set by the application (like streamer).

subr4           2 bit field -- Identifies subr 4 as one of two standard forms
                or unstandard.  One of the standard forms is used by most
                Type 1 fonts, the other by most Type 1 Kanji row fonts.  These
                flags are only valid if standardSubrs is true.  This field
                is set by the application.

Notice 		char* -- The copyright notice.

FullName 	char* -- The full name of the font.

FamilyName 	char* -- The family name of the font.

baseFontName    char* -- The base font name of a synthetic font.  If this name
                is null the font is not synthetic (or, if still in the parse
                function, it has not yet been determined to be synthetic).

Weight 		char* -- The weight (boldness) of the font.

Version 	char* -- The version of the font.

ItalicAngle 	Fixed	-- Italic angle of the font.

UnderlinePosition Fixed	-- The underline position.

UnderlineThickness Fixed -- The underline thickness.

numCharacters	Int16 -- The number of character outlines parsed.  If a font
		contains only the Adobe standard characters this number is
		228.

encoding	Int16* -- A pointer to a table which maps character codes 
		(ASCII) into indices for the charStrings array.

specialEncoding char** -- A pointer to a 256 element array of pointers to 
                charString names, only used if !hasStandardEncoding.  
                Unencoded positions will be initialized to ".notdef";

numCharStrings	Int16 -- Number of elements in the charStrings, charLengths,
		and charNames arrays.  It may be different from numCharacters 
		because of composite characters.  

charStrings	CharDataPtr -- Array of charstrings (outline data) for the
		font.  

charLengths	Card16* -- An array of lengths, one for each charString.

charNames	char** -- A pointer to an array of strings, one name for each
		charString.

subrLengths	Card16** -- An array of arrays of the length of each subroutine
		string in each FontDesc.

pSubrArray	CharData** -- Pointer to array of pointers of subroutines.

otherSubrSize   Card16 -- Size of the other subr data in bytes.

pOtherSubrs	Card8* -- Pointer to the othersubrs PostScript (No structure
                imposed-just a string of characters).

buildCharArray  Fixed* -- Run time array used for temporary memory.  Newer
                fonts can cause memory to be allocated (only in this array)
                and access it with gets and puts.  It is uninitialized!

defaultVals     The FontValues for the font AFTER blending of hints, etc

blendMap[MAXAXES] BlendMap -- An array of tables used to map from user space
		(integers) to design space (0-1).

ds		DesignSpace* -- A structure used for blending several master
		fonts into one font with the desired characteristics.  OEMs
		shouldn't need to work with this field.

numAxes 	Card16 -- The number of axes in a multiple master font.

axisNames[MAXAXES][MAXAXISNAMELEN]  char -- The name of each axis in a 
		multiple mastet font.

weightVector[MAXWEIGHT]  Fixed -- The weights for each master in a
		multiple master font.

numBaseFonts 	IntX -- The number of base fonts.  Usually 1 for Roman fonts,

CID specific fields:

registry	char* -- The registry version info

ordering 	char* -- The ordering version info

supplement 	Int32 -- The supplement version info

GDBytes 	Int32 -- The number of bytes for Glyph offsets

FDBytes 	Int32 -- The number of bytes for Dictionary offsets

CIDCount 	Int32 -- Number of CID's in the cidfont.  

CIDMapOffset 	Int32 -- Offset to the CIDMap list, from dataStart

CIDFontVersion	Int32 -- formal version number for the file.

FDArrayFontName char** -- Array for the font names for each dict

SDBytes 	Card32* -- Array for number of bytes for subr offsets (per dict)

subrMapOffset 	Card32* -- Offset to the subrMap list, for each dict

subrCount 	Card32* -- Number of subrs for each dict

charOffsetsTable Card32 -- offset to start of the character offsets table

dataStart 	Card32 -- offset to start of data in the cidfont

UIDBase		Int32 -- Used for assigning IDs in VM (PostScript systems)

XUID		Int32 (array with 3 elements) -- eXtended Unique ID

cMap 		CMapPointer -- pointer to the associated cmap 

doubleEncryption Card8* -- Array indicating which dicts have double encryption

*/

typedef struct _t_T1FontRec	/* Contains all important font info */
{				/* Description of structure is above */
  char          *fontName;
  Int32		fontType;
  FontDesc      **pFontDict;
  FontInst      **pFontInst;
  Int32         uniqueID;
  FCdBBox       fontBBox;
  boolean       hasStandardCharacters:1;
  boolean       hasStandardEncoding:1;
  boolean	isCID:1;
  boolean	isFixedPitch:1;
  boolean	standardSubrs:1;
  boolean	subr4:2;

  char          *Notice;	/* Font Information */
  char  	*FullName;
  char 		*FamilyName;
  char          *baseFontName;
  char 		*Weight;
  char		*Version;
  Fixed		ItalicAngle;
  Fixed		UnderlinePosition;
  Fixed		UnderlineThickness;
  Fixed		initialRandomSeed;

  Int16         numCharacters;
  Int16         *encoding;
  char          **specialEncoding;

  Int16         numCharStrings;
  CharDataPtr   *charStrings;           /* Roman only */
  Card16        *charLengths;           /* Roman only */
  char          **charNames;            /* Roman only */

  Card16        **subrLengths;
  CharDataPtr   **pSubrArray;/* Pntr to array of pntrs to Subrs */
  Card16        otherSubrSize;
  Card8         *pOtherSubrs;

  Fixed *buildCharArray; /* Run time array used for temporary memory */

  /* Multiple Master variables */

  FontValues    defaultVals;
  BlendMap      blendMap[MAXAXES];
  DesignSpace   *ds;
  Card16        numAxes;
  char          axisNames[MAXAXES][MAXAXISNAMELEN];
  Fixed         weightVector[MAXWEIGHT];

  IntX          numBaseFonts;
  char          *baseMMFontName;

#if CID
  char          *fontPath;
#endif /* #if CID */

#if CID
/* CID variables */
  char		*registry;
  char		*ordering;
  Int32		supplement;
  Int32		GDBytes;
  Int32		FDBytes;
  Int32		CIDCount;
  Int32		CIDMapOffset;
  Int32		CIDFontVersion;
  char 		**FDArrayFontName;
  Card32	*SDBytes;
  Card32	*subrMapOffset;
  Card32	*subrCount;
  Card32	charOffsetsTable;
  Card32	dataStart;
  Int32		UIDBase;
  Int32		XUID[3];
  CMapPointer	cMap;
  Card8		*doubleEncryption;
#endif /* #if CID */

} T1FontRec, *T1FontPointer, **T1FontHandle;


/*************************************************************************

Function name:  T1ParseInit()

**************************************************************************

Date:           01/22/93
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Init the growable buffers.
Description:    Inits the growable buffers and establishes the
                application's memory reallocation function.  Also calls
                InitParseTables().

Parameters:     MemRealloc - the memory reallocation function.
Return Values:  ST_NOERR if no error, PE_CALLER if out of memory,
                otherwise, returns the code from InitParseTables().

Notes:          The return value in the manual is described incorrectly.
See also:       InitParseTables().
**************************************************************************/

IntX T1ParseInit ARGDECL1(ReallocFunc, MemRealloc);


/*************************************************************************

Function name:  T1ParseDeinit()

**************************************************************************

Date:           01/22/93
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Frees the growable buffers
Description:    Frees the growable buffers and calls Terminate to free
                any mem the render may be hogging.

Parameters:     none
Return Values:  none
See also:       T1ParseInit()
**************************************************************************/

void T1ParseDeinit ARGDECL0();


/*************************************************************************

Function name:  T1FontParse()

**************************************************************************

Date:           01/14/93 (comments added)
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Create and fill in in a T1FontRec structure.
Description:    This routine reads a font file and parses it, setting up
		the T1FontRec and other important structures and arrays.
                
Parameters:     font - the handle to the font to create
		GetBytesFunc - The call-back that reads in the raw data.
		AllocCharStrings - allocate charstrings callback
		CharStrings - get the charstrings callback
		AllocSubroutines - allocate subroutines callback
		Subroutines - get the subroutines callback
                FontDataStream - callback for getting the entire font stream
                KeyPosition - callback which will give the position for
                              certain keys.
                
Return Values:  PE_NOERR if all is OK, PE_CALLER if a generic error is found.
		Other return values come from the parser.
Notes:   	The T1FontHandle can be moved around but the buffer from
		GetBytesFunc and the first growable buffer cannot.  (The
		low-level parser assumes that these structures are locked
		down).
                If you are using the allocate and get routines for charstrings
                and subrs you must use both an allocate and a get--for
                instance, you cannot allocate the storage and expect the
                get routine to use it.
                FontDataStream and KeyPosition work together to get the
                complete font data stream (including all general postscript,
                etc) and inform the user when certain keys (subrs, charstrings,
                etc) are found.  This is used to perform certain streamer
                operations (non-snapshot) on font files.  See parse.h for
                the list of keys recognized.

See also:       T1FontRelease()

**************************************************************************/

IntX T1FontParse ARGDECL9(T1FontHandle, font, GetBytesFunc, GetBytes,
     AllocCharStringsFunc, AllocCharStrings, CharStringFunc, CharString,
     AllocSubroutinesFunc, AllocSubroutines, SubroutineFunc, Subroutine,
     FontDataStreamFunc, FontDataStream, KeyPositionFunc, KeyPosition,
	 FontAttributeFunc, FontAttribute);


/*************************************************************************

Function name:  T1FontRelease()

**************************************************************************

Date:           01/14/93 (comments added)
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Release regular structures.
Description:    When a font is no longer needed this routine will release
		a T1FontRec structure and all of it's substructures and arrays.
		It will not release shared structures if they're usage pointers
		indicate that they are still in use.
		It also does not free the encoding vector (which in this
		implementation is always the standard one) or the accent array
		(which is not used).
                
Parameters:     font - the handle to the font to release.
                
Return Values:  none.

See also:       T1FontParse()

**************************************************************************/

void T1FontRelease ARGDECL1(T1FontHandle, font);



#if CID

/*************************************************************************

Function name:  ATMGetCIDFont()

**************************************************************************

Date:           03/05/93
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Create and fill in in a T1FontRec structure for CID fonts.
Description:    This routine reads a font file and parses it, setting up
		the T1FontRec and other important structures and arrays.
		The T1FontRec for CID fonts takes up considerably more
		space than the "Roman" T1FontRec.
                
Parameters:     font - the handle to the font to create
		GetBytesFunc - The call-back that reads in the raw data.
		fontPath - The full name/path for the font file.
                
Return Values:  PE_NOERR if all is OK, PE_CALLER if an error is found.
Notes:   	The T1FontHandle can be moved around but the buffer from
		GetBytesFunc and the first growable buffer cannot.  (The
		low-level parser assumes that these structures are locked
		down).

See also:       T1FontParse(), T1FontRelease()
		Adobe CID-Keyed Font Files Specification

**************************************************************************/

#if HC386
IntX ATMGetCIDFont ARGDECL3(T1FontHandle, font, GetBytesFunc, GetBytes,
                           char *, fontPath);
#else
IntX ATMGetCIDFont ARGDECL3(T1FontHandle, font, GetBytesFunc, GetBytes,
                           Card8 *, fontPath);
#endif


/*************************************************************************

Function name:  ATMGetCMap()

**************************************************************************

Date:           03/05/93
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Read in a CMap or rearranged font for CIDFonts
Description:    This routine reads a CMap file and parses it, setting up
                a mapping for fonts (usually CID fonts).  It also reads
		rearranged fonts since their syntax is basically the
		same as a CMap.

		Rearranged fonts and "used" (included) CMaps are handled
		by the same technic--recursive calls to this routine.
		The decoder requires it's data to be in a certain order
		so at the end of recursion the data must be reordered with
		the latest block of data going to the head of the list
		(and the 2nd latest next, etc.).
 
Parameters:     cMap - the handle to the cMap to create
		GetBytesFunc - The call-back that reads in the raw data.
		cMapPath - The full name/path for the font file.
                
Return Values:  PE_NOERR if all is OK, PE_CALLER if an error is found.
		Note that the errors should parallel those of 
		ATMGetCIDFont(), although 'font' errors may not seem
		appropriate for a CMap.

Notes:   	On DOS/Windows systems it will try to convert any
		PostScript style names to DOS style names.

See also:       ATMGetCIDFont(), FindDOSFontName()
		Adobe CID-Keyed Font Files Specification

**************************************************************************/

#if HC386
IntX ATMGetCMap ARGDECL3(CMapHandle, cMap, GetBytesFunc, GetBytes, 
                           char *, cmapPath);
#else
IntX ATMGetCMap ARGDECL3(CMapHandle, cMap, GetBytesFunc, GetBytes, 
                           Card8 *, cmapPath);
#endif


/*************************************************************************

Function name:  ATMReleaseCMapHandle()

**************************************************************************

Date:           03/08/93 
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Release CMap structure
Description:    
Parameters:     cMap - the handle to the cMap to release.
                
Return Values:  none.

See also:       ATMGetCMap()

**************************************************************************/


void ATMReleaseCMapHandle ARGDECL1(CMapHandle, cMap);


/*************************************************************************

Function name:  ATMVerifyCIDVersion()

**************************************************************************

Date:           06/05/93
Author:         Ron Fischer (rff)
Prototype in:   parseglu.h
Summary:        Checks to make sure the CID and CMAP file version 
		information is compatible.
Description:    If the font is not a CID font returns false immediately.
		If it is, the Registry and Ordering fields are compared.
		If the fields are identical in both the CID font and the
		CMAP font, true is returned, otherwise false is returned.
                
Parameters:     font - the (CID) font to check
		cMap - the cMap to check
                
Return Values:  true if the versions are compatible, false if they are not.
Notes:          
See also:       ATMGetCMap(), ATMGetCIDFont()
		Adobe CID-Keyed Font Files Specification

**************************************************************************/


CardX ATMVerifyCIDVersion ARGDECL2(T1FontHandle, font, CMapHandle, cMap);


/* Charstring decryption routines needed by other functions: */

global void kATM_DecryptCharstring ARGDECL2(Card8 *, Str, CardX *, Len);


global procedure DecryptString ARGDECL3(register Card8 *, s, IntX, lenIV, CardX *, len);

#endif /* #if CID */

#endif /* PARSEGLUE_H */
