/* stream.h - tests the streamer package

              Copyright 1994 -- Adobe Systems, Inc.
            PostScript is a trademark of Adobe Systems, Inc.
NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

Original version: Ron Fischer, Wed May 18th, 1994
*/

#if !defined(_STREAM_H_)
#define _STREAM_H_


#if ISP==isp_sparc
/* The Achilles heel of C--header files suck.  These extremely common */
/* definitions are missing from the gcc header files on the Sparc. */

#define SEEK_SET        0
#define SEEK_END        2

int fseek(FILE *stream, long offset, int mode);
int sscanf(const char *s, const char *format, ...);
#endif


typedef struct
 { Card8 *name[256];
   Fixed designVector[256][2];
   Card8 isLower[256];
   IntX glyphCount;
 } FauxGlyphsStruct;

IntX GetFauxData ARGDECL4(Card8 *, fauxName, FauxInfoPointer, fauxInfo,
         FauxValsPointer *, fauxVals, FauxGlyphsStruct *, fauxGlyphs);

/*************************************************************************

Function name:  ClearFauxData()

**************************************************************************

Date:           05/31/94
Author:         Ron Fischer (rff)
Prototype in:   stream.h
Summary:        Frees the memory used by the faux font structures.
Description:

Parameters:

Return Values:
Notes:
See also:

**************************************************************************/

PUBLIC IntX ClearFauxData ARGDECL2(FauxInfoPointer, fauxInfo,
                                  FauxValsPointer *, fauxVals);

boolean MyRealloc ARGDECL2(void **, hndl, Card32, size);

#endif

