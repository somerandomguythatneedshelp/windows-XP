/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DEVCAPS.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for ...                   */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_DEVMODESEG)

//max length of bin description reported by DC_BINNAMES of DeviceCapabilities()
#define MAX_BINNAME_LEN 24

#define RC_no_match -1
#define RC_no_xlat_data -2

// local functions
DWORD NEAR PASCAL GetDatatypes(LP lpout) ;
LPPOINT NEAR PASCAL GetMaxMinPaperDimensions(LPPDEVICE, int, LPPOINT);
DWORD NEAR PASCAL GetMSDefinedPaperBins(LPPDEVICE lppd, LPWORD lpbinlist, WORD wIndex);

DWORD NEAR PASCAL GetDevicePapers(LPPDEVICE, int, LP);
DWORD FAR PASCAL EnumerateResolutions(LPPDEVICE, LP);
// DWORD NEAR PASCAL EnumerateFileDependencies(LPPDEVICE, LPPSEXTDEVMODE, LPSTR);
DWORD NEAR PASCAL EnumeratePaperNames(LPPDEVICE lpPDevice, LPPSEXTDEVMODE lpDriveState, LPSTR lpOut);
int NEAR PASCAL LandscapeToPortrait(LPPDEVICE lpPDevice);
BOOL   FAR  IsFilePort( LPSTR szPort ) ;

extern WORD FAR PASCAL GetPrivateDocStickySize();  // in devmode.c

typedef struct _tagNAMES
  {
  char names[64];
  }NAMES, *PNAMES,FAR *LPNAMES;


/***************************************************************************
*                       DeviceCapabilities
*  function:
*       this is the DeviceCapabilities external entry point.
*       See the description of "DeviceCapabilities" in the Windows SDK
*       documentation for more information.
*  prototype:
*       DWORD FAR PASCAL DeviceCapabilities(LPSTR lpzFriendly,LPSTR lpzPort,
*                                           WORD wIndex,LP lpOut,
*                                           LPDEVMODE lpDevMode)
*  parameters:
*       LPSTR lpzFriendly -- null terminated string containing the name of
*                          the device (friendly)
*       LPSTR lpzPort -- null terminated string containing the name of the
*                        port.  lpzFriendly and lpzPort together uniquely
*                        identify the device whose capabilities are being
*                        queried.
*       WORD  wIndex -- an index which specifies the particular capability
*                       being queried.
*       LP lpOut -- a pointer to an array of bytes.  The format of the
*                   array depends on the value of wIndex.  If lpOut == NULL,
*                   the return value of DeviceCapabilities is the number
*                   of bytes which would be required for the array pointed
*                   to by lpOut.
*       LPDEVMODE lpDevMode -- points to a Devmode data structure.  If
*                   lpDevMode == NULL, return the current values for the
*                   printer identified by lpzFriendly/lpzPort.  If lpDevmode
*                   != NULL, return the values from the DEVMODE structure
*                   passed in.  If the values requested are not part of
*                   DEVMODE, values for the printer identified by lpzFriendly/
*                   lpzPort will be returned.
*  returns:
*       DWORD -- depends on the setting of wIndex and the other parameters.
****************************************************************************/
DWORD _loadds FAR PASCAL DeviceCapabilities(LPSTR lpzFriendly,LPSTR lpzPort,
                                            WORD wIndex,LP lpOut,
                                            LPDEVMODE lpDevMode)
{
    DWORD dRC = (DWORD) -1L; //fail
    LPPSEXTDEVMODE lpExtDevMode , lpMyDevMode = NULL;
    POINT retpoint;
    LPPDEVICE lppd = NULL;
    LPWPXBLOCKS   lpWPXblock ;
    LPSTR lpzDevice;
    DWORD dwType, dwNeeded;
    char  szDevice[CCHDEVICENAME];
    LPDRIVERINFO  lpDrvInfo;
    LPPRINTERINFO lpPrinterInfo;
    LPSTR lpFileName = NULL;
    BOOL OEMDoneIt;

    switch (wIndex)
    {
        case DC_COPIES:
            return MAX_COPIES;
        case DC_VERSION:
            return GDI_VERSION;
        case DC_DRIVER:
            return DRIVER_VERSION;
        case DC_TRUETYPE:
            return (DCTT_DOWNLOAD | DCTT_SUBDEV);
        case DC_DATATYPE_PRODUCED:
            return   GetDatatypes(lpOut) ;
    }

    // Get printer model name
    lpzDevice = szDevice;
    lpzDevice[0] = '\0';
    if (DrvGetPrinterData(lpzFriendly, (LPSTR)INT_PD_PRINTER_MODEL, &dwType, lpzDevice,
                          CCHDEVICENAME, &dwNeeded) != ERROR_SUCCESS)
    {
        /* Unknown model - use default printer. */
    LoadString(ghDriverMod, IDS_DEFAULTPRINTER, lpzDevice, CCHDEVICENAME);
    }

   lpWPXblock = GetPrinter(lpzDevice) ;
   if(!lpWPXblock)
       goto  terminateDevCaps ;

    lpExtDevMode = lpMyDevMode =
        (LPPSEXTDEVMODE) GlobalAllocPtr(GHND|GMEM_DDESHARE,
                                        dsizeof(PSEXTDEVMODE) );
    if(!lpMyDevMode)
        goto  terminateDevCaps ;

    if (DrvGetPrinterData(lpzFriendly, (LPSTR)INT_PD_DEFAULT_DEVMODE, &dwType,
                          (LPBYTE)lpExtDevMode, sizeof(PSEXTDEVMODE),
                          &dwNeeded) == ERROR_SUCCESS)
    {
        MERGETYPE mergeType;
        if((mergeType = GetMergeType(lpWPXblock,
                                     lpExtDevMode)) != MERGE_FULL)
        {
            PSEXTDEVMODENONFILL dmTemp;

            dmTemp = *(LPPSEXTDEVMODENONFILL)lpExtDevMode;    /* Save the bad cached devmode */

            // For a cached devmode, DOCRESTRICTED is actually
            // CACHEDRESTRICTED.
            if (mergeType == MERGE_DOCRESTRICTED)
                mergeType = MERGE_CACHEDRESTRICTED;
            PsExtDevmodeMerge(lpExtDevMode, (LPPSEXTDEVMODE) &dmTemp,
                              lpzDevice, lpzFriendly, TRUE);
        }
    }
    else
    {
        InitDefaultDevmode( lpWPXblock, lpExtDevMode, lpzFriendly);
        UpdatePublicDevmode(lpWPXblock, lpExtDevMode);
    }

    if(lpDevMode)
    {
        // Merge lpDevMode into it.
        PsExtDevmodeMerge(lpExtDevMode, (LPPSEXTDEVMODE) lpDevMode,
                          lpzDevice, lpzFriendly, FALSE);
    }

    lppd = (LPPDEVICE)GlobalAllocPtr( GHND|GMEM_DDESHARE, dsizeof(PDEVICE));
    if (!lppd)
      goto  terminateDevCaps ;

   // got our dummy pdevice
   lppd->sMagic = LUCAS ;

   lppd->lpPSExtDevmode = lpExtDevMode ;
   lppd->lpWPXblock = lpWPXblock ;
   DrvStateRead(lppd, lpExtDevMode ) ;

   // OEM plugin
   lpPrinterInfo = (LPPRINTERINFO)(lpWPXblock->WPXprinterInfo);
   lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->PCFileName.dword);
   if (lpPrinterInfo->bOEMExist)
   {
      OEMDoneIt = FALSE;
      if (lpDrvInfo=(LPDRIVERINFO)GlobalAllocPtr(GMEM_SHARE|GHND, sizeof(DRIVERINFOT)))
      {
         lpDrvInfo->hOemCust = NULL;
         lpDrvInfo->lpszFriendly = lpzFriendly;
         lpDrvInfo->lpszPort = lpzPort;
         lpDrvInfo->pDev = *lppd;
         lpDrvInfo->lpDM = lppd->lpPSExtDevmode;

         lpDrvInfo->hOemCust = AdobeOEMInitDllStub(lpDrvInfo,lpFileName,
                                             DLL_TYPE_OEM_CUST, DEVICECAP);
         if( lpDrvInfo->hOemCust )
         {
            OEMDoneIt = AdobeOEMDeviceCapabilitiesStub(lpDrvInfo->hOemCust,
                                 lpzFriendly, lpzPort, wIndex, lpOut, &dRC);
            AdobeOEMTermDllStub(lpDrvInfo->hOemCust);
         }
         GlobalFreePtr(lpDrvInfo);
         if( OEMDoneIt )
            goto terminateDevCaps;
         else
            dRC = (DWORD)-1L;
      }
   }

   // switch based on request
   switch (wIndex)
   {
      case DC_BINS:
      case DC_BINNAMES:
         dRC = GetMSDefinedPaperBins(lppd, (LPWORD)lpOut, wIndex);
         break;

      case DC_DUPLEX:
         if (lpExtDevMode->dm.dm.dmDuplex != 0)
               dRC = 1;
         else
               dRC = 0;
         break;

      case DC_ENUMRESOLUTIONS:
         dRC = EnumerateResolutions(lppd, lpOut);
         break;

      case DC_EXTRA:
         dRC = lpExtDevMode->dm.dm.dmDriverExtra;
         break;

      case DC_FIELDS:
         dRC = lpExtDevMode->dm.dm.dmFields;
         break;

//    The subsystem provides a 32 bit entry point. So we shall fail this call.
      case DC_FILEDEPENDENCIES:
//         dRC = EnumerateFileDependencies(lppd,
//                                          lpExtDevMode,lpOut);
         break;

      case DC_MAXEXTENT:
         // search for biggest paper size
         // return point structure
         //  Fix for bug 239808
         //  retpoint = *(POINT FAR *)GetMaxMinPaperDimensions(lppd, 1);
         GetMaxMinPaperDimensions(lppd, 1, (LPPOINT)&retpoint);
         dRC = *(LPDWORD)&retpoint;
         break;

      case DC_MINEXTENT:
         // search for smallest paper size
         // return point structure
         //  Fix for bug 239808
         //  retpoint = *(POINT FAR *)GetMaxMinPaperDimensions(lppd, 2);
         GetMaxMinPaperDimensions(lppd, 2, (LPPOINT)&retpoint);
         dRC = *(LPDWORD)&retpoint;
         break;

      case DC_ORIENTATION:
         dRC = LandscapeToPortrait(lppd);
         break;

      case DC_PAPERS:
      case DC_PAPERSIZE:
      case DC_PAPERNAMES:
         dRC = GetDevicePapers(lppd, wIndex,lpOut);
         break;

      case DC_SIZE:
         dRC = lpExtDevMode->dm.dm.dmSize;
         break;

//*******************************************************
//          Fixed bug 118385
//  03-Aug-1995  -by-  [olegsher]
//  Extra code to support ICM in our driver
// The GDI uses the returning values from DC_ICC_MANUFACTURER and
//  DC_ICC_MODEL to search thru the registry to associate the
//  driver with profile. In order to use different driver name and
//  be fully compatible with the GDI, our driver should implement those
//  functions.

      case DC_ICC_MANUFACTURER:
         {
            LPPRINTERINFO lpPI ;

            lpPI = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo ;
            if (lpPI->ICMManufacturer[0] != '\0')
            {
               MemCopy((LPSTR) &dRC, (LPSTR) &lpPI->ICMManufacturer,
                       ICM_MANUFACTURER_LEN);
            }
            else
            {
               dRC = (DWORD)-1L;
            }
         }
         break;

      case DC_ICC_MODEL:
         {
            LPPRINTERINFO lpPI ;

            lpPI = (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo ;
            if(lpPI->ICMModelName[0] != '\0')
            {
               MemCopy((LPSTR) &dRC, (LPSTR) &lpPI->ICMModelName, ICM_MODEL_NAME_LEN);
            }else
            {
               dRC = (DWORD)-1L;
            }
         }
         break;

      default:
         dRC = (DWORD)-1L;
         break;
   }


terminateDevCaps:
   if(lppd)
        GlobalFreePtr(lppd);
   if(lpMyDevMode)
        GlobalFreePtr(lpMyDevMode);
   if(lpWPXblock)
      FreePrinter(lpWPXblock) ;

    return(dRC);
}

#ifndef MICROSOFT_DRIVER_VERSION
/***************************************************************************
*                       DeviceCapabilitiesEx
*  function:
*       this is the ISV DeviceCapabilities external entry point.
*       this function allows ISV to GET and SET some of the values
*       in the private portion of the DEVMODE and WPX.
*
*  parameters:
*       LPSTR lpzFriendly -- null terminated string containing the name of
*                          the device (friendly)
*       WORD  wCapability -- an index which specifies the particular capability
*                       being queried.
*       LPDEVMODE lpDevMode -- points to a Devmode data structure.  If
*                   lpDevMode == NULL, retrive the current Devmode for the
*                   printer identified by lpzFriendly/lpzPort.
*
*       Other parameters depend on the wCapability.
*       ...
*
*  returns:
*       DWORD -- depends on the setting of wIndex and the other parameters.
****************************************************************************/
DWORD _loadds FAR PASCAL DeviceCapabilitiesEx(LPSTR lpzFriendly,
                                     WORD   wCapability,  LPDEVMODE lpDevMode,
                                     int    iDataItemID,  LPSTR lpString,
                                     BOOL   bFromWPX,     int iIDOption,
                                     WORD * lpSize,       DWORD dwData,
                                     LPSTR  lpModuleName)
{
    DWORD dRC = (DWORD) -1L ; //fail
    LPPSEXTDEVMODE lpExtDevMode = NULL, lpMyDevMode = NULL;
    LPPDEVICE lppd = NULL;
    LPWPXBLOCKS   lpWPXblock ;
    LPSTR lpzDevice;
    DWORD dwType, dwNeeded;
    char  szDevice[CCHDEVICENAME];
    BOOL  bSuccess = FALSE;
    LPWORD  lpCRC_16_tab = (LPWORD) crc_16_tab;


    LPOEMINFO lpOEMInfo;
    HANDLE hContext = NULL;
    lpExtDevMode = NULL;

    // Get printer model name
    lpzDevice = szDevice;
    lpzDevice[0] = '\0';
    if (DrvGetPrinterData(lpzFriendly, (LPSTR)INT_PD_PRINTER_MODEL, &dwType, lpzDevice,
                          CCHDEVICENAME, &dwNeeded) != ERROR_SUCCESS)
    {
        // unknown printer
        goto  terminateDevCaps ;    // error
    }

    lpWPXblock = GetPrinter(lpzDevice) ;
    if(!lpWPXblock)
       goto  terminateDevCaps ;     // error

    lpExtDevMode = lpMyDevMode =
        (LPPSEXTDEVMODE) GlobalAllocPtr(GHND|GMEM_DDESHARE,
                                        dsizeof(PSEXTDEVMODE) );
    if(!lpMyDevMode)
        goto  terminateDevCaps ;  // error

    if (DrvGetPrinterData(lpzFriendly, (LPSTR)INT_PD_DEFAULT_DEVMODE, &dwType,
                          (LPBYTE)lpExtDevMode, sizeof(PSEXTDEVMODE),
                          &dwNeeded) == ERROR_SUCCESS)
    {
        MERGETYPE mergeType;
        if((mergeType = GetMergeType(lpWPXblock,
                                     lpExtDevMode)) != MERGE_FULL)
        {
            PSEXTDEVMODE dmTemp;

            dmTemp = *lpExtDevMode;    /* Save the bad cached devmode */

            // For a cached devmode, DOCRESTRICTED is actually
            // CACHEDRESTRICTED.
            if (mergeType == MERGE_DOCRESTRICTED)
                mergeType = MERGE_CACHEDRESTRICTED;
            PsExtDevmodeMerge(lpExtDevMode, (LPPSEXTDEVMODE) &dmTemp,
                              lpzDevice, lpzFriendly, TRUE);
        }
    }
    else
    {
        InitDefaultDevmode( lpWPXblock, lpExtDevMode, lpzFriendly);
        UpdatePublicDevmode(lpWPXblock, lpExtDevMode);
    }

    if(lpDevMode)
    {
        // Merge lpDevMode into it.
        PsExtDevmodeMerge(lpExtDevMode, (LPPSEXTDEVMODE) lpDevMode,
                          lpzDevice, lpzFriendly, FALSE);
    }

    lppd = (LPPDEVICE)GlobalAllocPtr( GHND|GMEM_DDESHARE, dsizeof(PDEVICE));
    if (!lppd)
    {
       goto  saveDevCaps ;   // error
    }

   // got our dummy pdevice
    lppd->sMagic = LUCAS ;

    lppd->lpPSExtDevmode = lpExtDevMode ;
    lppd->lpWPXblock = lpWPXblock ;
    DrvStateRead(lppd, lpExtDevMode ) ;

    // Create hContext for OEMINFO structure
    hContext = GlobalAlloc(GMEM_DDESHARE|GHND, sizeof(OEMINFO));
    if (hContext)
    {
       lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);
       bSuccess = (lpOEMInfo != NULL);
    }

    if (!bSuccess)
    {
       goto  terminateDevCaps ;   // error
    }

    lpOEMInfo->lpPSExtDevmode = lpExtDevMode;
    lpOEMInfo->lppd = lppd;
    lpOEMInfo->lpDrvInfo = NULL;        // don't need this
    lpOEMInfo->flDllType = DLL_TYPE_APP;

    // switch based on request
    switch (wCapability)
    {
       case DCEX_GETDWORD:
          dRC = DRVGetDWord(hContext, iDataItemID, bFromWPX);
          break;

       case DCEX_GETKEYWORDID:
          dRC = DRVGetKeywordID(hContext, lpString);
          break;

       case DCEX_GETKEYWORDNUMOPTIONS:
          dRC = DRVGetKeywordNumOptions(hContext, iDataItemID);
          break;

       case DCEX_GETKEYWORDOPTIONDWORD:
          dRC = DRVGetKeywordOptionDWord(hContext, iDataItemID, iIDOption, bFromWPX);
          break;

       case DCEX_GETKEYWORDOPTIONPS:
          dRC = DRVGetKeywordOptionPS(hContext, iDataItemID, iIDOption,
                                       lpString, lpSize);
          break;

       case DCEX_GETKEYWORDOPTIONSTRING:
          dRC = DRVGetKeywordOptionString(hContext, iDataItemID, iIDOption,
                                           lpString, lpSize);
          break;

       case DCEX_GETKEYWORDOPTIONTRANSLATION:
          dRC = DRVGetKeywordOptionTranslation(hContext, iDataItemID,
                                                iIDOption, lpString, lpSize);
          break;

       case DCEX_GETKEYWORDSTRING:
          dRC = DRVGetKeywordString(hContext, iDataItemID, lpString, lpSize);
          break;

       case DCEX_GETKEYWORDTRANSLATION:
          dRC = DRVGetKeywordTranslation(hContext, iDataItemID, lpString, lpSize);
          break;

       case DCEX_GETSTRING:
          dRC = DRVGetString(hContext, iDataItemID, lpString, lpSize, bFromWPX);
          break;

       case DCEX_ISKEYWORDOPTIONCONSTRAINED:
          dRC = DRVIsKeywordOptionConstrained(hContext, iDataItemID, iIDOption);
          break;

       case DCEX_SETDWORD:
          dRC = DRVSetDWord(hContext, iDataItemID, dwData);
          if(dRC)
          {
             lpExtDevMode->dm.check1 = CalcCRC((LPSTR)&lpExtDevMode->dm.dwTimeStamp, GetPrivateDocStickySize() -
                              2*sizeof(WORD), 0xffff, lpCRC_16_tab);
             lpExtDevMode->dm.check2 = CalcCRC((LPSTR)&lpExtDevMode->dm.dwTimeStamp, sizeof(PSEXTDEVMODE) -
                              sizeof(DEVMODE) - 2*sizeof(WORD), 0xffff,
                              lpCRC_16_tab);
          }
          break;

#ifdef Adobe_Driver
       case DCEX_SETFILTER:
            // store the lpModuleName in DevMode
             // if lpModuleName is NULL, remove it

          if (lpModuleName == NULL)
             lpExtDevMode->dm.appModulename[0]= '\0';
          else
             lstrcpy(lpExtDevMode->dm.appModulename, lpModuleName);

          lpExtDevMode->dm.check1 = CalcCRC((LPSTR)&lpExtDevMode->dm.dwTimeStamp, GetPrivateDocStickySize() -
                             2*sizeof(WORD), 0xffff, lpCRC_16_tab);
          lpExtDevMode->dm.check2 = CalcCRC((LPSTR)&lpExtDevMode->dm.dwTimeStamp, sizeof(PSEXTDEVMODE) -
                             sizeof(DEVMODE) - 2*sizeof(WORD), 0xffff,
                             lpCRC_16_tab);
             dRC = 1;
          break;
#endif
       case DCEX_SETSTRING:
          dRC = DRVSetString(hContext, iDataItemID, lpString, *lpSize);
          if(dRC)
          {
             lpExtDevMode->dm.check1 = CalcCRC((LPSTR)&lpExtDevMode->dm.dwTimeStamp, GetPrivateDocStickySize() -
                              2*sizeof(WORD), 0xffff, lpCRC_16_tab);
             lpExtDevMode->dm.check2 = CalcCRC((LPSTR)&lpExtDevMode->dm.dwTimeStamp, sizeof(PSEXTDEVMODE) -
                              sizeof(DEVMODE) - 2*sizeof(WORD), 0xffff,
                              lpCRC_16_tab);
          }
          break;
       default:
          break;

    }


saveDevCaps:
   if(lpDevMode && lpExtDevMode)
   {
      _fmemcpy((LPPSEXTDEVMODE)lpDevMode, lpExtDevMode, sizeof(PSDEVMODE));
   }
terminateDevCaps:

   if(lppd)
        GlobalFreePtr(lppd);
   if(lpMyDevMode)
        GlobalFreePtr(lpMyDevMode);
   if(lpWPXblock)
      FreePrinter(lpWPXblock) ;

   if(hContext)
   {
      GlobalUnlock(hContext);
      GlobalFree  (hContext);
   }
   return(dRC);
}
#endif

/***************************************************************************
*                       GetDevicePapers
*  function:
*       this function returns the number of paper sizes and optionally a
*       list of these paper sizes.  Based on the "index" parameter, these
*       paper sizes may either be all of the paper sizes supported by the
*       printer or only the MS defined paper sizes (those which appear in
*       the DMPAPER list).
*  NOTE: (1/29/93)Functionality revised a bit, per Microsoft's ONLINE clarification.
*       ALL paper sizes and names are returned, and no distinction is
*       made between MS defined or custom non-standard papers. It is up
*       to the caller to distiguish between the two. After all the caller
*       does know what the standard MS defined papers are.
*
*  prototype:
*       DWORD NEAR PASCAL GetDevicePapers(LPPDEVICE lppd,
*                                         int index, LP lpout);
*  parameters:
*       LPPDEVICE lppd -- pdevice ptr
*       LPPSEXTDEVMODE LPPSEXTDEVMODE -- pointer to the drvstate struct.
*       int index -- DC_PAPERS => MS defined paper sizes, DC_PAPERSIZE =>
*                               all papers supported
*       LP lpout -- pointer to receive the list of papers -- either a
*                   vector of DMPAPER_...s if index = DC_PAPERS or a
*                   vector of POINT structures containing paper dimensions
*                   in tenths of a millimeter.
*  returns:
*       DWORD - number of paper sizes supported
***************************************************************************/

DWORD NEAR PASCAL GetDevicePapers(LPPDEVICE lppd, int index,LP lpout)
{
    LPPOINT lppoint=NULL;
    LPWORD  lpword=NULL;
    LPSTR   lpnames=NULL;
    char    tmpstring[64];
    int     rc ;
    WORD    numPapers, dex ;
    LPPRINTERINFO lpPrinterInfo ;
    LPMAINKEYHDR  lpCurMainKeyHdr ;
    LPBYTE        lpOptionsBlock;
    LPPAPERINFO   lpPaperInfo ;
    LPWPXBLOCKS   lpWPXblock ;
    LPPSDEVMODE   dm1;
    int  i = 0;

    lpWPXblock = lppd->lpWPXblock  ;
    dm1 = &lppd->lpPSExtDevmode->dm ;

    lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;
    lpOptionsBlock = lpWPXblock->WPXarrays ;
    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;

    lpPaperInfo = (LPPAPERINFO)MAKELONG(
        lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );

    // Find out how many paper sizes are supported by the current printer.

    rc = KeywordGetNumOfOptions(lppd, IND_PAPERINFO, &numPapers);

    if (lpPrinterInfo->devcaps.CustomPageSize != 0xFFFF)
    {
        numPapers += 3; // return all three of the custom paper sizes + DMPAPER_USER
    }

    if (dm1->currentCustPaper == APP_DEFINED)
    {
        numPapers++; // include custom other (app defined) paper
    }

    if(!lpout)
        return(numPapers);


    // init the correct list pointer
    if (index == DC_PAPERS)
        lpword = (LPWORD)lpout;
    else if (index == DC_PAPERSIZE)
        lppoint = (LPPOINT)lpout;
    else if (index == DC_PAPERNAMES)
        lpnames = (char FAR *)lpout;

    // create the appropriate list of papers based on index
    // when dex==numPapers-1, return info of DMPAPER_USER
    for (dex = 0; dex < numPapers; dex++)
    {
        // obtain paperID here.
        if (lpword)  //  DC_PAPERS
        {
            if (dex >= lpPrinterInfo->devcaps.CustomPageSize)
            {
                if (dex == numPapers-1)
                    *lpword = DMPAPER_USER;
                else
                    *lpword = lpPaperInfo[lpPrinterInfo->devcaps.CustomPageSize].paperID + i;
                i++;
            }
            else
            {
                *lpword = lpPaperInfo[dex].paperID ;
            }
            lpword ++;
        }
        else if(lpnames)  //  DC_PAPERNAMES
        {
            if (dex >= lpPrinterInfo->devcaps.CustomPageSize)
            {
                if (i < APP_DEFINED)
                {
                    lstrcpy(lpnames, dm1->custPaper[i++].CustomName);
                }
                else
                {
                    // App defined custom paper.
                    LoadDrvrString(ghDriverMod, IDS_CUSTOM_OTHER_PAPER, tmpstring,
                                   sizeof(tmpstring));
                    lstrcpy(lpnames, tmpstring);
                }
            }
            else
            {
                KeywordGetOptionTranslation( lppd,  IND_PAPERINFO, dex,
                                                lpnames, CCHPAPERNAME) ;
            }
            lpnames += CCHPAPERNAME ;
        }
        else if (lppoint)   //  DC_PAPERSIZE
        {
            if (dex >= lpPrinterInfo->devcaps.CustomPageSize)
            {
                WORD x, y;

                if (dex == numPapers-1)
                {   // return the dimension of the default paper.
                    x = lpPaperInfo[lpCurMainKeyHdr->DefaultOptionIndex].width;
                    y = lpPaperInfo[lpCurMainKeyHdr->DefaultOptionIndex].length;
                }
                else if (i < APP_DEFINED)
                {
                    x = (WORD)dm1->custPaper[i].customWidth;
                    y = (WORD)dm1->custPaper[i++].customHeight;
                }
                else
                {
                    // App defined custom paper.
                    x = (WORD)dm1->appCustWidth;
                    y = (WORD)dm1->appCustHeight;
                }
                lppoint->x = MulDiv(x, 254, 72);
                lppoint->y = MulDiv(y, 254, 72);
            }
            else
            {
                lppoint->x = MulDiv(lpPaperInfo[dex].width, 254, 72);
                lppoint->y = MulDiv(lpPaperInfo[dex].length, 254, 72);
            }
            lppoint++ ;
        }
    }

    return((DWORD)numPapers);
}


/***************************************************************************
*                       GetMaxMinPaperDimensions
*  function:
*       this function returns a point structure which contains the
*       maximum or minimum height and width of the paper dimensions.
*       maximum or minimum is controlled by the "maxmin" parameter.
*  prototype:
*       POINT NEAR PASCAL GetMaxMinPaperDimensions(LPPSEXTDEVMODE LPPSEXTDEVMODE,
*                                                  int maxmin);
*  parameters:
*       LPPSEXTDEVMODE LPPSEXTDEVMODE -- pointer to the drvstate struct.
*       int maxmin -- 1 => maximum, 2 => minimum
*  returns:
*       POINT - smallest or largest x and y dimensions
***************************************************************************/

LPPOINT NEAR PASCAL GetMaxMinPaperDimensions(LPPDEVICE lppd,int maxmin,LPPOINT lpOutpoint)
{
   POINT outpoint;
   WORD   numPapers, dex ;
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   LPBYTE      lpOptionsBlock;
   LPPAPERINFO  lpPaperInfo ;
   LPWPXBLOCKS   lpWPXblock ;


   lpWPXblock = lppd->lpWPXblock  ;

   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;
   lpOptionsBlock = lpWPXblock->WPXarrays ;
   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;

   lpPaperInfo = (LPPAPERINFO)MAKELONG(
      lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );


   if (lpPrinterInfo->devcaps.CustomPageSize != 0xFFFF)
   {
      //  the min / max custompaper info params gives this info directly
      LPPARAM  widthParam, heightParam ;

      widthParam = &lpPrinterInfo->custpageinfo.width ;
      heightParam = &lpPrinterInfo->custpageinfo.height ;

      if (maxmin == 1)       // look for maximum
      {
         outpoint.x = MulDiv(widthParam->max, 254, 72);
         outpoint.y = MulDiv(heightParam->max, 254, 72);
      }
      else                   // look for minimum
      {
         outpoint.x = MulDiv(widthParam->min, 254, 72);
         outpoint.y = MulDiv(heightParam->min, 254, 72);
      }
      // Fix for bug 239808
      // return((LPPOINT)&outpoint);
      *lpOutpoint = outpoint;
      return( lpOutpoint );
   }

   //  else we must enum all paper sizes looking for the largest or smallest
   //  dimensions

   // init with first paper dim

   outpoint.x = lpPaperInfo[0].width;
   outpoint.y = lpPaperInfo[0].length;

   KeywordGetNumOfOptions(lppd, IND_PAPERINFO, &numPapers);

   for(dex = 1 ; dex < numPapers ; dex++)
   {
      //  do everything in Points convert to 10ths of MM later.

      if (maxmin == 1)   // look for maximum
      {
         if((WORD)outpoint.x < lpPaperInfo[dex].width)
            outpoint.x = lpPaperInfo[dex].width ;
         if((WORD)outpoint.y < lpPaperInfo[dex].length)
            outpoint.y = lpPaperInfo[dex].length;
      }
      else                   // look for minimum
      {
         if((WORD)outpoint.x > lpPaperInfo[dex].width)
            outpoint.x = lpPaperInfo[dex].width ;
         if((WORD)outpoint.y > lpPaperInfo[dex].length)
            outpoint.y = lpPaperInfo[dex].length;
      }
   }

   outpoint.x = MulDiv(outpoint.x, 254, 72);
   outpoint.y = MulDiv(outpoint.y, 254, 72);

   // Fix for bug 239808
   // return((LPPOINT)&outpoint);
   *lpOutpoint = outpoint;
   return( lpOutpoint );
}

/***********************************************************************
*                       GetMSDefinedPaperBins
*  function:
*    If wIndex is DC_BINS:
*       returns the number of all paper bins supported by the
*       printer indicated in drvstate and, optionally, a WORD array
*       containing a list of the supported bin numbers.
*    If wIndex is DC_BINNAMES:
*       bin names of all supported bins
*
*  prototype:
*       DWORD NEAR PASCAL GetMSDefinedPaperBins(LPPDEVICE lppd,
*                    LPPSEXTDEVMODE LPPSEXTDEVMODE, LPWORD lpbinlist, WORD wIndex);
*  parameters:
*       LPPDEVICE lppd -- pdevice ptr
*       LPPSEXTDEVMODE LPPSEXTDEVMODE -- pointer to the drvstate struct.
*       LPWORD lpbinlist -- pointer to the array to receive the list
*                           of bins (DM_BIN...).  If NULL, list not
*                           generated.
*  returns:
*       DWORD -- number of all bins supported
**********************************************************************/

DWORD NEAR PASCAL GetMSDefinedPaperBins(LPPDEVICE lppd,
LPWORD lpbinlist, WORD wIndex)
{
   WORD   numBins, i, rc;
   LPWORD   binIDarray ;
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   LPBYTE      lpOptionsBlock, bin_desc;
   LPINPUTSLOTINFO  lpSlotInfo ;
   LPWPXBLOCKS   lpWPXblock ;

   // get the number of bins supported -- total

   rc = KeywordGetNumOfOptions(lppd, IND_INPUTSLOTINFO , &numBins);

   if(!lpbinlist)
      return(numBins);

   lpWPXblock = lppd->lpWPXblock  ;
   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;
   lpOptionsBlock = lpWPXblock->WPXarrays ;
   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;

   lpSlotInfo = (LPINPUTSLOTINFO)MAKELONG(
      lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );

   if (wIndex == DC_BINS)
      binIDarray = (LPWORD)lpbinlist;
   else if (wIndex == DC_BINNAMES)
      bin_desc = (LPSTR)lpbinlist;

   // check for supported bins and construct the list of paper bins.

   for (i = 0; i < numBins; i ++)
   {
      if (wIndex == DC_BINS)
      {
         *binIDarray = lpSlotInfo[i].slotID ;
         binIDarray ++;
      }
      else if (wIndex == DC_BINNAMES)
      {
         KeywordGetOptionTranslation( lppd,  IND_INPUTSLOTINFO, i,
                                      bin_desc, MAX_BINNAME_LEN) ;
         bin_desc += MAX_BINNAME_LEN ;
      }
   }        // for(..)

   return((DWORD)numBins);
}

/*
*****************************************************************************
** ENUMERATERESOLUTIONS
**    Returns list of available resolutions.
**
*****************************************************************************
*/
DWORD FAR PASCAL EnumerateResolutions(LPPDEVICE lppd, LP lpOut)
{
   int rc, i, totalnumresolutions;
   LPLONG lpResolutions = NULL;
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   LPBYTE      lpOptionsBlock;
   LPRESOLUTIONINFO  lpResInfo ;
   LPWPXBLOCKS   lpWPXblock ;


   // get total number of resolutions supported by the printer
   rc = KeywordGetNumOfOptions(lppd, IND_RESOLUTIONINFO,
                                     &totalnumresolutions);

   if (rc == FALSE)     // check if *JCLResolution keyword is present
      return((DWORD)-1);  // just fail out for now.

   if(!lpOut)
      return(totalnumresolutions);

   lpResolutions = (LPLONG)lpOut;


   lpWPXblock = lppd->lpWPXblock  ;

   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;
   lpOptionsBlock = lpWPXblock->WPXarrays ;
   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_RESOLUTIONINFO ;

   lpResInfo = (LPRESOLUTIONINFO)MAKELONG(
      lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );

   for (i = 0; i < totalnumresolutions; i++)
   {
      lpResolutions[ i * 2] =
         (LONG)lpResInfo[i].res.word.x ;
      lpResolutions[ i * 2 + 1] =
         (LONG)lpResInfo[i].res.word.y ;

//   may want to filter out resolutions that are currently constrained
   }

   return (DWORD)totalnumresolutions;
}


#if 0
/*
*****************************************************************************
** ENUMERATEFILEDEPENDENCIES
**    Returns number and names of files loaded with the driver.
**
*****************************************************************************
*/
DWORD NEAR PASCAL EnumerateFileDependencies(LPPDEVICE lppd, LPPSEXTDEVMODE lpExtDevMode,LPSTR lpOut)
{
   int i,resc_id;
   char tmpstring[MAX_OPTION_LEN];
   LPNAMES lpNames;

   if(lpOut)
      lpNames = (LPNAMES)lpOut;

   resc_id = ID_STR_FILE_DEP_FIRST;

   for(i=0;i < FILE_DEP_COUNT;i++,resc_id++)
   {
      tmpstring[0] = '\0';
      LoadDrvrString(ghDriverMod, resc_id,tmpstring, MAX_OPTION_LEN);
      if(lpOut)
         lstrcpy((LPSTR)&(*lpNames++),(LPSTR)tmpstring);
   }
   return i;
}
#endif

/*
*****************************************************************************
** LandscapeToPortrait()
**    Returns relation between landscape and portrait in # of degrees
**    counterclockwise from portrait
*****************************************************************************
*/
int NEAR PASCAL LandscapeToPortrait(LPPDEVICE lppd)
{

//      GetCurrPPDOptVal(lppd,lpExtDevMode, ID_PPDSTR_KEY_LANDSCAPEORIENT,
//                        ID_PPDSTR_BASE_LANDSCAPEORIENT, DMORIENT_ANGLE_FIRST,
//                        DMORIENT_ANGLE_LAST);

   if(((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->devcaps.landscapeOrientPlus90 )
      return 90;
   else
      return 270;
}


/***************************************************************************
*                       GetDatatypes
*  function:
*       this function returns the number of output data formats and optionally a
*       list of these output formats.
*
*  prototype:
*       DWORD NEAR PASCAL GetDatatypes(LP lpout);

*  parameters:
*       LPPDEVICE lppd -- pdevice ptr
*       LP lpout -- pointer to receive the list of output formats --
*           app must provide a buffer of size CCHPAPERNAME * num_formats
*  returns:
*       DWORD - number of output formats supported
***************************************************************************/

DWORD NEAR PASCAL GetDatatypes(LP lpout)
{
   char FAR *lpnames=NULL;
   int rc ;


   rc = 2 ;  // currently 2 output formats are supported

   if(!lpout)
      return(rc);


   lpnames = (char FAR *)lpout;


   lstrcpy(lpnames, DATATYPE_RAW);
   lpnames += CCHPAPERNAME ;
   lstrcpy(lpnames, DATATYPE_EPS);

   return((DWORD)rc);
}


