/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TTDIALOG.H                                                   */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/

typedef struct
{
   char SectionName[128];
   int iSubsCurPos;
} TTDlgState;

typedef TTDlgState FAR *LPTTDlgState;

void NEAR FONTSDIALOGSEG PASCAL ReadAssignmentFromIni(HWND hDlg, HANDLE);
void NEAR FONTSDIALOGSEG PASCAL WriteAssignmentToIni(HWND hDlg, HANDLE);
int  NEAR FONTSDIALOGSEG PASCAL GetRasterizerType(HANDLE,
                                    LPWPXBLOCKS lpWPXBlock, LPPSEXTDEVMODE lpPSExtDevmode);
void NEAR FONTSDIALOGSEG PASCAL ReplacePSFamily(HWND hDlg, LPSTR, LPSTR);
void NEAR FONTSDIALOGSEG PASCAL AddPSFamily(HWND hDlg, LPSTR lpPSFamily);
void NEAR FONTSDIALOGSEG PASCAL AddTTFamily(HWND hDlg, LPSTR lpTTFamily);
void NEAR FONTSDIALOGSEG PASCAL FillPSComboBox(HWND hDlg, int iCtrlID);
BOOL NEAR FONTSDIALOGSEG PASCAL FillSubsList(HWND hDlg, int active_TT_index, 
                                         BOOL bUpdateAll);
void NEAR FONTSDIALOGSEG PASCAL WriteStateToWinIni(HWND hDlg, LPPDEVICE lpPDevice);
void NEAR FONTSDIALOGSEG PASCAL SetAssignment(HWND hDlg, int iTTFamily, int iPSTarget);
void NEAR FONTSDIALOGSEG PASCAL SetDefaultAssignments(HWND hDlg, HANDLE);
void NEAR FONTSDIALOGSEG PASCAL GetAllFamilies(HWND hDlg, WORD enumFlag);
int  NEAR FONTSDIALOGSEG PASCAL FindFontFamily(HGLOBAL hFamilies, int iNumFamilies, LPSTR lpTarget);

BOOL NEAR FONTSDIALOGSEG PASCAL CheckAssignment(HWND hDlg, int iTTFamily, int iPSTarget, LPSTR lpTTName, LPSTR lpPSName);

void FAR  PASCAL InitializeTTSubsTable(HANDLE ghDriverMod);

