/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ICM.C                                                        */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "icmstr.h"

#pragma code_seg(_ICM2SEG)

extern BOOL bATMWorkAround;

char        CSAName[]     = "/AdobePS4CSA ";
static char ControlD[] = "\004";
static char F709[] = "{ dup 0.018 lt {4.5 mul} \
{0.45 exp 1.099 mul 0.099 sub} ifelse } bind  ";
static char WBPoints[] = "/WhitePoint [0.9642 1 0.8249] /BlackPoint [0 0 0] ";
static char TransformPRQ[] = "/RangePQR [0 1 0 1 0 1] \
/TransformPQR [ {} bind dup dup ] ";
static char BeginRT[] = "/RenderTable [ ";

static char MatrixABC[] = " ";
static char RangeABC[] = "/RangeABC [0 1 0 1 0 1] ";
static char EncodeABC[] = " ";

static char RangeLMN[] = "/RangeLMN [0 1 0 1 0 1]";
static char EncodeLMN[] = "/EncodeLMN [{ dup 0.0 le {pop 0.0}{0.5556 exp}ifelse} bind dup dup] ";

double SonyTrinitron[9] = {
    0.4439, 0.2522, 0.0436,
    0.3341, 0.6371, 0.1387,
0.1725, 0.1107, 0.9067};

static char ColorSpace1[] = "/CIEBasedABC << /DecodeLMN ";
static char ColorSpace3[] = " exp} bind ";
// ALWAYS_ICM
// static char ColorSpace5[] = "/WhitePoint [0.9642 1 0.8249] ";
static char DefCS[] = "exch /ColorSpace defineresource pop ";
static char FindCS[] = "/ColorSpace findresource";
static char SetCS[] = "dup setcolorspace /colspABC exch def ";
static char DefineCRD[] = "definecolorrendering ";
static char SelectCRD[] = "selectcolorrendering ";

#define WriteObject(hF,Obj) _lwrite(hF, (LPSTR) Obj, lstrlen((LPSTR) Obj) )
#define SendObject(lpp,Obj) PortWrite(lpp, (LPSTR) Obj, lstrlen((LPSTR) Obj) )

#define HTOPTR(s,o) (LPVOID) ( ((DWORD)((WORD)(o))) |       \
                               (((DWORD)((WORD)(s))) << 16) )

#define     BUFSIZE     2048

DWORD NEAR PASCAL WriteHexBuffer_f (HFILE hFile, LPSTR lpBuff, DWORD dwBytes);
DWORD NEAR PASCAL WriteInt_f (HFILE hFile, WORD wInt);
DWORD NEAR PASCAL WriteFloat_f (HFILE hFile, double dFloat);
DWORD NEAR PASCAL WriteABCandLMN_f (HFILE hFile);

void NEAR PASCAL ApplyInv709 (LPSTR lpBuff, DWORD nBytes);
void NEAR PASCAL PSSendInt (LPPDEVICE lppd, WORD wInt);
void NEAR PASCAL PSSendFloat (LPPDEVICE lppd, double dFloat);
void NEAR PASCAL PSSendFile (LPPDEVICE lppd, LPSTR lpszFile);

// ALWAYS_ICM
DWORD _loadds FAR PASCAL DeviceCapabilities(LPSTR lpzFriendly,LPSTR lpzPort,
                                            WORD wIndex,LP lpOut,
                                            LPDEVMODE lpDevMode);
BOOL ProfileSelection(LPPDEVICE lppd, LPSTR lpProfileName);

//ALWAYS_ICM
static  char   *MediaType[]     = {"Standard", "Glossy", "Transparency"};
static  char   *DitherType[]    = {"None", "Coarse", "Fine", "LineArt", "CrayScale"};
static  char   DefaultProfile[] = "default";
static  char   Profile00[]      = "profile00";

double dMatrixIn[9];
double dMatrixOut[9];

double dRowIn[9];
double dRowOut[9];


BOOL EXTERN 
InvertMatrix (double FAR * lpInMatrix,
              double FAR * lpOutMatrix)
{
    double det;

    double FAR *a;
    double FAR *b;
    double FAR *c;
    if ((NULL == lpInMatrix) ||
        (NULL == lpOutMatrix))
    {
        return (FALSE);
    }
    a = (double FAR *) &(lpInMatrix[0]);
    b = (double FAR *) &(lpInMatrix[3]);
    c = (double FAR *) &(lpInMatrix[6]);

    det = a[0] * b[1] * c[2] + a[1] * b[2] * c[0] + a[2] * b[0] * c[1] -
        (a[2] * b[1] * c[0] + a[1] * b[0] * c[2] + a[0] * b[2] * c[1]);

    if (det == 0.0)                     // What to do?
    {
        lpOutMatrix[0] = 1.0;
        lpOutMatrix[1] = 0.0;
        lpOutMatrix[2] = 0.0;

        lpOutMatrix[3] = 0.0;
        lpOutMatrix[4] = 1.0;
        lpOutMatrix[5] = 0.0;

        lpOutMatrix[6] = 0.0;
        lpOutMatrix[7] = 0.0;
        lpOutMatrix[8] = 1.0;
        return (FALSE);
    } else
    {
        lpOutMatrix[0] = (b[1] * c[2] - b[2] * c[1]) / det;
        lpOutMatrix[3] = -(b[0] * c[2] - b[2] * c[0]) / det;
        lpOutMatrix[6] = (b[0] * c[1] - b[1] * c[0]) / det;

        lpOutMatrix[1] = -(a[1] * c[2] - a[2] * c[1]) / det;
        lpOutMatrix[4] = (a[0] * c[2] - a[2] * c[0]) / det;
        lpOutMatrix[7] = -(a[0] * c[1] - a[1] * c[0]) / det;

        lpOutMatrix[2] = (a[1] * b[2] - a[2] * b[1]) / det;
        lpOutMatrix[5] = -(a[0] * b[2] - a[2] * b[0]) / det;
        lpOutMatrix[8] = (a[0] * b[1] - a[1] * b[0]) / det;
        return (TRUE);
    }
}

BOOL NEAR PASCAL 
MultMatrix (double FAR * lpInMatrix, double FAR * lpInRow,
            double FAR * lpOutRow)
{
    double FAR *a;
    double FAR *b;
    double FAR *c;

    double A;
    double B;
    double C;
    if ((NULL == lpInMatrix) ||
        (NULL == lpInRow) ||
        (NULL == lpOutRow))
    {
        return (FALSE);
    }
    A = lpInRow[0];
    B = lpInRow[1];
    C = lpInRow[2];

    a = (double FAR *) &(lpInMatrix[0]);
    b = (double FAR *) &(lpInMatrix[3]);
    c = (double FAR *) &(lpInMatrix[6]);

    lpOutRow[0] = A * a[0] + B * b[0] + C * c[0];
    lpOutRow[1] = A * a[1] + B * b[1] + C * c[1];
    lpOutRow[2] = A * a[2] + B * b[2] + C * c[2];

    return (TRUE);
}



/***************************************************************************
*                               CreateCRD
*  function:
*       this is the functions which creates the Color Rendering Dictionary (CRD)
*       by sampling the supplied ICM.DLL.
*  prototype:
*       HANDLE FAR PASCAL CreateCRD(
*                      LPICMINFO    lpICM,
*                      LPSTR           lpFName,
*                      DWORD           cCRD,
*                      WORD            nSamples,
*                      BOOL            AllowBinary,
*                      LPDWORD         lpdwSize)
*  parameters:
*       lpICM       --  Pointer to ICM INFO block
*       lpFName     --  Name of the output file
*       cCRD        --  Desired Intent
*       nSamples    --  Number of samples along R, G and B,
*                           totalling n*n*n samples in 3-D space
*       AllowBinary --  1: Binary CRD allowed, 0: Only Ascii CRD allowed
*       lpdwSize    --  Pointer to the variable that receives the file size
*  returns:
*       hFile       --  handle to the open file that has the created
*                           CRD ready to be sent down to the PS printer
***************************************************************************/

HANDLE FAR PASCAL 
CreateCRD (LPICMINFO lpICM,
           LPSTR lpFName,
           DWORD cCRD,
           WORD nSamples,
           BOOL AllowBinary,
           LPDWORD lpdwSize)
{
    HFILE hFile;                        // Handle to the open file which
 // has generated PostScript
    OFSTRUCT FStr;                      // Structure that keeps info on file

    BYTE bRed;                          // ---------------------
    BYTE bGreen;                        // Byte-components of RGB triplet
    BYTE bBlue;                         // ---------------------

    BYTE _huge *lpBuff = NULL;          // Handle and pointer to the memory
                                        // buffer

    LPSTR lpTable;                      // Working pointer to the RGBs table

    WORD i, j, k;
    DWORD dwSize;
    DWORD dwicIntent;
    CHANDLE cp, cp1;
    HGLOBAL hcpMem, hcpMem1;
    BOOL   bSuccess = FALSE;

    if (NULL == lpICM)
    {
        return ((HANDLE)HFILE_ERROR);
    }

    hFile = OpenFile (lpFName, (OFSTRUCT FAR *) & FStr,
                      OF_CREATE | OF_WRITE);
    if (hFile == HFILE_ERROR)
    {
        return (hFile);
    }

    switch (cCRD)
    {
        case LCS_GM_IMAGES:
            dwicIntent = icPerceptual;
            break;
        case LCS_GM_BUSINESS:
            dwicIntent = icSaturation;
            break;
        case LCS_GM_GRAPHICS:
            dwicIntent = icRelativeColorimetric;
            break;
        default:
            dwicIntent = icAbsoluteColorimetric;
            break;
    }

    hcpMem = hcpMem1 = 0;

    // Load device icc profile
    if (lpICM->lcsDestFilename[0] &&
        (LoadCP (lpICM->lcsDestFilename, (HGLOBAL FAR *) &hcpMem,
                 (LPCHANDLE) & cp) == FALSE))
    {
        hcpMem = 0;
    }

    // Load target icc profile
    if (hcpMem &&
        lpICM->lcsTargetFilename[0] &&
        (LoadCP (lpICM->lcsTargetFilename, (HGLOBAL FAR *) &hcpMem1,
                 (LPCHANDLE) & cp1) == FALSE))
    {
        hcpMem1 = 0;
    }

    // Try to build a previewing CRD
    if (lpICM->lcsTargetFilename[0] && hcpMem && hcpMem1)
    {
        if (GetPS2PreviewColorRenderingDictionary (cp, cp1, dwicIntent, NULL,
                                         &dwSize, AllowBinary))
        {
            if (NULL != (lpBuff = GlobalAllocPtr(GHND, dwSize)))
            {
                bSuccess = GetPS2PreviewColorRenderingDictionary (cp, cp1,
                                  dwicIntent, lpBuff, &dwSize, AllowBinary);
                if (!bSuccess)
                {
                    GlobalFreePtr(lpBuff);
                }
            }
        }
    }

    // Try to build a normal CRD
    if (!bSuccess && !(lpICM->lcsTargetFilename[0]) && hcpMem)
    {
        if (GetPS2ColorRenderingDictionary (cp, dwicIntent, NULL,
                                         &dwSize, AllowBinary))
        {
            if (NULL != (lpBuff = GlobalAllocPtr(GHND, dwSize)))
            {
                bSuccess = GetPS2ColorRenderingDictionary (cp,
                                  dwicIntent, lpBuff, &dwSize, AllowBinary);
                if (!bSuccess)
                {
                    GlobalFreePtr(lpBuff);
                }
            }
        }
    }

    // Write CRD to file.
    if (bSuccess)
    {
        DWORD lTmp = dwSize;
        while (lTmp > BUFSIZE)
        {
            i = BUFSIZE;
            _lwrite (hFile, lpBuff, i);
            lTmp -= BUFSIZE;
            lpBuff += BUFSIZE;
        }
        if (lTmp > 0L)
        {
            i = (WORD) lTmp;
            _lwrite (hFile, lpBuff, i);
        }
    }

    // Free cp handle.
    if (hcpMem)
        FreeCP (hcpMem);
    if (hcpMem1)
        FreeCP (hcpMem1);

    if (!bSuccess)
    {
        dwSize = 0L;
 // File is successfully open - start to place data in it
        dwSize += WriteObject (hFile, BeginDict);   // Begin dictionary
        dwSize += WriteObject (hFile, DictType);    // Dictionary type
        dwSize += WriteObject (hFile, WBPoints);    // Send down white and
                                                    // black points
        dwSize += WriteABCandLMN_f (hFile); // Fill ABC and LMN for inverse
                                            // source
        dwSize += WriteObject (hFile, TransformPRQ);    // Fill out PRQ stuff -
                                                        // just identity

        dwSize += WriteObject (hFile, BeginRT);
        dwSize += WriteInt_f (hFile, nSamples); // Send down Na
        dwSize += WriteInt_f (hFile, nSamples); // Send down Nb
        dwSize += WriteInt_f (hFile, nSamples); // Send down Nc

        dwSize += WriteObject (hFile, NewLine);
        dwSize += WriteObject (hFile, BeginArray);

        lpBuff = GlobalAllocPtr (GHND, 3L * nSamples * (DWORD) nSamples);
        if (NULL == lpBuff)
        {
            _lclose (hFile);
            return ((HANDLE) HFILE_ERROR);
        }
        for (i = 0; i < nSamples; i++)  // Na strings should be sent
        {
            lpTable = lpBuff;
            bRed = (BYTE) ((i * 255) / (nSamples - 1));
            for (j = 0; j < nSamples; j++)
            {
                bGreen = (BYTE) ((j * 255) / (nSamples - 1));
                for (k = 0; k < nSamples; k++)
                {
                    bBlue = (BYTE) ((k * 255) / (nSamples - 1));
                    *(lpTable++) = bRed;
                    *(lpTable++) = bGreen;
                    *(lpTable++) = bBlue;
                }
                ICMTranslateRGBs (lpICM->hICMT,
                             lpBuff + j * (DWORD) nSamples, CMS_RGBTRIPLETS,
                                  (UINT) nSamples, (UINT) 1, (UINT) 0,
                             lpBuff + j * (DWORD) nSamples, CMS_RGBTRIPLETS,
                                  CMS_FORWARD);
            }
            ApplyInv709 (lpBuff, 3L * nSamples * (DWORD) nSamples); // Treat RGB-triplets
                                                                    // with
    // inverse 709 function

            dwSize += WriteObject (hFile, BeginString);
            dwSize += WriteHexBuffer_f (hFile, lpBuff, 3L * nSamples * (DWORD) nSamples);
            dwSize += WriteObject (hFile, EndString);
            dwSize += WriteObject (hFile, NewLine);
        }
        dwSize += WriteObject (hFile, EndArray);    // End array
        dwSize += WriteInt_f (hFile, 3);// Send down m
        dwSize += WriteObject (hFile, F709);    // The PS to process output
                                                // from CRT
        dwSize += WriteObject (hFile, F709);    // The PS to process output
                                                // from CRT
        dwSize += WriteObject (hFile, F709);    // The PS to process output
                                                // from CRT
        dwSize += WriteObject (hFile, EndArray);    // End array

        dwSize += WriteObject (hFile, EndDict); // End dictionary definition
        bSuccess = TRUE;
    }

    if (lpBuff)
    {
        GlobalFreePtr(lpBuff);
    }

    if (NULL != lpdwSize)
    {
        *lpdwSize = dwSize;
    }
    return (hFile);
}
/***************************************************************************
*
*   Function to write the integer into the file
*
***************************************************************************/

DWORD NEAR PASCAL 
WriteInt_f (HFILE hFile, WORD wInt)
{
    WORD k;
    char buf[8];
    k = wsprintf ((LPSTR) buf, (LPSTR) "%u ", wInt);
    return (_lwrite (hFile, (LPSTR) buf, k));
}
/***************************************************************************
*
*   Function to write the float into the file
*
***************************************************************************/

DWORD NEAR PASCAL 
WriteFloat_f (HFILE hFile, double dFloat)
{
    WORD k;
    char buf[12];

    char cSign;
    double dInt;
    double dFract;
    LONG lFloat;
    lFloat = (LONG) floor (dFloat * 10000.0 + 0.5);

    dFloat = lFloat / 10000.0;

    dInt = floor (fabs (dFloat));
    dFract = fabs (dFloat) - dInt;

    cSign = ' ';
    if (dFloat < 0)
    {
        cSign = '-';
    }
    k = wsprintf ((LPSTR) buf, (LPSTR) "%c%d.%0.4lu ", cSign, (WORD) dInt, (DWORD) (dFract * 10000.0));
    return (_lwrite (hFile, (LPSTR) buf, k));
}


/***************************************************************************
*
*   Function to send the integer into the port
*
***************************************************************************/

void NEAR PASCAL 
SendInt (LPPDEVICE lppd, WORD wInt)
{
    WORD k;
    char buf[8];
    k = wsprintf ((LPSTR) buf, (LPSTR) "%u ", wInt);
    PortWrite (lppd, (LPSTR) buf, k);
}
/***************************************************************************
*
*   Function to send the float into the port
*
***************************************************************************/

void NEAR PASCAL 
SendFloat (LPPDEVICE lppd, double dFloat)
{
    WORD k;
    char buf[12];

    char cSign;
    double dInt;
    double dFract;
    LONG lFloat;
    lFloat = (LONG) floor (dFloat * 10000.0 + 0.5);

    dInt = floor (fabs (dFloat));
    dFract = fabs (dFloat) - dInt;

//  ALWAYS_ICM 
//  cSign = ' ';
    if (dFloat < 0)
    {
        cSign = '-';
        k = wsprintf ((LPSTR) buf, (LPSTR) "%c%d.%0.4lu ", cSign, (WORD) dInt, (DWORD) (dFract * 10000.0));
    }
    else
    {
        k = wsprintf ((LPSTR) buf, (LPSTR) "%d.%0.4lu ", (WORD) dInt, (DWORD) (dFract * 10000.0));
    }
    PortWrite (lppd, (LPSTR) buf, k);
}
/***************************************************************************
*
*   Function to write the buffer as  string of Hex into the file
*
***************************************************************************/

DWORD NEAR PASCAL 
WriteHexBuffer_f (HFILE hFile, LPSTR lpBuff, DWORD dwBytes)
{
    BYTE _huge *hpByte;
    char buf[8];
    WORD k;
    DWORD lSize = 0L;
    hpByte = (BYTE _huge *) lpBuff;

    for (; dwBytes; dwBytes--)
    {
        k = wsprintf ((LPSTR) buf, (LPSTR) " %2.2x", *hpByte);
        lSize += _lwrite (hFile, (LPSTR) buf, k);
        hpByte++;
    }
    return (lSize);
}


/***************************************************************************
*
*   Function to apply inverse CCIR 709 recommendation to the block of
*   bytes
*
***************************************************************************/

void NEAR PASCAL 
ApplyInv709 (LPSTR lpBuff, DWORD dwBytes)
{
    BYTE _huge *hpByte;
    double dResult;
    double dInput;
    hpByte = (BYTE _huge *) lpBuff;
    for (; dwBytes; dwBytes--)
    {
        dInput = (double) *hpByte;
        dResult = (dInput + 25.245) / 280.245;
        dResult = pow (dResult, (1 / 0.45)) * 255;
        *hpByte = (BYTE) dResult;
        hpByte++;
    }
}


/***************************************************************************
*
*   Function to find out the inverse of the supplied Source ColorSpace
*   and to send the PostScript to do this
*
***************************************************************************/

DWORD NEAR PASCAL 
WriteABCandLMN_f (HFILE hFile)
{
// Currently we use Sony Trinitron as the colorspace,
//  so here we send down pre-computed inverse Sony
    double InverseSony[9];

    WORD i;
    DWORD lSize = 0L;

    lSize += WriteObject (hFile, MatrixABC);
    lSize += WriteObject (hFile, EncodeABC);
    lSize += WriteObject (hFile, RangeABC);

    lSize += WriteObject (hFile, RangeLMN);
    lSize += WriteObject (hFile, EncodeLMN);


    InvertMatrix (SonyTrinitron, InverseSony);

    lSize += WriteObject (hFile, MatrixLMNTag);
    lSize += WriteObject (hFile, BeginArray);
    for (i = 0; i < 9; i++)
    {
        lSize += WriteFloat_f (hFile, InverseSony[i]);
    }
    lSize += WriteObject (hFile, EndArray);
    return (lSize);
}
/***************************************************************************
*
***************************************************************************/

DWORD _loadds FAR PASCAL 
CMGetInfo (DWORD dwInfo)
{
    DWORD dwRet;
    switch (dwInfo)
    {
        case CMS_GET_VERSION:
            dwRet = 0x00040000;
            break;

        case CMS_GET_DRIVER_LEVEL:
            dwRet = CMS_LEVEL_2;
            break;

        case CMS_GET_IDENT:
        default:
            dwRet = 0x41444F42;
            break;
    }
    return (dwRet);
}

HCTMTRANSFORM _loadds FAR PASCAL 
CMCreateTransform (LPLOGCOLORSPACE lpCS,
                   LPSTR lpDevCh,
                   LPSTR lpTargetDevCh)
{
    HANDLE hICMI;
    LPICMINFO lpICMI;
    hICMI = GlobalAlloc (GHND | GMEM_DDESHARE, (DWORD) sizeof (ICMINFO));
    if (!hICMI)
        return NULL;

    lpICMI = (LPICMINFO) GlobalLock (hICMI);
    MemCopy ((LPVOID) & (lpICMI->lcsSource), (LPVOID) lpCS,
             (DWORD) sizeof (LOGCOLORSPACE));
    lpICMI->hICMT = ICMCreateTransform (lpCS, lpDevCh, lpTargetDevCh);

 // Check if ICMCreateTransform succeeded.
    if (LOWORD (lpICMI->hICMT) >= 0x0100)
    {
 // Success
        lpICMI->lcsDestFilename[0] = '\0';
        if (NULL != lpDevCh)
        {
            lstrcpy ((LPSTR) & lpICMI->lcsDestFilename, lpDevCh);
        }

        // PROOFING_CRD
        lpICMI->lcsTargetFilename[0] = '\0';
        if (NULL != lpTargetDevCh)
        {
            lstrcpy ((LPSTR) & lpICMI->lcsTargetFilename, lpTargetDevCh);
        }
        lpICMI->lppd = NULL;     // Fix bug 195632.  jjia   2/20/97
        GlobalUnlock (hICMI);
    } else
    {
        HANDLE temp = (HANDLE) lpICMI->hICMT;
 // Clean up
        GlobalUnlock (hICMI);
        GlobalFree (hICMI);

 // Return whatever error code ICMCreateTransform returned
        hICMI = temp;
    }
    return (hICMI);

}

// ALWAYS_ICM
HCTMTRANSFORM _loadds FAR PASCAL 
CreateDefTransform (LPVOID lppd)
{
    HANDLE     hICMI;
    LPICMINFO  lpICMI;
    LPLOGCOLORSPACE lpCS;

    hICMI = GlobalAlloc(GHND | GMEM_DDESHARE |GMEM_ZEROINIT, (DWORD)sizeof(ICMINFO));
    if (!hICMI)
        return NULL;
    lpICMI = (LPICMINFO)GlobalLock(hICMI);
    if (!ProfileSelection((LPPDEVICE)lppd, lpICMI->lcsDestFilename))
    {
        lpICMI->lcsDestFilename[0] = '\0';
        GlobalUnlock(hICMI);
        GlobalFree(hICMI);
        hICMI = NULL;
    }
    else
    {
        lpCS = &(lpICMI->lcsSource);
        lpCS->lcsSignature =  0x50534F43;
        lpCS->lcsVersion   =  0x400;
        lpCS->lcsSize      =  sizeof(LOGCOLORSPACE);
        lpCS->lcsCSType    =  LCS_CALIBRATED_RGB;
        lpCS->lcsGamutMatch=  0;
        // sRGB to XYZ conversion
        lpCS->lcsGammaRed  =  FIXED_16DOT16((float)2.2);
        lpCS->lcsGammaGreen=  FIXED_16DOT16((float)2.2);
        lpCS->lcsGammaBlue =  FIXED_16DOT16((float)2.2);
        lpCS->lcsEndpoints.ciexyzRed.ciexyzX  = FIXED_2DOT30((float)0.4124);
        lpCS->lcsEndpoints.ciexyzRed.ciexyzY  = FIXED_2DOT30((float)0.2126);
        lpCS->lcsEndpoints.ciexyzRed.ciexyzZ  = FIXED_2DOT30((float)0.0193);
        lpCS->lcsEndpoints.ciexyzGreen.ciexyzX= FIXED_2DOT30((float)0.3576);
        lpCS->lcsEndpoints.ciexyzGreen.ciexyzY= FIXED_2DOT30((float)0.7152);
        lpCS->lcsEndpoints.ciexyzGreen.ciexyzZ= FIXED_2DOT30((float)0.1192);
        lpCS->lcsEndpoints.ciexyzBlue.ciexyzX = FIXED_2DOT30((float)0.1805);
        lpCS->lcsEndpoints.ciexyzBlue.ciexyzY = FIXED_2DOT30((float)0.0722);
        lpCS->lcsEndpoints.ciexyzBlue.ciexyzZ = FIXED_2DOT30((float)0.9505);
        lpCS->lcsFilename[0] = '\0';
        GlobalUnlock(hICMI);
    }
    return (hICMI);
}

BOOL _loadds FAR PASCAL 
DeleteDefTransform (HCTMTRANSFORM hTransform)
{
    if (hTransform)
        GlobalFree( (HANDLE) hTransform);
    return TRUE;
}

//!!! due to bitmap buffering there might be an
//!!! outstanding DIB cache with this as a
//!!! needed transform, maintaining and walking
//!!! a pdev chain is a dangerous thing, and
//!!! there's few intelligent completely safe
//!!! ways to delay the delete, but i'm sure
//!!! olegsher will think of something - davidw

BOOL _loadds FAR PASCAL 
CMDeleteTransform (HCTMTRANSFORM hTransform)
{
#if 0
    LPICMINFO   lpICMI;
    BOOL        bRet = FALSE;
    LPPDEVICE   lppd;

    lpICMI  =  (LPICMINFO) GlobalLock( (HANDLE) hTransform);

    // Fix bug 195632. jjia 2/20/97.
    // See above davidw's comment.
    if (lpICMI)
    {
        lppd = (LPPDEVICE)(lpICMI->lppd);
        if (lppd && (lppd->sMagic == LUCAS) &&
            (fEnabledLppd(lppd)) &&
            (lppd->GlobalBuffer.hBitmapBf) &&
            (lppd->GlobalBuffer.lpBitmapBf))
        {
            HandleBufferedBitmap((LP)lppd);
        }

#if 0
        if (LOWORD (lpICMI->hICMT) >= 0x0100)
            bRet = ICMDeleteTransform(lpICMI->hICMT) ;
        else
            bRet = TRUE;
#else
        bRet = TRUE;
#endif

        GlobalUnlock( (HANDLE) hTransform);
        GlobalFree( (HANDLE) hTransform);
    }

    return( bRet );
#else
   return (FALSE);
#endif
}

BOOL _loadds FAR PASCAL 
CMTranslateRGB (HCTMTRANSFORM hTransform, RGBQUAD RGBQuad,
                LPVOID lpResult, DWORD dwFlags)
{
// ALWAYS_ICM
#if 0
    LPICMINFO   lpICMI;
    BOOL        bRet;

    lpICMI  =  (LPICMINFO) GlobalLock( (HANDLE) hTransform);
    bRet = ICMTranslateRGB(lpICMI->hICMT, RGBQuad,
                        lpResult, dwFlags) ;
    GlobalUnlock( (HANDLE) hTransform);
    return( bRet );
#else
    *((RGBQUAD far *) lpResult) = RGBQuad;
    return (1);
#endif

}

BOOL _loadds FAR PASCAL 
CMTranslateRGBs (HCTMTRANSFORM hTransform,
                 LPVOID lpSrc, DWORD dwSrcFlags,
                 DWORD nSrcWidth, DWORD nSrcHeight, DWORD nSrcStride,
                 LPVOID lpDest, DWORD dwDestFlags,
                 DWORD dwFlags)
{
    LPICMINFO lpICMI;
    BOOL bRet;
    lpICMI = (LPICMINFO) GlobalLock ((HANDLE) hTransform);
    bRet = ICMTranslateRGBs (lpICMI->hICMT, lpSrc, dwSrcFlags,
                             nSrcWidth, nSrcHeight, nSrcStride,
                             lpDest, dwDestFlags, dwFlags);
    GlobalUnlock ((HANDLE) hTransform);
    return (bRet);
}

BOOL _loadds FAR PASCAL 
CMCheckColorsInGamut (HCTMTRANSFORM hTransform,
                      LPVOID lpSrc,
                      LPVOID lpDest, DWORD dwCount)
{
    LPICMINFO lpICMI;
    BOOL bRet;
    lpICMI = (LPICMINFO) GlobalLock ((HANDLE) hTransform);
    bRet = ICMCheckColorsInGamut (lpICMI->hICMT, lpSrc,
                                  lpDest, dwCount);
    GlobalUnlock ((HANDLE) hTransform);
    return (bRet);

}

BOOL _loadds FAR PASCAL 
CMGetPS2ColorSpaceArray (
                         LPSTR lpProfileName,
                         DWORD InputIntent,
                         WORD InpDrvClrSp,
                         MEMPTR lpBuffer,
                         LPDWORD lpcbSize,
                         BOOL AllowBinary)
{
    BOOL Ret = FALSE;
    HGLOBAL hcpMem;
    CHANDLE cp;
    Ret = LoadCP (lpProfileName, (HGLOBAL FAR *) &hcpMem, (LPCHANDLE) & cp);

    if (Ret)
    {
        Ret = GetPS2ColorSpaceArray (cp, InputIntent, InpDrvClrSp,
                                     lpBuffer, lpcbSize, AllowBinary);
        FreeCP (hcpMem);
    }
    return (Ret);
}

BOOL _loadds FAR PASCAL 
CMGetPS2ColorRenderingDictionary (
                                  LPSTR lpProfileName,
                                  DWORD Intent,
                                  MEMPTR lpMem,
                                  LPDWORD lpcbSize,
                                  BOOL AllowBinary)
{
    BOOL Ret = FALSE;
    HGLOBAL hcpMem;
    CHANDLE cp;
    Ret = LoadCP (lpProfileName, (HGLOBAL FAR *) &hcpMem, (LPCHANDLE) & cp);
    if (Ret)
    {
        Ret = GetPS2ColorRenderingDictionary (cp, Intent, lpMem,
                                              lpcbSize, AllowBinary);
        FreeCP (hcpMem);
    }
    return (Ret);
}

BOOL _loadds FAR PASCAL 
CMGetPS2ColorRenderingIntent (
                              LPSTR lpProfileName,
                              DWORD Intent,
                              MEMPTR lpMem,
                              LPDWORD lpcbSize)
{
    BOOL Ret = FALSE;
    HGLOBAL hcpMem;
    CHANDLE cp;
    Ret = LoadCP (lpProfileName, (HGLOBAL FAR *) &hcpMem, (LPCHANDLE) & cp);
    if (Ret)
    {
        Ret = GetPS2ColorRenderingIntent (cp, Intent, lpMem, lpcbSize);
        FreeCP (hcpMem);
    }
    return (Ret);
}


/*****************************************************************************/
/*                                                                           */
/*                            TICMColor                                      */
/* Purpose:                                                                  */
/*    The main function that handles Device Independant Color.               */
/*      It checks the type of the RGBs that will be used in GDI call,        */
/*      sets appropriate colorspace and colorrendering dictionary            */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd -- pdevice                                               */
/*    DWORD hTransICM --    Handle  to current  ICM from DRAWMODE            */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/
short FAR PASCAL 
TICMColor (LPPDEVICE lppd, DWORD hTransICM)
{
    LPICMINFO lpICMI;
    LPICMINFO lpICMCurr;
    LPLOGCOLORSPACE lpCS;
    CSPACESET csNewCS;
    DWORD crdNewCRD = 0L;
    int  ICMStatus = 0;                  // 0: Noop,
    WORD bColorMode;
    int  CRDChanged = 0;
    CSIG DevColorSpace;                  // 247974

 // 1: Change color space
 // 2: Change color space and do icm.
 // Just for safety
    if (bATMWorkAround || lppd->job.bfESCOpenChannel ||
        lppd->lpPSExtDevmode->dm.useImageColorMatching == ICM_DISABLE)
        return (TRUE);

    lppd->lpGSStack->lpgGState->bColorMode = bColorMode = 0;

    lpICMI = (LPICMINFO) HTOPTR (hTransICM, 0);
    lpICMCurr = (LPICMINFO) HTOPTR (lppd->graphics.hCMTransform, 0);

 // This is a specific case when the ICM handle is NULL and it
 // means that no color processing should take place at all.
    if (NULL == lpICMI)
    {
 // Only Level 2 printers have --setcolorspace-- and
 // --setcolorrendering-- operators.       
 // We only support Level 2 printer!
#ifndef ADOBE_DRIVER_42
        if (lppd->lpPSExtDevmode->dm2.bfUseLevel2)
#endif        
        {
    // Because during CRD downloading we can execute
    // --restore--, send ColorSpace AFTER CRD.
    // Changed 25-Oct-1995  -by-  [olegsher]
            if (lppd->lpGSStack->lpgGState->CRDActive != LCS_GM_DEFAULT)
            {
                crdNewCRD = LCS_GM_DEFAULT;
                PSSendAndSelectCRD (lppd, NULL, crdNewCRD, bColorMode);
            }
            if ((lppd->lpGSStack->lpgGState->ColorSpace != CS_DEVICE_RGB) ||
                (lppd->graphics.hCMTransform != hTransICM))
            {
                csNewCS = CS_DEVICE_RGB;
                PSSendColorSpace (lppd, NULL, csNewCS);
            }
            lppd->graphics.hCMTransform = hTransICM;
        }
    } else
    {
 // Now we have new and current ICMInfo structures - compare
 // If any parameter in colorspace has changed - send new colorspace
 // or ColorRenderingDictionary
        lpCS = (LPLOGCOLORSPACE) & (lpICMI->lcsSource);
        if (lpCS->lcsCSType == LCS_DEVICE_RGB)
        {
            csNewCS = CS_DEVICE_RGB;
            ICMStatus = 1;
        } else if (lpCS->lcsCSType == LCS_DEVICE_CMYK)
        {
            csNewCS = CS_DEVICE_CMYK;
            bColorMode |= CM_CMYK;
            ICMStatus = 1;
        } else if (ValidColorSpace (lppd, lpICMI, &DevColorSpace))
        {                               // maybe check for calibrated
                                        // identity here
    // Setup flags based upon user's selection
            ICMStatus = 2;
            switch (lppd->lpPSExtDevmode->dm.iColorMatchingMethod)
            {
                case COLOR_MATCHING_ON_HOST:
                    if (DevColorSpace == icSigCmykData)    // 247974
                    {
                        csNewCS = CS_DEVICE_CMYK;
                        bColorMode = CM_USE_ICM | CM_CMYK_OUT;
                    }
                    else   // DeviceRGB
                    {
                        csNewCS = CS_DEVICE_RGB;
                        bColorMode = CM_USE_ICM;
                    }
                    break;
                case COLOR_MATCHING_ON_PRINTER:
                    bColorMode = CM_SEND_CRD;
            /* Fall thru  */
                case COLOR_MATCHING_PRINTER_CALIBRATION:
                    bColorMode |= CM_USE_CRD;
                    crdNewCRD = lpICMI->lcsSource.lcsGamutMatch;    // Get current intent.
            /* Fall thru  */
                default:
                    csNewCS = CS_CALIBRATED_RGB;
                    break;
            }
        }
 // For Level 1 printers the only feature supported is
 // "Change colors on the host"
 // Also force all output on Level 1 printers to be RGB,
 // so we can use --setrgbcolor-- on all Level 1 printers without
 // risk. Some printers support so-called "Color extensions",
 // i.e. --setcmykcolor--, but it is extra pain to track them
 // and have special cases for that.
 // Added  21-Jun-1995  -by-  [olegsher]   
 #ifndef ADOBE_DRIVER_42
 /* Don't support Level1 printer anymore!! */
        if (!lppd->lpPSExtDevmode->dm2.bfUseLevel2 && (ICMStatus == 2))
        {
            bColorMode = CM_USE_ICM;
        } else 
#endif        
        if (ICMStatus > 0)
        {
    // Because during CRD downloading we can execute
    // --restore--, send ColorSpace AFTER CRD.
    // Changed 25-Oct-1995  -by-  [olegsher]
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    // This is a tricky part -
    // we are supposed to get the intent for curent
    // graphic output in    lpICMI->lcsSource.lcsGamutMatch
    // structure member, but so far we only getting 0s,
    // which in turn means Default ColorRendering.
    // At this time GDI forgets to place the user-selected
    // Intent into this field (or maybe we are missing something),
    // so I added the code that replaces 0 value with the one
    // deduced from user-suppled
    // Changed 06-Jun-1995  -by-  [olegsher]
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            if (0 == crdNewCRD)
            {
                switch (lppd->lpPSExtDevmode->dm.iRenderingIntent)
                {
                    case INTENT_SATURATION:
                        crdNewCRD = LCS_GM_BUSINESS;
                        break;
                    case INTENT_CONTRAST:
                        crdNewCRD = LCS_GM_IMAGES;
                        break;
                    case INTENT_COLORMETRIC:
                        if (lppd->lpPSExtDevmode->dm.iAbsoluteColorimetric) 
                           crdNewCRD = LCS_GM_ABSOLUTE;
                        else
                           crdNewCRD = LCS_GM_GRAPHICS;
                        break;
                    default:
                        break;
                }
            }
    // First make sure we are using CRDs before checking
    // to see if a new one is needed
            if (bColorMode & CM_USE_CRD)
            {
        // We need to send new CRD if one of the following is true.
        // 1. The intent has changed (CRDActive != newCRD)
        // 2. We haven't sent anything down and DestFileName is non NULL.
        // 3. The dest file name has changed.
                if ((lppd->lpGSStack->lpgGState->CRDActive != crdNewCRD) ||
                    (lpICMCurr == NULL && lpICMI->lcsDestFilename) ||
                    lstrcmp (lpICMI->lcsDestFilename, lpICMCurr->lcsDestFilename) ||
                    // PROFING_CRD
                    lstrcmp (lpICMI->lcsTargetFilename, lpICMCurr->lcsTargetFilename) )
                {
                    PSSendAndSelectCRD (lppd, lpICMI, crdNewCRD, bColorMode);
                    CRDChanged = 1;
                }
            }
    // If new colorspace type is required or colorspace params
    // has changed - send new ColorSpace
            if ((lppd->lpGSStack->lpgGState->ColorSpace != csNewCS) ||
                (NULL == lpICMCurr) ||
                MemComp ((LPVOID) & (lpCS->lcsEndpoints),
                         (LPVOID) & (lpICMCurr->lcsSource.lcsEndpoints),
                         (DWORD) sizeof (CIEXYZTRIPLE)) ||
                (lpCS->lcsGammaRed != lpICMCurr->lcsSource.lcsGammaRed) ||
                (lpCS->lcsGammaGreen != lpICMCurr->lcsSource.lcsGammaGreen) ||
                (lpCS->lcsGammaBlue != lpICMCurr->lcsSource.lcsGammaBlue) ||
                lstrcmp ((LPSTR) & (lpCS->lcsFilename),
                         (LPSTR) & (lpICMCurr->lcsSource.lcsFilename))
                )
            {
                if (PSSendColorSpace (lppd, lpCS, csNewCS) && CRDChanged)
                    PSSendAndSelectCRD (lppd, lpICMI, crdNewCRD, bColorMode);
            }
        }
    }
    lppd->lpGSStack->lpgGState->bColorMode = bColorMode;
    lppd->graphics.hCMTransform = hTransICM;
    return (TRUE);
}

/****************************************************************************/
/*                                                                          */
/*                           PSSendColorSpace                               */
/****************************************************************************/

int FAR PASCAL 
PSSendColorSpace (LPPDEVICE lppd, LPLOGCOLORSPACE lpCS,
                  CSPACESET csCS)
{
    double dGamma[3];
    double dElem[9];
    double dChrom[9] = { 0.64, 0.33, 0.03, 0.3, 0.6, 0.1, 0.15, 0.06, 0.79 };
//  double dTrist[9] = { 0.4124, 0.2126, 0.0193, 0.3576, 0.7152, 0.1192, 0.1805, 0.0722, 0.9505 };
    double tolerance = 0.005;
    LPSTR lpBuff = NULL;
    DWORD dwSize;
    short Flavor, i;
    BOOL BinaryProtocal;
    DWORD wInpDrvClrSp;
    HGLOBAL hcpMem = 0;
    CHANDLE cp;
    BOOL Ret = FALSE;
    CSIG Intent = 0;
    LPLOGCOLORSPACE lpCSCurr;
    int  CSADownLoad = 0;

    // Color space may changed.  jjia.  5/30/96
    lppd->lpGSStack->lpgGState->bColorSpaceChanged = TRUE;

    if ((csCS == CS_DEVICE_RGB) || (csCS == CS_DEVICE_CMYK))
    {
       /********************************************************************
        *  Send device color space
        ********************************************************************/
        SendObject (lppd, NewLine);
        SendObject (lppd, BeginArray);           // Begin Array
        if (csCS == CS_DEVICE_RGB)
        {
            SendObject (lppd, DeviceRGBTag);     // /DeviceRGB
        } else if (csCS == CS_DEVICE_CMYK)
        {
            SendObject (lppd, DeviceCMYKTag);    // /DeviceCMYK
        }
        SendObject (lppd, EndArray);             // ]
    }

    if (csCS == CS_CALIBRATED_RGB)
    {
        lpCSCurr = (LPLOGCOLORSPACE)(&(lppd->graphics.CS));

        // Determine output an ascii or binary CSA
        DetermineOutputCharacteristics (lppd, &Flavor, &BinaryProtocal);

       /********************************************************************
        * Determine what kind of CSA we want to output:
        * SPEED Mode                        : CieBasedABC
        * PORTABLE Mode & PS Version > 2016 : CieBasedDEF
        * EPS, ARCHIVE, PJL ARCHIVE         : CieBasedDEF
        ********************************************************************/
        wInpDrvClrSp = icSigRgbData;
        if (lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED)
        {
            wInpDrvClrSp = icSigRgbData;
        } else if (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE)
        {
            int iPSVersion = GetPSVersion (lppd);
            if (iPSVersion >= 2016)
                wInpDrvClrSp = icSigDefData;
        } else if ((lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS) ||
                   (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
                   (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE))
        {
            wInpDrvClrSp = icSigDefData;
        }

       /********************************************************************
        *  Determine Intent.
        ********************************************************************/
        if ((NULL != lpCS) && (lpCS->lcsFilename[0]))
        {
            Ret = LoadCP (lpCS->lcsFilename, (HGLOBAL FAR *) &hcpMem, (LPCHANDLE) & cp);
            if (Ret && !GetCPRenderIntent(cp, (LPCSIG) &Intent))
                Intent = 0;
        }

       /********************************************************************
        *  Build the CALIBRATED_RGB color space
        ********************************************************************/

        if (!(lppd->graphics.bCSASent[lppd->lpProcsetstuff->savelevel] == (Intent+1)) ||
            (MemComp ((LPVOID) & (lpCS->lcsEndpoints),
                      (LPVOID) & (lpCSCurr->lcsEndpoints),
                      (DWORD) sizeof (CIEXYZTRIPLE))) ||
            (lpCS->lcsGammaRed != lpCSCurr->lcsGammaRed) ||
            (lpCS->lcsGammaGreen != lpCSCurr->lcsGammaGreen) ||
            (lpCS->lcsGammaBlue != lpCSCurr->lcsGammaBlue) ||
            (lstrcmp ((LPSTR) & (lpCS->lcsFilename),
                      (LPSTR) & (lpCSCurr->lcsFilename)))
           )
        {   
            if (Ret &&
               (GetPS2ColorSpaceArray (cp, Intent, wInpDrvClrSp, NULL, &dwSize, BinaryProtocal)))
            {
               /****************************************************************
                *  Build the color space from the input color profile.
                ****************************************************************/
                lpBuff = GlobalAllocPtr (GHND, dwSize);
                if ((NULL != lpBuff) &&
                    (GetPS2ColorSpaceArray (cp, Intent, wInpDrvClrSp,
                                        lpBuff, &dwSize, BinaryProtocal)))
                {
                    lppd->graphics.CSAClear = 1;
                    TCleanToVMMark(lppd, 1);
                    VMCheck (lppd, VM_CRD, dwSize);
                    lppd->graphics.CSAClear = 0;

                    PSSendBitMapDataLevel1Binary (lppd, lpBuff, dwSize);
                }
            } else
            {
               /****************************************************************
                *  Build color space from the LOG-COLORSPACE.
                ****************************************************************/
                // ALWAYS_ICM
                BOOL bUseAdobeCSA = TRUE;
                double whiteX, whiteY, whiteZ;
                whiteX = whiteY = whiteZ = 0.0;

                dwSize = 2048;
                lppd->graphics.CSAClear = 1;
                TCleanToVMMark(lppd, 1);
                VMCheck (lppd, VM_CRD, dwSize);
                lppd->graphics.CSAClear = 0;

                dElem[0] = ((lpCS->lcsEndpoints.ciexyzRed.ciexyzX >> 30) * 1.0) +
                    (lpCS->lcsEndpoints.ciexyzRed.ciexyzX & 0x3FFFFFFFL) / 1073741823.0;

                dElem[1] = ((lpCS->lcsEndpoints.ciexyzRed.ciexyzY >> 30) * 1.0) +
                    (lpCS->lcsEndpoints.ciexyzRed.ciexyzY & 0x3FFFFFFFL) / 1073741823.0;

                dElem[2] = ((lpCS->lcsEndpoints.ciexyzRed.ciexyzZ >> 30) * 1.0) +
                    (lpCS->lcsEndpoints.ciexyzRed.ciexyzZ & 0x3FFFFFFFL) / 1073741823.0;

            // =============================
                dElem[3] = ((lpCS->lcsEndpoints.ciexyzGreen.ciexyzX >> 30) * 1.0) +
                    (lpCS->lcsEndpoints.ciexyzGreen.ciexyzX & 0x3FFFFFFFL) / 1073741823.0;

                dElem[4] = ((lpCS->lcsEndpoints.ciexyzGreen.ciexyzY >> 30) * 1.0) +
                    (lpCS->lcsEndpoints.ciexyzGreen.ciexyzY & 0x3FFFFFFFL) / 1073741823.0;

                dElem[5] = ((lpCS->lcsEndpoints.ciexyzGreen.ciexyzZ >> 30) * 1.0) +
                    (lpCS->lcsEndpoints.ciexyzGreen.ciexyzZ & 0x3FFFFFFFL) / 1073741823.0;

            // =============================
                dElem[6] = ((lpCS->lcsEndpoints.ciexyzBlue.ciexyzX >> 30) * 1.0) +
                    (lpCS->lcsEndpoints.ciexyzBlue.ciexyzX & 0x3FFFFFFFL) / 1073741823.0;

                dElem[7] = ((lpCS->lcsEndpoints.ciexyzBlue.ciexyzY >> 30) * 1.0) +
                    (lpCS->lcsEndpoints.ciexyzBlue.ciexyzY & 0x3FFFFFFFL) / 1073741823.0;

                dElem[8] = ((lpCS->lcsEndpoints.ciexyzBlue.ciexyzZ >> 30) * 1.0) +
                    (lpCS->lcsEndpoints.ciexyzBlue.ciexyzZ & 0x3FFFFFFFL) / 1073741823.0;  //

                // If not 2.30 number, try 16.16 number
                if ((dElem[0] < 0.0002) && (dElem[1] < 0.0002) && (dElem[2] < 0.0002) &&
                    (dElem[3] < 0.0002) && (dElem[4] < 0.0002) && (dElem[5] < 0.0002) &&
                    (dElem[6] < 0.0002) && (dElem[7] < 0.0002) && (dElem[8] < 0.0002))
                {
                    dElem[0] = ((lpCS->lcsEndpoints.ciexyzRed.ciexyzX >> 16) * 1.0) +
                        (lpCS->lcsEndpoints.ciexyzRed.ciexyzX & 0x0000FFFFL) / 65535.0;
         
                    dElem[1] = ((lpCS->lcsEndpoints.ciexyzRed.ciexyzY >> 16) * 1.0) +
                        (lpCS->lcsEndpoints.ciexyzRed.ciexyzY & 0x0000FFFFL) / 65535.0;

                    dElem[2] = ((lpCS->lcsEndpoints.ciexyzRed.ciexyzZ >> 16) * 1.0) +
                        (lpCS->lcsEndpoints.ciexyzRed.ciexyzZ & 0x0000FFFFL) / 65535.0;

                // =============================
                    dElem[3] = ((lpCS->lcsEndpoints.ciexyzGreen.ciexyzX >> 16) * 1.0) +
                        (lpCS->lcsEndpoints.ciexyzGreen.ciexyzX & 0x0000FFFFL) / 65535.0;

                    dElem[4] = ((lpCS->lcsEndpoints.ciexyzGreen.ciexyzY >> 16) * 1.0) +
                        (lpCS->lcsEndpoints.ciexyzGreen.ciexyzY & 0x0000FFFFL) / 65535.0;

                    dElem[5] = ((lpCS->lcsEndpoints.ciexyzGreen.ciexyzZ >> 16) * 1.0) +
                        (lpCS->lcsEndpoints.ciexyzGreen.ciexyzZ & 0x0000FFFFL) / 65535.0;

                // =============================
                    dElem[6] = ((lpCS->lcsEndpoints.ciexyzBlue.ciexyzX >> 16) * 1.0) +
                        (lpCS->lcsEndpoints.ciexyzBlue.ciexyzX & 0x0000FFFFL) / 65535.0;

                    dElem[7] = ((lpCS->lcsEndpoints.ciexyzBlue.ciexyzY >> 16) * 1.0) +
                        (lpCS->lcsEndpoints.ciexyzBlue.ciexyzY & 0x0000FFFFL) / 65535.0;

                    dElem[8] = ((lpCS->lcsEndpoints.ciexyzBlue.ciexyzZ >> 16) * 1.0) +
                        (lpCS->lcsEndpoints.ciexyzBlue.ciexyzZ & 0x0000FFFFL) / 65535.0; 
                }

                for (i=0; i<9 && bUseAdobeCSA; i++) 
                {
                    if (dElem[i] > dChrom[i]+tolerance || dElem[i] < dChrom[i]-tolerance)
                        bUseAdobeCSA = FALSE;
                }
                
                if (!bUseAdobeCSA)
                {
                   whiteX += dElem[0] + dElem[3] + dElem[6];  // ALWAYS_ICM
                   whiteY += dElem[1] + dElem[4] + dElem[7];  // ALWAYS_ICM
                   whiteZ += dElem[2] + dElem[5] + dElem[8];  // ALWAYS_ICM
                
                   dGamma[0] = ((lpCS->lcsGammaRed >> 16) * 1.0) +
                       (lpCS->lcsGammaRed & 0x0000FFFFL) / 65536.0;
                   dGamma[1] = ((lpCS->lcsGammaGreen >> 16) * 1.0) +
                       (lpCS->lcsGammaGreen & 0x0000FFFFL) / 65536.0;
                   dGamma[2] = ((lpCS->lcsGammaBlue >> 16) * 1.0) +
                       (lpCS->lcsGammaBlue & 0x0000FFFFL) / 65536.0;

                   bUseAdobeCSA = whiteX    < 0.9505+tolerance && whiteX    > 0.9505-tolerance && 
                                  whiteY    < 1.0   +tolerance && whiteY    > 1.0   -tolerance &&
                                  whiteZ    < 1.089 +tolerance && whiteZ    > 1.089 -tolerance &&
                                  dGamma[0] < 2.2   +tolerance && dGamma[0] > 2.2   -tolerance &&
                                  dGamma[1] < 2.2   +tolerance && dGamma[1] > 2.2   -tolerance &&
                                  dGamma[2] < 2.2   +tolerance && dGamma[2] > 2.2   -tolerance;
                }
                
                if (bUseAdobeCSA)
                {  
                   SendObject (lppd, AdobeCSA);
                }
                else
                {
                   SendObject (lppd, NewLine);
                   SendObject (lppd, BeginArray);  // Begin Array
    
                   SendObject (lppd, ColorSpace1);
                   SendObject (lppd, BeginArray);  // [
    
                   SendObject (lppd, BeginFunction); // {
                   SendFloat (lppd, dGamma[0]);
                   SendObject (lppd, ColorSpace3); // exp } bind
    
                   SendObject (lppd, BeginFunction); // {
                   SendFloat (lppd, dGamma[1]);
                   SendObject (lppd, ColorSpace3); // exp } bind
       
                   SendObject (lppd, BeginFunction); // {
                   SendFloat (lppd, dGamma[2]);
                   SendObject (lppd, ColorSpace3); // exp } bind
        
                   SendObject (lppd, EndArray);// ]
// ALWAYS_ICM        
//                 SendObject (lppd, ColorSpace5); // /WhitePoint
        
            //---------------------------------------------------
                   SendObject (lppd, MatrixLMNTag); // /MatrixLMN
                   SendObject (lppd, BeginArray);  // [

                   for( i=0; i<9; i++ ) SendFloat (lppd, dElem[i]);
                
                   SendObject (lppd, EndArray);// ]

// ALWAYS_ICM
                   SendObject (lppd, WhitePointTag);
                   SendObject (lppd, BeginArray);
                   SendFloat  (lppd, whiteX);
                   SendFloat  (lppd, 1.0);
                   SendFloat  (lppd, whiteZ);
                   SendObject (lppd, EndArray);

                   SendObject (lppd, EndDict); // End dictionary

                   SendObject (lppd, EndArray);    // ]
                }
            }
            SendObject (lppd, NewLine);
            SendObject (lppd, CSAName);
            SendObject (lppd, DefCS);

            lppd->graphics.bCSASent[lppd->lpProcsetstuff->savelevel] = (BYTE)Intent + 1;
            MemCopy((LPSTR)(&(lppd->graphics.CS)), lpCS, sizeof(LOGCOLORSPACE));

            VMUsed (lppd, VM_CRD, dwSize);  // report how much memory were
                                            // used
            if (TSetVMMark(lppd, 1, TRUE))
            {
                CSADownLoad = 1;
            }
        }
        SendObject (lppd, NewLine);
        SendObject (lppd, CSAName);
        SendObject (lppd, FindCS);
    }

   /********************************************************************
    *  set color space.
    ********************************************************************/
    SendObject (lppd, NewLine);
    SendObject (lppd, SetCS);           // setcolorspace
    SendObject (lppd, NewLine);

    lppd->lpGSStack->lpgGState->ColorSpace = csCS;

    if (Ret)
        FreeCP (hcpMem);

    if (lpBuff)
    {
        GlobalFreePtr (lpBuff);
    }
    return CSADownLoad;
}

//************************************************************************
//  GetFileTime - function to get File Timestamp
//              returns 0L if any eror occurs
//
DWORD FAR PASCAL 
GetFileTime (LPBYTE lpFile)
{
    OFSTRUCT ofFileStruct;
    WORD date, time;
    HFILE hFile;
    DWORD dwRes = 0L;
    if (HFILE_ERROR != (hFile = OpenFile ((LPSTR) lpFile, (LPOFSTRUCT) & ofFileStruct,
                                          OF_READ)))
    {
        if (0 == _dos_getftime (hFile, &date, &time))
        {
            dwRes = ((DWORD) date) << 16;
            dwRes += (DWORD) time;
        }
        _lclose (hFile);
    }
    return (dwRes);
}

/****************************************************************************/
/*                                                                          */
/*                           PSSendAndSelectCRD                             */
/****************************************************************************/

void FAR PASCAL 
PSSendAndSelectCRD (LPPDEVICE lppd, LPICMINFO lpICM,
                    DWORD cCRD, WORD bColorMode)
{
    LPSTR lpszEntry;
    char szBuff[256];
    char szTarget[256];
    char szCacheFile[16];
    char szFileSize[16];
    HANDLE hFile = (HANDLE) HFILE_ERROR;
    LPSTR lpBuff = NULL;
    DWORD dwicIntent;
    DWORD dwSize;
    short Flavor;
    BOOL BinaryProtocal;
    LPICMINFO lpICMCurr;
    CHANDLE cp;
    HGLOBAL hcpMem;
    BOOL Ret;
    lpICMCurr = (LPICMINFO) HTOPTR (lppd->graphics.hCMTransform, 0);
 
 // Determine output a ascii or binary CRD. 8/16/95 jjia
    DetermineOutputCharacteristics (lppd, &Flavor, &BinaryProtocal);

    if (cCRD == LCS_GM_IMAGES)
    {
        lpszEntry = "Perceptual";
        dwicIntent = icPerceptual;
    } else if (cCRD == LCS_GM_BUSINESS)
    {
        lpszEntry = "Saturation";
        dwicIntent = icSaturation;
    } else if (cCRD == LCS_GM_GRAPHICS)
    {
        lpszEntry = "Colorimetric";
        dwicIntent = icRelativeColorimetric;
    } else
    {
        lpszEntry = "DefaultColorRendering";
        dwicIntent = icAbsoluteColorimetric;
    }

 // Get the intent real name from the output color profile.
 // Added  24-Jan-1995  -by-  [olegsher]
    Ret = FALSE;
    if ((NULL != lpICM) &&
        (lpICM->lcsDestFilename[0]) &&
        ((Ret = LoadCP (lpICM->lcsDestFilename,
                        (HGLOBAL FAR *)&hcpMem, (LPCHANDLE) & cp)) != FALSE) &&
        (GetPS2ColorRenderingIntent (cp, dwicIntent, NULL, &dwSize)))
    {
        lpBuff = GlobalAllocPtr (GHND, dwSize);
        if ((NULL != lpBuff) &&
            (GetPS2ColorRenderingIntent (cp, dwicIntent, lpBuff, &dwSize)))
        {
            lpszEntry = lpBuff;
        }
    }
    if (Ret)
        FreeCP (hcpMem);

 // Muck around with CRD ONLY:
 // - ICMhandle is not NULL
 // - the mode is "Download CRDs"
 // - non-default CRD is required
 // - the CRD was not send before, or even if it was sent, the
 // profile had changed

    if ((NULL != lpICM) &&
        (bColorMode & CM_SEND_CRD) && cCRD &&
      (!(lppd->graphics.bCRDSent[lppd->lpProcsetstuff->savelevel] & cCRD) ||
       ((NULL != lpICMCurr) &&
        lstrcmp (lpICM->lcsDestFilename, lpICMCurr->lcsDestFilename)))

        )
    {
        HKEY hKey;
 // We must send CRD and this particular one isn't on the printer
 // Check if we have one already pre-computed
 //****************************************************************
 // Added new functionality to handle timestamped CRD.
 // Fixed as a bug#119. 01-Jun-1995  -by-  [olegsher]
 // The information about pre-compiled CRD is kept in the
 // registry under the key
 // \\HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Print
 // \Printers\<FriendlyName>\PrinterDriverData
 // and the ASCII keys are
 // Perceptual
 //   CacheFile
 //   TimeStamp
 //   Profile
 //   FileSize
 //   Type
 //   TargetProfile
 //   TargetCacheFile
 //   TargetFileSize
 // Saturation
 //   CacheFile
 //   TimeStamp
 //   Profile
 //   FileSize
 //   Type
 //   TargetProfile
 //   TargetCacheFile
 //   TargetFileSize
 // Colorimetric
 //   CacheFile
 //   TimeStamp
 //   Profile
 //   FileSize
 //   Type
 //   TargetProfile
 //   TargetCacheFile
 //   TargetFileSize
 //
        lstrcpy (szBuff, "\\System\\CurrentControlSet\\Control\\Print\\Printers\\");
        lstrcat (szBuff, (LPSTR) lppd->lpPSExtDevmode->dm.dm.dmDeviceName);
        lstrcat (szBuff, "\\");
        lstrcat (szBuff, "PrinterDriverData");
        lstrcat (szBuff, "\\");
        lstrcat (szBuff, lpszEntry);
        if (ERROR_SUCCESS ==
            RegCreateKey (HKEY_LOCAL_MACHINE, szBuff, (LPHKEY) & hKey))
        {
            BOOL bNewCRD = FALSE;
            DWORD dwDateTime;
            LONG cb;                    // Size of the copied value
            OFSTRUCT FStr;
    // In order to use the old Pre-compiled PostScript we need
    // the following conditions to exist :
    // - profile file should be the same
    // - timestamp on the profile should be the same
    // - the original PS file should exist
    // ********************************

    // Does  Profile entry in registry exist?
    // If no - create new one.

    //------------------------------------------------
    // Check the device icc profile
            cb = dsizeof (szBuff);
            if ((ERROR_SUCCESS != RegQueryValue (hKey, "Profile",
                                         (LPSTR) szBuff, (LPDWORD) & cb)) ||
                (cb == 0L) ||
                ('\0' == szBuff[0]) ||
                (0 != lstrcmpi (szBuff, lpICM->lcsDestFilename))
                )
            {
                RegSetValue (hKey, "Profile", REG_SZ, lpICM->lcsDestFilename,
                             (DWORD) lstrlen (lpICM->lcsDestFilename) + 1);
                bNewCRD = TRUE;
            }
    //------------------------------------------------
    // Get timestamp and compare to the current one
            cb = dsizeof (szBuff);
            if ((TRUE == bNewCRD) ||
              (0L == (dwDateTime = GetFileTime (lpICM->lcsDestFilename))) ||
                (ERROR_SUCCESS != RegQueryValue (hKey, "TimeStamp",
                                         (LPSTR) szBuff, (LPDWORD) & cb)) ||
                (cb == 0L) ||
                ('\0' == szBuff[0]) ||
                ((DWORD) atol (szBuff) != dwDateTime)
                )
            {
                wsprintf (szBuff, "%lu", dwDateTime);
                RegSetValue (hKey, "TimeStamp", REG_SZ, szBuff,
                             (DWORD) lstrlen (szBuff) + 1);
                bNewCRD = TRUE;
            }

    //------------------------------------------------
    // Check the target icc profile(format: "profile-name timestamp type")
            cb = dsizeof (szBuff);
            if (lpICM->lcsTargetFilename[0] != '\0')
            {
                dwDateTime = GetFileTime (lpICM->lcsTargetFilename);
                wsprintf (szTarget, "%s %lu %u",
                         lpICM->lcsTargetFilename, dwDateTime, (short) BinaryProtocal);
                if ((TRUE == bNewCRD) ||
                    (0L == dwDateTime) ||
                    (ERROR_SUCCESS != RegQueryValue (hKey, "TargetProfile",
                                         (LPSTR) szBuff, (LPDWORD) & cb)) ||
                    (cb == 0L) ||
                    ('\0' == szBuff[0]) ||
                    (0 != lstrcmpi (szBuff, szTarget)))
                {
                    RegSetValue (hKey, "TargetPRofile", REG_SZ, szTarget,
                             (DWORD) lstrlen (szTarget) + 1);

                    bNewCRD = TRUE;
                }
                //------------------------------------------------
                // Check the size of the file
                cb = dsizeof (szBuff);
                if ((TRUE == bNewCRD) ||
                    (ERROR_SUCCESS != RegQueryValue (hKey, "TargetFileSize",
                                     (LPSTR) szBuff, (LPDWORD) & cb)) ||
                    (cb == 0L) ||
                    ('\0' == szBuff[0]) ||
                    (0L == (dwSize = (DWORD) atol (szBuff))))
                {
                    bNewCRD = TRUE;
                }

                lstrcpy(szCacheFile, "TargetCacheFile");
                lstrcpy(szFileSize, "TargetFileSize");
            }
            else
            {
                //------------------------------------------------
                // Check if cache file is a ASCII or BINARY file
                // and compare to the current one     8/16/95 jjia
                cb = dsizeof (szBuff);
                if ((TRUE == bNewCRD) ||
                    (ERROR_SUCCESS != RegQueryValue (hKey, "Type",
                                         (LPSTR) szBuff, (LPDWORD) & cb)) ||
                    (cb == 0L) ||
                    ('\0' == szBuff[0]) ||
                    (atoi (szBuff) != BinaryProtocal)
                    )
                {
                    wsprintf (szBuff, "%u", (short) BinaryProtocal);
                    RegSetValue (hKey, "Type", REG_SZ, szBuff, (DWORD) lstrlen (szBuff) + 1);
                    bNewCRD = TRUE;
                }

                //------------------------------------------------
                // Check the size of the file
                cb = dsizeof (szBuff);
                if ((TRUE == bNewCRD) ||
                    (ERROR_SUCCESS != RegQueryValue (hKey, "FileSize",
                                     (LPSTR) szBuff, (LPDWORD) & cb)) ||
                    (cb == 0L) ||
                    ('\0' == szBuff[0]) ||
                    (0L == (dwSize = (DWORD) atol (szBuff))))
                {
                    bNewCRD = TRUE;
                }

                lstrcpy(szCacheFile, "CacheFile");
                lstrcpy(szFileSize, "FileSize");
            }
    //------------------------------------------------
    // Check if the cache file exists
            cb = dsizeof (szBuff); 

            if ((TRUE == bNewCRD) ||
                (ERROR_SUCCESS != RegQueryValue (hKey, szCacheFile,
                                         (LPSTR) szBuff, (LPDWORD) & cb)) ||
                (cb == 0L) ||
                ('\0' == szBuff[0]) ||
                (HFILE_ERROR == (hFile = OpenFile (szBuff,
                                         (OFSTRUCT FAR *) & FStr, OF_READ)))
                )
            {
        // Remove old cache file and create a new
                 cb = dsizeof (szBuff);
                if ((ERROR_SUCCESS == RegQueryValue (hKey, szCacheFile,
                                         (LPSTR) szBuff, (LPDWORD) & cb)) &&
                    (cb != 0L) &&
                    ('\0' != szBuff[0])
                    )
                {
                    hFile = OpenFile (szBuff,
                                      (OFSTRUCT FAR *) & FStr, OF_DELETE);
                    _lclose (hFile);
                }
        // Create temporary file
                GetTempFileName (0, "CRD", 0, szBuff);
                if (HFILE_ERROR !=
                    (hFile = CreateCRD (lpICM, szBuff, cCRD,
                                        17, BinaryProtocal, &dwSize)))
                {
                    char szNum[15];
                    RegSetValue (hKey, szCacheFile, REG_SZ, szBuff,
                                 (DWORD) lstrlen (szBuff) + 1);
                    wsprintf (szNum, "%lu", dwSize);
                    RegSetValue (hKey, szFileSize, REG_SZ, szNum,
                                 (DWORD) lstrlen (szNum) + 1);
                    _lclose (hFile);
                }
            } else
            {
                _lclose (hFile);
            }
            RegCloseKey (hKey);
        }
        if (hFile != HFILE_ERROR)
        {
            lppd->graphics.CRDClear = cCRD;
            TCleanToVMMark(lppd, 1);
            lppd->graphics.CRDClear = 0xFF; // If error occurs - kill all
                                            // CRDs
            VMCheck (lppd, VM_CRD, dwSize);
            lppd->graphics.CRDClear = 0;

            SendObject (lppd, NewLine);
            SendObject (lppd, Slash);
            SendObject (lppd, (LPSTR) lpszEntry);
            SendObject (lppd, Space);

            PSSendFile (lppd, (LPSTR) szBuff);


            SendObject (lppd, NewLine);
            SendObject (lppd, DefineCRD);

            lppd->graphics.bCRDSent[lppd->lpProcsetstuff->savelevel] |= cCRD;

            VMUsed (lppd, VM_CRD, dwSize);  // report how much memory were
                                            // used
            TSetVMMark(lppd, 1, TRUE);
        }
    }
    if ((bColorMode & CM_USE_CRD) || (cCRD == 0))
    {
        SendObject (lppd, NewLine);
        SendObject (lppd, Slash);
        SendObject (lppd, (LPSTR) lpszEntry);
        SendObject (lppd, Space);
        SendObject (lppd, SelectCRD);
        SendObject (lppd, NewLine);
    }
    lppd->lpGSStack->lpgGState->CRDActive = cCRD;
    if (lpBuff)
    {
        GlobalFreePtr (lpBuff);
    }
}
/*****************************************************************************/
/*                                                                           */
/*                          PSSendFile                                       */
/* Purpose:                                                                  */
/*    To send pre-computed CRD from the file to the printer.                 */
/*                                                                           */
/* Parameters:                                                               */
/*    LPDEVICE lppd     -- pdevice                                           */
/*    LPSTR lpszFile    --  Name    of  the file to be sent                  */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL 
PSSendFile (LPPDEVICE lppd, LPSTR lpszFile)
{
    LPSTR lpBuff = NULL;
    HFILE hFile;                        // Handle to the open file which
 // has generated PostScript
    OFSTRUCT FStr;                      // Structure that keeps info on file

    WORD n;                             // Bytes counter

    hFile = OpenFile (lpszFile, (OFSTRUCT FAR *) & FStr, OF_READ);

    if (hFile == HFILE_ERROR)
    {
        return;
    }
    lpBuff = GlobalAllocPtr (GHND, (DWORD) BUFSIZE);
    if (NULL == lpBuff)
    {
        _lclose (hFile);
        return;
    }
    do
    {
        n = _lread (hFile, lpBuff, BUFSIZE);
        PSSendBitMapDataLevel1Binary (lppd, lpBuff, (DWORD) n);
    } while (n == BUFSIZE);

    _lclose (hFile);
    GlobalFreePtr (lpBuff);
}

//ALWAYS_ICM
BOOL ProfileSelection(LPPDEVICE lppd, LPSTR lpProfileName)
{
    CSIG   Manufacturer;
    CSIG   Model;
    LPDEVMODE lpDevmode = &(lppd->lpPSExtDevmode->dm.dm);
    LPSTR  lpszFriendlyName = lpDevmode->dmDeviceName;
    LPSTR  lpszPort         = lppd->szPortName;
    LPSTR  szBuff = NULL, szName = NULL, szKey = NULL;
    HKEY   hKey, hKey1;
    BOOL   rc = TRUE;
    DWORD  dwTemp;
    DWORD  dwRegIndex, dwType;
    DWORD  cbName, cbValue;
    char   lpRegValName[32];

    Manufacturer = DeviceCapabilities(lpszFriendlyName,lpszPort, DC_ICC_MANUFACTURER, NULL, NULL);
    Model        = DeviceCapabilities(lpszFriendlyName,lpszPort, DC_ICC_MODEL, NULL, NULL);

    if (Manufacturer == NULL || Model == NULL)
        return  FALSE;

    if ((szBuff = GlobalAllocPtr(GDLLHND, 3*BUF_SIZE)) == NULL)
        return FALSE;
    szName = szBuff + BUF_SIZE;
    szKey = szName + BUF_SIZE;

    if (IsWin40())
    {
        /***
        **  Try to Open Manufacturer\Model key
        ***/
        LoadString(ghDriverMod, IDS_REGSTR_PATH_ICM, szBuff, BUF_SIZE);
        lstrcat(szBuff, "\\");
        lstrcpyn(lpRegValName, (LPSTR)(&Manufacturer), 5);
        lstrcat(szBuff, lpRegValName);    // Appen Manufacturer key to registry path.
        lstrcat(szBuff, "\\");
        lstrcpyn(lpRegValName, (LPSTR)(&Model), 5);
        lstrcat(szBuff, lpRegValName);
        if (ERROR_SUCCESS != RegOpenKey(HKEY_LOCAL_MACHINE, szBuff, (LPHKEY)&hKey))
        {
            rc = FALSE;
            goto Done;  // We do not support substitution profiles. So just return.
        }

       /***
        ** Try to Open Manufacturer\Model\MediaType key
        ***/
        lstrcat(szBuff, "\\");
        lstrcpy(szKey, szBuff);     // szBuff is a copy of current RegKey
        // Try to find the MediaType subkey that match DEVMODE.
        rc = FALSE;
        if ((dwTemp = lpDevmode->dmMediaType))
        {
            lstrcpy(szName, MediaType[dwTemp - 1]);
            lstrcat(szKey, szName);
            if (ERROR_SUCCESS == RegOpenKey(HKEY_LOCAL_MACHINE, szKey, (LPHKEY)&hKey1))
                rc = TRUE;
        }
        // Use the first MediaType key.
        if (rc == FALSE)
        {
            lstrcpy(szKey, szBuff);
            if (ERROR_SUCCESS == RegEnumKey(hKey, 0, (LPSTR)szName, BUF_SIZE))
            {
                lstrcat(szKey, szName);
                if (ERROR_SUCCESS == RegOpenKey(HKEY_LOCAL_MACHINE, szKey, (LPHKEY)&hKey1))
                    rc = TRUE;
            }
        }
        // If can not find any MediaType key, return here.
        if (rc == FALSE)
            goto Done;
     
        /***
        ** Try to Open Manufacturer\Model\MediaType\DitherType key
        ***/
        RegCloseKey(hKey);
        hKey = hKey1;
        lstrcat(szKey, "\\");      
        lstrcpy(szBuff, szKey);    // szBuff is a copy of current RegKey
        // Try to find the DitherType subkey that match DEVMODE.
        rc = FALSE;
        if ((dwTemp = lpDevmode->dmDitherType))
        {
            lstrcpy(szName, DitherType[dwTemp - 1]);
            lstrcat(szKey, szName);
            if (ERROR_SUCCESS == RegOpenKey(HKEY_LOCAL_MACHINE, szKey, (LPHKEY)&hKey1))
                rc = TRUE;
        }
        // Use the first DitherType key.
        if (rc == FALSE)
        {
            lstrcpy(szKey, szBuff);
            if (ERROR_SUCCESS == RegEnumKey(hKey, 0, (LPSTR)szName, BUF_SIZE))
            {
                lstrcat(szKey, szName);
                if (ERROR_SUCCESS == RegOpenKey(HKEY_LOCAL_MACHINE, szKey, (LPHKEY)&hKey1))
                    rc = TRUE;
            }
        }
        // If can not find any DitherType key, return here.
        if (rc == FALSE)
            goto Done;
 
        /***
        ** Try to Open Manufacturer\Model\MediaType\Resolution key
        ***/
        RegCloseKey(hKey);
        hKey = hKey1;
        lstrcat(szKey, "\\");      
        lstrcpy(szBuff, szKey);    // szBuff is a copy of current RegKey
        // Try to find the Resolution subkey that match DEVMODE.
        wsprintf(szName, "%0.5dx%0.5d", lpDevmode->dmPrintQuality, lpDevmode->dmYResolution);
        rc = FALSE;
        lstrcat(szKey, szName);
        if (ERROR_SUCCESS == RegOpenKey(HKEY_LOCAL_MACHINE, szKey, (LPHKEY)&hKey1))
            rc = TRUE;
        // Use the first resolution key.
        if (rc == FALSE)
        {
            lstrcpy(szKey, szBuff);
            if (ERROR_SUCCESS == RegEnumKey(hKey, 0, (LPSTR)szName, BUF_SIZE))
            {
                lstrcat(szKey, szName);
                if (ERROR_SUCCESS == RegOpenKey(HKEY_LOCAL_MACHINE, szKey, (LPHKEY)&hKey1))
                    rc = TRUE;
            }
        }
        // If can not find any Resolution key, return here.
        if (rc == FALSE)
            goto Done;    
 
        RegCloseKey(hKey);
        hKey = hKey1;
     
        /***
        **  Looking for icc profile
        ***/
        rc = FALSE;
        lstrcpy(lpRegValName, Profile00);           // Select the first icc profile as default.
        // First pass, search default profile name.
        dwRegIndex = 0;
        while ((cbName = cbValue = BUF_SIZE) &&
               (RegEnumValue(hKey, dwRegIndex, szName, (LPDWORD)&cbName,
                NULL, (LPDWORD)&dwType, szBuff, (LPDWORD)&cbValue) == ERROR_SUCCESS))
        {
            if ((cbName != BUF_SIZE) && (lstrcmp(szName, DefaultProfile) == 0))
            {
                if (cbValue != BUF_SIZE)
                {
                    lstrcpy(lpRegValName, szBuff);    // Find a default icc profile ID.
                    break;
                }
            }
            dwRegIndex++;
        }
        // Second pass, Find profile name.
        dwRegIndex = 0;
        while ((cbName = cbValue = BUF_SIZE) &&
               (RegEnumValue(hKey, dwRegIndex, szName, (LPDWORD)&cbName,
                NULL, (LPDWORD)&dwType, szBuff, (LPDWORD)&cbValue) == ERROR_SUCCESS))
        {
            if ((cbName != BUF_SIZE) && (lstrcmp(szName, lpRegValName) == 0))
            {
                if (cbValue != BUF_SIZE)
                {
                    lstrcpy(lpProfileName, szBuff);
                    rc = TRUE;
                    break;
                }
            }
            dwRegIndex++;
        }
    }     
    // Windows98
    else
    {
        long    len, type;
        short   score, highScore=-1;
        LPSTR   p, lpszWinner;
        LPBYTE  q;
        HGLOBAL hcpMem, hData;
        MEMPTR  lpData;
        CHANDLE cp;
        SINT    index=0, size=0;
        
        len = BUFSIZE;
        LoadString(ghDriverMod, IDS_REGSTR_PRINTERDRIVERDATA, szKey, BUF_SIZE);
        wsprintf(szBuff, szKey, lpszFriendlyName);
        if (!GetSystemDirectory((LPSTR)szName, BUFSIZE) ||
            ERROR_SUCCESS != RegOpenKey(HKEY_LOCAL_MACHINE, szBuff, (LPHKEY)&hKey) ||
            ERROR_SUCCESS != RegQueryValueEx(hKey, "ICMProfile", 0, &type, szBuff, &len) ||
            *szBuff == 0)
        {
            rc = FALSE;
            goto Done;  // We do not support substitution profiles. So just return.
        }   
        
        lstrcat(szName, "\\Color\\");   
        lstrcpy(lpProfileName, szName);

        len = lstrlen(szBuff);                    
        if (!szBuff[len] && !szBuff[len+1])  // only one profile
        {
           lstrcat(lpProfileName, szBuff);
        }
        else
        {   // pick the best profile
           p = szBuff;
           lpszWinner = NULL;
           while( *p )
           {
              wsprintf(szKey, "%s%s", szName, p); 
                                           
              if (LoadCP(szKey, (HGLOBAL FAR*)&hcpMem, (LPCHANDLE)&cp))
              {
                 score = 0;
                                    
                 // match MediaType
                 if(DoesCPTagExist(cp, icSigMediaType) &&
                    GetCPTagIndex(cp, icSigMediaType, (LPSINT)&index) &&
                    GetCPElementSize(cp, index, (LPSINT)&size ) &&
                    MemAlloc(size, (HGLOBAL FAR *)(&hData), (LPMEMPTR)(&lpData)))
                 {  
                    if (GetCPElement(cp, index, lpData, size))
                    {   
                       q = (LPBYTE)&(lpDevmode->dmMediaType);
                       lpData += sizeof(icTagBase);
                       if(q[0]==lpData[3] && q[1]==lpData[2] && 
                          q[2]==lpData[1] && q[3]==lpData[0])
                          score++;
                    }
                    MemFree(hData);
                 }        
                 
                 // match DitherType
                 if(DoesCPTagExist(cp, icSigDitherType) &&
                    GetCPTagIndex(cp, icSigDitherType, (LPSINT)&index) &&
                    GetCPElementSize(cp, index, (LPSINT)&size ) &&
                    MemAlloc(size, (HGLOBAL FAR *)(&hData), (LPMEMPTR)(&lpData)))
                 {  
                    if (GetCPElement(cp, index, lpData, size))
                    {   
                       q = (LPBYTE)&(lpDevmode->dmDitherType);
                       lpData += sizeof(icTagBase);
                       if(q[0]==lpData[3] && q[1]==lpData[2] && 
                          q[2]==lpData[1] && q[3]==lpData[0])
                          score++;
                    }
                    MemFree(hData);
                 }        

                 // match Resolution
                 if(DoesCPTagExist(cp, icSigResolution) &&
                    GetCPTagIndex(cp, icSigResolution, (LPSINT)&index) &&
                    GetCPElementSize(cp, index, (LPSINT)&size ) &&
                    MemAlloc(size, (HGLOBAL FAR *)(&hData), (LPMEMPTR)(&lpData)))
                 {  
                    if (GetCPElement(cp, index, lpData, size))
                    {  BOOL match = TRUE;

                       lpData += sizeof(icTagBase);
                       if(lpDevmode->dmYResolution)
                       {          
                          q = (LPBYTE)&(lpDevmode->dmYResolution);
                          match = q[0]==lpData[7] && q[1]==lpData[6];
                       } 
                       if(match)
                       { 
                          q = (LPBYTE)&(lpDevmode->dmPrintQuality);
                          if(q[0]==lpData[3] && q[1]==lpData[2])
                             score++;
                       }      
                    }
                    MemFree(hData);
                 }        

                 if(score > highScore)
                 {
                    lpszWinner = p;
                    highScore = score;
                 } 
                 FreeCP (hcpMem);
              }
              len = lstrlen(p); 
              p += len + 1;             
           }
           
           if(lpszWinner) 
              lstrcat(lpProfileName, lpszWinner);
           else
              rc = FALSE;    
        }
    }

Done:
    GlobalFreePtr(szBuff);
    RegCloseKey(hKey);
    return rc;
}

#pragma optimize("", off)

DWORD FIXED_2DOT30(float fNumber)
{
   long   Integer;
   float  Fraction;
   DWORD  rc;

   Integer = (LONG)floor(fNumber);
   Fraction = fNumber - (float)Integer;
   rc = (DWORD)(Integer << 30) & 0xc0000000;
   rc += ((DWORD)(Fraction * 1073741823.0) & 0x3fffffff);
   return rc;
}
      
DWORD FIXED_16DOT16(float fNumber)
{
   long   Integer;
   float  Fraction;
   DWORD  rc;

   Integer = (LONG)floor(fNumber);
   Fraction = fNumber - (float)Integer;
   rc = (DWORD)(Integer << 16) & 0xFFFF0000;
   rc += ((DWORD)(Fraction * 65535.0) & 0x0000FFFF);
   return rc;
}


