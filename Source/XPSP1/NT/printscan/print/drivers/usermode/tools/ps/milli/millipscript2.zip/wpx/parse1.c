/*  parse1.c  - some functions used to load the WPX structures   */

#include  "generic.h"

#pragma code_seg(_PARSE1SEG)

extern  DWORD  PPDchecksum ;  //  checksum for PPD file.

BOOL  FAR   PASCAL  initWPXinfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable,
LPBYTE   lpPPDName )
{
   BOOL  status ;


   status = initPrinterInfo(lpPrinterInfo, lpOptionsBlock, lpStringTable,
                            lpPPDName);

   if(!status)
      return(FALSE);

//   bCustomSize = initCustPageInfo(lpPrinterInfo, lpStringTable);
// verify  bCustomSize before calling initPaperInfo !!
// called from within initPrinterInfo.

   status = initPaperInfo(lpPrinterInfo, lpOptionsBlock , lpStringTable );

   if(!status)
      return(FALSE);

   status = initDuplexingInfo(lpPrinterInfo, lpOptionsBlock );

   if(!status)
      return(FALSE);

   status = initCollationInfo(lpPrinterInfo, lpOptionsBlock );

   if(!status)
      return(FALSE);

   status = initOutputOrderInfo(lpPrinterInfo, lpOptionsBlock, lpStringTable );

   if(!status)
      return(FALSE);

   status = initInputSlotInfo(lpPrinterInfo, lpOptionsBlock , lpStringTable );

   if(!status)
      return(FALSE);

   status = initResolutionInfo(lpPrinterInfo, lpOptionsBlock );

   if(!status)
      return(FALSE);

   status = initOutputBinInfo(lpPrinterInfo, lpOptionsBlock , lpStringTable );

   if(!status)
      return(FALSE);

   status = initMediaTypeInfo(lpPrinterInfo, lpOptionsBlock , lpStringTable );

   if(!status)
      return(FALSE);

   status = initInstalledMemoryInfo(lpPrinterInfo, lpOptionsBlock , lpStringTable );

   if(!status)
      return(FALSE);

   status = initOpenUIstructs(lpPrinterInfo, lpOptionsBlock , lpStringTable );

   if(!status)
      return(FALSE);

   status = initNoneOptionIndex(lpPrinterInfo, lpOptionsBlock , lpStringTable );

   if(!status)
      return(FALSE);

   status = initOrderDependency(lpPrinterInfo, lpOptionsBlock , lpStringTable );

   if(!status)
      return(FALSE);

   status = initUIConstraints(lpPrinterInfo, lpOptionsBlock , lpStringTable) ;

   if(!status)
      return(FALSE);


   return(status);
}



BOOL  NEAR   PARSE1SEG PASCAL  initPaperInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable )
{
   WORD  i, j, numEntries, undefinedID ;
   DWORD  lengthOffset ;
   LPMAINKEYHDR  lpPaperInfoHdr, lpPageRegionInfoHdr ;
   LPGENERIC_OPTION  lpPageRegionInfo , lpPaperInfo;
   LPPAPERINFO   lpExtraPaperInfo ;
   HPBYTE   hpCur, hpPaper ;
   BYTE   Buffer[256];  // holds string value for parsing into tokens
   LPBYTE  lpBuf, lpTok1;      // scratch pointers.
   long  int  lvalue ;
   BOOL    bErrors ;


   scalePaperIDtable() ;

   lpPaperInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;
   lpPageRegionInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_PAGEREGIONINFO ;

   //  eventually to be performed by OpenUI parser.
   if(!lpPaperInfoHdr->MainKey.dword)
   {
      lpPaperInfoHdr->MainKeyID = PAGESIZE;
      lpPaperInfoHdr->MainKey.dword = lpMainKeyWordsTable[PAGESIZE].dword ;
      lpPaperInfoHdr->MainTranslation.dword = 0L ;
   }

   if(!lpPageRegionInfoHdr->MainKey.dword)
   {
      lpPageRegionInfoHdr->MainKeyID = PAGEREGION;
      lpPageRegionInfoHdr->MainKey.dword = lpMainKeyWordsTable[PAGEREGION].dword ;
      lpPageRegionInfoHdr->MainTranslation.dword = 0L ;
   }

   lpPaperInfoHdr->UItype = PICKONE ;   // not actually used by UI code
   lpPageRegionInfoHdr->UItype = PICKONE ;

   lpPaperInfoHdr->OptionQuery.dword = 0L ;
   lpPageRegionInfoHdr->OptionQuery.dword = 0L ;


   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == Q_PAGESIZE)
      {
         lpPaperInfoHdr->OptionQuery.dword =
            addStringToTable(lpKeyEntry[i].value);  // invocations are
         break;                                    // simple strings
      }
   }

   //  ------ parse PaperDimension entries -------

   lpExtraPaperInfo = (LPPAPERINFO)MAKELONG(
                           lpPaperInfoHdr->extraOptionArray,
                           HIWORD(lpOptionsBlock));

   lpPaperInfo = (LPGENERIC_OPTION)MAKELONG(
                           lpPaperInfoHdr->OptionKeyWords.w.offset,
                           HIWORD(lpOptionsBlock));

   lpPageRegionInfo = (LPGENERIC_OPTION)MAKELONG(
                          lpPageRegionInfoHdr->OptionKeyWords.w.offset,
                          HIWORD(lpOptionsBlock));

   // reserve 3 numbers for Custom papers and 1 for Custom Other paper(APP_DEFINED)
   undefinedID = DMPAPER_CUST + CUST_IDS_RESERVED;  // first undefined paper is assigned
                                    //  this value.

   //  remove redundant papersize options
   for(numEntries = i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword != PAPERDIMENSION)
         continue ;   //  should drop to end of for loop.

      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      for(j = 0 ; j < numEntries ; j++)
      {
         lengthOffset = lpPaperInfo[j].OptionKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, hpCur))
            break;
      }
      if(j < numEntries) //  duplicate option
         continue;   //  this option has already been added.

      hpPaper = hpCur;

      lpPaperInfo[numEntries].OptionKey.dword =
      lpPageRegionInfo[numEntries].OptionKey.dword =
         addStringToTable(lpKeyEntry[i].option);

      lpPaperInfo[numEntries].OptionTranslation.dword =
      lpPageRegionInfo[numEntries].OptionTranslation.dword =
         addTransStringToTable(lpKeyEntry[i].optionTrans) ;

      //  value is Quoted string containing two reals: width and height
      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITPAPERINFO, ERR_PAPERDIMENSION);
         errorMsg(INITPAPERINFO, ERR_KEYWORD_HAS_NO_VALUE);
         continue ;   //  should drop to end of for loop.
      }
      if(!(lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITPAPERINFO, ERR_PAPERDIMENSION);
         errorMsg(INITPAPERINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
         errorString(hpCur);
         continue ;   //  should drop to end of for loop.
      }

      addQuotedStringToTable(hpCur, Buffer, 255) ;  // copy to temp buffer

      lpBuf = Buffer;

      bErrors = FALSE ;

      if((lpTok1 = extractStringToken(&lpBuf))  &&
                        convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
         lpExtraPaperInfo[numEntries].width = (WORD)lvalue;
      else
         bErrors = TRUE ;

      if(!bErrors   &&  lpBuf  &&
                        (lpTok1 = extractStringToken(&lpBuf))  &&
                        convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
         lpExtraPaperInfo[numEntries].length = (WORD)lvalue;
      else
         bErrors = TRUE ;

      if(bErrors)
      {
         errorMsg(INITPAPERINFO, ERR_PAPERDIMENSION);
         errorMsg(INITPAPERINFO, ERR_EXPCTD_TWO_TOKENS);
         errorMsg(INITPAPERINFO, ERR_CONV_STRING_TO_DECIMAL);
         errorString(Buffer);
         continue;
      }

      //  at this time we may initialize paperID and NaturalUnit fields
      setPaperID(hpPaper, lpExtraPaperInfo + numEntries, &undefinedID);

      numEntries++ ;
   }

   //  init all paper invocation values to zero.
   for(i = 0 ; i < numEntries ; i++)
   {
      lpPaperInfo[i].Invocation.dword = 0L;  // pagesize invocation
      lpPageRegionInfo[i].Invocation.dword = 0L;  // pageregion invocation
      lpExtraPaperInfo[i].imageableArea.left = 0;
      lpExtraPaperInfo[i].imageableArea.right = lpExtraPaperInfo[i].width;
      lpExtraPaperInfo[i].imageableArea.top = lpExtraPaperInfo[i].length;
      lpExtraPaperInfo[i].imageableArea.bottom = 0;
   }

   //  extract IMAGEABLEAREA  info

   for(i = numKeywords ; i ; )
   {
      i-- ;  //  work our way backwards so first entry
            //  overwrites any others.

      if(lpKeyEntry[i].keyword != IMAGEABLEAREA)
         continue ;
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      for(j = 0 ; j < numEntries ; j++)
      {
         lengthOffset = lpPaperInfo[j].OptionKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, hpCur))
            break;
      }
      if(j >= numEntries)
         continue;   //  doesn't match any of the recorded entries

      //  value is Quoted string containing four reals
      //  which specify the bounding box in pscript coords.
      //  left, bottom, right, top

      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITPAPERINFO, ERR_IMAGEABLEAREA);
         errorMsg(INITPAPERINFO, ERR_KEYWORD_HAS_NO_VALUE);
         continue ;   //  should drop to end of for loop.
      }
      if(!(lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITPAPERINFO, ERR_IMAGEABLEAREA);
         errorMsg(INITPAPERINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
         errorString(hpCur);
         continue ;   //  should drop to end of for loop.
      }
      addQuotedStringToTable(hpCur, Buffer, 255);  //  if value exceeds
      lpBuf = Buffer;                //  buffersize, error will result.

      bErrors = FALSE ;

      if((lpTok1 = extractStringToken(&lpBuf))  &&
                        convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
         lpExtraPaperInfo[j].imageableArea.left = (WORD)lvalue ;
      else
         bErrors = TRUE ;

      if(!bErrors   &&  lpBuf  &&
                        (lpTok1 = extractStringToken(&lpBuf))  &&
                        convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
         lpExtraPaperInfo[j].imageableArea.bottom = (WORD)lvalue;
      else
         bErrors = TRUE ;

      if(!bErrors   &&  lpBuf  &&
                        (lpTok1 = extractStringToken(&lpBuf))  &&
                        convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
         lpExtraPaperInfo[j].imageableArea.right = (WORD)lvalue;
      else
         bErrors = TRUE ;

      if(!bErrors   &&  lpBuf  &&
                        (lpTok1 = extractStringToken(&lpBuf))  &&
                        convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
         lpExtraPaperInfo[j].imageableArea.top = (WORD)lvalue;
      else
         bErrors = TRUE ;

      if(bErrors)
      {
         errorMsg(INITPAPERINFO, ERR_IMAGEABLEAREA);
         errorMsg(INITPAPERINFO, ERR_EXPCTD_FOUR_TOKENS);
         errorMsg(INITPAPERINFO, ERR_CONV_STRING_TO_DECIMAL);
         errorString(Buffer);
      }
      else
      {
         // ensure roundoff error decreases the imageable area.
         // fix bug 234521 - adjust imageable area ONLY if there is
         //  an unprintable region to begin with
         if (0 < lpExtraPaperInfo[j].imageableArea.left)
         {
            lpExtraPaperInfo[j].imageableArea.left ++;
         }
         if (0 < lpExtraPaperInfo[j].imageableArea.bottom)
         {
            lpExtraPaperInfo[j].imageableArea.bottom ++;
         }
      }
   }  //  went through every  IMAGEABLEAREA entry.


   //  extract PAGESIZE  info

   for(i = numKeywords ; i ; )
   {
      i-- ;  //  work our way backwards so first entry
            //  overwrites any others.

      if(lpKeyEntry[i].keyword != PAGESIZE)
         continue ;   //  should drop to end of for loop.
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      for(j = 0 ; j < numEntries ; j++)
      {
         lengthOffset = lpPaperInfo[j].OptionKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, hpCur))
            break;  //  attempt to find matching papername.
      }
      if(j >= numEntries)
         continue;   //  doesn't match any of the recorded entries

      //  value is Invocation string

      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITPAPERINFO, ERR_PAGESIZE);
         errorMsg(INITPAPERINFO, ERR_KEYWORD_HAS_NO_INVC_VALUE);
         continue ;   //  should drop to end of for loop.
      }
      if(!(lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITPAPERINFO, ERR_PAGESIZE);
         errorMsg(INITPAPERINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
         errorString(hpCur);
         continue ;   //  should drop to end of for loop.
      }

      lpPaperInfo[j].Invocation.dword =
                              addStringToTable(hpCur);  // invocation
   }  //  went through every  PAGESIZE entry.

   //  extract PAGEREGION  info

   for(i = numKeywords ; i ; )
   {
      i-- ;  //  work our way backwards so first entry
            //  overwrites any others.

      if(lpKeyEntry[i].keyword != PAGEREGION)
         continue ;   //  should drop to end of for loop.
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      for(j = 0 ; j < numEntries ; j++)
      {
         lengthOffset = lpPaperInfo[j].OptionKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, hpCur))
            break;  //  attempt to find matching papername.
      }
      if(j >= numEntries)
         continue;   //  doesn't match any of the recorded entries

      //  value is Invocation string

      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITPAPERINFO, ERR_PAGEREGION);
         errorMsg(INITPAPERINFO, ERR_KEYWORD_HAS_NO_INVC_VALUE) ;
         continue ;   //  should drop to end of for loop.
      }
      if(!(lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITPAPERINFO, ERR_PAGEREGION);
         errorMsg(INITPAPERINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
         errorString(Buffer);
         continue ;   //  should drop to end of for loop.
      }

      lpPageRegionInfo[j].Invocation.dword =
                              addStringToTable(hpCur);
   }  //  went through every  PAGEREGION entry.


   // it is not use by any UI

   if(bCustomSize)      // used to track UI constraints and
   {                    // OrderDependency.
                                                    /* "Custom Size"        */
      LoadString(ghDriverMod, ID_PPDSTR_CUSTOMSIZE, Buffer, sizeof(Buffer));
      lpPaperInfo[numEntries].OptionKey.dword =
      lpPageRegionInfo[numEntries].OptionKey.dword =
         addStringToTable(Buffer);

      lpPaperInfo[numEntries].OptionTranslation.dword =
      lpPageRegionInfo[numEntries].OptionTranslation.dword = 0L ;

      lpPaperInfo[numEntries].Invocation.dword = 0L ;
      lpPageRegionInfo[numEntries].Invocation.dword = 0L ;

      lpExtraPaperInfo[numEntries].width = 0L;  // not actually used.
      lpExtraPaperInfo[numEntries].length = 0L;

      lpExtraPaperInfo[numEntries].paperID = DMPAPER_CUST;

      lpPrinterInfo->devcaps.CustomPageSize = numEntries ;
      //  index of custompagesize option.

      numEntries++;
   }

   // update actual number of papersizes.
   lpPaperInfoHdr->OptionKeyWords.w.length = numEntries ;
   lpPageRegionInfoHdr->OptionKeyWords.w.length = numEntries ;
   // these two arrays must be the same size!

   if(!numEntries)
   {
      errorMsg(INITPAPERINFO, ERR_NO_PAPERSIZES);
      return(FALSE) ;
   }


   //  set default papersize here.
   lpPaperInfoHdr->DefaultOptionIndex = 0 ;
   lpPageRegionInfoHdr->DefaultOptionIndex = 0 ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == DEFAULTPAGESIZE)
         break;  //   scan for this keyword.  stop at first occurance
   }

   if(i >= numKeywords)
      goto    endInitPaperInfo;

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPAPERINFO, ERR_DEFAULTPAGESIZE);
      errorMsg(INITPAPERINFO, ERR_KEYWORD_HAS_NO_VALUE);
      goto   endInitPaperInfo;  // select this line --or--
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPAPERINFO, ERR_DEFAULTPAGESIZE);
      errorMsg(INITPAPERINFO, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto   endInitPaperInfo;   //  for non fatal errors
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf);

   for(j = 0 ; j < numEntries ; j++)
   {
      lengthOffset = lpPaperInfo[j].OptionKey.dword ;
      if(!strtblcmp(lengthOffset, lpStringTable, lpBuf))
      {
         lpPaperInfoHdr->DefaultOptionIndex = j ;
         lpPageRegionInfoHdr->DefaultOptionIndex = j ;
         break;
      }
   }

endInitPaperInfo:
   return(TRUE);
}






BOOL  NEAR   PARSE1SEG PASCAL  initInputSlotInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable )
{
   // -------- parse  INPUTSLOT  entries -------


   WORD  i, j, numEntries, firstInputSlot, undefinedID ;
   DWORD  lengthOffset ;
   LPMAINKEYHDR  lpInputSlotInfoHdr ;
   LPINPUTSLOTINFO   lpExtraInputSlotInfo ;
   LPGENERIC_OPTION   lpInputSlotInfo ;
   HPBYTE   hpCur ;
   BYTE   Buffer[256];  // holds string value for parsing into tokens
   LPBYTE  lpBuf;      // scratch pointers.



   lpInputSlotInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;

   //  eventually to be performed by OpenUI parser.
   if(!lpInputSlotInfoHdr->MainKey.dword)
   {
      lpInputSlotInfoHdr->MainKeyID = INPUTSLOT;
      lpInputSlotInfoHdr->MainKey.dword = lpMainKeyWordsTable[INPUTSLOT].dword ;
      lpInputSlotInfoHdr->MainTranslation.dword = 0L ;
   }

   lpInputSlotInfoHdr->UItype = PICKONE ;   // not actually used by UI code

   lpInputSlotInfoHdr->OptionQuery.dword = 0L ;


   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == Q_INPUTSLOT)
      {
         lpInputSlotInfoHdr->OptionQuery.dword =
            addStringToTable(lpKeyEntry[i].value);  // invocations are
         break;                                    // simple strings
      }
   }


   lpExtraInputSlotInfo = (LPINPUTSLOTINFO)MAKELONG(
       lpInputSlotInfoHdr->extraOptionArray, HIWORD(lpOptionsBlock) );

   lpInputSlotInfo = (LPGENERIC_OPTION)MAKELONG(
       lpInputSlotInfoHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

   if(bAutoSelect)
   {
      lpPrinterInfo->devcaps.AutoSense = 0 ;
      //  index of AutoSelect option.
      firstInputSlot = numEntries = 1;     //  AutoSelect is another inputslot

                                                    /* "AutoSelect Tray" */
      LoadString(ghDriverMod, ID_PPDSTR_AUTOSELECTTRAY, Buffer, sizeof(Buffer));
      lpInputSlotInfo[0].OptionKey.dword = addStringToTable(Buffer);

      lpInputSlotInfo[0].OptionTranslation.dword = 0L ;
      lpInputSlotInfo[0].Invocation.dword = 0L ;   // no command - its Automatic!
      lpExtraInputSlotInfo[0].ReqsPageRegion = FALSE ;  // Obviously!
         //  we switch to using only PageSize command.
      lpExtraInputSlotInfo[0].slotID = DMBIN_AUTO ;
   }
   else
      firstInputSlot = numEntries = 0;

   undefinedID = DMBIN_USER;  // first undefined slot is assigned
                                    //  this value.


   //  remove redundant inputslot options

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword != INPUTSLOT)
         continue ;   //  should drop to end of for loop.
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      for(j = firstInputSlot ; j < numEntries ; j++)
      {
         lengthOffset = lpInputSlotInfo[j].OptionKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, hpCur))
            break;
      }
      if(j < numEntries)
         continue;   //  this entry has already been added.

      lpInputSlotInfo[numEntries].OptionKey.dword =
                  addStringToTable(hpCur);

      lpInputSlotInfo[numEntries].OptionTranslation.dword =
         addTransStringToTable(lpKeyEntry[i].optionTrans) ;

      //  value is Invocation string
      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITINPUTSLOTINFO, ERR_INPUTSLOT);
         errorMsg(INITINPUTSLOTINFO, ERR_KEYWORD_HAS_NO_VALUE);
         continue ;   //  should drop to end of for loop.
      }
      if(!(lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITINPUTSLOTINFO, ERR_INPUTSLOT);
         errorMsg(INITINPUTSLOTINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
         errorString(hpCur);
         continue ;   //  should drop to end of for loop.
      }

      lpInputSlotInfo[numEntries].Invocation.dword =
                              addStringToTable(hpCur);
      lpExtraInputSlotInfo[numEntries].ReqsPageRegion = FALSE ;  // Default.

      setSlotID(lpInputSlotInfo[numEntries].OptionKey,
                  lpExtraInputSlotInfo + numEntries, &undefinedID);
      numEntries++  ;
   }  //  went through every  INPUTSLOT entry.


   //  extract REQUIRESPAGEREGION  info  (exclude ManualFeed)

   for(i = numKeywords ; i ; )
   {
      i-- ;  //  work our way backwards so first entry
            //  overwrites any others.

      if(lpKeyEntry[i].keyword != REQUIRESPAGEREGION)
         continue ;
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      for(j = firstInputSlot ; j < numEntries ; j++)
      {
         lengthOffset = lpInputSlotInfo[j].OptionKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, hpCur))
            break;
      }
      if(j >= numEntries  &&  hstrcmp(hpCur, (HPBYTE)"All"))
         continue;   //  doesn't match any of the recorded entries
                     //  'All' is a special wildcard option keyword
                     //  which matches all option keywords.
      //  value is  string value: True | False

      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITINPUTSLOTINFO, ERR_REQUIRESPAGEREGION);
         errorMsg(INITINPUTSLOTINFO, ERR_KEYWORD_HAS_NO_VALUE);
         continue ;   //  should drop to end of for loop.
      }
      if((lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITINPUTSLOTINFO, ERR_REQUIRESPAGEREGION);
         errorMsg(INITINPUTSLOTINFO, ERR_EXPCTD_STRING_NOT_QUOTED);
         errorString(hpCur);
         continue ;   //  should drop to end of for loop.
      }
      hstrcpyn(Buffer, hpCur, 255);
      lpBuf = Buffer;
      lpBuf = extractStringToken(&lpBuf);
      if(lstrcmp("True", lpBuf))
      {
         if(!hstrcmp(lpKeyEntry[i].option, (HPBYTE)"All") )
         {                            //  set for all Inputslots!
            for(j = firstInputSlot ; j < numEntries ; j++)
               lpExtraInputSlotInfo[j].ReqsPageRegion = FALSE ;
         }
         else
            lpExtraInputSlotInfo[j].ReqsPageRegion = FALSE ;
      }
      else
      {
         if(!hstrcmp(lpKeyEntry[i].option, (HPBYTE)"All") )
         {                            //  set for all Inputslots!
            for(j = firstInputSlot ; j < numEntries ; j++)
               lpExtraInputSlotInfo[j].ReqsPageRegion = TRUE ;
         }
         else
            lpExtraInputSlotInfo[j].ReqsPageRegion = TRUE ;
      }

   }  //  went through every  REQUIRESPAGEREGION entry.



   //   what about manual feed? that counts as another slot!
   if(!bManFeed)
      goto  noManualFeed1 ;  // don't bother looking.

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == MANUALFEED  &&
               (hpCur = lpKeyEntry[i].option) &&
               !hstrcmp("True", hpCur))
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    noManualFeed1;  //  optional keyword

   lpInputSlotInfo[numEntries].OptionKey.dword =
                        lpMainKeyWordsTable[MANUALFEED].dword ;

   LoadString(ghDriverMod, IDS_MANUALFEED, Buffer, sizeof(Buffer));

   lpInputSlotInfo[numEntries].OptionTranslation.dword =
                  addStringToTable(Buffer);
//   hack this until all OpenUI's are parsed.

   //  value is Invocation string
   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITINPUTSLOTINFO, ERR_MANUALFEED_TRUE);
      errorMsg(INITINPUTSLOTINFO, ERR_KEYWORD_HAS_NO_INVC_VALUE);
      goto    noManualFeed1;  //  optional keyword
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITINPUTSLOTINFO, ERR_MANUALFEED_TRUE);
      errorMsg(INITINPUTSLOTINFO, ERR_EXPCTD_INVOCATN_NOT_STRING);
      errorString(hpCur);
      goto    noManualFeed1;  //  optional keyword
   }

   lpInputSlotInfo[numEntries].Invocation.dword =
                           addStringToTable(hpCur);
   lpExtraInputSlotInfo[numEntries].ReqsPageRegion = TRUE ;  // for ManualFeed.

   lpExtraInputSlotInfo[numEntries].slotID = DMBIN_MANUAL ;

   lpPrinterInfo->devcaps.ManualFeed = numEntries ;

   numEntries++  ;

   //  how to disable manual feed. - already done.

noManualFeed1:

#if 0

   //  Adobe doesn't want this anymore.

   {         // add MIXEDBINS if applicable
      BOOL   bUpper = FALSE, bLower = FALSE ;
      DWORD  lengthOffset ;

      for(j = firstInputSlot ; j < numEntries ; j++)
      {
         lengthOffset = lpInputSlotInfo[j].OptionKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, (HPBYTE)"Upper"))
            bUpper = TRUE;
         else if(!strtblcmp(lengthOffset, lpStringTable, (HPBYTE)"Lower"))
            bLower = TRUE;
         if(bUpper && bLower)  // go for it!
         {

            lpPrinterInfo->devcaps.MixedBins = numEntries ;
            //  index of MixedBins option.

                                                    /* "Mixed Bins"         */
            LoadString(ghDriverMod, ID_PPDSTR_MIXEDBINS, Buffer, sizeof(Buffer));
            lpInputSlotInfo[numEntries].OptionKey.dword =
                        addStringToTable(Buffer);

            lpInputSlotInfo[numEntries].OptionTranslation.dword = 0L ;
            lpInputSlotInfo[numEntries].Invocation.dword = 0L ;   // no command - its driver implemented!
            lpExtraInputSlotInfo[numEntries].ReqsPageRegion = FALSE ;  // not applicable
            setSlotID(lpInputSlotInfo[numEntries].OptionKey,
                        lpExtraInputSlotInfo + numEntries, &undefinedID);
            numEntries++ ;     //  MixedBins is another inputslot

            break;
         }
      }
   }

#endif

   lpInputSlotInfoHdr->OptionKeyWords.w.length = numEntries ;
   lpInputSlotInfoHdr->DefaultOptionIndex = 0 ;


   // I feel the driver should always select AutoSelect if availible.

   if(numEntries == 0  ||  bAutoSelect)
      goto   endInputSlot;

   // ---  set default inputslot here. ---  init to first slot.

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == DEFAULTINPUTSLOT)
         break;  //   scan for this keyword.  stop at first occurance
   }

   //  if no default found use the default-default: the entry[0]!
   if(i >= numKeywords)
      goto    endInputSlot;

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITINPUTSLOTINFO, ERR_DEFAULTINPUTSLOT);
      errorMsg(INITINPUTSLOTINFO, ERR_KEYWORD_HAS_NO_VALUE);
      goto   endInputSlot;  // select this line --or--
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITINPUTSLOTINFO, ERR_DEFAULTINPUTSLOT);
      errorMsg(INITINPUTSLOTINFO, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto   endInputSlot;   //  for non fatal errors
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf);

   for(j = firstInputSlot ; j < numEntries ; j++)
   {
      lengthOffset = lpInputSlotInfo[j].OptionKey.dword ;
      if(!strtblcmp(lengthOffset, lpStringTable, lpBuf))
      {
         lpInputSlotInfoHdr->DefaultOptionIndex = j ;
         break;
      }
   }


endInputSlot:
   return(TRUE);
}





BOOL  NEAR   PARSE1SEG PASCAL  initInstalledMemoryInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable )
{
   // -------- parse  INSTALLEDMEMORY  entries -------


   WORD  i, j, numEntries, lengthOptions, numFontCacheEntries;
   DWORD  lengthOffset, lvalue  ;
   LPMAINKEYHDR  lpInstalledMemoryInfoHdr ;
   LPMEMORYINFO   lpExtraMemoryInfo ;
   LPGENERIC_OPTION   lpInstalledMemoryInfo ;
   HPBYTE   hpCur ;
   BOOL bNoDefault= FALSE;
   BYTE   Buffer[256];  // holds string value for parsing into tokens
   LPBYTE  lpBuf;      // scratch pointers.

   lpInstalledMemoryInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_MEMORYINFO ;
   if (!(lengthOptions = lpInstalledMemoryInfoHdr->OptionKeyWords.w.length))
        goto endInstalledMemory;            // array bounds check

   //  eventually to be performed by OpenUI parser.
   if(!lpInstalledMemoryInfoHdr->MainKey.dword)
   {
      lpInstalledMemoryInfoHdr->MainKeyID = VMOPTION;
      lpInstalledMemoryInfoHdr->MainKey.dword = lpMainKeyWordsTable[VMOPTION].dword ;
      lpInstalledMemoryInfoHdr->MainTranslation.dword = 0L ;
   }

   lpInstalledMemoryInfoHdr->UItype = PICKONE ;   // not actually used by UI code

   lpInstalledMemoryInfoHdr->OptionQuery.dword = 0L ;



   lpExtraMemoryInfo = (LPMEMORYINFO)MAKELONG(
       lpInstalledMemoryInfoHdr->extraOptionArray, HIWORD(lpOptionsBlock) );

   lpInstalledMemoryInfo = (LPGENERIC_OPTION)MAKELONG(
       lpInstalledMemoryInfoHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

   //  remove redundant InstalledMemory options
   //  get all the info from VMOPTION except translation strings

   numEntries = 0 ;
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword != VMOPTION)
         continue ;   //  should drop to end of for loop.
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      for(j = 0 ; j < numEntries ; j++)
      {
         lengthOffset = lpInstalledMemoryInfo[j].OptionKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, hpCur))
            break;
      }
      if(j < numEntries)
         continue;   //  this entry has already been added.

      lpInstalledMemoryInfo[numEntries].OptionKey.dword =
                  addStringToTable(hpCur);

      lpInstalledMemoryInfo[numEntries].OptionTranslation.dword =
         addTransStringToTable(lpKeyEntry[i].optionTrans) ;

      //  value is amount of free VM
      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITINSTALLEDMEMORYINFO, ERR_INSTALLEDMEMORY);
         errorMsg(INITINSTALLEDMEMORYINFO, ERR_KEYWORD_HAS_NO_VALUE);
         continue ;   //  should drop to end of for loop.
      }
      if(!(lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITINSTALLEDMEMORYINFO, ERR_INSTALLEDMEMORY);
         errorMsg(INITINSTALLEDMEMORYINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
         errorString(hpCur);
         continue ;   //  should drop to end of for loop.
      }

      lpInstalledMemoryInfo[numEntries].Invocation.dword = 0L ;


      if(convStrToInt(&lvalue, hpCur, -3))
         lpExtraMemoryInfo[numEntries].AvailibleVM = lvalue;
      else
         lpExtraMemoryInfo[numEntries].AvailibleVM =
            lpPrinterInfo->devcaps.iFreeVM ;  // Default.

      numEntries++  ;
   }  //  went through every  INSTALLEDMEMORY entry.


   //  get keyword translation string from the INSTALLEDMEMORY
   for(i = 0 ; i < numKeywords ; i++)
   {
      if((hpCur = lpKeyEntry[i].option) && !hstrcmp("*InstalledMemory", hpCur))
      {
         lpInstalledMemoryInfoHdr->MainTranslation.dword =
               addTransStringToTable(lpKeyEntry[i].optionTrans) ;
         break;
      }

   }  //  went through every  INSTALLEDMEMORY entry.

   //  get options translation strings from the INSTALLEDMEMORY
   numEntries = 0 ;
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword != INSTALLEDMEMORY)
         continue ;   //  should drop to end of for loop.
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      for(j = 0 ; j < numEntries ; j++)
      {
         lengthOffset = lpInstalledMemoryInfo[j].OptionKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, hpCur))
            break;
      }
      if(j < numEntries)
         continue;                     // this entry has already been added.

      if (numEntries > lengthOptions)  // array bounds check
         break;
      lpInstalledMemoryInfo[numEntries].OptionTranslation.dword =
         addTransStringToTable(lpKeyEntry[i].optionTrans) ;

      numEntries++  ;
   }  //  went through every  INSTALLEDMEMORY entry.


   lpInstalledMemoryInfoHdr->OptionKeyWords.w.length = numEntries ;
   lpInstalledMemoryInfoHdr->DefaultOptionIndex = 0 ;


   // ---  set default installedmemory here. ---  init to first entry.

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == DEFAULTINSTALLEDMEMORY)
         break;  //   scan for this keyword.  stop at first occurance
   }

   //  if no default found use the default-default: the entry[0]!
   if(i >= numKeywords)
   {
      bNoDefault = TRUE;
      goto FontCache;
   }

    // get DefaultInstalledmemory value

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITINPUTSLOTINFO, ERR_INSTALLEDMEMORY);
      errorMsg(INITINPUTSLOTINFO, ERR_KEYWORD_HAS_NO_VALUE);
      bNoDefault = TRUE;
      goto FontCache;
   }

   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf);

   for(j = 0 ; j < numEntries ; j++)
   {
      lengthOffset = lpInstalledMemoryInfo[j].OptionKey.dword ;
      if(!strtblcmp(lengthOffset, lpStringTable, lpBuf))
      {
         lpInstalledMemoryInfoHdr->DefaultOptionIndex = j ;
         break;
      }
   }


FontCache:
   // Went through every FCacheSize entry, store into lpExtraMemoryInfo

   numFontCacheEntries = 0 ;
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword != FONTCACHESIZE)
         continue ;   //  should drop to end of for loop.
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      //  value is amount of available Fontcache
      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITINSTALLEDMEMORYINFO, ERR_INSTALLEDMEMORY);
         errorMsg(INITINSTALLEDMEMORYINFO, ERR_KEYWORD_HAS_NO_VALUE);
         continue ;   //  should drop to end of for loop.
      }
      // FontCacheSize

      if(convStrToInt(&lvalue, hpCur, -3))
         lpExtraMemoryInfo[numFontCacheEntries].AvailibleFC = (WORD)lvalue;
      else
         lpExtraMemoryInfo[numFontCacheEntries].AvailibleFC = (WORD)0;

      numFontCacheEntries++  ;

   }  //  went through every  FCacheSize entry.

   // ---  set default VMoption here. ---


   //  if no default found use the default-default: the entry[0]!
   if(i >= numKeywords)
      goto    endInstalledMemory;

   for(j = 0 ; j < numEntries ; j++)
   {
      if(lpExtraMemoryInfo[j].AvailibleVM ==
            lpPrinterInfo->devcaps.iFreeVM)
      {
         if (bNoDefault)
            lpInstalledMemoryInfoHdr->DefaultOptionIndex = j ;
         // use the FreeVM entry as corresponded fontCache default
         if (lpPrinterInfo->devcaps.bFontCacheSize && lpExtraMemoryInfo[j].AvailibleFC > 0)
             lpPrinterInfo->devcaps.iFontCacheSize =
                            lpExtraMemoryInfo[j].AvailibleFC;
         break;
      }
   }


endInstalledMemory:
   return(TRUE);
}



BOOL  NEAR    PARSE1SEG PASCAL  initDuplexingInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock  )
{
   WORD  i ;
   LPMAINKEYHDR  lpDuplexingInfoHdr ;
   LPGENERIC_OPTION   lpDuplexingInfo ;
   HPBYTE   hpCur ;

   //  duplex support
   //  First set default values:

   lpDuplexingInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_DUPLEXINGINFO ;

   //  eventually to be performed by OpenUI parser.
   if(!lpDuplexingInfoHdr->MainKey.dword)
   {
      lpDuplexingInfoHdr->MainKeyID = DUPLEX;
      lpDuplexingInfoHdr->MainKey.dword = lpMainKeyWordsTable[DUPLEX].dword ;
      lpDuplexingInfoHdr->MainTranslation.dword = 0L ;
   }

   lpDuplexingInfoHdr->UItype = PICKONE ;   // not actually used by UI code

   lpDuplexingInfoHdr->OptionQuery.dword = 0L ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == Q_DUPLEX)
      {
         lpDuplexingInfoHdr->OptionQuery.dword =
            addStringToTable(lpKeyEntry[i].value);  // invocations are
         break;                                    // simple strings
      }
   }

   lpPrinterInfo->devcaps.SupportsDuplexing = FALSE ;


   lpDuplexingInfo = (LPGENERIC_OPTION)MAKELONG(
       lpDuplexingInfoHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );



   lpDuplexingInfo[DUPLEX_NONE].Invocation.dword = 0L ;
   lpDuplexingInfo[SIMPLEXTUMBLE].Invocation.dword = 0L ;
   lpDuplexingInfo[DUPLEXTUMBLE].Invocation.dword = 0L ;
   lpDuplexingInfo[DUPLEXNOTUMBLE].Invocation.dword = 0L ;


   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == DUPLEX  &&
               (hpCur = lpKeyEntry[i].option) &&
               !(hstrcmp("None", hpCur)  &&  hstrcmp("False", hpCur)  &&
               hstrcmp("SimplexNoTumble", hpCur)))
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto   GetDuplexTumbleInfo;   //  for non fatal errors

   //  store option name
   lpDuplexingInfo[DUPLEX_NONE].OptionKey.dword =
         addStringToTable(lpKeyEntry[i].option);

   lpDuplexingInfo[DUPLEX_NONE].OptionTranslation.dword =
        addTransStringToTable(lpKeyEntry[i].optionTrans) ;


   //  value is Invocation string
   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITDUPLEXINGINFO, ERR_DUPLEX_NONE);
      errorMsg(INITDUPLEXINGINFO, ERR_KEYWORD_HAS_NO_INVC_VALUE);
      goto   GetDuplexTumbleInfo;   //  for non fatal errors
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITDUPLEXINGINFO, ERR_DUPLEX_NONE);
      errorMsg(INITDUPLEXINGINFO, ERR_EXPCTD_INVOCATN_NOT_STRING);
      errorString(hpCur);
      goto   GetDuplexTumbleInfo;   //  for non fatal errors
   }

   lpDuplexingInfo[DUPLEX_NONE].Invocation.dword =
                           addStringToTable(hpCur);

GetDuplexTumbleInfo:

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == DUPLEX  &&
               (hpCur = lpKeyEntry[i].option) &&
               !hstrcmp("DuplexTumble", hpCur))
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto   GetDuplexNoTumbleInfo;   //  for non fatal errors


   //  store option name
   lpDuplexingInfo[DUPLEXTUMBLE].OptionKey.dword =
         addStringToTable(lpKeyEntry[i].option);

   lpDuplexingInfo[DUPLEXTUMBLE].OptionTranslation.dword =
        addTransStringToTable(lpKeyEntry[i].optionTrans) ;

   //  value is Invocation string
   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITDUPLEXINGINFO, ERR_DUPLEX_DUPLEXTUMBLE);
      errorMsg(INITDUPLEXINGINFO, ERR_KEYWORD_HAS_NO_INVC_VALUE);
      goto   GetDuplexNoTumbleInfo;   //  for non fatal errors
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITDUPLEXINGINFO, ERR_DUPLEX_DUPLEXTUMBLE);
      errorMsg(INITDUPLEXINGINFO, ERR_EXPCTD_INVOCATN_NOT_STRING);
      errorString(hpCur);
      goto   GetDuplexNoTumbleInfo;   //  for non fatal errors
   }

   lpDuplexingInfo[DUPLEXTUMBLE].Invocation.dword =
                           addStringToTable(hpCur);

   lpPrinterInfo->devcaps.SupportsDuplexing = TRUE ;

GetDuplexNoTumbleInfo:


   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == DUPLEX  &&
               (hpCur = lpKeyEntry[i].option) &&
               !hstrcmp("DuplexNoTumble", hpCur))
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto   GetSimplexTumbleInfo;   //  for non fatal errors


   //  store option name
   lpDuplexingInfo[DUPLEXNOTUMBLE].OptionKey.dword =
         addStringToTable(lpKeyEntry[i].option);

   lpDuplexingInfo[DUPLEXNOTUMBLE].OptionTranslation.dword =
        addTransStringToTable(lpKeyEntry[i].optionTrans) ;

   //  value is Invocation string
   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITDUPLEXINGINFO, ERR_DUPLEX_DUPLEXNOTUMBLE);
      errorMsg(INITDUPLEXINGINFO, ERR_KEYWORD_HAS_NO_INVC_VALUE);
      goto   GetSimplexTumbleInfo;   //  for non fatal errors
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITDUPLEXINGINFO, ERR_DUPLEX_DUPLEXNOTUMBLE);
      errorMsg(INITDUPLEXINGINFO, ERR_EXPCTD_INVOCATN_NOT_STRING);
      errorString(hpCur);
      goto   GetSimplexTumbleInfo;   //  for non fatal errors
   }

   lpDuplexingInfo[DUPLEXNOTUMBLE].Invocation.dword =
                           addStringToTable(hpCur);

   lpPrinterInfo->devcaps.SupportsDuplexing = TRUE ;


GetSimplexTumbleInfo:


   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == DUPLEX  &&
               (hpCur = lpKeyEntry[i].option) &&
               !hstrcmp("SimplexTumble", hpCur))
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto   endGetDuplexInfo;   //  for non fatal errors


   //  store option name
   lpDuplexingInfo[SIMPLEXTUMBLE].OptionKey.dword =
         addStringToTable(lpKeyEntry[i].option);

   lpDuplexingInfo[SIMPLEXTUMBLE].OptionTranslation.dword =
        addTransStringToTable(lpKeyEntry[i].optionTrans) ;

   //  value is Invocation string
   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITDUPLEXINGINFO, ERR_DUPLEX_SIMPLEXTUMBLE);
      errorMsg(INITDUPLEXINGINFO, ERR_KEYWORD_HAS_NO_INVC_VALUE);
      goto   endGetDuplexInfo;   //  for non fatal errors
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITDUPLEXINGINFO, ERR_DUPLEX_SIMPLEXTUMBLE);
      errorMsg(INITDUPLEXINGINFO, ERR_EXPCTD_INVOCATN_NOT_STRING);
      errorString(hpCur);
      goto   endGetDuplexInfo;   //  for non fatal errors
   }

   lpDuplexingInfo[SIMPLEXTUMBLE].Invocation.dword =
                           addStringToTable(hpCur);



endGetDuplexInfo:

   lpDuplexingInfoHdr->DefaultOptionIndex = 0 ;

   //  parser selects the default mode not PPD file.

   if(lpPrinterInfo->devcaps.SupportsDuplexing)
   {
      for(i = 0 ; i < NUM_DUPLEX_MODES ; i++)
      {
         if (lpDuplexingInfo[i].Invocation.w.length)
         {
            lpDuplexingInfoHdr->DefaultOptionIndex = i ;
            break ;
         }
      }
   }

   return(TRUE) ;
}


BOOL  NEAR    PARSE1SEG PASCAL  initCollationInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock  )
{
   WORD  i ;
   LPMAINKEYHDR  lpCollationInfoHdr ;
   LPGENERIC_OPTION   lpCollationInfo ;
   HPBYTE   hpCur ;

   //  duplex support
   //  First set default values:

   lpCollationInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_COLLATIONINFO ;

   //  eventually to be performed by OpenUI parser.
   if(!lpCollationInfoHdr->MainKey.dword)
   {
      lpCollationInfoHdr->MainKeyID = COLLATE;
      lpCollationInfoHdr->MainKey.dword = lpMainKeyWordsTable[COLLATE].dword ;
      lpCollationInfoHdr->MainTranslation.dword = 0L ;
   }

   lpCollationInfoHdr->UItype = PICKONE ;   // not actually used by UI code

   lpCollationInfoHdr->OptionQuery.dword = 0L ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == Q_COLLATE)
      {
         lpCollationInfoHdr->OptionQuery.dword =
            addStringToTable(lpKeyEntry[i].value);  // invocations are
         break;                                    // simple strings
      }
   }

   lpPrinterInfo->devcaps.bCollateSupport = FALSE ;


   lpCollationInfo = (LPGENERIC_OPTION)MAKELONG(
       lpCollationInfoHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );



   lpCollationInfo[COLLATE_TRUE].Invocation.dword = 0L ;
   lpCollationInfo[COLLATE_FALSE].Invocation.dword = 0L ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == COLLATE  &&
               (hpCur = lpKeyEntry[i].option) &&
               !hstrcmp("True", hpCur))
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto   GetCollateFalseInfo;   //  for non fatal errors

   //  store option name
   lpCollationInfo[COLLATE_TRUE].OptionKey.dword =
         addStringToTable(lpKeyEntry[i].option);

   lpCollationInfo[COLLATE_TRUE].OptionTranslation.dword =
        addTransStringToTable(lpKeyEntry[i].optionTrans) ;


   //  value is Invocation string
   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITCOLLATIONINFO, ERR_COLLATE_TRUE);
      errorMsg(INITCOLLATIONINFO, ERR_KEYWORD_HAS_NO_INVC_VALUE);
      goto   GetCollateFalseInfo;   //  for non fatal errors
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITCOLLATIONINFO, ERR_COLLATE_TRUE);
      errorMsg(INITCOLLATIONINFO, ERR_EXPCTD_INVOCATN_NOT_STRING);
      errorString(hpCur);
      goto   GetCollateFalseInfo;   //  for non fatal errors
   }

   lpCollationInfo[COLLATE_TRUE].Invocation.dword =
                           addStringToTable(hpCur);

   lpPrinterInfo->devcaps.bCollateSupport = TRUE;

GetCollateFalseInfo:

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == COLLATE  &&
               (hpCur = lpKeyEntry[i].option) &&
               !hstrcmp("False", hpCur))
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto   endGetCollateInfo;   //  for non fatal errors


   //  store option name
   lpCollationInfo[COLLATE_FALSE].OptionKey.dword =
         addStringToTable(lpKeyEntry[i].option);

   lpCollationInfo[COLLATE_FALSE].OptionTranslation.dword =
        addTransStringToTable(lpKeyEntry[i].optionTrans) ;

   //  value is Invocation string
   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITCOLLATIONINFO, ERR_COLLATE_FALSE);
      errorMsg(INITCOLLATIONINFO, ERR_KEYWORD_HAS_NO_INVC_VALUE);
      goto   endGetCollateInfo;   //  for non fatal errors
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITCOLLATIONINFO, ERR_COLLATE_FALSE);
      errorMsg(INITCOLLATIONINFO, ERR_EXPCTD_INVOCATN_NOT_STRING);
      errorString(hpCur);
      goto   endGetCollateInfo;   //  for non fatal errors
   }

   lpCollationInfo[COLLATE_FALSE].Invocation.dword =
                           addStringToTable(hpCur);

endGetCollateInfo:

   lpCollationInfoHdr->DefaultOptionIndex = COLLATE_FALSE ;

   //  parser selects the default mode not PPD file.

   if(lpPrinterInfo->devcaps.bCollateSupport)
   {
      for(i = 0 ; i < NUM_COLLATE_MODES ; i++)
      {
         if (lpCollationInfo[i].Invocation.w.length)
         {
            lpCollationInfoHdr->DefaultOptionIndex = i ;
            break ;
         }
      }
   }

   return(TRUE) ;
}

BOOL  NEAR    PARSE1SEG PASCAL  initOutputOrderInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock,
LPBYTE lpStringTable   )
{
   WORD  i ;
   LPMAINKEYHDR  lpOutputOrderInfoHdr ;
   LPGENERIC_OPTION   lpOutputOrderInfo ;
   HPBYTE   hpCur ;
   BYTE   Buffer[256];  // holds string value for parsing into tokens
   LPBYTE  lpBuf;      // scratch pointers.
   DWORD  lengthOffset ;

   //  outputorder support
   //  First set default values:

   lpOutputOrderInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_OUTPUTORDERINFO ;

   //  eventually to be performed by OpenUI parser.
   if(!lpOutputOrderInfoHdr->MainKey.dword)
   {
      lpOutputOrderInfoHdr->MainKeyID = OUTPUTORDER;
      lpOutputOrderInfoHdr->MainKey.dword = lpMainKeyWordsTable[OUTPUTORDER].dword ;
      lpOutputOrderInfoHdr->MainTranslation.dword = 0L ;
   }

   lpOutputOrderInfoHdr->UItype = PICKONE ;   // not actually used by UI code

   lpOutputOrderInfoHdr->OptionQuery.dword = 0L ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == Q_OUTPUTORDER)
      {
         lpOutputOrderInfoHdr->OptionQuery.dword =
            addStringToTable(lpKeyEntry[i].value);  // invocations are
         break;                                    // simple strings
      }
   }

   lpPrinterInfo->devcaps.bOutputOrderSupport = FALSE ;


   lpOutputOrderInfo = (LPGENERIC_OPTION)MAKELONG(
       lpOutputOrderInfoHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );



   lpOutputOrderInfo[OUTPUTORDER_NORMAL].Invocation.dword = 0L ;
   lpOutputOrderInfo[OUTPUTORDER_REVERSE].Invocation.dword = 0L ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == OUTPUTORDER  &&
               (hpCur = lpKeyEntry[i].option) &&
               !hstrcmp("Normal", hpCur))
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto   GetOutputOrderReverseInfo;   //  for non fatal errors

   //  store option name
   lpOutputOrderInfo[OUTPUTORDER_NORMAL].OptionKey.dword =
         addStringToTable(lpKeyEntry[i].option);

   lpOutputOrderInfo[OUTPUTORDER_NORMAL].OptionTranslation.dword =
        addTransStringToTable(lpKeyEntry[i].optionTrans) ;

   //  value is Invocation string
   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITOUTPUTORDERINFO, ERR_OUTPUTORDER_NORMAL);
      errorMsg(INITOUTPUTORDERINFO, ERR_KEYWORD_HAS_NO_INVC_VALUE);
      goto   GetOutputOrderReverseInfo;   //  for non fatal errors
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITOUTPUTORDERINFO, ERR_OUTPUTORDER_NORMAL);
      errorMsg(INITOUTPUTORDERINFO, ERR_EXPCTD_INVOCATN_NOT_STRING);
      errorString(hpCur);
      goto   GetOutputOrderReverseInfo;   //  for non fatal errors
   }

   lpOutputOrderInfo[OUTPUTORDER_NORMAL].Invocation.dword =
                           addStringToTable(hpCur);

   lpPrinterInfo->devcaps.bOutputOrderSupport = TRUE ;

GetOutputOrderReverseInfo:

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == OUTPUTORDER  &&
               (hpCur = lpKeyEntry[i].option) &&
               !hstrcmp("Reverse", hpCur))
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto   GetDefaultOutputOrderInfo;   //  for non fatal errors


   //  store option name
   lpOutputOrderInfo[OUTPUTORDER_REVERSE].OptionKey.dword =
         addStringToTable(lpKeyEntry[i].option);

   lpOutputOrderInfo[OUTPUTORDER_REVERSE].OptionTranslation.dword =
        addTransStringToTable(lpKeyEntry[i].optionTrans) ;

   //  value is Invocation string
   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITOUTPUTORDERINFO, ERR_OUTPUTORDER_REVERSE);
      errorMsg(INITOUTPUTORDERINFO, ERR_KEYWORD_HAS_NO_INVC_VALUE);
      goto   GetDefaultOutputOrderInfo;   //  for non fatal errors
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITOUTPUTORDERINFO, ERR_OUTPUTORDER_REVERSE);
      errorMsg(INITOUTPUTORDERINFO, ERR_EXPCTD_INVOCATN_NOT_STRING);
      errorString(hpCur);
      goto   GetDefaultOutputOrderInfo;   //  for non fatal errors
   }

   lpOutputOrderInfo[OUTPUTORDER_REVERSE].Invocation.dword =
                           addStringToTable(hpCur);

   lpPrinterInfo->devcaps.bOutputOrderSupport = TRUE ;

GetDefaultOutputOrderInfo:

   lpOutputOrderInfoHdr->DefaultOptionIndex = OUTPUTORDER_NORMAL;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == DEFAULTOUTPUTORDER)
      break;  //   scan for this keyword.  stop at first occurance
   }

   if(i >= numKeywords)
   goto    endGetOutputOrderInfo;

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITOUTPUTORDERINFO, ERR_DEFAULTOUTPUTORDER);
      errorMsg(INITOUTPUTORDERINFO, ERR_KEYWORD_HAS_NO_VALUE);
      goto    endGetOutputOrderInfo;
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITOUTPUTORDERINFO, ERR_DEFAULTOUTPUTORDER);
      errorMsg(INITOUTPUTORDERINFO, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto    endGetOutputOrderInfo;
   }

   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf);

   if( lpPrinterInfo->devcaps.bOutputOrderSupport )
   {
      for(i = 0 ; i < NUM_OUTPUTORDER_MODES ; i++)
      {
         lengthOffset = lpOutputOrderInfo[i].OptionKey.dword;
         if(!strtblcmp(lengthOffset, lpStringTable, lpBuf))
         {
            lpOutputOrderInfoHdr->DefaultOptionIndex = i;
            break;
         }
      }
   }
   else if( !lstrcmp( lpBuf, "Reverse" ) )
     lpOutputOrderInfoHdr->DefaultOptionIndex = OUTPUTORDER_REVERSE;

endGetOutputOrderInfo:
   return(TRUE) ;
}

BOOL  NEAR    PARSE1SEG PASCAL  initResolutionInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock)
{
   WORD  i, j, numEntries ;
   DWORD  dwScratch ;
   LPMAINKEYHDR  lpResolutionInfoHdr ;
   LPRESOLUTIONINFO   lpExtraResolutionInfo ;
   LPGENERIC_OPTION   lpResolutionInfo ;
   HPBYTE   hpCur ;
   BYTE   Buffer[256];  // holds string value for parsing into tokens

// ------ extract Resolution info ------

   lpResolutionInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_RESOLUTIONINFO ;

   //  eventually to be performed by OpenUI parser.
   if(!lpResolutionInfoHdr->MainKey.dword)
   {
      lpResolutionInfoHdr->MainKeyID = RESOLUTION;
      lpResolutionInfoHdr->MainKey.dword = lpMainKeyWordsTable[RESOLUTION].dword ;
      lpResolutionInfoHdr->MainTranslation.dword = 0L ;
      lpResolutionInfoHdr->flags = 0;
   }

   lpResolutionInfoHdr->UItype = PICKONE ;   // not actually used by UI code

   lpResolutionInfoHdr->OptionQuery.dword = 0L ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == Q_RESOLUTION   ||
            lpKeyEntry[i].keyword == Q_JCLRESOLUTION)
      {
         if(lpKeyEntry[i].flags & JCLKEYWORD)
            lpResolutionInfoHdr->OptionQuery.dword =
               addQuotedStringToTable(lpKeyEntry[i].value, NULL, 0);
         else
            lpResolutionInfoHdr->OptionQuery.dword =
               addStringToTable(lpKeyEntry[i].value);  // invocations are
         break;                                    // simple strings
      }
   }

   lpExtraResolutionInfo = (LPRESOLUTIONINFO)MAKELONG(
       lpResolutionInfoHdr->extraOptionArray, HIWORD(lpOptionsBlock) );
   lpResolutionInfo = (LPGENERIC_OPTION)MAKELONG(
       lpResolutionInfoHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );


   for(numEntries = i = 0 ; i < numKeywords ; i++)
   {
      WORD  keyword ;
      DWORD  dwScratch ;

      keyword = (bUseSetResolution) ? SETRESOLUTION : RESOLUTION ;

      if(lpKeyEntry[i].keyword != keyword  &&
            lpKeyEntry[i].keyword != JCLRESOLUTION)
         continue ;   //  should drop to end of for loop.
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      dwScratch = extractResolution(hpCur);

      for(j = 0 ; (j < numEntries) &&
               (dwScratch != lpExtraResolutionInfo[j].res.dword) ; j++)
         ;
      if(j < numEntries)
         continue;   //  this entry has already been added.

      lpExtraResolutionInfo[numEntries].res.dword = dwScratch ;
            // non-destructive read

      if(!lpExtraResolutionInfo[numEntries].res.dword)
      {
         errorMsg(INITRESOLUTIONINFO, ERR_SETRESOLUTION);
         errorMsg(INITRESOLUTIONINFO, ERR_PARSING_OPTION);
         errorString(hpCur);
         continue ;   //  should drop to end of for loop.
      }

      //  init all Halftone parameters to this until new PPD
      //  entries are found which override.
      lpExtraResolutionInfo[numEntries].ScreenFreq = ScreenFreq ;
      lpExtraResolutionInfo[numEntries].ScreenAngle = ScreenAngle ;

      lpResolutionInfo[numEntries].OptionKey.dword =
         addStringToTable(lpKeyEntry[i].option);

      lpResolutionInfo[numEntries].OptionTranslation.dword =
         addTransStringToTable(lpKeyEntry[i].optionTrans) ;


      if(bUseSetResolution)    // NULL string - don't use this command.
         lpResolutionInfo[numEntries].Invocation.dword = 0L ;
      else
      {
         //  value is Invocation string
         hpCur = lpKeyEntry[i].value;
         if(!hpCur)
         {
            errorMsg(INITRESOLUTIONINFO, ERR_RESOLUTION);
            errorMsg(INITRESOLUTIONINFO, ERR_KEYWORD_HAS_NO_VALUE);
            continue ;   //  should drop to end of for loop.
         }
         if(!(lpKeyEntry[i].bValueQuoted))
         {
            errorMsg(INITRESOLUTIONINFO, ERR_RESOLUTION);
            errorMsg(INITRESOLUTIONINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
            errorString(hpCur);
            continue ;   //  should drop to end of for loop.
         }
         if(lpKeyEntry[i].flags & JCLKEYWORD)
            lpResolutionInfo[numEntries].Invocation.dword =
               addQuotedStringToTable(hpCur, NULL, 0);
         else
            lpResolutionInfo[numEntries].Invocation.dword =
               addStringToTable(hpCur);
         if(lpKeyEntry[i].keyword == JCLRESOLUTION)
         {
            lpResolutionInfoHdr->MainKeyID = JCLRESOLUTION;
            lpResolutionInfoHdr->MainKey.dword = lpMainKeyWordsTable[JCLRESOLUTION].dword ;
         }
         lpResolutionInfoHdr->flags |= lpKeyEntry[i].flags;
      }

      numEntries++  ;
   }  //  went through every  RESOLUTION entry.

   for(i = numKeywords ; i ; )
   {
      DWORD  dwScratch, lvalue ;

      i-- ;  //  work our way backwards so first entry
            //  overwrites any others.

      if(lpKeyEntry[i].keyword != SCREENFREQRES)
         continue ;
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      dwScratch = extractResolution(hpCur);

      for(j = 0 ; (j < numEntries) &&
               (dwScratch != lpExtraResolutionInfo[j].res.dword) ; j++)
         ;

      if(j >= numEntries)
         continue;   //  doesn't match any of the recorded entries

      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITRESOLUTIONINFO, ERR_SCREENFREQRES);
         errorMsg(INITRESOLUTIONINFO, ERR_KEYWORD_HAS_NO_VALUE);
         continue ;   //  should drop to end of for loop.
      }
      if(!(lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITRESOLUTIONINFO, ERR_SCREENFREQRES);
         errorMsg(INITRESOLUTIONINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
         errorString(hpCur);
         continue ;   //  should drop to end of for loop.
      }
      if(convStrToInt(&lvalue, hpCur, 1))     //  read tenths
         lpExtraResolutionInfo[j].ScreenFreq = (DWORD)lvalue;
      else
      {
         errorMsg(INITRESOLUTIONINFO, ERR_SCREENFREQRES);
         errorMsg(INITRESOLUTIONINFO, ERR_CONV_STRING_TO_DECIMAL);
         errorString(hpCur);
      }

   }


   for(i = numKeywords ; i ; )
   {
      DWORD  dwScratch, lvalue ;

      i-- ;  //  work our way backwards so first entry
            //  overwrites any others.

      if(lpKeyEntry[i].keyword != SCREENANGLERES)
         continue ;
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      dwScratch = extractResolution(hpCur);

      for(j = 0 ; (j < numEntries) &&
               (dwScratch != lpExtraResolutionInfo[j].res.dword) ; j++)
         ;

      if(j >= numEntries)
         continue;   //  doesn't match any of the recorded entries

      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITRESOLUTIONINFO, ERR_SCREENANGLERES);
         errorMsg(INITRESOLUTIONINFO, ERR_KEYWORD_HAS_NO_VALUE);
         continue ;   //  should drop to end of for loop.
      }
      if(!(lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITRESOLUTIONINFO, ERR_SCREENANGLERES);
         errorMsg(INITRESOLUTIONINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
         errorString(hpCur);
         continue ;   //  should drop to end of for loop.
      }
      if(convStrToInt(&lvalue, hpCur, 1))     //  read tenths
         lpExtraResolutionInfo[j].ScreenAngle = (DWORD)lvalue;
      else
      {
         errorMsg(INITRESOLUTIONINFO, ERR_SCREENANGLERES);
         errorMsg(INITRESOLUTIONINFO, ERR_CONV_STRING_TO_DECIMAL);
         errorString(hpCur);
      }

   }

   //  select a default resolution.

   lpResolutionInfoHdr->DefaultOptionIndex = 0 ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == DEFAULTRESOLUTION  ||
            lpKeyEntry[i].keyword == DEFAULTJCLRESOLUTION)
         break;  //   scan for this keyword.  stop at first occurance
   }

   if(i >= numKeywords)
      goto    checkResolutionCount;

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITRESOLUTIONINFO, ERR_DEFAULTRESOLUTION);
      errorMsg(INITRESOLUTIONINFO, ERR_KEYWORD_HAS_NO_VALUE);
      goto    checkResolutionCount;
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITRESOLUTIONINFO, ERR_DEFAULTRESOLUTION);
      errorMsg(INITRESOLUTIONINFO, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto    checkResolutionCount;
   }

   dwScratch = extractResolution(hpCur);

   for(j = 0 ; j < numEntries; j++)
   {
      if(lpExtraResolutionInfo[j].res.dword == dwScratch)
      {
         lpResolutionInfoHdr->DefaultOptionIndex = j ;
         break;
      }
   }
   if(!numEntries  &&  dwScratch)  //  defaultRes keyword defines the resolution
   {
      lpResolutionInfo[0].OptionKey.dword =
         addStringToTable(hpCur);

      lpResolutionInfo[0].OptionTranslation.dword = 0L ;

      lpExtraResolutionInfo[0].res.dword = dwScratch ;
      lpResolutionInfo[0].Invocation.dword = 0L ;
      lpExtraResolutionInfo[0].ScreenFreq = ScreenFreq ;
      lpExtraResolutionInfo[0].ScreenAngle = ScreenAngle ;
      numEntries = 1;
   }

checkResolutionCount:

   if(!numEntries)
   {
                                                /* "300dpi I think"         */
      LoadString(ghDriverMod, ID_PPDSTR_300DPIITHINK, Buffer, sizeof(Buffer));
      lpResolutionInfo[0].OptionKey.dword = addStringToTable(Buffer);

      lpResolutionInfo[0].OptionTranslation.dword = 0L ;

      lpExtraResolutionInfo[0].res.word.x =
      lpExtraResolutionInfo[0].res.word.y = 300 ; //  assume a default res.
      lpResolutionInfo[0].Invocation.dword = 0L ;
      lpExtraResolutionInfo[0].ScreenFreq = ScreenFreq ;
      lpExtraResolutionInfo[0].ScreenAngle = ScreenAngle ;
      numEntries = 1;
   }

   lpResolutionInfoHdr->OptionKeyWords.w.length = numEntries ;

   return(TRUE) ;
}



BOOL  NEAR    PARSE1SEG PASCAL  initOutputBinInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable )
{
   WORD  i, j, numEntries ;
   DWORD  lengthOffset ;
   LPMAINKEYHDR  lpOutputBinInfoHdr ;
   LPGENERIC_OPTION   lpOutputBinInfo ;
   BYTE   Buffer[256];  // holds string value for parsing into tokens
   HPBYTE   hpCur ;
   LPBYTE  lpBuf;      // scratch pointers.




   // -------- parse  OUTPUTBIN  entries -------


   lpOutputBinInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_OUTPUTBININFO ;

   //  eventually to be performed by OpenUI parser.
   if(!lpOutputBinInfoHdr->MainKey.dword)
   {
      lpOutputBinInfoHdr->MainKeyID = OUTPUTBIN;
      lpOutputBinInfoHdr->MainKey.dword = lpMainKeyWordsTable[OUTPUTBIN].dword ;
      lpOutputBinInfoHdr->MainTranslation.dword = 0L ;
   }

   lpOutputBinInfoHdr->UItype = PICKONE ;   // not actually used by UI code

   lpOutputBinInfoHdr->OptionQuery.dword = 0L ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == Q_OUTPUTBIN)
      {
         lpOutputBinInfoHdr->OptionQuery.dword =
            addStringToTable(lpKeyEntry[i].value);  // invocations are
         break;                                    // simple strings
      }
   }

   lpOutputBinInfo = (LPGENERIC_OPTION)MAKELONG(
       lpOutputBinInfoHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

   for(numEntries = i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword != OUTPUTBIN)
         continue ;   //  should drop to end of for loop.
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      for(j = 0 ; j < numEntries ; j++)
      {
         lengthOffset = lpOutputBinInfo[j].OptionKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, hpCur))
            break;
      }
      if(j < numEntries)
         continue;   //  this entry has already been added.


      lpOutputBinInfo[numEntries].OptionKey.dword =
                  addStringToTable(hpCur);

      lpOutputBinInfo[numEntries].OptionTranslation.dword =
         addTransStringToTable(lpKeyEntry[i].optionTrans) ;


      //  value is Invocation string
      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITOUTPUTBININFO,  ERR_OUTPUTBIN);
         errorMsg(INITOUTPUTBININFO, ERR_KEYWORD_HAS_NO_VALUE);
         continue ;   //  should drop to end of for loop.
      }
      if(!(lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITOUTPUTBININFO, ERR_OUTPUTBIN);
         errorMsg(INITOUTPUTBININFO, ERR_EXPCTD_QUOTED_NOT_STRING);
         errorString(hpCur);
         continue ;   //  should drop to end of for loop.
      }

      lpOutputBinInfo[numEntries].Invocation.dword =
                              addStringToTable(hpCur);
      numEntries++  ;
   }  //  went through every  OUTPUTBIN entry.


   lpOutputBinInfoHdr->OptionKeyWords.w.length = numEntries ;

   // ---  set default OutputBin here. ---  init to first slot.

   lpOutputBinInfoHdr->DefaultOptionIndex = 0 ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == DEFAULTOUTPUTBIN)
         break;  //   scan for this keyword.  stop at first occurance
   }

   //  if no default found use the default-default: the entry[0]!
   if(i >= numKeywords)
      goto    endOutputBin;

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITOUTPUTBININFO, ERR_DEFAULTOUTPUTBIN);
      errorMsg(INITOUTPUTBININFO, ERR_KEYWORD_HAS_NO_VALUE);
      goto    endOutputBin;
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITOUTPUTBININFO, ERR_DEFAULTOUTPUTBIN);
      errorMsg(INITOUTPUTBININFO, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto    endOutputBin;
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf);

   for(j = 0 ; j < numEntries ; j++)
   {
      lengthOffset = lpOutputBinInfo[j].OptionKey.dword ;
      if(!strtblcmp(lengthOffset, lpStringTable, lpBuf))
      {
         lpOutputBinInfoHdr->DefaultOptionIndex = j ;
         break;
      }
   }

endOutputBin:
   return(TRUE);
}



BOOL  NEAR    PARSE1SEG PASCAL  initMediaTypeInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable )
{
   WORD  i, j, numEntries ;
   DWORD  lengthOffset ;
   LPMAINKEYHDR  lpMediaTypeInfoHdr ;
   LPGENERIC_OPTION   lpMediaTypeInfo ;
   HPBYTE   hpCur ;
   BYTE   Buffer[256];  // holds string value for parsing into tokens
   LPBYTE  lpBuf;      // scratch pointers.



   // -------- parse  MEDIATYPE  entries -------

   lpMediaTypeInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_MEDIATYPEINFO ;

   //  eventually to be performed by OpenUI parser.
   if(!lpMediaTypeInfoHdr->MainKey.dword)
   {
      lpMediaTypeInfoHdr->MainKeyID = MEDIATYPE;
      lpMediaTypeInfoHdr->MainKey.dword = lpMainKeyWordsTable[MEDIATYPE].dword ;
      lpMediaTypeInfoHdr->MainTranslation.dword = 0L ;
   }

   lpMediaTypeInfoHdr->UItype = PICKONE ;   // not actually used by UI code

   lpMediaTypeInfoHdr->OptionQuery.dword = 0L ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == Q_MEDIATYPE)
      {
         lpMediaTypeInfoHdr->OptionQuery.dword =
            addStringToTable(lpKeyEntry[i].value);  // invocations are
         break;                                    // simple strings
      }
   }

   lpMediaTypeInfo = (LPGENERIC_OPTION)MAKELONG(
       lpMediaTypeInfoHdr->OptionKeyWords.w.offset, HIWORD(lpOptionsBlock) );

   for(numEntries = i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword != MEDIATYPE)
         continue ;   //  should drop to end of for loop.
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.

      for(j = 0 ; j < numEntries ; j++)
      {
         lengthOffset = lpMediaTypeInfo[j].OptionKey.dword ;
         if(!strtblcmp(lengthOffset, lpStringTable, hpCur))
            break;
      }
      if(j < numEntries)
         continue;   //  this entry has already been added.


      lpMediaTypeInfo[numEntries].OptionKey.dword =
                  addStringToTable(hpCur);

      lpMediaTypeInfo[numEntries].OptionTranslation.dword =
         addTransStringToTable(lpKeyEntry[i].optionTrans) ;

      //  value is Invocation string
      hpCur = lpKeyEntry[i].value;
      if(!hpCur)
      {
         errorMsg(INITMEDIATYPEINFO,  ERR_MEDIATYPE);
         errorMsg(INITMEDIATYPEINFO, ERR_KEYWORD_HAS_NO_VALUE);
         continue ;   //  should drop to end of for loop.
      }
      if(!(lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(INITMEDIATYPEINFO, ERR_MEDIATYPE);
         errorMsg(INITMEDIATYPEINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
         errorString(hpCur);
         continue ;   //  should drop to end of for loop.
      }


      lpMediaTypeInfo[numEntries].Invocation.dword =
                              addStringToTable(hpCur);
      numEntries++  ;
   }  //  went through every  MEDIATYPE entry.


   lpMediaTypeInfoHdr->OptionKeyWords.w.length = numEntries ;

   // ---  set default mediaType here. ---  init to first slot.

   lpMediaTypeInfoHdr->DefaultOptionIndex = 0 ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == DEFAULTMEDIATYPE)
         break;  //   scan for this keyword.  stop at first occurance
   }

   //  if no default found use the default-default: the entry[0]!
   if(i >= numKeywords)
      goto    endMediaType;

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITMEDIATYPEINFO, ERR_DEFAULTMEDIATYPE);
      errorMsg(INITMEDIATYPEINFO, ERR_KEYWORD_HAS_NO_VALUE);
      goto    endMediaType;
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITMEDIATYPEINFO, ERR_DEFAULTMEDIATYPE);
      errorMsg(INITMEDIATYPEINFO, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto    endMediaType;
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf);

   for(j = 0 ; j < numEntries ; j++)
   {
      lengthOffset = lpMediaTypeInfo[j].OptionKey.dword ;
      if(!strtblcmp(lengthOffset, lpStringTable, lpBuf))
      {
         lpMediaTypeInfoHdr->DefaultOptionIndex = j ;
         break;
      }
   }

endMediaType:
   return(TRUE);
}






BOOL  NEAR    PARSE1SEG PASCAL  initPrinterCaps(LPPRINTERINFO lpPrinterInfo,
                                                  LPBYTE lpStringTable)
{
   LPDEVCAPS      lpDevcaps = &lpPrinterInfo->devcaps;
   WORD  i;
   BYTE   Buffer[256];  //  holds string value for parsing into tokens
   HPBYTE   hpCur;      //  points to extracted string.
   LPBYTE   lpBuf, lpTok1 ;     //  scratch pointers.
   long  lvalue;

   //  store color flag
   lpDevcaps->color = FALSE;  //  default assumption
   lpDevcaps->LanguageEncoding = LangEncoding ;

   // these fields will be set to their option index value
   // if they exist.  Or 0xFFFF if not supported.

   lpDevcaps->AutoSense = 0xFFFF;  //  default assumption
   lpDevcaps->MixedBins = 0xFFFF;  //  default assumption
   lpDevcaps->ManualFeed = 0xFFFF;  //  default assumption
   lpDevcaps->CustomPageSize = 0xFFFF;  //  default assumption

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == COLORDEVICE)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage3;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_COLORDEVICE);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage3;  // select this line --or--
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_COLORDEVICE);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto   getInfoStage3;   //  for non fatal errors
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf);
   if(!lstrcmp("True", lpBuf))
      lpDevcaps->color = TRUE;

getInfoStage3:



   //  store languageLevel flag
   lpDevcaps->languageLevel = 2;  //  default assumption for 4.2+
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == LANGUAGELEVEL)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage4;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_LANGUAGELEVEL);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage4;  // select this line --or--
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_LANGUAGELEVEL);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_QUOTED_NOT_STRING);
      errorString(hpCur);
      goto   getInfoStage4;   //  for non fatal errors
   }
   addQuotedStringToTable(hpCur, Buffer, 255);  //  translate hex into Buffer.
   if(!lstrcmp("2", Buffer))
      lpDevcaps->languageLevel = 2;

   // L3_CLIP     add languagelevel 3
   else if(!lstrcmp("3", Buffer))
      lpDevcaps->languageLevel = 3;

getInfoStage4:
   //  store PJL flag

   lpDevcaps->BCPsupport =
   lpDevcaps->TBCPsupport =
   lpDevcaps->PJLsupport = FALSE;  //  default assumption

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == PROTOCOLSS)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage5;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_PROTOCOLS);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage5;  // select this line --or--
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_PROTOCOLS);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto   getInfoStage5;   //  for non fatal errors
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   while(lpBuf)  //  read in several tokens if necessary.
   {
      lpTok1 = extractStringToken(&lpBuf) ;  // may return NULL.

      if(!lpTok1)
         continue ;  // this token was a dud.

      if(!lstrcmp("PJL", lpTok1))
         lpDevcaps->PJLsupport = TRUE;
      else  if(!lstrcmp("BCP", lpTok1))
         lpDevcaps->BCPsupport = TRUE;
      else  if(!lstrcmp("TBCP", lpTok1))
         lpDevcaps->TBCPsupport = TRUE;
   }

getInfoStage5:

   lpDevcaps->SupportsDuplexing = FALSE ;  // initialize for now.
   //  later set when duplex commands are found.
   lpDevcaps->AutoSense =  bAutoSelect;


   //  store landscapeOrient90 flag
   lpDevcaps->landscapeOrientPlus90 = TRUE;  //  default assumption

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == LANDSCAPEORIENTATION)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage6;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_LANDSCAPEORIENTATION);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage6;  // select this line --or--
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_LANDSCAPEORIENTATION);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto   getInfoStage6;   //  for non fatal errors
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf);
   if(!lstrcmp("Minus90", lpBuf))
      lpDevcaps->landscapeOrientPlus90 = FALSE;

getInfoStage6:

   //  store TrueImageSupport flag
   lpDevcaps->TrueImageSupport = FALSE;  //  default assumption

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == TRUEIMAGEDEVICE)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage7;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_TRUEIMAGEDEVICE);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage7;  // select this line --or--
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_TRUEIMAGEDEVICE);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto   getInfoStage7;   //  for non fatal errors
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf);
   if(!lstrcmp("True", lpBuf))
      lpDevcaps->TrueImageSupport = TRUE;

getInfoStage7:



   //  store TrueTypeSupport flag
   lpDevcaps->TTRasterizer = TTRAST_NONE;  //  default assumption

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == TTRASTERIZER)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage8;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_TTRASTERIZER);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage8;  // select this line --or--
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_TTRASTERIZER);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto   getInfoStage8;   //  for non fatal errors
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf);
   if(!lstrcmp("TrueImage", lpBuf))
      lpDevcaps->TTRasterizer = TTRAST_TRUEIMAGE;
   else  if(!lstrcmp("Type42", lpBuf))
      lpDevcaps->TTRasterizer = TTRAST_TYPE42;
   else  if(!lstrcmp("Accept68K", lpBuf))
      lpDevcaps->TTRasterizer = TTRAST_68K;


getInfoStage8:
   //  leading and trailing control D configuration was removed.

   //  store ScreenFreq

   ScreenFreq = 600;  //  default assumption
   //  the driver code should interpret a ScreenFreq = 0 as nop.
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == SCREENFREQ)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage10;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_SCREENFREQ);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage10;  // select this line --or--
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_SCREENFREQ);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_QUOTED_NOT_STRING);
      errorString(hpCur);
      goto   getInfoStage10;   //  for non fatal errors
   }
   if(convStrToInt(&lvalue, hpCur, 1))     //  read tenths
      ScreenFreq = (DWORD)lvalue;
   else
   {
      errorMsg(INITPRINTERCAPS, ERR_SCREENFREQ);
      errorMsg(INITPRINTERCAPS, ERR_CONV_STRING_TO_DECIMAL);
      errorString(hpCur);
   }


getInfoStage10:

   //  store ScreenAngle
   ScreenAngle = 450;  //  default assumption
   //  the driver code should interpret a ScreenAngle = 0 as nop.
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == SCREENANGLE)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage11;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_SCREENANGLE);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage11;  // select this line --or--
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_SCREENANGLE);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_QUOTED_NOT_STRING);
      errorString(hpCur);
      goto   getInfoStage11;   //  for non fatal errors
   }
   if(convStrToInt(&lvalue, hpCur, 1))     //  read tenths
      ScreenAngle = (DWORD)lvalue;
   else
   {
      errorMsg(INITPRINTERCAPS, ERR_SCREENANGLE);
      errorMsg(INITPRINTERCAPS, ERR_CONV_STRING_TO_DECIMAL);
      errorString(hpCur);
   }

getInfoStage11:

   //  store iFreeVM
   lpDevcaps->iFreeVM = 173;  //  default assumption is 173k
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == FREEVM)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage3b;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_FREEVM);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage3b;  // select this line --or--
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_FREEVM);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_QUOTED_NOT_STRING);
      errorString(hpCur);
      goto   getInfoStage3b;   //  for non fatal errors
   }
   addQuotedStringToTable(hpCur, Buffer, 255);  //  translate hex into Buffer.
   if(convStrToInt(&lvalue, Buffer, -3))  // conv bytes to kbytes.
      lpDevcaps->iFreeVM = lvalue;
   else
   {
      errorMsg(INITPRINTERCAPS, ERR_FREEVM);
      errorMsg(INITPRINTERCAPS, ERR_CONV_STRING_TO_DECIMAL);
      errorString(Buffer);
   }


getInfoStage3b:

#ifdef Adobe_Driver
   //  store FaxSupport flag
   lpDevcaps->bFaxSupport = FALSE;  //  default assumption

#ifndef MICROSOFT_DRIVER_VERSION
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == FAXSUPPORT)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage12;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_FAXSUPPORT);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage12;  // select this line --or--
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_FAXSUPPORT);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto   getInfoStage12;   //  for non fatal errors
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf);
   if(!lstrcmp("Base", lpBuf))
      lpDevcaps->bFaxSupport = TRUE;
#endif

getInfoStage12:
#endif
    // Check if FontCacheSize is specified
   lpDevcaps->bFontCacheSize = FALSE;
    for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == FONTCACHESIZE)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage13;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_FONTCACHESIZE);  //YCT change in errorid.h later
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage13;  // select this line --or--
   }
   lpDevcaps->bFontCacheSize = TRUE;

    // use the first entry as default
    if(convStrToInt(&lvalue, hpCur, -3))  // conv bytes to kbytes.
      lpDevcaps->iFontCacheSize = (WORD)lvalue;
   else
   {
      errorMsg(INITPRINTERCAPS, ERR_FONTCACHESIZE);
      errorMsg(INITPRINTERCAPS, ERR_CONV_STRING_TO_DECIMAL);
      errorString(hpCur);
   }

getInfoStage13:
   lpDevcaps->iDefaultProtocol = 0;  //  default assumption

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == ADDEFAULTPROTOCOL)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage14;  // keyword nor found

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_PROTOCOLS);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage14;  // select this line --or--
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf) ;  // may return NULL.

   if(!lstrcmp("ASCII", lpBuf))
         lpDevcaps->iDefaultProtocol = ASCII;
   else if(!lstrcmp("BCP", lpBuf))
         lpDevcaps->iDefaultProtocol = BCP;
        else  if(!lstrcmp("TBCP", lpBuf))
                lpDevcaps->iDefaultProtocol = TBCP;
              else  if(!lstrcmp("BINARY", lpBuf))
                lpDevcaps->iDefaultProtocol = BINARY;

getInfoStage14:
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == JOBTIMEOUT)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage15;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_JOBTIMEOUT);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage15;  // select this line --or--
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_JOBTIMEOUT);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_QUOTED_NOT_STRING);
      errorString(hpCur);
      goto   getInfoStage15;   //  for non fatal errors
   }
//   addQuotedStringToTable(hpCur, Buffer, 255);  //  translate hex into Buffer.
   if(convStrToInt(&lvalue, hpCur, 0))
      lpDevcaps->JobTimeout = (WORD)lvalue;
   else
   {
      errorMsg(INITPRINTERCAPS, ERR_JOBTIMEOUT);
      errorMsg(INITPRINTERCAPS, ERR_CONV_STRING_TO_DECIMAL);
      errorString(Buffer);
   }

getInfoStage15:
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == WAITTIMEOUT)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage16;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_WAITTIMEOUT);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage16;  // select this line --or--
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_WAITTIMEOUT);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_QUOTED_NOT_STRING);
      errorString(hpCur);
      goto   getInfoStage16;   //  for non fatal errors
   }
//   addQuotedStringToTable(hpCur, Buffer, 255);  //  translate hex into Buffer.
   if(convStrToInt(&lvalue, hpCur, 0))
      lpDevcaps->WaitTimeout = (WORD)lvalue;
   else
   {
      errorMsg(INITPRINTERCAPS, ERR_WAITTIMEOUT);
      errorMsg(INITPRINTERCAPS, ERR_CONV_STRING_TO_DECIMAL);
      errorString(Buffer);
   }


getInfoStage16:

   lpDevcaps->bPrintPSErrors = FALSE;
   lpDevcaps->PrintPSErrorExist = 0;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == PRINTPSERRORS)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage17;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_PRINTPSERRORS);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage17;  // select this line --or--
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERCAPS, ERR_PRINTPSERRORS);
      errorMsg(INITPRINTERCAPS, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto   getInfoStage17;   //  for non fatal errors
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;
   lpBuf = extractStringToken(&lpBuf);
   if(!lstrcmp("True", lpBuf))
      lpDevcaps->bPrintPSErrors = TRUE;

   lpDevcaps->PrintPSErrorExist = 1;

getInfoStage17:

   lpDevcaps->iAdHasEuro = 0xFFFF;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == ADHASEURO)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getInfoStage18;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERCAPS, ERR_ADHASEURO);
      errorMsg(INITPRINTERCAPS, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getInfoStage18;  // select this line --or--
   }

   lpDevcaps->iAdHasEuro = !hstrcmp("True", hpCur) ? 1 : 0;

getInfoStage18:

   return(TRUE);
}

// OEMPLUGI begin
BOOL  NEAR    PARSE1SEG PASCAL  QueryOEMDocStickySize(
LPBYTE    lpFileName,
LPPRINTERINFO lpPrinterInfo,
WORD FAR  *lpSize )
{
   HINSTANCE hOEMCustDll;
   char      szPCFileName[24];
   char      szPath[128];
   WORD      retVal;
   int       iLen;
   LPOEMGETDOCSTICKYSIZE lpOEMGetDocStickySize;

    retVal = FALSE;
    if (lpSize)
    {
        // Construct the OEM DLL full path
        lstrcpy(szPCFileName,"\\");
        if (lstrlen(lpFileName) > 12)  // It is invalid PCFileName
        {                              // Do not continue
              *lpSize = 0;
              return retVal;
        }
        lstrcat(szPCFileName, lpFileName);

        iLen = lstrlen(szPCFileName);

        szPCFileName[iLen-3] = '\0';
        lstrcat(szPCFileName, "dll");

        GetDriverDirectory(szPath, sizeof(szPath));

        lstrcat(szPath, szPCFileName);
        hOEMCustDll = LoadLibrary(szPath);

        if (hOEMCustDll <= HINSTANCE_ERROR)
        {
           GetWindowsDirectory(szPath, sizeof(szPath));
           lstrcat(szPath, szPCFileName);
           hOEMCustDll = LoadLibrary(szPath);
        }

        *lpSize = 0;  // Assuming that the OEM requires no address space if we fail to load the DLL
        if (hOEMCustDll > HINSTANCE_ERROR)
        {   // We found the OEM DLL
           lpOEMGetDocStickySize  = (LPOEMGETDOCSTICKYSIZE)GetProcAddress(hOEMCustDll,
                                                                          "OEMGetDocStickySize");
           if (lpOEMGetDocStickySize)
              *lpSize = lpOEMGetDocStickySize(MAXOPTIONSTATES - lpPrinterInfo->numMainKeyHdrs);
           retVal = TRUE;
           FreeLibrary(hOEMCustDll);
        }
    }
    return retVal;
}
// OEMPLUGI end

BOOL  NEAR    PARSE1SEG PASCAL  initPrinterInfo(
LPPRINTERINFO  lpPrinterInfo,
LPBYTE   lpOptionsBlock ,
LPBYTE   lpStringTable,
LPBYTE   lpPPDName )
{
   WORD  i;     //  keyEntry index
   BOOL   bNoRes = FALSE;
   HPBYTE   hpCur ;     //  points to extracted string.
   DWORD  dwTemp[2];
   char   szModelName[MAX_PPD_MODELNAME_LEN];
   char   szName[MAX_PPD_MODELNAME_LEN];
   WORD   nCount;

   lpPrinterInfo->versionNum = WPXVERSION ;

   // Stamp this WPX file with the time of its creation, so we can bind
   // DEVMODE settings to a specific WPX file. (If someone changes their
   // PPD file, we need to re-evaluate the devmode's private data)
   lpPrinterInfo->dwPPDchecksum = PPDchecksum ;
   lpPrinterInfo->dwRandom = GetTickCount();

   // Store last modification times of PPD file and Pscrip.drv so that
   // if either of them changes, we can recreate the WPX file.
   if (!GetFileModTimes(lpPPDName, (LPDWORD)&dwTemp))
       return(FALSE);  // Failure
   lpPrinterInfo->dwPPDLMT  = dwTemp[0];
   lpPrinterInfo->dwDrvrLMT = dwTemp[1];

   //  store modelname
   hpCur = NULL;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == SHORTNICKNAME)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }

   if(!hpCur)
   {
      for(i = 0 ; i < numKeywords ; i++)
      {
         if(lpKeyEntry[i].keyword == MODELNAME)
         {
            hpCur = lpKeyEntry[i].value;
            break;  //   scan for this keyword.  stop at first occurance
         }
      }
   }

   if(!hpCur)
   {
      for(i = 0 ; i < numKeywords ; i++)
      {
         if(lpKeyEntry[i].keyword == NICKNAME)
         {
            hpCur = lpKeyEntry[i].value;
            break;  //   scan for this keyword.  stop at first occurance
         }
      }
   }

   if(!hpCur)
   {
      errorMsg(INITPRINTERINFO, ERR_MODELNAME);
      errorMsg(INITPRINTERINFO, ERR_KEYWORD_NOT_FOUND);
      return(FALSE);  // Failure.
   }

   lpPrinterInfo->modelname.dword = addQuotedStringToTable(hpCur, NULL, 0);

// Added for ICM support (fix bug 118385).  jjia. 10/18/95
// Add ModelName
   hpCur = NULL;
   szModelName[0] = '\0';
   szName[0] = '\0';

   for(i = 0 ; i < numKeywords ; i++)
   {
       if(lpKeyEntry[i].keyword == MODELNAME)
       {
           hpCur = lpKeyEntry[i].value;
           break;
       }
   }
   if(hpCur)
   {
      static WORD wCRCa[] =
      {  0x0000, 0xC0C1, 0xC181, 0x0140,
         0xC301, 0x03C0, 0x0280, 0xC241,
         0xC601, 0x06C0, 0x0780, 0xC741,
         0x0500, 0xC5C1, 0xC481, 0x0440
      };
      static WORD wCRCb[] =
      {  0x0000, 0xCC01, 0xD801, 0x1400,
         0xF001, 0x3C00, 0x2800, 0xE401,
         0xA001, 0x6C00, 0x7800, 0xB401,
         0x5000, 0x9C01, 0x8801, 0x4600

      };
      LPSTR lpTmp;
      BYTE  cTmp;
      WORD  wCRC;
      char  Name[9];

      lpPrinterInfo->RealModelName.dword = addQuotedStringToTable(hpCur, NULL, 0);

      // Fix bug 118385.   jjia.  10/18/95
      // If you change MAX_PPD_MODELNAME_LEN, you also need to change
      // MAX_MODEL_NAME defined in the INSTALLER and ICMTOOLS.
      lstrcpyn(szModelName, hpCur, MAX_PPD_MODELNAME_LEN);
      nCount = lstrlen(szModelName);
      wCRC = 0;
      for( lpTmp = (LPSTR)szModelName; nCount; nCount--, lpTmp++)
      {
         cTmp = (BYTE) (((WORD) *lpTmp) ^ ((WORD) wCRC ));
         wCRC = (wCRC>>8) ^ wCRCa[cTmp&0x0F] ^ wCRCb[cTmp>>4] ;
      }
      wsprintf((LPSTR) &Name[0], "%-08.8lX", (DWORD) wCRC );
      MemCopy((LPSTR) &lpPrinterInfo->ICMModelName, (LPSTR) &Name[4],
              ICM_MODEL_NAME_LEN);
   }
   else
   {
      lpPrinterInfo->RealModelName.dword = 0 ;
      lpPrinterInfo->ICMModelName[0] = '\0';
   }
// End

// Add Manufacturer.
   hpCur = NULL;
   for(i = 0 ; i < numKeywords ; i++)
   {
       if(lpKeyEntry[i].keyword == MANUFACTURER)
       {
           hpCur = lpKeyEntry[i].value;
           break;
       }
   }
   if(hpCur)
   {
      lpPrinterInfo->Manufacturer.dword = addQuotedStringToTable(hpCur, NULL, 0);
      // Fix bug 118385.   jjia.  10/18/95
      lstrcpyn(szName, hpCur, MAX_PPD_MODELNAME_LEN);
      nCount = lstrlen(szName);
   }
   else
   {
      lpPrinterInfo->Manufacturer.dword = 0 ;

      lstrcpyn(szName, szModelName, MAX_PPD_MODELNAME_LEN);
      nCount = lstrlen(szName);
   }

   if(szName[0] != '\0')
   {
      WORD  i;
      BOOL  bSpace;
      char  Name[4];
      BYTE  c;

      bSpace = FALSE;
      for(i = 0; i < 4; i++)
      {
         if (i < nCount)
             c = szName[i];
         if( (' ' == c) || ('-' == c) || ( i == nCount))
               bSpace = TRUE;
         if( bSpace )
               c = ' ';
         Name[i] = toupper(c);
      }
      MemCopy(lpPrinterInfo->ICMManufacturer, Name, ICM_MANUFACTURER_LEN);
   }else
   {
      lpPrinterInfo->ICMManufacturer[0] = '\0';
   }

   hpCur = NULL;

   //
   // we don't want to allow OEM driver plugins
   //
#ifndef MICROSOFT_DRIVER_VERSION
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == PCFILENAME)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }
#endif

   if(hpCur)
      lpPrinterInfo->PCFileName.dword = addQuotedStringToTable(hpCur, NULL, 0);
   else
      lpPrinterInfo->PCFileName.dword = 0 ;

// OEMPLUGI begin
   if(hpCur) {
      lpPrinterInfo->bOEMExist = QueryOEMDocStickySize(hpCur, lpPrinterInfo, &lpPrinterInfo->numOEMDocSticky);
   }
   else {
      lpPrinterInfo->bOEMExist = FALSE;
      lpPrinterInfo->numOEMDocSticky = 0;
   }
// OEMPLUGI end

   hpCur = NULL;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == PPDVERSION)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }

   if(hpCur)
      lpPrinterInfo->PPDVersion.dword = addQuotedStringToTable(hpCur, NULL, 0);
   else
      lpPrinterInfo->PPDVersion.dword = 0 ;

   hpCur = NULL;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == PRODUCT)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }

   if(hpCur)
      lpPrinterInfo->Product.dword = addQuotedStringToTable(hpCur, NULL, 0);
   else
      lpPrinterInfo->Product.dword = 0 ;

   hpCur = NULL;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == PSVERSION)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }

   if(hpCur)
      lpPrinterInfo->PSVersion.dword = addQuotedStringToTable(hpCur, NULL, 0);
   else
      lpPrinterInfo->PSVersion.dword = 0 ;


   if(!initPrinterCaps(lpPrinterInfo, lpStringTable) )
      return(FALSE);  // Failure.

//#ifdef ADOBE_WEB
   // get web keyword strings

   hpCur = NULL;
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == WEBURL)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }
   if(hpCur)
      MemCopy(lpPrinterInfo->szWebURL, hpCur, sizeof(lpPrinterInfo->szWebURL));
   else
      lpPrinterInfo->szWebURL[0] = '\0' ;

   hpCur = NULL;
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == WEBSERVER)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }
   if(hpCur)
      MemCopy(lpPrinterInfo->szWebServer, hpCur, sizeof(lpPrinterInfo->szWebServer));
   else
      lpPrinterInfo->szWebServer[0] = '\0' ;

   hpCur = NULL;
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == WEBPORT)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }
   if(hpCur)
      MemCopy(lpPrinterInfo->szWebPort, hpCur, sizeof(lpPrinterInfo->szWebPort));
   else
      lpPrinterInfo->szWebPort[0] = '\0' ;

   hpCur = NULL;
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == WEBPRINTER)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }
   if(hpCur)
      MemCopy(lpPrinterInfo->szWebPrinter, hpCur, sizeof(lpPrinterInfo->szWebPrinter));
   else
      lpPrinterInfo->szWebPrinter[0] = '\0' ;

   hpCur = NULL;
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == WEBPRINTERNAME)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }
   if(hpCur)
      MemCopy(lpPrinterInfo->szWebPrinterName, hpCur, sizeof(lpPrinterInfo->szWebPrinterName));
   else
      lpPrinterInfo->szWebPrinterName[0] = '\0' ;

   hpCur = NULL;
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == WEBCOMMPROTOCOL)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }
   if(hpCur)
      MemCopy(lpPrinterInfo->szWebCommProtocol, hpCur, sizeof(lpPrinterInfo->szWebCommProtocol));
   else
      lpPrinterInfo->szWebCommProtocol[0] = '\0' ;

   hpCur = NULL;
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == WEBPPD)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }
   if(hpCur)
      MemCopy(lpPrinterInfo->szWebPPD, hpCur, sizeof(lpPrinterInfo->szWebPPD));
   else
      lpPrinterInfo->szWebPPD[0] = '\0' ;

   hpCur = NULL;
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == WEBNOTICE)
      {
         hpCur = lpKeyEntry[i].value;
         break;  //   scan for this keyword.  stop at first occurance
      }
   }
   if(hpCur)
      MemCopy(lpPrinterInfo->szWebNotice, hpCur, sizeof(lpPrinterInfo->szWebNotice));
   else
      lpPrinterInfo->szWebNotice[0] = '\0' ;
//#endif

#if 1 // Re-enabled. Could be dangerous to assume there won't be PPDs with
      //  PSVersion < 2013 and with type42. ShyamV - 03/12/95

   //   disable oleg's fix cause our PPDs will never advertise
   //   Type 42 capability if PSver is < 2013 !
   //   Also, stringref isn't being dereferenced properly .

   // Fixed bug 29589 - Type 42 bug
   //  Type 42 handling was implemented incorrectly in
   //  printers with PS version < 2013. We supply the
   //  PS fix for that, and this fix is activated when
   //  text is sent and TTRasterizer == TTRAST_TYPE42BUGGY
   // Fixed 29-Aug-1994  -by-  [olegsher]
   // Oops! I forgot to convert string to Long - silly me!!
   //       07-Nov-1994  [olegsher]
   if( ( lpPrinterInfo->PSVersion.dword ) &&
       ( lpPrinterInfo->devcaps.TTRasterizer == TTRAST_TYPE42 )
     )
   {
      LPSTR   lpCur = StringRefToLP( lpPrinterInfo->PSVersion);

      while (*lpCur != '(')
         lpCur++;    // skip leading spaces.
         lpCur++;    // skip opening "(" now.
      while (*lpCur == ' ')   // skip spaces after the opening "("
         lpCur++;    // we now have the "real" beginning to the PSVersion string.

      if ( lstrcmp(lpCur, "2013") < 0 )
      {
#ifdef ADOBE_DRIVER
         lpPrinterInfo->devcaps.TTRasterizer = TTRAST_NONE;//disable for pre-2013 printers.
#else
         lpPrinterInfo->devcaps.TTRasterizer = TTRAST_TYPE42BUGGY;
#endif
      }
   }
   else  // If TrueImage device, suppress TrueImage support -ShyamV- 03/12/95
   {
      if( (lpPrinterInfo->devcaps.TrueImageSupport == TRUE) ||
          (lpPrinterInfo->devcaps.TTRasterizer == TTRAST_TRUEIMAGE)
        )
      {
         lpPrinterInfo->devcaps.TrueImageSupport = FALSE;
         lpPrinterInfo->devcaps.TTRasterizer = TTRAST_NONE;
      }
   }
#endif

   if(lpPrinterInfo->devcaps.PJLsupport)
   {
      if(!initJCLinfo(&lpPrinterInfo->JCLinfo) )
         return(FALSE);  // Failure.
   }
#ifndef ADOBE_DRIVER_42

   {
      BOOL   bFoundInList = FALSE;
      BYTE   lpModelName[CCHDEVICENAME] ;
      LPBYTE   lpBuf;
      WORD     keyBytesRead, bytesRead , i;

      lpBuf = GlobalAllocPtr(GHND, 1024);

      if(lpBuf)
      {
         keyBytesRead = GetPrivateProfileString("DEFAULT_USE_PORTABILITY",
            NULL, "   ", lpBuf, 1024, "system\\pscript.ini");

         for(i = 0 ; i < keyBytesRead ;  )
         {
            bytesRead = GetPrivateProfileString("DEFAULT_USE_PORTABILITY",
               lpBuf+i , "   ", lpModelName, CCHDEVICENAME, "system\\pscript.ini");

            if(!strtblcmp(lpPrinterInfo->modelname.dword, lpStringTable ,
               lpModelName) )
            {
               bFoundInList = TRUE ;
               break ;
            }
            while(lpBuf[i])
               i++ ;
            if(!lpBuf[++i])
               break ;
         }

         GlobalFreePtr(lpBuf);
      }

      lpPrinterInfo->devcaps.DefaultToPortability = bFoundInList ;
   }
#else
   lpPrinterInfo->devcaps.DefaultToPortability = FALSE;
#endif

   if(!initFontList(lpPrinterInfo, lpOptionsBlock, lpStringTable ))
      return(FALSE);  // Failure.

   //  how to disable manual feed.
   lpPrinterInfo->disableManFeed.dword = 0L ;
   //  assume unnecessary until proven otherwise.

   if(!bManFeed)
      goto    noManualFeed;  //  optional keyword

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == MANUALFEED  &&
               (hpCur = lpKeyEntry[i].option) &&
               !hstrcmp("False", hpCur))
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
   {
      bManFeed = FALSE ;   // If you can't turn it off I
                        // won't let you turn in on !
      goto    noManualFeed;  //  optional keyword
   }

   //  value is Invocation string
   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITPRINTERINFO, ERR_MANUALFEED_FALSE);
      errorMsg(INITPRINTERINFO, ERR_KEYWORD_HAS_NO_INVC_VALUE);
      bManFeed = FALSE ;   // If you can't turn it off I
                        // won't let you turn in on !
      goto    noManualFeed;  //  optional keyword
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERINFO, ERR_MANUALFEED_FALSE);
      errorMsg(INITPRINTERINFO, ERR_EXPCTD_INVOCATN_NOT_STRING);
      errorString(hpCur);
      bManFeed = FALSE ;   // If you can't turn it off I
                        // won't let you turn in on !
      goto    noManualFeed;  //  optional keyword
   }

   lpPrinterInfo->disableManFeed.dword = addStringToTable(hpCur);
   //  this string is issued before every Inputslot selection.

noManualFeed:

   bCustomSize = initCustPageInfo(lpPrinterInfo) ;

   //  store PassWord

   lpPrinterInfo->password.dword = 0L;  //  default assumption
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == PASSWORD)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getExitServerInfo;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
      goto   getExitServerInfo;  // select this line --or--

   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERINFO, ERR_PASSWORD);
      errorMsg(INITPRINTERINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
      errorString(hpCur);
      goto   getExitServerInfo;   //  for non fatal errors
   }
   lpPrinterInfo->password.dword =
               addQuotedStringToTable(hpCur, NULL, 0);  //  translate hex


getExitServerInfo:
   //  store ExitServer invocation

   lpPrinterInfo->exitServer.dword = 0L;  //  default assumption
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == EXITSERVER)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getPatchFileInfo;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
      goto   getPatchFileInfo;  // select this line --or--

   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERINFO, ERR_EXITSERVER);
      errorMsg(INITPRINTERINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
      errorString(hpCur);
      goto   getPatchFileInfo;   //  for non fatal errors
   }
   lpPrinterInfo->exitServer.dword =
               addQuotedStringToTable(hpCur, NULL, 0);  //  translate hex

getPatchFileInfo:
   //  store PatchFile invocation

   lpPrinterInfo->PatchFile.dword = 0L;  //  default assumption
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == PATCHFILE)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getJobPatchFileInfo;  //  optional keyword

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
      goto   getJobPatchFileInfo;  // select this line --or--

   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITPRINTERINFO, ERR_PATCHFILE);
      errorMsg(INITPRINTERINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
      errorString(hpCur);
      goto   getJobPatchFileInfo;   //  for non fatal errors
   }
   lpPrinterInfo->PatchFile.dword =
               addQuotedStringToTable(hpCur, NULL, 0);  //  translate hex

getJobPatchFileInfo:
   //  store several JobPatchFile  "invocation strings" in specified order !

{

   WORD  nPatches, j, IndexOfSmallest ;
   long  int  lvalue ;

   struct
   {
      WORD  KeyEntryIndex ;
      WORD  Order ;
   }  JobPatchTable[MAX_JOBPATCHES] ;




   for(nPatches = i = 0 ; i < numKeywords  &&  nPatches < MAX_JOBPATCHES
                     ; i++)
   {
      if(lpKeyEntry[i].keyword == JOBPATCHFILE  &&  lpKeyEntry[i].option)
      {
         if(!(lpKeyEntry[i].value
                           &&  lpKeyEntry[i].bValueQuoted))
            continue ;
         if(!convStrToInt(&lvalue, lpKeyEntry[i].option, 0))
            continue ; // if failure is encountered.

         JobPatchTable[nPatches].Order = (WORD)lvalue ;
         JobPatchTable[nPatches].KeyEntryIndex = i ;
         nPatches++ ;
      }
   }
   for(i = 0 ; i < nPatches  ; i++)
   {
      //  scan JobPatchTable for smallest remaining Order value

      for(IndexOfSmallest = 0 , j = 1 ; j < nPatches ; j++)
      {
         if(JobPatchTable[j].Order < JobPatchTable[IndexOfSmallest].Order)
            IndexOfSmallest = j ;
      }

      lpPrinterInfo->JobPatchFile[i].order =
                        JobPatchTable[IndexOfSmallest].Order ;

      hpCur = lpKeyEntry[JobPatchTable[IndexOfSmallest].KeyEntryIndex].value;
      lpPrinterInfo->JobPatchFile[i].invoc.dword =
                                 addStringToTable(hpCur);  // invocation


      JobPatchTable[IndexOfSmallest].Order = 0xFFFF ;
   }

   lpPrinterInfo->nJobPatchFiles = nPatches;
}


//endInitPrinterInfo:

   lpPrinterInfo->InstallableOptions = 0xFFFF ;  // default: none

   return(TRUE);  // Success
}



//  return value : is or is not custompagesize supported?


BOOL  NEAR    PARSE1SEG PASCAL  initCustPageInfo(
LPPRINTERINFO  lpPrinterInfo)
{
   LPCUSTPAGEINFO lpCustPageInfo;
   WORD  i ;
   HPBYTE   hpCur;
   BYTE   Buffer[256];  // holds string value for parsing into tokens
   LPBYTE  lpBuf, lpTok1;      // scratch pointers.
   long  int  lvalue ;
   BOOL   bErrors ;


   lpCustPageInfo = &lpPrinterInfo->custpageinfo;
   lpPrinterInfo->devcaps.CustomPageSize = 0xFFFF ;
   //  initially assume no custompage support.

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == CUSTOMPAGESIZE)
         break;  //   scan for this keyword.  stop at first occurance
   }

   if(i >= numKeywords  ||
      !(hpCur = lpKeyEntry[i].option)  ||  hstrcmp("True", hpCur))
      goto    NoCustomPaper;

   //  initialize to safe defaults
   lpCustPageInfo->Invocation.dword = 0 ;
   //  assume this command is emitted whenever PageRegion would
   //  be emitted.

   if(hpCur = lpKeyEntry[i].value)
      lpCustPageInfo->Invocation.dword =
               addStringToTable(hpCur);   //  invocation string may be absent



   if(!extractParams(&lpCustPageInfo->width, "Width") )
      goto    NoCustomPaper;

   if(!extractParams(&lpCustPageInfo->height, "Height") )
      goto    NoCustomPaper;

   if(!extractParams(&lpCustPageInfo->widthOffset, "WidthOffset") )
      goto    NoCustomPaper;

   if(!extractParams(&lpCustPageInfo->heightOffset, "HeightOffset") )
      goto    NoCustomPaper;

   if(!extractParams(&lpCustPageInfo->Orientation, "Orientation") )
      goto    NoCustomPaper;

// ----- end of custompagesize parameter extraction -------


   //  fill out remainder of Custom Paper entries.
   lpCustPageInfo->MaxMediaWidth = lpCustPageInfo->width.max ;
                     //  set the default value
   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == MAXMEDIAWIDTH)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto    getHWmargins;  //  optional keyword
   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITCUSTPAGEINFO, ERR_MAXMEDIAWIDTH);
      errorMsg(INITCUSTPAGEINFO, ERR_KEYWORD_HAS_NO_VALUE);
      goto   getHWmargins;  // select this line --or--
   }
   if(!(lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITCUSTPAGEINFO, ERR_MAXMEDIAWIDTH);
      errorMsg(INITCUSTPAGEINFO, ERR_EXPCTD_QUOTED_NOT_STRING);
      errorString(hpCur);
      goto   getHWmargins;   //  for non fatal errors
   }
   addQuotedStringToTable(hpCur, Buffer, 255);  //  translate hex into Buffer.
   if(convStrToInt(&lvalue, (HPBYTE)Buffer, 0))     //  in Pscript units
      lpCustPageInfo->MaxMediaWidth = (WORD)lvalue ;
   else
   {
      errorMsg(INITCUSTPAGEINFO, ERR_MAXMEDIAWIDTH);
      errorMsg(INITCUSTPAGEINFO, ERR_CONV_STRING_TO_DECIMAL);
      errorString(Buffer);
   }


getHWmargins:


   bErrors = FALSE ;

   lpCustPageInfo->HWmargins.left =
   lpCustPageInfo->HWmargins.bottom =
   lpCustPageInfo->HWmargins.right =
   lpCustPageInfo->HWmargins.top = 0;

   lpCustPageInfo->isCutSheet = FALSE ;


   //  read HardWare margins

   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == HWMARGINS)
         break;  //   scan for this keyword.  stop at first occurance
   }
   if(i >= numKeywords)
      goto   endGetHWmargins ;

   lpCustPageInfo->isCutSheet = TRUE ;

   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(INITCUSTPAGEINFO, ERR_HWMARGINS);
      errorMsg(INITCUSTPAGEINFO, ERR_KEYWORD_HAS_NO_VALUE);
      goto   endGetHWmargins ;
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(INITCUSTPAGEINFO, ERR_HWMARGINS);
      errorMsg(INITCUSTPAGEINFO, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      goto   endGetHWmargins ;
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;

   if((lpTok1 = extractStringToken(&lpBuf))  &&
                     convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
      lpCustPageInfo->HWmargins.left = (WORD)lvalue;
   else
      bErrors = TRUE ;

   if(!bErrors   &&  lpBuf  &&
                     (lpTok1 = extractStringToken(&lpBuf))  &&
                     convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
      lpCustPageInfo->HWmargins.bottom = (WORD)lvalue;
   else
      bErrors = TRUE ;

   if(!bErrors   &&  lpBuf  &&
                     (lpTok1 = extractStringToken(&lpBuf))  &&
                     convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
      lpCustPageInfo->HWmargins.right = (WORD)lvalue;
   else
      bErrors = TRUE ;

   if(!bErrors   &&  lpBuf  &&
                     (lpTok1 = extractStringToken(&lpBuf))  &&
                     convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
      lpCustPageInfo->HWmargins.top = (WORD)lvalue;
   else
      bErrors = TRUE ;

endGetHWmargins:

   if(bErrors)
   {
      errorMsg(INITCUSTPAGEINFO, ERR_HWMARGINS);
      errorMsg(INITCUSTPAGEINFO, ERR_TOKENS_MISSING);
      errorMsg(INITCUSTPAGEINFO, ERR_CONV_STRING_TO_DECIMAL);
      errorString(hpCur);

      //  return to default values:
      lpCustPageInfo->HWmargins.left =
      lpCustPageInfo->HWmargins.bottom =
      lpCustPageInfo->HWmargins.right =
      lpCustPageInfo->HWmargins.top = 0;
   }



   //  save these for very last, cause they enable custom page size support.
   lpPrinterInfo->devcaps.CustomPageSize = 0 ;  // placeholder means true

   return(TRUE);

NoCustomPaper:  //  optional keyword
   return(FALSE);
}



//  extractParams and store into a PARAM structure.

BOOL  NEAR    PARSE1SEG PASCAL  extractParams(
LPPARAM  lpParam,     // the structure
LPBYTE   lpOption)  // "Width" for example

{
   WORD  i ;
   long  int  lvalue ;
   HPBYTE   hpCur;
   BYTE   Buffer[256];  // holds string value for parsing into tokens
   LPBYTE  lpBuf, lpTok1 ;      // scratch pointers.
   BOOL    bErrors ;


   for(i = 0 ; i < numKeywords ; i++)
   {
      if(lpKeyEntry[i].keyword == PARAMCUSTOMPAGESIZE  &&
             (hpCur = lpKeyEntry[i].option)  &&
             !hstrcmp(hpCur, lpOption)   )
         break;  //   scan for first occurance of this keyword and option.
   }
   if(i >= numKeywords)
      return(FALSE);


   //  value is string value containing 'order type min max'
   hpCur = lpKeyEntry[i].value;
   if(!hpCur)
   {
      errorMsg(EXTRACTPARAMS, ERR_PARAMCUSTOMPAGESIZE);
      errorMsg(EXTRACTPARAMS, ERR_KEYWORD_HAS_NO_VALUE);
      return(FALSE);
   }
   if((lpKeyEntry[i].bValueQuoted))
   {
      errorMsg(EXTRACTPARAMS, ERR_PARAMCUSTOMPAGESIZE);
      errorMsg(EXTRACTPARAMS, ERR_EXPCTD_STRING_NOT_QUOTED);
      errorString(hpCur);
      return(FALSE);
   }
   hstrcpyn(Buffer, hpCur, 255);
   lpBuf = Buffer;

   bErrors = FALSE ;

   if((lpTok1 = extractStringToken(&lpBuf))  &&
                     convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
      lpParam->order = (BYTE)lvalue;
   else
      bErrors = TRUE ;

   if(!bErrors   &&  lpBuf  &&  (lpTok1 = extractStringToken(&lpBuf)) )
   {
      if(!hstrcmp(lpTok1, "points"))
         lpParam->units = TYPOINTS;
      else if(!hstrcmp(lpTok1, "int"))
         lpParam->units = INTS;
      else if(!hstrcmp(lpTok1, "real"))
         lpParam->units = REALS;
      else
         bErrors = TRUE ;
   }
   else
      bErrors = TRUE ;

   if(!bErrors   &&  lpBuf  &&
                     (lpTok1 = extractStringToken(&lpBuf))  &&
                     convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
   {
      if(lvalue > 9288)
         lvalue = 9288 ;
      lpParam->min = (WORD)lvalue ;
   }
   else
      bErrors = TRUE ;

   if(!bErrors   &&  lpBuf  &&
                     (lpTok1 = extractStringToken(&lpBuf))  &&
                     convStrToInt(&lvalue, (HPBYTE)lpTok1, 0))
   {
      if(lvalue > 9288)
         lvalue = 9288 ;
      lpParam->max = (WORD)lvalue ;
   }
   else
      bErrors = TRUE ;

   if(bErrors)
   {
      errorMsg(EXTRACTPARAMS, ERR_PARAMCUSTOMPAGESIZE);
      errorMsg(EXTRACTPARAMS, ERR_TOKENS_MISSING);
      errorMsg(EXTRACTPARAMS, ERR_CONV_STRING_TO_DECIMAL);
      errorString(hpCur);
      return(FALSE);
   }
   return(TRUE);
}



/*  string must be in this format:
[leading whitespace][+|-][nnn][.][mmm]
where nnn or mmm or both must be present.
returns the integer portion of (nnn.mmm * 10 ** power)
returns TRUE if string represents a legal number
*/

BOOL  FAR  PASCAL  convStrToInt(
LPLONG  lpValue ,  // return converted number here.
HPBYTE   hpStr ,    // string to be converted
short     power )    // include power digits to right of decimal pt. if
               //   positive, divide result by this power of ten if negative.
{
   long  accumulator = 0, sign = 1;
   BYTE   legal = 0 ;
   WORD   digits = 0 ;

   //  Ignore leading white space
   while(*hpStr == 32  ||  *hpStr == 9)
      hpStr++ ;
   if(*hpStr == '-' )
   {
      sign = -1;
      hpStr++ ;
   }
   else if(*hpStr == '+' )
      hpStr++ ;

   while(*hpStr >= '0'  &&  *hpStr <= '9')
   {
      accumulator *= 10;
      digits++;
      accumulator += *hpStr - '0' ;
      legal |= 4;
      hpStr++ ;
   }
   if(*hpStr == '.' )
   {
      hpStr++ ;
      legal |= 2;
      if(*hpStr >= '0'  &&  *hpStr <= '9')
         legal |= 1;
   }
   while( power > 0 &&  *hpStr >= '0'  &&  *hpStr <= '9')
   {
      accumulator *= 10;
      digits++;
      accumulator += *hpStr - '0' ;
      legal |= 1;
      hpStr++ ;
      power-- ;
   }
   while(power > 0)
   {
      accumulator *= 10;
      digits++;
      power-- ;
   }
   while(power < 0)
   {
      accumulator /= 10;
      power++ ;
   }


   if(legal > 2  && digits < 10)  // check for overflow.
   {                          // exclude number consisting of just a '.'
      *lpValue = accumulator * sign ;
      return(TRUE);
   }
   return(FALSE);
}

// parse option keyword of Resolution or SetResolution keyword.
// return resolution as dword, with x as loword and y as hiword.
// return (0,0) upon error.

DWORD  NEAR   PARSE1SEG PASCAL  extractResolution(
HPBYTE   hpStr )    // option keyword to be parsed
{
   WORD  xRes, yRes ;
   char tmpbuf[28];
    HPBYTE tmpStr, tmp1Str;

   xRes = yRes = 0;
    tmpStr = hpStr;
    tmp1Str = &tmpbuf[0];

   while(*hpStr >= '0'  &&  *hpStr <= '9')
   {
      xRes *= 10;
      xRes += *hpStr - '0' ;
      *tmp1Str++ =  *hpStr++ ;
   }
   if(*hpStr == '.')  // skip the fraction 300.52dpi -> 300dpi
   {
      hpStr++;
       while(*hpStr >= '0'  &&  *hpStr <= '9')
          hpStr++;
   }
   if(*hpStr == 'x' || *hpStr == 'X')
      *tmp1Str++ = *hpStr++ ;
   else if((*hpStr == 'd' || *hpStr == 'D')  &&  xRes)
        {
        //copy the rest
          while (*hpStr != '\0')
             *tmp1Str++ = *hpStr++;
             *tmp1Str = '\0';
             if (lstrlen(tmpStr) != lstrlen(tmpbuf))
          {
                 lstrcpy(tmpStr, tmpbuf);
                 *(tmpStr + lstrlen(tmpbuf)) = '\0'; //end with NULL
          }

          return(MAKELONG(xRes, xRes)) ;    //  equal resolution format
        }
   else
      return(0L);  // unexpected character.

   while(*hpStr >= '0'  &&  *hpStr <= '9')
   {
      yRes *= 10;
      yRes += *hpStr - '0' ;
      *tmp1Str++ = *hpStr++ ;
   }
   if(*hpStr == '.')  // skip the fraction 300.42x600.55dpi ->300x600dpi
   {
      hpStr++;
       while(*hpStr >= '0'  &&  *hpStr <= '9')
          hpStr++;
   }
   if((*hpStr == 'd' || *hpStr == 'D')  &&  xRes  &&  yRes)
   {
        //copy the rest
      while (*hpStr != '\0')
          *tmp1Str++ = *hpStr++;
      *tmp1Str = '\0';
        if (lstrlen(tmpStr) != lstrlen(tmpbuf))
      {
             lstrcpy(tmpStr, tmpbuf);
             *(tmpStr + lstrlen(tmpbuf)) = '\0'; //end with NULL
      }
      return(MAKELONG(xRes, yRes)) ;     //  can't have a res of zero!
   }
   else
      return(0L);  // unexpected character.
}




/*  strtblcmp() - compares a string in the stringtable
   to a normal NULL terminated string.
   returns 0 if equal 1 otherwise.  */

WORD    FAR  PASCAL  strtblcmp(
long    lengthOffset ,   //  two words - self explainatory
LPBYTE  lpStringTable ,  //  points to byte 0 of stringTable
HPBYTE  hpBuf  )         //  points to normal NULL terminated string.
{
   WORD  count ;

   count = HIWORD(lengthOffset);

   if(!hpBuf)  // NULL pointer
   {
      if(!count)
         return(0);  // both are NULL strings!
      return(1);     // else one is NULL the other isn't.
   }

   lpStringTable += LOWORD(lengthOffset);  // Now points right to string
   while(count--)
   {
      if(*hpBuf++ != *lpStringTable++)
         return(1);
   }
   if(*hpBuf)     //  should be at the NULL termination
      return(1);
   return(0);
}



