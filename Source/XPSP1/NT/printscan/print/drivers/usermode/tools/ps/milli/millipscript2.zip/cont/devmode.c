/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DEVMODE.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for the ExtDeviceMode     */
/*              function which is the main entry point into the driver       */
/*                                                                           */
/*****************************************************************************/
#include "generic.h"
#include <string.h>
#include "spin.h"

#pragma code_seg(_DEVMODESEG)

#define RESTRICTED_DEVMODE  0x800000
#define CHECKSIZE(ptr, size)  (!(IsBadWritePtr(ptr, size) || \
                                 IsBadReadPtr(ptr, size)))

#ifdef Adobe_Driver
#define NUM_PRSHT_PAGES    20
#else
#define NUM_PRSHT_PAGES    20       // Not sure what this number should be.  This used to be defined as 5.  Now
                                    // that Microsoft supports OEM, this number should be increased.
#endif

// hack for apps that hard-code DEVMODE size that works only in Win3.1
#define DMSPECVERSION_WIN31 0x030A
#define DMFIELDS_WIN31      0x0000FFFFL
#define DMSIZE_WIN31        70

#define MIN_CUST_SIZE       72
#define IDX_X_OFFSET         0
#define IDX_Y_OFFSET         1
#define IDX_X_SIZE           2
#define IDX_Y_SIZE           3

typedef int (WINAPI *LPPROPERTYSHEETPROC)(LPCPROPSHEETHEADER lpHeader);
typedef HPROPSHEETPAGE (WINAPI* LPCREATEPROC)(LPCPROPSHEETPAGE);

// OEMPLUGI utility function TH 03/17/95
LPPROPSHEETPAGE FAR PASCAL CreateOemStubPropSheet(PROPSHEETPAGE FAR *lpPropShPage, LPARAM lDrvParam);


#ifdef ADOBE_DRIVER
DLGPROC Procs[]={ CHPaperDlg,
                  CHGraphicsDlg,
                  CHFontsDlg,
                  CHDeviceDlg,
                  CHPostScriptDlg,
                  CHWaterMarksDlg};

LPSTR Templates[]={ "CH_Paper",
                    "CH_Graphics",
                    "CH_Fonts",
                    "CH_Device",
                    "CH_PostScript",
                    "CH_WaterMarks"};
#else
DLGPROC Procs[5]={CHPaperDlg,
                  CHGraphicsDlg,
                  CHFontsDlg,
                  CHDeviceDlg,
                  CHPostScriptDlg};

LPSTR Templates[5]={"CH_Paper",
                    "CH_Graphics",
                    "CH_Fonts",
                    "CH_Device",
                    "CH_PostScript"};
#endif


char szCreateDlgPageFunction[]="CreatePropertySheetPage";
char szPropertySheetFunction[]="PropertySheet";

BOOL FAR PASCAL ICMProfileInstalled(LPPRINTERINFO lpPrinterInfo, LPSTR lpszFriendlyName)
{
   BOOL  bInstalled = FALSE;
   HKEY  hKey, hSubKey;
   char  szICMKey[256];  // ICM key path in registry
   char  szSubKey[32];
   int   i, j;
   char  iccProfNames[128];
   DWORD dwSize, dwType;

   // WIN95-98
   if (!IsWin40())
   {   // Win4.1
       LoadString(ghDriverMod, IDS_REGSTR_PRN_PRINTER_0, szICMKey, sizeof(szICMKey));
       lstrcat(szICMKey, "\\");
       lstrcat(szICMKey, lpszFriendlyName);
       lstrcat(szICMKey, "\\");
       lstrcat(szICMKey, "PrinterDriverData");

       if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR)szICMKey, (HKEY FAR *) &hKey)
          == ERROR_SUCCESS)
       {
          //if a key exist for this friendly printer
          dwSize = sizeof(iccProfNames);
          if ((RegQueryValueEx(hKey, (LPSTR)"ICMProfile", 0, (LPDWORD) &dwType,
             (LPSTR)iccProfNames, (LPDWORD)&dwSize) == ERROR_SUCCESS) &&
             (dwSize > 1))
          {
              bInstalled = TRUE;
          }
       }
       if (hKey)
          RegCloseKey(hKey);
   }
   else
   {   // Win4.0
       LoadString(ghDriverMod, IDS_REGSTR_PATH_ICM, szICMKey, sizeof(szICMKey));
       if(RegOpenKey(HKEY_LOCAL_MACHINE, szICMKey, &hKey) == ERROR_SUCCESS)
       {
       for(i=0; RegEnumKey(hKey, i, szSubKey, sizeof(szSubKey)) == ERROR_SUCCESS;
           i++)
       {
          if(lstrcmp(szSubKey, lpPrinterInfo->ICMManufacturer) == 0)
          {
             lstrcat(szICMKey, "\\");
             lstrcat(szICMKey, szSubKey);
             if(RegOpenKey(HKEY_LOCAL_MACHINE, szICMKey, &hSubKey) == ERROR_SUCCESS)
             {
                for(j=0; RegEnumKey(hSubKey, j, szSubKey, sizeof(szSubKey)) == ERROR_SUCCESS;
                    j++)
                {
                   if(lstrcmp(szSubKey, lpPrinterInfo->ICMModelName) == 0)
                   {
                      bInstalled = TRUE;
                      break;
                   }
                }
                RegCloseKey(hSubKey);
             }
          }
       }
       RegCloseKey(hKey);
       }
   }
   return(bInstalled);
}

void NEAR PASCAL SetDlgFlags(LPDRIVERINFO lpDrvInfo)
{
    LPPRINTERINFO lpPrinterInfo;
    DWORD         dwTemp;
    int           iNumOpts;

    lpPrinterInfo = (LPPRINTERINFO) lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;

    /* Paper dialog */
    /*
     * NOTE!! THERE IS NO SUPPORT FOR THE FOLLOWING COMBINATION:
     *         ~DI_ORIENTATION && DI_PAPERSIZE.
     * Of courese, you can have Orientation and Paper size or neither or both.
     * Supporting this requires painful code in the Paper dialog, and I
     * feel that this combination is never required.
     */
    dwTemp = DI_ORIENTATION;
    if (! (lpDrvInfo->wFlags & DI_ADVSETUPDLG))
    {
       /* ExtDeviceMode or ExtDeviceModePropSheet */
       dwTemp |= DI_PAPERSIZE;    // do not assume paper source exist
    }
    if (lpPrinterInfo->devcaps.SupportsDuplexing)
        dwTemp |= DI_DUPLEX;
    if (lpPrinterInfo->devcaps.bCollateSupport)
        dwTemp |= DI_COLLATE;
    if (lpPrinterInfo->devcaps.bOutputOrderSupport)
        dwTemp |= DI_REVERSEORDER;
    if (DoesKeywordExistByIndex(&lpDrvInfo->pDev, ID_KEY_MEDIATYPE) == TRUE)
        dwTemp |= DI_MEDIATYPE;
    if (DoesKeywordExistByIndex(&lpDrvInfo->pDev, ID_KEY_OUTPUTBIN) == TRUE)
        dwTemp |= DI_OUTPUTBIN;
    if (DoesKeywordExistByIndex(&lpDrvInfo->pDev, ID_KEY_INPUTSLOT) == TRUE)
        dwTemp |= DI_PAPERSOURCE;

    if ((dwTemp & DI_PAPERSIZE) &&
        lpPrinterInfo->devcaps.CustomPageSize != 0xFFFF)
        dwTemp |= DI_CUSTOM;
    lpDrvInfo->dwUIFlags[DI_PAPER] = dwTemp;

#ifdef ADOBE_DRIVER
    /* Watermark Dialog */

    dwTemp = 0;
    if(lpPrinterInfo->devcaps.languageLevel >= 2)
    {
       // if Level 1, suppress Watermark
       // if Level 2, always do printer sticky even from apps
       dwTemp |= DI_PSTICKY;
    }
    lpDrvInfo->dwUIFlags[DI_WATERMARK] = dwTemp;
#endif

    /* Device dialog */
    dwTemp = DI_PRINTERFTRS;
    if (lpDrvInfo->wFlags & DI_PROPSHEET)
    {
        dwTemp |= DI_AVAILVM | DI_IOPTIONS;
        if (lpPrinterInfo->devcaps.bFontCacheSize)
           dwTemp |= DI_AVAILFCACHE;
    }
    if (lpPrinterInfo->DocSticky.w.length == 0)
        dwTemp &= ~DI_PRINTERFTRS;

    KeywordGetNumOfOptions(&lpDrvInfo->pDev, IND_MEMORYINFO, (LPWORD)&iNumOpts);

    if ((lpPrinterInfo->PrinterSticky.w.length == 0) && (iNumOpts == 0))
        dwTemp &= ~DI_IOPTIONS;

    lpDrvInfo->dwUIFlags[DI_DEVICE] = dwTemp;

    /* Fonts dialog */
    dwTemp = 0;
    if (lpDrvInfo->wFlags & DI_PROPSHEET)
    {
        /* ExtDeviceMode or ExtDeviceModePropSheet */
        dwTemp |= DI_DLTT | DI_FNTSUBS | DI_DLPSCRIPT | DI_DLFMT;
    }
    lpDrvInfo->dwUIFlags[DI_FONTS] = dwTemp;

    /* Graphics dialog */
    lpDrvInfo->dwUIFlags[DI_GRAPHICS] = DI_RESLN | DI_SPECIAL | DI_SCALE | DI_LAYOUT;
    if (lpDrvInfo->wFlags & DI_PROPSHEET)
    {
       // Printer-sticky properties are configurable only by
       // the ExtDeviceModePropSheet function.
       lpDrvInfo->dwUIFlags[DI_GRAPHICS] |= DI_PRINTPAGEBORDER;
    }

    //Win95-98
    if (ICMProfileInstalled(lpPrinterInfo,
        lpDrvInfo->pDev.lpPSExtDevmode->dm.dm.dmDeviceName))
        lpDrvInfo->dwUIFlags[DI_GRAPHICS] |= DI_COLOR;

    /* Postscript dialog */
    dwTemp = DI_OUTFMT;
    if (lpDrvInfo->wFlags & DI_PROPSHEET)
    {
        if (lpDrvInfo->lpDM->dm2.bAllowExitServer)
            dwTemp |= DI_HEADER;
        dwTemp |= DI_ERRORINFO | DI_JOBTOUT | DI_WAITTOUT | DI_ADVANCED;
    }
    lpDrvInfo->dwUIFlags[DI_POSTSCRIPT] = dwTemp;
}

#if 0
/*****************************************************************************/
/*                           ValidatePostscriptOptions                       */
/* Purpose:                                                                  */
/*   Validates the fields in the private portion of the devmode that         */
/*   correspond to the UI in the postscript and advance postscript pages.    */
/*   Changes invalid options to valid ones.                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   lpWPXblock -- Pointer to WPX block.                                     */
/*   lpPSExtDevmode -- Pointer to devmode to validate.                       */
/*                                                                           */
/* Returns: Nothing                                                          */
/*****************************************************************************/
void FAR PASCAL ValidatePostscriptOptions(LPWPXBLOCKS lpWPXblock,
                                          LPPSEXTDEVMODE lpPsExtDevmode)
{
    /* BUGBUG : TBD */
}
#endif

/*****************************************************************************/
/*                       CallOEMValidateDevmode                              */
/* Purpose:                                                                  */
/*   Lets the OEM plugin validate the devmode                                */
/*                                                                           */
/* Parameters:                                                               */
/*   lpDrvInfo -- Pointer to DriverInfo                                      */
/*   lpWPXblock -- Pointer to WPX block.                                     */
/*   lpPSExtDevmode -- Pointer to devmode to validate.                       */
/*                                                                           */
/* Returns: Nothing                                                          */
/*****************************************************************************/
VOID NEAR PASCAL CallOEMValidateDevmode( LPDRIVERINFO   lpDrvInfo,
                                         LPWPXBLOCKS    lpWPXblock,
                                         LPPSEXTDEVMODE lpPSExtDevmode)

{
    LPPRINTERINFO   lpPrinterInfo;
    LPSTR           lpFileName;
    LPPDEVICE       lppd;

    if (!lpWPXblock) return;

    lpPrinterInfo = (LPPRINTERINFO)(lpWPXblock->WPXprinterInfo);

    if (lpPrinterInfo->bOEMExist)
    {
        if (lpDrvInfo)
        {
            // Set DEVMODE if no valid one with current PDEVICE
            if (!(lpDrvInfo->pDev.lpPSExtDevmode))
                lpDrvInfo->pDev.lpPSExtDevmode = lpPSExtDevmode;

            if (lpDrvInfo->hOemCust)
                AdobeOEMValidateDevmode(lpDrvInfo->hOemCust);
            else
            {
                lppd = (LPPDEVICE)&lpDrvInfo->pDev;
                lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->PCFileName.dword);

                lpDrvInfo->hOemCust = AdobeOEMInitDllStub(lpDrvInfo,lpFileName,DLL_TYPE_OEM_CUST,VALIDATEDM);
                if (lpDrvInfo->hOemCust)
                {
                    AdobeOEMValidateDevmode(lpDrvInfo->hOemCust);
                    AdobeOEMTermDllStub(lpDrvInfo->hOemCust);
                    lpDrvInfo->hOemCust = NULL;
                }
            }
        }
    }
}

/*****************************************************************************/
/*                           ValidateOptions                                 */
/* Purpose:                                                                  */
/*   Validates the values in the private portion of the devmode.             */
/*   Changes invalid options to valid ones.                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   lpDrvInfo -- Pointer to DriverInfo                                      */
/*   lpWPXblock -- Pointer to WPX block.                                     */
/*   lpPSExtDevmode -- Pointer to devmode to validate.                       */
/*                                                                           */
/* Returns: Nothing                                                          */
/*****************************************************************************/
BOOL NEAR PASCAL ValidateOptions(LPDRIVERINFO   lpDrvInfo,
                                 LPWPXBLOCKS    lpWPXblock,
                                 LPPSEXTDEVMODE lpPSExtDevmode)
{
    CallOEMValidateDevmode(lpDrvInfo, lpWPXblock, lpPSExtDevmode);

    return validateOptionArray(lpWPXblock, lpPSExtDevmode);
}


/*****************************************************************************/
/*                           UpdateGlobal                                    */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: Nothing                                                          */
/*****************************************************************************/
void FAR PASCAL UpdateGlobal(LPDRIVERINFO lpDrvInfo,
                             BOOL         bUpdateSave)
{
    // We need to make sure that the data is entirely self-consistent,
    // and that the public devmode gets updated. Do this before we
    // do anything else. Always reference lpDrvInfo->lpDM, so we can
    // safely be called at any time and we'll use the right devmode.

    lpDrvInfo->bValidateOptions = lpDrvInfo->bValidateOptions &&
        ValidateOptions(lpDrvInfo, lpDrvInfo->pDev.lpWPXblock,lpDrvInfo->lpDM);
    InitializeDrvVariables(lpDrvInfo->lpDM);
    UpdatePublicDevmode(lpDrvInfo->pDev.lpWPXblock,lpDrvInfo->lpDM);

    // If bUpdateSave is TRUE, then we want to copy the current contents
    // of lpDrvInfo->DMScratch to lpDrvInfo->DMSave. This lets us handle
    // the Apply Now notification correctly.
    if(bUpdateSave)
        lpDrvInfo->DMSave=lpDrvInfo->DMScratch;

    // If DM_UPDATE is set, update the cache and tell the world that
    // we've done our thing.
    if(DM_UPDATE & lpDrvInfo->wMode)
    {
        /*
         * SetEnvironment requires that dmDriverExtra have the size of the
         * *entire* private devmode. It usually has only the doc-sticky size.
         * So, save current value before we cache, and then put it back.
         */
        WORD temp = lpDrvInfo->lpDM->dm.dm.dmDriverExtra;

        lpDrvInfo->lpDM->dm.dm.dmDriverExtra = sizeof(PSEXTDEVMODE) -
            sizeof(DEVMODE);
        DrvSetPrinterData(lpDrvInfo->lpDM->dm.dm.dmDeviceName,
                          (LPSTR)INT_PD_DEFAULT_DEVMODE, (DWORD)REG_BINARY,
                          (LPBYTE)lpDrvInfo->lpDM,
                          sizeof(PSEXTDEVMODE));
        lpDrvInfo->lpDM->dm.dm.dmDriverExtra = temp;
        SendMessage(HWND_BROADCAST,WM_DEVMODECHANGE,NULL,
                    (LPARAM)(LPSTR)(lpDrvInfo->lpDM->dm.dm.dmDeviceName));
    }

    // Set the status flags to do this as rarely as possible
    lpDrvInfo->wFlags |= (DI_SAVED | DI_VALIDATED);
}


/*****************************************************************************/
/*                           IEndDevMode                                     */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/
int NEAR PASCAL IEndDevMode(LPDRIVERINFO lpDrvInfo)
{
    int nReturn=-1;

    // Stuff to do if we successfully initialized.
     // bug 203449 remove the UnRegisterLongSpinControlCalss()
    //if(lpDrvInfo->wMode & DM_PROMPT)
    //{
       // UnRegister custom spin control which can handle the DWORD value.
       // UnRegisterLongSpinControlClass(ghDriverMod);
    //}

    if(DI_INITIALIZED & lpDrvInfo->wFlags)
    {
            // This needs to come before the call to UpdateGlobal, since
            // UpdateGlobal may alter the state of bSaved. If we're not
            // putting up a dialog, return IDOK. If we put up a dialog,
            // return IDOK if the user ever chose OK or Apply Now. A truth
            // table of the two conditions will show that we only return
            // IDCANCEL if DM_PROMPT is set and bSaved is FALSE.

            nReturn = ((DM_PROMPT & lpDrvInfo->wMode) &&
                !(DI_SAVED & lpDrvInfo->wFlags))?
                IDCANCEL:IDOK;

            // If the data hasn't been validated, validate it now.

            if (!(DI_VALIDATED & lpDrvInfo->wFlags) ||
                (DM_UPDATE & lpDrvInfo->wMode))
            {
                UpdateGlobal(lpDrvInfo,FALSE);
            }

            // Return the final devmode, if appropriate
            if ((lpDrvInfo->wMode & DM_COPY) && lpDrvInfo->lpdmOutput)
            {
                if (GetAppCompatFlags(0) & GACF_FORCEWIN31DEVMODESIZE)
                {
                    // Apps that hardcode devmode size
                    lpDrvInfo->lpDM->dm.dm.dmDriverExtra = 0;
                    lpDrvInfo->lpDM->dm.dm.dmSpecVersion = DMSPECVERSION_WIN31;
                    lpDrvInfo->lpDM->dm.dm.dmSize = DMSIZE_WIN31;
                    lpDrvInfo->lpDM->dm.dm.dmFields &= DMFIELDS_WIN31;
                }
                MemCopy((LPVOID) lpDrvInfo->lpdmOutput,(LPVOID) lpDrvInfo->lpDM,
                     lpDrvInfo->lpDM->dm.dm.dmDriverExtra +
                        (DWORD) sizeof(DEVMODE));

            }

            // If we loaded the help file, free it!
            if(lpDrvInfo->fHelp)
                WinHelp(NULL, szHelpFile, HELP_QUIT, 0L);
    }

    /*
     * Not necessary any more as we have validate options
     * as part of checking UI constraints.
     */
#if 0
    if ((!lpDrvInfo->bValidateOptions) &&
        (DM_PROMPT & lpDrvInfo->wMode) &&
        (nReturn == IDOK))
    {
        char warning[15];
        char text[300];

        /*
         * The user chose OK, but validate options returned false.
         * Warn the user about it.
         */
        LoadString(ghDriverMod, IDS_INSTALLWARNING, warning, sizeof(warning));
        LoadString(ghDriverMod, DLGS_VALIDATE_WARNING, text, sizeof(text));
        MessageBox(NULL, text, warning, MB_ICONEXCLAMATION | MB_OK);
    }
#endif

    if(lpDrvInfo->pDev.lpWPXblock)
        FreePrinter(lpDrvInfo->pDev.lpWPXblock) ;

//    if(DI_REGISTERED & lpDrvInfo->wFlags)
//        UnRegisterControlClass(ghDriverMod);

    if(lpDrvInfo->hInstShell >= HINSTANCE_ERROR)
        FreeLibrary(lpDrvInfo->hInstShell);

    if(lpDrvInfo->hIconMgr >= HINSTANCE_ERROR)
        FreeLibrary(lpDrvInfo->hIconMgr);

    // OEMPLUGI begin
    if (lpDrvInfo->hOemCust)
    {
        AdobeOEMTermDllStub(lpDrvInfo->hOemCust);
        lpDrvInfo->hOemCust = NULL;
    }

#ifdef Adobe_Driver
    // Adobe driver also supports FAX.
    if (lpDrvInfo->hPSFax)
    {
        AdobeOEMTermDllStub(lpDrvInfo->hPSFax);
        lpDrvInfo->hPSFax = NULL;
    }
//#ifdef ADOBE_WEB
    // Adobe driver also supports Web Printer.
    if (lpDrvInfo->hWebPrinter)
    {
        AdobeOEMTermDllStub(lpDrvInfo->hWebPrinter);
        lpDrvInfo->hWebPrinter = NULL;
    }
//#endif
#endif
    // OEMPLUGI end

    GlobalFreePtr(lpDrvInfo->lpUICArray);
    GlobalFreePtr(lpDrvInfo);

    return nReturn;
}


/*****************************************************************************/
/*                       PropPageCallback                                    */
/* Purpose:                                                                  */
/*      This is a public entry point. It loads ds on entry, and calls the  */
/*      internal function IEndDevMode.                                       */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/
UINT _loadds FAR PASCAL PropPageCallback(HWND            hWnd,
                                         UINT            uMsg,
                                         LPPROPSHEETPAGE lpPSP)
{
    if(PSPCB_RELEASE==uMsg)
        IEndDevMode((LPDRIVERINFO)(lpPSP->lParam));

    return 1;
}

// OEMPLUGI begin
UINT _loadds FAR PASCAL StubPropPageCallback(HWND            hWnd,
                                             UINT            uMsg,
                                             LPPROPSHEETPAGE lpPSP)
{

    LPDRIVERINFO    *lppDrvInfo;

    if(PSPCB_RELEASE==uMsg) {
        lppDrvInfo = (LPDRIVERINFO *)((char *)lpPSP + (lpPSP->dwSize - sizeof(LPDRIVERINFO)));
        IEndDevMode(*lppDrvInfo);
    }
    return 1;
}
// OEMPLUGI end

/*********************************************************************
*                       DeviceMode
*  function:
*       This is a Driver entry point which provides functionality similar
*       to but more limited than ExtDeviceMode -- implemented as a call
*       to ExtDeviceMode.
*  prototype:
*       short FAR PASCAL DeviceMode(HWND hWnd,HANDLE hInst,LPSTR lpzDevice,
*                                    LPSTR lpzPort)
*  parameters:
*       HWND hWnd -- parent window handle
*       HANDLE hInst -- instance handle
*       LPSTR lpsDevice -- device name string
*       LPSTR lpsPort -- port name string
*  returns:
*       short -- as defined in the the DDK
*               TRUE or FALSE -- FALSE => error
***********************************************************************/
short _loadds FAR PASCAL DeviceMode(HWND   hWnd,
                                    HANDLE hInst,
                                    LPSTR  lpzDevice,
                                    LPSTR  lpzPort)
{
   short sRC ;

   sRC = (ExtDeviceMode(hWnd,hInst,NULL,lpzDevice,lpzPort,NULL,NULL,
                        DM_PROMPT|DM_UPDATE)==IDOK);

   return(sRC) ;
}


WORD FAR PASCAL GetPrivateDocStickySize()
{
    LPPSEXTDEVMODE lpdm;
    WORD wSize;

    if (GetAppCompatFlags(GetCurrentTask()) & RESTRICTED_DEVMODE)
    {  /* This app requires a restricted devmode */
        LPBYTE lpStart, lpEnd;

        lpdm = (LPPSEXTDEVMODE) &wSize;

        lpStart = (LPBYTE) &lpdm->dm;
        lpEnd = (LPBYTE) &lpdm->dm.optionState[IND_NUMPREDEFINEDHDRS];

        wSize = (int) (OFFSETOF(lpEnd) - OFFSETOF(lpStart) - sizeof(DEVMODE));
    }
    else
        wSize = sizeof(PSDEVMODE) - sizeof(DEVMODE);

    return wSize;
}


/*****************************************************************************/
/*                            UpdatePublicDevmode                            */
/* Purpose:                                                                  */
/*      This function syncs up the public part of the devmode from the       */
/*      values in the prinvate portion.                                      */
/* Parameters:                                                               */
/*      lpWPXblock --  pointer to the WPX block.                             */
/*      lpPSExtDevmode -- pointer to the devmode.                            */
/* Returns: BOOL                                                             */
/*      TRUE => sucess, FALSE => failure.                                    */
/*****************************************************************************/
BOOL FAR PASCAL UpdatePublicDevmode(LPWPXBLOCKS   lpWPXblock,
                                    LPPSEXTDEVMODE  lpPSExtDevmode)
{
    LPPSDEVMODE  dm1;
    LPPSDEVMODE2  dm2;
    LPDEVMODE publicdm;
    LPPRINTERINFO  lpPrinterInfo ;
    LPMAINKEYHDR  lpCurMainKeyHdr ;
    LPBYTE      lpOptionsBlock;
    LPPDEVICE   lppd ;
    LPWORD      lpCRC_16_tab = (LPWORD) crc_16_tab;
    BOOL        rc = FALSE;

    if (!(lppd = (LPPDEVICE) GlobalAllocPtr(GMEM_SHARE|GHND, sizeof(PDEVICE))))
        goto EndUpdatePublicDM;

    lppd->lpWPXblock = lpWPXblock ;
    lppd->lpPSExtDevmode = lpPSExtDevmode ;

    lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;
    lpOptionsBlock = lpWPXblock->WPXarrays ;

    dm1 = &lpPSExtDevmode->dm ;
    dm2 = &lpPSExtDevmode->dm2 ;

    publicdm = &dm1->dm ;

    /* Update checksum of private devmode. This is the best place to do it */
    dm1->check1 = CalcCRC((LPSTR)&dm1->dwTimeStamp, GetPrivateDocStickySize() -
                          2*sizeof(WORD), 0xffff, lpCRC_16_tab);
    dm1->check2 = CalcCRC((LPSTR)&dm1->dwTimeStamp, sizeof(PSEXTDEVMODE) -
                          sizeof(DEVMODE) - 2*sizeof(WORD), 0xffff,
                          lpCRC_16_tab);

    publicdm->dmSpecVersion = GDI_VERSION;
    publicdm->dmDriverVersion = DRIVER_VERSION;
    publicdm->dmSize = sizeof(DEVMODE);
    publicdm->dmDriverExtra = GetPrivateDocStickySize();
    publicdm->dmFields =
                DM_ORIENTATION   |
                DM_PAPERSIZE     |
                DM_PAPERLENGTH   |
                DM_PAPERWIDTH    |
                DM_SCALE         |
                DM_COPIES        |
                DM_DEFAULTSOURCE |
                DM_TTOPTION      |
                DM_COLLATE       |  // **
                DM_PRINTQUALITY  |
                DM_YRESOLUTION   |
                DM_ICMMETHOD     |  // **
                DM_ICMINTENT     |  // **
                DM_COLOR         |  // **
                DM_DUPLEX        |  // **
                DM_MEDIATYPE     |  // ** add media type
                DM_DITHERTYPE;      // **   add dither type

//  ** - clear this bit later to indicate "capability not supported"

    if(!lpPrinterInfo->devcaps.SupportsDuplexing)
        publicdm->dmFields &= ~DM_DUPLEX ;   // clear flag!

    if(!lpPrinterInfo->devcaps.bCollateSupport)
    {
       publicdm->dmFields &= ~DM_COLLATE ;   // clear flag!
       publicdm->dmCollate = DMCOLLATE_FALSE;
    }
    else
    {
       WORD collate;

       KeywordGetCurrentOption(lppd, IND_COLLATIONINFO, &collate) ;
       if(collate==COLLATE_TRUE)
       {
          publicdm->dmCollate = DMCOLLATE_TRUE;
       }
       else
       {
          publicdm->dmCollate = DMCOLLATE_FALSE;
       }
    }

//#ifdef ADOBE_WEB
    if (dm2->bWebPrinter)
    {
       publicdm->dmFields |= DM_COLLATE ;    // set the flag!
       publicdm->dmCollate = DMCOLLATE_TRUE; // and turn on the dmCollate
    }
//#endif
    if(!lpPrinterInfo->devcaps.color)
    {
        publicdm->dmFields &= ~DM_COLOR ;
        publicdm->dmFields &= ~DM_ICMMETHOD;
        publicdm->dmFields &= ~DM_ICMINTENT;
    }

    if(dm1->PaperOrient == OR_PORTRAIT)
        publicdm->dmOrientation = DMORIENT_PORTRAIT ;
    else
        publicdm->dmOrientation = DMORIENT_LANDSCAPE ;

    {
        LPRESOLUTIONINFO  lpResInfo ;
        WORD      resIndex ;

        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_RESOLUTIONINFO ;

        lpResInfo =
            (LPRESOLUTIONINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray,
                                       HIWORD(lpOptionsBlock) );

        KeywordGetCurrentOption(lppd , IND_RESOLUTIONINFO, &resIndex) ;

        publicdm->dmPrintQuality = lpResInfo[resIndex].res.word.x ;
        publicdm->dmYResolution  = lpResInfo[resIndex].res.word.y ;
    }

    {
        WORD     paperIndex ;
        LPPAPERINFO  lpPaperInfo ;
        DWORD     x, y;
        WORD      paperID;

        KeywordGetCurrentOption(lppd , IND_PAPERINFO, &paperIndex) ;

        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;

        lpPaperInfo = (LPPAPERINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray,
                                            HIWORD(lpOptionsBlock) );

        if(paperIndex == lpPrinterInfo->devcaps.CustomPageSize)
        {
            if (dm1->currentCustPaper != APP_DEFINED)
            {
                paperID = lpPaperInfo[paperIndex].paperID
                                   + dm1->currentCustPaper;
                x = (DWORD) dm1->custPaper[dm1->currentCustPaper].customWidth;
                y = (DWORD) dm1->custPaper[dm1->currentCustPaper].customHeight;
            }
            else
            {
                // App defined
                paperID = lpPaperInfo[paperIndex].paperID + APP_DEFINED;
                x = (DWORD)dm1->appCustWidth;
                y = (DWORD)dm1->appCustHeight;
            }

            publicdm->dmPaperLength = MulDiv((WORD) y, 254, 72);
            publicdm->dmPaperWidth = MulDiv((WORD) x, 254, 72);
        }
        else
        {
            paperID = lpPaperInfo[paperIndex].paperID ;
            x = (DWORD) lpPaperInfo[paperIndex].width;
            y = (DWORD) lpPaperInfo[paperIndex].length;
            publicdm->dmPaperLength = MulDiv((WORD) y, 254, 72);
            publicdm->dmPaperWidth = MulDiv((WORD) x, 254, 72);
        }

        x = (x / (DWORD) 72) * publicdm->dmPrintQuality;
        y = (y / (DWORD) 72) * publicdm->dmYResolution;

        publicdm->dmPaperSize = paperID;

        publicdm->dmPelsWidth =
            publicdm->dmOrientation == DMORIENT_PORTRAIT ? x : y;
        publicdm->dmPelsHeight =
            publicdm->dmOrientation == DMORIENT_PORTRAIT ? y : x;
    }

    publicdm->dmScale   = dm1->Scale ;
    publicdm->dmCopies  = dm1->Copies;

    {
        LPINPUTSLOTINFO  lpInputSlotInfo ;
        WORD  SlotIndex;

        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;

        lpInputSlotInfo =
            (LPINPUTSLOTINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray,
                                      HIWORD(lpOptionsBlock) );

        KeywordGetCurrentOption(lppd , IND_INPUTSLOTINFO, &SlotIndex) ;
        publicdm->dmDefaultSource = lpInputSlotInfo[SlotIndex].slotID ;
    }

    if(lpPSExtDevmode->dm2.iTTSubsFmtSource == TTSUBSFORMAT_DOWNLOADTT)
        publicdm->dmTTOption = DMTT_DOWNLOAD ;
    else
        publicdm->dmTTOption = DMTT_SUBDEV ;

    publicdm->dmDisplayFlags = 0;

    // Fix bug 164376. iColorOption is a printer sticky feature.
    if(lpPSExtDevmode->dm2.iColorOption == COLOR_8BIT)
    {
        publicdm->dmColor = DMCOLOR_MONOCHROME;
        publicdm->dmDisplayFlags |= DM_GRAYSCALE;
    }
    else
        publicdm->dmColor = DMCOLOR_COLOR ;


    {
        WORD     duplexIndex ;

        KeywordGetCurrentOption(lppd , IND_DUPLEXINGINFO, &duplexIndex) ;

        switch  (duplexIndex)
        {
            case  DUPLEXNOTUMBLE :
                publicdm->dmDuplex = DMDUP_VERTICAL ;
                break;
            case  DUPLEXTUMBLE:
                publicdm->dmDuplex = DMDUP_HORIZONTAL ;
                break;
            case  DUPLEX_NONE:
            default:
                publicdm->dmDuplex = DMDUP_SIMPLEX ;
                break;
        }
    }

    /* More fields that moved over from NT */
    publicdm->dmBitsPerPel = 8;

    /* ICM fields. (Fix buf 121363) */
    if (dm1->useImageColorMatching == ICM_DISABLE)
        publicdm->dmICMMethod = DMICMMETHOD_NONE;
    else
    {
        switch (dm1->iColorMatchingMethod)
        {
            case COLOR_MATCHING_ON_HOST:
                publicdm->dmICMMethod = DMICMMETHOD_SYSTEM;
                break;
            case COLOR_MATCHING_ON_PRINTER:
                publicdm->dmICMMethod = DMICMMETHOD_DRIVER;
                break;
            case COLOR_MATCHING_PRINTER_CALIBRATION:
                publicdm->dmICMMethod = DMICMMETHOD_DEVICE;
                break;
            default:
                publicdm->dmICMMethod = DMICMMETHOD_NONE;
                break;
        }
    }
//  publicdm->dmICMMethod = lpPSExtDevmode->dm.useImageColorMatching ?
//        lpPSExtDevmode->dm.iColorMatchingMethod : DMICMMETHOD_NONE;
    publicdm->dmICMIntent = lpPSExtDevmode->dm.iRenderingIntent;

    /* Fields we do not yet support */
    publicdm->dmFormName[0] = '\0';
    publicdm->dmLogPixels = 0;
    publicdm->dmDisplayFrequency = 0L;
   // publicdm->dmMediaType = 0;
   // publicdm->dmDitherType = 0;
    publicdm->dmReserved1 = 0L;
    publicdm->dmReserved2 = 0L;

    rc = TRUE;

EndUpdatePublicDM:
    if (lppd)
        GlobalFreePtr(lppd);

    return rc;
}


int FAR PASCAL DefaultPaperSize(LPPSEXTDEVMODE lpPSExtDevmode,
                                LPWPXBLOCKS lpWPXblock)
{
    LPPRINTERINFO lpPrinterInfo;
    LPMAINKEYHDR  lpCurMainKeyHdr;
    LPPAPERINFO   lpPaperInfo;
    int           defPaperID;
    int           numOptions, i;
    int           myCountry;
    char          szIntl[20], szCountry[40];

    LoadString(ghDriverMod, IDS_INTL, szIntl, 20);
    LoadString(ghDriverMod, IDS_COUNTRY, szCountry, 40);

   {
      BOOL   bFoundInList = FALSE;

      myCountry = GetProfileInt((LPSTR) szIntl, (LPSTR) szCountry,
                                USA_COUNTRYCODE) ;

      switch(myCountry)
      {
         case 0:                         // string was there but 0
         case USA_COUNTRYCODE:           // DEFINED in COUNTRY.H
         case 2:
                  bFoundInList = TRUE;
                  break;
         default:
                  bFoundInList =  (((myCountry >= 50) && (myCountry < 60) && (myCountry != 55)) || // exclude Brazil
                        ((myCountry >= 500) && (myCountry < 600))) ;
                  break;
      }

#if 0
//  eric wants to maintain consistency with Unidrv


      lpBuf = GlobalAllocPtr(GHND, 1024);


      if(lpBuf)
      {
         keyBytesRead = GetPrivateProfileString("DEFAULT_LETTERSIZE_PAPER",
            NULL, "   ", lpBuf, 1024, "pscript.ini");

         for(i = 0 ; i < keyBytesRead ;  )
         {
            iCountry = GetPrivateProfileInt("DEFAULT_LETTERSIZE_PAPER",
               lpBuf+i , 1, "pscript.ini");

            if(myCountry == iCountry)
            {
               bFoundInList = TRUE ;
               break ;
            }
            while(lpBuf[i])
               i++ ;
            if(!lpBuf[++i])
               break ;
         }

         GlobalFreePtr(lpBuf);
      }
#endif



      defPaperID = (bFoundInList) ?
           DMPAPER_LETTER : DMPAPER_A4;
   }


    lpPSExtDevmode->dm.currentCustPaper = 0xFFFF; // custom paper not seleted
    lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;

    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;
    numOptions = lpCurMainKeyHdr->OptionKeyWords.w.length ;

    lpPaperInfo = (LPPAPERINFO) MAKELONG(lpCurMainKeyHdr->extraOptionArray,
                                         HIWORD(lpWPXblock->WPXarrays));

    for (i=0; i<numOptions; i++)
    {
        if (lpPaperInfo[i].paperID == (WORD) defPaperID)
            break;
    }

    if (i < numOptions)
    {
        lpPSExtDevmode->dm.optionState[IND_PAPERINFO].optionKeyIndex = i ;
    }
    return myCountry;
}


//#ifdef ADOBE_WEB
/*****************************************************************************/
/*                            IsWebPrinter                                   */
/* Purpose:                                                                  */
/*      This function checks to see if current printer a Web printer.        */
/* Returns: BOOL                                                             */
/*      TRUE => YES, FALSE => NO.                                            */
/*****************************************************************************/
BOOL FAR PASCAL IsWebPrinter(LPSTR lpFriendly)
{
#ifdef MICROSOFT_DRIVER_VERSION
    return FALSE;
#else
    BOOL   retVal = FALSE; // assume not a Web printer
    int    count;
    char   szDriverName[36];
    char   szWebPrinter[12] = "WEBPrinter";
    DWORD  dwType, dwNeeded;

    if (DrvGetPrinterData(lpFriendly, (LPSTR)INT_PD_PRINTER_MODEL, &dwType,
                          szDriverName, CCHDEVICENAME, &dwNeeded) == ERROR_SUCCESS)
    {
       count = lstrlen(szWebPrinter);
       szDriverName[count] = '\0';
       if(lstrcmp(szDriverName, szWebPrinter) == 0)
       {
          retVal = TRUE;
       }
    }
    return(retVal);
#endif
}
//#endif

/*****************************************************************************/
/*                            IsPS3IPrinter                                   */
/* Purpose:                                                                  */
/*      This function checks to see if current printer a Web printer.        */
/* Returns: BOOL                                                             */
/*      TRUE => YES, FALSE => NO.                                            */
/*****************************************************************************/
BOOL FAR PASCAL IsPS3IPrinter(LPSTR lpFriendly)
{
    return(TRUE);
}

/*****************************************************************************/
/*                            InitDefaultDevmode                             */
/* Purpose:                                                                  */
/*      This function creates a default devmode from values in the WPXblock. */
/* Parameters:                                                               */
/*      lpWPXblock --  pointer to the WPX block.                             */
/*      lpPSExtDevmode -- pointer to the devmode.                            */
/*      friendlyName   -- friendly name of the printer.                      */
/* Returns: BOOL                                                             */
/*      TRUE => sucess, FALSE => failure.                                    */
/*****************************************************************************/
BOOL FAR PASCAL InitDefaultDevmode(LPWPXBLOCKS    lpWPXblock,
                                   LPPSEXTDEVMODE lpPSExtDevmode,
                                   LPBYTE         friendlyName )
{
    LPPDEVICE     lppd ;
    LPPSDEVMODE   dm1;
    LPPSDEVMODE2  dm2;
    WORD          i;
    int           countrycode;
    LPPRINTERINFO lpPrinterInfo ;
    LPMAINKEYHDR  lpCurMainKeyHdr ;
    LPBYTE        lpOptionsBlock;

    lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;
    lpOptionsBlock = lpWPXblock->WPXarrays ;

    dm1 = &lpPSExtDevmode->dm ;
    dm2 = &lpPSExtDevmode->dm2 ;

    /*  don't init public devmode, let it propagate */


    /* set MainKeyHdr default options first! */
    if (!(lppd = (LPPDEVICE) GlobalAllocPtr(GMEM_SHARE|GHND,sizeof(PDEVICE))))
       return FALSE;

    lppd->lpWPXblock = lpWPXblock ;
    lppd->lpPSExtDevmode = lpPSExtDevmode ;

    if( !KeywordSetOptionsToPPDdefault(lppd) )
    {
       if (lppd)
          GlobalFreePtr(lppd);

       return(FALSE);  // something has failed.
    }

    // initialize #copies to 1 because we don't have ui for it
    dm1->Copies = 1;

    // Set default paper size based on country code
    countrycode = DefaultPaperSize(lpPSExtDevmode, lpWPXblock);

    dm1->marginState = DEFAULT_MARGINS ;

    dm1->DspUnits = (countrycode == USA_COUNTRYCODE) ? INCHES_100 :
        MILLIMETERS_10;

    dm1->privateFlags = 0 ;

    dm1->dwTimeStamp = lpPrinterInfo->dwPPDchecksum ;
    dm1->dwRandom = lpPrinterInfo->dwRandom ;

    dm1->useDefaultHalftoneParams = TRUE;

    dm1->bColorToBlack  = FALSE ;

    // Fix bug 164376. iColorOption is a printer sticky feature.
    dm2->iColorOption  = (lpPrinterInfo->devcaps.color) ?
        (COLOR_FULL_COLOR) : (COLOR_8BIT) ;

    dm1->useImageColorMatching = ICM_ALLOW;
    dm1->iColorMatchingMethod = COLOR_MATCHING_ON_HOST;
// ALWAYS_ICM
    dm1->iRenderingIntent = INTENT_SATURATION;

    dm1->dwWatermarkID = 0;

    dm1->bL2MaskedImage = 0;
    dm1->bL3MaskedImage = 0;

    // this value now in bytes - how can you have 12.48 bytes free ?

    CopyStringRefToLPBYTE(lpWPXblock, dm2->password,
                          lpPrinterInfo->password.dword) ;
    dm2->defaultICM[0]  = '\0' ;
    dm2->bAllowExitServer = (lpPrinterInfo->exitServer.w.length != 0);

    // OEMPLUGI begin
    dm1->numOEMDocSticky = lpPrinterInfo->numOEMDocSticky;
    if (lpPrinterInfo->numMainKeyHdrs + dm1->numOEMDocSticky > MAXOPTIONSTATES)
       dm1->numOEMDocSticky = MAXOPTIONSTATES - lpPrinterInfo->numMainKeyHdrs;
    if (dm1->numOEMDocSticky)
    {
        LPBYTE lpOEMDocSticky;
        i = dm1->numOEMDocSticky * sizeof(DWORD);
        lpOEMDocSticky = (LPBYTE)&dm1->optionState[MAXOPTIONSTATES] - i;
        MemSet(lpOEMDocSticky, 0, i);
    }

    // OEMPLUGI begin
#ifdef Adobe_Driver

#ifdef MICROSOFT_DRIVER_VERSION
    dm2->bFAXingP =  dm1->bFAXingD = dm2->bFaxExist = dm2->bWebPrinter = FALSE;
#else

    dm2->bFAXingP = FALSE;
    dm1->bFAXingD = lpPrinterInfo->devcaps.bFaxSupport;
    dm2->bFaxExist = FALSE;
//#ifdef ADOBE_WEB
    dm2->bWebPrinter = IsWebPrinter(friendlyName);
#endif
//#endif
    // PS3I
    dm2->bPS3IPrinter = IsPS3IPrinter(friendlyName);
    dm2->bFax35FontsOnly = FALSE;
#endif
    dm2->TTRasterizer = lpPrinterInfo->devcaps.TTRasterizer;
    dm2->bFullDown = FALSE;
    dm2->bTrueTypeWide = TRUE;
    dm2->bTrueTypeFast = TRUE;

    // Initialize bHalftoneModified flag
    dm2->bHalftoneModified = MODIFIED_NONE;

    dm2->bEUDCAble = FALSE; // by default - no EUDC

    // OEMPLUGI end

    /*
     * Devmode really isn't the place for such horseshit.
     * the UI code could just as easily determine this for itself
     *  instead of adding extra variables to the Devmode.
     */

    {
        LPPAPERINFO  lpPaperInfo ;
        WORD  max, numPapers ;

        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;

        lpPaperInfo = (LPPAPERINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray,
                                            HIWORD(lpOptionsBlock) );

        if(lpPrinterInfo->devcaps.CustomPageSize != 0xFFFF)
        {
            numPapers = lpPrinterInfo->devcaps.CustomPageSize ;
            //  no imageable area allowed for custom page sizes.
        }
        else
            numPapers = lpCurMainKeyHdr->OptionKeyWords.w.length ;

        max = (numPapers > MAXPAPERMARGINS) ? MAXPAPERMARGINS : numPapers ;

        for(i = 0 ; i < max ; i++)
            dm2->revisedPaperMargins[i]  = lpPaperInfo[i].imageableArea ;
    }
    UpdatePublicDevmode(lpWPXblock, lpPSExtDevmode) ;

    lstrcpy(dm1->dm.dmDeviceName, friendlyName ) ;

    /* Call the standard restore defaults for each dialog's data */
    RestoreDeviceDefaults(lpPSExtDevmode, lpWPXblock, 0xFFFFFFFFL);

    RestorePaperDefaults(lpPSExtDevmode, lpWPXblock, 0xFFFFFFFFL);
    RestoreCustPapDefaults(lpPSExtDevmode, lpWPXblock);

    // Both these are needed for the fonts property page and related sub dialog
    RestoreFontsDefaults(lpPSExtDevmode, lppd);
    RestoreSendAsDefaults(lpPSExtDevmode, lpWPXblock);

    RestorePostScriptDefaults(lpPSExtDevmode, lpWPXblock, 0xFFFFFFFFL);

    // Both these are needed for the graphics page and related sub dialog
    RestoreGraphicsDefaults(  lpPSExtDevmode, lpWPXblock, 0xFFFFFFFFL);
    RestoreColorDlgDefaults(lpPSExtDevmode);

    RestoreAdvancedDefaults(lpPSExtDevmode, lpWPXblock);

    // Initialize iDataOutputFormat entry
    if ( lpPrinterInfo->devcaps.iDefaultProtocol > 0)
      dm2->iDataOutputFormat = lpPrinterInfo->devcaps.iDefaultProtocol - 1 ;

    InitializeDrvVariables(lpPSExtDevmode);

    if (lppd)
       GlobalFreePtr(lppd);

    return(TRUE);  // success
}


/*****************************************************************************/
/*                            MergePublicDM                                  */
/* Purpose:                                                                  */
/*      This function merges the public devmode from lpNewExtDevmode into    */
/*      the private portion of lpCurExtDevmode. It does not affect the       */
/*      public portion of lpCurExtDevmode, as that is handled by the         */
/*      function UpdatePublicDevmode().                                      */
/* Parameters:                                                               */
/*      lpWPXblock --  pointer to the WPX block.                             */
/*      lpCurExtDevmode -- pointer to the current devmode.                   */
/*      lpNewExtDevmode -- pointer to the  devmode that is to be merged in.  */
/* Returns: BOOL                                                             */
/*      TRUE => sucess, FALSE => failure.                                    */
/*****************************************************************************/
BOOL NEAR PASCAL MergePublicDM(LPWPXBLOCKS     lpWPXblock,
                               LPPSEXTDEVMODE  lpCurExtDevmode,
                               LPPSEXTDEVMODE  lpNewExtDevmode)
{
    LPPRINTERINFO lpPrinterInfo ;
    LPMAINKEYHDR  lpCurMainKeyHdr ;
    LPBYTE        lpOptionsBlock;
    LPPDEVICE     lppd ;
    LPPSDEVMODE   lpCurdm1, lpNewdm1;    /* Doc sticky private devmode */
    LPDEVMODE     lpCurPublicdm, lpNewPublicdm; /* Public devmode */
    WORD          i;
    BOOL          rc = FALSE;
    WORD               minval[4], maxval[4];

    if (!(lppd = (LPPDEVICE) GlobalAllocPtr(GMEM_SHARE|GHND, sizeof(PDEVICE))))
        goto EndMergePublicDM;

    // Create pdevice
    lppd->lpWPXblock = lpWPXblock ;
    lppd->lpPSExtDevmode = lpCurExtDevmode ;

    lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;
    lpOptionsBlock = lpWPXblock->WPXarrays ;

    lpCurdm1 = &lpCurExtDevmode->dm ;
    lpCurPublicdm = &lpCurdm1->dm ;

    lpNewdm1 = &lpNewExtDevmode->dm ;
    lpNewPublicdm = &lpNewdm1->dm ;

    /* Paper orientation */
    if(lpNewPublicdm->dmFields & DM_ORIENTATION)
    {
        if(lpNewPublicdm->dmOrientation == DMORIENT_PORTRAIT)
        {
            lpCurdm1->PaperOrient = OR_PORTRAIT ;
        }
        else   //  any landscape is OK.
        {
            if(lpCurdm1->PaperOrient == OR_PORTRAIT)
                lpCurdm1->PaperOrient = OR_LANDSCAPE ;
        }
    }

    /* Paper size */
    {
        LPPAPERINFO  lpPaperInfo ;
        WORD numPapers, i, casestudy ;
        BOOL status = FALSE ;

        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;

        lpPaperInfo = (LPPAPERINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray,
                                            HIWORD(lpOptionsBlock) );

        //  determine  case:
        casestudy = 0 ;

        if(!(lpNewPublicdm->dmFields &
             (DM_PAPERLENGTH | DM_PAPERWIDTH | DM_PAPERSIZE)))
        {
            casestudy = 1 ;
        }
        else if(lpNewPublicdm->dmFields & DM_PAPERSIZE)
        {
            if(lpNewPublicdm->dmPaperSize)
            {
                if((lpNewPublicdm->dmPaperSize < DMPAPER_USER) ||
                   (lpNewPublicdm->dmPaperSize >= DMPAPER_CUST + CUST_IDS_RESERVED))
                    casestudy = 2 ;
                else if(lpPrinterInfo->devcaps.CustomPageSize != 0xFFFF &&
                        lpNewPublicdm->dmPaperSize >= DMPAPER_CUST &&
                        lpNewPublicdm->dmPaperSize < DMPAPER_CUST+CUST_IDS_RESERVED)
                    casestudy = 3 ;
                else if(lpPrinterInfo->devcaps.CustomPageSize != 0xFFFF &&
                        (lpNewPublicdm->dmFields & DM_PAPERLENGTH) &&
                        (lpNewPublicdm->dmFields & DM_PAPERWIDTH))
                    casestudy = 4;
            }
        }
        else if(lpPrinterInfo->devcaps.CustomPageSize != 0xFFFF &&
                lpNewPublicdm->dmFields & DM_PAPERLENGTH  &&
                lpNewPublicdm->dmFields & DM_PAPERWIDTH)
        {
            casestudy = 4 ;
        }

        if(casestudy == 1)
        {
            //  no paper specified.  use current paper!
            status = TRUE ;
        }
        else  if(casestudy == 2)
        {
            //  non-custom size specified, attempt to comply.

            numPapers = lpCurMainKeyHdr->OptionKeyWords.w.length ;

            for(i = 0 ; i < numPapers ; i++)
            {
                if(lpPaperInfo[i].paperID == (WORD)lpNewPublicdm->dmPaperSize)
                {
                    status = KeywordSetCurrentOption(lppd , IND_PAPERINFO, i) ;
                    if(!status)
                       goto USE_DEFAULTPAPER ;

                    status = KeywordSetCurrentOption(lppd , IND_PAGEREGIONINFO, i) ;
                    if(!status)
                       goto USE_DEFAULTPAPER ;
                    break;
                }
            }
        }
        else  if(casestudy == 3)
        {
            //  new devmode specifies driver custom sizes.
            status = KeywordSetCurrentOption(lppd , IND_PAPERINFO,
                         lpPrinterInfo->devcaps.CustomPageSize) ;
            if(!status)
                goto USE_DEFAULTPAPER ;

            status = KeywordSetCurrentOption(lppd , IND_PAGEREGIONINFO,
                         lpPrinterInfo->devcaps.CustomPageSize) ;
            if(!status)
                goto USE_DEFAULTPAPER ;

            if(lpNewPublicdm->dmPaperSize == DMPAPER_CUST)
                lpCurdm1->currentCustPaper = 0;
            else if(lpNewPublicdm->dmPaperSize == DMPAPER_CUST+1)
                lpCurdm1->currentCustPaper = 1;
            else if(lpNewPublicdm->dmPaperSize == DMPAPER_CUST+2)
                lpCurdm1->currentCustPaper = 2;
            else if(lpNewPublicdm->dmPaperSize == DMPAPER_CUST+APP_DEFINED)
                lpCurdm1->currentCustPaper = APP_DEFINED;
        }
        else  if(casestudy == 4)
        {
            //  new devmode specifies custom size and dimensions
            //  YES! printer does support custom size !

            LPCUSTPAGEINFO lpCPInfo;
            int            appHeight;
            int            appWidth;
            int            id;

            // convert values from 1 tenths of a millimeter to postscript unit
            appHeight = MulDiv(lpNewPublicdm->dmPaperLength, 72, 254);
            appWidth = MulDiv(lpNewPublicdm->dmPaperWidth, 72, 254);
            lpCPInfo = (LPCUSTPAGEINFO) &lpPrinterInfo->custpageinfo;

            minval[IDX_X_SIZE] = max(lpCPInfo->width.min, MIN_CUST_SIZE);
            minval[IDX_Y_SIZE] = max(lpCPInfo->height.min, MIN_CUST_SIZE);
            maxval[IDX_X_SIZE] = lpCPInfo->width.max;
            maxval[IDX_Y_SIZE] = lpCPInfo->height.max;

            for (id=0; id<NUM_CUST_SIZES; id++)
            {
               if ((int)lpCurdm1->custPaper[id].customHeight == appHeight &&
                   (int)lpCurdm1->custPaper[id].customWidth  == appWidth)
                        break;
            }

            // if Transverse, change width and height         bug #197440
            if ((id < NUM_CUST_SIZES) && (lpCurdm1->custPaper[id].Transverse))
            {
               WORD temp= maxval[IDX_X_SIZE];

               maxval[IDX_X_SIZE] = maxval[IDX_Y_SIZE];
               maxval[IDX_Y_SIZE] = temp;
               temp = minval[IDX_X_SIZE];
               minval[IDX_X_SIZE] = minval[IDX_Y_SIZE];
               minval[IDX_Y_SIZE] = temp;
            }

            if (appHeight >= (int)minval[IDX_Y_SIZE] &&
                appHeight <= (int)maxval[IDX_Y_SIZE] &&
                appWidth  >= (int)minval[IDX_X_SIZE] &&
                appWidth  <= (int)maxval[IDX_X_SIZE])
            {
                status = KeywordSetCurrentOption(lppd , IND_PAPERINFO,
                         lpPrinterInfo->devcaps.CustomPageSize) ;
                if(!status)
                    goto USE_DEFAULTPAPER ;

                status = KeywordSetCurrentOption(lppd , IND_PAGEREGIONINFO,
                         lpPrinterInfo->devcaps.CustomPageSize) ;
                if(!status)
                    goto USE_DEFAULTPAPER ;

                if( id < NUM_CUST_SIZES )
                    lpCurdm1->currentCustPaper = id;
                else
                {
                    // when none of the entries matched, it is the
                    // application defined entry
                    lpCurdm1->appCustHeight = (float) appHeight;
                    lpCurdm1->appCustWidth = (float) appWidth;
                    lpCurdm1->currentCustPaper = APP_DEFINED;
                }
            }
        }

USE_DEFAULTPAPER:

        if(!status)
        {
            //  all other situations requiring driver to punt.
            //  or failure of previous attempts.

            i = lpCurMainKeyHdr->DefaultOptionIndex ;

            status = KeywordSetCurrentOption(lppd , IND_PAPERINFO, i ) ;
            if(!status)
                goto EndMergePublicDM;  // Utterly unable to set papersize.

            status = KeywordSetCurrentOption(lppd , IND_PAGEREGIONINFO, i ) ;
            if(!status)
                goto EndMergePublicDM;  // Utterly unable to set pageregion.
        }
    }


    /* Scale - can't range check */
    if(lpNewPublicdm->dmFields & DM_SCALE)
        lpCurdm1->Scale  = lpNewPublicdm->dmScale ;

    /* Copies - can't range check */
    if(lpNewPublicdm->dmFields & DM_COPIES)
        lpCurdm1->Copies = lpNewPublicdm->dmCopies ;

    /* Input slot */
    if(lpNewPublicdm->dmFields & DM_DEFAULTSOURCE)
    {
        LPINPUTSLOTINFO  lpInputSlotInfo ;
        WORD  defSlotIndex, numSlots ;
        BOOL   status = FALSE ;

        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;

        lpInputSlotInfo =
            (LPINPUTSLOTINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray,
                                      HIWORD(lpOptionsBlock) );

        numSlots = lpCurMainKeyHdr->OptionKeyWords.w.length ;

        for(i = 0 ; i < numSlots ; i++)
        {
            if(lpInputSlotInfo[i].slotID ==
               (WORD)lpNewPublicdm->dmDefaultSource)
            {
                status = KeywordSetCurrentOption(lppd , IND_INPUTSLOTINFO, i) ;
                break;
            }
        }

        if(!status &&
           (DoesKeywordExistByIndex(lppd, ID_KEY_INPUTSLOT) == TRUE))
        {
            // do this only when "InputSlot" keyword exists
            defSlotIndex = lpCurMainKeyHdr->DefaultOptionIndex ;

            status = KeywordSetCurrentOption(lppd , IND_INPUTSLOTINFO,
                                             defSlotIndex) ;
            if(!status)
                goto EndMergePublicDM;
        }
    }

    /* X & Y resolutions */
    if(lpNewPublicdm->dmFields & DM_PRINTQUALITY)
    {
        LPRESOLUTIONINFO  lpResInfo ;
        WORD   numRes ;
        BOOL  status ;

        status = FALSE ;

        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_RESOLUTIONINFO ;

        lpResInfo =
            (LPRESOLUTIONINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray,
                                       HIWORD(lpOptionsBlock) );

        numRes = lpCurMainKeyHdr->OptionKeyWords.w.length ;

        if(lpNewPublicdm->dmFields & DM_YRESOLUTION)
        {
            for(i = 0 ; i < numRes ; i++)
            {
                if ((WORD)lpNewPublicdm->dmPrintQuality ==
                     lpResInfo[i].res.word.x &&
                    (WORD)lpNewPublicdm->dmYResolution  ==
                     lpResInfo[i].res.word.y)
                {
                    status = KeywordSetCurrentOption(lppd , IND_RESOLUTIONINFO,
                                                     i) ;
                    break;
                }
            }
        }
        if(!status)
        {
            for(i = 0 ; i < numRes ; i++)
            {
                if ((WORD)lpNewPublicdm->dmPrintQuality ==
                     lpResInfo[i].res.word.x &&
                    (WORD)lpNewPublicdm->dmPrintQuality  ==
                     lpResInfo[i].res.word.y)
                {
                    status = KeywordSetCurrentOption(lppd , IND_RESOLUTIONINFO,
                                                     i) ;
                    break;
                }
            }
        }

        if(!status)
        {
            i = lpCurMainKeyHdr->DefaultOptionIndex ;
            status = KeywordSetCurrentOption(lppd , IND_RESOLUTIONINFO, i) ;
        }

    }

    /* Color */
    // Fix bug 164376. iColorOption is a printer sticky feature.
    if(lpNewPublicdm->dmFields & DM_COLOR)
    {
        if(lpNewPublicdm->dmColor == DMCOLOR_MONOCHROME)
        {
            lpCurExtDevmode->dm2.iColorOption = COLOR_8BIT ;
        }
        else if (lpPrinterInfo->devcaps.color) // color allowed
        {
            if(lpCurExtDevmode->dm2.iColorOption == COLOR_8BIT)
                lpCurExtDevmode->dm2.iColorOption = COLOR_FULL_COLOR ;
        }
    }

    /* Duplexing */
    if(lpNewPublicdm->dmFields & DM_DUPLEX)
    {
        LPGENERIC_OPTION  lpDuplexInfo ;
        WORD     index ;

        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_DUPLEXINGINFO ;

        lpDuplexInfo =
            (LPGENERIC_OPTION)MAKELONG(lpCurMainKeyHdr->OptionKeyWords.w.offset,
                                       HIWORD(lpOptionsBlock) );

        switch  (lpNewPublicdm->dmDuplex)
        {
            case  DMDUP_VERTICAL:
                index = DUPLEXNOTUMBLE ;
                if(lpPrinterInfo->devcaps.SupportsDuplexing &&
                   !lpDuplexInfo[index].Invocation.w.length)
                    index = DUPLEX_NONE ;
                break;
            case  DMDUP_HORIZONTAL:
                index = DUPLEXTUMBLE ;
                if(lpPrinterInfo->devcaps.SupportsDuplexing &&
                   !lpDuplexInfo[index].Invocation.w.length)
                    index = DUPLEX_NONE ;
                break;
            case  DMDUP_SIMPLEX:
            default:
                index = DUPLEX_NONE ;
                break;
        }
        KeywordSetCurrentOption(lppd, IND_DUPLEXINGINFO, index) ;
    }

    /* Collate */
    if(lpNewPublicdm->dmFields & DM_COLLATE)
    {
        LPGENERIC_OPTION  lpCollationInfo ;
        WORD     index ;

        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_COLLATIONINFO;

        lpCollationInfo =
            (LPGENERIC_OPTION)MAKELONG(lpCurMainKeyHdr->OptionKeyWords.w.offset,
                                       HIWORD(lpOptionsBlock) );

        switch  (lpNewPublicdm->dmCollate)
        {
            case  DMCOLLATE_TRUE:
                index = COLLATE_TRUE;
                if(lpPrinterInfo->devcaps.bCollateSupport &&
                   !lpCollationInfo[index].Invocation.w.length)
                    index = COLLATE_FALSE;
                break;
            default:
                index = COLLATE_FALSE;
                break;
        }
        KeywordSetCurrentOption(lppd, IND_COLLATIONINFO, index);
    }

    /* TrueType substitution */
    if(lpNewPublicdm->dmFields & DM_TTOPTION)   //  2 to 3 state mapping.
    {
        if(lpNewPublicdm->dmTTOption == DMTT_DOWNLOAD)
        {
            lpCurExtDevmode->dm2.iTTSubsFmtSource = TTSUBSFORMAT_DOWNLOADTT ;
        }
        else
        {
            if(lpCurExtDevmode->dm2.iTTSubsFmtSource == TTSUBSFORMAT_DOWNLOADTT)
                lpCurExtDevmode->dm2.iTTSubsFmtSource = TTSUBSFORMAT_TABLE ;
        }
    }

    /* ICM fields (Fix bug 121363) */
    if(lpNewPublicdm->dmFields & DM_ICMINTENT)
        lpCurdm1->iRenderingIntent = (RENDERING_INTENT)(lpNewPublicdm->dmICMIntent);
    if(lpNewPublicdm->dmFields & DM_ICMMETHOD)
    {   // useImageColorMatching could be ALLOW or ALWAYS.
        // change useImageColorMatching to ALLOW only when it's DISABLE
        if( lpCurdm1->useImageColorMatching == ICM_DISABLE )
           lpCurdm1->useImageColorMatching = ICM_ALLOW;
        switch (lpNewPublicdm->dmICMMethod)
        {
            case DMICMMETHOD_NONE:
                lpCurdm1->useImageColorMatching = ICM_DISABLE;
                break;
            case DMICMMETHOD_SYSTEM:
                lpCurdm1->iColorMatchingMethod = COLOR_MATCHING_ON_HOST;
                break;
            case DMICMMETHOD_DRIVER:
                lpCurdm1->iColorMatchingMethod = COLOR_MATCHING_ON_PRINTER;
                break;
            case DMICMMETHOD_DEVICE:
                lpCurdm1->iColorMatchingMethod = COLOR_MATCHING_PRINTER_CALIBRATION;
                break;
            default:
                lpCurdm1->useImageColorMatching = ICM_DISABLE;
                break;
        }
    }

    rc = TRUE; // success

EndMergePublicDM:
    if (lppd)
        GlobalFreePtr(lppd);
    return rc;
}


/*****************************************************************************/
/*                            MergeDocStickyDM                               */
/* Purpose:                                                                  */
/*      This function merges the document sticky part of the private devmode */
/*      from lpNewExtDevmode into the private portion of lpCurExtDevmode.    */
/*      It does not affect the public portion of lpCurExtDevmode, as that is */
/*      handled by the function UpdatePublicDevmode().                       */
/* Parameters:                                                               */
/*      lpWPXblock --  pointer to the WPX block.                             */
/*      lpCurExtDevmode -- pointer to the current devmode.                   */
/*      lpNewExtDevmode -- pointer to the  devmode that is to be merged in.  */
/*      bRestricted -- Only merges fields that are "100% doc sticky"         */
/* Returns: Nothing                                                          */
/*****************************************************************************/
void NEAR PASCAL MergeDocStickyDM(LPWPXBLOCKS    lpWPXblock,
                                  LPPSEXTDEVMODE lpCurExtDevmode,
                                  LPPSEXTDEVMODE lpNewExtDevmode,
                                  MERGETYPE      mergeType)
{
    if (mergeType == MERGE_DOC)
    {
        MemCopy((LPVOID) ((LPBYTE) &lpCurExtDevmode->dm + sizeof(DEVMODE)),
             (LPVOID) ((LPBYTE) &lpNewExtDevmode->dm + sizeof(DEVMODE)),
             (DWORD) lpNewExtDevmode->dm.dm.dmDriverExtra);
    }
    else
    {
        // DOCRESTRICTED && CACHEDRESTRICTED
        LPPSDEVMODE lpCurdm1 = &lpCurExtDevmode->dm;
        LPPSDEVMODE lpNewdm1 = &lpNewExtDevmode->dm;
        LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo;

        lpCurdm1->DspUnits = lpNewdm1->DspUnits;
        lpCurdm1->Copies = lpNewdm1->Copies;
        lpCurdm1->layout = lpNewdm1->layout;
        lpCurdm1->PaperOrient = lpNewdm1->PaperOrient;
        lpCurdm1->marginState = lpNewdm1->marginState;
        lpCurdm1->bOutputOrder = lpNewdm1->bOutputOrder;

        if (lpPrinterInfo->devcaps.color)
        {
            // Fix bug 164376. iColorOption is a printer sticky feature.
            // lpCurdm1->iColorOption = lpNewdm1->iColorOption;
            lpCurdm1->useImageColorMatching =
                lpNewdm1->useImageColorMatching;
            lpCurdm1->iColorMatchingMethod = lpNewdm1->iColorMatchingMethod;
            lpCurdm1->iRenderingIntent = lpNewdm1->iRenderingIntent;
        }
        lpCurdm1->useDefaultHalftoneParams =
         lpNewdm1->useDefaultHalftoneParams;
        lpCurdm1->ScreenFrequency = lpNewdm1->ScreenFrequency;
        lpCurdm1->ScreenAngle = lpNewdm1->ScreenAngle;
        lpCurdm1->bNegImage = lpNewdm1->bNegImage;
        lpCurdm1->bMirror = lpNewdm1->bMirror;
        lpCurdm1->bColorToBlack = lpNewdm1->bColorToBlack;
        lpCurdm1->Scale = lpNewdm1->Scale;
        lpCurdm1->enumDialect = lpNewdm1->enumDialect;
        lpCurdm1->privateFlags = lpNewdm1->privateFlags;

        if (lpPrinterInfo->devcaps.CustomPageSize != 0xffff)
        {
            LPBYTE lpCur, lpNew;

            lpCurdm1->currentCustPaper = lpNewdm1->currentCustPaper;
            lpCur = (LPBYTE) lpCurdm1->custPaper;
            lpNew = (LPBYTE) lpNewdm1->custPaper;
            MemCopy(lpCur, lpNew, sizeof(CUSTPAPER) * (DWORD) NUM_CUST_SIZES);
            lpCurdm1->appCustWidth = lpNewdm1->appCustWidth;
            lpCurdm1->appCustHeight = lpNewdm1->appCustHeight;
        }

        // Some extra stuff has to be for CACHEDRESTRICTED
        if (mergeType == MERGE_CACHEDRESTRICTED)
        {
            LPPSDEVMODE2 lpCurdm2 = &lpCurExtDevmode->dm2;
            LPPSDEVMODE2 lpNewdm2 = &lpNewExtDevmode->dm2;

            lpCurdm2->fHeader = lpNewdm2->fHeader;
            lpCurdm2->bErrHandler = lpNewdm2->bErrHandler;
            lpCurdm2->bPrintPageBorder = lpNewdm2->bPrintPageBorder;
            lpCurdm2->iDLFontFmt = lpNewdm2->iDLFontFmt;

#ifdef ADOBE_DRIVER
            lpCurdm2->bFax35FontsOnly = lpNewdm2->bFax35FontsOnly;
#endif
            lpCurdm2->iPS_DLFontFmt = lpNewdm2->iPS_DLFontFmt;
            lpCurdm2->iTTSubsFmtSource = lpNewdm2->iTTSubsFmtSource;
            lpCurdm2->iMinOutlinePPEM = lpNewdm2->iMinOutlinePPEM;
            lpCurdm2->iJobTimeout = lpNewdm2->iJobTimeout;
            lpCurdm2->iWaitTimeout = lpNewdm2->iWaitTimeout;
#ifndef ADOBE_DRIVER_42
            if (lpPrinterInfo->devcaps.languageLevel >= 2)
                lpCurdm2->bfUseLevel2 = lpNewdm2->bfUseLevel2;
            lpCurdm2->bCompress = lpNewdm2->bCompress;
#else
            lpCurdm2->useLanguageLevel = lpNewdm2->useLanguageLevel;
#endif

            lpCurdm2->iDataOutputFormat = lpNewdm2->iDataOutputFormat;
            lpCurdm2->bSendCtrlDBefore = lpNewdm2->bSendCtrlDBefore;
            lpCurdm2->bSendCtrlDAfter = lpNewdm2->bSendCtrlDAfter;
            lpCurdm2->bFavorTT = lpNewdm2->bFavorTT;
            lpCurdm2->bHalftoneModified = lpNewdm2->bHalftoneModified;
        }
        else if (mergeType == MERGE_DOC)
        {
            // Copy relevant parts of optionarray
            LPPDEVICE     lppd;
            LPBOOL          lpOptionArray = NULL;
            int           i, iBaseIndex, iLength;

            lppd = (LPPDEVICE)GlobalAllocPtr(GMEM_SHARE|GHND, sizeof(PDEVICE));
            lpOptionArray = (LPBOOL)GlobalAllocPtr(GHND, MAXOPTIONSTATES*sizeof(BOOL));

            if (lppd &&  lpOptionArray)
            {
                lppd->lpWPXblock = lpWPXblock;


                for (i=IND_PAPERINFO; i<IND_MEMORYINFO; i++)
                {
                    lppd->lpPSExtDevmode = lpNewExtDevmode;
                    KeywordGetCurrentOptionArray(lppd, i, lpOptionArray);
                    lppd->lpPSExtDevmode = lpCurExtDevmode;
                    KeywordSetCurrentOptionArray(lppd, i, lpOptionArray);
                }

                iBaseIndex = lpPrinterInfo->DocSticky.w.offset;
                iLength    = lpPrinterInfo->DocSticky.w.length;
                for (i=0; i<iLength; i++)
                {
                     lppd->lpPSExtDevmode = lpNewExtDevmode;
                     KeywordGetCurrentOptionArray(lppd, i+iBaseIndex, lpOptionArray);
                     lppd->lpPSExtDevmode = lpCurExtDevmode;
                     KeywordSetCurrentOptionArray(lppd, i+iBaseIndex, lpOptionArray);
                }
            }
            if (lpOptionArray)
               GlobalFreePtr(lpOptionArray);
            if (lppd)
               GlobalFreePtr(lppd);
        }

        // OEMPLUGI begin
        if (lpCurdm1->numOEMDocSticky == lpNewdm1->numOEMDocSticky)
        {
            LPBYTE  lpCur, lpNew;
            int     size;

            size = lpCurdm1->numOEMDocSticky * sizeof(DWORD);
            lpCur = (LPBYTE)&lpCurdm1->optionState[MAXOPTIONSTATES] - size;
            lpNew = (LPBYTE)&lpNewdm1->optionState[MAXOPTIONSTATES] - size;
            MemCopy(lpCur, lpNew, size);
        }

#ifdef ADOBE_DRIVER
        lpCurdm1->dwWatermarkID = lpNewdm1->dwWatermarkID;
        lpCurdm1->WMFirstPageOnly = lpNewdm1->WMFirstPageOnly;
        lpCurdm1->WMForeGround = lpNewdm1->WMForeGround;
        lpCurdm1->WMOutline = lpNewdm1->WMOutline;
#endif
        // OEMPLUGI end
    }
}


/*****************************************************************************/
/*                            GetMergeType                                   */
/* Purpose:                                                                  */
/*      This function decides what kind of merging has to done. It takes a   */
/*      WPX block, and a devmode and checks to see if it is our devmode, and */
/*      if so whether timestamps matches, and if it not ours, do we          */
/*      recognize it as a vaid Windows devmode etc., and comes up with a     */
/*      merge type.                                                          */
/* Parameters:                                                               */
/*      lpWPXblock --  pointer to the WPX block.                             */
/*      lpPSExtDevmode -- pointer to the devmode.                            */
/* Returns: MERGETYPE                                                        */
/*          MERGE_USEDEFAULTS -> Cannot recognize the devmode. Throw it away */
/*          MERGE_PUBLICDM    -> Not ours, use only public part of devmode   */
/*          MERGE_DOCRESTRICTED -> Ours, but timestamps do not match.        */
/*          MERGE_FULL        -> Everything is good - take it as is.         */
/*****************************************************************************/
MERGETYPE FAR PASCAL GetMergeType(LPWPXBLOCKS    lpWPXblock,
                                  LPPSEXTDEVMODE lpPSExtDevmode)
{
    LPPRINTERINFO lpPrinterInfo ;
    LPDEVMODE     lpPublicdm = &lpPSExtDevmode->dm.dm;
    LPWORD        lpCRC_16_tab = (LPWORD) crc_16_tab;
    MERGETYPE     rc = MERGE_USEDEFAULTS;

    lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;

    /* Make sure size is as large as the first few fields we touch */
    if (!CHECKSIZE(lpPSExtDevmode, CCHDEVICENAME + 4*sizeof(UINT)))
        goto EndGetMergeType;

    if (lpPublicdm->dmSpecVersion == 0x400 &&
        lpPublicdm->dmSize == sizeof(DEVMODE))
    {
        /* Chicago devmode */
        rc = MERGE_PUBLICDM;    /* Do this at the very least */

        /* Check if it is the current version of our driver */
        if (lpPublicdm->dmDriverVersion == DRIVER_VERSION)
        {
            BOOL bProceed = TRUE;

            if (!CHECKSIZE(lpPSExtDevmode, sizeof(PSDEVMODE)))
                goto EndGetMergeType;

            /*
             * Optimistically we shall give the best mergeType now. If
             * timestamps do not match, we shall degrade to MERGE_DOCRESTRICTED.
             */
            if (lpPublicdm->dmDriverExtra == sizeof(PSEXTDEVMODE) -
                sizeof(DEVMODE))
                rc = MERGE_FULL;
            else if (lpPublicdm->dmDriverExtra == GetPrivateDocStickySize())
                rc = MERGE_DOC;
            else
                bProceed = FALSE; /* Size don't match -> MERGE_PUBLICDM */

            if (bProceed)
            {
                /* Do CRCs match */
                if  (lpPSExtDevmode->dm.dwTimeStamp != lpPrinterInfo->dwPPDchecksum)
                    rc = MERGE_DOCRESTRICTED; /* Need to validate */
            }
        }
    }    /* Chicago devmode */
    else if (lpPublicdm->dmSpecVersion >= 0x300)
    {
        /*
         * Windows 3.0, Windows 3.1, or Windows NT devmode.
         * We support public devmode merge only.
         */

        rc = MERGE_PUBLICDM;
    }

EndGetMergeType:
    switch (rc)
    {
        case MERGE_PUBLICDM:
            /* This isn't fool-proof. But what can we do? */
            if (!CHECKSIZE(lpPSExtDevmode, lpPublicdm->dmSize))
                rc = MERGE_USEDEFAULTS;
            break;
        case MERGE_DOC:
        case MERGE_DOCRESTRICTED:
            /* Size already checked. Do only checksum */
            if (lpPSExtDevmode->dm.check1 !=
                CalcCRC((LPSTR)&lpPSExtDevmode->dm.dwTimeStamp,
                        GetPrivateDocStickySize() - 2*sizeof(WORD),
                        0xffff, lpCRC_16_tab))
                rc = MERGE_PUBLICDM;
            break;
        case MERGE_FULL:
            if ((!CHECKSIZE(lpPSExtDevmode, sizeof(PSEXTDEVMODE))) ||
                (lpPSExtDevmode->dm.check2 !=
                 CalcCRC((LPSTR)&lpPSExtDevmode->dm.dwTimeStamp,
                        sizeof(PSEXTDEVMODE) - sizeof(DEVMODE) - 2*sizeof(WORD),
                        0xffff, lpCRC_16_tab)))
            {
                /* Size checked to be at least as large as PSDEVMODE */
                if (lpPSExtDevmode->dm.check1 !=
                    CalcCRC((LPSTR)&lpPSExtDevmode->dm.dwTimeStamp,
                            GetPrivateDocStickySize() - 2*sizeof(WORD),
                            0xffff, lpCRC_16_tab))
                    rc = MERGE_PUBLICDM;
                else
                    rc = MERGE_DOC;
            }
            break;
    }

    return rc;
}


/*****************************************************************************/
/*                            MergeDevmode                                   */
/* Purpose:                                                                  */
/*      This function merges lpNewExtDevmode into lpCurExtDevmode.           */
/* Parameters:                                                               */
/*      lpWPXblock --  pointer to the WPX block.                             */
/*      lpCurExtDevmode -- pointer to the current devmode.                   */
/*      lpNewExtDevmode -- pointer to the devmode that is merged in.         */
/*      mergeType -- Specifies what kind of merge is to be done.             */
/* Returns: BOOL                                                             */
/*      TRUE => sucess, FALSE => failure.                                    */
/*****************************************************************************/
BOOL NEAR PASCAL MergeDevMode(LPWPXBLOCKS lpWPXblock,
                              LPPSEXTDEVMODE lpCurExtDevmode,
                              LPPSEXTDEVMODE lpNewExtDevmode,
                              MERGETYPE mergeType)
{
    BOOL rc = TRUE;

    /*
     * This function should always receive non null values for lpNewExtDevmode
     * and lpCurExtDevmode.
     */

    switch (mergeType) {
        case MERGE_FULL:
            MemCopy((LPVOID) lpCurExtDevmode, (LPVOID) lpNewExtDevmode,
                    (DWORD) sizeof(PSEXTDEVMODE));
            break;

        case MERGE_DOC:
        case MERGE_DOCRESTRICTED:
        case MERGE_CACHEDRESTRICTED:
            MergeDocStickyDM(lpWPXblock, lpCurExtDevmode,
                             lpNewExtDevmode, mergeType);
            /* Fall thu' */

        case MERGE_PUBLICDM:
            rc = MergePublicDM(lpWPXblock, lpCurExtDevmode, lpNewExtDevmode);
            break;

        default:
            break;
    }

    return rc;
}

/*****************************************************************************/
/*                            UpdateICMRegistry                              */
/* Purpose:                                                                  */
/*      This function updates the registry with the ICM info for those       */
/*      who upgraded from Win95 to Win98                                     */
/* Parameters:                                                               */
/*      lpFriendly --  friendly name of printer                              */
/*      lpDevName -- device name                                             */
/* Returns: none                                                             */
/*****************************************************************************/
VOID NEAR PASCAL UpdateICMRegistry( LPSTR lpFriendly, LPSTR lpDevName )
{   HKEY  hKeyPrn, hKeyEnv;
    char  szKey[256], value[256];
    DWORD valueType, dataSize = sizeof( value );

    LoadString(ghDriverMod, IDS_REGSTR_PRN_PRINTER, value, sizeof( value ));
    wsprintf(szKey, value, (LPSTR)lpFriendly);
    strcat(szKey, "\\PrinterDriverData");
    if (RegOpenKey(HKEY_LOCAL_MACHINE, szKey, &hKeyPrn) == ERROR_SUCCESS)
    {
        if (RegQueryValueEx( hKeyPrn, "ICMProfile", NULL, &valueType, value, &dataSize ) != ERROR_SUCCESS)
        {
            LoadString(ghDriverMod, IDS_REGSTR_ENV_DRIVERS, value, sizeof( value ));
            wsprintf(szKey, value, (LPSTR)lpDevName);
            if(RegOpenKey(HKEY_LOCAL_MACHINE, szKey, &hKeyEnv) == ERROR_SUCCESS)
            {   dataSize = sizeof( value );
                if (RegQueryValueEx( hKeyEnv, "Dependent Files", NULL, &valueType, value, &dataSize ) == ERROR_SUCCESS)
                {   LPSTR p, pData = szKey, lpszName;
                    int len, total = 0;
                    *pData = 0;
                    for( p=value; *p && p<(LPSTR)value+dataSize; p += len+1 )
                    {   len = lstrlen( p );
                        lpszName = p + len - 1;
                        while( lpszName >= p && *lpszName != '.' )
                           lpszName--;
                        if (!lstrcmp( lpszName, ".ICM" ))
                        {
                            while( lpszName >= p && *lpszName != '\\' )
                               lpszName--;
                            lpszName++;
                            lstrcpy( pData, lpszName );
                            total += lstrlen( pData ) + 1;
                            pData = (LPSTR)szKey + total;
                        }
                    }
                    if( *szKey )
                    {
                        *pData = 0;
                        RegSetValueEx(hKeyPrn, "ICMProfile", NULL, REG_BINARY, szKey, total + 1);
                    }
                }
                RegCloseKey(hKeyEnv);
            }
        }
        RegCloseKey(hKeyPrn);
    }
}

/*****************************************************************************/
/*                       EnterDevMode                                        */
/*  function:                                                                */
/*       This is the main function that does the work of all the devmode     */
/*       related entry points in the driver.                                 */
/*  parameters:                                                              */
/*       hWnd -- parent window handle                                        */
/*       hInst -- instance handle                                            */
/*       lpdmOutput -- pointer to receive a devmode                          */
/*       lpFriendly -- friendly name string                                  */
/*       lpPort -- port name string                                          */
/*       lpdmInput -- pointer to pass in a devmode                           */
/*       lpProfile -- pointer to the name of an alternate profile            */
/*                    file to use for storing device records                 */
/*       lpfnAdd -- from ExtDeviceModePropSheet                              */
/*       lParam -- from ExtDeviceModePropSheet                               */
/*       wMode -- mode of operation                                          */
/*       wFrom -- specifies if call was made from ExtDeviceMode,             */
/*                AdvancedSetupDialog, or ExtDeviceModePropSheet.            */
/*  returns:                                                                 */
/*       short -- as defined in the the DDK                                  */
/*   NOTE:                                                                   */
/*       since we don't use WIN.INI for storing driver data, we do not       */
/*       use lpProfile if it is provided.                                    */
/*****************************************************************************/
short NEAR PASCAL EnterDevMode(HWND                 hWnd,
                               HANDLE               hInst,
                               LPPSEXTDEVMODE       lpdmOutput,
                               LPSTR                lpFriendly,
                               LPSTR                lpPort,
                               LPPSEXTDEVMODE       lpdmInput,
                               LPSTR                lpProfile,
                               LPFNADDPROPSHEETPAGE lpfnAdd,
                               LPARAM               lParam,
                               WORD                 wMode,
                               WORD                 wFrom)
{
    LPPRINTERINFO  lpPrinterInfo;
    LPPSEXTDEVMODE lpdmCached = NULL;
    LPDRIVERINFO   lpDrvInfo;
    LPWPXBLOCKS    lpWPXblock ;
    LPSTR          lpDevName;
    DWORD          dwType, dwNeeded, rc;
    MERGETYPE      mergeType;
    short          dialogStatus = -1;
    char           szDevName[CCHDEVICENAME];
    BOOL           status = FALSE;
    BOOL           bDoSetEnv = FALSE;
    char           temp1[60], temp[60]; // temp strings.
    LPSTR          p;

    if(DM_PROMPT & wMode)
    {
       // Register custom spin control which can handle the DWORD value.
       RegisterLongSpinControlClass(ghDriverMod);
    }

    // Get printer model name
    lpDevName = (LPSTR) szDevName;
    lpDevName[0] = '\0';                /* Null intialize it */
    if (DrvGetPrinterData(lpFriendly, (LPSTR)INT_PD_PRINTER_MODEL, &dwType, lpDevName,
                          CCHDEVICENAME, &dwNeeded) != ERROR_SUCCESS)
    {
        /* Unknown model - use default printer. */
    LoadString(ghDriverMod, IDS_DEFAULTPRINTER, lpDevName, CCHDEVICENAME);
    }

    // Before we can do anything else, we need to get the printer information
    // and allocate a DRIVERINFO structure.
    if (!(lpWPXblock=GetPrinter(lpDevName)))
        return -1;

                                        /* if do not know the name of the   */
                                        /* help file, read it from registry */
    if (!*szHelpFile)                   /* "ADOBEPS4.HLP"                   */
        GetHelpNameFromModelName(lpDevName, szHelpFile, sizeof(szHelpFile));
    if (!*szIniCreator)                 /* "ADOBEPS4.DRV Version 4.1"       */
        GetIniCreatorFromModelName(lpDevName, szIniCreator, sizeof(szIniCreator));

    if (!(lpDrvInfo=(LPDRIVERINFO)GlobalAllocPtr(GMEM_SHARE|GHND,
                                                 sizeof(DRIVERINFOT))))
    {
        FreePrinter(lpWPXblock);
        return -1;
    }

    lpPrinterInfo = (LPPRINTERINFO) lpWPXblock->WPXprinterInfo;

    // Update ICMProfile in the Registry for those who upgraded from 95 to 98
    if (lpPrinterInfo->devcaps.color && !IsWin40())
        UpdateICMRegistry( lpFriendly, lpDevName );

    // Initialize as much of lpDrvInfo as we can

    // OEMPLUGI begin
    lpDrvInfo->hOemCust = NULL;
#ifdef Adobe_Driver
    lpDrvInfo->hPSFax   = NULL;
//#ifdef ADOBE_WEB
    lpDrvInfo->hWebPrinter = NULL;
//#endif
#endif
    // OEMPLUGI end

    lpDrvInfo->lpUICArray = (LPUICARRAY)GlobalAllocPtr(GMEM_SHARE|GHND,
                              lpPrinterInfo->numMainKeyHdrs * sizeof(UICARRAY));
    if (!lpDrvInfo->lpUICArray)
    {
        GlobalFreePtr(lpDrvInfo);
        FreePrinter(lpWPXblock);
        return -1;
    }
    lpDrvInfo->bAllowConstraint = FALSE;
    lpDrvInfo->wMode = wMode;
    lpDrvInfo->wFlags |= wFrom;
    lpDrvInfo->pDev.lpWPXblock = lpWPXblock;
    lpDrvInfo->ghDriverMod = ghDriverMod;
    lpDrvInfo->lpdmOutput = lpdmOutput;
    lpDrvInfo->bValidateOptions = TRUE;
    lpDrvInfo->bSaveFontAssignments = FALSE;
    if (lpPort){
        lstrcpy(lpDrvInfo->pDev.szPortName, lpPort);
        }
    else {
        // Find the portname from WIN.INI. Fix bug 75, 3-8-95, PPeng
        temp[0]=0;
        LoadString(ghDriverMod, IDS_DEVICES_IN_WININI, (LPSTR)temp1, sizeof(temp1));
        GetProfileString((LPSTR)temp1, lpFriendly, "", (LPSTR)temp, sizeof(temp));
        if (temp[0]!=0){
           p=(LPSTR)_fstrchr(temp,',');
           if (p!=NULL)
              lstrcpy(lpDrvInfo->pDev.szPortName, (LPSTR)(p+1) );
           }
        }

    rc = DrvGetPrinterData(lpFriendly, (LPSTR)INT_PD_DEFAULT_DEVMODE, &dwType,
                           (LPBYTE)&lpDrvInfo->DMScratch,
                           sizeof(PSEXTDEVMODE), &dwNeeded);

    if (wFrom != DI_ADVSETUPDLG)
    {
        /*
         * Stuff that only happens on ExtDeviceMode calls--blocking,
         * reading the current environment, etc.
         *
         * Get the current settings, either from the cache or generate
         * defaults.
         */

        if (rc == ERROR_SUCCESS)
        {
           lpdmCached = &lpDrvInfo->DMScratch;
        }

        if (lpdmCached)
        {
            if((mergeType = GetMergeType(lpWPXblock, lpdmCached)) == MERGE_FULL)
            {
                status=TRUE;
            }
            else
            {
                PSEXTDEVMODE dmTemp;

                dmTemp = *lpdmCached;    /* Save the bad cached devmode */
                status = InitDefaultDevmode(lpWPXblock, &lpDrvInfo->DMScratch,
                                            lpFriendly);

                // For a cached devmode, DOCRESTRICTED is actually
                // CACHEDRESTRICTED.
                if (mergeType == MERGE_DOCRESTRICTED)
                    mergeType = MERGE_CACHEDRESTRICTED;

                if (status && (mergeType != MERGE_USEDEFAULTS))
                {
                    status = MergeDevMode(lpWPXblock, &lpDrvInfo->DMScratch,
                                          (LPPSEXTDEVMODE) &dmTemp, mergeType);
                }
                /* The cached devmode was not good, so cache this */
                bDoSetEnv = TRUE;
            }
        }
        else
        {
            /* No cached devmode */
            status = InitDefaultDevmode(lpWPXblock, &lpDrvInfo->DMScratch,
                                        lpFriendly);

            /*
             * For upgradability read profile from win.ini or specified
             * lpProfile and merge into DMScratch.
             */
            MergeProfileWithDevmode(lpWPXblock, &lpDrvInfo->DMScratch,
                                    lpProfile, lpDevName, lpPort);
            /* We didn't find a cached devmode, so cache this */
            bDoSetEnv = TRUE;
        }

        if (bDoSetEnv)
        {
            UpdatePublicDevmode(lpWPXblock, &lpDrvInfo->DMScratch);
            lpDrvInfo->DMScratch.dm.dm.dmDriverExtra = sizeof(PSEXTDEVMODE) -
                sizeof(DEVMODE);
            DrvSetPrinterData(lpFriendly, (LPSTR)INT_PD_DEFAULT_DEVMODE,
                              (DWORD)REG_BINARY,
                              (LPBYTE)&lpDrvInfo->DMScratch,
                              sizeof(PSEXTDEVMODE));
        }

        if(status == FALSE)
            goto IEDM_exit;

        // If necessary, merge input DEVMODE with global settings
        if((DM_MODIFY & wMode) && lpdmInput)
        {
            mergeType = GetMergeType(lpWPXblock, lpdmInput);
            // 32 bit apps get full devmode. Merge only doc sticky part.
            if (mergeType == MERGE_FULL)
                mergeType = MERGE_DOC;
            status = MergeDevmode(lpWPXblock, &lpDrvInfo->DMScratch,
                                  lpdmInput, mergeType) ;
            if(status == FALSE)
                goto IEDM_exit;
        }
    }
    else
    {
        /* Stuff to do for AdvancedSetUpDialog only... */
        /*
         * Get our base devmode - from environment or default as the case may
         * be. Then merge in the doc supplied devmode.
         */
        if (rc == ERROR_SUCCESS)
        {
            if((mergeType = GetMergeType(lpWPXblock,
                                         &lpDrvInfo->DMScratch)) != MERGE_FULL)
            {
                PSEXTDEVMODE dmTemp;

                dmTemp = lpDrvInfo->DMScratch; /* Save the bad cached devmode */
                InitDefaultDevmode(lpWPXblock, &lpDrvInfo->DMScratch,
                                   lpFriendly);

                // For a cached devmode, DOCRESTRICTED is actually
                // CACHEDRESTRICTED.
                if (mergeType == MERGE_DOCRESTRICTED)
                    mergeType = MERGE_CACHEDRESTRICTED;

                MergeDevMode(lpWPXblock, &lpDrvInfo->DMScratch,
                             (LPPSEXTDEVMODE) &dmTemp, mergeType);
            }
        }
        else
        {
            InitDefaultDevmode(lpWPXblock, &lpDrvInfo->DMScratch, lpFriendly);
        }

        // Now merge in the doc supplied devmode
        mergeType = GetMergeType(lpWPXblock, lpdmInput);
        // 32 bit apps get full devmode. Merge only doc sticky part.
        if (mergeType == MERGE_FULL)
            mergeType = MERGE_DOC;
        MergeDevMode(lpWPXblock, &lpDrvInfo->DMScratch, lpdmInput, mergeType);
    }

    lpDrvInfo->lpDM = &(lpDrvInfo->DMScratch);

    if(DM_PROMPT & wMode)
    {
        // perform this to ensure consistent set of options
        // is presented to user.

        ValidateOptions(lpDrvInfo, lpWPXblock, &lpDrvInfo->DMScratch);
        InitializeDrvVariables(&lpDrvInfo->DMScratch);
        UpdatePublicDevmode(lpWPXblock,&lpDrvInfo->DMScratch);
        lpDrvInfo->wFlags |= DI_VALIDATED;

        lpDrvInfo->DMSave=lpDrvInfo->DMScratch;
        lpDrvInfo->bChanged = FALSE;

#ifdef Adobe_Driver
        lpDrvInfo->wmChanged = FALSE;
#endif
        lpDrvInfo->bPainting = FALSE;

        lpDrvInfo->pDev.sMagic=LUCAS;
        lpDrvInfo->pDev.lpPSExtDevmode=lpDrvInfo->lpDM;

        DrvStateRead(&(lpDrvInfo->pDev),lpDrvInfo->lpDM);

        /*
         * bring up our property sheets here.
         * the result is to modify DMScratch
         * note:  don't ever read or write to the public
         * DEVMODE.  Note that the dialog procs will make
         * sure that lpDrvInfo->lpDM points to the right
         * thing when we're all done.
         */

        {
            PROPSHEETPAGE       propShPage[NUM_PRSHT_PAGES];
            WORD                wLoop, wUsed = 0;
            LPPROPERTYSHEETPROC lpPropertySheet;
            LPCREATEPROC        lpCreateProc;

            // OEMPLUGI begin
#ifdef Adobe_Driver
            DWORD dwPSFaxPagesToDisplay = PS_DISPLAY_ALL;
//#ifdef ADOBE_WEB
            DWORD dwWebPrinterPagesToDisplay = PS_DISPLAY_ALL;
//#endif
#endif
            PROPSHEETPAGE FAR *lpPropSheetArray;
            BOOL              flStub;     // TH 03/17/95
            int iNumOemPropPages = 0;
            int iNumPSFaxPropPages = 0;
//#ifdef ADOBE_WEB
            int iNumWebPrinterPropPages = 0;
//#endif
            DWORD dwDrvPagesToDisplay = PS_DISPLAY_ALL;
            DWORD dwOEMPagesToDisplay = PS_DISPLAY_ALL;
            WORD  flEntry;
            LPPRINTERINFO lpPrinterInfo = NULL;
            LPSTR lpFileName = NULL;
            BOOL retval;
            // OEMPLUGI end


            /* Zero-Init propShPage */
            MemSet((LPVOID) propShPage,0,
                   (long)NUM_PRSHT_PAGES * sizeof(PROPSHEETPAGE));

            SetDlgFlags(lpDrvInfo);

            /* OEMPLUGI begin */
            lpDrvInfo->lpszFriendly = lpFriendly;
            lpDrvInfo->lpszPort = lpPort;

            lpPrinterInfo = (LPPRINTERINFO)(lpWPXblock->WPXprinterInfo);
            lpFileName = StringRefToLPBYTE(&(lpDrvInfo->pDev), lpPrinterInfo->PCFileName.dword);
            switch(wFrom)
            {
                case DI_ADVSETUPDLG:
                    flEntry = ADVSETUPDLG;
                    break;
                case DI_EXTDEVMODE:
                    flEntry = EXTDEVMODE;
                    break;
                case DI_PROPSHEET:
                    flEntry = PROPSHEET;
                    break;
            }
            if (lpPrinterInfo->bOEMExist)
                lpDrvInfo->hOemCust = AdobeOEMInitDllStub(lpDrvInfo,lpFileName,
                                                           DLL_TYPE_OEM_CUST, flEntry);

#ifdef Adobe_Driver
            if (wFrom == DI_PROPSHEET)   // Only call FAX dll if we're in Printer folder
                lpDrvInfo->hPSFax   = AdobeOEMInitDllStub(lpDrvInfo,NULL,
                                                   DLL_TYPE_PS_FAX, flEntry);
//#ifdef ADOBE_WEB
            if (lpDrvInfo->lpDM->dm2.bWebPrinter)
                lpDrvInfo->hWebPrinter = AdobeOEMInitDllStub(lpDrvInfo,NULL,
                                                   DLL_TYPE_WEB_PRINTER, flEntry);
//#endif
#endif

            if (lpDrvInfo->hOemCust)
            {
                /* Oem stuff starts at sheet DIALOG_PAGES */
                lpPropSheetArray = &(propShPage[DIALOG_PAGES]);

                retval = AdobeOEMGetPropertyPagesStub(lpDrvInfo->hOemCust,
                                             lpPropSheetArray,
                                             &iNumOemPropPages,
                                             &dwOEMPagesToDisplay);

                   if (retval)   // ignore OEM if return FALSE
                       dwDrvPagesToDisplay = dwDrvPagesToDisplay & dwOEMPagesToDisplay;

            }

#ifdef Adobe_Driver
            if (lpDrvInfo->hPSFax)
            {
                lpDrvInfo->lpDM->dm2.bFaxExist = TRUE;
                /* PSFax stuff starts at sheet 5+iNumOemPropPages */
                lpPropSheetArray = &(propShPage[DIALOG_PAGES+iNumOemPropPages]);

                AdobeOEMGetPropertyPagesStub(lpDrvInfo->hPSFax,
                                             lpPropSheetArray,
                                             &iNumPSFaxPropPages,
                                             &dwPSFaxPagesToDisplay);

                dwDrvPagesToDisplay = dwDrvPagesToDisplay & dwPSFaxPagesToDisplay;
            }
//#ifdef ADOBE_WEB
            if (lpDrvInfo->hWebPrinter)
            {
                /* Web Printer stuff starts at sheet 5+iNumOemPropPages */
                lpPropSheetArray = &(propShPage[DIALOG_PAGES+
                                                iNumPSFaxPropPages +
                                                iNumOemPropPages]);

                AdobeOEMGetPropertyPagesStub(lpDrvInfo->hWebPrinter,
                                             lpPropSheetArray,
                                             &iNumWebPrinterPropPages,
                                             &dwWebPrinterPagesToDisplay);

                dwDrvPagesToDisplay = dwDrvPagesToDisplay & dwWebPrinterPagesToDisplay;
            }
//#endif
#endif
            /* Turn off appropriate drv property pages */
            /* Paper */
            if (!(dwDrvPagesToDisplay & PS_DISPLAY_PAPER))
            {
                lpDrvInfo->dwUIFlags[DI_PAPER] = 0x0L;
            }

            /* Fonts */
            if (!(dwDrvPagesToDisplay & PS_DISPLAY_FONTS))
            {
                lpDrvInfo->dwUIFlags[DI_FONTS] = 0x0L;
            }

            /* Graphics */
            if (!(dwDrvPagesToDisplay & PS_DISPLAY_GRAPHICS))
            {
                lpDrvInfo->dwUIFlags[DI_GRAPHICS] = 0x0L;
            }

            /* PostScript */
            if (!(dwDrvPagesToDisplay & PS_DISPLAY_POSTSCRIPT))
            {
                lpDrvInfo->dwUIFlags[DI_POSTSCRIPT] = 0x0L;
            }

            /* Device Options */
            if (!(dwDrvPagesToDisplay & PS_DISPLAY_DEVICE_OPTIONS))
            {
                lpDrvInfo->dwUIFlags[DI_DEVICE] = 0x0L;
            }
#ifdef Adobe_Driver
            /* Watermark */
            if (!(dwDrvPagesToDisplay & PS_DISPLAY_WATERMARKS))
            {
                lpDrvInfo->dwUIFlags[DI_WATERMARK] = 0x0L;
            }
#endif
            /* OEMPLUGI end */


            // Set up property sheets Paper
            for(wLoop=0;wLoop<DIALOG_PAGES;wLoop++)
            {
                if (lpDrvInfo->dwUIFlags[wLoop])
                {
                    propShPage[wUsed].hInstance=ghDriverMod;
                    propShPage[wUsed].pszTemplate=Templates[wLoop];
                    propShPage[wUsed].pfnDlgProc=Procs[wLoop];
                    propShPage[wUsed].lParam=(LPARAM)lpDrvInfo;
                    propShPage[wUsed].dwSize=sizeof(PROPSHEETPAGE);
                    wUsed++;
                }
            }


            // OEMPLUGI begin
            /* Pack the OEM pages to the end of ordinary ones */

            flStub = (wUsed == 0);      // TH 03/17/95

            if (iNumOemPropPages > 0)
            {
                for(wLoop=0;wLoop<(WORD)iNumOemPropPages;wLoop++)
                {
                    propShPage[wUsed] = propShPage[DIALOG_PAGES+wLoop];
                    wUsed++;
                }
            }

#ifdef Adobe_Driver
            if (iNumPSFaxPropPages > 0)
            {
                for(wLoop=0;wLoop<(WORD)iNumPSFaxPropPages;wLoop++)
                {
                    propShPage[wUsed] = propShPage[DIALOG_PAGES+iNumOemPropPages+wLoop];
                    wUsed++;
                }
            }
//#ifdef ADOBE_WEB
            if (iNumWebPrinterPropPages > 0)
            {
                for(wLoop=0;wLoop<(WORD)iNumWebPrinterPropPages;wLoop++)
                {
                    propShPage[wUsed] = propShPage[DIALOG_PAGES+iNumOemPropPages+iNumPSFaxPropPages+wLoop];
                    wUsed++;
                }
            }
//#endif
#endif
            // OEMPLUGI end

            if (wUsed)
            {
                char szBuf[MAX_PATH];
                /*
                 * Load the DLLs that we're going to need,
                 * and find the functions.
                 */
                LoadString(ghDriverMod, IDS_COMMCTRL, szBuf, MAX_PATH);
                if ((lpDrvInfo->hInstShell=LoadLibrary(szBuf)) >=
                    HINSTANCE_ERROR)
                {
                    lpCreateProc=
                      (LPCREATEPROC)GetProcAddress(lpDrvInfo->hInstShell,
                                                   szCreateDlgPageFunction);
                    lpPropertySheet=
                      (LPPROPERTYSHEETPROC)GetProcAddress(lpDrvInfo->hInstShell,
                                                       szPropertySheetFunction);

                    if (! lpCreateProc || ! lpPropertySheet)
                        goto IEDM_exit;
                }
                else
                    goto IEDM_exit;

                LoadString(ghDriverMod, IDS_ICONLIB, szBuf, MAX_PATH);
                if ((lpDrvInfo->hIconMgr = LoadLibrary(szBuf)) >=
                    HINSTANCE_ERROR)
                {
                    lpDrvInfo->lpGetIconResource =
                        (GETICONRESOURCE)GetProcAddress(lpDrvInfo->hIconMgr,
                                                        "GetIconResource");

                    if (!lpDrvInfo->lpGetIconResource)
                        goto IEDM_exit;
                }
                else
                    goto IEDM_exit;

                // Register custom controls
//                if(RegisterControlClass(ghDriverMod))
//                    lpDrvInfo->wFlags |= DI_REGISTERED;
//                else
//                {
//                    /*
//                     * The dialogs will puke if we haven't successfully
//                     * registered the custom controls, so abort now!
//                     */
//                    goto IEDM_exit;
//                }

                /*
                 * Branch differently for ExtDeviceModePropSheet calls. If
                 * lpfnAdd is given, assume that it's ExtDeviceModePropSheet.
                 */

                if(lpfnAdd)
                {
                    // OEMPLUGI begin
                    LPPROPSHEETPAGE lpPropShPage;
                    // OEMPLUGI end

                    // Need to set the release function.
                    propShPage[0].pfnCallback=PropPageCallback;
                    propShPage[0].dwFlags |= PSP_USECALLBACK;

                    // OEMPLUGI begin
                    if (flStub) {
                        lpPropShPage = CreateOemStubPropSheet(propShPage, (LPARAM)lpDrvInfo);
                        if (lpPropShPage)
                        {
                            HPROPSHEETPAGE hPage;

                            lpPropShPage->pfnCallback = StubPropPageCallback;
                            if(hPage=lpCreateProc(lpPropShPage))
                            {
                                lpfnAdd(hPage,lParam);
                                GlobalFreePtr(lpPropShPage);
                            }
                            else
                            {
                                /* Error--abort initialization! */
                                goto IEDM_exit;
                            }
                        }
                    }
                    if (flStub)
                        wLoop = 1;
                    else
                        wLoop = 0;

                    for(;wLoop<wUsed;wLoop++)
                    {
                        HPROPSHEETPAGE hPage;

                        if(hPage=lpCreateProc(propShPage+wLoop))
                        {
                            lpfnAdd(hPage,lParam);
                        }
                        else
                        {
                            /* Error--abort initialization! */
                            goto IEDM_exit;
                        }
                    }
                    // OEMPLUGI end

                    /* Everything is fully initialized--set the flag! */
                    lpDrvInfo->wFlags |= DI_INITIALIZED;

                    // Return without freeing the pages--the caller is
                    // responsible for calling the release function
                    // (EndDevMode) when the pages are going away.
                    return IDOK;
                }
                else
                {
                    PROPSHEETHEADER propShHeader;

                    /* Everything is fully initialized--set the flag! */
                    lpDrvInfo->wFlags |= DI_INITIALIZED;

                    /*
                     * We need to call PropertySheet directly--Zero init
                     * propShHeader first!!!
                     */
                    MemSet((LPVOID) &propShHeader,0,
                           (DWORD) sizeof(PROPSHEETHEADER));

                    /* Set up the property sheet header */
                    propShHeader.dwSize     = sizeof(PROPSHEETHEADER);
                    propShHeader.dwFlags    = PSH_PROPTITLE | PSH_PROPSHEETPAGE;
                    propShHeader.hwndParent = hWnd;
                    propShHeader.hInstance  = ghDriverMod;
                    propShHeader.pszCaption =
                        lpDrvInfo->lpDM->dm.dm.dmDeviceName;
                    propShHeader.ppsp       = (LPPROPSHEETPAGE)propShPage;
                    propShHeader.nPages     = wUsed;

                    lpPropertySheet(&propShHeader);
                }
            }
        }
    }
    else                                /* DM_PROMPT flag not set */
        lpDrvInfo->wFlags |= DI_INITIALIZED;

    // Any code that needs to be handled after the dialog should
    // be in EndDevMode!!!

IEDM_exit:
    return IEndDevMode(lpDrvInfo);
}


/*****************************************************************************/
/*                       ExtDeviceMode                                       */
/*  function:                                                                */
/*       This is a Driver entry point which provides access to the dialogs   */
/*       and allows I/O of Devmode structures.                               */
/*  parameters:                                                              */
/*       hWnd -- parent window handle                                        */
/*       hInst -- instance handle                                            */
/*       lpdmOutput -- pointer to receive a devmode                          */
/*       lpDeviceName -- device name string                                  */
/*       lpPort -- port name string                                          */
/*       lpdmInput -- pointer to pass in a devmode                           */
/*       lpProfile -- pointer to the name of an alternate profile            */
/*                    file to use for storing device records                 */
/*       wMode -- mode of operation                                          */
/*  returns:                                                                 */
/*       short -- as defined in the the DDK                                  */
/*   NOTE:                                                                   */
/*       since we don't use WIN.INI for storing driver data, we do not       */
/*       use lpProfile if it is provided.                                    */
/*****************************************************************************/
short _loadds FAR PASCAL ExtDeviceMode(HWND      hWnd,
                                       HANDLE    hInst,
                                       LPDEVMODE lpdmOutput,
                                       LPSTR     lpFriendlyName,
                                       LPSTR     lpPort,
                                       LPDEVMODE lpdmInput,
                                       LPSTR     lpProfile,
                                       WORD      wMode)
{
    if(!wMode)
        return GetPrivateDocStickySize() + sizeof(DEVMODE);
    else
        return EnterDevMode(hWnd, hInst, (LPPSEXTDEVMODE) lpdmOutput,
                            lpFriendlyName, lpPort, (LPPSEXTDEVMODE)lpdmInput,
                            lpProfile, NULL, NULL, wMode, DI_EXTDEVMODE);
}


/*****************************************************************************/
/*                           ExtDeviceModePropSheet                          */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: as defined in the DDI for ExtDeviceMode                          */
/*****************************************************************************/
short _loadds WINAPI ExtDeviceModePropSheet(HWND                 hWnd,
                                            HINSTANCE            hInst,
                                            LPSTR                lpFriendlyName,
                                            LPSTR                lpPort,
                                            DWORD                dwReserved,
                                            LPFNADDPROPSHEETPAGE lpfnAdd,
                                            LPARAM               lParam)
{
    return EnterDevMode(hWnd, hInst, NULL, lpFriendlyName, lpPort, NULL, NULL,
                        lpfnAdd, lParam, DM_PROMPT | DM_UPDATE, DI_PROPSHEET);
}


WORD _loadds FAR PASCAL AdvancedSetUpDialog(HWND hWnd,
                                            HANDLE hDriver,
                                            LPDEVMODE lpdmInput,
                                            LPDEVMODE lpdmOutput)
{
    WORD rc = (WORD) -1;   // fail

    if (lpdmInput && lpdmOutput && lpdmInput->dmSpecVersion >= 0x300)
    {
        rc = EnterDevMode(hWnd, hDriver, (LPPSEXTDEVMODE) lpdmOutput,
                          lpdmInput->dmDeviceName,
                          NULL, (LPPSEXTDEVMODE) lpdmInput, NULL, NULL,
                          NULL, DM_PROMPT | DM_MODIFY | DM_COPY,
                          DI_ADVSETUPDLG);
    }
    return rc;
}


/*****************************************************************************/
/*                 InitializeDrvVariables                                    */
/* Purpose:                                                                  */
/*   Initializes PSEXTDEVMODE variables that are used privately by the       */
/*   driver.                                                                 */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPSEXTDEVMODE lpPSExtDevmode -- Pointer to PSExtDevmode                */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/
void FAR PASCAL InitializeDrvVariables(LPPSEXTDEVMODE lpPSExtDevmode)
{
    /* Initialize the VM range */

    lpPSExtDevmode->dm2.fMinVM = (float)PRINTER_VM_LOW * 1024;  // in bytes
    lpPSExtDevmode->dm2.fMaxVM = (float)PRINTER_VM_HIGH * 1024;

    lpPSExtDevmode->dm2.fMinFontCache = (float)PRINTER_FCACHE_LOW * 1024;  // in bytes
    lpPSExtDevmode->dm2.fMaxFontCache = (float)PRINTER_FCACHE_HIGH * 1024;

    /* Initialize the output format stuff */
    switch (lpPSExtDevmode->dm.enumDialect)
    {
        case DIA_SPEED:
            lpPSExtDevmode->dm2.bOutputDialect = (BYTE) DIALECT_PS;
            lpPSExtDevmode->dm2.bPJL_Protocol = TRUE;
            lpPSExtDevmode->dm2.bDSC = FALSE;
            lpPSExtDevmode->dm2.bVM_Tracking = TRUE;
            break;
        case DIA_PORTABLE:
            lpPSExtDevmode->dm2.bOutputDialect = (BYTE) DIALECT_PS;
            lpPSExtDevmode->dm2.bPJL_Protocol = TRUE;
            lpPSExtDevmode->dm2.bDSC = TRUE;
            lpPSExtDevmode->dm2.bVM_Tracking = TRUE;
            break;
        case DIA_EPS:
            lpPSExtDevmode->dm2.bOutputDialect = (BYTE) DIALECT_EPS;
            lpPSExtDevmode->dm2.bPJL_Protocol = FALSE;
            lpPSExtDevmode->dm2.bDSC = TRUE;
            lpPSExtDevmode->dm2.bVM_Tracking = FALSE;
            break;
        case DIA_ARCHIVE:
            lpPSExtDevmode->dm2.bOutputDialect = (BYTE) DIALECT_PS;
            lpPSExtDevmode->dm2.bPJL_Protocol = FALSE;
            lpPSExtDevmode->dm2.bDSC = TRUE;
            lpPSExtDevmode->dm2.bVM_Tracking = FALSE;
            break;
        case DIA_PJL_ARCHIVE:
            lpPSExtDevmode->dm2.bOutputDialect = (BYTE) DIALECT_PS;
            lpPSExtDevmode->dm2.bPJL_Protocol = TRUE;
            lpPSExtDevmode->dm2.bDSC = TRUE;
            lpPSExtDevmode->dm2.bVM_Tracking = FALSE;
            break;
    }
}

void FAR PASCAL PsExtDevmodeMerge(LPPSEXTDEVMODE lpCurDevmode,
                                  LPPSEXTDEVMODE lpNewDevmode,
                                  LPSTR          lpszDevice,
                                  LPSTR          lpszFriendly,
                                  BOOL           bInitialize)
{
      LPWPXBLOCKS   lpWPXblock;
      MERGETYPE     mergeType;

      lpWPXblock = GetPrinter(lpszDevice);
      if (bInitialize)
          InitDefaultDevmode(lpWPXblock, lpCurDevmode, lpszFriendly);
      mergeType = GetMergeType(lpWPXblock, lpNewDevmode);
      // 32 bit apps get full devmode. Merge only doc sticky part.
      if (mergeType == MERGE_FULL)
          mergeType = MERGE_DOC;
      MergeDevmode(lpWPXblock, lpCurDevmode, lpNewDevmode, mergeType);
      InitializeDrvVariables(lpCurDevmode);
      ValidateOptions(NULL, lpWPXblock, lpCurDevmode);

      UpdatePublicDevmode(lpWPXblock, lpCurDevmode);

      FreePrinter(lpWPXblock);
}


BOOL FAR PASCAL FarMergePublicDM(LPWPXBLOCKS   lpWPXblock,
                               LPPSEXTDEVMODE  lpCurExtDevmode,
                               LPPSEXTDEVMODE  lpNewExtDevmode)
{
    return MergePublicDM(lpWPXblock, lpCurExtDevmode, lpNewExtDevmode);
}


// OEMPLUGI begin
LPPROPSHEETPAGE FAR PASCAL CreateOemStubPropSheet(PROPSHEETPAGE FAR *lpPropShPage, LPARAM lDrvParam)
{
    LPPROPSHEETPAGE   lpOemStubPropSheet;
    LPARAM            *lpParam;

    lpOemStubPropSheet = GlobalAllocPtr(GMEM_SHARE|GHND, lpPropShPage->dwSize + sizeof(LPARAM));
    if (lpOemStubPropSheet)
    {
        *lpOemStubPropSheet = *lpPropShPage;
        lpOemStubPropSheet->dwSize += sizeof(LPARAM);
        lpParam = (LPARAM *)((char *)lpOemStubPropSheet + lpPropShPage->dwSize);
        *lpParam = lDrvParam;
    }
    return lpOemStubPropSheet;
}
// OEMPLUGI end
