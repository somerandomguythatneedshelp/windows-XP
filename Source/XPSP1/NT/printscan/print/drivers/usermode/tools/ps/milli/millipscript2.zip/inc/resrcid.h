/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: RESRCID.H                                              */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/* Change History :                                                          */
/* L3_CLIP -- Level3 clipsave cliprestore support.  9/13/96   jjia           */
/*                                                                           */
/*****************************************************************************/

#include "icons.h"

#define DMGID_begin                    1031
//      DMGID_defaultpath              1032
//      DMGID_defaultmodpath           1033
//#define DMGID_pswriter                 1034
//#define DMGID_datamgr                  1035
//#define DMGID_translate                1036
//#define DMGID_spooler                  1037
//#define DMGID_errorcaption             1038
#define DMGID_end                      1046
//#define INI_begin                      1047
//#define INI_pswriter                   1048
//#define INI_defaultdrive               1049
//#define INI_defaultdriveletter         1050
//#define INI_defaultpath                1051
//#define INI_defaultpathstring          1052
//#define INI_cfg                        1053
//#define INI_cfgdefault                 1054
//#define INI_pidb                       1055
//#define INI_pidefault                  1056
//#define INI_ppddb                      1057
//#define INI_ppddefault                 1058
//#define INI_ftx                        1059
//#define INI_ftxdefault                 1060
//#define INI_ftd                        1061
//#define INI_ftddefault                 1062
//#define INI_verbose                    1063
//#define INI_yes                        1064
//#define INI_no                         1065
//#define INI_creator                    1066
#define INI_DIALECTFILENAME_BASE       1067
//#define INI_end                        1068


//#define LID_errorcaption               5001
//#define LID_yes                        5049
//#define LID_no                         5050
//#define LID_blurb                      5051
//#define LID_sendoutputto               5052
//#define LID_landscape                  5053
//#define LID_end                        5054

//constants for translate resources
//

//here are the categories of PostScript resources

#define PS_begin                        256
#define PS_proc                         257
#define PS_end                          258

// custom messages
#define WM_ADOBE_HELP                   WM_USER + 10
#define WM_BUILD_DLG                    WM_USER + 100
#define WM_SHOW_DLG                     WM_USER + 101

//the types of procset resources

#define PSPROC_begin                      0
#define PSPROC_minheader                  1
#define PSPROC_copies                     2
#define PSPROC_ehandler                   3
#define PSPROC_vmehandler                 90
#define PSPROC_hardware                   4
#define PSPROC_software                   5
#define PSPROC_fatalerr_ps1               10
#if 0
// ADOBEPS42
#define PSPROC_resemul_ps1                6
#define PSPROC_utils0_ps1                 7
#define PSPROC_utils1_ps1                 8
#define PSPROC_utils2_ps1                 9
#define PSPROC_ocutils2_ps1               56
#define PSPROC_mhutils2_ps1               91
#define PSPROC_textenc_ps1                11
#define PSPROC_text_ps1                   12
#define PSPROC_textbold_ps1               13
#define PSPROC_graph0_ps1                 14
#define PSPROC_graph1_ps1                 15
#define PSPROC_graph2_ps1                 16
#define PSPROC_imagebw0_ps1               17
#define PSPROC_imagebw1_ps1               18
#define PSPROC_imageco1_ps1               19
#define PSPROC_imageco2_ps1               20
#define PSPROC_compat_ps1                 22
#define PSPROC_calrgb_ps1                 21
#define PSPROC_type3hdr_ps1               40
#define PSPROC_type1hdr_ps1               42
#define PSPROC_type1ehdr_ps1              44
#define PSPROC_type1eftr_ps1              46
#define PSPROC_type1ehdrU_ps1             48
#define PSPROC_type1eftrU_ps1             50
#define PSPROC_nup_ps1                    53
#define PSPROC_watermark_ps1              62
#define PSPROC_min_utils0_ps1             64

#define PSPROC_kanji_ps1                  58
#define PSPROC_kanji2_ps1                 60

#define PSPROC_type0hdr_ps1               71
#endif

#define PSPROC_utils0_ps2                 23
#define PSPROC_utils2_ps2                 24
#define PSPROC_textenc_ps2                25 //this has ANSIEncoding
#define PSPROC_text_ps2                   26
#define PSPROC_textbold_ps2               27
#define PSPROC_graph0_ps2                 28
#define PSPROC_graph1_ps1                 29
#define PSPROC_imagebw0_ps2               30
#define PSPROC_imageco2_ps2               31
#define PSPROC_calrgb_ps2                 32
#define PSPROC_compat_ps2                 33
#define PSPROC_beg_bcp                    34
#define PSPROC_beg_bcp_A                  35
#define PSPROC_end_bcp                    36
#define PSPROC_end_bcp_A                  37
#define PSPROC_calrgbsp_ps1               38
#define PSPROC_end                        39
#define PSPROC_type3hdr_ps2               41
#define PSPROC_type1hdr_ps2               43
#define PSPROC_type1ehdr_ps2              45
#define PSPROC_type1eftr_ps2              47
#define PSPROC_type1ehdrU_ps2             49
#define PSPROC_type1eftrU_ps2             51
#define PSPROC_type42_ps2                 52
#define PSPROC_nup_ps2                    54
#define PSPROC_rledecode                  55
#define PSPROC_ocutils2_ps2               57
#define PSPROC_mhutils2_ps2               92

#define PSPROC_kanji_ps2                  59
#define PSPROC_kanji2_ps2                 61


#define PSPROC_watermark_ps2              63
#define PSPROC_min_utils0_ps2             65

#define PSPROC_cmap_128_ps2               66
#define PSPROC_cmap_129_ps2               67
#define PSPROC_cmap_130_ps2               68
#define PSPROC_cmap_134_ps2               69
#define PSPROC_cmap_136_ps2               70
#define PSPROC_type0hdr_ps2               72
#define PSPROC_cmap_FFFF_ps2              73
#define PSPROC_feature_safe               74
#define PSPROC_greek_encoding             75
#define PSPROC_turkish_encoding           76
#define PSPROC_hebrew_encoding            77
#define PSPROC_arabic_encoding            78
#define PSPROC_baltic_encoding            79
#define PSPROC_russian_encoding           80
#define PSPROC_ee_encoding                81
#define PSPROC_min_text_ps2               82
// L3_CLIP
#define PSPROC_clipsave_ps3               83
#ifdef T3OUTLINE
#define PSPROC_type3olhdr_ps2             84
#endif
#ifdef ADOBE_DRIVER
#define PSPROC_blankpage                  85
#endif
// Merge in new procset for UFL.  may delete the old ones later
#define PSPROC_ufl_cmap_FFFF_ps2          86
#define PSPROC_ufl_type42_ps2             87
#define PSPROC_ufl_cffnt_ps2              88
#define PSPROC_ufl_type3hdr_ps2           89

// PSPROC_vmehandler used                 90 
#ifdef ADD_EURO
#define PSPROC_euro_ps2                   91
#endif


//document structuring conventions resources

#define DSC_begin                      1999
#define DSC_null                       2000
#define DSC_adobe                      2001
#define DSC_epsf                       2002
#define DSC_query                      2003
#define DSC_exitserver                 2004
#define DSC_title                      2005
#define DSC_creator                    2006
#define DSC_date                       2007
#define DSC_for                        2008
#define DSC_routing                    2009
#define DSC_proofmode                  2010
#define DSC_bbox                       2011
#define DSC_pages                      2012
#define DSC_continue                   2013
#define DSC_requirements               2014
#define DSC_docfonts                   2015
#define DSC_docneededres               2016
#define DSC_docsuppliedres             2017
#define DSC_docprocsets                2018
#define DSC_docneededprocsets          2019
#define DSC_docsuppliedprocsets        2020
#define DSC_docneededfiles             2021
#define DSC_docsuppliedfiles           2022
#define DSC_docpapersizes              2023
#define DSC_docpaperforms              2024
#define DSC_docpapercolors             2025
#define DSC_docpaperweights            2026
#define DSC_docprinterrequired         2027
#define DSC_docprocesscolors           2028
#define DSC_doccustomcolors            2029
#define DSC_endcomments                2030
#define DSC_beginprolog                2031
#define DSC_endprolog                  2032
#define DSC_beginsetup                 2033
#define DSC_endsetup                   2034
#define DSC_begindocument              2035
#define DSC_enddocument                2036
#define DSC_beginfile                  2037
#define DSC_endfile                    2038
#define DSC_beginfont                  2039
#define DSC_endfont                    2040
#define DSC_beginprocset               2041
#define DSC_endprocset                 2042
#define DSC_beginbinary                2043
#define DSC_endbinary                  2044
#define DSC_beginpapersize             2045
#define DSC_endpapersize               2046
#define DSC_beginfeature               2047
#define DSC_endfeature                 2048
#define DSC_beginexitserver            2049
#define DSC_endexitserver              2050
#define DSC_beginprocesscolor          2051
#define DSC_endprocesscolor            2052
#define DSC_begincustomcolor           2053
#define DSC_endcustomcolor             2054
#define DSC_cmykcustomcolor            2055
#define DSC_rgbcustomcolor             2056
#define DSC_trailer                    2057
#define DSC_page                       2058
#define DSC_pagefonts                  2059
#define DSC_pagefiles                  2060
#define DSC_pagebbox                   2061
#define DSC_pageprocesscolors          2062
#define DSC_pagecustomcolors           2063
#define DSC_beginpagesetup             2064
#define DSC_endpagesetup               2065
#define DSC_beginobject                2066
#define DSC_endobject                  2067
#define DSC_pagetrailer                2068
#define DSC_includeres                 2069
#define DSC_includeprocset             2070
#define DSC_includefile                2071
#define DSC_executefile                2072
#define DSC_changefont                 2073
#define DSC_paperform                  2074
#define DSC_papercolor                 2075
#define DSC_paperweight                2076
#define DSC_papersize                  2077
#define DSC_feature                    2078
#define DSC_eof                        2079
#define DSC_beginquery                 2080
#define DSC_beginprinterquery          2081
#define DSC_endprinterquery            2082
#define DSC_beginvmstatus              2083
#define DSC_endvmstatus                2084
#define DSC_beginfeaturequery          2085
#define DSC_endfeaturequery            2086
#define DSC_beginfilequery             2087
#define DSC_endfilequery               2088
#define DSC_beginfontquery             2089
#define DSC_endfontquery               2090
#define DSC_beginfontlistquery         2091
#define DSC_endfontlistquery           2092
#define DSC_beginprocsetquery          2093
#define DSC_endprocsetquery            2094
#define DSC_beginpreview               2095
#define DSC_endpreview                 2096
#define DSC_languagelevel              2097
#define DSC_beginresource              2098
#define DSC_endresource                2099
#define DSC_docneedres                 2100
#define DSC_pageorder                  2101
#define DSC_documentdata               2102
#define DSC_binary                     2103
#define DSC_clean7bit                  2104
#define DSC_clean8bit                  2105
#define DSC_special                    2106
#define DSC_ascending                  2107
#define DSC_docsuppresfont             2108
#define DSC_docneedresfont             2109
#define DSC_includeresfont             2110
#define DSC_atend                      2111
#define DSC_plus_font                  2112
#define DSC_begin_patchfile            2113
#define DSC_end_patchfile              2114
#define DSC_begin_jobpatchfile         2115
#define DSC_end_jobpatchfile           2116
#define DSC_Netware_ATPS               2117
#define DSC_pages_atend                2118
#define DSC_viewingorientation         2119
#define DSC_begindefaults              2120
#define DSC_enddefaults                2121
#define DSC_includeresource            2122
// DSC 3.1
#define DSC_docsuppliedfeatures        2123
#define DSC_targetdevice                2124
#define DSC_begindevicesetup            2125
#define DSC_enddevicesetup              2126
#define DSC_begindocumentsetup          2127
#define DSC_enddocumentsetup            2128
#define DSC_endpagecomments             2129
#define DSC_beginsetcolorespace         2130
#define DSC_endsetcolorespace           2131
#define DSC_beginreendingintent         2132
#define DSC_endrendingintent            2133
#define DSC_beginuncounteddata          2134
#define DSC_enduncounteddata            2135
#define DSC_datacount                   2136
#define DSC_trailerlength               2137
#define DSC_pagefeatures                    2138
#define DSC_plus_file                  2139
#define DSC_plus                           2140
#define DSC_begindatacountedatend       2141
#define DSC_enddatacountedatend         2142
#define DSC_beginnonPPDfeature          2143
#define DSC_endnonPPDfeature            2144
#define DSC_begindata                   2145
#define DSC_enddata                     2146
// add these for NT compatibility
#define DSC_documentprocesscolors       2147
#define DSC_documentprocesscolorsatend  2148
#define DSC_platecolor                  2149
// Remember to bump the following if you add DSC stuff
#define DSC_end                         2150  //  BEWARE !!!!!!!!!


//PPD resource string id's:
//#define ID_PPDSTR_KEY_DRVRMARK         3000
//#define ID_PPDSTR_DRVRMARK             3001
//#define ID_PPDSTR_KEY_MODEL            3002
#define ID_PPDSTR_KEY_DIALECT          3003
#define ID_PPDSTR_BASE_DIALECT         3004
 //Leave room for dialect options.

#define ID_PPDSTR_KEY_INPUTSLOT        3015
#define ID_PPDSTR_BASE_INPUTSLOT       3016
 //Leave room for input slot options.

#define ID_PPDSTR_KEY_PAGESIZE         2300
#define ID_PPDSTR_BASE_PAGESIZE        2301
 //Leave room for page size(media) options.

#define ID_PPDSTR_KEY_RESOLUTION       3084
#define ID_PPDSTR_KEY_PAGEREGION       3085
#define ID_PPDSTR_KEY_IMGAREA          3086
#define ID_PPDSTR_KEY_PAPERDIM         3087
#define ID_PPDSTR_KEY_MANUALFEED       3088
#define ID_PPDSTR_KEY_LANGLEVEL        3089
#define ID_PPDSTR_KEY_LEVEL2ACTIVE     3090
#define ID_PPDSTR_KEY_ORIENT           3091
#define ID_PPDSTR_BASE_ORIENT          3092
 //Leave room for orientation options.

#define ID_PPDSTR_KEY_DUPLEX           3096
#define ID_PPDSTR_BASE_DUPLEX          3097
 //Leave room for duplex options.

#define ID_PPDSTR_KEY_NOMARGINS        3105
#define ID_PPDSTR_KEY_PROTOCOL         3106
#define ID_PPDSTR_BASE_PROTOCOL        3107
 //Leave room for protocol options.

#define ID_PPDSTR_KEY_USECOLOR         3115
#define ID_PPDSTR_KEY_COPIES           3116
#define ID_PPDSTR_KEY_SCALING          3117
#define ID_PPDSTR_KEY_WAITTIMEOUT      3118
#define ID_PPDSTR_KEY_JOBTIMEOUT       3119
#define ID_PPDSTR_KEY_AUTOTRAYSWITCH   3120
#define ID_PPDSTR_KEY_CUSTOMPAGE       3121
#define ID_PPDSTR_KEY_CUSTOMPAGEPARAMS 3122
#define ID_PPDSTR_PARAM_WIDTH          3123
#define ID_PPDSTR_PARAM_HEIGHT         3124
#define ID_PPDSTR_PARAM_WIDTHOFFSET    3125
#define ID_PPDSTR_PARAM_HEIGHTOFFSET   3126
#define ID_PPDSTR_PARAM_ORIENT         3127
#define ID_PPDSTR_KEY_PROTOCOLUSED     3128
#define ID_PPDSTR_KEY_MATCHCOLOR       3129
#define ID_PPDSTR_KEY_ERRORHANDLER     3130
#define ID_PPDSTR_KEY_DOWNLOADHDR      3131
#define ID_PPDSTR_KEY_HANDSHAKE        3132
#define ID_PPDSTR_KEY_PROTOCOLOPT      3133
#define ID_PPDSTR_KEY_PSPERFORM        3134
#define ID_PPDSTR_KEY_PRNMODE          3135
#define ID_PPDSTR_KEY_PASSWORD         3136
#define ID_PPDSTR_KEY_EXITSERVER       3137
#define ID_PPDSTR_KEY_AUTOTRAYSELECT   3138

#define ID_PPDSTR_KEY_MIXEDBINS        3139
#define ID_PPDSTR_KEY_ALLOWEXITSERVER  3140

#define ID_PPDSTR_KEY_LANDSCAPEORIENT  3141
#define ID_PPDSTR_BASE_LANDSCAPEORIENT 3142
 //Leave room for 3 landscape orientation angle options.

#define ID_PPDSTR_KEY_NOFONTS          3150
#define ID_PPDSTR_KEY_JCL_STARTJOB     3152
#define ID_PPDSTR_KEY_JCL_ENDJOB       3153
#define ID_PPDSTR_KEY_JCL_JCLTOPS      3154
#define ID_PPDSTR_KEY_JCL_OPENUI       3155
#define ID_PPDSTR_KEY_JCL_CLOSEUI      3156
#define ID_PPDSTR_KEY_JCL_RESOLUTION   3157
#define ID_PPDSTR_KEY_JCL_DEF_RES      3158
#define ID_PPDSTR_KEY_JCL_FRAMEBUFF    3159
#define ID_PPDSTR_KEY_JCL_DEF_FRAMEBUF 3160
#define ID_PPDSTR_KEY_TTDOWNLOADFORMAT 3161
#define ID_PPDSTR_KEY_TTSUBSTITUTE     3162
// #define ID_PPDSTR_KEY_TYPE42OK         3163
#define ID_PPDSTR_KEY_PSDOWNLOADFORMAT 3163

// Chicago Begin
//#define ID_PPDSTR_DRVRMARK30           3177
#define ID_PPDSTR_KEY_MEDIATYPE        3178
#define ID_PPDSTR_KEY_OUTPUTBIN        3179
//#define ID_PPDSTR_KEY_MARGINS          3180
//#define ID_PPDSTR_KEY_CUSTPAGE_MARGINS 3181
//#define ID_PPDSTR_KEY_CUSTPAGE_IA      3182
// Chicago End


//#define ID_PPDSTR_KEY_OEMCUSTDLL       3164
//#define ID_PPDSTR_KEY_OEMHELPFILE      3165
//#define ID_PPDSTR_KEY_PCFILENAME       3166
//#define ID_PPDSTR_KEY_OEMFEATURE       3167
#define ID_PPDSTR_KEY_TTRASTERIZER     3168

      // get greyscale and halftone
#define ID_PPDSTR_KEY_SCREENFREQUENCY  3169
#define ID_PPDSTR_KEY_SCREENANGLE      3170
#define ID_PPDSTR_KEY_TYPE42BUGGY      3171
//#define ID_PPDSTR_DRVRMARK21           3172
#define ID_PPDSTR_KEY_VERSION          3173
#define ID_PPDSTR_KEY_COLORDEVICE      3174
#define ID_PPDSTR_KEY_JOBPATCHFILE     3175
#define ID_PPDSTR_KEY_PATCHFILE        3176

//For Japanese Mincho & Gothic facename support.
#define ID_PPDSTR_DBCS_MINCHO_H        3190
#define ID_PPDSTR_DBCS_MINCHO_V        3191
#define ID_PPDSTR_DBCS_GOTHIC_H        3192
#define ID_PPDSTR_DBCS_GOTHIC_V        3193

#define ID_PPDSTR_CUSTOMSIZE           3194
#define ID_PPDSTR_AUTOSELECTTRAY       3195
#define ID_PPDSTR_MIXEDBINS            3196
#define ID_PPDSTR_300DPIITHINK         3197

#define ID_DSCSTR_AUTOSELECTTRAY       3198

// random strings for PPD parser
#define IDS_MANUALFEED                 3200
 
#define ID_PPDSTR_KEY_COLLATE          3210
#define ID_PPDSTR_KEY_OUTPUTORDER      3211

//The following offsets define the language specific id ranges in the
// string table.
#define ID_USA                        10000
#define ID_France                     12000
#define ID_Germany                    14000
#define ID_Spain                      16000

//The following offsets describe ranges within each language specific section
// of the string table.
#define ID_errors                         0
#define ID_errors_end                   500

#define ID_dlg_strings                ID_errors_end  +  1
#define ID_dlg_strings_end            ID_dlg_strings + 50



#define PSFRAG_setgray                4000
#define PSFRAG_setcolor               4001
#define PSFRAG_box                    4003
#define PSFRAG_slash                  4004
#define PSFRAG_leftbracket            4005
#define PSFRAG_rightbracket           4006
#define PSFRAG_crlf                   4007
#define PSFRAG_space                  4008
#define PSFRAG_mysetup                4009
#define PSFRAG_snap                   4010
#define PSFRAG_setup                  4011
#define PSFRAG_epsprintsetup          4012
#define PSFRAG_pagesetup              4013
#define PSFRAG_pagecleanup            4014
#define PSFRAG_rrectstroke            4015
#define PSFRAG_RRectstroke            4016
#define PSFRAG_circlestroke           4017
#define PSFRAG_circlefill             4018
#define PSFRAG_ccwellipse             4019
#define PSFRAG_cwellipse              4020
#define PSFRAG_save                   4021
#define PSFRAG_restore                4022
#define PSFRAG_setmiterlimit          4023
#define PSFRAG_rectfill               4024
#define PSFRAG_rectstroke             4025
#define PSFRAG_rectclip               4026
#define PSFRAG_rrectfill              4027
#define PSFRAG_RRectfill              4028
#define PSFRAG_beginimage             4029
// used by merging setpagedevice.  jjia   7/16/96
#define PSFRAG_beginmergespd          4030
#define PSFRAG_endmergespd            4031

#define PSFRAG_bitmaskimage           4032
#define PSFRAG_endimage               4033
#define PSFRAG_solid                  4034
#define PSFRAG_setdsh                 4035
#define PSFRAG_copy                   4036
#define PSFRAG_CTMsave                4037
#define PSFRAG_CTMrestore             4038
#define PSFRAG_hrf                    4039
#define PSFRAG_prf                    4040
#define PSFRAG_rrp                    4041
#define PSFRAG_RRp                    4042
#define PSFRAG_leftcaret              4043
#define PSFRAG_rightcaret             4044
#define PSFRAG_doNimage               4045
#define PSFRAG_doclutimage            4046
#define PSFRAG_sU                     4047
#define PSFRAG_sT                     4048
#define PSFRAG_eR                     4049
#define PSFRAG_mF                     4050
#define PSFRAG_mIF                    4051
#define PSFRAG_mBF                    4052
#define PSFRAG_sSU                    4053
#define PSFRAG_sST                    4054
#define PSFRAG_sR                     4055
#define PSFRAG_sB                     4056
#define PSFRAG_asB                    4057
#define PSFRAG_wsB                    4058
#define PSFRAG_awsB                   4059
#define PSFRAG_jobtimeout             4060
#define PSFRAG_waittimeout            4061
#define PSFRAG_beginsafe              4062
#define PSFRAG_endsafe                4063
#define PSFRAG_declaredict            4064
#define PSFRAG_enddefresource         4065
#define PSFRAG_initprocset            4066
#define PSFRAG_setdefaults            4067
#define PSFRAG_declaredict_L2         4068
#define PSFRAG_initprocset_L2         4069
#define PSFRAG_incprocsetstart        4070
#define PSFRAG_incprocsetstartL2      4071
#define PSFRAG_incprocsetend          4072
#define PSFRAG_incrdict               4073
#define PSFRAG_end                    4074
#define PSFRAG_initdribble            4075
#define PSFRAG_incrdict_L2            4076
#define PSFRAG_initdribble_L2         4077
#define PSFRAG_PSERR_l2images1        4078
#define PSFRAG_PSERR_l2images2        4079
#define PSFRAG_PSERR_l2images3        4080
#define PSFRAG_PSERR_l2images4        4081
#define PSFRAG_PSERR_l2images5        4082
#define PSFRAG_PSERR_l2iheader        4083
#define PSFRAG_PSERR_l2itrailr        4084
#define PSFRAG_PSERR_onlyL2_1         4085
#define PSFRAG_PSERR_onlyL2_2         4086
#define PSFRAG_PSERR_onlyL2_3         4087
#define PSFRAG_PSERR_onlyL2_4         4088
#define PSFRAG_PSERR_onlyL2_5         4089
#define PSFRAG_PSERR_onlyL2_6         4090
#define PSFRAG_PSERR_binnone_1        4091
#define PSFRAG_PSERR_binnone_2        4092
#define PSFRAG_PSERR_binnone_3        4093
#define PSFRAG_PSERR_binnone_4        4094
#define PSFRAG_PSERR_binnone_5        4095
#define PSFRAG_PSERR_binnone_6        4096
#define PSFRAG_PSERR_binnone_7        4097
#define PSFRAG_PSERR_binBCPA_1        4098
#define PSFRAG_PSERR_binBCPA_2        4099
#define PSFRAG_PSERR_binBCPA_3        4100
#define PSFRAG_PSERR_binBCPA_4        4101
#define PSFRAG_PSERR_binBCPA_5        4102
#define PSFRAG_PSERR_binBCPA_6        4103
#define PSFRAG_PSERR_binBCPA_7        4104
#define PSFRAG_PSERR_binBCPB_1        4105
#define PSFRAG_PSERR_binBCPB_2        4106
#define PSFRAG_PSERR_binBCPB_3        4107
#define PSFRAG_PSERR_binBCPB_4        4108
#define PSFRAG_PSERR_binBCPB_5        4109
#define PSFRAG_PSERR_binBCPB_6        4110
#define PSFRAG_PSERR_binBCPB_7        4111
#define PSFRAG_DOWNHEAD_1             4112
#define PSFRAG_DOWNHEAD_2             4113
#define PSFRAG_DOWNHEAD_3             4114
#define PSFRAG_DOWNHEAD_4             4115
#define PSFRAG_DOWNHEAD_5             4116
#define PSFRAG_DOWNHEAD_6             4117
#define PSFRAG_DOWNHEAD_7             4118
#define PSFRAG_DOWNHEAD_8             4119
#define PSFRAG_PSERR_NOPRO_1          4120
#define PSFRAG_PSERR_NOPRO_2          4121
#define PSFRAG_PSERR_NOPRO_3          4122
#define PSFRAG_PSERR_NOPRO_4          4123
#define PSFRAG_PSERR_NOPRO_5          4124
#define PSFRAG_PSERR_NOPRO_6          4125
#define PSFRAG_PSERR_NOPRO_7          4126
#define PSFRAG_PSERR_NOPRO_8          4127
#define PSFRAG_PSERR_NOPRO_9          4128
#define PSFRAG_termprocset            4129
#define PSFRAG_termprocset_L2         4130
#define PSFRAG_termdribble            4131
#define PSFRAG_termdribble_L2         4132
#define PSFRAG_termMinHdr             4133
#define PSFRAG_initcalrgb             4134
#define PSFRAG_termcalrgb             4135
#define PSFRAG_beginprocset           4136
#define PSFRAG_beginprocset_L2        4137
#define PSFRAG_suspenddribble_L2      4138
#define PSFRAG_suspendprocset_L2      4139
#define PSFRAG_suspenddribble         4140
#define PSFRAG_suspendprocset         4141
#define PSFRAG_resumedribble_L2       4142
#define PSFRAG_resumeprocset_L2       4143
#define PSFRAG_resumedribble          4144
#define PSFRAG_resumeprocset          4145
#define PSFRAG_PJL_language           4146
#define PSFRAG_UEL                    4147
#define PSFRAG_lf                     4148
#define PSFRAG_eoclip                 4149
#define PSFRAG_clip                   4150
#define PSFRAG_rectoutline            4151
#define PSFRAG_setmatrix              4152
#define PSFRAG_setscreenfrequency     4153
#define PSFRAG_setscreenangle             4154
#define PSFRAG_Type42Encoding         4155
#define PSFRAG_Type42CharStrings      4156
#define PSFRAG_Type42DictBegin        4157
#define PSFRAG_concat                 4158
#define PSFRAG_PJL_EOJ                4159
#define PSFRAG_sF42                   4160
#define PSFRAG_bS42                   4161
#define PSFRAG_eS42                   4162
#define PSFRAG_PJL_job                4163
#define PSFRAG_Type42CharStringBegin  4164
#define PSFRAG_Type42BeginBuildChars  4165
#define PSFRAG_Type42EndBuildChars    4166
#define PSFRAG_Type42CharStringEnd    4167
#define PSFRAG_PSERR_VM_1             4168
#define PSFRAG_PSERR_VM_2             4169
#define PSFRAG_PSERR_VM_3             4170
#define PSFRAG_PSERR_VM_4             4171
#define PSFRAG_PSERR_VM_5             4172
#define PSFRAG_PSERR_VM_6             4173
#define PSFRAG_PSERR_VM_7             4174
#define PSFRAG_PSERR_VM_8             4175
#define PSFRAG_PSERR_VMHeader         4176
#define PSFRAG_PSERR_VMTrailr         4177
#define PSFRAG_VMCheck                4178
#define PSFRAG_BMFill                 4179
#define PSFRAG_begincopyimage         4180
#define PSFRAG_rectshape              4181
#define PSFRAG_sRxy                   4182
#define PSFRAG_sBT3                   4183
#define PSFRAG_asBT3                  4184
#define PSFRAG_wsBT3                  4185
#define PSFRAG_awsBT3                 4186
#define PSFRAG_initcompatprocset      4187
#define PSFRAG_suspendcompatprocset   4188
#define PSFRAG_termcompatprocset      4189

#define PSFRAG_OC                     4190
#define PSFRAG_declaredict_OC         4191
#define PSFRAG_initprocset_OC         4192

#define PSFRAG_resumecalrgb           4193
#define PSFRAG_beginNup               4194
#define PSFRAG_reinitNup              4195
#define PSFRAG_firstpageNup           4196
#define PSFRAG_finalpageNup           4197
#define PSFRAG_NumOfQuadrantsNup      4198
#define PSFRAG_negativeimage          4199

#define PSFRAG_setscreen              4200
#define PSFRAG_openbracket            4201
#define PSFRAG_closebracket           4202
#define PSFRAG_cvn                    4203
#define PSFRAG_backgroundstart        4204
#define PSFRAG_backgroundend          4205
#define PSFRAG_restoreCTM             4206
#define PSFRAG_saveCTM                4207
#define PSFRAG_epsprocsetstart        4208
#define PSFRAG_OCprocsetstart         4249

#define PSFRAG_doCMYKclutimage    4209
#define PSFRAG_doCMYKimage        4210
#define PSFRAG_setcmykcolor       4211

#define PSFRAG_initializeNup          4212
#define PSFRAG_setupcompatmatrix      4213
#define PSFRAG_refreshColorSpace      4214
#define PSFRAG_fillbackground         4215
#define PSFRAG_productname            4216
//Fix bug 120000.  jjia.  10/13/95
#define PSFRAG_dscincludeprocset      4217
#define PSFRAG_dscbeginresource_L2    4218
#define PSFRAG_dscbeginresource       4219
#define PSFRAG_dscbegindocument       4239
//end

#ifdef ADOBE_DRIVER
#define PSFRAG_Type42PrepFor2015      4220
#define PSFRAG_Type42AddChar          4221
#define PSFRAG_Type0Encoding          4222
#define PSFRAG_Type0DictBegin         4223
#define PSFRAG_Type42DescendantEncoding   4224
#define PSFRAG_Type42DescendantCharString 4225
#define PSFRAG_Type42AddGDirDict      4226
#define PSFRAG_watermark_exec         4227
#define PSFRAG_watermark_0_L2         4228
#define PSFRAG_watermark_1_L2         4229
#define PSFRAG_watermark_2_L2         4230
#define PSFRAG_watermark_3_L2         4231
#define PSFRAG_watermark_4_L2         4232
#define PSFRAG_mysetup_wm             4233
#define PSFRAG_ctm_wm_save            4234
#define PSFRAG_ctm_wm_cont            4235
#define PSFRAG_ctm_wm_set             4236
#define PSFRAG_AType42GnumEncoding    4237
#define PSFRAG_setrgbcolor            4238
// 4239 is used by  PSFRAG_dscbegindocument
#endif


#define PSFRAG_mF_V                   4240
#define PSFRAG_mF_83V                 4241
#define PSFRAG_sBK                    4242
#define PSFRAG_asBK                   4243
#define PSFRAG_wsBK                   4244
#define PSFRAG_awsBK                  4245
#define PSFRAG_mIFK                   4246

// Add xshow.
#define PSFRAG_xsB                    4247
#define PSFRAG_min_mF                 4248 //make font for min header
// 4249 is used by PSFRAG_OCprocsetstart

// L3_CLIP   We can use ID 3900 -- 3999
#define PSFRAG_clipsave               3900
#define PSFRAG_cliprestore            3901
#define PSFRAG_dscbeginresource_Incr_L2 3902

// CSL-Mode-Switching - or - No-Mode-Switching support
#define PSFRAG_CSLCompMode1           3903
#define PSFRAG_CSLCompMode2           3904

// Fix bug 164116(2)
#define PSFRAG_porprocsetstartL2      3905

#define PSFRAG_fixnotdef              3906
// Fix bug 197396. 
#define PSFRAG_pagesave               3907

// ADOBE_SPOOLER
#define PSFRAG_InitEnv                3908
#define PSFRAG_ResetEnv               3909

// Fix bug 265334
#define PSFRAG_reclaimVM              3910

#define ADDPRN                        4250
//#define ADDPRN_szInstall              ADDPRN
//#define ADDPRN_szNoNickname           ADDPRN+1
//#define ADDPRN_szInstaller            ADDPRN+2
//#define ADDPRN_szSelectPrinter        ADDPRN+3
//#define ADDPRN_szInstallError         ADDPRN+4
//#define ADDPRN_szInstallSuccess       ADDPRN+5
//#define ADDPRN_szInstallDuplicate     ADDPRN+6
//#define ADDPRN_szPrinterHelp          ADDPRN+7
//#define ADDPRN_szPPDMask              ADDPRN+8
//#define ADDPRN_szNickName             ADDPRN+9
//#define ADDPRN_szShortNickName        ADDPRN+10
//#define ADDPRN_szInclude              ADDPRN+11
//#define ADDPRN_szBadNickName          ADDPRN+12
#define ADDPRN_szWarning              ADDPRN+13
//#define ADDPRN_szNoPPDMatch           ADDPRN+14
//#define IDS_szInstallFromOrigDisk     ADDPRN+15
//#define IDS_szDevInstallError         ADDPRN+16
//#define IDS_szRemoveReinstall         ADDPRN+17

#define DLGS                          4300
#define DLGS_CUSTOM_SIZE_ERROR        DLGS
#define DLGS_CUSTOM_OFFSET_ERROR      DLGS+1
#define DLGS_CUSTOM_SUM_ERROR         DLGS+2
#define DLGS_LENGTH                   DLGS+3
#define DLGS_WIDTH                    DLGS+4
#define DLGS_PARALLEL                 DLGS+5
#define DLGS_PERPENDICULAR            DLGS+6
#define DLGS_szOptionAvailable        DLGS+7
#define DLGS_szPrinterSetupHelp       DLGS+8
#define DLGS_szDownloadHeaderOK       DLGS+9
#define DLGS_szDownloadHeader         DLGS+10
#define DLGS_szResourceAccess         DLGS+11
#define DLGS_szResourceError          DLGS+12
#define DLGS_szSetPrinterOK           DLGS+13
#define DLGS_szSetPrinter             DLGS+14
#define DLGS_szJobControlHelp         DLGS+15
//#define DLGS_szDeletePrinter          DLGS+16
//#define DLGS_szSelectPrinterDelete    DLGS+17
//#define DLGS_szPrinterDeleteHelp      DLGS+18
#define DLGS_szMissingHelp            DLGS+19
#define DLGS_OptionalFeatureHelp      DLGS+20
#define DLGS_TTDialogHelp             DLGS+21
//#define DLGS_szIndex                  DLGS+22
#define DLGS_NoPrinterHelp            DLGS+23
#define DLGS_CustomPaperHelp          DLGS+24
#define DLGS_CUSTOM_NAME_ERROR        DLGS+25
#define DLGS_szDownloadHeaderFailed   DLGS+26
#define DLGS_NO_HELP_TOPIC            DLGS+100
#define DLGS_szEPSWarning1            DLGS+101
#define DLGS_szEPSWarning2            DLGS+102
#define DLGS_MARGINS_ERROR            DLGS+103
#define DLGS_NO_MARGINS_FOR_CUSTPAP   DLGS+104
#define DLGS_VALIDATE_WARNING         DLGS+105
#define DLGS_NO_MARGINS               DLGS+106
#define DLGS_GRAPHICS_ERROR           DLGS+107
#define DLGS_VALUE_ERROR              DLGS+108   
#define DLGS_MAXIMUM                  DLGS+109
#define DLGS_MINIMUM                  DLGS+110 
#define DLGS_ADONLINE                 DLGS+111
#define DLGS_TRANSVERSE_ERROR         DLGS+112  
  
#define GLBL                          4350
//#define GLBL_DEFAULT_PRINTER          GLBL
#define GLBL_szFilePort               GLBL+2
//#define GLBL_szUnknownError           GLBL+3
#define GLBL_szNone                   GLBL+4
//#define GLBL_szFalse                  GLBL+5
//#define GLBL_szTrue                   GLBL+6
#define GLBL_szOne                    GLBL+7
#define GLBL_szTwo                    GLBL+8
#define GLBL_szThree                  GLBL+9
#define GLBL_szFont                   GLBL+10
//#define GLBL_szQuestion               GLBL+9
//#define GLBL_szHelpFile30             GLBL+10
#define GLBL_szHelpFile31             GLBL+11
#define GLBL_szPortsSection           GLBL+12

#define DLLSTUFF                      4375
//#define DLLSTUFF_LocalInit            DLLSTUFF
//#define DLLSTUFF_AdobeError           DLLSTUFF+1
//#define DLLSTUFF_BadPDMVersion        DLLSTUFF+2

#define ESC                           4380
//#define ESC_szUntitled                ESC
//#define ESC_MSRect1                   ESC+1
//#define ESC_MSRect2                   ESC+2
//#define ESC_MSRect3                   ESC+3
//#define ESC_MSRect4                   ESC+4
//#define ESC_PostScript                ESC+5

#define STRING_START          5000

#if 0
/* FROM  DMG\DLGS.C   */
#define ID_STR_AB                            STRING_START+150
#define ID_STR_OPT1                          STRING_START+2
#define ID_STR_OPT2                          STRING_START+3
#define ID_STR_CUSTOMPAPER                   STRING_START
#define ID_STR_JOBCONTROL                    STRING_START+4
#define ID_STR_PICKNICK                      STRING_START+5
#define ID_STR_NOPRNTR                       STRING_START+6
#define ID_STR_ADDP1                         STRING_START+7
#define ID_STR_ADDP31                        STRING_START+8

#define ID_STR_NONICK                        STRING_START+9
#define IDS_EPS                              STRING_START+10
#define IDS_TYPE42                           STRING_START+11

#define ID_STR_DefaultPrinter                STRING_START+70
#define ID_STR_Devmode30                     STRING_START+71
#define ID_STR_Devmode31                     STRING_START+72
#endif

/* FOR DEVCAPS.C */
#define ID_STR_FILE_DEP_FIRST           STRING_START+500
#define ID_STR_PSENUM_DLL               ID_STR_FILE_DEP_FIRST
#define ID_STR_RUNENUM_EXE              ID_STR_FILE_DEP_FIRST+1
#define ID_STR_DOWN_DLL                 ID_STR_FILE_DEP_FIRST+2
#define ID_STR_WINDOWN_EXE              ID_STR_FILE_DEP_FIRST+3
#define FILE_DEP_COUNT                  4

/* CONT\ESCAPES.C */
#define ID_STR_Untitiled                           STRING_START+12
#define ID_STR_PostScript                          STRING_START+13
#ifdef ADOBE_DRIVER
#define IDS_CONFIRM_WM_NUP_TEXT            STRING_START+14
#endif

#if 0
/* CONT\REALIZE.C */
#define ID_STR_Height                              STRING_START+14
#define ID_STR_Width                               STRING_START+15
#define ID_STR_Escapement                          STRING_START+16
#define ID_STR_Orientation                         STRING_START+17
#define ID_STR_Weight                              STRING_START+18
#define ID_STR_Italic                              STRING_START+19
#define ID_STR_Underline                           STRING_START+20
#define ID_STR_StrikeOut                           STRING_START+21
#define ID_STR_CharSet                             STRING_START+24
#define ID_STR_OutPrecision                        STRING_START+25
#define ID_STR_ClipPrecision                       STRING_START+26
#define ID_STR_Quality                             STRING_START+27
#define ID_STR_PitchAndFamily                      STRING_START+28
#define ID_STR_FaceName                            STRING_START+29

#define ID_STR_Points                              STRING_START+30
#define ID_STR_Ascent                              STRING_START+31
#define ID_STR_InternalLeading                     STRING_START+34
#define ID_STR_ExternalLeading                     STRING_START+35


#define ID_STR_PixWidth                            STRING_START+41
#define ID_STR_PixHeight                           STRING_START+42

#define ID_STR_AvgWidth                            STRING_START+46
#define ID_STR_MaxWidth                            STRING_START+47
#define ID_STR_WidthBytes                          STRING_START+48

#define ID_STR_Accelerator                         STRING_START+64
#define ID_STR_Overhang                            STRING_START+65

/* FROM DLLSTUFF.C */
#define ID_STR_PathToFile                         STRING_START+80

#define ID_STR_ErrHandlesLeft                     STRING_START+81
#define ID_STR_DisableCheck                       STRING_START+82
#endif

/* From dlgsutil.c */
#define IDS_SOFTFONTWARNING                       STRING_START+83
#define IDS_INSTALLWARNING                        STRING_START+84
//#define IDS_NEXTNICK_BASE                         STRING_START+85
//#define IDS_DLL_EXT                               STRING_START+86
//#define IDS_HLP_EXT                               STRING_START+87

//#define IDS_METRIC_OR_IMPERIAL_UNITS              STRING_START+88

/* From drvstate.c */
//#define IDS_USE_DEFAULT_PRINTER                   STRING_START+89

//#define IDS_DRIVER_ID                             STRING_START+90
//#define IDS_TWO_SETUPS                            STRING_START+91

/* From fntcache.c */
#define IDS_POSTSCRIPT                            STRING_START+100
#define IDS_SOFTFONT                              STRING_START+101
#define IDS_MFDFILEKEY                            STRING_START+102
#define IDS_MFD_FILE                              STRING_START+103
#define IDS_MFM_FILE                              STRING_START+104

/* From devmode.c */
#define IDS_INTL                                  STRING_START+105
#define IDS_COUNTRY                               STRING_START+106
#define IDS_COMMCTRL                              STRING_START+107
#define IDS_ICONLIB                               STRING_START+108
#define IDS_DEFAULTPRINTER                        STRING_START+109
#define IDS_DEFAULTPPD                            STRING_START+110
#define IDS_WEBPRINTER                            STRING_START+111

/* Defines below for the True Type Dialog box */

/* Identifiers used by the TT dialog for controls */
#define ID_SEND_AS              101
#define ID_SUBSTITUTE           102
#define ID_SB_TRUETYPE          103
#define ID_USE_DEFAULTS         104

/* These following identifiers need to be sequential to allow for expansion
   later */
// #define MAX_NUM_SUBSTITUTIONS     4
#define ID_TT_1                 200
#define ID_TT_2                 ID_TT_1 + 1
#define ID_TT_3                 ID_TT_2 + 1
#define ID_TT_4                 ID_TT_3 + 1
#define ID_ACTIVE_TT            200
#define ID_FONTS_LISTBOX        201

#define ID_SUBS_1               500
#define ID_SUBS_2               ID_SUBS_1 + 1
#define ID_SUBS_3               ID_SUBS_2 + 1
#define ID_SUBS_4               ID_SUBS_3 + 1
#define ID_ACTIVE_SUBS          500

#define STR_BUFF_LEN            128
#define SHORT_BUFF_LEN          64
#define FAMILY_NAME_SIZE        LF_FACESIZE
#define INI_CACHE_SIZE          24576

/* Send as States */
#define SEND_AS_TYPE_1          1
#define SEND_AS_TYPE_3          3
#define SEND_AS_TYPE_42         42
#define SEND_AS_DONT_SEND       0
#define SEND_AS_DEFAULT         SEND_AS_TYPE_1

// RCDATA resource IDs for font alias, preferred CJK fonts,
// fixed-pitch font names which are marked as proposional
// incorrectly, and TT=>PS substitution table. Each RCDATA
// block must be terminated with RCDATA_TERMINATOR value
// explicitely.

#define RCDATA_TERMINATOR       0x00
#define ALIAS_GROUP_TERMINATOR  0x01

#define ID_FNT_ALIAS            8000
#define ID_FNT_DEF_SUBS_FONT    8001
#define ID_FNT_INCRCT_FIXED     8002
#define ID_FNT_PREF_CJK         8003


//#ifdef STREAMER
#define ID_ENCODE_NAMES     8004
#define ID_ENCODE_INDEX     8005
//#endif

#ifdef ADD_EURO
#define ID_EUROFONT_NAMES                    8006
#define ID_EURO_T1CS                         8007
#define ID_EURO_T1CSIDX                      8008
#define ID_SETCACHEDEVICE_PARAMS             8009
#define ID_OBLIQUE_UNDERLYING                8010
#endif

#define ID_MAC_GLYPH_NAMES                   8011   

/* String identifiers */
#define IDS_SEND_AS_PREFIX      9100
#define IDS_DONT_SEND_PREFIX    9101
#define IDS_TYPE_1              9102
#define IDS_TYPE_3              9103
#define IDS_TYPE_42             9104
#define IDS_DONT_SEND           9105
#define IDS_NO_TT_FONTS         9106
#define IDS_NO_TT_FONTS_TITLE   9107

#define IDS_INI_SEND_AS         9500
#define IDS_INI_TT_SUBSTITUTION 9501
#define IDS_INI_TRUE            9502
#define IDS_INI_FALSE           9503
#define IDS_INI_SUBS_TITLE      9504
#define IDS_USE_DEFAULTS        9505
#define IDS_USE_DEFAULTS_TITLE  9506
#define IDS_TRUE_TYPE_TITLE     9507
#define IDS_TRUE_TYPE_DISABLED  9508
#define IDS_TT_SECTION          9509
#define IDS_TT_ENABLED          9510
#define IDS_TT_DEF_DLFORMAT     9511  // Default Tt DownLoad As format for non-type42 printers.
#define IDS_TT_DEF_DLFORMAT42   9512  // for T42-capable printers


/* We need a proper help topic ID here */
#define HELP_TTFONTS            HELP_CONTENTS

#define IDS_OK_STRING           13
#define IDS_CANCEL_STRING1      14
#define IDS_CANCEL_STRING2      15

#define IDS_BASE_UIC_NAME       3500
#define IDS_BASE_LAYOUT_NAME    3600
#define IDS_BASE_DUPLEX_NAME    3630

#define SMALL_UIC_BMP          3650
#define SMALL_UIC_MASK         3651
#define LARGE_UIC_BMP          3652
#define LARGE_UIC_MASK         3653
#define IDS_DRIVERFILES        3654
#define IDS_WIN31WPDFILE       3655

#define IDS_SUGGEST_RESOLUTION 3700


#ifdef ADOBE_DRIVER
    /* Values following the ones for ONEUP_ICON etc. in icons.h */
   // n-up without page border icons

#define LOGO_BMP        10
#define LOGO_MASK_BMP   11   
//  There are 36 pictures in paper control group and 34 pictures in paper handling group
#define PAPER_CONTROL_BMP  12
#define PAPER_PDNCNRN_BMP  12
#define PAPER_PDNCNRY_BMP  13
#define PAPER_PDNCYRN_BMP  14
#define PAPER_PDNCYRY_BMP  15
#define PAPER_PDLCNRN_BMP  16
#define PAPER_PDLCNRY_BMP  17
#define PAPER_PDLCYRN_BMP  18
#define PAPER_PDLCYRY_BMP  19
#define PAPER_PDSCNRN_BMP  20
#define PAPER_PDSCNRY_BMP  21
#define PAPER_PDSCYRN_BMP  22
#define PAPER_PDSCYRY_BMP  23

#define PAPER_LDNCNRN_BMP  24
#define PAPER_LDNCNRY_BMP  25
#define PAPER_LDNCYRN_BMP  26
#define PAPER_LDNCYRY_BMP  27
#define PAPER_LDLCNRN_BMP  28
#define PAPER_LDLCNRY_BMP  29
#define PAPER_LDLCYRN_BMP  30
#define PAPER_LDLCYRY_BMP  31
#define PAPER_LDSCNRN_BMP  32
#define PAPER_LDSCNRY_BMP  33
#define PAPER_LDSCYRN_BMP  34
#define PAPER_LDSCYRY_BMP  35

#define PAPER_RDNCNRN_BMP  36
#define PAPER_RDNCNRY_BMP  37
#define PAPER_RDNCYRN_BMP  38
#define PAPER_RDNCYRY_BMP  39
#define PAPER_RDLCNRN_BMP  40
#define PAPER_RDLCNRY_BMP  41
#define PAPER_RDLCYRN_BMP  42
#define PAPER_RDLCYRY_BMP  43
#define PAPER_RDSCNRN_BMP  44
#define PAPER_RDSCNRY_BMP  45
#define PAPER_RDSCYRN_BMP  46
#define PAPER_RDSCYRY_BMP  47

#define PAPER_CONTROL_MASK_BMP        48
#define PAPER_CONTROL_PDNCN_MASK_BMP  48
#define PAPER_CONTROL_PDNCY_MASK_BMP  49
#define PAPER_CONTROL_PDYCN_MASK_BMP  50
#define PAPER_CONTROL_PDYCY_MASK_BMP  51
#define PAPER_CONTROL_LDNCN_MASK_BMP  52
#define PAPER_CONTROL_LDNCY_MASK_BMP  53
#define PAPER_CONTROL_LDYCN_MASK_BMP  54
#define PAPER_CONTROL_LDYCY_MASK_BMP  55

#define PAPER_HANDLING_BMP   56
#define GRAPHICS_L01OPPN_BMP 56
#define GRAPHICS_L02OPPN_BMP 57
#define GRAPHICS_L04OPPN_BMP 58
#define GRAPHICS_L06OPPN_BMP 59
#define GRAPHICS_L09OPPN_BMP 60
#define GRAPHICS_L16OPPN_BMP 61

#define GRAPHICS_L01OLPN_BMP 62
#define GRAPHICS_L02OLPN_BMP 63
#define GRAPHICS_L04OLPN_BMP 64
#define GRAPHICS_L06OLPN_BMP 65
#define GRAPHICS_L09OLPN_BMP 66
#define GRAPHICS_L16OLPN_BMP 67

#define PAPER_HANDLING_BORDER_BMP 68 
#define GRAPHICS_L02OPPY_BMP 68
#define GRAPHICS_L04OPPY_BMP 69
#define GRAPHICS_L06OPPY_BMP 70
#define GRAPHICS_L09OPPY_BMP 71
#define GRAPHICS_L16OPPY_BMP 72

#define GRAPHICS_L02OLPY_BMP 73
#define GRAPHICS_L04OLPY_BMP 74
#define GRAPHICS_L06OLPY_BMP 75
#define GRAPHICS_L09OLPY_BMP 76
#define GRAPHICS_L16OLPY_BMP 77

#define PAPER_HANDLING_PORTRAIT_MASK_BMP  78
#define PAPER_HANDLING_LANDSCAPE_MASK_BMP 79 

#define CUSTOM1_ICON        277
#define CUSTOM2_ICON        278
#define CUSTOM3_ICON        279
#define CUSTOM4_ICON        280
#define CUSTOM5_ICON        281

#define CUSTOM1H_ICON       282
#define CUSTOM2H_ICON       283
#define CUSTOM3H_ICON       284
#define CUSTOM4H_ICON       285
#define CUSTOM5H_ICON       286

#define CUSTOM1W_ICON       287
#define CUSTOM2W_ICON       288
#define CUSTOM3W_ICON       289
#define CUSTOM4W_ICON       290
#define CUSTOM5W_ICON       291


#define SIXUP_ICON          503
#define NINEUP_ICON        504
#define SIXTEENUP_ICON      505

   // n-up with page border icons
#define TWOUPBD_ICON       506
#define FOURUPBD_ICON      507
#define SIXUPBD_ICON       508
#define NINEUPBD_ICON      509
#define SXTNUPBD_ICON      510

#endif

// This file is separated from PS 4.0. so no ifdef is added here:
#define IDS_DEVICES_IN_WININI   (STRING_START+200)
#define IDS_WM_NONE             (STRING_START+201)
#define IDS_WM_NEW              (STRING_START+202)
#define IDS_FONT_REGULAR        (STRING_START+203)
#define IDS_FONT_BOLD           (STRING_START+204)
#define IDS_FONT_ITALIC         (STRING_START+205)
#define IDS_FONT_BOLDITALIC     (STRING_START+206)
#define IDS_NEWWM_TITLE         (STRING_START+207)  //  New Watermark Dlg title.

#define IDS_UNIT_INCH           (STRING_START+208)  //  "(In)" - Inches
#define IDS_UNIT_CM             (STRING_START+209)  //  "(Cm)" - centimeters

#define IDS_CHARSET_INCOMPATIBLE (STRING_START+211) // tt substitution dlg
#define IDS_FONT_NO_SUBSTITUTE  (STRING_START+212)

// Keys in registry used by the driver
#define IDS_REGSTR_PATH_ADOBEPS       (STRING_START+213)
#define IDS_REGSTR_PATH_INCOMPAT_APPS (STRING_START+215)
#define IDS_REGSTR_PATH_WATERMARK     (STRING_START+216)
#define IDS_REGSTR_PATH_WATERMARK_CUSTOMCOLOR (STRING_START+217)
#define IDS_REGSTR_VAL_SHOW_ALERT     (STRING_START+218)
#define IDS_REGSTR_VAL_DISABLE_NUP    (STRING_START+219)
#define IDS_REGSTR_VAL_DISABLE_WM     (STRING_START+220)


// String IDS for Watermark Localization: Default Font and PS Font List with Display subs
#define IDS_WM_DEFAULT_FONT       (STRING_START+221)
#define IDS_WM_FONT_MIN           (STRING_START+222)
#define IDS_WM_FONT1              (STRING_START+223)
#define IDS_WM_FONT2              (STRING_START+224)
#define IDS_WM_FONT3              (STRING_START+225)
#define IDS_WM_FONT4              (STRING_START+226)
#define IDS_WM_FONT5              (STRING_START+227)
#define IDS_WM_FONT6              (STRING_START+228)
#define IDS_WM_FONT7              (STRING_START+229)
#define IDS_WM_FONT8              (STRING_START+230)
#define IDS_WM_FONT9              (STRING_START+231)
#define IDS_WM_FONT10             (STRING_START+232)
#define IDS_WM_FONT11             (STRING_START+233)
#define IDS_WM_FONT12             (STRING_START+234)
// add more strings here and increase the MAX val.
#define IDS_WM_FONT_MAX           (STRING_START+235)  // Keep this one maximal for IDS_WM_FOTN#

#define IDS_REGSTR_PATH_ICM       (STRING_START+236)   
#define IDS_REGSTR_PATH_FONTSINFO (STRING_START+237)
#define IDS_DRIVER_VERSION        (STRING_START +238)
#define IDS_DRIVER_MANUFACTURER   (STRING_START +239)
#define IDS_REGSTR_RESIDENT_FONTS (STRING_START +240)  
#define IDS_REGSTR_PRN_PRINTER    (STRING_START +241)
#define IDS_REGSTR_PRN_PRINTER_0  (STRING_START +242)
#define IDS_REGSTR_PRINTERDRIVERDATA (STRING_START +243)
#define IDS_REGSTR_ENV_DRIVERS       (STRING_START +244)
    
//added the following lines for localizing the driver.
#ifndef DS_3DLOOK
#define DS_3DLOOK             0x0004L
#endif
#ifndef DS_CONTEXTHELP
#define DS_CONTEXTHELP        0x2000L
#endif
#ifndef SS_ETCHEDHORZ
#define SS_ETCHEDHORZ         0x00000010L
#endif
#ifndef IDI_WARNING
#define IDI_WARNING           32515  // for localizing the driver.
#endif
