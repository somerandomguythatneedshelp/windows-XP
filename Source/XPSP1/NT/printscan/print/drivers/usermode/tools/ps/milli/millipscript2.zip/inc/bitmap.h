/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: BITMAP.H                                                     */
/*                                                                           */
/* Description: This module contains Nothing.                                */
/*                                                                           */
/*****************************************************************************/


