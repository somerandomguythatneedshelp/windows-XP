/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: FONTURIL.H                                             */
/*                                                                           */
/* Description: This include contains the prototype for font utiltity        */
/*                                                                           */
/*****************************************************************************/

LONG PASCAL FontScale(LPPDEVICE lppd,LPPFM lpPFM,SHORT sXScale,SHORT sYScale);
VOID FFontIndexFree(LPFONTSTATE lpFontState);
VOID FFontIndexUnlock(LPFONTSTATE lpFontState);
LPFONTINDEX FFontIndexLock(LPFONTSTATE lpFontState);
SHORT FFontDirOpen(LPFONTSTATE lpFontState);
SHORT FFontDirClose(SHORT hFontDir);
FLAG FFontRead(SHORT hFontDir,LPFONTSTATE lpFontState,SHORT sFontid,
        LPLPFONTREC lplpFontRec,LPLPPFM lplpPFM);
VOID FFontCacheLock(LPFONTSTATE lpFontState);
VOID FFontCacheUnlock(LPFONTSTATE lpFontState);

FLAG FFontidListInit(LPFONTSTATE lpFontState);
SHORT FFontidFind(LPFONTSTATE lpFontState,SHORT sFontid);
FLAG FFontidBump(LPFONTSTATE lpFontState);
FLAG FInstanceListInit(LPFONTSTATE lpFontState);
SHORT FInstanceFind(LPFONTSTATE lpFontState,LPFONTINSTANCE lpFontInst);
FLAG FInstanceBump(LPFONTSTATE lpFontState);
