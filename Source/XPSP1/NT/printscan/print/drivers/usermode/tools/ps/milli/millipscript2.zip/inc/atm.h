/*****************************************************************************
*                                                                           
* Module Name: ATM.H
*                                                                           
* Description: This module contains 
*              
*
* Version 2.5.1 - 2/20/93
*
* Same as 2.5 but has addFont/removeFont interface added.
*****************************************************************************/

#ifndef _H_ATM
#define _H_ATM


/* Define return values for non-BOOL functions. */
#define ATM_NOERR               (0)    /* Normal return. */
#define ATM_INVALIDFONT         (-1)   /* Font not consistent. */
#define ATM_CANTHAPPEN          (-2)   /* Some kind of internal error. */
#define ATM_BADMATRIX           (-3)   /* Matrix inverse undefined. */
#define ATM_MEMORY              (-4)   /* Out of memory. */
#define ATM_NOTSUPPORTED        (-5)   /* Running ATM doesn't support call. */
#define ATM_NOTRUNNING          (-6)   /* ATM is not running. */
#define ATM_FILLORDER           (-7)   /* Inconsistent fill calls. */
#define ATM_CANCELLED           (-8)   /* Client halted operation. */
#define ATM_NOCHAR              (-9)   /* No outline for char code in font. */
#define ATM_BADPROC             (-100) /* Bad callback proc address. */
#define ATM_CANTDRAW            (-101) /* Error in imaging; a bad rop? */
#define ATM_BADPARM             (-102) /* Bad parameter passed in. */
#define ATM_SELECTED            (-200) /* See ATMSelectObject. */
#define ATM_SELECTERROR         (-204) /* See ATMSelectObject. */



/* Define additional flags for the wOption parameter of the ...XYShow... */
/* routines.  These flags are NOT supported in all versions of the ATM   */
/* backdoor.  Check the version numbers for each option flag below.      */
#define ATM_USELOGCOLOR         (0x0100) /* In ATM backdoor since version 2.01
                                         ** This flag causes ATM to use the
                                         ** logical color set for text
                                         ** foreground in the DC even when
                                         ** it would normally switch to the
                                         ** nearest pure color based on the
                                         ** settings in ATM.INI.
                                         ** This is mutually exclusive with
                                         ** ATM_USEPURECOLOR.  Incorrect usage
                                         ** will cause an error.
                                         */
#define ATM_USEPURECOLOR        (0x0200) /* In ATM backdoor since version 2.01
                                         ** This flag causes ATM to use the
                                         ** nearest pure color instead of the
                                         ** actual logical color set for text
                                         ** foreground in the DC.
                                         ** This is mutually exclusive with
                                         ** ATM_USELOGCOLOR.  Incorrect usage
                                         ** will cause an error.
                                         */
#define ATM_MAKEVISIBLE         (0x0400) /* In ATM backdoor since version 2.01
                                         ** This flag is used for B/W devices
                                         ** and causes ATM to use either white
                                         ** or black depending on the color of
                                         ** background in order to make the
                                         ** text visible.
                                         ** If this flag is specified,
                                         ** ATM_USELOGCOLOR & ATM_USEPURECOLOR
                                         ** are ignored.
                                         */


/* Define flags for the 'options' parameter of the ATMSelectObject routine */
/* These flags are NOT supported in all versions of ATM.  Check the        */
/* version numbers for each option flag below.                             */
#define ATM_DEFER               (0x0001) /* In ATM backdoor since version 2.01
                                         ** This flag causes ATM to defer to a
                                         ** device font when selecting a font
                                         ** handle into a DC the first time.
                                         ** This is mutually exclusive with
                                         ** ATM_SELECT.  Incorrect usage will
                                         ** cause an error.
                                         */
#define ATM_SELECT              (0x0002) /* In ATM backdoor since version 2.01
                                         ** This flag forces ATM to render a
                                         ** font even when normally it would
                                         ** be deferred to the device.  This
                                         ** can happen only when selecting a
                                         ** handle into a DC the first time.
                                         ** This is mutually exclusive with
                                         ** ATM_DEFER.  Incorrect usage will
                                         ** cause an error.
                                         */
#define ATM_USEEXACTWIDTH       (0x0004) /* In ATM backdoor since version 2.01
                                         ** This flag causes ATM to create the
                                         ** font being selected into a screen
                                         ** DC without adjusting the width
                                         ** data.  This can happen only when
                                         ** selecting a handle into a DC for
                                         ** the first time.
                                         */



#ifndef ATMBD_IMPL

typedef long int ATMFixed;  /* 16.16 signed number.  Integer in hi word. */

typedef struct
{
   ATMFixed a, b, c, d, tx, ty;
} ATMFixedMatrix, FAR *LPATMFixedMatrix;

typedef struct
{
   ATMFixed x, y;
} ATMFixedPoint, FAR *LPATMFixedPoint;

typedef struct
{
   short int x, y;
} ATMShortPoint, FAR *LPATMShortPoint;

typedef struct
{
   ATMShortPoint ll, ur;
} ATMBBox, FAR *LPATMBBox;


#define ATMINTTOFIXED(n)        ((ATMFixed) (((long int) (n)) << 16))

extern BOOL FAR PASCAL ATMIsUp(void);
extern BOOL FAR PASCAL ATMGetBuildStr(LPSTR);



extern BOOL FAR PASCAL ATMProperlyLoaded (void);
        /* In ATM backdoor since version 1.0
        **
        ** This routine initializes the backdoor and returns true if all
        ** goes well and if ATM is loaded and running.  It will return false
        ** if ATM is not installed or loaded.
        **
        ** NOTE: You must have a call to 'ATMProperlyLoaded',
        **       or all other calls will fail.
        */

extern BOOL FAR PASCAL ATMClearAllForce (void);
        /* In ATM backdoor since version 2.0
        **
        ** Undoes preceeding calls to any and all of ATMForceCreate,
        ** ATMForceDefer, or ATMForceExactWidth whose effects are pending.
        **
        ** Returns true if the call is successful, false otherwise.
        **
        */

extern int  FAR PASCAL ATMFillStart (void);
        /* In ATM backdoor since version 1.0
        **
        ** Starts a new outline fill operation.
        */

extern int  FAR PASCAL ATMFillMoveTo (LPATMFixedPoint lpFixPnt);
extern int  FAR PASCAL ATMFillLineTo (LPATMFixedPoint lpFixPnt);
extern int  FAR PASCAL ATMFillCurveTo (
                                LPATMFixedPoint lpFixPnt1,
                                LPATMFixedPoint lpFixPnt2,
                                LPATMFixedPoint lpFixPnt3);
extern int  FAR PASCAL ATMFillClosePath (void);
        /* In ATM backdoor since version 1.0
        **
        ** All LPATMFixedPoint numbers passed into the above routines are
        ** expressed in DEVICE units (rather than logical units) and are
        ** not subject to changes due to some effective mapping mode.
        **
        ** NOTE: A bug in the ATM backdoor versions 1.0 and 1.1 prevented
        **       the coordinates passed into these routines from being
        **       interpreted correctly in any mode OTHER THAN MM_TEXT.
        **       Vesrions 1.15 and higher work correctly in all mapping modes
        **       although we recommend using MM_TEXT in order to minimize
        **       round off errors.
        */

extern int  FAR PASCAL ATMFillGetBBox (HDC hDC, LPATMBBox lpBBox);
        /* In ATM backdoor since version 1.15
        **
        ** This routine can be called before one of the FillEnd routines to
        ** obtain bounding box information for the outline being filled.
        **
        ** The information obtained from this routine can help the caller to
        ** more accurately determine x,y coordinates for one of the FillEnd
        ** operations.
        **
        ** NOTE: This routine cannot be called after a call to ATMFillEnd or
        **       ATMBaseFillEnd.
        **
        ** lpBBox is expressed in LOGICAL units.  If NULL, bbox is not
        ** returned.
        */

extern int  FAR PASCAL ATMFillEnd (HDC hDC, int x, int y, DWORD rop);
        /* In ATM backdoor since version 1.0
        **
        ** Completes an outline fill operation by actually rendering the
        ** resulting image on a device specified by hDC and using the raster
        ** operation 'rop'.
        ** x,y specifies (in LOGICAL units) the coordinates of the upper left
        ** corner of the image.
        **
        ** NOTE: The image is drawn using the current text color specified
        **       in hDC.
        */

extern int  FAR PASCAL ATMBaseFillEnd (HDC hDC, int x, int y, DWORD rop);
        /* In ATM backdoor since version 1.15
        **
        ** NOTE: This routine is different from ATMFillEnd ONLY in the way
        **       that x and y are interpreted.  In the case of this routine
        **       x and y are the coordinates of the start of the baseline
        **       for the character being filled and drawn.  x,y is expressed
        **       in LOGICAL units.
        */

extern BOOL FAR PASCAL ATMFontAvailable (
                                LPSTR    lpFacename,
                                int      nWeight,
                                BYTE     cItalic,
                                BYTE     cUnderline,
                                BYTE     cStrikeOut,
                                BOOL FAR *lpFromOutline);
        /* In ATM backdoor since version 1.0
        **
        ** Returns true if ATM can render the specified font.
        ** lpFromOutline is true if there is an actual outline available
        ** to ATM for rendering the font.  It will be false if ATM would
        ** synthesize the font from a base outline.
        */

extern BOOL FAR PASCAL ATMFontSelected (HDC hDC);
        /* In ATM backdoor since version 1.0
        **
        ** Returns true if the currently selected font in the hDC is an
        ** ATM font.
        */

extern BOOL FAR PASCAL ATMForceCreate (void);
#define ATMForceSelect ATMForceCreate
        /* In ATM backdoor since version 1.1
        **
        ** This routine causes the 'next' call for creating a font to actually
        ** create an ATM font even when normally deferring to a device font
        ** would be possible.  It is important that an application making this
        ** call NOT give up its time slice between calling this routine and
        ** actually creating (selecting) the font.  Doing so may render the
        ** call to this routine void as another application may attempt to
        ** create a font which will be affected by the first application's
        ** call to ATMForceCreate.
        **
        ** Returns true if the call is successful, false otherwise.
        **
        ** NOTE: ATMForceCreate is not a toggle.  The effect can be realized
        **       only ONCE.
        **
        ** NOTE: ATMForceCreate and ATMForceDefer are mutually exclusive.
        **       So a call to one voids a previous call to the other.
        **
        ** IMPORTANT NOTE: A font is actually created when it is selected into
        **       a target DC and NOT when CreateFont or CreateFontIndirect is
        **       called.  Therefore, an application must call ATMForceCreate
        **       immediately before calling SelectObject in order to achieve
        **       the desired effects.  Note that if a given font is selected
        **       into more than one DC then ATMForceCreate must be called
        **       before EACH call to SelectObject.
        **       Actually, it is more appropriate to use the macro
        **       ATMForceSelect instead of directly calling ATMForceCreate.
        */

extern BOOL FAR PASCAL ATMForceDefer (void);
        /* In ATM backdoor since version 2.0
        **
        ** This routine causes the 'next' call for creating a font to
        ** necessarily be deferred to the device even when ATM would normally
        ** create the font.  It is important that an application making this
        ** call NOT give up its time slice between calling this routine and
        ** actually creating (selecting) the font.  Doing so may render the
        ** call to this routine void as another application may attempt to
        ** create a font which will be affected by the first application's
        ** call to ATMForceDefer.
        **
        ** Returns true if the call is successful, false otherwise.
        **
        ** NOTE: ATMForceDefer is not a toggle.  The effect can be realized
        **       only ONCE.
        **
        ** NOTE: ATMForceCreate and ATMForceDefer are mutually exclusive.
        **       So a call to one voids a previous call to the other.
        **
        ** IMPORTANT NOTE: A font is actually created when it is selected into
        **       a target DC and NOT when CreateFont or CreateFontIndirect is
        **       called.  Therefore, an application must call ATMForceDefer
        **       immediately before calling SelectObject in order to achieve
        **       the desired effects.  Note that if a given font is selected
        **       into more than one DC then ATMForceDefer must be called
        **       before EACH call to SelectObject.
        */

extern BOOL FAR PASCAL ATMForceExactWidth (void);
        /* In ATM backdoor since version 1.1
        **
        ** This routine causes the 'next' call for creating a font to create
        ** a font without adjusting the width data for the screen.  Note that
        ** the effect can only be realized for a font that is selected into a
        ** display DC.  It is important that an application making this call
        ** NOT give up its time slice between calling this routine and
        ** actually creating (selecting) the font.  Doing so may render the
        ** call to this routine void as another application may attempt to
        ** create a font which will be affected by the first application's
        ** call to ATMForceExactWidth.
        **
        ** Returns true if the call is successful, false otherwise.
        **
        ** NOTE: ATMForceExactWidth is not a toggle.  The effect can be
        **       realized only ONCE.
        **
        ** IMPORTANT NOTE: A font is actually created when it is selected into
        **       a target DC and NOT when CreateFont or CreateFontIndirect is
        **       called.  So, an application must call ATMForceExactWidth
        **       immediately before calling SelectObject in order to achieve
        **       the desired effects.  Note that if a given font is selected
        **       into more than one screen DC then ATMForceExactWidth must be
        **       called before EACH call to SelectObject.
        */

extern int FAR PASCAL ATMGetFontBBox (
                                HDC       hDC,
                                LPATMBBox lpFontBBox);
        /* In ATM backdoor since version 2.01
        **
        ** This routine obtains the font bounding box for the font currently
        ** selected into 'hDC'.
        **
        ** lpFontBBox is expressed in unscaled character units.  If NULL,
        ** ATM_BADPARM is returned.
        */

extern int FAR PASCAL ATMGetOutline (
                                HDC              hDC,
                                char             c,
                                LPATMFixedMatrix lpMatrix,
                                FARPROC          lpProcMoveTo,
                                FARPROC          lpProcLineTo,
                                FARPROC          lpProcCurveTo,
                                FARPROC          lpProcClosePath,
                                LPSTR            lpData);
        /* In ATM backdoor since version 1.0
        **
        ** Reports the outline of the specified character.
        **
        ** Callbacks should look something like this...
        ** Don't forget to export them in the .DEF file and to pass
        ** ProcInstances to ATMGetOutline.
        **
        **    BOOL FAR PASCAL ClosePath (LPSTR lpData)
        **    BOOL FAR PASCAL MoveTo (LPATMFixedPoint lpFixPnt, LPSTR lpData)
        **    BOOL FAR PASCAL LineTo (LPATMFixedPoint lpFixPnt, LPSTR lpData)
        **    BOOL FAR PASCAL CurveTo (LPATMFixedPoint lpFixPnt1,
        **                             LPATMFixedPoint lpFixPnt2,
        **                             LPATMFixedPoint lpFixPnt3,
        **                             LPSTR lpData)
        **
        ** NOTE: ATMGetOutline cannot be called in the middle of an
        **       ATMFillStart..ATMFillEnd block of operations.
        */

extern WORD FAR PASCAL ATMGetVersion (void);
        /* In ATM backdoor since version 1.0
        **
        ** Returns the version number of the currently running ATM.  Minor
        ** number in high byte and major number in low byte.
        */

extern int FAR PASCAL ATMSelectObject (
                                HDC      hDC,
                                HANDLE   hNewObject,
                                WORD     options,
                                LPHANDLE lphOldObject);
        /* In ATM backdoor since version 2.01
        **
        ** This routine is designed to replace the collection of ATMForceXXX
        ** and the corresponding ATMClearAllForce routines.
        **
        ** Instead of calling one of the ATMForceXXX routines followed by a
        ** call to SelectObject(), an application should call ATMSelectObject
        ** with appropriate flags set in the 'options' parameter.  For this
        ** parameter, ATM_DEFER, ATM_SELECT, and ATM_USEEXACTWIDTH specify
        ** the equivalent actions to ATMForceDefer(), ATMForceCreate, and
        ** ATMForceExactWidth, respectively.  It is not necessary to call
        ** ATMClearAllForce() following a call to ATMSelectObject().
        **
        ** The handle being selected into the DC is passed in 'hNewObject'.
        ** The handle to the old object is returned in 'lphOldObject'.  If
        ** this parameter is NULL, the old object is not returned.
        **
        ** Successful return value:
        **      ATM_SELECTED            hNewFont successfully selected.
        **   NOTE that ATM_SELECTED is the same return value as
        **        ATM_NEWFONTSELECTED in versions 2.01 and 2.02.  In these
        **        older versions, this routine returned additional values:
        **        ATM_NONFONTSELECTED, ATM_OLDFONTSELECTED, and
        **        ATM_FOREIGNFONTSELECTED.  All of these return values are
        **        now obsolete.
        **
        ** Failure return values are:
        **      ATM_NOT_ON              ATM is not running.
        **      ATM_BADPARM             Conflicting 'options' flags.
        **      ATM_CANTHAPPEN          An internal error is encountered.
        **      ATM_SELECTERROR         'hDC' or 'hNewObject' is bad/invalid.
        */

extern BOOL FAR PASCAL ATMXYShowText (
                                HDC              hDC,
                                int              x,
                                int              y,
                                WORD             wOptions,
                                LPRECT           lpRect,
                                LPSTR            lpString,
                                int              nCount,
                                LPATMFixedPoint  lpPoints,
                                LPATMFixedMatrix lpMatrix);
        /* In ATM backdoor since version 1.0
        **
        ** Renders text given an arbitrary transformation matrix (lpMatrix)
        ** and specific widths (lpPoints) for precise positioning of each
        ** character in the string.  All but the last two parameters
        ** correspond to and are interpreted the same as the parameters of
        ** GDI's ExtTextOut with the following exceptions:
        **
        **    1) the wOptions parameter may include addition ATM-specific
        **       values ATM_USELOGCOLOR, ATM_USEPURECOLOR, or ATM_MAKEVISIBLE.
        **    2) Opaquing text is not supported.  That is, if wOptions includes
        **       the ETO_OPAQUE option, it will be ignored.
        **
        ** Returns true if the call is successful, false otherwise.
        **
        ** lpPoints is expressed in DEVICE units.  If NULL, default character
        ** widths are used.
        ** lpMatrix is expressed in DEVICE units.  If NULL, the font is used
        ** unmodified.
        **
        ** NOTE: x and y are the coordinates of the upper left corner of the
        **       text box without taking the matrix into consideration.  In
        **       other words, x,y defines the origin of a normal TextOut or
        **       ExtTextOut call which would use the font unmodified (i.e.
        **       with default matrix).  This means that the baseline position
        **       is determined relative to the unmodified font.  Also note
        **       that x and y are expressed in LOGICAL units (just as the x
        **       and y parameters of the TextOut and ExtTextOut routines).
        **       However, the character widths passed in 'lpPoints' are
        **       expressed in DEVICE units and are not subject to the current
        **       mapping mode in effect for 'hDC'.  This means that for
        **       devices that are capable of rendering graphics at lower than
        **       normal resolutions (such as the PCL driver's ability to
        **       switch to 150 or 75 dpi), these widths are expressed at the
        **       graphics resolution in effect.
        **       lpRect is expressed in LOGICAL units.
        **
        ** NOTE: ATMXYShowText cannot be called in the middle of an
        **       ATMFillStart..ATMFillEnd block of operations.
        */

extern BOOL FAR PASCAL ATMBBoxBaseXYShowText (
                                HDC              hDC,
                                int              x,
                                int              y,
                                WORD             wOptions,
                                LPRECT           lpRect,
                                LPSTR            lpString,
                                int              nCount,
                                LPATMFixedPoint  lpPoints,
                                LPATMFixedMatrix lpMatrix,
                                BOOL             bDoOutput,
                                LPATMBBox        lpBBox,
                                LPATMFixedPoint  lpDelta);
        /* In ATM backdoor since version 1.15
        **
        ** This routine is quite similar to the ATMXYShowText routine with
        ** some slight differences.  First, x and y specify the coordinates
        ** of the start of the baseline (rather than the upper left corner).
        ** Similar to ATMXYShowText, x and y are interpreted as LOGICAL units,
        ** lpRect is expressed in LOGICAL units, and lpPoints are given in
        ** DEVICE units.
        ** If bDoOutput is TRUE then actual output is produced in the same
        ** manner as ATMXYShowText.
        ** lpBBox will receive the bounding box (or extent), in LOGICAL units,
        ** of the string.
        ** lpDelta will receive the deltas that should be applied to x,y in
        ** order to make a following call to this routine continue at the
        ** correct point on the baseline.  lpDelta is given in DEVICE units.
        **
        ** Returns true if the call is successful, false otherwise.
        **
        ** lpBBox is expressed in LOGICAL units.  If NULL, bbox is not
        ** returned.
        ** lpDelta is expressed in DEVICE units.  If NULL, delta is not
        ** returned.
        **
        ** NOTE: ATMBBoxBaseXYShowText cannot be called in the middle of an
        **       ATMFillStart..ATMFillEnd block of operations.
        */


/***** The following APIs are used to update ATM's data structures ****/


/* Define return values for non-BOOL functions. */
#define ATM_PATHTOOLONG         (-400) /* See ATMAddFont. */
#define ATM_BADFONTTYPE         (-401) /* See ATMAddFont. */
#define ATM_BADSTYLE            (-402) /* See ATMAddFont. */
#define ATM_NOROOM              (-403) /* See ATMAddFont. */
#define ATM_NOFONT              (-404) /* See ATMAddFont. */
#define ATM_BADMENUNAME         (-405) /* See ATMAddFont. */
#define ATM_FONTINUSE           (-406) /* See ATMAddFont. */
#define ATM_FONTPRESENT         (-407) /* See ATMFontStatus. */
#define ATM_FONTDIFFERENT       (-408) /* See ATMFontStatus. */
#define ATM_FONTABSENT          (-409) /* See ATMFontStatus. */


/* Define flags for the 'style' parameter of ATMAddFont and ATMRemoveFont. */
#define ATM_BOLD                0x0002
#define ATM_BOLDITALIC          (ATM_BOLD | ATM_ITALIC)
#define ATM_ITALIC              0x0001


extern int FAR PASCAL ATMAddFont (
                                LPSTR lpMenuName,
                                WORD  style,
                                LPSTR lpMetricsFile,
                                LPSTR lpFontFile);
        /* In ATM backdoor since version 2.5
        **
        ** This routine makes a newly installed font available to ATM.
        **
        ** The lpMenuName contains the Windows name of the font.
        **
        ** The style parameter contains none, one or both of the flags
        ** ATM_ITALIC and ATM_BOLD.
        **
        ** The lpMetricsFile contains the full pathname to the .pfm file
        ** for the font.
        **
        ** The lpFontFile contains the full pathname to the .pfb file for
        ** the font.
        **
        ** Successful return values are:
        **     ATM_NOERR
        **
        ** Failure return values are:
        **     ATM_INVALIDFONT          Invalid font format.
        **     ATM_PATHTOOLONG          At least one path is too long.
        **     ATM_BADFONTTYPE          The font is uncompressed.
        **     ATM_BADSTYLE             The style parameter has bad bits!
        **     ATM_NOROOM               Can't add to internal tables.
        **     ATM_NOFONT               At least one path doesn't point to
        **                              the correct file.
        **     ATM_BADMENUNAME          Missing or invalid menu name given.
        **     ATM_FONTINUSE            The paths and menu name specify an
        **                              existing font which is in use by ATM.
        */

extern int FAR PASCAL ATMBeginFontChange (void);
        /* In ATM backdoor since version 2.5
        **
        ** Starts a series of font change operations consisting of calls to
        ** the rotuines ATMAddFont and ATMRemoveFont.  Must be called before
        ** calling ATMAddFont or ATMRemoveFont.
        */

extern int FAR PASCAL ATMEndFontChange (void);
        /* In ATM backdoor since version 2.5
        **
        ** Finishes a series of font change operations consisting of calls to
        ** the rotuines ATMAddFont and ATMRemoveFont.
        ** Call this function after font changes are completed, or your font
        ** changes may not take effect.
        */

extern int FAR PASCAL ATMRemoveFont (
                                LPSTR lpMenuName,
                                WORD  style);
        /* In ATM backdoor since version 2.5
        **
        ** This call makes a font inaccessible to ATM. Any subsequent
        ** requests to ATM for this font will fail.
        **
        ** The lpMenuName contains the Windows name of the font.
        **
        ** The style parameter contains none, one or both of the flags
        ** ATM_ITALIC and ATM_BOLD.
        **
        ** Successful return values are:
        **     ATM_NOERR
        **
        ** Failure return values are:
        **     ATM_BADSTYLE             The style parameter has bad bits!
        **     ATM_NOFONT               The specified font is not available.
        **     ATM_BADMENUNAME          Missing or invalid menu name given.
        */

extern int FAR PASCAL ATMFontStatus (
                                LPSTR lpMenuName,
                                WORD  style,
                                LPSTR lpMetricsFile,
                                LPSTR lpFontFile);
        /* In ATM backdoor since version 2.5
        **
        ** This routine determines whether or not a given font is currently
        ** installed and/or in use by ATM.  It should be called prior to
        ** installing a new font.
        ** If the return value is ATM_FONTINUSE, then no attempt should be made
        ** to install the font.
        **
        ** The lpMenuName contains the Windows name of the font.
        **
        ** The style parameter contains none, one or both of the flags
        ** ATM_ITALIC and ATM_BOLD.
        **
        ** The lpMetricsFile contains the full pathname to the .pfm file
        ** for the font.
        **
        ** The lpFontFile contains the full pathname to the .pfb file for
        ** the font.
        **
        ** Successful return values are:
        **     ATM_FONTINUSE            The paths and menu name specify an
        **                              existing font which is in use by ATM.
        **     ATM_FONTPRESENT          The paths and menu name specify an
        **                              existing font which is NOT in use.
        **     ATM_FONTDIFFERENT        The font, as specified by its menu name
        **                              and styles, exists but its data files
        **                              are different from those specified by
        **                              lpMetricsFile & lpFontFile parameters.
        **     ATM_FONTABSENT           There is no such font installed.
        **
        ** Failure return values are:
        **     ATM_PATHTOOLONG          At least one path is too long.
        **     ATM_BADFONTTYPE          The font is uncompressed.
        **     ATM_BADSTYLE             The style parameter has bad bits!
        **     ATM_NOFONT               At least one path doesn't point to
        **                              the correct file.
        **     ATM_BADMENUNAME          Missing or invalid menu name given.
        */


#endif /* ATMBD_IMPL */

#endif /* _H_ATM */
