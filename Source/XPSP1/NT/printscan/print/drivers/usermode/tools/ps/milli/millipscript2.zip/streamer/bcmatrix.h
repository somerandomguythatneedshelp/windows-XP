/* CM_VerSion bcmatrix.h atm05 1.2 10075.eco sum= 49352 */
 /* CM_VerSion bcmatrix.h atm04 1.6 05393.eco sum= 30255 */
/*
  bcmatrix.h -- Interface to matrix routines.

Copyright (c) 1986-1992 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks
of Adobe Systems Incorporated.

Original version: Mike Byron
Edit History:
Craig Rublee: Wed May 13 18:37:03 PDT 1992
End Edit History.
*/

#ifndef BCMATRIX_H
#define BCMATRIX_H

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif

#ifndef	PACKAGE_SPECS_H
#include PACKAGE_SPECS
#endif

#include PUBLICTYPES
#include BUILDCH


#ifndef USE68KMATRIX
#define USE68KMATRIX            0
#endif  /* USE68KMATRIX */

  /* SetupMtx return codes:                                                */
#define SM_NOERR   0            /* No problems                             */
#define SM_TOOBIG  1            /* Coefficients too big                    */
#define SM_BADINV  2            /* Matrix inversion failed                 */

typedef struct {
  real a, b, c, d, tx, ty;
  } RMtx, *PRMtx;

typedef enum {
  none, bc_zero, ad_zero, general
  } MtxType;


typedef struct {
  CardX mtxtype, imtxtype;
  FixMtx  m;
  FixMtx im; /* inverse */
  } FntMtx, *PFntMtx;


extern Fixed ApproxDLen ARGDECL1(PFCd, cp);
extern procedure LinesPerEm 
ARGDECL4(
  FixMtx  *, tfm,  /* Character space to device space matrix */
  Fixed,  mSize,   /* Size of unit square in charater space units */
  Fixed   *, pX, 
  Fixed   *, pY 
);

procedure GetEmSize
ARGDECL2(
  FracMtx  *, pFMtx,	/* FontMatrix */
  Fixed	   *, mSize
);

extern boolean FixMtxInvert ARGDECL2(   /* returns true/false success code         */
  FixMtx *, m,                  /* a matrix                                */
  FixMtx *, im                  /* return the inverse                      */
  );

  /* SetUpMtx must be   called  to  set  up the  matrix  that is used  by
     BuildChar. This routine only needs
     to be called when fontMatrix and/or tfmMatrix change.                 */

extern IntX SetUpMtx
  ARGDECL6(
  PFixMtx,   pTfm,        /* Transformation from character to device space. */ 
  Fixed,     mSize,       /* Size of unit square in charater space units */
  PFixMtx,   pFIMtx,	  /* pointer to matrix in the FontInst struct. */     	
  boolean *, pNoXSkew,    /* true => X axis is skewed */
  boolean *, pNoYSkew,    /* true => Y axis is skewed */
  boolean *, pSwitchAxis  /* true => X and Y axes are flipped */
  );

/* SetGSMatrix - initializes the global gsmatrix from mtx */
extern int SetGSMatrix ARGDECL2(FixMtx *, mtx, boolean, switchAxis);


extern procedure BCTfmP
  ARGDECL3(
   PFontInst,	pFontInst,
   FCd,		c,
   FCd *,	ct
  );
  
#if     USE68KMATRIX

extern procedure FntTfmP ARGDECL2(FCd, c, FCd *, ct);
extern procedure FntITfmP ARGDECL2(FCd, c, FCd *, ct);
extern procedure FntDTfmP ARGDECL2(FCd, c, FCd *, ct);
extern procedure FntIDTfmP ARGDECL2(FCd, c, FCd *, ct);

#else   /* USE68KMATRIX */

global procedure (*Transform) ARGDECL2(FCd, c, FCd *, ct);
global procedure (*ITransform) ARGDECL2(FCd, c, FCd *, ct);
global procedure (*DTransform) ARGDECL2(FCd, c, FCd *, ct);
global procedure (*IDTransform) ARGDECL2(FCd, c, FCd *, ct);

#define FntTfmP(c, ct)  (*(Transform))(c, ct)
#define FntITfmP(c, ct) (*(ITransform))(c, ct)
#define FntDTfmP(c, ct)  (*(DTransform))(c, ct)
#define FntIDTfmP(c, ct)  (*(IDTransform))(c, ct)


/* The next group of procedures are the transformation procs used by
   BCSetMtx and the Tfm #defines. */
extern procedure bcz_fixed_tfm ARGDECL2(FCd, c, FCd *, ct);
extern procedure adz_fixed_tfm ARGDECL2(FCd, c, FCd *, ct);
extern procedure gen_fixed_tfm ARGDECL2(FCd, c, FCd *, ct);
extern procedure d_bcz_fixed_tfm ARGDECL2(FCd, c, FCd *, ct);
extern procedure d_adz_fixed_tfm ARGDECL2(FCd, c, FCd *, ct);
extern procedure d_gen_fixed_tfm ARGDECL2(FCd, c, FCd *, ct);
extern procedure inv_bcz_fixed_tfm ARGDECL2(FCd, c, FCd *, ct);
extern procedure inv_adz_fixed_tfm ARGDECL2(FCd, c, FCd *, ct);
extern procedure inv_gen_fixed_tfm ARGDECL2(FCd, c, FCd *, ct);
extern procedure inv_d_bcz_fixed_tfm ARGDECL2(FCd, c, FCd *, ct);
extern procedure inv_d_adz_fixed_tfm ARGDECL2(FCd, c, FCd *, ct);
extern procedure inv_d_gen_fixed_tfm ARGDECL2(FCd, c, FCd *, ct);

#endif  /* USE68KMATRIX */


#endif  /* BCMATRIX_H */
