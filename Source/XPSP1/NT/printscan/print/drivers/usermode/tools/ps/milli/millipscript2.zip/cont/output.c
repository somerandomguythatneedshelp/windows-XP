/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: OUTPUT.C                                                     */
/*                                                                           */
/* Description: This module contains the functions for ...                   */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_GRAPHSEG)


// postscript is limited to 1500 polygon points.  each x and y of a moveto
// is one (2 per pair).  for a curveto each x,y is 2 (4 per pair).

#define PATH_LIMIT  1500

/* Local routine */
BOOL NEAR PtsAreRect(int sCount, LPPOINT lppt);

/* GDI brute routine */
short FAR PASCAL dmOutput(LP,short,short,LPPOINT,LPPPEN,LPPBRUSH,
     LPDRAWMODE,LPRECT);

FLAG FAR PASCAL CDoPen(LPPDEVICE lppd,LPPPEN lpPPen,LPDRAWMODE lpDrawMode)
{
  //LATER: make this more optimal, look ahead, if more than
  //a certain amt of changes are required output the entire
  //pen structure instead of the individual parameters
  //
  //    Now we store all information about pen, even if
  //    pen is NULL
  //    If we are asked to use a null pen we must store this information
  //        but suppress the output until the pen style is back to normal
  //    Changed  17-Mar-1993  -by-  [olegs]
  if(lpPPen )
  {
       // The DDK book said so.....
       //  18-Mar-1993  -by-  [olegs]
       if( lpPPen->ptWidth.x < 0 )           // Null pen
               lpPPen->bStyle = LS_NOLINE ;

       if(lpPPen->bStyle!=lppd->pen.bStyle)
       {
               CPenStyle(lppd, lpPPen->bStyle);
       }
       if( lpPPen->bStyle == LS_NOLINE )   // No need to go any further - exit
               return ( FALSE ) ;

       if(lpPPen->ptWidth.x!=lppd->pen.ptWidth.x)
       {
            CPenWidth(lppd,lpPPen->ptWidth);
       }

       if(lpPPen->bCap!=lppd->pen.bCap)
       {
            //for pen cap the PDEVICE structure has the current state
            //information, we must update the PPEN structure
            //
            lpPPen->bCap=lppd->pen.bCap;
            CPenCap(lppd,lppd->pen.bCap);
       }
       if(lpPPen->bJoin!=lppd->pen.bJoin)
       {
            //for pen cap the PDEVICE structure has the current state
            //information, we must update the PPEN structure
            //
            lpPPen->bJoin=lppd->pen.bJoin;
            CPenJoin(lppd,lppd->pen.bJoin);
       }
       if(lpPPen->sMiterLimit!=lppd->pen.sMiterLimit)
       {
            //for pen cap the PDEVICE structure has the current state
            //information, we must update the PPEN structure
            //
            lpPPen->sMiterLimit=lppd->pen.sMiterLimit;
            CPenMiterLimit(lppd,lppd->pen.sMiterLimit);
       }
       if(lpPPen->dFGColor!=lppd->pen.dFGColor)          // Color of solid lines
       {                                                 // and dashes in styled
            CPenFGColor(lppd,lpPPen->dFGColor);
       }
       if(lpDrawMode->bkColor!=lppd->pen.dBGColor)       // Color of gaps in styled
       {                                                 // lines.
            CPenBGColor(lppd,lpDrawMode->bkColor);
       }
       if((BYTE)lpDrawMode->bkMode!=lppd->graphics.bBackgroundMode)
       {
          CBackgroundMode(lppd,(BYTE)lpDrawMode->bkMode);
       }
       return(TRUE);
  }else
       CPenStyle(lppd, LS_NOLINE);
  return(FALSE);
}


FLAG FAR PASCAL CDoBrush(LPPDEVICE lppd,LPPBRUSH lpPBrush,LPDRAWMODE lpDrawMode)
{
  LPDWORD PDevicePat0_3,BrushPat0_3;
  LPDWORD PDevicePat4_7,BrushPat4_7;
  DWORD   FGColor,BGColor;

  if(lpPBrush )
  {
  //    Now we store all information about brush, even if
  //    the brush is hollow
  //    If the brush is hollow - store this information, but don't
  //        send anything out
  //    Changed  17-Mar-1993  -by-  [olegs]
       switch(lpPBrush->bStyle)
       {
     case BS_SOLID  :
           FGColor = lpPBrush->dFGColor;
           BGColor = lpPBrush->dBGColor;
           break;

     case BS_HATCHED:
           FGColor = lpPBrush->dFGColor;
           BGColor = lpPBrush->dBGColor;
           if(lpPBrush->bHatch!=lppd->brush.bHatch)
           {
               CBrushHatch(lppd,lpPBrush->bHatch);
           }
           break;

     case BS_PATTERN:
           FGColor = lpDrawMode->TextColor;
           BGColor = lpDrawMode->bkColor;

           BrushPat0_3 = (DWORD FAR *) &(lpPBrush->pattern[0]);
           BrushPat4_7 = (DWORD FAR *) &(lpPBrush->pattern[4]);

           PDevicePat0_3 = (DWORD FAR *) &(lppd->brush.pattern[0]);
           PDevicePat4_7 = (DWORD FAR *) &(lppd->brush.pattern[4]);

           if((*BrushPat0_3!=*PDevicePat0_3) || (*BrushPat4_7!=*PDevicePat4_7))
           {
               CBrushPattern(lppd,(LPPAT) &lpPBrush->pattern[0]);
           }
           break;

     case BS_HOLLOW:
     default:
           CBrushStyle(lppd, BS_HOLLOW);
           return (FALSE) ;
           break;
       }                                                 // End switch(...

       if( lpPBrush->bStyle != lppd->brush.bStyle)
       {
          CBrushStyle(lppd, lpPBrush->bStyle);
       }

       if((BYTE)lpDrawMode->bkMode != lppd->graphics.bBackgroundMode)
       {
          CBackgroundMode(lppd, (BYTE) lpDrawMode->bkMode);
       }

       if(FGColor!=lppd->brush.dFGColor)
       {
          CBrushFGColor(lppd,FGColor);
       }
       if(BGColor!=lppd->brush.dBGColor)
       {
          CBrushBGColor(lppd,BGColor);
       }
       return(TRUE);
  }else
       CBrushStyle(lppd, BS_HOLLOW);

  return(FALSE);
}



/*************************************************************************
 *
 *  function: Output
 *
 *      Draws geometrical shapes (lines, rectangles, etc.).  Uses GDI
 *      state extensively.  When fDoMSRectHack flag is set, this routine
 *      implements the hack.
 *
 *      May be called anytime between StartDoc and EndDoc.  
 *      Can be disabled.  Can change state.
 *
 *  prototype:
 *      short FAR PASCAL Output(LP lpDevice,short sStyle,
 *               short sCount,LPPOINT lppt, LPPPEN lpPPen,LPPBRUSH lpPBrush,
 *               LPDRAWMODE lpDrawMode,LPRECT lpClipRect)
 *
 *  parameters:
 *      LP lpDevice -   Pointer to PDEVICE for current device context
 *      short sStyle -  Code indicating what shape to draw (and how to
 *                      interpret lppt[])
 *      short sCount -  The number of elements in lppt[]
 *      LPPOINT lppt -  An array of POINT, giving vertices to draw
 *      LPPPEN lpPPen - Pointer to a PPEN structure (GDI physical pen)
 *      LPPBRUSH lpPBrush -
 *                      Pointer to a PBRUSH structure (GDI physical brush)
 *      LPDRAWMODE lpDrawMode -
 *                      Pointer to a DRAWMODE structure (GDI graphics state)
 *      LPRECT lpClipRect -
 *                      Pointer to an optional clipping rectangle
 *
 *************************************************************************/

short _loadds FAR PASCAL Output(LP lpDevice,short sStyle,short sCount,
                                LPPOINT lppt,LPPPEN lpPPen,LPPBRUSH lpPBrush,
                                LPDRAWMODE lpDrawMode,LPRECT lpClipRect)
{
     LPPDEVICE lppd;
     FLAG  eoFill;
     short height,width;
     RECT  rect;
     POINT radius;
     short  point_limit ;
     short sRC   = 1; //success
     BOOL  bClipSent = FALSE;

     lppd=(LPPDEVICE)lpDevice;
     sRC = 0; //failure
     if(lppd->sMagic == 0)           //is this call to a memory bitmap?
     sRC = dmOutput(lpDevice,sStyle,sCount,lppt,lpPPen,lpPBrush,
          lpDrawMode,lpClipRect);

     else if (lppd->sMagic==LUCAS)
     {
          sRC = 1; // success

          if (!fInDocLppd(lppd))
          {
          sRC = 0;    // We're being called at the wrong time; failure.
          
          }

          else if (fDisableGDILppd(lppd))
          {
          // GDI is disabled.  This call is a NOP, and returns success.
          // sRC is already 1.
          }

          else if (fDoMSRectHackLppd(lppd) && (sStyle == OS_RECTANGLE)) 

          // Check to see if we should invoke the MS Rectangle hack
          // If the style is OS_RECTANGLE, and the flag fDoMSRectHack
          // is TRUE, then do the hack; else proceed normally (clearing
          // the fDoMSRectHack flag).

          {
          if (!fChangeStateLppdSt(lppd, ST_RAW_DATA))
               sRC = 0;        // This transistion should never fail.

               CMSRectHack(lppd, (lpClipRect != NULL),
                  lpClipRect, (LPRECT)lppt     );

               SetDoMSRectHackLppdF(lppd, FALSE);
          }

          else    // Normal code generation

          {
               if (!fChangeStateLppdSt(lppd, ST_MARKED_PAGE))
                    sRC = 0;        // This transistion should never fail.

               // if we have a buffered bitmap, flush it before any output 
               // operation is done - check for buffered bitmap before calling
               // function to prevent DIB segment from loading unnecessarily.
               if (lppd->GlobalBuffer.hBitmapBf && 
                   lppd->GlobalBuffer.lpBitmapBf)
               {
                   HandleBufferedBitmap((LP)lppd);
               }

               //   Fixed  17-Mar-1993 -by-  [olegs]
               if(lppd->graphics.PathLevel == 0 )   // Realize pen and brush
               {                               //  only when not in PATH mode
                    CDoPen  (lppd,lpPPen    ,lpDrawMode);
                    if( sStyle  !=  OS_POLYLINE  &&  sStyle  !=  OS_POLYBEZIER)
                         CDoBrush(lppd,lpPBrush,lpDrawMode);
               }
               if( lpDrawMode  &&  
                  (((WORD)lpDrawMode->ICMCXform != (WORD)lppd->graphics.hCMTransform ) ||
                   (lpDrawMode->ICMCXform == NULL) && (lppd->graphics.hDefCMTransform)
                  ))
               {
                   // ALWAYS_ICM
                   if ((lpDrawMode->ICMCXform == NULL) &&
                       (lppd->graphics.hDefCMTransform))
                   {
                       if ((WORD)lppd->graphics.hDefCMTransform != (WORD)lppd->graphics.hCMTransform)
                           CICMColor(lppd, lppd->graphics.hDefCMTransform);
                   }
                   else
                   {
                       CICMColor(lppd, lpDrawMode->ICMCXform );
                   }
               }
// In some  cases we are called with hollow brush and null pen
//   in order to draw a path and then clip to it.
//   Fixed  16-Mar-1993  -by-  [olegs]
//       if(fPen || fBrush)
//       {
               if(lppd->graphics.PathLevel == 0 && lpClipRect)
               {
                    switch (sStyle)
                    {
                        case OS_ELLIPSE:
                        case OS_CIRCLE :
                        case OS_RECTANGLE:
                        case OS_ROUNDRECT:
                            bClipSent = CClipRect(lppd,lpClipRect,(LPRECT)lppt,0);
                            break;
                        case OS_POLYLINE:
                            if(sCount==2)
                            {
                                bClipSent = CClipRect(lppd,lpClipRect,(LPRECT)lppt,0);
                                break;
                            }
                        default:
                            bClipSent = CClipRect(lppd,lpClipRect,NULL,0);
                    }
               }

               switch(sStyle)
               {
               case OS_ELLIPSE:
               case OS_CIRCLE :
                    if(sCount>=2)
                    {
                    rect  = *(LPRECT)lppt;
                    width = ABS(rect.right - rect.left);
                    height= ABS(rect.top - rect.bottom);
                    if(height!=width)
                         CEllipse(lppd,(LPRECT)lppt,TRUE,TRUE);
                    else
                         CCircle(lppd,(LPRECT)lppt,TRUE,TRUE);
                    }
               break;
     
               case OS_PIE:
                    if(sCount>=5)
                    CPie(lppd,(LPRECT)lppt,TRUE,TRUE,
                              (LPPOINT) &lppt[2], (LPPOINT) &lppt[3]);
               break;
     
               case OS_ARC:
                    if(sCount>=5)
                    CArc(lppd,(LPRECT)lppt,&lppt[2],&lppt[3]);
               break;
     
               case OS_CHORD:
                    if(sCount>=5)
                    CChord(lppd,(LPRECT)lppt,TRUE,TRUE,&lppt[2],&lppt[3]);
               break;
     
               case OS_ROUNDRECT:
                    radius = *(LPPOINT)&lppt[2];
                    if(sCount>=2)
                    {
                    if((radius.x!=0) && (radius.y!=0))
                         CRoundRectangle(lppd,(LPRECT)lppt,TRUE,TRUE,
                               &lppt[2]);
                    else
                         CRectangle(lppd,(LPRECT)lppt,TRUE,TRUE);
                    }
               break;
     
               case OS_RECTANGLE:
                    if(sCount>=2)
                         CRectangle(lppd,(LPRECT)lppt,TRUE,TRUE);
               break;
     
               case OS_MARKER:
               break;

               case OS_POLYBEZIER:

               point_limit = PATH_LIMIT / 4; // curveto takes 4 per point
#ifndef ADOBE_DRIVER_42
                    if( ( ( !lppd->lpPSExtDevmode->dm2.bfUseLevel2 ||
                            (lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS) ) &&
                          (sCount > point_limit) ) ||
                        ( sCount < 2 ) )
                    {
                         sRC = -1 ;  // GDI must simulate it
                         break ;
                    }
#endif
                    CPolyBezier(lppd, lppt,sCount);

               break;
     
               case OS_POLYLINE:

                    // Check for maximum allowable number of points
#ifndef ADOBE_DRIVER_42
                    if( !lppd->lpPSExtDevmode->dm2.bfUseLevel2 ||
                        (lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS) )
                    {
                         if (lppd->graphics.bPolyMode == PM_BEZIER)
                              point_limit = PATH_LIMIT / 4; // curveto takes 4 per point
                         else
                              point_limit = PATH_LIMIT / 2;   // moveto takes 2
                         if( sCount > point_limit )
                         {
                              sRC = -1 ;  // GDI must simulate it
                              break ;
                         }
                    }
#endif
                    if(sCount==2)
                         CLine(lppd,lppt);
                    else if (PtsAreRect(sCount, lppt))
                    {
                         rect.left   = lppt[0].x;
                         rect.top    = lppt[0].y;
                         rect.right  = lppt[2].x;
                         rect.bottom = lppt[2].y;
                         CRectangle(lppd,(LPRECT)&rect, FALSE, TRUE);
                    }else
                         CPolyLine(lppd, lppt,sCount);
                    break;
     
               case OS_ALTPOLYGON:
               case OS_WINDPOLYGON:

                    if(sStyle == OS_ALTPOLYGON )
                         eoFill = ALTERNATE;
                    else
                         eoFill = WINDING;
#ifndef ADOBE_DRIVER
                    if( !lppd->lpPSExtDevmode->dm2.bfUseLevel2 ||
                        (lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS) )
                    {
                         if (lppd->graphics.bPolyMode == PM_BEZIER)
                              point_limit = PATH_LIMIT / 4; // curveto takes 4 per point
                         else
                              point_limit = PATH_LIMIT / 2;   // moveto takes 2
                         if( sCount > point_limit )
                         {
                              sRC = -1 ;  // GDI must simulate it
                              break ;
                         }
                    }
#endif

                    if(sCount==2)
                         CLine(lppd,lppt);
                    else if (PtsAreRect(sCount, lppt))
                    {
                         rect.left   = lppt[0].x;
                         rect.top    = lppt[0].y;
                         rect.right  = lppt[2].x;
                         rect.bottom = lppt[2].y;
                         CRectangle(lppd,(LPRECT)&rect, TRUE, TRUE);
                    }else
                         CPolygon(lppd, lppt, TRUE, TRUE, eoFill,
                                             sCount);
                    break;
     
     
               case OS_POLYMARKER:
               break;
     
               case OS_SCANLINES:
                    CScanLine(lppd,lppt,TRUE,TRUE,sCount);
               break;
     
               case OS_BEGINNSCAN:
                    CScanLineBegin(lppd);
               break;
     
               case OS_ENDNSCAN  :
                    CScanLineEnd(lppd);
               break;

               default:
                    sRC = -1 ; // Do not support - GDI emulate
               }               // End switch(Style)...

               if( (lppd->graphics.PathLevel == 0 ) && lpClipRect && bClipSent)
                    CClipEnd(lppd);       // Remove clipping rectangle.
// Fixed  16-Mar-1993  -by-  [olegs]
//            }                                       // End if(Pen || Brush) ...
          }                                   // End if(...bfDoMSRectHack)
     }
     return(sRC);
}

/* PtsAreRect: Returns TRUE if polygon points contained in lppt form a
 *             rectangle.  sCount is the number of points in lppt[].
 *
 *     [0]----------[1]     lppt[0] and lppt[4] must be the same
 *     [4]           |
 *      |            |
 *     [3]----------[2]
 */
BOOL NEAR PtsAreRect(int sCount, LPPOINT lppt)
{
     BOOL fRC;

     if (sCount != 5) return FALSE;      // Not the right number of points.
     if (lppt == NULL) return FALSE;     // Array must be non-null.

     if ((lppt[0].x != lppt[4].x) || (lppt[0].y != lppt[4].y)) 
     return FALSE;                   // Polyline isn't closed

     /* Pairs of opposite corners define a square.  lppt[0] and lppt[2],
      * and lppt[1] and lppt[3], are opposite corners.  However, they 
      * may describe the rectangle in any of a number of different orders.
      * So, extract the coordinates of each of the four sides, and compare
      * them.
      */
     
     fRC =   ( min(lppt[0].y,lppt[2].y) == min(lppt[1].y,lppt[3].y) )
      && ( min(lppt[0].x,lppt[2].x) == min(lppt[1].x,lppt[3].x) )
      && ( max(lppt[0].y,lppt[2].y) == max(lppt[1].y,lppt[3].y) )
      && ( max(lppt[0].x,lppt[2].x) == max(lppt[1].x,lppt[3].x) )
      // Fixed bug 126090.    1/9/96  JJIA
      // In some special case, even above condation is true the polygon is still
      // not a rectangle. For example: point0 = point1 and point2 = point3
      && !((lppt[0].x == lppt[1].x) && (lppt[0].y == lppt[1].y))
      && !((lppt[0].x == lppt[3].x) && (lppt[0].y == lppt[3].y));

     return fRC;
}
