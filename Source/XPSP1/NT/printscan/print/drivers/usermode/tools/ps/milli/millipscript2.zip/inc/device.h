/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: DEVICE.H                                               */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHDeviceDlg(HWND hdlg, unsigned msg, WORD wParam, 
                                    LONG lParam);
void FAR PASCAL RestoreDeviceDefaults(LPPSEXTDEVMODE lpPSExtDevmode,
                                      LPWPXBLOCKS lpWPXBlock,
                                      DWORD dwUIFlags);

