/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TTDIALOG.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for the TrueType          */
/*              Font Substitutions dialog                                    */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_FONTSDIALOGSEG)

int WINAPI EnumFontFamiliesEx(HDC, LPLOGFONT, FONTENUMPROC, LPARAM,DWORD);


/*****************************************************************************/
/*                 CheckPostscriptDlg                                        */
/* Purpose:                                                                  */
/*   Returns index if found, otherwise returns -1                            */
/*   Works for both TT and PS fonts. Use binary search for speed.            */
/*                                                                           */
/* Parameters:                                                               */
/*   HGLOBAL hFamilies -- Handle to memory containing families stack         */
/*   int iNumFamilies -- Number of font families in stack                    */
/*   LPSTR lpTarget -- Target family name                                    */
/*                                                                           */
/* Returns: int                                                              */
/*   Index of family or -1 if not found                                      */
/*****************************************************************************/

int NEAR PASCAL
FindFontFamily(HGLOBAL hFamilies, int iNumFamilies, LPSTR lpTarget)
{
  LPSTR lpFamilyName, lpStackStart;
  int retVal, iHigh, iLow, iTrial;
  BOOL done;
  int cmpResult;

  /* No Families */
  if (iNumFamilies == 0)
    return (-1); /* Not found */

  lpStackStart = (LPSTR)GlobalLock(hFamilies);

  /* One Family */
  if (iNumFamilies == 1)
    {
    if (lstrcmp(lpStackStart, lpTarget) == 0)
      retVal = 0;
    else
      retVal = -1;
    }
  else
    { /* 2 or more families already in existance */
    retVal = -1;
    done = FALSE;

    /* Check to see if equal to the beginning */
    cmpResult = lstrcmp(lpStackStart, lpTarget);
    if (cmpResult == 0)
      {
      retVal = 0;
      done = TRUE;
      }
    else
      if (cmpResult > 0)
        done = TRUE;

    /* Check to see if at the end */
    lpFamilyName = (LPSTR)(lpStackStart + (iNumFamilies - 1)*FAMILY_NAME_SIZE);
    cmpResult = lstrcmp(lpFamilyName, lpTarget);
    if (cmpResult == 0)
      {
      retVal = iNumFamilies - 1;
      done = TRUE;
      }
    else
      if (cmpResult < 0)
        done = TRUE;

    /* We now know it is between and not equal to the limits if !done */
    iLow = 0;
    iHigh = iNumFamilies - 1;
    iTrial = (iHigh + iLow)/ 2;

    while (!done)
      { /* Do the binary search */
      lpFamilyName = (LPSTR)(lpStackStart + iTrial*FAMILY_NAME_SIZE);
      cmpResult = lstrcmp(lpFamilyName, lpTarget);
      if (cmpResult == 0)
        {
        retVal = iTrial; /* Found */
        done = TRUE;
        }
      else
        if (cmpResult < 0)
          iLow = iTrial;
        else
          iHigh = iTrial;

      iTrial = (iHigh + iLow)/ 2;
      if (iTrial == iLow)
        done = TRUE; /* Not found */
      }
    }
  GlobalUnlock(hFamilies);

  /* answer is between the high and low so insertion point is set to
     high and old high gets pushed along */
  return (retVal);
}

/*****************************************************************************/
/*                 SetDefaultAssignments                                     */
/* Purpose:                                                                  */
/*   sets the TT to PS assignments to the default. If it is in the "special" */
/*   set of default families it gets their special defaults otherwise it     */
/*   gets set to "Send As"                                                   */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- window handle for dialog, used to get devmode structures   */
/*   HANDLE ghDriverMod -- Driver module handle                              */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL
SetDefaultAssignments(HWND hDlg, HANDLE ghDriverMod)
{
   LPDRIVERINFO   lpDrvInfo;
   LPPSEXTDEVMODE lpPSExtDevmode;
   int            nNumDefSubsFont;
   HGLOBAL        hgblRcData;
   LPBYTE         lpbyRcData;
   int            iTTIndex;
   int            iPSIndex;
   LPSTR       lpszTT;
   LPSTR       lpszPS;
   int            i;

   lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg, DWL_USER);
   lpPSExtDevmode = lpDrvInfo->lpDM;

   // set all to "Send As" for default

   for (iTTIndex = 0;
         iTTIndex < lpPSExtDevmode->dm2.iNumTTFamilies;
            iTTIndex++)
   {
      SetAssignment(hDlg, iTTIndex, 0);
   }

   // Get the number of the default substitution fonts and load
   // them into memory.

   nNumDefSubsFont = GetNumDefSubsFont();

   lpbyRcData = LoadFontResource(ID_FNT_DEF_SUBS_FONT, &hgblRcData);

   if (nNumDefSubsFont < 0 || lpbyRcData == NULL)
   {
      // Error occurred while reading ID_FNT_DEF_SUBS_FONT resource,
      // but no way to let the caller know it. Hope it never happens.

      return;
   }

   nNumDefSubsFont /= 2;

   // Substitute a TT font to a PS font if necessary

   for (i = 0; i < nNumDefSubsFont; i++)
   {
      lpszTT = (LPSTR)lpbyRcData;
      lpbyRcData += lstrlen(lpszTT) + 1;

      lpszPS = (LPSTR)lpbyRcData;
      lpbyRcData += lstrlen(lpszPS) + 1;

      // See if we have this TT

      iTTIndex = FindFontFamily(lpPSExtDevmode->dm2.hTTFamilies,
                                    lpPSExtDevmode->dm2.iNumTTFamilies,
                                    lpszTT);

      if (iTTIndex >= 0)
      {
          // The TT font name was found. Find its substitution.

        iPSIndex = FindFontFamily(lpPSExtDevmode->dm2.hPSFamilies,
                                    lpPSExtDevmode->dm2.iNumPSFamilies,
                                    lpszPS);

            if (iPSIndex < 0)
         {
            // Set it to "Send As".
            iPSIndex = 0;
         }

            SetAssignment(hDlg, iTTIndex, iPSIndex);
      }
   }

   UnloadFontResource(hgblRcData);
}

/*****************************************************************************/
/*                 FindInsertionPoint                                        */
/* Purpose:                                                                  */
/*   Finds insertion point using binary search. Works for both PS and        */
/*   TT. Returns new index for target. Assumes it Target doesn't exist       */
/*   already for speed. iNumFamiles is num BEFORE the insertion.             */
/*                                                                           */
/* Parameters:                                                               */
/*   LPSTR lpStackStart -- Pointer to the start of font family stack         */
/*   int iNumFamilies -- Number of font families in stack                    */
/*   LPSTR lpTarget -- Target font family string                             */
/*                                                                           */
/* Returns: int                                                              */
/*   insertion point index                                                   */
/*****************************************************************************/

static int NEAR
FindInsertionPoint(LPSTR lpStackStart, int iNumFamilies, LPSTR lpTarget)
{
  int iLow, iHigh, iTrial;
  LPSTR lpFamilyName;

  /* No Families */
  if (iNumFamilies == 0)
    return (0); /* insert at beginning */

  /* One Family */
  if (iNumFamilies == 1)
    {
    if (lstrcmp(lpStackStart, lpTarget) < 0)
      return (1);
    else
      return (0);
    }

  /* 2 or more families already in existance */

  /* Check to see if insert in the beginning */
  if (lstrcmp(lpStackStart, lpTarget) > 0)
    return (0);

  /* Check to see if insert at the end */
  lpFamilyName = (LPSTR)(lpStackStart + (iNumFamilies - 1)*FAMILY_NAME_SIZE);
  if (lstrcmp(lpFamilyName, lpTarget) < 0)
    return (iNumFamilies);

  /* We now know it is between and not equal to the limits */
  iLow = 0;
  iHigh = iNumFamilies - 1;
  iTrial = (iHigh + iLow)/ 2;

  while (iTrial != iLow)
    {
    lpFamilyName = (LPSTR)(lpStackStart + iTrial*FAMILY_NAME_SIZE);
    if (lstrcmp(lpFamilyName, lpTarget) < 0)
      iLow = iTrial;
    else
      iHigh = iTrial;
    iTrial = (iHigh + iLow)/ 2;
    }

  /* answer is between the high and low so insertion point is set to
     high and old high gets pushed along */
  return (iHigh);
}

/*****************************************************************************/
/*                 MakeRoomForFamily                                         */
/* Purpose:                                                                  */
/*   Makes room for a font family at the given insertion point. Moves all    */
/*   following families down the line to ensure that the font family stack   */
/*   is still in order.                                                      */
/*                                                                           */
/* Parameters:                                                               */
/*   LPSTR lpStackStart -- Pointer to the start of font family stack         */
/*   int iNumFamilies -- Number of font families in stack                    */
/*   int iInsertionPoint -- Index of point where we want to insert           */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

static void NEAR
MakeRoomForFamily(LPSTR lpStackStart, int iNumFamilies, int iInsertionPoint)
{
  int i;
  LPSTR lpSource, lpDestination;

  if (iInsertionPoint == iNumFamilies)
    return; /* Do nothing */

  for (i=iNumFamilies-1; i >= iInsertionPoint; i--)
  {
    lpSource = (LPSTR)(lpStackStart + i*FAMILY_NAME_SIZE);
    lpDestination = (LPSTR)(lpSource + FAMILY_NAME_SIZE);
    lstrcpy(lpDestination, lpSource);
  }
}

/*****************************************************************************/
/*                 AddPSFamily                                               */
/* Purpose:                                                                  */
/*   Add PostScript family to the postscript font stack                      */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- dialog handle. used to obtain devmode structures           */
/*   LPSTR lpPSFamily -- PostScript family to be added                       */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL
AddPSFamily(HWND hDlg, LPSTR lpPSFamily)
{
  LONG              lNumBytes;
  LPSTR             lpFamilyName, lpStackStart;
  int               iInsertionPoint;
  LPPSEXTDEVMODE    lpPSExtDevmode;
  LPDRIVERINFO      lpDrvInfo;

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg, DWL_USER);
  lpPSExtDevmode = lpDrvInfo->lpDM;

  if (FindFontFamily(lpPSExtDevmode->dm2.hPSFamilies,
                     lpPSExtDevmode->dm2.iNumPSFamilies, lpPSFamily) != -1)
    return;

  lNumBytes = (lpPSExtDevmode->dm2.iNumPSFamilies + 1) * FAMILY_NAME_SIZE;

  lpPSExtDevmode->dm2.hPSFamilies = GlobalReAlloc(
                                        lpPSExtDevmode->dm2.hPSFamilies,
                                        lNumBytes, GHND|GMEM_DDESHARE);

  lpStackStart = (LPSTR)GlobalLock(lpPSExtDevmode->dm2.hPSFamilies);

  iInsertionPoint = FindInsertionPoint(lpStackStart,
                                       lpPSExtDevmode->dm2.iNumPSFamilies,
                                       lpPSFamily);

  /* Make room for the family */
  MakeRoomForFamily(lpStackStart, lpPSExtDevmode->dm2.iNumPSFamilies,
                                  iInsertionPoint);

  /* Insert the family */
  lpFamilyName = (LPSTR)(lpStackStart + iInsertionPoint*FAMILY_NAME_SIZE);
  lstrcpy(lpFamilyName, lpPSFamily);

  GlobalUnlock(lpPSExtDevmode->dm2.hPSFamilies);
  lpPSExtDevmode->dm2.iNumPSFamilies++;
}


void NEAR PASCAL
ReplacePSFamily(HWND  hDlg, LPSTR lpPSOldFamily, LPSTR lpPSNewFamily)
{
  int               i;
  LPPSEXTDEVMODE    lpPSExtDevmode;
  LPDRIVERINFO      lpDrvInfo;

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg, DWL_USER);
  lpPSExtDevmode = lpDrvInfo->lpDM;

  i = FindFontFamily(lpPSExtDevmode->dm2.hPSFamilies,
                     lpPSExtDevmode->dm2.iNumPSFamilies,
                     lpPSOldFamily);

  if(i==-1)
      AddPSFamily(hDlg, lpPSNewFamily);
  else
  {
      LPSTR lpStackStart;
      LPSTR lpFamilyName;

      lpStackStart = (LPSTR)GlobalLock(lpPSExtDevmode->dm2.hPSFamilies);

      lpFamilyName = (LPSTR)(lpStackStart + i*FAMILY_NAME_SIZE);
      lstrcpy(lpFamilyName, lpPSNewFamily);

      GlobalUnlock(lpPSExtDevmode->dm2.hPSFamilies);
  }
}

/*****************************************************************************/
/*                 AddTTFamily                                               */
/* Purpose:                                                                  */
/*   Add TrueType family to the TrueType font stack                          */
/*                                                                           */
/* Parameters:                                                               */
/*   LPSTR lpTTFamily -- TrueType family to be added                         */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL
AddTTFamily(HWND hDlg, LPSTR lpTTFamily)
{
  LONG              lNumBytes, lNumAssignmentBytes;
  LPSTR             lpFamilyName, lpStackStart;
  LPINT             lpAssignmentStackStart, lpAssignment;
  int               iInsertionPoint;
  LPPSEXTDEVMODE    lpPSExtDevmode;
  LPDRIVERINFO      lpDrvInfo;

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg, DWL_USER);
  lpPSExtDevmode = lpDrvInfo->lpDM;

                                    /****************************************/
                                    /* does the family allready exist?      */
                                    /****************************************/

  if (FindFontFamily(lpPSExtDevmode->dm2.hTTFamilies,
                     lpPSExtDevmode->dm2.iNumTTFamilies,
                     lpTTFamily) != -1)
    return;

                                    /****************************************/
                                    /* insert alphabeticly in our font list */
                                    /****************************************/

  lNumBytes = (lpPSExtDevmode->dm2.iNumTTFamilies + 1) * FAMILY_NAME_SIZE;
  lpPSExtDevmode->dm2.hTTFamilies = GlobalReAlloc(
                                        lpPSExtDevmode->dm2.hTTFamilies,
                                        lNumBytes, GHND|GMEM_DDESHARE);

  lpStackStart = (LPSTR)GlobalLock(lpPSExtDevmode->dm2.hTTFamilies);
  iInsertionPoint = FindInsertionPoint(lpStackStart,
                                       lpPSExtDevmode->dm2.iNumTTFamilies,
                                       lpTTFamily);

  MakeRoomForFamily(lpStackStart,
                    lpPSExtDevmode->dm2.iNumTTFamilies,
                    iInsertionPoint);

  lpFamilyName = (LPSTR)(lpStackStart + iInsertionPoint*FAMILY_NAME_SIZE);
  lstrcpy(lpFamilyName, lpTTFamily);

  GlobalUnlock(lpPSExtDevmode->dm2.hTTFamilies);
  lpPSExtDevmode->dm2.iNumTTFamilies++;

                                    /****************************************/
                                    /* Add a new TT Assignment vector member*/
                                    /****************************************/

  lNumAssignmentBytes = lpPSExtDevmode->dm2.iNumTTFamilies * sizeof(int);
  lpPSExtDevmode->dm2.hTTAssignment = GlobalReAlloc(
                                            lpPSExtDevmode->dm2.hTTAssignment,
                                            lNumAssignmentBytes,
                                            GHND|GMEM_DDESHARE);
  lpAssignmentStackStart = (LPINT)GlobalLock(lpPSExtDevmode->dm2.hTTAssignment);
  lpAssignment =    lpAssignmentStackStart
                  + (lpPSExtDevmode->dm2.iNumTTFamilies - 1);
  *lpAssignment = 0; /* The default assignment */
  GlobalUnlock(lpPSExtDevmode->dm2.hTTAssignment);
}

/*****************************************************************************/
/*                 EnumPSFamCallBack                                         */
/* Purpose:                                                                  */
/*   Callback function to allow us to build the PostScript family font       */
/*   stack by enumerating the PostScript fonts.                              */
/*                                                                           */
/* Parameters:                                                               */
/*   LPENUMLOGFONT lpLogFont  -- Pointer to Enum version of the LogFont      */
/*   LPNEWTEXTMETRIC lpTextMetric -- Pointer to the text metric              */
/*   int iFontType -- Font type                                              */
/*   LPARAM lParam -- LOWORD(lParam) holds dialog box handle                 */
/*                                                                           */
/* Returns: int                                                              */
/*   1 to continue enumeration                                               */
/*****************************************************************************/

int _loadds CALLBACK
EnumPSFamCallBack(LPENUMLOGFONT lpLogFont, LPNEWTEXTMETRIC lpTextMetric,
                  int iFontType, LPARAM lParam)
{
  // Supress Vertical Fonts: based on Name only - some OLD Pfm's have bad charset
  if (lpLogFont->elfLogFont.lfFaceName[0]=='@') return (1);

  if (iFontType == DEVICE_FONTTYPE)              /* for all postscript fonts */
    AddPSFamily((HWND)LOWORD(lParam), lpLogFont->elfLogFont.lfFaceName);

  return(1);
}

/*****************************************************************************/
/*                 EnumTTFamCallBack                                         */
/* Purpose:                                                                  */
/*   Callback function to allow us to build the TrueType family font         */
/*   stack by enumerating the TrueType fonts.                                */
/*                                                                           */
/* Parameters:                                                               */
/*   LPENUMLOGFONT lpLogFont  -- Pointer to Enum version of the LogFont      */
/*   LPNEWTEXTMETRIC lpTextMetric -- Pointer to the text metric              */
/*   int iFontType -- Font type                                              */
/*   LPARAM lParam -- LOWORD(lParam) holds dialog box handle                 */
/*                                                                           */
/* Returns: int                                                              */
/*   1 to continue enumeration                                               */
/*****************************************************************************/

int _loadds CALLBACK
EnumTTFamCallBack(LPENUMLOGFONT lpLogFont, LPNEWTEXTMETRIC lpTextMetric,
                  int iFontType, LPARAM lParam)
{
  // Supress Vertical Fonts: based on Name only - some OLD Pfm's have bad charset
  if (lpLogFont->elfLogFont.lfFaceName[0]=='@') return (1);

  if ((iFontType & TRUETYPE_FONTTYPE) != 0)         /* for any truetype font */
    AddTTFamily((HWND)LOWORD(lParam), lpLogFont->elfLogFont.lfFaceName);

  return(1);
}

/*****************************************************************************/
/*                 GetAllFamilies                                            */
/* Purpose:                                                                  */
/*   Gets all PS Family names and fills the data array                       */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- handle to dialog. obtain devmode structure from here       */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL
GetAllFamilies(HWND hDlg, WORD enumFlag)
{
  HDC            hScreenDC;
  LOGFONT        lf;
  HCURSOR        hCursor;
  LPPSEXTDEVMODE lpPSExtDevmode;
  LPDRIVERINFO   lpDrvInfo;

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER);
  lpPSExtDevmode = lpDrvInfo->lpDM;

  hCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));

                                    /* Get the device (PostScript) families */
#if 1                               /* EnumDFonts is quicker than CreateIC  */
                                    /* FIXME: multiligual postscript fonts? */

  EnumDFonts((LP)&lpDrvInfo->pDev, NULL, EnumPSFamCallBack,
             (LP)MAKELONG(hDlg, enumFlag));

#else                               /* the  s l o w  way....                */
  HDC hPrinterDC;
  char szDriver[_MAX_FNAME], szFilename[256];

                                    /* get name of this dll                 */
  GetModuleFileName(ghDriverMod, szFilename, sizeof(szFilename));
  _splitpath(szFilename, NULL, NULL, szDriver, NULL);

  hPrinterDC = CreateDC(szDriver, lpPSExtDevmode->dm.dm.dmDeviceName,
                        lppd->szPortName, NULL);
  if (hPrinterDC != NULL)
  {
    memset((char *)&lf, 0, sizeof(lf));
    lf.lfCharSet = DEFAULT_CHARSET;
    lf.lfPitchAndFamily = 0;        /* FIXME: hebrew and arabic - MONO FONT?*/

    EnumFontFamiliesEx(hPrinterDC, &lf, (FONTENUMPROC)EnumPSFamCallBack,
                     MAKELONG(hDlg, 0), 0L);
    DeleteDC(hPrinterDC);
  }
#endif

  /* Get the TrueType Families */
  hScreenDC = GetDC(NULL);
  if (hScreenDC != NULL)
  {
    memset((char *)&lf, 0, sizeof(lf));
    lf.lfCharSet = DEFAULT_CHARSET;
    lf.lfPitchAndFamily = 0;        /* FIXME: hebrew and arabic - MONO FONT?*/

    EnumFontFamiliesEx(hScreenDC, &lf, (FONTENUMPROC)EnumTTFamCallBack,
                       MAKELONG(hDlg, 0), 0l);
    ReleaseDC(NULL, hScreenDC);
  }
  SetCursor(hCursor);
}

/*****************************************************************************/
/*                 GetSendAsString                                           */
/* Purpose:                                                                  */
/*   Gets the appropriate "Send As" string prefix for the current situation  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to dialog containing the "Send As" choice box       */
/*   LPSTR lpSendAsBuffer -- Buffer to store the "Send As" string            */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

static void NEAR
GetSendAsString(HANDLE ghDriverMod, HWND hDlg, LPSTR lpSendAsBuffer)
{

  char strBuff[SHORT_BUFF_LEN], strBuff2[SHORT_BUFF_LEN];
  int curSel;

  curSel = (int)SendDlgItemMessage(hDlg, ID_SEND_AS, CB_GETCURSEL, 0, 0L);
  SendDlgItemMessage(hDlg, ID_SEND_AS, CB_GETLBTEXT, curSel, (LPARAM)(LPSTR)strBuff);
  LoadString(ghDriverMod, IDS_DONT_SEND, strBuff2, SHORT_BUFF_LEN);

  if (lstrcmp(strBuff, strBuff2) == 0)      /* It's the Don't Send Case */
    LoadString(ghDriverMod, IDS_DONT_SEND_PREFIX, lpSendAsBuffer, STR_BUFF_LEN);
  else                                      /* All other cases */
    LoadString(ghDriverMod, IDS_SEND_AS_PREFIX, lpSendAsBuffer, STR_BUFF_LEN);

  lstrcat(lpSendAsBuffer, strBuff);
}

/*****************************************************************************/
/*                 SetAssignment                                             */
/* Purpose:                                                                  */
/*   Sets a given TT family as mapped to a given PS family. Uses the family  */
/*   indicies of the two with respect to each's own font family stack        */
/*                                                                           */
/* Parameters:                                                               */
/*   int iTTFamily -- index to TrueType family                               */
/*   int iPSTarget -- index to PostScript target to map TT family to         */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL
SetAssignment(HWND hDlg, int iTTFamily, int iPSTarget)
{
  LPINT          lpAssignmentStackStart, lpAssignment;
  LPPSEXTDEVMODE lpPSExtDevmode;
  LPDRIVERINFO   lpDrvInfo;

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER);
  lpPSExtDevmode = lpDrvInfo->lpDM;

  lpAssignmentStackStart = (LPINT)GlobalLock(lpPSExtDevmode->dm2.hTTAssignment);
  lpAssignment = lpAssignmentStackStart + iTTFamily;
  *lpAssignment = iPSTarget;
  GlobalUnlock(lpPSExtDevmode->dm2.hTTAssignment);
}

/*****************************************************************************/
/* EnumLFCharSetsCallBack                                                    */
/*                                                                           */
/* Purpose                                                                   */
/*   gets one member of a family's lfCharSet and puts it into the bit array. */
/*                                                                           */
/* Parameters:                                                               */
/*   as defined by the EnumFontFamilyEx function.                            */
/*                                                                           */
/* Returns: allways 1.                                                       */
/*****************************************************************************/

int _loadds CALLBACK
EnumLFCharSetsCallBack(LPENUMLOGFONT lpLogFont, LPNEWTEXTMETRIC lpTextMetric,
                       int iFontType, BYTE *pbArray)
{
  BYTE  lfCharSet, offset, bit;

  lfCharSet = lpLogFont->elfLogFont.lfCharSet;
  offset    = lfCharSet / 8;
  bit       = lfCharSet % 8;

  pbArray[offset] |= (1 << bit);                /* which bit is to be set   */

  return(1);                                    /* continue the enumeration */
}

/*****************************************************************************/
/* GetLFCharSets                                                             */
/*                                                                           */
/* Purpose:                                                                  */
/*    builds a bit array for all charsets for this font                      */
/*                                                                           */
/* Parameters:                                                               */
/*   HDC hDC -- DC to enumerate the fonts on                                 */
/*   LPSTR lpFamily -- the font family name                                  */
/*   BYTE *pb -- pointer to the bit array, 32 bytes in length                */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

static void NEAR
GetLFCharSets(HDC hDC, LPSTR lpFamily, BYTE *pb)
{
    LOGFONT lf;

    memset((char *)&lf, 0, sizeof(lf));
    lf.lfCharSet = DEFAULT_CHARSET;
    lf.lfPitchAndFamily = 0;         /* FIXME: hebrew and arabic - MONO FONT */
    lstrcpy(lf.lfFaceName, lpFamily);

    EnumFontFamiliesEx(hDC, &lf, (FONTENUMPROC)EnumLFCharSetsCallBack,
                                 (LPARAM)(LPSTR)pb, 0l);
}

/*****************************************************************************/
/*                  CheckAssignement                                         */
/*                                                                           */
/* Purpose:                                                                  */
/*   Returns TRUE on valid assignment (intersecting charsets) between the    */
/*   postscript and the truetype fonts on this HDC.                          */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg      -- window handle, provides access to devmode structs     */
/*   int iTTFamily  -- index to TrueType font                                */
/*   int iPSFamily  -- index to postscrit font                               */
/*   LPSTR lpTTName -- buffer to hold the truetype name. value returned here */
/*   LPSTR lpPSName -- buffer to hold the postscript name. value ret here    */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE:  intersection found                                               */
/*   FALSE: no intersection - fonts are not compatable.                      */
/*                                                                           */
/*****************************************************************************/

BOOL NEAR PASCAL
CheckAssignment(HWND hDlg, int iTTFamily, int iPSTarget,
                           LPSTR lpTTName, LPSTR lpPSName)
{
  LPDRIVERINFO      lpDrvInfo;
  LPPSEXTDEVMODE    lpPSExtDevmode;
  BYTE              *pt, *pp, bCSTT[256/8], bCSPS[256/8];
  LPSTR             lpStackStartTT, lpStackStartPS;
  int               i;
  BOOL              ret = FALSE;

  if (iPSTarget == 0)                   /* idx of zero is the "Send As..."  */
    return(TRUE);                       /* string which is allways avaiable */

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER);
  lpPSExtDevmode = lpDrvInfo->lpDM;

  lpStackStartPS = (LPSTR)GlobalLock(lpPSExtDevmode->dm2.hPSFamilies);
  lstrcpy(lpPSName, (LPSTR)(lpStackStartPS + iPSTarget*FAMILY_NAME_SIZE));
  GlobalLock(lpPSExtDevmode->dm2.hPSFamilies);

  lpStackStartTT = (LPSTR)GlobalLock(lpPSExtDevmode->dm2.hTTFamilies);
  lstrcpy(lpTTName, (LPSTR)(lpStackStartTT + iTTFamily*FAMILY_NAME_SIZE));
  GlobalLock(lpPSExtDevmode->dm2.hTTFamilies);

  memset((char *)bCSTT, 0, sizeof(bCSTT));
  memset((char *)bCSPS, 0, sizeof(bCSPS));

  GetLFCharSets(lpPSExtDevmode->dm2.hDCPrinter, lpTTName, bCSTT);
  GetLFCharSets(lpPSExtDevmode->dm2.hDCPrinter, lpPSName, bCSPS);

  for (pt = bCSTT, pp = bCSPS, i = 0; i < sizeof(bCSTT); i++, pt++, pp++) {
    if (*pt & *pp) {
        ret = TRUE;                             /* intersection found       */
        break;
    }
  }

  return(ret);
}

/*****************************************************************************/
/*                 GetAssignment                                             */
/* Purpose:                                                                  */
/*   Gets the corresponding PS family that a given TT family was mapped to.  */
/*   Uses indicies of the corresponding font stack.                          */
/*                                                                           */
/* Parameters:                                                               */
/*   int iTTFamily -- Index of the TT family we want to know about           */
/*                                                                           */
/* Returns: int                                                              */
/*   Index of the PS family that the TT family was mapped to.                */
/*****************************************************************************/

static int NEAR
GetAssignment(HWND hDlg, int iTTFamily)
{
  LPDRIVERINFO   lpDrvInfo;
  LPPSEXTDEVMODE lpPSExtDevmode;
  LPINT          lpAssignmentStackStart, lpAssignment;
  int            retVal;

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER);
  lpPSExtDevmode = lpDrvInfo->lpDM;

  lpAssignmentStackStart = (LPINT)GlobalLock(lpPSExtDevmode->dm2.hTTAssignment);
  lpAssignment = lpAssignmentStackStart + iTTFamily;
  retVal       = *lpAssignment;
  GlobalUnlock(lpPSExtDevmode->dm2.hTTAssignment);

  return (retVal);
}

/*****************************************************************************/
/*                 ReadAssignmentFromIni                                     */
/* Purpose:                                                                  */
/*   Reads assignment vector from Win.ini and sets appropriate ones in       */
/*   assignment vector based on TT family list.                              */
/*                                                                           */
/* Parameters:                                                               */
/*   HANDLE ghDriverMod -- Driver module handle                              */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL
ReadAssignmentFromIni(HWND hDlg, HANDLE ghDriverMod)
{
  HGLOBAL           hIniCache;
  char              section[SHORT_BUFF_LEN], entry[FAMILY_NAME_SIZE];
  char              PSFamily[FAMILY_NAME_SIZE];
  LPSTR             lpIniCache, lpNextEntry;
  int               iniCacheOffset;
  LPDRIVERINFO      lpDrvInfo;
  LPPSEXTDEVMODE    lpPSExtDevmode;

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg, DWL_USER);
  lpPSExtDevmode = lpDrvInfo->lpDM;


    /*
     * First set default assignments from resource table, and then
     * overwrite win.ini settings.
     */
  SetDefaultAssignments(hDlg, ghDriverMod);

  LoadString(ghDriverMod, IDS_INI_SUBS_TITLE, section, SHORT_BUFF_LEN);

  hIniCache       = GlobalAlloc(GHND|GMEM_DDESHARE, INI_CACHE_SIZE);
  lpIniCache      = (LPSTR)GlobalLock(hIniCache);
  iniCacheOffset  = 0;
  lpNextEntry     = lpIniCache;

  GetProfileString(section, NULL, "", lpIniCache, INI_CACHE_SIZE);

  if (*lpIniCache != '\0')      /* Got some data, otherwise do nothing       */
  {                             /* The Cache has all entrys titles right now */
    do                          /* Go through all the present substitutions  */
    {
      lstrcpy(entry, lpNextEntry);
      GetProfileString(section, entry, "", PSFamily, FAMILY_NAME_SIZE);

      if (lstrlen(PSFamily) > 0)            /* An assignment exists */
      {
        int iTTIndex, iPSIndex;

        iTTIndex = FindFontFamily(lpPSExtDevmode->dm2.hTTFamilies,
                                  lpPSExtDevmode->dm2.iNumTTFamilies,
                                  entry);

        if (lstrcmp(PSFamily, "0") != 0)        /* Substituted by PS font  */
            iPSIndex = FindFontFamily(lpPSExtDevmode->dm2.hPSFamilies,
                                      lpPSExtDevmode->dm2.iNumPSFamilies,
                                      PSFamily);
        else                                    /* it's a Send As...       */
            iPSIndex = 0;

        if (iTTIndex != -1 && iPSIndex != -1)
            SetAssignment(hDlg, iTTIndex, iPSIndex);
      }

      iniCacheOffset = iniCacheOffset + 1 + lstrlen(entry);
      lpNextEntry = lpIniCache + iniCacheOffset;
    } while (*lpNextEntry != '\0');
  }
  GlobalUnlock(hIniCache);
  GlobalFree(hIniCache);
}


/*****************************************************************************/
/*                 TTExistCallBack                                           */
/* Purpose:                                                                  */
/*   Callback function to allow us to check if a particular TT font exist    */
/*   by enumerating the TrueType fonts.                                      */
/*                                                                           */
/* Parameters:                                                               */
/*   LPENUMLOGFONT lpLogFont  -- Pointer to Enum version of the LogFont      */
/*   LPNEWTEXTMETRIC lpTextMetric -- Pointer to the text metric              */
/*   int iFontType -- Font type                                              */
/*   LPARAM lParam -- LOWORD(lParam) holds dialog box handle                 */
/*                                                                           */
/* Returns: int                                                              */
/*   0 to stop enumeration after find one                                    */
/*   1 to continue enumeration                                               */
/*****************************************************************************/
int _loadds CALLBACK TTExistCallBack(LPENUMLOGFONT lpLogFont, 
        LPNEWTEXTMETRIC lpTextMetric, int iFontType, LPARAM lParam)
{
  LPINT  lpRet = (LPINT)lParam;
  if ((iFontType & TRUETYPE_FONTTYPE) != 0){         /* for any truetype font */
     *lpRet = 1; // set the value back to caller
     return 0;   // return 0 to stop enum after found one.
     }
  return(1);
}

/*****************************************************************************/
/*                 TTFontExist                                               */
/* Purpose:                                                                  */
/*   Check if passed-in lpFacename is a TrueType font by doing               */ 
/*   a simple enumFanoFamilies() call                                        */
/* Parameters:                                                               */
/*   LPSTR  lpFaceName -- a string - lfFaceName in Windows                   */
/* Returns: 1: if it is TT font, 0-not                                       */
/*****************************************************************************/
int NEAR PASCAL TTFontExist(LPSTR lpFaceName)
{
  HDC        hScreenDC;
  int        ret=0;   
  hScreenDC = GetDC(NULL);   // ScreenDC Has all TrueType Fonts!
  if (hScreenDC != NULL)
  {
    EnumFontFamilies(hScreenDC, lpFaceName, (FONTENUMPROC)TTExistCallBack, (DWORD)(LPINT)&ret);
    ReleaseDC(NULL, hScreenDC);
  }
  return ret;
}


/*****************************************************************************/
/*                 WriteAssignmentToIni                                      */
/* Purpose:                                                                  */
/*   Writes Assignment vector to INI file.                                   */
/*                                                                           */
/* Parameters:                                                               */
/*   HANDLE ghDriverMod -- Driver module handle                              */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL
WriteAssignmentToIni(HWND hDlg, HANDLE ghDriverMod)
{
   char        szSection[SHORT_BUFF_LEN];
   LPDRIVERINFO   lpDrvInfo;
   LPPSEXTDEVMODE lpPSExtDevmode;
   LPSTR       lpPSStack;
   LPSTR       lpTTStack;
   LPSTR       lpszPS;
   LPSTR       lpszTT;
   int            nPSIndex;
   int            nTTIndex;
   int            nNumDefSubsFont;
   HGLOBAL        hgblRcData;
   LPBYTE         lpbyRcData;
   int            i;
    // buffers used to write out the Vertical Substitution for CJK font, fix bug142334
    LPSTR    lpBuf1=NULL, lpBuf2=NULL;
    lpBuf1 = GlobalAllocPtr(GHND|GMEM_DDESHARE, 1024);  // 1K buffer
    if (lpBuf1) lpBuf2 = lpBuf1+512;  // each buf is 511 byte long.

   lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER);
   lpPSExtDevmode = lpDrvInfo->lpDM;

   LoadString(ghDriverMod, IDS_INI_SUBS_TITLE, szSection, sizeof szSection);

   lpPSStack = (LPSTR)GlobalLock(lpPSExtDevmode->dm2.hPSFamilies);
   lpTTStack = (LPSTR)GlobalLock(lpPSExtDevmode->dm2.hTTFamilies);

   // First go through all TT fonts, and write out all substituted fonts.

   for (i = 0; i < lpPSExtDevmode->dm2.iNumTTFamilies; i++)
   {
      lpszTT = (LPSTR)(lpTTStack + i * FAMILY_NAME_SIZE);
      nPSIndex  = GetAssignment(hDlg, i);

      if (nPSIndex == 0)
      {
         // a "Send as..." type
            lpszPS = NULL;
      }
      else
      {
            lpszPS = (LPSTR)(lpPSStack + nPSIndex * FAMILY_NAME_SIZE);
      }

      WriteProfileString(szSection, lpszTT, lpszPS);

        // Also write out the Vertical Substitution for CJK font, fix bug142334
        // First check if "@TTBrother" is a TT font or not, if it is a real
        // Vertical TT font, then add new pair to the win.ini: 
        // @TTBrother=@PSBrother or delete @TTBrother from win.ini if lpszPS is NULL.
        if (lpBuf1 && lpBuf2){ 
           // Construct the Vertical brothers
           lpBuf1[0]='@'; 
           lstrcpy((lpBuf1+1), lpszTT);
           if (TTFontExist(lpBuf1)){
              if (lpszPS!=NULL){
                 lpBuf2[0]='@'; 
                 lstrcpy((lpBuf2+1), lpszPS);
                 WriteProfileString(szSection, lpBuf1, lpBuf2); // Add the V-entry
                 }
              else{
                 // DOn't change lpBuf2 , but use NULL directly
                 WriteProfileString(szSection, lpBuf1, NULL);  // Delete the V-entry
                 }
              }
        }

   }

   // Next go through all fonts in the resource table (ie fonts that
   // have default substitutions), and write out all fonts that are
   // now "Send As".

   nNumDefSubsFont = GetNumDefSubsFont();

   lpbyRcData = LoadFontResource(ID_FNT_DEF_SUBS_FONT, &hgblRcData);

   if (nNumDefSubsFont < 0 || lpbyRcData == NULL)
   {
      // Error occurred while reading ID_FNT_DEF_SUBS_FONT resource,
      // but no way to let the caller know it. Hope it never happens.

      GlobalUnlock(lpPSExtDevmode->dm2.hPSFamilies);
      GlobalUnlock(lpPSExtDevmode->dm2.hTTFamilies);
      return;
   }

   nNumDefSubsFont /= 2;

   for (i = 0; i < nNumDefSubsFont; i++)
   {
      lpszTT = (LPSTR)lpbyRcData;
      lpbyRcData += lstrlen(lpbyRcData) + 1; // Move to next PS font...
      lpbyRcData += lstrlen(lpbyRcData) + 1; // then skip it.

      nTTIndex = FindFontFamily(lpPSExtDevmode->dm2.hTTFamilies,
                                    lpPSExtDevmode->dm2.iNumTTFamilies,
                                    lpszTT);

      if (nTTIndex >= 0)
      {
         // This TT exists, so find its substitution.

            nPSIndex = GetAssignment(hDlg, nTTIndex);

            if (nPSIndex == 0)
         {
            // Write in win.ini
               WriteProfileString(szSection, lpszTT, "0");
         }
      }
   }

   UnloadFontResource(hgblRcData);

   GlobalUnlock(lpPSExtDevmode->dm2.hPSFamilies);
   GlobalUnlock(lpPSExtDevmode->dm2.hTTFamilies);
    // Free the buffers used to write out the Vertical Substitution for CJK font
      GlobalFreePtr(lpBuf1) ;  // free one frees all because lpBuf2 = lpBuf1+512;
}

/*****************************************************************************/
/*                 GetRasterizerType                                         */
/* Purpose:                                                                  */
/*   Gets the rasterizer type of the current printer.                        */
/*                                                                           */
/* Parameters:                                                               */
/*   HANDLE ghDriverMod -- Driver module handle                              */
/*   LPPDEVICE lppd -- pdevice                                               */
/*   LPDRVSTATE lpDrvState -- Driver State                                   */
/*                                                                           */
/* Returns: int                                                              */
/*   Rasterizer type                                                         */
/*****************************************************************************/

int NEAR PASCAL
GetRasterizerType(HANDLE ghDriverMod, LPWPXBLOCKS lpWPXBlock,
                  LPPSEXTDEVMODE lpPSExtDevmode)
{
  TTRAST_OPT TTRasterizer;
  int retVal;

  TTRasterizer = ((LPPRINTERINFO)(lpWPXBlock->WPXprinterInfo))->devcaps.TTRasterizer;
  if ( (TTRasterizer == TTRAST_TYPE42) || (TTRasterizer == TTRAST_TYPE42BUGGY ) )
    retVal = RASTERIZER_TYPE42;
  else if (TTRasterizer == TTRAST_TRUEIMAGE)
      retVal = RASTERIZER_TRUEIMAGE;
    else
      retVal = RASTERIZER_NORMAL;

  return (retVal);
}

/*****************************************************************************/
/*                 FillPSComboBox                                            */
/* Purpose:                                                                  */
/*   Fills a PostScript Combo box from the list of Family Names              */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to TrueType Font substitutions dialog box           */
/*   int iCtrlID -- ID of the control to fill with PS Family names           */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL
FillPSComboBox(HWND hDlg, int iCtrlID)
{
  LPDRIVERINFO      lpDrvInfo;
  LPPSEXTDEVMODE    lpPSExtDevmode;
  HWND              hCtrl;
  char              strBuff[STR_BUFF_LEN];
  LPSTR             lpStackStart, lpFamilyName;
  int               i;

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg, DWL_USER);
  lpPSExtDevmode = lpDrvInfo->lpDM;

  hCtrl = GetDlgItem(hDlg, iCtrlID);

  lpStackStart = (LPSTR)GlobalLock(lpPSExtDevmode->dm2.hPSFamilies);

  for (i = 0; i < lpPSExtDevmode->dm2.iNumPSFamilies; i++)
  {
    lpFamilyName = (LPSTR)(lpStackStart + i*FAMILY_NAME_SIZE);
    lstrcpy(strBuff, lpFamilyName);
    SendMessage(hCtrl, CB_ADDSTRING, 0, (LPARAM)(LPSTR)strBuff);
  }

  GlobalUnlock(lpPSExtDevmode->dm2.hPSFamilies);
}

/*****************************************************************************/
/*      GetSubsLine                                                          */
/*                                                                           */
/* Purpose:                                                                  */
/*   To build the truetype -> postscript substitution string that is         */
/*   placed in the listbox                                                   */
/*                                                                           */
/* Parameters:                                                               */
/*    HWND hDlg -- dialog box handle                                         */
/*    LPSTR lpBuf -- buffer to place result                                  */
/*    LPSTR lpStackStart -- base of TrueType font "stack" list               */
/*    int iTTidx -- index to which font in this list                         */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

static void NEAR
GetSubsLine(HWND hDlg, LPSTR lpBuf, LPSTR lpStackStart, int iTTidx)
{
  LPSTR lpFamilyName, lpAssignment;
  char  shortTTFamName[SHORT_BUFF_LEN];
  char  strBuff[SHORT_BUFF_LEN];
  int   iCurAssignment;

  /* Fill in the TT Family text */
  lpFamilyName = (LPSTR)(lpStackStart + iTTidx*FAMILY_NAME_SIZE);

  /* Use the Active TT item to help truncate family name */
  TruncateToFitControl(hDlg, ID_ACTIVE_TT, lpFamilyName, shortTTFamName);
  lstrcpy(lpBuf, shortTTFamName);
  lstrcat(lpBuf, "\t");

  /* Set up the assigned substitutions */
  iCurAssignment = GetAssignment(hDlg, iTTidx);
  SendDlgItemMessage(hDlg, ID_ACTIVE_SUBS, CB_GETLBTEXT,
                     iCurAssignment, (LPARAM)(LPCSTR)strBuff);
  if (strBuff[0] != ' ')
    lpAssignment = strBuff;
  else
    lpAssignment = strBuff + 2; /* Eat up two leading spaces for "  Send As" */
  lstrcat(lpBuf, lpAssignment);

}

/*****************************************************************************/
/*                 FillSubsList                                              */
/* Purpose:                                                                  */
/*   Fill the substitutions list to take care of scrolling the substitutions */
/*   Works even if there are fewer families than MAX_TT_SUBSTITUTIONS        */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to TrueType Font substitutions dialog box           */
/*   int active_TT_index -- index of the active TT family (zero based)       */
/*   BOOL bUpdateAll - TRUE if update list box and active items, FALSE       */
/*                     if update only active items                           */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   Return TRUE if movement occurred, FALSE if not                          */
/*****************************************************************************/

BOOL NEAR PASCAL
FillSubsList(HWND hDlg, int iTTIndex, BOOL bUpdateAll)
{
  LPDRIVERINFO      lpDrvInfo;
  LPPSEXTDEVMODE    lpPSExtDevmode;
  LPSTR             lpStackStart, lpFamilyName;
  char              shortTTFamName[SHORT_BUFF_LEN];
  char              strBuff2[2 * SHORT_BUFF_LEN];
  int               iTabPos = 0;
  int               i, iCurAssignment;
  DWORD             idxTop;
  HWND              hList;

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER);
  lpPSExtDevmode = lpDrvInfo->lpDM;

  hList = GetDlgItem(hDlg, ID_FONTS_LISTBOX);
  lpStackStart = (LPSTR)GlobalLock(lpPSExtDevmode->dm2.hTTFamilies);

  idxTop = SendMessage(hList, LB_GETTOPINDEX, 0, 0l);
  SendMessage(hList, WM_SETREDRAW, (WPARAM)FALSE, 0L);

  if (bUpdateAll)
  {
    HCURSOR hCursor;

    hCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
    /* Clear out the list box */
    SendMessage(hList, LB_RESETCONTENT, 0, 0L);

    /* Set tab stop in middle */
    iTabPos = 95;
    SendMessage(hList, LB_SETTABSTOPS, (WPARAM)1, (LPARAM)(int FAR *)&iTabPos);

    /* Fill in the text, set up the substitutions */
    for (i = 0; i < lpPSExtDevmode->dm2.iNumTTFamilies; i++)
    {
        GetSubsLine(hDlg, strBuff2, lpStackStart, i);
        SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)(LPCSTR)strBuff2);
    }

    /* Highlight active item */
    SendMessage(hList, LB_SETCURSEL, iTTIndex, 0L);
    SetCursor(hCursor);
  }
  else                                  /* only change the active tt line   */
  {
    GetSubsLine(hDlg, strBuff2, lpStackStart, iTTIndex);
    SendMessage(hList, LB_DELETESTRING, (WPARAM)iTTIndex, 0l);
    SendMessage(hList, LB_INSERTSTRING, (WPARAM)iTTIndex, (LPARAM)strBuff2);
    SendMessage(hList, LB_SETCURSEL,    (WPARAM)iTTIndex, 0l);
  }
  SendMessage(hList, LB_SETTOPINDEX,  (WPARAM)idxTop, 0l);
  SendMessage(hList, WM_SETREDRAW,    (WPARAM)TRUE, 0L);

      /* Update Active label */
  lpFamilyName = (LPSTR)(lpStackStart + iTTIndex*FAMILY_NAME_SIZE);
  TruncateToFitControl(hDlg, ID_ACTIVE_TT, lpFamilyName, shortTTFamName);
  SetDlgItemText(hDlg, ID_ACTIVE_TT, shortTTFamName);

      /* Set up the assigned substitutions */
  iCurAssignment = GetAssignment(hDlg, iTTIndex);

      /* Redraw active item's combo box */
  SendDlgItemMessage(hDlg, ID_ACTIVE_SUBS, CB_SETCURSEL,
                         iCurAssignment, 0L);

  GlobalUnlock(lpPSExtDevmode->dm2.hTTFamilies);
  return (TRUE);
}

/*****************************************************************************/
/*                 WriteDefaultAssignmentToIni                               */
/* Purpose:                                                                  */
/*   Writes Default Assignment vector to INI file.                           */
/*                                                                           */
/* Parameters:                                                               */
/*   HANDLE ghDriverMod -- Driver module handle                              */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void
WriteDefaultAssignmentsToIni(HANDLE ghDriverMod)
{
   char  szSection[SHORT_BUFF_LEN];
   int      nNumDefSubsFont;
   HGLOBAL  hgblRcData;
   LPBYTE   lpbyRcData;
   LPSTR lpszTT;
   LPSTR lpszPS;

   LoadString(ghDriverMod, IDS_INI_SUBS_TITLE, szSection, sizeof szSection);

   nNumDefSubsFont = GetNumDefSubsFont();

   lpbyRcData = LoadFontResource(ID_FNT_DEF_SUBS_FONT, &hgblRcData);

   if (nNumDefSubsFont < 0 || lpbyRcData == NULL)
   {
      return;
   }

   for (nNumDefSubsFont /= 2; nNumDefSubsFont > 0; nNumDefSubsFont--)
   {
      lpszTT = (LPSTR)lpbyRcData;
      lpbyRcData += lstrlen(lpszTT) + 1;

      lpszPS = (LPSTR)lpbyRcData;
      lpbyRcData += lstrlen(lpszPS) + 1;

      WriteProfileString(szSection, lpszTT, lpszPS);
   }

   UnloadFontResource(hgblRcData);
}

/*****************************************************************************/
/*                 InitializeTTSubsTable                                     */
/* Purpose:                                                                  */
/*   Initialize the TrueType substitutions table                             */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- window handle to dialog, used to get devmode structures    */
/*   HANDLE ghDriverMod -- Driver module handle                              */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void FAR PASCAL InitializeTTSubsTable(HANDLE ghDriverMod)
{
  HGLOBAL hIniCache;
  LPSTR lpIniCache;
  char section[SHORT_BUFF_LEN];

  LoadString(ghDriverMod, IDS_INI_SUBS_TITLE, section, SHORT_BUFF_LEN);

  hIniCache  = GlobalAlloc(GHND|GMEM_DDESHARE, INI_CACHE_SIZE);
  lpIniCache =  (LPSTR)GlobalLock(hIniCache);

  GetProfileString(section, NULL, "", lpIniCache, INI_CACHE_SIZE);

  if (*lpIniCache == '\0')         /* Don't have any data, write out some */
     WriteDefaultAssignmentsToIni(ghDriverMod);

  GlobalUnlock(hIniCache);
  GlobalFree(hIniCache);
}
