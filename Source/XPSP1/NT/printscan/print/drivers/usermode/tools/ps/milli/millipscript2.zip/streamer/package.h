/* CM_VerSion package.h atm05 1.2 10076.eco sum= 48501 */
/* CM_VerSion package.h atm04 1.8 05393.eco sum= 40720 */
/*
  package.h

Copyright (c) 1991-1992 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of
Adobe Systems Incorporated.  Many of the intellectual and
technical concepts contained herein are proprietary to Adobe,
are protected as trade secrets, and are made available only to
Adobe licensees for their internal use.  Any reproduction or
dissemination of this software is strictly forbidden unless
prior written permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks of
Adobe Systems Incorporated.

Original version: 
Edit History:
John Nogrady: Tue May 12 13:46:40 1992
Craig Rublee: Wed Jul 15 11:42:13 PDT 1992
Ron Fischer: Thu Aug 27 17:51:41 1992
End Edit History.

*/

/* PC Version! */


#ifndef PACKAGE_SPECS_H
#define PACKAGE_SPECS_H

/* This file is used when the ATM rasterizer is compiled outside the
PostScript Development Environment. It replaces the package_specs.h files
provided by the development environment. The switch -DPACKAGE_SPECS="package.h"
should be added to the compilation line.
*/

#define BUFFGLUE	"..\streamer\buffglue.h"
#define BUILDGLU	"..\streamer\buildglu.h"
#define PARSEGLU	"..\streamer\parseglu.h"
#define IOGLUE		"..\streamer\ioglue.h"
#define CIDGLUE		"..\streamer\cidglue.h"
#define DBCSGLUE	"..\streamer\dbcsglue.h"

#define PUBLICTYPES     "..\streamer\publicty.h"
#define DEVICETYPES     "..\streamer\devicety.h"
#define ENVIRONMENT     "..\streamer\environm.h"
#define EXCEPT          "..\streamer\except.h"
#define FP              "..\streamer\fp.h"
#define BUILDCH         "..\streamer\buildch.h"
#define CSCAN           "..\streamer\cscan.h"
#define PROTOS          "..\streamer\protos.h"
#define BLEND           "..\streamer\blend.h"
#define PARSE           "..\streamer\parse.h"
#define BCMATRIX        "..\streamer\bcmatrix.h"
#define DEVPATTERN      "..\streamer\devpatte.h"
#define FRAMEPIXEL      "..\streamer\framepix.h"
#define ATM             "..\streamer\stratm.h"
#define ATMQRED         "..\streamer\atmqred.h"
#define OSSYSLIB        "..\streamer\ossyslib.h"
#define CLOCK           <time.h>
#define T1CHIP          "..\streamer\t1chip.h"
#define BCUTIL		"..\streamer\bcutil.h"
#define TRUETYPE	"..\streamer\truetype.h"
#define STREAMER	"..\streamer\streamer.h"
#define STREAMER_FAUX		"..\streamer\faux.h"

#define MEM		"..\streamer\mem.h"
#define DECO_LIB	"..\deco\deco_lib.h"

#define FCNTL_H		<fcntl.h>
#define STDIO_H		<stdio.h>
#define MALLOC_H	<malloc.h>
#define STDLIB_H	<stdlib.h>


/* CM_VerSion switches_16_286.h atm04 1.2 04074.eco sum= 13451 */
/*
  switches.h

Copyright (c) 1992 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of
Adobe Systems Incorporated.  Many of the intellectual and
technical concepts contained herein are proprietary to Adobe,
are protected as trade secrets, and are made available only to
Adobe licensees for their internal use.  Any reproduction or
dissemination of this software is strictly forbidden unless
prior written permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks of
Adobe Systems Incorporated.

Original version:
Edit History:
Craig Rublee: Fri Jul 19 17:43:59 1991
End Edit History.
*/

#ifndef SWITCHES_H
#define SWITCHES_H

/* Compilation switches for the 16 bit microsoft compiler */
#define HC386    0
#define OS       os_msdos
#define STAGE    DEVELOP
#define ISP      isp_i80286
#define BCMAIN   0
#define SWAPUNIT 8
#define SCANUNIT 32
#define BCVIDEO  video_vga
#define DEVICE_CONSISTENT 0
#define ASMARITH 0
#define FORCE32BITS 0
#define ASMCONV 0
#define STREAMER_DBCS 0
#define CID	0
#define RANDOMACCESS 0
#define CUBE	1
#define GLOBALCOLORING 0
#define ONEPASSGC 0

/* definitions for BC */
#define TRUE_TYPE 0
#define NOT_ON_THE_MAC
#define T1CDEBUG 0
#define T1MODEL at_model

#endif /* SWITCHES_H */

#endif /* PACKAGE_SPECS_H */
