/* @(#)CM_VerSion xcf_cmd.c atm08 1.6 16293.eco sum= 15368 atm08.004 */
/* xf.c - tests the font expander package

              Copyright 1995 -- Adobe Systems, Inc.
            PostScript is a trademark of Adobe Systems, Inc.
NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

Original version: John Felton, Dec 12 1995
*/

/* -------------------------------------------------------------------------
     Header Includes
  --------------------------------------------------------------------------- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <memory.h>
#include <time.h>

#ifndef _SIZE_T
#define _SIZE_T /* so size_t isn't redefined here */
#include "xcf_pub.h"
#undef _SIZE_T
#else
#include "xcf_pub.h"
#endif

#include "xcf_priv.h"

#define PROFILING 0	/* xxx */
#if PROFILING
#include <profiler.h>
#endif /*PROFILING*/

#ifdef MAC_ENV
#include <console.h>
#else
#include <malloc.h>
#endif
#if 0
#include PACKAGE_SPECS
#include ENVIRONMENT
#endif


/* ### Missing prototypes ### */
extern int printf(const char *format, ...);
extern int fprintf(FILE *stream, const char *format, ...);
extern int sscanf( const char *buffer, const char *format, ... );
extern size_t fwrite(const void *ptr, size_t size, size_t count, FILE *stream);
size_t fread( void *buffer, size_t size, size_t count, FILE *stream );
extern int fseek(FILE *stream, long offset, int wherefrom);
extern int fclose(FILE *stream);
extern long int strtol(const char *, char **, int);
  



/* ---------------------------------------------------------------------------
     Macro Definitions
--------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------
     Static Variables
 --------------------------------------------------------------------------- */

FILE PTR_PREFIX *inFile;
FILE PTR_PREFIX *outFile;
void PTR_PREFIX *pGetBytesBuffer = NULL;
unsigned short int getBytesBufferSize = 0;
XCF_CallbackStruct callbacks;

XCF_ClientOptions xcfOptions;

time_t   start, finish;
double   elapsed_time;

/* File error messages */
char PTR_PREFIX *PEstring[11] = {
  "no error",                           /*   0 PE_NOERR */
  "I/O error or early EOF",             /*  -1 PE_READ */
  "token too big",                      /*  -2 PE_BIGTOKEN */
  "failed callback procedure",          /*  -3 PE_CALLER */
  "bad font file",                      /*  -4 PE_BADFILE */
  "font is not Type 1",                 /*  -5 PE_NOTTYPE1OR4 */
  "buffer too small",                   /*  -6 PE_BUFFSMALL */
  "bad cartridge synthetic font",       /*  -7 PE_CARTBADSYNTH */
  "bad blending data",                  /*  -8 PE_BADBLEND */
  "internal error",                     /*  -9 PE_CANTHAPPEN */
  "badly formatted number",             /* -10 PE_BADNUMBER */
};


/* Program usage description */
static void printUsage(void)
{
printf(
"'xcf' converts a CFF font into a Type 1 font.\n"
"Version: %s\n"
"Usage: xcf [-options] <inFont> <outFont>\n"
"Options:\n"
"     -a         dump CFF in ASCII. (Dump single font if -f used)\n"
"     -b         use binary eexec (default = hex)\n"
"     -d         print font set directory (no converson performed)\n"
"     -f n       extract font #n from font set (default = 0)\n"
"     -i         incremental download\n"
"     -l n       use lenIV n (default = 4)\n"
"     -m         Read CFF into memory before converting (faster)\n"
"     -p         use plain text (default = eexec encryption)\n"
"     -s         include subroutines (default = flatten)\n"
"     -t n       generate charstring type n (default = 1)\n"
"\n"
"inFont is the name of a CFF font. (default = stdin)\n"
"outFont will contain the generated Type 1 font. (default=stdout)\n",
  XCF_Version
);
}

/* ---------------------------------------------------------------------------
     Function Declarations
 --------------------------------------------------------------------------- */

/*char PTR_PREFIX *myBuffer;
Card32 myBufferSize;

   if (fread(&desc.type, 1, sizeof(desc.type), inFile) != sizeof(desc.type))


length = fread(myBuffer, 1, (CardX)MIN(UNIX_READ_MAX, (CardX)myBufferSize), inFile);
fwrite(pData, len, 1, outFile);

*/

/* ---------------------------------------------------------------------------
     Function: usage():

     usage() writes the program usage description to stdout.
  --------------------------------------------------------------------------- */
static void usage(void)
{
  printUsage();
  exit(1);
}




/* #if OS != os_msdos && OS != os_thinkc && OS != os_windowsNT */
/* #if OS==os_mach */
/* extern int getopt (int  argc, char **  argv, char *  optstring); */
/* #elif OS != os_aix && OS != os_solaris */
/* extern int getopt (int  argc, char **  argv, const char *  optstr); */
/* #endif */
/* extern int optind; */
/* extern char *optarg; */
/* #else */

static char *optarg;
static int optind=1;

/* ---------------------------------------------------------------------------
     Function: getopt():

     getopt() returns the next option letter in argv that
     matches a letter in the optstring.
  --------------------------------------------------------------------------- */

static int getopt(int argc, char PTR_PREFIX ** argv, const char PTR_PREFIX * opstring)
{
  char PTR_PREFIX *s;

  /* have all our command line arguments? */
  if (optind >= argc)
     return -1;

  /* Is this a valid options (starts with '-') */
  if (argv[optind][0] != '-')
     return -1;

  /* '--' means end of options */
  if (argv[optind][1] == '-') {
     optind++;
     return -1;
  }

  /* Is this option in our list of valid options? */
  s = strchr(opstring,(int)(argv[optind][1]));

  /* if no match return question mark */
  if (s == NULL) {
     fprintf(stderr,"Unknown Option encountered: %s\n",argv[optind]);
     return (int)'?';
  }

  /* Does this option have an argument */
  if (s[1] == ':') {
     optind++;
     if (optind < argc)
        optarg = argv[optind];
     else {
        fprintf(stderr,"No argument present for %s\n",argv[optind]);
        return (int)'?';
     }
  }
  else
     optarg = NULL;
  optind++;
  return (int)s[0];
} /* end getopt() */

/* #endif */

static void CheckError(enum XCF_Result status)
{
	if (status == XCF_Ok)
		return;
	fprintf(stderr, "ERROR: ");
	switch (status)
	{
	case XCF_EarlyEndOfData :
		fprintf(stderr, "EARLY END OF DATA");
		break;
	case XCF_StackOverflow :
		fprintf(stderr, "STACK OVERFLOW");
		break;
	case XCF_StackUnderflow :
		fprintf(stderr, "STACK UNDERFLOW");
		break;
	case XCF_UnterminatedDictionary :
		fprintf(stderr, "UNTERMINATED DICTIONARY");
		break;
	case XCF_InvalidDictionaryOrder :
		fprintf(stderr, "INVALID DICTIONARY ORDER");
		break;
	case XCF_IndexOutOfRange :
		fprintf(stderr, "INDEX OUT OF RANGE");
		break;
	case XCF_MemoryAllocationError :
		fprintf(stderr, "MEMORY ALLOCATION ERROR");
		break;
	case XCF_FontNotFound :
		fprintf(stderr, "FONT NOT FOUND");
		break;
	case XCF_UnsupportedVersion :
		fprintf(stderr, "UNSUPPORTED VERSION");
		break;
	case XCF_InvalidOffsetSize :
		fprintf(stderr, "INVALID OFFSET SIZE");
		break;
	case XCF_InvalidString :
		fprintf(stderr, "INVALID STRING");
		break;
	case XCF_InvalidOffset :
		fprintf(stderr, "INVALID OFFSET");
		break;
	case XCF_CharStringDictNotFound :
		fprintf(stderr, "CHAR STRING DICT NOT FOUND");
		break;
	case XCF_InvalidCharString :
		fprintf(stderr, "INVALID CHAR STRING");
		break;
	case XCF_SubrDepthOverflow :
		fprintf(stderr, "SUBR DEPTH OVERFLOW");
		break;
	case XCF_FontNameTooLong :
		fprintf(stderr, "FONT NAME TOO LONG");
		break;
	case XCF_InvalidNumber :
		fprintf(stderr, "INVALID NUMBER");
		break;
	case XCF_HintOverflow :
		fprintf(stderr, "HINT OVERFLOW");
		break;
	case XCF_UnsupportedCharstringTypeRequested :
		fprintf(stderr, "UNSUPPORTED CHARSTRING TYPE REQUEST");
		break;
	case XCF_InternalError :
		fprintf(stderr, "INTERNAL ERROR");
		break;
	case XCF_InvalidNumberType :
		fprintf(stderr, "INVALID NUMBER TYPE");
		break;
	case XCF_GetBytesCallbackFailure :
		fprintf(stderr, "GET BYTES CALLBACK FAILURE");
		break;
	case XCF_InvalidFontIndex :
		fprintf(stderr, "INVALID FONT INDEX");
		break;
	case XCF_InvalidCIDFont :
		fprintf(stderr, "INVALID CID FONT");
		break;
  case XCF_InvalidDictArgumentCount :
		fprintf(stderr, "INVALID DICT ARGUMENT COUNT");
		break;
	case XCF_NoCharstringsFound :
		fprintf(stderr, "NO CHARSTRINGS FOUND");
		break;
	case XCF_InvalidBlendArgumentCount :
		fprintf(stderr, "INVALID BLEND ARGUMENT COUNT");
		break;
	case XCF_InvalidBlendDesignMap :
		fprintf(stderr, "INVALID BLEND DESIGN MAP");
		break;
  case XCF_InvalidDownloadArgument :
    fprintf(stderr, "INVALID DOWNLOAD ARGUMENT");
    break;
  case XCF_InvalidDownloadOptions :
    fprintf(stderr, "INVALID DOWNLOAD OPTIONS");
    break;
  case XCF_InvalidFontSetHandle:
    fprintf(stderr, "INVALID FONTSET HANDLE");
    break;
  case XCF_InvalidState :
    fprintf(stderr, "INVALID STATE");
    break;
  case XCF_InvalidGID :
    fprintf(stderr, "INVALID GID");
    break;
	default :
		fprintf(stderr, "UNKNOWN ERROR");
		break;
	}
	fprintf(stderr, "\r\n");
	exit(status);
}


/* Seek method constants */
#define SEEK_CUR    1
#define SEEK_END    2
#define SEEK_SET    0


/***********************************
		Callback Functions
 ***********************************/
static int PutBytesAtPos( unsigned char PTR_PREFIX *pData, long int position, unsigned short int length, void PTR_PREFIX *clientHook )
{
	if (position >= 0)
	{
      if(fseek(outFile, position, SEEK_SET))
		  return 0;
	}
	if (length > 0)
		if (fwrite(pData,1,length,outFile) != length)
			return 0;
	return 1;
}

static int StrCmp(const char PTR_PREFIX *string1,
                  const char PTR_PREFIX	*string2)
{
  return strcmp( string1, string2);
}

static long int OutputPos( void PTR_PREFIX *clientHook )
{
	return ftell(outFile);
}



static int GetBytesFromPos( unsigned char PTR_PREFIX * PTR_PREFIX *ppData, long int position, unsigned short int length, void PTR_PREFIX *clientHook )
{
	if (length == 0)
	{
		free(pGetBytesBuffer);
		pGetBytesBuffer = NULL;
		getBytesBufferSize = 0;
		return 1;
	}
	if (position >= 0)
		if(fseek(inFile, position, SEEK_SET))
			return 0;
	if (length > getBytesBufferSize)
	{
		if (pGetBytesBuffer != 0)
			free(pGetBytesBuffer);
		pGetBytesBuffer = malloc(length);
		if (pGetBytesBuffer == NULL)
		{
			getBytesBufferSize = 0;
			return 0;
		}
		getBytesBufferSize = length;
	}
	if (fread(pGetBytesBuffer, 1, length, inFile) != length)
		return 0;
	*ppData = pGetBytesBuffer;
	return 1;
}


static void PTR_PREFIX *CopyMemory( void PTR_PREFIX *dest, const void
																	 PTR_PREFIX *src, unsigned short int count )
{
	return memcpy(dest, src, (size_t) count);
}

static void PTR_PREFIX *SetMemory( void PTR_PREFIX *dest, int c, unsigned short int count )
{
	return memset(dest, c, (size_t) count);
}

static unsigned short int StringLength( const char PTR_PREFIX *string )
{
	return (unsigned short int) strlen(string);
}

static unsigned long int AllocateMem(void PTR_PREFIX * PTR_PREFIX *hndl, unsigned long int size, void PTR_PREFIX *clientHook ) /* Warning - this callback won't allocate more than 64k in Win16 */
{
char PTR_PREFIX *newptr;

/*printf("MyRealloc(): size = %ld.\n", size);*/

if ((size == 0) && (*hndl == NULL))
   return true;

if (size == 0)
 { (void)free(*hndl);
   *hndl = NULL;
   return true;
 } /* end if */

if (*hndl == NULL)
 { *hndl = malloc((size_t) size);
   if (*hndl == NULL)
      return false;
 } /* end if */
else
 { newptr = (char PTR_PREFIX *)realloc(*hndl, (size_t) size);
   if (newptr == NULL)
      return false;

   *hndl = newptr;
 } /* end else */

return true;
} /* end AllocateMem() */

static long FileLength(FILE PTR_PREFIX *strm)
{
	long pos;
	long savedPos = ftell(strm);		/* save position */
	fseek(strm, 0, SEEK_END);			/* Go to end */
	pos = ftell(strm);					/* get file size */
	fseek(strm, savedPos, SEEK_SET);	/* restore position */
	return(pos);
}

static int CharNameFromGID(XFhandle handle, void PTR_PREFIX*client,
                           XCFGlyphID glyphID,
                           char PTR_PREFIX *charName,
                           unsigned short int length)
{
  char str[50];

  strncpy(str, charName, length);
  str[length] = '\0';

  printf("CharNameFromGID: gid = %ld, name = %s, length = %ld\n",
				 (long)glyphID, str, (long)length);
  return 0;
}

static int CIDFromGID(XFhandle handle, void PTR_PREFIX *client, XCFGlyphID
											glyphID, Card16 cid)
{
  printf("CIDFromGID: gid = %ld, cid = %ld\n", (long) glyphID, (long)cid);
  return 0;
}

#if TEST
static void endTime(char PTR_PREFIX *str)
{
  time(&finish);

  elapsed_time = difftime( finish, start );
  printf( "\n%s takes %6.0f seconds.\n", str, elapsed_time );
}

static void startTime()
{
  time(&start);
}
#endif

/* ---------------------------------------------------------------------------
     Function: main()

     main() is the main program.
 --------------------------------------------------------------------------- */

#define MAX_FONT_NAME_LENGTH 512
#define MAX_COMMAND_LINE 1024

int main( int argc, char PTR_PREFIX *argv[ ])
{
int c;
char PTR_PREFIX *infontfile = NULL, PTR_PREFIX *outfontfile = NULL;
XFhandle h;

unsigned char PTR_PREFIX *encodingName = 0;
char PTR_PREFIX *replaceFontName = "TestFont";
XCFGlyphID subset[256];
char **glyphNames = NULL;

#ifdef XCF_DEVELOP
const char hexString[256*2];
#endif

enum XCF_Result status, cleanUpStatus;
char fontName[MAX_FONT_NAME_LENGTH];
char commandLine[MAX_COMMAND_LINE];
unsigned short int i;

unsigned int lenIV = 4;
boolean hex = true;
boolean inclSubrs = false;
boolean plainText = false;
unsigned int fontType = 1;
boolean directory = false;
boolean dumpAscii = false;
boolean dumpAll = true;
boolean inRAM = false;
boolean incremental = false;
boolean changegNames = false;
boolean cidFont = false;
unsigned int fontIndex = 0;
unsigned int numberOfFonts = 0;
unsigned short int identifier = 100;

int repeatCount;

#ifdef MAC_ENV
argc = ccommand(&argv);
#endif

commandLine[0] = 0;
optind = 0;

#if PROFILING
if (ProfilerInit(collectDetailed, bestTimeBase, 300 /*routines*/, 20 /*depth*/) != 0)
	return;
#endif /*PROFILING*/

	callbacks.putBytes = PutBytesAtPos;
	callbacks.outputPos = OutputPos;
	callbacks.getBytes = GetBytesFromPos;
	callbacks.pFont = NULL;
	callbacks.allocate = AllocateMem;
	callbacks.putBytesHook = NULL;
	callbacks.outputPosHook = NULL;
	callbacks.getBytesHook = NULL;
	callbacks.allocateHook = NULL;
	callbacks.strlen = &StringLength;
	callbacks.memcpy = &CopyMemory;
	callbacks.memset = &SetMemory;
	callbacks.sprintf = (XCF_sprintf)&sprintf;
	callbacks.printfError = (XCF_printfError)&printf;
  callbacks.atoi = (XCF_atoi)&atoi;
  callbacks.strtol = (XCF_strtol)&strtol;
	callbacks.atof = (XCF_atof)&atof;
  callbacks.strcmp = (XCF_strcmp)&StrCmp;
  callbacks.gidToCharName = (XCF_GIDToCharName)&CharNameFromGID;
  callbacks.gidToCID = (XCF_GIDToCID)&CIDFromGID;

  xcfOptions.fontIndex = 0;					/* font index w/i a CFF font set */
  xcfOptions.uniqueIDMethod = XCF_KEEP_UID;		/* UniqueID method */
  xcfOptions.dlOptions.useSpecialEncoding = 0;
  xcfOptions.maxBlockSize = 1024;
	xcfOptions.uniqueID = 0;

while (argv[optind] != NULL)
{
	strcat(commandLine, argv[optind++]);
	strcat(commandLine, " ");
}

/* Parse command-line options */

optind = 1;
  while ((c = getopt(argc, argv, "acdimnflbpsft?")) != EOF)
     switch (c) {
        case 'a':
           dumpAscii = true;
           break;
        case 'd':
           directory = true;
           break;
			  case 'i':
           incremental = true;
           break;
        case 'm':
           inRAM = true;
           break;
  			 case 'n':
           incremental = true;
           changegNames = true;
           break;
        case 'f':
           fontIndex = atoi(argv[optind]);
           optind++;
		   dumpAll = false;
           break;
        case 'l':
           lenIV = atoi(argv[optind]);
           optind++;
           break;
        case 't':
           fontType = atoi(argv[optind]);
           optind++;
           break;
        case 'b':
           hex = false;
           break;
        case 'p':
           plainText = true;
           break;
        case 's':
           inclSubrs = true;
           break;
        default:                                 /* All other options - show */
           usage();                              /* usage                    */
     }
  argc -= optind;
  argv += optind;

  /* Collect parameters */
#if !XCF_CID
/* xxx hack alert! */
  if (argc == 0)
     usage();
#endif

for (repeatCount=1; repeatCount<=1; ++repeatCount)
{

  /* The next argument on the command line is the font file specification. */
  infontfile = argv[0];
  outfontfile = argv[1];

/*	printf("%d ", repeatCount); */


	if (infontfile == NULL)
	{
		inFile = stdin;
		outFile = stdout;
	}
	else
    {
		if ((inFile = fopen(infontfile, "rb")) == NULL)
		{
			fprintf(stderr, "The input font file '%s' does not exist.\n", infontfile);
			exit(1);
		}
	}

	if (outfontfile == NULL)
		outFile = stdout;
	else
	{
		if ((outFile = fopen(outfontfile, "wb")) == NULL)
		{
			fprintf(stderr, "The output font file '%s' could not be opened.\n", outfontfile);
			exit(1);
		}
	}

	if (inRAM)
	{
		callbacks.getBytes = NULL;
		callbacks.fontLength = FileLength(inFile);
		callbacks.pFont = malloc((size_t) callbacks.fontLength);
		if (callbacks.pFont == NULL)
			{ fprintf(stderr, "Insufficient Memory To Hold CFF File\n");
			  exit(1);
			} /* end if */

		if ((unsigned long) fread(callbacks.pFont, (size_t) 1, (size_t) callbacks.fontLength, inFile) != callbacks.fontLength)
			{ free(callbacks.pFont); 
			  fprintf(stderr, "Bad Byte Count In Read\n");
			  exit(1);
			} /* end if */
	}

  xcfOptions.subrFlatten = (inclSubrs ? XCF_KEEP_SUBRS : XCF_FLATTEN_SUBRS);
  xcfOptions.eexecEncryption = (!plainText);
	xcfOptions.lenIV = lenIV;
	xcfOptions.hexEncoding = hex;
  xcfOptions.outputCharstrType = fontType;
  xcfOptions.dlOptions.encodeName = incremental ? encodingName : 0;
  xcfOptions.dlOptions.fontName =
    incremental ? (unsigned char PTR_PREFIX *)replaceFontName : 0;

	status = XCF_Init(&h, &callbacks, &xcfOptions);
  status = status | XCF_FontIdentification(h, &identifier);
  if (status == XCF_Ok && identifier == XCF_CID)
  { /* Reset a few default options. */
    XCF_Handle hdl = (XCF_Handle)h;
    cidFont = true;
    if (!incremental)
    {
      hdl->options.hexEncoding = false;
      hdl->options.lenIV = -1;
      hdl->options.eexecEncryption = false;
    }
  }

  /* printf("This has a font identifier of: %ld\n", (long)identifier); */

	if (status == XCF_Ok)
	{
		if (directory)
		{
			status = XCF_FontCount(h,&numberOfFonts);
			if ((status == XCF_Ok) && (numberOfFonts > 0))
				for (i=0;i<numberOfFonts;++i)
				{
					XCF_FontName(h,i,fontName,MAX_FONT_NAME_LENGTH);
					printf("%u) %s\r\n",i,fontName);
				}
		}
		else if (dumpAscii)
		{
#ifdef XCF_DUMP_CFF
        status = XCF_DumpCff(h,fontIndex,dumpAll,infontfile,commandLine);
#endif
		}
    else
    {
      if (incremental)
      {
        if (!changegNames)
        {
          unsigned short gCount;

          for (i=30; i < 51; i++)
            subset[i-30] = i;

          if (cidFont)
          {
            for (i=780; i < 801; i++)
              subset[i-780+21] = i;
            subset[0] = 2788;
          }

          status = XCF_ProcessCFF(h);
#if 0
          status = XCF_CountDownloadGlyphs(h, cidFont? 42 : 21 ,
                               (XCFGlyphID PTR_PREFIX *) &subset, &gCount);
          printf("Number of glyphs to download: %d\n", gCount);
          status = XCF_GlyphIDsToCIDs(h, 42, (XCFGlyphID PTR_PREFIX *) &subset, 0);
#endif
          status = XCF_GlyphIDsToCharNames(h, cidFont ? 42 : 21,
                               (XCFGlyphID PTR_PREFIX *) &subset, 0);
          status = XCF_DownloadFontIncr(h, cidFont? 42 : 21 /* i-30*/,
                                 (XCFGlyphID PTR_PREFIX *) &subset, 0, 0);
#ifdef XCF_DEVELOP                      
        for (i = 32; i <= 52;i++) 
          sprintf(&(hexString[(i-32)*2]), "%02x", i);
        XCF_ShowHexString(h, hexString, 0);
#endif
          for (i=35; i < 76; i++)
            subset[i-35] = i;
          status = XCF_CountDownloadGlyphs(h, i-35,
                               (XCFGlyphID PTR_PREFIX *) &subset, &gCount);
          printf("Number of glyphs to download: %d\n", gCount);
          status = XCF_DownloadFontIncr(h, i-35,
                               (XCFGlyphID PTR_PREFIX *) &subset, 0, 0);
        }
        else
        {
          status = XCF_Init(&h, &callbacks, &xcfOptions);
          glyphNames = (char **)calloc(29, sizeof(char *));
          for (i=20; i < 50; i++)
          {
            subset[i-20] = i;
            glyphNames[i-20] = calloc(15, sizeof(char));
            sprintf(glyphNames[i-20], "%s%d", "glyph", i);
          }
          status = XCF_DownloadFontIncr(h, i-20,
                                (XCFGlyphID PTR_PREFIX *) &subset,
                                (unsigned char **)glyphNames,	0);
          for (i = 0; i < 30; i++)
            free(glyphNames[i]);
          free(glyphNames);
#ifdef XCF_DEVELOP
        for (i = 32; i <= 102;i++) 
          sprintf(&(hexString[(i-32)*2]), "%02x", i);
        XCF_ShowHexString(h, hexString, 1);
#endif
        }
      }
      else
  			status = XCF_ConvertToPostScript(h);
		}

		cleanUpStatus = XCF_CleanUp(&h);
		if (status == XCF_Ok)
			status = cleanUpStatus;
	}

	if (inRAM)
		free(callbacks.pFont);

	fclose(inFile);
	fclose(outFile);

	CheckError(status); 
} /* end repeat loop */

#if PROFILING
	ProfilerDump("\pxcf.profile");
	ProfilerTerm();
#endif /*PROFILING*/
	return 0;
}  /* End of main() */


