/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1996 Microsoft Corporation. All rights reserved.            */
/*                                                                           */
/* Include File Name: EMAP.H                                                 */
/*                                                                           */
/* Description: This include contains the vector to multiple code pages.     */
/*                                                                           */
/*****************************************************************************/

extern WORD CommonEncode[];

// CodePage:   1
extern WORD DriverWinAnsiEncode[];

// CodePage:   2
extern WORD DriverOldWinAnsiEncode[];

// CodePage:   3
extern WORD StandardEncode[];

// CodePage:  77
extern WORD MacStandardEncode[];

// CodePage: 1250
extern WORD EasternEuropeEncode[];

// CodePage: 1251
extern WORD RussianEncode[];

// CodePage: 1252
extern WORD AnsiEncode[];

// CodePage: 1253
extern WORD GreekEncode[];

// CodePage: 1254
extern WORD TurkishEncode[];

// CodePage: 1255
extern WORD HebrewEncode[];

// CodePage: 1256
extern WORD ArabicEncode[];

// CodePage: 1257
extern WORD BalticEncode[];

