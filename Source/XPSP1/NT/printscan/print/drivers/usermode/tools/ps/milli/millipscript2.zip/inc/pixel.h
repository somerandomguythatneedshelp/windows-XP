/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: PIXEL.H                                                */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

DWORD _loadds FAR PASCAL Pixel(LP lpDevice,short sX,short sY,DWORD dPhysColor,
        LPDRAWMODE lpDrawMode);

