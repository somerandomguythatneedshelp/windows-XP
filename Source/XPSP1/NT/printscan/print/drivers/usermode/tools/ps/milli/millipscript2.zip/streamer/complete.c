/* streamer.c - tests the streamer package

              Copyright 1994 -- Adobe Systems, Inc.
            PostScript is a trademark of Adobe Systems, Inc.
NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

Original version: Ron Fischer, Fri Mar 4nd, 1994
*/

/* -------------------------------------------------------------------------
     Header Includes
  --------------------------------------------------------------------------- */

#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES

#include FP

#include STREAMER
#include PARSEGLU
#include "buffglue.h"


#define STREAM_BUF_SIZE 256
#define HALF_BUF_SIZE   (STREAM_BUF_SIZE>>1)

/* My temporary buffer.  If I just sent data directly through to the output
   buffer I would not be able to overwrite some data. */
char streamBuf[STREAM_BUF_SIZE];


/* What postion in the streamBuf are we at? */
Card32 streamBufTotal = 0;

/* What absolute pos does the first streamBuf entry correspond to? */
Card32 streamBufFirst = 0;


/* These are the main parameters used by Streamer functions.  In particular
   these values are needed in the callbacks.  Since it would be very 
   difficult to pass them through to the callbacks I use these globals. */
T1FontPointer pFont;
CharStrOpts *pCharOpts;
PStreamerOpts pStreamerOpts;
PBufferStatus pBufferStatus;
FauxInfoPointer pFauxInfo;


/* For this code I am assuming that the subrs and charstrings were 
   gathered on the first pass through the code.  So there is no need 
   to do anything with them on this pass. */

PRIVATE boolean DummyAllocSubrs ARGDEF1(IntX, count)
{
return true;
}  /* end DummyAllocSubrs() */


PRIVATE boolean DummySubroutine ARGDEF3(IntX, index, CharDataPtr, val, CardX, len)
{
return true;
} /* end DummySubroutine() */


PRIVATE boolean DummyCharString ARGDEF3(char *,key, CharDataPtr, val, CardX, len)
{
return true;
} /* end DummyCharString() */


PRIVATE boolean DummyAllocChars ARGDEF1(IntX, count)
{

return true;
} /* end DummyAllocChars() */


/* Send 'count' bytes of data from my temporary buffer to the output buffer. */
/* By this point count had better be able to fit into a Card16. */

PRIVATE void SendStreamBuf ARGDEF1(Card32, count)
{
BufferChars((Card8 *)streamBuf, count);
if (count < streamBufTotal)
   os_memcpy(streamBuf, streamBuf+count, (Card16)(streamBufTotal-count));
/* Wow.  This old code worked through an incredible coincidence.  The only
   time I was calling this code was when I sent the entire or exactly half
   of the buffer.  For exactly half this code just so happens to equal the
   (correct) code above. */
   /*os_memcpy(streamBuf, streamBuf+(STREAM_BUF_SIZE-count), (Card16)count);*/
streamBufTotal -= count;
streamBufFirst += count;

} /* end SendStreamBuf() */


/* Callback to get raw data for the font.  It temporarily buffers the data
   then sends it to the output buffer.
   count should ONLY be 1 for now!!!  If it changes the first param needs
   to become 'Card8 *'  */

PRIVATE boolean FontDataStream ARGDEF2(char, c, Card32, count)
{

/* Stream half the buffer--but save some so KeyPosition() will work */
if (streamBufTotal >= STREAM_BUF_SIZE-1)
   SendStreamBuf(HALF_BUF_SIZE);

if (c == (char)EOF)
{ SendStreamBuf(streamBufTotal);
   BufferFlush();
} /* end if */
else
{
   streamBuf[streamBufTotal] = c;
   streamBufTotal++;
}

return true;
} /* end FontDataStream() */


/* Write the complete temporary buffer out. */

PRIVATE void FlushStreamBuf ARGDEF1(Card32, count)
{
BufferChars((Card8 *)streamBuf, count);
streamBufFirst += streamBufTotal;
streamBufTotal = 0;
BufferFlush();
} /* end FlushStreamBuf() */


/* count should be the start of the string(s) of interest.  Otherwise it has
   almost no use.  I already know where I am in the stream--I keep track
   of that myself! */
PRIVATE boolean KeyPosition ARGDEF2(Card8, type, Card32, count)
{
IntX i, code;
char tempBuf[2];

switch (type)
 { /* The subrs were found in the font.  This can happen 2 times for synthetic
      fonts.  Each time call the routine to stream subrs.  This routine
      handles all encryption and lets the user sparse the data. */
   case SUBR_POSITION:
      FlushStreamBuf(count-streamBufFirst-1);
      BufferSave(pBufferStatus); /* Get the very latest status */
      code = StreamSubrs(pFont, pCharOpts, pBufferStatus);
      if (code != ST_NOERR)
         return false;
      break;

   /* The charstrings were found in the font.  Call StreamChars() to handle
      all encryption and sparsing issues. */
   case CHARSTRING_POSITION:
      FlushStreamBuf(count-streamBufFirst-2);/* go back before the "2 index" */
      BufferSave(pBufferStatus); /* Get the very latest status */
      code = StreamChars(pFont, pCharOpts, pStreamerOpts, pBufferStatus, pFauxInfo);
      if (code != ST_NOERR)
         return false;
      break;

   /* The user may want to give the font a new unique id so that it does not
      get confused with the original. */
   case UID_POSITION:
      FlushStreamBuf(count-streamBufFirst-1);
// Bug # 264982 remove the UniqueID for incremetal downloaded font

//      BufferString((Card8 *)"UniqueID ");
//      BufferInt(pFont->uniqueID);
//      BufferChar(' ');
      if ( pFont->pFontDict[0]->numMasters <= 1 )
      {
//          BufferString((Card8 *)"def /XUID [4 ");
          BufferString((Card8 *)"XUID [4 ");
          BufferInt(pFont->uniqueID);
          BufferString("] ");
      }
      break;

   /* In a special usage of this code the font type will be changed... */
   case FONT_TYPE_POSITION:
      FlushStreamBuf(count-streamBufFirst-1);
      BufferString((Card8 *)"FontType ");
      BufferInt(pFont->fontType);
      BufferChar(' ');
      break;

   /* The user may want to give the font a new fullname so that it does not
      get confused with the original. */
   case FULLNAME_POSITION:
      tempBuf[0] = ' '; //assume we have a space.
      code = InspectChars(-1, 1, (char *)&tempBuf); //start at -1 of in.buf, read 1 char.
      if (tempBuf[0] == ' ')
         FlushStreamBuf(count-streamBufFirst-1);
      else
         FlushStreamBuf(count-streamBufFirst);
      
      BufferString((Card8 *)"FullName (");
      BufferString((Card8 *)pFont->FullName);
      BufferString((Card8 *)") ");
      break;

   /* The user may want to give the font a new font name so that it does not
      get confused with the original. */
   case FONTNAME_POSITION:
      FlushStreamBuf(count-streamBufFirst-1);
      BufferString((Card8 *)"FontName /");
      BufferString((Card8 *)pFont->fontName);
      BufferChar(' ');
      break;

   /* The encryption may be changed--make sure it is set up correctly. */
   case EEXEC_POSITION:
      i = (IntX)(count - streamBufFirst - 1);
      if (streamBuf[i-1] == '%')
         i--;		/* "currentdict may be preceded by '%' */
      FlushStreamBuf(i); 		/* Send the unencrypted data */
      code = StreamEEXEC(pStreamerOpts);/* Set up encryption/no encryption */
      if (code != ST_NOERR)
         return false;
      break;

   /* Turn encryption in the file off */
   case EEXEC_OFF_POSITION:
      /* Need to see if this is a previously encrypted file or not.  If not I
         must not flush everything after count.  A few fonts (helvetica
         condensed) have some stuff to preserve... */
      i = (IntX)(count-streamBufFirst);
      if (!strncmp(streamBuf+i, "end", 3))
       { SendStreamBuf(count-streamBufFirst);
         /* Get rid of the extra "end" that plaintext files have, without nuking
            the following data (or spitting the "end" out). */
         if (4 < (IntX)streamBufTotal)
            os_memcpy(streamBuf, streamBuf+4, (Card16)(streamBufTotal-4));
         streamBufTotal -= 4;
         streamBufFirst += 4;
       } /* end if */
      else
         FlushStreamBuf(count - streamBufFirst); /* Send the unencrypted data */

      if (pStreamerOpts->eexec != ST_NO_ENCRYPTION)
       { BufferStringEOL((Card8 *)"mark currentfile closefile");
 
         BufferFlush();
         BufferSetEEKey(0, ST_NO_ENCRYPTION);      /* Turn off encryption */

         BufferStringEOL((Card8 *)"");
         for (i = 0; i < 8; i++)                   /* Write 512 ascii zeroes */
            BufferStringEOL((Card8 *)"0000000000000000000000000000000000000000000000000000000000000000");
         BufferStringEOL((Card8 *)"cleartomark");           /* Say bye bye */
       } /* end if */
      else
         BufferStringEOL((Card8 *)"end");     /* "end" for systemdict begin */


      break;

   /* The user can supply a different encoding */
   case ENCODING_POSITION:
      FlushStreamBuf(count-streamBufFirst-2);
      code = StreamEncoding(pFont, (Card8)pFont->hasStandardEncoding);
      if (code != ST_NOERR)
         return false;
      break;

   /* Sometimes the parse may need to backup--I need to keep my buffer in sync*/
   case BACKUP_POSITION:
      streamBufTotal--;	/* If streamBufTotal = 0 I'm hosed. */
      break;

   case ATTRIBS_POSITION:
      if (!pStreamerOpts->accessPrivateDict)
       { /* Flush the stream, including the attribute */
         FlushStreamBuf(streamBufTotal);
       } /* end if */
      else
         FlushStreamBuf(count-streamBufFirst);
      break;

   /* I need to ensure lenIV gets into the font so I do this in the case
      dealing with PRIVATE_POSITION.  So if, on the rare occasion it 
      occurs, lenIV is already in the font I'll just end up duplicating
      it.  (It's easier than trying to remove it). */
   case LENIV_POSITION:
      FlushStreamBuf(count-streamBufFirst);
      BufferString((Card8 *)"lenIV ");
      BufferInt(pStreamerOpts->lenIV);
      BufferChar(' ');	/* the "def" will be supplied by the parser... */
      break;

   /* I need to add a couple items to the private dictionary... */
   case PRIVATE_POSITION:
      /* See if I need to add or delete the encryption notification */
      FlushStreamBuf(count-streamBufFirst);
      BufferStringEOL((Card8 *)"/RD {string currentfile exch readstring pop} executeonly def");
      BufferStringEOL((Card8 *)"/ND {noaccess def} executeonly def");
      BufferStringEOL((Card8 *)"/NP {noaccess put} executeonly def");
      /* Note that I ALWAYS send out the lenIV field here, even if it's 4.
         This is because I already told the Private dict (in the parser)
         that I was adding exactly 4 entries. */
      BufferString((Card8 *)"/lenIV ");
      BufferInt(pStreamerOpts->lenIV);
      BufferStringEOL((Card8 *)" def");
      break;

   /* I need to add some breadcrumbs to the FontInfo dictionary. */
   case FONTINFO_POSITION:
      FlushStreamBuf(count-streamBufFirst);

      /* This "breadcrumb" is the real clue that streamer processed the file.  
         In all files streamer touches it will add this entry.  */
      BufferString((Card8 *)"/BaseFontName /");
      BufferString((Card8 *)pFont->fontName);
      BufferStringEOL((Card8 *)" def");
      break;
      
 } /* end switch */

return true;
} /* end KeyPosition() */


  /* Abort if the font is a hybrid font */
PRIVATE boolean FontAttribute ARGDEF1(Card16, type)
{
	return ( type == ST_HYBRID_FONT ) ? 0 : 1;
} /* end FontAttribute() */

/*************************************************************************

Function name:  StreamCompleteFont()

**************************************************************************

Date:           05/23/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream the complete font, including any generic PostScript
Description:    This routine streams a font file allowing the user to
                modify a couple fields.  It is used because often fonts
                contain "generic" PostScript which is not recognized by the
                parser but needs to passed through (for printers, perhaps).
                Fields the user can change include: subrs, charstrings,
                encoding, uid, font name, full name, and encryption.
                
Parameters:     fp -- the font pointer containing the info on the font.
 		s -- the streamer options.
		charOpts -- the charstring options.
		b - the initial buffer status.
		fi - the faux font options (not actually used here).
		GetBytes - the callback used to get the font data.
Return Values:  
Notes:          This routine is used as a 2nd pass through the data.  It 
                is assumed that the first pass gathered the data into fp.
See also:       

**************************************************************************/

PUBLIC IntX StreamCompleteFont ARGDEF6(T1FontPointer, fp, PStreamerOpts, s,
       CharStrOpts *, charOpts, PBufferStatus, b, FauxInfoPointer, fi,
       GetBytesFunc, GetBytes)
{
IntX code;
T1FontPointer dummyFp = NULL;/* Don't care about data--I got what I needed the 
                           first time through the font (in fp). */

streamBufTotal = 0;
streamBufFirst = 0;

/* I'll need these variables in the callbacks but I cann't easily pass
   them in, so here I create copies. */
pFont = fp;
pStreamerOpts = s;
pCharOpts = charOpts;
pBufferStatus = b;
pFauxInfo = fi;

code = T1FontParse(&dummyFp, GetBytes, DummyAllocChars, DummyCharString, 
                   DummyAllocSubrs, DummySubroutine, FontDataStream,
                   KeyPosition, FontAttribute);

if (dummyFp)
   T1FontRelease(&dummyFp); /* Make sure this memory is freed */

return code;
} /* end StreamCompleteFont() */




