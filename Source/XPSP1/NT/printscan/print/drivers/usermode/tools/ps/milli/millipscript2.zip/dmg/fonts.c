/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: FONTS.C                                                      */
/*                                                                           */
/* Description: This module contains the functions for the Fonts Options     */
/*              Property sheet Dialog Box                                    */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "apd42map.hh"

#pragma code_seg(_FONTSDIALOGSEG)

#define MAX_THRESHOLD   9999
#define MIN_THRESHOLD   0

/*****************************************************************************/
/*                 GetTTSendAsString                                         */
/* Purpose:                                                                  */
/*   Gets the Send As string appropriate to the currently selected Send As   */
/*   option.                                                                 */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the fonts dialog                                 */
/*   LPSTR lpSendAsBuffer -- buffer to receive the Send As prefix string     */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL
GetTTSendAsString(HWND hDlg, int iFormat, LPSTR lpSendAsBuffer)
{
    int  iStringID;
    int  nLength;

    switch(iFormat)
    {
        case TT_DLFORMAT_TYPE1:
            iStringID=IDS_TYPE_1;
            break;

        case TT_DLFORMAT_TYPE3:
            iStringID=IDS_TYPE_3;
            break;

        case TT_DLFORMAT_TYPE42:
            iStringID=IDS_TYPE_42;
            break;

        case TT_DLFORMAT_TRUEIMAGE:
            iStringID=IDS_TRUEIMAGE;
            break;

        default:
            iStringID=IDS_DONT_SEND;
            break;
    }

    if (iStringID==IDS_DONT_SEND)
        nLength = LoadString(ghDriverMod, IDS_DONT_SEND_PREFIX,
                             lpSendAsBuffer, STR_BUFF_LEN);
    else
        nLength = LoadString(ghDriverMod, IDS_SEND_AS_PREFIX,
                             lpSendAsBuffer, STR_BUFF_LEN);

    LoadString(ghDriverMod,iStringID,lpSendAsBuffer+nLength,
               STR_BUFF_LEN-nLength);
}

BOOL FAR PASCAL ATMProperlyLoaded()
{
    return FALSE;
}


/*****************************************************************************/
/*                 ReadSendAsStateFromWinIni                                 */
/* Purpose:                                                                  */
/*   Set up list boxes and combo  boxes in the fonts Send As Dialog Box      */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to Font features dialog                             */
/*   LPDRIVERINFO lpDrvInfo -- pointer to DRIVERINFO structure               */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL
ReadSendAsStateFromWinIni(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    HWND hCtrl;
    char strBuff[STR_BUFF_LEN];
    int iTTSendAs, iTTSendAsSel;
    int iPSSendAs;
    int iRetVal;
    int iRasterizerType;
    int iIndex;
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;

    /* Fill in the send PS as list box */
    hCtrl = GetDlgItem(hDlg, ID_FONTS_SEND_PS_AS);
    SendMessage(hCtrl, CB_RESETCONTENT, 0, 0L);

    if (ATMProperlyLoaded())
    {
        LoadString(ghDriverMod, IDS_OUTLINES, strBuff, STR_BUFF_LEN);
        SendMessage(hCtrl, CB_ADDSTRING, 0, (LPARAM)(LPSTR)strBuff);
        SendMessage(hCtrl, CB_SETITEMDATA, 0, (LPARAM)PS_DLFORMAT_OUTLINES);

        LoadString(ghDriverMod, IDS_BITMAPS, strBuff, STR_BUFF_LEN);
        SendMessage(hCtrl, CB_ADDSTRING, 0, (LPARAM)(LPSTR)strBuff);
        SendMessage(hCtrl, CB_SETITEMDATA, 1, (LPARAM)PS_DLFORMAT_BITMAPS);
    }
    LoadString(ghDriverMod, IDS_NATIVE, strBuff, STR_BUFF_LEN);
    SendMessage(hCtrl, CB_ADDSTRING, 0, (LPARAM)(LPSTR)strBuff);

    LoadString(ghDriverMod, IDS_DONT_SEND, strBuff, STR_BUFF_LEN);
    SendMessage(hCtrl, CB_ADDSTRING, 0, (LPARAM)(LPSTR)strBuff);

    if (ATMProperlyLoaded())
    {
        SendMessage(hCtrl, CB_SETITEMDATA, 2, (LPARAM)PS_DLFORMAT_NATIVE);
        SendMessage(hCtrl, CB_SETITEMDATA, 3, (LPARAM)PS_DLFORMAT_DONT_SEND);
    }
    else
    {
        SendMessage(hCtrl, CB_SETITEMDATA, 0, (LPARAM)PS_DLFORMAT_NATIVE);
        SendMessage(hCtrl, CB_SETITEMDATA, 1, (LPARAM)PS_DLFORMAT_DONT_SEND);
    }

    /* Figure out the PS selection */
    iPSSendAs = lpPSExtDevmode->dm2.iPS_DLFontFmt;
    switch (iPSSendAs)
    {
        case PS_DLFORMAT_OUTLINES:
            LoadString(ghDriverMod, IDS_OUTLINES, strBuff, STR_BUFF_LEN);
            break;
        case PS_DLFORMAT_BITMAPS:
            LoadString(ghDriverMod, IDS_BITMAPS, strBuff, STR_BUFF_LEN);
            break;
        case PS_DLFORMAT_DONT_SEND:
            LoadString(ghDriverMod, IDS_DONT_SEND, strBuff, STR_BUFF_LEN);
            break;
        case PS_DLFORMAT_NATIVE:
        default:
            LoadString(ghDriverMod, IDS_NATIVE, strBuff, STR_BUFF_LEN);
            break;
    }
    iRetVal = (int)SendMessage(hCtrl, CB_SELECTSTRING, (WPARAM)-1,
                               (LPARAM)(LPSTR)strBuff);
    if (iRetVal == CB_ERR)
    {
        LoadString(ghDriverMod, IDS_NATIVE, strBuff, STR_BUFF_LEN);
        SendMessage(hCtrl, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)(LPSTR)strBuff);
    }

    /* Fill in the send TT as list box */
    hCtrl = GetDlgItem(hDlg, ID_FONTS_SEND_TT_AS);
    SendMessage(hCtrl, CB_RESETCONTENT, 0, 0L);

    /*
     * The order the strings are inserted is important
     * DrvState.TT_DLFormat assumes this order
     * 1. Don't Send, 2. Type 1, 3. Type 3, 4. Type 42
     */
    /* I changed the order as per Matt's instructions - John Kwan */

    LoadString(ghDriverMod, IDS_TYPE_1, strBuff, STR_BUFF_LEN);
    iIndex=LOWORD(SendMessage(hCtrl, CB_ADDSTRING, 0, (LPARAM)(LPSTR)strBuff));
    SendMessage(hCtrl,CB_SETITEMDATA,iIndex,TT_DLFORMAT_TYPE1);
    LoadString(ghDriverMod, IDS_TYPE_3, strBuff, STR_BUFF_LEN);
    iIndex=LOWORD(SendMessage(hCtrl, CB_ADDSTRING, 0, (LPARAM)(LPSTR)strBuff));
    SendMessage(hCtrl,CB_SETITEMDATA,iIndex,TT_DLFORMAT_TYPE3);

    iRasterizerType = GetRasterizerType(ghDriverMod, (lpDrvInfo->pDev.lpWPXblock),
                                        lpPSExtDevmode);
    switch (iRasterizerType)
    {
        case RASTERIZER_TYPE42:
            LoadString(ghDriverMod, IDS_TYPE_42, strBuff, STR_BUFF_LEN);
            iIndex=LOWORD(SendMessage(hCtrl, CB_ADDSTRING, 0,
                                      (LPARAM)(LPSTR)strBuff));
            SendMessage(hCtrl,CB_SETITEMDATA,iIndex,TT_DLFORMAT_TYPE42);
            break;
        case RASTERIZER_TRUEIMAGE:
            LoadString(ghDriverMod, IDS_TRUEIMAGE, strBuff, STR_BUFF_LEN);
            iIndex=LOWORD(SendMessage(hCtrl, CB_ADDSTRING, 0,
                                      (LPARAM)(LPSTR)strBuff));
            SendMessage(hCtrl,CB_SETITEMDATA,iIndex,TT_DLFORMAT_TRUEIMAGE);
            break;
        case RASTERIZER_NORMAL:
        default:
            break;
    }

    LoadString(ghDriverMod, IDS_DONT_SEND, strBuff, STR_BUFF_LEN);
    SendMessage(hCtrl, CB_ADDSTRING, 0, (LPARAM)(LPSTR)strBuff);

    /* This takes care of the mismatch of the saved parameter and the combo
       box order */
    iTTSendAs = lpPSExtDevmode->dm2.iDLFontFmt;
    switch (iTTSendAs)
    {
        case TT_DLFORMAT_TYPE1:
            iTTSendAsSel = TT_SEND_SEL_TYPE1;
            break;
        case TT_DLFORMAT_TYPE3:
            iTTSendAsSel = TT_SEND_SEL_TYPE3;
            break;
        case TT_DLFORMAT_TYPE42:
            iTTSendAsSel = TT_SEND_SEL_TYPE42;
            break;
        case TT_DLFORMAT_TRUEIMAGE:
            iTTSendAsSel = TT_SEND_SEL_TRUEIMAGE;
            break;
        default:
            if (iRasterizerType == RASTERIZER_TRUEIMAGE ||
                iRasterizerType == RASTERIZER_TYPE42)
                iTTSendAsSel = TT_SEND_SEL_NONE_TT;
            else
                iTTSendAsSel = TT_SEND_SEL_NONE_NO_TT;
            break;
    }
    SendMessage(hCtrl, CB_SETCURSEL, iTTSendAsSel, 0L);

    /* Set up other Send As item */
    CheckDlgButton(hDlg, ID_FONTS_FAVOR_TT, lpPSExtDevmode->dm2.bFavorTT);
    SetDlgItemInt(hDlg, ID_FONTS_THRESHOLD,
                  lpPSExtDevmode->dm2.iMinOutlinePPEM, FALSE);
}

/*****************************************************************************/
/*                 ReadFontStateFromWinIni                                   */
/* Purpose:                                                                  */
/*   Set up list boxes and combo  boxes in the fonts dialog box. Read in and */
/*   set up the TrueType to PostScript assignments.                          */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to Font features dialog                             */
/*   LPDRIVERINFO lpDrvInfo -- pointer to DRIVERINFO structure               */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL
ReadFontStateFromWinIni(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    char            strBuff[STR_BUFF_LEN];
    int             iTTSubs;
    LPPSEXTDEVMODE  lpPSExtDevmode;

    lpPSExtDevmode = lpDrvInfo->lpDM;

    /* Insert the Send As string */
    if (lpPSExtDevmode->dm2.iNumTTFamilies > 0) {
        GetTTSendAsString(hDlg, lpPSExtDevmode->dm2.iDLFontFmt, strBuff);
        AddPSFamily(hDlg, strBuff);
    }
    /* Set up the radio button */
    iTTSubs = lpPSExtDevmode->dm2.iTTSubsFmtSource;
    switch (iTTSubs)
    {
        case TTSUBSFORMAT_TABLE:
            CheckRadioButton(hDlg, ID_FONTS_USE_TABLE,
                             ID_FONTS_ALWAYS_DOWNLOAD_TT, ID_FONTS_USE_TABLE);
            break;
        case TTSUBSFORMAT_USEPRINTER:
            CheckRadioButton(hDlg, ID_FONTS_USE_TABLE,
                             ID_FONTS_ALWAYS_DOWNLOAD_TT,
                             ID_FONTS_USE_PRINTER_FONTS);
            break;
        case TTSUBSFORMAT_DOWNLOADTT:
            CheckRadioButton(hDlg, ID_FONTS_USE_TABLE,
                             ID_FONTS_ALWAYS_DOWNLOAD_TT,
                             ID_FONTS_ALWAYS_DOWNLOAD_TT);
            break;
    }
}


VOID NEAR PASCAL
NewTTFormat(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
   char szOldFamily[50];
   char szNewFamily[50];
   int active_TT = 0;
   LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;

   GetTTSendAsString(hDlg,lpPSExtDevmode->dm2.iDLFontFmt,szOldFamily);

   lpPSExtDevmode->dm2.iDLFontFmt=LOWORD(SendDlgItemMessage(
      hDlg,ID_FONTS_SEND_TT_AS,CB_GETITEMDATA,LOWORD(SendDlgItemMessage(
      hDlg,ID_FONTS_SEND_TT_AS,CB_GETCURSEL,NULL,NULL)),NULL));

   GetTTSendAsString(hDlg,lpPSExtDevmode->dm2.iDLFontFmt,szNewFamily);

   ReplacePSFamily(hDlg, szOldFamily, szNewFamily);
}

/*****************************************************************************/
/*                 RestoreFontsDefaults                                      */
/* Purpose:                                                                  */
/*   Procedure to restore fonts property sheet items to PPD defaults         */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPSEXTDEVMODE lpPSExtDevmode -- pointer to PSEXTDEVMODE structure      */
/*   LPPDEVICE lppd -- pointer to PDEVICE structure                          */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void FAR PASCAL RestoreFontsDefaults( LPPSEXTDEVMODE lpPSExtDevmode, LPPDEVICE lppd )
{
  LPPRINTERINFO  lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo;

  lpPSExtDevmode->dm2.iTTSubsFmtSource = TTSUBSFORMAT_TABLE;
  if( lpPrinterInfo->devcaps.iAdHasEuro != 0xFFFF )  // PPD has *ADHasEuro
     lpPSExtDevmode->dm2.bAddEuro = lpPrinterInfo->devcaps.iAdHasEuro != 1;
  else
     lpPSExtDevmode->dm2.bAddEuro = GetPSVersion(lppd) < 3011;

#ifdef PANEURO
    lpPSExtDevmode->dm.privateFlags |= SUPPRESS_DEVICEFNT_ENUM ;
#endif


}

///////////////////////////////////////////////////////
///// Also Called by OEMStubs.C to find out default Download type
int FAR PASCAL GetTTSendAsDefault(LPPSEXTDEVMODE lpPSExtDevmode, LPWPXBLOCKS lpWPXBlock)
{
  char strBuff[STR_BUFF_LEN];
  int iTTSendAs;
  TTRAST_OPT TTRasterizer;

    strBuff[0]='\0';
    iTTSendAs = TT_DLFORMAT_TYPE1;  // default if no localized string is found

    TTRasterizer = GetRasterizerType(ghDriverMod, lpWPXBlock, lpPSExtDevmode);
#if 0
  // If Type 42 available, default to Type42. -- bug 126394, 1-12-95, PPeng
  if ( TTRasterizer == TTRAST_TYPE42)
      iTTSendAs = TT_DLFORMAT_TYPE42;
#endif

  // For Far-east versions, look for prefered Default TT format in Resource
  // The reason is that some TT fonts have holes when converted to Type1, e.g. Taiwan
    if ( TTRasterizer == TTRAST_TYPE42){
       // For Type42-capable printers:
       LoadString(ghDriverMod, IDS_TT_DEF_DLFORMAT42, strBuff, STR_BUFF_LEN);
      }
    else{
       LoadString(ghDriverMod, IDS_TT_DEF_DLFORMAT, strBuff, STR_BUFF_LEN);
      }
    // notice the hard-coded "1","3","42" here - and warning in PSwriter.rc
    if      (!lstrcmpi(strBuff, "1"))  iTTSendAs = TT_DLFORMAT_TYPE1;
    else if (!lstrcmpi(strBuff, "3"))  iTTSendAs = TT_DLFORMAT_TYPE3;
    else if (!lstrcmpi(strBuff, "42")) iTTSendAs = TT_DLFORMAT_TYPE42;
    else ; // add more options here in the future.

    return iTTSendAs;
}


/*****************************************************************************/
/*                 RestoreSendAsDefaults                                     */
/* Purpose:                                                                  */
/*   Proceedure to restore Send As Dialog items to PPD defaults              */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPSEXTDEVMODE lpPSExtDevmode -- pointer to PSEXTDEVMODE structure      */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void FAR PASCAL
RestoreSendAsDefaults(LPPSEXTDEVMODE lpPSExtDevmode, LPWPXBLOCKS lpWPXBlock)
{
  lpPSExtDevmode->dm2.iDLFontFmt = GetTTSendAsDefault(lpPSExtDevmode, lpWPXBlock);

  lpPSExtDevmode->dm2.iPS_DLFontFmt = PS_DLFORMAT_NATIVE;
  lpPSExtDevmode->dm2.iMinOutlinePPEM  = 100;
  lpPSExtDevmode->dm2.bFavorTT = FALSE;
}


/*****************************************************************************/
/* InitFontsDlg                                                              */
/*                                                                           */
/* Purpose:                                                                  */
/*   Does the initial allocations specific for the fonts dialog. These       */
/*   memory handles allocated here are filled when the font substitution     */
/*   dialog box is created.                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- handle to the dialog box                                   */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE -- ok                                                              */
/*   FALSE -- error                                                          */
/*****************************************************************************/
static BOOL NEAR
InitFontsDialog(HWND hDlg)
{
  LPDRIVERINFO   lpDrvInfo;
  LPPSEXTDEVMODE lpPSExtDevmode;

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg, DWL_USER);
  lpPSExtDevmode = lpDrvInfo->lpDM;

                                                  /* Initialize global data */
  lpPSExtDevmode->dm2.hPSFamilies    = GlobalAlloc(GHND|GMEM_DDESHARE, 0L);
  lpPSExtDevmode->dm2.iNumPSFamilies = 0;
  lpPSExtDevmode->dm2.hTTFamilies    = GlobalAlloc(GHND|GMEM_DDESHARE, 0L);
  lpPSExtDevmode->dm2.hTTAssignment  = GlobalAlloc(GHND|GMEM_DDESHARE, 0L);
  lpPSExtDevmode->dm2.iNumTTFamilies = 0;

  return(TRUE);
}

/*****************************************************************************/
/* DeinitFontsDialog                                                         */
/*                                                                           */
/* Purpose:                                                                  */
/*   To release all of the memory that was brought allocated in the          */
/*   InitFontsDialog() function.                                             */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- handle to the dialog box                                   */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

static void NEAR
DeinitFontsDialog(HWND hDlg)
{
  LPDRIVERINFO   lpDrvInfo;
  LPPSEXTDEVMODE lpPSExtDevmode;

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER);
  lpPSExtDevmode = lpDrvInfo->lpDM;
                                                /* Free up the memory */
  if (lpPSExtDevmode->dm2.hPSFamilies)
    GlobalFree(lpPSExtDevmode->dm2.hPSFamilies);
  if (lpPSExtDevmode->dm2.hTTFamilies)
    GlobalFree(lpPSExtDevmode->dm2.hTTFamilies);
  if (lpPSExtDevmode->dm2.hTTAssignment)
    GlobalFree(lpPSExtDevmode->dm2.hTTAssignment);

  lpPSExtDevmode->dm2.hPSFamilies    = 0;
  lpPSExtDevmode->dm2.hTTFamilies    = 0;
  lpPSExtDevmode->dm2.hTTAssignment  = 0;
  lpPSExtDevmode->dm2.iNumPSFamilies = 0;
  lpPSExtDevmode->dm2.iNumTTFamilies = 0;
}
/*****************************************************************************/
/*                                                                           */
/* SaveFontAssignments                                                       */
/*                                                                           */
/* Purpose:                                                                  */
/*  Saves any changes made to the font assignment lists back to the          */
/*  win.ini file                                                             */
/*                                                                           */
/* Parameters:                                                               */
/*  HWND hDlg -- used to get at the devmode structures                       */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/
static void NEAR
SaveFontAssignments(HWND hDlg)
{
  HCURSOR       hOldCursor;
  LPDRIVERINFO  lpDrvInfo;

  lpDrvInfo      = (LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER);

  if (lpDrvInfo->bSaveFontAssignments)
  {
    hOldCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
    WriteAssignmentToIni(hDlg, ghDriverMod);
    SetCursor(hOldCursor);

    lpDrvInfo->bSaveFontAssignments = 0;
  }
}

/*****************************************************************************/
/* ReinitFontsDialog                                                         */
/*                                                                           */
/* Purpose:                                                                  */
/*  This function is called when it is known that the data contained within  */
/*  the buffers held by this dialog is dirty - as would be if the fonts      */
/*  on the printer get changed. Remember that due to the length of time      */
/*  that it takes to grab all of the data, that we procrastinate intill      */
/*  it is actually needed, and then hold on to it intill the property        */
/*  dialog box is totally destroyed. This function is equivelent to          */
/*  destroying any data that may have been allocated, and then reinitializing*/
/*  it so that it can be regathered if called for.                           */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- handle to the dialog box                                   */
/*                                                                           */
/* Returns:                                                                  */
/*   Same as InitFontsDialog()                                               */
/*****************************************************************************/

static BOOL NEAR
ReinitFontsDialog(HWND hDlg)
{
  SaveFontAssignments(hDlg);
  DeinitFontsDialog(hDlg);
  return(InitFontsDialog(hDlg));
}

/*****************************************************************************/
/*                 CHFontsDlg                                                */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the Font Features property sheet dialog box.      */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL
CHFontsDlg(HWND hDlg, unsigned imsg, WORD wParam, LONG lParam)
{
    LPDRIVERINFO    lpDrvInfo;
    LPPSEXTDEVMODE  lpPSExtDevmode;
    int             status   = RC_ok;
    BOOL            result   = TRUE;
    BOOL            bChanged = FALSE;

    if (lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
    {
#ifdef USEHOOKPROC                          /* Process hook function stuff */
        if(DrvProcessHookProc(&(lpDrvInfo->pDev), hDlg, imsg,
                              wParam,lParam, "HookSetup"))
            return TRUE;
#endif
        lpPSExtDevmode = lpDrvInfo->lpDM;
    }

    switch (imsg)
    {
        case WM_INITDIALOG:
            lpDrvInfo=(LPDRIVERINFO)(((LPPROPSHEETPAGE)lParam)->lParam);
            SetWindowLong(hDlg,DWL_USER,(LPARAM)lpDrvInfo);
            lpPSExtDevmode=lpDrvInfo->lpDM;
            lpDrvInfo->bPainting = TRUE;

            InitFontsDialog(hDlg);
            ReadFontStateFromWinIni(hDlg, lpDrvInfo);
            lpDrvInfo->bPainting = FALSE;
            CheckDlgButton(hDlg,ID_FONTS_ADD_EURO,lpPSExtDevmode->dm2.bAddEuro);
#ifdef PANEURO
            CheckDlgButton(hDlg,ID_SUPPRESS_DEVFONTS,
                lpPSExtDevmode->dm.privateFlags & SUPPRESS_DEVICEFNT_ENUM);
#endif
#ifdef PSDEBUG // Following controls are for testing only
            CheckDlgButton(hDlg,ID_PREF_CHAR, !(lpPSExtDevmode->dm2.bTrueTypeWide));
            CheckDlgButton(hDlg,ID_PREF_WHOLE, lpPSExtDevmode->dm2.bFullDown);
            CheckDlgButton(hDlg,ID_PREF_FAST, lpPSExtDevmode->dm2.bTrueTypeFast);
            CheckDlgButton(hDlg,ID_PREF_EUDC, lpPSExtDevmode->dm2.bEUDCAble);
            EnableWindow(GetDlgItem(hDlg,ID_PREF_FAST),
                  (!(IsDlgButtonChecked(hDlg, ID_PREF_CHAR)) &&
                  !(IsDlgButtonChecked(hDlg, ID_PREF_WHOLE))) );
#endif
            break ;

        case WM_CONTEXTMENU:
            if (wParam != -1)
            {
                WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                        (DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_HELP:
            if (((LPHELPINFO) lParam)->hItemHandle != -1)
            {
                WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                        HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
            }
            break;


        case WM_NOTIFY:
            switch (NOTIFY_CODE(lParam))
            {
                case PSN_KILLACTIVE:
#ifdef PANEURO
                    if (IsDlgButtonChecked(hDlg, ID_SUPPRESS_DEVFONTS))
                        lpPSExtDevmode->dm.privateFlags |= SUPPRESS_DEVICEFNT_ENUM;
                    else
                        lpPSExtDevmode->dm.privateFlags &= ~SUPPRESS_DEVICEFNT_ENUM;
#endif
#ifdef PSDEBUG    // following controls are for testing only
                    lpPSExtDevmode->dm2.bTrueTypeWide =
                             !(IsDlgButtonChecked(hDlg, ID_PREF_CHAR));
                    lpPSExtDevmode->dm2.bFullDown =
                             IsDlgButtonChecked(hDlg, ID_PREF_WHOLE);
                    lpPSExtDevmode->dm2.bTrueTypeFast =
                             IsDlgButtonChecked(hDlg, ID_PREF_FAST);
                    lpPSExtDevmode->dm2.bEUDCAble =
                             IsDlgButtonChecked(hDlg, ID_PREF_EUDC);
#endif
                    break;

                case PSN_APPLY:
                    /* Write out substitutions if necessary */
                    SaveFontAssignments(hDlg);

                    if (lpDrvInfo->bChanged)
                    {
                        UpdateGlobal(lpDrvInfo,TRUE);
                        WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
                        lpDrvInfo->bChanged = FALSE;
                    }
                    break;

                case PSN_RESET:
                    DeinitFontsDialog(hDlg);        /* frees up the memory  */
                    lpDrvInfo->lpDM=&(lpDrvInfo->DMSave);
                    WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
                    break;

//                case PSN_HASHELP:
//                    SetWindowLong(hDlg,DWL_MSGRESULT,TRUE);
//                    break;

//                case PSN_HELP:
//                    WinHelp(hDlg,szHelpFile,HELP_CONTEXT,NULL);
//                    break;
            }
            break;

        case WM_COMMAND:
            switch (wParam)
            {
                case ID_RESTORE_DEFAULTS:
                    RestoreFontsDefaults(lpPSExtDevmode, &(lpDrvInfo->pDev));
                    ReadFontStateFromWinIni(hDlg, lpDrvInfo);
                    CheckDlgButton(hDlg,ID_FONTS_ADD_EURO,lpPSExtDevmode->dm2.bAddEuro);
#ifdef PANEURO
                    CheckDlgButton(hDlg,ID_SUPPRESS_DEVFONTS,
                        lpPSExtDevmode->dm.privateFlags & SUPPRESS_DEVICEFNT_ENUM);
#endif
#ifdef PSDEBUG
                    CheckDlgButton(hDlg,ID_PREF_CHAR, FALSE); // default to use Glyph-index
                    CheckDlgButton(hDlg,ID_PREF_WHOLE, FALSE); // default to incremental
                    CheckDlgButton(hDlg,ID_PREF_FAST, TRUE);
                    CheckDlgButton(hDlg,ID_PREF_EUDC, FALSE);
#endif
                    bChanged = TRUE;
                    break;

                case ID_ABOUT:
                    DialogBoxParam(ghDriverMod,"AB",hDlg,
                                   fnAboutDlg, (LPARAM)lpDrvInfo);
                    break;

                case ID_FONTS_EDIT_TABLE:
                    if (lpPSExtDevmode->dm2.iNumTTFamilies == 0)
                        GetAllFamilies(hDlg, 1);
                    ReadFontStateFromWinIni(hDlg, lpDrvInfo);

                    if (DialogBoxParam(ghDriverMod,"CH_SUBSTITUTION_TABLE",hDlg,
                                       CHFontSubstitutionDlg,
                                       (LPARAM)lpDrvInfo) == IDOK)
                        bChanged = TRUE;
                    break;

                case ID_FONTS_SEND_TT_AS_PB:
                    if (DialogBoxParam(ghDriverMod,"CH_SEND_AS",hDlg,
                                       CHSendAsDlg,
                                       (LPARAM)lpDrvInfo) == IDOK)
                        bChanged = TRUE;
                    break;

                case ID_FONTS_USE_TABLE:
                    lpPSExtDevmode->dm2.iTTSubsFmtSource = TTSUBSFORMAT_TABLE;
                    bChanged = TRUE;
                    break;
                case ID_FONTS_USE_PRINTER_FONTS:
                    lpPSExtDevmode->dm2.iTTSubsFmtSource =
                        TTSUBSFORMAT_USEPRINTER;
                    bChanged = TRUE;
                    break;
                case ID_FONTS_ALWAYS_DOWNLOAD_TT:
                    lpPSExtDevmode->dm2.iTTSubsFmtSource =
                        TTSUBSFORMAT_DOWNLOADTT;
                    bChanged = TRUE;
                    break;

                case ID_FONTS_ADD_EURO:
                    lpPSExtDevmode->dm2.bAddEuro = IsDlgButtonChecked(hDlg,ID_FONTS_ADD_EURO)?TRUE:FALSE;
                    bChanged = TRUE;
                    break;

#ifdef PANEURO
                case ID_SUPPRESS_DEVFONTS:
                    if (HIWORD(lParam) == BN_CLICKED)
                        bChanged = TRUE;
                    break;
#endif

#ifdef PSDEBUG
                case ID_PREF_CHAR:
                case ID_PREF_WHOLE:
                case ID_PREF_FAST:
                case ID_PREF_EUDC:
                    if (HIWORD(lParam) == BN_CLICKED){
                        bChanged = TRUE;
                        EnableWindow(GetDlgItem(hDlg,ID_PREF_FAST),
                             (!(IsDlgButtonChecked(hDlg, ID_PREF_CHAR)) &&
                             !(IsDlgButtonChecked(hDlg, ID_PREF_WHOLE))));
                    }
                    break;
#endif
                case ID_FONTS_UPDATE:
                    ReinitFontsDialog(hDlg);    /* get rid of cached lists  */
                                                /* Update softfont cache    */
                                                /* delete MFD files from   */
                                                /* disk as well            */
                    UpdateSoftFonts(lpDrvInfo->pDev.lpPSExtDevmode->dm.dm.dmDeviceName);
                    break;


#ifndef USE_WHATSTHIS_HELP
                case ID_HELP:
                    WinHelp(hDlg, szHelpFile, HELP_CONTEXT,
                            IDH_PSCRIPT_PRINTING_FONTS);
                    break;
#endif
                default:
                    result = FALSE;
                    break;
            }
            break;

        default:
            result = FALSE;
            break;
    } /* switch(imsg) */

    if (bChanged && lpDrvInfo && !lpDrvInfo->bChanged && !lpDrvInfo->bPainting)
    {
        lpDrvInfo->bChanged = TRUE;
        PropSheet_Changed( GetParent(hDlg), hDlg );
    }
    return(result);
}

/*****************************************************************************/
/*      CreatePrinterIC                                                      */
/*                                                                           */
/* Purpose:                                                                  */
/*   Returns a printer IC - used to enumerate fonts.                         */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPDEVICE lppd -- printer device                                        */
/*                                                                           */
/* Returns: HDC of printer                                                   */
/*                                                                           */
/*****************************************************************************/

static HDC NEAR
CreatePrinterIC(LPDRIVERINFO lpDrvInfo)
{
  HDC            hDC;
  LPPSEXTDEVMODE lpPSExtDevmode;
  LPPDEVICE      lppd;
  HCURSOR        hCursor;
  char           szDriver[_MAX_FNAME], szFilename[256];

  lpPSExtDevmode = lpDrvInfo->lpDM;
  lppd           = &lpDrvInfo->pDev;

  GetModuleFileName(ghDriverMod, szFilename, sizeof(szFilename));
  _splitpath(szFilename, NULL, NULL, szDriver, NULL);

  hCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));   /* this may take time   */
  hDC = CreateIC(szDriver,
                 lpPSExtDevmode->dm.dm.dmDeviceName,
                 lppd->szPortName,
                 NULL);
  SetCursor(hCursor);

  return(hDC);
}


/*****************************************************************************/
/*              WarnIfNotCompatable                                          */
/*                                                                           */
/* Purpose:                                                                  */
/*   To check if the Truetype and Postscript fonts have compatible           */
/*   (intersecting) lfCharsets and warn the user if not.                     */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- dialog box handle                                          */
/*   WORD wId  -- dialog item to set focus before bringing up message box    */
/*   int iTT -- index to currently selected truetype font                    */
/*   int iPS -- index to currently selected postscript font                  */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE: comparison is ok or accepted by the user                          */
/*   FALSE: do not accept this match                                         */
/*****************************************************************************/

static BOOL NEAR
WarnIfNotCompatable(HWND hDlg, WPARAM wId, int iTT, int iPS)
{
    char            szTT[SHORT_BUFF_LEN], szPS[SHORT_BUFF_LEN];
    char            strBuff[256], strFmt[256], strTitle[SHORT_BUFF_LEN];

    *szTT = *szPS = 0;

    if (!CheckAssignment(hDlg, iTT, iPS, szTT, szPS)) {

        LoadString(ghDriverMod, IDS_FONT_NO_SUBSTITUTE,
                    strTitle, sizeof(strTitle));

                            /* this format string is something like:        */
                            /* "The characters of the TrueType font \"%s\"  */
                            /* and the Printer font \"%s\" are not          */
                            /* compatible.\n\nDo you still wish to keep     */
                            /* the selection ?"                             */

        LoadString(ghDriverMod, IDS_CHARSET_INCOMPATIBLE,
                    strFmt, sizeof(strFmt));
        wsprintf((LPSTR)strBuff, strFmt, (LPSTR)szTT, (LPSTR)szPS);

        SetFocus(GetDlgItem(hDlg, wId));
        if (MessageBox(hDlg, strBuff, strTitle,
                    MB_YESNO|MB_ICONQUESTION) != IDYES) {
            return(FALSE);
        }
    }

    return(TRUE);
}

/*****************************************************************************/
/*                 CHFontSubstitutionDlg                                     */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the Font Substitution Dialog                     */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL
CHFontSubstitutionDlg(HWND hDlg, unsigned imsg, WORD wParam, LONG lParam)
{
    LPDRIVERINFO    lpDrvInfo;
    LPPSEXTDEVMODE  lpPSExtDevmode;
    HWND            hCtrl;
    int             active_TT;
    DWORD           dwSize;
    LPINT           lpTTTable, lpBackupTable;

    if (lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
        lpPSExtDevmode = lpDrvInfo->lpDM;

    switch (imsg)
    {
        case WM_INITDIALOG:     /* depends on GetAllFamilies() called prior */

            lpDrvInfo = (LPDRIVERINFO)lParam;
            SetWindowLong(hDlg,DWL_USER,(LPARAM)lpDrvInfo);
            lpPSExtDevmode = lpDrvInfo->lpDM;

                                      /* this DC is created first time used */
            lpPSExtDevmode->dm2.hDCPrinter = (WORD)-1;

            if (lpPSExtDevmode->dm2.iNumTTFamilies > 0)
            {
                /*
                 * Read in the assignments if we haven't already read
                 * them in and marked them for saving.
                 */
                if (!lpDrvInfo->bSaveFontAssignments)
                    ReadAssignmentFromIni(hDlg, ghDriverMod);

                /* Backup the assignment table */
                dwSize = GlobalSize(lpPSExtDevmode->dm2.hTTAssignment);
                lpDrvInfo->hSavedDevmode = GlobalAlloc(GHND, dwSize);
                lpBackupTable = (LPINT)GlobalLock(lpDrvInfo->hSavedDevmode);
                lpTTTable = (LPINT)GlobalLock(lpPSExtDevmode->dm2.hTTAssignment);
                if (lpBackupTable)
                    MemCopy((LPVOID)lpBackupTable, (LPVOID)lpTTTable, dwSize);
                GlobalUnlock(lpPSExtDevmode->dm2.hTTAssignment);
                GlobalUnlock(lpDrvInfo->hSavedDevmode);

                /* Fill in the combo box for the active substitution */
                FillPSComboBox(hDlg, ID_ACTIVE_SUBS);

                /* Fill in the substitutions list, assignments must be known
                   by this point */
                FillSubsList(hDlg, 0, TRUE);
            }
            else
            { /* No TT Families */
                hCtrl = GetDlgItem(hDlg, ID_FONTS_LISTBOX);
                ShowWindow(hCtrl, SW_HIDE);
                hCtrl = GetDlgItem(hDlg, ID_ACTIVE_TT);
                ShowWindow(hCtrl, SW_HIDE);
                hCtrl = GetDlgItem(hDlg, ID_ACTIVE_SUBS);
                ShowWindow(hCtrl, SW_HIDE);
            }
            break;

        case WM_CONTEXTMENU:
            if (wParam != -1)
            {
                WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                        (DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_HELP:
            if (((LPHELPINFO) lParam)->hItemHandle != -1)
            {
                WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                        HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                    lpDrvInfo->bSaveFontAssignments = TRUE;
                    // Fall through

                case IDCANCEL:
                    if (wParam == IDCANCEL)
                    {
                        /* Restore assignment table */
                        lpTTTable = (LPINT)GlobalLock(lpPSExtDevmode->dm2.hTTAssignment);
                        lpBackupTable =
                            (LPINT)GlobalLock(lpDrvInfo->hSavedDevmode);
                        dwSize = GlobalSize(lpPSExtDevmode->dm2.hTTAssignment);
                        if (lpBackupTable)
                            MemCopy((LPVOID)lpTTTable,
                                    (LPVOID)lpBackupTable,
                                    dwSize);
                        GlobalUnlock(lpPSExtDevmode->dm2.hTTAssignment);
                        GlobalUnlock(lpDrvInfo->hSavedDevmode);
                    }
                    if (lpDrvInfo->hSavedDevmode)
                        GlobalFree(lpDrvInfo->hSavedDevmode);

                                        /* delete the printer dc if created */
                    if (   lpPSExtDevmode->dm2.hDCPrinter
                        && lpPSExtDevmode->dm2.hDCPrinter != (WORD)-1)
                        DeleteDC(lpPSExtDevmode->dm2.hDCPrinter);

                    EndDialog(hDlg, wParam);
                    break;

#ifndef USE_WHATSTHIS_HELP
                case ID_HELP:
                    WinHelp(hDlg, szHelpFile, HELP_CONTEXT,
                            IDH_PSCRIPT_USE_SUB_TABLE);
                    break;
#endif

                case ID_RESTORE_DEFAULTS:
                    {
                        char strBuff[256], title[SHORT_BUFF_LEN];

                        LoadString(ghDriverMod, IDS_USE_DEFAULTS_TITLE,
                                   title, SHORT_BUFF_LEN);
                        LoadString(ghDriverMod, IDS_USE_DEFAULTS, strBuff, 256);
                        if (MessageBox(hDlg, strBuff, title,
                                       MB_YESNO|MB_ICONQUESTION) == IDYES)
                        {
                            active_TT = (int)SendDlgItemMessage(hDlg,
                                                        ID_FONTS_LISTBOX,
                                                        LB_GETCURSEL,0,0L);
                            SetDefaultAssignments(hDlg, ghDriverMod);
                            FillSubsList(hDlg, active_TT, TRUE);
                        }
                    }
                    break;

                case ID_FONTS_LISTBOX:
                    if (HIWORD(lParam) == LBN_SELCHANGE)
                    {
                        active_TT = (int)SendDlgItemMessage(hDlg,
                                                            ID_FONTS_LISTBOX,
                                                            LB_GETCURSEL,0,0L);

                        FillSubsList(hDlg, active_TT, FALSE);
                    }
                    break;

                case ID_ACTIVE_SUBS:
                {
                    static int iOldAssignment, block = 0;
                    int        iCurAssignment, brk;

                    switch(HIWORD(lParam)) {
                        case CBN_SELCHANGE:
                        case CBN_SETFOCUS:
                        case CBN_KILLFOCUS:
                        case CBN_CLOSEUP:
                            active_TT = (int)SendDlgItemMessage(hDlg,
                                                        ID_FONTS_LISTBOX,
                                                        LB_GETCURSEL,0,0L);
                            iCurAssignment = (int)SendDlgItemMessage(hDlg,
                                                        ID_ACTIVE_SUBS,
                                                        CB_GETCURSEL,
                                                        0, 0L);
                            switch(HIWORD(lParam)) {
                                case CBN_SETFOCUS:
                                    if (!block)
                                        iOldAssignment = iCurAssignment;
                                    break;
                                case CBN_KILLFOCUS:
                                case CBN_CLOSEUP:
                                    if (block)
                                        break;          /* no rentrency     */

                                    if (iCurAssignment == iOldAssignment)
                                        break;
                                    block = 1;          /* avoid renterncy  */

                                                /* optimization: create the */
                                                /* DC the first time it is  */
                                                /* needed - can be ssllooww */

                                    if (lpPSExtDevmode->dm2.hDCPrinter == (WORD)-1)
                                    {
                                        lpPSExtDevmode->dm2.hDCPrinter =
                                            CreatePrinterIC(lpDrvInfo);
                                    }
                                    brk = WarnIfNotCompatable(hDlg, wParam,
                                                              active_TT,
                                                              iCurAssignment);
                                    block = 0;
                                    if (brk) {
                                        iOldAssignment = iCurAssignment;
                                        break;
                                    }
                                    iCurAssignment = iOldAssignment;
                                                            /* vv FALL vv   */
                                case CBN_SELCHANGE:         /* ^^ FELL ^^   */
                                    SetAssignment(hDlg, active_TT,
                                                        iCurAssignment);
                                    FillSubsList(hDlg, active_TT, FALSE);
                                    break;
                            }
                        default:
                            break;
                    }
                    return (TRUE);
                    break;
                }
                default:
                    return(FALSE);
            } /* switch(wParam) */
            break ;

        default:
            return(FALSE);
    } /* switch(imsg) */

    return(TRUE);
}

/*****************************************************************************/
/*                 CHSendAsDlg                                               */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the Send Font As Dialog                          */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL
CHSendAsDlg(HWND hDlg, unsigned imsg, WORD wParam, LONG lParam)
{
    LPDRIVERINFO lpDrvInfo;
    LPPSEXTDEVMODE lpPSExtDevmode, lpPSExtSavedDevmode;
    BOOL bTranslated;
    int iPSSendAsSel, iPSSendAs, temp;

    if (lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
    {
        lpPSExtDevmode = lpDrvInfo->lpDM;
    }

    switch (imsg)
    {
        case WM_INITDIALOG:
            lpDrvInfo=(LPDRIVERINFO)lParam;
            SetWindowLong(hDlg,DWL_USER,(LPARAM)lpDrvInfo);
            lpPSExtDevmode=lpDrvInfo->lpDM;

            lpDrvInfo->hSavedDevmode = GlobalAlloc(GHND, sizeof(PSEXTDEVMODE));
            lpPSExtSavedDevmode =
                (LPPSEXTDEVMODE)GlobalLock(lpDrvInfo->hSavedDevmode);
            *lpPSExtSavedDevmode = *lpPSExtDevmode;
            GlobalUnlock(lpDrvInfo->hSavedDevmode);

            // limit the edit box length of the text to 4
            SendDlgItemMessage(hDlg, ID_FONTS_THRESHOLD, EM_LIMITTEXT, 4, 0L);
            // Fix bug 122507 jjia 4/29/96
            SendDlgItemMessage(hDlg, ID_FONTS_THRESHOLD_SPN, UDM_SETRANGE, NULL,
                           MAKELPARAM(MAX_THRESHOLD, MIN_THRESHOLD));

            ReadSendAsStateFromWinIni(hDlg, lpDrvInfo);
            break;

        case WM_CONTEXTMENU:
            if (wParam != -1)
            {
                WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                        (DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_HELP:
            if (((LPHELPINFO) lParam)->hItemHandle != -1)
            {
                WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                        HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                    /* Read in Favor TT flag */
                    lpPSExtDevmode->dm2.bFavorTT =
                        IsDlgButtonChecked(hDlg,ID_FONTS_FAVOR_TT);

                    {
                       // Read in threshold value and check if valid.
                       int   i;

                       i = GetDlgItemInt(hDlg, ID_FONTS_THRESHOLD, &bTranslated, FALSE);
                       if(!bTranslated)
                       {
                          // Failed to translate edit control's text to int.
                          // Failure usually is caused by a ',' which spin
                          // control added automatically when the value is
                          // greater than 999. So try to use spin control to
                          // get the current value instead.
                          i = (int)SendDlgItemMessage(hDlg, ID_FONTS_THRESHOLD_SPN,
                                                 UDM_GETPOS, 0, 0L);
                       }

                       if(i > MAX_THRESHOLD || i < MIN_THRESHOLD)
                       {
                           bTranslated = FALSE;
                           ShowErrorValueMessage(hDlg, ID_FONTS_THRESHOLD,
                                                 (long)MIN_THRESHOLD, (long)MAX_THRESHOLD);
                           return (bTranslated);
                        }
                        else
                        {
                           lpPSExtDevmode->dm2.iMinOutlinePPEM = i;
                        }
                    }

                    GlobalFree(lpDrvInfo->hSavedDevmode);
                    EndDialog(hDlg, wParam) ;
                    break;

                case IDCANCEL:
                    /* Reset the Data */
                    lpPSExtSavedDevmode =
                        (LPPSEXTDEVMODE)GlobalLock(lpDrvInfo->hSavedDevmode);
                    *lpPSExtDevmode = *lpPSExtSavedDevmode;
                    GlobalUnlock(lpDrvInfo->hSavedDevmode);
                    GlobalFree(lpDrvInfo->hSavedDevmode);

                    /* Fix the Send As text */
                    if (lpPSExtDevmode->dm2.iNumTTFamilies > 0)
                    {
                        ReadSendAsStateFromWinIni(hDlg, lpDrvInfo);
                        NewTTFormat(hDlg,lpDrvInfo);
                    }
                    EndDialog(hDlg, wParam) ;
                    break ;

#ifndef USE_WHATSTHIS_HELP
                case ID_HELP:
                    WinHelp(hDlg, szHelpFile, HELP_CONTEXT, IDH_PSCRIPT_FONT_DWNLD);
                    break;
#endif

                case ID_RESTORE_DEFAULTS:
                    temp = lpPSExtDevmode->dm2.iDLFontFmt;
                    RestoreSendAsDefaults(lpPSExtDevmode, (lpDrvInfo->pDev.lpWPXblock) );
                    ReadSendAsStateFromWinIni(hDlg, lpDrvInfo);
                    lpPSExtDevmode->dm2.iDLFontFmt = temp;
                    NewTTFormat(hDlg,lpDrvInfo);
                    break;

                case ID_FONTS_SEND_TT_AS:
                    if(CBN_SELCHANGE==HIWORD(lParam))
                        NewTTFormat(hDlg,lpDrvInfo);
                    break;

                case ID_FONTS_SEND_PS_AS:
                    if(CBN_SELCHANGE==HIWORD(lParam))
                    {
                        iPSSendAsSel = (int)SendDlgItemMessage(hDlg,
                                                           ID_FONTS_SEND_PS_AS,
                                                           CB_GETCURSEL, 0, 0L);
                        iPSSendAs = (int)SendDlgItemMessage(hDlg,
                                                        ID_FONTS_SEND_PS_AS,
                                                        CB_GETITEMDATA,
                                                        iPSSendAsSel, 0L);
                        lpPSExtDevmode->dm2.iPS_DLFontFmt = iPSSendAs;
                    }
                    break;

                default:
                    return(FALSE);
            } /* switch(wParam) */
            break ;

        default:
            return(FALSE);
    } /* switch(imsg) */

    return(TRUE);
}
