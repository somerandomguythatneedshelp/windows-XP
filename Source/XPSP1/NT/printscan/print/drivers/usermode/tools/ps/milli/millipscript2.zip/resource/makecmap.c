
/****************************************************************************

    PROGRAM: makecmap.c

    PURPOSE: Create CMAP resource files based on ordering IDs (OIDs) for CJK

    Requires:  Global arrays for CJK-Encodings define din TRAN\ttfonts2.c

    FUNCTIONS:
        Define Global arrays for CJK-Encodings.

****************************************************************************/


// Include a C file here to get everything we need -!!!

#include "..\tran\ttfonts2.c"

HANDLE    hInst;  // global. so other procedures can use it.
HWND      hWnd;              

#define IDM_DOIT    501
#define IDM_DONE    502

#define MAX_CHARSET 10

int   CharSet[MAX_CHARSET]; // which charset's CMAP file to create, passed-in
char  OutputFile[MAX_CHARSET][128]; // output file name - e.g. cmap_B5.ps, passed-in
int   NumCharSet;  // Num of CMAP files to make

char      tmp[128]; // a tmp buffer;

long FAR PASCAL MainWndProc(HWND hWnd, WORD wMsg, WORD wParam,  LONG lParam);
BOOL SaveBufferToFile(HWND hWnd, LPSTR szFileName, HPBYTE hpBuf, DWORD dwSize);
int FAR PASCAL CreateCMAP(int charset, LPSTR lpszCMAP, WORD *wSize, int bVertical);

// Cmap header;
// Fill in CMapName -- used as a key in the resource dict.
// These three lines are not necessary if sent inside a Job. 
// %%!PS-Adobe-3.0 Resource-CMap 
// %% %%DocumentNeededResources: ProcSet (CIDInit)
// %% %%IncludeResource: ProcSet (CIDInit)

/* from nup.ps: We need this fix here for Min-headers using CID/42.
% Added the definition of /d as def in order to fix bug in Japanese printers
% which use | as part of the built-in procset for fonts manipulation. This 
% is in conflict with our definition of | as --def--.
% /| is now replaced by /d
*/

char CMAP_H0[]="\n#include \"psabbr.h\" \n#include \"psver.h\"\n\
%%%%BeginResource: file DSC_NAME(-CMAP-%s) PSVER \n";

char CMAP_H1[]="/CMAP-%s {\
\n";

// To fill in CmapName, CMapName, Registry, Ordering, Supplement, Version.
char CMAP_H2[]="%% %%BeginResource: CMap (%s)\n\
%% %%Title: (%s %s %s %d)\n\
%% %%Version: %d\n\
%% %%EndComments\n\n\
/CIDInit /ProcSet findresource begin\n\n\
12 dict begin \n\n\
begincmap \n\n";


// To fill in CMapName, CMapName, Registry, Ordering, Supplement, Version.

char CMAP_H3[]="/CIDSystemInfo <<\n\
  /Registry (%s) \n\
  /Ordering (%s) \n\
  /Supplement %d \n\
>> def\n\n\
/CMapName /%s def\n\
/CMapVersion %d def\n\
/CMapType %d def\n\n\
%% UIDs are optional\n\n\
/WMode %d def\n\n\n";

// Since this CMap will refer to more than one font, the CIDSystmInfo is an array
// Craig Rublee's Fix for Rearrangedfont bug with WMode. 3-12-1996
char CMAP_V3[]=
"%% Since this CMap will refer to more than one font, the CIDSystmInfo is an array\n\
%% Craig Rublee's Fix for Rearrangedfont bug with WMode. 3-12-1996\n\
/CIDSystemInfo [ <<\n\
  /Registry (%s) \n\
  /Ordering (%s) \n\
  /Supplement %d \n\
>> dup ] def\n\n\
/CMapName /%s def\n\
/CMapVersion %d def\n\
/CMapType %d def %% new mapType\n\n\
%% UIDs are optional\n\n\
/WMode %d def\n\n\n";

char CMAP_V4[]="%% define matrix for font 1. \n\
1 beginusematrix [0 -1 1 0 0 0] endusematrix   %% rotate Roman chars\n\
1 usefont\n\
%d begincidrange\n";


// CMAP Tail
char CMAP_T[]="endcmap\n\
CMapName currentdict /CMap defineresource pop\n\
end\nend\n%% %%EndResource\n} bind def\n";

// CMAP Tail
char CMAP_T1[]="%%%%EndResource\n";

char CMAP_USE[]="CMAP-%s  /%s usecmap\n\n";


/*--------------------------------------------------------------------------
  |   Function:   int PASCAL WinMain()  
  |   Parameters: (hInstance, hPrevInstance, lpCmdLine, nCmdShow)
  |   lpCmdLine format: "-cCharSet1 OutputFileName1 -cCharSet2 OutputFileName2 ..."
  |   Purpose:    Main procedure
  --------------------------------------------------------------------------*/
int PASCAL WinMain(HANDLE hInstance, HANDLE hPrevInstance,
				   LPSTR  lpCmdLine, int    nCmdShow)
  {
  WNDCLASS  WndClass;
  MSG       msg;                            
  char      szAppName[] = "CJK CMAP Creater";
  char      szClassName[] = "CJKCMAPCr";
  LPSTR     p; // a pointer
  int       i, j;
  

  // Only allow one instance of this program to run.
  if (!hPrevInstance)
	{
	// register the window class so we can create the window and
	// get the message queue.
	WndClass.style          = NULL;                  
	WndClass.lpfnWndProc    = (WNDPROC) MainWndProc;
	WndClass.cbClsExtra     = 0;                
	WndClass.cbWndExtra     = 0;                
	WndClass.hInstance      = hInstance;          
	WndClass.hIcon          = NULL;
	WndClass.hCursor        = LoadCursor(NULL, IDC_ARROW);
	WndClass.hbrBackground  = COLOR_WINDOW+1;
	WndClass.lpszMenuName   =  NULL;  
	WndClass.lpszClassName  = szClassName; 
	RegisterClass(&WndClass);
	}
  else
	// Just return if second instance.
	return(FALSE);

  hInst=hInstance;

  // In all honesty, we really don't care what the style of the
  // Window is since we don't show/display the window.
  hWnd  = CreateWindow(szClassName,               
						szAppName,  
						WS_OVERLAPPEDWINDOW,           
						0, 0, 1, 1,  
						NULL,                          
						NULL,                         
						hInstance,                     
						NULL);

   // We do care whether the windows was created or not.
   if (!hWnd)
	return (FALSE);

   // Parse the command line and save them in the global arrays CharSet and OutputFile[]
	i=0;
	p = lpCmdLine;
	while (p && *p){
	    if (*p == '-'){
	        p++;
	        p++; // skip c or C
	        j=0;
	        while( p && *p && *p!=' '){
	            tmp[j]=*p;
	            j++; p++;
	        }
	        tmp[j]='\0';
	        CharSet[i] = atoi((LPSTR)tmp);
	        while( p && *p && *p==' ' ) p++; // skip the spaces
	        j=0;
	        while( p && *p && *p!=' '){
	            OutputFile[i][j]=*p;
	            j++; p++;
	        }
            OutputFile[i][j]='\0';
	        i++; // next charset.
	    }
	    p++;
	}
	
	NumCharSet = i;
	
   // Send a message to my self: Just Do It !
	PostMessage(hWnd, WM_COMMAND, IDM_DOIT, 0L);

	while (GetMessage(&msg, NULL, NULL, NULL)) {
	   TranslateMessage(&msg);
	   DispatchMessage(&msg);
	   }
	return (msg.wParam);
}


/*--------------------------------------------------------------------------
  |   Function:   long FAR PASCAL MainWndProc()  
  |   Parameters: (HWND hWnd, WORD wMsg, WORD wParam, LONG lParam)
  |   Purpose:    We create the necessary CMAP file
  --------------------------------------------------------------------------*/
long FAR PASCAL MainWndProc(HWND hWnd, WORD wMsg, WORD wParam,  LONG lParam)
{
LPSTR lpszBuf;   // a buffer.
int   i;
WORD  wSize;

  switch (wMsg)
	{
	case WM_COMMAND:
	 switch (wParam) {
	  case IDM_DOIT:
        lpszBuf = (LPBYTE) GlobalAllocPtr(GHND, LIMIT_32K);  // 32K is enough!
        if (lpszBuf){
           for (i=0; i<NumCharSet;i++){
              // Fill in lpszbuff
              CreateCMAP(CharSet[i], lpszBuf, &wSize, 0);
              // Save to File
              SaveBufferToFile(hWnd, (LPSTR)OutputFile[i], (HPBYTE)lpszBuf, (DWORD)wSize);
              }
           }

        if (lpszBuf) GlobalFreePtr(lpszBuf);
  	    // I am DONE, send a message to close my self:
	    SendMessage(hWnd, WM_COMMAND, IDM_DONE, 0L);
  	    break;
  	    
	case IDM_DONE:
	  // Add whatever we want to do here.
	  // Just quit.
	  PostQuitMessage(0);
	  break;
	  }
	  break;

	
	case WM_DESTROY: 
	  PostQuitMessage(0);
	  break;

	default:                        
	  return (DefWindowProc(hWnd, wMsg, wParam, lParam));
	}
  return (0);
}


BOOL SaveBufferToFile(HWND hWnd, LPSTR szFileName, HPBYTE hpBuf, DWORD dwSize)
{
    BOOL bSuccess;
    long IOStatus;
    char szTemp[120];
    OFSTRUCT OfStruct;                        /* information from OpenFile()     */
    HFILE  hFile;

    if ((hFile = OpenFile(szFileName, &OfStruct,
        OF_CANCEL | OF_CREATE)) < 0) {

        /* If the file can't be saved */

        wsprintf(szTemp, "Cannot write to %s.", szFileName);
        MessageBox(hWnd, szTemp, NULL, MB_OK | MB_ICONHAND);
        return (FALSE);
    }

    /* Set the cursor to an hourglass during the file transfer */

    IOStatus = _hwrite(hFile, (HPBYTE)hpBuf, (long)dwSize);
    _lclose(hFile);
    if (IOStatus != (long)dwSize) {
        wsprintf(szTemp, "Error writing to %s.", szFileName);
        MessageBox(hWnd, szTemp,
            NULL, MB_OK | MB_ICONHAND);
        bSuccess = FALSE;
    }
    else {
        bSuccess = TRUE;                /* Indicates the file was saved      */
    }

    return (bSuccess);
}


// Passed-in lpszCMAP should be 16K long to hold all information.
int FAR PASCAL CreateCMAP(int charset, LPSTR lpszCMAP, WORD *wSize, int bVertical)
{
LPDBCSENCODE lpEncoding;
LPCMAPINFO  lpCMAPInfo, lpCMAPInfo_V;
char tmp[1024];
int i,j,k, cidstart, rlength, num100;
int needNotDef=FALSE;
LONG notDefx1, notDefx2;  // NOTdef CodeRange.
// Just like Win95, everything outof range is considered a SINGLE-Byte Notdef !!!
// <FE70>show becomes ".p"  - this is the case when the font is sent in Glyph-Index mode.

#define  CAT_STR(x, y, s) lstrcat((x), (y)); (s) += lstrlen(y);


    lpEncoding = GetEncoding((int)charset, 0);   // 0-means NoEUDC chars
    lpCMAPInfo = GetCMAPInfo((int)charset, 0);  // get horizontal one
    lpCMAPInfo_V = GetCMAPInfo((int)charset, 1);  // get Vertical one
    
    *wSize = 0; lpszCMAP[0]='\0';

// Header:
   wsprintf(tmp, CMAP_H0, lpCMAPInfo->Ordering);
   CAT_STR(lpszCMAP, tmp, *wSize);

// Horizontal CMAP   
   wsprintf(tmp, CMAP_H1, lpCMAPInfo->CMapName);
   CAT_STR(lpszCMAP, tmp, *wSize);    

   // for CMAP_H2, To fill in CmapName, CMapName, Registry, Ordering, Supplement, Version.
   wsprintf(tmp, CMAP_H2, lpCMAPInfo->CMapName, lpCMAPInfo->CMapName,
              lpCMAPInfo->Registry, lpCMAPInfo->Ordering, lpCMAPInfo->Supplement,
              lpCMAPInfo->CMapVersion);
   CAT_STR(lpszCMAP, tmp, *wSize);    

   // For CMAP_H3, To fill in Registry, Ordering, Supplement, CMAPName, Version, Type, bVertical.
   wsprintf(tmp, CMAP_H3, lpCMAPInfo->Registry, lpCMAPInfo->Ordering, lpCMAPInfo->Supplement,
              lpCMAPInfo->CMapName, lpCMAPInfo->CMapVersion,
              lpCMAPInfo->CMapType, 0);  // 0==Horizontal
   CAT_STR(lpszCMAP, tmp, *wSize);    

   // CodeSpaceRange
   // It should be 1+(int)lpEncoding->numSBRange+lpEncoding->numDBRange for
   // the extra NOTDef DByte range
   // <F040> <FCFC>  % Not def range for Shit-JIS
   // <FA31> <FEFE>
   // See DB ranges if we need a NOTDEF CodeRange

// remember :
// typedef struct tagDBCSRANGE
//  {
//  BYTE min_1;
//  BYTE max_1;    // range for Byte-1
//  BYTE min_2;
//  BYTE max_2;    // range for Byte-2
//  WORD start;    // base ID for this range
//  WORD end;      // IDs are [start, end-1].
// } DBCSRANGE;

   needNotDef = TRUE;
   for (i=0; i<lpEncoding->numDBRange; i++){
      // FF is the last notdef Single-Byte range for all languages
      // so we need notdef range only if FF is not covered.
      if ( (LONG)lpEncoding->DBCSRanges[i].max_1 >= 0xFF ) needNotDef=FALSE;
   }

   if (needNotDef){
      // Find the Notdefrange: Start with
      notDefx1 = 1 + (LONG) lpEncoding->DBCSRanges[0].max_1;  
      notDefx2 = (LONG) 0xFF;  // 0xFF is always NOTdef Single-Byte

      // Find the Notdefrange: Adjust notDefx1 if necessary
      for (i=0; i<lpEncoding->numDBRange; i++){
         if ( (LONG)lpEncoding->DBCSRanges[i].max_1 > notDefx1 )
            notDefx1 = 1+ (LONG)lpEncoding->DBCSRanges[i].max_1;
      }
   }

   // last chance to adjust
   if (notDefx2 < notDefx1) needNotDef=FALSE;

   if (needNotDef){
     wsprintf(tmp, "%d begincodespacerange\n", 1+(int)lpEncoding->numSBRange+lpEncoding->numDBRange);
     CAT_STR(lpszCMAP, tmp, *wSize);
    }
   else{
     wsprintf(tmp, "%d begincodespacerange\n", (int)lpEncoding->numSBRange+lpEncoding->numDBRange);
     CAT_STR(lpszCMAP, tmp, *wSize);
    }

   // Single-Byte ranges
   for (i=0; i<lpEncoding->numSBRange; i++){
      wsprintf(tmp, "  <%lX> <%lX>\n", (LONG)lpEncoding->SBRanges[i].min_1,
                                   (LONG)lpEncoding->SBRanges[i].max_1 );
      CAT_STR(lpszCMAP, tmp, *wSize);
   }

   // Output the Notdefrange:
   if (needNotDef){
      wsprintf(tmp, "  <%2.2lX> <%2.2lX>\n", 
                notDefx1, notDefx2);
      CAT_STR(lpszCMAP, tmp, *wSize);
   }


   // DB ranges
   for (i=0; i<lpEncoding->numDBRange; i++){
      wsprintf(tmp, "  <%lX%lX> <%lX%lX>\n", 
                (LONG)lpEncoding->DBCSRanges[i].min_1, (LONG)lpEncoding->DBCSRanges[i].min_2,
                (LONG)lpEncoding->DBCSRanges[i].max_1, (LONG)lpEncoding->DBCSRanges[i].max_2  );
      CAT_STR(lpszCMAP, tmp, *wSize);
   }


   wsprintf(tmp, "endcodespacerange\n\n");
   CAT_STR(lpszCMAP, tmp, *wSize);

// Map Single-byte-notdefs to "space" - half-width notdef
// 1 beginnotdefrange
// <00> <1f> 32   % the "space" is used as single byte NotDef
// endnotdefrange
// 1 begincidrange
// <20> <80> 32
// endcidrange
   
   wsprintf(tmp,
     "1 beginnotdefrange \n  <00> <1f> 32   %% the space is used as single byte NotDef\nendnotdefrange\n\n" );
   CAT_STR(lpszCMAP, tmp, *wSize);

   // cidrange - 1-byte
   wsprintf(tmp, "%d begincidrange\n", (int)lpEncoding->numSBRange);
   CAT_STR(lpszCMAP, tmp, *wSize);

   // 0-th is special - start from 32 ...
   wsprintf(tmp, "  <%lX> <%lX>  %d\n", (LONG)lpEncoding->SBRanges[0].min_1 + 32,
                                   (LONG)lpEncoding->SBRanges[0].max_1, lpEncoding->SBRanges[0].start+32);
   CAT_STR(lpszCMAP, tmp, *wSize);

   for (i=1; i<lpEncoding->numSBRange; i++){
      wsprintf(tmp, "  <%lX> <%lX>  %d\n", (LONG)lpEncoding->SBRanges[i].min_1,
                                   (LONG)lpEncoding->SBRanges[i].max_1, lpEncoding->SBRanges[i].start);
      CAT_STR(lpszCMAP, tmp, *wSize);
   }
   wsprintf(tmp, "endcidrange\n\n");
   CAT_STR(lpszCMAP, tmp, *wSize);

   // cidrange - 2-byte
   for (i=0; i<lpEncoding->numDBRange; i++){
      cidstart = lpEncoding->DBCSRanges[i].start;
      rlength = 1 + (int)(lpEncoding->DBCSRanges[i].max_2 - (int)lpEncoding->DBCSRanges[i].min_2); 
      num100 = 1 + (int)(lpEncoding->DBCSRanges[i].max_1 - (int)lpEncoding->DBCSRanges[i].min_1); 
      num100 = num100/100;

      // 100 ranges
      for (k=0; k<num100; k++){
         wsprintf(tmp, "100 begincidrange\n");
         CAT_STR(lpszCMAP, tmp, *wSize);
         for (j=k*100; j<(k+1)*100; j++){
            wsprintf(tmp, "  <%lX%lX> <%lX%lX>  %d\n", 
                          (LONG)lpEncoding->DBCSRanges[i].min_1+j, (LONG)lpEncoding->DBCSRanges[i].min_2, 
                          (LONG)lpEncoding->DBCSRanges[i].min_1+j, (LONG)lpEncoding->DBCSRanges[i].max_2,
                          cidstart);
            CAT_STR(lpszCMAP, tmp, *wSize);
            cidstart += rlength;
           }
         wsprintf(tmp, "endcidrange\n\n");
         CAT_STR(lpszCMAP, tmp, *wSize);
         }

       // remaining ranges:
       k = num100; // k is the num of whole 100 ranges. Always 0 or 1 (maximal 200 cidranges).
       num100 = 1 + (int)(lpEncoding->DBCSRanges[i].max_1 - (int)lpEncoding->DBCSRanges[i].min_1); 
       num100 = num100%100;
         wsprintf(tmp, "%d begincidrange\n", num100);
         CAT_STR(lpszCMAP, tmp, *wSize);
         for (j=k*100; j<k*100+num100; j++){
            wsprintf(tmp, "  <%lX%lX> <%lX%lX>  %d\n", 
                          (LONG)lpEncoding->DBCSRanges[i].min_1+j, (LONG)lpEncoding->DBCSRanges[i].min_2, 
                          (LONG)lpEncoding->DBCSRanges[i].min_1+j, (LONG)lpEncoding->DBCSRanges[i].max_2,
                          cidstart);
            CAT_STR(lpszCMAP, tmp, *wSize);
            cidstart += rlength;
           }
         wsprintf(tmp, "endcidrange\n\n");
         CAT_STR(lpszCMAP, tmp, *wSize);
      }

   wsprintf(tmp, CMAP_T);
   CAT_STR(lpszCMAP, tmp, *wSize);

// Vertical Version  - usecmap uses H version
   wsprintf(tmp, CMAP_H1, lpCMAPInfo_V->CMapName);
   CAT_STR(lpszCMAP, tmp, *wSize);    

   // for CMAP_H2, To fill in CmapName, CMapName, Registry, Ordering, Supplement, Version.
   wsprintf(tmp, CMAP_H2, lpCMAPInfo_V->CMapName, lpCMAPInfo_V->CMapName,
              lpCMAPInfo_V->Registry, lpCMAPInfo_V->Ordering, lpCMAPInfo_V->Supplement,
              lpCMAPInfo_V->CMapVersion);
   CAT_STR(lpszCMAP, tmp, *wSize);    

   wsprintf(tmp, CMAP_USE, lpCMAPInfo->CMapName, lpCMAPInfo->CMapName); // usecmap uses H-version
   CAT_STR(lpszCMAP, tmp, *wSize);    

   // For CMAP_V3, To fill in Registry, Ordering, Supplement, CMAPName, Version, Type, bVertical.
   wsprintf(tmp, CMAP_V3, lpCMAPInfo_V->Registry, lpCMAPInfo_V->Ordering, lpCMAPInfo_V->Supplement,
              lpCMAPInfo_V->CMapName, lpCMAPInfo_V->CMapVersion,
              lpCMAPInfo_V->CMapType, 1);  // 1=vertical
   CAT_STR(lpszCMAP, tmp, *wSize);    

   // For CMAP_V4, To begin Re-arranged cidrange - Single Byte ranges.
   wsprintf(tmp, CMAP_V4, (int)lpEncoding->numSBRange);
   CAT_STR(lpszCMAP, tmp, *wSize);
   // Re-arranged cidrange - 1-byte
   // 0-th is special - start from 32 ...
   wsprintf(tmp, "  <%lX> <%lX>  %d\n", (LONG)lpEncoding->SBRanges[0].min_1 + 32,
                                   (LONG)lpEncoding->SBRanges[0].max_1, lpEncoding->SBRanges[0].start+32);
   CAT_STR(lpszCMAP, tmp, *wSize);

   for (i=1; i<lpEncoding->numSBRange; i++){
      wsprintf(tmp, "  <%lX> <%lX>  %d\n", (LONG)lpEncoding->SBRanges[i].min_1,
                                   (LONG)lpEncoding->SBRanges[i].max_1, lpEncoding->SBRanges[i].start);
      CAT_STR(lpszCMAP, tmp, *wSize);
   }
   wsprintf(tmp, "endcidrange\n\n");
   CAT_STR(lpszCMAP, tmp, *wSize);

   wsprintf(tmp, "1 beginnotdefrange\n  <00> <1f> 32\n endnotdefrange\n\n");
   CAT_STR(lpszCMAP, tmp, *wSize);


   wsprintf(tmp, CMAP_T);
   CAT_STR(lpszCMAP, tmp, *wSize);
   
// Tail
   wsprintf(tmp, CMAP_T1);  // %%EndResource ...
   CAT_STR(lpszCMAP, tmp, *wSize);


  return 1;
}


