/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: GETCHARW.H                                                   */
/*                                                                           */
/* Description: Contains internal function prototype for GetCharWidth.       */
/*                                                                           */
/*****************************************************************************/

short _loadds FAR PASCAL DevGetCharWidth(LP lpDevice,LPSHORT lpsCharWidth,
                                         WORD sFirstChar,WORD sLastChar,
                                         LPPSFONTINFO lpFontInfo,
                                         LPDRAWMODE lpDrawMode,
                                         LPTEXTXFORM lpTextXForm);
