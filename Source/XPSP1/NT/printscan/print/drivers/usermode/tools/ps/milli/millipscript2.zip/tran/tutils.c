/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TUTILS.C                                                     */
/*                                                                           */
/* Description: This module contains the functions for                       */
/*                                                                           */
/* Change History:                                                           */
/* L3_CLIP -- Level3 Clipsave/cliprestore support.  9/16/96    jjia          */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_TUTILSSEG)

#define HTOPTR(s,o) (LPVOID) ( ((DWORD)((WORD)(o))) |       \
                               (((DWORD)((WORD)(s))) << 16) )

#define  SIZE_FONTHEADER   0x15000L   /* 86016 bytes to hold the "loca" for FE fonts*/

#define  SIZE_MINSFNT      0x15000L  /* 86016 bytes */
#define  SIZE_ONEGLYF      0x4000L   /* 16384 bytes */

// local prototypes
static VOID NEAR PASCAL resetProcsetList(LPPDEVICE lppd);
static VOID NEAR PASCAL saveUpdate(LPPDEVICE lppd);
static VOID NEAR PASCAL restoreUpdate(LPPDEVICE lppd);

void SaveGlyphData0(LPPDEVICE lppd, int Num);
short FAR PASCAL PSGetFragmentLength(LPPDEVICE lppd, WORD FragId);
VOID FAR PASCAL CreatePassThroughID(LPPDEVICE lppd,
                                    LPPASSTHROUGHENTRY currententry,
                                    LPSTR    lpPassID);

/****************************************************************************************
*
*                          TInitGraphicState
*
*  Function:   Initializes the graphics state
*
*  Called:     VOID FAR PASCAL TInitGraphicState(LPPDEVICE lppd)
*    
*  Parameters: LPPDEVICE        lppd        pdevice pointer
*
*  Returns:    nothing
*
****************************************************************************************/

VOID FAR PASCAL TInitGraphicState(LPPDEVICE lppd)
{
     RECT rect;                 // Imageable area, PS user units (== GDI pixels)
  
     // Initialize Pen Cap as undefined. Changed to fix bug#371
     // Fixed 23-Jun-1993  -by-  [olegs]

     lppd->lpGSStack->lpgGState->dColor         = RGB_BLACK            ;
     lppd->lpGSStack->lpgGState->bPenCap        = (BYTE) -1            ;
     lppd->lpGSStack->lpgGState->bPenJoin       = (BYTE) -1            ;
     lppd->lpGSStack->lpgGState->bPenStyle      = PENSTYLE_solid       ;
     lppd->lpGSStack->lpgGState->sPenMiter      = PENMITER_default     ;
     lppd->lpGSStack->lpgGState->ptPen.x        =1                     ;
     lppd->lpGSStack->lpgGState->ptPen.y        =1                     ;

     lppd->lpGSStack->lpgGState->bBrushStyle    = BRUSHSTYLE_solid     ;
     lppd->lpGSStack->lpgGState->currentFontData.FontName[0] = (char)0;

     // performance improvement.  jjia  6/4/96
     lppd->lpGSStack->lpgGState->bColorSpaceChanged = TRUE;
                                                             // init currentFontData to nothing
     // Fixed bug 120847.  jjia.  10/30/95
     // Only reset pen, brush and font if this function is called by ESCResetPage.
     if (lppd->job.bfESCResetPage)
          return;

     PSSetNoCurrentPoint(lppd);

     // Determine the extent of the GDI coordinate system
     if (lppd->lpPSExtDevmode->dm.marginState == TRUE) //Full page is imageable.
     {
          SetRect((LPRECT)&rect, 0, 0, lppd->ptPaperDim.x,
                                                            lppd->ptPaperDim.y) ;
     }
     else
     {
          // drvState.imageRect is expressed with an origin at the top-left
          // corner of the paper.  Use OffsetRect to convert it so the origin
          // is at the top-left corner of the imageable area.
          // so left == top == 0.
          rect = lppd->imageRect ;
          OffsetRect((LPRECT)&rect, -(lppd->imageRect.left), 
                                                       -(lppd->imageRect.top));
     }

     // Init the PS clipping rect to the full imageable area.

     lppd->lpGSStack->lpgGState->cliprect[0] = min(rect.left, rect.right);
     lppd->lpGSStack->lpgGState->cliprect[1] = min(rect.top, rect.bottom);
     lppd->lpGSStack->lpgGState->cliprect[2] = ABS(rect.right - rect.left);
     lppd->lpGSStack->lpgGState->cliprect[3] = ABS(rect.bottom - rect.top);

     // The clip rect is initially equal to the full imageable area.
     lppd->lpGSStack->lpgGState->fClipIsMax  = TRUE;  
     // ICM stuff
     lppd->lpGSStack->lpgGState->ColorSpace = CS_DEVICE_RGB ;
     lppd->lpGSStack->lpgGState->CRDActive = 0;
     lppd->lpGSStack->lpgGState->bColorMode = 0;  // fix icm bug 4/3/96
     lppd->graphics.CRDClear = 0;
     lppd->graphics.CSAClear = 0;
     lppd->graphics.bCRDSent[0] = 0 ;
     lppd->graphics.bCSASent[0] = 0 ;
     // L3_CLIP
     lppd->graphics.bClipSave = FALSE ;
//     MemSet((LPSTR)(&(lppd->graphics.CS)), 0, sizeof(LOGCOLORSPACE));
}

/***************************************************************************************
*
*                                TSetPen
*
*  Function:   Sets pen values based on the GSTATE stack.
*
*  Called:     VOID FAR PASCAL TSetPen(LPPDEVICE lppd)
*    
*  Parameters: LPPDEVICE   lppd        pdevice pointer
*
*  Returns:    nothing
*
****************************************************************************************/

VOID FAR PASCAL TSetPen(LPPDEVICE lppd)
{
     lppd->pen.dFGColor     = lppd->lpGSStack->lpgGState->dColor      ;
     lppd->pen.bCap         = lppd->lpGSStack->lpgGState->bPenCap     ;
     lppd->pen.bJoin        = lppd->lpGSStack->lpgGState->bPenJoin    ;
     lppd->pen.bStyle       = lppd->lpGSStack->lpgGState->bPenStyle   ;
     lppd->pen.sMiterLimit  = lppd->lpGSStack->lpgGState->sPenMiter   ;
     lppd->pen.ptWidth      = lppd->lpGSStack->lpgGState->ptPen     ;
     lppd->brush.fPaintBack = FALSE;
}

/******************************************************************************
*
*                             TSetBrush
*
*  Function:     This routine sets brush values based on the GSTATE stack.
*
*  Called:       VOID FAR PASCAL TSetBrush(LPPDEVICE lppd)
*
*  Parameters:   LPPDEVICE lppd -- pdevice pointer
*
*  returns:      None
*
******************************************************************************/

VOID FAR PASCAL TSetBrush(LPPDEVICE lppd)
{
     lppd->brush.dFGColor   = lppd->lpGSStack->lpgGState->dColor      ;
     lppd->brush.bStyle     = lppd->lpGSStack->lpgGState->bBrushStyle ;
     lppd->brush.bHatch     = (BYTE)BRUSHHATCH_none     ;
     lppd->brush.fPaintBack = FALSE               ;
}

/******************************************************************************
*
*                           GSStackCreate
*
*  Function:     This routine initializes the GSTATE stack.
*
*  Called:       VOID FAR PASCAL GSStackCreate(LPPDEVICE lppd)
*
*  Parameters:   LPPDEVICE lppd -- pdevice pointer
*
*  returns:      None
*
******************************************************************************/

VOID FAR PASCAL GSStackCreate(LPPDEVICE lppd)
{
     short dex;

     // Init the savelevel fields in the stack records to an impossible value.
     for (dex = 0; dex < MAX_GSSTACK_ELEMS; dex ++)
     {
          lppd->lpGSStack->elems[dex].savelevel = -1;
     }

     // Initialize pointer to point at the top of the stack.
     lppd->lpGSStack->lpgGState = &(lppd->lpGSStack->elems[0]);
     lppd->lpGSStack->num_pushed = 0;                         // stack is empty
}

/******************************************************************************
*
*                           GSStackPush
*
*  Function: This routine pushes the current GSTATE on the GSTATE stack.
*
*  Called: VOID FAR PASCAL GSStackPush(LPPDEVICE lppd)
*
*  Parameters:  LPPDEVICE lppd -- pdevice pointer
*
*  Returns:   None
*
******************************************************************************/

VOID FAR PASCAL GSStackPush(LPPDEVICE lppd)
{
     // Before fix we checked for >= MAX_GSSTACK_ELEMS, thus missing by 1
     //  Fixed  15-Mar-1993  -by-  [olegs]
     if (lppd->lpGSStack->num_pushed < ( MAX_GSSTACK_ELEMS - 1 ))
     {
          lppd->lpGSStack->lpgGState->savelevel = lppd->lpProcsetstuff->savelevel;
                                                                                // record the save level
          // Init the next record
          lppd->lpGSStack->elems[lppd->lpGSStack->num_pushed + 1] =
                                             lppd->lpGSStack->elems[lppd->lpGSStack->num_pushed];

          // Point to the next one
          lppd->lpGSStack->num_pushed++ ;
          lppd->lpGSStack->lpgGState =
                                        &(lppd->lpGSStack->elems[lppd->lpGSStack->num_pushed]);
     }
}

/******************************************************************************
*
*                              GSStackPop
*
*  Function:
*       This routine pops GSTATE from the GSTATE stack.
*
*  Called:
*       VOID FAR PASCAL GSStackPop(LPPDEVICE lppd)
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice pointer
*
*  Returns:   None
*
******************************************************************************/

VOID FAR PASCAL GSStackPop(LPPDEVICE lppd)
{
     if (lppd->lpGSStack->num_pushed > 0)
     {
          lppd->lpGSStack->num_pushed-- ;
          lppd->lpGSStack->lpgGState =
                                   &(lppd->lpGSStack->elems[lppd->lpGSStack->num_pushed]);
     }
}

/******************************************************************************
*
*                           GSStackNumPushed
*
*  Function:   Returns the number of GSTATE's pushed onto the GSTATE stack.
*
*  Called:     short FAR PASCAL GSStackNumPushed(LPPDEVICE lppd)
*
*  Parameters: LPPDEVICE lppd -- pdevice pointer
*
*  Returns:    NumPushed
*
******************************************************************************/

short FAR PASCAL GSStackNumPushed(LPPDEVICE lppd)
{
     return(lppd->lpGSStack->num_pushed );
}

/*****************************************************************************
*
*                      UnLockTranslateLayerData
*
*  Function:    UnLocks all tranlate layer data
*
*  Called:      VOID FAR PASCAL UnLockTranslateLayerData( LPPDEVICE lppd )
*
*  Parameters:  lppd   LPPDEVICE     pdevice pointer
*
*  Returns:     Nothing
*
*****************************************************************************/

VOID FAR PASCAL UnLockTranslateLayerData(LPPDEVICE lppd)
{
     FARPROC  fnExitFunc;

     if (fInDocLppd(lppd) || (stCurrentLppd(lppd) == ST_JOB_DONE))
     {
          if (lppd->hDriverTokenDLL != NULL)
          {
               fnExitFunc = GetProcAddress( lppd->hDriverTokenDLL, "ExitDriverDLL");
               if (fnExitFunc != NULL)
               {
                    (*fnExitFunc)( lppd );
               }
          }
          else
          {
               MGUnlock(lppd->TFuncHandle);
               lppd->lpTFuncPtr = (LPVOID)NULL;

               MGUnlock(lppd->AsciiBinHandle);
               lppd->lpAsciiBinPtr = (LPVOID)NULL;

               MGUnlock(lppd->FontDataHandle);
               lppd->lpFontDataList = (LPFONTDATALIST)NULL;

               MGUnlock(lppd->FontDSCHandle);
               lppd->lpFontDSCList = (LPFONTDSCLIST)NULL;

               MGUnlock(lppd->FileDSCHandle);
               lppd->lpFileDSCList = (LPFILEDSCLIST)NULL;

               MGUnlock(lppd->FeatureDSCHandle);
               lppd->lpFeatureDSCList = (LPFEATUREDSCLIST)NULL;

               MGUnlock(lppd->PassThrouhgHandle);

               MGUnlock(lppd->ProcsetstuffHandle);
               lppd->lpProcsetstuff = (LPPROCSETDOWNLOAD)NULL;

               MGUnlock(lppd->hdlGSStack);
               lppd->lpGSStack = (LPGSSTACKREC)NULL;

               MGUnlock(lppd->hPatBrushInfo);
               lppd->lpPatBrushInfo = (LPPATBRUSHINFO)NULL;

               // Unlock Global Memory used by PSSend....() functions
               MGUnlock(lppd->GlobalBuffer.hStringAscii7);
               lppd->GlobalBuffer.lpStringAscii7 = (BYTE huge *)NULL;

               MGUnlock(lppd->GlobalBuffer.hBitMapDataLevel1Binary);
               lppd->GlobalBuffer.lpBitMapDataLevel1Binary = (LPBYTE)NULL;

               MGUnlock(lppd->GlobalBuffer.hDirect);
               lppd->GlobalBuffer.lpDirect = (LPBYTE)NULL;

               MGUnlock(lppd->GlobalBuffer.hStringOutput);
               lppd->GlobalBuffer.lpStringOutput = (BYTE huge *)NULL;

          }
     }
} // UnLockTranslateLayerlData 

/*****************************************************************************
*
*                         LockTranslateLayerData
*
*  Function:     Locks Translate layer data
*
*  Called:       VOID FAR PASCAL LockTranslateLayerData( LPPDEVICE lppd )
*
*  Parameters:   lppd    LPPDEVICE     ptr to pdevice
*
*  Returns:      Nothing
*
*****************************************************************************/

VOID FAR PASCAL LockTranslateLayerData(LPPDEVICE lppd)
{
     FARPROC  fnEnterFunc;

     if (fInDocLppd(lppd) || (stCurrentLppd(lppd) == ST_JOB_DONE))
     {
          if (lppd->hDriverTokenDLL != NULL)
          {
               fnEnterFunc = GetProcAddress(lppd->hDriverTokenDLL, "EnterDriverDLL");
               if (fnEnterFunc != NULL)
               {
                    (*fnEnterFunc)(lppd);
               }
          }
          else
          {
               lppd->lpTFuncPtr = (LPVOID)MGLock(lppd, lppd->TFuncHandle, TRUE);

               lppd->lpAsciiBinPtr = (LPVOID)MGLock(lppd, lppd->AsciiBinHandle, TRUE);

               lppd->lpFontDataList = (LPFONTDATALIST)MGLock(lppd, lppd->FontDataHandle, TRUE);
               
               lppd->lpFontDSCList = (LPFONTDSCLIST)MGLock(lppd, lppd->FontDSCHandle, TRUE); 
               
               lppd->lpFileDSCList = (LPFILEDSCLIST)MGLock(lppd, lppd->FileDSCHandle, TRUE);
               
               lppd->lpFeatureDSCList = (LPFEATUREDSCLIST)MGLock(lppd, lppd->FeatureDSCHandle, TRUE);
               
               lppd->lpProcsetstuff = (LPPROCSETDOWNLOAD)MGLock(lppd, lppd->ProcsetstuffHandle, TRUE);
               
               lppd->lpGSStack = (LPGSSTACKREC)MGLock(lppd, lppd->hdlGSStack, TRUE);
               
               lppd->lpPatBrushInfo = (LPPATBRUSHINFO)MGLock(lppd, lppd->hPatBrushInfo, TRUE);

               // Lock the Global Memory used by the PSSend...() functions
               lppd->GlobalBuffer.lpStringAscii7 = 
                    (BYTE huge *)MGLock(lppd, lppd->GlobalBuffer.hStringAscii7,TRUE);
               lppd->GlobalBuffer.lpBitMapDataLevel1Binary = 
                    (LPBYTE)MGLock(lppd, lppd->GlobalBuffer.hBitMapDataLevel1Binary,TRUE);
               lppd->GlobalBuffer.lpDirect = 
                    (LPBYTE)MGLock(lppd, lppd->GlobalBuffer.hDirect,TRUE);
               lppd->GlobalBuffer.lpStringOutput = 
                    (BYTE huge *)MGLock(lppd, lppd->GlobalBuffer.hStringOutput, TRUE);
          }
     }
} // LockGlobalData 

/*****************************************************************************
*
*                       AllocTranslateLayerData
*
*  Function:      Allocates memory for Translate layer data structures
*
*  Called:        VOID FAR PASCAL AllocTranslateLayerData( LPPDEVICE lppd )
*
*  Parameters:    lppd    LPPDEVICE     ptr to pdevice
*
*  Returns        Nothing
*
*****************************************************************************/

PSERROR FAR PASCAL AllocTranslateLayerData(LPPDEVICE lppd)
{
     PSERROR rc = PS_SUCCESS;
     
     if (lppd->TFuncHandle == NULL)
     {
          lppd->lpTFuncPtr = (LPVOID)MGAllocLock(lppd, 
               (LPHANDLE)&lppd->TFuncHandle, (DWORD)sizeof(TFUNCTIONPTRS), GHND, TRUE);
     }

     if (lppd->AsciiBinHandle == NULL)
     {
          lppd->lpAsciiBinPtr = (LPVOID)MGAllocLock(lppd,
               (LPHANDLE)&lppd->AsciiBinHandle,(DWORD)sizeof(ASCIIBINPTRS), GHND,TRUE);
     }

     if (lppd->FontDataHandle == NULL)
     {
          lppd->lpFontDataList = (LPFONTDATALIST)MGAllocLock(lppd,
               (LPHANDLE)&lppd->FontDataHandle,(DWORD)sizeof(FONTDATALIST), GHND,TRUE);
     }

     if (lppd->GASHandle == NULL)
     {
          lppd->lpGASList = (LPGASLIST)MGAllocLock(lppd,
               (LPHANDLE)&lppd->GASHandle,(DWORD)sizeof(GASLIST), GHND,TRUE);
     }

     if (lppd->FontDSCHandle == NULL)
     {
          lppd->lpFontDSCList = (LPFONTDSCLIST)MGAllocLock(lppd,
               (LPHANDLE)&lppd->FontDSCHandle,(DWORD)sizeof(FONTDSCLIST), GHND,TRUE);
     }

     if (lppd->FileDSCHandle == NULL)
     {
          lppd->lpFileDSCList = (LPFILEDSCLIST)MGAllocLock(lppd,
               (LPHANDLE)&lppd->FileDSCHandle,(DWORD)sizeof(FILEDSCLIST), GHND,TRUE);
     }

     if (lppd->FeatureDSCHandle == NULL)
     {
          lppd->lpFeatureDSCList = (LPFEATUREDSCLIST)MGAllocLock(lppd,
               (LPHANDLE)&lppd->FeatureDSCHandle,(DWORD)sizeof(FEATUREDSCLIST), GHND,TRUE);
     }
     if (lppd->ProcsetstuffHandle == NULL)
     {
          lppd->lpProcsetstuff = (LPPROCSETDOWNLOAD)MGAllocLock(lppd,
               (LPHANDLE)&lppd->ProcsetstuffHandle,(DWORD)sizeof(PROCSETDOWNLOAD), GHND,TRUE);
     }

     if (lppd->hdlGSStack == NULL)
     {
          lppd->lpGSStack = (LPGSSTACKREC)MGAllocLock(lppd,
               (LPHANDLE)&lppd->hdlGSStack,(DWORD)sizeof(GSSTACKREC), GHND,TRUE);
     }

     if (lppd->hPatBrushInfo == NULL)
     {
          lppd->lpPatBrushInfo = (LPPATBRUSHINFO)MGAllocLock(lppd,
               (LPHANDLE)&lppd->hPatBrushInfo,(DWORD)sizeof(PATBRUSHINFO), GHND,TRUE);
     }

     if (!lppd->lpTFuncPtr || !lppd->lpAsciiBinPtr || !lppd->lpFontDataList ||
         !lppd->lpFontDSCList || !lppd->lpFileDSCList ||!lppd->lpFeatureDSCList ||
         !lppd->lpProcsetstuff || !lppd->lpGSStack)
     {
         rc = PS_ALLOC_FAILED;
         goto EndAllocTranslateLayerData;
     }
     
     // Allocate Global Memory Buffers in PDevice for use by various send functions 
     // This is done as an optimization to speed up the zillions of calls to a
     // few PSSend...() functions that do expensive MGAlloc(), GlobalAlloc() in
     // EVERY call!! This scheme works OK now - 200-400% speed gains. At a later
     // date, we can become more fancy in how we implement this optimization 
     // in a more sophisticated manner - ShyamV - 7/23/93

     if (lppd->GlobalBuffer.lpStringAscii7 = (BYTE huge *)MGAllocLock(lppd, 
             (LPHANDLE)&lppd->GlobalBuffer.hStringAscii7, 0x7000, GHND, TRUE))
         lppd->GlobalBuffer.dStringAscii7 = 0x7000L;

     if (lppd->GlobalBuffer.lpBitMapDataLevel1Binary = (LPBYTE)MGAllocLock(lppd, 
             (LPHANDLE)&lppd->GlobalBuffer.hBitMapDataLevel1Binary,
             0x4000, GHND, TRUE))
         lppd->GlobalBuffer.dBitMapDataLevel1Binary = 0x4000L;

     if (lppd->GlobalBuffer.lpDirect = (LPBYTE)MGAllocLock(lppd, 
             (LPHANDLE)&lppd->GlobalBuffer.hDirect, 0x1000, GHND, TRUE))
         lppd->GlobalBuffer.dDirect = 0x1000L;

     if (lppd->GlobalBuffer.lpStringOutput = (BYTE huge *)MGAllocLock(lppd, 
             (LPHANDLE)&lppd->GlobalBuffer.hStringOutput,
             0x800, GHND, TRUE))
         lppd->GlobalBuffer.dStringOutput = 0x800L;

     if (lppd->GlobalBuffer.TTtoT1stuff.lpOutlineBuf = 
            GlobalAllocPtr(GHND|GMEM_DDESHARE, 16))
         lppd->GlobalBuffer.TTtoT1stuff.wOutlineBufSize = 16 ;

     if (lppd->GlobalBuffer.TTtoT1stuff.lpCSBuffer = 
            GlobalAllocPtr(GHND|GMEM_DDESHARE, 16)) 
         lppd->GlobalBuffer.TTtoT1stuff.wCSSize = 16 ;

     if (lppd->GlobalBuffer.UFLBuffers.lpDLGlyph =  (LONG *)
            GlobalAllocPtr(GHND|GMEM_DDESHARE, 64 * sizeof(LONG)))
         lppd->GlobalBuffer.UFLBuffers.wDLGlyphSize = 64 ;

     if (lppd->GlobalBuffer.UFLBuffers.lpCharIndex = (USHORT *)
            GlobalAllocPtr(GHND|GMEM_DDESHARE, 64* sizeof(USHORT)))
         lppd->GlobalBuffer.UFLBuffers.wCharIndexSize = 64 ;

     if (lppd->GlobalBuffer.UFLBuffers.lpUnicode = (LPWORD)
            GlobalAllocPtr(GHND|GMEM_DDESHARE, 64* sizeof(WORD)))
         lppd->GlobalBuffer.UFLBuffers.wUnicodeSize = 64 ;

     if (!lppd->GlobalBuffer.lpStringAscii7 ||
         !lppd->GlobalBuffer.lpBitMapDataLevel1Binary ||
         !lppd->GlobalBuffer.lpDirect ||
         !lppd->GlobalBuffer.lpStringOutput ||
         !lppd->GlobalBuffer.TTtoT1stuff.lpOutlineBuf ||
         !lppd->GlobalBuffer.TTtoT1stuff.lpCSBuffer)
     {
         rc = PS_ALLOC_FAILED;
         goto EndAllocTranslateLayerData;
     }
     
     lppd->GlobalBuffer.TTtoT1stuff.lpCSEnd = 
         lppd->GlobalBuffer.TTtoT1stuff.lpCSBuffer + 
         lppd->GlobalBuffer.TTtoT1stuff.wCSSize;

EndAllocTranslateLayerData:
     // Buffers will get freed later (ESCEndDoc) even if we report 
     // back an error (ESCAbortDoc)
     return rc;
}

// A function to free all GI to SOI mappings (GASList).
void FreeGASList(LPPDEVICE lppd)
{
 LPGASLIST lpGASList = lppd->lpGASList;
 int i;
   if (lpGASList==NULL) return;  // self-defence
   for (i=0; i<lpGASList->GASNextRecord; i++)
      {
      FreeGIAssigned(lppd, (LPGIASSIGNED)&(lpGASList->GASList[i]));
      }
}

/*****************************************************************************
*                          FreePassThroughEntry
* Function: Free PostScript PassThrough data record
*
* Parameters: LPPDEVICE lppd     PDEVICE pointer
* Returns:  nothing
*****************************************************************************/

void FAR PASCAL FreePassThroughEntry(LPPDEVICE lppd)
{
   LPSTR lpPassThrough = lppd->lpPassThroughRootEntry;
   LPPASSTHROUGHHEADER lpHdr; 
   LPSTR lpNextPassThrough; 
 
   if (lpPassThrough!=NULL){
     do {
        lpHdr = (LPPASSTHROUGHHEADER)lpPassThrough;
        lpNextPassThrough = lpHdr->lpNextBufferEntry;
        GlobalFreePtr(lpPassThrough);
        lpPassThrough = lpNextPassThrough;
     } while( lpPassThrough != NULL);
         
   }
   lppd->lpPassThroughRootEntry = lppd->lpPassThroughCurrentEntry =NULL;
}

/*****************************************************************************
*
*                          FreeTranslateLayerData
*
*  Function:   Frees the globalalloc data used by the embedded translators.
*
*  Called:     VOID FAR PASCAL FreeTranslateLayerData(LPPDEVICE lppd)
*
*  Parameters: lppd    LPPDEVICE     ptr to pdevice
*
*  Returns:    Nothing
*
*****************************************************************************/

VOID FAR PASCAL FreeTranslateLayerData( LPPDEVICE lppd )
{
     if (lppd->TFuncHandle)
     {
         MGFree(lppd, lppd->TFuncHandle,TRUE);
         lppd->TFuncHandle = NULL;
         lppd->lpTFuncPtr = (LPVOID)NULL;
     }

     if (lppd->AsciiBinHandle)
     {
         MGFree(lppd, lppd->AsciiBinHandle,TRUE);
         lppd->AsciiBinHandle = NULL;
         lppd->lpAsciiBinPtr = (LPVOID)NULL;
     }

     if (lppd->FontDataHandle &&
         lppd->SmsStartDoc!=SECOND_SD)
         // Don't free the FontData list for second StartDOC call because there are fonts
         // downloaded before StartDoc() - where we artificially make first StartDoc() call
         // This tweak is to fix bug 123510 - keep DSC as well as FontDataList record
     {
         lppd->nPreStartDocFonts = 0;  // set to 0 so all fontdata willbe freed
         InitFontDataList( lppd );  // This call will gurantee all lpFontDataList->GlyphData/0 willbe freed
         MGFree(lppd, lppd->FontDataHandle,TRUE);
         lppd->FontDataHandle = NULL;
         lppd->lpFontDataList = (LPFONTDATALIST)NULL;
     }

     if (lppd->GASHandle)
     {
         FreeGASList(lppd);
         MGFree(lppd, lppd->GASHandle,TRUE);
         lppd->GASHandle = NULL;
         lppd->lpGASList = (LPGASLIST)NULL;
     }

     if (lppd->FontDSCHandle &&
         lppd->SmsStartDoc!=SECOND_SD)
         // Don't free the DSC list for second StartDOC call because there are fonts
         // downloaded before StartDoc() - where we artificially make first StartDoc() call
         // This tweak is to fix bug 123510 - keep DSC as well as FontDataList record
     {
         MGFree(lppd, lppd->FontDSCHandle,TRUE);
         lppd->FontDSCHandle = NULL;
         lppd->lpFontDSCList = (LPFONTDSCLIST)NULL;
     }
     if (lppd->FileDSCHandle)
     {
         MGFree(lppd, lppd->FileDSCHandle,TRUE);
         lppd->FileDSCHandle = NULL;
         lppd->lpFileDSCList = (LPFILEDSCLIST)NULL;
     }

     if (lppd->FeatureDSCHandle)
     {
         MGFree(lppd, lppd->FeatureDSCHandle,TRUE);
         lppd->FeatureDSCHandle = NULL;
         lppd->lpFeatureDSCList = (LPFEATUREDSCLIST)NULL;
     }

     FreePassThroughEntry(lppd);

     if (lppd->ProcsetstuffHandle)
     {
         MGFree(lppd, lppd->ProcsetstuffHandle,TRUE);
         lppd->ProcsetstuffHandle = NULL;
         lppd->lpProcsetstuff = (LPPROCSETDOWNLOAD)NULL;
     }

     if (lppd->hdlGSStack)
     {
         MGFree(lppd, lppd->hdlGSStack,TRUE);
         lppd->hdlGSStack = NULL;
         lppd->lpGSStack = (LPGSSTACKREC)NULL;
     }

     if (lppd->hPatBrushInfo)
     {
         MGFree(lppd, lppd->hPatBrushInfo,TRUE);
         lppd->hPatBrushInfo = NULL;
         lppd->lpPatBrushInfo = (LPPATBRUSHINFO)NULL;
     }

     // Free the Global Memory allocated for the PSSend...() functions.
     if (lppd->GlobalBuffer.hStringAscii7)
     {
         MGFree(lppd, lppd->GlobalBuffer.hStringAscii7,TRUE);
         lppd->GlobalBuffer.hStringAscii7 = NULL;
         lppd->GlobalBuffer.lpStringAscii7 = (BYTE huge *)NULL;
         lppd->GlobalBuffer.dStringAscii7 = 0L;
     }

     if (lppd->GlobalBuffer.hBitMapDataLevel1Binary)
     {                                                                              
         MGFree(lppd, lppd->GlobalBuffer.hBitMapDataLevel1Binary,TRUE);
         lppd->GlobalBuffer.hBitMapDataLevel1Binary = NULL;
         lppd->GlobalBuffer.lpBitMapDataLevel1Binary = (LPBYTE)NULL;
         lppd->GlobalBuffer.dBitMapDataLevel1Binary = 0L;
     }

     if (lppd->GlobalBuffer.hDirect)
     {
         MGFree(lppd, lppd->GlobalBuffer.hDirect, TRUE);
         lppd->GlobalBuffer.hDirect = NULL;
         lppd->GlobalBuffer.lpDirect = (LPBYTE)NULL;
         lppd->GlobalBuffer.dDirect = 0L;
     }

     if (lppd->GlobalBuffer.hStringOutput)
     {
         MGFree(lppd, lppd->GlobalBuffer.hStringOutput, TRUE);
         lppd->GlobalBuffer.hStringOutput = NULL;
         lppd->GlobalBuffer.lpStringOutput = (BYTE huge *)NULL;
         lppd->GlobalBuffer.dStringOutput = 0L;
     }

    if (lppd->GlobalBuffer.TTtoT1stuff.lpCSBuffer)
        GlobalFreePtr(lppd->GlobalBuffer.TTtoT1stuff.lpCSBuffer) ;
    if (lppd->GlobalBuffer.TTtoT1stuff.lpOutlineBuf)
        GlobalFreePtr(lppd->GlobalBuffer.TTtoT1stuff.lpOutlineBuf) ;

    lppd->GlobalBuffer.TTtoT1stuff.lpCSBuffer = NULL ;
    lppd->GlobalBuffer.TTtoT1stuff.lpOutlineBuf = NULL ;
    lppd->GlobalBuffer.TTtoT1stuff.lpCSEnd = NULL ;
    lppd->GlobalBuffer.TTtoT1stuff.lpCSPos = NULL ;
    lppd->GlobalBuffer.TTtoT1stuff.wCSSize = 0 ;
    lppd->GlobalBuffer.TTtoT1stuff.wOutlineBufSize = 0 ;

    if (lppd->GlobalBuffer.UFLBuffers.lpDLGlyph)
        GlobalFreePtr(lppd->GlobalBuffer.UFLBuffers.lpDLGlyph) ;
    if (lppd->GlobalBuffer.UFLBuffers.lpCharIndex)
        GlobalFreePtr(lppd->GlobalBuffer.UFLBuffers.lpCharIndex) ;
    if (lppd->GlobalBuffer.UFLBuffers.lpUnicode)
        GlobalFreePtr(lppd->GlobalBuffer.UFLBuffers.lpUnicode) ;
    lppd->GlobalBuffer.UFLBuffers.lpDLGlyph = NULL;
    lppd->GlobalBuffer.UFLBuffers.lpCharIndex = NULL;
    lppd->GlobalBuffer.UFLBuffers.lpUnicode = NULL;
    lppd->GlobalBuffer.UFLBuffers.wDLGlyphSize = 0;
    lppd->GlobalBuffer.UFLBuffers.wCharIndexSize = 0;
    lppd->GlobalBuffer.UFLBuffers.wUnicodeSize = 0;

#ifdef ADOBE_DRIVER

    FreeWaterMark(lppd); // free watermark cached font info, 5-6-95, ppeng
#endif

     if (lppd->SmsStartDoc!=SECOND_SD)
         // Don't free the lpFontListTable for second StartDOC call because 
         // we want the same font names "MSTT31abcd" for all pages and Pre-stardoc fonts.
     {
        FreeTTFontTable(lppd) ;   // Free atoms table
     }

   if(lppd->lpDownloadFaceStr)
      GlobalFreePtr((LPVOID)lppd->lpDownloadFaceStr) ;
   lppd->dwDownloadFaceStr=0;  // length of buffer lpDownloadFaceStr
   lppd->lpDownloadFaceStr=NULL ; // String used for next Escape(DownloadFace) call.
   // We depend on the fact this func will be called again with SECOND_SD - so the next
   // assigment will catch the correct font number downloaded pre-startdoc().
   if (lppd->SmsStartDoc==SECOND_SD){
      lppd->nPreStartDocFonts = lppd->lpFontDataList->FontDataNextRecord;  
      // this check is not necessary since MAXFONTDATARECORDS=200 and no one should DL 200 fonts already
      if (lppd->nPreStartDocFonts >= MAXFONTDATARECORDS)
         lppd->nPreStartDocFonts = MAXFONTDATARECORDS/2 ;  // cut it to half. this is for corner cases
      SaveGlyphData0(lppd, lppd->nPreStartDocFonts);
      }

} // FreeTranslateLayerData 

#ifndef ADOBEPS42
BOOL FAR PASCAL RLEDecodeNeeded(LPPDEVICE lppd)
{
    /* 
     * RLE decoding procset is needed if it is level 1 printer, and 
     * bitmap compression in enabled.
     */
    return ((! lppd->lpPSExtDevmode->dm2.bfUseLevel2) && 
            lppd->lpPSExtDevmode->dm2.bCompress);
}
#else
BOOL FAR PASCAL RLEDecodeNeeded(LPPDEVICE lppd)
{
    /* 
     * RLE decoding procset is needed if it is level 1 printer, and 
     * bitmap compression in enabled.
     */
    return ( FALSE );
}
#endif

/*****************************************************************************
*
*                            InitProcsetList
*
*  Function:   Initializes the list of downloaded procsets
*
*  Called:     VOID FAR PASCAL InitProcsetList(LPPDEVICE lppd);
*
*  Parameters: LPPDEVICE lppd -- pdevice pointer
*
*  Returns:    nothing
*
*****************************************************************************/

VOID FAR PASCAL InitProcsetList(LPPDEVICE lppd)
{
     short dex;
     BOOL bfBinaryOutput =
         (lppd->lpPSExtDevmode->dm2.iDataOutputFormat != PROTOCOL_ASCII);

#ifndef ADOBEPS42
     if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
          (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS) &&
           bfBinaryOutput)
     {
          lppd->lpProcsetstuff->procsettype = L2ONLY;
     }
     else
     {
          lppd->lpProcsetstuff->procsettype = L1L2COMPAT;
     }
#else
     lppd->lpProcsetstuff->procsettype = L2ONLY;
#endif

     lppd->lpProcsetstuff->anyprocsetsent = FALSE;

     // Init the procset "sent" flags to false

     for (dex = 0; dex < MAXPROCSETRECORDS; dex ++)
     {
          lppd->lpProcsetstuff->procsetlist[dex] = -1;
     }
}

/************************************************************************
*
*                         AddProcsetRecord
*
*  Function:   Adds a record to the procset list
*
*  Called:     short FAR PASCAL AddProcsetRecord(LPPDEVICE lppd, short Psetnumber);
*
*  Parameters: LPPDEVICE lppd        pdevice pointer
*              short     Psetnumber  the number which indicates the procset type
*
*  Returns:    short -- RC_ok or RC_fail
*
*************************************************************************/

short FAR PASCAL AddProcsetRecord(LPPDEVICE lppd, short Psetnumber)
{
     short retval = RC_fail;

     if ((Psetnumber >= 0) && (Psetnumber < MAXPROCSETRECORDS))
     {
          lppd->lpProcsetstuff->procsetlist[Psetnumber] = 
              lppd->lpProcsetstuff->savelevel;
          retval = RC_ok;
     }

     // Check for all procsets there
     if (  (lppd->lpProcsetstuff->procsetlist[TEXT] > -1) &&
               (lppd->lpProcsetstuff->procsetlist[ATEXT] > -1) &&
               (lppd->lpProcsetstuff->procsetlist[VTEXT] > -1) &&
               (lppd->lpProcsetstuff->procsetlist[KTEXT] > -1) &&
               (lppd->lpProcsetstuff->procsetlist[GDIOBJ] > -1) &&
               (lppd->lpProcsetstuff->procsetlist[BITBLT] > -1) &&
               (lppd->lpProcsetstuff->procsetlist[DIB] > -1) &&
               (lppd->lpProcsetstuff->procsetlist[PASST] > -1) &&
#ifdef ADD_EURO
               (lppd->lpProcsetstuff->procsetlist[EUROHDR] > -1) &&
#endif
               ((lppd->lpProcsetstuff->procsetlist[TYPE42] > -1) ||
               (lppd->lpProcsetstuff->procsetlist[TYPE1HDR] > -1)
#ifdef T3OUTLINE
               || (lppd->lpProcsetstuff->procsetlist[TYPE3OLHDR] > -1)
#endif
               )
#ifndef ADOBEPS42
               && (RLEDecodeNeeded(lppd) &&
                (lppd->lpProcsetstuff->procsetlist[RLE_DECODE] > -1))
#endif
          )
     {
          lppd->lpProcsetstuff->allthere = TRUE;
     }

     return(retval);
}

/************************************************************************
*
*                         TokenNeedsProcset
*
*  Function:   This function is called by a token processing function to indicate
*              which procset group it requires to be present in memory.  This
*              function puts the procset (and any related procsets) into memory.
*
*  Called:     VOID FAR PASCAL TokenNeedsProcset(LPPDEVICE lppd, short Procset);
*
*  Parameters: LPPDEVICE lppd       pdevice pointer
*              short     Procset    the procset number
*
*  Returns:    short -- RC_ok or RC_fail
*
**************************************************************************/

short FAR PASCAL TokenNeedsProcset(LPPDEVICE lppd, short Procset)
{
     short retval = RC_ok;
     BOOL DownLoadHdr = lppd->lpPSExtDevmode->dm2.fHeader ||
                        lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS ||
                        lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE ||
                        lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE;

     // Fix bug 164116 (2)
     // Pre_downloaded header(allthere == TRUE) + SPEED or PORTABLE:
     // Can not incremental download
     // Pre_downloaded header(allthere == TRUE) + EPS ARCHIVE PJL_ARCHIVE:
     // Can incremental download
     // SPEED PORTABLE(allthere == TRUE): Can incremental download.
     // MINHEADER (allthere == FALSE): Can incremental download.
     // OPENCHANNEL (allthere == true): can not incremental download. #206970.
     if ((lppd->lpProcsetstuff->allthere == FALSE) ||

         // Fix bug 194989. jjia   2/17/97
         // For a predownloaded Type42 font, if the current output mode is
         // Portability and the current font download format is not Type42. 
         // We need to download Type42 header here.
         (DownLoadHdr) &&
         !(lppd->job.bfESCOpenChannel) &&

         (((Procset == TYPE42  ) &&
          (lppd->lpPSExtDevmode->dm2.iDLFontFmt != TT_DLFORMAT_TYPE42)) ||
          (Procset >= CMAP_128) && (Procset <= CMAP_136) ||
          (Procset == CMAP_FFFF) ||
          (Procset >= ENCODING_0) && (Procset <= ENCODING_255)
         ))
     {
          // Begin procset downloading
          lppd->lpProcsetstuff->anyprocsetsent = FALSE;

          // Deal with prerequisite procsets

          switch (Procset)
          {
               case VTEXT:
                    retval = downloadprocset(lppd,KTEXT);
               case KTEXT:
                    retval = downloadprocset(lppd,ATEXT);
               case ATEXT:
                    retval = downloadprocset(lppd,TEXT);
               break;

               case RLE_DECODE:
               case DIB:
                    retval = downloadprocset(lppd,BITBLT);
               break;

               case PASST:
                   // Fix bug 164116 (6). 10/17/96  jjia 
               break;

#ifdef T3OUTLINE
               case TYPE3OLHDR:
#endif
               case TYPE3HDR:
               case TYPE1HDR:
               case TYPE42:
                    // Fix bug 194989.  jjia  2/17/97
                    // In the portability mode, TEXT has been downloaded.
                    if (lppd->lpProcsetstuff->allthere == FALSE)
                        retval = downloadprocset(lppd, TEXT);
               break;

               default:
               break;
          } // switch(Procset)

          // Now download the required procset
          if (retval == RC_ok )
          {
               retval = downloadprocset(lppd, Procset);
          }

          // End procset download
          if (retval == RC_ok )
          {
               retval = endprocsetdownload(lppd);
          }
     } // if (...)

     return (retval);
}

/*********************************************************************
*
*                         downloadprocset
*
*  Function:   This function checks to see if the procset is already downloaded.
*              If not, it calls a function which gets the save level to the
*              correct place and updates the font list.  Then the procset is
*              downloaded and the fact that it was sent is recorded.
*
*  Called:     short NEAR PASCAL downloadprocset(LPPDEVICE lppd, short psetnum);
*
*  Parameters:  LPPDEVICE lppd     pdevice pointer
*              short     psetnum  the procset to download
*
*  Returns:    short -- RC_ok or RC_FAIL
*
**********************************************************************/

short NEAR PASCAL downloadprocset(LPPDEVICE lppd, short psetnum)
{
     short retval = RC_ok;
     BOOL isthere;

     // Check to set if the procset is already downloaded
     isthere = FALSE;
     if ((psetnum >= 0) && (psetnum < MAXPROCSETRECORDS))
     {
          if (lppd->lpProcsetstuff->procsetlist[psetnum] > -1)
          {
               isthere = TRUE;
          }
     }

     if (isthere == FALSE)
     {
          if (lppd->lpProcsetstuff->anyprocsetsent == FALSE)
          {
               retval = downloadprocsetstartup(lppd);
               if (retval == RC_ok)
                    lppd->lpProcsetstuff->anyprocsetsent = TRUE;
          }

          if (retval == RC_ok)
          {
               // Ship out the procset(s)
               retval = procsetsendprocs(lppd,psetnum);

               if (retval == RC_ok)
                    retval = AddProcsetRecord(lppd, psetnum);
          }
     }

     return (retval);
}

/**********************************************************************
*
*                        downloadprocsetstartup
*
*  Function:    This function sends the code to initiate procset downloading.
*               It also resets the font data list.
*
*  Called:      short NEAR PASCAL downloadprocsetstartup(LPPDEVICE lppd);
*
*  Parameters:  LPPDEVICE lppd  pdevice pointer
*
*  Returns:     short -- RC_ok or RC_fail
*
***********************************************************************/

short NEAR PASCAL downloadprocsetstartup(LPPDEVICE lppd)
{
     LPASCIIBINPTRS tempptr;
     short retval = RC_ok;
     BOOL nodribble = ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED) &&
                       (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS));

     tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

     // Fix bug 164116. portable mode also incremental download cmaps.
     TCleanToVMMark(lppd, 2);
     if( fIsMinHeaderLppd(lppd) )
     {
          PSSendFragment(lppd, PSFRAG_epsprocsetstart);
     }else if (lppd->lpProcsetstuff->procsettype == L2ONLY)
     {
          // Do the L2 invocation
          if (nodribble)
          {
              // Fix bug 164116 (2)
              // Download procset in portabilite mode.
              PSSendFragment(lppd, PSFRAG_porprocsetstartL2);
          }
          else
          {
              PSSendFragment(lppd, PSFRAG_incprocsetstartL2);
          }
     }
     else
     {
          // Do the L1/L2 compat invocation
          PSSendFragment(lppd, PSFRAG_incprocsetstart);
     }
     (*tempptr->PSSendCRLF)(lppd);

     return (retval);
}

// Get rid of level1   jjia  5/1/96
#ifndef ADOBEPS42
/**********************************************************************
*
*                       procsetsendprocs
*
*  Function:    Send the right procset based on the procset type
*               and the L2only/L1L2compat switch
*
*  Called:      short FAR PASCAL procsetsendprocs(LPPDEVICE lppd, short procsettype);
*
*  Parameters:  LPPDEVICE lppd      pdevice pointer
*               short procsettype   the procsets to download (TEXT, DIB, etc.)
*
*  Returns:     short -- RC_ok or RC_fail
*
**********************************************************************/

short FAR PASCAL procsetsendprocs(LPPDEVICE lppd, short procsettype)
{
     LPASCIIBINPTRS tempptr;
     short retval = TRUE;

     tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

     if (lppd->lpProcsetstuff->procsettype == L2ONLY)
     {
          switch (procsettype)
          {
               case TEXT:
                    retval = PSSendProc(lppd, PSPROC_text_ps2);
                    (*tempptr->PSSendCRLF)(lppd);

                    if (retval == RC_ok)
                    {
                         retval = PSSendProc(lppd, PSPROC_textenc_ps2);
                         (*tempptr->PSSendCRLF)(lppd);
                    }
               break;

               case ATEXT:
                    retval = PSSendProc(lppd, PSPROC_textbold_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case VTEXT:
                    retval = PSSendProc(lppd, PSPROC_kanji_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;


               case KTEXT:
                    retval = PSSendProc(lppd, PSPROC_kanji2_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case GDIOBJ:
                    retval = PSSendProc(lppd, PSPROC_graph0_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
                    if (retval == RC_ok)
                    {
                         retval = PSSendProc(lppd, PSPROC_graph2_ps2);
                         (*tempptr->PSSendCRLF)(lppd);
                    }
               break;

               case BITBLT:
                    retval = PSSendProc(lppd, PSPROC_imagebw0_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case DIB:
                    retval = PSSendProc(lppd, PSPROC_imageco2_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case PASST:
                    retval = PSSendProc(lppd, PSPROC_compat_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case TYPE3HDR:
                    retval = PSSendProc(lppd, PSPROC_ufl_type3hdr_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case TYPE1HDR:
                    retval = PSSendProc(lppd, PSPROC_type1hdr_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case TYPE42:
                    retval = PSSendProc(lppd, PSPROC_ufl_type42_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case CMAP_128:
                    retval = PSSendProc(lppd, PSPROC_cmap_128_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               
               case CMAP_129:
                    retval = PSSendProc(lppd, PSPROC_cmap_129_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               
               case CMAP_130:
                    retval = PSSendProc(lppd, PSPROC_cmap_130_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               
               case CMAP_134:
                    retval = PSSendProc(lppd, PSPROC_cmap_134_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               
               case CMAP_136:
                    retval = PSSendProc(lppd, PSPROC_cmap_136_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case CMAP_FFFF:
                    retval = PSSendProc(lppd, PSPROC_cmap_FFFF_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case TYPE0HDR:
                    retval = PSSendProc(lppd, PSPROC_type0hdr_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_0:
                    retval = PSSendProc(lppd, PSPROC_textenc_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_161:
                    retval = PSSendProc(lppd, PSPROC_greek_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_162:
                    retval = PSSendProc(lppd, PSPROC_turkish_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_177:
                    retval = PSSendProc(lppd, PSPROC_hebrew_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_178:
                    retval = PSSendProc(lppd, PSPROC_arabic_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_186:
                    retval = PSSendProc(lppd, PSPROC_baltic_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_204:
                    retval = PSSendProc(lppd, PSPROC_russian_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_238:
                    retval = PSSendProc(lppd, PSPROC_ee_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case MIN_TEXT:
                    retval = PSSendProc(lppd, PSPROC_min_text_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               default:
                    retval = RC_fail;
               break;
          } // switch (procsettype)
     }
     else     // L1/L2 Compat
     {
          switch (procsettype)
          {
               case TEXT:
                    retval = PSSendProc(lppd, PSPROC_text_ps1);
                    (*tempptr->PSSendCRLF)(lppd);
                    if (retval == RC_ok)
                    {
                         retval = PSSendProc(lppd, PSPROC_textenc_ps1);
                         (*tempptr->PSSendCRLF)(lppd);
                    }
               break;

               case ATEXT:
                    retval = PSSendProc(lppd, PSPROC_textbold_ps1);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case VTEXT:
                    retval = PSSendProc(lppd, PSPROC_kanji_ps1);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case KTEXT:
                    retval = PSSendProc(lppd, PSPROC_kanji2_ps1);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case GDIOBJ:
                    retval = PSSendProc(lppd, PSPROC_graph0_ps1);
                    (*tempptr->PSSendCRLF)(lppd);
                    if (retval == RC_ok)
                    {
                         retval = PSSendProc(lppd, PSPROC_graph1_ps1);
                         (*tempptr->PSSendCRLF)(lppd);
                    }
                    if (retval == RC_ok)
                    {
                         retval = PSSendProc(lppd, PSPROC_graph2_ps1);
                         (*tempptr->PSSendCRLF)(lppd);
                    }
               break;

               case BITBLT:
                    retval = PSSendProc(lppd, PSPROC_imagebw0_ps1);
                    (*tempptr->PSSendCRLF)(lppd);
                    if (retval == RC_ok)
                    {
                         retval = PSSendProc(lppd, PSPROC_imagebw1_ps1);
                         (*tempptr->PSSendCRLF)(lppd);
                    }
                    if (retval == RC_ok)
                         TSendHeaderL2ImageError(lppd);

                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case DIB:
                    retval = PSSendProc(lppd, PSPROC_imageco1_ps1);
                    (*tempptr->PSSendCRLF)(lppd);
                    if (retval == RC_ok)
                    {
                         retval = PSSendProc(lppd, PSPROC_imageco2_ps1);
                         (*tempptr->PSSendCRLF)(lppd);
                    }
               break;

               case PASST:
                    retval = PSSendProc(lppd, PSPROC_compat_ps1);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case TYPE3HDR:
                    retval = PSSendProc(lppd, PSPROC_type3hdr_ps1);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case TYPE1HDR:
                    retval = PSSendProc(lppd, PSPROC_type1hdr_ps1);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case TYPE42:
                    retval = PSSendProc(lppd, PSPROC_ufl_type42_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case CMAP_128:
                    retval = PSSendProc(lppd, PSPROC_cmap_128_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               
               case CMAP_129:
                    retval = PSSendProc(lppd, PSPROC_cmap_129_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               
               case CMAP_130:
                    retval = PSSendProc(lppd, PSPROC_cmap_130_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               
               case CMAP_134:
                    retval = PSSendProc(lppd, PSPROC_cmap_134_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               
               case CMAP_136:
                    retval = PSSendProc(lppd, PSPROC_cmap_136_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case CMAP_FFFF:
                    retval = PSSendProc(lppd, PSPROC_cmap_FFFF_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case TYPE0HDR:
                    retval = PSSendProc(lppd, PSPROC_type0hdr_ps1);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               case ENCODING_0:
                    retval = PSSendProc(lppd, PSPROC_textenc_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_161:
                    retval = PSSendProc(lppd, PSPROC_greek_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_162:
                    retval = PSSendProc(lppd, PSPROC_turkish_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_177:
                    retval = PSSendProc(lppd, PSPROC_hebrew_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_178:
                    retval = PSSendProc(lppd, PSPROC_arabic_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_186:
                    retval = PSSendProc(lppd, PSPROC_baltic_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_204:
                    retval = PSSendProc(lppd, PSPROC_russian_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_238:
                    retval = PSSendProc(lppd, PSPROC_ee_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case MIN_TEXT:
                    retval = PSSendProc(lppd, PSPROC_min_text_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
#ifndef ADOBEPS42
               case RLE_DECODE:
                    retval = PSSendProc(lppd, PSPROC_rledecode);
                    (*tempptr->PSSendCRLF)(lppd);
                    break;
#endif                  
               default:
                    retval = RC_fail;
               break;
          } // switch (procsettype)
     }

     if (retval != RC_ok)
          retval = RC_fail;

     return(retval);
}
#else
/**********************************************************************
*
*                       procsetsendprocs
*
*  Function:    Send the right procset based on the procset type
*
*  Called:      short FAR PASCAL procsetsendprocs(LPPDEVICE lppd, short procsettype);
*
*  Parameters:  LPPDEVICE lppd      pdevice pointer
*               short procsettype   the procsets to download (TEXT, DIB, etc.)
*
*  Returns:     short -- RC_ok or RC_fail
*
**********************************************************************/

short FAR PASCAL procsetsendprocs(LPPDEVICE lppd, short procsettype)
{
     LPASCIIBINPTRS tempptr;
     short retval = TRUE;

     tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

//   if (lppd->lpProcsetstuff->procsettype == L2ONLY)  
     {
          switch (procsettype)
          {
               case TEXT:
                    retval = PSSendProc(lppd, PSPROC_text_ps2);
                    (*tempptr->PSSendCRLF)(lppd);

                    if (retval == RC_ok)
                    {
                         retval = PSSendProc(lppd, PSPROC_textenc_ps2);
                         (*tempptr->PSSendCRLF)(lppd);
                    }
               break;

               case ATEXT:
                    retval = PSSendProc(lppd, PSPROC_textbold_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case VTEXT:
                    retval = PSSendProc(lppd, PSPROC_kanji_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case KTEXT:
                    retval = PSSendProc(lppd, PSPROC_kanji2_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case GDIOBJ:
                    retval = PSSendProc(lppd, PSPROC_graph0_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
                    if (retval == RC_ok)
                    {
                         // Use level 1 for pattern for speed.
                         retval = PSSendProc(lppd, PSPROC_graph1_ps1);
                         (*tempptr->PSSendCRLF)(lppd);
                    }
               break;

               case BITBLT:
                    retval = PSSendProc(lppd, PSPROC_imagebw0_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case DIB:
                    retval = PSSendProc(lppd, PSPROC_imageco2_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case PASST:
                    retval = PSSendProc(lppd, PSPROC_compat_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case TYPE3HDR:
                    retval = PSSendProc(lppd, PSPROC_ufl_type3hdr_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case TYPE1HDR:
                    retval = PSSendProc(lppd, PSPROC_type1hdr_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
#ifdef T3OUTLINE
               case TYPE3OLHDR:
                    retval = PSSendProc(lppd, PSPROC_type3olhdr_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
#endif
               case TYPE42:
                    retval = PSSendProc(lppd, PSPROC_ufl_type42_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case CMAP_128:
                    retval = PSSendProc(lppd, PSPROC_cmap_128_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               
               case CMAP_129:
                    retval = PSSendProc(lppd, PSPROC_cmap_129_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               
               case CMAP_130:
                    retval = PSSendProc(lppd, PSPROC_cmap_130_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               
               case CMAP_134:
                    retval = PSSendProc(lppd, PSPROC_cmap_134_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               
               case CMAP_136:
                    retval = PSSendProc(lppd, PSPROC_cmap_136_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case CMAP_FFFF:
                    retval = PSSendProc(lppd, PSPROC_cmap_FFFF_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case TYPE0HDR:
                    retval = PSSendProc(lppd, PSPROC_type0hdr_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
               case ENCODING_0:
                    retval = PSSendProc(lppd, PSPROC_textenc_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_161:
                    retval = PSSendProc(lppd, PSPROC_greek_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_162:
                    retval = PSSendProc(lppd, PSPROC_turkish_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_177:
                    retval = PSSendProc(lppd, PSPROC_hebrew_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_178:
                    retval = PSSendProc(lppd, PSPROC_arabic_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_186:
                    retval = PSSendProc(lppd, PSPROC_baltic_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_204:
                    retval = PSSendProc(lppd, PSPROC_russian_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case ENCODING_238:
                    retval = PSSendProc(lppd, PSPROC_ee_encoding);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case MIN_TEXT:
                    retval = PSSendProc(lppd, PSPROC_min_text_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case UFLT3HEADER:
                    retval = PSSendProc(lppd, PSPROC_ufl_type3hdr_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case UFLT42HEADER:
                    retval = PSSendProc(lppd, PSPROC_ufl_type42_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case UFLCFFHEADER:
                    retval = PSSendProc(lppd, PSPROC_ufl_cffnt_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;

               case UFLCMAPFE:
                    retval = PSSendProc(lppd, PSPROC_ufl_cmap_FFFF_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
#ifdef ADD_EURO
               case EUROHDR:
                    retval = PSSendProc(lppd, PSPROC_euro_ps2);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
#endif

#ifndef ADOBEPS42
               case RLE_DECODE:
                    retval = PSSendProc(lppd, PSPROC_rledecode);
                    (*tempptr->PSSendCRLF)(lppd);
               break;
#endif
               default:
                    retval = RC_fail;
               break;
          } // switch (procsettype)
     }
     if (retval != RC_ok)
          retval = RC_fail;

     return(retval);
}
#endif

/**********************************************************************
*
*                       endprocsetdownload
*
*  Function:    If any procsets have actually been sent, send the trailer
*               to re-init the procsets, set the anysent flag back to FALSE,
*               and blow away the font list.
*
*  Called:      short FAR PASCAL endprocsetdownload(LPPDEVICE lppd);
*
*  Parameters:  LPPDEVICE lppd -- pdevice pointer
*
*  Returns:     short -- RC_ok or RC_fail
*
***********************************************************************/

short FAR PASCAL endprocsetdownload(LPPDEVICE lppd)
{
     LPASCIIBINPTRS tempptr;
     short retval = RC_ok;

     tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

     if (lppd->lpProcsetstuff->anyprocsetsent == TRUE)
     {
          // Re-init the procsets
          AdobeOEMSendPSStub(lppd, PS_INDEX_SAVE_BEGIN, NULL, 0);

          if( fIsMinHeaderLppd(lppd) )
          {
             PSSendFragment(lppd,PSFRAG_incprocsetend);
             PSSendFragment(lppd,PSFRAG_end);
             PSSendFragment(lppd,PSFRAG_end);
          }else
          {
             PSSendFragment(lppd,PSFRAG_end);
             PSSendFragment(lppd,PSFRAG_incprocsetend);
          }
          (*tempptr->PSSendCRLF)(lppd);
          AdobeOEMSendPSStub(lppd, PS_INDEX_SAVE_END, NULL, 0);

          lppd->lpProcsetstuff->anyprocsetsent = FALSE;

          // Put the gstate stack back the way it was
          // Fix bug 164116. potable mode also incremental download cmaps.
          TSetVMMark(lppd, 2, TRUE);
     }

     return (retval);
}

/*****************************************************************************
*
*                            resetProcsetList
*
*  Function:   Update the downloaded procset list to the current save level.
*
*  Called:     static VOID NEAR PASCAL resetProcsetList(LPPDEVICE lppd);
*
*  Parameters: LPPDEVICE lppd -- pdevice pointer
*
*  Returns:    nothing
*
*****************************************************************************/

static VOID NEAR PASCAL resetProcsetList(LPPDEVICE lppd)
{
    short dex;

    for (dex = 0; dex < MAXPROCSETRECORDS; dex ++)
    {
        if (lppd->lpProcsetstuff->procsetlist[dex] >
            lppd->lpProcsetstuff->savelevel)
        {
            lppd->lpProcsetstuff->procsetlist[dex] = -1;
        }
    }
}

/*****************************************************************************
*
*                            ResetPatternCache
*
*****************************************************************************/

VOID FAR PASCAL ResetPatternCache(LPPDEVICE lppd)
{
    LPPATBRUSHINFO lpPBInfo = lppd->lpPatBrushInfo;
    int i; 
    if (lpPBInfo && (lpPBInfo->bBrushIndex != 0))
    { 
        for (i=0; i<MAXPATTERN; i++)
        {
            lpPBInfo->brush[i].bStyle = 0;
        }
        lpPBInfo->bBrushIndex = 0;
    }
}

/*****************************************************************************
*
*                            PSSendNegativeImage
*
*  Function:   If negative image is selected:
*              1. Send color transfer function to tranlate color.
*              2. Send black background for entire imageable area.
*
*  Called:     static VOID NEAR PASCAL PSSendNegativeImage(LPPDEVICE lppd);
*
*  Parameters: LPPDEVICE lppd -- pdevice pointer
*
*  Returns:    nothing
*
*****************************************************************************/

void FAR PASCAL PSSendNegativeImage(LPPDEVICE lppd, BOOL bSetTransfer)
{
    LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    FLAG fgray;

    // Send negative image if necessaary
    if (lppd->lpPSExtDevmode->dm.bNegImage && bSetTransfer)
    {
        PSSendFragment(lppd, PSFRAG_negativeimage);
        (*tempptr->PSSendCRLF)(lppd);
    }


    // Send white background for entire imageable area. This is safe 
    // to do because printers cannot paint white as their color
    // scheme is subtractive. So if negative image is chosen,
    // this paints the background with the opposite color.
    // This is to be done only once per page
    
    // When job is min-header or OpenChannel - the coordinates for the
    // rectangle that should be white must be in default PS coordinates.
    //  Fixed Adobe bug#84, MS bugs 10317, 3326.
    //    11-Aug-1994  -by-  [olegs]

    // Performance improvement. Fill entire imageable area to white
    // only when negative image is selected.    jjia   5/20/95.
    if ((lppd->pagebackground != lppd->lpProcsetstuff->currpagenumber) &&
        (lppd->lpPSExtDevmode->dm.bNegImage))
    {     
        RECT   rect;
    
        (*tempptr->PSSendBasic)(lppd, PSOP_gsave);

        // Since we do a settransfer on page1, all pages from page2 on will be
        // initiated to be a 'black' page by the PS interpreter.
        // If there is a margin, we need to revert the pages to 'white' first.
        if (lppd->lpProcsetstuff->currpagenumber != 1 &&  
            lppd->lpPSExtDevmode->dm.marginState != NO_MARGINS )
        {    
           fgray = PSSendRGBColor(lppd, (DWORD) RGB(0, 0, 0));
           PSSendRGBColorOP(lppd, fgray);  // Send  sg  -or-  sco
           SetRect(&rect, 0, 0, lppd->ptPaperDim.x,lppd->ptPaperDim.y) ;
           OffsetRect((LPRECT) &rect, -lppd->imageRect.left, -lppd->imageRect.top);
           PSSendRect(lppd, rect.top, rect.left, rect.bottom, rect.right);
           PSSendFragment(lppd, PSFRAG_rectfill);     // Solid fill
           (*tempptr->PSSendCRLF)(lppd);
        }
                
        fgray = PSSendRGBColor(lppd, (DWORD) RGB(255, 255, 255));
        PSSendRGBColorOP(lppd, fgray);  // Send  sg  -or-  sco

        // Send x y width height
        // Fix bug 220135.
        // if NO_MARGINS, fill full page, else fill imageable area.
        if( ( lppd->lpPSExtDevmode->dm2.bOutputDialect == DIALECT_EPS ) &&
           ( lppd->lpPSExtDevmode->dm.PaperOrient != OR_PORTRAIT ) )
        {
            if (lppd->lpPSExtDevmode->dm.marginState == NO_MARGINS)
            {   // Full page is imageable
                SetRect(&rect, 0, 0, lppd->ptPaperDim.y,lppd->ptPaperDim.x) ;
            } else
            {
                int  temp;
                rect = lppd->imageRect;
                OffsetRect((LPRECT) &rect, -rect.left, -rect.top);
                temp = rect.right;
                rect.right = rect.bottom;
                rect.bottom = temp;
            }
        }else
        {
            if (lppd->lpPSExtDevmode->dm.marginState == NO_MARGINS)
            {   // Full page is imageable
                SetRect(&rect, 0, 0, lppd->ptPaperDim.x,lppd->ptPaperDim.y) ;
            } else
            {
                rect = lppd->imageRect;
                OffsetRect((LPRECT) &rect, -rect.left, -rect.top);
            }
        }

        if (lppd->job.bfESCOpenChannel || lppd->job.bfJobMinHeader)
        {
            POINT p;
            p.x =  rect.left; p.y = rect.top ;
            DeviceToDefaultPS(lppd, (LPPOINT) &p);
            rect.left = p.x; rect.top = p.y ;
            
            p.x =  rect.right; p.y = rect.bottom ;
            DeviceToDefaultPS(lppd, (LPPOINT) &p);
            rect.right = p.x; rect.bottom = p.y ;
        }
        PSSendRect(lppd, rect.top, rect.left, rect.bottom, rect.right);
        PSSendFragment(lppd, PSFRAG_rectfill);     // Solid fill
        (*tempptr->PSSendBasic)(lppd, PSOP_grestore);
        (*tempptr->PSSendCRLF)(lppd);
        lppd->pagebackground = lppd->lpProcsetstuff->currpagenumber;
    }
}


/************************************************************************
*
*                              PSSendSave
*
*   Function:     This function sends a "save" to the printer.
*                 This function is used to keep track of the printer states:
*                 graphic state, font and procset.
*
*   Called:       void FAR PASCAL PSSendSave(LPPDEVICE lppd, BOOL pageSetup)
*
*   Parameters:   LPPDEVICE lppd -- pdevice pointer
*                 BOOL pageSetup -- true: pagesetup.
*                        16-bit: 1 page features is send for this page.
*                                  send negative image.
*                        15-bit: 1 send pagesave + page setup
*                        14-bit: 1 send pagesave only. ignore 15 16 bits 
*
*   Returns:      nothing
*
*************************************************************************/

void FAR PASCAL PSSendSave(LPPDEVICE lppd, BOOL pageSetup)
{
    LPASCIIBINPTRS tempptr;
    CHAR buf[64];
    BOOL bNupEnabled =
                (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS) &&
                (lppd->disableNUP == 0) &&
                (lppd->lpPSExtDevmode->dm.layout != ONE_UP ) ;
    BOOL bPageFeatureSent = FALSE;
    BOOL bPageSaveSent = TRUE;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    if (pageSetup & 4)
    // send "pagesave save" only. Do not send negative image.
    {
        // Fix bug 204185.
        // For portability mode, we must send pagesave at the
        // beginning of each page to make reverse order printing work.
        AdobeOEMSendPSStub(lppd, PS_INDEX_SAVE_BEGIN, NULL, 0);
        PSSendFragment(lppd, PSFRAG_pagesave);
        (*tempptr->PSSendCRLF)(lppd);
        AdobeOEMSendPSStub(lppd, PS_INDEX_SAVE_END, NULL, 0);
    }
    else if (pageSetup)
    // send "pagesave save" and negative image.
    {
        // need to special case page save

        // Fix bug 197396.
        // For portability mode, we must send pagesave at the
        // beginning of each page to make reverse order printing work.
        if (!(lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) &&
           // Fix bug 204185
           !(lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) &&
           !(lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE))
        {
            AdobeOEMSendPSStub(lppd, PS_INDEX_SAVE_BEGIN, NULL, 0);
            PSSendFragment(lppd, PSFRAG_pagesave);
            (*tempptr->PSSendCRLF)(lppd);
            PSSendFragment(lppd, PSFRAG_pagesetup);
            AdobeOEMSendPSStub(lppd, PS_INDEX_SAVE_END, NULL, 0);
        }
        else
        {
            PSSendFragment(lppd, PSFRAG_pagesetup);
            bPageSaveSent = FALSE;
        }

        // ADOBE_SPOOLER
//        PSSendFragment(lppd, PSFRAG_ResetEnv);

        // Color space may be changed.  5/30/96  jjia
        lppd->lpGSStack->lpgGState->bColorSpaceChanged = TRUE;

        // fix bug 200486. jjia   3/27/97
        if (pageSetup > 1)
            bPageFeatureSent = pageSetup & 1;
        if (!bNupEnabled &&
            !(lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) &&
            // Fix bug 204185
            !(lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) &&
            !(lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE) &&
            !(lppd->lpProcsetstuff->currpagenumber == 1) &&
            !(bPageFeatureSent))
            PSSendNegativeImage(lppd, FALSE);
        else
            PSSendNegativeImage(lppd, TRUE);
    }
    else
    {
        // Send the save level
        AdobeOEMSendPSStub(lppd, PS_INDEX_VMSAVE_BEGIN, NULL, 0);
      wsprintf(buf, "userdict begin /savelevel%d ",
               lppd->lpProcsetstuff->savelevel);
      PSSendString(lppd, buf);
        
      // Send "save def"
      PSSendFragment(lppd, PSFRAG_save);
        
        lstrcpy(buf, (LPSTR)"end");
        PSSendString(lppd, buf);
        AdobeOEMSendPSStub(lppd, PS_INDEX_VMSAVE_END, NULL, 0);

    }
    
    (*tempptr->PSSendCRLF)(lppd);
    if (bPageSaveSent)
    {
        saveUpdate(lppd);
        if (pageSetup)
            lppd->lpProcsetstuff->pagesaveLevel = lppd->lpProcsetstuff->savelevel;
    }
}

/************************************************************************
*
*                           PSSendRestore
*
*  Function:     This function sends a "restore" to the printer.
*                This function is used to keep track of the printer states:
*                graphic state, font and procset.
*
*  Called:       void FAR PASCAL PSSendRestore(LPPDEVICE lppd)
*
*  Parameters:   LPPDEVICE lppd -- pdevice pointer
*
*  Returns:      short - number of bytes send down
*
************************************************************************/

short FAR PASCAL PSSendRestore(LPPDEVICE lppd)
{
    LPASCIIBINPTRS tempptr;
    CHAR buf[64];
    unsigned short iRCount=0;
    LPPATBRUSHINFO lpPBInfo = lppd->lpPatBrushInfo;
    
    // stack underflow
        // If there is a spool error, this gets called as part of job 
        // deletion. In this case, savelevel may not be > 0, but who cares.
    PSDEBUG_ASSERT((lppd->wSpoolError <=0) || 
                       (lppd->lpProcsetstuff->savelevel >= 0));
    if (!(lppd->lpProcsetstuff->savelevel > 0))
        return(iRCount);

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    // L3_CLIP
    if (lppd->graphics.bClipSave)
    {
        short gstacklevel;            
        gstacklevel = GSStackNumPushed(lppd);
        lppd->graphics.GState = lppd->lpGSStack->elems[gstacklevel];
    }

   if (lppd->lpProcsetstuff->pagesaveLevel == lppd->lpProcsetstuff->savelevel)
   {
        // need to special case page restore
        AdobeOEMSendPSStub(lppd, PS_INDEX_RESTORE_BEGIN, NULL, 0);
        PSSendFragment(lppd, PSFRAG_pagecleanup);
        iRCount += PSGetFragmentLength(lppd, PSFRAG_pagecleanup);
        AdobeOEMSendPSStub(lppd, PS_INDEX_RESTORE_END, NULL, 0);

        lppd->lpProcsetstuff->pagesaveLevel = 0;
   }
   else
   {
        // Send the save object
        wsprintf(buf, "savelevel%d ", lppd->lpProcsetstuff->savelevel - 1);
        PSSendString(lppd, buf);
        iRCount += lstrlen(buf);

        // Send "restore"
        PSSendFragment(lppd, PSFRAG_restore);
        iRCount += PSGetFragmentLength(lppd, PSFRAG_restore);
   }
   (*tempptr->PSSendCRLF)(lppd);
   iRCount += 2;
   
   // pop out the saved pattern brushes created in this savelevel
   if (lpPBInfo)
   {   int i; 
       BOOL found = FALSE;
       
       for (i=0; i<MAXPATTERN; i++)
       {
          if (lpPBInfo->brush[i].bStyle && 
              lpPBInfo->brush[i].savelevel == lppd->lpProcsetstuff->savelevel)
             lpPBInfo->brush[i].bStyle = 0;
       }
       for (i=0; i<MAXPATTERN && !found; i++ )
          if (!lpPBInfo->brush[i].bStyle) found = TRUE;
       if (found) lpPBInfo->bBrushIndex = i-1;
   } 
   
   restoreUpdate(lppd);
   return(iRCount);
}

/************************************************************************
*
*                              saveUpdate
*
*   Function:     This function is used to keep track of the printer states
*                 (graphic state, font and procset) after a save.
*
*   Called:       static VOID NEAR PASCAL saveUpdate(LPPDEVICE lppd)
*
*   Parameters:   LPPDEVICE lppd -- pdevice pointer
*
*   Returns:      nothing
*
*************************************************************************/

static VOID NEAR PASCAL saveUpdate(LPPDEVICE lppd)
{
    short gstacklevel;
    GSTATE tempgstate;
    BOOL  fGray;

    GSStackPush(lppd) ;         // chunk a gstate image onto the stack

    lppd->lpProcsetstuff->savelevel ++;     // increment the save level

    // Now put the data from the gstate stack back in the printer in
    //  such a way that the gstate stack correctly emulates the printer

    gstacklevel = GSStackNumPushed(lppd);
    tempgstate = lppd->lpGSStack->elems[gstacklevel + 1];

//    lppd->graphics.ColorSpace = -1;
//    lppd->graphics.CRDActive  = (DWORD) -1;

    while ( (tempgstate.savelevel != -1) &&
              (tempgstate.savelevel <= lppd->lpProcsetstuff->savelevel))
    {
         PSSendGSave(lppd);

         // Emit the PS to update the printer to this level
         fGray = PSSendColor(lppd, tempgstate.dColor);
         PSSendColorOP(lppd,fGray); 


         PSSendPenWidth(lppd, tempgstate.ptPen);
         PSSendPenCap(lppd, tempgstate.bPenCap);
         PSSendPenJoin(lppd, tempgstate.bPenJoin);
         PSSendPenMiter(lppd, tempgstate.sPenMiter);
         PSSendPenStyle(lppd, tempgstate.bPenStyle,tempgstate.ptPen.x);

         // bBrushStyle;    these items get set in GSTATE, then overwritten
         // bBrushHatch;    by lppd items when used.

         PSSendCTM(lppd, (LPPSMATRIX)(tempgstate.jobCTM));

         // The font data is waxed and we are not going to restore it
         tempgstate.currentFontData.FontName[0] = (char)0;
         tempgstate.TextCurrentPoint.x = -1;
         tempgstate.TextCurrentPoint.y = -1;

         // Current cliprect associated with this
         if ((tempgstate.cliprect[0] != 0) ||
              (tempgstate.cliprect[1] != 0) ||
              (tempgstate.cliprect[2] != 0) ||
              (tempgstate.cliprect[3] != 0))
         {
                     LPASCIIBINPTRS tempptr;

                     tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

                     PSSendClipRect(lppd, tempgstate.cliprect[0],
                                    tempgstate.cliprect[1],
                                    tempgstate.cliprect[2],
                                    tempgstate.cliprect[3]);
         }

         gstacklevel = GSStackNumPushed(lppd);
         tempgstate = lppd->lpGSStack->elems[gstacklevel+1];
    }

     // L3_CLIP
     if (lppd->graphics.bClipSave)
     {
         PSSendFragment(lppd, PSFRAG_clipsave);

         // Emit the PS to update the printer to this level
         tempgstate = lppd->graphics.GState;
         fGray = PSSendColor(lppd, tempgstate.dColor);
         PSSendColorOP(lppd,fGray); 
         PSSendPenWidth(lppd, tempgstate.ptPen);
         PSSendPenCap(lppd, tempgstate.bPenCap);
         PSSendPenJoin(lppd, tempgstate.bPenJoin);
         PSSendPenMiter(lppd, tempgstate.sPenMiter);
         PSSendPenStyle(lppd, tempgstate.bPenStyle,tempgstate.ptPen.x);
         PSSendCTM(lppd, (LPPSMATRIX)(tempgstate.jobCTM));
         PSSendClipRect(lppd,
             tempgstate.cliprect[0], tempgstate.cliprect[1],
             tempgstate.cliprect[2], tempgstate.cliprect[3]);
      }

     PSSetNoCurrentPoint(lppd);
     lppd->lpGSStack->lpgGState->savelevel = lppd->lpProcsetstuff->savelevel;
     lppd->graphics.bCRDSent[lppd->lpProcsetstuff->savelevel] =
     lppd->graphics.bCRDSent[lppd->lpProcsetstuff->savelevel - 1] ;
     lppd->graphics.bCSASent[lppd->lpProcsetstuff->savelevel] =
     lppd->graphics.bCSASent[lppd->lpProcsetstuff->savelevel - 1] ;
     lppd->lpFontDataList->iDefinedFonts[lppd->lpProcsetstuff->savelevel] =
     lppd->lpFontDataList->iDefinedFonts[lppd->lpProcsetstuff->savelevel-1]; // this saveleve>0 (just ++)

}

/************************************************************************
*
*                           restoreUpdate
*
*  Function:     This function is used to keep track of the printer states
*                (graphic state, font and procset) after a save.
*
*  Called:       static VOID NEAR PASCAL restoreUpdate(LPPDEVICE lppd)
*
*  Parameters:   LPPDEVICE lppd -- pdevice pointer
*
*  Returns:      nothing
*
************************************************************************/

static VOID NEAR PASCAL restoreUpdate(LPPDEVICE lppd)
{
   WORD   stackIndex ;

   stackIndex = lppd->lpGSStack->num_pushed ;

    lppd->lpProcsetstuff->savelevel --;     // decrement the save level

    // Pop Gstate stack until we get to the level which emulates the last save

    lppd->lpGSStack->elems[stackIndex+1].savelevel = -1;
    while ( (lppd->lpGSStack->num_pushed > 0)  &&
      (lppd->lpGSStack->elems[lppd->lpGSStack->num_pushed - 1].savelevel >= lppd->lpProcsetstuff->savelevel) &&
                (lppd->lpGSStack->lpgGState->savelevel > 0) )
    {
        GSStackPop(lppd);
    }

   // Go thru every CRD in the stack and invalidate all
   //    downloaded CRDs of this type
   for( stackIndex = 0; stackIndex <= (WORD)lppd->lpProcsetstuff->savelevel ; ++stackIndex)
   {
      lppd->graphics.bCRDSent[stackIndex] &= ~(lppd->graphics.CRDClear);
      if (lppd->graphics.CSAClear)
         lppd->graphics.bCSASent[stackIndex] = 0;
   }

    // Update the font and procset data to the current save level
    ResetFontDataList(lppd);
    resetProcsetList(lppd);
//   lppd->graphics.ColorSpace = -1;
//   lppd->graphics.CRDActive  = (DWORD) -1;


   PSSetNoCurrentPoint(lppd);
}

/************************************************************************
*
*                           PSSetNoCurrentPoint
*
*  Function:    This function sets the TextCurrentPoint state to an impossible
*               value, representing the PostScript 'no current point' state.
*               Any operation which changes the PostScript current point to
*               an indeterminate value should call this routine.
*
*  Called:      void FAR PASCAL PSSetNoCurrentPoint(LPPDEVICE lppd)
*
*  Parameters:  LPPDEVICE lppd -- pdevice pointer
*
*  Returns:     nothing
*
************************************************************************/

void FAR PASCAL PSSetNoCurrentPoint(LPPDEVICE lppd)
{
     lppd->lpGSStack->lpgGState->TextCurrentPoint.x = -1;// set to impossible values
     lppd->lpGSStack->lpgGState->TextCurrentPoint.y = -1;
     lppd->job.bfIsCurrentPoint = FALSE;

     return;
}

/************************************************************************
*  Fix bug 164116 (2)
************************************************************************/

LANGID GetSystemDefaultLangID()
{
    BYTE     szBuff[256];
    HKEY     hKey;
    DWORD    cb;
    DWORD    dwType;
    LANGID   LangID = 0;

    lstrcpy (szBuff, "Control Panel\\International");
    if (ERROR_SUCCESS == RegOpenKey (HKEY_CURRENT_USER, szBuff, (HKEY FAR *)&hKey))
    {
        cb = sizeof (szBuff);
        if (ERROR_SUCCESS == RegQueryValueEx (hKey, "Locale",
                              0, &dwType, (LPSTR)szBuff, (LPDWORD)&cb))
        {
            LangID = ui32toSINT(szBuff + 4);
        }
        RegCloseKey(hKey);
    }
    return LangID;
}

/************************************************************************
*
************************************************************************/

BOOL FAR PASCAL TSetVMMark(LPPDEVICE lppd, WORD wOption, BOOL PageSetup)
{
   return FALSE;    // SAVE_RESTORE 

   switch (wOption)
   {
       case 0:
           PSSendSave(lppd, PageSetup);
           return TRUE;
       case 1:          
           if ((lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED) &&
               DoVMTracking(lppd))
           {
               PSSendSave(lppd, PageSetup);
               return TRUE;
           }
           break;
       case 2:
           if ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_PORTABLE) &&
               DoVMTracking(lppd))
           {
               PSSendSave(lppd, PageSetup);
               return TRUE;
           }
           break;
   }
   return FALSE;
}

/************************************************************************
*
************************************************************************/

short FAR PASCAL TCleanToVMMark(LPPDEVICE lppd, WORD wOption)
{
   // if we send CRD or CSA in this savelevel, it will overwrite the
   // CRD and CSA sent in previous savelevel. So, we have to update the
   // CRD and CSA history to disable the old CRD and CSA.
   WORD  i;
   for( i = 0; i <= (WORD)lppd->lpProcsetstuff->savelevel ; i++)
   {
      lppd->graphics.bCRDSent[i] &= ~(lppd->graphics.CRDClear);
      if (lppd->graphics.CSAClear)
         lppd->graphics.bCSASent[i] = 0;
   }
   return 0;     // SAVE_RESTORE

   switch (wOption)
   {
       case 0:
           return (PSSendRestore(lppd));
       case 1:
           if ((lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED) &&
               DoVMTracking(lppd))
           {
               return (PSSendRestore(lppd));
           }
           break;
       case 2:
           if ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_PORTABLE) &&
               DoVMTracking(lppd))
           {
               return (PSSendRestore(lppd));
           }
           break;
    }
    return 0;
}

/************************************************************************
*
************************************************************************/

int FAR PASCAL SavePassthroughInfo(LPPDEVICE lppd)
{
    LPASCIIBINPTRS tempptr;
    short sRC = RC_ok;
    LPPASSTHROUGHHEADER lpHdr;
    LPBYTE lpTmp;
    LPPASSTHROUGHENTRY currententry, previousentry;
    CHAR  lpPassID[32];

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    if ( lppd->lpPassThroughRootEntry == NULL)
    {
        lpTmp  = GlobalAllocPtr(GHND|GMEM_DDESHARE,ONEBUF + HEADERSIZE);

        if (lpTmp != NULL)
        {
            
            lppd->lpPassThroughRootEntry =
                lppd->lpPassThroughCurrentEntry = lpTmp;
            lpHdr = (LPPASSTHROUGHHEADER)lpTmp;
            lpHdr->lpNextBufferEntry = NULL;
            lpHdr->nIndex = 0;
            currententry = (LPPASSTHROUGHENTRY)((BYTE *)lpTmp+ HEADERSIZE);
            currententry->passthroughIndex = 0;
            lppd->iCurrIndex = 0;
        }
        // if can't allocate the memory return error
        else 
            return(sRC=RC_fail);
    }
    else                        
    {
        // update PassThrough info, and its pointer
        // 4K per block, 128 entry per block
        lpHdr = (LPPASSTHROUGHHEADER)lppd->lpPassThroughCurrentEntry;
        previousentry = (LPPASSTHROUGHENTRY)((BYTE *)lpHdr + HEADERSIZE + lppd->iCurrIndex * sizeof(PASSTHROUGHENTRY));

        // bug # 280658
        if ((lppd->iCurrIndex + 1) < ONEBUF/sizeof(PASSTHROUGHENTRY))
        {
            currententry =  (LPPASSTHROUGHENTRY)((BYTE *)previousentry + sizeof(PASSTHROUGHENTRY));
            lpHdr->nIndex = lppd->iCurrIndex += 1;
        }
        else
        {
            lpHdr->nIndex = lppd->iCurrIndex;

            lpTmp  = GlobalAllocPtr(GHND|GMEM_DDESHARE,ONEBUF + HEADERSIZE);
                            
            if (lpTmp != NULL)
            {

                lpHdr->lpNextBufferEntry = lpTmp;
                lpHdr = (LPPASSTHROUGHHEADER)lppd->lpPassThroughCurrentEntry = (LPPASSTHROUGHHEADER)lpTmp;
                lpHdr->nIndex = 0;
                lpHdr->lpNextBufferEntry = NULL;
               
                lppd->iCurrIndex = 0; //reset to 0 for new block

                currententry = (LPPASSTHROUGHENTRY)((BYTE *)lpTmp+ HEADERSIZE);
            }
            // if can't allocate the memory return error
            else 
            {
                 currententry = previousentry;
                 return(sRC=RC_fail);
            }
        }
        currententry->passthroughIndex = previousentry->passthroughIndex + 1; 
    }
    currententry->dataLen = 0;
    currententry->TickCount = GetTickCount();
    currententry->AsciiBinHandle = (unsigned short)(lppd->AsciiBinHandle);
    CreatePassThroughID(lppd, currententry, lpPassID);
    (*tempptr->PSSendDSC)(lppd, DSC_begindatacountedatend, (LPSTR)lpPassID);

    return sRC;
}

/************************************************************************
*
************************************************************************/

int FAR PASCAL PrintPassthroughInfo(LPPDEVICE lppd, int iCnt)
{
    LPASCIIBINPTRS tempptr;
    int    i;
    LPPASSTHROUGHENTRY currentpassthrough;
    LPPASSTHROUGHHEADER lpHdr;
    CHAR   tmp[32];
    int    nsize;
    CHAR   szTemp[64];
    int    iCount = iCnt;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    if (lppd->lpPassThroughRootEntry != NULL)
    {
        currentpassthrough = (LPPASSTHROUGHENTRY)(lppd->lpPassThroughRootEntry + HEADERSIZE);
        lpHdr = (LPPASSTHROUGHHEADER)lppd->lpPassThroughRootEntry;
        i = 0;
        (*tempptr->PSSendDSC)(lppd, DSC_datacount, (LPSTR)NULL);
        iCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
        while(TRUE) {
            if( currentpassthrough->dataLen > 0)
            {
                CreatePassThroughID(lppd, currentpassthrough, szTemp);
                lstrcat(szTemp, BLANK);
                wsprintf(tmp, "%lu", currentpassthrough->dataLen);
                lstrcat(szTemp, tmp);
                (*tempptr->PSSendDSC)(lppd, DSC_plus, (LPSTR)szTemp);
                iCount += (lstrlen(lppd->GlobalBuffer.lpStringAscii7)+2);
            }
            nsize = sizeof(PASSTHROUGHENTRY);
            i++;
            if ( i <= lpHdr->nIndex)
            {
                currentpassthrough = (LPPASSTHROUGHENTRY)((BYTE *)currentpassthrough + nsize);
            }
            else
            {
                if (lpHdr->lpNextBufferEntry == NULL)
                    break;
                else // start next chunk
                {
                    lpHdr = (LPPASSTHROUGHHEADER)lpHdr->lpNextBufferEntry;
                    currentpassthrough = (LPPASSTHROUGHENTRY)((BYTE *)lpHdr + HEADERSIZE);
                    i = 0;
                }
            }
             
        } // end while
    }
    return iCount;
}

/************************************************************************
*
************************************************************************/

VOID FAR PASCAL PrintPassthroughEndDSC(LPPDEVICE lppd)
{
    LPASCIIBINPTRS tempptr;
    char lpPassID[32];
    LPPASSTHROUGHENTRY currententry;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    // Send a CRLF.  This provides a PostScript language delimiter
    // between the raw printer data, and makes sure the following
    // DSC comment is in column 1.
    (*tempptr->PSSendCRLF)(lppd);

    if (lppd->lpPassThroughRootEntry != NULL)
    {
        currententry = (LPPASSTHROUGHENTRY)((BYTE *)lppd->lpPassThroughCurrentEntry+
                       HEADERSIZE + lppd->iCurrIndex * sizeof(PASSTHROUGHENTRY));

        CreatePassThroughID(lppd, currententry, lpPassID);
        currententry->dataLen += 2;
        // add CRLF as part of size
        (*tempptr->PSSendDSC)(lppd, DSC_enddatacountedatend, (LPSTR)lpPassID);
    }
}

/***********************************************************************
*                           CreatePassThroughID
*  Purpose: Create an Unique ID for BeginUncountedData/EndUncountedData
*      new DSC 3.1 comments.  
*
*  parameter:
*       LPPDEVICE lppd -- pdevice pointer
*
*  returns: LPSTR
*
***********************************************************************/
VOID FAR PASCAL CreatePassThroughID(LPPDEVICE lppd,
                                    LPPASSTHROUGHENTRY currententry,
                                    LPSTR    lpPassID)
{
   char sztmp[8];
   unsigned short  index;

   *lpPassID = 0;
   sztmp[0] = 0;
   wsprintf(lpPassID, "J%08lx",currententry->TickCount);
   _ltoa(currententry->AsciiBinHandle, sztmp, 10);
   lstrcat(lpPassID, sztmp);
   index = currententry->passthroughIndex + 1; // start from 1 instead of 0
   wsprintf(sztmp, "%d", index);
   lstrcat(lpPassID, sztmp);

   // add pass through #
   lpPassID[lstrlen(lpPassID) + 1]= '\0';
}

