/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: STRBLT.C                                                     */
/*                                                                           */
/* Description: This module contains the functions for ...                   */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_TEXTOUTSEG)


DWORD _loadds FAR PASCAL DevExtTextOut(LP, short, short, LPRECT, LPSTR, short,
                                       LPPSFONTINFO, LPDRAWMODE, LPTEXTXFORM, 
                                       LPSHORT, LPRECT, WORD);

/* ***************************************************************** */

DWORD _loadds FAR PASCAL StrBlt(LP lp,SHORT sX,SHORT sY,LPRECT lpClipRect,
                                LPSTR lpz,SHORT sCount,LPPSFONTINFO lpFontInfo,
                                LPDRAWMODE lpDrawMode,LPTEXTXFORM lpTextXForm)
{
   DWORD dwRC ;

   dwRC = DevExtTextOut(lp,sX,sY,lpClipRect,lpz,sCount,lpFontInfo,
                        lpDrawMode,lpTextXForm,(LPSHORT)0L,
                        (LPRECT)0L,(WORD)0) ;

  return(dwRC) ;
}
