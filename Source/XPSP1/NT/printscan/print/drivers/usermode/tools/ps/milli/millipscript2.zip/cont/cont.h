/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: CONT.H                                                       */
/*                                                                           */
/* Description: This module contains defines for \cont                       */
/*                                                                           */
/*****************************************************************************/

#define MAX_DEVICES            10
typedef struct _DEVICELIST
        {
        int numdevices;
        char devicenames[MAX_DEVICES][DEVNAMESIZE];
        } DEVICELIST, FAR * LPDEVICELIST;

int FAR PASCAL DoEnumDevices(LPSTR, HANDLE, LPDEVICELIST);
