/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: GDIDM.H                                                      */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/

/*--------------- driver helper routines supplyed by GDI -----------------*/

int  FAR PASCAL dmRealizeObject(LP,SHORT,LPSTR,LPSTR,LPTEXTXFORM);
int  FAR PASCAL dmOutput(LP, int, int, LPPOINT, LPPEN, LPBR, LPDRAWMODE, LPRECT);
long FAR PASCAL dmStrBlt(LP, int, int, LPRECT, LPSTR, int, LPPSFONTINFO, LPDRAWMODE, LPTEXTXFORM);
BOOL FAR PASCAL dmBitblt(LP, int, int, LPBITMAP, int, int, int, int, long, long, LPDRAWMODE);

CO  FAR PASCAL   dmPixel(LP, int, int, CO, LPDRAWMODE);
int FAR PASCAL   dmScanLR(LP, int, int, CO, int);
RGB FAR PASCAL   dmColorInfo(LP, RGB, LPCO);
short FAR PASCAL dmEnumObj(LP,short,FARPROC,LP);



