
/* CM_VerSion parse.c atm05 1.5 11080.eco sum= 33115 */
/* CM_VerSion parse.c atm04 1.13 05715.eco sum= 30113 */
/*
  parse.c - parse a Type 1 font

Copyright (c) 1989-1992 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks
of Adobe Systems Incorporated.

Original version: Paul Haahr: Wed Jun 12 10:26:04 1991
Edit History:
Ron Fischer: Thu Mar 4 16:05:04 1993
Paul Haahr: Fri Oct 2 11:10:49 1992
Naoki Hotta: Mon Aug 24 15:19:02 PDT 1992
Craig Rublee: Wed May 13 18:42:21 PDT 1992
Paul Haahr: Sun Nov 24 19:31:50 1991
John Nogrady: Fri Aug 23 15:38:37 1991
End Edit History.

Revision History
  92/8/24 15:19:02 hotta
  Added new composite font support.
  New entry point ParseEncoding() for new composite control file and
  for composite font rearrange file.
End Revision History.

*/
#include <stdio.h>

#ifdef FAKEKANJI
#include "kmisc.h"
#endif

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif

#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES
#include FP
#include BUILDCH
#include PARSE
#include BLEND
#include "chartype.h"
#include "strtofix.h"

#include <setjmp.h>
#if OS==os_aix
#include <stddef.h>
#endif


/* NOTE ON DOUBLE ENCRYPTION:  The RunInt callback is used to indicate
 * whether double encryption is on for charStrings and subrs.  If the
 * key value is "eCCRun" double encryption is on.  If it is "CCRun" or 
 * not present single encryption is on.  Double encryption is slightly
 * different from eexec encryption (described in the black book).  See
 * ATM-J (Windows or Mac), or the OEM/ATM code for an example of it's
 * usage.
 */


/*********************** O P T I O N S ***********************/


/*
 * HEXENCODING -- if true, the parser will be able to deal with hex format
 *      eexec fonts; the only fonts that are really in this format are
 *      uncompressed fonts on unix machines
 */

#ifndef HEXENCODING
#define HEXENCODING     1
#endif

/*
 * FAST_GETTOKEN -- if true, GetToken doesn't check for buffer overflow in 
 * tokens other than charstrings.  note that overflow can only occur if a 
 * token is longer than TOKENBUFFER_MIN from parse.h, which should be >= 1024.  
 * I strongly recommend turning this off.
 */

#ifndef FAST_GETTOKEN
#define FAST_GETTOKEN   0
#endif


/******************** D E F I N I T I O N S ********************/


/* offsetof should be in <stddef.h>, but not all machines have one */
#ifndef offsetof
#define offsetof(type,identifier) ((long)&((type *)0)->identifier)
#endif

#ifndef lengthof
#define lengthof(array) ((sizeof (array)) / (sizeof (array[0])))
#endif

#if __GNUC__
/* ANSI does not like this.  Try it the other way.  rff 10/13/93 */
/*typedef void volatile noreturn;*/
typedef void noreturn;
#elif (OS==os_thinkc)
#define noreturn void
#else
typedef void noreturn;
#endif

#define isodd(n)        ((n)&1)
#define streq(s, t)     (strcmp(s, t) == 0)
#define isprefix(s, t)  (strncmp(s, t, (sizeof t) - 1) == 0)

#define MAXLEN_PSNAME   128     /* longest legal PostScript name token */
#define MAXSTDS         2
#define MAXBLUELEN      (12+2)
#define MAXOTHERBLUELEN (12-2)


#if BCMAIN
extern IntX debug_parse;
#endif


/*
 * notes on the implementation of this parser
 *      Paul Haahr, 18 June 1991
 *
 * A number of tricks are played with pointers and the c type system, in order 
   to treat things that are substantially similar with the same code.  See, 
   for example the MakeSetProc() macro used by ParseDict.  (I believe all of 
   this is portable, but I could be wrong.)  I use the c preprocessor in far 
   too many gross ways.  this (combined with the ugly casting mentioned above) 
   are my half-baked attempts at using c as a polymorphic language.  Again, I 
   believe this is all portable.  Declarations marked with the comment 
   ``CACHE'' are local variables used to cache globals.  Best performance and 
   smallest size will result if these are put in registers.

 * Because of the deficiencies of think c as a compiler, register declarations
 * have been put in any spot where they did not increase code size.
 */


/*
 * private types
 */

typedef union { void *p; Int32 i; } Arg;

typedef struct {
  char *name;
  IntX (*proc) ARGDECL1(Arg *, u);
  Arg u;
} Field;

typedef struct {
  Field *table;
  IntX len;
  void (*init) ARGDECL0();
} Dict;

PRIVATE Dict FontDict, Private, BlendDict, PrivateBlend, CompositeDict, DerivedDict;
PRIVATE Dict CIDFontDict, EncodingDict;

/* Token -- describes a PostScript lexical entity */
typedef enum {
        t_string,       /* (String) */
        t_name,         /* /Name */
        t_hex,          /* <HexString> */
        t_number,       /* integer or real */

        t_open,         /* '[' or '{' */
        t_close,        /* '}' or ']' */


#if COMPOSITE_FONT
        t_origfont,     /* %%OriginalFont */
        t_endfont,      /* %%EndAdobeStdCompFont_BDY */
/*#if COPYPROTECT*/
        t_checksum,     /* %%CheckSum */
        t_atm,          /* %%ATM */
/*#endif*/
        t_begindata,	/* %%BeginData */ 

        t_subcategory,	/* %ADOResourceSubCategory */
        t_startrearrangedfont, /* %ADOStartRearrangedFont */
#endif

        t_id,           /* anything else */
        t_EOF,          /* end of file */
        t_none          /* empty value for untoken */
} Token;

#if BCMAIN
char *tokenname[] = {
  "string", "name", "hex", "number", "open", "close",
  "id", "EOF"
};
#define hascontents(t)  (t==t_string||t==t_number||t==t_id||t==t_name)
#endif

typedef struct {
  boolean (*useStd) ARGDECL0();
  boolean (*useSpecial) ARGDECL1(IntX, count);
  boolean (*special) ARGDECL2(IntX, i, char *, charname);
} EncodingProcs;


/*
 * global variables
 *      put all file statics here
 *      i don't think there should be any non-constant block scoped statics
 *      nothing from parse.c should be exported except the functions;
 */

PRIVATE void *clientHook;		/* Client data to pass through */
PRIVATE ParseFontProcs *procs;          /* support and result return routines */
PRIVATE jmp_buf parser_exception;       /* non-local goto target for parse errors */

PRIVATE GrowableBuffer *tokenbuf;       /* handle on where to build the token */
PRIVATE char *token;                    /* the string value of the current token */
PRIVATE boolean isreal;                 /* was the last number token not an integer? */

PRIVATE FontDesc *font;         /* the font data */
#define fontval (&font->values[0])
PRIVATE Int32 fontType;         /* must be 1 (normal) or 4 (cartridge) */
PRIVATE Fixed stemWidth;        /* the guessed stem width from the /Erode proc */
PRIVATE CardX numAxes;          /* number of design axes for a multiple master font */

PRIVATE boolean didPrivate;     /* has the private dictionary been parsed? */
PRIVATE boolean didCharStrings; /* have we read the CharStrings? */
PRIVATE boolean didSubroutines; /* how about those Subrs? */
PRIVATE boolean copiedBlendDict, copiedPrivateBlend;

PRIVATE EncodingProcs encoding, accentEncoding;

#if COMPOSITE_FONT
enum ParseState {
  NoHeader,
  Type1Font,
  AdobeStdCompFont,
  AdobeStdCompFont_BDY,
  AdobePGFont,
  AdobePGFont_CSA,
  AdobeDerivedFont,
  AdobeRearrangedFont,
  AdobeCMap,
  AdobeCIDFont,
  AdobeCompositeFont
};
PRIVATE enum ParseState parsestate;     /* may have to be passed to some callbacks */
PRIVATE boolean isCompFont;                /* composite font extensions, etc. */

PRIVATE IntX fontVersion;        /* major version number */

PRIVATE Token lasttoken;              /* remember last type of a token */

PRIVATE boolean DoFontProtect ARGDECL0();
PRIVATE boolean DoCIDProtect ARGDECL0();

PRIVATE IntX lastnumber;              /* remember last number for an operator */
PRIVATE char lastname[MAXLEN_PSNAME]; /* remember last name for encoding */

#endif /* COMPOSITE_FONT */

#if STREAMFONT
PRIVATE Card32 streamCount = 0;
PRIVATE boolean streamData = true;
PRIVATE boolean syntheticFont = false;
#endif

/*
 * error handling
 */

/* ParseError -- non-local goto for parse errors */
PRIVATE noreturn ParseError ARGDEF1(int, e) {
  longjmp(parser_exception, e);
}


/*
 * decryption
 */

#define C1              ((Card16) 52845)
#define C2              ((Card16) 22719)
#define key_eexec       ((Card16) 55665)
#define key_charstring  ((Card16) 4330)


/*
 * input routines
 */

#define GetChar()       (in.buf < in.bufend ? (IntX)(*in.buf++) : FillBuf())
#define SkipChar()      ((void) (in.buf++ < in.bufend || FillBuf()))

struct {                /* current input state */
  Card8 **handle;               /* pointer to data returned from GetBytes */
  Card8 *buf;                   /* the current input buffer */
  Card8 *bufend;                /* end of input data */
  Card8 *extra;                 /* data past the end of the buffer */
  IntX nybble;                   /* half of a pending 2 hex digit sequence */
  boolean eof;                  /* have we hit an EOF? */
  boolean ishex;                /* are we in a hex encoded part of a file? */
  boolean iseexec;              /* are we in an eexec encrypted part of the file */
  boolean skipping;             /* true if skipping a section: for eexec/closefile detection */
#if COMPOSITE_FONT
  boolean isprotect;            /* true if in copy protect section */
#endif
  Card16 eekey;                 /* eexec current encryption key */
  Int16 ungot;                  /* ungotten character for GetToken() */
#if RANDOMACCESS
  CardX bufno;                  /* count of GetBytes() calls */
  IntX bufshrink;		/* fudge factor for first buffer */
#define	IN_BUFSHRINK	in.bufshrink
  GrowableBuffer *lookaside;    /* lookaside buffer for eexec keys and whitespace indices */
  Card16 *keybuf;               /* eexec key for each character in the buffer! */
  CardX skipcount;              /* number of whitespace characters we've seen so far */
  CardX skipmax;                /* maximum number of skipped characters */
  CardX *skip;                  /* pointer into the growable buffer */
  Card8 *bufstart;              /* for doing whitespace correction */
#else
#define	IN_BUFSHRINK	0
#endif
#if COMPOSITE_FONT
  IntX strlen;                  /* string token length -- used only for SubsVector */
  IntX bufshrunk;		/* number of bytes shrunk by eexec decryption */
#endif

} in;


#if STREAMFONT

/* The stream font code: This code streams out all of the decrypted font 
   information (with some key exceptions) through the FontDataStream
   callback.  This is user by the streamer code to stream a font, preserving
   any general PostScript stuff.  Certain items are not streamed out:
   subrs, charstrings, and dictionary entries that may be changed by the
   user.  This allows a user to change encoding, encryption, sparsing, 
   flattening, the name, and the unique id of the font with out changing
   anything else.
 */

/* Look for a key word.  If it's found inform the user through the 
   KeyPosition callback. */

PRIVATE void CheckKeyWord ARGDEF1(char *, token)
{
Card8 keyType = 0;
IntX offset = 8;

if (streq(token, "FontName"))
   keyType = FONTNAME_POSITION;
else if (streq(token, "Encoding"))
   keyType = ENCODING_POSITION;
else if (streq(token, "FullName"))
   keyType = FULLNAME_POSITION;
else if (streq(token, "UniqueID"))
   keyType = UID_POSITION;
else if (streq(token, "FontType"))
   keyType = FONT_TYPE_POSITION;
else if (streq(token, "lenIV"))
 { keyType = LENIV_POSITION;
   offset = 6;
 } /* end else */

if (keyType && *procs->KeyPosition)
 { if (!(*procs->KeyPosition)(keyType, streamCount-offset))
      ParseError(PE_CALLER);
   streamData = false;	/* Don't want to output the value--let the user. */
 } /* end if */

} /* end CheckKeyWord() */

/* I need these prototype for the next couple functions */
PRIVATE Token GetToken ARGDECL0();
PRIVATE IntX FillBuf ARGDEF0();

/* When using streamer to produce sparsed fonts, etc. the BaseFontName
   entry is added to the FontInfo dictionary.  This entry contains the
   name of the font the streamed font is based upon.  This is THE clue
   that the font is a streamed font.  Of course I have to increase the
   count of items in the FontInfo dict by 1.
*/
PRIVATE void InsertBaseFontName ARGDEF0()
{
Token t;

if (!(*procs->KeyPosition))
   return;

streamData = false;
t = GetToken();
if (t == t_number)       /* If not, I'm hosed */
 { Int32 entries, high;
   entries = strtol(token, NULL, 10) + 1;
   high = (Int32) entries/10;
   if (high)
    { if (!(*procs->FontDataStream)((char)(high+'0'), 1))
         ParseError(PE_CALLER);
      streamCount++;
    } /* end if */
   if (!(*procs->FontDataStream)((char)((entries-(high*10))+'0'), 1))
      ParseError(PE_CALLER);
   if (!(*procs->FontDataStream)(' ', 1))
      ParseError(PE_CALLER);
   streamCount += 2;
   streamData = true;
 } /* end if */
GetToken();     /* dict */
GetToken();     /* dup */
GetToken();     /* begin */
/* Let the callback insert the /BaseFontName entry */
if (!(*procs->KeyPosition)(FONTINFO_POSITION, streamCount))
   ParseError(PE_CALLER);
} /* end InsertBaseFontName() */


/* This fuction allow us to inspect the character in the in.buf*/
/* IMPORTANT: CALLER SHOULD PASS A BUFFER THAT IS readNCh+1 (for the null terminator)
AND CHECK THE RETURN VALUE TO BE SURE WE RETURN AS MANY CHARACTER AS ASKED*/
PUBLIC IntX InspectChars ARGDEF3 (IntX, start, IntX, readNCh, char*, buffer)
{
   char *string;
   IntX i;

   if (in.bufend-in.buf < readNCh)
     readNCh = in.bufend-in.buf;

   string = (in.buf+start);
   for (i = 0; i< readNCh; i++)
     buffer[i] = string[i];

   buffer[i] = '\0';

   return readNCh;


}

/* Create my own GetChar() function -- this will let me intercept the
   decrypted characters and pass them back to the user. */

#undef GetChar

PRIVATE IntX GetChar(void) 
{
IntX c = (in.buf < in.bufend ? *in.buf++ : FillBuf());
if (streamData && (*procs->FontDataStream))
 { if (!(*procs->FontDataStream)((char)c, 1))
      ParseError(PE_CALLER);
   streamCount++;
 } /* end if */

return c;
}



/* Usually the parser just stops as soon as it has a Private Dict, subrs,
   and charstrings.  For streaming we want everything, down to the last
   eof.  Also, the zeros for padding are converted to garbage by decryption
   so I rewrite them out. */

PRIVATE void ReadCharsUntilEOF ARGDEF0()
{ 
   Token t = t_id;
   Card32 lastEnd = 0; /* Need to know the last "end" in an unencrypted font */
   IntX fileWasEncrypted = false;

   in.skipping = true;     /* You don't want to recognize "currentfile" */

   while (t != t_EOF)
   { 
      if (!strncmp(token, "closefile", 9))
      { 
         fileWasEncrypted = true;

         /* Step back, before the whole "mark currentfile closefile" stuff */
         if (!(*procs->KeyPosition)(EEXEC_OFF_POSITION, streamCount-27))
            ParseError(PE_CALLER);

         streamData = false;
         /* Get rid of the 256 encrypted "zeros".  These cause the tokenizer 
            to misfunction... */

         if (in.iseexec)
         { 
            IntX i;
            char c;
            for (i = 0; i < 256; i++)
               c = (char)GetChar();
         } /* end if */

         do
         { 
            t = GetToken();
            if (!strncmp(token, "cleartomark", 11))
               streamData = true;
         } while (in.buf < in.bufend);

      /* In the hex case if in.extra has data it will be the cleartomark stuff */
         if (in.ishex && in.extra)
         { 
            while (in.buf < in.bufend)
            { 
               t = GetToken();
               if (!strncmp(token, "cleartomark", 11))
                  streamData = true;
            } /* end while */
         } /* end if */
      } /* end if (token==closefile)*/
//need to read the end of buffer.
// bug 1866323 Formata-LightExpert terminate prematurely.
//      else if (in.buf >= in.bufend)
//        break;
      else if (!strncmp(token, "end", 3))
      { 
         lastEnd = streamCount;
         t = GetToken();
      } /* end else */
      else
         t = GetToken();		/* Skip everything until closefile found */
   } /* end while */

   /* Send this signal even if the current font is not encrypted--the
      font I'm creating may be encrypted so it would need this marker. 
      Note that this assumes "end" is the last string in the file! */
   if (lastEnd == 0) /* When end is last token lastEnd doesn't get set */
      lastEnd = streamCount;
   if (!fileWasEncrypted)
      if (!(*procs->KeyPosition)(EEXEC_OFF_POSITION, lastEnd-5))
         ParseError(PE_CALLER);

   if (!(*procs->FontDataStream)(EOF, 1))
      ParseError(PE_CALLER);

} /* end ReadCharsUntilEOF() */

PRIVATE void SpecialAttribute ARGDEF1(Card16, type)
{
	if (*procs->FontAttribute && !(*procs->FontAttribute)(type))
		ParseError(PE_CALLER);
}

#endif /* STREAMFONT */

/* This routine is used to backup 1 character in the parse input stream. 
   Such a simple operation is made into a procedure so that the STREAMFONT
   section is not repeated 10 times through out the code.  Also, this is
   related to GetChar() so it is somewhat appropriate here....
 */

PRIVATE void Backup1Position ARGDEF1(char, c)
{
*--in.buf = (Card8)c;

#if STREAMFONT
if (streamData && *procs->KeyPosition)
 { if (!(*procs->KeyPosition)(BACKUP_POSITION, streamCount-1))
      ParseError(PE_CALLER);
   streamCount--;
 } /* end if */
#endif /* STREAMFONT */

} /* end Backup1Position() */


/* This debugging option will not work with STREAMFONT! */
#define SAVE_GOTTEN_CHARS 0
#if SAVE_GOTTEN_CHARS
#undef GetChar()

PRIVATE IntX FillBuf ARGDEF0();
IntX GetChar(void) {
  IntX c = (in.buf < in.bufend ? *in.buf++ : FillBuf());
  static FILE *fp = NULL;
  if (fp == NULL)
    fp = fopen("foo", "w");
  putc(c, fp);
  return c;
}
#endif /* SAVE_GOTTEN_CHARS */

#if HEXENCODING
/* HexConvert -- translate an input buffer of ascii hex strings into a binary sequence */
PRIVATE procedure HexConvert ARGDEF0() {
  register IntX first, c;
  register Card8 *s, *t, *end;

  s = t = in.buf;
  end = in.bufend;
  first = in.nybble;
  while (s < end) {
    if ((c = atmparse_chartab[*s++]) & ISWHITESPACE) {
#if RANDOMACCESS
      if (in.skipcount >= in.skipmax) {
        if (!(*procs->GrowBuff)(in.lookaside, TOKENBUFFER_GROW, true, clientHook))
          ParseError(PE_BUFFSMALL);
        in.skipmax = (CardX)in.lookaside->len / (sizeof (CardX));
        in.skip = (CardX *) in.lookaside->ptr;
      }
      in.skip[in.skipcount++] = t - in.buf;
#endif
      continue;
    }
    if ((c & ISHEXDIGIT) == 0) {
      --s;
      if (first >= 0)
        --s;
      MEMMOVE(s, t, end - s);
      in.extra = &t[end - s];
      break;
    }
    c &= HEXVAL;
    if (first < 0)
      first = c << 4;
    else {
      *t++ = (Card8)(first | c);
      first = -1;
    }
  }
  in.nybble = first;
  in.bufend = t;
#if RANDOMACCESS
  in.bufstart = in.buf;
#endif
#if COMPOSITE_FONT
  in.bufshrunk += s - t;
#endif
}
#endif  /* HEXENCODING */

/* DecryptBuf -- perform the eexec decryption on an input buffer */
PRIVATE procedure DecryptBuf ARGDEF0() {
  register CardX cipher, key;
  register Card8 *s, *bufend;

#if RANDOMACCESS
  register Card16 *keyp;
  Card32 buflen = sizeof (*in.keybuf) * SubtractPtr(in.bufend, in.buf) + in.skipcount * sizeof *in.skip;
  if (in.lookaside->len < buflen) {
    if (!(*procs->GrowBuff)(in.lookaside, buflen - in.lookaside->len, true, clientHook))
      ParseError(PE_BUFFSMALL);
    in.skipmax = (CardX)in.lookaside->len / (sizeof (CardX));
    in.skip = (CardX *) in.lookaside->ptr;
  }
  keyp = in.keybuf = (Card16 *) &in.skip[in.skipcount];
  in.bufstart = in.buf;
#endif

#if STREAMFONT

  for (s = in.buf, bufend = in.bufend, key = in.eekey; s < bufend; s++) {
#if RANDOMACCESS
    *keyp++ = key;
#endif
    cipher = *s;
    *s = (Card8)(cipher ^ (key >> 8));
    key = (cipher + key) * C1 + C2;
    if (((Int32)s - 21) >= (Int32)in.buf)
     { if (iswhitespace(*s) && !strncmp((char *)s-21, "currentfile closefile", 21))
        { in.iseexec = false;
          break;
        } /* end if */
     } /* end if */
  }
  in.eekey = key;

#else

  for (s = in.buf, bufend = in.bufend, key = in.eekey; s < bufend; s++) {
#if RANDOMACCESS
    *keyp++ = key;
#endif
    cipher = *s;
    *s = (Card8)(cipher ^ (key >> 8));
    key = (cipher + key) * C1 + C2;
  }
  in.eekey = key;

#endif /* STREAMFONT */
}


/* FillBuf -- fill the input buffer, possibly decrypt */
PRIVATE IntX FillBuf ARGDEF0() {
    CardX len;

    if (in.extra != NULL) {
      IntX c;
      in.bufend = in.extra;
      in.extra = NULL;
      in.iseexec = false;
#if STREAMFONT				/* This is a recursive call to */
      if (streamData)			/* GetChar()--If I don't turn off */
       { streamData = false;		/* output I get a repeated character. */
         c = GetChar();
         streamData = true;
       } /* end if */
      else				/* Don't lose this else! */
#endif
      c = GetChar();
      return c;
    }
    if (in.eof)
      return EOF;
    if (!(*procs->GetBytes)((char ***)&in.handle, &len))
      ParseError(PE_READ);
    if (len == 0) {
      in.eof = true;
      return EOF;
    }

#if COMPOSITE_FONT
    in.bufshrunk = 0;
#endif
#if RANDOMACCESS
    in.bufno++;
    in.skipcount = 0;
    in.keybuf = NULL;
    in.bufshrink = 0;
#endif
    in.buf = *in.handle;
    in.bufend = &in.buf[len];

    if (in.iseexec) {   /* must decrypt the buffer contents */
#if HEXENCODING
      if (in.ishex)
        HexConvert();
#endif /* HEXENCODING */
      DecryptBuf();
    }
#if RANDOMACCESS
    /*
     * DecryptBuf is the only function that sets in.bufstart.  But that will not
     * get executed if we are not using eexec.
     * EA - 1/19/94 - likewise for in.keybuf
     */
    else
    {
      in.bufstart = in.buf;
      in.keybuf = (Card16)in.buf;
    }
#endif
    return *in.buf++;
}


/* EexecDecrypt -- start decrypting the input stream */
PRIVATE procedure EexecDecrypt ARGDEF0() {
  register IntX i;
  register Card16 key;
  Card8 x[4];   /* initial ciphertext bytes */

  in.ishex = true;
  in.nybble = -1;	/* 8/25/92 hotta */

#if !HEXENCODING
  for (i = 0; i < 4; i++)
    x[i] = GetChar();
#else
  {
    register IntX c;
    /* Skip white space. Where white space is defined as:
       space, tab, linefeed, and carriage return.
       This is the definition in the Adobe Type 1 Font Format book
       which is different from the definition in the PostScript
       Language Reference Manual, 2nd edition which is different
       from the definition in the PostScript Language Reference
       Manual, 1st edition.


       If any of the first 4 characters are not white space or
       a valid hex digit, declare the file binary. Use the most
       restrictive definition of white space (the black book).

       If this test declares the file to be ascii, then skip over
       white space before starting the eexec decryption. Note that
       no white space characters may be embedded in the first four
       bytes of eexec cyphertext.

    */
    for (i = 0, c = GetChar();; c = GetChar()) {
      if (!ishexdigit(c) && c != ' ' && c !='\t' && c!= '\n' && c != '\r')
        in.ishex = false;
      x[i] = c;
      if (++i >= 4)
        break;
    }

/* the next code removes initial white space characters after the file is 
   declared to be hex encoded. This happens most frequently on a DOS
   platform where the eexec delimiter is cr/lf. Removing an initial white
   space character if the file is binary produces bad results, failing to 
   do so for a hex file produces bad results. 
*/
    while(in.ishex && ((x[0] == ' ') || (x[0] == '\t') || (x[0] == '\n') ||
	(x[0] == '\r'))){
	    for(i=0;i<3;i++)x[i]=x[i+1];
	    x[3] = GetChar();
    }
  }
#endif

  key = key_eexec;

#if HEXENCODING
  if (in.ishex) {
    IntX c1 = ((atmparse_chartab[x[0]] & HEXVAL) << 4) | (atmparse_chartab[x[1]] & HEXVAL);
    IntX c2 = ((atmparse_chartab[x[2]] & HEXVAL) << 4) | (atmparse_chartab[x[3]] & HEXVAL);
    key = (c1 + key) * C1 + C2;
    key = (c2 + key) * C1 + C2;
    HexConvert();
  } else
#endif
    for (i = 0; i < 4; i++)
      key = (x[i] + key) * C1 + C2;

  in.iseexec = true;
  in.eekey = key;
#if RANDOMACCESS
#if HEXENCODING
  /* Account for the bytes at the beginning of an eexec
     section. If in.hex is false this will be four bytes, if it is true then it
     will be the number of whitespace bytes between the start of the eexec
     section and the Hex data. In the routine GetBinaryString
     in.bufshrink is added to the bufpos when reporting the byte position in
     the file.
  */
  in.bufshrink = in.buf - *in.handle;
#else
  /* If there is no HEXENCODING then in.bufshrink must be 0. */
  in.bufshrink = 0;	
#endif /* HEXENCODING */ 
#endif /* RANDOMACCESS */
  DecryptBuf();

#if HEXENCODING
  if (in.ishex) {
    SkipChar();
    SkipChar();
  }
#endif
}

#if COMPOSITE_FONT
/* StopDecrypting -- return to cleartext input, re-encrypt current buffer */
PRIVATE procedure StopDecrypting ARGDEF0() {
  /* TODO: HEXENCODING and !RANDOMACCESS versions */
  if (in.iseexec) {
    if (in.buf != in.bufend) {
      register Card8 *s = in.buf;
      register Card8 *end = in.bufend;
      register Card16 key = in.keybuf[in.buf - in.bufstart];
      while (s < end) {
        register Card8 c = *s ^ (Card8)(key >> 8);
        key = (c + key) * C1 + C2;
        *s++ = c;
      }
    }
    in.iseexec = false;
    in.ishex = false;
  }
}
#endif

/* InitInput -- set up the input state */
/* SUPPRESS 590 *//* CodeCenter Warning:  Formal parameter 'lookaside' not used */
PRIVATE procedure InitInput ARGDEF2(GrowableBuffer *, growbuf, GrowableBuffer *, lookaside) {
  if (growbuf->len < TOKENBUFFER_MIN)
    if (!(*procs->GrowBuff)(growbuf, TOKENBUFFER_MIN - growbuf->len, false, clientHook))
      ParseError(PE_BUFFSMALL);
  tokenbuf = growbuf;
  token = growbuf->ptr;

  in.handle     = NULL;
  in.buf        = NULL;
  in.bufend     = NULL;
  in.extra      = NULL;
  in.eof        = false;
  in.iseexec    = false;
  in.ishex      = false;
  in.nybble     = -1;
  in.skipping   = false;
#if COMPOSITE_FONT
  in.isprotect  = false;
#endif
#if RANDOMACCESS
  in.bufno      = (CardX)-1;
  in.lookaside  = lookaside;
  in.skipcount  = 0;
  in.skipmax    = (CardX)lookaside->len / (sizeof (CardX));
  in.skip       = (CardX *) lookaside->ptr;
  in.keybuf     = NULL;
#endif

}


/*
 * lexical analysis -- turn a bytestream into a Token stream
 *      if you change the size of token_table, also change InitParseTables
 */

/* ScanString -- convert a PostScript string to the appropriate byte sequence */
#if FAST_GETTOKEN
PRIVATE procedure ScanString ARGDEF1(Card8 *, dest)
#else
PRIVATE Card8 *ScanString ARGDEF2(register Card8 *, dest, register Card8 *, tend)
#endif
{
  register Card8 *t = dest;
  register IntX c, paren = 0;
  for (;;) {
    c = GetChar();
  string_switch:
#if !FAST_GETTOKEN
    if (t >= tend)
      return t;
#endif
    switch (c) {
    case '(':
      ++paren;
      break;
    case ')':
      if (paren-- > 0)
        break;
      *t = '\0';
#if COMPOSITE_FONT
      in.strlen += t - dest;
#endif
#if FAST_GETTOKEN
      return;
#else
      return NULL;
#endif
    case '\\':
          c = GetChar();
          switch (c) {
      case 'n':  c = '\n'; break;
      case 'r':  c = '\r'; break;
      case 't':  c = '\t'; break;
      case 'b':  c = '\b'; break;
      case 'f':  c = '\f'; break;
      case '(':
      case ')':
      case '\\':
        break;
      case '\r':
        c = GetChar();
        if (c == '\n')
          continue;
        else
          goto string_switch;
      case '\n':
        c = GetChar();
        if (c == '\r')
          continue;
        else
          goto string_switch;
      case '0': case '1': case '2': case '3':
      case '4': case '5': case '6': case '7': {
        IntX n = c - '0';
        while ('0' <= (c = GetChar()) && c <= '7')
          n = n * 8 + c - '0';
    
        Backup1Position((char)c); 
      /* I changed this to Backup1Position() but it started out different
         then most cases--usually this would be *--in.buf = (Card8)c;.
         That is actually a safer way of (I think) doing exactly what this
         tries.  It is safer because of the rare case when a buffer flush
         occurs and you cannot back up. */
        c = n;
        break;
      }
      case EOF:
        ParseError(PE_BADFILE);
      }
      break;
    case EOF:
      ParseError(PE_BADFILE);
    }
    *t++ = (Card8)c;
  }
}


/* Macros used in GetToken() */

#if FAST_GETTOKEN

#define PUTCHAR(c)      (*t++ = (Card8)(c))

#else

#define PUTCHAR(c) \
  do { \
    if (t >= tend) { \
      if (!(*procs->GrowBuff)(tokenbuf, TOKENBUFFER_GROW, true, clientHook)) \
        ParseError(PE_BUFFSMALL); \
      t = ((Card8 *) tokenbuf->ptr) + (t - (Card8 *) token); \
      token = tokenbuf->ptr; \
      tend = (Card8 *) &tokenbuf->ptr[tokenbuf->len]; \
    } \
    *t++ = (Card8)(c); \
  } while (0)

#define GROWBUF() \
  do { \
      if (!(*procs->GrowBuff)(tokenbuf, TOKENBUFFER_GROW, true, clientHook)) \
        ParseError(PE_BUFFSMALL); \
      t = ((Card8 *) tokenbuf->ptr) + (t - (Card8 *) token); \
      token = tokenbuf->ptr; \
      tend = (Card8 *) &tokenbuf->ptr[tokenbuf->len]; \
  } while (0)

#endif /* #if FAST_GETTOKEN, #else */


/* GetToken -- get a PostScript token from GetChar() */
PRIVATE Token GetToken ARGDEF0() 
{
register IntX c;
register Card8 *t;

#if !FAST_GETTOKEN
register Card8 *tend;
#endif

restart:					/* restart: */

t = (Card8 *)token;

#if !FAST_GETTOKEN
tend = &t[tokenbuf->len];
#endif

for (;;) 
   switch ((IntX)(c = (IntX)GetChar())) 
    { case EOF: 				/* EOF */
         return t_EOF;

						/* Whitespace */
      case ' ': case '\t': case '\n': case '\r': case '\f': case '\0':
         break;

						/* Open brackets */
      case '[': case '{': 
         return t_open;

						/* Close brackets */
      case '}': case ']': 
         return t_close;

						/* Percent sign '%' */
      case '%':
         c = GetChar();

#if COMPOSITE_FONT

         if (c == '%') 
          { while (!istokenend(c = GetChar()))
               PUTCHAR(c);

            Backup1Position(c);
            *t = '\0';

            if (streq(token, "OriginalFont:"))
               return t_origfont;

            if (isprefix(token, "EndAdobeStdCompFont_BDY"))
               return t_endfont;

/*#if COPYPROTECT*/

            if (streq(token, "ATM")) 
             { in.isprotect = true;
               return t_atm;
             } /* end if */

            if (streq(token, "CheckSum"))
               return t_checksum;

/*#endif*/ /* COPYPROTECT */

            if (streq(token, "BeginData:"))
             { while (c != '\n' && c != '\r' && c != EOF)
                  c = GetChar();
               return t_begindata;
             } /* end if */

          } /* end if */
         else if (c == 'A') 
          { while (!istokenend(c = GetChar()))
               PUTCHAR(c);
            Backup1Position(c);
            *t = '\0';
						/* ADOResourceSubCategory: */
            if (streq(token, "DOResourceSubCategory:"))  
               return t_subcategory;
						/* ADOStartRearrangedFont */
            if (streq(token, "DOStartRearrangedFont"))  
               return t_startrearrangedfont;
          } /* end else if */

         t = (Card8 *)token;

#endif /* COMPOSITE_FONT */

         while (c != '\n' && c != '\r' && c!= EOF)
            c = GetChar();

         break; /* case '%' */


      case '/':					/* Backslash '/' */
         while (!istokenend(c = GetChar()))
            PUTCHAR(c);

         if (!iswhitespace(c))
            Backup1Position((char)c);
         *t = '\0';

         return t_name;


      case '(': 				/* Paren '(' */

#if COMPOSITE_FONT
         in.strlen = 0;
#endif

#if FAST_GETTOKEN
         ScanString(t);
#else
         while ((t = ScanString(t, tend)) != NULL)
            GROWBUF();
#endif

         return t_string;


      case '<':					/* Less than '<' */
         while ((c = GetChar()) != '>')
          { if (c == EOF)
               ParseError(PE_BADFILE);
            PUTCHAR(c);
          } /* end while */

         PUTCHAR(c);
         return t_hex;


      case '.':					/* Period '.' */
         *t++ = '.';
         c = GetChar();

         if (!isdigit(c))
            goto other;
         *t++ = (Card8)c;
         goto fraction;


      case '-':					/* Dash '-' */
         *t++ = '-';
         c = GetChar();

         if (!isdigit(c))
            goto other;
         /* FALLTHROUGH */

  						/* Numbers */ 
      case '0': case '1': case '2': case '3': case '4':
      case '5': case '6': case '7': case '8': case '9':
         isreal = false;
         *t++ = (Card8)c;

         while (isdigit(c = GetChar()))
            PUTCHAR(c);

         if (c == '#') 
          { PUTCHAR(c);
            while (isdigit(c = GetChar()))
               PUTCHAR(c);
          } /* end if */

         if (c == '.') 
          { PUTCHAR('.');
fraction:					/* fraction: */
            while (isdigit(c = GetChar()))
               PUTCHAR(c);
            isreal = true;
          } /* end if */

         if (c == 'e' || c == 'E')
          { PUTCHAR('e');
            c = GetChar();

            if (c == '-') 
             { PUTCHAR('-');
               c = GetChar();
             } /* end if */

            for (; isdigit(c); c = GetChar())
               PUTCHAR(c);
            isreal = true;
          } /* end if */

         PUTCHAR('\0');
         if (!iswhitespace(c))
            Backup1Position((char)c);

         return t_number;


      default:					/* default */
         *t++ = (Card8)c;

         for (;;) 
          { c = (Card8)GetChar();
other:						/* other: */
            if (istokenend(c))
               break;
            PUTCHAR(c);
          } /* end for */

         if (!iswhitespace(c))
            Backup1Position((char)c);
         PUTCHAR('\0');

         if (*token == 'c' && !in.skipping && streq(token + 1, "urrentfile")) 
          { Token next = GetToken();
            if (next == t_id)
               if (!in.iseexec) 
	        { if (!(*procs->StartEexecSection)())
	             ParseError(PE_EXITEARLY);
#if STREAMFONT	/* User may be changing encryption so intercept it here */
                  if (*procs->KeyPosition)
                   { if (!(*procs->KeyPosition)(EEXEC_POSITION, streamCount-17))
                        ParseError(PE_CALLER);
                     streamData = false;
                   } /* end if */
#endif /* STREAMFONT */
                  if (streq(token, "eexec"))
                   { EexecDecrypt();
#if STREAMFONT
                     if (*procs->KeyPosition)
                        streamData = true;
#endif /* STREAMFONT */
                     goto restart;
                   } /* end if */
#if STREAMFONT
                  if (*procs->KeyPosition)
                     streamData = true;
#endif /* STREAMFONT */
                } /* end if */

#if COMPOSITE_FONT

               else 
                { if (streq(token, "closefile")) 
                   { if (parsestate != AdobeCIDFont || 
                         (parsestate == AdobeCIDFont && !in.isprotect)) 
                      { StopDecrypting();
			/* For Type1 fonts we want to see the "closefile" */
			/* token (in particular in the no-subrs case). */
                        if (parsestate != Type1Font)
                           goto restart;
                      } /* end if */
                   } /* end if */
                } /* end else */

#endif /* COMPOSITE_FONT */

            return next;
          } /* end if */
#if STREAMFONT	/* If the data is NOT encrypted I still need to know where */
                /* it would be (in case I am encrypting it). */
         else if (streq(token, "systemdict"))
          { Token next = GetToken();
            if (next == t_id)
             { if (streq(token, "begin"))
                { if (*procs->KeyPosition)
                   { if (!(*procs->KeyPosition)(EEXEC_POSITION, streamCount-16))
                        ParseError(PE_CALLER);
                   } /* end if */
                } /* end if */
             } /* end if */
          } /* end if */
#endif /* STREAMFONT */


      return t_id;

    } /* end switch */

} /* end GetToken() */

#undef PUTCHAR


/*
 * token conversions
 */

PRIVATE procedure SkipTo ARGDEF1(Token, end) {
  register Token t;
  if (end != t_id)
    in.skipping = true;
  while ((t = GetToken()) != end)
    switch (t) {
    case t_open:
      SkipTo(t_close);
      break;
#if COMPOSITE_FONT && ORIGINAL_FONT
    case t_origfont:
      in.skipping = false;
      return;
#endif
#if COMPOSITE_FONT /*&& COPYPROTECT*/
    case t_atm:
      if (!DoCIDProtect()) ParseError(PE_BADFILE);
      break;

    case t_checksum:
      if (!DoFontProtect()) ParseError(PE_BADFILE);
      break;
#endif
    case t_close:
    case t_EOF:
      ParseError(PE_BADFILE);
    default:
      ;
    }
  in.skipping = false;
}

#define SkipToID(id)    do SkipTo(t_id); while (!streq(token, id))

#if COMPOSITE_FONT
PRIVATE Token SkipToEitherOf ARGDEF2(Token *, endlist, IntX, numberOfTokens) {
  register Token t;
  register IntX n;
  in.skipping = false;
  for (;;) {
    t = GetToken();
    for (n = 0; n < numberOfTokens; n++) {
      if (t == endlist[n]) {
        in.skipping = false;
        return t;
       }
     }
    switch (t) {
      case t_open:
        SkipTo(t_close);
        break;
#if COMPOSITE_FONT &&  ORIGINAL_FONT
      case t_origfont:
        in.skipping = false;
        return t;
#endif
#if COMPOSITE_FONT /*&& COPYPROTECT*/
      case t_atm:
        if (!DoCIDProtect()) ParseError(PE_BADFILE);
        break;

      case t_checksum:
        if (!DoFontProtect()) ParseError(PE_BADFILE);
        break;
#endif
      case t_close:
      case t_EOF:
        ParseError(PE_BADFILE);
      default:
        ;
     }
   }
 }
#endif /* COMPOSITE_FONT */

PRIVATE Int32 ConvertInteger ARGDEF1(register char *, token) {
  /* TODO: more error checks? */
  register char *s, c;
  for (s = token; isdigit((unsigned int) (c = *s)); s++)
/* SUPPRESS 530 *//* CodeCenter Warning: Empty body for 'for' statement */
    ;
  if (*s == '#')
    return strtol(&s[1], NULL, atoi(token));
  if (s == token && (c != '-' && c != '+'))
    ParseError(PE_BADFILE);
  return atol(token);
}

#if COMPOSITE_FONT
PRIVATE Int32 GetInteger ARGDEF0() {
  register Token t;

  lasttoken = t = GetToken();
  if (t == t_hex)
    return strtol(token, NULL, 16);

  if (t != t_number)
    ParseError(PE_BADFILE);
  return ConvertInteger(token);
}
#else
PRIVATE Int32 GetInteger ARGDEF0() {
  if (GetToken() != t_number)
    ParseError(PE_BADFILE);
  return ConvertInteger(token);
}
#endif

PRIVATE Fixed MakeFixed ARGDEF0() {
  return isreal ? ConvertFixed(token) : FixInt(ConvertInteger(token));
}

PRIVATE Fixed GetFixed ARGDEF0() {
  if (GetToken() != t_number)
    ParseError(PE_BADFILE);
  return MakeFixed();
}

PRIVATE Frac GetFrac ARGDEF0() {
  if (GetToken() != t_number)
    ParseError(PE_BADFILE);
  return isreal ? ConvertFrac(token) : FixedToFrac(FixInt(ConvertInteger(token)));
}

PRIVATE boolean ConvertBoolean ARGDEF1(char *, s) {
  if (streq(s, "true"))
    return true;
  if (streq(s, "false"))
    return false;
  ParseError(PE_BADFILE);
#if ISP==isp_sparc
return 0;
#endif
  return false;
}

PRIVATE boolean GetBoolean ARGDEF0() {
  if (GetToken() == t_id)
    return ConvertBoolean(token);
  ParseError(PE_BADFILE);
#if ISP==isp_sparc
return 0;
#endif
  return false;
}

PRIVATE char *GetStringToken ARGDEF0() {
  register Token t = GetToken();
  if (t == t_string || t == t_name)
    return token;
  ParseError(PE_BADFILE);
#if ISP==isp_sparc
return 0;
#endif
  return false;
}


/*
 * array parsing
 */

/* GetOpenFixedArray -- parse an array of Fixeds, assuming it is already open */
PRIVATE CardX GetOpenFixedArray ARGDEF2(Fixed *, p, CardX, maxlen) {
  register CardX len = 0;
  for (;; p++) {
    Token t = GetToken();
    if (t == t_number)
      *p = MakeFixed();
    else if (t == t_close)
      return len;
    else
      ParseError(PE_BADFILE);
    /* STRIDE: p = (Fixed *) (((char *) p) + stride); */
    if (++len >= maxlen) {
      if (GetToken() != t_close)
        ParseError(PE_BADFILE);
      return len;
    }
  }
}

/* GetFixedArray -- parse an array of Fixeds */
PRIVATE CardX GetFixedArray ARGDEF2(Fixed *, p, CardX, maxlen) {
  if (GetToken() != t_open)
    ParseError(PE_BADFILE);
  return GetOpenFixedArray(p, maxlen);
}



/*
 * type 1 charstring and subroutine parsing
 *      these routines bypass the GetToken() interface and call
 *      GetChar() directly.  (it might make sense to bypass even
 *      that layer and just peek at how many characters are in
 *      the buffer.)
 */

PRIVATE Card8 *binaryToken;
#if COMPOSITE_FONT
PRIVATE IntX extraskip;          /* HACK! */
#endif

/* GetBinaryString -- fetch a "nbytes |- ~binary~stream~" sequence into the token buffer */
#if RANDOMACCESS
PRIVATE Card32 GetBinaryString ARGDEF3(CardX *, bufno, CardX *, charno, Card32 *, eekey)
#define getBinaryString()       GetBinaryString(NULL, NULL, NULL)
#else
PRIVATE Card32 GetBinaryString ARGDEF0()
#define getBinaryString()       GetBinaryString()
#endif
{
  Int32 len;
  register Card8 *t, *tend;
  len = GetInteger();
#if COMPOSITE_FONT
  {
    IntX i;
    for (i = 0; i < extraskip; i++)
      GetToken();
  }
#endif
  GetToken(); /* skip the "-|" or "RD" */
  if (tokenbuf->len < (Card32)len) {
    register Card32 incr;
    incr = ((len - tokenbuf->len + TOKENBUFFER_GROW - 1) / TOKENBUFFER_GROW) * TOKENBUFFER_GROW;
    if (!(*procs->GrowBuff)(tokenbuf, incr, false, clientHook))
      ParseError(PE_BUFFSMALL);
    token = tokenbuf->ptr;
  }
#if RANDOMACCESS
    if (bufno != NULL) {                /* either all 3 are NULL or none are */
      register CardX bufpos;
      if (in.buf == in.bufend) {        /* if at end of buffer, read in next segment */
        FillBuf();
        /* Why not use Backup1Position() here?  Because STREAMFONT is NOT
           active in GetBinaryString() (which is only used for subrs and
           charstrings), and there is no value to assign to in.buf (as
           Backup1Position() would want to do. */
        in.buf--;
           
      }
      bufpos = in.buf - in.bufstart;
      *eekey = in.keybuf[bufpos];
#if HEXENCODING
      if (in.ishex) {
        register CardX spaces = in.skipcount;
        while (spaces-- > 0 && in.skip[spaces] > bufpos)
          ;
        bufpos = bufpos * 2 + spaces + 1;
      }
      *charno = bufpos + IN_BUFSHRINK;
      *bufno = in.bufno;
#else
      *charno = in.buf - *in.handle + IN_BUFSHRINK;
      *bufno = in.bufno;
#endif
    }
#endif
//Fix bug 118873    9/8/95   jjia 
//In IBM PC platform, (in.buf + len) may exceed the memory segment boundary.
//  if (in.buf + len <= in.bufend) {
  if ((in.bufend - in.buf) >= len) {
    binaryToken = in.buf;
    in.buf += len;
  } else {
    t = binaryToken = (Card8 *) token;
    tend = &t[len];
    while (t < tend) {
      register IntX count = in.bufend - in.buf;
      if (count == 0)
        *t++ = (Card8)FillBuf();
      else {
        register Card8 *s = in.buf;
        if (count > tend - t)
          count = tend - t;
        do
          *t++ = *s++;
        while (--count > 0);
        in.buf = s;
      }
    }
  }
  return len;
}

/* Get the OtherSubr PostScript code and pass it to user */
PRIVATE procedure DoOtherSubrs ARGDEF0()
{
Token t;
CardX brackets = 1;		/* Number of brackets not closed */
Card8 *s, 			/* Pointer to start of this line */
       c;			/* Current character */
Card16 count;			/* # of bytes on this line */

t = GetToken();
if (t != t_open)		/* Must start with an open bracket */
   ParseError(PE_BADFILE);

#if STREAMFONT
if ( 0 == syntheticFont )
#endif
if (!(*procs->OtherSubrs)((Card8 *)"[", 1))
   ParseError(PE_CALLER);

c = 0;
s = in.buf;			/* Point to start of OtherSubrs */
count = 0;
while (brackets > 0)		/* Until matching closebracket found */
 { /* Send data when eol found, or if buffer flush will occur. */
   if ((c == '\r') || (c == '\n') || ((in.bufend - in.buf) == 0))
    { 
#if STREAMFONT
	  if ( 0 == syntheticFont )
#endif
	  if (!(*procs->OtherSubrs)(s, count))
         ParseError(PE_CALLER);
      if ((in.bufend - in.buf) == 0)
       { c = (char)GetChar();		/* Force the flush to occur */
         s = in.buf-1;		/* then note the position */
       } /* end if */
      else
       { s = in.buf;		/* Get the position for the next string */
         c = GetChar();
       } /* end else */
      count = 1;
    } /* end if */
   else
    { c = GetChar();
      count++;
    } /* end else */

   if (c == '[')
      brackets++;
   if (c == ']')
      brackets--;
 } /* end while */

/* Send off the last data */
#if STREAMFONT
if ( 0 == syntheticFont )
#endif
if (!(*procs->OtherSubrs)(s, count))
    ParseError(PE_CALLER);

t = GetToken();
if (t != t_id)		/* Must end with an "-|" or "ND" */
   ParseError(PE_BADFILE);


#if STREAMFONT
if ( 0 == syntheticFont )
#endif
if (!(*procs->OtherSubrs)((Card8 *)" ND", 3))	// Change this to be "ND" because somefont would define this as "readonly def".  TH 3/026/96
   ParseError(PE_CALLER);

} /* end DoOtherSubrs() */


/* SkipBinaryString -- skip over a "nbytes |- ~binary~stream~" sequence */
PRIVATE procedure SkipBinaryString ARGDEF0() {
  register Card32 len;
  len = GetInteger();
  GetToken(); /* skip the "-|" or "RD" */
  while (len-- != 0)
    SkipChar();
}

#if STREAMFONT 
/* We incremental download a font, we need to change the XUID of the font */
PRIVATE void ChangeXUID()
{
    register Token t;

    t = GetToken();

    if (t != t_open) 
        ParseError(PE_BADFILE);

    /* Turn off streaming so we can add a 3 to the XUID */
    streamData = false;

    if (!(*procs->FontDataStream)('3', 1))
        ParseError(PE_CALLER);
    if (!(*procs->FontDataStream)(' ', 1))
        ParseError(PE_CALLER);
    streamCount += 2;

    /* Done, turn on streaming again */
    streamData = true;
    SkipTo(t_close);
}
#endif

/* DoSubrs -- parse the array of subroutines */
PRIVATE Token DoSubrs ARGDEF0() {
  register Token t;
  register CardX i, count, length, index;
  register boolean (*putSubr) ARGDECL3(IntX, index, CharDataPtr, val, CardX, len);
  register Token result;
  register boolean hybrid;

#if STREAMFONT	/* Let the user know where the subrs go.  In synthetic fonts */
                /* This can occur 2 times. */
streamData = false;
if (*procs->KeyPosition)
 { if (!(*procs->KeyPosition)(SUBR_POSITION, streamCount-6))
      ParseError(PE_CALLER);
 } /* end if */
#endif /* STREAMFONT */

  hybrid = false;
  t = GetToken();
  if (t != t_number) {
    if (t != t_id || !streq(token, "hires"))
      ParseError(PE_BADFILE);
    SkipTo(t_number);
    hybrid = true;
#if STREAMFONT
	SpecialAttribute( ST_HYBRID_FONT );
#endif

  }
skip:
  count = (CardX)ConvertInteger(token);
  result = t_id;

  if (count == 0)		/* No Subrs to read so exit this routine */
   { didSubroutines = true;
     return result;
   } /* end if */

  if (didSubroutines) {
    for (i = 0; i < count; i++) {
      while ((t = GetToken()) != t_number)
        if (t == t_name) {
          result = t_name;
          goto done;
        }
      SkipBinaryString();
    }

    /* Got all the data, read off the end of subrs stuff */
    while (1)
     { if ((t == t_id) && (streq("|-", token) || streq("ND", token)))
        { result = t_id;
          goto done;
        }
       /* Some fonts use "noaccess def" instead of "ND" or "|-" */
       else if ((t == t_id) && streq("noaccess", token))
         { t = GetToken();		
           if ((t == t_id) && (streq("def", token)))
            { result = t_id;
              goto done;
            } /* end if */
         } /* end else */
	   else if ((t == t_id) && streq("hires", token)) { // Hybrid font
#if STREAMFONT
			SpecialAttribute( ST_HYBRID_FONT );
#endif
		   result = t_id;
		   goto done;
	   }
      t = GetToken();
    } /* end while */

    goto done;
  }
  didSubroutines = true;

  putSubr = procs->Subroutine;
  if (!(*procs->AllocSubroutines)(count))
    ParseError(PE_CALLER);
  /* Go until all subrs are found.  This loop allows a single subr to be */
  /* specified multiple times, as long as it is in valid range. */
  while(1)
   { while ((t = GetToken()) != t_number)
      { if (t == t_name)
         { result = t_name;
           font->lenSubrArray = count;
           goto done;
         }
       /* Check to see if subrs are over */
       else if ((t == t_id) && (streq("|-", token) || streq("ND", token)))
         { result = t_id;
           font->lenSubrArray = count;
           goto done;
         }
       /* Some fonts use "noaccess def" instead of "ND" or "|-" */
       else if ((t == t_id) && streq("noaccess", token))
         { t = GetToken();
           if ((t == t_id) && ( streq("def", token)))
            { result = t_id;
              font->lenSubrArray = count;
              goto done;
            } /* end if */
         } /* end else */
      } /* end while */

     index = (CardX)ConvertInteger(token);
     if (index >= count)
        ParseError(PE_BADFILE);

     length = (CardX)getBinaryString();
     if (!putSubr(index, binaryToken, length))
        ParseError(PE_CALLER);
   }
  font->lenSubrArray = count;

done:
  if (hybrid) {
    hybrid = false;
    SkipTo(t_number);
    goto skip;
  }

#if STREAMFONT /* Subrs are over, start streaming again */
streamData = true;
#endif /* STREAMFONT */

  return result;
}


/* DoCharStrings -- parse the dictionary of type 1 glyph descriptions */
PRIVATE procedure DoCharStrings ARGDEF0() {
  register Token t;
  register boolean hybrid;
  register CardX count;
#if RANDOMACCESS
  boolean (*putCharString) ARGDECL6(
    CardX, buffNum, CardX, byteNum, Card32, cryptNum,
    char *, key, CharDataPtr, val, CardX, len
  );
#else
  boolean (*putCharString) ARGDECL3(
    char *, key, CharDataPtr, val, CardX, len
  );
#endif

#if STREAMFONT   /* Let the user know where the charstrings are */
streamData = false;
if (*procs->KeyPosition)
 { if (!(*procs->KeyPosition)(CHARSTRING_POSITION, streamCount-11))
      ParseError(PE_CALLER);
 } /* end if */
#endif /* STREAMFONT */

  hybrid = false;

  t = GetToken();
  if (t != t_number) {
#if COMPOSITE_FONT
    if (isCompFont && t == t_name) {
      if (!(*procs->UseNamedCharStrings)(token))
        ParseError(PE_CALLER);
      return;
    }
#endif
    if (t != t_id && !streq(token, "hires")) {
      return;
      /*ParseError(PE_BADFILE);*/
    }
    SkipTo(t_number);
    hybrid = true;
#if STREAMFONT
	SpecialAttribute( ST_HYBRID_FONT );
#endif

  }
skip:
  count = (CardX)ConvertInteger(token);
  SkipToID("begin");

  if (didCharStrings) {
    while ((t = GetToken()) == t_name) {
      SkipBinaryString();
      GetToken(); /* skip "|-" or "ND" */
      if ((t == t_id) && streq("noaccess", token))
         GetToken();    /* skip "noaccess def" */
    }
    if (t != t_id && !streq(token, "end"))
      ParseError(PE_BADFILE);
    goto done;
  }
  didCharStrings = true;

  if (!(*procs->AllocCharStrings)(count))
    ParseError(PE_CALLER);

  putCharString = procs->CharString;
  for (;;) {
    char name[MAXLEN_PSNAME];
    register CardX length;

    /* skip over "|-" or "ND" if present */
    while ((t = GetToken()) != t_name)
      if (t == t_id && streq(token, "end"))
        goto done;

    strcpy(name, token);
#if RANDOMACCESS
    {
      Card32 eekey;
      CardX bufno, charno;
      length = (IntX)GetBinaryString(&bufno, &charno, &eekey);
      if (!(*putCharString)(bufno, charno, eekey, name, binaryToken, length))
        ParseError(PE_CALLER);
    }
#else
    length = (CardX)GetBinaryString();
    if (!(*putCharString)(name, binaryToken, length))
      ParseError(PE_CALLER);
#endif
  }

done:
  if (hybrid) {
    hybrid = false;
    SkipTo(t_number);
    goto skip;
  }

#if STREAMFONT  /* Charstrings are over, start streaming */
streamData = true;

/* Look for access attributes that should immediately follow charstrings */
/* They have a very specific format! */
if (*procs->KeyPosition)
 { GetToken(); /* end in *very, very* rare cases (old fonts), readonly, etc.*/

   if (streq(token, "readonly") || streq(token, "noaccess"))
    { if (!(*procs->KeyPosition)(ATTRIBS_POSITION, streamCount-9))
         ParseError(PE_CALLER);
      GetToken(); /* put */
    } /* end if */
   else if (!streq(token, "end"))
     return;

   GetToken();
   if (streq(token, "readonly") || streq(token, "noaccess"))
    { if (!(*procs->KeyPosition)(ATTRIBS_POSITION, streamCount-9))
         ParseError(PE_CALLER);
      GetToken(); /* put */
    } /* end if */

   /* Possible for both attributes to be set! */
   GetToken();
   if (streq(token, "readonly") || streq(token, "noaccess"))
    { if (!(*procs->KeyPosition)(ATTRIBS_POSITION, streamCount-9))
         ParseError(PE_CALLER);
      GetToken(); /* put */
    } /* end if */
 } /* end if */
#endif /* STREAMFONT */
}



/*
 * worker functions for fields of fonts
 */


#define Proc(name)      PRIVATE IntX name ARGDEF1(Arg *, u)

typedef struct {
  Card16 maxlen;                /* maximum length in elements */
  Card16 len;                   /* offset in FontDesc to length field */
  Card16 data;                  /* offset in FontValues to data */
} ArrayDesc;


/*
 * generic procedures for setting fields within structs
 *      there is an unfortunate asymetry here:
 *  SetFixed works on the FontValues structs,
 *      whereas SetInt(16|32) work on the FontDesc struct.
 */

#define MakeSetProc(procname, var, type, getfunc) \
  Proc(procname) { \
    * (type *) (((char *) var) + u->i) = (type)getfunc(); \
    return 0; \
  }

MakeSetProc(SetFixed,   fontval, Fixed, GetFixed)
MakeSetProc(SetInt16,   font,   Int16,  GetInteger)
MakeSetProc(SetInt32,   font,   Int32,  GetInteger)

#undef  MakeSetProc

Proc (SetFixedArray) {
  register ArrayDesc *array = (ArrayDesc*)u->p;
  * (Card16 *) (((char *) font) + array->len)
    = GetFixedArray((Fixed *) (((char *) fontval) + array->data), array->maxlen);
  return 0;
}


/*
 * functions that return values through the ParseProcs callback procedures
 */

#define MakeCallProc(procname, type, getfunc) \
  Proc (procname) { \
    if (!(*(boolean (*) ARGDECL1(type, x)) *(void **) (((char *) procs) + u->i))(getfunc())) \
      return PE_CALLER; \
    return 0; \
  }

MakeCallProc(CallFixedProc,     Fixed,  GetFixed)
MakeCallProc(CallIntProc,       Int32,  GetInteger)
MakeCallProc(CallBooleanProc,   boolean, GetBoolean)
MakeCallProc(CallStringProc,    char *, GetStringToken)

#undef  MakeCallProc


/*
 * procedures aimed at specific fields
 */

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameter 'u' not used */
Proc (SetForceBold) {
  register Card32 flags = fontval->flags;
  flags |= FONT_FORCEBOLD_USED;
  if (GetBoolean())
    flags |= FONT_FORCEBOLD;
  else
    flags &= ~FONT_FORCEBOLD;
  fontval->flags = flags;
  return 0;
}

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameter 'u' not used */
Proc (SetFontType) {
#if COMPOSITE_FONT
  if (streq(token, "PGFontType")) {
    fontType = GetInteger();
    if (!(parsestate == AdobePGFont && fontType == 0) &&
        !(parsestate == AdobeCIDFont && (fontType == 0 || fontType == 1)))
      return PE_BADFILE;
    if (!(*procs->FontType)(PGFontType))
      return PE_CALLER;
    fontType = 1;
    return PE_NOERR;
  }
#endif
  fontType = GetInteger();
#if COMPOSITE_FONT
  switch (parsestate) {         /* TODO: make sure these are correct */
  case Type1Font:
  case AdobePGFont:
  case AdobePGFont_CSA:
#endif
    if (fontType != 1)
      return PE_BADFONTTYPE;
#if COMPOSITE_FONT
    break;
  case AdobeStdCompFont:
  case AdobeStdCompFont_BDY:
  case AdobeCompositeFont:
    if (fontType != 0)
      return PE_BADFONTTYPE;
    break;
  case AdobeDerivedFont:
    if (fontType != 1 && fontType != 4)
      return PE_BADFONTTYPE;
    break;

  case AdobeRearrangedFont: /* These can't happen conditions quiet compilers */
  case AdobeCMap:           /* that complain "enumerated type not handled" */
  case AdobeCIDFont:
    break; 

  case NoHeader:
    return PE_CANTHAPPEN;
  }
#endif
  if (!(*procs->FontType)(fontType))
    return PE_CALLER;
  return 0;
}

PRIVATE procedure DoFontBBox ARGDEF1(register FCdBBox *, bbox) {
  if (GetToken() != t_open)
    ParseError(PE_BADFILE);
  bbox->bl.x = GetFixed();
  bbox->bl.y = GetFixed();
  bbox->tr.x = GetFixed();
  bbox->tr.y = GetFixed();
  if (GetToken() != t_close)
    ParseError(PE_BADFILE);
}

PRIVATE procedure DoFontMatrix ARGDEF1(register FracMtx *, m) {
  if (GetToken() != t_open)
    ParseError(PE_BADFILE);
  m->a  = GetFrac();
  m->b  = GetFrac();
  m->c  = GetFrac();
  m->d  = GetFrac();
  m->tx = GetFrac();
  m->ty = GetFrac();
  if (GetToken() != t_close)
    ParseError(PE_BADFILE);
}

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameter 'u' not used */
Proc (SetFontBBox) {
  DoFontBBox(&fontval->fontBBox);
  return PE_NOERR;
}

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameter 'u' not used */
Proc (SetFontMatrix) {
  DoFontMatrix(&font->fontMatrix);
  return PE_NOERR;
}

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameter 'u' not used */
Proc (SetRndStemUp) {
  font->languageGroup = 1;
  return PE_NOERR;
}


/*
 * ParseErodeProc
 *      pull the stem width out of the /Erode proc---very hackish.
 *      this value is only used if StdHW or StdVW is not present.
 *
 *      any errors in the layout of the /Erode proc cause it to be ignored,
 *      but no error is ever signaled.
 */

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameter 'u' not used */
Proc (ParseErodeProc) {
  register IntX i;
  register Token t;
  if (GetToken() != t_open)
    return 0;
  for (i = 0; i < 15; i++)
    if ((t = GetToken()) == t_close)
      return 0;
    else if (t == t_open)
      SkipTo(t_close);
  if ((t = GetToken()) == t_number) {
    register Fixed f = MakeFixed();
    if (FixInt(20) <= f && f <= FixInt(400)) {
      stemWidth = f;
    }
  }
  SkipTo(t_close);
  return 0;
}

/*
 * DoEncoding
 *      parse an encoding vector, either /Encoding or /AccentEncoding
 */

Proc (DoEncoding) {
  register IntX i;
  register Token t;
  register EncodingProcs *p = (EncodingProcs*)u->p;

  switch (GetToken()) {

  case t_id:
    if (!streq(token, "StandardEncoding"))
      return PE_BADFILE;
    if (!(*p->useStd)())
      return PE_CALLER;
#if STREAMFONT
    GetToken();		/* Read off the ending "def" */
#endif
    break;

  case t_open:
    if (!(*p->useSpecial)(256))
      return PE_CALLER;
    for (i = 0; (t = GetToken()) != t_close; i++) {
      if (t != t_name)
        return PE_BADFILE;
      if (!streq(token, ".notdef") && !(*p->special)(i, token))
        return PE_CALLER;
    }
    break;

  case t_number:
    i = (IntX)ConvertInteger(token);
    if (!(*p->useSpecial)(i))
      return PE_CALLER;
#if COMPOSITE_FONT
    if (isCompFont)
      SkipToID("for");          /* maybe this could be done always? */
#endif
    for (;;) {
      for (;;)
        if ((t = GetToken()) == t_id) {
          if (streq(token, "dup"))
            break;
          if (streq(token, "def"))
            return 0;
        }
      if ((t = GetToken()) == t_number) {
        i = (IntX)ConvertInteger(token);
        t = GetToken();
        if (t == t_name && !(*p->special)(i, token))
          return PE_CALLER;
#if COMPOSITE_FONT
        if (t == t_number && isCompFont && p == &encoding) {
          IntX n = (IntX)ConvertInteger(token);
          if (!(*procs->NumericEncoding)(i, n))
            return PE_CALLER;
        }
#endif
      }
    }
    /*SUPPRESS 529*/ /* CodeCenter Warning: Statement not reached */
    break;

#if COMPOSITE_FONT
  case t_name:
    if (!isCompFont || p != &encoding)
      return PE_BADFILE;
    if (!(*procs->UseNamedEncoding)(token))
      return PE_CALLER;
    if (GetToken() != t_id || !streq(token, "findencoding"))    /* TODO: remove this check? */
      return PE_BADFILE;
    break;
#endif

  default:
    return PE_BADFILE;

  }
  return PE_NOERR;
}

/*
 * multiple master definitions
 */

PRIVATE procedure SetNumMasters ARGDEF1(CardX, n) {
  if (font->numMasters == n)
    return;
  if (font->numMasters != 0 || n > MAXWEIGHTS)
    ParseError(PE_BADBLEND);
  if (!(*procs->ResizeFontDesc)(&font, offsetof(FontDesc, values[n])))
    ParseError(PE_CALLER);
  if (!(*procs->BlendNumberDesigns)(n))
    ParseError(PE_CALLER);
  font->numMasters = n;
}

PRIVATE procedure SetNumAxes ARGDEF1(CardX, n) {
  if (numAxes == n)
    return;
  if (numAxes != 0 || n > MAXAXES)
    ParseError(PE_BADBLEND);
  if (!(*procs->BlendNumberAxes)(n))
    ParseError(PE_CALLER);
  numAxes = n;
}

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameter 'u' not used */
Proc (SetWeightVector) {
  register IntX n;
  Fixed wv[MAXWEIGHTS];
  n = GetFixedArray(wv, MAXWEIGHTS);
  SetNumMasters(n);
  if (!(*procs->WeightVector)(wv, n))
    return PE_CALLER;
  return 0;
}

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameter 'u' not used */
Proc (SetBlendAxisTypes) {
  register CardX i;
  if (GetToken() != t_open)
    return PE_BADFILE;
  for (i = 0; ; i++) {
    register Token t = GetToken();
    if (t == t_close)
      break;
    if (t != t_name && t != t_string)
      return PE_BADFILE;
    if (i >= numAxes && numAxes != 0)
      return PE_BADBLEND;
    if (!(*procs->BlendAxisType)(i, token))
      return PE_CALLER;
  }
  SetNumAxes(i);
  return 0;
}

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameter 'u' not used */
Proc (SetBlendDesignMap) {
  register IntX i, j;
  register Token t;
  Fixed from[MAXBLENDDESIGNMAP], to[MAXBLENDDESIGNMAP];
  if (GetToken() != t_open)
    return PE_BADFILE;
  for (i = 0; ; i++) {
    t = GetToken();
    if (t != t_open)
      break;
    for (j = 0; ; j++) {
      t = GetToken();
      if (t != t_open)
        break;
      if (j >= MAXBLENDDESIGNMAP)
        return PE_BADBLEND;
      from[j] = GetFixed();
      to[j] = GetFixed();
      if (GetToken() != t_close)
        return PE_BADFILE;
    }
    if (t != t_close)
      return PE_BADFILE;
    if (!(*procs->BlendDesignMapping)(i, j, from, to))
      return PE_CALLER;
  }
  if (t != t_close)
    return PE_BADFILE;
  SetNumAxes(i);
  return 0;
}

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameter 'u' not used */
Proc (SetBlendDesignPositions) {
  register IntX i, n;
  register Token t;
  Fixed pos[MAXWEIGHTS][MAXAXES];

  if (GetToken() != t_open)
    return PE_BADFILE;
  for (n = 0; ; n++) {
    t = GetToken();
    if (t != t_open)
      break;
    SetNumAxes(GetOpenFixedArray(pos[n], MAXAXES));
  }
  if (t != t_close)
    return PE_BADFILE;
  SetNumMasters(n);
  for (i = 0; i < n; i++)
    if (!(*procs->BlendDesignPositions)(i, pos[i]))
      return PE_CALLER;
  return 0;
}

Proc (SetBlendFixed) {
  register CardX i;
  if (GetToken() != t_open)
    return PE_BADFILE;
  for (i = 0; i < font->numMasters; i++)
    * (Fixed *) (((char *) &font->values[i]) + u->i) = GetFixed();
  if (GetToken() != t_close)
    return PE_BADBLEND;
  return 0;
}

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameter 'u' not used */
Proc (SetBlendForceBold) {
  register CardX i;
  if (GetToken() != t_open)
    return PE_BADFILE;
  for (i = 0; i < font->numMasters; i++) {
    register Card32 *flagp, flags;
    flagp = &font->values[i].flags;
    flags = *flagp | FONT_FORCEBOLD_USED;
    if (GetBoolean())
      flags |= FONT_FORCEBOLD;
    else
      flags &= ~FONT_FORCEBOLD;
    *flagp = flags;
  }
  if (GetToken() != t_close)
    return PE_BADBLEND;
  return 0;
}

Proc (CallBlendFixedProc) {
  register CardX i;
  boolean (*proc) ARGDECL2(IntX, blend, Fixed, x) =
      *(boolean (**) ARGDECL2(IntX, blend, Fixed, x)) (((char *) procs) + u->i);
  if (GetToken() != t_open)
    return PE_BADFILE;
  for (i = 0; i < font->numMasters; i++)
    if (!(*proc)(i, GetFixed()))
      return PE_CALLER;
  if (GetToken() != t_close)
    return PE_BADBLEND;
  return 0;
}

/* SUPPRESS 590 *//* CodeCenter Warning: Formal parameter 'u' not used */
Proc (SetBlendFontBBox) {       /* depends on equivalence of FCdBBox and Fixed[4] */
  register CardX i, j;
  Fixed *bbox[MAXWEIGHTS];

  for (i = 0; i < font->numMasters; i++)
    bbox[i] = (Fixed *) &font->values[i].fontBBox;
  if (GetToken() != t_open)
    return PE_BADFILE;
  for (j = 0; j < 4; j++) {
    if (GetToken() != t_open)
      return PE_BADFILE;
    for (i = 0; i < font->numMasters; i++)
      bbox[i][j] = GetFixed();
    if (GetToken() != t_close)
      return PE_BADFILE;
  }
  if (GetToken() != t_close)
    return PE_BADFILE;
  return 0;
}


/*
 * blue values, blended and not
 */


typedef struct {
  Card16 num;                   /* offset in FontDesc to count of elements */
  Card16 zone;                  /* offset in FontDesc to zone flags (top vs. bottom) */
  Card16 values;                /* offset in FontValues to the blue values */
} BlueDesc;


Proc (ParseBlues) {
  register BlueValueRec *val;
  register unsigned i, len, num; 
  Card16 *nump;
  register Fixed *p;
  register Card32 mask, *maskp;
  Fixed f[MAXBLUELEN];
  register BlueDesc *blue;

  blue  = (BlueDesc*)u->p;
  nump  = (Card16 *) (((char *) font) + blue->num);
  maskp = (Card32 *) (((char *) font) + blue->zone);
  val   = (BlueValueRec *) (((char *) fontval) + blue->values);

  len = GetFixedArray(f, MAXBLUELEN);
  if (isodd(len))
    return PE_BADFILE;

#if STREAMFONT
 // This can happen twice in a synthetic font.  Don't need to add the BlueValues of the basic font.  TH 03/26/96
  if ( syntheticFont )
	  return 0;
#endif

  len >>= 1;
  if (len == 0)
    return 0;

  num = *nump;
  mask = *maskp;
  if (num > 0) {        /* have we already seen the otherblues? */
    i = num + len;
    do {
      --i;
      val[i] = val[i - len];
    } while (i > len);
    mask <<= len;
  }

  for (i = 0, p = f; i < len; i++, val++) {
    val->botEdge = *p++;
    val->topEdge = *p++;
    if (val->botEdge > val->topEdge)
      return PE_BADFILE;
  }
  *maskp = mask | 1;    /* the first zone on the list is the baseline, a bottom zone */
  *nump = num + len;
  return 0;
}

Proc (ParseOtherBlues) {
  register BlueValueRec *val;
  register unsigned i, len, num; 
  Card16 *nump;
  register Card32 bit, mask, *maskp;
  register Fixed *p;
  Fixed f[MAXOTHERBLUELEN];
  register BlueDesc *blue;

  blue  = (BlueDesc*)u->p;
  nump  = (Card16 *) (((char *) font) + blue->num);
  maskp = (Card32 *) (((char *) font) + blue->zone);
  val   = (BlueValueRec *) (((char *) fontval) + blue->values);

  len = GetFixedArray(f, MAXOTHERBLUELEN);
  if (isodd(len))
    return PE_BADFILE;

#if STREAMFONT
  // This can happen twice for a Synthetic font.  Ignore the value of the basic font 
  if ( syntheticFont )
	  return 0;
#endif

  len >>= 1;
  if (len == 0)
    return 0;

  num = *nump;
  mask = *maskp;

  for (i = 0, p = f, val += num, bit = (1L << num); i < len; i++, val++, bit <<= 1) {
    val->botEdge = *p++;
    val->topEdge = *p++;
    if (val->botEdge > val->topEdge)
      return PE_BADFILE;
    mask |= bit;
  }
  *maskp = mask;
  *nump = num + len;
  return 0;
}

Proc (ParseBlendBlues) {
  register CardX i, j;
  register Card32 bit, mask;
  register unsigned n;
  register Token t;
  BlueValueRec *blues[MAXWEIGHTS];
  register BlueDesc *blue;

  blue  = (BlueDesc*)u->p;
  n     = * (Card16 *) (((char *) font) + blue->num);
  mask  = * (Card32 *) (((char *) font) + blue->zone);

  if (GetToken() != t_open)
    return PE_BADFILE;
  for (i = 0; i < font->numMasters; i++)
    blues[i] = (BlueValueRec *) (((char *) &font->values[i]) + blue->values);

  for (i = 0, bit = 1;; bit <<= 1, i++) {
    Fixed bot[MAXWEIGHTS], top[MAXWEIGHTS];
    t = GetToken();
    if (t != t_open)
      break;
    if (i >= n                                  /* too many values? */
        || (i > 1 && (mask & bit) != 0)         /* conflicts with an OtherBlue? */
        || GetOpenFixedArray(bot, MAXWEIGHTS) != font->numMasters
        || GetFixedArray(top, MAXWEIGHTS) != font->numMasters)
      return PE_BADBLEND;
    for (j = 0; j < font->numMasters; j++) {
      blues[j][i].botEdge = bot[j];
      blues[j][i].topEdge = top[j];
    }
  }
  if (t != t_close)
    return PE_BADFILE;
  return 0;
}

Proc (ParseBlendOtherBlues) {
  register CardX i, j;
  register Card32 bit, mask;
  register unsigned n;
  register Token t;
  BlueValueRec *blues[MAXWEIGHTS];
  register BlueDesc *blue;

  blue  = (BlueDesc*)u->p;
  n     = * (Card16 *) (((char *) font) + blue->num); 
  mask  = * (Card32 *) (((char *) font) + blue->zone);

  if (GetToken() != t_open)
    return PE_BADFILE;
  for (i = 0; i < font->numMasters; i++)
    blues[i] = (BlueValueRec *) (((char *) &font->values[i]) + blue->values);
  for (i = 1, bit = 2; (mask & bit) == 0; i++, bit <<= 1)
    if (i >= n)
      return PE_BADBLEND;

  for (;; i++) {
    Fixed bot[MAXWEIGHTS], top[MAXWEIGHTS];
    t = GetToken();
    if (t != t_open)
      break;
    if (i >= n                                  /* too many values? */
        || GetOpenFixedArray(bot, MAXWEIGHTS) != font->numMasters
        || GetFixedArray(top, MAXWEIGHTS) != font->numMasters)
      return PE_BADBLEND;
    for (j = 0; j < font->numMasters; j++) {
      blues[j][i].botEdge = bot[j];
      blues[j][i].topEdge = top[j];
    }
  }
  if (t != t_close)
    return PE_BADFILE;
  return 0;
}



/*
 * standard widths and stem snaps, blended and not
 *      this could be much cleaner, if we didn't have to be backwards compatible
 */

Proc (ParseStdW) {
  Fixed f[MAXSTEMS];
  CardX len;
  register ArrayDesc *array;

  array = (ArrayDesc*)u->p;
  len = GetFixedArray(f, array->maxlen);
  if (len == 0)
    return 0;
  if (len > 1) {
    Card16 *lensnap = (Card16 *) (((char *) font) + array->len);
    if (*lensnap == 0) {
      register Fixed *snap = (Fixed *) (((char *) fontval) + array->data);
      register CardX i;
      for (i = 0; i < len; i++)
        snap[i] = f[i];
      *lensnap = len;
    }
  }
  /* this conditional is ugly and violates the interface hiding that should be going on */
  if (array->len == offsetof(FontDesc, lenStemSnapH))
    fontval->stdHW = f[0];
  else if (array->len == offsetof(FontDesc, lenStemSnapV))
    fontval->stdVW = f[0];
  else
    return PE_CANTHAPPEN;
  return 0;
}

Proc (ParseBlendStdW) {
  register IntX status;
  if (GetToken() != t_open)
    return PE_BADFILE;
  status = SetBlendFixed(u);
  if (GetToken() != t_close)
    return PE_BADFILE;
  return status;
}

Proc (ParseBlendStemSnap) {
  register CardX i, n;
  register Token t;
  Fixed f[MAXWEIGHTS], *snap[MAXWEIGHTS];
  register ArrayDesc *array;
  Card16 *lenp;

  array = (ArrayDesc *)u->p;
  for (i = 0; i < font->numMasters; i++)
    snap[i] = (Fixed *) (((char *) &font->values[i]) + array->data);

  if (GetToken() != t_open)
    return PE_BADFILE;
  for (n = 0; (t = GetToken()) == t_open; n++) {
    if (n >= array->maxlen)
      return PE_BADFILE;
    if (GetOpenFixedArray(f, font->numMasters) != font->numMasters)
      return PE_BADBLEND;
    for (i = 0; i < font->numMasters; i++)
      snap[i][n] = f[i];
  }
  if (t != t_close)
    return PE_BADFILE;

  lenp = (Card16 *) (((char *) font) + array->len);
  if (*lenp > n)
    return PE_BADBLEND;
  *lenp = (Card16)n;
  return 0;
}


/*
 * dictionary initializations
 */


PRIVATE procedure InitPrivate ARGDEF0() {
  didPrivate = true;
}

PRIVATE procedure InitBlendDict ARGDEF0() {
  register FontValues *val, *fv, *end;

  if (copiedBlendDict)
    return;
  copiedBlendDict = true;

  fv = &font->values[0];
  end = &font->values[font->numMasters];

  for (val = &font->values[1]; val < end; val++)
    val->fontBBox       = fv->fontBBox;
}

PRIVATE procedure InitPrivateBlend ARGDEF0() {
  register FontValues *val, *fv, *end;

  if (copiedPrivateBlend)
    return;
  copiedPrivateBlend = true;

  fv = &font->values[0];
  end = &font->values[font->numMasters];

  if (stemWidth != 0) {
    if (fv->stdHW == 0 && font->lenStemSnapH == 0)
      fv->stdHW = stemWidth;
    if (fv->stdVW == 0 && font->lenStemSnapV == 0)
      fv->stdVW = stemWidth;
  }

  for (val = &font->values[1]; val < end; val++) {
    register CardX i;
    val->blueScale      = fv->blueScale;
    val->blueFuzz       = fv->blueFuzz;
    val->blueShift      = fv->blueShift;
    val->stdHW          = fv->stdHW;
    val->stdVW          = fv->stdVW;
    val->defaultSidebearingX = fv->defaultSidebearingX;
    val->defaultSidebearingY = fv->defaultSidebearingY;
    val->defaultWidthX  = fv->defaultWidthX;
    val->defaultWidthY  = fv->defaultWidthY;
    val->flags          = fv->flags;
    for (i = 0; i < font->numBlueValues; i++)
      val->blueValues[i] = fv->blueValues[i];
    for (i = 0; i < font->numFamilyBlues; i++)
      val->familyBlueValues[i] = fv->familyBlueValues[i];
    for (i = 0; i < font->lenStemSnapH; i++)
      val->stemSnapH[i] = fv->stemSnapH[i];
    for (i = 0; i < font->lenStemSnapV; i++)
      val->stemSnapV[i] = fv->stemSnapV[i];
  }
}



/*
 * the guts of the parser
 *      here is where the table driven code lies, as well as all the stuff
 *      which deals with the dictionaries themselves, and stuff for funky
 *      font organizations, such as synthetic fonts (e.g., an oblique that
 *      contains the font it is derived from) or hybrid fonts (hires-lores)
 */

#if BCMAIN
PRIVATE char *DictName ARGDEF1(Dict *, dict) {
  if (dict == NULL)                     return "NULL";
  if (dict == &FontDict)                return "font dictionary";
  if (dict == &Private)                 return "Private";
  if (dict == &BlendDict)               return "Blend";
  if (dict == &PrivateBlend)            return "Blend/Private";
  if (dict == &CompositeDict)           return "composite font dictionary";
  if (dict == &DerivedDict)             return "derived font dictionary";
  if (dict == &CIDFontDict)             return "cid dictionary";
  if (dict == &EncodingDict)            return "encoding font dictionary";
  return "?";
}

PRIVATE procedure DictCheck ARGDEF1(Dict *, dict) {
  IntX i;
  Field *f = dict->table;
  for (i = 1; i < dict->len; i++)
    if (strcmp(f[i-1].name, f[i].name) >= 0)
      fprintf(stderr, "\"%s\" appears before \"%s\" in %s\n",
              f[i-1].name, f[i].name, DictName(dict));
}
#endif

PRIVATE Field *MatchField ARGDEF2(Dict *, dict, char *, name) {
  register Field *field = dict->table;
  register IntX lo = 0, hi = dict->len - 1;
  while (lo <= hi) {
    register IntX m, cmp;
    m = (lo + hi) / 2;
    cmp = strcmp(name, field[m].name);
    if (cmp == 0)
      return &field[m];
    else if (cmp < 0)
      hi = m - 1;
    else
      lo = m + 1;
  }
  return NULL;
}

PRIVATE boolean InitDict ARGDEF1(Dict *, dict) {
  do {
#if STREAMFONT
    /* I need to insert a couple entries into the private dictionary, for
       the RD,ND,NP defs, and a new lenIV indicator.  To do this properly
       I need to increase the number of private dictionary entries, then
       let the user know to insert the data. */
    if (*procs->FontDataStream && streamData && streq(token, "Private"))
     { Token t;
       streamData = false;
       t = GetToken();
       if (t == t_number)	/* If not, I'm hosed */
        { Int32 entries, high;
          entries = strtol(token, NULL, 10) + 4;
          high = (Int32) entries/10; 
          if (high)
           { if (!(*procs->FontDataStream)((char)(high+'0'), 1))
                ParseError(PE_CALLER);
             streamCount++;
           } /* end if */
          if (!(*procs->FontDataStream)((char)((entries-(high*10))+'0'), 1))
             ParseError(PE_CALLER);
          if (!(*procs->FontDataStream)(' ', 1))
             ParseError(PE_CALLER);
          streamCount += 2;
          streamData = true;
        } /* end if */
     } /* end if */  
#endif /* STREAMFONT */
    SkipTo(t_id);
#if ORIGINAL_FONT
    if (streq(token, "OriginalFont:"))
      return true;
#endif
    if (streq(token, "def"))
      return false;
  } while (!streq(token, "begin"));
  if (dict->init != NULL)
    (*dict->init)();
  return true;
}

#if COMPOSITE_FONT

#define PROTECT_RECORD_LENGTH 10
PRIVATE boolean DoFontProtect ARGDECL0() {
  SkipChar();		/* space separator */
#if COPYPROTECT
  if (!(*procs->FontProtection)(PROTECT_RECORD_LENGTH, in.buf))
    return false;
#endif
  in.buf += PROTECT_RECORD_LENGTH;
  return true;
}

#define CID_PROTECT_RECORD_LENGTH 22
PRIVATE boolean DoCIDProtect ARGDECL0() {
  SkipChar();		/* space separator */
#if COPYPROTECT
  if (!(*procs->FontProtection)(CID_PROTECT_RECORD_LENGTH, in.buf))
    return false;
#endif
  in.buf += CID_PROTECT_RECORD_LENGTH;
  return true;
}

#endif /* end COMPOSITE_FONT */


PRIVATE IntX DoParse ARGDEF1(register Dict *, dict) {
  register Token t;
  register IntX nesting = 0;
  
#if STREAMFONT
  streamCount = 0;
  syntheticFont = 0;
#endif

  if (!InitDict(dict))
    return PE_BADFILE;

#if COMPOSITE_FONT && ORIGINAL_FONT
  if (streq(token, "OriginalFont:")) {
    t = GetToken();
    (*procs->OriginalFont)(token);
    return PE_NOERR;
  }
#endif
#if COMPOSITE_FONT		/* Don't look for subrs yet in a CID */
if (dict == &CIDFontDict) 	/* font--they'll be found later. */
   didSubroutines = true;	
#endif

  while (!didPrivate || !didCharStrings || !didSubroutines)
    switch (t = GetToken()) {

    got_name:
    case t_name:
      if (dict != NULL) {
        register Field *f = MatchField(dict, token);
        if (f != NULL) {
          register IntX code;
#if STREAMFONT /* Check for key words in the font */
          if (*procs->KeyPosition)
           { CheckKeyWord(token);
             code = (*f->proc)(&f->u);
             streamData = true; 
           } /* end if */
          else			/* Don't lose this else!! */
#endif /* STREAMFONT */
          code = (*f->proc)(&f->u);

          if (code != 0)
            return code;
          break;
        }
      }
      if (streq(token, "CharStrings")) {
        dict = NULL;
        DoCharStrings();
      } else if (streq(token, "Subrs")) {
        t = DoSubrs();
        if (t == t_name)
          goto got_name;
      } 
#if STREAMFONT 
      else if (streq(token, "XUID")) {
          if (*procs->FontDataStream) 
            ChangeXUID();
      }
#endif
      else if (streq(token, "Private")) {
         if (InitDict(&Private))
         { dict = &Private;
#if STREAMFONT /* Let the user know the private dictionary was found. */
           if (*procs->KeyPosition)
            { if (!(*procs->KeyPosition)(PRIVATE_POSITION, streamCount))
                 ParseError(PE_CALLER);
            } /* end if */
#endif /* STREAMFONT */
         } /* end if */
#if COMPOSITE_FONT
        else if (isCompFont) {
          in.isprotect = false;
          if ((dict == &CompositeDict || dict == &DerivedDict) && InitDict(&Private))
            dict = &Private;
        }
#endif
      } 
      else if (streq(token, "Blend")) {
        if (dict == &Private) {
          if (InitDict(&PrivateBlend))
            dict = &PrivateBlend;
          break;
        }
        if (dict == &FontDict) {
          if (InitDict(&BlendDict)) {
            dict = &BlendDict;
            nesting = 1;
          }
        }
      } else if (streq(token, "OtherSubrs")) 
        DoOtherSubrs();
#if STREAMFONT
        else if (streq(token, "FontInfo") &&  (dict == &FontDict)) /* JWF -- Added check to be sure we are in the font dictionary. */
           InsertBaseFontName();
#endif /* STREAMFONT */
   
      break;

    case t_id:
      if (streq(token, "FontDirectory")) {
		  register char *fontname;

#if STREAMFONT	&& !COMPOSITE_FONT
        unsigned char *s = in.buf;

        // Turn off data output temp to handle Synthetic fonts        
        streamData = false;
#endif

        fontname = GetStringToken();


        /* Fix added so that Tekton Oblique MM will work.  This is a */
        /* synthetic MM that would point to the wrong dict at this time. */
        if (dict == &PrivateBlend)
           dict = &Private;

        if (!didSubroutines && (*procs->ShareSubroutines)(fontname))
          didSubroutines = true;
        if (!didCharStrings && (*procs->ShareCharStrings)(fontname))
          didCharStrings = true;

#if STREAMFONT	&& !COMPOSITE_FONT
      // TH 03/26/96
      //Find out if this is an oblique font or not.  Assuming the following PS is used to find the derived font:
      // FontDirectory /Helvetica known
        if ( fontname ) {
			   t = GetToken();
            if (streq(token, "known")) {
				   syntheticFont = true;

              if ((*procs->BaseMMFontName))
                  ((*procs->BaseMMFontName)(s));

               // Change the name of the font w/i the PostScript code of the font
               *(s+1) = *(s+1) + 1;
				   SpecialAttribute( ST_SYNTHETIC_FONT );
			   }
			   in.buf = s;			  /* rewind to the original input buffer position */
        }
        streamData = true;

#endif

        if (!didPrivate || !didCharStrings || !didSubroutines) {
          /* skip to the appropriate point in the base font */
			SkipToID("begin");
			SkipToID("end");
        }

		if (dict == &Private)
			dict = NULL;
        break;
      }
#if STREAMFONT
	  else if (streq(token, "hires")) {
		  SpecialAttribute( ST_HYBRID_FONT );
	  }
#endif

      if (dict == &BlendDict) {
        if (streq(token, "begin"))
          nesting++;
        else if (streq(token, "end") && --nesting == 0)
          dict = &FontDict;
      }
#if COMPOSITE_FONT
     else if (dict == &CIDFontDict && streq(token, "StartData")) /* for safety. */
        return PE_BADFILE;
#endif
#if COMPOSITE_FONT
      if (streq(token, "closefile") && (parsestate == Type1Font)) 
#else
      if (streq(token, "closefile")) 
#endif
			   	   /* Should only get here on files without */
       { if (!didCharStrings)	   /* subrs, in which case it needs a way */
            return PE_BADFILE;     /* to exit gracefully. */
         else
#if STREAMFONT          /* Need to read off stuff until eof */
          { if (*procs->FontDataStream)
               ReadCharsUntilEOF();
            return PE_NOERR;
          } /* end else */
#else
            return PE_NOERR;
#endif /* STREAMFONT */
       } 
      break;

    case t_open:
      SkipTo(t_close);
      break;

#if COMPOSITE_FONT
/*#if COPYPROTECT*/
    case t_atm:
      if (!DoCIDProtect()) return -1;
      break;

    case t_checksum:
      if (!DoFontProtect()) return -1;
      break;
/*#endif*/

    case t_begindata:
        if (dict == &CIDFontDict) {
          if (GetToken() != t_string || !streq(token, "Binary"))
            return PE_BADFILE;
          if (GetToken() != t_number)
            return PE_BADFILE;
          if (GetToken() != t_id || !streq(token, "StartData"))
            return PE_BADFILE;
          if (!(*procs->CIDStartData)(in.bufno, in.buf - *in.handle + in.bufshrunk))
            return PE_CALLER;
          didCharStrings = true;
        }
       break;
#endif

    default:
      break;

#if COMPOSITE_FONT
    case t_endfont:
      if (isCompFont)
        return PE_NOERR;
#endif

    case t_EOF:		/* Actually, eof is usually discovered when the */
			/* GetBytes() callback fails, then FillBuff() */
			/* returns an early EOF error. */
#if COMPOSITE_FONT
      if (parsestate == AdobePGFont	
       || parsestate == AdobeDerivedFont
       || parsestate == AdobeCompositeFont)
        return PE_NOERR;
#endif       
      if (!didCharStrings)
        return PE_BADFILE;
      return PE_NOERR;
    }

#if STREAMFONT		/* Need to read off stuff until eof */
if (*procs->FontDataStream)
   ReadCharsUntilEOF();
#endif /* STREAMFONT */
  return PE_NOERR;
}


#if COMPOSITE_FONT
/*
 * CompFont/composite font support
 */


PRIVATE IntX DoParseEncoding ARGDEF1(register Dict *, dict) {
  register Token t;

  while (1)
    switch (t = GetToken()) {

    case t_number:
      /* Remember a number for some operators. */
      lastnumber = (IntX)ConvertInteger(token);
      break;

    case t_name:
      /* Remember name for encoding. */
      strncpy(lastname, token, MAXLEN_PSNAME);
      lastname[MAXLEN_PSNAME - 1] = 0;

    case t_id:
      {
        register Field *f = MatchField(dict, token);
        if (f != NULL) {
          register IntX code = (*f->proc)(&f->u);
          if (code != 0)
            return code;
        } else if (streq(token, "endrearrangedfont"))
          return PE_NOERR;
      }
      break;

    case t_EOF:
        return PE_NOERR;

    default:
      break;
    }

  return PE_NOERR;
}


/* GetHeaderComment -- look for a %! comment and inspect standard headers */
PRIVATE IntX GetHeaderComment ARGDEF1(int, nomatch) {
  IntX c;
  char *s;
top:
  do
    c = GetChar();
  while (iswhitespace(c));
  if (c != '%') {
    Backup1Position(c);
    return nomatch;
  }
  if ((c = GetChar()) != '!') {
    while (c != '\n' && c != '\r' && c != EOF)
      c = GetChar();
    goto top;
  }
  for (;;) {
    c = GetChar();
    if (!iswhitespace(c))
      break;
    if (c == '\n' || c == '\r')
      goto top;
  }
  s = token;
  do {
    *s++ = (Card8)c;
    c = GetChar();
  } while (!istokenend(c));
  *s = '\0';
  if (!iswhitespace(c))
     Backup1Position(c);

  if (isprefix(token, "PS-Adobe-")) {
    GetToken();
    switch (token[0]) {
    case 'A':
     if (!isprefix(token, "Adobe"))
       return nomatch;
     s = &token[sizeof "Adobe" - 1];
     switch (*s++) {
     case 'C':
       if (streq(s, "ompositeFont"))
         return AdobeCompositeFont;
       else if (streq(s, "ompositeEncoding"))
         return AdobeCMap;
       break;
     case 'D':
       if (streq(s, "erivedFont"))
         return AdobeDerivedFont;
       break;
     case 'P':
       if (isprefix(s, "rimogenitalFont")) {
         s += sizeof "rimogenitalFont" - 1;
         if (*s == '\0')
           return AdobePGFont;
         if (streq(s, "_CSA"))
           return AdobePGFont_CSA;
       }
      break;
    case 'R':
      break;
    case 'S':
      if (isprefix(s, "tdCompFont")) {
        s += sizeof "tdCompFont" - 1;
        if (*s == '\0')
          return AdobeStdCompFont;
        if (streq(s, "_BDY"))
          return AdobeStdCompFont_BDY;
      }
      break;
    } 
    break;
   case 'R':
   if (isprefix(token, "Resource-CMap")) {
     return AdobeCMap;
   }
   else if (isprefix(token, "Resource-CIDFont")) {
     return AdobeCIDFont;
   }
   else if (isprefix(token, "Resource-Font")) {
     return AdobeRearrangedFont;
   }
   /* NOBREAK */
   default:
     return nomatch;
   }
  }

  return nomatch;
}

/* procedures for examining fields of composite fonts */

Proc (SetVersion) {
  char *s, *t;
  s = GetStringToken();
  if (!(*procs->version)(s))
    return PE_CALLER;
  t = strchr(s, '.');
  if (t != NULL)
    *t = '\0';
  fontVersion = atoi(s);
  return PE_NOERR;
}

Proc (SetPGFArray) {
  IntX n = 0;
  Token t;

  if (!(*procs->AllocPGFArray)(UNKNOWN_LENGTH))
    return PE_CALLER;
  while ((t = GetToken()) != t_close) {
    if (t == t_name)
      if (!(*procs->PGFArray)(n++, token))
        return PE_CALLER;
  }
  if (!(*procs->AllocPGFArray)(n))
    return PE_CALLER;
  return PE_NOERR;
}

PRIVATE IntX GetCDevProc ARGDEF0() {
  Token t = GetToken();
  if (t == t_name) {
    if (streq(token, "StandardCDevProc"))
      return StdCDevProc;
    return UnknownCDevProc;
  }
  if (t == t_open) {
    SkipTo(t_close);
    return UnknownCDevProc;
  }
  if (t == t_id && streq(token, "null"))
    return NoCDevProc;
  ParseError(PE_BADFILE);
}

Proc (SetCDevProc) {
  if (!(*procs->CDevProc)(GetCDevProc()))
    ParseError(PE_CALLER);
  return PE_NOERR;
}

Proc (SetCharOffsets) {
  IntX len;
  /* Skip the next 2 tokens by setting extraskip to 2. */
  extraskip = 2;
  len = (IntX)getBinaryString();
  extraskip = 0;
  if (!(*procs->CharOffsets)(len, binaryToken))
    return PE_CALLER;
  return PE_NOERR;
}

Proc (SetSubsVector) {
  Card8 *s = (Card8 *) GetStringToken();
  if (!(*procs->SubsVector)(in.strlen, s))
    return PE_CALLER;
  return PE_NOERR;
}

Proc (SetFDepVector) {
  Token t;
  IntX n = 0;
  switch (GetToken()) {

  case t_open:
    if (!(*procs->AllocFDepVector)(UNKNOWN_LENGTH))
      return PE_CALLER;
    while ((t = GetToken()) != t_close)
      if (t == t_name) {
        if (!(*procs->FDepVector)(n++, token))
          return PE_CALLER;
        /* TODO: extra GetToken() to skip ahead? */
      }
    if (!(*procs->AllocFDepVector)(n))
      return PE_CALLER;
    break;

  case t_number:
    if (!(*procs->AllocFDepVector)((IntX)ConvertInteger(token)))
      return PE_CALLER;
    SkipToID("dup");
    while ((t = GetToken()) != t_id || !streq(token, "def"))
      if (t == t_number) {
        char key[128];
        n = (IntX)ConvertInteger(token);
        GetToken();
        strcpy(key, token);
        if (GetToken() == t_id && streq(token, "findfont")) {
          if (!(*procs->FDepVector)(n, key))
            return PE_CALLER;
        } else {
          IntX len;
          boolean flag = ConvertBoolean(token);
          IntX index = (IntX)GetInteger();
          /*
           * when reading old style fast composite fonts, we may have to do 3
           * GetToken() calls between the length and the charstring
           */
          len = (IntX)getBinaryString();
          if (!(*procs->FDepVector_MDFF)(n, key, flag, index, len, binaryToken))
            return PE_CALLER;
        }
      }
    break;

  default:
    return PE_BADFILE;
  }
  return PE_NOERR;
}

Proc (SetMDFV) {
  IntX n;
  Token t;
  if (GetToken() != t_open)
    return PE_BADFILE;
  if (!(*procs->AllocMDFV)(UNKNOWN_LENGTH))
    return PE_CALLER;
  for (n = 0; (t = GetToken()) == t_open; n++) {
    IntX index = 0;
    FCdBBox bbox;
    FracMtx mtx;
    char encname[MAXLEN_PSNAME], csname[MAXLEN_PSNAME];

    if (GetToken() != t_name)
      return PE_BADFILE;
    strcpy(encname, token);
    if (GetToken() != t_name)
      return PE_BADFILE;
    strcpy(csname, token);
    DoFontBBox(&bbox);
    if (GetToken() != t_open)
      return PE_BADFILE;
    if (!(*procs->MDFVBegin)(n, encname, csname, &bbox))
      return PE_CALLER;
    while ((t = GetToken()) == t_name)
      if (!(*procs->MDFVFont)(index++, token))
        return PE_CALLER;
    if (t != t_close)
      return PE_BADFILE;
    DoFontMatrix(&mtx);
    if (!(*procs->MDFVEnd)(index, &mtx, GetCDevProc()))
      return PE_CALLER;
    if (GetToken() != t_close)
      return PE_BADFILE;
  }
  if (t != t_close)
    return PE_BADFILE;
  if (!(*procs->AllocMDFV)(n))
    return PE_CALLER;
  return PE_NOERR;
}
#endif  /* COMPOSITE_FONT */

#if COMPOSITE_FONT
/* CIDFont contains more than one private dict and need to be initialized separately. */
PRIVATE procedure InitFontDescCIDFont ARGDEF1(FontDesc *, fontp) {
  font = fontp;

  MEMZERO(font, sizeof (FontDesc));

  font->versionNum      = 1;            /* TODO */
  font->lenIV           = 4;

  font->expansionFactor      = 3932;         /*  == Fixed 0.06 */
  font->subroutineNumberBias    = 0;
  font->lenBuildCharArray       = 32;
  font->initialRandomSeed       = 0;

  fontval->blueShift            = FixInt(7);
  fontval->blueFuzz             = FixInt(1);
  fontval->blueScale            = 2597;         /* == Fixed 0.039625 */
  fontval->defaultSidebearingX  = 0;
  fontval->defaultSidebearingY  = 0;
  fontval->defaultWidthX        = 0;
  fontval->defaultWidthY        = 0;

  fontval->fontBBox.bl.x        = 0;
  fontval->fontBBox.bl.y        = 0;
  fontval->fontBBox.tr.x        = 0;
  fontval->fontBBox.tr.y        = 0;

  font->fontMatrix.a         = FixedOne;
  font->fontMatrix.b         = 0;
  font->fontMatrix.c         = 0;
  font->fontMatrix.d         = FixedOne;
  font->fontMatrix.tx        = 0;
  font->fontMatrix.ty        = 0;

  extraskip = 0;
  fontVersion = -1;
}


Proc (SetFontDictArray) {
  register Dict * dict;
  register Token t;
  Int32 len, i;
  FontDesc *fontp,*savefont;
  IntX result = PE_NOERR;
  boolean didFontDict;
  IntX nesting = 0;

  len = GetInteger();

  /* save current fontdesc (fontdesc for cid) */
  savefont = font;

  if (!(*procs->CIDFDArray)(len)) {
    result = PE_CALLER;
    goto ERROR;
  }

/* In the released CID format, there can't appear Subrs entries in Private dicts,
** but in case there happened to be, we set didSubroutine to true so as to
** skip them.
*/
didSubroutines = true;

  for (i = 0; i < len; i++) {

    if (!(*procs->BeginCIDFontDict)(i, &fontp)) {
     result = PE_CALLER;
     goto ERROR;
    }
    font = fontp;			/* Point to current font descriptor */
    *font = *savefont;			/* Initialize the descriptor */
    extraskip = 0;			/* Set some state variables */
    fontVersion = -1;

    dict = &CIDFontDict;
    if (!InitDict(&CIDFontDict)) {
     result = PE_BADFILE;
     goto ERROR;
    }
    nesting++;

    didFontDict = false;
    didPrivate = false;
    while(!didFontDict) {
      switch (t = GetToken()) {

      got_name:
      case t_name:
        if (dict != NULL) {
          register Field *f = MatchField(dict, token);
          if (f != NULL) {
            register IntX code = (*f->proc)(&f->u);
            if (code != 0) {
              result = code;
              goto ERROR;
            }
            break;
          }
        }
        if (streq(token, "Subrs")) {
          t = DoSubrs();
          if (t == t_name)
            goto got_name;
        } else if (streq(token, "Private")) {
          if (InitDict(&Private)) {
            dict = &Private;
            nesting++;
          }
        }
        break;

      case t_id:
      	if (streq(token, "begin")) {
      		nesting++;
      	}
      	else if (streq(token, "end")) {
      		nesting--;
      		if (nesting == 0)
      			didFontDict = true;
      		else if (nesting == 1 && dict == &Private) {
      			didPrivate = true;
	    			dict = &CIDFontDict;
	    		}
      	}
        else if (streq(token, "StartData")) {	/* for safety. */
        	result = PE_BADFILE;
        	goto ERROR;
        }
        break;

      case t_open:
        SkipTo(t_close);
        break;

      default:
        break;

      case t_EOF:
        result = PE_BADFILE;
        goto ERROR;
      } /*switch*/

    } /*while*/

    if (!(*procs->EndCIDFontDict)(i)) {
      result = PE_CALLER;
      goto ERROR;
    }
  } /*for*/


  if (nesting != 0) {
  	result = PE_BADFILE;
  	goto ERROR;
  }
  didPrivate = true;

ERROR:
  /* restore fontdesc */
  font = savefont;

  return result;
}
#endif /*COMPOSITE_FONT*/

#if COMPOSITE_FONT
/* search '>' and get a length of a character code in hex 
   otherwise it should always be one byte.
*/
#define SET_CODE_LEN (lasttoken == t_hex ? (strchr(token, '>') - token) >> 1 : 1)

Proc (DoCIDRange) {
  IntX n, srcCodeLoLen, srcCodeHiLen;
  Card32 srcCodeLo, srcCodeHi, dstGlyphIDLo;

  n = lastnumber;

  while (n--) {
    srcCodeLo = (Card32)GetInteger();
    srcCodeLoLen = SET_CODE_LEN;
    srcCodeHi = (Card32)GetInteger();
    srcCodeHiLen = SET_CODE_LEN;
    dstGlyphIDLo = (Card32)GetInteger();

    if (!(*procs->cidrange)(srcCodeLo, srcCodeLoLen, srcCodeHi, srcCodeHiLen, dstGlyphIDLo))
      return PE_CALLER;
  }

  return PE_NOERR;
}

Proc (DoCIDChar) {
  IntX n, srcCodeLen;
  Card32 srcCode, dstGlyphID;

  n = lastnumber;

  while (n--) {
    srcCode = (Card32)GetInteger();
    srcCodeLen = SET_CODE_LEN;
    dstGlyphID = (Card32)GetInteger(); 

    if (!(*procs->cidchar)(srcCode, srcCodeLen, dstGlyphID))
      return PE_CALLER;
  }

  return PE_NOERR;
}

Proc (DoCodeSpaceRange) {
  IntX n, srcCode1Len, srcCode2Len;
  Card32 srcCode1, srcCode2;

  n = lastnumber;

  while (n--) {
    srcCode1 = (Card32)GetInteger();
    srcCode1Len = SET_CODE_LEN;
    srcCode2 = (Card32)GetInteger();
    srcCode2Len = SET_CODE_LEN;

    if (!(*procs->codespacerange)(srcCode1, srcCode1Len, srcCode2, srcCode2Len))
      return PE_CALLER;
  }

  return PE_NOERR;
}

Proc (DoNotDefRange) {
  IntX n, srcCodeLoLen, srcCodeHiLen;
  Card32 srcCodeLo, srcCodeHi, dstGlyphIDLo;

  n = lastnumber;

  while (n--) {
    srcCodeLo = (Card32)GetInteger();
    srcCodeLoLen = SET_CODE_LEN;
    srcCodeHi = (Card32)GetInteger();
    srcCodeHiLen = SET_CODE_LEN;
    dstGlyphIDLo = (Card32)GetInteger();

    if (!(*procs->notdefrange)(srcCodeLo, srcCodeLoLen, srcCodeHi, srcCodeHiLen, dstGlyphIDLo))
      return PE_CALLER;
  }

  return PE_NOERR;
}

Proc (DoNotDefChar) {
  IntX n, srcCodeLen;
  Card32 srcCode;

  n = lastnumber;

  while (n--) {
    srcCode = (Card32)GetInteger();

    if (GetToken() != t_number)
      ParseError(PE_BADFILE);  

    srcCodeLen = SET_CODE_LEN;

    if (!(*procs->notdefchar)(srcCode, srcCodeLen, (Card32)ConvertInteger(token)))
      return PE_CALLER;
  }

  return PE_NOERR;
}

Proc (DoBeginRearrangedFont) {
  IntX i;
  Token t;

  if (!(*procs->rearrangedfont)(lastname))
    return PE_CALLER;

  if (GetToken() != t_open)
    ParseError(PE_BADFILE);

  for (i = 0; (t = GetToken()) != t_close; i++) {
    if (t != t_name)
      ParseError(PE_BADFILE);

    if (!(*procs->componentfont)(i, token))
      return PE_CALLER;
  }

  if (!(*procs->endcomponentfont)(i))
    return PE_CALLER;

if (GetToken() != t_id || !streq(token, "beginrearrangedfont"))
  return PE_BADFILE;

  return PE_NOERR;
}

Proc (DoXUID) 		/* Format: /XUID [v1 v2 v3] def */
{
Int32 v1, v2, v3;	/* The 3 XUID integer parameters */

  if (GetToken() != t_open)
    ParseError(PE_BADFILE);
  v1   = GetInteger();
  v2   = GetInteger();
  v3   = GetInteger();
  if (GetToken() != t_close)
    ParseError(PE_BADFILE);

  if (!(*procs->XUID)(v1, v2, v3))
    return PE_CALLER;

  GetToken();	/* def */

  return PE_NOERR;
}

Proc (DoUseMatrix) {
  FixMtx m;

  if (GetToken() != t_open)
    ParseError(PE_BADFILE);
  m.a  = GetFixed();
  m.b  = GetFixed();
  m.c  = GetFixed();
  m.d  = GetFixed();
  m.tx = GetFixed();
  m.ty = GetFixed();
  if (GetToken() != t_close)
    ParseError(PE_BADFILE);

  if (!(*procs->usematrix)(lastnumber, &m))
    return PE_CALLER;

  GetToken();	/* endusematrix */

  return PE_NOERR;
}

Proc (DoUseFont) {
  if (!(*procs->usefont)((Card16)lastnumber))
    return PE_CALLER;

  return PE_NOERR;
}

Proc (DoBFRange) {
  IntX i, n, srcCodeLoLen, srcCodeHiLen;
  Card32 srcCodeLo, srcCodeHi;
  Token t;

  n = lastnumber;

  while (n--) {
    srcCodeLo = (Card32)GetInteger();
    srcCodeLoLen = SET_CODE_LEN;
    srcCodeHi = (Card32)GetInteger();
    srcCodeHiLen = SET_CODE_LEN;

    t = GetToken();

    if (t == t_number) {
      if (!(*procs->bfrange_code)(srcCodeLo, srcCodeLoLen, srcCodeHi, srcCodeHiLen, (Card32)ConvertInteger(token)))
        return PE_CALLER;
    }
    else if (t == t_hex) {
      if (!(*procs->bfrange_code)(srcCodeLo, srcCodeLoLen, srcCodeHi, srcCodeHiLen, (Card32)strtol(token, NULL, 16)))
        return PE_CALLER;
    }
    else if (t == t_open) {
      for (i = 0; t != t_close; i++) {
        if (!(*procs->bfrange_name)(srcCodeLo, srcCodeLoLen, srcCodeHi, srcCodeHiLen, i, token))
          return PE_CALLER;

        t = GetToken();
      }
    }
    else
      ParseError(PE_BADFILE);  
  }

  return PE_NOERR;
}

Proc (DoBFChar)
{
  IntX n, srcCodeLen;
  Card32 srcCode;
  Token t;

  n = lastnumber;

  while (n--) {
    srcCode = (Card32)GetInteger();

    t = GetToken();
    srcCodeLen = SET_CODE_LEN;

    if (t == t_number) {
      if (!(*procs->bfchar_code)(srcCode, srcCodeLen, (Card32)ConvertInteger(token)))
        return PE_CALLER;
    }
    else if (t == t_hex) {
      if (!(*procs->bfchar_code)(srcCode, srcCodeLen, (Card32)strtol(token, NULL, 16)))
        return PE_CALLER;
    }
    else if (t == t_name) {
      if (!(*procs->bfchar_name)(srcCode, srcCodeLen, token))
        return PE_CALLER;
    }
    else
      ParseError(PE_BADFILE);  
  }

  return PE_NOERR;
}


Proc (DoUseCMap) 
{
/* Pass the name of the used CMap to the user.  Only one used CMap per CMap, */
/* although they may be nested. */
if (!(*procs->UseCMap)(lastname))
   return PE_CALLER;

return PE_NOERR;
} /* end DoUseCMap() */

#endif /*COMPOSITE_FONT*/


/*
 * check/correct the data
 */

PRIVATE Fixed AdjustBlueScale ARGDEF3(Fixed, bluescale, CardX, len, BlueValueRec *, val) {
  register CardX i;
  register Fixed maxovershoot, overshoot;
  maxovershoot = 0;
  for (i = 0; i < len; i++, val++) {
    overshoot = val->topEdge - val->botEdge;
    if (overshoot > maxovershoot)
      maxovershoot = overshoot;
  }
  overshoot = fixmul(maxovershoot, bluescale);
  if (overshoot < FIXEDONE)
    return bluescale;
  return fixdiv(FIXEDONE, maxovershoot) - 1;
}

PRIVATE procedure FixFontDesc ARGDEF1(FontDesc *, font) {
  CardX i;
  boolean fakeVW = false, fakeHW = false;

#if COMPOSITE_FONT
  /* TODO: is this correct? */
  /* disable stem snap for old fonts */
  if (isCompFont && fontVersion >= 0 && fontVersion < 3) {
    stemWidth = 0;
    font->values->stdHW = 0;
    font->values->stdVW = 0;
    font->lenStemSnapH = 0;
    font->lenStemSnapV = 0;
    for (i = 1; i < font->numMasters; i++) {
      FontValues *val = &font->values[i];
      val->stdHW = 0;
      val->stdVW = 0;
    }
   } /* end if */
#endif

  if (font->numMasters == 0) {
    if (stemWidth != 0) {
      if (fontval->stdHW == 0 && font->lenStemSnapH == 0)
        fontval->stdHW = stemWidth;
      if (fontval->stdVW == 0 && font->lenStemSnapV == 0)
        fontval->stdVW = stemWidth;
    }
    font->numMasters = 1;
  }

#if COMPOSITE_FONT /* Moved this to AFTER numMasters set equal to 1 */
  if (isCompFont && fontVersion >= 0 && fontVersion < 3) {
    for (i = 1; i < font->numMasters; i++) {
      FontValues *val = &font->values[i];
      val->stdHW = 0;
      val->stdVW = 0;
    }
  }
#endif

  if (font->lenStemSnapH == 0 && fontval->stdHW != 0) {
    fakeHW = true;
    font->lenStemSnapH = 1;
  }
  if (font->lenStemSnapV == 0 && fontval->stdVW != 0) {
    fakeVW = true;
    font->lenStemSnapV = 1;
  }
  for (i = 0; i < font->numMasters; i++) {
    FontValues *val = &font->values[i];
    val->blueScale = AdjustBlueScale(val->blueScale, font->numBlueValues, val->blueValues);
    if (fakeHW)
      val->stemSnapH[0] = val->stdHW;
    if (fakeVW)
      val->stemSnapV[0] = val->stdVW;
  }
}


/*
 * miscellaneous
 */

/* InitGlobals -- reset the global state before parsing */
PRIVATE procedure InitGlobals ARGDEF1(ParseFontProcs *, parseprocs) {
  procs = parseprocs;

  didPrivate = false;
  didCharStrings = false;
  didSubroutines = false;
  copiedBlendDict = false;
  copiedPrivateBlend = false;

  /* font properties */
  fontType = 1;
  stemWidth = 0;
  numAxes = 0;

  encoding.useStd       = procs->UseStandardEncoding;
  encoding.useSpecial   = procs->UseSpecialEncoding;
  encoding.special      = procs->SpecialEncoding;

  accentEncoding.useStd         = procs->UseStandardAccentEncoding;
  accentEncoding.useSpecial     = procs->UseSpecialAccentEncoding;
  accentEncoding.special        = procs->SpecialAccentEncoding;

  MEMZERO(font, sizeof (FontDesc));

  font->versionNum      = 1;            /* TODO */
  font->lenIV           = 4;
  font->expansionFactor      = 3932;         /*  == Fixed 0.06 */
  font->subroutineNumberBias = 0;
  font->lenBuildCharArray = 32;
  font->initialRandomSeed = 0;

  fontval->defaultSidebearingX = 0;
  fontval->defaultSidebearingY = 0;
  fontval->defaultWidthX = 0;
  fontval->defaultWidthY = 0;

  fontval->blueShift            = FixInt(7);
  fontval->blueFuzz             = FixInt(1);
  fontval->blueScale            = 2597;         /* == Fixed 0.039625 */

  fontval->fontBBox.bl.x        = 0;
  fontval->fontBBox.bl.y        = 0;
  fontval->fontBBox.tr.x        = 0;   
  fontval->fontBBox.tr.y        = 0;

  font->fontMatrix.a         = FixedOne;
  font->fontMatrix.b         = 0;
  font->fontMatrix.c         = 0;
  font->fontMatrix.d         = FixedOne;
  font->fontMatrix.tx        = 0;
  font->fontMatrix.ty        = 0;

#if COMPOSITE_FONT
  extraskip = 0;
  fontVersion = -1;
#endif
}


/*
 * InitParseTables
 *      this is a public interface and should be called once at the dawn of
 *      time.  these data structures are static, but Think C on the Mac
 *      when building a driver (ATM) refuses to initialize a static from a
 *      pointer.  sigh.
 *
 *      if you change the total number of dictionary fields, remember to change
 *      the FIELD_COUNT; otherwise, this will return PE_CANTHAPPEN.  a very gross
 *      c preprocessor hack is used with BCMAIN to make the problem more obvious.
 *
 *      can return either PE_NOERR or PE_CANTHAPPEN
 */

#if BCMAIN
static struct { char *file; IntX line; } warning = { __FILE__, __LINE__ + COMPOSITE_FONT ? 4 : 6 };
#endif

#if COMPOSITE_FONT
#define FIELD_COUNT     142
#else
#define FIELD_COUNT     68
#endif /*COMPOSITE_FONT*/

PUBLIC IntX InitParseTables ARGDEF0() {
  register Field *f;
  register IntX (*SetInt) ARGDECL1(Arg *, u);
  static Field fieldtable[FIELD_COUNT];

#define FUNC(id)                offsetof(ParseFontProcs, id)
#define FONTOFFSET(field)       offsetof(FontDesc, field)
#define VALOFFSET(field)        offsetof(FontValues, field)

  static ArrayDesc
    StemSnapH = { MAXSTEMS, FONTOFFSET(lenStemSnapH), 
                            (Card16)VALOFFSET(stemSnapH[0]) },
    StemSnapV = { MAXSTEMS, FONTOFFSET(lenStemSnapV), 
                            (Card16)VALOFFSET(stemSnapV[0]) };
  static BlueDesc
    Blues       = {
      FONTOFFSET(numBlueValues),
      FONTOFFSET(blueZones),
      (Card16)VALOFFSET(blueValues[0])
    },
    FamilyBlues = {
      FONTOFFSET(numFamilyBlues),
      FONTOFFSET(familyBlueZones),
      (Card16)VALOFFSET(familyBlueValues[0])
    };

  f = fieldtable;

/* SUPPRESS 558 *//* The conditional expression 'if' is always true */
  if (sizeof (int) == sizeof (Int32))
    SetInt = SetInt32;
/* SUPPRESS 558 */ /* SUPPRESS 529 *//* The conditional expression 'if' is always false AND The statement cannot be reached */
  else if (sizeof (int) == sizeof (Int16))
/* SUPPRESS 529 *//* The statement cannot be reached */
    SetInt = SetInt16;
  else
    return PE_CANTHAPPEN;

#define BeginDict(d, i) { d.table = f; d.init = i; }
#define EndDict(d)      { d.len = f - d.table; }

#define N(n, p)                 { f->name = n; f->proc = p; f++; }
#define P(n, proc, arg)         { f->u.p = arg; N(n, proc) }
#define I(n, proc, arg)         { f->u.i = arg; N(n, proc) }
#define F(n, proc, field)       I(n, proc, FONTOFFSET(field))
#define V(n, proc, field)       I(n, proc, VALOFFSET(field))
#define C(n, proc, func)        I(n, proc, FUNC(func))

#if COMPOSITE_FONT
#  define       KN(x, y)        N(x, y)
#  define       KP(x, y, z)     P(x, y, z)
#  define       KI(x, y, z)     I(x, y, z)
#  define       KF(x, y, z)     F(x, y, z)
#  define       KV(x, y, z)     V(x, y, z)
#  define       KC(x, y, z)     C(x, y, z)
#else
#  define       KN(x, y)
#  define       KP(x, y, z)
#  define       KI(x, y, z)
#  define       KF(x, y, z)
#  define       KV(x, y, z)
#  define       KC(x, y, z)
#endif

  BeginDict(PrivateBlend, InitPrivateBlend);
    V(  "BlueFuzz",             SetBlendFixed,          blueFuzz)
    V(  "BlueScale",            SetBlendFixed,          blueScale)
    V(  "BlueShift",            SetBlendFixed,          blueShift)
    P(  "BlueValues",           ParseBlendBlues,        &Blues)
    P(  "FamilyBlues",          ParseBlendBlues,        &FamilyBlues)
    P(  "FamilyOtherBlues",     ParseBlendOtherBlues,   &FamilyBlues)
    N(  "ForceBold",            SetBlendForceBold)
    P(  "OtherBlues",           ParseBlendOtherBlues,   &Blues)
    V(  "StdHW",                ParseBlendStdW,         stdHW)
    V(  "StdVW",                ParseBlendStdW,         stdVW)
    P(  "StemSnapH",            ParseBlendStemSnap,     &StemSnapH)
    P(  "StemSnapV",            ParseBlendStemSnap,     &StemSnapV)
    V(  "defaultSidebearingX",  SetBlendFixed,          defaultSidebearingX)
    V(  "defaultSidebearingY",  SetBlendFixed,          defaultSidebearingY)
    V(  "defaultWidthX",        SetBlendFixed,          defaultWidthX)
    V(  "defaultWidthY",        SetBlendFixed,          defaultWidthY)
  EndDict(PrivateBlend);

  BeginDict(Private, InitPrivate);
    V(  "BlueFuzz",             SetFixed,               blueFuzz)
    V(  "BlueScale",            SetFixed,               blueScale)
    V(  "BlueShift",            SetFixed,               blueShift)
    P(  "BlueValues",           ParseBlues,             &Blues)
    N(  "Erode",                ParseErodeProc)
    I(  "ExpansionFactor",      SetFixed,
                FONTOFFSET(expansionFactor) - FONTOFFSET(values[0]))
    P(  "FamilyBlues",          ParseBlues,             &FamilyBlues)
    P(  "FamilyOtherBlues",     ParseOtherBlues,        &FamilyBlues)
    N(  "ForceBold",            SetForceBold)
    I(  "ForceBoldThreshold",   SetFixed,
                        FONTOFFSET(boldThreshold) - FONTOFFSET(values[0]))
    F(  "LanguageGroup",        SetInt16,               languageGroup)
    P(  "OtherBlues",           ParseOtherBlues,        &Blues)
    KC( "PGFontID",             CallIntProc,            PGFontID)
    N(  "RndStemUp",            SetRndStemUp)
    KC( "RunInt",               CallStringProc,         RunInt)
    KC( "SDBytes",              CallIntProc,            SDBytes)
    P(  "StdHW",                ParseStdW,              &StemSnapH)
    P(  "StdVW",                ParseStdW,              &StemSnapV)
    P(  "StemSnapH",            SetFixedArray,          &StemSnapH)
    P(  "StemSnapV",            SetFixedArray,          &StemSnapV)
    KC( "SubrCount",            CallIntProc,            SubrCount)
    KC( "SubrMapOffset",        CallIntProc,            SubrMapOffset)
    F(  "UniqueID",             SetInt32,               privUniqueId)
    V(  "defaultSidebearingX",  SetFixed,               defaultSidebearingX)
    V(  "defaultSidebearingY",  SetFixed,               defaultSidebearingY)
    V(  "defaultWidthX",        SetFixed,               defaultWidthX)
    V(  "defaultWidthY",        SetFixed,               defaultWidthY)
    I(  "initialRandomSeed",    SetFixed,
                FONTOFFSET(initialRandomSeed) - FONTOFFSET(values[0]))
    F(  "lenBuildCharArray",    SetInt16,               lenBuildCharArray)
    F(  "lenIV",                SetInt16,               lenIV)
    F(  "subroutineNumberBias", SetInt16,               subroutineNumberBias)
  EndDict(Private);

  BeginDict(BlendDict, InitBlendDict);
    N(  "FontBBox",             SetBlendFontBBox)
    C(  "ItalicAngle",          CallBlendFixedProc,     BlendItalicAngle)
    C(  "UnderlinePosition",    CallBlendFixedProc,     BlendUnderlinePosition)
    C(  "UnderlineThickness",   CallBlendFixedProc,     BlendUnderlineThickness)
  EndDict(BlendDict);

  BeginDict(FontDict, NULL);
    P(  "AccentEncoding",       DoEncoding,             &accentEncoding)
    N(  "BlendAxisTypes",       SetBlendAxisTypes)
    N(  "BlendDesignMap",       SetBlendDesignMap)
    N(  "BlendDesignPositions", SetBlendDesignPositions)
    KN( "CDevProc",             SetCDevProc)
    KN( "CharOffsets",          SetCharOffsets)                 /* TODO */
    P(  "Encoding",             DoEncoding,             &encoding)
    C(  "FamilyName",           CallStringProc,         FamilyName)
    N(  "FontBBox",             SetFontBBox)
    N(  "FontMatrix",           SetFontMatrix)
    C(  "FontName",             CallStringProc,         FontName)
    N(  "FontType",             SetFontType)
    C(  "FullName",             CallStringProc,         FullName)
    C(  "ItalicAngle",          CallFixedProc,          ItalicAngle)
    C(  "Notice",               CallStringProc,         Notice)
    KN( "PGFArray",             SetPGFArray)
    KN( "PGFontType",           SetFontType)
    F(  "PaintType",            SetInt16,               paintType)
    KC( "PrimogenitalFontName", CallStringProc,         FontName)
    I(  "StrokeWidth",          SetFixed,               
              FONTOFFSET(strokeWidth) - FONTOFFSET(values[0]))
    KN( "SubsVector",           SetSubsVector)
    C(  "UnderlinePosition",    CallFixedProc,          UnderlinePosition)
    C(  "UnderlineThickness",   CallFixedProc,          UnderlineThickness)
    C(  "UniqueID",             CallIntProc,            PublicUniqueID)
    C(  "Weight",               CallStringProc,         Weight)
    N(  "WeightVector",         SetWeightVector)
    C(  "isFixedPitch",         CallBooleanProc,        isFixedPitch)
#if COMPOSITE_FONT
    N(  "version",              SetVersion)
#else
    C(  "version",              CallStringProc,         version)
#endif
  EndDict(FontDict);

#if COMPOSITE_FONT
  BeginDict(CompositeDict, NULL);
    P(  "Encoding",             DoEncoding,             &encoding)
    N(  "FDepVector",           SetFDepVector)
    C(  "FMapType",             CallIntProc,            FMapType)
    N(  "FontBBox",             SetFontBBox)
    N(  "FontMatrix",           SetFontMatrix)
    C(  "FontName",             CallStringProc,         FontName)
    N(  "FontType",             SetFontType)
    N(  "MDFV",                 SetMDFV)
    C(  "MDID",                 CallIntProc,            MDID)
    C(  "PGFontID",             CallIntProc,            PGFontID)
    F(  "PaintType",            SetInt16,               paintType)
    C(  "PrefEnc",              CallStringProc,         PrefEnc)
    N(  "SubsVector",           SetSubsVector)
    C(  "WMode",                CallIntProc,            WritingMode)
    C(  "version",              CallStringProc,         version)
  EndDict(CompositeDict);
#endif

#if COMPOSITE_FONT
  BeginDict(DerivedDict, NULL);
    N(  "CDevProc",             SetCDevProc)
    N(  "CharOffsets",          SetCharOffsets)
    C(  "CharStrings",          CallStringProc,         UseNamedCharStrings)
    P(  "Encoding",             DoEncoding,             &encoding)
    N(  "FontBBox",             SetFontBBox)
    N(  "FontMatrix",           SetFontMatrix)
    C(  "FontName",             CallStringProc,         FontName)
    N(  "FontType",             SetFontType)
    N(  "PGFArray",             SetPGFArray)
    F(  "PaintType",            SetInt16,               paintType)
    C(  "UniqueID",             CallIntProc,            PublicUniqueID)
    C(  "WMode",                CallIntProc,            WritingMode)
    C(  "version",              CallStringProc,         version)
  EndDict(DerivedDict);
#endif

#if COMPOSITE_FONT
  BeginDict(CIDFontDict, NULL);
    C(  "CIDCount",            	CallIntProc,            CIDCount)
    C(  "CIDFontName",          CallStringProc,         FontName)
    N(  "CIDFontType",          SetFontType)
    C(  "CIDFontVersion",       CallIntProc,            CIDFontVersion)
    N(  "FDArray",              SetFontDictArray)
    C(  "FDBytes",              CallIntProc,            FDBytes)
    N(  "FontBBox",             SetFontBBox)
    N(  "FontMatrix",           SetFontMatrix)
    C(  "FontName",             CallStringProc,         FDArrayFontName)
    N(  "FontType",             SetFontType)
    C(  "FullName",             CallStringProc,         FullName)
    C(  "GDBytes",              CallIntProc,            GDBytes)
    C(  "Notice",               CallStringProc,         Notice)
    C(  "Ordering",             CallStringProc,         Ordering)
    F(  "PaintType",            SetInt,                 paintType)
    C(  "Registry",             CallStringProc,         Registry)
    C(  "Supplement",           CallIntProc,            Supplement)
    C(  "UIDBase",              CallIntProc,            UIDBase)
    C(  "UnderlinePosition",    CallFixedProc,          UnderlinePosition)
    C(  "UnderlineThickness",   CallFixedProc,          UnderlineThickness)
    N(  "XUID",			DoXUID)
  EndDict(CIDFontDict);
#endif

#if COMPOSITE_FONT
  BeginDict(EncodingDict, NULL);
    C(  "Ordering",             CallStringProc,         Ordering)
    C(  "Registry",             CallStringProc,         Registry)
    C(  "Supplement",           CallIntProc,            Supplement)
    N(  "beginbfchar",          DoBFChar)
    N(  "beginbfrange",         DoBFRange)
    N(  "begincidchar",         DoCIDChar)
    N(  "begincidrange",        DoCIDRange)
    N(  "begincodespacerange",  DoCodeSpaceRange)
    N(  "beginnotdefchar",      DoNotDefChar)
    N(  "beginnotdefrange",     DoNotDefRange)
    N(  "beginpgfrange",        DoCIDRange)
    N(  "beginusematrix",       DoUseMatrix)
    N(  "usecmap",              DoUseCMap)
    N(  "usefont",              DoUseFont)
  EndDict(EncodingDict);
#endif /*COMPOSITE_FONT*/


#undef  N
#undef  P
#undef  I
#undef  C
#undef  V
#undef  F

#undef  KN
#undef  KP
#undef  KI
#undef  KC
#undef  KV
#undef  KF

#undef  FUNC
#undef  DICT
#undef  FONTOFFSET
#undef  VALOFFSET

#undef  BeginDict
#undef  EndDict

#if BCMAIN
  if (f - fieldtable != lengthof(fieldtable))
    fprintf(stderr, "%s:%d: tablesize is %d, should be %d\n",
            warning.file, warning.line, lengthof(fieldtable), f - fieldtable);
  DictCheck(&FontDict);
  DictCheck(&Private);
  DictCheck(&BlendDict);
  DictCheck(&PrivateBlend);
  DictCheck(&CompositeDict);
  DictCheck(&DerivedDict);
  DictCheck(&CIDFontDict);
  DictCheck(&EncodingDict);
#endif

  if (f - fieldtable != lengthof(fieldtable))
    return PE_CANTHAPPEN;

  return PE_NOERR;
}


/*
 * ParseFont -- the public interface
 */

PUBLIC IntX ParseFont ARGDEF5(
  FontDesc **, fontp,           /* where to store the font data */
  ParseFontProcs *, parseprocs, /* callback procs */
  GrowableBuffer *, growbuf,    /* growable buffer to contain a token. */
  GrowableBuffer *, lookaside,  /* input lookaside buffer */
  void *, pClientHook		/* Client's data */
) {
  register IntX error;
  clientHook = pClientHook;

  if ((error = setjmp(parser_exception)) != 0)
    return error;

  font = *fontp;
  InitGlobals(parseprocs);
  InitInput(growbuf, lookaside);

#if !COMPOSITE_FONT
  error = DoParse(&FontDict);
  FixFontDesc(font);

#else /* COMPOSITE_FONT */
  parsestate = GetHeaderComment(Type1Font);
  switch (parsestate) {
  case Type1Font:
    isCompFont = false;
    error = DoParse(&FontDict);
    FixFontDesc(font);
    break;
  case AdobePGFont:
    isCompFont = true;
    error = DoParse(&FontDict);
    FixFontDesc(font);
    break;
  case AdobeDerivedFont:
    isCompFont = true;
    error = DoParse(&DerivedDict);
    break;
  case AdobeCompositeFont:
  case AdobeStdCompFont:
  case AdobeStdCompFont_BDY:
    isCompFont = true;
    error = DoParse(&CompositeDict);
    break;
  case AdobeCIDFont:
    isCompFont = true;
    error = DoParse(&CIDFontDict);
    break;
  default:
    return PE_BADFILE;
  }
#endif

  *fontp = font;
  return error;
}

#if COMPOSITE_FONT
/*
 * ParseEncoding -- the public interface
 */

PUBLIC IntX ParseEncoding ARGDEF4(
  ParseFontProcs *, parseprocs, /* callback procs */
  GrowableBuffer *, growbuf,    /* growable buffer to contain a token. */
  GrowableBuffer *, lookaside,  /* input lookaside buffer */
  void *, pClientHook		/* Client's data */
) {
  register IntX error;

  clientHook = pClientHook;
  if ((error = setjmp(parser_exception)) != 0)
    return error;

  procs = parseprocs;
  InitInput(growbuf, lookaside);

  parsestate = GetHeaderComment(Type1Font);
  switch (parsestate) {
  case AdobeCMap:
    isCompFont = true;
    error = DoParseEncoding(&EncodingDict);
    break;
  case AdobeRearrangedFont:
    {
		IntX n = 0;
		boolean first = true;
		boolean foundSubCategory = false;
		Token tokenlist[5];

		tokenlist[n++] = t_subcategory;
		tokenlist[n++] = t_startrearrangedfont;
		tokenlist[n++] = t_name;
		tokenlist[n++] = t_id;
searchagain:
		switch (SkipToEitherOf(tokenlist, n)) {
		case t_subcategory:
			if (!first)
				return PE_BADFILE;
			if (GetToken() != t_id || !streq(token, "RearrangedFont"))
				return PE_BADFILE;
			foundSubCategory = true;
			first = false;
	   	goto searchagain;
		case t_name:
	   	if (first && !foundSubCategory)
	   	 	return PE_BADFILE;
			first = false;
			goto searchagain;
		case t_id:
 	   	if (first && !foundSubCategory)
	   	 	return PE_BADFILE;
    	first = false;
			goto searchagain;
		case t_startrearrangedfont:
			if (GetToken() != t_name)
				return PE_BADFILE;
			strncpy(lastname, token, MAXLEN_PSNAME);	/* remember the last name. used by DoBeginRearrangedFont */
			lastname[MAXLEN_PSNAME - 1] = 0;
			if (error = DoBeginRearrangedFont(NULL))
				return error;
			break;

	   default:
	   	 return PE_BADFILE;
	   }
    isCompFont = true;
    error = DoParseEncoding(&EncodingDict);
    break;
    }
  default:
    return PE_BADFILE;
  }

  return error;
}
#endif

