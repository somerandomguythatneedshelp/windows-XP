/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: UIC.H                                                  */
/*                                                                           */
/* Description: This include contains the prototype for dmg\uic.c            */
/*                                                                           */
/*****************************************************************************/

#ifndef UIC_H
#define UIC_H

BOOL _loadds FAR PASCAL CHUICDlg(HWND hDlg, unsigned imsg, WORD wParam, 
                                 LONG lParam);

#endif /* ifndef UIC_H */
