#ifndef _CFONT_H
#define _CFONT_H  1


/* NEAR functions */
VOID NEAR REALIZESEG PASCAL MPFontScale(LPPDEVICE,LPPFMHEADER,LPINT,
                                        LPINT,LPINT,LPINT,int);

/* FAR functions */
FLAG FAR PASCAL RealizeFontProperties(LPPDEVICE,LPLOGFONT,LPPSFONTINFO,
                                      LPTEXTXFORM,HPFONTDIRECTORY, BOOL, BYTE, HPPFMPROLOG);

void FAR PASCAL PatchPFMOffsets(LPPFMHEADER);

void FAR PASCAL SetLeading(BYTE,SHORT, int, int,LPINT,LPINT,int,BYTE);

VOID  FAR PASCAL ScaleDevCharWidths(LPPDEVICE lppd, LPPSFONTINFO FontInfo) ;


#endif /* ifndef _CFONT_H */
