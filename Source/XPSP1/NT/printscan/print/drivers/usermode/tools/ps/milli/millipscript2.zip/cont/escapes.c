/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ESCAPES.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for ...                   */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "krnlcmn.h"  // For GetProcessDword()
#include "ufoenc.h"

#pragma code_seg(_ESCAPESSEG)

#define PS_BUFSIZE_BIG ((WORD) 65535)   // Because a PostScript string may be this big


extern BOOL FAR PASCAL FarMergePublicDM(LPWPXBLOCKS, LPPSEXTDEVMODE,
                                        LPPSEXTDEVMODE);
// Fix bug 194796.  jjia  2/18/97
extern BOOL __export CALLBACK LoseSoftFontsProc(HWND hDlg, UINT message,
                                                WPARAM wParam, LPARAM lParam);

/* Local functions */

void FAR PASCAL EmitStringRef(LPPDEVICE lppd, DWORD    dwstringref) ;

BYTEFLAG bfIsMSRectHackCbPch( unsigned int cb, LPSTR pch );
                                                  // True if pch invokes MSRectHack

SHORT PASCAL ResetDV(LPPDEVICE,LPPDEVICE);
BOOL CheckPattern(unsigned int cb, LPSTR pch, LPSTR szPattern);

// OEMPLUGI begin
SHORT NEAR PASCAL CallOEMStartDocStub(LPPDEVICE lppd, PRINTJOB_TYPE wPrintJobType);
SHORT NEAR PASCAL CallOEMEndDocStub(LPPDEVICE lppd);
SHORT NEAR PASCAL CallOEMEndSessionStub(LPPDEVICE lppd);
void NEAR PASCAL EndOEM(LPPDEVICE lppd);
void FAR PASCAL ResyncOutputFormat(LPPDEVICE lppd);
// OEMPLUGI end

/***********************************************************************
*                       ESCOpenChannel
*  function:
*       initializes the translation process for Aldus OPENCHANNEL escape
*
*       May be called only in state ST_ENABLED.  Never disabled.
*       Causes state transition to ST_MARKED_PAGE.
*       Generates no PostScript.
*
*  prototype:
*       SHORT FAR PASCAL ESCOpenChannel(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- pointer to string containing the job title
*       LP lpOutData -- not used
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/
SHORT FAR PASCAL ESCOpenChannel(LPPDEVICE lppd,LP lpInData,LP lpOutData)
{
    SHORT sRC, retval;
    LPDOCINFO lpDocInfo;
    LPASCIIBINPTRS tempptr;

    sRC=1;    //success
    lpDocInfo = (LPDOCINFO) lpOutData;

    if (stCurrentLppd(lppd) != ST_ENABLED)
    {
        sRC = SP_ERROR; // failure -- can't call us in this state.
    }
    else
    {
       // Set this flag ealier so OEM and AlertDialog can see this flag in lppd. 7-21-95, PPeng. fix bug118128
       // set this falg for BinitUFL();
        lppd->job.bfESCOpenChannel = TRUE;

        BInitUFL(lppd);

        if(lpDocInfo  &&  (lpDocInfo->cbSize == sizeof(DOCINFO)) &&
               lpDocInfo->lpszDatatype &&
               lpDocInfo->lpszDatatype[0])
        {
            if( !lstrcmp(lpDocInfo->lpszDatatype, DATATYPE_EPS) )
            {
               lppd->lpPSExtDevmode->dm.enumDialect = DIA_EPS;

               lppd->lpPSExtDevmode->dm2.bOutputDialect = (BYTE) DIALECT_EPS;
               lppd->lpPSExtDevmode->dm2.bPJL_Protocol = FALSE;
               lppd->lpPSExtDevmode->dm2.bDSC = TRUE;
               lppd->lpPSExtDevmode->dm2.bVM_Tracking = FALSE;
            }
        }

        if (lpDocInfo && lpDocInfo->lpszOutput)
            lstrcpyn(lppd->szSDOutput, (LPSTR)lpDocInfo->lpszOutput, sizeof(lppd->szSDOutput)-2);
        else
            lstrcpyn(lppd->szSDOutput, (LPSTR)lppd->szPortName, sizeof(lppd->szSDOutput)-2);

        if( lpInData && lpInData[0] )
        {
            lstrcpyn((LPSTR)lppd->szTitle,(LPSTR)lpInData,
                                    sizeof(lppd->szTitle) );
            // lstrcpyn() truncates and appends NULL, if srclen > dstlen
        }

        // OEMPLUGI begin
        sRC = CallOEMStartDocStub(lppd, OPENCHANNELJOB);
        // OEMPLUGI end

        if ( sRC > 0)
           ResyncOutputFormat(lppd);

        if ( (sRC == SP_ERROR) ||
             (sRC == SP_APPABORT) ||
             (sRC == SP_USERABORT)  )
        {
            // OEMPLUGI begin
            EndOEM(lppd);
            // OEMPLUGI end

            return (sRC);
        }

#ifdef ADOBE_DRIVER
    if (!GetWM_NUP_Confirmation(lppd))
    {
       lppd->stCurrent = ST_ENABLED;
       ESCAbortDoc(lppd, NULL, NULL);
       return(SP_USERABORT);
    }
#endif

        retval = StartTranslation(lppd, lpDocInfo);
        if (retval == RC_userabort)
        {
            return (SP_USERABORT);
        }
        else if (retval == RC_fail)
            return -1;

        // I know that is the gross violation of the logic of the
        //  state machine, but this is the _ONLY_ way I can switch
        //  to the IN_DOCUMENT state without emitting any PostScript.
        lppd->stCurrent =  ST_MARKED_PAGE;
        lppd->job.bfESCOpenChannel = TRUE;

        // Force output to be ASCII7
        //  Fixed 24-Aug-1993  -by-  [olegs]
#ifndef ADOBE_DRIVER_42
        lppd->lpPSExtDevmode->dm2.bCompress = FALSE;
#endif
        AsciiOrBinary(PPSLEVEL1, FALSE, lppd);
        CInitPen(lppd);
        CInitBrush(lppd);


      tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

      //   PageMaker 6.0 will emit all PJL and PatchFile stuff for us.
#if 0
      if(lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS)
      {
         LPPRINTERINFO   lpPrinterInfo;
         WORD   index ;
         BOOL bTemp;



         // When Open Channel - send PJL header, if necessary.
         //  Fixed 24-Aug-1994  -by-  [olegs]
//         bTemp = lppd->lpPSExtDevmode->dm2.bSendCtrlDBefore ;
//         lppd->lpPSExtDevmode->dm2.bSendCtrlDBefore = FALSE;
//         PSSendBeginProtocol(lppd) ;
//         lppd->lpPSExtDevmode->dm2.bSendCtrlDBefore = bTemp; ;


         lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);

         if(lpPrinterInfo->PatchFile.w.length  ||
                                 lpPrinterInfo->nJobPatchFiles)
            (*tempptr->PSSendDSC)(lppd, DSC_adobe, (LPSTR)NULL);

         // Emit Patch file string if it exists
         if (lpPrinterInfo->PatchFile.w.length)
         {
            (*tempptr->PSSendDSC)(lppd, DSC_begin_patchfile  , (LPSTR)NULL);

            EmitStringRef(lppd, lpPrinterInfo->PatchFile.dword) ;
            (*tempptr->PSSendCRLF)(lppd);
            (*tempptr->PSSendDSC)(lppd, DSC_end_patchfile, (LPSTR)NULL);
            (*tempptr->PSSendCRLF)(lppd);
         }

         // Emit Job Patch file string if it exists
         for (index = 0 ; index < lpPrinterInfo->nJobPatchFiles ; index++)
         {
            char   zTemp[8] ;

            wsprintf((LPSTR)zTemp,(LPSTR)"%d",
               lpPrinterInfo->JobPatchFile[index].order);

            PSSendFragment(lppd,PSFRAG_beginsafe);
            (*tempptr->PSSendCRLF)(lppd);

            (*tempptr->PSSendDSC)(lppd, DSC_begin_jobpatchfile  , (LPSTR)zTemp);

            EmitStringRef(lppd, lpPrinterInfo->JobPatchFile[index].invoc.dword) ;
            (*tempptr->PSSendCRLF)(lppd);
            (*tempptr->PSSendDSC)(lppd, DSC_end_jobpatchfile    , (LPSTR)NULL);
            PSSendFragment(lppd,PSFRAG_endsafe);
            (*tempptr->PSSendCRLF)(lppd);
         }
      }

#endif

    }
    return(sRC);
}

/***********************************************************************
*                       ESCCloseChannel
*  function:
*       Closes the channel for Aldus' special PASSTHRU escape
*
*       May be called after StartDoc and in place of EndDoc.
*       Never disabled.
*       Causes  transition to ST_ENABLED.
*
*  prototype:
*       SHORT FAR PASCAL ESCCloseChannel(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- not used
*       LP lpOutData -- not used
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCCloseChannel(LPPDEVICE lppd,LP lpInData,LP lpOutData)
{
    SHORT sRC = 1;    //success
    HTASK hCurrentTask;

//    BOOL  bTemp;

    // When Close Channel - send PJL trailer, if necessary.
    //  Fixed 24-Aug-1994  -by-  [olegs]
//    bTemp = lppd->lpPSExtDevmode->dm2.bSendCtrlDBefore ;
//    lppd->lpPSExtDevmode->dm2.bSendCtrlDAfter = FALSE;

    // OEMPLUGI begin
    // Call OEMEndDoc function first, then call OEMTermDll after
    // EndTranslation so that the OEM filter can be performed.
    sRC = CallOEMEndDocStub(lppd);
    // OEMPLUGI end


//    PSSendEndProtocol(lppd) ;
//    lppd->lpPSExtDevmode->dm2.bSendCtrlDAfter = bTemp;

    EndTranslation(lppd);

    // OEMPLUGI begin
    EndOEM(lppd);
    // OEMPLUGI end

    BTermUFL(lppd); // terminate UFL
    // I know that is the gross violation of the logic of the
    //  state machine, but this is the _ONLY_ way I can switch
    //  to the ST_ENABLED state without emitting any PostScript.
    lppd->stCurrent =  ST_ENABLED;
    lppd->job.bfESCOpenChannel = FALSE;
    hCurrentTask = GetCurrentTask();
    return(sRC);
}


/***********************************************************************
*                       ESCPostScriptPass
*  function:
*       allows raw data to be passed through to the printer.
*       The main difference between this escape and ESCPassThrough
*       is in data encapsulation. This particular escape was added
*       by Aldus' request and we _DO NOT_ output any --save--
*       --restore-- brackets around PostScript.
*
*       May be called anytime between StartDoc and EndDoc.  Never
*       disabled.  Never changes driver state.
*
*  prototype:
*       SHORT FAR PASCAL ESCPostScriptPass(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- pointer to passthrough struct, 1st word = size,
*                       the rest is data.
*       LP lpOutData -- not used
*  returns:
*       >0 => number of bytes sent
*       0 => error
************************************************************************/

SHORT FAR PASCAL ESCPostScriptPass(LPPDEVICE lppd,LP lpInData,LP lpOutData)
{
    WORD wNumBytes;
    WORD retval;

    if (lppd->sMagic != LUCAS)
          retval = 0;
    else
    {
        wNumBytes=*((LPWORD)lpInData)++;

        // Give oem a chance to modify the postscript streams.
        // The burden is on OEMs(e.g. PSFax) to figure out the
        // beginning of the print job and the end of the print job.
        // They can modify the postscript streams accordingly.

        AdobeOEMSendPSStub(lppd, PS_INDEX_OPENCHANNEL, lpInData, wNumBytes);
        retval = wNumBytes;

    } // if sMagic != LUCAS ... else ...

    return(retval);
}

/***********************************************************************
*                       ESCSetGDIXForm
*  function:
*       Sends the "normal" CTM that directly converts GDI units
*       into PS units.
*
*       May be called during ST_ENABLED only.  Never disabled.
*       Does not cause a state change.
*
*  prototype:
*       SHORT FAR PASCAL ESCSetGDIXForm(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- not used
*       LP lpOutData -- not used
*  returns:
*       1 => supported
*       0 => error
************************************************************************/

SHORT FAR PASCAL ESCSetGDIXForm(LPPDEVICE lppd,LP lpInData,LP lpOutData)
{
    return(CSetGDIXForm(lppd));
}

/***********************************************************************
*                       ESCDownLoadHeader
*  function:
*       Downloads one of the specified headers
*
*       May be called during ST_ENABLED only.  Never disabled.
*       Does not cause a state change.
*
*  prototype:
*       SHORT FAR PASCAL ESCDownLoadHeader(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- pointer to the header's ID
*           =   0,1,8   - PostScript header for normal job
*           =   4       - Already downloaded header check
*
*       LP lpOutData -- pointer to the dictionary name where this procset is
*  returns:
*       1 => supported
*       0 => invalid hDC or out of order call
************************************************************************/

SHORT FAR PASCAL ESCDownLoadHeader(LPPDEVICE lppd,LP lpInData,LP lpOutData)
{
    WORD    wHeaderID;

    wHeaderID = 1;

    if(lpOutData)
    {
        LoadDrvrString(ghDriverMod, PSFRAG_OC, (LPSTR) lpOutData, 32);
    }

    if(lpInData)
    {
        wHeaderID = *((LPWORD)lpInData);
    }

    return(CDownLoadHeader(lppd, wHeaderID));
}

/***********************************************************************
*                       ESCResetPage
*  function:
*       Invalidates all pens, brushes, fonts
*
*       May be called after StartDoc and in place of EndDoc.
*       Never disabled.
*       Causes no transition.
*
*  prototype:
*       SHORT FAR PASCAL ESCResetPage(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- not used
*       LP lpOutData -- not used
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCResetPage(LPPDEVICE lppd,LP lpInData,LP lpOutData)
{
    SHORT sRC;

    sRC=1;    //success

    if (!fInDocLppd(lppd))
    {
        sRC = SP_ERROR; // failure -- we can't be called in this state.
    }
    else
    {
        lppd->job.bfESCResetPage = TRUE;   // Fix bug 120847. jjia. 10/30/95
        CInitPen(lppd);
        CInitBrush(lppd);
        InitFontDataList(lppd);
        TInitGraphicState(lppd);
        ResetPatternCache(lppd);
        lppd->job.bfESCResetPage = FALSE;
    } // if (fInDoc...)

    return(sRC);
}




/***********************************************************************
*                       ESCNewFrame
*  function:
*       causes the current page, if any, to be closed and printed, then
*       then sets the state machine to await the start of the
*       next page.
*
*       This entry point may be called only between STARTDOC and ENDDOC.
*       It is always enabled.
*       It changes state to ST_EMPTY_PAGE.
*
*  prototype:
*       SHORT FAR PASCAL ESCNewFrame(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- not used
*       LP lpOutData -- not used
*  returns:
*       1 => supported
*       <0 => one of the Generalized Error Codes
************************************************************************/

SHORT FAR PASCAL ESCNewFrame(LPPDEVICE lppd,LP lpInData,LP lpOutData)
{
   SHORT retval;

   // Check if it's illegal for us to be called here.
   if (!fInDocLppd(lppd))
   {
       retval = SP_ERROR;
   }
   else
   {   // if !fInJob(...) ... else

       // It's OK for us to be called.  Now force the state change.
       // This will eject the current page as a side effect.

       retval = 1;             // init to good return

       // Check if it is an EPS job. If so, check current page number. If second,
       // page, throw up a MessageBox telling the user he is attempting to create
       // a multi-page EPS file. Create a valid 1-page EPS file and end the job.

       if ( lppd->lpPSExtDevmode->dm2.bOutputDialect == DIALECT_EPS)
       {
           if (lppd->lpProcsetstuff->currpagenumber == 2)
           {
               char strBuff[160];
               // char strBuff1[16];
               LoadDrvrString(ghDriverMod, DLGS_szEPSWarning2, strBuff, sizeof(strBuff));

               // Fix bug 194796. jjia   2/18/97
               // Warning Dialog box will behind the app's window if we use MessageBox.
               // LoadDrvrString(ghDriverMod, ADDPRN_szWarning, strBuff1, sizeof(strBuff1));
               // MessageBox(NULL, strBuff, strBuff1, MB_OK | MB_ICONEXCLAMATION);
               DialogBoxParam(ghDriverMod, MAKEINTRESOURCE(CH_LOSESOFTFONTS_DLG),
                                GetActiveWindow(),
                                LoseSoftFontsProc,
                                (LPARAM)(LPSTR)strBuff);

               if (stCurrentLppd(lppd) != ST_EMPTY_PAGE)
                  if (!fChangeStateLppdSt(lppd, ST_EMPTY_PAGE))
                  {
                      retval = SP_ERROR;
                  }
               retval = ESCEndDoc(lppd, lpInData, lpOutData);

               if (retval > NULL)
                  retval = SP_USERABORT;     // pretend the User aborted the job...

               return(retval);               // end the job
           }  // if (currpage == 2)..
       }     // if EPS job ...


       // If current page is empty, to eject it, we must first go to ST_MARKED_PAGE
       if (stCurrentLppd(lppd) == ST_EMPTY_PAGE) {
           if (!fChangeStateLppdSt(lppd, ST_MARKED_PAGE))
               return SP_ERROR;
       }

       if (!fChangeStateLppdSt(lppd, ST_EMPTY_PAGE))
           retval = SP_ERROR;

   }   // if !fInJob(...) ... else ...

   return(retval);
}

/***********************************************************************
*                       ESCSetColorTable
*  function:
*       sets an item in the color table for the device.  Not supported
*
*       May be called anytime from ST_ENABLED to ST_JOB_DONE.
*       Never disabled.  Never changes state.
*
*  prototype:
*       SHORT FAR PASCAL ESCSetColorTable(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- not used
*       LP lpOutData -- not used
*  returns:
*       1 => supported
*       0 => not supported
************************************************************************/

SHORT FAR PASCAL ESCSetColorTable(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
          {

          // if (stCurrentLppd(lppd) == ST_ENDED)
          //     {
          //     return(0);   // Not legal to be called here
          //     }
          // else
          //     {
          //     // Legal to be called.
          //
          //     // Change GSTATE here.
          //
          //     if (fInJobLppd(lppd))
          //         {
          //         // Send token(s) here.
          //         }
          //     }

          return(0);
          }

/***********************************************************************
*                       ESCQueryEscSupport
*  function:
*       returns 1 if the Escape function is supported -- 0 if not
*
*       May be called anytime the driver is enabled.
*       Never causes a state transition.  Never disabled.
*
*  prototype:
*       SHORT FAR PASCAL ESCQueryEscSupport(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- pointer to the escape index
*       LP lpOutData -- not used
*  returns:
*       1 => supported
*       0 => not supported
************************************************************************/

SHORT FAR PASCAL ESCQueryEscSupport(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
   SHORT sRC;
   WORD wEscNum, version, obsoleteEscapesRC;
   HTASK  hTask ;


   hTask = GetCurrentTask();
   version = (WORD)GetExpWinVer(hTask);
   obsoleteEscapesRC = (version >= 0x0400) ? 0 : 1 ;

   //  all obsolete escapes should return obsoleteEscapesRC
   //  instead of a hardcoded 1 or 0.


   // Control() called fEnableLppd and made sure it's legal to call us.

   wEscNum=*(LPWORD)lpInData;
   sRC=0;

   switch(wEscNum)
   {
      case NEWFRAME:
               sRC = 1;
               break;
      case ABORTDOC:
               sRC = 1;
               break;
      case NEXTBAND:
               sRC = 1;
               break;
      case SETCOLORTABLE:
               sRC = 0;
               break;
      case GETCOLORTABLE:
               sRC = 0;
               break;
      case FLUSHOUTPUT:
               sRC = 1;
               break;
      case DRAFTMODE:
               sRC = 0;
               break;
      case QUERYESCSUPPORT:
               sRC = 1;
               break;
      case SETABORTPROC:
               sRC = 1;
               break;
      case STARTDOC:
               sRC = 1;
               break;
      case ENDDOC:
               sRC = 1;
               break;
      case GETPHYSPAGESIZE:
               sRC = 1;
               break;
      case GETPRINTINGOFFSET:
               sRC = 1;
               break;
      case GETSCALINGFACTOR:
               sRC = 1;
               break;
      case SETCOPYCOUNT:
               sRC = 1;
               break;
      case SELECTPAPERSOURCE:
               sRC = 0;
               break;
      case PASSTHROUGH:
               sRC = 1;
               break;
      case GETTECHNOLOGY:
               sRC = 1;
               break;
      case SETLINECAP:
               sRC = 1;
               break;
      case SETLINEJOIN:
               sRC = 1;
               break;
      case SETMITERLIMIT:
               sRC = 1;
               break;
      case BANDINFO:
               sRC = 0;
               break;
      case DRAWPATTERNRECT:
               sRC = 0;
               break;
      case GETVECTORPENSIZE:
               sRC = 0;
               break;
      case GETVECTORBRUSHSIZE:
               sRC = 0;
               break;
      case ENABLEDUPLEX:
               sRC = 1;
               break;
      case GETSETPAPERBINS:  // new !
               sRC = 1;
               break;
      case GETSETPAPERORIENTATION: // new !
               sRC = 1;
               break;
      case ENUMPAPERBINS:  // new !
               sRC = 1;
               break;
      case SETDIBSCALING:
               sRC = 1;
               break;
      case EPSPRINTING:
               sRC = 1;
               break;
      case ENUMPAPERMETRICS:  // new !
               sRC = 1;
               break;
      case GETSETPAPERMETRICS:
               sRC = 0;
               break;
      case GETVERSION:
               sRC = 0;
               break;
      case GETSETSCREENPARAMS:
               sRC = 1;
               break;
      case QUERYDIBSUPPORT:
               sRC = 1;
               break;
      case POSTSCRIPTDATA:
               sRC = 1;
               break;
      case POSTSCRIPTIGNORE:
               sRC = 1;
               break;
      case GETEXTENDEDTEXTMETRICS:
               sRC = 1;
               break;
      case GETEXTENTTABLE:
               sRC = 0;
               break;
      case GETPAIRKERNTABLE:
               sRC = 1;
               break;
      case RESETDC:
               sRC = 1;
               break;
      case GETTRACKKERNTABLE:
               sRC = 0;
               break;
      case EXTEXTOUT:
               sRC = 0;
               break;
      case GETFACENAME:
               sRC = 1;
               break;
      case DOWNLOADFACE:
               sRC = 1;
               break;
      case ENABLERELATIVEWIDTHS:
               sRC = 0;
               break;
      case ENABLEPAIRKERNING:
               sRC = 1;
               break;
      case SETKERNTRACK:
               sRC = 1;
               break;
      case SETALLJUSTVALUES:
               sRC = 1;
               break;
      case SETCHARSET:
               sRC = 1;
               break;
      case BEGINPATH:
               sRC = 1;
               break;
      case CLIPTOPATH:
               sRC = 1;
               break;
      case ENDPATH:
               sRC = 1;
               break;
      case EXTDEVICECAPS:
               sRC = 1;
               break;
      case RESTORECTM:     // new !
               sRC = 1;    /* Commented out in ESCRestoreCTM */
               break;
      case SAVECTM:        // new !
               sRC = 1;    /* Commented out in ESCSaveCTM */
               break;
      case SETARCDIRECTION:
               sRC = 1;
               break;
      case SETBACKGROUNDCOLOR:
               sRC = 0;    /* Commented out in ESCSetBackgroundColor */
               break;
      case SETPOLYMODE:
               sRC = 1;
               break;
      case SETSCREENANGLE:
               sRC = 1;
               break;
      case SETSPREAD:
               sRC = 1;
               break;
      case TRANSFORMCTM:  // new !
               sRC = 1;    /* Commented out in ESCTransformCTM */
               break;
      case SETCLIPBOX:
               sRC = 1;
               break;
      case SETBOUNDS:
               sRC = 1;
               break;
      case ATMINFO:
               sRC = 1;
               break;
/************ Microsoft/Aldus add-ons **************************************/
      case OPENCHANNEL:
               sRC = 1;
               break;
      case DOWNLOADHEADER:
               sRC = 1;
               break;
      case CLOSECHANNEL:
               sRC = 1;
               break;
      case SETGDIXFORM:
               sRC = 1;
               break;
      case RESETPAGE:
               sRC = 1;
               break;
      case POSTSCRIPT_PASSTHROUGH:
               sRC = 1;
               break;
// Special PassThrough. Added 5-1-95
      case SPCLPASSTHROUGH:   // kept for AdobePS 3.01's backward compatible
      case SPCLPASSTHROUGH2:  // id for query Callable for multiple times, added 11-27-95
               sRC = 1;
               break;
// Bravo-PS Injection point
#ifndef MICROSOFT_DRIVER_VERSION
      case SPCLPSINJECTION:   // for application PostScript injection support.
               sRC = 1;
               break;

      case DOWNLOADFACESTR:  // id for Incremental Escape(DOWNLOADFACE), added 11-27-95
               sRC = 1;
               break;
#endif

/***************************************************************************/
      default:
               sRC = 0;        // not implemented
               break;
   }

   return(sRC);
}

/***********************************************************************
*                       ESCSetAbortProc
*  function:
*       stores the applications program's hDC for passing to GDI at
*       OPEN_JOB.  If StartTranslation has already occured, this function
*       is out of order and causes an error.
*
*       May be called during ST_ENABLED only.  Never disabled.
*       Does not cause a state change.
*
*  prototype:
*       SHORT FAR PASCAL ESCSetAbortProc(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- pointer to applications program's hDC
*       LP lpOutData -- not used
*  returns:
*       1 => supported
*       -1 => invalid hDC or out of order call
************************************************************************/

SHORT FAR PASCAL ESCSetAbortProc(LPPDEVICE lppd,LP lpInData,LP lpOutData)
          {
          //If the job was canceled and we didn't get an ABORTDOC
          //call it ourselves
          /*
           * This should not be done, as per Chicago spec, because
           * GDI will call this before and after ResetDC (after StartDoc
           * obviously). So just store the hdc always - Bug #12275 - Srini
           */
#if 0
          if (stCurrentLppd(lppd) == ST_JOB_STARTED)
          {
            ESCAbortDoc(lppd, NULL, NULL);
          }

          if (stCurrentLppd(lppd) != ST_ENABLED)
                    retval = -1;
          else
                    {
                    lppd->hdc=*((LPHDC)lpInData);

                    if(lppd->hdc == NULL)
                              retval = -1;
                    else
                              retval = 1;
                    }
#endif
          lppd->hdc = *((LPHDC)lpInData);

          return(1);
          }


/***********************************************************************
*                       ESCStartDoc
*  function:
*       initializes the translation process
*
*       May be called only in state ST_ENABLED.  Never disabled.
*       Causes state transition to ST_JOB_STARTED.
*
*  prototype:
*       SHORT FAR PASCAL ESCStartDoc(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- pointer to string containing the job title
*       LP lpOutData -- not used
* The calling sequence maybe:
*     0 -- Normal app or as old ways;
*     1,2 -- New way - 1 is used for StartTranslation without open port.
*                    - 2 is for StartTrans with OpenPort and call CDocBegin().
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCStartDoc(LPPDEVICE lppd,LP lpInData,LP lpOutData)
{
    char strBuff[144];
    int retval;
    SHORT sRC;
    BOOL flag;
    LPDOCINFO lpDocInfo;
    /* lppd->SmsStartDoc remembers how the startdoc is called:
       NORMAL_SD - normal start
       FIRST_SD  - Start without start CDocBegin()
       SECOND_SD - Start with CDocBegin() only.
     */

    int flagtoOEM;

    sRC=1;    //success
    if (lppd->SmsStartDoc==FIRST_SD) lppd->bCopyToSpecial=TRUE; // from here, all data goto special Buffer
    else lppd->bCopyToSpecial=FALSE; // from here, all data goto real port.

    lpDocInfo = (LPDOCINFO)lpOutData;

    //If the job was canceled and we didn't get an ABORTDOC
    //call it ourselves

    // do these check only for all startDoc calls:
     if (stCurrentLppd(lppd) == ST_JOB_STARTED)
         ESCAbortDoc(lppd, NULL, NULL);
     if (stCurrentLppd(lppd) != ST_ENABLED)
     {
         sRC = SP_ERROR; // failure -- can't call us in this state.
     }

    if (sRC != SP_ERROR)
    { // Do this part no matter what lppd->SmsStartDoc is.

         // Remember the current number of copies which can be different
         // for each page. When the current #copies for the page is different
         // from the current #copies, send the setup code for #copies.
         lppd->iCurrentCopies = lppd->lpPSExtDevmode->dm.dm.dmCopies;
         lppd->iDefaultCopies = lppd->lpPSExtDevmode->dm.dm.dmCopies;
         lppd->job.bfIsFirstNextBand = 1;     // Fix bug 117832 8/3/95 jjia
         if(lpDocInfo  && (lpDocInfo->cbSize == sizeof(DOCINFO)) &&
               lpDocInfo->lpszDatatype &&
               lpDocInfo->lpszDatatype[0])
         {
            if( !lstrcmp(lpDocInfo->lpszDatatype, DATATYPE_EPS) )
            {
               lppd->lpPSExtDevmode->dm.enumDialect = DIA_EPS;

               lppd->lpPSExtDevmode->dm2.bOutputDialect = (BYTE) DIALECT_EPS;
               lppd->lpPSExtDevmode->dm2.bPJL_Protocol = FALSE;
               lppd->lpPSExtDevmode->dm2.bDSC = TRUE;
               lppd->lpPSExtDevmode->dm2.bVM_Tracking = FALSE;
            }
         }

         if((lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS) ||
            (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
            (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE))
         {
            // If EPS or ARCHIVE or PJL ARCHIVE, force it to ASCII format.
            lppd->lpPSExtDevmode->dm2.iDataOutputFormat = PROTOCOL_ASCII;
         }

        // check for job title - first in DOCINFO,
        // then in lpInData. If not found - create a fake one
        if ( lpDocInfo &&
             lpDocInfo->lpszDocName &&
             lpDocInfo->lpszDocName[0] )
        {
            lstrcpyn((LPSTR)lppd->szTitle,lpDocInfo->lpszDocName,
                                sizeof(lppd->szTitle));
        }
        else if( lpInData &&
        //*******************************************************
            ( LOWORD(lpInData) != 0xFFFF ) &&  // Fix for bug in MSCB
        //*******************************************************
            lpInData[0] )
        {
            lstrcpyn((LPSTR)lppd->szTitle,(LPSTR)lpInData,
                                    sizeof(lppd->szTitle) );
            // lstrcpyn() truncates and appends NULL, if srclen > dstlen
        }
        else
        {
            // generate a dummy job title
            LoadString(ghDriverMod,ID_STR_Untitiled,lppd->szTitle,
                sizeof(lppd->szTitle));
        }

        if (lpDocInfo && lpDocInfo->lpszOutput)
            lstrcpyn(lppd->szSDOutput, (LPSTR)lpDocInfo->lpszOutput, sizeof(lppd->szSDOutput)-2);
        else
            lstrcpyn(lppd->szSDOutput, (LPSTR)lppd->szPortName, sizeof(lppd->szSDOutput)-2);
    }

        // check if output format is EPS. If so, port should be FILE:
        // if not, throw up a MessageBox and let user
        //  continue with buggy EPS file (or) let user ABORT the job
    if (sRC != SP_ERROR && lppd->SmsStartDoc!=FIRST_SD)
    { // Do this part Only ONCE - lppd->SmsStartDoc is NORMAL or 2nd

        if (lppd->lpPSExtDevmode->dm2.bOutputDialect == DIALECT_EPS)
        {
            if (!IsFilePort(lppd->szSDOutput))
            {
                LoadDrvrString(ghDriverMod, DLGS_szEPSWarning1, strBuff, sizeof(strBuff));
                retval = MessageBox(NULL, strBuff, NULL, MB_YESNO | MB_ICONSTOP);
                if (retval == IDNO)
                    return(SP_USERABORT);
            }
        }
    }  // end !=FIRST_SD

    if (sRC != SP_ERROR)
       { // Do this part no matter what lppd->SmsStartDoc is. OEMStartDoc() is called several times

#ifdef ADOBE_DRIVER
        if (sRC > 0)
        {
            char szSection[BUF_SIZE];

                                    /****************************************/
                                    /* flag to disable streamer             */
                                    /*                                      */
                                    /* In [Postscript,port] sect of win.ini */
                                    /* 0 streamer off, 1 on, 2 ask each job */
                                    /****************************************/

            LoadString(ghDriverMod, IDS_POSTSCRIPT, szSection, BUF_SIZE);
            lstrcat((LPSTR) szSection, lppd->szPortName);
            if (lppd->szPortName[lstrlen(lppd->szPortName) - 1] == ':')
                szSection[lstrlen(szSection) - 1] = '\0';

            lppd->job.bfType1Incr = GetProfileInt(szSection, "Type1Incremental", 1);

        }
#endif
        if (sRC > 0)
        {

            /****************************************/
            /* OEMPLUGI hook to StartDoc            */
            /****************************************/

             // PREMINHEADER  : Minheader with lppd->SmsStartDoc=First
             // MINHEADERJOB  : Minheader with lppd->SmsStartDoc=Normal or second
             // PRESTARTDOC   : GDI App with lppd->SmsStartDoc=First
             // STARTDOCJOB   : GDI App with lppd->SmsStartDoc=normal or second
            if (fIsMinHeaderLppd(lppd)){
                if (lppd->SmsStartDoc==FIRST_SD) flagtoOEM = PREMINHEADER;
                else flagtoOEM = MINHEADERJOB;
               }
            else{
                if (lppd->SmsStartDoc==FIRST_SD) flagtoOEM = PRESTARTDOC;
                else flagtoOEM = STARTDOCJOB;
            }
            sRC = CallOEMStartDocStub(lppd, flagtoOEM);
             if (sRC > 0)
               ResyncOutputFormat(lppd);
        }

        if ( (sRC == SP_ERROR) ||
             (sRC == SP_APPABORT) ||
             (sRC == SP_USERABORT)
           )
        {

            // OEMPLUGI begin
            EndOEM(lppd);
            // OEMPLUGI end

            return (sRC);
        }
      }
// put UFL init here for now.  It should be done once per driver init.
    BInitUFL(lppd);

    if (sRC != SP_ERROR && lppd->SmsStartDoc!=FIRST_SD)
      { // Change state only once (lppd->SmsStartDoc is Normal or 2nd).

        flag = fChangeStateLppdSt( lppd, ST_JOB_STARTED );

#ifdef ADOBE_DRIVER
//    if (fIsMinHeaderLppd(lppd))
// Some Normal Apps may be on Incompatible List:
    {
       if (!GetWM_NUP_Confirmation(lppd))
       {
          lppd->stCurrent = ST_ENABLED;
          ESCAbortDoc(lppd, NULL, NULL);
          return(SP_USERABORT);
       }
    }
#endif

    }

    if (sRC !=SP_ERROR){
       if (lppd->SmsStartDoc==SECOND_SD){
         // We use lppd->SmsStartDoc==2nd call this funciton only once !!!!!
         // in this case, free the trans stuff
         EndTranslation(lppd);
         // after the statetransition is done set it back to the same as normal app
         lppd->SmsStartDoc = NORMAL_SD;
         }

        //Start the translation process. In a two-pass implementation this
        // call will be moved to ESCEndDoc().
        retval = (int)StartTranslation(lppd, lpDocInfo);
        if (retval == RC_userabort)
        {
            return (SP_USERABORT);
        }
        else if (retval == RC_fail)
            return -1;

        //Provide translation layer with a snapshot of control layer's state.
        CDriverData(lppd);
    }


    if (sRC != SP_ERROR && lppd->SmsStartDoc!=FIRST_SD) {
            // real startdoc. Normal or 2nd call
        flag = flag && CDocumentBegin(lppd);
        if(flag != TRUE)
            sRC=SP_ERROR;
     }

    return(sRC);
}

/***********************************************************************
*                       ESCAbortDoc
*  function:
*       aborts the printing process for this job
*
*       May be called after StartDoc and in place of EndDoc.
*       Never disabled.  Causes transition to state JOB_DONE, then
*       state ENDED.
*
*  prototype:
*       SHORT FAR PASCAL ESCAbortDoc(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- not used
*       LP lpOutData -- not used
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCAbortDoc(LPPDEVICE lppd,LP lpInData,LP lpOutData)
{
    SHORT sRC;
    HTASK hCurrentTask;

    sRC=1;    //success

    if (!fInDocLppd(lppd))
    {
        sRC = SP_ERROR; // failure -- we can't be called in this state.
    }
    else
    {
        if (lppd->sMagic == LUCAS)
        {

            // OEMPLUGI begin
            if (lppd->hDrvInfo)
            {
                if (lppd->hOemCust)
                {
                    AdobeOEMAbortDocStub(lppd->hOemCust);
                }
#ifdef Adobe_Driver
                if (lppd->hPSFax)
                {
                    AdobeOEMAbortDocStub(lppd->hPSFax);
                }
                if (lppd->hWebPrinter)
                {
                    AdobeOEMAbortDocStub(lppd->hWebPrinter);
                }
#endif
            }
            // OEMPLUGI end


        // Delete the job so that the spooler can take appropriate action
       if (lppd->hPortHandle)
       {
            AdobeOEMDeleteJobStub(lppd, 0);
            lppd->hPortHandle = 0;    // so that future calls to output data will fail.
            lppd->wSpoolError = 0;    // Should not return failure due to a previous error.
       }
        // Now continue with normal processing so that the internal state machine
        // can clean itself up. Any data it tries to output will not be sent out because
        // port handle is NULL.

            // Move state machine to ST_EMPTY_PAGE.  This tidies up
            // any outstanding raw data, and ejects the current page.

            if (!fChangeStateLppdSt(lppd, ST_EMPTY_PAGE))
            {
                sRC = SP_ERROR;
            }

            CDocumentAbort(lppd);

            if (!fChangeStateLppdSt(lppd, ST_JOB_DONE))
            {
                sRC = SP_ERROR;
            }
            EndTranslation(lppd);

            // OEMPLUGI begin
            EndOEM(lppd);
            // OEMPLUGI end

            // Now move state machine to ST_ENABLED.  This terminates the
            // token stream.
            if (!fChangeStateLppdSt(lppd, ST_ENABLED))
            {
                sRC = SP_ERROR;
            }
        }
    }
    hCurrentTask = GetCurrentTask();
//    Ps_ClearPortBufferItem(hCurrentTask);
    return(sRC);
}

/***********************************************************************
*                       ESCFlushOutput
*  function:
*       flushes any output in the devices buffers.
*
*       May be called any time between StartDoc and EndDoc.
*       Never changes state.  Never is disabled.
*
*  prototype:
*       SHORT FAR PASCAL ESCFlushOutput(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- not used
*       LP lpOutData -- not used
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCFlushOutput(LPPDEVICE lppd,LP lpInData,LP lpOutData)
          {
          SHORT sRC;

          if (!fInDocLppd(lppd))
               {
               //  sRC = SP_ERROR;     //failure -- can't call us here.
                  sRC = 1 ;  // don't fail or ToolBook will vomit.
               }
          else
               {
               sRC=1;    //success
               if (lppd->sMagic == LUCAS)
                    {
                    sRC = CDocumentFlush(lppd);
                    }
               }
          return(sRC);
          }

/***********************************************************************
*                       ESCEndDoc
*  function:
*       ends the printing process for this job
*
*       May be called after StartDoc and in place of EndDoc.
*       Never disabled.  Causes transition to state JOB_DONE, then
*       state ENDED.
*
*  prototype:
*       SHORT FAR PASCAL ESCEndDoc(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- not used
*       LP lpOutData -- not used
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCEndDoc(LPPDEVICE lppd,LP lpInData,LP lpOutData)
{
    SHORT sRC;
    HTASK hCurrentTask;
    PSERROR rc;


    sRC=1;    //success
    if (!fInDocLppd(lppd))
    {
        sRC = SP_ERROR; // failure -- we can't be called in this state.
    }
    else
    {
        if (lppd->sMagic == LUCAS)
        {
           CHAR      lpzPort[MAX_PORT_NAME];   // Port name
           HDC       tempDC;
           LPPSEXTDEVMODE tmplpPSExtDevmode;   // pointer to Extended Devmode structure
           LPWPXBLOCKS tmplpWPXblock;       // pointer to wpx (PPD data)

            // Move state machine to ST_JOB_DONE.  This tidies up
            // any outstanding raw data, and ejects the current page.

            if (!fChangeStateLppdSt(lppd, ST_JOB_DONE))
            {
                sRC = SP_ERROR;
            }

            CDocumentEnd(lppd);  // do all the PSinsertion before OEM EndDoc

           /* OEMPLUGI begin */
           sRC = CallOEMEndDocStub(lppd);
           /* OEMCust end */

            EndTranslation(lppd);


            /* OEMPLUGI begin */
            EndOEM(lppd);
            /* OEMCust end */


           lstrcpy(lpzPort , lppd->szPortName);
           tempDC = lppd->hdc;
           tmplpPSExtDevmode = lppd->lpPSExtDevmode ;
           tmplpWPXblock = lppd->lpWPXblock ;

//Terminate UFL  should be done ones.  Init is in EscStartDoc
           BTermUFL(lppd);
           FreePDeviceBufs(lppd);  // undoes buffers created by initPDevice()

           rc = InitPDevice(lppd) ; // Finally  reinit PD
           if (PS_ERROR(rc))
           {
               FreePDeviceBufs(lppd);
               sRC = SP_ERROR;
               goto EndESCEndDoc;
           }
           lstrcpy(lppd->szPortName, lpzPort);
           lppd->hdc = tempDC;

           // Create ExtDevmode structure for lppd
           lppd->lpPSExtDevmode = tmplpPSExtDevmode ;

           lppd->lpWPXblock = tmplpWPXblock ;
           DrvStateRead(lppd, lppd->lpPSExtDevmode ) ;

           if (!fChangeStateLppdSt(lppd, ST_ENABLED))
             sRC = SP_ERROR;
       }
    } // if (fInDoc...)
    hCurrentTask = GetCurrentTask();
//    Ps_ClearPortBufferItem(hCurrentTask);

EndESCEndDoc:
    return(sRC);
}


/***********************************************************************
*                       ESCNextBand
*  function:
*       returns the next band rectangle.  In our case, that is the whole
*       page.  We must support this escape, since sometimes apps call
*       us without doing a QueryESCSupport first.
*
*       If ESCNextBand is called on a page with marks, then it ejects
*       the page and returns a RECT structure filled with zeros.  If
*       it is called on an empty page, it returns the size of the next
*       band rectangle, the whole page.  Two consecutive calls to
*       ESCNextBand should eject a blank page.  To implement this, we
*       have ESCNextBand set the state machine to ST_MARKED_PAGE when
*       it is called on ST_JOB_STARTED or ST_EMPTY_PAGE.
*
*       May be called anytime between STARTDOC and ENDDOC.
*       Causes state to change.  Never disabled.
*
*  prototype:
*       SHORT FAR PASCAL ESCNextBand(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- LPPOINT -- specifies the scaling shift count, not used
*       LP lpOutData -- LPRECT -- coordinates of next band (the whole
*                       page for us
*  returns:
*       >0 => success
*       <0 => error
************************************************************************/

SHORT FAR PASCAL ESCNextBand(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
   LPPDEVICE lppd;
   SHORT retval;

   lppd=(LPPDEVICE)lpDevice;

   /* In case the user aborted we should return the next band as an
      empty rectangle so it can get out of it. Done for Publishers
      PaintBrush. -jmk */
   if (lppd->hPortHandle == SP_USERABORT)
     {
     SetRectEmpty((LPRECT)lpOutData);
     return (SP_USERABORT);
     }

   if (!fInDocLppd(lppd) || (lppd->sMagic != LUCAS))
       retval = SP_ERROR;
   else
   {
       retval = 1;

       // Check if it is an EPS job. If so, check current page number. If second,
       // page, throw up a MessageBox telling the user he is attempting to create
       // a multi-page EPS file. Create a valid 1-page EPS file and end the job.

       if ( lppd->lpPSExtDevmode->dm2.bOutputDialect == DIALECT_EPS)
       {
           if (lppd->lpProcsetstuff->currpagenumber == 2)
           {
               char strBuff[128];
//               char strBuff1[16];
               LoadDrvrString(ghDriverMod, DLGS_szEPSWarning2, strBuff, sizeof(strBuff));
//               LoadDrvrString(ghDriverMod, ADDPRN_szWarning, strBuff1, sizeof(strBuff1));
               MessageBox(NULL, strBuff, NULL, MB_OK | MB_ICONSTOP);

               if (stCurrentLppd(lppd) != ST_EMPTY_PAGE)
                  if (!fChangeStateLppdSt(lppd, ST_EMPTY_PAGE))
                  {
                      retval = SP_ERROR;
                  }
               retval = ESCEndDoc(lpDevice, lpInData, lpOutData);

               if (retval > NULL)
                  retval = SP_USERABORT;     // pretend the User aborted the job...

               return(retval);               // end the job
           }  // if (currpage == 2)..
       }     // if EPS job ...

       if (   (stCurrentLppd(lppd) == ST_JOB_STARTED)
           || (stCurrentLppd(lppd) == ST_EMPTY_PAGE )
           || (lppd->job.bfIsFirstNextBand == 1) )
       {
           lppd->job.bfIsFirstNextBand = 0;
           if (!fChangeStateLppdSt(lppd, ST_MARKED_PAGE))
               retval = SP_ERROR;

           ((LPRECT)lpOutData)->top = 0;
           ((LPRECT)lpOutData)->left = 0;
           ((LPRECT)lpOutData)->bottom = lppd->ptPaperDim.y;
           ((LPRECT)lpOutData)->right = lppd->ptPaperDim.x;
       }
       else
       {
           // they wanted a new band, we'll give them
           // the whole next page and return a Band size = 0

           if (!fChangeStateLppdSt(lppd, ST_EMPTY_PAGE))
               retval = SP_ERROR;

           SetRectEmpty((LPRECT)lpOutData);
       }

   }  // if !fInDoc.... else ...

   return(retval);
}


/***********************************************************************
*                       ESCGetPhysPageSize
*  function:
*       returns the physical page size in device coordinates.
*
*       May be called anytime driver is enabled.  Never disabled.
*       Never changes driver state.
*
*  prototype:
*       SHORT FAR PASCAL ESCGetPhysPageSize(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- not used
*       LP lpOutData -- pointer to a POINT data structure
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCGetPhysPageSize(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
          {
          LPPDEVICE lppd;
          LPPOINT lpPt;
          SHORT retval;

          lppd=(LPPDEVICE)lpDevice;
          retval = 4;     // Number of bytes to keep info

          if (lppd->sMagic != LUCAS)
               retval = -1;
          else if ( lpOutData )
          {
             lpPt=(LPPOINT)lpOutData;

             lpPt->x=lppd->ptPaperDim.x;
             lpPt->y=lppd->ptPaperDim.y;
          }

          return(retval);
          }

/***********************************************************************
*                       ESCGetPrintingOffset
*  function:
*       Returns the offset from the corner of the paper that the GDI
*       coordinate system origin is located. Units are in pixels.
*       Consider the figure below:
*
*
*       |--------------------------------------------------------|
*       |                                                        |
*       |    |------------------------------------------------|  |
*       |    ||--->x1                                 y2<---| |  |
*       |    ||                                             | |  |
*       |    |v                                             v |  |
*       |    |y1                                            x2|  |
*       |    |                                                |  |
*       |    |                                                |  |
*       |    |                                                |  |
*       |    |                                                |  |
*       |    |                                                |  |
*       |    |                                                |  |
*       |    |                                                |  |
*       |    |                                                |  |
*       |    |                                                |  |
*       |    |                                                |  |
*       |    |                                              y3|  |
*       |    |                                                |  |
*       |    |                                               ^|  |
*       |    |                                               ||  |
*       |    |                                               ||  |
*       |    |                                        x3<-----|  |
*       |    |------------------------------------------------|  |
*       |^y0                                                     |
*       ||                                                       |
*       ||___>x0                                                 |
*       |--------------------------------------------------------|
*
*       (x0,y0) is the PostScript origin.
*       (x1,y1) is the GDI origin when printing in portrait mode.
*       (x2,y2) is the GDI origin when printing in landscape mode.
*       (x3,y3) is the GDI origin when printing in Rotate landscape mode.
*
*   The outer rectangle represents the physical sheet of paper.
*   The inner rectangle represents the imageable area of the paper.
*   The PostScript origin is actually at the edge of the physical paper.
*   Similarly, the GDI origins line up with the edge of the imageable area.
*
*       May be called anytime driver is enabled.  Never disabled.
*       Never changes driver state.
*
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- not used
*       LP lpOutData -- pointer to a POINT data structure
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCGetPrintingOffset(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
   LPPOINT lpPt;
   LPPDEVICE lppd;

   lppd = (LPPDEVICE) lpDevice ;
   lpPt = (LPPOINT) lpOutData ;

     if( lpPt)
     {
          lpPt->x = lppd->imageRect.left;
          lpPt->y = lppd->imageRect.top;
     }

     return(4);

}

/***********************************************************************
*                       ESCGetScalingFactor
*  function:
*       returns the scaling factor for bitmaps.  The MS driver returns
*       0,0 -- so will we.
*
*       May be called anytime driver is enabled.  Never disabled.
*       Never changes driver state.
*
*  prototype:
*       SHORT FAR PASCAL ESCGetScalingFactor(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- not used
*       LP lpOutData -- pointer to a POINT data structure
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCGetScalingFactor(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
          {
          LPPDEVICE lppd;
          LPPOINT lpPt;
          SHORT retval;

          retval = 4;

          lppd=(LPPDEVICE)lpDevice;
          if (lppd->sMagic != LUCAS)
                    retval = -1;
          else if( lpOutData )
          {
             lpPt=(LPPOINT)lpOutData;

             lpPt->x = 0;
             lpPt->y = 0;
          }

          return(retval);
          }

/***********************************************************************
*                       ESCSetCopyCount
*  function:
*       sets the copy count.  If not in a document, set the value in
*       PDEVICE, else set the value in PDEVICE AND send a token.
*
*       May be called anytime before ENDDOC.  Never disabled.
*       Never causes change in state.
*
*  prototype:
*       SHORT FAR PASCAL ESCSetCopyCount(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- pointer to SHORT, requested copies
*       LP lpOutData -- pointer to SHORT, actual copies
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCSetCopyCount(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
   LPPDEVICE lppd;
   SHORT sNumCopies ;
   SHORT retval;

   lppd=(LPPDEVICE)lpDevice;
   if (lppd->sMagic != LUCAS)
      retval = 0;
   else
   {
      sNumCopies=*((LPSHORT)lpInData);

      if (sNumCopies < MIN_COPIES)
         sNumCopies = MIN_COPIES ;
      else if (sNumCopies > MAX_COPIES)
         sNumCopies = MAX_COPIES ;

      *((LPSHORT)lpOutData)=sNumCopies;//Report actual # copies.

      retval = 1;

      // Fix for bug 117832 with Persuasion 3.0 - ShyamV - 08/22/95.
      if (stCurrentLppd(lppd) == ST_RAW_DATA)
      {
         // We are in PassThrough mode. Doing a SetCopyCount might blow off
         // imaging done in the passthrough call.

         *((LPSHORT)lpOutData)=0;      // tell App. copy count was not set.
         lppd->job.bfCopyCountSent = TRUE;
         return(retval);
      } // end fix for 117832

      if (fInDocLppd(lppd) && lppd->job.bfCopyCountSent == FALSE)
      {
         // Workaround for problem with nUP and WRITE first page blank.
         // WRITE issues this escape after document setup (and nUP setup) is
         // completed and the setpagedevice invoked for setting NumCopies
         // affects nUP setup. So the first page does not print.
         // If this problem becomes more widespread (more than 1 app), we can
         // think of a better workaround. Right now, this fix is solid.
         //  - ShyamV - 12/23/93
         if (lppd->lpPSExtDevmode->dm.layout == ONE_UP)
         {
            if (CJobCopies(lppd,sNumCopies) != RC_ok)
               retval = 0;
            else
               lppd->job.bfCopyCountSent = TRUE;
         }
         else
         {
            lppd->job.bfCopyCountSent = TRUE;
         }
      }
   }
   return(retval);
}

/***********************************************************************
*                       ESCPassThrough
*  function:
*       allows raw data to be passed through to the printer.  If this is
*       the 1st passthrough (i.e. bfInPassThrough == FALSE), send a
*       token for GSAVE.  Then send the data.
*
*       May be called anytime between StartDoc and EndDoc.  Never
*       disabled.  May well change driver state.
*
*  prototype:
*       SHORT FAR PASCAL ESCPassThrough(LP,LP,LP);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- pointer to passthrough struct, 1st word = size,
*                       the rest is data.
*       LP lpOutData -- not used
*  returns:
*       >0 => number of bytes sent
*       0 => error
************************************************************************/

SHORT FAR PASCAL ESCPassThrough(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
     {
     LPPDEVICE lppd;
     WORD wNumBytes;
     WORD retval;
     BOOL fDoMSRectHack = FALSE;


     lppd=(LPPDEVICE)lpDevice;
     if (lppd->sMagic != LUCAS)
          retval = 0;
     else
          {
          wNumBytes=*((LPWORD)lpInData)++;
          if (wNumBytes == 0)
               retval = 0;
          else if (!fInDocLppd(lppd))
               retval = 0;
          else
               {
// SAVE_RESTORE
#if 1
               // in a document, can send tokens
               if (DoVMTracking(lppd) &&
                  ((lppd->lpPSExtDevmode->dm.enumDialect == DIA_PORTABLE) ||
                  // fix bug 204185
                  (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
                  (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE)))
               {
                   // If it is a Win16 app that is not Windows 95 aware,
                   // disable VM tracking.
                   if ((GetProcessDword(NULL, GPD_FLAGS) &
                        GPF_WIN16_PROCESS) &&
                       (GetProcessDword(NULL, GPD_EXP_WINVER) < 0x0400))
                   {
                       lppd->VMDisabledOnPassThru = TRUE;
                   }
               }
#endif
               // send initial encapsulation
               if (!fChangeStateLppdSt(lppd, ST_RAW_DATA))
                    {
                    retval = 0;
                    }
               else
                    {
                    // The MSRectHack applies whenever PassThrough is called
                    // with a buffer whose contents match a special pattern,
                    // followed by an Output(OS_RECT).
                    // Normally this buffer is the first of a series of
                    // PassThrough calls, but when two such series occur
                    // consecutively the driver has no way of telling them
                    // apart.  Thus, it must scan each buffer.
                    // The scanner is implemented to bail out as soon as it
                    // sees the buffer doesn't trigger the hack.

                    fDoMSRectHack = bfIsMSRectHackCbPch(wNumBytes, lpInData);

                    SetDoMSRectHackLppdF(lppd, fDoMSRectHack);

                    // send the raw data token
                    if(CRawPrinterData(lppd,lpInData,wNumBytes) != RC_ok)
                         retval = 0;
                    else
                         retval = wNumBytes;

                    }  // if (!fChangeState...) ... else ...

               } // if !fInDocLppd....

          } // if sMagic != LUCAS ... else ...

     return(retval);
     }


/***********************************************************************
*                       bfIsMSRectHackCbPch
*  function:
*       Compares the contents of buffer Pch with a static pattern,
*       ignoring whitespace and ASCII digits.  If they match,
*       the MSRectHack is required; returns TRUE.  Otherwise,
*       returns FALSE.
*
*       This hack is narrowly focussed.  We want to be sure to recognise
*       the code we know about, and trivial variations of it, but we
*       don't want to falsely recognise code that is in fact different.
*       >1 whitespace characters are equivalent to one; by ignoring all
*       characters of ' ' and less, we ignore insignificant whitespace
*       variations and possibly some significant ones too.  A future
*       version could conceivably have a dict bigger than 40, but still
*       want to activate this hack; by ignoring all digits we can ignore
*       changes in the dict size.
*
*  prototype:
*       BYTEFLAG bfIsMSRectHackCbPch( unsigned int cb, LPSTR pch );
*  parameters:
*       int   cb    -- length of buffer *pch.
*       LPSTR pch   -- buffer to be compared to pattern.
*  returns:
*       TRUE  if buffer pch matches the pattern, false otherwise.
************************************************************************/

#define fIsIgnoredCh( ch )  (   ((ch) <=' ')                    \
                                    || (('0'<= (ch))&&((ch) <='9')) )

#define SkipIgnoredPchCb( pch, cb )                             \
     while ( ((cb) > 0) && fIsIgnoredCh(*pch) )                  \
          {                                                       \
          (pch)++;                                                \
          (cb)--;                                                 \
          }

BYTEFLAG bfIsMSRectHackCbPch( unsigned int cb, LPSTR pch )
     {

//The following two strings are output by epsimp.flt version 2 and
//version 3.  These are used by MSWord, PowerPoint, etc.
     static char szPattern3[] = "%MSEPS Preamble";
     static char szPattern2[] = "/pp_save save def";
//We used to have a much longer match pattern for Pattern2.  I have
//shortened them since whitespace changed between version 2 and version
//3.
     if (!CheckPattern(cb, pch, szPattern3))
       if (!CheckPattern(cb, pch, szPattern2))
          return FALSE;
     return TRUE;
}

BOOL CheckPattern(unsigned int cb, LPSTR pch, LPSTR szPattern)
{
     unsigned int cbPattern = lstrlen( szPattern );
     int f;          // return code
     DWORD  dwSize ;

     // Fast tests for failure: the buffer is impossibly small, or either
     // of the first two characters in the buffer don't match their
     // counterparts in the pattern (and aren't ignored characters).

     // This test assumes that szPattern has at least two characters,
     // and that the first two characters are non-ignored.

     if (   (cb < 2)
          || ((szPattern[0] != pch[0]) && !fIsIgnoredCh(pch[0]))
          || ((szPattern[1] != pch[1]) && !fIsIgnoredCh(pch[1]))
        )
          return( FALSE );


     // Fast test for success: the buffer exactly matches the pattern.
     dwSize = min(cb, cbPattern) ;
     f = MemComp( pch, szPattern, dwSize );
     if ((f == 0) && (cb >= cbPattern))
          // szPattern is a leading substring of pch.
          return( TRUE );     // Exact match -- this is the pattern we seek.


     // Slow (but sure) test for matching.

     // The buffer does not exactly match the pattern. Search again,
     // disregarding non-printable characters and digits.  Return as
     // soon as the result is clear.

     SkipIgnoredPchCb(pch, cb);
     SkipIgnoredPchCb(szPattern, cbPattern);

     if ((cb == 0) || (cbPattern == 0))
          return(FALSE);                  // All characters ignored. No match.

     while ((cb > 0) && (cbPattern > 0) && (*pch == *szPattern))
          {
          pch++;
          cb--;
          szPattern++;
          cbPattern--;

          SkipIgnoredPchCb(pch, cb);
          SkipIgnoredPchCb(szPattern, cbPattern);
          }

     if (cbPattern == 0)
          return(TRUE);           // Pattern completely matched.

     return(FALSE);              // Either pch was short (cb == 0), or a non-
                                        // ignored char didn't match. Either way,
                                        // the pattern wasn't matched.

}




/**********************************************************************
*                       ESCGetTechnology
*  function:
*       returns a string describing the technology of the device.  In
*       this case "PostScript".
*
*       May be called anytime the driver is enabled.  Never disabled.
*       Never changes state.
*
*  prototype:
*       SHORT FAR PASCAL ESCGetTechnologyLPPDEVICE lpDevice,LP lpInData,LP lpOutData);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- not used
*       LP lpOutData -- string containing technology type
*  returns:
*       >0 => success
*       0  => error
*  note:
*       this escape returns "PostScript", just like the MS driver
*
************************************************************************/

SHORT FAR PASCAL ESCGetTechnology(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
          LPSTR   lpz;
          int     retval;

          lpz=(LPSTR)lpOutData;
          retval = 0;

          if( lpz)
          {
               // BUGBUG -- the size here is completely bogus!
               LoadString(ghDriverMod,ID_STR_PostScript,lpz,15);

               // follow the final string with another null
               lpz[lstrlen(lpz)+1]='\0';
               // Changed from string length to 1 due to the fact that
               //   some funny app called Adobe Illustrator expects
               //   1 on return as the success.
               //   Changed  5-Mar-1993  -by-  [olegs]
               retval = 1 ;
          }

          return (retval);
}

/**********************************************************************
*                       ESCSetLineCap
*  function:
*       sets the line end cap type.
*
*       May be called any time up till ENDDOC.  May be disabled.
*       Never changes state.
*
*  prototype:
*       SHORT FAR PASCAL ESCSetLineCapLPPDEVICE lpDevice,LP lpInData,LP lpOutData);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- LPSHORT type -- -1 = default GDI,
*                                       0 = square -- no projection
*                                       1 = round
*                                       2 = square -- project .5 line width
*       LP lpOutData -- LPSHORT -- return previous line cap
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCSetLineCap(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
     {
     LPPDEVICE lppd;
     LPSHORT lpsNewCap;
     LPSHORT lpsOldCap;
     SHORT retval;

     lppd=(LPPDEVICE)lpDevice;
     if (lppd->sMagic != LUCAS)
               retval = 0;
     else
          {
          retval = 1;

          lpsNewCap=(LPSHORT)lpInData;
          lpsOldCap=(LPSHORT)lpOutData;

          if(lpsOldCap != NULL)
               *lpsOldCap=(SHORT)lppd->pen.bCap;

          if ((lpsNewCap != NULL) && !fDisableGDILppd(lppd))
               {
               switch (*lpsNewCap)
                    {
                    case -1:
                         lppd->pen.bCap = PENCAP_round;
                         break;
                    case 0:
                         lppd->pen.bCap = PENCAP_butt;
                         break;
                    case 1:
                         lppd->pen.bCap = PENCAP_round;
                         break;
                    case 2:
                         lppd->pen.bCap = PENCAP_square;
                         break;
                    default:
                         retval = -1;
                    }
               if (fInDocLppd(lppd) && (retval == 1))
                    {
                    // send a token
                    CPenCap(lppd,lppd->pen.bCap);
                    }
               }
          else
               retval = -1;
          }

     return(retval);
     }


/**********************************************************************
*                       ESCSetLineJoin
*  function:
*       sets the line join type.
*
*       May be called any time up till ENDDOC.  May be disabled.
*       Never changes state.
*
*  prototype:
*       SHORT FAR PASCAL ESCSetLineJoinLPPDEVICE lpDevice,LP lpInData,LP lpOutData);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- LPWORD type --   0 = miter
*                                       1 = round
*                                       2 = bevel
*       LP lpOutData -- LPWORD -- return previous line join
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCSetLineJoin(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
          {
          LPPDEVICE lppd;
          LPSHORT lpsNewJoin;
          LPSHORT lpsOldJoin;
          SHORT retval;

          lppd=(LPPDEVICE)lpDevice;
          if (lppd->sMagic != LUCAS)
                    retval = 0;
          else
                    {
                    retval = 1;
                    lpsNewJoin=(LPSHORT)lpInData;
                    lpsOldJoin=(LPSHORT)lpOutData;

                    if(lpsOldJoin != NULL)
                              *lpsOldJoin=lppd->pen.bJoin;

                    if ((lpsNewJoin != NULL) && !fDisableGDILppd(lppd))
                              {
                              switch (*lpsNewJoin)
                                        {
                                        case -1:
                                                  lppd->pen.bJoin = PENJOIN_round;
                                                  break;
                                        case 0:
                                                  lppd->pen.bJoin = PENJOIN_miter;
                                                  break;
                                        case 1:
                                                  lppd->pen.bJoin = PENJOIN_round;
                                                  break;
                                        case 2:
                                                  lppd->pen.bJoin = PENJOIN_bevel;
                                                  break;
                                        default:
                                                  retval = -1;
                                        }
                              if (fInDocLppd(lppd) && (retval == 1))
                                        {
                                        // send a token
                                        CPenJoin(lppd,lppd->pen.bJoin);
                                        }
                              }
                    else
                              retval = -1;
                    }

          return(retval);
          }

/**********************************************************************
*                       ESCSetMiterLimit
*  function:
*       sets the miter limit.
*
*       May be called any time up till ENDDOC.  May be disabled.
*       Never changes state.
*
*  prototype:
*       SHORT FAR PASCAL ESCSetMiterLimitLPPDEVICE lpDevice,LP lpInData,LP lpOutData);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- LPWORD type -- new miter limit
*       LP lpOutData -- LPWORD -- return previous miter limit
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

SHORT FAR PASCAL ESCSetMiterLimit(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
          {
          LPPDEVICE lppd;
          LPWORD lpwNewMiter;
          LPWORD lpwOldMiter;

          SHORT retval;

          lppd=(LPPDEVICE)lpDevice;
          if (lppd->sMagic != LUCAS)
                    retval = 0;
          else
                    {
                    retval = 1;
                    lpwNewMiter = (LPWORD)lpInData;
                    lpwOldMiter = (LPWORD)lpOutData;

                    if(lpwOldMiter != NULL)
                              *lpwOldMiter = lppd->pen.sMiterLimit;

                    if ((lpwNewMiter != NULL) && !fDisableGDILppd(lppd))
                              {
                              lppd->pen.sMiterLimit = *lpwNewMiter;
                              if (fInDocLppd(lppd))
                                        {
                                        // send a token
                                        CPenMiterLimit(lppd,lppd->pen.sMiterLimit);
                                        }
                              }
                    }

          return(retval);
          }

/**********************************************************************
*                       ESCEnableDuplex
*  function:
*       enables or disables duplex printing.
*
*       May be called any time after Enable and before EndDoc.
*       Never disabled.  Never changes state.
*
*  prototype:
*       SHORT FAR PASCAL ESCEnableDuplexLPPDEVICE lpDevice,LP lpInData,LP lpOutData);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- pointer to a word, as follow:
*                       0=>simplex
*                       1=>duplex with vertical binding
*                       2=>duplex with horizontal binding
*       LP lpOutData -- not used
*  returns:
*       >0 => success
*       0 => error
*
************************************************************************/

SHORT FAR PASCAL ESCEnableDuplex(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
   LPPDEVICE    lppd;
   WORD         wDuplexType;
   SHORT        retval;

   retval = 0;
   lppd=(LPPDEVICE)lpDevice;

   if (lppd->sMagic == LUCAS)
   {
       wDuplexType=*((LPWORD)lpInData);
       switch (wDuplexType)
       {
          case 0: /* Simplex */
                wDuplexType = DMDUP_SIMPLEX;
                break;
          case 1: /* Duplex with vertical binding */
                wDuplexType = DMDUP_VERTICAL;
                break;
          case 2: /* Duplex with horizontal binding */
                wDuplexType = DMDUP_HORIZONTAL;
                break;
          default: /* Who knows just give it a Simplex */
                wDuplexType = DMDUP_SIMPLEX;
                break;
       } /* switch */

       retval = 1;
       if ( fInDocLppd(lppd) && (CJobDuplex(lppd,wDuplexType) != RC_ok) )
       {
         retval = 0;
       }
       lppd->lpPSExtDevmode->dm.dm.dmDuplex = wDuplexType ;

   } /* if Magic != LUCAS */

   return( retval );
} /* End of ESCEnableDuplex */


VOID FAR PASCAL swapDWORD(LPDWORD  dw1, LPDWORD  dw2)
{
   DWORD   tmp;

   tmp = *dw1 ;
   *dw1 = *dw2 ;
   *dw2 = tmp ;
}



SHORT FAR PASCAL ESCResetDC(LPPDEVICE lpNew,LPPDEVICE lpOld)
{
   SHORT  sRC, retval = 0;
   LPPRINTERINFO lpPrinterInfo;
   int    bMinHeader;


       if (lpOld->sMagic != LUCAS  ||  lpNew->sMagic != LUCAS)
       {
           return retval;
       }

       // make sure we have state information
       if (!fInDocLppd( lpOld))
       {
            retval = 1;
       }
       else
       {

       /* let OEM has the chance to set the devmode again in case the
              application may have changed it
           */
            lpPrinterInfo = (LPPRINTERINFO)(lpOld->lpWPXblock->WPXprinterInfo);

            if (lpPrinterInfo->bOEMExist)
            {
                sRC = CallOEMStartDocStub(lpNew, RESETDCCALL);
             }

           /* sanity check on selected values */
            retval =  ResetDV(lpNew,lpOld);

            // If retval is not Zero - ResetDC can be done
            if (retval)
            {
               LPPDEVICE  pTmpPDev;

               pTmpPDev = (LPPDEVICE) GlobalAllocPtr(GHND|GMEM_DDESHARE,
                                                     sizeof(PDEVICE));
               if (!pTmpPDev)
               {
                   return 0;
               }


               //cleanup stuff for UFL.
               //Make font DataList's SubFont point to new lppd.
               //do it before lpOld gets wipe out
               ResetSubFont(lpOld, lpNew);
               UpdateUFLObj(lpOld, lpNew);

               //  first  just swap all fields.
               MemCopy((void FAR *)pTmpPDev,(void FAR *)lpOld,sizeof(PDEVICE));
               MemCopy((void FAR *)lpOld,(void FAR *)lpNew,sizeof(PDEVICE));
               MemCopy((void FAR *)lpNew,(void FAR *)pTmpPDev,sizeof(PDEVICE));

               GlobalFreePtr(pTmpPDev);


               // ...but keep the WPXblock and merge in the public part
               // of PSExtDevmode
               swapDWORD((LPDWORD)&lpNew->lpWPXblock, (LPDWORD)&lpOld->lpWPXblock);
#if 1
               {
                   LPPSEXTDEVMODE lpOldDM = lpOld->lpPSExtDevmode;
                   LPPSEXTDEVMODE lpNewDM = lpNew->lpPSExtDevmode;

                   // As we swapped everything above, lpOldDM has all the
                   // new stuff
                   FarMergePublicDM(lpNew->lpWPXblock, lpNewDM, lpOldDM);
                   UpdatePublicDevmode(lpNew->lpWPXblock, lpNewDM);
               }
#else
               swapDWORD((LPDWORD)&lpNew->lpPSExtDevmode, (LPDWORD)&lpOld->lpPSExtDevmode);
#endif

               bMinHeader = lpNew->job.bfJobMinHeader ;
               // temporarily disable Minheader because DrvStateRead may set wrong lpNew->psmatrix
               lpNew->job.bfJobMinHeader = FALSE;

               // Call DrvStateRead to update paper and CTM info
               DrvStateRead(lpNew, lpNew->lpPSExtDevmode ) ;

               // Restore Minheader flag disabled for DrvStateRead()
               lpNew->job.bfJobMinHeader = bMinHeader;

               /* set flag in new PDEVICE - what kind of ResetDC ...
                    was requested */

               // Fix bug 121157. jjia. 11/22/95
               // If lppd->job.bfReset has been set to RESETDC_NEW_PAGE,
               // do not set it back to RESETDC_PAGE_CONTINUE.
               if (fIsDeviceReset(lpNew) != RESETDC_NEW_PAGE)
               {
                    fDeviceReset (lpNew,retval);
               }
               retval = 1;

               /* do not allow state transition to occur ...
                    on call to Disable() with old PDEVICE */
               fDisableTranslate(lpOld, TRUE);


            }
          // done with resetDC, end this session
            // the lpOld and lpNew is swapped
            if ( sRC > 0 )
            {
               //lpOld is the lpNew that RESETDC session create
               sRC = CallOEMEndSessionStub(lpOld);

               // use correct PDEVICE, the swapDWORD only change
               // the ExtDevmode  bug # 262299   VOID


            }
       }

       return(retval);
}


SHORT PASCAL ResetDV(LPPDEVICE lpNew,LPPDEVICE lpOld)
{
    SHORT       nRetval;
    LPDEVMODE   lpNewDM = &(lpNew->lpPSExtDevmode->dm.dm);
    LPDEVMODE   lpOldDM = &(lpOld->lpPSExtDevmode->dm.dm);


    // First check for the unsupported changes in DEVMODE
    // Duplex is supported now: fix bug 255. 6-2-95
    // Collate and TTOption are not permitted to change inside the job.
    if(
//        (lpNewDM->dmPrintQuality != lpOldDM->dmPrintQuality )  ||
        (lpNewDM->dmColor != lpOldDM->dmColor               )  ||
//        (lpNewDM->dmYResolution != lpOldDM->dmYResolution   )  ||
        (lpNewDM->dmTTOption != lpOldDM->dmTTOption         )  ||
        (lpNewDM->dmCollate != lpOldDM->dmCollate           )
      )
    {
         return 0;
    }

    // Now we are pretty safe to do ResetDC.
    // For n-up support we need to know if this ResetDV call is
    //  for change in page orientation and scaling only.
    // We allow only page orientation and scale factor to change without
    //   starting a new page
    //   Fixed bug #4016 (old #23852)
    //    25-Oct-1994  -by-  [olegsher]
    // Add Copies and Duplex to flush to new page. 6-2-95
    if( ( lpOldDM->dmPaperSize == lpNewDM->dmPaperSize ) &&
       ( lpOldDM->dmPaperLength == lpNewDM->dmPaperLength ) &&
       ( lpOldDM->dmPaperWidth == lpNewDM->dmPaperWidth ) &&
       ( lpOldDM->dmDefaultSource == lpNewDM->dmDefaultSource ) &&
       ( lpOldDM->dmCopies == lpNewDM->dmCopies ) &&
       ( lpOldDM->dmPrintQuality == lpNewDM->dmPrintQuality )  &&
       ( lpOldDM->dmYResolution == lpNewDM->dmYResolution   )  &&
       ( lpOldDM->dmDuplex == lpNewDM->dmDuplex )
      )
    {
        nRetval = RESETDC_PAGE_CONTINUE;
    }else
    {
        nRetval = RESETDC_NEW_PAGE;
    }

    /* For some reason Enable() doesn't return port with ':' after it  ...*/
    /* ..on second try eg: 'LPT1:' versus 'LPT1'     */
    lstrcpy((LPSTR)(LONG)(lpNew->szPortName),
            (LPSTR)(LONG)(lpOld->szPortName));

    return nRetval;
}


// OEMPLUGI begin
void NEAR PASCAL EndOEM(LPPDEVICE lppd)
{
    if (lppd->hDrvInfo)
    {
        if (lppd->hOemCust)
        {
            AdobeOEMTermDllStub(lppd->hOemCust);
        }
#ifdef Adobe_Driver
        if (lppd->hPSFax)
        {
            AdobeOEMTermDllStub(lppd->hPSFax);
        }
        if (lppd->hWebPrinter)
        {
            AdobeOEMTermDllStub(lppd->hWebPrinter);
        }
#endif
        GlobalUnlock(lppd->hDrvInfo);
        GlobalFree(lppd->hDrvInfo);
        lppd->hDrvInfo = NULL;
        lppd->hOemCust = NULL;
#ifdef Adobe_Driver
        lppd->hPSFax   = NULL;
        lppd->hWebPrinter = NULL;
#endif
    }
}

SHORT NEAR PASCAL CallOEMEndDocStub(LPPDEVICE lppd)
{
    SHORT sOemRC;
#ifdef Adobe_Driver
    SHORT sFaxRC;
    SHORT sWebRC;
#endif

    sOemRC = 1;
#ifdef Adobe_Driver
    sFaxRC = 1;
    sWebRC = 1;
#endif

    *lppd->szSDOutput = 0;

    if (lppd->hDrvInfo)
    {
        if (lppd->hOemCust)
        {
            sOemRC = AdobeOEMEndDocStub(lppd->hOemCust);
        }
#ifdef Adobe_Driver
        if (lppd->hPSFax)
        {
            sFaxRC = AdobeOEMEndDocStub(lppd->hPSFax);
        }
        if (lppd->hWebPrinter)
        {
            sWebRC = AdobeOEMEndDocStub(lppd->hWebPrinter);
        }
#endif
    }

#ifdef Adobe_Driver
    if (sWebRC >= 0 && sFaxRC >= 0 && sOemRC >= 0)
//    if (sFaxRC >= 0 && sOemRC >= 0)
#else
    if (sOemRC >= 0)
#endif
        return 1;
    else
        return SP_ERROR;
}
// This reoutine is used to clean up the CallOEMStartDoc call
// for RESETDC
// Fore ResetDC , we don't want to delete the library and handle
SHORT NEAR PASCAL CallOEMEndSessionStub(LPPDEVICE lppd)
{
    SHORT sOemRC;
    LPOEMINFO lpOEMInfo;

    sOemRC = 1;

    if (lppd->hDrvInfo)
    {
        if (lppd->hOemCust)
        {
           sOemRC = CallOEMEndDocStub(lppd);
           sOemRC = AdobeOEMEndSessionStub(lppd->hOemCust);

           lpOEMInfo = (LPOEMINFO)GlobalLock(lppd->hOemCust);

           // Free the library
           // The OEMInit will load the plugi-in everytime the
           // RESETDC is called

           if (lpOEMInfo->hOEMCustDll > HINSTANCE_ERROR)
           {
              FreeLibrary(lpOEMInfo->hOEMCustDll);
              lpOEMInfo->hOEMCustDll = (HINSTANCE)NULL;
           }

           // In case the DRVSetFilter is called in the Plug-In
           // clean up as well

           if (lpOEMInfo->hOEMFilterDll > HINSTANCE_ERROR)
           {
              FreeLibrary(lpOEMInfo->hOEMFilterDll);
              lpOEMInfo->hOEMFilterDll = (HINSTANCE)NULL;
           }
           if (lpOEMInfo)
               GlobalUnlock(lppd-hOemCust);
           GlobalFree(lppd->hOemCust);
        }
        GlobalFree(lppd->hDrvInfo);
        lppd->hDrvInfo = NULL;
        lppd->hOemCust = NULL;
    }

    if (sOemRC >= 0)

        return 1;

    else
        return SP_ERROR;
}


SHORT NEAR PASCAL CallOEMStartDocStub(LPPDEVICE lppd, PRINTJOB_TYPE wPrintJobType)
{
    DRIVERINFOT FAR *lpDrvInfo;
    LPPRINTERINFO   lpPrinterInfo;
    LPSTR           lpFileName;
    SHORT           sRC = 0;
    char            APPFilter[14];
    HANDLE          hContext;
    LPOEMINFO       lpOEMInfo;
     BOOL            bMinHeader;

    lppd->hDrvInfo = GlobalAlloc(GHND|GMEM_DDESHARE, sizeof(DRIVERINFOT));
    lpDrvInfo = (DRIVERINFOT FAR *)GlobalLock(lppd->hDrvInfo);

    /* Set up DrvInfo */
    lpDrvInfo->lpDM = lppd->lpPSExtDevmode;
    lpDrvInfo->pDev = *lppd;
    lpPrinterInfo = (LPPRINTERINFO)(lppd->lpWPXblock->WPXprinterInfo);

    if (lpPrinterInfo->bOEMExist)
    {
        lpFileName = StringRefToLPBYTE(lppd, lpPrinterInfo->PCFileName.dword);
        lppd->hOemCust = AdobeOEMInitDllStub(lpDrvInfo,lpFileName,DLL_TYPE_OEM_CUST,PRINTING);
        if (lppd->hOemCust)
        {
            sRC = AdobeOEMStartDocStub(lppd->hOemCust,lppd->szTitle, wPrintJobType);
            // update the public demode with private devmode information
            UpdatePublicDevmode(lppd->lpWPXblock,lppd->lpPSExtDevmode);

            // Re-calculate the lppd->psmatrix  to use new bMirror YCT
            // bug # 180366

            bMinHeader = lppd->job.bfJobMinHeader;
            // temporarily disable Minheader because DrvStateRead may set wrong lpNew->psmatrix
            lppd->job.bfJobMinHeader = FALSE;
                // update paper dimension and CTM
            DrvStateRead(lppd, lppd->lpPSExtDevmode ) ;
            // Restore Minheader flag disabled for SetCTMatrix()
            lppd->job.bfJobMinHeader = bMinHeader;

        }
    }
    else
        lppd->hOemCust = NULL;

#ifdef Adobe_Driver
    if (sRC >= 0 &&
        lppd->lpPSExtDevmode->dm2.bFAXingP &&
        lppd->lpPSExtDevmode->dm.bFAXingD)
    {
        lppd->hPSFax = AdobeOEMInitDllStub(lpDrvInfo,NULL,DLL_TYPE_PS_FAX,PRINTING);
        if (lppd->hPSFax)
        {
            sRC = AdobeOEMStartDocStub(lppd->hPSFax,lppd->szTitle, wPrintJobType);
        }
    }
    else
        lppd->hPSFax = NULL;

    if (sRC >= 0 && lppd->lpPSExtDevmode->dm2.bWebPrinter)
    {
        lppd->hWebPrinter = AdobeOEMInitDllStub(lpDrvInfo,NULL,DLL_TYPE_WEB_PRINTER,PRINTING);
        if (lppd->hWebPrinter)
        {
            sRC = AdobeOEMStartDocStub(lppd->hWebPrinter,lppd->szTitle, wPrintJobType);
        }
    }
    else
        lppd->hWebPrinter = NULL;

    // if Application filter exist
    // call DrvSetFilter()
    if(*lppd->lpPSExtDevmode->dm.appModulename)
    {

        lstrcpy (APPFilter, lppd->lpPSExtDevmode->dm.appModulename);
        lstrcat (APPFilter, ".dll");
        hContext = GlobalAlloc(GMEM_DDESHARE|GHND, sizeof(OEMINFO));
        if (hContext)
           lpOEMInfo = (LPOEMINFO)GlobalLock(hContext);

        lpOEMInfo->lpPSExtDevmode = lpDrvInfo->lpDM;
        lpOEMInfo->lppd = &(lpDrvInfo->pDev);
        lpOEMInfo->lpDrvInfo = lpDrvInfo;
        lpOEMInfo->flDllType = DLL_TYPE_APP;

        lpOEMInfo->wEntry = PRINTING;
        lpOEMInfo->hOEMCustDll = (HINSTANCE)NULL;
        lpOEMInfo->hOEMFilterDll = (HINSTANCE)NULL;

        GlobalUnlock(hContext);

        lppd->hAppIsv = hContext;
        DRVSetFilter(hContext, APPFilter,
                 "The App downstream filter encounter problems", 0, NULL);

    }
#endif

    if (sRC == 0)
       sRC = 1;

#ifdef Adobe_Driver
    if ((lppd->hOemCust == NULL) && (lppd->hPSFax == NULL)
         && (lppd->hWebPrinter == NULL) && (lppd->hAppIsv == NULL))
//    if ((lppd->hOemCust == NULL) && (lppd->hPSFax == NULL) && (lppd->hAppIsv == NULL))
#else
    if (lppd->hOemCust == NULL)
#endif
    {
        GlobalUnlock(lppd->hDrvInfo);
        GlobalFree(lppd->hDrvInfo);
        lppd->hDrvInfo = NULL;
    }
#ifdef Adobe_Driver
    else
    {
        // Initialize filter data
        lppd->wcOEMFilter = lpDrvInfo->pDev.wcOEMFilter;
        lppd->cbOEMDataSize = lpDrvInfo->pDev.cbOEMDataSize;
        lppd->hOEMFilterData = lpDrvInfo->pDev.hOEMFilterData;

    }
#endif
    return sRC;
}

// OEMPLUGI end

void FAR PASCAL ResyncOutputFormat(LPPDEVICE lppd)
{
    // If OEM change the data type to EPS
    // keep the parameters in sync bug # 181671
    // Do not use lpDocInfo to check the datatype

    if (lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS)
    {
        lppd->lpPSExtDevmode->dm2.bOutputDialect = (BYTE) DIALECT_EPS;
        lppd->lpPSExtDevmode->dm2.bPJL_Protocol = FALSE;
        lppd->lpPSExtDevmode->dm2.bDSC = TRUE;
        lppd->lpPSExtDevmode->dm2.bVM_Tracking = FALSE;
        // add  n-up    and copies
        lppd->lpPSExtDevmode->dm.Copies = 1;
        lppd->lpPSExtDevmode->dm.layout = ONE_UP;
        lppd->lpPSExtDevmode->dm2.bErrHandler = FALSE;

        // The driver already perform download full header for
        // EPS format job
    }

    if((lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS) ||
         (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE) ||
         (lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE))
    {
        // If EPS or ARCHIVE or PJL ARCHIVE, force it to ASCII format.
        lppd->lpPSExtDevmode->dm2.iDataOutputFormat = PROTOCOL_ASCII;
    }

}

