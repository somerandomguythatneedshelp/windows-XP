/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DRVRDLL.H                                                    */
/*                                                                           */
/* Description: Driver functions that must be exported by the DLL.           */
/*                                                                           */
/*****************************************************************************/

#ifdef _DRVRDLL_CODE
#endif

typedef SHORT (FAR PASCAL *DLLPROC)( LPPDEVICE );

SHORT FAR PASCAL StartDLL( LPPDEVICE );
SHORT FAR PASCAL EndDLL( LPPDEVICE );
SHORT FAR PASCAL EnterDriverDLL( LPPDEVICE );
SHORT FAR PASCAL ExitDriverDLL( LPPDEVICE );

