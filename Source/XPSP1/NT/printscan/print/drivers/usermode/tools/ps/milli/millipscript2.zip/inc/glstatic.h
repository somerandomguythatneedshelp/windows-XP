/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: GLSTATIC.H                                             */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

//Setjmp.h provides declartions for the setjmp() and longjmp() routines.
#include "setjmp.h"

extern jmp_buf ErrJmpVector ;
extern char LocalStringBuffer[128];

extern HHOOK hSystemHook;
extern HANDLE ghDriverMod;
extern char szPPDMask[];
extern char szNone[5];                  /* sizes defined in globals.h   */
extern char szFalse[6];                 /* sizes must match             */
extern char szTrue[5];
extern char szDefaultPrinter[16];
extern char szHelpFile[13];
extern char szIniCreator[64];
extern char szOne[2];
extern char szTwo[2];
extern char szThree[2];
extern char szFont[6];
extern char szQuestion[8];
extern LPSTR** AliasTable;
extern LPSTR* IncorrectFixedFontList;
extern LPSTR* PrefCJKFontList;
extern LPSTR* EncodeNameList;
extern LPSTR* MacGlyphNameList;
extern BYTE DefaultCJKCharSet; // used for CJK-Font Relization and CJK-CMap downloading

