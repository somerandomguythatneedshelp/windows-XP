
/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: EXTTEXTW.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for ExtTextOut            */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_TEXTOUTSEG)


#define _1BIT     1
#define _2BIT     2


// EXTERNs from  EXTTEXT.C used in this module.

BOOL NEAR TEXTOUTSEG PASCAL SetJustification(LPPDEVICE, LPDRAWMODE, 
                                               LPJUSTBREAKREC, LPJUSTBREAKREC);
short NEAR TEXTOUTSEG PASCAL GetJustBreak(LPJUSTBREAKREC);

int NEAR TEXTOUTSEG PASCAL PairKern(LPKP lpkp, int iCh1, int iCh2);

int NEAR TEXTOUTSEG PASCAL TrackKern(LPPDEVICE lpdv, LPPSFONTINFO lpFontInfo, int cb);


///////////////////////////////////////////////////////////
/*------------------ local functions --------------------*/

VOID NEAR TEXTOUTSEG PASCAL DumpStrWide(LPPDEVICE lpdv, LPPSFONTINFO lpFontInfo, 
  LPTEXTXFORM lpTextXForm,
  LPDRAWMODE lpdm, int ix, int iy, LPWORD /* LPSTR */ lpbStr, long cxStr, int count,
  int CharExtra, int BreakExtra, LPINT lpdx);

LONG NEAR TEXTOUTSEG PASCAL GetTranStrSizeWide(LPPDEVICE lpdv, 
                                          LPPSFONTINFO lpFontInfo,
                                          LPWORD /* LPSTR */ lpbStr, int count, 
                                          LPWORD lpBreakCnt,
                                          WORD offset);

LONG NEAR TEXTOUTSEG PASCAL ShowTextWide(LPPDEVICE lpdv, int ix, int iy, 
                                          LPWORD lpbSrc, int abscbSrc,
                                          LPPSFONTINFO lpFontInfo, LPDRAWMODE lpdm,
                                          LPTEXTXFORM lpTextXForm, LPSHORT lpdx, 
                                          LPPSFONTINFO TranFontInfo,
                                          long lsize);

DWORD NEAR TEXTOUTSEG PASCAL ShowStrInBBoxWide(LPPDEVICE   lpdv,
                                          int ix,
                                          int iy,
                                          LPWORD lpbSrc,
                                          int cb,
                                          LPDRAWMODE  lpdm,
                                          LPTEXTXFORM lpTextXForm,
                                          LPSHORT lpdx,
                                          LPPSFONTINFO TranFontInfo,
                                          long lsize);
extern DWORD NEAR TEXTOUTSEG PASCAL StrBBox(LPPDEVICE lpdv,
                                          int ix,
                                          int cb,
                                          LPPSFONTINFO  lpFontInfo,
                                          LPDRAWMODE  lpdm,
                                          LPSHORT lpdx);

///////////////////////////////////////////////////////////



// Functions for TrueType Widefont support

/****************************************************************
* Name: GetTranStrSizeWide()
*
* Action: Get the size of the PS string taking in account
*  all possible Track Kerning, Pair Kerning ....
*
*  offset is a new variable needed to sync the substring lpbStr to the 
*  charwidth array (lpTranCharWidths) of the entire string !
*
*   ATTENTION: The result is returned in the DIGITIZED font units!!!!
*
*****************************************************************/

LONG NEAR TEXTOUTSEG PASCAL GetTranStrSizeWide(LPPDEVICE lpdv, 
                                           LPPSFONTINFO lpFontInfo,
                                           LPWORD lpbStr, int count,
                                           LPWORD lpBreakCount,
                                           WORD   offset)
{
   LPFONTEXTRA FontExtra = NULL;
   LPKP lpPairKern = NULL;
   LPTTFONTINFO lpTTFontInfo;
   short   i,j;
   int     iCh;        // Current char
   int     iPrevCh;    // Previous char
   LPWORD  lpTranCharWidths;   // LP to array of widths on TRAN side
                               //  in the units that this font ws digitized.

   //  Font Parameters
   WORD         dfBreakChar ;
   WORD         dfFirstChar ;
   BOOL        fVariablePitch;
   WORD    HighByte ;   
   LPREALIZEBUFS  lpCache ;

   DWORD    TranStrWidth  ; // Width of the string on TRAN side

   if ( count == 0 )
            return (0L) ;


   lpCache = &lpdv->GlobalBuffer.RealizeBufs ;


   // Get information about the font - first, last chars, break character

   if(lpFontInfo->dfType & PF_GLYPH_INDEX)
   {
      dfFirstChar = 0 ;
      
      dfBreakChar      = *(LPWORD)&lpFontInfo->dfDefaultChar  ;
   }
   else
   {
      dfFirstChar     = ((WORD)lpFontInfo->dfFirstChar) & 0x00ff;
      dfBreakChar     = ((WORD)(lpFontInfo->dfBreakChar + dfFirstChar)) & 0x00ff;
   }

   if ( lpFontInfo->dfType & TYPE_TRUETYPE )
   {
      lpTTFontInfo    = (LPTTFONTINFO) ((LPSTR)lpFontInfo +
                                 lpFontInfo->dfBitsOffset);

      HighByte = lpTTFontInfo->HighByte  ;

      if ( lpFontInfo->dfType & TYPE_OUTLINE )
         lpTranCharWidths = lpCache->lpdWidths + lpCache->offsetWidths;
      else
         lpTranCharWidths = lpCache->rgwWidths + lpCache->offsetWidths;
   }
   else
   {
      HighByte = 0 ;

      FontExtra = (LPFONTEXTRA) BUMPFAR(lpFontInfo, lpFontInfo->dfDriverInfo);
      lpTranCharWidths = lpCache->devlpdWidths + lpCache->offsetWidths;
   }


   //*******************************************************************
   if ( lpFontInfo->dfPitchAndFamily & 1) // Variable width font
   {
         fVariablePitch = TRUE;
   }
   else
   {
      fVariablePitch   = FALSE;

#if 0
      forget all this stuff about average widths.

      if ( lpFontInfo->dfType & TYPE_TRUETYPE )
      {
         if ( lpFontInfo->dfType & TYPE_OUTLINE )
            {
            TAvgWidth = lpTTFontInfo->xFontInfo->dfAvgWidth ;
            }
         else
            {
            TAvgWidth = lpFontInfo->dfAvgWidth ;
         //  Take the width of any character  NOT!
         //  TAvgWidth = lpTranCharWidths[dfFirstChar+32] ;
            }
      }
      else
      {
         TAvgWidth = FontExtra->psAvgWidth ;
      }
#endif
   }

   /*  Zip through the string substituting any
   * characters outside of the valid range into dfDefaultChar.
   * Also apply Pair Kerning rules to the character pairs.
   */
   TranStrWidth    = 0L;
   iCh             = 0;
   if (lpBreakCount)
       *lpBreakCount = 0;
   for ( i = 0,j = 0; i  < count ; i++ )
   {
      iPrevCh = iCh;
      iCh = ( (int) lpbStr[i] ) & 0x00FF ;
      iCh = HighByte | (WORD)iCh ;

//      if ( ((WORD)iCh   < dfFirstChar   ) ||
//            ((WORD)iCh   > dfLastChar    )   )
//               iCh  =  dfDefaultChar ;

      // Update BreakCount
      if (((WORD) iCh == dfBreakChar) && lpBreakCount)
          (*lpBreakCount)++;

      // Get character width: no table - use average width
      //  Width is calculated in PS font units - 1/1000 of EM-square
      //  or in native digitizer units in the case of TT->Type42
//      TranStrWidth += lpTranCharWidths[iCh] ;
      TranStrWidth += lpTranCharWidths[i+offset] ;

      if( fVariablePitch  &&      // Apply pair kerning
         !(lpFontInfo->dfType & TYPE_TRUETYPE )    &&   // to PS font only
         lpdv->text.bfPairKern )
      {
          lpPairKern = (LPKP) BUMPFAR (lpFontInfo, FontExtra->dwPairKern);
          TranStrWidth += PairKern(lpPairKern, iPrevCh, iCh) ;
      }
   }

   //  If Postscript output - correct  the size by applying Track Kerning
   if (!(lpFontInfo->dfType & TYPE_TRUETYPE))
   {
      TranStrWidth += TrackKern(lpdv, lpFontInfo, count) ;
      // Convert string width from PS units to device units
      TranStrWidth *= FontExtra->sPSxScale;
   }
   else       // TrueType font
   {
      // Scale the width for all Type 1 and Type 42 chars.
      // Type 3 doesn't require that because the characters' widths
      // was already scaled by initrgwWidths(lpdv, lpFontInfo) call
      if ( lpFontInfo->dfType & TYPE_OUTLINE )
      {
         TranStrWidth *= lpTTFontInfo->sx ;
      }
   }

   return(TranStrWidth);
   // Comment : 20-Jun-1994  -by-  [olegs]
   // This function should return the width of the string as DWORD 
   //  with maximum available precision. To do that we accumulate the
   //  width of the string in the native units for the specific type of
   //  the font being used:
   //     - TTRefEM for Type 1 and Type 42
   //     - GDI Pixels for Type 3 fonts
   //     - 1000-per-EM for real PostScript font
   //     - Whatever was told to us for resident TT fonts that have a .PFM
   //
}


/****************************************************************
* Name: DumpStrWide()
*
* Action: Execute the Postscript calls necessary to output a
* string of text.
* The function takes as parameters the string to output,  the length
*   of the resulting output in GDI space. It will try to find the best
*   fit for the given string on the TRAN side.
*
*   The algorithm so far is:
*   -   Find the size of the string on the TRAN side using
*    all applicable modifications - Track Kerning, Pair Kerning,....
*   -   Calculate how many additional points should we add to every
*    regular character and to the every break character.
*   -   Make a call on TRAN side with those parameters.
*
*****************************************************************/

#pragma  optimize ("se", off)
#pragma  optimize ("d", on)

VOID NEAR TEXTOUTSEG PASCAL DumpStrWide(LPPDEVICE lpdv, LPPSFONTINFO lpFontInfo, 
  LPTEXTXFORM lpTextXForm,
  LPDRAWMODE lpdm, int ix, int iy, LPWORD lpbStr, long cxStr, int count,
  int CharExtra, int BreakExtra, LPINT lpdx)
{
     short   i;
     int     iCh;            // Current char
     LPWORD  lpSubString ;   // Pointer to the current run substring
     POINT   CurrentPoint ;  // Where to place the current run
     LONG      lNextPos;    // Relative position of the next char in run

     //  Font Parameters
     int         dfBreakChar ;
     int         dfFirstChar ;

     LONG        lCharExtra;
     LONG        lBreakExtra;
     LONG        lError;   // Difference between GDI and TRAN sizes

     WORD        CharCount   ;   // Number of chars in the Substring
     WORD        BreakCount  ;   // Number of Break characters in the string
     WORD        HighByte ;   
     LONG        lGDIStrWidth;      // Width of the string in GDI units
     DWORD       EM ;

     if ( count == 0 )
             return;

     // Find the value of EM - the size of the digitization grid
     // for the specific font.
     // The GetTranStrSize() function will return the size of the
     //  output string in EM-units.
     // For Type 1, 3, 42 - any TT font - it is usually 2048,
     // for PostScript font - it can be either 1000 for real PostScript
     // fonts, or something else for Printer-resident TT fonts.
     //  Added  20-Jun-1994  -by-  [olegs]

     if ( lpFontInfo->dfType & TYPE_TRUETYPE )
     {
        // For Type 1 and Type 42 the width of the string returned by
        // the call to the  GetTranStrSize() function is in TTRefEM units,
        // while for Type 3 it will be in GDI pixels.
        if ( lpFontInfo->dfType & TYPE_OUTLINE )
        {
            LPTTFONTINFO lpTTFontInfo;
            lpTTFontInfo    = (LPTTFONTINFO) ((LPSTR)lpFontInfo +
                                 lpFontInfo->dfBitsOffset);
            EM = (DWORD) lpTTFontInfo->TTRefEM ;
        }else
        {
            EM = 1; // One Type 3 unit is equal 1 GDI pixel
        }
     }else
     {
        LPPFMEXTENSION lpPFMExt;
        LPETM lpETM;
        lpPFMExt = (LPPFMEXTENSION) ((LPBYTE) lpFontInfo + sizeof(PFMHEADER));
        lpETM = (LPETM) ((LPBYTE) lpFontInfo + lpPFMExt->dfExtMetricsOffset);
        EM = (DWORD) lpETM->etmMasterUnits;
     }   

     //********************************************
     //              Initialize vars

     CurrentPoint.x = ix;
     CurrentPoint.y = iy;
     lCharExtra     = CharExtra *EM;
     lBreakExtra    = BreakExtra*EM;
     //********************************************

     // Get information about the font - first, last chars, break character
   if(lpFontInfo->dfType & PF_GLYPH_INDEX)
   {
      LPTTFONTINFO lpTTFontInfo;

      lpTTFontInfo    = (LPTTFONTINFO) ((LPSTR)lpFontInfo +
                                 lpFontInfo->dfBitsOffset);

      HighByte = lpTTFontInfo->HighByte  ;

      dfFirstChar = 0 ;
      dfBreakChar      = *(LPWORD)&lpFontInfo->dfDefaultChar  ;
   }
   else
   {
      HighByte = 0 ;
      dfFirstChar     = ((WORD)lpFontInfo->dfFirstChar) & 0x00ff;
      dfBreakChar     = ((WORD)(lpFontInfo->dfBreakChar + dfFirstChar)) & 0x00ff;
   }

     START_PROFILE("CTextBegin", PRFCTEXTBEGIN);
     CTextBegin(lpdv,(LPPOINT) &CurrentPoint, lpFontInfo, lpTextXForm);
     STOP_PROFILE(PRFCTEXTBEGIN);


     if( lpdx )
     {   // Special case - output the string using width vector.
          // During the output we can break the string into multiple runs.
          WORD  offset ;   // aligns lpSubString properly with CharWidthArray
          WORD  wRuns = 0;
          WORD  fLeadByte = FALSE;

         /*
          * First pass, calculate how many runs.
          */

          lNextPos = 0L;
          offset = BreakCount = 0;
          lpSubString = lpbStr ;
          CharCount = 0;      // Counter on characters in a substring

          for(i=0; i < count ; i++)
          {
               iCh = ( (int) lpbStr[i] ) & 0x00FF; // Get current char

               if( !(lpFontInfo->dfType & PF_GLYPH_INDEX) &&
                   IsDBCSCharSet(lpFontInfo->dfCharSet) &&
                   (fLeadByte = IsDBCSLeadByteEx(lpFontInfo->dfCharSet,(BYTE)iCh)))
               {
                   lNextPos += lpdx[i] * EM;     // Position for the next char
                   i++;
                   CharCount++;
               }

               iCh = HighByte | (WORD)iCh ;
               if( iCh == dfBreakChar )    // If it is break character - 
                    BreakCount++ ;          //   bump break counter

               CharCount++ ;               // Bump char counter

               lNextPos += lpdx[i] * EM;     // Position for the next char
               lError = lNextPos - ( GetTranStrSizeWide(lpdv,
                                                    lpFontInfo, 
                                                    lpSubString, 
                                                    CharCount, 
                                                    NULL,
                                                    offset
                                                    ) 
                      + lCharExtra * CharCount + lBreakExtra * BreakCount);
               if(  lError )
                                   // Aha!!! - we  are off the target - something
                                   //  should be done - play with CharExtra, or with
                                   //  BreakExtra. If all possible adjustments were
                                   //  already made - break the run.
               {
                    if( ( iCh == dfBreakChar )  &&   // This is break character,
                         ( BreakCount == 1)      &&   //  .. first time,
                         ( BreakExtra    ==  0)       //  .. BreakExtra wasn't used
                      )   
                    {
                         lBreakExtra = lError ;
                         continue;                   // One more chance ....
                    }
                         
                    if(  
                         ( ( CharCount == 1 ) ||   
                           ( CharCount == 2 && fLeadByte)) &&   // First time
                         ( lBreakExtra == 0L  ) &&   // No space adjustment
                         ( iCh != dfBreakChar ) &&   // Non-break char
                         ( CharExtra == 0 )       )  // CharExtra wasn't used
                    {
                         lCharExtra += lError ;
                         continue;                   // One more chance ....
                    }
                    //*********************************************************
                    // We tried everything and cannot adjust - break the run
                    //  Output accumulated run

                    wRuns ++;

                    //---------------------------------------------------------
                    // Prepare for the next run
                    // Roll back the next position variable to find the starting
                    //  point of the next run. The next run starts where previous
                    lpSubString = lpSubString + CharCount - (fLeadByte?2:1);
                    offset += CharCount - (fLeadByte?2:1);
                    i -= fLeadByte?2:1;

                    lNextPos = 0;
                    BreakCount = 0;
                    CharCount = 0;
                    lCharExtra     = CharExtra *EM;
                    lBreakExtra    = BreakExtra*EM;
               }
          }
          wRuns ++;        
        

         /*
          *  Second pass, print.
          */

         if ((count == 1) ||
             (100* wRuns - count - 200 <= 0))
         {
             /*
              * Using old method to show string (show, ashow .....)
              */

              fLeadByte = FALSE;
  
              lNextPos = 0L;
              offset = BreakCount = 0;
              lpSubString = lpbStr ;
              CharCount = 0;      // Counter on characters in a substring

              for(i=0; i < count ; i++)
              {
                  iCh = ( (int) lpbStr[i] ) & 0x00FF; // Get current char
                  if( !(lpFontInfo->dfType & PF_GLYPH_INDEX) &&
                      IsDBCSCharSet(lpFontInfo->dfCharSet) &&
                      (fLeadByte = IsDBCSLeadByteEx(lpFontInfo->dfCharSet,(BYTE)iCh)))
                  {
                      lNextPos += lpdx[i] * EM;     // Position for the next char
                      i++;
                      CharCount++;
                  }
                  iCh = HighByte | (WORD)iCh ;
                  if( iCh == dfBreakChar )    // If it is break character - 
                      BreakCount++ ;          //   bump break counter

                  CharCount++ ;               // Bump char counter

                  lNextPos += lpdx[i] * EM;     // Position for the next char
                  lError = lNextPos - ( GetTranStrSizeWide(lpdv,
                                                           lpFontInfo, 
                                                           lpSubString, 
                                                           CharCount, 
                                                           NULL,
                                                           offset
                                                           ) 
                         + lCharExtra * CharCount + lBreakExtra * BreakCount);
                  if(  lError )
                                   // Aha!!! - we  are off the target - something
                                   //  should be done - play with CharExtra, or with
                                   //  BreakExtra. If all possible adjustments were
                                   //  already made - break the run.
                  {
                      if( ( iCh == dfBreakChar )  &&   // This is break character,
                          ( BreakCount == 1)      &&   //  .. first time,
                          ( BreakExtra    ==  0)       //  .. BreakExtra wasn't used
                        )   
                      {
                          lBreakExtra = lError ;
                          continue;                   // One more chance ....
                      }
                         
                      if(  
                           ( ( CharCount == 1 ) ||   
                             ( CharCount == 2 && fLeadByte)) &&   // First time
                           ( lBreakExtra == 0L  ) &&   // No space adjustment
                           ( iCh != dfBreakChar ) &&   // Non-break char
                           ( CharExtra == 0 )       )  // CharExtra wasn't used
                       {
                           lCharExtra += lError ;
                           continue;                   // One more chance ....
                       }
                       //*********************************************************
                       // We tried everything and cannot adjust - break the run
                       //  Output accumulated run
                       START_PROFILE("CTextRunWide", PRFCTEXTRUN);
                       CTextRunWide(lpdv, lpSubString, CharCount-(fLeadByte?2:1), 
                                    lBreakExtra/(double) EM,
                                    lCharExtra/(double) EM, lpFontInfo, lpTextXForm, NULL);
                       STOP_PROFILE(PRFCTEXTRUN);

                       //---------------------------------------------------------
                       // Prepare for the next run
                       // Roll back the next position variable to find the starting
                       //  point of the next run. The next run starts where previous
                       lpSubString = lpSubString + CharCount - (fLeadByte?2:1);
                       offset += CharCount - (fLeadByte?2:1);
                       i -= fLeadByte?2:1;

                       lNextPos = 0;
                       BreakCount = 0;
                       CharCount = 0;
                       lCharExtra     = CharExtra *EM;
                       lBreakExtra    = BreakExtra*EM;
                  }
              }
              START_PROFILE("CTextRunWide", PRFCTEXTRUN);
              CTextRunWide(lpdv, lpSubString, CharCount , lBreakExtra/(double) EM,
                           lCharExtra/(double) EM, lpFontInfo, lpTextXForm, NULL);
              STOP_PROFILE(PRFCTEXTRUN);
          }
          else
          {
             /*
              * Using xshow to show string ( do not break string to runs )
              */
              START_PROFILE("CTextRunWide", PRFCTEXTRUN);
              CTextRunWide(lpdv, lpbStr, count , 0, 0, lpFontInfo, lpTextXForm, lpdx);
              STOP_PROFILE(PRFCTEXTRUN);
          }
     }else
     {
          // Get the size of the string as it will appear on paper
          //  taking  in account track kerning, pair kerning and so on.
          lGDIStrWidth =  GetTranStrSizeWide(lpdv, lpFontInfo, lpbStr, count,
                                         (LPWORD) &BreakCount, 0
                                          );
          //**************************************************************************
          //              TRICKY PART !!!!!!
          //  We have the size of the string if we output it on TRAN side in
          //      dGDIStrWidth.
          //  We also have the size of the string we reported to GDI - it's
          //      in cxStr. What shall we do if they differ? The answer is -
          //      to stretch/expand the resulting string so it will fit into the
          //      space we reported back to GDI. The next question is - how to
          //      stretch/expand, how many pixels add to each char, to every break.
          //      We should analyze the CharCount, CharExtra, BreakCount,
          //      BreakExtra values passed to us in order to find how.
          //**************************************************************************



          lError = cxStr * EM - (lGDIStrWidth +
                                   lCharExtra * count  +
                                   lBreakExtra * BreakCount );

          // Fix bug 190218.  1/23/97   jjia
          // Make sure not to use very small extra width.
          if ((lError > -(LONG)EM) && (lError < (LONG)EM) ||
              (((lError == -(LONG)EM) || (lError == (LONG)EM)) && (count >= 10)))
              lError = 0;

          START_PROFILE("CTextRunWide", PRFCTEXTRUN);
          CTextRunWide(lpdv, lpbStr, count, lBreakExtra/(double) EM,
                     (lCharExtra + (lError/(double) count) ) / (double) EM,
                               lpFontInfo, lpTextXForm, NULL);
          STOP_PROFILE(PRFCTEXTRUN);

     }
     START_PROFILE("CTextEnd", PRFCTEXTEND);
     CTextEnd(lpdv, lpFontInfo, lpTextXForm, (WORD) cxStr );
     STOP_PROFILE(PRFCTEXTEND);
}

#pragma  optimize ("d", off)
#pragma  optimize ("se", on)

/****************************************************************
* Name: ShowStrInBBoxWide()
*
* Action: This routine draw text on an output device
*
* Returns: A long value which is the concatenation of the
*      text height and string width.
*
*      The high-order word contains the string height,
*      and the low-order word contains the string width.
*
*****************************************************************/

DWORD NEAR TEXTOUTSEG PASCAL ShowStrInBBoxWide(lpdv, ix, iy, lpbSrc, cb,
          lpdm, lpTextXForm, lpdx, TranFontInfo, lsize)

LPPDEVICE   lpdv;           /* Far ptr the device descriptor */
int ix;                     /* The horizontal origin */
int iy;                     /* The vertical origin */
LPWORD      lpbSrc;             /* Far ptr to the source string */
int cb;                     /* Size of the source string */
LPDRAWMODE  lpdm;           /* Far ptr to the justification info, etc. */
LPTEXTXFORM lpTextXForm;    /* Font transformation structure */
LPSHORT lpdx;               /* Far ptr to delta-x moves */
LPPSFONTINFO TranFontInfo;  /* Far ptr to the PSFONTINFO (font metrics)
                             * structure  used for an actual TRAN-side output*/
long lsize;
{
    DWORD         gdiStrWidth = LOWORD(lsize);
    JUSTBREAKREC  justifyLetter;
    JUSTBREAKREC  justifyWord;

    if ( cb == 0 )
        return(0x1L);       // Return Success

    SetJustification(lpdv, lpdm, &justifyWord, &justifyLetter);

    DumpStrWide(lpdv, TranFontInfo, lpTextXForm, lpdm, ix, iy,
            lpbSrc, gdiStrWidth, cb ,
            justifyLetter.extra, justifyWord.extra, lpdx );
    return lsize;
}

/***************************************************************
*
*                        ShowTextWide
*
* Action: This routine is used to draw text strings on the display
*     surface.  Most of the real work is done by the ShowStr routine.
*
******************************************************************/

LONG NEAR TEXTOUTSEG PASCAL ShowTextWide(LPPDEVICE lpdv, int ix, int iy, 
                                          LPWORD lpwSrc, int cbSrc,
                                          LPPSFONTINFO lpFontInfo, LPDRAWMODE lpdm,
                                          LPTEXTXFORM lpTextXForm, LPSHORT lpdx, 
                                          LPPSFONTINFO TranFontInfo, long lsize)
{
   LPFONTEXTRA FontExtra;     // Far ptr to the extended device font structure 
   LPTTFONTINFO lpTTFontInfo ;

   if( TranFontInfo->dfType & TYPE_TRUETYPE )
   {
      lpTTFontInfo = (LPTTFONTINFO)((LPSTR)TranFontInfo + 
                                       TranFontInfo->dfBitsOffset);
   }
   else 
   {
      FontExtra=(LPFONTEXTRA)BUMPFAR (TranFontInfo, TranFontInfo->dfDriverInfo);
   }

   {
      WORD   HighByte ;

      HighByte = *lpwSrc & 0xFF00 ;

      lpTTFontInfo->HighByte = HighByte ;

      // download a softfont
      if ( (TranFontInfo->dfType & TYPE_TRUETYPE)      ||
                          (FontExtra->dwSoftFont)
         ) 
      {
         START_PROFILE("CSoftFontLoad", PRFCSOFTFONTLOAD);
         CSoftFontLoad(lpdv, TranFontInfo, lpTextXForm, (LPSTR)lpwSrc, cbSrc);
         STOP_PROFILE(PRFCSOFTFONTLOAD);
      }
   }

   // set the text color
   CPenFGColor(lpdv,lpdm->TextColor);

   // Output the text string now
   if (!lsize)
   {
       lsize = StrBBox(lpdv, ix, (int)cbSrc, lpFontInfo, lpdm, lpdx);
   }
   lsize = ShowStrInBBoxWide(lpdv, ix, iy, lpwSrc, cbSrc, lpdm,
                        lpTextXForm, lpdx, TranFontInfo, lsize);

   return (lsize);
}


