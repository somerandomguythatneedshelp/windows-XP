/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: QPROCS.H                                                     */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/


#ifdef QDEFS
SHORT (FAR PASCAL *lpQCreate)(LPXFILE,SHORT);
SHORT (FAR PASCAL *lpQOpen)(LPXFILE,SHORT);
SHORT (FAR PASCAL *lpQClose)(LPXFILE);
FLAG  (FAR PASCAL *lpQDelete)(LPXFILE);
LONG  (FAR PASCAL *lpQSeek)(LPXFILE,LONG,SHORT);
SHORT (FAR PASCAL *lpQRead)(LPXFILE,LP,SHORT);
SHORT (FAR PASCAL *lpQReadMultiple)(LPXFILE,LP,SHORT,SHORT);
DWORD (FAR PASCAL *lpQReadMega)(LPXFILE,LP,DWORD,DWORD);
CHAR  (FAR PASCAL *lpQReadChar)(LPXFILE);
SHORT (FAR PASCAL *lpQReadShort)(LPXFILE);
LONG  (FAR PASCAL *lpQReadLong)(LPXFILE);
SHORT (FAR PASCAL *lpQWrite)(LPXFILE,LP,SHORT);
SHORT (FAR PASCAL *lpQWriteMultiple)(LPXFILE,LP,SHORT,SHORT);
DWORD (FAR PASCAL *lpQWriteMega)(LPXFILE,LP,DWORD,DWORD);
FLAG  (FAR PASCAL *lpQWriteChar)(LPXFILE,CHAR);
FLAG  (FAR PASCAL *lpQWriteShort)(LPXFILE,SHORT);
FLAG  (FAR PASCAL *lpQWriteLong)(LPXFILE,LONG);
#else
extern SHORT (FAR PASCAL *lpQCreate)(LPXFILE,SHORT);
extern SHORT (FAR PASCAL *lpQOpen)(LPXFILE,SHORT);
extern SHORT (FAR PASCAL *lpQClose)(LPXFILE);
extern FLAG  (FAR PASCAL *lpQDelete)(LPXFILE);
extern LONG  (FAR PASCAL *lpQSeek)(LPXFILE,LONG,SHORT);
extern SHORT (FAR PASCAL *lpQRead)(LPXFILE,LP,SHORT);
extern SHORT (FAR PASCAL *lpQReadMultiple)(LPXFILE,LP,SHORT,SHORT);
extern DWORD (FAR PASCAL *lpQReadMega)(LPXFILE,LP,DWORD,DWORD);
extern CHAR  (FAR PASCAL *lpQReadChar)(LPXFILE);
extern SHORT (FAR PASCAL *lpQReadShort)(LPXFILE);
extern LONG  (FAR PASCAL *lpQReadLong)(LPXFILE);
extern SHORT (FAR PASCAL *lpQWrite)(LPXFILE,LP,SHORT);
extern SHORT (FAR PASCAL *lpQWriteMultiple)(LPXFILE,LP,SHORT,SHORT);
extern DWORD (FAR PASCAL *lpQWriteMega)(LPXFILE,LP,DWORD,DWORD);
extern FLAG  (FAR PASCAL *lpQWriteChar)(LPXFILE,CHAR);
extern FLAG  (FAR PASCAL *lpQWriteShort)(LPXFILE,SHORT);
extern FLAG  (FAR PASCAL *lpQWriteLong)(LPXFILE,LONG);
#endif

#define QCreate(x,y)           (*lpQCreate)(x,y)
#define QOpen(x,y)             (*lpQOpen)(x,y)
#define QClose(x)              (*lpQClose)(x)
#define QDelete(x)             (*lpQDelete)(x)
#define QSeek(x,y,z)           (*lpQSeek)(x,y,z)
#define QCurPos(x)             (*lpQSeek)(x,0,1)
#define QSkip(x,y)             (*lpQSeek)(x,y,1)
#define QHome(x)               (*lpQSeek)(x,0L,0)
#define QEnd(x)                (*lpQSeek)(x,0L,2)
#define QRead(x,y,z)           (*lpQRead)(x,y,z)
#define QReadMultiple(w,x,y,z) (*lpQReadMultiple)(w,x,y,z)
#define QReadMega(w,x,y,z)     (*lpQReadMega)(w,x,y,z)
#define QReadChar(x)           (*lpQReadChar)(x)
#define QReadShort(x)          (*lpQReadShort)(x)
#define QReadLong(x)           (*lpQReadLong)(x)
#define QWrite(x,y,z)          (*lpQWrite)(x,y,z)
#define QWriteMultiple(w,x,y,z)(*lpQWriteMultiple)(w,x,y,z)
#define QWriteMega(w,x,y,z)    (*lpQWriteMega)(w,x,y,z)
#define QWriteChar(x,y)        (*lpQWriteChar)(x,y)
#define QWriteShort(x,y)       (*lpQWriteShort)(x,y)
#define QWriteLong(x,y)        (*lpQWriteLong)(x,y)



