/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ADDPRN.C                                                     */
/*                                                                           */
/* Description: This module contains the functions for adding printers.      */
/*                                                                           */
/*****************************************************************************/

#include "ps.h"         // Also includes PRINT.H, WINDOWS.H, GDIDEFS.INC etc..

#include <commdlg.h>
#include <dlgs.h>
#include "string.h"
#include "ctype.h"
#include "dos.h"
#include "errno.h"
#include "direct.h"
#include "glstatic.h"
#include "memory.h"
#include "drvrmem.h"
#include "errors.h"
#include "resrcid.h"
#include "dlgid.h"
#include "drvfuncs.h"
#include "ps_enumx.h"
#include "dlgsfunc.h"
#include "resource.h"
#include <stdlib.h>
#include "dmg.h"
#include "upgrade.h"   // Chicago 
#include "dlgsutil.h"  // import DrvProcessHookProc(), GetNextNickName()
#include "lcalls.h"
#include "keywfunc.h"

/* Used by DlgDirList() */
#define EXCLUSIVE                       0x8000
#define DRIVES                          0x4000
#define SUBDIR                          0x0010
#define FILES                           0x0

#define MAX_PPD_NICKNAME_LEN            127

#define WM_REFRESH                     WM_USER + 1


/***** Save and Restore default Path variables *****/
#define     MAX_WIN_PATH      144
char        szPathBuffer[MAX_WIN_PATH];
char        szPathBuffer2[MAX_WIN_PATH];
WORD        wDriveNum;

/***** PPD File Name Structure *****/

struct  PPDNamesStruct
{
   char    PPDNickname[MAX_PPD_NICKNAME_LEN];
   char    null_terminate;
   char    PPDFilename[13];
};

struct PPDNamesStruct  FAR *lpPPDNamesStruct = NULL;
HANDLE hPPDNamesStruct = 0;

extern int iStdOpenFileRetCode;  // in dlgsutil.c

#if 0
WORD     GetNumPPDFiles( VOID );
LPSTR    GetPPDNickname(LPSTR FilePathToPPD);
short    GetNextPPDLine(LPSTR buffer, LPSTR buff2, LPSHORT cnt, LPSHORT p1, int fd2);
short    PPDCompareStr(LPSTR s1, LPSTR s2);
BOOL FAR DanglingQuote(LPSTR buf, LPSTR FAR *quote_string);
LPSTR    ExtractNickname( LPSTR linebuf );
LPSTR FAR PASCAL SkipStr(LPSTR s, LPSTR white_chars);
int      AddThePrinter(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode, HWND hdlg, LPSTR nickName, LPSTR pathToPPD, WORD wIndex); /* Chicago */
// LONG FAR PASCAL NicknameWndProc(HWND hWnd, WORD wMsg, WORD wParam, LONG lParam);
#endif

/***************************************************************************
*                               AddThePrinter
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       HWND      hdlg --
*       LPSTR     nickName --
*       LPSTR     pathToPPD --
*       WORD      wIndex --
*    
*  Returns: int
*                                                                           
***************************************************************************/
int AddThePrinter(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode,
                  HWND hdlg, LPSTR nickName, LPSTR pathToPPD,
                  WORD wIndex)
{
   WORD wLength;
   HANDLE   pihdl = NULL ;
   int status = RC_fail;
//   HCURSOR cursorh;
   
   // Add a \ at the end -- if necessary 
   wLength = lstrlen(pathToPPD);
   
   if (pathToPPD[wLength-1] != '\\')
   {
      pathToPPD[wLength] = '\\';
      pathToPPD[wLength+1] = NULL;
   }
   
   // Add the PPD file spec 
   lstrcat( pathToPPD, lpPPDNamesStruct[wIndex].PPDFilename );
   
   // Add the new printer. 
   // Chicago begin 
   if (Pscript355OnPortAlready(lpPSExtDevmode->dm.dm.dmDeviceName,
      lppd->szPortName))
   {  /* Upgrading from Pscript to AdobePS */
      if (UpgradeOnePrinter(lppd,
         lpPSExtDevmode->dm.dm.dmDeviceName,
         lppd->szPortName,
         pathToPPD) == TRUE)
      {
         status = PDM_RC_ok;
      }
      else
      {
         status = PDM_RC_fail;
      }
   }
   else
   {  /* Adding a brand new printer */
      /* Chicago end */
#if 0
      pihdl = Ps_EnumOpen( nickName, 0 );
      if (pihdl != 0)
      {
         cursorh = SetCursor(LoadCursor(NULL, IDC_WAIT));
         ShowCursor( TRUE );
         status = Ps_ExtAddPrinter( pihdl, pathToPPD, nickName,
         lppd->szPortName,
         lpPSExtDevmode->dm.dm.dmDeviceName);
         Ps_EnumClose( pihdl );
         ShowCursor(FALSE);
         SetCursor(cursorh);
      }
#endif
   } /* Chicago */
   
   switch (status)
   {
      case PDM_RC_ok :
      {
         //DrvrStringMessageBox( hdlg, ADDPRN_szInstallSuccess, ADDPRN_szInstaller, MB_OK | MB_ICONINFORMATION);
         EndDialog(hdlg, IDOK);
         break;
      }
      case PDM_RC_duplicate :
      {
         DrvrStringMessageBox( hdlg, ADDPRN_szInstallDuplicate, ADDPRN_szInstaller, MB_OK | MB_ICONINFORMATION);
         break;
      }     
      case PDM_RC_fail :
      default :
      {
         DrvrStringMessageBox( hdlg, ADDPRN_szInstallError, ADDPRN_szInstaller, MB_OK | MB_ICONHAND);
         EndDialog(hdlg, IDABORT);
         break;
      }
   } /* switch */
   
   return status;
   
} // END AddThePrinter


/***************************************************************************
*                               FillPPDListBox
*  Purpose:
*
*  Parameters:
*       HWND      hPPDNicknameLB --
*       WORD      wNumOfPPDFiles --
*       LPPDEVICE lppd --
*    
*  Returns: void
*                                                                           
***************************************************************************/
void FillPPDListBox(HWND hPPDNicknameLB,WORD wNumOfPPDFiles,LPPDEVICE lppd)
{
   long        lSize;
   WORD        wIndex;
   LPSTR       NickName;
   static struct  find_t  temp_dir_buffer;
   HCURSOR     hCursor;
   
   // Allocate the buffer for the PPD files.
   
   lSize = wNumOfPPDFiles * sizeof(struct PPDNamesStruct);
   
   // Unlock, Re-Alloc the memory and Lock the new handle.
   MGUnlock( hPPDNamesStruct );
   hPPDNamesStruct = MGReAlloc( lppd, hPPDNamesStruct, lSize, GMEM_ZEROINIT, FALSE );
   
   if ( hPPDNamesStruct == 0 )
   {
      return;
   }
   
   lpPPDNamesStruct = (struct PPDNamesStruct FAR *) MGLock( lppd, hPPDNamesStruct, FALSE );
   
   if ( lpPPDNamesStruct == NULL )
   {
      return ;
   }
   
   /* Change the cursor to an hourglass */
   hCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
   
   SendMessage( hPPDNicknameLB, LB_RESETCONTENT, 0, 0L );
   
   /*Inhibit Redraw */
   SendMessage( hPPDNicknameLB, WM_SETREDRAW, FALSE, 0L );
   
   wIndex = 0;
   if ( l_dos_findfirst(szPPDMask, (_A_NORMAL | _A_RDONLY), &temp_dir_buffer) == 0 )
   {
      do
      {
         NickName = GetPPDNickname(temp_dir_buffer.name);
         if (NickName != NULL)
         {
            /* Save the PPD Filename */
            _fstrncpy( lpPPDNamesStruct[wIndex].PPDFilename,
            temp_dir_buffer.name,
            sizeof(temp_dir_buffer.name) );
            
            /* Terminate */
            lpPPDNamesStruct[wIndex].null_terminate = NULL;
            
            /* Get the Nickname */
            lstrcpy( lpPPDNamesStruct[wIndex].PPDNickname, NickName );
            //Add the nickname to the listbox
            SendMessage( hPPDNicknameLB, LB_ADDSTRING, 0, (LONG) lpPPDNamesStruct[wIndex].PPDNickname );
            wIndex++;
         }
      } while ( l_dos_findnext(&temp_dir_buffer) == 0 );
   } 
   
   /* Redraw the listbox */
   SendMessage( hPPDNicknameLB, WM_SETREDRAW, TRUE, 0L );
   InvalidateRect(hPPDNicknameLB, NULL, TRUE);
   UpdateWindow( hPPDNicknameLB );
   SetCursor(hCursor);
   
} // END FillPPDListBox


/***************************************************************************
*                               UpdateListBox
*  Purpose:
*       Update the AddPrinter Directory and PPD Nickname Listboxes.
*
*  Parameters:
*       LPPDEVICE lppd --
*       HWND      hDlg --
*    
*  Returns: VOID
*                                                                           
***************************************************************************/
VOID FAR UpdateListBox(LPPDEVICE lppd, HWND hDlg)
{              
   HWND hPPDNicknameLB;
   char Directory[MAX_FILEPATH_LEN];
   WORD wNumOfPPDFiles;
   
   GetDlgItemText(hDlg, ID_PPDPATH, Directory, MAX_FILEPATH_LEN);

   // Get a Handle to the PPD Nickname Listbox.
   hPPDNicknameLB = GetDlgItem( hDlg, ID_PPDLIST );
   
   DlgDirList( hDlg, Directory, ID_PPD_DIR_LB, ID_PPDPATH, EXCLUSIVE | DRIVES | SUBDIR);
   
   wNumOfPPDFiles = GetNumPPDFiles();
   
   if ( wNumOfPPDFiles == 0 )
   {
      SendMessage( hPPDNicknameLB, LB_RESETCONTENT, 0, 0L );
   }
   else
   {
      FillPPDListBox( hPPDNicknameLB, wNumOfPPDFiles, lppd );
   }

} // End UpdateListBox


/***************************************************************************
*                               UpdateListBox31
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       HWND      hDlg --
*    
*  Returns: VOID
*                                                                           
***************************************************************************/
VOID FAR UpdateListBox31(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode, HWND hDlg)
{              
   HWND hPPDNicknameLB;
   char Directory[MAX_FILEPATH_LEN];
   WORD wNumOfPPDFiles;
   
   GetDlgItemText(hDlg, stc1, Directory, MAX_FILEPATH_LEN);
   
   // Get a Handle to the PPD Nickname Listbox.
   hPPDNicknameLB = GetDlgItem( hDlg, lst3 );
   
   wNumOfPPDFiles = GetNumPPDFiles();
   
   if ( wNumOfPPDFiles == 0 )
   {
      SendMessage( hPPDNicknameLB, LB_RESETCONTENT, 0, 0L );
   }
   else
   {
      FillPPDListBox( hPPDNicknameLB, wNumOfPPDFiles, lppd );
      
      /* Highlight the right one if it exists */
      if (SendDlgItemMessage(hDlg, lst3, LB_SELECTSTRING, (WPARAM)-1,
              (LPARAM)(LPSTR)(lpPSExtDevmode->dm.dm.dmDeviceName)) != LB_ERR)
      {
         SendDlgItemMessage(hDlg, lst2, LB_SETCURSEL, (UINT)-1, 0);
         SetFocus(GetDlgItem(hDlg, lst3));
      }
   }
} // END UpdateListBox31


/***************************************************************************
*                               AddPrinterHookProc
*  Purpose:
*
*  Parameters:
*       HWND   hDlg --
*       UINT   msg --
*       WPARAM wParam --
*       LPARAM lParam --
*    
*  Returns: UINT
*                                                                           
***************************************************************************/
UINT CALLBACK AddPrinterHookProc(HWND hDlg, UINT msg, WPARAM wParam,
                                 LPARAM lParam)
{
   LPPDEVICE lppd = NULL;
//   LPDRVSTATE lpDrvState = NULL;
   OPENFILENAME FAR *lpOfn;
   LPPSEXTDEVMODE lpPSExtDevmode = NULL;

   int    status;
   int    CurSel;
   WORD   wNumOfPPDFiles;
   WORD   wIndex;
   char   tmpstring[MAX_WIN_PATH];
   char   szPrinterHelp[80];
   char   nickName[MAX_NICKNAME_LEN];
   char   cPPDname[MAX_PPD_NICKNAME_LEN];
   LPSTR  lpNickName;
   LPDRIVERINFO lpDrvInfo;
   
   /* Process hook function stuff */
   if (msg == WM_INITDIALOG)
     {
     lpOfn = (OPENFILENAME FAR *)lParam;
     lpDrvInfo = (LPDRIVERINFO)(lpOfn->lCustData);
     SetWindowLong(hDlg, DWL_USER, (LONG)lpDrvInfo);
     }
   else
     {
     lpDrvInfo = (LPDRIVERINFO)GetWindowLong(hDlg, DWL_USER);
     }

   if (lpDrvInfo != NULL)
     {
     lppd = &lpDrvInfo->pDev;
     lpPSExtDevmode = lpDrvInfo->lpDM;
     }

   switch (msg)
   {
      case WM_INITDIALOG:
         lppd = &lpDrvInfo->pDev;
//         lpDrvState = lpDrvInfo->lpDrvState;
         lpPSExtDevmode = lpDrvInfo->lpDM;
         
         /***** Center the Dialog *****/
         CenterPopup( hDlg, GetParent(hDlg) );
         
         /* Get the current drive & directory */
         _getcwd( szPathBuffer, MAX_WIN_PATH );
         _dos_getdrive( &wDriveNum );
         
         status = RC_ok ;
         lpPPDNamesStruct = (struct PPDNamesStruct FAR *)MGAllocLock(lppd,
                            &hPPDNamesStruct, sizeof(struct PPDNamesStruct), GHND, FALSE );
         if (!lpPPDNamesStruct)
         {
            status = RC_fail;
         }
         
         if (status != RC_ok)
         {
            iStdOpenFileRetCode = IDABORT;
            EndDialog(hDlg, IDABORT);
            
            /* Reset lppd */
            lppd = NULL;
            return (TRUE);
         }
         else  //Initialize controls.
         {
            LoadDrvrString(ghDriverMod, ADDPRN_szPPDMask, szPPDMask, sizeof(szPPDMask));
            
            tmpstring[sizeof(tmpstring)-1] = 0 ;  //Ensure string termination.
            
            /* Update the Window caption */
            GetDlgItemText(hDlg, stc5, tmpstring, MAX_WIN_PATH);
            lstrcat(tmpstring, lpPSExtDevmode->dm.dm.dmDeviceName);
            SetDlgItemText(hDlg, stc5, tmpstring);
            
            UpdateListBox31(lppd,lpPSExtDevmode, hDlg);
         }
         
         ShowWindow(GetDlgItem(hDlg, edt1), SW_HIDE);
         ShowWindow(GetDlgItem(hDlg, lst1), SW_HIDE);
         ShowWindow(GetDlgItem(hDlg, stc2), SW_HIDE);
         ShowWindow(GetDlgItem(hDlg, cmb1), SW_HIDE);
         ShowWindow(GetDlgItem(hDlg, chx1), SW_HIDE);
         break;
      
      case WM_REFRESH:
         UpdateListBox31(lppd, lpPSExtDevmode, hDlg);
         return (TRUE);
         break;
      
      case WM_ACTIVATE:
         if (wParam != WA_INACTIVE)
           {  /* Being activated */
           /* Set the help topic */
           lppd->iHelpContext = IDM_HELP_ADD_PRINTER_DLG;
           }
         else
           {  /* Being deactivated */
           /* Reset the help topic */
           lppd->iHelpContext = IDM_HELP_NO_TOPIC;
           }
         break;
      
      case WM_COMMAND:
         switch (wParam)
         {
            case cmb2:
               switch(HIWORD(lParam))
               {
                  case CBN_SELCHANGE:
                     SendDlgItemMessage(hDlg, lst3, LB_SETCURSEL, (UINT)-1, 0);
                     PostMessage(hDlg, WM_COMMAND, IDOK, 0);
                     break;
               }
               break;

            case lst2: /* Directories list box */
               switch(HIWORD(lParam))
               {
                  case LBN_DBLCLK:
                     PostMessage(hDlg, WM_COMMAND, IDOK, 0);
                     break;
                  case LBN_SELCHANGE:
                     SendDlgItemMessage(hDlg, lst3, LB_SETCURSEL, (UINT)-1, 0);
                     break;
               }
               break;

            case lst3: /* Printer description list box */
               switch(HIWORD(lParam))
               {
                  case LBN_DBLCLK:
                     PostMessage(hDlg, WM_COMMAND, IDOK, 0);
                     break;
                  case LBN_SELCHANGE:
                     SendDlgItemMessage(hDlg, lst2, LB_SETCURSEL, (UINT)-1, 0);
                     break;
               }
               break;
      
            case IDOK:
               lpNickName = nickName;
               /* Check to see if a PPD File has been selected */
               CurSel = (WORD) SendDlgItemMessage(hDlg, lst3, LB_GETCURSEL, 0, 0L);
               if (CurSel == LB_ERR)
               {
                  PostMessage(hDlg, WM_REFRESH, 0, 0);
               }
               else
               {
                  BOOL bPerformAddPrinter;
                  
                  wNumOfPPDFiles = GetNumPPDFiles();
                  SendDlgItemMessage(hDlg, lst3, LB_GETTEXT, CurSel, (LONG) (LPSTR) cPPDname);
                  GetDlgItemText(hDlg, stc1, tmpstring, MAX_FILEPATH_LEN);
                  
                  bPerformAddPrinter = TRUE;
                  if (lstrcmp(cPPDname, lpPSExtDevmode->dm.dm.dmDeviceName) != 0)
                  {  /* User chose a different PPD */
                     char strBuff[128], title[16];
                     
                     LoadString(ghDriverMod, ADDPRN_szWarning, title, sizeof(title));
                     LoadString(ghDriverMod, ADDPRN_szNoPPDMatch, strBuff, sizeof(strBuff));
                     if (MessageBox(hDlg, strBuff, title, MB_OKCANCEL|MB_ICONQUESTION) != IDOK)
                     {
                        bPerformAddPrinter = FALSE;
                     }
                  }
                  
                  if (bPerformAddPrinter)
                  {  /* Add the printer */
                     /* Make the nickname -jmk */
/* cylon1                     GetNextNickName(lpPSExtDevmode);
                     lstrcpy(nickName, lpDrvState->zNickName); */
                     
                     /* Cycle through the PPD files to find a match */
                     for ( wIndex = 0; wIndex < wNumOfPPDFiles; wIndex++ )
                     {
                        if (lstrcmp(lpPPDNamesStruct[wIndex].PPDNickname, cPPDname)==0)
                        {
                           AddThePrinter(lppd, lpPSExtDevmode, hDlg, lpNickName, tmpstring, wIndex ); /* Chicago */
                           break;
                        }
                     }
                     
                     if ( wIndex == wNumOfPPDFiles )
                     {
                        DrvrStringMessageBox( hDlg, ADDPRN_szInstallError, ADDPRN_szInstaller, MB_OK | MB_ICONHAND);
                        iStdOpenFileRetCode = IDABORT;
                        EndDialog(hDlg, IDABORT);
                        
                        /* Reset lppd */
                        lppd = NULL;
                        return (TRUE);
                     }
                     else
                     {
                        iStdOpenFileRetCode = IDOK;
                        EndDialog(hDlg, IDOK);
                        
                        /* Reset lppd */
                        lppd = NULL;
                        return (TRUE);
                     }
                  }
                  else
                  {  /* Don't add the printer */
                  
                     /* Reset lppd */
                     lppd = NULL;
                     return (TRUE);
                  }
               } /* End else if no PPD selection */
               break;
      
            case IDCANCEL:
               iStdOpenFileRetCode = IDCANCEL;
               EndDialog( hDlg, IDCANCEL );
               
               if (lpDrvInfo->fHelp)
               {
                  if (CheckHelpFile(hDlg) == TRUE)
                  {
                     WinHelp(hDlg, szHelpFile, HELP_QUIT, 0L);
                  }
               }
               
               /* Reset lppd */
               lppd = NULL;
               break;
      
            case ID_HELP:
               if (CheckHelpFile(hDlg) == TRUE)
               {
                  LoadDrvrString(ghDriverMod, ADDPRN_szPrinterHelp, szPrinterHelp, sizeof(szPrinterHelp));
                  lpDrvInfo->fHelp = WinHelp(hDlg, szHelpFile, HELP_KEY, (DWORD)(LPSTR)szPrinterHelp);
               }
               break;
         } // End switch
         break; // End WM_COMMAND
      
      case WM_DESTROY:
         if (lpPPDNamesStruct)
         {
            MGUnlockFree(lppd, hPPDNamesStruct, FALSE);
         }
         
         lpPPDNamesStruct = NULL;
         hPPDNamesStruct = 0;
         
         /***** Return to the default drive and directory *****/
         if ( szPathBuffer )
         {
            _chdrive( wDriveNum );
            _chdir( szPathBuffer );
         }
         break;

   } /* End switch (msg) */
   
   return (FALSE);
   
} // END AddPrinterHookProc


/***************************************************************************
*                               AddPPDFile
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd --
*       HWND      hDlg --
*       LPSTR     lpPathToPPD --
*       LPSTR     lpszDevType --
*    
*  Returns: BOOL
*       TRUE if found the proper printer PPD, else returns FALSE.
* 
*  Note:
*       Accepts lpPathToPPD C:\WIN31\SYSTEM (all caps, no slash at the end,
*       lpszDevType is string from OEMSETUP.INF).
*                                                                           
***************************************************************************/
BOOL AddPPDFile(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode, HWND hDlg, LPSTR lpPathToPPD, LPSTR lpszDevType)
{
   LPSTR   lpPPDDevType;
//   char    nickName[MAX_NICKNAME_LEN];
   HCURSOR hCursor;
   BOOL    done, retVal;
   static struct  find_t  temp_dir_buffer;
   
   // Initialize 
   retVal = FALSE;
   done = FALSE;
   LoadDrvrString(ghDriverMod, ADDPRN_szPPDMask, szPPDMask, sizeof(szPPDMask));
   
   // Save the old dir and change to the new one 
   _getcwd( szPathBuffer, MAX_WIN_PATH );
   _dos_getdrive( &wDriveNum );
   
   lstrcpy(szPathBuffer2, lpPathToPPD);
   _chdrive((int)(szPathBuffer2[0] - 'A' + 1)); // GetWindowsSystem returns caps 
   _chdir(szPathBuffer2);
   
   // Change the cursor to an hourglass
   hCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
   
   // Go through the files to find the right one 
   if (l_dos_findfirst(szPPDMask,(_A_NORMAL | _A_RDONLY),&temp_dir_buffer)==0)
   {
      do
      {
         lpPPDDevType = GetPPDNickname(temp_dir_buffer.name);
         
         if (lpPPDDevType != NULL)
         {
            if (lstrcmp(lpPPDDevType, lpszDevType) == 0)
            {  // Found the right one, must add the printer 
               HANDLE pihdl = NULL;
               int status = RC_fail;
               
               done = TRUE;
               retVal = TRUE;
               
/* cylon1               GetNextNickName(lpPSExtDevmode);
               lstrcpy(nickName, lpDrvState->zNickName); */
               
               // Construct fully qualified path of PPD file 
               lstrcpy(szPathBuffer2, lpPathToPPD);
               lstrcat(szPathBuffer2, "\\");
               lstrcat(szPathBuffer2, temp_dir_buffer.name);
               
               // Add the new printer.
               // Chicago begin
               if (Pscript355OnPortAlready(lpPSExtDevmode->dm.dm.dmDeviceName,
                  lppd->szPortName))
               {  // Upgrading from Pscript to AdobePS 
                  if (UpgradeOnePrinter(lppd,
                     lpPSExtDevmode->dm.dm.dmDeviceName,
                     lppd->szPortName,
                     szPathBuffer2) == TRUE)
                  {
                     status = PDM_RC_ok;
                  }
                  else
                  {
                     status = PDM_RC_fail;
                  }
               }
               else
               {  // Adding a brand new printer 
                  // Chicago end
#if 0
                  pihdl = Ps_EnumOpen( nickName, 0 );
                  if (pihdl != 0)
                  {
                     status = Ps_ExtAddPrinter(pihdl, szPathBuffer2, nickName,
                     lppd->szPortName,
                     lpPSExtDevmode->dm.dm.dmDeviceName);
                     Ps_EnumClose( pihdl );
                  }
#endif
               } // Chicago 
               
               // Figure out the result 
               switch (status)
               {
                  case PDM_RC_ok:
                     //DrvrStringMessageBox( hDlg, ADDPRN_szInstallSuccess, ADDPRN_szInstaller, MB_OK | MB_ICONINFORMATION);
                     retVal = TRUE;
                     break;
                  case PDM_RC_duplicate:
                     DrvrStringMessageBox( hDlg, ADDPRN_szInstallDuplicate, ADDPRN_szInstaller, MB_OK | MB_ICONINFORMATION);
                     retVal = TRUE;
                     break;
                  case PDM_RC_fail:
                  default:
                     DrvrStringMessageBox( hDlg, ADDPRN_szInstallError, ADDPRN_szInstaller, MB_OK | MB_ICONHAND);
                     retVal = FALSE;
                     break;
               } // switch 
            } // Found the printer
         }
      } while (!done && l_dos_findnext(&temp_dir_buffer) == 0 );
   }
   
   // Restore the old disk drive and dir 
   _chdrive( wDriveNum );
   _chdir( szPathBuffer );
   
   SetCursor(hCursor);
   
   return (retVal);

} // END AddPPDFile

/***************************************************************************
*                               GetNumPPDFiles
*  Purpose:
*       This routine returns the total number of PPD files in the current
*       directory.
*
*  Parameters:
*       VOID
*    
*  Returns: WORD
*                                                                           
***************************************************************************/
WORD GetNumPPDFiles( VOID )
{         
   static struct  find_t  temp_dir_buffer;
   WORD   wNumPPDFiles;
   
   // Init Number of files 
   wNumPPDFiles = 0;
   LoadDrvrString(ghDriverMod, ADDPRN_szPPDMask, szPPDMask, sizeof(szPPDMask));
   
   if (l_dos_findfirst(szPPDMask, _A_NORMAL | _A_RDONLY, &temp_dir_buffer)==0)
   {
      do
      {
         wNumPPDFiles++;
      } while( l_dos_findnext(&temp_dir_buffer) == 0 );
   }
   
   return (wNumPPDFiles);
   
} // End GetNumPPDFiles


/***************************************************************************
*                               GetPPDNickname
*  Purpose:
*
*  Parameters:
*       LPSTR FilePathToPPD --
*    
*  Returns: LPSTR
*
*  Note:
*       This function was pirated from ParsePPD() in the Enumerator.
*                                                                           
***************************************************************************/
LPSTR GetPPDNickname(LPSTR FilePathToPPD)
{
   char buff2[MAX_PPD_NICKNAME_LEN]; //this is what is being
                                     //returned.  It should
                                     //have a st address
   int    fd2;
   short  count, ptr1;
   char   buffer[MAX_PPD_NICKNAME_LEN];
   LPSTR  lpNickname;
   char   szNickname[20];
   char   szShortNickname[20];
   char   szModelName[20]; /* Chicago */
   char   szInclude[20];
   
   char   szNicknameVal[40];
   char   szShortNicknameVal[40];
   char   szModelNameVal[40]; /* Chicago */
   
   // OPEN THE .PPD FILE 
   fd2 = _lopen(FilePathToPPD, OF_READ);

   if (fd2 < 0)
   {
      return (NULL);
   }
   
   /* INITIALIZE BUFFERS AND POINTERS TO READ THE .PPD */
   ptr1 = 0;
   count = _lread( fd2, buffer, PS_FILE_PATH_LENGTH);
   LoadDrvrString(ghDriverMod, ADDPRN_szNickName, szNickname, sizeof(szNickname));
   LoadDrvrString(ghDriverMod, ADDPRN_szShortNickName, szShortNickname, sizeof(szNickname));
   LoadDrvrString(ghDriverMod, ADDPRN_szModelName, szModelName, sizeof(szModelName)); /* Chicago */
   LoadDrvrString(ghDriverMod, ADDPRN_szInclude, szInclude, sizeof(szInclude));
   
   szNicknameVal[0]  = szShortNicknameVal[0] = 
   szModelNameVal[0] = '\0' ;  // init all values to null strings
   
   
   /* LOOP READING ALL THE LINES IN THE PPD */
   while (! GetNextPPDLine(buffer, buff2, &count, &ptr1, fd2) )
   {
      if (buff2[0] == '*')
      {
         if(!szShortNicknameVal[0] &&
            !_fstrncmp(szShortNickname, buff2, lstrlen(szShortNickname)))
         {
            lpNickname = ExtractNickname( buff2 );
            _fstrncpy(szShortNicknameVal, lpNickname, 32 );
         }
         else if (!szModelNameVal[0]     &&  
            !_fstrncmp(szModelName, buff2, lstrlen(szModelName)))
         {
            lpNickname = ExtractNickname( buff2 );
            _fstrncpy(szModelNameVal, lpNickname, 32 );
         }
         else if ( !szNicknameVal[0] &&  
            !_fstrncmp(szNickname, buff2, lstrlen(szNickname)))
         {
            lpNickname = ExtractNickname( buff2 );
            _fstrncpy(szNicknameVal, lpNickname, 32 );
         }
         // else if (!_fstrncmp(szInclude, buff2, lstrlen(szInclude)))  //This makes me nervous.  What if the nickname is in an included file?
         //       continue ;
      } /* End IF (buff2[0] == '*') */
   } /* End WHILE */

   _lclose(fd2);
   
   if(szShortNicknameVal[0])
   {
      szShortNicknameVal[32] = '\0' ;
      _fstrcpy(buff2, szShortNicknameVal);
   }
   else if(szModelNameVal[0])
   {
      szModelNameVal[32] = '\0' ;
      _fstrcpy(buff2, szModelNameVal);
   }
   else if(szNicknameVal[0])
   {
      szNicknameVal[32] = '\0' ;
      _fstrcpy(buff2, szNicknameVal);
   }
   else
   {
      return(NULL) ;
   }
   
   return ((LPSTR)buff2);
   
} // END GetPPDNickname



/***************************************************************************
*                               GetNextPPDLine
*  Purpose:
*       Parse one PPD file.  This function is recursive so a PPD can have
*       included files and they will be parsed also.
*
*  Parameters:
*       char  FAR *buffer --
*       char  FAR *buff2 --
*       short FAR *cnt --
*       short FAR *p1 --
*       int       fd2 --
*    
*  Returns: short
*
*  Note:
*       This function was pirated from GetNextLine() in the Enumerator.
*                                                                           
***************************************************************************/
short GetNextPPDLine(char FAR *buffer, char FAR *buff2, short FAR *cnt,
                     short FAR *p1, int fd2)
{
   short  ptr1, ptr2, count;

   ptr1 = *p1;
   count = *cnt;

   if (count == 0)
   {
      return -1;
   }

   do 
   {
      ptr2 = 0;
      while (buffer[ptr1] >= 32 || buffer[ptr1] == 9 /* TABS are OK */ ) 
      {
         buff2[ptr2++] = buffer[ptr1++];
         if (ptr1 == count) 
         {
            count = _lread(fd2, buffer, PS_FILE_PATH_LENGTH);
            if (count == 0) 
            {
               buff2[ptr2] = 0;
               *p1 = ptr1;
               *cnt = count;
               return 0;
            }
            ptr1 = 0;
         }
      }

      while (buffer[ptr1] < 32) 
      {
         ptr1 ++;
         if (ptr1 == count) 
         {
            count = _lread(fd2, buffer, PS_FILE_PATH_LENGTH);
            if (count == 0) 
            {
               buff2[ptr2] = 0;
               *p1 = ptr1;
               *cnt = count;
               return 0;
            }
            ptr1 = 0;
         }
      }
      buff2[ptr2++] = 0;
   } while (lstrlen(buff2) == 0);

   *p1 = ptr1;
   *cnt = count;

   return 0;

} // END GetNextPPDLine


/***************************************************************************
*                               ExtractNickname
*  Purpose:
*       Returns PPD Nickname.
*
*  Parameters:
*       LPSTR linebuf --
*    
*  Returns: LPSTR
*
*  Note:
*       This function was pirated from PPDBinAddKeywordLine() in the Enumerator.
*                                                                           
***************************************************************************/
LPSTR ExtractNickname( LPSTR  linebuf )
{       
   LPSTR  lpNickname;
   LPSTR  wrkstring;
   LPSTR  colon_loc;
   LPSTR  post_colon_string;
   WORD   wCount;
   
   
   if (linebuf[0] == '*')
   {
      wrkstring = &linebuf[1];
      colon_loc = _fstrchr(wrkstring, ':');
      
      if (colon_loc)
      {
         post_colon_string = colon_loc + 1;
         
         //--------------------------------------------------------------
         // Extract the Nickname field
         //--------------------------------------------------------------
         
         /* Remove any beginning spaces */
         lpNickname = SkipStr( post_colon_string, " " );
         
         /* Remove any beginning Tabs */
         lpNickname = SkipStr( lpNickname, "\t" );
         
         /* String must be enclosed in quotes to be valid */
         if (lpNickname[0] != '\"')
         {
            return (NULL);
         }
         
         /* Remove any beginning quotes */
         lpNickname = SkipStr( lpNickname, "\"" );
         
         /* Remove Ending quote */
         wCount = _fstrcspn( lpNickname, "\"" );

         /* String must be enclosed in quotes to be valid */
         if (lpNickname[wCount] != '\"')
         {
            return (NULL);
         }
         else
         {
            lpNickname[wCount] = 0;
         }
         
         if (lpNickname[0])
         {
//            ConvertTranslation(lpNickname);
            return( lpNickname );
         }
         else
         {
            return( NULL );
         }
      } /* End IF (colon_loc) */
   } /* End IF (linebuf[0] == '*') */

   return( NULL );

} // End ExtractNickname


/***************************************************************************
*                               SkipStr
*  Purpose:
*       This function skips past 'white' characters in a string.
*
*  Parameters:
*       LPSTR s -- pointer to string that may contain white characters
*       LPSTR white_chars -- pointer to string defining white characters
*    
*  Returns: LPSTR
*       Updated string pointer pointing to first non-white character in
*       original string.
*
*  Note:
*       This function was pirated from strskip() in the Enumerator.
*                                                                           
***************************************************************************/
LPSTR FAR PASCAL SkipStr(LPSTR s, LPSTR white_chars)

{ 
   while (_fstrchr(white_chars, (*s)) && (*s))
   {
      s++ ;
   }

   return(s) ;

} // End SkipStr
