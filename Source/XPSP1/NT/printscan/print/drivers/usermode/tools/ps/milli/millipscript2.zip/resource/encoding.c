/*
 * encoding.c
 *
 * $Header:   L:/PVCS/PS40/PSCRIPT/RESOURCE/ENCODING.C_V   1.7   27 Mar 1995 11:23:06   olegsher  $
 * 
 * Copyright (c) 1989-1991 Adobe Systems Incorporated.
 * All rights reserved.
 *
 * This file may be freely copied and redistributed as long as:
 *   1) This entire notice continues to be included in the file, 
 *   2) If the file has been modified in any way, a notice of such
 *      modification is conspicuously indicated.
 *
 * PostScript, Display PostScript, and Adobe are registered trademarks of
 * Adobe Systems Incorporated.
 * 
 * ************************************************************************
 * THE INFORMATION BELOW IS FURNISHED AS IS, IS SUBJECT TO CHANGE WITHOUT
 * NOTICE, AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY ADOBE SYSTEMS
 * INCORPORATED. ADOBE SYSTEMS INCORPORATED ASSUMES NO RESPONSIBILITY OR 
 * LIABILITY FOR ANY ERRORS OR INACCURACIES, MAKES NO WARRANTY OF ANY 
 * KIND (EXPRESS, IMPLIED OR STATUTORY) WITH RESPECT TO THIS INFORMATION, 
 * AND EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR PARTICULAR PURPOSES AND NONINFINGEMENT OF THIRD PARTY RIGHTS.
 * ************************************************************************
 * 
 * $Log:   L:/PVCS/PS40/PSCRIPT/RESOURCE/ENCODING.C_V  $
 *- |
 *- |   Rev 1.7   27 Mar 1995 11:23:06   olegsher
 *- |Merged with Microsoft codedrop 03/20/95.
 *- |
 *- |   Rev 1.0   28 Jul 1993 15:08:08   JKEEFE
 *- |Initial revision.
 *- |
 *- |   Rev 3.0   05 Aug 1992 15:38:38   JKEEFE
 *- |Initial revision.
 *- |
 *- |   Rev 1.0   23 Oct 1991 14:44:24   jdlh
 *- |Initial revision.
 *
 */

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "tokens.h"
#include "encoding.h"

#ifndef FP_IS_IEEE
#define FP_IS_IEEE  1
#endif  /* FP_IS_IEEE */

#ifndef HIGH_BYTE_FIRST
#define HIGH_BYTE_FIRST 1
#endif  /* HIGH_BYTE_FIRST */

typedef struct _t_LoopHole {
  union {
    float   real;
    unsigned long rawBits;
  } value;
} LoopHole;

int  ieeeFormat = true;
int  highByteFirst = HIGH_BYTE_FIRST;
int  fBinary = false;
int  fLevel2 = false;

char *stringStorage = NULL;
char *stringPointer = NULL;
long stringLength = 0;

char szNumber[100];     /* Storage for ASCII form of number */

/* Information for formatting output */
#define cbLineMax 78       /* Maximum bytes on a line */

unsigned long cbLine = 0;   /* Current width of line */
int fDelimPrevToken = true; /* True if last token sent was delimiting */



/* Local functions */
void    EncodeIntegerBinary (long integer);
size_t  cbIntegerBinary( long integer);
void    EncodeRealBinary( float real );
size_t  cbRealBinary( float real );
size_t  cbDelimCbF  ( size_t cbDesired, int fPreDelim );
void    SendDelimCbF( size_t cbDesired, int fPreDelim );
unsigned long
        lcbStringLiteralPchCchF( char *pch, size_t cch, int fBinary );
size_t  cbLiteralChF( unsigned char ch, int fBinary );
void    SendLiteralChF( unsigned char ch, int fBinary );


void EncodeInteger (integer)
  long integer;
 /*
  */
{
    size_t cbASCII, cbBinary;   /* Lengths of ASCII and binary encodings */
    size_t cbDelim;             /* Cost of delimiter before token */

    cbASCII  = sprintf( szNumber, "%ld", integer );
    cbBinary = cbIntegerBinary( integer );

    cbDelim  = cbDelimCbF( cbASCII, false );

    /* Now encode the integer */
    switch (iOperation) {

    case OP_STATISTICS:
    case OP_EMIT:
    default:
        if ( (cbBinary < cbDelim + cbASCII) && fLevel2 && fBinary ) {
            if (iOperation == OP_EMIT) {
                EncodeIntegerBinary( integer );
            }
            rgcbOut[ SC_NUMBERS ] += cbBinary;
            cbLine += cbBinary;
            fDelimPrevToken = true;
        } else {
            SendDelimCbF( cbASCII, false );
            if (iOperation == OP_EMIT) {
                printf( "%ld", integer );
            }
            rgcbOut[ SC_NUMBERS ] += cbASCII;
            cbLine += cbASCII;
            fDelimPrevToken = false;
        };
        break;

    case OP_TOKENSEQ:
        if (fSubstGeneric)
            printf( "%0*d", (int)cbASCII, 0 );  /* emit string of zeros */
        else
            printf( "%ld", integer );
        printf( "\n" );
        break;

    }

    TRACE(( "\nEncodeInteger: cbBinary %ld, cbASCII %ld, cbDelim %ld\n",
        (unsigned long)cbBinary, (unsigned long)cbASCII, 
        (unsigned long)cbDelim                                        ));
    TRACE(( "  rgcbOut[SC_NUMBERS] %ld.\n", (unsigned long)rgcbOut[SC_NUMBERS]));

    return;
}

void EncodeReal (float real)
 /*
   Encoding of reals depends on the native floating point for the machine
   executing this program.  If it is an IEEE machine, no real conversion is
   required, regardless of whether IEEE or native format tokens are requested.
   If the machine is not an IEEE machine, conversion of reals to IEEE format
   is required if IEEE format tokens are requested.
  */
{
    size_t cbASCII, cbBinary;   /* Lengths of ASCII and binary encodings */
    size_t cbDelim;             /* Cost of delimiter before token */

    cbASCII  = sprintf( szNumber, "%g", real );
    cbBinary = cbRealBinary( real );

    cbDelim  = cbDelimCbF( cbASCII, false );

    /* Now encode the integer */
    switch (iOperation) {

    case OP_STATISTICS:
    case OP_EMIT:
    default:
        if ( (cbBinary < cbDelim + cbASCII) && fLevel2 && fBinary ) {
            if (iOperation == OP_EMIT) {
                EncodeRealBinary( real );
            }
            rgcbOut[ SC_NUMBERS ] += cbBinary;
            cbLine += cbBinary;
            fDelimPrevToken = true;
        } else {
            SendDelimCbF( cbASCII, false );
            if (iOperation == OP_EMIT) {
                printf( "%g", real );
            }
            rgcbOut[ SC_NUMBERS ] += cbASCII;
            cbLine += cbASCII;
            fDelimPrevToken = false;
        };
        break;

    case OP_TOKENSEQ:
        if (fSubstGeneric)
            printf( "%0*d.", (int)(cbASCII-1), 0 );
        else
            printf( "%g", real );
        printf( "\n" );
        break;

    }

    TRACE(( "\nEncodeReal: cbBinary %ld, cbASCII %ld, cbDelim %ld\n",
        (unsigned long)cbBinary, (unsigned long)cbASCII, 
        (unsigned long)cbDelim                                        ));
    TRACE(( "  rgcbOut[SC_NUMBERS] %ld.\n", (unsigned long)rgcbOut[SC_NUMBERS]));

    return;

}

void EncodeName (type, name)
  int type;
  char *name;
 /*
   Look for name in the systemname table.  If present, send the encoded form
   unless an immediately evaluated name is required.  Unencoded executable
   names are preceded by a space.  This avoids bookkeeping to record whether
   the name needs to be explicitly separated from the preceding token.
  */
{
#define cbNameBinary 2      /* length of a binary token encoded name */

    int  index      = MapName (name);
    size_t  cbName  = strlen( name );
    size_t  cbDelim;
    int  fUseIndex  = ( fLevel2 && fBinary && (index >= 0) );

    if (iOperation == OP_TOKENSEQ) {
        switch (type) {

        case LITERALNAME:
            printf( "%s/\n", name );
            break;


        case SELFDELIMNAME:
        case EXECUTABLENAME:
            printf( "%s\n", name );
            break;

        case IMMEDIATENAME:
            printf( "%s//\n", name );
            break;

        default:
            FatalError("Unknown name type %d\n", type);
            break;

        }

    } else {

        switch (type) {

        case LITERALNAME:
            cbName += 1;    /* Allow for '/' */
            cbDelim = cbDelimCbF( cbName, true );
            if (fUseIndex && (cbDelim + cbName > cbNameBinary)) {
                if (iOperation == OP_EMIT) {
                    putchar (145);
                    putchar (index);
                }
                rgcbOut[ SC_NAMES ] += cbNameBinary;
                cbLine += cbNameBinary;
                fDelimPrevToken = true;
            } else {
                SendDelimCbF( cbName, true );
                if (iOperation == OP_EMIT) 
                    printf ("/%s", name);
                rgcbOut[ SC_NAMES ] += cbName;
                cbLine += cbName;
                fDelimPrevToken = false;
            }
            break;
      
        case EXECUTABLENAME:
            cbDelim = cbDelimCbF( cbName, false );
            if (fUseIndex && (cbDelim + cbName > cbNameBinary)) {
                if (iOperation == OP_EMIT) {
                    putchar (146);
                    putchar (index);
                }
                rgcbOut[ SC_NAMES ] += cbNameBinary;
                cbLine += cbNameBinary;
                fDelimPrevToken = true;
            } else {
                SendDelimCbF( cbName, false );
                if (iOperation == OP_EMIT) 
                    printf ("%s", name);
                rgcbOut[ SC_NAMES ] += cbName;
                cbLine += cbName;
                fDelimPrevToken = false;
            }
            break;
      
        case IMMEDIATENAME:
            cbName += 2;        /* Allow for '//' */
            cbDelim = cbDelimCbF( cbName, true );
            if (!fBinary)
                SendDelimCbF( cbName, true );
            if (iOperation == OP_EMIT)
                printf ("//%s", name);
            rgcbOut[ SC_NAMES ] += cbName;
            cbLine += cbName;
            fDelimPrevToken = false;
            break;
      
        case SELFDELIMNAME:
            cbDelim = cbDelimCbF( cbName, true );
            if (!fBinary)
                SendDelimCbF( cbName, true );
            if (iOperation == OP_EMIT)
                printf ("%s", name);
            rgcbOut[ SC_NAMES ] += cbName;
            cbLine += cbName;
            fDelimPrevToken = true;
            break;
      
        default:
            FatalError ("Unknown name type %d\n", type);
            break;
        }
    }

    TRACE(( "\nEncodeName: cbName %ld, cbDelim %ld, index %d, fUseIndex %d.",
        (unsigned long)cbName, (unsigned long)cbDelim,
        index, fUseIndex                                          ));
}

void BeginStringEncoding()
 /*
   Initalise string pointer and count, checking first to ensure that no
   previous string is unterminated.  This would be a failure in the parsing
   code.
  */
{
  assert (stringPointer == NULL);

  stringPointer = stringStorage;
  stringLength = 0;
}

void EndStringEncoding ()
 /*
   Write encoded string to output.  Check first that a string is actually
   being built and that its length remains within bounds.
  */
{
    unsigned long cbLiteral;
    unsigned long cbHex     = 1 + (stringLength * 2) + 1;
    unsigned long cbBinary  = ((stringLength < 256) ? 2 : 3) + stringLength;
    size_t cbLiteralDelim, cbHexDelim;
    char *pb = stringStorage;       /* utility pointer to string */

    assert ((stringPointer != NULL) && (stringLength <= MAXSTRING));

    if (iOperation == OP_TOKENSEQ) {
        printf("(");
        while( stringLength-- > 0 ) {
            if (fSubstGeneric) {
                printf( "x" );
            } else {
                    SendLiteralChF( *pb++, false );
            }
        } /* while */
        printf(")");
        printf( "\n" );

    } else {    /* iOperation == OP_EMIT or OP_STATISTICS */

        /* Calculate length of string in literal, hex, and binary forms. */
        cbLiteral = lcbStringLiteralPchCchF( 
                            pb, (size_t)stringLength, fBinary );
        if (cbLiteral <= cbLineMax) {
            cbLiteralDelim   = cbDelimCbF( (size_t)cbLiteral, true );
        } else {
            /* String is too long to fit on one line: calculate number
             * of escaped newlines necessary.  
             * One escaped newline takes 1 byte for '\', plus cbEOL.
             * Wrap long strings by putting as much as possible on this
             * line (cbLineMax - cbLine - 1, allowing for '\'), then
             * filling remaining lines (cbLineMax - 1 each, allowing for
             * '\').
             */
            cbLiteralDelim   = (1+cbEOL);
            cbLiteralDelim  *=   (cbLiteral - (cbLineMax - cbLine - 1)) 
                               % (cbLineMax - 1);
        };

        /* cbHex and cbBinary computed above. */
        if (cbHex <= cbLineMax) {
            cbHexDelim = cbDelimCbF( (size_t) cbHex, true );
        } else {
            /* String is too long to fit on one line; calculate number 
             * of newlines necessary.
             * Each newline takes cbEOL bytes (no escape necessary).
             * Wrap long strings by putting as much as possible on this
             * line (cbLineMax - cbLine), then filling remaining lines
             * (cbLineMax each).
             */
            cbHexDelim = cbEOL*(
                         (size_t)(cbHex - (cbLineMax - cbLine)) % cbLineMax );
        }

        TRACE(( "\nEndStringEncoding: cbLiteral %ld + %ld, cbHex %ld + %ld, cbBinary %ld\n",
            (unsigned long)cbLiteral, (unsigned long) cbLiteralDelim,
            (unsigned long)cbHex, (unsigned long) cbHexDelim,
            (unsigned long)cbBinary                                     ));


        /* Now choose which encoding to use, and send the string. */

        if (fBinary && fLevel2 && (cbBinary < (cbLiteral + cbLiteralDelim))) {
            
            /* Use the binary encoding of the string. */

            if (iOperation == OP_EMIT) {
                if (stringLength < 256) {
                  putchar (142);
                  putchar ((unsigned char)stringLength);
                } else if (highByteFirst) {
                  putchar (143);
                  putchar ((unsigned char)((stringLength >> 8) & 0377));
                  putchar ((unsigned char)(stringLength & 0377));
                } else {
                  putchar (144);
                  putchar ((unsigned char)(stringLength & 0377));
                  putchar ((unsigned char)((stringLength >> 8) & 0377));
                }
              
                fwrite (stringStorage, 1, (size_t)stringLength, stdout);
                /* WARNING: in MS C 6.0, size_t is an unsigned int, and so is smaller
                 * than the long stringLength. This is OK as long as MAXSTRING < 64K. */
            }
            rgcbOut[ SC_STRINGS ] += cbBinary;
            fDelimPrevToken = true;
            /* don't update cbLine, because (fLevel2 && fBinary) is TRUE */

        } else if ((cbHex + cbHexDelim) < (cbLiteral + cbLiteralDelim)) {
            
            /* Use the hex encoding of the string */

            TRACE(( "\nEncodeStringHex: string %1.*s, cch %ld, cbHex %ld.",
                    pb, (int) stringLength, 
                    (unsigned long) stringLength, (unsigned long) cbHex   ));
            
            if (cbHex <= cbLineMax)
                SendDelimCbF( (size_t)cbHex, true );
            else 
                SendDelimCbF( 1, true );    /* Make room for '<' */
            if (iOperation == OP_EMIT)
                putchar( '<' );
            cbLine++;
            rgcbOut[ SC_STRINGS ]++;

            while ( stringLength > 0 ) {
                SendDelimCbF( 2, true );    /* Make room for 2 hex digits */
                if (iOperation == OP_EMIT)
                    printf( "%2.2x", (unsigned char) *pb );
                pb++;
                stringLength--;
                cbLine += 2;
                rgcbOut[ SC_STRINGS ] += 2;

            } /* while */
            if (iOperation == OP_EMIT)
                putchar( '>' );
            cbLine++;
            rgcbOut[ SC_STRINGS ]++;
            fDelimPrevToken = true;
        
        } else {    
            
            /* Use the literal encoding of the string */
            if (cbLiteral <= cbLineMax)
                SendDelimCbF( (size_t)cbLiteral, true );
            else 
                SendDelimCbF( 2, true );    /* Make room for '(' and '\' */
            TRACE(( "\nEmit Litstring: %ld+1...", (unsigned long)cbLine ));
            if (iOperation == OP_EMIT)
                putchar( '(' );
            cbLine++;

            while ( stringLength > 0 ) {
                size_t cb;

                cb = cbLiteralChF( *pb, fBinary );

                if (cb > (size_t)(cbLineMax - cbLine)) {
                    if (iOperation == OP_EMIT) 
                        putchar( '\\' );
                    cbLine++;
                    SendEOL();
                    /* Charge escaped EOL to SC_STRINGS, not to SC_FILLER. */
                    rgcbOut[ SC_FILLER  ] -= cbEOL;
                    rgcbOut[ SC_STRINGS ] += 1+cbEOL;
                }
                SendLiteralChF(*pb, fBinary);
                pb++;
                stringLength--;

            } /* while */
            if (iOperation == OP_EMIT)
                putchar( ')' );
            cbLine++;
            fDelimPrevToken = true;
            TRACE(( "==%ld\n", (unsigned long)cbLine ));
            rgcbOut[ SC_STRINGS ] += cbLiteral;

        }
    }
  
    stringPointer = NULL;     /* Indicate that no string is being built */
}

void EncodeDSC (char *text)
{
    /* Write a DSC comment to the output.  These must be at the start
     * of the line, so call SendEOL to send an end-of-line sequence if
     * not already at the start of a line. text is assumed to end with 
     * an EOL.
     */

    SendEOL();
    switch (iOperation) {

    case OP_EMIT: 
        printf( "%s", text );
        /* fall through */

    case OP_STATISTICS:
    default:
        rgcbOut[ SC_DSC ] += strlen(text) + (cbEOL - 1);
        cbLine = 0;     /* text ends in '\n' */
        fDelimPrevToken = true;
        break;
        
    case OP_TOKENSEQ: 
        if (fSubstGeneric) {
            while( *++text )
                printf( "%%" );
        } else {
            printf( "%s", text );
        }
        printf( "\n" );
        break;


    }

    TRACE(( "\nEncodeDSC: %s, rgcbOut[SC_DSC] %ld, rgcbOut[SC_FILLER] %ld\n", 
                text, (unsigned long)rgcbOut[SC_DSC], 
                (unsigned long)rgcbOut[SC_FILLER]   ));
}

void SendEOL (void)
{
    /* If we are not currently at the start of a line, send a newline
     * sequence.  Update all the bookkeeping.
     */

    if ((iOperation != OP_TOKENSEQ) && (cbLine > 0)) {
        if (iOperation == OP_EMIT)
            printf( "\n" );
        rgcbOut[SC_FILLER] += cbEOL;
        cbLine = 0;
        fDelimPrevToken = true;     // An end-of-line is a delimeter
    }

}

void EncodeIntegerBinary (integer)
  long integer;
 /*  Send an integer in the minimal binary encoding.  
  *  Caller is responsible for checking line length and delimiters.
  */
{
  if ((-128L <= integer) && (integer < 128L)) {
    putchar (136);
    putchar ((unsigned char)(integer & 0377));
  } else if ((-32768 <= integer) && (integer < 32768)) {
    if (highByteFirst) {
      putchar (134);
      putchar ((unsigned char)((integer >> 8) & 0377));
      putchar ((unsigned char)(integer & 0377));
    } else {
      putchar (135);
      putchar ((unsigned char)(integer & 0377));
      putchar ((unsigned char)((integer >> 8) & 0377));
    }
  } else {
    char bytes[5];
    int i;
    if (highByteFirst) {
      bytes[0] = 132;

      for (i = 4; i > 0; i--) {
    bytes[i] = (unsigned char)(integer & 0377);
    integer >>= 8;
      }
    } else {
      bytes[0] = 133;

      for (i = 1; i < 5; i++) {
    bytes[i] = (unsigned char)(integer & 0377);
    integer >>= 8;
      }
    }

    fwrite (bytes, 1, 5, stdout);
  }
}

size_t cbIntegerBinary (integer)
  long integer;
 /*  Return the number of bytes required for the smallest binary 
  *  encoding of the supplied integer.
  */
{
  if ((-128L <= integer) && (integer < 128L)) {
    return( 2 );    // 136, value+128

  } else if ((-32768 <= integer) && (integer < 32768)) {
    return( 3 );    // 134|135, 2-byte-value

  } else {
    return( 5 );    // 132|133, 4-byte-value
  }
}

void EncodeRealBinary (float real)
 /* 
   Send a real in the minimum binary encoding.  Caller is responsible for
   checking delimiters, line length, etc.

   Encoding of reals depends on the native floating point for the machine
   executing this program.  If it is an IEEE machine, no real conversion is
   required, regardless of whether IEEE or native format tokens are requested.
   If the machine is not an IEEE machine, conversion of reals to IEEE format
   is required if IEEE format tokens are requested.
  */
{
  unsigned long value;
  int     i;
  char    bytes[5];
  int highOrderFirst = highByteFirst;

  if (ieeeFormat) {
#if FP_IS_IEEE
    LoopHole l;

    l.value.real = real;
    value = l.value.rawBits;
    bytes [0] = (highByteFirst ? 138 : 139);
#else   /*FP_IS_IEEE*/
    /* Need to convert from native to IEEE here.  Send ASCII for now. */
    printf (" %g ", real);      /* Use spaces to delimit ASCII number */
    return;
#endif  /*FP_IS_IEEE*/
  } else {
    LoopHole l;

    l.value.real = real;
    value = l.value.rawBits;
    bytes [0] = 140;
    highOrderFirst = HIGH_BYTE_FIRST;
  }

  if (highOrderFirst) {
    for (i = 4; i > 0; i--) {
      bytes[i] = (unsigned char)(value & 0377);
      value >>= 8;
    }
  } else {
    for (i = 1; i < 5; i++) {
      bytes[i] = (unsigned char)(value & 0377);
      value >>= 8;
    }
  }

  fwrite (bytes, 1, 5, stdout);
}



size_t cbRealBinary( float real )
 /*
    Return the number of bytes required for the shortest binary encoding
    of real.
  */
{
    if (ieeeFormat) {
#if FP_IS_IEEE
        return( 5 )
#else /*FP_IS_IEEE*/
        return(sprintf( szNumber, " %g ", real ) );
                                /* Use spaces to delimit ASCII number */
#endif /*FP_IS_IEEE*/
    } else {
        return( 5 );
    }
}

size_t cbDelimCbF( size_t cbDesired, int fPreDelim )
/* 
    cbDelimCbF: returns the number of bytes required to delimit a token
    that is cbDesired bytes long, allowing for the possible need to send
    an EOL if the desired token would make the line too long.  This 
    value is useful in computing whether ASCII or binary representation
    is more compact.
 */
{
    size_t cbLeft;  /* bytes available on current line */

    cbLeft = (size_t)(cbLineMax - cbLine);

    if (fDelimPrevToken || fPreDelim) {
        if ( cbLeft >= cbDesired )
            return( 0 );
        else
            return( cbEOL );
    } else {
        if ( (unsigned long)cbLeft >= (unsigned long)(1 + cbDesired) )
            return( 1 );
        else
            return( cbEOL );
    };

}




void SendDelimCbF( size_t cbDesired, int fPreDelim )
/*
    SendDelimCb: sends whatever combination of delimiter
    and EOL is necessary.  A delimiter is necessary unless:
    * fPreDelim is TRUE, meaning the token is self-delimiting
    * fDelimPrevToken is TRUE, meaning the preceding token is self-
      delimiting.
    An EOL is necessary if the there is not enough room on the current
    line to fit cbDesired bytes plus a pre-delimiter.  And EOL is
    itself a delimiter.

    The caller is responsible for checking that cbDesired is actually
    less than or equal to cbLineMax.
 */
{
    TRACE(( "\nSendDelimCbF( %ld bytes, %d PreDelim ): cbLine %d, %d left, %d DelimPrev; ",
            (unsigned long)cbDesired, fPreDelim, 
            (int)cbLine, (int)(cbLineMax-cbLine), fDelimPrevToken   ));

    if (fDelimPrevToken || fPreDelim) {
        if ( (signed long)(cbLineMax - cbLine) >= (signed long)cbDesired ) {
            /* do nothing */
            TRACE(( "<>" ));
        } else {
            TRACE(( "<EOL>" ));
            SendEOL();
        }
    } else {
        if ( (signed long)(cbLineMax - cbLine) >= (signed long)(1 + cbDesired) ) {
            TRACE(( "< >" ));
            printf( " " );
            cbLine++;
            rgcbOut[ SC_FILLER ]++;
        } else {
            TRACE(( "<EOL>" ));
            SendEOL();
        }
    }
    TRACE(( " " ));
}

unsigned long lcbStringLiteralPchCchF( char *pch, size_t cch, int fBinary )
 /* Returns the number of bytes required to represent the first
  * cch bytes in pch[] as a PostScript langage literal string.
  * Return type is long int, because size_t is limited to 64K in Microsoft
  * C, and a 64K-byte PostScript string could take more than 64K chars
  * in literal form.
  */
{
    unsigned long cbSum = 2;    /* At minimum, '(' and ')' */

    #if 0
        TRACE(( "\nlcbStringLiteralPchCchF( %1.*s, %ld, %d ): %d",
            pch, (int)cch, (unsigned long) cch, fBinary, cbSum ));
    #endif

    while (cch-- > 0) {
        #if 0
            TRACE(( "+%ld", (unsigned long) cbLiteralChF( *pch, fBinary ) ));
        #endif
        cbSum += cbLiteralChF( *pch++, fBinary );
    }

    #if 0
        TRACE(( "==%ld.\n", cbSum ));
    #endif

    return( cbSum );
}



size_t cbLiteralChF( unsigned char ch, int fBinary )
 /* Returns the number of bytes required to represent the given character
  * as a PostScript langague literal string.
  */
{
    switch (ch) {
    case '\n':
        return(cbEOL);
        break;

    case '(':   case ')':
    case '\\':  
        return( 2 );
        break;

    case '\r':
    case '\t':  case '\b':
        if (fBinary)
            return( 1 );
        else
            return( 2 );
        break;

    default:
        if ((' ' <= ch) && (ch <= '~'))
            return( 1 );
        else if (fBinary)
            return( 1 );
        else
            return( 4 );
        break;
    }

}




void SendLiteralChF( unsigned char ch, int fBinary )
 /* Print the given character using the escape sequences for a PostScript
  * language literal string.  Update cbLine.
  */

{
    size_t cb;

    cb = cbLiteralChF( ch, fBinary );
    if (ch == '\n')
        cbLine = 0;
    else
        cbLine += cb;

    if (iOperation != OP_STATISTICS) {
        switch (ch) {
        case '\n':
            printf("\n");
            break;
    
        case '(':   case ')':
        case '\\':  
            printf("\\%c", ch);
            break;
    
        case '\r':
            if (fBinary) {
                printf( "%c", ch );
            } else {
                printf( "\\r" );
            }
            break;
    
        case '\t':
            if (fBinary) {
                printf( "%c", ch );
            } else {
                printf( "\\t" );
            }
            break;
    
        case '\b':
            if (fBinary) {
                printf( "%c", ch );
            } else {
                printf( "\\b" );
            }
            break;
    
        default:
            if ((' ' <= ch) && (ch <= '~')) {
                printf( "%c", ch );
            } else if (fBinary) {
                printf( "%c" );
            } else {
                printf( "\\%3o", ch );
            }
            break;
    
        } /* switch */
    } /* if */
}

void InitEncoding (void)
 /*
   Storage management for PostScript strings is simplified by pre-allocating
   enough room for the largest allowable string.
  */
{
  stringStorage = (char *) malloc ((size_t) MAXSTRING);

  if (stringStorage == NULL)
    FatalError ("Failed to allocate string storage (%d bytes).", MAXSTRING);
}
