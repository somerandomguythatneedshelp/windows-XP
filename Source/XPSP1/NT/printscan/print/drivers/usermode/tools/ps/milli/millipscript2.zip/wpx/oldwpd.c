//-------------------------------------------------------------------------
// This routine converts a win 3.x WPD file to the intermediate form used
// by PSCRIPT.DRV for Chicago. Note that since several of the fields are
// not included in the WPD file, we end up with a lot of default values.
//
// The following assumptions are made in this module:
// 1) Neither the input file nor the output file will exceed 64K. This is
//    a pretty safe assumption, since the largest WPD file from win 3.1
//    was about 6.5 KB.
// 2) Any element of the PRINTERINFO structure will be ignored if its
//    length is NULL.
// 3) We are a simple BOOLEAN function, where either everything works,
//    or it doesn't work at all.
// 4) The old WPD file is either in the system or windows directory.
// 5) All required files are already installed when we are called.
// 6) The old WPD is from either win 3.0 or 3.1
//
//-------------------------------------------------------------------------

#include  "generic.h"

#pragma code_seg(_OLDWPDSEG)

#if 0
// #include <windows.h>
// #include <print.h>
// #include <string.h>
// #include <dos.h>
// #include <io.h>
// #include <time.h>

// #include "..\printcap.h"
#endif

LPBYTE lpStringPtr;   
WORD   wpdScreenFreq , wpdScreenAngle , curOffset;

// extern HINSTANCE ghDriverMod;
void NEAR PASCAL InitializeMainKeyHdrs(LPWPXBLOCKS  lpWPX) ;
extern  DWORD  PPDchecksum ;  //  checksum for PPD file.


// Page Dimensions in hundredths of an inch. Since we don't want to have
// multiple paper sizes with the same ID, we set bUsed to TRUE whenever
// we find a match. Set the Dummy values to TRUE to be certain that they
// are never mapped. NaturalUnit indicates the natural unit for this
// paper size.
PAGEDIMENSION OLDWPDSEG PageDim[]={{ 850,1100,INCHES_100,    FALSE},   // Letter
                         { 850,1100,INCHES_100,    FALSE},   // LetterSmall
                         {1100,1700,INCHES_100,    FALSE},   // Tabloid
                         {1700,1100,INCHES_100,    FALSE},   // Ledger
                         { 850,1400,INCHES_100,    FALSE},   // Legal
                         { 550, 850,INCHES_100,    FALSE},   // Statement
                         { 725,1050,INCHES_100,    FALSE},   // Executive
                         {1169,1654,MILLIMETERS_10,FALSE},   // A3
                         { 827,1169,MILLIMETERS_10,FALSE},   // A4
                         { 827,1169,MILLIMETERS_10,FALSE},   // A4 Small
                         { 583, 827,MILLIMETERS_10,FALSE},   // A5
                         { 984,1394,MILLIMETERS_10,FALSE},   // B4 (JIS)
                         { 717,1012,MILLIMETERS_10,FALSE},   // B5
                         { 850,1300,INCHES_100,    FALSE},   // Folio
                         { 846,1083,MILLIMETERS_10,FALSE},   // Quarto
                         {1000,1400,INCHES_100,    FALSE},   // 10x14
                         {1100,1700,INCHES_100,    FALSE},   // 11x17
                         { 850,1100,INCHES_100,    FALSE},   // Note 8.5 x 11
                         { 388, 888,INCHES_100,    FALSE},   // Envelope #9
                         { 413, 950,INCHES_100,    FALSE},   // Envelope #10
                         { 450,1038,INCHES_100,    FALSE},   // Envelope #11
                         { 475,1100,INCHES_100,    FALSE},   // Envelope #12
                         { 500,1150,INCHES_100,    FALSE},   // Envelope #14
                         {1700,2200,INCHES_100,    FALSE},   // C size sheet
                         {2200,3400,INCHES_100,    FALSE},   // D size sheet
                         {3400,4400,INCHES_100,    FALSE},   // E size sheet
                         { 433, 866,MILLIMETERS_10,FALSE},   // Envelope DL
                         { 638, 902,MILLIMETERS_10,FALSE},   // Envelope C5
                         {1276,1803,MILLIMETERS_10,FALSE},   // Envelope C3
                         { 902,1276,MILLIMETERS_10,FALSE},   // Envelope C4
                         { 449, 638,MILLIMETERS_10,FALSE},   // Envelope C6
                         { 449, 902,MILLIMETERS_10,FALSE},   // Envelope C65
                         { 984,1390,MILLIMETERS_10,FALSE},   // Envelope B4
                         { 693, 984,MILLIMETERS_10,FALSE},   // Envelope B5
                         { 693, 492,MILLIMETERS_10,FALSE},   // Envelope B6
                         { 433, 906,MILLIMETERS_10,FALSE},   // Envelope 110x230
                         { 388, 750,INCHES_100,    FALSE},   // Envelope Monarch
                         { 363, 650,INCHES_100,    FALSE},   // Envelope 6 3/4
                         {1488,1100,INCHES_100,    FALSE},   // US Standard Fanfold
                         { 850,1200,INCHES_100,    FALSE},   // German Standard Fanfold
                         { 850,1300,INCHES_100,    FALSE},   // German Legal Fanfold
                         {2500,3530,MILLIMETERS_10,FALSE},   // B4 (ISO)
                         {1000,1480,MILLIMETERS_10,FALSE},   // Japanese Postcard
                         { 900,1100,INCHES_100,    FALSE},   // 9 x 11 in
                         {1000,1100,INCHES_100,    FALSE},   // 10 x 11 in
                         {1500,1100,INCHES_100,    FALSE},   // 15 x 11 in
                         {2200,2200,MILLIMETERS_10,FALSE},   // Envelope Invite
                         {   0,   0,INCHES_100,    TRUE},    // Dummy
                         {   0,   0,INCHES_100,    TRUE},    // Dummy
                         { 950,1200,INCHES_100,    FALSE},   // Letter Extra
                         { 950,1500,INCHES_100,    FALSE},   // Legal Extra
                         {1169,1800,INCHES_100,    FALSE},   // Tabloid Extra
                         { 929,1268,MILLIMETERS_10,FALSE},   // A4 Extra
                         {1100, 850,INCHES_100,    FALSE},   // Letter Transverse
                         { 827,1169,MILLIMETERS_10,FALSE},   // A4 Transverse
                         {1200, 950,INCHES_100,    FALSE},   // Letter Extra Transverse
                         { 894,1402,MILLIMETERS_10,FALSE},   // SuperA/SuperA/A4
                         {1201,1917,MILLIMETERS_10,FALSE},   // SuperB/SuperB/A3
                         { 850,1269,INCHES_100,    FALSE},   // Letter Plus
                         { 827,1299,MILLIMETERS_10,FALSE},   // A4 Plus
                         { 583, 827,MILLIMETERS_10,FALSE},   // A5 Transverse
                         { 717,1012,MILLIMETERS_10,FALSE},   // B5 Transverse
                         {1268,1752,MILLIMETERS_10,FALSE},   // A3 Extra
                         { 685, 925,MILLIMETERS_10,FALSE},   // A5 Extra
                         { 791,1087,MILLIMETERS_10,FALSE},   // B5 Extra
                         {1654,2339,MILLIMETERS_10,FALSE},   // A2
                         {1169,1654,MILLIMETERS_10,FALSE},   // A3 Transverse
                         {1268,1752,MILLIMETERS_10,FALSE},   // A3 Extra Transverse
                        };

// Resolution selection string--extract from old pscript driver
BYTE szResCmd[]="statusdict begin %d setresolution end\n";

// "Special" font names (from mkprn.c)
FONTMAP OLDWPDSEG FontMap[]={{"ar",    "Arial"},
                   {"arb",   "Arial-Bold"},
                   {"arbo",  "Arial-BoldOblique"},
                   {"aro",   "Arial-Oblique"},
                   {"arn",   "Arial-Narrow"},
                   {"arnb",  "Arial-Narrow-Bold"},
                   {"arnbo", "Arial-Narrow-BoldOblique"},
                   {"arno",  "Arial-Narrow-Oblique"},
                   {"cm",    "Courier"},
                   {"hm",    "Helvetica"},
                   {"hvbl",  "Helvetica-Black"},
                   {"hvblo", "Helvetica-BlackOblique"},
                   {"hvl",   "Helvetica-Light"},
                   {"hvlo",  "Helvetica-LightOblique"},
                   {"hvn",   "Helvetica-Narrow"},
                   {"hvnb",  "Helvetica-Narrow-Bold"},
                   {"hvnbo", "Helvetica-Narrow-BoldOblique"},
                   {"hvno",  "Helvetica-Narrow-Oblique"},
                   {"ncb",   "NewCenturySchlbk-Bold"},
                   {"ncbi",  "NewCenturySchlbk-BoldItalic"},
                   {"nci",   "NewCenturySchlbk-Italic"},
                   {"ncr",   "NewCenturySchlbk-Roman"},
                   {"krb",   "Korinna-Bold"},
                   {"krrg",  "Korinna-Regular"},
                   {"krkx",  "Korinna-KursivRegular"},
                   {"krkb",  "Korinna-KursivBold"},
                   {"lb",    "LubalinGraph-Book"},
                   {"lbo",   "LubalinGraph-BookOblique"},
                   {"ld",    "LubalinGraph-Demi"},
                   {"ldo",   "LubalinGraph-DemiOblique"},
                   {"sm",    "Symbol"},
                   {"ntr",   "Times-New-Roman"},
                   {"ntb",   "Times-New-Roman-Bold"},
                   {"ntbi",  "Times-New-Roman-BoldItalic"},
                   {"nti",   "Times-New-Roman-Italic"},
                   {"vtb",   "Varitimes#Bold"},
                   {"vtbi",  "Varitimes#BoldItalic"},
                   {"vti",   "Varitimes#Italic"},
                   {"vtr",   "Varitimes#Roman"},
                   {"zca",   "ZapfCalligraphic-Roman"},
                   {"zcab",  "ZapfCalligraphic-Bold"},
                   {"zcabi", "ZapfCalligraphic-BoldItalic"},
                   {"zcai",  "ZapfCalligraphic-Italic"},
                   {"zc",    "ZapfChancery-MediumItalic"},
// Dynamically created font names (see mkprn.c)
                   {"AGB",   "AvantGarde-Book"},
                   {"AGBO",  "AvantGarde-BookOblique"},
                   {"AGD",   "AvantGarde-Demi"},
                   {"AGDO",  "AvantGarde-DemiOblique"},
                   {"BD",    "Bookman-Demi"},
                   {"BDI",   "Bookman-DemiItalic"},
                   {"BL",    "Bookman-Light"},
                   {"BLI",   "Bookman-LightItalic"},
                   {"CB",    "Courier-Bold"},
                   {"CBO",   "Courier-BoldOblique"},
                   {"CO",    "Courier-Oblique"},
                   {"GB",    "Garamond-Bold"},
                   {"GBI",   "Garamond-BoldItalic"},
                   {"GL",    "Garamond-Light"},
                   {"GLI",   "Garamond-LightItalic"},
                   {"HB",    "Helvetica-Bold"},
                   {"HBO",   "Helvetica-BoldOblique"},
                   {"HC",    "Helvetica-Condensed"},
                   {"HCB",   "Helvetica-Condensed-Bold"},
                   {"HCBO",  "Helvetica-Condensed-BoldObl"},
                   {"HCO",   "Helvetica-Condensed-Oblique"},
                   {"HO",    "Helvetica-Oblique"},
                   {"OB",    "Optima-Bold"},
                   {"OBO",   "Optima-BoldOblique"},
                   {"OO",    "Optima-Oblique"},
                   {"OR",    "Optima"},
                   {"PB",    "Palatino-Bold"},
                   {"PBI",   "Palatino-BoldItalic"},
                   {"PI",    "Palatino-Italic"},
                   {"PR",    "Palatino-Roman"},
                   {"SD",    "Souvenir-Demi"},
                   {"SDI",   "Souvenir-DemiItalic"},
                   {"SL",    "Souvenir-Light"},
                   {"SLI",   "Souvenir-LightItalic"},
                   {"TB",    "Times-Bold"},
                   {"TBI",   "Times-BoldItalic"},
                   {"TI",    "Times-Italic"},
                   {"TR",    "Times-Roman"},
                   {"ZD",    "ZapfDingbats"},
                   {NULL,    NULL}};



//------------------------*retStringRef*---------------------------------
// Action: Add an entry to the string table & return  its STRINGREF value
//
// lpString     FAR pointer to string 
// wLength      Length of string (or NULLTERMINATED)
//
//
// Return: None (void)
//------------------------------------------------------------------------
DWORD NEAR PASCAL retStringRef(LPSTR       lpString,
                               WORD        wLength)
{
  WORD wLoop;
  WORD wStartOffset;
  DWORD  stringRef ;

  if(NULLTERMINATED==wLength)
  {
    wStartOffset=OFFSETOF(lpStringPtr);

    for(wLoop=0;*lpString;wLoop++)
      *lpStringPtr++ = *lpString++;

    stringRef = MAKELONG(wStartOffset,wLoop);
  }
  else // String with a specified length
  {
    wStartOffset=OFFSETOF(lpStringPtr);

    for(wLoop=0;wLoop<wLength;wLoop++)
      *lpStringPtr++ = *lpString++;

    stringRef = MAKELONG(wStartOffset,wLoop);
  }
  *lpStringPtr++ = 0 ;  // null termination.

  return(stringRef) ;
}





//---------------------*FillCommandFromOldString*------------------------
// Action: Fill a COMMAND structure
//
// lpOldStrings    Pointer to old string block
// dwOffset        Offset in old string block of command string
//
// Note:   All old commands, except the transfer function are stored
//         with a DWORD pointing to a table of DWORDS, with each element
//         of the table pointing to the actual string in the format
//         length,string. The transfer function is not used in the new
//         format, so we always use the indirection.
//
// Return: None (void)
//-----------------------------------------------------------------------
DWORD NEAR PASCAL FillCommandFromOldString(LPSTR     lpOldStrings,
                                          DWORD     dwOffset)
{
  DWORD dwMyOffset, stringRef = 0L;
  LPSTR lpData;

  if(dwOffset)
  {
    dwMyOffset=GET_PS_DWORD(lpOldStrings,dwOffset);

    if(dwMyOffset)
    {
      lpData=lpOldStrings+dwMyOffset;

      stringRef = retStringRef(lpData+2,*((LPWORD)lpData));
    }
  }
  return(stringRef) ;
}



//---------------------------*FuzzyMatch*------------------------------
// Action: Compare two strings for a fuzzy match. This means that we
//         check the first n characters, where n is the length of the
//         shorter of the two strings. The exception is that we return
//         FALSE if one string (not both) is NULL.
//
// Return: TRUE if we have a fuzzy match, FALSE if not
//---------------------------------------------------------------------
BOOL NEAR PASCAL FuzzyMatch(LPSTR lpStr1,
                            LPSTR lpStr2)
{
  // One string empty, one not
  if(('\0'==*lpStr1) != ('\0'==*lpStr2))
    return FALSE;

  while(*lpStr1 && *lpStr2)
    if(*lpStr1++ != *lpStr2++)
      return FALSE;

  return TRUE;
}



//------------------*GropeForOldWPDinDirectory*------------------------
// Action: Check all .WPD files in the specified directory to see if
//         we can find the one that matches the requested model name.
//         If we find it, read the information into memory so we don't
//         have to go back to the disk for the information.
//
// Return: A far pointer to the file contents if successful, NULL if not.
//         The caller must free this pointer when done.
//
// Side Effect: Write the actual file name (without the path) into
//              lpDirectory, but only when we have a match.
//---------------------------------------------------------------------
LPOLDPS_RES_HEADER NEAR PASCAL GropeForOldWPDinDirectory(LPSTR lpDirectory,
                                                         LPSTR lpModelName)
{
  static struct _find_t fileinfo;
  HFILE                 hTest;
  LPOLDPS_RES_HEADER    lpReadData;
  WORD                  wDataSize;
  PSTR                  pScratch;
  LPSTR                 lpWDLModelName;

  // We need a local buffer for temporary storage
  if(!(pScratch=(PSTR)LocalAlloc(LPTR,_MAX_PATH)))
    return NULL;

  // Scan all of the .WPD files that we find in this directory
  wsprintf(pScratch,"%s\\*.WPD",lpDirectory);
  if(!_dos_findfirst(pScratch,_A_RDONLY,&fileinfo))
  {
    do
    {
      // Read entire .WPD file into memory--ignore files with 0 length
      wsprintf(pScratch,"%s\\%s",lpDirectory,(LPSTR)fileinfo.name);
      hTest=_lopen(pScratch,READ|OF_SHARE_DENY_WRITE);
      if(HFILE_ERROR!=hTest)
      {
        wDataSize=(WORD)_llseek(hTest,0L,SEEK_END);
        if(wDataSize &&
          (lpReadData=(LPOLDPS_RES_HEADER)GlobalAllocPtr(GHND,
                                                        (DWORD)wDataSize)))
        {
          _llseek(hTest,0L,SEEK_SET);
          _lread(hTest,lpReadData,wDataSize);
        }
        _lclose(hTest);

        // Paranoia: Some random file has a WPD extension. When we try
        // to get the model name, we may go off the end of the block
        // and GP fault--very rude. So check that the end of the
        // last reported block is not beyond the total file length.
        // If this is the case, assume that it's a valid WPD file.
        if(max(max(lpReadData->dir_loc+lpReadData->dir_len,
                   lpReadData->cap_loc+lpReadData->cap_len),
               lpReadData->pss_loc+lpReadData->pss_len) <= (DWORD)wDataSize)
        {
          // See if this WPD file describes the model we need
          lpWDLModelName=ADVANCE_BYTES(lpReadData,
                                       lpReadData->cap_loc+sizeof(int));
          if(FuzzyMatch(lpModelName,lpWDLModelName))
          {
            // we have a match--clean up & return (filename & handle)
            lstrcpy(lpDirectory,fileinfo.name);
            LocalFree((HGLOBAL)pScratch);
            PPDchecksum = crc32((HPBYTE)lpReadData, (DWORD)wDataSize) ;
            return (LPOLDPS_RES_HEADER)lpReadData;
          }
        }

        // This isn't the right file--free the memory & try again
        GlobalFreePtr(lpReadData);
      }
    } while (!_dos_findnext(&fileinfo));
  }

  // We only get here if we didn't find a match
  return NULL;
}



//----------------------*ConvertDuplexCommands*------------------------
// Action: Convert old duplex info to new format
//
// Return: None (void)
//---------------------------------------------------------------------
void NEAR PASCAL ConvertDuplexCommands(LPSTR        lpOldStrings,
                                       LPWPXBLOCKS  lpWPX)
{
   WORD    i;
   DWORD dwLookup;
   LPMAINKEYHDR  lpMainKeyHdrs ;
   LPPRINTERINFO  lpPI ;
   LPGENERIC_OPTION  lpDuplexingInfo ;

   lpPI = (LPPRINTERINFO)lpWPX->WPXprinterInfo ;
   lpMainKeyHdrs = lpPI->mainKeyHdrs + IND_DUPLEXINGINFO ;

   //  lpOptionsBlock  = lpWPX->WPXarrays ;

   lpMainKeyHdrs->MainKeyID = DUPLEX;
   lpMainKeyHdrs->MainKey.dword = 
                     retStringRef("Duplex", NULLTERMINATED);

   lpMainKeyHdrs->OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs->OptionKeyWords.w.length = NUM_DUPLEX_MODES ;

   lpDuplexingInfo = (LPGENERIC_OPTION)(lpWPX->WPXarrays + curOffset) ;

  // Duplex commands are stored in three consecutive DWORDS. The offset
  // of the first DWORD is stored in DWORD 6 of lpOldStrings. The
  // strings order is: Sinplex, Vertical Duplex, Horizontal Duplex
  dwLookup=GET_PS_DWORD(lpOldStrings,SEL_DUPLEX);

   lpDuplexingInfo[DUPLEX_NONE].Invocation.dword = 
      FillCommandFromOldString(lpOldStrings,dwLookup) ;
   lpDuplexingInfo[SIMPLEXTUMBLE].Invocation.dword = 0L ;
   lpDuplexingInfo[DUPLEXTUMBLE].Invocation.dword = 
      FillCommandFromOldString(lpOldStrings,dwLookup+2*sizeof(DWORD)) ;
   lpDuplexingInfo[DUPLEXNOTUMBLE].Invocation.dword = 
      FillCommandFromOldString(lpOldStrings,dwLookup+sizeof(DWORD)) ;

   lpDuplexingInfo[DUPLEX_NONE].OptionKey.dword = 
                     retStringRef("Duplex Off", NULLTERMINATED);
   lpDuplexingInfo[SIMPLEXTUMBLE].OptionKey.dword = 
                     retStringRef("Not Availible", NULLTERMINATED);
   lpDuplexingInfo[DUPLEXTUMBLE].OptionKey.dword = 
                     retStringRef("Duplex Tumble", NULLTERMINATED);
   lpDuplexingInfo[DUPLEXNOTUMBLE].OptionKey.dword = 
                     retStringRef("Duplex No Tumble", NULLTERMINATED);

   //  just tack yourself to the head of one of the roots.
   i = lpPI->OrderListRoot.DocumentSetup ;
   lpPI->OrderListRoot.DocumentSetup = IND_DUPLEXINGINFO ;
   lpMainKeyHdrs->order.ArrayIndex = i ;


   for(i = 0 ; i < NUM_DUPLEX_MODES ; i++)
   {
      lpDuplexingInfo[i].order.ArrayIndex = 0xFFFF ;  // uninitialized.
      lpDuplexingInfo[i].UIconstraintIndex = 0xFFFF ;  // no constraints
      lpDuplexingInfo[i].OptionTranslation.dword = 0L ;
   }

   curOffset +=  NUM_DUPLEX_MODES * sizeof(GENERIC_OPTION) ;
}



//-------------------------*ConvertResolutionInfo*---------------------
// Action: WPD file has no useful resolution info
//         just initialize first one to 300dpi.
//
// Return: none (void)
//---------------------------------------------------------------------
void NEAR PASCAL ConvertResolutionInfo(LPWPXBLOCKS  lpWPX)
{
   extern  WORD   curOffset, wpdScreenFreq , wpdScreenAngle ;
   WORD   i, numResolutions;
   LPMAINKEYHDR  lpMainKeyHdrs ;
   LPPRINTERINFO  lpPI ;
   LPRESOLUTIONINFO lpResInfo;
   LPGENERIC_OPTION  lpOptionInfo ;

   numResolutions = 1 ;  // hardcoded and unchangeable!

   lpPI = (LPPRINTERINFO)lpWPX->WPXprinterInfo ;
   lpMainKeyHdrs = lpPI->mainKeyHdrs + IND_RESOLUTIONINFO ;

   //  lpOptionsBlock  = lpWPX->WPXarrays ;

   lpMainKeyHdrs->MainKeyID = RESOLUTION;
   lpMainKeyHdrs->MainKey.dword = 
                     retStringRef("Resolution", NULLTERMINATED);

   lpMainKeyHdrs->OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs->OptionKeyWords.w.length = numResolutions ;


   lpOptionInfo = (LPGENERIC_OPTION) (lpWPX->WPXarrays + curOffset) ;

   curOffset +=  numResolutions * sizeof(GENERIC_OPTION) ;

   lpMainKeyHdrs->extraOptionArray = (WORD)curOffset ;

   lpResInfo = (LPRESOLUTIONINFO)(lpWPX->WPXarrays + curOffset) ;

   lpOptionInfo[0].Invocation.dword = 0L ;  // none !
   lpOptionInfo[0].order.ArrayIndex = 0xFFFF ;  // uninitialized.
   lpOptionInfo[0].UIconstraintIndex = 0xFFFF ;  // no constraints
   lpOptionInfo[0].OptionKey.dword =
                     retStringRef("300dpi", NULLTERMINATED);
   lpOptionInfo[0].OptionTranslation.dword = 0L ;

   lpResInfo[0].res.dword = MAKELONG(300, 300) ;  // report 300 dpi always
   lpResInfo[0].ScreenFreq = wpdScreenFreq ;
   lpResInfo[0].ScreenAngle = wpdScreenAngle ;

   //  just tack yourself to the head of one of the roots.
   i = lpPI->OrderListRoot.DocumentSetup ;
   lpPI->OrderListRoot.DocumentSetup = IND_RESOLUTIONINFO ;
   lpMainKeyHdrs->order.ArrayIndex = i ;

   curOffset +=  numResolutions * sizeof(RESOLUTIONINFO) ;
}



//---------------------*ConvertGeneralInfo*----------------------------
// Action: Convert general capabilities, as much as possible, from the
//         old file format. The model name is needed to deal with cases
//         that are hardcoded in the old postscript driver.
//
// Return: none (void)
//---------------------------------------------------------------------
void NEAR PASCAL ConvertGeneralInfo(LPOLDPRINTER  lpOldPrint,
                                    LPSTR         lpModelName,
                                    LPWPXBLOCKS lpWPX )
{
   LPPRINTERINFO  lpPI ;

   lpPI = (LPPRINTERINFO)lpWPX->WPXprinterInfo ;

   lpPI->versionNum = WPXVERSION ;

   // Stamp this WPX file with the checksum of the PPD file, so we can bind
   // DEVMODE settings to a specific WPX file. (If someone changes their
   // PPD file, we need to re-evaluate the devmode's private data)
   lpPI->dwPPDchecksum = PPDchecksum ;
   lpPI->dwRandom = GetTickCount();

   lpPI->modelname.dword = retStringRef(lpModelName,NULLTERMINATED);
   lpPI->fileID.dword = retStringRef("Converted from old format",NULLTERMINATED);

   lpPI->PCFileName.dword = 0L ;
   lpPI->Product.dword = 0L ;
   lpPI->PSVersion.dword = 0L ;
   lpPI->disableManFeed.dword = 0L ;
   lpPI->password.dword = 0L;  //  default assumption
   lpPI->exitServer.dword = 0L;  //  default assumption
   lpPI->PatchFile.dword = 0L;  //  default assumption
   lpPI->nJobPatchFiles = 0;  //  default assumption

   lpPI->InstallableOptions = 0xFFFF ;  // default: none

   lpPI->numMainKeyHdrs = IND_NUMPREDEFINEDHDRS ;
   lpPI->PrinterSticky.w.length = 0 ;
   lpPI->PrinterSticky.w.offset = IND_NUMPREDEFINEDHDRS;
   lpPI->DocSticky.w.length = 0 ;
   lpPI->DocSticky.w.offset = IND_NUMPREDEFINEDHDRS  ;


   lpPI->devcaps.BCPsupport =
   lpPI->devcaps.TBCPsupport = 
   lpPI->devcaps.PJLsupport = FALSE;  //  default assumption

   // Only one WPD printer supports PJL--HP LaserJet III Si PostScript
   if(!lstrcmp(lpModelName,"HP LaserJet IIISi PostScript"))
   {
      LPJCLINFO  lpJCLinfo = &lpPI->JCLinfo ;

      lpPI->devcaps.PJLsupport=TRUE;

      lpJCLinfo->JCLBegin.dword = retStringRef("\033%-12345X@PJL JOB\012", NULLTERMINATED);

      lpJCLinfo->JCLToPSInterpreter.dword = retStringRef("@PJL ENTER LANGUAGE=POSTSCRIPT\012", NULLTERMINATED );
         
      lpJCLinfo->JCLEnd.dword = retStringRef("\033%-12345X@PJL EOJ\012\033%-12345X", NULLTERMINATED) ;
   }

   lpPI->devcaps.color=lpOldPrint->fColor;
   lpPI->devcaps.LanguageEncoding = NOENCODING ;

   // these fields will be set to their option index value
   // if they exist.  Or 0xFFFF if not supported.

   lpPI->devcaps.AutoSense = 0xFFFF;  //  default assumption
   lpPI->devcaps.MixedBins = 0xFFFF;  //  default assumption
   lpPI->devcaps.ManualFeed = 0xFFFF;  //  default assumption
   lpPI->devcaps.CustomPageSize = 0xFFFF;  //  default assumption

   lpPI->devcaps.languageLevel=1;

   lpPI->devcaps.SupportsDuplexing = FALSE ;  // initialize for now.
   lpPI->devcaps.landscapeOrientPlus90 = TRUE;  //  default assumption

   lpPI->devcaps.TrueImageSupport=OLDIS_TRUEIMAGE(lpOldPrint);
   lpPI->devcaps.TTRasterizer = TTRAST_NONE;  //  default assumption

   if(OLDACCEPTS_TRUETYPE(lpOldPrint))
      lpPI->devcaps.TTRasterizer = TTRAST_TRUEIMAGE;

   wpdScreenFreq = lpOldPrint->ScreenFreq;   // store in Globals for transfer
   wpdScreenAngle = lpOldPrint->ScreenAngle; // to resolution arrays.

   lpPI->devcaps.iFreeVM = lpOldPrint->iMaxVM;

}



//------------------------*ConvertPaperSlots*--------------------------
// Action: Convert the paper slots from the old format to the new one.
//         Notice that we need to give special treatment to the manual
//         feed & extract it from the manual switch info.
//
// Return: None (void)
//---------------------------------------------------------------------
void NEAR PASCAL ConvertPaperSlots(LPOLDPRINTER  lpOldPrint,
                                   LPSTR         lpOldStrings,
                                   LPWPXBLOCKS lpWPX)
{
   WORD       wLoop, wSlot, i;
   LPMAINKEYHDR  lpMainKeyHdrs ;
   LPPRINTERINFO  lpPI ;
   LPINPUTSLOTINFO   lpXSlotInfo ;
   LPGENERIC_OPTION   lpOptionInfo ;

  DWORD      dwLookup;
  BOOL       bSupportedSlot;



  // The 3.0 WPD files used slot indices that were 1-based. The 3.1 WPD
  // (and newer) use 0-based indices. So, we need to shift our slots
  // that we look at if the input file is a 3.0 format.
  if(lpOldPrint->version < WIN31WPDVERSION)
  {
      lpOldPrint->feed[0] |= lpOldPrint->feed[1];

      for(i = 1 ; i < OLDNUMFEEDS - 1 ; i++ )
      {
         lpOldPrint->feed[i] = lpOldPrint->feed[i+1];
      }

      lpOldPrint->feed[i] = FALSE;
  }


  // Get offset of lookup table
  dwLookup=GET_PS_DWORD(lpOldStrings,SEL_INPUTSLOT);

  for(wLoop=0,wSlot=0;wLoop<OLDNUMFEEDS;wLoop++)
  {
    // Shift the slot index if we're reading an old format file
    bSupportedSlot=lpOldPrint->feed[wLoop];

    // Exclude Envelope Manual from our list of bins. 
    if(bSupportedSlot && ((OLDDMBIN_FIRST+wLoop) != OLDDMBIN_ENVMANUAL))
    {
      // Add this slot to the table
      wSlot++ ;
    }
  }

   lpPI = (LPPRINTERINFO)lpWPX->WPXprinterInfo ;
   lpMainKeyHdrs = lpPI->mainKeyHdrs + IND_INPUTSLOTINFO  ;

   lpMainKeyHdrs->OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs->OptionKeyWords.w.length = wSlot ;

   lpOptionInfo = (LPGENERIC_OPTION) (lpWPX->WPXarrays + curOffset) ;

   curOffset +=  wSlot * sizeof(GENERIC_OPTION) ;

   lpMainKeyHdrs->extraOptionArray = (WORD)curOffset ;

   lpXSlotInfo = (LPINPUTSLOTINFO)(lpWPX->WPXarrays + curOffset) ;

   lpMainKeyHdrs->MainKeyID = INPUTSLOT;
   lpMainKeyHdrs->MainKey.dword = 
                     retStringRef("InputSlot", NULLTERMINATED);



  for(wLoop=0,wSlot=0;wLoop<OLDNUMFEEDS;wLoop++)
  {
    // Get all supported slots EXCEPT manual envelope. We exclude manual
    // envelope because manual is treated as a separate slot and we don't
    // want to have two of them. (The assumption here is that we will never
    // have manual envelope without regular manual).

    // Shift the slot index if we're reading an old format file
    bSupportedSlot=lpOldPrint->feed[wLoop];

    // Exclude Envelope Manual from our list of bins. A user gets this
    // particular format by selecting manual feed and envelope size.
    if(bSupportedSlot && ((OLDDMBIN_FIRST+wLoop) != OLDDMBIN_ENVMANUAL))
    {
      // Add this slot to the table
      BYTE  szSlotName[64];

      // LoadString should never fail, since we handle all cases that
      // Mkprn knew about. Add the guard just to be sure.
      if(LoadString(ghDriverMod,BIN_START+OLDDMBIN_UPPER+wLoop,
                    szSlotName,sizeof(szSlotName)))
      {
         lpOptionInfo[wSlot].OptionKey.dword =
                           retStringRef(szSlotName, NULLTERMINATED);

         lpXSlotInfo[wSlot].slotID = wLoop+OLDDMBIN_FIRST;

         // Get command for this slot--special case manual feed
         if(OLDDMBIN_MANUAL==OLDDMBIN_FIRST+wLoop)
         {
            // This is manual feed--get the selection string from the strings,
            // and set the disable manual feed command, while we're at it.
            DWORD dwManualLookup;

            dwManualLookup=GET_PS_DWORD(lpOldStrings,MANUALSWITCH);

            lpPI->disableManFeed.dword = 
               FillCommandFromOldString(lpOldStrings,
                                 dwManualLookup ) ;
            // enable ManFeed
            lpOptionInfo[wSlot].Invocation.dword = 
               FillCommandFromOldString(lpOldStrings,
                                 dwManualLookup+sizeof(DWORD) ) ;

            lpPI->devcaps.ManualFeed = wSlot ;
         }
         else
            lpOptionInfo[wSlot].Invocation.dword = 
                FillCommandFromOldString(lpOldStrings,
                                  dwLookup+wLoop*sizeof(DWORD) ) ;

        if((OLDDMBIN_FIRST+wLoop) == (WORD)lpOldPrint->defFeed)
          // Update default slot in PRINTERINFO structure
            lpMainKeyHdrs->DefaultOptionIndex = wLoop;


         lpOptionInfo[wSlot].order.ArrayIndex = 0xFFFF ;  // uninitialized.
         lpOptionInfo[wSlot].UIconstraintIndex = 0xFFFF ;  // no constraints
         lpOptionInfo[wSlot].OptionTranslation.dword = 0L ;

         lpXSlotInfo[wSlot].ReqsPageRegion = TRUE ;  //  Be on the safe side


   // no provisions for AUTOSENSE or MixedBins.

        wSlot++;
      }
    }
  }

   //  just tack yourself to the head of one of the roots.
   i = lpPI->OrderListRoot.DocumentSetup ;
   lpPI->OrderListRoot.DocumentSetup = IND_INPUTSLOTINFO ;
   lpMainKeyHdrs->order.ArrayIndex = i ;

   curOffset +=  wSlot * sizeof(INPUTSLOTINFO) ;
}



//--------------------------*ConvertPaperSizes*------------------------
// Action: Convert the paper size information from the old to the new
//         structure. We need to be a little careful here because of
//         the differences between 3.0 & 3.1 WPD files.
//         Since the old format didn't have a default paper size, our
//         default will always be the first paper size in the old WPD
//         file.
//
// Return: None (void)
//---------------------------------------------------------------------
void NEAR PASCAL ConvertPaperSizes(LPOLDPRINTER  lpOldPrint,
                                   LPSTR         lpOldStrings,
                                   LPWPXBLOCKS lpWPX)
{
  WORD           wLoop, wNumPapers, wPaper, wPaperID, i;
  LPOLDPAPER_REC lpOldPapers;
  BYTE           szPaperName[64];
  DWORD          dwPageSizeOffset, dwPageRegionOffset;
   LPMAINKEYHDR  lpPageRegionHdr, lpPaperSizeHdr ;
   LPPRINTERINFO  lpPI ;
   LPPAPERINFO   lpXPaperInfo ;
   LPGENERIC_OPTION   lpPaperInfo, lpPageRegionInfo ;



  // There are two old WPD versions--get the right information
  if(lpOldPrint->version >= WIN31WPDVERSION)
  {
    // 3.1 version--iCapsBits included in the OLDPRINTER structure
    wNumPapers=(WORD)lpOldPrint->iNumPapers;
    lpOldPapers=(LPOLDPAPER_REC)&lpOldPrint->Paper;
  }
  else
  {
    // 3.0 version--iCapsBits not included in OLDPRINTER structure
    wNumPapers=(WORD)lpOldPrint->iCapsBits;
    lpOldPapers=(LPOLDPAPER_REC)&lpOldPrint->iNumPapers;
  }


   lpPI = (LPPRINTERINFO)lpWPX->WPXprinterInfo ;
   lpPaperSizeHdr = lpPI->mainKeyHdrs + IND_PAPERINFO  ;

   lpPaperSizeHdr->OptionKeyWords.w.offset = (WORD)curOffset ;
   lpPaperSizeHdr->OptionKeyWords.w.length = wNumPapers ;

   lpPaperInfo = (LPGENERIC_OPTION) (lpWPX->WPXarrays + curOffset) ;

   curOffset +=  wNumPapers * sizeof(GENERIC_OPTION) ;

   lpPaperSizeHdr->extraOptionArray = (WORD)curOffset ;

   lpXPaperInfo = (LPPAPERINFO)(lpWPX->WPXarrays + curOffset) ;

   lpPaperSizeHdr->MainKeyID = PAGESIZE;
   lpPaperSizeHdr->MainKey.dword = 
                     retStringRef("PageSize", NULLTERMINATED);

   curOffset +=  wNumPapers * sizeof(PAPERINFO) ;

   lpPageRegionHdr = lpPI->mainKeyHdrs + IND_PAGEREGIONINFO  ;

   lpPageRegionHdr->OptionKeyWords.w.offset = (WORD)curOffset ;
   lpPageRegionHdr->OptionKeyWords.w.length = wNumPapers ;

   lpPageRegionInfo = (LPGENERIC_OPTION) (lpWPX->WPXarrays + curOffset) ;

   curOffset +=  wNumPapers * sizeof(GENERIC_OPTION) ;

   lpPageRegionHdr->MainKeyID = PAGEREGION;
   lpPageRegionHdr->MainKey.dword = 
                     retStringRef("PageRegion", NULLTERMINATED);


   // Find the offsets to the lookup tables for the page commands
   dwPageSizeOffset=GET_PS_DWORD(lpOldStrings,NORMALIMAGE);
   dwPageRegionOffset=GET_PS_DWORD(lpOldStrings,MANUALIMAGE);

   for(wLoop=0,wPaper=0;wLoop<wNumPapers;wLoop++)
   {
      wPaperID=lpOldPapers[wLoop].iPaperType;

   
      // This LoadString will only fail if we have an unknown paper size,
      // and if that's the case we just don't worry about it.
      if(LoadString(ghDriverMod,PAPER_START+wPaperID,szPaperName,
                  sizeof(szPaperName)))
      {
         int  wdim;

         // We know how to process this paper--do it!
         lpPaperInfo[wPaper].OptionKey.dword =
         lpPageRegionInfo[wPaper].OptionKey.dword =
            retStringRef(szPaperName,NULLTERMINATED) ;

         // now for the commands...
         lpPaperInfo[wPaper].Invocation.dword = 
            FillCommandFromOldString(lpOldStrings,dwPageSizeOffset) ;

         lpPageRegionInfo[wPaper].Invocation.dword = 
            FillCommandFromOldString(lpOldStrings,dwPageRegionOffset);

         lpPaperInfo[wPaper].order.ArrayIndex = 0xFFFF ;  // uninitialized.
         lpPaperInfo[wPaper].UIconstraintIndex = 0xFFFF ;  // no constraints
         lpPaperInfo[wPaper].OptionTranslation.dword = 0L ;

         lpPageRegionInfo[wPaper].order.ArrayIndex = 0xFFFF ;  // uninitialized.
         lpPageRegionInfo[wPaper].UIconstraintIndex = 0xFFFF ;  // no constraints
         lpPageRegionInfo[wPaper].OptionTranslation.dword = 0L ;

         lpXPaperInfo[wPaper].paperID=wPaperID;
         lpXPaperInfo[wPaper].width=PageDim[wPaperID-DMPAPER_FIRST].width;
         lpXPaperInfo[wPaper].length=PageDim[wPaperID-DMPAPER_FIRST].length;

         // When copying the imageable area, we need to exchange the top and
         // bottom values. This is because the coordinates are expressed in
         // POSTSCRIPT coordinates (origin at lower left corner) and MKPRN
         // converted them to GDI coordinates (origin at top left corner).
         // The new driver expects the coordinates in POSTSCRIPT coordinates,
         // so we have to undo what MKPRN did.
         SetRect(&(lpXPaperInfo[wPaper].imageableArea),
                  lpOldPapers[wLoop].rcImage.left,
                  lpOldPapers[wLoop].rcImage.bottom,
                  lpOldPapers[wLoop].rcImage.right,
                  lpOldPapers[wLoop].rcImage.top);

         wdim = (int)lpXPaperInfo[wPaper].width ;
         lpXPaperInfo[wPaper].width = (WORD)MulDiv(wdim, 72, 100) ;

         wdim = (int)lpXPaperInfo[wPaper].length ;
         lpXPaperInfo[wPaper].length = (WORD)MulDiv(wdim, 72, 100) ;

         wdim = lpXPaperInfo[wPaper].imageableArea.left ;
         lpXPaperInfo[wPaper].imageableArea.left = MulDiv(wdim, 72, 100) ;
         wdim = lpXPaperInfo[wPaper].imageableArea.top ;
         lpXPaperInfo[wPaper].imageableArea.top = MulDiv(wdim, 72, 100) ;
         wdim = lpXPaperInfo[wPaper].imageableArea.right ;
         lpXPaperInfo[wPaper].imageableArea.right = MulDiv(wdim, 72, 100) ;
         wdim = lpXPaperInfo[wPaper].imageableArea.bottom ;
         lpXPaperInfo[wPaper].imageableArea.bottom = MulDiv(wdim, 72, 100) ;

         wPaper++;
      }
      // Bump pointers for commands, even if we didn't process the paper size
      dwPageSizeOffset+=sizeof(DWORD);
      dwPageRegionOffset+=sizeof(DWORD);
   }

   lpPaperSizeHdr->OptionKeyWords.w.length = wPaper ;
   lpPageRegionHdr->OptionKeyWords.w.length = wPaper ;  // actual number.



     //  just tack yourself to the head of one of the roots.
   i = lpPI->OrderListRoot.DocumentSetup ;
   lpPI->OrderListRoot.DocumentSetup = IND_PAGEREGIONINFO ;
   lpPageRegionHdr->order.ArrayIndex = i ;

   i = lpPI->OrderListRoot.DocumentSetup ;
   lpPI->OrderListRoot.DocumentSetup = IND_PAPERINFO ;
   lpPaperSizeHdr->order.ArrayIndex = i ;

}



//-----------------------*MapToOriginalFontName*-----------------------
// Action: Map the old (condensed) font names to the offical PPD versions.
//         The easiest way to do this is to use a lookup table containing
//         the old and new entries.  Add the real font name to StringTable.
//
// Return: string ref pointing to real font name, else 0L for failure.
//
//---------------------------------------------------------------------
DWORD NEAR PASCAL MapToOriginalFontName(LPSTR lpOldName)
{
  WORD wLoop, wMax ;
  DWORD dword;

  wMax=sizeof(FontMap)/sizeof(FONTMAP);

  for(wLoop=0 ; wLoop < wMax ; wLoop++)
  {
    if(!lstrcmpi(lpOldName,FontMap[wLoop].pszShortName))
    {
      dword = retStringRef(FontMap[wLoop].pszFullName,NULLTERMINATED) ;
      return dword;
    }
  }
  return 0L;  // failed
}


//-------------------------*ConvertFontEntries*------------------------
// Action: for each font listed in the WPD - obtain the PPD font name, we
//         need to map the resource name stored in the old WPD file to
//         the actual font name that was in the original PPD.
//          Then call InstallPrinterFonts to do the rest.
//
// Return: Length of font entries in new file
//---------------------------------------------------------------------
BOOL NEAR PASCAL ConvertFontEntries(LPOLDPS_RES_HEADER lpOldHead,
                                    LPWPXBLOCKS lpWPX)
{
  LPFONTENTRY lpOldFont;
  WORD        wNumOldFonts, wNumNewFonts;
  WORD        wLoop;
   LPPRINTERINFO  lpPI ;
   LPFONTLIST  lpFontList ;

   lpPI = (LPPRINTERINFO)lpWPX->WPXprinterInfo ;

   lpFontList = (LPFONTLIST) (lpWPX->WPXarrays + curOffset) ;

   // Get initial pointers and # of old fonts

   lpOldFont=(LPFONTENTRY)ADVANCE_BYTES(lpOldHead,
                                          lpOldHead->dir_loc+sizeof(WORD));

   wNumOldFonts=*((LPWORD)ADVANCE_BYTES(lpOldHead,lpOldHead->dir_loc));

   for(wLoop=0 , wNumNewFonts=0 ; wLoop<wNumOldFonts ; wLoop++)
   {
      lpFontList[wNumNewFonts].fontname.dword =
         MapToOriginalFontName(
            ((LPSTR)lpOldFont)+lpOldFont->font_name_offset+2*sizeof(short)) ;
      if(lpFontList[wNumNewFonts].fontname.dword)
         wNumNewFonts++ ;
      lpOldFont=(LPFONTENTRY)ADVANCE_BYTES(lpOldFont,lpOldFont->size);
   }

   lpPI->FontList.w.offset = (WORD)curOffset ;  // first secondary array
   lpPI->FontList.w.length = wNumNewFonts ;

   curOffset +=  wNumNewFonts * sizeof(FONTLIST) ;

   return InstallPrinterFonts(lpPI, lpWPX->WPXstrings, lpWPX->WPXarrays);
}



//---------------------------*ConvertFormat*---------------------------
// Action: Convert the old WPD file referenced by lpOldWPD into a new
//         format and store the result in the block identified by
//         lpNewHead. lpPath identifies the path for the WPX file,
//         and the PFM index file will always live in the parent of
//         this directory. Wrong, Wrong !!
//
// Return: A far pointer to the new block if successful, NULL if not
//---------------------------------------------------------------------

LPWPX_HEADER NEAR PASCAL ConvertFormat(LPOLDPS_RES_HEADER lpOldHead,
                                             LPSTR              lpModelName)
{
  LPOLDPRINTER        lpOldPrint;
  LPSTR               lpOldStrings;
  DWORD               dwOldFileSize;
  WPX_HEADER        WPXHead;
  WPXBLOCKS          WPXblock ;  // a special version
  LPPRINTERINFO  lpPI ;
  LPBYTE         lpWPXbuffer,  lpOptionsBlock, lpStringTable, lpTgt  ;
   WORD     PrinterInfo_len ;



  lpOldPrint=(LPOLDPRINTER)ADVANCE_BYTES(lpOldHead,lpOldHead->cap_loc);
  lpOldStrings=ADVANCE_BYTES(lpOldHead,lpOldHead->pss_loc);

  // Allocate two blocks of memory here--the first is where we will
  // eventually build the output file. The second is where we will
  // temporarily store our command strings. Let's leave ourselves
  // plenty of room--alloc the first block to be four times the
  // size of the original file, the second block the same size as
  // the original file.
  dwOldFileSize=GlobalSize((HGLOBAL)SELECTOROF(lpOldHead));


   PrinterInfo_len = sizeof(PRINTERINFO) + 
                     IND_NUMPREDEFINEDHDRS * sizeof(MAINKEYHDR) ;
                     //  WPD files don't support OpenUI's



  lpPI=(LPPRINTERINFO)GlobalAllocPtr(GHND, PrinterInfo_len);
  if(!lpPI)
    goto  ConvertFormatFailed ;

  lpOptionsBlock = GlobalAllocPtr(GHND, 0x7000);  // large enough
  if(!lpOptionsBlock)
    goto  ConvertFormatFailed ;

  lpStringTable=GlobalAllocPtr(GHND,dwOldFileSize);
  if(!lpStringTable)
    goto  ConvertFormatFailed ;


   //  now initialize WPXblock with all relavent pointers.

   WPXblock.WPXprinterInfo = (LPBYTE)lpPI ;
   WPXblock.WPXarrays      = lpOptionsBlock ;
   WPXblock.WPXstrings     = lpStringTable ;
   WPXblock.WPXconstraints = NULL ;
   //  these fields track amount of each buffer used.

   lpStringPtr = lpStringTable ;
   curOffset = 0 ;  // offset to current position in lpOptionsBlock.

  // Now actually start to fill in the PRINTERINFO structure--since our
  // memory is initialized to zero, any fields that aren't used are already
  // set appropriately.


  ConvertGeneralInfo(lpOldPrint,lpModelName,&WPXblock);

  InitializeMainKeyHdrs(&WPXblock);  


  if(lpPI->devcaps.SupportsDuplexing = OLDIS_DUPLEX(lpOldPrint))
     /*  this is NOT a == conditional */
     ConvertDuplexCommands(lpOldStrings,&WPXblock);

  ConvertPaperSizes(lpOldPrint,lpOldStrings,&WPXblock);
  ConvertPaperSlots(lpOldPrint,lpOldStrings,&WPXblock);
  ConvertResolutionInfo(&WPXblock);


  // Go convert the font directories
  ConvertFontEntries(lpOldHead,&WPXblock);

//  no more writing to buffers  lpOptionsBlock or lpStringTable is allowed.

   //  now initialize WPXHead with all relavent offsets.


   WPXHead.PrinterInfo_len   = PrinterInfo_len  ;
   WPXHead.OptionArray_len   = curOffset ;
   WPXHead.stringtab_len     = lpStringPtr - lpStringTable ;
   WPXHead.UI_constraint_len = 0 ;

   WPXHead.PrinterInfo_loc   = (long)sizeof(WPX_HEADER);
   WPXHead.OptionArray_loc   = WPXHead.PrinterInfo_loc + WPXHead.PrinterInfo_len  ;
   WPXHead.stringtab_loc     = WPXHead.OptionArray_loc + WPXHead.OptionArray_len ;
   WPXHead.UI_constraint_loc = WPXHead.stringtab_loc + WPXHead.stringtab_len ;


  lpWPXbuffer=GlobalAllocPtr(GHND, 
      WPXHead.UI_constraint_loc + WPXHead.UI_constraint_len);

  if(!lpWPXbuffer)
    goto  ConvertFormatFailed ;

  //  transfer contents of WPX blocks into lpWPXbuffers

  _fmemcpy(lpWPXbuffer, &WPXHead, sizeof(WPX_HEADER));

  lpTgt = ADVANCE_BYTES(lpWPXbuffer,WPXHead.PrinterInfo_loc);

  _fmemcpy(lpTgt, (LPBYTE)lpPI, WPXHead.PrinterInfo_len);

  lpTgt = ADVANCE_BYTES(lpWPXbuffer,WPXHead.OptionArray_loc);

  _fmemcpy(lpTgt, lpOptionsBlock, WPXHead.OptionArray_len);

  lpTgt = ADVANCE_BYTES(lpWPXbuffer,WPXHead.stringtab_loc);

  _fmemcpy(lpTgt, lpStringTable, WPXHead.stringtab_len);

  //  no UIConstraints info to copy!


   goto  cleanupConvertFormat ;

ConvertFormatFailed:
  if(lpWPXbuffer)
      GlobalFreePtr(lpWPXbuffer) ;
   lpWPXbuffer = NULL ;

cleanupConvertFormat:
  if(lpPI)
      GlobalFreePtr(lpPI) ;
  if(lpOptionsBlock)
      GlobalFreePtr(lpOptionsBlock) ;
  if(lpStringTable)
      GlobalFreePtr(lpStringTable) ;
   

  return (LPWPX_HEADER)lpWPXbuffer ;
}



//-------------------------*WriteNewWPD*-------------------------------
// Action: Change the passed in name to *.WPX and write out the memory
//         block referenced by lpNewWPD.
//
// Side effect: This will write the fully qualified name of the output
//              file into the buffer pointer to by lpPath if we're
//              successful (This is the buffer the caller supplies).
//
// Return: TRUE if successful, FALSE if not
//---------------------------------------------------------------------
BOOL NEAR PASCAL WriteNewWPD(LPSTR              lpOldFileName,
                             LPWPX_HEADER lpWPXHead,
                             LPSTR              lpPath,
                             WORD               wBufSize)
{
  PSTR  pNewFile;
  BOOL  bSuccess=FALSE;

  // Allocate a buffer big enough to hold the new file name
  if(pNewFile=(PSTR)LocalAlloc(LPTR,_MAX_PATH))
  {
    // Create the new file name by appending the old file name to the
    // specified path and then changing the extension from "WPD" to "WPX"
    HFILE hWPD;
    WORD  wFileSize;
    WORD  wWrittenSize;

    pNewFile[wsprintf(pNewFile,"%s\\%s",lpPath,lpOldFileName)-1]='X';
    
    // Write the file

    hWPD=_lcreat(pNewFile,0);

    if(HFILE_ERROR!=hWPD)
    {
      wFileSize= 
         (WORD)(lpWPXHead->UI_constraint_loc + lpWPXHead->UI_constraint_len) ;

      wWrittenSize=_lwrite(hWPD,lpWPXHead,wFileSize);
      _lclose(hWPD);

      // Check to see if entire file was written
      if(wFileSize==wWrittenSize)
      {
        WORD wLoop;
        PSTR pWalk;

        // Copy wBufSize bytes to the buffer
        for(wLoop=0,pWalk=pNewFile;
            wLoop<wBufSize && (*lpPath++ = *pWalk++);
            wLoop++);

        // Check case where string exceeded buffer.
        if(wLoop==wBufSize)
          *(--lpPath)='\0';

        bSuccess=TRUE;
      }
      else
      {
        // Couldn't write entire file--remove what we wrote.
        remove(pNewFile);
      }
    }

    LocalFree((HLOCAL)pNewFile);
  }
  return bSuccess;
}
      


//------------------------*ConvertOldWPD*------------------------------
// Action: Find the WPD file for the specified printer, and convert it
//         to the new format. Places to look for the old WPD file:
//         System Directory, Windows Directory. Write the converted
//         file name in the directory specified by lppath, and update
//         lpPath to include the fully-formed file name.
//
//    lpModelName is caller supplied, 
//    lpPath is set by caller to point to subdir
//    the new WPX file should be placed in.  Upon successful
//    return, it is appended with the name of the WPX file,
//    generating a full pathname.  
//    wBufSize is the size of lpPath.  should be large enough to
//    hold full path to new WPX file.
//
// Return: TRUE if file is found and converted, FALSE if not
//---------------------------------------------------------------------
BOOL FAR PASCAL ConvertOldWPD(LPSTR lpModelName,
                               LPSTR lpPath,
                               WORD  wBufSize)
{
  BYTE               szBuf[_MAX_PATH];
  LPOLDPS_RES_HEADER lpOldWPD;
  LPWPX_HEADER       lpNewWPX;
  BOOL               bReturn=FALSE;

  // If the buffer size is 0, we can't do anything anyway, so fail now
  if(!wBufSize)
    return FALSE;

  // Normal installation--WPD in system directory
  GetDriverDirectory(szBuf, _MAX_PATH);
  lpOldWPD=GropeForOldWPDinDirectory(szBuf,lpModelName);
  if(!lpOldWPD)
  {
    // Network installation--WPD in windows directory
    GetWindowsDirectory(szBuf,_MAX_PATH);
    lpOldWPD=GropeForOldWPDinDirectory(szBuf,lpModelName);
    if(!lpOldWPD)
      // Couldn't find a matching model
      return FALSE;
  }

  // lpOldWPD contains the old WPD file, and szBuf contains the 8.3 filename
  // of the file that we read. Write the new file in the specified path.

  if(lpNewWPX=ConvertFormat(lpOldWPD,lpModelName))
  {
    if(WriteNewWPD(szBuf,lpNewWPX,lpPath,wBufSize))
      bReturn=TRUE;

    GlobalFreePtr(lpNewWPX);
  }

  GlobalFreePtr(lpOldWPD);
  return bReturn;
}

////////////////////////////////////////////////////////////////////////////
//                    SERVICE ROUTINES FOR PARSER
////////////////////////////////////////////////////////////////////////////


//------------------------*GetStringRef------------------------------------
// Action: Copy a string from a STRINGREF to an array & return the length
//         of the string. Don't exceed the array size, but NULL-terminate
//         the string. If lpBuffer is NULL, return the size of the string,
//         plus 1 byte for the NULL.
//
// Return: Length of the string
//-------------------------------------------------------------------------
WORD GetStringRef(LPSTRINGREF lpRef,
                  LPBYTE      lpStrings,
                  LPSTR       lpBuffer,
                  WORD        wBufSize)
{
  LPSTR lpSource;
  WORD  wCount;

  if(!lpBuffer)
    return lpRef->w.length+1;

  for(wCount=0,lpSource=lpStrings+lpRef->w.offset;
      wCount<min(wBufSize-1,lpRef->w.length);
      wCount++)
    *lpBuffer++=*lpSource++;

  *lpBuffer='\0';

  return wCount;
}



//----------------------------*MapString*----------------------------------
// Action: Map the string pointer passed in to an ID value, using the
//         specified resources as the translation table. This code is
//         used for mapping both paper sizes and paper slots.
//
// Return: Mapped ID if successful, NOMAP if error.
//-------------------------------------------------------------------------
WORD NEAR PASCAL MapString(LPSTR lpTarget,
                           WORD  wFirstResource,
                           WORD  wLastResource)
{
  WORD wLoop;
  BYTE szBuffer[256];

  if(wFirstResource>wLastResource)
    return NOMAP;

  for(wLoop=wFirstResource;wLoop<=wLastResource;wLoop++)
  {
    if(LoadString(ghDriverMod,wLoop,szBuffer,sizeof(szBuffer)) &&
       !lstrcmp(lpTarget,szBuffer))
      return (wLoop-wFirstResource);
  }

  return NOMAP;
}


//------------------------------*IsUSA*-----------------------------------//
//  Read win.ini and return country code
//
//  Note that if a country was set up, it will have a valid nonzero country
//  code.
//
//  This version of the function returns TRUE for ANY Western-hemisphere
//  country  (USA, CANADA, any area with dial code beginning with 5:
//  5n, 5nn). Unabashedly taken from Unidrv.
//------------------------------------------------------------------------//
#define USA_COUNTRYCODE   1
#define FRCAN_COUNTRYCODE 2

BOOL NEAR PASCAL IsUSA()
{
    int iCountry;

    iCountry = GetProfileInt("intl", "icountry", USA_COUNTRYCODE);
    switch(iCountry)
    {
        case 0:                         // string was there but 0
        case USA_COUNTRYCODE:           // DEFINED in COUNTRY.H
        case FRCAN_COUNTRYCODE:
                return TRUE;

        default:
                if (((iCountry >= 50) && (iCountry < 60)) ||
                    ((iCountry >= 500) && (iCountry < 600)))
                    return TRUE;
                else
                    return FALSE;
    }

}


void NEAR PASCAL InitializeMainKeyHdrs(LPWPXBLOCKS  lpWPX)
{
   WORD  i ;
   LPMAINKEYHDR  lpMainKeyHdrs ;
   LPPRINTERINFO  lpPI ;

   lpPI = (LPPRINTERINFO)lpWPX->WPXprinterInfo ;
   lpMainKeyHdrs = lpPI->mainKeyHdrs ;

   lpPI->OrderListRoot.ExitServer =
   lpPI->OrderListRoot.Prolog =
   lpPI->OrderListRoot.Unassigned =  // emit this after pagesetup.
   lpPI->OrderListRoot.DocumentSetup =
   lpPI->OrderListRoot.PageSetup =
   lpPI->OrderListRoot.JCLSetup =  
   lpPI->OrderListRoot.AnySetup =  0xFFFF;


   for(i = 0 ; i < IND_NUMPREDEFINEDHDRS ; i++)
   {
      lpMainKeyHdrs[i].MainKeyID = 0 ;
      lpMainKeyHdrs[i].MainKey.dword = 0L ;
      lpMainKeyHdrs[i].MainTranslation.dword = 0L ;
      lpMainKeyHdrs[i].OptionQuery.dword = 0L ; 
      lpMainKeyHdrs[i].order.ArrayIndex = 0xFFFF  ;  // end of list
      lpMainKeyHdrs[i].order.PPDorderValue = 0  ;
      lpMainKeyHdrs[i].OrderListRoot = 0xFFFF  ;  // nothing in List
      lpMainKeyHdrs[i].UItype = PICKONE ;
      lpMainKeyHdrs[i].OptionKeyWords.dword = 0 ;
      lpMainKeyHdrs[i].extraOptionArray = 0 ; 
      lpMainKeyHdrs[i].DefaultOptionIndex = 0 ; 
      lpMainKeyHdrs[i].NoneOptionIndex = 0xFFFF  ;  // none option doesn't exist
   }

}


int FAR PASCAL ExtractDefInputSlotFromWPD(LPSTR lpModelName)
{
  LPOLDPRINTER        lpOldPrint;
  BYTE               szBuf[_MAX_PATH];
  LPOLDPS_RES_HEADER lpOldWPD;
  int               iReturn = -1;



  // Normal installation--WPD in system directory
  GetDriverDirectory(szBuf, _MAX_PATH);
  lpOldWPD=GropeForOldWPDinDirectory(szBuf,lpModelName);
  if(!lpOldWPD)
  {
    // Network installation--WPD in windows directory
    GetWindowsDirectory(szBuf,_MAX_PATH);
    lpOldWPD=GropeForOldWPDinDirectory(szBuf,lpModelName);
    if(!lpOldWPD)
      // Couldn't find a matching model
      return iReturn;
  }

  // lpOldWPD contains the old WPD file, and szBuf contains the 8.3 filename
  // of the file that we read. 

  lpOldPrint=(LPOLDPRINTER)ADVANCE_BYTES(lpOldWPD,lpOldWPD->cap_loc);

  iReturn = (WORD)lpOldPrint->defFeed ;

  GlobalFreePtr(lpOldWPD);
  return iReturn;
}

/*****************************************************************************/
/*                 GetDriverDircetory                                        */
/*                                                                           */
/* Purpose: Get the full path of the directory where our driver was loaded.  */
/*                                                                           */
/* Parameters:                                                               */
/*   LPSTR lpDir -- pointer to a buf to hold the driver dir path             */
/*   WORD  cnt   -- number of bytes of the buf                               */
/*                                                                           */
/* Returns: int                                                              */
/*****************************************************************************/
UINT FAR PASCAL GetDriverDirectory(LPSTR lpDir, WORD cnt)
{
   LPSTR lpTmpPt;
   UINT  len;

   len = GetModuleFileName(ghDriverMod, lpDir, cnt);
   if(len)
   {
      // get only the path name, get rid of the file name
      lpTmpPt = lpDir + len;
      while(*lpTmpPt != '\\')
      {
         lpTmpPt--;   
      }
      *lpTmpPt = '\0';
      len = lstrlen(lpDir);
   }
   return(len);
}


