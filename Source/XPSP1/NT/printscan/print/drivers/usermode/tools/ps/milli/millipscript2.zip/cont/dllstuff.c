
/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DLLSTUFF.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for our existance as a    */
/*              DLL and some global string setup.                            */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "vmdapriv.h"
#include "regsetup.h"

#pragma code_seg(_TEXTSEG)


// jmp_buf ErrJmpVector;        /* To be removed later */
char LocalStringBuffer[128];  /* To be removed later */

HANDLE ghDriverMod = NULL;
char szNone[5];
char szHelpFile[13];
char szIniCreator[64];             /* ADOBEPS.DRV Version 4.1 (via registry)*/
char szOne[2];
char szTwo[2];
char szThree[2];
char szFont[6];
BOOL bATMWorkAround = FALSE;
BOOL bATMLoaded = FALSE;
LPSTR** AliasTable = NULL;
LPSTR* IncorrectFixedFontList = NULL;
LPSTR* PrefCJKFontList = NULL;

LPSTR* EncodeNameList = NULL;
LPSTR* MacGlyphNameList = NULL;

typedef BOOL (FAR PASCAL *LPISDBCSCHARSET)(BYTE);
typedef BOOL (FAR PASCAL *LPISDBCSLEADBYTEEX)(BYTE, BYTE);
typedef LPSTR (FAR PASCAL *LPGETLEADBYTEVECTOR)(BYTE);
// Global Function pointers to CJK-GDI
LPISDBCSCHARSET lpIsDBCSCharSet = NULL;
LPISDBCSLEADBYTEEX lpIsDBCSLeadByteEx = NULL;
LPGETLEADBYTEVECTOR lpGetLeadByteVector = NULL;

LPSTR lpCJKLeadBytePtr = NULL;
LPSTR lpszLeadByte128 = NULL;
LPSTR lpszLeadByte129 = NULL;
LPSTR lpszLeadByte130 = NULL;
LPSTR lpszLeadByte134 = NULL;
LPSTR lpszLeadByte136 = NULL;

BYTE DefaultCJKCharSet=0; // used for CJK-Font Relization and CJK-CMap downloading

void EmulateGDIFuncs(void);

void LoadGlobalStrings(void);
int AllocCJKLeadByteBuffer();
int FreeCJKLeadByteBuffer();



/***************************************************************************
*  NOTE:
*       if we implement a list of handles, the list should be initialized
*       in LibMain and the cleanup function should be called in WEP.
****************************************************************************/
/****************************************************************************
*                          LibMain
*  function:
*            called by LibEntry.  LibEntry is called by Windows when
*            the DLL is loaded.  The LibEntry routine is provided in
*            the LIBENTRY.OBJ in the SDK Link Libraries disk.  (The
*            source LIBENTRY.ASM is also provided.)
*
*            LibEntry initializes the DLL's heap, if a HEAPSIZE value is
*            specified in the DLL's DEF file.  Then LibEntry calls
*            LibMain.  The LibMain function below satisfies that call.
*
*  prototype:
*       int FAR PASCAL LibMain(HANDLE hModule, WORD wDataSeg,
*                              WORD cbHeapSize, LPSTR lpszCmdLine)
*  parameters:
*       HANDLE hModule -- the module handle
*       WORD   wDataSeg -- the data segment descriptor
*       WORD   cbHeapSize -- heap
*       LPSTR  lpszCmdLine -- string containing the command line
*  returns:
*       int   1 => success
*             0 => failure
****************************************************************************/

int FAR PASCAL LibMain(hModule, wDataSeg, cbHeapSize, lpszCmdLine)
   HANDLE  hModule;
   WORD    wDataSeg;
   WORD    cbHeapSize;
   LPSTR   lpszCmdLine;
{
	char static szMsgSrvrClass[] = SZMESSAGESERVERCLASS;
    HWND hwndMsgSrvr;

    ghDriverMod = hModule;

    INIT_MEMTRACE();

	// Load font resources in RCDATA format.

	if (LoadAliasTable() == FALSE)
	{
		return FALSE;
	}

	if (LoadIncorrectFixedFontList() == FALSE)
	{
		FreeAliasTable();
		return FALSE;
	}

	if (LoadPreferredCJKFontList() == FALSE)
	{
		FreeAliasTable();
		FreeIncorrectFixedFontList();
		return FALSE;
	}

	if (AllocCJKLeadByteBuffer() == FALSE)
	{
		FreeAliasTable();
		FreeIncorrectFixedFontList();
    	FreePreferredCJKFontList();
		return FALSE;
	}
    

	// Load any other strings.

    LoadGlobalStrings();

    EmulateGDIFuncs();
    
    // Check to see if ATM is loaded, and if workaround is needed.

    if (bATMLoaded = GetModuleHandle("ATM"))
    {
        bATMWorkAround = GetProfileInt("PScript.Drv", "ATMWorkaround", 0);
    }

    // Tell msgsrvr we are loaded so that he can cache a hdc to the
    // current printer for performance...
	// INH_PRINTERDRIVERLOADED == 0x109 defined in inherit.h in dos386 tree.

    hwndMsgSrvr = FindWindowEx(NULL, NULL, szMsgSrvrClass, NULL);

    if (hwndMsgSrvr)
    {
        PostMessage(hwndMsgSrvr, WM_USER+0x109, 0, 0L);
    }


   return TRUE;

} // END LibMain


/****************************************************************************
*                               DevWEP
*  function:
*       called by Windows when the DLL is unloaded.
*  prototype:
*       int FAR PASCAL WEP(int bSystemExit);
*  parameters:
*       int bSystemExit -- TRUE => whole system is stopping
*  returns:
*       int 1 => success
*****************************************************************************/

int _loadds CALLBACK DevWEP (bSystemExit)
   int  bSystemExit;
{
	TerminateWPXcache();

	FreeFontCacheMemory();

	END_MEMTRACE();

	// Unload font resources allocated in LibMain function.

	FreeAliasTable();

	FreeIncorrectFixedFontList();

	FreePreferredCJKFontList();

    FreeCJKLeadByteBuffer();


//#ifdef STREAMER
	FreeEncodeNameList();
//#endif	
        FreeMacGlyphNameList();
	return(1);
} // END DevWEP


/****************************************************************************
*                               LoadGlobalStrings
*  function:
*    This function loads many useful strings into global storage.
*  prototype:
*       void LoadGlobalStrings()
*  parameters:
*       NONE
*  returns:
*       VOID
*****************************************************************************/

void LoadGlobalStrings()
{
   LoadDrvrString(ghDriverMod, GLBL_szNone, szNone, sizeof(szNone));
   LoadDrvrString(ghDriverMod, GLBL_szOne, szOne, sizeof(szOne));
   LoadDrvrString(ghDriverMod, GLBL_szTwo, szTwo, sizeof(szTwo));
   LoadDrvrString(ghDriverMod, GLBL_szThree, szThree, sizeof(szThree));
   LoadDrvrString(ghDriverMod, GLBL_szFont, szFont, sizeof(szFont));
}


/****************************************************************************
*                      int GetDefaultCJKCharSet()
*  function:
*    This function returns the default CharSet val for CJK Win95.
*  prototype:
*  int GetDefaultCJKCharSet()
*  parameters:
*       NONE
*  returns:
*       CharSet as in LogFont
*****************************************************************************/
BYTE GetDefaultCJKCharSet()
{
    int           myCountry, charSet;
    char          szIntl[20], szCountry[40];
    LoadString(ghDriverMod, IDS_INTL, szIntl, 20);
    LoadString(ghDriverMod, IDS_COUNTRY, szCountry, 40);
    myCountry = GetProfileInt((LPSTR) szIntl, (LPSTR) szCountry, 
                                USA_COUNTRYCODE) ;
      switch(myCountry)
      {  // We need correct number for CJK only.
         case 86: // PRC
           charSet = 134; // GB2312_CHARSET;
           break;

         case 886: // Taiwan
           charSet = 136; // CHINESEBIG5_CHARSET;
           break;

         case 81: //J
           charSet = 128; // SHIFTJIS_CHARSET;
           break;

         case 82:  // K
           charSet = 129; //129=HANGEUL_CHARSET; 130=JOHAB_CHARSET is not used on Win95
           break;

         default:
           charSet = 0;  // All Western use 0.
           break;
      }
    return (BYTE)charSet;
}

/****************************************************************************
*                               EmulateGDIFuncs
*  function:
*    This function emulates/loads several useful GDI/Sys functions to unify CJK and US
*        ISDBCSCHARSET         = GDI.905
*        GETLEADBYTEVECTOR     = GDI.906
*        ISDBCSLEADBYTEEX      = GDI.907
*  prototype:
*       void EmulateGDIFuncs()
*  parameters:
*       NONE
*  returns:
*       VOID
*****************************************************************************/
void EmulateGDIFuncs()
{
  HANDLE  hGDI = NULL;
  int     i;

  hGDI = GetModuleHandle("GDI.EXE"); // GDI must be loaded already !!
  if (hGDI){
  	 lpIsDBCSCharSet = (LPISDBCSCHARSET) GetProcAddress(hGDI,"ISDBCSCHARSET");
  	 lpIsDBCSLeadByteEx = (LPISDBCSLEADBYTEEX)GetProcAddress(hGDI,"ISDBCSLEADBYTEEX");
  	 lpGetLeadByteVector = (LPGETLEADBYTEVECTOR)GetProcAddress(hGDI,"GETLEADBYTEVECTOR");
  }
  
  

  if (!lpGetLeadByteVector ||
      !lpIsDBCSLeadByteEx){
     // Initial global LeadByteVectors -- only once per DLLMain()
     for (i=0;i<255;i++) lpszLeadByte128[i]=(char)0;
     for (i=0;i<255;i++) lpszLeadByte129[i]=(char)0;
     for (i=0;i<255;i++) lpszLeadByte130[i]=(char)0;
     for (i=0;i<255;i++) lpszLeadByte134[i]=(char)0;
     for (i=0;i<255;i++) lpszLeadByte136[i]=(char)0;
     // We hard-code these bounds here because they are not going to change for Win95:
     // J
     for (i=0x81;i<=0x9F;i++) lpszLeadByte128[i]=(char)1;
     for (i=0xE0;i<=0xEF;i++) lpszLeadByte128[i]=(char)1;
     for (i=0xfa;i<=0xFc;i++) lpszLeadByte128[i]=(char)1;
     // K-Hangeul
     for (i=0x81;i<=0xFE;i++) lpszLeadByte129[i]=(char)1;
     // K-Johab
     for (i=0x84;i<=0xD3;i++) lpszLeadByte130[i]=(char)1;
     for (i=0xD9;i<=0xDE;i++) lpszLeadByte130[i]=(char)1;
     for (i=0xE0;i<=0xF9;i++) lpszLeadByte130[i]=(char)1;
     //CS
     for (i=0x81;i<=0xFE;i++) lpszLeadByte134[i]=(char)1;
     //CT
     for (i=0xA1;i<=0xFA;i++) lpszLeadByte136[i]=(char)1;
  }
  // Set a global - to be used in Realize.c and CMap downloading.
  DefaultCJKCharSet = GetDefaultCJKCharSet();
}

BOOL FAR PASCAL IsDBCSCharSet(BYTE cset)
{
int ics = (int)cset;
  if (lpIsDBCSCharSet){
     return (*lpIsDBCSCharSet)(cset);
  }
  else{
  	return (ics==128 || ics==129 || ics==130 ||
            ics==134 || ics==136);
  }
}

LPSTR   FAR PASCAL GetLeadByteVector(BYTE cset)
{
  if (lpGetLeadByteVector){
     return (*lpGetLeadByteVector)(cset);
  }
  else{
    switch(cset){
        case 128:
           return lpszLeadByte128; break;
        case 129:
           return lpszLeadByte129; break;
        case 130:
           return lpszLeadByte130; break;
        case 134:
           return lpszLeadByte134; break;
        case 136:
           return lpszLeadByte136; break;
        default:
           // caller knows not to call this for non-DBCS charset.
           return NULL;  break;
    }
  }
}


BOOL  FAR PASCAL IsDBCSLeadByteEx(BYTE cset, BYTE byte)
{
  LPSTR  lpLeadV;
  if (!IsDBCSCharSet(cset)) return FALSE;
  if (lpIsDBCSLeadByteEx){
     return (*lpIsDBCSLeadByteEx)(cset, byte);
  }
  else{
     lpLeadV=GetLeadByteVector(cset);
     return lpLeadV[byte];
  }
}


int AllocCJKLeadByteBuffer()
{
  lpCJKLeadBytePtr = (LPSTR) GlobalAllocPtr(GHND | GMEM_SHARE, (256 * 5));
  if (lpCJKLeadBytePtr == NULL)
    return 0;

  lpszLeadByte128 = lpCJKLeadBytePtr + (256 * 0);
  lpszLeadByte129 = lpCJKLeadBytePtr + (256 * 1);
  lpszLeadByte130 = lpCJKLeadBytePtr + (256 * 2);
  lpszLeadByte134 = lpCJKLeadBytePtr + (256 * 3);
  lpszLeadByte136 = lpCJKLeadBytePtr + (256 * 4);

  return 1;
}

int FreeCJKLeadByteBuffer()
{
    if (lpCJKLeadBytePtr != NULL)
        GlobalFreePtr(lpCJKLeadBytePtr);

    return 1;
}
