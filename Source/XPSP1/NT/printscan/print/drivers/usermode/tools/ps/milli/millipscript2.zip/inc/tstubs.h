/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: TSTUBS.H                                               */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

//              -----   Pens     -----

SHORT FAR PASCAL rTPen           (LPPPEN                                 );
SHORT FAR PASCAL rTPenCap        (BYTE                                   );
SHORT FAR PASCAL rTPenFGColor    (DWORD                                  );
SHORT FAR PASCAL rTPenBGColor    (DWORD                                  );
SHORT FAR PASCAL rTPenJoin       (BYTE                                   );
SHORT FAR PASCAL rTPenMiterLimit (SHORT                                  );
SHORT FAR PASCAL rTPenStyle      (BYTE                                   );
SHORT FAR PASCAL rTPenWidth      (POINT                                  );


//              -----   Brushes  -----

SHORT FAR PASCAL rTBrushBGColor  (DWORD                                  );
SHORT FAR PASCAL rTBrushFGColor  (DWORD                                  );
SHORT FAR PASCAL rTBrushHatch    (BYTE                                   );
SHORT FAR PASCAL rTBrushPattern  (LPPAT                                  );
SHORT FAR PASCAL rTBrushStyle    (BYTE                                   );


//              -----   Shapes   -----

SHORT FAR PASCAL rTArc           (LPRECT ,LPPOINT,LPPOINT            );
SHORT FAR PASCAL rTChord         (LPRECT ,FLAG ,FLAG,LPPOINT,LPPOINT );
SHORT FAR PASCAL rTEllipse       (LPRECT ,FLAG ,FLAG                 );
SHORT FAR PASCAL rTCircle        (LPRECT ,FLAG ,FLAG                 );
SHORT FAR PASCAL rTLine          (LPPOINT                            );
SHORT FAR PASCAL rTPie           (LPRECT ,FLAG ,FLAG,LPPOINT,LPPOINT );
SHORT FAR PASCAL rTPolygon       (LPPOINT,FLAG ,FLAG,FLAG,SHORT      );
SHORT FAR PASCAL rTPolyLine      (LPPOINT,SHORT                      );
SHORT FAR PASCAL rTRectangle     (LPRECT ,FLAG ,FLAG                 );
SHORT FAR PASCAL rTRoundRectangle(LPRECT ,FLAG ,FLAG,LPPOINT         );
SHORT FAR PASCAL rTScanLine      (LPPOINT,FLAG ,FLAG,SHORT           );
SHORT FAR PASCAL rTScanLineBegin (FLAG,FLAG                          );
SHORT FAR PASCAL rTScanLineEnd   (VOID                               );
SHORT FAR PASCAL rTPolyMode      (BYTE                               );

//              -----   Bitmaps  -----
SHORT FAR PASCAL rTBMOpaqueBox   (LPRECT,DWORD                       );
SHORT FAR PASCAL rTOpaqueBox     (LPRECT,DWORD,WORD                  );
SHORT FAR PASCAL rTBitmapHeader  (LPRECT ,LPRECT,FLAG                );
SHORT FAR PASCAL rTBitmapData    (LPPDEVICE,LPBITMAP,LPRECT          );


//              -----   Management  -----

SHORT FAR PASCAL rTDriverData    (LPPDEVICE,SHORT              );
SHORT FAR PASCAL rTDocumentPage  (void                         );
SHORT FAR PASCAL rTDocumentAbort (void                         );
SHORT FAR PASCAL rTDocumentEnd   (void                         );
SHORT FAR PASCAL rTDocumentFlush (void                         );
SHORT FAR PASCAL rTDocumentBegin (void                         );
SHORT FAR PASCAL rTClipRect      (LPPDEVICE,LPRECT,LPRECT,int  );
SHORT FAR PASCAL rTClipEnd       (VOID                         );
SHORT FAR PASCAL rTJobType       (SHORT                        );
SHORT FAR PASCAL rTJobTitle      (LPSTR                        );
SHORT FAR PASCAL rTJobCopies     (WORD                         );
SHORT FAR PASCAL rTJobDuplex     (WORD                         );
SHORT FAR PASCAL rTBackgroundMode(BYTE                         );
SHORT FAR PASCAL rTColorBG       (DWORD                        );
SHORT FAR PASCAL rTArcDirection  (BYTE                         );
SHORT FAR PASCAL rTICMColor      (LPPDEVICE, DWORD             );

//              ----   Escapes ---------

SHORT FAR PASCAL rTRawPrinterStart(VOID);
SHORT FAR PASCAL rTRawPrinterData(LP , WORD );
SHORT FAR PASCAL rTRawPrinterEnd(VOID);
