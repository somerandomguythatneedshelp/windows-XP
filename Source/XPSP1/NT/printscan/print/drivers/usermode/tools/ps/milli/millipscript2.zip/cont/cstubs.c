/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: CSTUBS.C                                                     */
/*                                                                           */
/* Description: This module contains the function for ...                    */
/*                                                                           */
/* Change History:                                                           */
/* L3_MASK -- Support level3 transparent image.  9/19/96   jjia              */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_GRAPHSEG)


/***************************************************************************
*                               CArcDirection
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CArcDirection(LPPDEVICE lppd,BYTE Direction);
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       BYTE      Direction -- ...
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CArcDirection(LPPDEVICE lppd,BYTE Direction)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTArcDirection)(lppd, Direction);  // From ESCSetArcDirection
   return(TRUE);
} // END CArcDirection



/***************************************************************************
*                               CBackgroundMode
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CBackgroundMode(LPPDEVICE lppd, BYTE BackgroundMode);
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       BYTE      BackgroundMode -- ...
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CBackgroundMode(LPPDEVICE lppd, BYTE BackgroundMode)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTBackgroundMode)(lppd, BackgroundMode);
   return(TRUE);
} // END CBackgroundMode


// Bitmaps and DIBs

/***************************************************************************
*                               CBitmapHeader
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CBitmapHeader(LPPDEVICE lppd,LPRECT SrcRect,
*                                      LPRECT DstRect,DWORD rop);
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       LPRECT    SrcRect -- ...
*       LPRECT    DstRect -- ...
*       DWORD     rop -- ...
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CBitmapHeader(LPPDEVICE lppd,LPRECT SrcRect,LPRECT DstRect,DWORD rop)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTBitmapHeader)(lppd,SrcRect,DstRect,rop);
   return(TRUE);
} // END CBitmapHeader


/***************************************************************************
*                               CBitmapOperator
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CBitmapOperator(LPPDEVICE lppd,DWORD FGColor,
*                                        DWORD BGColor,DWORD rop);
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       DWORD     FGColor --
*       DWORD     BGColor --
*       DWORD     rop --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CBitmapOperator(LPPDEVICE lppd,BOOL bTransparent,
                                 DWORD FGColor,DWORD BGColor,DWORD rop)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTBitmapOperator)(lppd,bTransparent,FGColor,BGColor,rop);
   return(TRUE);
} // END CBitmapOperator


/***************************************************************************
*                               CBitmapData
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CBitmapData(LPPDEVICE lppd,LPBITMAP DevBitmap,
*                                    LPRECT SrcRect, SHORT FirstSegScans );
*  parameters:
*       LPPDEVICE   lppd -- pointer to PDEVICE or BITMAP
*       LPBITMAP DevBitmap --
*       LPRECT      SrcRect --
*       SHORT       FirstSegScans --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CBitmapData(LPPDEVICE lppd,LPBITMAP DevBitmap,LPRECT SrcRect, SHORT FirstSegScans )
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTBitmapData)(lppd, DevBitmap,SrcRect, FirstSegScans );
   return(TRUE);
} // END CBitmapData


/***************************************************************************
*                               CDIBDataBits
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CDIBDataBits(LPPDEVICE lppd,LPRECT SrcRect,LPSTR lpBits,
*                                     LPBITMAPINFO lpBitmapInfo);
*  parameters:
*       LPPDEVICE    lppd -- pointer to PDEVICE or BITMAP
*       LPRECT       SrcRect --
*       LPSTR        lpBits --
*       LPBITMAPINFO lpBitmapInfo -- 
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
//L3_MASK FAST_IMAGE
//short FAR PASCAL CDIBDataBits(LPPDEVICE lppd,LPRECT SrcRect,LPSTR lpBits,
//                              LPBITMAPINFO lpBitmapInfo)
short FAR PASCAL CDIBDataBits(LPPDEVICE lppd,LPDRAWMODE lpdm,
                              LPRECT SrcRect, LPRECT DstRect, LPSTR lpBits,
                              LPBITMAPINFO lpBitmapInfo,
                              LPSTR lpGrayTable, SHORT FastImgType,
                              float far * ResampleRatio)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   // L3_MASK FAST_IMAGE
   (*tempptr->rTDIBDataBits)(lppd,lpdm,SrcRect,DstRect,
                             lpBits,lpBitmapInfo,
                             lpGrayTable, FastImgType,
                             ResampleRatio);
   return(TRUE);
} // END CDIBDataBits

// L3_MASK begin
/***************************************************************************
*                               CDIBClipRgns
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CDIBClipRgns(LPPDEVICE lppd,LPRECT DstRect,
*                                     LPRECT SrcRect,LPSTR lpBits,
*                                     LPBITMAPINFO lpBitmapInfo);
*  parameters:
*       LPPDEVICE    lppd    -- pointer to PDEVICE or BITMAP
*       LPRECT       DstRect --
*       LPRECT       SrcRect --
*       LPSTR        lpBits  --
*       LPBITMAPINFO lpBitmapInfo -- 
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CDIBClipRgns(LPPDEVICE lppd, LPDRAWMODE lpdm,
                              LPRECT DstRect, LPRECT SrcRect,
                              LPSTR lpBits,LPBITMAPINFO lpBitmapInfo)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTDIBClipRgns)(lppd, lpdm,DstRect, SrcRect,lpBits,lpBitmapInfo);
   return(TRUE);
} // END CDIBDataBits
// L3_MASK end

/***************************************************************************
*                               CDIBHeader
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CDIBHeader(LPPDEVICE lppd,LPRECT SrcRect,LPRECT DstRect,
*                                   short BitsPerSample)
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       LPRECT    SrcRect --
*       LPRECT    DstRect --
*	short	  BitsPerSample --
*	BOOL	  bCMYK --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
// L3_MASK  FAST_IMAGE
short FAR PASCAL CDIBHeader(LPPDEVICE lppd,LPDRAWMODE lpdm, 
                            LPRECT SrcRect,LPRECT DstRect,
                            BOOL bCMYK, LPBITMAPINFO lpBitmapInfo,
                            SHORT FastImgType,
                            float far * ResampleRatio)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   // L3_MASK  FAST_IMAGE
   (*tempptr->rTDIBHeader)(lppd, lpdm, SrcRect,DstRect,bCMYK,
                           lpBitmapInfo, FastImgType, ResampleRatio);
   return(TRUE);
} // END CDIBHeader


/***************************************************************************
*                               CDIBOperator
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CDIBOperator(LPPDEVICE lppd, short BitsPerSample);
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       short     BitsPerSample
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CDIBOperator(LPPDEVICE lppd, short BitsPerSample,
                              SHORT FastImgType)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTDIBOperator)(lppd, BitsPerSample, FastImgType);
   return(TRUE);
} // END EDIBOperator


/***************************************************************************
*                               CGrayTable
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CGrayTable(LPPDEVICE lppd, LPBYTE GrayTable,WORD TableLen)
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       LPBYTE    GrayTable --
*       WORD      TableLen --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CGrayTable(LPPDEVICE lppd, LPBYTE GrayTable,WORD TableLen)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTGrayTable)(lppd,GrayTable,TableLen);
   return(TRUE);
} // END CGrayTable


/***************************************************************************
*                               CColorTable
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CColorTable(LPPDEVICE lppd, LPDWORD ColorTable,WORD TableLen)
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       LPDWORD   ColorTable --
*       WORD      TableLen --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CColorTable(LPPDEVICE lppd, LPDWORD ColorTable,WORD TableLen)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTColorTable)(lppd,ColorTable,TableLen);
   return(TRUE);
} // END CColorTable


// Text Tokens

/***************************************************************************
*                               CTextBegin
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CTextBegin(LPPDEVICE lppd, LPPOINT CurrentPoint,
*                                   LPPSFONTINFO FontInfo,LPTEXTXFORM TextXForm)
*  parameters:
*       LPPDEVICE   lppd -- pointer to PDEVICE or BITMAP
*       LPPOINT     CurrentPoint --
*       LPPSFONTINFO  FontInfo --
*       LPTEXTXFORM TextXForm --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CTextBegin(LPPDEVICE lppd, LPPOINT CurrentPoint,
                            LPPSFONTINFO FontInfo,LPTEXTXFORM TextXForm)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTTextBegin)(lppd,CurrentPoint,FontInfo,TextXForm);
   return(TRUE);
} // END CTextBegin


/***************************************************************************
*                               CTextRun
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CTextRun(LPPDEVICE lppd, LPSTR String,int count, 
*                                 double breakExtra, double charExtra,
*                                 LPPSFONTINFO FontInfo,LPTEXTXFORM TextXForm);
*  parameters:
*       LPPDEVICE   lppd -- pointer to PDEVICE or BITMAP
*       LPSTR       String --
*       int         count --
*       double      breakExtra --
*       double      charExtra --
*       LPPSFONTINFO  FontInfo --
*       LPTEXTXFORM TextXForm --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CTextRun(LPPDEVICE lppd, LPSTR String,int count, double breakExtra,
                          double charExtra, LPPSFONTINFO FontInfo,
                          LPTEXTXFORM TextXForm, LPINT lpdx)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTTextRun)(lppd,String,count, breakExtra, charExtra,
                         FontInfo,TextXForm, lpdx)   ;
   return(TRUE);
} // END CTextRun


/***************************************************************************
*                               CTextEnd
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CTextEnd(LPPDEVICE lppd,LPPSFONTINFO FontInfo,
*                                 LPTEXTXFORM TextXForm,int extent);
*  parameters:
*       LPPDEVICE   lppd -- pointer to PDEVICE or BITMAP
*       LPPSFONTINFO  FontInfo --
*       LPTEXTXFORM TextXForm --
*       int         extent --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CTextEnd(LPPDEVICE lppd,LPPSFONTINFO FontInfo,LPTEXTXFORM TextXForm,
  int extent)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTTextEnd)(lppd,FontInfo,TextXForm, extent);
   return(TRUE);
} // END CTextEnd


/***************************************************************************
*                               CSoftFontLoad
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CSoftFontLoad(LPPDEVICE lppd,LPPSFONTINFO FontInfo,
*                                      LPTEXTXFORM TextXForm,LPSTR String,
*                                      short sCount);
*  parameters:
*       LPPDEVICE   lppd -- pointer to PDEVICE or BITMAP
*       LPPSFONTINFO  FontInfo --
*       LPTEXTXFORM TextXForm --
*       LPSTR       String --
*       short       sCount --
*  returns:
*       PSERROR
*                                                                           
***************************************************************************/
PSERROR FAR PASCAL CSoftFontLoad(LPPDEVICE lppd,LPPSFONTINFO FontInfo,
                               LPTEXTXFORM TextXForm,LPSTR String,short sCount)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   return (*tempptr->rTSoftFontLoad)(lppd,FontInfo,TextXForm,String,sCount);
} // END CSoftFontLoad 


#ifdef ADD_EURO
PSERROR FAR PASCAL CDeviceFontLoad(LPPDEVICE lppd,LPPSFONTINFO FontInfo,
                               LPTEXTXFORM TextXForm)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   return (*tempptr->rTDeviceFontLoad)(lppd,FontInfo,TextXForm);
} // END CDeviceFontLoad 
#endif

/***************************************************************************
*                               CClipRect
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CClipRect(LPPDEVICE lppd,LPRECT lpRect)
*  parameters:
*       LPPDEVICE lppd   -- pointer to PDEVICE or BITMAP
*       LPRECT    lpRect -- Clip rect
*       LPRECT    lpRealRect --  Real output rect
*       int       Escapement --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CClipRect(LPPDEVICE lppd,LPRECT lpRect,
                           LPRECT lpRealRect, int Escapement)
{
   LPTFUNCTIONPTRS tempptr;
   short           rc = 0;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return( rc );
   rc = (*tempptr->rTClipRect)(lppd,lpRect, lpRealRect, Escapement);
   return( rc );
} // END CClipRect


/***************************************************************************
*                               CClipEnd
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CClipEnd(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CClipEnd(LPPDEVICE lppd)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTClipEnd)(lppd);
   return(TRUE);
} // END CClipEnd


/***************************************************************************
*                               CColorBG
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CColorBG(LPPDEVICE lppd, DWORD Color)
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       DWORD     Color --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CColorBG(LPPDEVICE lppd, DWORD Color)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTColorBG)(lppd,Color);       // From ESCSetBackgroundColor
   return(TRUE);
} // END CClorBG


/***************************************************************************
*                               CPolyMode
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CPolyMode(LPPDEVICE lppd,BYTE PolyMode)
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       BYTE      PolyMode --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CPolyMode(LPPDEVICE lppd,BYTE PolyMode)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTPolyMode)(lppd,PolyMode);
   return(TRUE);
} // END CPolyMode


/***************************************************************************
*                               CPageOrientation
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CPageOrientation(LPPDEVICE lppd,WORD Orient )
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       WORD      Orient --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CPageOrientation(LPPDEVICE lppd,WORD Orient )
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTPageOrientation)(lppd, Orient );
   return(TRUE);
} // END CPageOrientation


/***************************************************************************
*                               CPaperSource
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CPaperSource(LPPDEVICE lppd,LPSTR slot_name)
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       LPSTR     slot_name --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CPaperSource(LPPDEVICE lppd,LPSTR slot_name)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTPaperSource)(lppd,slot_name);
   return(TRUE);
} // END CPaperSource 


/***************************************************************************
*                               CPaperSize
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CPaperSize(LPPDEVICE lppd,LPSTR media_name)
*  parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE or BITMAP
*       LPSTR     media_name __
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CPaperSize(LPPDEVICE lppd,LPSTR media_name)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTPaperSize)(lppd, media_name) ;
   return(TRUE);
} // END CPaperSize


/*****************************************************************************
*                            CMSRectHack               
* FUNCTION: 
*       Generate MS Driver code to support MS-driver-specific apps.
*
* BACKGROUND:  Microsoft Win PowerPoint 2.0 and Win Word 2.0 ship with
*       an EPS import filter EPSIMP.FLT.  This filter, following the Aldus
*       graphics import filter spec, allows applications to treat EPS files
*       as Windows metafiles -- all EPS and PostScript-specific code is in
*       the filter.
*           The filter prints an EPS file by:
*        1. Sending PostScript language code to redefine operators used
*           by the Microsoft PostScript driver v. 3.3/3.4 to draw rectangles
*           and clipping rectangles.  The redefinitions keep track of whether
*           the MS operators were called, and copies their parameters.
*        2. Calling GDI to draw a rectangle at the position and size which
*           the EPS illustration is to appear.  If the illustration is to
*           be clipped, the clipping rectangle is sent via GDI.  The driver
*           generates its normal code to clip and image rectangles:
*               dx dy x y CB        % clip to a rectangle
*               dx dy x y B         % draw a rectangular path
*        3. The filter's redefinitions trap the parameters and store them
*           away.
*        4. The filter sends further PostScript language code to compute
*           the translation and scaling required to place the illustration
*           properly, and performs that.  It also performs clipping, if
*           required.
*        5. The filter then sends the PostScript language code from the 
*           EPS illustration.
*
*           The fix consists of scanning the buffers of initial Passthrough
*       calls to detect the redefinition code from step 1.  If this code
*       is detected, the driver sets a flag dfDoEmptyPath.  If the next
*       call to the driver is to Output(), with style OS_RECTANGLE, then
*       the driver generates an EmptyPath token and does not generate
*       the ClipRect, Pen, Brush, and Rectangle tokens normally associated
*       with rectangles.  The effect of the EmptyPath rectangle is to
*       generate the operators which the Microsoft Driver v. 3.3 would have
*       used to draw and clip to rectangles.
*
* PSEUDO CODE
* -----------
*       Initialise lppd->job.bfDoMSRectHack to FALSE.
*
*       In ESCPassThrough,
*           if (lpInData == "/pp_save save def....") 
*               then lppd->job.bfDoMSRectHack = TRUE.
*
*       In Output(),
*           if (lppd->job.bfDoMSRectHack && (sStyle == OS_RECTANGLE)) then
*               CMSRectHack(lppd, fClip?, lpClipRect, (LPRECT) lppt);
*               lppd->job.bfDoMSRectHack = FALSE;
*           else 
*               (do normal Output() processing)
*
*
*  prototype:
*       short FAR PASCAL CMSRectHack(LPPDEVICE lppd,BOOL fClip,
*                                    LPRECT lpRectClip,LPRECT lpRect)
*  parameters:
*       LPPDEVICE lppd -- The pdevice to send the hack to!!
*       BOOL      fClip -- TRUE if we should send lpRectClip
*       LPRECT    lpRectClip -- Coordinates to pass to 'CB operator
*       LPRECT    lpRect -- Coordinates to pass to 'B operator
*  returns:
*       short == TRUE - alls well that ends.
*
*****************************************************************************/
short FAR PASCAL CMSRectHack( 
    LPPDEVICE lppd,
    BOOL      fClip,
    LPRECT    lpRectClip,
    LPRECT    lpRect                )
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(NULL == tempptr) return(FALSE);
   (*tempptr->rTMSRectHack)( lppd, fClip, lpRectClip, lpRect ) ;
   return(TRUE) ;
} // END CMSRectHack


/***************************************************************************
*                               CGraphSave
*  function:
*       ...
*  prototype:
*       void FAR PASCAL CGraphSave(LPPDEVICE lpDevice)
*  parameters:
*       LPPDEVICE lpDevice -- pointer to PDEVICE or BITMAP
*  returns:
*       void
*                                                                           
***************************************************************************/
void FAR PASCAL CGraphSave(LPPDEVICE lpDevice)
{
   LPTFUNCTIONPTRS tempptr = (LPTFUNCTIONPTRS)lpDevice->lpTFuncPtr;
   if (tempptr)
        (*tempptr->rTClipPath)(lpDevice, CP_SAVE, 0);
} // END CGraphSave


/***************************************************************************
*                               CGraphRestore
*  function:
*       ...
*  prototype:
*       void FAR PASCAL CGraphRestore(LPPDEVICE lpDevice)
*  parameters:
*       LPPDEVICE lpDevice -- pointer to PDEVICE or BITMAP
*  returns:
*       void
*                                                                           
***************************************************************************/
void FAR PASCAL CGraphRestore(LPPDEVICE lpDevice)
{
   LPTFUNCTIONPTRS tempptr = (LPTFUNCTIONPTRS)lpDevice->lpTFuncPtr;
   if (tempptr)
        (*tempptr->rTClipPath)(lpDevice, CP_RESTORE, 0);
} // END CGraphRestore


/***************************************************************************
*                               CClip
*  function:
*       ...
*  prototype:
*       void FAR PASCAL CClip(LPPDEVICE lpDevice, WORD mode)
*  parameters:
*       LPPDEVICE lpDevice -- pointer to PDEVICE or BITMAP
*       WORD      mode --
*  returns:
*       void
*                                                                           
***************************************************************************/
void FAR PASCAL CClip(LPPDEVICE lpDevice, WORD mode)
{
   LPTFUNCTIONPTRS tempptr = (LPTFUNCTIONPTRS)lpDevice->lpTFuncPtr;
   if (tempptr)
        (*tempptr->rTClipPath)(lpDevice, CP_CLIP, mode);
} // END CClip


/***************************************************************************
*                               CEndPath
*  function:
*       ...
*  prototype:
*       void FAR PASCAL CEndPath(LPPDEVICE lpDevice, LPPATHINFO lpPathInfo, 
*                     LPDRAWMODE lpDrawMode)
*  parameters:
*       LPPDEVICE  lpDevice -- pointer to PDEVICE or BITMAP
*       LPPATHINFO lpPathInfo --
*       LPDRAWMODE lpDrawMode --
*  returns:
*       void
*                                                                           
***************************************************************************/
void FAR PASCAL CEndPath(LPPDEVICE lpDevice, LPPATHINFO lpPathInfo, LPDRAWMODE lpDrawMode)
{
   LPTFUNCTIONPTRS tempptr = (LPTFUNCTIONPTRS)lpDevice->lpTFuncPtr;
   if (tempptr)
        (*tempptr->rTEndPath)(lpDevice, lpPathInfo, lpDrawMode);
} // END CEndPath


/***************************************************************************
*                               CSaveCTM
*  function:
*       ...
*  prototype:
*       void FAR PASCAL CSaveCTM(LPPDEVICE lpDevice)
*  parameters:
*       LPPDEVICE lpDevice -- pointer to PDEVICE or BITMAP
*  returns:
*       void
*                                                                           
***************************************************************************/
void FAR PASCAL CSaveCTM(LPPDEVICE lpDevice)
{
   LPTFUNCTIONPTRS tempptr = (LPTFUNCTIONPTRS)lpDevice->lpTFuncPtr;
   if (tempptr)
        (*tempptr->rTCTMSaveRestore)(lpDevice, CTMSAVE);
} // END CSaveCTM


/***************************************************************************
*                               CRestoreCTM
*  function:
*       ...
*  prototype:
*       void FAR PASCAL CRestoreCTM(LPPDEVICE lpDevice)
*  parameters:
*       LPPDEVICE lpDevice -- pointer to PDEVICE or BITMAP
*  returns:
*       void
*                                                                           
***************************************************************************/
void FAR PASCAL CRestoreCTM(LPPDEVICE lpDevice)
{
   LPTFUNCTIONPTRS tempptr = (LPTFUNCTIONPTRS)lpDevice->lpTFuncPtr;
   if (tempptr)
       (*tempptr->rTCTMSaveRestore)(lpDevice, CTMRESTORE);
} // END CRestoreCTM


/***************************************************************************
*                               CTransformCTM
*  function:
*       ...
*  prototype:
*       void FAR PASCAL CTransformCTM(LPPDEVICE lpDevice, LPDWORD lpMatrix)
*  parameters:
*       LPPDEVICE lpDevice -- pointer to PDEVICE or BITMAP
*       LPDWORD   lpMatrix --
*  returns:
*       void
*                                                                           
***************************************************************************/
void FAR PASCAL CTransformCTM(LPPDEVICE lpDevice, LPDWORD lpMatrix)
{
   LPTFUNCTIONPTRS tempptr = (LPTFUNCTIONPTRS)lpDevice->lpTFuncPtr;
   if (tempptr)
        (*tempptr->rTCTMTransform)(lpDevice, lpMatrix);

} // END CTransformCTM


/***************************************************************************
*                               CClipBox
*  function:
*       ...
*  prototype:
*       void FAR PASCAL CClipBox(LPPDEVICE lpDevice, LPRECT lpRect)
*  parameters:
*       LPPDEVICE lpDevice -- pointer to PDEVICE or BITMAP
*       LPRECT    lpRect --
*  returns:
*       void
*                                                                           
***************************************************************************/
void FAR PASCAL CClipBox(LPPDEVICE lpDevice, LPRECT lpRect)
{
   LPTFUNCTIONPTRS tempptr = (LPTFUNCTIONPTRS)lpDevice->lpTFuncPtr;
   if (tempptr)
        (*tempptr->rTClipBox)(lpDevice, lpRect);
} // END CClipBox

/***************************************************************************
*                               CICMColor
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CICMColor(LPPDEVICE lppd, DWORD hCMTran)
*  parameters:
*       LPPDEVICE lppd  -- pointer to PDEVICE 
*       DWORD hCMTran   -- handle to Transform from DRAWMODE
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CICMColor(LPPDEVICE lppd, DWORD hCMTran)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if(tempptr) {
        (*tempptr->rTICMColor)(lppd, hCMTran);
        return(TRUE);
   }
   return(FALSE);
} // END CICMColor


#ifdef ADOBE_DRIVER

/***************************************************************************
*                               CTextRunWide
*  function:
*       ...
*  prototype:
*       short FAR PASCAL CTextRunWide(LPPDEVICE lppd, LPWORD String,int count, 
*                                 double breakExtra, double charExtra,
*                                 LPPSFONTINFO FontInfo,
*                                 LPTEXTXFORM TextXForm, LPINT lpdx);
*  parameters:
*       LPPDEVICE   lppd -- pointer to PDEVICE or BITMAP
*       LPWORD      String --
*       int         count --
*       double      breakExtra --
*       double      charExtra --
*       LPPSFONTINFO  FontInfo --
*       LPTEXTXFORM TextXForm --
*       LPINT       lpdx --
*  returns:
*       short == ...
*                                                                           
***************************************************************************/
short FAR PASCAL CTextRunWide(LPPDEVICE lppd, LPWORD String,int count,
                          double breakExtra, double charExtra,
                          LPPSFONTINFO FontInfo,LPTEXTXFORM TextXForm, LPINT lpdx)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   if (tempptr) {
       (*tempptr->rTTextRunWide)(lppd,String,count, breakExtra, charExtra,
                                 FontInfo,TextXForm, lpdx) ;
       return(TRUE);
   }
   return(FALSE);
} // END CTextRunWide

#endif // ADOBE_DRIVER
