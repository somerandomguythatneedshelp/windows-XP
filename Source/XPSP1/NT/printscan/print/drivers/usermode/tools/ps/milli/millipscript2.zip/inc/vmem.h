/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: VMEM.H                                                       */
/*                                                                           */
/* Description: This module contains ...                                     */
/*                                                                           */
/*****************************************************************************/

#ifndef VMEM_H
#define VMEM_H

// type of operation that uses VM tracking
#define VM_DOCSTART     1     // beginning of a job
#define VM_PASSTHROUGH  2     // esc pass through
#define VM_PFB_FONT     3     // download pfb font
#define VM_PFA_FONT     4     // download pfa font
#define VM_TTT42_FONT   5     // download TrueType Type 42
#define VM_TTT1_HEADER  6     // download TrueType synthetic Type 1 header
#define VM_TTT1_FONT    7     // download TrueType synthetic Type 1
#define VM_TTT3_HEADER  8     // download TrueType synthetic Type 3 header
#define VM_TTT3_FONT    9     // download TrueType synthetic Type 3
#define VM_TT_FONT      10    // download TrueType for printer with TrueImage
#ifdef ADOBE_DRIVER
#define VM_PST1_HEADER  11    // download PS Type 1 header
#define VM_PST1_FONT    12    // download PS Type 1
#define VM_CRD          13    // download PS Type 1
#endif
#define VM_TTT01_HEADER  14     // download TrueType as Type 0 /Type-1s Header
#define VM_TTT03_HEADER  15     // download TrueType as Type 0 /Type-3s Header
#define VM_TTT0CID_FONT  16     // download TrueType as Type 0 /CIDFont Font or header
#ifdef  T3OUTLINE
#define VM_TTT3OL_HEADER  17    // download TrueType as Type 3 Outline header
#define VM_TTT3OL_FONT    18    // download TrueType as Type 3 Outline
#define VM_TTT03OL_HEADER 19    // download TrueType as Type 0 /Type-3 Outline Header
#define VM_NONE           20    
#else
#define VM_NONE          17    
#endif

#define VM_GOODESTIMATE   21  /* Don't add any other estimate factors */

#define DoVMTracking(lppd)   ((lppd->doVMTracking > 0) && \
                              lppd->lpPSExtDevmode->dm2.bVM_Tracking)
#define DoVMRecovery(lppd)   (DoVMTracking(lppd) && (lppd->doVMRecovery > 0))

// Macros shared by VMRecory and TText.c
#define AppNumToName2(lpName, num) \
             wsprintf((lpName), "%2.2X", (int)(num))
#define AppNumToName3(lpName, num) \
             wsprintf((lpName), "%03.3X", (int)(num))
#define AppNumToName5(lpName, num1, num2) \
             wsprintf((lpName), "%2.2X-%2.2X", (int)(num1), (int)(num2))

VOID FAR PASCAL VMResetEstimateUsed(LPPDEVICE lppd);
VOID FAR PASCAL VMDisable(LPPDEVICE lppd);
VOID FAR PASCAL VMEnable(LPPDEVICE lppd);
VOID FAR PASCAL VMRecoverDisable(LPPDEVICE lppd);
VOID FAR PASCAL VMRecoverEnable(LPPDEVICE lppd);
BOOL FAR PASCAL VMCheck(LPPDEVICE lppd, WORD checkWhat, DWORD size);
VOID FAR PASCAL VMUsed(LPPDEVICE lppd, WORD usedWhat, DWORD size);
WORD FAR PASCAL VMRecover(LPPDEVICE lppd);
VOID FAR PASCAL VMSetupAfterRecovery(LPPDEVICE lppd, WORD recoverWhat, 
                                     WORD savelevel);

#endif // VMEM_H

