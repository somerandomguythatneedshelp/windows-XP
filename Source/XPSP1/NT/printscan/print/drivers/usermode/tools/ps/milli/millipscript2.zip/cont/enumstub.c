#include "generic.h"

#pragma code_seg(_ENUMERATORSEG)

#ifdef ENUMERATOR

void FAR PASCAL Enum_AddFonts(LPSTR lpszModelName, LPSTR lpszPort, 
                              LPFONTLIST lpFontList, 
			      WORD wNumFonts, LPBYTE lpStrHeap)
{
    /**************************************************************************
      The FontList structure is defined as:
      
      typedef struct tagFONTLIST {
        STRINGREF      fontname;
	STRINGREF      familyname;
	BOOL                    custom;        //  TRUE if custom font.
	WORD                 index;            //  Index of font in
					       // fontcache (Used as a hint for 
                                               //            fast access).
      } FONTLIST, FAR *LPFONTLIST;

      This function should traverse lpFontList, and pick up the font names as 
      follows:

      LPSTR lpszFontName = STRREF_TO_PTR(lpStrHeap, lpFontList->fontname).
      ************************************************************************/
    return;
}

void FAR PASCAL Enum_InstallPrinter(LPSTR lpszModelName, LPSTR lpszOldPort, 
                                    LPSTR lpszNewPort)
{
    /*************************************************************************
      If lpszOldPort is NULL, a new printer is being added.
      If lpszNewPort is NULL, the printer is being deleted.
      If both a re non-NULL, the printer port is being changed.
      ************************************************************************/
    return;
}

WORD FAR PASCAL Enum_EnumerateFonts(LPSTR lpszModelName, LPSTR lpszPort, 
                                    FONTSOURCE fntSrc, ENUMTYPE etype, 
                                    LPSTR lpszName, FARPROC lpCallbackProc, 
				    LP lpClientData)
{
    /*************************************************************************
      If (fntSrc == DEVICE_FONTS), enumerate fonts on all devices on 
      lpszModelName.
      If (fntSrc == HOST_FONTS), ignore lpszModelName (will be NULL), and 
      enumerate host fonts.
      If (fntSrc == ALL_FONTS), enumerate both device and host fonts.

      etype specifies which fonts to enumerate from fntSrc.
      If (etype == PS_FACE_NAME), enumerate all fonts with family name equal to 
      lpszName.
      If (etype == PS_FAMILY_NAME), ignore lpszName (will be NULL), and 
      enumerate one font per family.
      If (etype == PS_ALL), enumerate all fonts.
      *************************************************************************/
    return 0;
}

#endif
