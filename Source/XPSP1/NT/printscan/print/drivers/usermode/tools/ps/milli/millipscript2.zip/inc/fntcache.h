#ifndef _FONTCACHE_H
#define _FONTCACHE_H  1

#define BUF_SIZE           1024
#define SM_BUF              256
#define MFD_NAME_LENGTH    MAX_PATH
#define MFM_NAME_LENGTH    MAX_PATH

#define PFM_FROM_REGISTRY    0x0
#define PFM_FROM_ADFONTS_MFM 0x1
#define PFM_FROM_OEM_MFM     0x2

/* Typdefs used in fntcache.c */
typedef struct tagDATETIME {
    unsigned int date;
    unsigned int time;
} DATETIME, FAR* LPDATETIME;

typedef struct tagFONTFILE {
    char szName1[PS_FILE_PATH_LENGTH]; /* PS:Full path name, TT: PSName*/
    char szName2[PS_FILE_PATH_LENGTH]; /* PS:Full path name, TT: TTFaceName */
    BYTE lfCharSet;           //use if TT font
    int  lfWeight;            //use if TT font
    BYTE lfItalic;           //use if TT font
    WORD wType;   /* 0 =PFM/PFB, 1 = SFNT, 2 = TT Font */
} FONTFILE, FAR* LPFONTFILE, _huge* HPFONTFILE;

typedef struct tagTTENUMSTRUCT {
   HDC  hDC;
   WORD nTTFonts;
   WORD nTTFontsCounter;
   HPFONTFILE hpTTFonts;
   ATOM FAR *lpATOM;
   WORD lpATOMSize;
} TTENUMSTRUCT, FAR * LPTTENUMSTRUCT;



/* Data in segment DGROUP */
extern CACHEHDR chFonts;
extern DATETIME DateTime;
extern WORD _far crc_16_tab[];              /* far to fix C4746 warning     */
extern BOOL bInitFontCache;


/* NEAR functions - segment "_UTILS" */
WORD NEAR ENUMSEG PASCAL GetNumASCIIZStrings(LPSTR);
BOOL NEAR ENUMSEG PASCAL CheckFontCRC(LPFILEHDR, LPCRCINFO, BOOL);

LPFONTCACHE NEAR ENUMSEG PASCAL GetListOfFontFrCache(LPSTR lpszFriendlyName, CACHEHDR ch, LPSERIALNUMS lpPIData);
LPFONTCACHE NEAR ENUMSEG PASCAL GetListOfFonts(LPSTR lpszFriendlyName, CACHEHDR ch, LPSERIALNUMS lpPIData);
DWORD NEAR ENUMSEG PASCAL CreateListOfFonts(LPSTR lpszFriendlyName, CACHEHDR ch, LPSTR lpszLOFName, LPSERIALNUMS lpPIData);
LPFONTCACHE NEAR ENUMSEG PASCAL LoadListOfFonts(LPSTR lpszIndexTbl, 
                                       CACHEHDR ch,
                                       LPSERIALNUMS lpPIData);
VOID NEAR ENUMSEG PASCAL AddListOfFontCache(LPFONTCACHE lpCache);
void NEAR ENUMSEG PASCAL GetListOfFontsFileName(LPSTR lpszFriendlyName, LPSTR lpszLOFFile, DWORD cbSize);
void NEAR ENUMSEG PASCAL SetListOfFontsFileName(LPSTR lpszFriendlyName, LPSTR lpszLOFFile);
VOID NEAR ENUMSEG PASCAL SetFontVisibility(HKEY hKeyHPFR, HKEY hKeyTTFR, 
      HPFONTDIRECTORY hpFontDirList, HPFONTDIRECTORY hpCurFont, 
      WORD nFontsInDirList, BYTE *statusFlag);

WORD NEAR ENUMSEG PASCAL GetFontsMFDFrReg(LPSTR lpszKey, LPSTR lpszMFDFileName, DWORD cbSize);
VOID NEAR ENUMSEG PASCAL SetFontsMFDToReg(LPSTR lpszKey, LPSTR lpszMFDFileName);
VOID NEAR ENUMSEG PASCAL CreateFontsName(LPSTR lpszName, WORD cbSize);
WORD NEAR ENUMSEG PASCAL CreateFontsMFD(LPSTR lpszMFDPath, LPDWORD dwPSFRSerialNo, LPDWORD dwTTFRSerialNo, DWORD dwMFMTimeStamp,
                                        LPSTR lpszFriendlyName);
WORD NEAR ENUMSEG PASCAL GetFontsMFD(LPCACHEHDR lpCH, LPSTR lpszMFDPath, DWORD dwPSFRSerialNo, DWORD dwTTFRSerialNo);
LPSTR NEAR ENUMSEG PASCAL MakePFMPFBSFNT(LPSTR lpValue, HPFONTFILE hpFontPtr, WORD wType);
int NEAR ENUMSEG PASCAL FindStringPos(LPSTR lpValue, LPSTR lpString);
LPSTR NEAR ENUMSEG PASCAL FindString(LPSTR lpValue, LPSTR lpString, LPWORD lpwLength);
BOOL NEAR ENUMSEG PASCAL ExpandPSFontsPath(LPSTR lpszPtr, LPSTR lpszExpandedName);
WORD NEAR ENUMSEG PASCAL LoadMFDData(LPSTR, LPFONTDIRCACHE,
                                       DWORD , DWORD, WORD);
DWORD FAR PASCAL ReadMetricFile(LPSTR, HPVOID FAR*);
WORD NEAR PASCAL MergeTTFontsFromReg(HPFONTFILE *phpPFMFile, LPWORD lpwNumFonts);
WORD NEAR PASCAL MergePSFontsFromReg(HPFONTFILE *phpPFMFile, LPWORD lpwNumFonts);
WORD NEAR PASCAL FillIndexTable(HPDIRINDEX, WORD,
                                 HPFONTDIRECTORY [], WORD,
                                 WORD, WORD,
                                 LPRESIDENTFONT);

WORD NEAR PASCAL DeleteFontCache(LPCSTR lpszPrinter);
void NEAR PASCAL InitNewFontDirCache();
void NEAR PASCAL ResetPortCheckSum(LPSTR szPort);



/* FAR functions */
void FAR PASCAL InitFontCache(void);
WORD FAR PASCAL CalcCRC(LPBYTE, WORD, WORD, LPWORD);
void FAR PASCAL CreateMFDFileName(LPSTR);
void FAR PASCAL FreeCache(LPFONTCACHE);
void FAR PASCAL FreeFontCacheMemory(void);
DWORD FAR PASCAL ReadPFMData(HFILE, LPVOID FAR*);
DWORD FAR PASCAL ReadPFMFile(LPSTR, LPVOID FAR*);
DWORD FAR PASCAL ReadPFMFromMFM(LPSTR, LPVOID FAR*, DWORD);
void FAR PASCAL MakeTextMetric(LPPFMHEADER, LPTEXTMETRIC, WORD, WORD);
// functions added to support ATM.INI:
int FAR PASCAL MergeOtherSoftFonts(HPPFMFILE *phpPFMFile, LPWORD lpwNumFonts, LPSTR lpszIniFile, LPSTR lpszSection);

WORD FAR PASCAL ConvertMFMToPFMs(LPSTR lpszMFMFile);
BOOL FAR PASCAL MakeFontKeyVal(LPSTR, LPSTR, LPSTR, LPSTR, WORD, WORD);
WORD FAR PASCAL CreateLOFMFDFile(HFILE hfile, LPDIRINDEXHDR lpIndexHdr, 
                                 HPDIRINDEX hpDirIndex, LPSTR lpszFriendlyName);
VOID FAR PASCAL SyncTrueTypeFontReg();
DWORD FAR PASCAL SetRegDWord(LPSTR lpszPath, LPSTR lpszKey, DWORD dwNewSerial);
DWORD FAR PASCAL GetRegDWord(LPSTR lpszPath, LPSTR lpszKey);
DWORD FAR PASCAL GetSerialNo(LPSTR);
DWORD FAR PASCAL SetSerialNo(LPSTR, DWORD);
DWORD FAR PASCAL GetSecondSerialNo(LPSTR);
DWORD FAR PASCAL SetSecondSerialNo(LPSTR, DWORD);
HPFONTDIRECTORY FAR PASCAL GetHostFontCache(LPWORD);
WORD FAR PASCAL GetMFDsCached(BOOL, LPSTR);
LPFONTCACHE FAR PASCAL GetFontCache(LPSTR);
LPSTR FAR PASCAL SkipToNext(LPSTR);
HPPFMHEADER FAR PASCAL GetMetricCache(HPFONTDIRECTORY, BYTE, HPPFMPROLOG);
DWORD FAR PASCAL ReadPFMFromMFD(LPSTR, LPVOID FAR* , DWORD);
DWORD FAR PASCAL ReadPFMData(HFILE, LPVOID FAR*);
WORD FAR PASCAL GetPFB(LPSTR lpPSFontName, LPSTR lpValue);
WORD FAR PASCAL GetResidentFontsList(LPSTR, LPRESIDENTFONT FAR *,
                                 DWORD FAR *);
VOID FAR PASCAL FreeResidentFontsList(LPRESIDENTFONT, WORD);
DWORD FAR PASCAL ReadPFMWithProlog(HFILE, HPVOID FAR *);
int FAR PASCAL ResidentFontCompare(LPVOID, LPVOID);
BOOL NEAR PASCAL MatchVersion(LPRESIDENTFONT, DWORD);
BOOL NEAR PASCAL UseThisMetricFile(LPFONTDIRECTORY, WORD, LPRESIDENTFONT, DWORD);
int FAR PASCAL EnumFontsCompare(LPVOID, LPVOID);


/* functions to Update the Resident font registry*/
VOID FAR PASCAL UpdateResidentFonts(LPSTR, DWORD);
WORD NEAR PASCAL UpdatePrnInstResidentFonts(LPSTR);
WORD FAR PASCAL GetRomFonts(LPRESIDENTFONT FAR *, LPSTR);
WORD FAR PASCAL GetRegResFonts(LPRESIDENTFONT FAR *, LPSTR);
WORD NEAR PASCAL RmObsRomFontsFrReg(LPRESIDENTFONT, LPRESIDENTFONT, WORD, WORD, LPSTR);
WORD NEAR PASCAL RemoveRomEntry(HKEY, LPRESIDENTFONT);
WORD NEAR PASCAL AddResFontToReg(LPRESIDENTFONT, LPRESIDENTFONT, WORD, WORD, LPSTR);
WORD NEAR PASCAL AddRomEntry(HKEY, LPRESIDENTFONT, LPRESIDENTFONT);
DWORD NEAR PASCAL GetTimeStampID (LPSTR szPath);
void NEAR PASCAL MakeResFontValue(LPSTR, LPSTR);
void NEAR PASCAL RemoveValue(LPSTR, LPSTR, char);
LPRESIDENTFONT FAR PASCAL InResidentFontList(LPSTR, WORD, LPRESIDENTFONT);
LPSTR NEAR PASCAL FindStringGen(LPSTR, LPSTR, char, LPWORD);
DWORD FAR PASCAL GetMFMTimeStampID();
BOOL FAR PASCAL NeedToUpdateResRegistry(LPSTR, LPDWORD, DWORD);
BOOL FAR PASCAL NeedToMergeIniFiles(LPSTR);
VOID FAR PASCAL UpdateMFMToPFM();
BOOL NEAR PASCAL GetPortFromFriendlyName(LPSTR, LPSTR, DWORD);




// Function Exported to support third parties to update SoftFont Cache
void __loadds FAR PASCAL UpdateSoftFonts(LPSTR);
BOOL __loadds FAR PASCAL UpdateSoftFontInfo();
VOID FAR PASCAL SynIniFilesToRegistry(LPSTR, BOOL);
WORD NEAR PASCAL MergeIniResFonts(LPSTR, LPSTR);
VOID FAR PASCAL ResetResidentFontRegistry(LPSTR);
VOID FAR PASCAL ResetFontCache();

#endif /* _FONTCACHE_H */
