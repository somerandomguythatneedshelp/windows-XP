/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PROPSH.C                                                     */
/*                                                                           */
/* Description: This module contains the functions for the simulated         */
/*              property sheet shell                                         */
/*                                                                           */
/*****************************************************************************/

#pragma code_seg("_PROPSH")
#include "ps.h"         // Also includes PRINT.H, WINDOWS.H, GDIDEFS.INC etc..

#include "string.h"
#include "ctype.h"
#include "stdlib.h"
#include "glstatic.h"
#include "memory.h"
#include "drvrmem.h"
#include "errors.h"
#include "resrcid.h"
#include "dlgid.h"
#include "drvfuncs.h"
#include "dlgsfunc.h"
#include "resource.h"
#include "OEM.h"
#include "spin.h"

#define ALLOCATE
#include "dmg.h"
#include "dlgsutil.h"
#include "paper.h"
#include "fonts.h"
#include "device.h"
#include "graphics.h"
#include "psdlg.h"
#include "keywfunc.h"

/*****************************************************************************/
/*                 CHPropertySheetDlg                                        */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the simulated property sheet parent dialog box.   */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned msg -- Message                                                 */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHPropertySheetDlg(HWND hDlg, unsigned msg,
                                           WORD wParam, LONG lParam)
{
   BOOL result = TRUE ;
   LPPDEVICE lppd = NULL;
/*   LPDRVSTATE lpArgDrvState = NULL;
   LPDRVSTATE lpDrvState = NULL; */
   int status = RC_ok ;
  LPDRIVERINFO lpDrvInfo;
  LPPSEXTDEVMODE lpPSExtDevmode = NULL;
  LPPSEXTDEVMODE lpSavPSExtDevmode = NULL;

  /* Process hook function stuff */
  if (msg == WM_INITDIALOG)
    {
    lpDrvInfo = (LPDRIVERINFO)lParam;
    SetWindowLong(hDlg, DWL_USER, lParam);
    }
  else
    {
    lpDrvInfo = (LPDRIVERINFO)GetWindowLong(hDlg, DWL_USER);
    }

  if (lpDrvInfo != NULL)
    {
    lppd = &lpDrvInfo->pDev;
    lpPSExtDevmode = lpDrvInfo->lpDM;
    }

  if (DrvProcessHookProc(lppd, hDlg, msg, wParam, lParam, "HookSetup") !=
      FALSE)
    return (TRUE);

  switch (msg)
    {
    case WM_ACTIVATE:
      if (wParam != WA_INACTIVE)
        { /* Being activated */
        /* Set the help topic */
        lppd->iHelpContext = IDM_HELP_PROPERTY_SHELL;
        }
      else
        { /* Being deactivated */
        /* Reset the help topic */
        lppd->iHelpContext = IDM_HELP_NO_TOPIC;
        }
      break;

    case WM_INITDIALOG:
      lpDrvInfo->fHelp = FALSE;

      /* Set the initial help topic */
      lppd->iHelpContext = IDM_HELP_PROPERTY_SHELL;

      /* Set up the keyboard hook */
      if (IsWin31())
        hSystemHook = (HHOOK)SetWindowsHook(WH_KEYBOARD, (HOOKPROC)KeyboardHookProc);
      else
        hSystemHook = (HHOOK)SetWindowsHook(WH_KEYBOARD, (HOOKPROC)Keyboard30HookProc);

      /* Set up the SPINCTRL */
      RegisterControlClass(ghDriverMod);

      /* Set up property categories */
      SendDlgItemMessage(hDlg, 100, LB_ADDSTRING, 0, (LPARAM)(LPSTR)"Device Options");
      SendDlgItemMessage(hDlg, 100, LB_ADDSTRING, 0, (LPARAM)(LPSTR)"Fonts");
      SendDlgItemMessage(hDlg, 100, LB_ADDSTRING, 0, (LPARAM)(LPSTR)"Graphics");
      SendDlgItemMessage(hDlg, 100, LB_ADDSTRING, 0, (LPARAM)(LPSTR)"Paper");
      SendDlgItemMessage(hDlg, 100, LB_ADDSTRING, 0, (LPARAM)(LPSTR)"PostScript");

      /* Initialize stuff so that other dialogs can use it */
      /* Copy the DRVSTATE structure passed in into a 'work' copy. */
/*      lpArgDrvState = (LPDRVSTATE)&(lppd->drvState);
      lpDrvState = (LPDRVSTATE) MGAllocLock(lppd, &lpDrvInfo->DrvStateh,
                                            dsizeof(DRVSTATE), GHND, FALSE) ; */
      /* Use different logic here. We now send the real thing in instead
         of the created copy to be consistant with other dialogs. The saved
         copy now is kept untouched unless there's a cancel. */
      lpSavPSExtDevmode = PsExtDevmodeCreateCopy(lpPSExtDevmode);
//      lpDrvInfo->lpSavPSExtDevmode = lpSavPSExtDevmode;

/*      if (!lpDrvState)
        status = RC_fail ; */

      /* No code needed here since done above when created we also copied */
#if 0
      /* Populate created DrvState */
      if (lstrcmpi((*lpArgDrvState).zNickName, szDefaultPrinter))
        { /* Copy Arg to normal, total, isn't default printer */
        DrvStateCopy(lppd, lpArgDrvState, lpDrvState) ;
        KeywordListLock(lppd,&(*lpDrvState).PPDList, FALSE) ;
        lppd->lpOEMDrvState = lpDrvState;
        }
      else
        { /* Copy Arg to normal, strings only, is default printer */
        lstrcpy((*lpDrvState).zNickName, (*lpArgDrvState).zNickName) ;
        lstrcpy((*lpDrvState).zDevType, (*lpArgDrvState).zDevType) ;
        lstrcpy((*lpDrvState).port.zName, (*lpArgDrvState).port.zName) ;
        }
#endif
      break ;

    case WM_ADOBE_HELP:
      if (lppd->iHelpContext != IDM_HELP_NO_TOPIC && CheckHelpFile(hDlg) == TRUE)
        WinHelp(hDlg, szHelpFile, HELP_CONTEXT, (DWORD)lppd->iHelpContext);
      break;

    case WM_COMMAND:
      switch (wParam)
        {
        case 100:
          if (HIWORD(lParam) == LBN_SELCHANGE)
            {
            int iSheetItem;

            iSheetItem = (int)SendDlgItemMessage(hDlg, 100, LB_GETCURSEL, 0, 0L);
            if (iSheetItem != LB_ERR)
              {
              switch (iSheetItem)
                {
                case 0:
                  DrvModalDialogBox(lppd, lpPSExtDevmode, ghDriverMod, hDlg, CHDeviceDlg, "CH_Device", "OEM_ABOUT",
                                    "OEMAbout");
                  break;
                case 1:
                  DrvModalDialogBox(lppd, lpPSExtDevmode, ghDriverMod, hDlg, CHFontsDlg, "CH_Fonts", "OEM_ABOUT",
                                    "OEMAbout");
                  break;
                case 2:
                  DrvModalDialogBox(lppd, lpPSExtDevmode, ghDriverMod, hDlg, CHGraphicsDlg, "CH_Graphics", "OEM_ABOUT",
                                    "OEMAbout");
                  break;
                case 3:
                  DrvModalDialogBox(lppd, lpPSExtDevmode, ghDriverMod, hDlg, CHPaperDlg, "CH_Paper", "OEM_ABOUT",
                                    "OEMAbout");
                  break;
                case 4:
                  DrvModalDialogBox(lppd, lpPSExtDevmode, ghDriverMod, hDlg, CHPostScriptDlg, "CH_PostScript", "OEM_ABOUT",
                                    "OEMAbout");
                  break;
                }
              }
            else
              MessageBeep(0);
            }
          break;
        case IDOK:
          /* Unhook our hook */
          if (IsWin31())
            UnhookWindowsHook(WH_KEYBOARD, (HOOKPROC)KeyboardHookProc);
          else
            UnhookWindowsHook(WH_KEYBOARD, (HOOKPROC)Keyboard30HookProc);

          /* Remove SPINCTRL */
          UnRegisterControlClass(ghDriverMod);

          /* Reset the help topic */
          lppd->iHelpContext = IDM_HELP_NO_TOPIC;

#if 0
          lpArgDrvState = (LPDRVSTATE)&(lppd->drvState);
          /* Populate real DrvState from created one */
          status = DrvStateCopy(lppd, lpDrvState, lpArgDrvState) ;
          if (status != RC_ok)
            AbortDevmodeDlg(lppd, lpDrvState, lpArgDrvState, hDlg, IDABORT) ; //oops.
          else  //Clean up.
            {
            DrvStateDestroy(lppd, lpDrvState) ;
            lpDrvState = NULL ;
            EndDialog(hDlg, IDOK) ;
            }

          /* Unconditional clean up stuff */
          MGUnlockFree(lppd, lpDrvInfo->DrvStateh, FALSE) ;
          lpDrvInfo->DrvStateh = NULL ;
#endif
//          lpSavPSExtDevmode = lpDrvInfo->lpSavPSExtDevmode;
          PsExtDevmodeDestroy(lpSavPSExtDevmode);
//          lpDrvInfo->lpSavPSExtDevmode = NULL;
          EndDialog(hDlg, IDOK) ;

          if (lpDrvInfo->fHelp)
            {
            if (CheckHelpFile(hDlg) == TRUE)
            WinHelp(hDlg, szHelpFile, HELP_QUIT, 0L);
            }

          /* Reset lppd */
          lppd = NULL;
          break ;

        case IDCANCEL:
          /* Unhook our hook */
          if (IsWin31())
            UnhookWindowsHook(WH_KEYBOARD, (HOOKPROC)KeyboardHookProc);
          else
            UnhookWindowsHook(WH_KEYBOARD, (HOOKPROC)Keyboard30HookProc);

          /* Remove SPINCTRL */
          UnRegisterControlClass(ghDriverMod);

          /* Reset the help topic */
          lppd->iHelpContext = IDM_HELP_NO_TOPIC;

          /* Restore the old values */
//          lpSavPSExtDevmode = lpDrvInfo->lpSavPSExtDevmode;
          PsExtDevmodeCopy(lpPSExtDevmode, lpSavPSExtDevmode);
          PsExtDevmodeDestroy(lpSavPSExtDevmode);
//          lpDrvInfo->lpSavPSExtDevmode = NULL;
          EndDialog(hDlg, IDCANCEL) ;

          if (lpDrvInfo->fHelp)
            {
            if (CheckHelpFile(hDlg) == TRUE)
            WinHelp(hDlg, szHelpFile, HELP_QUIT, 0L);
            }

          /* Reset lppd */
          lppd = NULL;
          break ;

        case ID_HELP:
          PostMessage(GetActiveWindow(), WM_ADOBE_HELP, 0, 0L);
          break;

        case ID_ABOUT:
          {
          char strBuff[16];

          lstrcpy(strBuff, LOAD_STRING(ID_STR_AB));
          DrvModalDialogBox(lppd, lpPSExtDevmode, ghDriverMod, hDlg, fnAboutDlg, strBuff, "OEM_ABOUT",
                            "OEMAbout");
          }
          break ;

        default:
          result = FALSE ;
          break ;

        } //switch(wParam)
      break ;

    default:
      result = FALSE ;
      break ;
    } //switch(msg)

  return result ;
}
