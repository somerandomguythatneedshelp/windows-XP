/*
  pslib.h

Copyright (c) 1991-1992 Adobe Systems Incorporated.
All rights reserved.

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript is a registered trademark of Adobe Systems Incorporated.
Display PostScript is a trademark of Adobe Systems Incorporated.

Original version: John Nogrady
Edit History:
John Nogrady: Wed Jan 22 18:08:44 1992
End Edit History.
Revision History
  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/PSLIB.H_V  $
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:07:28   unknown
 *- |Initial revision.
End Revision History.
*/

#ifndef	PSLIB_H
#define	PSLIB_H

/* This file is necessary to support the building of the
** ps_model of the type 1 chip code as well as to keep
** ps_manager happy.   PSsupp_h.h, used when T1MODEL=ps_model,
** includes PSLIB.
**
** In postscript, os_malloc contains a second argument
** MEMDEFAILT(arg).  This macro must be defined here
** to compile type 1 chip code when T1MODEL==ps_model
** In the postscript world, the MEMDETAILARG definition is
** in the instrumentation.h file in the pslib package.
*/

#define MEMDETAILARG(arg)

#endif	/* PSLIB_H */
