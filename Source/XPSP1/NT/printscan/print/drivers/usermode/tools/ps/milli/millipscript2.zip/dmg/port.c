/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PORT.C                                                       */
/*                                                                           */
/* Description: This module contains the function ...                        */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_PORTSEG)


#if 0
extern short FAR PASCAL CDocumentAbort(LPPDEVICE lppd);

VOID NEAR PASCAL HandlePortError(LPPDEVICE lppd, short sError);
int FlushToSpool( LPPDEVICE lppd );
int WriteToSpool( LPPDEVICE lppd, LPSTR lpData, WORD count );
#endif

// defined in PSDATA.C.
LPSPCLPSDATA FAR PASCAL CreateNewSpclPSData(LPPDEVICE lppd);
int FAR PASCAL CopySpecialPSData(LPPDEVICE lppd, LPSPCLPSDATA lpSpecialPSData, LPBYTE lpPSData, DWORD dwLen);

LPPSINJECTDATA FAR PASCAL CreateNewPSInjectionRecord(LPPDEVICE lppd);
void FAR PASCAL SetupPSInjectionRecord(LPPDEVICE lppd, LPBYTE lpPSData);
int FAR PASCAL CopyPSInjectionData(LPPDEVICE lppd, LPPSINJECTDATA lpPSInjectData, LPBYTE lpPSData, DWORD dwLen);


//WriteSpool() can't send > 32k at once; using 30000 to avoid boundary case.
#define WRITE_SPOOL_MAX 30000

/***********************************************************************
*                       PortOpen
*  Purpose:
*       This function performs the necessary calls to establish
*       commumnication with the MicroSoft Spooler. The first call
*       ( to OpenJob() ) get a handle to the print job. All future
*       references to this job are through the job handle.
*       The second call instructs the Spooler to start a logical
*       page.
*
*  Parameters:
*       LPPDEVICE lppd     -- pdevice ptr
*       LPSTR     lpzTitle -- Job title
*       HDC       hdc      -- Handle to the device context
* 
*  Returns: BOOL
*
*************************************************************************/
BOOL FAR PASCAL PortOpen(LPPDEVICE lppd,LPSTR lpzTitle,HDC hdc,LPDOCINFO lpDocInfo)
{
   LPSTR  lpzPort;
   short  sError;
   HANDLE hJob;
   BOOL   retVal = FALSE;  // Until proven otherwise

//    STOP_PROFILE(DOCPRINT);
   
   /* We now allow DocInfo to superceed if it exists */
   if (lpDocInfo && lpDocInfo->lpszOutput)
   {
      lpzPort = lpDocInfo->lpszOutput;
   }
   else
   {
      lpzPort=(LPSTR)lppd->szPortName;
   }
   
   lppd->hPortHandle = 0 ;
   
   hJob   = AdobeOEMOpenJobStub(lppd,lpzPort,lpzTitle,hdc) ;  //Open the print job.
   
   sError = hJob ; //We need to convert to signed to check for errors.
   
   if (sError <= 0)
   {
      if (sError == SP_USERABORT)
      {
         /* Must save user abort in file handle in cases where the user
         really hit abort. Comes from Publishers Paintbrush
         getting stuck on NextBand -jmk */
         lppd->hPortHandle = (HANDLE)SP_USERABORT;
         
         ESCEndDoc(lppd, NULL, NULL);
      }
      else
      {
         HandlePortError(lppd, sError) ;
      }
   }
   else
   {
      //Store the handle to the Job.
      lppd->hPortHandle = hJob ;

         retVal = TRUE ;
   }

//   START_PROFILE("Doc Profile", DOCPRINT);
   return (retVal);

} // END PortOpen 


/***********************************************************************
*                       PortFirstStartSpoolPage
*  Purpose:
*
*  Parameters:
*       LPPDEVICE lppd     -- pdevice ptr
* 
*  Returns: BOOL
*
*************************************************************************/
BOOL FAR PASCAL PortFirstStartSpoolPage(LPPDEVICE lppd)
{
   short  sError;
   BOOL   retVal = FALSE;  // Until proven otherwise

   if (lppd->hPortHandle > 0)
   {
      sError = AdobeOEMStartSpoolPageStub(lppd) ;       // Begin a logical page 
      lppd->iSpoolBufferCount = 0;          // No bytes have been written yet.
      
      if (sError < 0)
         HandlePortError(lppd, sError);
      else
         retVal = TRUE ;
   }
   return (retVal);

} // END PortFirstStartSpoolPage


/***********************************************************************
*                       PortPage
*  Purpose:
*       This function instructs the spooler to end the previous page
*       and start a new page.
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice ptr
*
*  Returns: None
*
*************************************************************************/
VOID FAR PASCAL PortPage(LPPDEVICE lppd)
{
   short sError;
   
   if (lppd->hPortHandle > 0)
   {
      sError = FlushToSpool( lppd );
      
      /* 
       * For the first page, do not end and restart spooler page. This 
       * makes the printer manager report an extra page.
       */
      if (lppd->lpProcsetstuff->currpagenumber > 1)
      {
          if( sError >= 0 )
          {   // End the spooler page
              sError=AdobeOEMEndSpoolPageStub(lppd) ;
          }
      
          if (sError >= 0)
          {   // Start spooler page
              sError= AdobeOEMStartSpoolPageStub(lppd) ;
          }
      }
      
      if (sError < 0)
      {
         HandlePortError(lppd, sError);
      }
   }
} // END PortPage


/***********************************************************************
*                       PortWrite
*  Purpose:
*       This function accepts a pointer to a buffer and the length
*       of the buffer and sends the data to the spooler.
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice ptr
*       LP        lpData -- A buffer containing the data to send to the spooler
*       WORD      NumBytes -- The number of bytes to write to the spooler
*
*  Returns: None
*
*************************************************************************/
VOID FAR PASCAL PortWrite(LPPDEVICE lppd,LP lpData,WORD NumBytes)
{
   short sError = 1 ;
   
   if (lppd->hPortHandle > 0 || lppd->bCopyToSpecial
									  || lppd->bCopyToInjectBuff )  // have a handle or just copy to a internal buffer
   {
//      lppd->drvState.port.PortDirtyFlag = TRUE ;//Indicate that something has been written.

      sError = WriteToSpool( lppd, (LPSTR)lpData, NumBytes);
      
      if (sError <= 0)
      {
         HandlePortError(lppd, sError) ;
      }
   }
} // END PortWrite 


/***********************************************************************
*                       PortWriteString
*
*  Purpose:
*       This function accepts a pointer to a buffer and computes the
*       length of the buffer and sends the data to the spooler.
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice ptr
*       LP        lpData -- A buffer containing the data to send to the spooler
*
*  Returns: None
*
*************************************************************************/
VOID FAR PASCAL PortWriteString(LPPDEVICE lppd,LP lpData)
{
   short sError = 1;
   WORD  NumBytes;
   
   if(lppd->hPortHandle > 0)
   {
//      lppd->drvState.port.PortDirtyFlag = TRUE;  // Indicate that something
                                                 // has been written.
      
      NumBytes = (WORD)lstrlen((LPSTR)lpData);   // NumBytes <= 0xFFFF
      
      sError=WriteToSpool( lppd,(LPSTR)lpData,NumBytes);
      
      if (sError <= 0)
      {
         HandlePortError(lppd, sError);
      }
   }
} // END PortWriteString 


/***********************************************************************
*                       PortLastEndSpoolPage
*  Purpose:
*       This function closes the job. An EndSpoolPage() is issued followed
*       by a CloseJob().
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice ptr
*
*  Returns: None
*
*************************************************************************/
VOID FAR PASCAL PortLastEndSpoolPage(LPPDEVICE lppd)
{
   short sError;
   
   if(lppd->hPortHandle > 0)
   {
      sError = FlushToSpool( lppd );
      
      if (sError >= 0)
      {
         sError = AdobeOEMEndSpoolPageStub(lppd) ; // End the logical page
      }
      
      if (sError < 0)
      {
         HandlePortError(lppd, sError);
      }
   }
} // END PortLastEndSpoolPage


/***********************************************************************
*                       PortClose
*  Purpose:
*       This function closes the job. An EndSpoolPage() is issued followed
*       by a CloseJob().
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice ptr
*
*  Returns: None
*
*************************************************************************/
VOID FAR PASCAL PortClose(LPPDEVICE lppd)
{
   short sError;
   
   if(lppd->hPortHandle > 0)
   {
      sError = FlushToSpool( lppd );
      
      if (sError >= 0)
      {
         sError = AdobeOEMCloseJobStub(lppd); // Close the job
      }
      
      if (sError >= 0)
      {
         // Record the job as closed.
         lppd->hPortHandle = 0 ;
      }
      else
      {
         HandlePortError(lppd, sError);
      }
   }
} // END PortClose


/***********************************************************************
*                           PortClean
*  Purpose:
*       This function clears the port dirty flag. The Driver can call
*       PortDirtyQuery() to see if anything has been written to the port
*       since this call.
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice ptr
*
*  Returns: None
*
*************************************************************************/
VOID FAR PASCAL PortClean(LPPDEVICE lppd)
{
//   lppd->drvState.port.PortDirtyFlag = FALSE ;

}  // END PortClean

/***********************************************************************
*                         PortDirtyQuery
*  Purpose:
*       This function returns the port dirty flag. This flag is TRUE if
*       PortWrite() has been invoked since the last invocation of PortClean().
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice pointer
*
*  Returns: PortDirtyFlag
*
*************************************************************************/
BOOL FAR PASCAL PortDirtyQuery(LPPDEVICE lppd)
{
//   return(lppd->drvState.port.PortDirtyFlag) ;
     return TRUE;

} // END PortDirtyQuery


/***********************************************************************
*                           HandlePortError
*  Purpose:
*       This function is called when a spooler error is detected. If
*       a user abort or application abort has occurred, the current job
*       is deleted and subsequent PortWrite's for the current job are
*       simply ignored. Note that this is not considered a fatal error.
*       All other errors are regarded as fatal - we longjmp() back after
*       recording them.
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice ptr
*       short     sError - error code
*
*  Returns: None
*
*************************************************************************/
VOID NEAR PASCAL HandlePortError(LPPDEVICE lppd, short sError)
{
   switch( sError )
   {
      case SP_APPABORT    : 
          lppd->wSpoolError = 0;
          /* NOTE NO BREAK */
      case SP_USERABORT   : 
      case SP_OUTOFDISK   : 
      case SP_OUTOFMEMORY : 
      {
//         CDocumentAbort( lppd ); Do not call during port error, as it calls 
//         SendEndProtocol() which in turn cals WritePort, and we get here again
//         into an infinite loop and cause a stack overflow. This function 
//         anyway doesn't do anything except send end protocol - #21696 - Srini
      }    /* NOTE NO BREAK */
      default :                 /* includes "case SP_ERROR" */
      {
         AdobeOEMDeleteJobStub( lppd, 0 );
         lppd->hPortHandle = 0;
#if 0
         EJmpOut(lppd, TRUE);        // Clean up Driver and longjmp() back.
#endif
         break;
      }
   } /* switch */
   
   return;

} // END HandlePortError 


/*****************************************************************************
*                           WriteToSpool
*  Purpose: 
*       Write the data to a buffer or the spooler.
*
*  Pseudo Code:
*       IF( new data + old data > INTERNAL_SPOOLER_MAX ) CHECKING for OVERFLOW
*       BEGIN
*          FlushToSpool.
*       END
*       
*       IF( new data < INTERNAL_SPOOLER_MAX )     ONLY NEW DATA CAN OVERFLOW
*       BEGIN
*         copy new data to internal spooler.
*       END
*       ELSE
*       BEGIN
*         WHILE( new data > MS_SPOOL_MAX )         NEW DATA OVERFLOWS repeatedly
*         BEGIN
*           Write MS_SPOOL_MAX data to MS-spool.
*           Subtract new data. move new data pointer.
*         END
*         Write out remaining new data.
*       END
*  
*  Parameters:
*       LPPDEVICE lppd   -- The context to write the data to.
*       LPSTR     lpData -- The bytes to write to the spooler
*       WORD      count  -- Number to bytes to write to spooler.
*  
*  Returns: int
*       See DDK on spooler return functions.
*  
*****************************************************************************/
int WriteToSpool( LPPDEVICE lppd, LPSTR lpData, WORD count )
{
   static  WORD  spoolsize = 0;
	LPBYTE lpTmp;

   // special case to save the APP injection request into the
   // link list structure.
   if(!spoolsize)
   {
      spoolsize = GetProfileInt("stress", "spoolsize", INTERNAL_SPOOL_MAX);
      if(spoolsize < 100)
         spoolsize = 100 ;
   }

   if( spoolsize - lppd->iSpoolBufferCount <= count )   // Fix bug 120981. jjia. 11/6/95
   {
      lppd->wSpoolError = FlushToSpool( lppd );
   }


   if(lppd->wSpoolError  > 0 )
   {
      if( count < spoolsize )
      {
         // special case to save the APP injection request into the
         // link list structure.
			if( lppd->bCopyToInjectBuff )   //save it in the buffer
         {
    	     if (lppd->lpPSInjectData==NULL){  // only for the first time
            // Allocate new buffer:
                lppd->lpPSInjectRoot = lppd->lpPSInjectData = CreateNewPSInjectionRecord(lppd);
            }
            else 
        	       lppd->lpPSInjectData = CreateNewPSInjectionRecord(lppd);
            SetupPSInjectionRecord(lppd, (LPBYTE)lpData);
            lpTmp = (LPBYTE)lpData + sizeof(PSINJECTBYTE);
            lppd->wSpoolError=
                CopyPSInjectionData(lppd, lppd->lpPSInjectData, (LPBYTE)lpTmp, count);
            return (1);
			}

         MemCopy( &(lppd->SpoolBuffer[ lppd->iSpoolBufferCount ]), 
                 lpData, (DWORD) count );
         lppd->iSpoolBufferCount = lppd->iSpoolBufferCount + count;
         if( lppd->bCopyToSpecial )   // flush the stuff to lpSpclPSData right now:
            {
              lppd->wSpoolError = FlushToSpool( lppd );
            }
      }
      else
      {
         /* Just write to the psinject record. */
         // do it once here instead of 30k each
          if ( lppd->bCopyToInjectBuff )   //save it in the buffer
          { 
      	    if (lppd->lpPSInjectData==NULL){  // only for the first time
               // Allocate new buffer:
                 lppd->lpPSInjectRoot = lppd->lpPSInjectData = CreateNewPSInjectionRecord(lppd);
             }
             else 
                 lppd->lpPSInjectData = CreateNewPSInjectionRecord(lppd);
             SetupPSInjectionRecord(lppd, (LPBYTE)lpData);
   //          lpTmp = (LPBYTE)(lpPSInject->dwLen) + sizeof(PSINJECTBYTE);
            lpTmp = (LPBYTE)lpData + sizeof(PSINJECTBYTE);
             lppd->wSpoolError=
                CopyPSInjectionData(lppd, lppd->lpPSInjectData, (LPBYTE)lpTmp, count);
             return (1);

      	 }      

         /* Just write the data out. */
         while ((count > WRITE_SPOOL_MAX) && (lppd->wSpoolError > 0))
         {
         if (lppd->bCopyToSpecial){
            if (lppd->lpSpecialPSData==NULL){
               // Allocate new buffer:
               lppd->lpSpecialPSData = CreateNewSpclPSData(lppd);
               }
            lppd->wSpoolError=
               CopySpecialPSData(lppd, lppd->lpSpecialPSData, (LPBYTE)lpData, WRITE_SPOOL_MAX);
         }
         else {

            lppd->wSpoolError = AdobeOEMWriteSpoolStub(lppd,(LPSTR)lpData,WRITE_SPOOL_MAX);
           }
            //WriteSpool((HANDLE)lppd->hPortHandle,(LPSTR)lpData,WRITE_SPOOL_MAX);
            count  -= WRITE_SPOOL_MAX ;
            lpData += WRITE_SPOOL_MAX ;
        } // end while
         if (lppd->wSpoolError > 0)
         {
           if (lppd->bCopyToSpecial){
            if (lppd->lpSpecialPSData==NULL){
               // Allocate new buffer:
               lppd->lpSpecialPSData = CreateNewSpclPSData(lppd);
               }
            lppd->wSpoolError=
               CopySpecialPSData(lppd, lppd->lpSpecialPSData, (LPBYTE)lpData, count);
            }
           else {
            lppd->wSpoolError = AdobeOEMWriteSpoolStub(lppd,(LPSTR)lpData, count);
         	}
       }	// end else
         
         lppd->iSpoolBufferCount = 0;
      }	//  end if lppd->wSpoolError > 0
   }
   
   return( lppd->wSpoolError );
} // END WriteToSpool 


/*****************************************************************************
*                           FlushToSpool
*  Purpose: 
*       This function flushes the current data in the internal spooler
*       to the Windows Spooler.
*  
*  Parameters:
*       LPPDEVICE lppd -- The context to flush to disk.
*  
*  Returns: int 
*       See DDK on spooler return functions.
*
*****************************************************************************/
int FlushToSpool( LPPDEVICE lppd )
{
   
   if( lppd->iSpoolBufferCount > 0  &&  lppd->wSpoolError  > 0)
   {
      if (lppd->bCopyToSpecial){
         if (lppd->lpSpecialPSData==NULL){
            // Allocate new buffer:
            lppd->lpSpecialPSData = CreateNewSpclPSData(lppd);
            }
         lppd->wSpoolError=
            CopySpecialPSData(lppd, lppd->lpSpecialPSData, (LPBYTE)&(lppd->SpoolBuffer[ 0 ]), lppd->iSpoolBufferCount);
      }
       else {
          lppd->wSpoolError = AdobeOEMWriteSpoolStub(lppd,(LPSTR)&(lppd->SpoolBuffer[ 0 ]), lppd->iSpoolBufferCount );
       }
      
      lppd->iSpoolBufferCount = 0;
   }
   
   return( lppd->wSpoolError );
} // END FlushToSpool 


