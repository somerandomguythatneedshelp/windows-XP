/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: EPSFUNCS.H                                                   */
/*                                                                           */
/* Description: This module contains ...                                     */
/*                                                                           */
/*****************************************************************************/

// EPS format, normal mode
PSERROR FAR PASCAL TSoftFontLoadEPS         (LPPDEVICE,LPPSFONTINFO,LPTEXTXFORM,LPSTR,short);
SHORT FAR PASCAL TDocumentBeginEPS        (LPPDEVICE);
SHORT FAR PASCAL TDocumentEndEPS          (LPPDEVICE);
SHORT FAR PASCAL TDocumentPageBeginEPS    (LPPDEVICE);

// Printable format, Minimal header (EPSPRINTING) mode

SHORT FAR PASCAL TDocumentBeginMinHeader(LPPDEVICE);
SHORT FAR PASCAL TDocumentEndMinHeader(LPPDEVICE);
SHORT FAR PASCAL TRawPrinterStart_MinHdr(LPPDEVICE);
short FAR PASCAL TRawPrinterEnd_MinHdr(LPPDEVICE lppd);

// EPS format, Minimal header (EPSPRINTING) mode

SHORT FAR PASCAL TDocumentBeginMinHeaderEPS(LPPDEVICE);
SHORT FAR PASCAL TDocumentEndMinHeaderEPS(LPPDEVICE);
SHORT FAR PASCAL TDocumentPageBeginMinHeaderEPS(LPPDEVICE);
SHORT FAR PASCAL TDocumentPageEndMinHeaderEPS(LPPDEVICE);

// Dummy functions for EPS. 

short FAR PASCAL TJobCopiesEPS(LPPDEVICE, WORD);
short FAR PASCAL TJobDuplexEPS(LPPDEVICE, WORD);
short FAR PASCAL TPaperSourceEPS(LPPDEVICE, LPSTR);
short FAR PASCAL TPaperSizeEPS(LPPDEVICE, LPSTR);
short FAR PASCAL TPageOrientationEPS(LPPDEVICE,  WORD);


