/* CM_VerSion protos.h atm04 1.3 07683.eco sum= 08070 */
/*
  protos.h

Original version: Ed McCreight: 30 Oct 90
Edit History:
Edward Fiala: 10 May 12:59:10 1991
Ed McCreight: 10 May 91 11:00
End Edit History.
Revision History
  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/PROTOS.H_V  $
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:07:26   unknown
 *- |Initial revision.
  Revision 6.1  91/10/07  18:22:44  rublee
   
  
  
End Revision History.

*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*
*  This source code is provided to you by Adobe on a non-exclusive,
*  royalty-free basis to facilitate your development of PostScript
*  language programs.  You may incorporate it into your software as is
*  or modified, provided that you include the following copyright
*  notice with every copy of your software containing any portion of
*  this source code.
*
* Copyright 1990-1991 Adobe Systems Incorporated.  All Rights Reserved.
*
* Adobe does not warrant or guarantee that this source code will
* perform in any manner.  You alone assume any risks and
* responsibilities associated with implementing, using or
* incorporating this source code into your software.
*
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef	PROTOS_H
#define	PROTOS_H


/* *   F I X E D - L E N G T H   A R G U M E N T   L I S T S   * */

/* The vast majority of C functions accept a fixed number of
 * arguments of fixed type.  The macro PROTOTYPES indicates whether
 * ANSI function prototypes are to be generated (or else ignored
 * as comments) for functions with fixed-length argument lists.
 */
 
#ifndef PROTOTYPES
#ifdef __STDC__
#define PROTOTYPES	__STDC__
#else /* __STDC__ */
#define PROTOTYPES	0
#endif /* __STDC__ */
#endif /* PROTOTYPES */

/* The function prototype macros ARGDECLn() and
 * ARGDEFn() should be as in the following example.
 * The n refers to the (fixed) number of arguments.
 */

#if 0 /* * *   B e g i n   c o m m e n t   * * */

/* ... in interface foozle.h: */
extern procedure foo ARGDECL2(integer, arg1, char *, arg2);

  /* Note: If PROTOTYPES is true, the above expands to
   *
   *    extern procedure foo (integer arg1, char * arg2);
   *     
   * if not, it expands to
   *
   *    extern procedure foo ();
   *
   * Note also that the first argument could optionally have
   * been typed as "register integer" instead of "integer".
   * The adjective "register" has no effect in a function
   * declaration.
   */


/* ... in implementation foozle.c: */
 # include "foozle.h"

 public procedure foo ARGDEF2(register integer, arg1, char *, arg2)

  /* Note: If PROTOTYPES is true, the above expands to
   *
   *    public procedure foo (register integer arg1, char * arg2)
   *
   * if not, it expands to
   *
   *    public procedure foo (arg1, arg2)
   *    register integer arg1;
   *    char * arg2;
   */
   
{
  /* statements of procedure foo */
}

/* .. in client in baz.c */
 # include "foozle.h"

 foo(3, "abc");

#endif /* * *   E n d   c o m m e n t   * * */

/* In a non-ANSI system, prototypes are good documentation.
 * They also help ANSI compilers catch type-mismatch errors.
 *
 * Portability warning:  Prototypes alter the rules for function argument
 * type conversions.  Be sure that all references
 * to prototype-defined functions are in the scope of prototype
 * declarations, and that any function that is prototype-declared
 * is also prototype-defined.  The latter can be checked by the compiler,
 * but the former generally cannot.  Since a prototyped definition
 * serve as a prototyped declaration, a private function does not
 * need a separate declaration if its definition textually precedes
 * its first use.  This definition-before-use order is natural to
 * Pascal programmers.
 */

#if PROTOTYPES

#define ARGDEF0()							\
  (void)
#define ARGDEF1(t1,v1)							\
  (t1 v1)
#define ARGDEF2(t1,v1,t2,v2)						\
  (t1 v1,t2 v2)
#define ARGDEF3(t1,v1,t2,v2,t3,v3)					\
  (t1 v1,t2 v2,t3 v3)
#define ARGDEF4(t1,v1,t2,v2,t3,v3,t4,v4)				\
  (t1 v1,t2 v2,t3 v3,t4 v4)
#define ARGDEF5(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5)				\
  (t1 v1,t2 v2,t3 v3,t4 v4,t5 v5)
#define ARGDEF6(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6)			\
  (t1 v1,t2 v2,t3 v3,t4 v4,t5 v5,t6 v6)
#define ARGDEF7(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7)		\
  (t1 v1,t2 v2,t3 v3,t4 v4,t5 v5,t6 v6,t7 v7)
#define ARGDEF8(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8)	\
  (t1 v1,t2 v2,t3 v3,t4 v4,t5 v5,t6 v6,t7 v7,t8 v8)
#define ARGDEF9(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8,t9,v9)	\
  (t1 v1,t2 v2,t3 v3,t4 v4,t5 v5,t6 v6,t7 v7,t8 v8,t9 v9)
#define ARGDEF10(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8,t9,v9,t10,v10) \
  (t1 v1,t2 v2,t3 v3,t4 v4,t5 v5,t6 v6,t7 v7,t8 v8,t9 v9,t10 v10)

#define ARGDEF11(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8,t9,v9,t10,v10,t11,v11) \
  (t1 v1,t2 v2,t3 v3,t4 v4,t5 v5,t6 v6,t7 v7,t8 v8,t9 v9,t10 v10,t11 v11)
#define ARGDEF12(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8,t9,v9,t10,v10,t11,v11,t12,v12) \
  (t1 v1,t2 v2,t3 v3,t4 v4,t5 v5,t6 v6,t7 v7,t8 v8,t9 v9,t10 v10,t11 v11,t12 v12)

#define ARGDECL0	ARGDEF0
#define ARGDECL1	ARGDEF1
#define ARGDECL2	ARGDEF2
#define ARGDECL3	ARGDEF3
#define ARGDECL4	ARGDEF4
#define ARGDECL5	ARGDEF5
#define ARGDECL6	ARGDEF6
#define ARGDECL7	ARGDEF7
#define ARGDECL8	ARGDEF8
#define ARGDECL9	ARGDEF9
#define ARGDECL10	ARGDEF10
#define ARGDECL11	ARGDEF11
#define ARGDECL12	ARGDEF12

#else /* PROTOTYPES */

#define ARGDEF0()							\
  ()
#define ARGDEF1(t1,v1)							\
  (v1) t1 v1;
#define ARGDEF2(t1,v1,t2,v2)						\
  (v1,v2) t1 v1; t2 v2;
#define ARGDEF3(t1,v1,t2,v2,t3,v3)					\
  (v1,v2,v3) t1 v1; t2 v2; t3 v3;
#define ARGDEF4(t1,v1,t2,v2,t3,v3,t4,v4)				\
  (v1,v2,v3,v4) t1 v1; t2 v2; t3 v3; t4 v4;
#define ARGDEF5(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5)				\
  (v1,v2,v3,v4,v5) t1 v1; t2 v2; t3 v3; t4 v4; t5 v5;
#define ARGDEF6(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6)			\
  (v1,v2,v3,v4,v5,v6) t1 v1; t2 v2; t3 v3; t4 v4; t5 v5; t6 v6;
#define ARGDEF7(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7)		\
  (v1,v2,v3,v4,v5,v6,v7)						\
  t1 v1; t2 v2; t3 v3; t4 v4; t5 v5; t6 v6; t7 v7;
#define ARGDEF8(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8)	\
  (v1,v2,v3,v4,v5,v6,v7,v8)						\
  t1 v1; t2 v2; t3 v3; t4 v4; t5 v5; t6 v6; t7 v7; t8 v8;
#define ARGDEF9(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8,t9,v9)	\
  (v1,v2,v3,v4,v5,v6,v7,v8,v9)						\
  t1 v1; t2 v2; t3 v3; t4 v4; t5 v5; t6 v6; t7 v7; t8 v8; t9 v9;
#define ARGDEF10(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8,t9,v9,t10,v10) \
  (v1,v2,v3,v4,v5,v6,v7,v8,v9,v10)					\
  t1 v1; t2 v2; t3 v3; t4 v4; t5 v5; t6 v6; t7 v7; t8 v8; t9 v9; t10 v10;
#define ARGDEF11(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8,t9,v9,t10,v10,t11,v11) \
  (v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11)					\
  t1 v1; t2 v2; t3 v3; t4 v4; t5 v5; t6 v6; t7 v7; t8 v8; t9 v9; t10 v10; t11 v11;
#define ARGDEF12(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8,t9,v9,t10,v10,t11,v11,t12,v12) \
  (v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12)				\
  t1 v1; t2 v2; t3 v3; t4 v4; t5 v5; t6 v6; t7 v7; t8 v8; t9 v9; t10 v10; t11 v11; t12 v12;


#define ARGDECL0()							\
  ()
#define ARGDECL1(t1,v1)							\
  ()
#define ARGDECL2(t1,v1,t2,v2)						\
  ()
#define ARGDECL3(t1,v1,t2,v2,t3,v3)					\
  ()
#define ARGDECL4(t1,v1,t2,v2,t3,v3,t4,v4)				\
  ()
#define ARGDECL5(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5)				\
  ()
#define ARGDECL6(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6)			\
  ()
#define ARGDECL7(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7)		\
  ()
#define ARGDECL8(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8)	\
  ()
#define ARGDECL9(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8,t9,v9)	\
  ()
#define ARGDECL10(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8,t9,v9,t10,v10) \
  ()
#define ARGDECL11(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8,t9,v9,t10,v10,t11, v11) \
  ()
#define ARGDECL12(t1,v1,t2,v2,t3,v3,t4,v4,t5,v5,t6,v6,t7,v7,t8,v8,t9,v9,t10,v10,t11, v11, t12, v12) \
  ()

#endif /* PROTOTYPES */



/* *   V A R I A B L E - L E N G T H   A R G U M E N T   L I S T S   * */

/* A small but interesting minority of C functions accepts
 * a variable number of arguments of variable type.  The
 * most widely known such function is printf().  There are
 * two commonly-accepted mechanisms for declaring and defining
 * such functions and sequencing through the arguments.
 *
 * The ANSI mechanism declares such a function to have a
 * fixed number of fixed-type arguments (at least one), followed
 * by an indeterminate number of arguments of unspecified type.
 * The indeterminate arguments are indicated by an ellipsis (...).
 * A set of macros for sequencing through the indeterminate
 * arguments is contained in the header file <stdarg.h>.
 *
 * The pre-ANSI mechanism declares such a function to have
 * no declared arguments ().  A set of macros for sequencing
 * through all the arguments is contained in the header file
 * <varargs.h>.
 *
 * Every C compiler should support one mechanism or the
 * other, and some support both.
 *
 * + The macro USE_STDARG selects which mechanism will be used.
 * + The macro PS_stdarg names the header file that defines the
 *     macros to be used for sequencing through variable-length
 *     argument lists.  Its name avoids using all capital letters,
 *     to prevent the makefile autobuilder from trying to read it.
 * + The macro PROTOTYPES_V indicates whether
 *     ANSI function prototypes are to be generated (or else ignored
 *     as comments) for functions with variable-length argument lists.
 *
 * In almost all cases, these macros should default correctly from
 * ANSI_C, but USE_STDARG allows the possibility of a future exception.
 */

#ifndef USE_STDARG
#define USE_STDARG	ANSI_C
#endif

#ifndef PS_stdarg
#if USE_STDARG
#define PS_stdarg	<stdarg.h>
#else /* !USE_STDARG */
#define PS_stdarg	<varargs.h>
#endif /* USE_STDARG */
#endif /* ndef PS_stdarg */

#ifndef PROTOTYPES_V
#define PROTOTYPES_V	USE_STDARG
#endif

/*
 * Here is an example using variable-length argument lists.
 * The function foovsum takes k+1 arguments: the first, k, tells
 * how many others there are, and the remaining ones are reals.
 * The function foovsum returns the sum of the last k arguments.
 *
 * Within the body of foovsum, argp is a local variable defined by
 * the macro ARGDEFVn().  Its type is va_list, defined
 * by stdarg.h or varargs.h.  argp points in a compiler-dependent way
 * to the still-unconsumed part of the argument list.  va_arg(p, t)
 * is a macro defined by stdarg.h or varargs.h that
 * returns the next argument (which must be of type t) from the
 * still-unconsumed part of the argument list pointed to by p,
 * and consumes it by advancing p.
 */

#if 0 /* * *   B e g i n   c o m m e n t   * * */

/* ... in interface foozle.h: */
  real foovsum ARGDECLV1(int, k);

/* ... in implementation foozle.c: */
 #include PS_stdarg
 #include "foozle.h"

 real foovsum ARGDEFV1(int, k)
 {
   int i;
   real sum = 0.0;
   for (i = 0; i < k; i++)
    sum += va_arg(argp, real);
   return sum;
 }
 ARGDEFV_END

/* ... in sources/makefile for foozle.c: */
/* This comment shouldn't be in the makefile but it is needed to stop
   compile warnings!
 # AUTOIGNORE = (PS_stdarg)
 */
/* ... in client baz.c: */
 #include "foozle.h"
 real sum = foovsum(3, 1.0, 2.0, 3.0); /* sum == 6.0 */

#endif  /* 0 * *   E n d   c o m m e n t   * * */


#if PROTOTYPES_V

#define ARGDECLV1(t1,v1)						\
  (t1 v1,...)
#define ARGDECLV2(t1,v1,t2,v2)						\
  (t1 v1,t2 v2,...)
#define ARGDECLV3(t1,v1,t2,v2,t3,v3)					\
  (t1 v1,t2 v2,t3 v3,...)
#define ARGDECLV4(t1,v1,t2,v2,t3,v3,t4,v4)				\
  (t1 v1,t2 v2,t3 v3,t4 v4,...)

#else /* !PROTOTYPES_V */

#define ARGDECLV1(t1,v1)						\
  ()
#define ARGDECLV2(t1,v1,t2,v2)						\
  ()
#define ARGDECLV3(t1,v1,t2,v2,t3,v3)					\
  ()
#define ARGDECLV4(t1,v1,t2,v2,t3,v3,t4,v4)				\
  ()

#endif /* PROTOTYPES_V */

#if USE_STDARG

#define ARGDEFV1(t1,v1)							\
  (t1 v1,...) { va_list argp; va_start(argp, v1);
#define ARGDEFV2(t1,v1,t2,v2)						\
  (t1 v1,t2 v2,...) { va_list argp; va_start(argp, v2);
#define ARGDEFV3(t1,v1,t2,v2,t3,v3)					\
  (t1 v1,t2 v2,t3 v3,...) { va_list argp; va_start(argp, v3);
#define ARGDEFV4(t1,v1,t2,v2,t3,v3,t4,v4)				\
  (t1 v1,t2 v2,t3 v3,t4 v4,...) { va_list argp; va_start(argp, v4);

#else /* !USE_STDARG */

#define ARGDEFV1(t1,v1)							\
  (va_alist) va_dcl {							\
  va_list argp; t1 v1;							\
  va_start(argp);							\
  v1 = va_arg(argp, t1);
#define ARGDEFV2(t1,v1,t2,v2)						\
  (va_alist) va_dcl {							\
  va_list argp; t1 v1; t2 v2;						\
  va_start(argp);							\
  v1 = va_arg(argp, t1);						\
  v2 = va_arg(argp, t2);
#define ARGDEFV3(t1,v1,t2,v2,t3,v3)					\
  (va_alist) va_dcl {							\
  va_list argp; t1 v1; t2 v2; t3 v3;					\
  va_start(argp);							\
  v1 = va_arg(argp, t1);						\
  v2 = va_arg(argp, t2);						\
  v3 = va_arg(argp, t3);
#define ARGDEFV4(t1,v1,t2,v2,t3,v3,t4,v4)					\
  (va_alist) va_dcl {							\
  va_list argp; t1 v1; t2 v2; t3 v3; t4 v4;				\
  va_start(argp);							\
  v1 = va_arg(argp, t1);						\
  v2 = va_arg(argp, t2);						\
  v3 = va_arg(argp, t3);						\
  v4 = va_arg(argp, t4);

#endif /* USE_STDARG */

#define ARGDEFV_END	}

#endif	/* PROTOS_H */
