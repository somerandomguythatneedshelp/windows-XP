/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: FAX.H                                                        */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/

typedef struct _FAXNODE
{
   CHAR zDial[32];
   CHAR zName[32];
   CHAR zPhone[32];
   CHAR zOrganization[32];
   CHAR zMailStop[32];
   CHAR zFaxPhone[32];
   CHAR zID[32];
   CHAR zCCITTID[20];
   CHAR zTimeZone[4];
}FAXNODE, FAR * LPFAXNODE;

typedef struct _FAX
{
   SHORT    sActivityReport;
   BYTE     bAnswer;
   BYTE     bBusy;
   BYTE     bConfirmation;
   BYTEFLAG bCoverSheet;
   BYTE     bDial;
   BYTE     bFaxType;                  /* std,fine */
   BYTE     bGroup3Extensions;
   BYTE     bReceiveImageSize;
   BYTE     bfSpeaker;
   BYTE     bfState;
   BYTE     bMaxRetries;               //number of retries before quit
   BYTE     bRetryInterval;            //number of minutes
   WORD     wMailTime;
   DWORD    wMailDate;
   BYTEFLAG bfTimeStampAuto;
   BYTEFLAG bfTimeStampInside;
   SHORT    sTransSchedule;
   
   /* information related to the receive fax node
    * this could be a array of entries, in the event
    * the fax is to be broadcast
    */
   MEMORY mFaxReceive;
   
   /* information related to the transmit fax node */
   MEMORY mRaxTransmit;

}FAX, FAR * LPFAX;

enum
{
   FAXREPORT_ondemand,
   FAXREPORT_modulo,
   FAXREPORT_tod,
   FAXREPORT_end
};

enum
{
   FAXANSWER_manual,
   FAXANSWER_auto,
   FAXANSWER_end
};

enum
{
   FAXBUSY_busyout,
   FAXBUSY_ringthru,
   FAXBUSY_end
};

enum
{
   FAXCONF_off,
   FAXCONF_on,
   FAXCONF_errors,
   FAXCONF_end
};

enum
{
   FAXDIAL_tone,
   FAXDIAL_pulse,
   FAXDIAL_end
};

enum
{
   FAXG3_dialfirst,
   FAXG3_renderfirst,
   FAXG3_end
};

enum
{
   FAXRCV_page,    //preserve page size
   FAXRCV_pixel,   //preserve pixel count
   FAXRCV_end
};

enum
{
   FAXSPEAKER_off,
   FAXSPEAKER_on,
   FAXSPEAKER_warn,
   FAXSPEAKER_both,
   FAXSPEAKER_end
};

enum
{
   FAXSTATE_nofax,
   FAXSTATE_faxonly,
   FAXSTATE_faxprint,
   FAXSTATE_end
};

enum
{
   FAXSCHEDULE_ondemand,
   FAXSCHEDULE_modulo,
   FAXSCHEDULE_tod,
   FAXSCHEDULE_end
};

enum
{
   FAXTYPE_std,
   FAXTYPE_fine,
   FAXTYPE_end
};



