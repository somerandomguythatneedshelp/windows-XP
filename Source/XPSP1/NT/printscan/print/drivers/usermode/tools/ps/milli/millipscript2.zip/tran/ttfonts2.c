
/****************************************************************************

    PROGRAM: TTfonts2.C

    PURPOSE: Implement ordering IDs (OIDs) for DBCS-CJK and Single-Byte encodings

    FUNCTIONS:
        Define Global arrays for CJK-Encodings.
        Currently, FillGlyphIndextable() is used for D.L. Type42 Single byte fonts.

****************************************************************************/


#include "generic.h"

#pragma code_seg(_TTFONTSSEG)
// Some local functions:
int FAR PASCAL GetCharFromOID(LPBYTE lpStr, BYTE charset, WORD myid, BOOL bEUDC);
// Next two functions are faster version if lpEnc is known.
WORD FAR PASCAL GetOIDFrom2Chars(BYTE first, BYTE second, LPDBCSENCODE lpEnc);
int FAR PASCAL Get2CharsFromOID(LPBYTE lpByte1, LPBYTE lpByte2, LPDBCSENCODE lpEnc, WORD myid);


// Global vriables for all possible encodings. - With EUDC Chars code in.
DBCSENCODE TTFONTSSEG DBCSEncodings[DBCS_LAST]= // globals
{
// One byte
 { 0, 0,
  {{0,0,0,0,0,0}, 
  {0,0,0,0,0,0},
  {0,0,0,0,0,0}, 
  {0,0,0,0,0,0}, 
  {0,0,0,0,0,0}},
  1,
  {{0,0xFF,0,0, 0, 0x100},
  {0,0,0,0,0,0}},
  0x100,
  {{0, 0xFF}, {0, 0}, {0,0}, {0,0}, {0,0}},
  {{0, 0}, {0,0},  {0,0}, {0,0}, {0,0}}
 },

 // Big5
 { 136, 2, 
  {// all DBCS starts from 256.  ranges are: start<= x <end
   // including all EUDCs (Level-1,2,3)
   {0x81, 0xFE, 0x40, 0x7E, 0x100, 0x100+0x7E*0x3F},  // include L1 L2+L3 EUDC
   {0x81, 0xFE, 0xA1, 0xFE, 0x100+0x7E*0x3F, 0x100+0x7E*0x3F+0x7E*0x5E}, //include normal and L1+L2+L3 EUDC
   {0,0,0,0,0,0}, 
   {0,0,0,0,0,0}, 
   {0,0,0,0,0,0}, 
   {0,0,0,0,0,0}, 
   {0,0,0,0,0,0}},
   2,
   {{0, 0x80,0,0, 0, 0x80+1},
   {0xFF, 0xFF, 0,0,0xFF, 0xFF+1},
   {0,0,0,0,0,0},
   {0,0,0,0,0,0}},
   0x100+0x7E*0x9D,  // total 20038 chars.
   {{0, 0x80}, {0xFF,0xFF}, {0,0}, {0,0}, {0,0}},
   {{0x81, 0xFE}, {0,0}, {0,0}, {0,0}, {0,0}}
 },

 // GBK - superset of GB2312-80 -- Extended by Microsoft in Win95-C 
 // - 7-24-1995 - yujiema@microsoft.com
 { 134, 2,
   {
   {0x81, 0xFE, 0x40, 0x7E, 0x100, 0x100+0x7E*0x3F},
   {0x81, 0xFE, 0x80, 0xFE, 0x100+0x7E*0x3F, 0x100+0x7E*0x3F+0x7E*0x7F},
   {0,0,0,0,0,0}, 
   {0,0,0,0,0,0}, 
   {0,0,0,0,0,0}, 
   {0,0,0,0,0,0},
   {0,0,0,0,0,0}},
   2,
   {{0, 0x80,0,0, 0, 0x80+1},
   {0xFF, 0xFF, 0,0,0xFF, 0xFF+1},
   {0,0,0,0,0,0},
   {0,0,0,0,0,0}},
   0x100+0x7E*0xBE, //total 24196 chars
   {{0, 0x80}, {0xFF,0xFF}, {0,0}, {0,0}, {0,0}},
   {{0x81, 0xFE}, {0,0}, {0,0}, {0,0}, {0,0}}
 },

 // SJIS
/* Correct 90ms-Encoding,  from Kei Suzuki 
00   - 1f    Notdef
20   - 7e    Single-byte character range (ASCII)
7f   - 80    Notdef
8140 - 9Ffc  Double-byte character range (Full-width Kana and Kanji)
a0   - df    Single-byte character range (Half-width Kana)
e040 - effc  Double-byte character range (Full-width Kanji)
f040 - f9fc  End-User Defined Character range
fa40 - fcfc  Double-byte character range (Full-width Kanji)
fd   - ff    Notdef
*/
 { 128, 6,
   {
   {0x81, 0x9F, 0x40, 0x7E, 0x100, 0x100+0x1F*0x3F}, 
   {0x81, 0x9F, 0x80, 0xFC, 0x100+0x1F*0x3F, 0x100+0x1F*0x3F+0x1F*0x7D}, 
   {0xE0, 0xF9, 0x40, 0x7E, 0x100+0x1F*0xBC, 0x100+0x1F*0xBC+0x1A*0x3F},
   {0xE0, 0xF9, 0x80, 0xFC, 0x100+0x1F*0xBC+0x1A*0x3F, 0x100+0x1F*0xBC+0x1A*0x3F+0x1A*0x7D},
   {0xfa, 0xFc, 0x40, 0x7E, 0x100+0x39*0xBC, 0x100+0x39*0xBC+0x3*0x3F},
   {0xfa, 0xFc, 0x80, 0xfc, 0x100+0x39*0xBC+0x3*0x3F, 0x100+0x39*0xBC+0x3*0xBC},
   {0,0,0,0,0,0}},
   3,
   {{0, 0x80,0,0, 0, 0x80+1},
   {0xA0, 0xDF,0,0, 0xA0, 0xDF+1},
   {0xFD, 0xFF, 0,0,0xFD, 0xFF+1},
   {0,0,0,0,0,0},
   },
   0x100+0x3C*0xBC,          // 11536 chars total.
   {{0, 0x80},  {0xA0,0xDF}, {0xFD,0xFF}, {0,0}, {0,0}},
   {{0x81, 0x9F}, {0xE0,0xF9}, {0xfa,0xfc}, {0,0}, {0,0}}
 },

 // KS87 - UHC (unified Hungeul Code) - ischoi@microsoft.com -7-24-95
 { 129, 3,
   {
   {0x81, 0xFE, 0x41, 0x5A, 0x100, 0x100+0x7E*0x1A},
   {0x81, 0xFE, 0x61, 0x7A, 0x100+0x7E*0x1A, 0x100+0x7E*0x1A+0x7E*0x1A},
   {0x81, 0xFE, 0x81, 0xFE, 0x100+0x7E*0x34, 0x100+0x7E*0x34+0x7E*0x7E},
   {0,0,0,0,0,0}, 
   {0,0,0,0,0,0}, 
   {0,0,0,0,0,0},
   {0,0,0,0,0,0}},
   2,
   {{00, 0x80,0,0, 0, 0x80+1},
   {0xFF, 0xFF, 0,0,0xFF, 0xFF+1},
   {0,0,0,0,0,0},
   {0,0,0,0,0,0}},
   0x100+0x7E*0xB2,  //total 22684 chars
   {{0, 0x80}, {0xFF,0xFF}, {0,0}, {0,0}, {0,0}},
   {{0x81, 0xFE}, {0,0}, {0,0}, {0,0}, {0,0}}
 },

 // KS92 - Johab - ischoi@microsoft.com -7-24-95
 { 130, 6,
   {
   {0x84, 0xD3, 0x41, 0x7E, 0x100, 0x100+0x50*0x3E}, 
   {0x84, 0xD3, 0x81, 0xFE, 0x100+0x50*0x3E, 0x100+0x50*0x3E+0x50*0x7E}, 
   {0xD8, 0xDE, 0x31, 0x7E, 0x100+0x50*0xBC, 0x100+0x50*0xBC+0x07*0x4E}, //D8 is for EUDC
   {0xD8, 0xDE, 0x91, 0xFE, 0x100+0x50*0xBC+0x07*0x4E, 0x100+0x50*0xBC+0x07*0x4E+0x07*0x6E},
   {0xE0, 0xF9, 0x31, 0x7E, 0x100+0x57*0xBC, 0x100+0x57*0xBC+0x1A*0x4E},
   {0xE0, 0xF9, 0x91, 0xFE, 0x100+0x57*0xBC+0x1A*0x4E, 0x100+0x57*0xBC+0x1A*0x4E+0x1A*0x6E},
   {0,0,0,0,0,0}},
   4,
   {{0, 0x83,0,0, 0, 0x83+1},
    {0xD4, 0xD7, 0,0,0xD4, 0xD7+1},
    {0xDF, 0xDF, 0,0,0xDF, 0xDF+1},
    {0xFA, 0xFF, 0,0,0xFA, 0xFF+1}
   },
   0x100+0x71*0xBC,  // total 21500 chars
   {{0, 0x83}, {0xD4,0xD7}, {0xDF,0xDF}, {0xFA,0xFF}, {0,0}},
   {{0x84, 0xD3}, {0xD8,0xDE}, {0xE0,0xF9}, {0,0}, {0,0}}
 }
,
// GI_FFFF - glyph-index based CID range
 { 0xFF, 3,
  {
   {0x00,  0x7F, 0x00, 0xFF, 0, 0x8000}, 
   {0x80,  0xFE, 0x00, 0xFF, 0x8000, 0xFF00},
   {0xFF,  0xFF, 0x00, 0xFE, 0xFF00, 0xFFFF},
  {0,0,0,0,0,0}, 
  {0,0,0,0,0,0}, 
  {0,0,0,0,0,0}, 
  {0,0,0,0,0,0}},
  0,
  {{0,0,0,0, 0, 0},
   {0,0,0,0,0,0},
   {0,0,0,0,0,0},
   {0,0,0,0,0,0}
  },
  0xFFFF,
  {{0, 0}, {0, 0}, {0,0}, {0,0}, {0,0}},
  {{0, 0}, {0,0},  {0,0}, {0,0}, {0,0}}
 }

};


// Global vriables for all possible encodings - WithOUT EUDC chars.
// Type42 cannot handle EUDC - because GetFontData() won't work on eudc chars
// The user may also choose not to do EUDC by the driver.
DBCSENCODE TTFONTSSEG SmallEncodings[DBCS_LAST]= // globals
{
// One byte
 { 0, 0,
  {{0,0,0,0,0,0}, 
  {0,0,0,0,0,0},
  {0,0,0,0,0,0}, 
  {0,0,0,0,0,0}, 
  {0,0,0,0,0,0}},
  1,
  {{0,0xFF,0,0, 0, 0x100},
  {0,0,0,0,0,0}},
  0x100,
  {{0, 0xFF}, {0, 0}, {0,0}, {0,0}, {0,0}},
  {{0, 0}, {0,0},  {0,0}, {0,0}, {0,0}}
 },

 // Big5
 { 136, 3, 
  {// all DBCS starts from 256.  ranges are: start<= x <end
   // Without any EUDCs:
   {0xA1, 0xFA, 0x40, 0x7E, 0x100, 0x100+0x5A*0x3F},  
   {0xA1, 0xC5, 0xA1, 0xFE, 0x100+0x5A*0x3F, 0x100+0x5A*0x3F+0x25*0x5E}, 
   {0xC9, 0xFA, 0xA1, 0xFE, 0x100+0x5A*0x3F+0x25*0x5E, 0x100+0x5A*0x3F+0x25*0x5E+0x32*0x5E}, 
   {0,0,0,0,0,0}, 
   {0,0,0,0,0,0}, 
   {0,0,0,0,0,0}, 
   {0,0,0,0,0,0}},
   2,
   {{0, 0xA0,0,0, 0, 0xA0+1},
    {0xFB, 0xFF, 0,0,0xFB, 0xFF+1},
    {0,0,0,0,0,0},
    {0,0,0,0,0,0},
    },
   0x100+0x5A*0x3F+0x57*0x5E,  // total 8587 chars - without EUDC.
   {{0, 0xA0}, {0xFB,0xFF}, {0,0}, {0,0}, {0,0}},  //1st-byte range for Single
   {{0xA1, 0xFA}, {0,0}, {0,0}, {0,0}, {0,0}}  //1st-byte range for DBCS
 },

 // GBK - superset of GB2312-80 -- Extended by Microsoft in Win95-C 
 // - 7-24-1995 - yujiema@microsoft.com
 { 134, 4,
   {
   {0x81, 0xFE, 0x40, 0x7E, 0x100, 0x100+0x7E*0x3F},
   {0x81, 0xFE, 0x80, 0xA0, 0x100+0x7E*0x3F, 0x100+0x7E*0x3F+0x7E*0x21},
   {0x81, 0xA9, 0xA1, 0xFE, 0x100+0x7E*0x60, 0x100+0x7E*0x60+0x29*0x5E},
   {0xB0, 0xF7, 0xA1, 0xFE, 0x100+0x7E*0x60+0x29*0x5E, 0x100+0x7E*0x60+0x29*0x5E+0x48*0x5E},
   {0,0,0,0,0,0},
   {0,0,0,0,0,0},
   {0,0,0,0,0,0}},
   2,
   {{0, 0x80,0,0, 0, 0x80+1},
    {0xFF, 0xFF, 0,0,0xFF, 0xFF+1},
    {0,0,0,0,0,0},
    {0,0,0,0,0,0}
    },
   0x100+0x7E*0x60+0x71*0x5E, // total 22974 chars
   {{0, 0x80}, {0xFF,0xFF}, {0,0}, {0,0}, {0,0}},
   {{0x81, 0xFE}, {0,0}, {0,0}, {0,0}, {0,0}}
 },

 // SJIS
/* Correct 90ms-Encoding, from Kei Suzuki 
00   - 1f    Notdef
20   - 7e    Single-byte character range (ASCII)
7f   - 80    Notdef
8140 - 9Ffc  Double-byte character range (Full-width Kana and Kanji)
a0   - df    Single-byte character range (Half-width Kana)
e040 - effc  Double-byte character range (Full-width Kanji)
f040 - f9fc  End-User Defined Character range
fa40 - fcfc  Double-byte character range (Full-width Kanji)
fd   - ff    Notdef
*/
 { 128, 6,
   {
   {0x81, 0x9F, 0x40, 0x7E, 0x100, 0x100+0x1F*0x3F}, 
   {0x81, 0x9F, 0x80, 0xFC, 0x100+0x1F*0x3F, 0x100+0x1F*0x3F+0x1F*0x7D}, 
   {0xE0, 0xEF, 0x40, 0x7E, 0x100+0x1F*0xBC, 0x100+0x1F*0xBC+0x10*0x3F},
   {0xE0, 0xEF, 0x80, 0xFC, 0x100+0x1F*0xBC+0x10*0x3F, 0x100+0x1F*0xBC+0x10*0x3F+0x10*0x7D},
   {0xfa, 0xFc, 0x40, 0x7E, 0x100+0x2F*0xBC, 0x100+0x2F*0xBC+0x3*0x3F},
   {0xfa, 0xFc, 0x80, 0xfc, 0x100+0x2F*0xBC+0x3*0x3F, 0x100+0x2F*0xBC+0x3*0xBC},
   {0,0,0,0,0,0}},
   3,
   {{0, 0x80,0,0, 0, 0x80+1},
    {0xA0, 0xDF,0,0, 0xA0, 0xDF+1},
    {0xFD, 0xFF, 0,0,0xFD, 0xFF+1},
    {0,0,0,0,0,0},
   },
   0x100+0x32*0xBC,          // 9656 chars total.
   {{0, 0x80},  {0xA0,0xDF}, {0xFd,0xFF}, {0,0}, {0,0}},
   {{0x81, 0x9F}, {0xE0,0xEF}, {0xfa,0xfc}, {0,0}, {0,0}}
 },

 // KS87 - UHC (unified Hungeul Code) - ischoi@microsoft.com -7-24-95
 { 129, 5,
   {
   {0x81, 0xFE, 0x41, 0x5A, 0x100, 0x100+0x7E*0x1A},
   {0x81, 0xFE, 0x61, 0x7A, 0x100+0x7E*0x1A, 0x100+0x7E*0x1A+0x7E*0x1A},
   {0x81, 0xFE, 0x81, 0xA0, 0x100+0x7E*0x34, 0x100+0x7E*0x34+0x7E*0x20},
   {0x81, 0xC8, 0xA1, 0xFE, 0x100+0x7E*0x54, 0x100+0x7E*0x54+0x48*0x5E},
   {0xCA, 0xFD, 0xA1, 0xFE, 0x100+0x7E*0x54+0x48*0x5E, 0x100+0x7E*0x54+0x48*0x5E+0x34*0x5E},
   {0,0,0,0,0,0},
   {0,0,0,0,0,0}},
   2,
   {{00, 0x80,0,0, 0, 0x80+1},
    {0xFF, 0xFF, 0,0,0xFF, 0xFF+1},
    {0,0,0,0,0,0},
    {0,0,0,0,0,0}
    },
   0x100+0x7E*0x54+0x7C*0x5E, //total 22496 chars
   {{0, 0x80}, {0xFF,0xFF}, {0,0}, {0,0}, {0,0}},
   {{0x81, 0xFE}, {0,0}, {0,0}, {0,0}, {0,0}}
 },

 // KS92 - Johab - ischoi@microsoft.com -7-24-95
 { 130, 6,
   {
   {0x84, 0xD3, 0x41, 0x7E, 0x100, 0x100+0x50*0x3E}, 
   {0x84, 0xD3, 0x81, 0xFE, 0x100+0x50*0x3E, 0x100+0x50*0x3E+0x50*0x7E}, 
   {0xD9, 0xDE, 0x31, 0x7E, 0x100+0x50*0xBC, 0x100+0x50*0xBC+0x06*0x4E}, 
   {0xD9, 0xDE, 0x91, 0xFE, 0x100+0x50*0xBC+0x06*0x4E, 0x100+0x50*0xBC+0x06*0x4E+0x06*0x6E},
   {0xE0, 0xF9, 0x31, 0x7E, 0x100+0x56*0xBC, 0x100+0x56*0xBC+0x1A*0x4E},
   {0xE0, 0xF9, 0x91, 0xFE, 0x100+0x56*0xBC+0x1A*0x4E, 0x100+0x56*0xBC+0x1A*0x4E+0x1A*0x6E},
   {0,0,0,0,0,0}},
   4,
   {{0, 0x83,0,0, 0, 0x83+1},
    {0xD4, 0xD8, 0,0,0xD4, 0xD8+1},
    {0xDF, 0xDF, 0,0,0xDF, 0xDF+1},
    {0xFA, 0xFF, 0,0,0xFA, 0xFF+1},
   },
   0x100+0x70*0xBC,  // total 21312 chars
   {{0, 0x83}, {0xD4,0xD8}, {0xDF,0xDF}, {0xFA,0xFF}, {0,0}},
   {{0x84, 0xD3}, {0xD9,0xDE}, {0xE0,0xF9}, {0,0}, {0,0}}
 }
,
// GI_FFFF - glyph-index based CID range
 { 0xFF, 3,
  {
   {0x00,  0x7F, 0x00, 0xFF, 0, 0x8000}, 
   {0x80,  0xFE, 0x00, 0xFF, 0x8000, 0xFF00},
   {0xFF,  0xFF, 0x00, 0xFE, 0xFF00, 0xFFFF},
  {0,0,0,0,0,0}, 
  {0,0,0,0,0,0}, 
  {0,0,0,0,0,0}, 
  {0,0,0,0,0,0}},
  0,
  {{0,0,0,0, 0, 0},
   {0,0,0,0,0,0},
   {0,0,0,0,0,0},
   {0,0,0,0,0,0}
  },
  0xFFFF,
  {{0, 0}, {0, 0}, {0,0}, {0,0}, {0,0}},
  {{0, 0}, {0,0},  {0,0}, {0,0}, {0,0}}
 }

};


// In the same order as in ttfonts2.h's enum of the charsets
// CIDFont is possible only for Type42 WITHOUT EUDC.
// So there is only one version - the one without EUDC.
CMAPINFO  TTFONTSSEG CMAPInfo_H[]=
{
   {"WinCharSet000-H", 1, 0, "Adobe", "WinCharSet000", 0}, // this one is never used.
   {"WinCharSet136-H", 1, 0, "Adobe", "WinCharSet136", 0},
   {"WinCharSet134-H", 1, 0, "Adobe", "WinCharSet134", 0},
   {"WinCharSet128-H", 1, 0, "Adobe", "WinCharSet128", 0},
   {"WinCharSet129-H", 1, 0, "Adobe", "WinCharSet129", 0},
   {"WinCharSet130-H", 1, 0, "Adobe", "WinCharSet130", 0},
   {"WinCharSetFFFF-H",1, 0, "Adobe", "WinCharSetFFFF",0},
};

CMAPINFO  TTFONTSSEG CMAPInfo_V[]=
{
   {"WinCharSet000-V", 1, 1, "Adobe", "WinCharSet000", 0}, // this one is never used.
   {"WinCharSet136-V", 1, 1, "Adobe", "WinCharSet136", 0},
   {"WinCharSet134-V", 1, 1, "Adobe", "WinCharSet134", 0},
   {"WinCharSet128-V", 1, 1, "Adobe", "WinCharSet128", 0},
   {"WinCharSet129-V", 1, 1, "Adobe", "WinCharSet129", 0},
   {"WinCharSet130-V", 1, 1, "Adobe", "WinCharSet130", 0},
   {"WinCharSetFFFF-V",1, 1, "Adobe", "WinCharSetFFFF",0},
};

// Function to map from Charset to Our index (enum) of languages.
int LangFromCharSet(int charset){
int lang;
   switch(charset)
     {

      case 128:
        lang = SJIS;
        break;

      case 129:
        lang = KS87;
        break;

      case 130:
        lang = KS92;
        break;

      case 134:
        lang = GB80;
        break;

      case 136:
        lang = BIG5;
        break;

      case 0xFF:
        lang = GI_FFFF;
        break;

      default:
        lang=ONEBYTE;
        break;
     }
     return lang;
}


LPDBCSENCODE FAR PASCAL GetEncoding(int charset, BOOL bEUDC){
int lang = LangFromCharSet(charset);

#ifdef PSDEBUG
// Do a SafeChecking here - to check any possible typos in the ranges
// Check all langs - not t\only this one.
int i, j, sBr, dBr;
WORD start, end;
LPDBCSENCODE lpEncoding;
char tmp[120];
 for (j=0; j<DBCS_LAST;j++){
    if (bEUDC) lpEncoding = &DBCSEncodings[j];  // j-th encoding - with EUDC
    else lpEncoding = &SmallEncodings[j];  // j-th encoding WITHOUT EUDC
    sBr = lpEncoding->numSBRange;
    dBr = lpEncoding->numDBRange;

    start = 0;
    for (i=0; i<sBr; i++){
       end = lpEncoding->SBRanges[i].max_1+1;  // Single byte range is from 0 to 255.
       start= lpEncoding->SBRanges[i].min_1;
       if (j!=6)  // we know GI_FFFF's char count is bad - we don't use it!!
       {
           if (start != lpEncoding->SBRanges[i].start ||
              end != lpEncoding->SBRanges[i].end){
              lpEncoding->SBRanges[i].start = start;
              lpEncoding->SBRanges[i].end = end;
              wsprintf(tmp, "j=%d, i=%d", j, i);
              MessageBox(NULL, "ERROR in DBCSEncodings's SBRanges", tmp, MB_OK);
           }
       }
       start = end;  
       }

    start = 256;  // DBCs starts at 256
    for (i=0; i<dBr; i++){
       end = start +
               (lpEncoding->DBCSRanges[i].max_1 - lpEncoding->DBCSRanges[i].min_1 + 1) *
               (lpEncoding->DBCSRanges[i].max_2 - lpEncoding->DBCSRanges[i].min_2 + 1);
       if (j!=GI_FFFF)  // we know GI_FFFF's char count is bad - we don't use it!!
       {
       if (start != lpEncoding->DBCSRanges[i].start ||
           end != lpEncoding->DBCSRanges[i].end){
            lpEncoding->DBCSRanges[i].start = start;
            lpEncoding->DBCSRanges[i].end = end;
            wsprintf(tmp, "j=%d, i=%d", j, i);
               MessageBox(NULL, "ERROR in DBCSEncodings's DBCSRanges", tmp, MB_OK);
           }
        }
       start = end;  
       }

    // Finally check n - CIDCount
     if (j!=GI_FFFF)  // we know GI_FFFF's char count is bad - we don't use it!!
     {
         if (end != lpEncoding->n){
             lpEncoding->n = end;
             wsprintf(tmp, "j=%d, i=%d", j, i);
             MessageBox(NULL, "ERROR in DBCSEncodings's n -CIDCount", tmp, MB_OK);
         }
      }
  }
#endif
   if (bEUDC) return (LPDBCSENCODE)&DBCSEncodings[lang];
   else return (LPDBCSENCODE)&SmallEncodings[lang];
}


LPCMAPINFO FAR PASCAL GetCMAPInfo(int charset, int bVertical){
int lang = LangFromCharSet(charset);
   if (bVertical) return (LPCMAPINFO)&CMAPInfo_V[lang];
   else return (LPCMAPINFO)&CMAPInfo_H[lang];
}


// Return the OID for one or two chars in lpStr based on charset
// This function doesn't move pointer lpStr. Caller should use AnsiNext()
// to do so.
WORD FAR PASCAL GetOIDFromChar(LPBYTE lpByte, BYTE charset, BOOL bEUDC)
{
WORD myid = 0 ; 
BYTE first, second;
LPDBCSENCODE lpEncoding;
    first = *lpByte;
    second = *(lpByte+1); // second byte
    lpEncoding = GetEncoding((int)charset, bEUDC);
    myid = GetOIDFrom2Chars(first, second, lpEncoding);
    return myid;
}


// Return the OID for two chars in lpByte1 lpByte2 based on charset
// For efficiency, this function always returns in the middle of a loop
// Be careful when adding more cases/code.
WORD FAR PASCAL GetOIDFrom2Chars(BYTE first, BYTE second, LPDBCSENCODE lpEncoding)
{
int i, ylen, sBr, dBr;
WORD myid = 0 ; // in case not found, return 0 == .notdef

    dBr = lpEncoding->numDBRange;
    sBr = lpEncoding->numSBRange;

    if (dBr==0) return (WORD) first; // Single Byte Encoding

    // Search single byte ranges first.
    for (i=0; i<sBr; i++){
       if ( (first>=lpEncoding->SBRanges[i].min_1  
             && first<=lpEncoding->SBRanges[i].max_1) )
          {
          // find it in this Single Byte range - IT's a single byte
          myid = (WORD)first;
          return myid;
          }
       }


    // Continue to search DByte ranges IF not found yet
    myid = lpEncoding->n; // to distinguish from single-byte .notdef id

    for (i=0; i<dBr; i++){
       if ( (first>=lpEncoding->DBCSRanges[i].min_1  
             && first<=lpEncoding->DBCSRanges[i].max_1) &&
            (second>=lpEncoding->DBCSRanges[i].min_2  
             && second<=lpEncoding->DBCSRanges[i].max_2) )
            {
            // find it in this range
            ylen = (int)lpEncoding->DBCSRanges[i].max_2 +1 - (int)lpEncoding->DBCSRanges[i].min_2;
            myid = (WORD)( lpEncoding->DBCSRanges[i].start  
                  + ((int)first -  lpEncoding->DBCSRanges[i].min_1) * ylen
                  + ((int)second - lpEncoding->DBCSRanges[i].min_2) );
            return myid;
            }
       }

   // if still not found in the DB range- return it as DB notdef: lpEncoding->n
   return myid;
}



// Fill in the first one or two bytes in lpByte based on id and charset.
// lpByte should be at least 2-bytes long. !!!!
// If the OID is beyound the range, lpByte points to NULL on return
// This function doesn't move the pointer lpByte to the next char. Caller
// Can use AnsiNext() or check the return value.
// Return Value: 1 - if one byte is inlpByte, 
//               2- if two bytes are in lpByte.
int FAR PASCAL GetCharFromOID(LPBYTE lpByte, BYTE charset, WORD myid, BOOL bEUDC)
{
WORD ret;
BYTE first=0, second=0;
LPDBCSENCODE lpEncoding;
    lpEncoding = GetEncoding((int)charset, bEUDC);
    ret=Get2CharsFromOID((LPBYTE)&first, (LPBYTE)&second, lpEncoding, myid);
    *lpByte = first;
    if (ret>1) *(lpByte+1) = second;
   return ret;
}


// Fill in two bytes based on id and charset.
// If the OID is beyound the range, lpByte1 points to NULL on return
// For efficiency, this function always returns in the middle of a loop
// Be careful when adding more cases/code.
// Return Value: 1 - if only one byte lpByte1 is used, 
//               2 - if two bytes lpByte and lpByte2 are used.
int FAR PASCAL Get2CharsFromOID(LPBYTE lpByte1, LPBYTE lpByte2, LPDBCSENCODE lpEncoding, WORD myid)
{
int sBr, dBr, i, k, ylen;

    sBr = lpEncoding->numSBRange;
    dBr = lpEncoding->numDBRange;

    // Special cases first
    if (myid<256 || dBr == 0){
       *lpByte1 = (BYTE)(myid&0x00FF);
       return 1;
      }
    if (myid >= lpEncoding->n) {
       *lpByte1 = '\0';
       return 1;
    }

    for (i=0; i<dBr; i++){
        if (myid >=lpEncoding->DBCSRanges[i].start &&
            myid < lpEncoding->DBCSRanges[i].end) {
            ylen = (int) lpEncoding->DBCSRanges[i].max_2 +1 - (int)lpEncoding->DBCSRanges[i].min_2;
            k = (myid - lpEncoding->DBCSRanges[i].start) / ylen;
            *lpByte1 = (BYTE) k + lpEncoding->DBCSRanges[i].min_1;
            k = (myid - lpEncoding->DBCSRanges[i].start) % ylen;
            *lpByte2 = (BYTE) k + lpEncoding->DBCSRanges[i].min_2;
            return 2;  // stop search !
          }
       }
 
  // unknown - maybe a single byte junk
  return 1;

}


BOOL FAR PASCAL IsGoodOID(WORD myid, int charset, BOOL bEUDC)
{
LPDBCSENCODE lpEncoding;
    lpEncoding = GetEncoding(charset, bEUDC);
    if (myid >=0 && myid < lpEncoding->n) return 1;
    else return 0;
}



// Build Glyph Index in lpwGI for font lf
// Pass-ed in lpwGI should be large enough to hold all chars in this charset.
// 16K (>15014) of WORD is enough for all CJK (today).
int FAR PASCAL FillGlyphIndexTable(HWND hwnd, LPGITABLE lpGITable){
HDC hDC;
HFONT hFont1, hOldFont1;
GCP_RESULTS results;
WORD i;
DWORD dwLangInfo;
LPDBCSENCODE lpEncoding;
char  c2[6];       // a 1 or 2 byte char

        
    results.lStructSize = sizeof(GCP_RESULTS);
    results.lpOutString = NULL;
    results.lpOrder = NULL;
    results.lpOutString = NULL;
    results.lpOrder = NULL;
    results.lpDx = NULL;
    results.lpCaretPos = NULL;
    results.lpClass = NULL;

    lpEncoding = GetEncoding((int)lpGITable->lf.lfCharSet, lpGITable->bEUDC);
    lpGITable->n=lpEncoding->n;

   // Use Screen DC.
   hDC=GetDC(hwnd);
   hFont1 = CreateFontIndirect(&(lpGITable->lf));
   hOldFont1 = SelectObject(hDC, hFont1);
   dwLangInfo = GetFontLanguageInfo(hDC);

   // Safe but stupid/slow: Better call GetCharplacement() for strings
   // Single bytes range: 0-255 
   c2[1]='\0';
   for (i=0; i<256;i++){
      results.lpGlyphs = lpGITable->lpwGI + i;
      results.nGlyphs = results.nMaxFit = 1;
      c2[0] = (BYTE) i;
      GetCharacterPlacement(hDC, (LPSTR)c2, 1, 1, &results, 0);
   }

#ifdef PSDEBUG
     if (lpEncoding->n > 256)
        MessageBox(NULL, "Somehow this is still called for DBCS. Run Debugger NOW", "Warning - Possible Bug", MB_OK);
#endif
      
   SelectObject(hDC, hOldFont1);
   DeleteObject(hFont1);
   ReleaseDC(hwnd, hDC);

return 1;
}



int FAR PASCAL Fill1ByteGlyphIndexTable(LPLOGFONT lf, LPWORD lpW1ByteGI)
{
HDC hDC;
HFONT hFont1, hOldFont1;
GCP_RESULTS results;
WORD i;
DWORD dwLangInfo;
char  c2[3];       // a 1 or 2 byte char

   if (!lf || !lpW1ByteGI) return 0;

   results.lStructSize = sizeof(GCP_RESULTS);
   results.lpOutString = NULL;
   results.lpOrder = NULL;
   results.lpDx = NULL;
   results.lpCaretPos = NULL; 
   results.lpClass = NULL;

   // Use Screen DC.
   hDC=GetDC(NULL);
   hFont1 = CreateFontIndirect(lf);
   hOldFont1 = SelectObject(hDC, hFont1);
   dwLangInfo = GetFontLanguageInfo(hDC);

   // Safe but stupid/slow: Better call GetCharplacement() for strings
   // Single bytes range: 0-255 
   c2[1]='\0';
   for (i= 0; i<256; i++){
      results.lpGlyphs = lpW1ByteGI + i;
      results.nGlyphs = results.nMaxFit = 1;
      c2[0] = (BYTE) i;
      GetCharacterPlacement(hDC, (LPSTR)c2, 1, 1, &results, 0);
   }

   SelectObject(hDC, hOldFont1);
   DeleteObject(hFont1);
   ReleaseDC(NULL, hDC);

return 1;
}


WORD FAR PASCAL GetGlyphIndexFromOID(LPLOGFONT lf, WORD oid, BOOL bEUDC)
{
HDC hDC;
HFONT hFont1, hOldFont1;
GCP_RESULTS results;
WORD gid[2];
DWORD dwLangInfo;
char  c2[3];       // a 1 or 2 byte char

   if (!lf) return 0;

   results.lStructSize = sizeof(GCP_RESULTS);
   results.lpOutString = NULL;
   results.lpOrder = NULL;
   results.lpDx = NULL;
   results.lpCaretPos = NULL; 
   results.lpClass = NULL;

   // Use Screen DC.
   hDC=GetDC(NULL);
   hFont1 = CreateFontIndirect(lf);
   hOldFont1 = SelectObject(hDC, hFont1);
   dwLangInfo = GetFontLanguageInfo(hDC);  // not use for now

   c2[0]=c2[1]=c2[2]='\0';
   GetCharFromOID((LPBYTE)&c2, (BYTE)lf->lfCharSet, oid, bEUDC);
   results.lpGlyphs = (LPWORD)&gid[0];
   results.nGlyphs = results.nMaxFit = 2;  // must be 2 to make GDI happy
   GetCharacterPlacement(hDC, (LPSTR)c2, 2, 2, &results, 0);  // must be 2 to make GDI happy

   SelectObject(hDC, hOldFont1);
   DeleteObject(hFont1);
   ReleaseDC(NULL, hDC);

   return gid[0];
}

int FAR PASCAL GetCIDCount(int charset, BOOL bEUDC)
{
LPDBCSENCODE lpEncoding;
    lpEncoding = GetEncoding(charset, bEUDC);
    // lpEncoding->n i sused as another notdef, so the totalCID is n+1
    return (1+lpEncoding->n);
}

