/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: BITBLT.C                                                     */
/*                                                                           */
/* Description: This module contains the functions for ...                   */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_DIBSEG)

BOOL  FAR PASCAL dmBitblt(LP,short,short,LPBITMAP,short,short,short,short,DWORD,LPPBRUSH,LPDRAWMODE);
short _loadds FAR PASCAL DevStretchBlt(LP,short,short,short,short,LPBITMAP,
                                       short,short, short,short,DWORD,LPPBRUSH,
                                       LPDRAWMODE,LPRECT);

/*****************************************************************************
*                 DevBitBlt                                                 
* Function:   
*                                                                           
* Called:
*   BOOL FAR PASCAL DevBitBlt(LP lpDest,short DestX,short DestY,LPBITMAP lpSrc,
*                short SrcX,short SrcY,short XExt,short YExt,DWORD dRop,
*                LPPBRUSH lpPBrush,LPDRAWMODE lpDrawMode)
*                                                                           
* Parameters:                                                               
*   LP          lpDest -- pointer to 
*   short       DestX
*   short       DestY
*   LPBITMAP lpSrc
*   short       SrcX
*   short       SrcY
*   short       XExt
*   short       YExt
*   DWORD       dRop
*   LPPBRUSH    lpPBrush
*   LPDRAWMODE  lpDrawMode
*                                                                           
* Returns: BOOL
*   TRUE  => if success 
*   FALSE => if failure 
*****************************************************************************/

BOOL _loadds FAR PASCAL DevBitBlt(LP lpDest,short DestX,short DestY,
                                  LPBITMAP lpSrc, short SrcX,short SrcY,
                                  short XExt,short YExt,DWORD dRop,
                                  LPPBRUSH lpPBrush,LPDRAWMODE lpDrawMode)
{
    LPPDEVICE lppd  =(LPPDEVICE)lpDest;

    if(lppd->sMagic == 0)
        {                                                 // Dest is memory
        dmBitblt(lpDest,DestX,DestY,lpSrc,SrcX,SrcY,
                 XExt,YExt,dRop,lpPBrush,lpDrawMode) ;
        }
    else if (lppd->sMagic == LUCAS)
        {                        // Dest is our device
               DevStretchBlt(lpDest,DestX,DestY,XExt,YExt,lpSrc,SrcX,SrcY,
                       XExt,YExt,dRop,lpPBrush,lpDrawMode,(LPRECT) NULL);
        }
    return( TRUE );
}
