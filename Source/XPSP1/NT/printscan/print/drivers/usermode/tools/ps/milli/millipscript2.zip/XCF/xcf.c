/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1994 Adobe Systems, Inc. All rights reserved.               */
/*                                                                           */
/* Module Name: XCF.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for managing basic DLL    */
/*              startup and shutdown                                         */
/*                                                                           */
/*****************************************************************************/

#include "windows.h"

/*****************************************************************************/
/*                          LibMain                                          */
/*  function:                                                                */
/*            called by LibEntry.  LibEntry is called by Windows when        */
/*            the DLL is loaded.  The LibEntry routine is provided in        */
/*            the LIBENTRY.OBJ in the SDK Link Libraries disk.  (The         */
/*            source LIBENTRY.ASM is also provided.)                         */
/*                                                                           */
/*            LibEntry initializes the DLL's heap, if a HEAPSIZE value is    */
/*            specified in the DLL's DEF file.  Then LibEntry calls          */
/*            LibMain.  The LibMain function below satisfies that call.      */
/*                                                                           */
/*  prototype:                                                               */
/*       int FAR PASCAL LibMain(HANDLE hModule, WORD wDataSeg,               */
/*                              WORD cbHeapSize, LPSTR lpszCmdLine)          */
/*  parameters:                                                              */
/*       HANDLE hModule -- the module handle                                 */
/*       WORD   wDataSeg -- the data segment descriptor                      */
/*       WORD   cbHeapSize -- heap                                           */
/*       LPSTR  lpszCmdLine -- string containing the command line            */
/*  returns:                                                                 */
/*       int   1 => success                                                  */
/*             0 => failure                                                  */
/*****************************************************************************/

int FAR PASCAL LibMain(hModule, wDataSeg, cbHeapSize, lpszCmdLine)
  HANDLE  hModule;
  WORD    wDataSeg;
  WORD    cbHeapSize;
  LPSTR   lpszCmdLine;
{

  if (hModule != NULL)
    hInstance = hModule;

  return (TRUE);
}

/*****************************************************************************/
/*                               WEP                                         */
/*  function:                                                                */
/*       called by Windows when the DLL is unloaded.                         */
/*  prototype:                                                               */
/*       int FAR PASCAL WEP(int bSystemExit);                                */
/*  parameters:                                                              */
/*       int bSystemExit -- TRUE => whole system is stopping                 */
/*  returns:                                                                 */
/*       int 1 => success                                                    */
/*****************************************************************************/

int _loadds CALLBACK WEP (bSystemExit)
  int  bSystemExit;
{
  return(1);
}
