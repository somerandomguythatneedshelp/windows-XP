/*
 *    Adobe Universal Font Library
 *
 *    Copyright (c) 1996 Adobe Systems Inc.
 *    All Rights Reserved
 *
 *    UFOT42.c
 *
 *
 * $Header:
 */


/*===============================================================================*
 * Include files used by this interface                                          *
 *===============================================================================*/
#include "UFLPriv.h"
#include "UFOT42.h"
#include "UFLMem.h"
#include "UFLMath.h"
#include "UFLStd.h"
#include "UFLErr.h"
#include "UFLPS.h"
#include "ParseTT.h"
#include "UFLVm.h"

UFOStruct *T42FontInit(
    const UFLMemObj *pMem,
    const UFLStruct *pUFL,
    const UFLRequest *pRequest
    );

UFLErrCode T42VMNeeded(
    UFOStruct           *pUFObj,
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMNeeded,
    unsigned long       *pFCNeeded
    );

UFLErrCode T42FontDownloadIncr(
    UFOStruct           *pUFObj,
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMUsage,
    unsigned long       *pFCUsage
    );

UFLErrCode
T42UndefineFont(
    UFOStruct   *pUFObj
);

static unsigned long GetLenByScanLoca(void PTR_PREFIX *,unsigned short,unsigned long,int );


/*
                         TrueType Table Description

    cmap - This table defines the mapping of character codes to the glyph index
           values used in the font. It may contain more than one subtable, in
           order to support more than one character encoding scheme. Character
           codes that do not correspond to any glyph in the font should be
           mapped to glyph index 0. The glyph at this location must be a
           special glyph representing a missing character.

    cvt - This table contains a list of values that can be referenced by
          instructions. They can be used, among other things, to control
          characteristics for different glyphs.

    fpgm - This table is similar to the CVT Program, except that it is only run
           once, when the font is first used. It is used only for FDEFs and
           IDEFs. Thus the CVT Program need not contain function definitions.
           However, the CVT Program may redefine existing FDEFs or IDEFs.
           FDEFS - Functional defs.  IDEFs - Intruction defs.

    glyf - This table contains information that describes the glyphs in the font.

    head - This table gives global information about the font.
            Table version number 0x00010000 for version 1.0.
            FIXED           fontRevision        Set by font manufacturer.
            ULONG           checkSumAdjustment  To compute:  set it to 0, sum
                                                the entire font as ULONG, then
                                                store 0xB1B0AFBA - sum.
            ULONG           magicNumber         Set to 0x5F0F3CF5.
            USHORT          flags               Bit 0 - baseline for font at y=0
                                                Bit 1 - left sidebearing at x=0
                                                Bit 2 - instructions may depend
                                                        on point size
                                                Bit 3 - force ppem to integer
                                                        values for all internal
                                                        scaler math; may use
                                                        fractional ppem sizes
                                                        if this bit is clear
            USHORT          unitsPerEm          Valid range is from 16 to 16384
            longDateTime    created             International date (8-byte field).
            longDateTime    modified            International date (8-byte field).
            FWORD           xMin                For all glyph bounding boxes.
            FWORD           yMin                For all glyph bounding boxes.
            FWORD           xMax                For all glyph bounding boxes.
            FWORD           yMax                For all glyph bounding boxes.
            USHORT          macStyle            Bit 0 bold (if set to 1)
                                                Bit 1 italic (if set to 1)
                                                Bits 2-15 reserved (set to 0).
            USHORT          lowestRecPPEM       Smallest readable size in pixels.
            SHORT           fontDirectionHint   0  Fully mixed directional glyphs
                                                1  Only strongly left to right
                                                2  Like 1 but also contains neutrals1
                                                -1 Only strongly right to left
                                                -2 Like -1 but also contains neutrals.
            SHORT           indexToLocFormat    0 for short offsets, 1 for long.
            SHORT           glyphDataFormat     0 for current format.

    hhea - This table contains information for horizontal layout.
            Type    Name                    Description
            FIXED   Table version number    0x00010000 for version 1.0.
            FWORD   Ascender                Typographic ascent.
            FWORD   Descender               Typographic descent.
            FWORD   LineGap                 Typographic line gap. Negative
                                            LineGap values are treated as zero
                                            in Windows 3.1, System 6, and System 7.
            UFWORD  advanceWidthMax         Maximum advance width value in hmtx table.
            FWORD   minLeftSideBearing      Minimum left sidebearing value in hmtx table.
            FWORD   minRightSideBearing     Minimum right sidebearing value.
                                            Calculated as Min(aw - lsb - (xMax - xMin)).
            FWORD   xMaxExtent              Max(lsb + (xMax - xMin)).
            SHORT   caretSlopeRise          Used to calculate the slope of the
                                            cursor (rise/run); 1 for vertical.
            SHORT   caretSlopeRun           0 for vertical.
            SHORT   (reserved)              set to 0
            SHORT   (reserved)              set to 0
            SHORT   (reserved)              set to 0
            SHORT   (reserved)              set to 0
            SHORT   (reserved)              set to 0
            SHORT   metricDataFormat        0 for current format.
            USHORT  numberOfHMetrics        Number of hMetric entries in hmtx
                                            table; may be smaller than the total
                                            number of glyphs in the font.

    hmtx - Horizontal metrics


    loca - The indexToLoc table stores the offsets to the locations of the
           glyphs in the font, relative to the beginning of the glyphData
           table. In order to compute the length of the last glyph element,
           there is an extra entry after the last valid index. By definition,
           index zero points to the missing character, which is the character
           that appears if a character is not found in the font. The missing
           character is commonly represented by a blank box or a space. If the
           font does not contain an outline for the missing character, then the
           first and second offsets should have the same value. This also
           applies to any other character without an outline, such as the space
           character. Most routines will look at the 'maxp' table to determine
           the number of glyphs in the font, but the value in the �loca� table
           should agree. There are two versions of this table, the short and
           the long. The version is specified in the indexToLocFormat entry in
           the head' table.

    maxp - This table establishes the memory requirements for this font.
            Type    Name    Description
            Fixed   Table version number    0x00010000 for version 1.0.
            USHORT  numGlyphs               The number of glyphs in the font.
            USHORT  maxPoints               Maximum points in a non-composite glyph.
            USHORT  maxContours             Maximum contours in a non-composite glyph.
            USHORT  maxCompositePoints      Maximum points in a composite glyph.
            USHORT  maxCompositeContours    Maximum contours in a composite glyph.
            USHORT  maxZones                1 if instructions do not use the twilight zone (Z0)
                                            2 if instructions do use Z0
                                            This should be set to 2 in most cases.
            USHORT  maxTwilightPoints       Maximum points used in Z0.
            USHORT  maxStorage              Number of Storage Area locations.
            USHORT  maxFunctionDefs         Number of FDEFs.
            USHORT  maxInstructionDefs      Number of IDEFs.
            USHORT  maxStackElements        Maximum stack depth2.
            USHORT  maxSizeOfInstructions   Maximum byte count for glyph instructions.
            USHORT  maxComponentElements    Maximum number of components
                                            referenced at "top level" for any
                                            composite glyph.
            USHORT  maxComponentDepth       Maximum levels of recursion; 1 for
                                            simple components.

    prep - The Control Value Program consists of a set of TrueType instructions
           that will be executed whenever the font or point size or
           transformation matrix change and before each glyph is interpreted.
           Any instruction is legal in the CVT Program but since no glyph is
           associated with it, instructions intended to move points within a
           particular glyph outline cannot be used in the CVT Program. The name
           'prep' is anachronistic.
*/


static char *RequiredTables_default[MINIMALNUMBERTABLES] =
{
    "cvt ",
    "fpgm",     // This table is missing from many fonts.
    "glyf",
    "head",
    "hhea",
    "hmtx",
    "loca",
    "maxp",
    "prep"
};

static char *RequiredTables_2015[MINIMALNUMBERTABLES] =
{
    "cvt ",
    "fpgm",     // This table is missing from many fonts.
    "glyf",
    "head",
    "hhea",
    "hmtx",
//  "loca",     // This huge table is Not needed on 2015 Pritners.
    "maxp",
    "prep",
    "zzzz"      // Dummy to fill this array (and has to be the last!).
};

static char* RDString = " RDS ";    // Fix bug Adobe #233904

typedef struct {
    long  startU;
    long  endU;
    long  startL;
    long  endL;
} CODERANGE;

typedef struct {
   short          sMaxCount;    // Maximum number of glyphs
   short          sCount;       // Number of glyps we're holding
   unsigned short *pGlyphs;     // Pointer to array of glyph indices.
} COMPOSITEGLYPHS;

#if 1
static CODERANGE gHalfWidthChars[] = {
    {0x0020, 0x007E, 0x20, 0x7E},   // CJK ASCII chars
    {0xFF60, 0xFF9F, 0x20, 0x5F},   // 0x20 to 0x5F is made up to make the localcode range the size
    {0xFFA0, 0xFFDF, 0xA0, 0xDF},   // HalfWidth J-Katakana and K-Hangul, Unicode Book P.383
    {0, 0, 0, 0}                    // terminator
    };
#else
// BUGBUG: this could be more accurite than the one above.
static CODERANGE gHalfWidthChars[] = {
    {0x0020, 0x007E, 0x20, 0x7E},   // ASCII (0x20-0x7E)
    {0xFF61, 0xFF9F, 0xA1, 0xDF},   // Half-width Katakana (0xA1-0xDF)
    {0xFFA0, 0xFFDC, 0x40, 0x7C},   // HalfWidth jamo (0x40-0x7C)
    {0, 0, 0, 0}                    // terminator
    };
#endif

#define  NUM_HALFWIDTHCHARS \
        ((short) (gHalfWidthChars[0].endL - gHalfWidthChars[0].startL + 1) + \
             (gHalfWidthChars[1].endL - gHalfWidthChars[1].startL + 1) + \
             (gHalfWidthChars[2].endL - gHalfWidthChars[2].startL + 1) + \
             (gHalfWidthChars[3].endL - gHalfWidthChars[3].startL + 1) + 1 )


// CIDSysInfo "(Adobe) (WinCharSetFFFF) 0" is registered for Win95 driver. Re-use it here.
static UFLCMapInfo  CMapInfo_FF_H  = {"WinCharSetFFFF-H",  1, 0, "Adobe", "WinCharSetFFFF", 0};
static UFLCMapInfo  CMapInfo_FF_V  = {"WinCharSetFFFF-V",  1, 1, "Adobe", "WinCharSetFFFF", 0};
static UFLCMapInfo  CMapInfo_FF_H2 = {"WinCharSetFFFF-H2", 1, 0, "Adobe", "WinCharSetFFFF", 0};
static UFLCMapInfo  CMapInfo_FF_V2 = {"WinCharSetFFFF-V2", 1, 1, "Adobe", "WinCharSetFFFF", 0};


char *gcidSuffix[NUM_CIDSUFFIX]={"CID", "CIDR", "CID32K", "CID32KR"};
#define CIDSUFFIX_R     1
#define CIDSUFFIX_32K   2
#define CIDSUFFIX_32KR  3

// Magic Baseline Numbers:
#define TT_BASELINE_X  "0.15"
#define TT_BASELINE_Y  "0.85"


void
T42FontCleanUp(
    UFOStruct      *pUFObj
    )
{
    T42FontStruct *pFont;

    if (pUFObj->pAFont == nil)
        return;

    pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    if ( pFont == nil )
        return;

    if (pFont->pHeader != nil)
        UFLDeletePtr(pUFObj->pMem, pFont->pHeader);

    if (pFont->pMinSfnt != nil)
        UFLDeletePtr(pUFObj->pMem, pFont->pMinSfnt);

    if (pFont->pStringLength != nil)
        UFLDeletePtr(pUFObj->pMem, pFont->pStringLength);

    if (pFont->pLocaTable != nil)
        UFLDeletePtr(pUFObj->pMem, pFont->pLocaTable);

    if (pFont->pRotatedGlyphIDs != nil)
        UFLDeletePtr(pUFObj->pMem, pFont->pRotatedGlyphIDs);
}


unsigned long
GetFontTable(
    UFOStruct     *pUFObj,
    unsigned long tableName,
    unsigned char *pTable
    )
{
    unsigned long   tableSize;
    T42FontStruct   *pFont;

    pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    tableSize = GETTTFONTDATA(pUFObj,
                                tableName,
                                0, 0, 0L,
                                pFont->info.fData.fontIndex);  /* size of the table */

    if (pTable != 0 && tableSize)
        tableSize = GETTTFONTDATA(pUFObj,
                                    tableName,
                                    0, pTable, tableSize,
                                    pFont->info.fData.fontIndex); /* get whole table */

    //
    // Special hack to fix #185003 and #308981: avoid useless
    // maxSizeOfInstructions check in TrueType rasterizer by setting the
    // highest value.
    //
    if (tableName == (*(unsigned long*)"maxp"))
    {
        //
        // maxSizeOfInstructions field in 'maxp' table is at byte offset 26
        // and 27.
        //
        pTable[26] = pTable[27] = 0xff;
    }

    return (tableSize);
}


void *GetSfntTable(
     unsigned char *sfnt,
     unsigned long tableName
     )
{
    TableDirectoryStruct *pTableDirectory = (TableDirectoryStruct*)sfnt;
    TableEntryStruct     *pTableEntry     = (TableEntryStruct*)((char*)pTableDirectory
                                                + sizeof(TableDirectoryStruct));
    unsigned short i = 0;

    while (i < MOTOROLAINT(pTableDirectory->numTables))
    {
        if (pTableEntry->tag == tableName)
        {
            break;
        }
        else
        {
            pTableEntry = (TableEntryStruct*)((char*)pTableEntry + sizeof(TableEntryStruct));
            i++;
        }
    }

    if (i < MOTOROLAINT(pTableDirectory->numTables))
    {
        if (pTableEntry->offset)
            return (void*)(sfnt + MOTOROLALONG(pTableEntry->offset));
    }

    return nil;
}



unsigned long
GetTableSize(
    UFOStruct     *pUFObj,
    unsigned char *pHeader,
    unsigned long tableName
    )

/*++

    This function returns the size of a table within this In-Memory-Version
    pHeader if it is present - If Not present, read-in from the orginal font
    header - we need this because 'loca' won't be in pHeader for CID/42, but
    we need its size!.

--*/

{
    TableDirectoryStruct *pTableDirectory = (TableDirectoryStruct*)pHeader;
    TableEntryStruct     *pTableEntry     = (TableEntryStruct*)((char*)pTableDirectory
                                                + sizeof(TableDirectoryStruct));
    T42FontStruct        *pFont           = (T42FontStruct*)pUFObj->pAFont->hFont;
    unsigned short       i;

    for (i = 0; i < MOTOROLAINT(pTableDirectory->numTables); i++)
    {
        if (pTableEntry->tag == tableName)
            break;
        else
            pTableEntry = (TableEntryStruct *)((char*)pTableEntry + sizeof(TableEntryStruct));
    }

    //
    // 'loca' table can be 0 length in 'sfnts': just get it from the font.
    // Bug 229911 ang 9/12/97
    //
    if ((i < MOTOROLAINT(pTableDirectory->numTables))
        && ((unsigned long) MOTOROLALONG(pTableEntry->length) > 0))
    {
        return ((unsigned long) MOTOROLALONG(pTableEntry->length));
    }
    else
    {
        //
        // We don't have this table in pHeader, find out the size from orignal
        // font file.
        //
        return GETTTFONTDATA(pUFObj, tableName,
                                0, 0, 0L,
                                pFont->info.fData.fontIndex);  /* size of the table */
    }
}


unsigned long
GetGlyphTableSize(
    UFOStruct     *pUFObj
    )
{
    T42FontStruct  *pFont;

    pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    return ( GetTableSize( pUFObj, pFont->pHeader, GLYF_TABLE ) );
}


unsigned long
GetTableDirectory(
    UFOStruct            *pUFObj,
    TableDirectoryStruct *pTableDir
    )
{
    unsigned long  size   = sizeof(TableDirectoryStruct);
    T42FontStruct  *pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    if (pTableDir == 0)
        return (size);  /* Find out the size only. */

    /* TTCHeader or TableDirectoryStruct starts from 0 byte of the font file. */
    size = GETTTFONTDATA(pUFObj, 0, 0, (void *) pTableDir,
                            (unsigned long) sizeof(TableDirectoryStruct), 0);

    /* Check if this is a TTC file - only uses first 4 bytes of pTableDIR! */
    if ( BIsTTCFont(*((unsigned long*) ((char *)pTableDir)) ) )
    {
        /* Parse TTCHeader to get correct offsetToTableDir from fontIndex. */
        size = pFont->info.fData.offsetToTableDir
             = GetOffsetToTableDirInTTC(pUFObj, pFont->info.fData.fontIndex);

        if (size > 0)
        {
            // Now get the correct TableDirectory from the TTC file.
            size = GETTTFONTDATA(pUFObj, 0, pFont->info.fData.offsetToTableDir,
                                    (void *) pTableDir,
                                    (unsigned long) sizeof(TableDirectoryStruct),
                                    pFont->info.fData.fontIndex);
        }
    }

    /* Do some basic check - better fail than crash: NumTables must be reasonable. */
    if ( (MOTOROLAINT(pTableDir->numTables) < 3)
            || (MOTOROLAINT(pTableDir->numTables) > 50) )
    {
        return 0;
    }

    return (size);
}


unsigned long
GetTableEntry(
    UFOStruct            *pUFObj,
    TableEntryStruct     *pTableEntry,
    TableDirectoryStruct *pTableDir
    )
{
    unsigned long size;
    T42FontStruct  *pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    if ( pTableDir == 0 )
        return (0);  /* We need the TableDirectoryStruct to get the entry. */

    size = MOTOROLAINT(pTableDir->numTables) * sizeof(TableEntryStruct);

    if ( pTableEntry == 0 )
        return (size);  /* Find out the size. */

    /* TableEntryStruct starts right after the TableDirectory. */
    size = GETTTFONTDATA(pUFObj, 0,
                            pFont->info.fData.offsetToTableDir + sizeof(TableDirectoryStruct),
                            (void *) pTableEntry, size, pFont->info.fData.fontIndex);

    return (size);
}


unsigned long
GetFontHeaderSize(
    UFOStruct     *pUFObj
    )
{
    TableDirectoryStruct  tableDir;
    unsigned long size;

    /* Need to fill in tableDir for the following line of code (GetTableEntry()). */
    size = GetTableDirectory( pUFObj, &tableDir );

    if (size != 0)
    {
        size += GetTableEntry( pUFObj, 0, &tableDir );  /* Get size only. */
    }
    return (size);
}


UFLErrCode
GetFontHeader(
    UFOStruct     *pUFObj,
    unsigned char *pHeader
    )
{
    unsigned char*          tempHeader = pHeader;
    TableDirectoryStruct*   pTableDir;
    unsigned long           size;

    pTableDir = (TableDirectoryStruct*)tempHeader;
    size = GetTableDirectory( pUFObj, pTableDir );

    tempHeader += size;  /* Move past table directory. */
    size = GetTableEntry( pUFObj, (TableEntryStruct *)tempHeader, pTableDir );

    return kNoErr;
}


unsigned long
GetNumGlyphsInGlyphTable(
    UFOStruct *pUFO
    )
{
    T42FontStruct              *pFont = (T42FontStruct *) pUFO->pAFont->hFont;
    unsigned long              dwSize;
    short                      indexToLocFormat;
    unsigned long              numGlyphs, realNumGlyphs = 0;
    unsigned long              locaSize;
    unsigned long PTR_PREFIX   *pLoca = NULL;
    unsigned short PTR_PREFIX  *pShortLoca = NULL;
    unsigned long PTR_PREFIX   *pLongLoca = NULL;
    unsigned long              i;
    Type42HeaderStruct         headTable;

    // Get numGlyphs - 4th and 5th byte in "maxp" table - see MaxPTableStruct.
    numGlyphs = GetNumGlyphs(pUFO);

    if (numGlyphs == 0)
    {
        return 0; // We don't understand this format.
    }

    //
    // Get indexToLocFormat - look at bytes 51 and 52 in "head" table - see
    // Type42HeaderStruct hard code offset 50  here because
    // sizeof(Type42HeaderStruct) is 56 - should be 54.
    //
    dwSize = GETTTFONTDATA(pUFO, *(unsigned long *)"head",
                                0, (void *)0, 0, pUFO->pFData->fontIndex);

    if ((dwSize == 0) || (dwSize == 0xFFFFFFFFL))
    {
        return 0; // No "head" !!! - should never happen.
    }

    dwSize = GETTTFONTDATA(pUFO, *(unsigned long *)"head",
                                0, (void *)&headTable, dwSize, pUFO->pFData->fontIndex);

    if ((dwSize == 0) || (dwSize == 0xFFFFFFFFL))
        return ( 0 );
    else
        indexToLocFormat = MOTOROLAINT(headTable.indexToLocFormat);

    // Now allocate a buffer to hold "loca" table.
    locaSize = (numGlyphs + 1) * (indexToLocFormat ? 4 : 2);

    pLoca = UFLNewPtr(pUFO->pMem, locaSize);

    if (pLoca == NULL)
    {
        dwSize = 0;
    }
    else
    {
        dwSize = GETTTFONTDATA(pUFO, *(unsigned long *)"loca",
                                0, (void *) pLoca, locaSize, pUFO->pFData->fontIndex);
    }

    if (pLoca && (dwSize != 0) && (dwSize != 0xFFFFFFFFL))
    {
        // Assume good until find otherwise.
        realNumGlyphs = 0;

        if (indexToLocFormat)
        {
            unsigned long dwLoca, dwLocaNext;
            pLongLoca = (unsigned long PTR_PREFIX *) pLoca;

            for (i = 0; i < numGlyphs; i++)
            {
                dwLoca     = MOTOROLALONG(pLongLoca[i]);
                dwLocaNext = MOTOROLALONG(pLongLoca[i+1]);

                // Check for 0 and duplicate.
                if ((dwLoca != 0) && (dwLoca != dwLocaNext))
                {
                    realNumGlyphs++;
                }
            }
        }
        else
        {
            unsigned short wLoca, wLocaNext;
            pShortLoca = (unsigned short PTR_PREFIX *) pLoca;

            for (i = 0; i < numGlyphs; i++)
            {
                wLoca     = MOTOROLAINT(pShortLoca[i]);
                wLocaNext = MOTOROLAINT(pShortLoca[i+1]);

                // Check for 0 and duplicate.
                if ((wLoca != 0) && (wLoca != wLocaNext))
                {
                    realNumGlyphs++;
                }
            }
        }
   }

   if (pLoca)
   {
        UFLDeletePtr(pUFO->pMem, pLoca);
   }

   return(realNumGlyphs);
}


void
GetAverageGlyphSize(
    UFOStruct     *pUFObj
    )
{
    unsigned long  glyfTableSize, cGlyphs;
    T42FontStruct  *pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    glyfTableSize = GetGlyphTableSize( pUFObj );

    if (UFO_NUM_GLYPHS(pUFObj) == 0 )
        pFont->info.fData.cNumGlyphs = GetNumGlyphs( pUFObj );

    cGlyphs = GetNumGlyphsInGlyphTable(pUFObj);

    if ((UFO_NUM_GLYPHS(pUFObj) != 0 ) && (cGlyphs != 0))
        pFont->averageGlyphSize = glyfTableSize / cGlyphs;
    else
        pFont->averageGlyphSize = 0;
}

#pragma optimize("", off)

unsigned long
GenerateMinimalSfnt(
    UFOStruct*    pUFObj,
    char**        requiredTables,
    UFLBool       bFullFont
    )
{
    unsigned long           tablesPresent[MINIMALNUMBERTABLES];
    UFLBool                 hasloca;

    T42FontStruct*          pFont;
    TableDirectoryStruct*   pTableDir;
    TableEntryStruct        *pTableEntry, *pEntry;
    unsigned char huge*     pCurrentMinSfnt;

    unsigned short          currentTable, numberOfTables, numberOfRealTables;
    unsigned long           size;

    TableEntryStruct*       pGlyphTableEntry;
    unsigned char*          glyfData;

    TableEntryStruct        tableEntry;
    unsigned long           tableSize;

    unsigned long           bytesRemaining;
    unsigned short          i, j;


    //
    // Bug fix 229911: ang 9/12/97
    // Check if RequiredTables has 'loca'. If not, remember to add 0-length one
    // as the last entry.
    //
    hasloca = 0;

    for (i = 0; i < MINIMALNUMBERTABLES; i++)
    {
        if (UFLstrcmp(requiredTables[i],  "loca") == 0)
        {
            hasloca = 1;
        }
        tablesPresent[i] = (unsigned long)0xFFFFFFFF;
    }

    //
    // Set up the primary pointers.
    //
    pFont           = (T42FontStruct*)pUFObj->pAFont->hFont;
    pTableDir       = (TableDirectoryStruct*)pFont->pHeader;
    pTableEntry     = (TableEntryStruct*)((char*)(pFont->pHeader) + sizeof(TableDirectoryStruct));
    pCurrentMinSfnt = (unsigned char huge*)pFont->pMinSfnt;

    //
    // Determine how many tables are actually present in pHeader (not in the
    // original TTF!).
    //
    numberOfTables = 0;

    for (i = 0; i < MINIMALNUMBERTABLES; i++)
    {
        if ( GetTableSize(pUFObj, pFont->pHeader, *(unsigned long*)(requiredTables[i])))
        {
            tablesPresent[numberOfTables] = *(unsigned long*)requiredTables[i];
            ++numberOfTables;
        }
    }

    //
    // Add extra entry if necessary.
    //
    if (!bFullFont)
        numberOfTables += 1;  // for 'gdir' table entry as the T42 indication

    if (!hasloca)
        numberOfTables += 1;  // for 0-length 'loca' table entry

    //
    // size will have the required size for the minimum 'sfnts' at the end.
    //
    size = sizeof(TableDirectoryStruct) + sizeof(TableEntryStruct) * numberOfTables;

    //
    // Initialize the table directory.
    //
    if (pFont->pMinSfnt)
    {
        TableDirectoryStruct    tableDir;
        unsigned long           dwVersion = 1;

        tableDir.version       = MOTOROLAINT(dwVersion);
        tableDir.numTables     =
        tableDir.searchRange   =
        tableDir.entrySelector =
        tableDir.rangeshift    =
        tableDir.numTables     = MOTOROLAINT(numberOfTables);

        UFLmemcpy((const UFLMemObj*)pUFObj->pMem,
                    pCurrentMinSfnt,
                    &tableDir,
                    sizeof(TableDirectoryStruct));

        pCurrentMinSfnt += sizeof(TableDirectoryStruct);
    }

    //
    // Initialize the table entries. Initialization of 'glyf' table entry will
    // be done later in order to make sure to put it at the end of the minimum
    // 'sfnts'.
    //
    // Note that we do linear search to find a table directory entry. This is
    // becasue some TT fonts don't have sorted table directory so that we can't
    // do binary search. (This is a fix for #310998.)
    //
    glyfData           = nil;
    pGlyphTableEntry   = nil;
    numberOfRealTables = MOTOROLAINT(pTableDir->numTables);

    for (currentTable = 0; currentTable < numberOfTables; currentTable++)
    {
        pEntry = pTableEntry;

        for (j = 0; j < numberOfRealTables; j++)
        {
            if (tablesPresent[currentTable] == pEntry->tag)
            {
                if (pFont->pMinSfnt)
                {
                    if (pEntry->tag == GLYF_TABLE)
                    {
                        glyfData = pCurrentMinSfnt;
                    }
                    else
                    {
                        tableEntry.tag      = pEntry->tag;
                        tableEntry.checkSum = pEntry->checkSum;
                        tableEntry.offset   = MOTOROLALONG(size);
                        tableEntry.length   = pEntry->length;

                        UFLmemcpy((const UFLMemObj*)pUFObj->pMem,
                                    pCurrentMinSfnt,
                                    &tableEntry,
                                    sizeof(TableEntryStruct));
                    }

                    pCurrentMinSfnt += sizeof(TableEntryStruct);
                }

                if (pEntry->tag == GLYF_TABLE)
                {
                    pGlyphTableEntry = pEntry;
                }
                else
                {
                    tableSize  = MOTOROLALONG(pEntry->length);
                    size      += BUMP4BYTE(tableSize);
                }

                break;
            }

            pEntry = (TableEntryStruct*)((char*)pEntry + sizeof(TableEntryStruct));
        }
    }

    //
    // Update 'glyf' table entry lastly.
    //
    if (glyfData && pGlyphTableEntry && pFont->pMinSfnt)
    {
        tableEntry.tag      = pGlyphTableEntry->tag;
        tableEntry.checkSum = pGlyphTableEntry->checkSum;
        tableEntry.offset   = MOTOROLALONG(size);
        tableEntry.length   = pGlyphTableEntry->length;

        UFLmemcpy((const UFLMemObj*)pUFObj->pMem,
                    glyfData,
                    &tableEntry,
                    sizeof(TableEntryStruct));
    }

    if (pGlyphTableEntry && bFullFont)
    {
        tableSize = MOTOROLALONG(pGlyphTableEntry->length);
        size += BUMP4BYTE(tableSize);
    }

    //
    // Special 'gdir' and 'loca' table entry handling.
    //
    if (!bFullFont && pFont->pMinSfnt)
    {
        tableEntry.tag      = *(unsigned long*)"gdir";
        tableEntry.checkSum = 0;
        tableEntry.offset   = 0;
        tableEntry.length   = 0;

        UFLmemcpy((const UFLMemObj*)pUFObj->pMem,
                    pCurrentMinSfnt,
                    &tableEntry,
                    (long)sizeof(TableEntryStruct));

        pCurrentMinSfnt += sizeof(TableEntryStruct);
    }

    if (!hasloca && pFont->pMinSfnt)
    {
        tableEntry.tag      = LOCA_TABLE;
        tableEntry.checkSum = 0;
        tableEntry.offset   = 0;
        tableEntry.length   = 0;

        UFLmemcpy((const UFLMemObj*)pUFObj->pMem,
                    pCurrentMinSfnt,
                    &tableEntry,
                    (long)sizeof(TableEntryStruct));

        pCurrentMinSfnt += sizeof(TableEntryStruct);
    }

    //
    // Copy the required tables after the entries.
    //
    if (pFont->pMinSfnt)
    {
        pTableEntry = (TableEntryStruct*)((char*)pFont->pMinSfnt + sizeof(TableDirectoryStruct));

        if (!bFullFont)
            --numberOfTables; // Because there is no 'gdir' table.

        if (!hasloca)
            --numberOfTables; // Because we treat 'loca' table as 0-length.

        for (i = 0; i < (unsigned short)numberOfTables; i++)
        {
            if (tablesPresent[i] != GLYF_TABLE)
            {
                bytesRemaining = MOTOROLALONG(pTableEntry->length);
                bytesRemaining = BUMP4BYTE(bytesRemaining);

                GetFontTable(pUFObj, tablesPresent[i], pCurrentMinSfnt);

                pCurrentMinSfnt += bytesRemaining;
            }

            pTableEntry = (TableEntryStruct*)((char*)pTableEntry + sizeof(TableEntryStruct));
        }

        //
        // Copy 'glyf' table lastly.
        //
        if (bFullFont)
        {
            bytesRemaining = MOTOROLALONG(pGlyphTableEntry->length);
            bytesRemaining = BUMP4BYTE(bytesRemaining);

            GetFontTable(pUFObj, GLYF_TABLE, pCurrentMinSfnt);
        }
    }

    return size;
}

#pragma optimize("", on)

UFLErrCode
GetMinSfnt(
    UFOStruct     *pUFObj,
    UFLBool       bFullFont
    )
{
    unsigned long   headerSize, sfntSize;
    char            **requiredTables = RequiredTables_default;
    UFLErrCode      retVal = kNoErr;
    T42FontStruct   *pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    //
    // IF CID/42, then we are sure we can omit the huge "loca" table - because
    // Send-TT-as-CID/Type42 is only supported on 2015 or above printers.
    //
    if ( IS_TYPE42CID(pUFObj->lDownloadFormat) )
    {
        requiredTables = RequiredTables_2015;
    }

    if ( pFont->pMinSfnt == 0 )
    {
        /* Get the size of the portion of the Type font we need. */
        headerSize = GetFontHeaderSize( pUFObj );
        if (headerSize == 0)
            return (kErrOutOfMemory); /* Some thing wrong when getting header. */

        if ((pFont->pHeader = (unsigned char *)UFLNewPtr(pUFObj->pMem, headerSize)) == nil)
            return (kErrOutOfMemory);

        GetFontHeader( pUFObj, pFont->pHeader );

        /* Calculate minimal /sfnts size for Incr or full download. */
        sfntSize = GenerateMinimalSfnt( pUFObj, requiredTables, bFullFont );

        if ((pFont->pMinSfnt = (unsigned char *)UFLNewPtr(pUFObj->pMem, sfntSize)) == nil)
        {
            UFLDeletePtr(pUFObj->pMem, pFont->pHeader);
            pFont->pHeader = nil;
            return ( kErrOutOfMemory );
        }

        /* Creates our sfnt - minSfnt. We then work on this minSfnt. */
        GenerateMinimalSfnt( pUFObj, requiredTables, bFullFont );

        if ( retVal == kNoErr )
        {
            pFont->minSfntSize = sfntSize;
        }
    }

    return retVal;
}


unsigned long
GetNextLowestOffset(
    TableEntryStruct *pTableEntry,
    TableEntryStruct **ppCurrentTable,
    short            numTables,
    unsigned long    leastOffset
    )
{
    short i;
    unsigned long lowestFound = 0xFFFFFFFFL;

    for ( i=0; i < numTables; ++i )
    {
        if (((unsigned long)MOTOROLALONG(pTableEntry->offset) > leastOffset)
            && ((unsigned long)MOTOROLALONG(pTableEntry->offset) < lowestFound))
        {
            lowestFound = (unsigned long)MOTOROLALONG(pTableEntry->offset);
            *ppCurrentTable = pTableEntry;
        }

        pTableEntry = (TableEntryStruct *)((char*)pTableEntry + sizeof(TableEntryStruct));
    }

    return (lowestFound);
}


unsigned long
GetBestGlyfBreak(
    UFOStruct     *pUFObj,
    unsigned char *sfnt,
    unsigned long upperLimit,
    UFLBool       longGlyfs
    )
{
    unsigned long  retVal;
    unsigned long  dwGlyphStart ;
    unsigned long  dwTableSize;
    unsigned short i;
    unsigned short numGlyphs;

    dwGlyphStart = retVal = 0xFFFFFFFFL;

    /* Get the size of loca table. */
    dwTableSize = GetTableSize (pUFObj, sfnt, LOCA_TABLE);

    if ( 0 == dwTableSize )
        return retVal;


    if (longGlyfs)
    {
        unsigned long PTR_PREFIX *locationTable = (unsigned long PTR_PREFIX *) GetSfntTable( sfnt, LOCA_TABLE );

        if ( locationTable )
        {
            numGlyphs = (unsigned short) ( dwTableSize / sizeof(unsigned long) );

            for ( i = 0; i < numGlyphs; i++ )
            {
                if (  MOTOROLALONG(*locationTable) > upperLimit )
                {
                    retVal = dwGlyphStart ;
                    break;
                }
                else
                {
                    if ((MOTOROLALONG(*locationTable) & 0x03L) ==  0)
                    {
                        /* Remember "good" guy. */
                        dwGlyphStart = MOTOROLALONG(*locationTable);
                    }
                    locationTable++;
                }
            }
        }
    }
    else
    {
        short PTR_PREFIX* locationTable = (short PTR_PREFIX *)GetSfntTable( sfnt, LOCA_TABLE );

        if ( locationTable )
        {
            numGlyphs = (unsigned short) (dwTableSize/sizeof(unsigned short)) ;
            upperLimit /= 2;

            for ( i = 0; i  < numGlyphs; i++ )
            {
                if ((unsigned long) (MOTOROLAINT(*locationTable)) >= upperLimit )
                {
                    retVal = dwGlyphStart ;
                    break ;
                }
                else
                {
                    if ((MOTOROLAINT(*locationTable) & 0x01) == 0)
                    {
                        /* Remember "good" guy. */
                        dwGlyphStart = (unsigned long)(2L * (unsigned short)MOTOROLAINT(*locationTable));
                    }
                    locationTable++;
                }
            }
        }
    }

    return( retVal );
}


UFLErrCode
CalculateStringLength(
    UFOStruct     *pUFObj,
    T42FontStruct *pFont,
    unsigned long  tableSize
    )
{
    TableEntryStruct      *pTableEntry = (TableEntryStruct *)(pFont->pMinSfnt + sizeof(TableDirectoryStruct));
    TableEntryStruct      *pCurrentTable;
    TableDirectoryStruct  *pTableDir = (TableDirectoryStruct *)pFont->pMinSfnt;

    unsigned long dwNewPoint;         /* Offset from the beginning of glyph table */
    unsigned long nextOffset = 0L;    /* Offset for the current point             */
    unsigned long prevOffset = 0L;    /* Offset for the previous breakpoint       */

    unsigned long glyphTableStart = 0L;
    unsigned long *stringLength = pFont->pStringLength;
    unsigned long *maxStringLength = stringLength + tableSize;

    if ( pFont->minSfntSize >= THIRTYTWOK )
    {
        do
        {
            nextOffset =
                GetNextLowestOffset(pTableEntry,
                                        &pCurrentTable,
                                        (short)MOTOROLAINT(pTableDir->numTables),
                                        nextOffset);

            if ( nextOffset == (unsigned long)0xFFFFFFFF )
            {
                /* No more data. */
                break ;
            }

            if ((nextOffset + MOTOROLALONG(pCurrentTable->length) - prevOffset) > THIRTYTWOK)
            {
                /* Total size is more that 64K. */

                if (pCurrentTable->tag == GLYF_TABLE)
                {
                    // BUGBUG - to improve perfomance, don't need this for Incr downloading.
                    /*
                     * If we stopped just on "glyf" table, get the break points
                     * to be inside the table but between two glyphs.
                     */
                    glyphTableStart = nextOffset ;  /* Next segment starts here. */

                    dwNewPoint = 0L;
                    while (1)
                    {
                        dwNewPoint = GetBestGlyfBreak( pUFObj, pFont->pMinSfnt,
                                                        prevOffset + THIRTYTWOK - glyphTableStart,
                                                        (UFLBool)(pFont->headTable.indexToLocFormat ? 1 : 0));

                        if ( dwNewPoint == 0xFFFFFFFF )
                        {
                            /* No next point. */
                            break;
                        }
                        else
                        {
                            nextOffset = glyphTableStart + dwNewPoint;
                            prevOffset = nextOffset;    /* New segment starts here. */
                            *stringLength = nextOffset;
                            stringLength++;             /* Next breakpoint goes there. */
                            if (stringLength >= maxStringLength)     // 3/22/1999
                                return kErrOutOfBoundary;
                        }
                    }
                }
                else
                {
                    /* Save the break point at Table Boundry. */
                    prevOffset = nextOffset;    /* New segment starts here. */
                    *stringLength = nextOffset; /* Save this breakpoint. */
                    stringLength++;             /* Next breakpoint goes there. */
                    if (stringLength >= maxStringLength)     // 3/22/1999
                        return kErrOutOfBoundary;

                    /*
                     * Break the single table at 64K boundry -- regardless
                     * what TT Spec says.
                     */
                    /* Tried on a 2016.102 printer. It works. 10-11-1995 */
                    glyphTableStart = nextOffset;  /* Next segment starts here */

                    dwNewPoint = 0L;
                    while (1)
                    {
                        /*
                         * We use 64K here becasue we only break a table when
                         * ABSOLUTELY necessary >64K.
                         */
                        dwNewPoint += SIXTYFOURK;

                        if (dwNewPoint > MOTOROLALONG(pCurrentTable->length))
                        {
                            /* No next point. */
                            break;
                        }
                        else
                        {
                            nextOffset = glyphTableStart + dwNewPoint ;
                            prevOffset = nextOffset;    /* New segment starts here. */
                            *stringLength = nextOffset;
                            stringLength++;             /* Next breakpoint goes there. */
                            if (stringLength >= maxStringLength)     // 3/22/1999
                                return kErrOutOfBoundary;

                        }
                    }
                }
            }
        } while (1);
    }

    *stringLength = pFont->minSfntSize + 1; /* Always close the breakpoints list. */
    stringLength++;
    if (stringLength >= maxStringLength)     // 3/22/1999
        return kErrOutOfBoundary;

    *stringLength = 0; /* Always close the breakpoints list with 0!!! */

    return kNoErr;       // 3/22/1999
}


UFLErrCode
FillInHeadTable(
    UFOStruct     *pUFObj
    )
{
    T42FontStruct  *pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    if ( GetFontTable(pUFObj, HEAD_TABLE, (unsigned char*)&pFont->headTable) == 0 )
        return (kErrBadTable);
//  else
//      return(kNoErr);

    // WCC 5/14/98 convert all motorola bytes.
    pFont->headTable.tableVersionNumber = MOTOROLALONG(pFont->headTable.tableVersionNumber);
    pFont->headTable.fontRevision       = MOTOROLALONG(pFont->headTable.fontRevision);
    pFont->headTable.checkSumAdjustment = MOTOROLALONG(pFont->headTable.checkSumAdjustment);
    pFont->headTable.magicNumber        = MOTOROLALONG(pFont->headTable.magicNumber);
    pFont->headTable.flags              = MOTOROLAINT(pFont->headTable.flags);
    pFont->headTable.unitsPerEm         = MOTOROLAINT(pFont->headTable.unitsPerEm);

    // Need to convert timeCreated and timeModified.
    pFont->headTable.xMin = MOTOROLAINT(pFont->headTable.xMin);
    pFont->headTable.yMin = MOTOROLAINT(pFont->headTable.yMin);
    pFont->headTable.xMax = MOTOROLAINT(pFont->headTable.xMax);
    pFont->headTable.yMax = MOTOROLAINT(pFont->headTable.yMax);

    pFont->headTable.macStyle          = MOTOROLAINT(pFont->headTable.macStyle);
    pFont->headTable.lowestRecPPEM     = MOTOROLAINT(pFont->headTable.lowestRecPPEM);
    pFont->headTable.fontDirectionHint = MOTOROLAINT(pFont->headTable.fontDirectionHint);
    pFont->headTable.indexToLocFormat  = MOTOROLAINT(pFont->headTable.indexToLocFormat);
    pFont->headTable.glyfDataFormat    = MOTOROLAINT(pFont->headTable.glyfDataFormat);

    return(kNoErr);
}


short
PSSendSfntsBinary(
    UFOStruct   *pUFObj
    )
{
    unsigned long   dwLen=0;
    short           i = 0;
    short           nSubStr = 1;
    UFLHANDLE       stream;
    char huge       *glyphs;
    unsigned long   minSfntSize;
    unsigned long   *breakHere;
    T42FontStruct   *pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    glyphs = (char huge *)pFont->pMinSfnt;
    minSfntSize = pFont->minSfntSize;
    breakHere = pFont->pStringLength;
    dwLen = *breakHere;

    stream = pUFObj->pUFL->hOut;
    if (dwLen > minSfntSize)
    {
        /* There's only 1 string. */
        dwLen -= 1;

        StrmPutInt( stream, dwLen+1 );
        StrmPutString( stream, RDString );

        StrmPutBytes( stream, glyphs, (UFLsize_t) dwLen, 0 );

        StrmPutString( stream, "0" );
        return nSubStr;  /* It is 1 -- only one string. */
    }

    StrmPutInt( stream, dwLen+1 );
    StrmPutString(stream, RDString);
    StrmPutBytes(stream, glyphs, (UFLsize_t) dwLen, 0);
    StrmPutString(stream, "0");
    glyphs = glyphs+dwLen;

    while (breakHere[i] <= minSfntSize)
    {
        dwLen = breakHere[i+1] - breakHere[i];
        if (breakHere[i+1] > minSfntSize)
            dwLen -= 1;

        StrmPutInt(stream, dwLen+1);
        StrmPutString(stream, RDString);
        StrmPutBytes(stream, glyphs, (UFLsize_t) dwLen, 0);
        StrmPutStringEOL(stream, "0");
        glyphs = glyphs+dwLen;

        i++;
        nSubStr++;
    }

    return (nSubStr);
}


short
PSSendSfntsAsciiHex(
    UFOStruct   *pUFObj
    )
{
    unsigned long dwBreak ;
    unsigned long i;
    short         bytesSent = 1;
    short         nSubStr = 1;
    UFLHANDLE     stream;
    char huge     *glyphs;
    unsigned long minSfntSize;
    unsigned long *breakHere;
    T42FontStruct *pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    glyphs = (char huge *)pFont->pMinSfnt;
    minSfntSize = pFont->minSfntSize;
    breakHere = pFont->pStringLength;

    stream = pUFObj->pUFL->hOut;
    StrmPutString(stream, "<");

    dwBreak = *breakHere - 1;

    for ( i = 0; i < minSfntSize; i++ )
    {
        StrmPutAsciiHex(stream, glyphs, 1);
        ++glyphs;
        ++bytesSent;

        if (i == dwBreak)
        {
            if (dwBreak != minSfntSize)
            {
                StrmPutStringEOL(stream, "00>");

                bytesSent = 1;
                StrmPutString(stream, "<");
            }
            dwBreak = *(++breakHere) - 1 ;
            nSubStr++;
        }

        /* We already have a control (stream->Out->AddEOL ) when to add a EOL.
            if (!(bytesSent % 40))
            {
                StrmPutStringEOL(stream, nilStr);
                bytesSent = 1;
            }
        */
    }
    StrmPutString(stream, "00>");

    return nSubStr;
}


UFLErrCode
CalcBestGlyfTableBreaks(
    UFOStruct     *pUFObj,
    unsigned long upperLimit,
    unsigned long tableSize
    )
{
    unsigned long  *stringLength;
    unsigned short i;                   /* loca table entries counter         */
    unsigned short numGlyphs;
    unsigned long  nextOffset = 0L;     /* Offset for the current point       */
    unsigned long  prevOffset = 0L;     /* Offset for the previous breakpoint */
    unsigned long  glyfTableSize;
    unsigned long  locaTableSize;
    T42FontStruct  *pFont = (T42FontStruct *) pUFObj->pAFont->hFont;
    unsigned long  *maxStringLength;

    stringLength = pFont->pStringLength;
    maxStringLength = stringLength + tableSize;

    nextOffset = 0xFFFFFFFFL ;

    *stringLength = 0L;     /* Start with offset 0. */
    stringLength++;

    glyfTableSize = GetTableSize( pUFObj, pFont->pHeader, GLYF_TABLE );
    locaTableSize = GetTableSize( pUFObj, pFont->pHeader, LOCA_TABLE );

    if (glyfTableSize > upperLimit)
    {
        if (pFont->headTable.indexToLocFormat)
        {   /* long offsets */
            unsigned long PTR_PREFIX *locationTable = (unsigned long PTR_PREFIX *)pFont->pLocaTable;
            unsigned long dwTmp;
            numGlyphs = (unsigned short)(locaTableSize / sizeof(unsigned long));

            for (i = 0; i < numGlyphs; i++)
            {
                dwTmp = MOTOROLALONG(*locationTable);

                if ( (dwTmp > (prevOffset + upperLimit)) && (nextOffset != prevOffset) )
                {
                    *stringLength = nextOffset ;
                    stringLength++;
                    if (stringLength >= maxStringLength)
                        return kErrOutOfBoundary;
                    prevOffset = nextOffset;
                }
                else
                {
                    if ( ( dwTmp & 0x03L) ==  0 )
                    {
                        nextOffset = dwTmp;
                    }
                    locationTable++;
                }
            }
        }
        else
        {
            unsigned short PTR_PREFIX *locationTable = (unsigned short PTR_PREFIX *)pFont->pLocaTable;
            unsigned short iTmp;
            numGlyphs = (unsigned short)(locaTableSize / sizeof(unsigned short));

            for (i = 0; i < numGlyphs; i++)
            {
                iTmp = MOTOROLAINT(*locationTable);

                if ( ((2L * (unsigned long)iTmp) > (prevOffset + upperLimit))
                      && (nextOffset != prevOffset) )
                {
                    *stringLength = nextOffset ;
                    stringLength++;
                    if (stringLength >= maxStringLength)
                        return kErrOutOfBoundary;
                    prevOffset = nextOffset;
                }
                else
                {
                    if ( (iTmp & 0x01) == 0 )
                    {
                        nextOffset = 2L * (unsigned long)iTmp;
                    }
                    locationTable++;
                }
            }
        }
    }

    *stringLength = glyfTableSize; /* Close the breakpoints list. */
    stringLength++;
    if (stringLength >= maxStringLength)
        return kErrOutOfBoundary;

    *stringLength = 0; /* Always close the breakpoints list with 0!!! */

    return kNoErr;
}


UFLErrCode
GenerateGlyphStorageExt(
    UFOStruct     *pUFObj,
    unsigned long tableSize
    )
{
    unsigned long   upperLimit = SFNT_STRINGSIZE; /* 0x3FFE */
    unsigned long   *stringLength;
    unsigned long   stringSize;
    short           i = 0;
    UFLHANDLE       stream;
    UFLErrCode      retVal;
    char            nilStr[] = "\0\0";  // An empty/nil string
    T42FontStruct   *pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    retVal = CalcBestGlyfTableBreaks(pUFObj, upperLimit, tableSize);
    if (retVal != kNoErr)
        return retVal;

    stringLength = pFont->pStringLength;
    stream = pUFObj->pUFL->hOut;

    /* Send down the array of Glyph strings. */

    retVal = StrmPutStringEOL(stream, nilStr);
    if ( kNoErr == retVal )
        retVal = StrmPutString(stream, "[");

    i = 1;
    while ( retVal == kNoErr && stringLength[i] != 0)
    {
#if 0
        //
        // For Chinese Font SongTi, the very last stringLength is incorrect:
        // glyfSize = 7068416, but the last glyf breaks at 6890292.
        // That means the very last glyf is 178124 - this is impossible.
        // Either GDI is not returning correct number or our function
        // GetTableSize() is wrong. Untill we fix our problem or get a better
        // build of Win95, this is a temp fix. ?????. 10-12-95
        //
        if (stringLength[i] > stringLength[i-1] + 0xFFFF)
            stringSize = (unsigned long)0x3FFF;  // 16K. This is a bogus entry anyway.
        else
#endif
        stringSize = stringLength[i] - stringLength[i-1];

        if ( kNoErr == retVal )
            retVal = StrmPutInt(stream, stringSize + 1);

        if ( retVal == kNoErr )
        {
            if (i % 13 == 0)
            retVal = StrmPutStringEOL(stream, nilStr);
            else
            retVal = StrmPutString(stream, " ");
        }
        i++;
    }

    if ( kNoErr == retVal )
        retVal = StrmPutStringEOL(stream, "] AllocGlyphStorage");

    return retVal;

}


unsigned short
GetTableDirectoryOffset(
    T42FontStruct *pFont,
    unsigned long tableName
    )
{
    TableDirectoryStruct* tableDirectory = (TableDirectoryStruct *)pFont->pMinSfnt;
    TableEntryStruct*     tableEntry     = (TableEntryStruct *)((char *)tableDirectory
                                                + sizeof(TableDirectoryStruct));
    unsigned short offset = sizeof(TableDirectoryStruct);
    unsigned short i = 0;

    while (i < MOTOROLAINT(tableDirectory->numTables))
    {
        if (tableEntry->tag == tableName)
        {
            break;
        }
        else
        {
            tableEntry = (TableEntryStruct *)((char *)tableEntry + sizeof(TableEntryStruct));
            offset += sizeof(TableEntryStruct);
            i++;
        }
    }
    return (offset);
}


/* ***** Sorting and Searching functions for an array of longs ***** */

// Function to compare longs
static short
CompareLong(
    const long x,
    const long y
    )
{
    if (x == y)
        return 0;
    else if (x < y)
        return -1;
    else
        return 1;
}

// Function to swap pointers to longs
static void
SwapLong(
    long *a,
    long *b
    )
{
    long tmp;
    if ( a != b )
    {
        tmp = *a;
        *a = *b;
        *b = tmp;
    }
}


// This is a tailored version of shortsort. Works only for an array of longs.
static void
ShortsortLong(
    char *lo,
    char *hi,
    unsigned short width,
    short (*comp)(const long, const long)
    )
{
    char *p, *max;
    while (hi > lo)
    {
        max = lo;
        for (p = lo + width; p <= hi; p += width)
        {
            if (comp(*(long*)p, *(long*)max) > 0)
            {
                max = p;
            }
        }
        SwapLong((long *)max, (long *)hi);
        hi -= width;
    }
}


// Function to Sort the array between lo and hi (inclusive)
void
QsortLong(
    char*           base,
    unsigned short  num,
    unsigned short  width,
    short (*comp)(const long, const long)
    )
{
    char *lo, *hi;          /* ends of sub-array currently sorting        */
    char *mid;              /* points to middle of subarray               */
    char *loguy, *higuy;    /* traveling pointers for partition step      */
    unsigned short size;    /* size of the sub-array                      */
    short stkptr;           /* stack for saving sub-array to be processed */
    char *lostk[16], *histk[16];

    /* Testing shows that this is a good value.   */
    const unsigned short CUTOFF0 = 8;

    /*
     * Note: the number of stack entries required is no more than
     * 1 + log2(size), so 16 is sufficient for any array with <=64K elems.
     */
    if (num < 2 || width == 0)
        return;  /* Nothing to do. */

    stkptr = 0;  /* Initialize stack. */

    lo = (char *)base;
    hi = (char *)base + width * (num-1);  /* Initialize limits. */

    /*
     * This entry point is for pseudo-recursion calling: setting lo and hi and
     * jumping to here is like recursion, but stkptr is prserved, locals aren't,
     * so we preserve stuff on the stack.
     */
sort_recurse:

    size = (unsigned short)((hi - lo) / width + 1); /* Number of el's to sort */

    if (size <= CUTOFF0)
    {
        ShortsortLong(lo, hi, width, comp);
    }
    else
    {
        mid = lo + (size / 2) * width;     /* Find middle element. */
        SwapLong((long *)mid, (long *)lo); /* Wwap it to beginning of array. */

        loguy = lo;
        higuy = hi + width;

        /*
         * Note that higuy decreases and loguy increases on every iteration,
         * so loop must terminate.
         */
        for (;;)
        {
            do
            {
                loguy += width;
            } while (loguy <= hi && comp(*(long *)loguy, *(long *)lo) <= 0);

            do
            {
                higuy -= width;
            } while (higuy > lo && comp(*(long *)higuy, *(long *)lo) >= 0);

            if (higuy < loguy)
                break;

            SwapLong((long *)loguy, (long *)higuy);
        }

        SwapLong((long *)lo, (long *)higuy); /* Put partition element in place. */

        if ( higuy - 1 - lo >= hi - loguy )
        {
            if (lo + width < higuy)
            {
                lostk[stkptr] = lo;
                histk[stkptr] = higuy - width;
                ++stkptr; /* Save big recursion for later. */
            }

            if (loguy < hi)
            {
                lo = loguy;
                goto sort_recurse; /* Do small recursion. */
            }
        }
        else
        {
            if (loguy < hi)
            {
                lostk[stkptr] = loguy;
                histk[stkptr] = hi;
                ++stkptr; /* Save big recursion for later. */
            }

            if (lo + width < higuy)
            {
                hi = higuy - width;
                goto sort_recurse; /* Do small recursion. */
            }
        }
    }

    /*
     * We have sorted the array, except for any pending sorts on the stack.
     * Check if there are any, and do them.
     */
    --stkptr;
    if (stkptr >= 0)
    {
        lo = lostk[stkptr];
        hi = histk[stkptr];
        goto sort_recurse; /* Pop subarray from stack. */
    }
    else
        return; /* All subarrays done. */
}


// This is a tailored version of the CRT bsearch().
void *
BsearchLong (
    const long     key,
    const char     *base,
    unsigned short num,
    unsigned short width,
    short (*compare)(const long, const long)
    )
{
    char *lo = (char *)base;
    char *hi = (char *)base + (num - 1) * width;
    char *mid;
    unsigned short half;
    short result;

    while (lo <= hi)
    {
        if (half = num / 2)
        {
            mid = lo + (num & 1 ? half : (half - 1)) * width;

            if (!(result = (*compare)(key, *(long *)mid)))
                return(mid);
            else if (result < 0)
            {
                hi = mid - width;
                num = num & 1 ? half : half-1;
            }
            else
            {
                lo = mid + width;
                num = half;
            }
        }
        else if (num)
            return((*compare)((long)key, *(long *)lo) ? nil : lo);
        else
            break;
    }

    return(nil);
}


UFLErrCode
DefaultGetRotatedGIDs(
    UFOStruct     *pUFObj,
    T42FontStruct *pFont,
    UFLFontProcs  *pFontProcs
    )
{
    short           i = 0, subTable;
    long            unicode, localcode, *pFoundGID;
    unsigned long   gi, offset;
    unsigned short  num;
    UFLErrCode      retVal = kNoErr;

    //
    // Don't forget to double the size. We expect extra GIDs coming from 'GSUB'
    // or 'mort' table.
    //
    pFont->pRotatedGlyphIDs = (long *)UFLNewPtr(pUFObj->pMem, (NUM_HALFWIDTHCHARS + 1) * sizeof(long) * 2);
    if ( !pFont->pRotatedGlyphIDs )
        return kErrOutOfMemory;

    //
    // To scan through TTF's "cmap" table to fingure out the glyph ids for all
    // characters in the range for romans and single byte chars.
    //
    i = 0;
    pFoundGID = pFont->pRotatedGlyphIDs;
    num = 0;  // Remember the number of GIDs.

    if (!pFontProcs->pfGetGlyphID)
        GetGlyphIDEx(pUFObj, 0, 0, &subTable, &offset, GGIEX_HINT_INIT);

    while ((gHalfWidthChars[i].startU != gHalfWidthChars[i].endU)
            && (gHalfWidthChars[i].startU != 0))
    {
        for (unicode = gHalfWidthChars[i].startU, localcode = gHalfWidthChars[i].startL;
             unicode <= gHalfWidthChars[i].endU;
             unicode++, localcode++)
        {
            if ( pFontProcs->pfGetGlyphID )
                gi = pFontProcs->pfGetGlyphID(pUFObj->hClientData,
                                                (unsigned short)unicode,
                                                (unsigned short)localcode);
            else
                gi = GetGlyphIDEx(pUFObj, unicode, localcode,
                                    &subTable, &offset, GGIEX_HINT_GET);

            if (gi > (unsigned long) UFO_NUM_GLYPHS(pUFObj))
                gi = 0;

            if (gi != 0)
            {
                *pFoundGID = (long) gi;
                pFoundGID++;
                num++;
            }
            else
            {
                //
                // We will have to treat all Half-width single characters as
                // "space" because we don't want to place a Double-Byte
                // /.notdef as rotated.
                //
            }
        }
        i++;
    }

    if (pFontProcs->pfGetRotatedGSUBs) // Fix #316070
    {
        // OK to trancate long to unsigned short.
        num += (unsigned short)pFontProcs->pfGetRotatedGSUBs(
                                                pUFObj->hClientData,
                                                pFont->pRotatedGlyphIDs,
                                                num);
    }

    pFont->numRotatedGlyphIDs = num;

    //
    // Now, sort the array so that we can search quicker later.
    //
    QsortLong((char*)(pFont->pRotatedGlyphIDs),
                pFont->numRotatedGlyphIDs,
                4,
                CompareLong);

    return retVal;
}


UFLErrCode
T42GetRotatedGIDs(
    UFOStruct     *pUFObj,
    T42FontStruct *pFont
    )
{
    UFLErrCode   retVal;
    UFLFontProcs *pFontProcs = (UFLFontProcs *)&(pUFObj->pUFL->fontProcs);

    pFont->numRotatedGlyphIDs = 0;

    // Assume this first in order to fall back to the default logic.
    retVal = kErrOSFunctionFailed;

    if (pFontProcs->pfGetRotatedGIDs)
    {
        long nGlyphs = pFontProcs->pfGetRotatedGIDs(pUFObj->hClientData, NULL, 0, nil);

        if (nGlyphs > 0)
        {
            pFont->pRotatedGlyphIDs = (long *)UFLNewPtr(pUFObj->pMem, (nGlyphs + 1) * sizeof (long));
            if (pFont->pRotatedGlyphIDs)
            {
                pFontProcs->pfGetRotatedGIDs(pUFObj->hClientData, pFont->pRotatedGlyphIDs, nGlyphs, nil);
                pFont->numRotatedGlyphIDs = (unsigned short)nGlyphs;
                retVal = kNoErr;
            }
            else
                retVal = kErrOutOfMemory;
        }
        else
            retVal = (nGlyphs == 0) ? kNoErr: kErrOSFunctionFailed;
    }

    if (retVal == kErrOSFunctionFailed)
    {
        // Default logic: scan TTF's cmap to get GIDs for CJK half-width chars.
        retVal = DefaultGetRotatedGIDs(pUFObj, pFont, pFontProcs);
    }

    return retVal;
}


UFLBool
IsDoubleByteGI(
    unsigned short  gi,
    long            *pGlyphIDs,
    short           length
    )
{
    void   *index;

    // Return True if gi is NOT in the pGlyphIDs - index==nil.
    index = BsearchLong ((long)gi,  (char *)pGlyphIDs, length, 4, CompareLong);

    if (index == nil)
        return (1);
    else
        return (0);
}


// ----------------- Begin code to support more than 32K glyphs --------------

/*****************************************************************************
*                            T42SendCMapWinCharSetFFFF_V
*
*   Make a vertical CMap based on known Rotated Glyph-indices (1 Byte chars).
*   Create a CMapType 1 CMap. Since this CMap is different for different font,
*   the CMapName is passed in by caller as lpNewCmap. The resulting CMap uses
*   2 or 4(lGlyphs>32K) CMaps: e.g.
*
*   [/TT31c1db0t0cid /TT31c1db0t0cidR]
*   or
*   [/TT31c1db0t0cid /TT31c1db0t0cidR /TT31c1db0t0cid32K /MSTT31c1db0t0cid32KR]
*****************************************************************************/

UFLErrCode
T42SendCMapWinCharSetFFFF_V(
    long            *pRotatedGID,
    short           wLength,
    UFLCMapInfo     *pCMap,
    char            *pNewCmap,
    unsigned long   lGlyphs,
    UFLHANDLE       stream
    )
{
    char            tempStr[256];
    short           nCount, nCount32K, nLen;
    short           i, j;
    unsigned short  wPrev, wCurr;
    UFLErrCode      retVal = kNoErr;

    UFLsprintf(tempStr,
        "/CIDInit /ProcSet findresource begin 12 dict begin begincmap /%s usecmap", pCMap->CMapName);
    retVal = StrmPutStringEOL(stream, tempStr);

    // % Since this CMap will refer to more than one font, the CIDSystmInfo is an array
    UFLsprintf(tempStr, "/CIDSystemInfo [ 3 dict dup begin /Registry (%s) def", pCMap->Registry);
    if (retVal == kNoErr)
        retVal = StrmPutStringEOL(stream, tempStr);

    UFLsprintf(tempStr, "/Ordering (%s0) def /Supplement 0 def end", pNewCmap);
    if (retVal == kNoErr)
        retVal = StrmPutStringEOL(stream, tempStr);

    if (lGlyphs > NUM_32K_1)
        UFLsprintf(tempStr, "dup dup dup] def");
    else
        UFLsprintf(tempStr, "dup] def");
    if (retVal == kNoErr)
        retVal = StrmPutStringEOL(stream, tempStr);

    UFLsprintf(tempStr, "/CMapName /%s def /CMapVersion 1 def /CMapType 1 def /WMode 1 def", pNewCmap);
    if (retVal == kNoErr)
        retVal = StrmPutStringEOL(stream, tempStr);

    UFLsprintf(tempStr, "1 beginusematrix [0 -1 1 0 0 0] endusematrix 1 usefont");
    if (retVal == kNoErr)
        retVal = StrmPutStringEOL(stream, tempStr);

    // Skip to emit begin~endcidrange if there is no rotated GIDs.
    if (wLength == 0)
        goto SENDCMAPFFFF_V_ENDCMAP;

    //
    // Count how many different Glyph-indices are there in pRotatedGID;
    // it must be sorted and there may be duplicates so that we count only
    // unique GIDs.
    //
    wPrev = (unsigned short) *(pRotatedGID);
    nCount = nCount32K = 0;

    if (wPrev > NUM_32K_1)
        nCount32K++;
    else
        nCount++;

    for (i = 0; i < wLength; i++)
    {
        wCurr = (unsigned short) (*(pRotatedGID + i));
        if (wPrev == wCurr)
            continue;
        else
        {
            wPrev = wCurr;
            if (wPrev > NUM_32K_1)
                nCount32K++;
            else
                nCount++;
        }
    }

    // Emit rotated GIDs.
    wPrev = (unsigned short)*(pRotatedGID);

    if (nCount > 100)
    {
        UFLsprintf(tempStr, "100 begincidrange" );
    }
    else
    {
        UFLsprintf(tempStr, "%d begincidrange", nCount);
    }

    if (retVal == kNoErr)
    {
        retVal = StrmPutStringEOL(stream, tempStr);
        retVal = StrmPutWordAsciiHex(stream, wPrev);
        retVal = StrmPutWordAsciiHex(stream, wPrev);
        UFLsprintf(tempStr, "%d", wPrev);
        retVal = StrmPutStringEOL(stream, tempStr);
    }

    /* 0 to 32K glyphs need rotation. */
    nLen = 1;
    for (i = 1; i < wLength; i++)
    {
        wCurr = (unsigned short) (*(pRotatedGID + i));

        /*
         * This potion is for 0 to 32K glyphs - the pRotatedGID are sorted,
         * so we can just break out of the loop here.
         */
        if (wCurr > NUM_32K_1)
            break;

        if (wPrev == wCurr)
            continue;
        else
        {
            wPrev = wCurr;
            nLen++;
        }

        if (retVal == kNoErr)
        {
            retVal = StrmPutWordAsciiHex(stream, wPrev);
            retVal = StrmPutWordAsciiHex(stream, wPrev);
            UFLsprintf(tempStr, "%d", wPrev);
            retVal = StrmPutStringEOL(stream, tempStr);
        }

        if (nLen % 100 == 0)
        {
            if (nCount - nLen > 100)
            {
                UFLsprintf(tempStr, "endcidrange\n100 begincidrange");
            }
            else if (nCount - nLen > 0)
            {
                UFLsprintf(tempStr, "endcidrange\n%d begincidrange", nCount - nLen);
            }
            else
            {
                UFLsprintf(tempStr, " ");
            }
        }
        else
            continue;  // Do next record.

        if (retVal == kNoErr)
            retVal = StrmPutStringEOL(stream, tempStr);
    }

    UFLsprintf(tempStr, "endcidrange");
    if (retVal == kNoErr)
        retVal = StrmPutStringEOL(stream, tempStr);

    /* 32K+ glyphs need rotation. */

    if (lGlyphs > NUM_32K_1)
    {
        // Build two more re-mappings for TT31abcd00032K.
        UFLsprintf(tempStr, "2 usefont");
        if (retVal == kNoErr)
            retVal = StrmPutStringEOL(stream, tempStr);

        nCount = (int) ((long)lGlyphs - (long)NUM_32K_1 + 0xFE) / 0xFF;
        UFLsprintf(tempStr, "%d begincidrange", nCount);
        if (retVal == kNoErr)
            retVal = StrmPutStringEOL(stream, tempStr);

        // We assume NUM_32K_1 ends at 00 (such as 0xFF00, or 0xFE00 ..>).
        for (i = 0; i < nCount; i++)
        {
            wPrev = (unsigned short) (i * 0x100 + (long)NUM_32K_1);
            retVal = StrmPutWordAsciiHex(stream, wPrev);
            retVal = StrmPutWordAsciiHex(stream, (unsigned short)(wPrev+0xFF));
            UFLsprintf(tempStr, "%d", wPrev);
            if (retVal == kNoErr)
                retVal = StrmPutStringEOL(stream, tempStr);
        }

        UFLsprintf(tempStr, "endcidrange");
        if (retVal == kNoErr)
            retVal = StrmPutStringEOL(stream, tempStr);

        if (nCount32K > 0)
        {
            // Remapping for MSTT31abcd00032KR.
            UFLsprintf(tempStr, "3 usefont");  // Font Array [000, 000R, 00032K, 00032KR]
            if (retVal == kNoErr)
                retVal = StrmPutStringEOL(stream, tempStr);
            wPrev = (unsigned short)*(pRotatedGID);

            for (j = 0; j < wLength; j++)
            {
                wCurr = (unsigned short) (*(pRotatedGID + j));
                wPrev = wCurr;
                if (wPrev > NUM_32K_1) break; // Found the start point.
            }

            if (nCount32K > 100)
                UFLsprintf(tempStr, "100 begincidrange");
            else
                UFLsprintf(tempStr, "%d begincidrange", nCount32K);

            if (retVal == kNoErr)
            {
                retVal = StrmPutStringEOL(stream, tempStr);
                retVal = StrmPutWordAsciiHex(stream, wPrev);
                retVal = StrmPutWordAsciiHex(stream, wPrev);
                UFLsprintf(tempStr, "%d", wPrev);
                retVal = StrmPutStringEOL(stream, tempStr);
            }

            nLen = 1;
            for (i = j; i < wLength; i++)
            {
                wCurr = (unsigned short) (*(pRotatedGID + i));

                if (wPrev == wCurr)
                    continue;
                else
                {
                    wPrev = wCurr;
                    nLen++;
                }

                if (retVal == kNoErr)
                {
                    retVal = StrmPutWordAsciiHex(stream, wPrev);
                    retVal = StrmPutWordAsciiHex(stream, wPrev);
                    UFLsprintf(tempStr, "%d", wPrev);
                    retVal = StrmPutStringEOL(stream, tempStr);
                }

                if (nLen % 100 == 0)
                {
                    if (nCount - nLen > 100)
                    {
                        UFLsprintf(tempStr, "endcidrange 100 begincidrange");
                    }
                    else if (nCount - nLen > 0)
                    {
                        UFLsprintf(tempStr, "endcidrange %d begincidrange", nCount-nLen);
                    }
                    else
                    {
                        UFLsprintf(tempStr, " ");
                    }
                }
                else
                    continue;  // Do next record.

                if (retVal == kNoErr)
                   retVal = StrmPutStringEOL(stream, tempStr);
            }

            UFLsprintf(tempStr, "endcidrange");
            if (retVal == kNoErr)
                retVal = StrmPutStringEOL(stream, tempStr);

            // End of additional 32K+ CMap code.
        }
    }

SENDCMAPFFFF_V_ENDCMAP:

    UFLsprintf(tempStr, "endcmap CMapName currentdict /CMap defineresource pop end end");

    if (retVal == kNoErr)
        retVal = StrmPutStringEOL(stream, tempStr);

    return retVal;
}

// ----------------- End code to support more than 32K glyphs ----------------


long
AdjBBox(
    long    value,
    UFLBool lowerleft
    )
{
   if (lowerleft)
   {
      if (value > 0)
         return (value - 1);
      else if (value < 0)
         return (value + 1);
      else
         return (value);
   }
   else
   {
      if (value > 0)
         return (value + 1);
      if (value < 0)
         return (value - 1);
      else
         return (value);
   }
}


UFLErrCode
CreateBaseFont(
    UFOStruct     *pUFObj,
    UFLBool       bFullFont
    )
{
    char            tempStr[100];
    UFLErrCode      retVal = kNoErr;
    unsigned long   tableSize, tableSize1;
    UFLHANDLE       stream;
    UFLCMapInfo     *pCMap;
    T42FontStruct   *pFont = (T42FontStruct *) pUFObj->pAFont->hFont;
    short           i, num;
    unsigned long   *pXuid = nil;
    unsigned long   cidCount;
    UFLFontProcs    *pFontProcs = (UFLFontProcs *)&(pUFObj->pUFL->fontProcs);
    char            *pCIDMap = NULL;
    long            em;
    UFLBool         bUseDef;
    long            fsType;

    stream = pUFObj->pUFL->hOut;

    /* Generate the minimal sfnt. */
    retVal = GetMinSfnt( pUFObj, bFullFont );

    if ( kNoErr == retVal )
        retVal = FillInHeadTable( pUFObj );

    if ( kNoErr == retVal )
    {
        pFont->info.fData.cNumGlyphs = GetNumGlyphs( pUFObj );
    }

    if ( kNoErr == retVal )
    {
        tableSize = GetTableSize( pUFObj, pFont->pMinSfnt, LOCA_TABLE );
        if ( tableSize )
        {
            //
            // The following code includes fix for #317027 and #316096: load
            // 'loca' table and set the extra glyph offset entry if it's
            // missing and the delta from the last glyph offset is less than
            // 4K for safety.
            //

            unsigned long expectedTableSize = pFont->info.fData.cNumGlyphs + 1;
            expectedTableSize *= pFont->headTable.indexToLocFormat ? 4 : 2;

            if (expectedTableSize > tableSize)
                pFont->pLocaTable = UFLNewPtr( pUFObj->pMem, expectedTableSize );
            else
                pFont->pLocaTable = UFLNewPtr( pUFObj->pMem, tableSize );

            if ( pFont->pLocaTable )
            {
                if ( GetFontTable(pUFObj, LOCA_TABLE, (unsigned char *)pFont->pLocaTable) == 0 )
                {
                    retVal = kErrGetFontData;
                }
                else if (expectedTableSize > tableSize)
                {
                    unsigned long  glyfTableSize = GetTableSize(pUFObj, pFont->pMinSfnt, GLYF_TABLE);
                    unsigned char  *pTable, *pExtraEntry;
                    unsigned long  lastValidOffset;

                    pTable = (unsigned char*)pFont->pLocaTable;

                    if (pFont->headTable.indexToLocFormat)
                    {
                        unsigned long *pLastEntry;

                        pLastEntry  = (unsigned long*)(pTable + (pFont->info.fData.cNumGlyphs - 1) * 4);

                        lastValidOffset = MOTOROLALONG(*pLastEntry);

                        if (glyfTableSize - lastValidOffset < 4097)
                        {
                            pExtraEntry = (unsigned char*)(pLastEntry + 1);

                            *pExtraEntry++ = (unsigned char)((glyfTableSize & 0xFF000000) >> 24);
                            *pExtraEntry++ = (unsigned char)((glyfTableSize & 0x00FF0000) >> 16);
                            *pExtraEntry++ = (unsigned char)((glyfTableSize & 0x0000FF00) >>  8);
                            *pExtraEntry   = (unsigned char)((glyfTableSize & 0x000000FF));
                        }
                    }
                    else
                    {
                        unsigned short *pLastEntry;

                        pLastEntry  = (unsigned short*)(pTable + (pFont->info.fData.cNumGlyphs - 1) * 2);

                        lastValidOffset = MOTOROLAINT(*pLastEntry);

                        if (glyfTableSize - lastValidOffset < 4097)
                        {
                            pExtraEntry = (unsigned char*)(pLastEntry + 1);

                            *pExtraEntry++ = (unsigned char)((glyfTableSize & 0x0000FF00) >>  8);
                            *pExtraEntry   = (unsigned char)((glyfTableSize & 0x000000FF));
                        }
                    }
                }
            }
            else
                retVal = kErrOutOfMemory;
        }
        else
            retVal = kErrGetFontData;
    }

    if ( kNoErr == retVal )
    {
        // Fix blue screen bug 278017.
        // tableSize = GetGlyphTableSize( pUFObj );
        tableSize = pFont->minSfntSize;     // 3/22/1999
        if (!bFullFont)
            tableSize += GetGlyphTableSize( pUFObj );

        if (((tableSize / SFNT_STRINGSIZE) * 5 / 4) > NUM_16KSTR)
            tableSize = (tableSize / SFNT_STRINGSIZE) * 5 / 4;
        else
            tableSize = NUM_16KSTR;

        // pFont->pStringLength = (unsigned long *)UFLNewPtr(pUFObj->pMem, (tableSize +1)*sizeof(unsigned long));
        tableSize1 = tableSize + 1;
        pFont->pStringLength = (unsigned long *)UFLNewPtr(pUFObj->pMem, tableSize1 * sizeof(unsigned long));

        if ( pFont->pStringLength )
        // CalculateStringLength(pUFObj, pFont );   // 3/22/1999
        retVal = CalculateStringLength(pUFObj, pFont,  tableSize1);
        else
            retVal =  kErrOutOfMemory;
    }

    // Send out left upper right lower values.
    if ( kNoErr == retVal )
    {
        /*
         * The first four values are the font bounding box, the last is the
         * UniqueID (which actually just gets ignored now). We convert all
         * floats into 24.8 fixed values.
         */
#if 0
        // We dont't set the UID for now.
        UFLsprintfEx(tempStr, "%f %f %f %f %x ",
            ((long)pFont->headTable.xMin << 8) / (long)pFont->headTable.unitsPerEm,
            ((long)pFont->headTable.yMin << 8) / (long)pFont->headTable.unitsPerEm,
            ((long)pFont->headTable.xMax << 8) / (long)pFont->headTable.unitsPerEm,
            ((long)pFont->headTable.yMax << 8) / (long)pFont->headTable.unitsPerEm,
            pFont->headTable.checkSumAdjustment);
#endif

        // Make sure the bounding box doesn't get truncated down to a smaller area.
        UFLsprintfEx(tempStr, "%f %f %f %f",
            (AdjBBox((long)pFont->headTable.xMin, 1) << 8) / (long)pFont->headTable.unitsPerEm,
            (AdjBBox((long)pFont->headTable.yMin, 1) << 8) / (long)pFont->headTable.unitsPerEm,
            (AdjBBox((long)pFont->headTable.xMax, 0) << 8) / (long)pFont->headTable.unitsPerEm,
            (AdjBBox((long)pFont->headTable.yMax, 0) << 8) / (long)pFont->headTable.unitsPerEm);

        retVal = StrmPutStringEOL(pUFObj->pUFL->hOut, tempStr);
    }

#ifdef __NEVER__
    // For full font downloading, fill in the Charstrings dict with all glyphs.
    if ( kNoErr == retVal && bFullFont )
    {
        unsigned char** tempVector = pGlyphs->glyphNames;
        for (i = 0; i < pGlyphs->sCount; i++, tempVector++)
        {
            UFLsprintf(tempStr, "/%s %d ", tempVector->pPSName, tempVector->index);
            retVal = StrmPutString(stream, tempStr);
        }
        UFLsprintf(tempStr, "%d t42CSA", pGlyphs->sCount);
        retVal = StrmPutStringEOL(stream, tempStr);
    }
#endif

    // Send out encoding name.
    if ( kNoErr == retVal )
    {
#if 1
        // Always emit Encoding array filled with /.notdef (due to bug fix #273021).
        retVal = StrmPutString( stream, gnotdefArray );
#else
        if ( pUFObj->pszEncodeName == 0 )
            retVal = StrmPutString( stream, gnotdefArray );
        else
            retVal = StrmPutString( stream, pUFObj->pszEncodeName );
#endif
    }

    // Send out font name.
    if ( kNoErr == retVal )
    {
        // IF CID/42-keyed font, then append "cid" to the CIDFont Name.
        if ( IS_TYPE42CID_KEYEDFONT(pUFObj->lDownloadFormat) )
        {
            UFLsprintf( tempStr, "/%s%s", pUFObj->pszFontName, gcidSuffix[0]);
        }
        else
        {
            //
            // CID_Resource also uses original fontName, client will produce new
            // names for composed font - with its own CMap!!
            //
            UFLsprintf( tempStr, " /%s", pUFObj->pszFontName );
        }
        retVal = StrmPutStringEOL( stream, tempStr );
    }

    /* Setup for CID-keyed-font or CIDFont-Resource downloading. */
    if (( kNoErr == retVal ) && IS_TYPE42CID(pUFObj->lDownloadFormat) )
    {
        if ( pFont->info.bUseIdentityCMap )
        {
            cidCount = UFO_NUM_GLYPHS(pUFObj);
            if (IS_TYPE42CID_V(pUFObj->lDownloadFormat) )
            {
                if (cidCount > NUM_32K_1)
                    pCMap = &CMapInfo_FF_V2;
                else
                    pCMap = &CMapInfo_FF_V;
            }
            else
            {
                if (cidCount > NUM_32K_1)
                    pCMap = &CMapInfo_FF_H2;
                else
                    pCMap = &CMapInfo_FF_H;
            }
        }
        else
        {
            cidCount = pFont->info.CIDCount;
            /* If CMap is provided, use it. */
            pCMap = &(pFont->info.CMap);
        }
    }

    /* IF CID/42, send CIDSysInfo, CIDCount, and WMode. */
    if ( ( kNoErr == retVal ) && IS_TYPE42CID(pUFObj->lDownloadFormat) )
    {
        UFLsprintf( tempStr, "(%s) (%s) %d %lu",
                    pCMap->Registry, pCMap->Ordering, pCMap->Supplement,
                    min(cidCount, (long)NUM_32K_1),
                    IS_TYPE42CID_H(pUFObj->lDownloadFormat) ? 0:1 );

        if ( kNoErr == retVal )
            retVal = StrmPutStringEOL( stream, tempStr );

        /* CIDMap */
        if ( pFontProcs->pfGetCIDMap
                && (tableSize = pFontProcs->pfGetCIDMap(pUFObj->hClientData, NULL, 0) )
             )
        {
            pCIDMap = UFLNewPtr( pUFObj->pMem, tableSize );

            if ( pCIDMap)
            {
                tableSize = pFontProcs->pfGetCIDMap( pUFObj->hClientData, pCIDMap, tableSize ) ;
                /* The pCIDMap is already ASCII, so just send it using PutBytes(). */
                if ( kNoErr == retVal )
                    StrmPutBytes(stream, pCIDMap, (UFLsize_t) tableSize, 1);
            }

            if (pCIDMap)
                UFLDeletePtr(pUFObj->pMem, pCIDMap);

            pCIDMap = nil;
        }
        else
        {
            //
            // IDStr creates an Identity string.
            // WCC - IDStrNull creates a strings which maps all oids to GID 0.
            // Bug #260864. Use IDStrNull for CC mode.
            //
            if (pFont->info.bUpdateCIDMap)
               UFLsprintf( tempStr, "%lu IDStrNull", min(cidCount-1, (long)NUM_32K_1) );
            else
               UFLsprintf( tempStr, "%lu IDStr", min(cidCount-1, (long)NUM_32K_1) );

            if ( kNoErr == retVal )
                retVal = StrmPutStringEOL( stream, tempStr );
        }

        /* WMode */
        UFLsprintf( tempStr, "%d CIDT42Begin", IS_TYPE42CID_H(pUFObj->lDownloadFormat) ? 0:1 );

        if ( kNoErr == retVal )
            retVal = StrmPutStringEOL( stream, tempStr );
    }
    else
    {
        /* Plain Type42 format */
        if ( kNoErr == retVal )
            retVal = StrmPutStringEOL( stream, "Type42DictBegin" );
    }

    /* Download the /sfnts array. */
    if ( kNoErr == retVal )
        retVal = StrmPutString(stream, "[");

    if ( kNoErr == retVal )
    {
        /* Remember Number of strings of all otherTables sent. */
        if (StrmCanOutputBinary(stream))
        {
            pFont->cNOtherTables = PSSendSfntsBinary( pUFObj );
        }
        else
        {
            pFont->cNOtherTables = PSSendSfntsAsciiHex( pUFObj );
        }
    }

    if ( kNoErr == retVal && !bFullFont )
        retVal = GenerateGlyphStorageExt( pUFObj, tableSize1 );

    if ( kNoErr == retVal )
        retVal = StrmPutStringEOL(stream, "]def ");

    if ( kNoErr == retVal && !bFullFont )
    {
        /* Invoke procedure to prepare for 2015 incremental downloading. */
        retVal = StrmPutInt(stream, GetTableDirectoryOffset(pFont, LOCA_TABLE));

        if ( kNoErr == retVal )
            retVal = StrmPutString(stream, " ");
        if ( kNoErr == retVal )
            retVal = StrmPutInt(stream, GetTableDirectoryOffset(pFont, GLYF_TABLE));
        if ( kNoErr == retVal )
            retVal = StrmPutStringEOL(stream, " ");

        if ( kNoErr == retVal )
            retVal = StrmPutStringEOL(stream, "PrepFor2015");
    }

    /*
     * Add FontInfo dict if the "post" table is not good as of today. We only
     * need this info in the FontInfo dict.
     */
    if ( kNoErr == retVal )   // 293130
    {
        retVal = StrmPutStringEOL(stream, "AddFontInfoBegin");
        pUFObj->dwFlags |= UFO_HasFontInfo;
    }

    if ( !BHasGoodPostTable(pUFObj) )
    {
        if (kNoErr == retVal )
        {
            UFLsprintf( tempStr, "AddFontInfo");
            if ( kNoErr == retVal )
            {
                retVal = StrmPutStringEOL( stream, tempStr);
                pUFObj->dwFlags |= UFO_HasG2UDict;
            }
        }
    }

    /* Add more font properties to FontInfo of the current dict. */
    if ( ( kNoErr == retVal ) && ( pFontProcs->pfAddFontInfo))
    {
        char *pBuffer;
        int  bufLen = 1000;

        pBuffer = UFLNewPtr( pUFObj->pMem, bufLen );
        if ( pBuffer)
        {
            pFontProcs->pfAddFontInfo(pUFObj->hClientData, pBuffer, bufLen ) ;
            retVal = StrmPutStringEOL(stream, pBuffer);
        }
        if (pBuffer)
            UFLDeletePtr(pUFObj->pMem, pBuffer);
        pBuffer = nil;
    }

    if (kNoErr == retVal)
    {
        // Fixing bug 284250. Add /FSType to FontInfoDict
        if ((fsType = GetOS2FSType(pUFObj)) == -1)
            fsType = 4;
        UFLsprintf(tempStr, "/FSType %ld def", fsType);
            retVal = StrmPutStringEOL(stream, tempStr);
    }

    if (kNoErr == retVal)
        StrmPutStringEOL(stream, "AddFontInfoEnd");

    /* Optionally add XUID. */
    if (kNoErr == retVal)
    {
        num = (short int) pUFObj->Xuid.sSize;
        pXuid = pUFObj->Xuid.pXUID;

        if (num > 0)
        {
                retVal = StrmPutString(stream, "[");
                for (i=0; ( kNoErr == retVal ) && (i<num); i++)
            {
                UFLsprintf(tempStr, "16#%x ", *(pXuid+i) );
                    retVal = StrmPutString(stream, tempStr);
            }
            if ( kNoErr == retVal )
            {
                UFLsprintf( tempStr, "] AddXUID");
                retVal = StrmPutStringEOL(stream, tempStr);
            }
        }
    }

    //
    // Send CDevProc to handle Metrics2 array.
    //
    // The current /CDevProc doesn't produce the same output as we see on the
    // screen when the TrueType font is 1) CJK, 2) vertical, 3) proportional,
    // and 4) fake-italic. We have investigated this problem long time, but for
    // now this is what we think we have to do: add Vy and URy (here Vy is
    // actaully TopSideBearing) and use it as real Vy regardless of that the TT
    // TT font is fake-italic-ed or not.
    //
    // _APPLY_TANGENT_ALPHA_TRICK_ section is what we have been doing to get
    // the closer output to the screen, but it doesn't work universally when,
    // for example, the font is rotated in 45 degrees. So we disabled it and
    // compromise the output until we understand what GDI is doing for the 1),
    // 2), 3), and 4) case. See AddT42vmtxEntry below too.
    //
    // The bug numbers related with this problem: 277035, 277063, 303540, and
    // 309104.
    //
    if (( kNoErr == retVal ) && IS_TYPE42CID_V(pUFObj->lDownloadFormat) )
    {
        long w1y, vx, vy, top;

        // Get default Metrics2 values.
        GetMetrics2FromTTF(pUFObj, 0, &em, &w1y, &vx, &vy, &top, &bUseDef, 1);

        UFLsprintf(tempStr, "/CDevProc{pop 3 index 0 lt");
        if (kNoErr == retVal)
            retVal = StrmPutStringEOL(stream, tempStr);

#ifndef _APPLY_TANGENT_ALPHA_TRICK_

        UFLsprintf(tempStr, "{4 -1 roll pop 0 4 1 roll 4 index add}");
        if (kNoErr == retVal)
            retVal = StrmPutStringEOL(stream, tempStr);

#else // _APPLY_TANGENT_ALPHA_TRICK_

        UFLsprintf(tempStr,
                    "{4 -1 roll pop 0 4 1 roll 4 index add");
        if (kNoErr == retVal)
            retVal = StrmPutStringEOL(stream, tempStr);

        //
        // Tangent Alpha Trick
        //
        // Adjust Vy based on the skewing factor of the current font matrix
        // if AdvanceHeight of the glyph is not equal to EM. The new Vy is
        // calculated using the following formula:
        //
        // Vy' = Vy - (URx - LLx)*Tangent(skew angle).
        //
        // Note: on Win9x the skew angle is hard-coded in iMat (currently 12
        // degree. Please see Kanji.ps, text.ps & watermark.ps).
        //
        UFLsprintf(tempStr,
                    "2 index -1 ne{rootfont /FontMatrix get %d get 0 ne",
                    pFont->nVObliqueElementIndex);
        if (kNoErr == retVal)
            retVal = StrmPutStringEOL(stream, tempStr);

        UFLsprintf(tempStr,
                    "{5 index 8 index sub %s mul sub}if}if}",
                    pFont->pszVObliqueTangentTheta);
        if (kNoErr == retVal)
            retVal = StrmPutStringEOL(stream, tempStr);

#endif // _APPLY_TANGENT_ALPHA_TRICK_

        //
        // Push down default W1 and V vector values for the glyphs of which
        // TopSideBearing is not available. (See AddT42vmtxEntry below.)
        //
        UFLsprintf(tempStr,
                    "{pop pop pop pop ");
        if (kNoErr == retVal)
            retVal = StrmPutString(stream, tempStr);

        UFLsprintf(tempStr,
                    (w1y == em) ? "0 -1 " : "0 %ld %ld div ",
                    -w1y, em);
        if (kNoErr == retVal)
            retVal = StrmPutString(stream, tempStr);

        UFLsprintf(tempStr,
                    "%ld %ld div %ld %ld div}ifelse", vx, em, vy, em);
        if (kNoErr == retVal)
            retVal = StrmPutStringEOL(stream, tempStr);

        UFLsprintf(tempStr,
                    "}bind def");
        if (kNoErr == retVal)
            retVal = StrmPutStringEOL(stream, tempStr);
    }

    if ( IS_TYPE42CID(pUFObj->lDownloadFormat) )
    {
        /* End the CIDFont resource creation. */
        if (kNoErr == retVal )
        {
            UFLsprintf( tempStr, "CIDT42End");
            if ( kNoErr == retVal )
                retVal = StrmPutStringEOL( stream, tempStr);
        }
    }
    else
    {
        /* Plain Type42 format */
        if ( kNoErr == retVal )
            retVal = StrmPutStringEOL(stream, "Type42DictEnd");
    }

    /* pRotatedGlyphIDs is also used for DoubleByteChar checking for Vertical CIDFont. */
    if ( ( kNoErr == retVal ) && IS_TYPE42CID_V(pUFObj->lDownloadFormat) )
    {
        retVal = T42GetRotatedGIDs( pUFObj, pFont );
    }

    /*
     * At this point, a CIDFont resource is created, if the request is to
     * do kTTType42CID_Resource, we are done.
     */
    if ( ( kNoErr == retVal ) && IS_TYPE42CID_KEYEDFONT(pUFObj->lDownloadFormat) )
    {
        /*
         * Instantiate the CMap resource if do composefont - notice a convention
         * used here: CMAP-cmapname is used to instantiate cmapname.
         * See CMap_FF.ps as an example.
         */
        if (kNoErr == retVal )
        {
            UFLsprintf( tempStr, "CMAP-%s", pCMap->CMapName);
            if ( kNoErr == retVal )
                retVal = StrmPutStringEOL( stream, tempStr);
        }

        /*
         * Now, we can construct CID-keyed font from CIDFont reosurce and a CMap.
         *
         * e.g. /TT3782053888t0 /WinCharSetFFFF-H [/TT3782053888t0cid ] composefont pop
         *
         * !!!BUT!!!, if there are more than 32K glyphs (like some Korean TT Fonts),
         * we need to make copies of the CIDFont Resource and make use of more than
         * one CMap - it's ugly, it's the only way to do it. PPeng, 11-12-1996
         */
        if (pUFObj->lDownloadFormat == kTTType42CID_H)
        {
            /* Horizontal: we need 1 or 2 cidfonts. */
            if (cidCount > NUM_32K_1)
            {
                /*
                 * Make a copy of the cid font so we can access 32K+ glyphs.
                 * % num CIDMap /NewName32K /BaseName T42CIDCP32K  => -
                 */
                UFLsprintf(tempStr, "%lu dup 1 sub %lu IDStr2 /%s%s /%s%s T42CIDCP32K",
                            cidCount - (long)NUM_32K_1, (long)NUM_32K_1,
                            pUFObj->pszFontName, gcidSuffix[CIDSUFFIX_32K],
                            pUFObj->pszFontName, gcidSuffix[0]);
                if ( kNoErr == retVal )
                    retVal = StrmPutString(stream, tempStr);

                /* Now create the CID-Keyed Font use two CIDFonts. */
                UFLsprintf(tempStr, "/%s /%s [/%s%s ",
                            pUFObj->pszFontName, pCMap->CMapName,
                            pUFObj->pszFontName, gcidSuffix[0] );
                if ( kNoErr == retVal )
                    retVal = StrmPutString(stream, tempStr);

                UFLsprintf(tempStr, "/%s%s ] composefont pop",
                            pUFObj->pszFontName,gcidSuffix[CIDSUFFIX_32K]);
                if ( kNoErr == retVal )
                    retVal = StrmPutStringEOL(stream, tempStr);
            }
            else
            {
                /* Now create the CID-Keyed Font use just one CIDFont. */
                UFLsprintf(tempStr, "/%s /%s [/%s%s ] composefont pop",
                            pUFObj->pszFontName, pCMap->CMapName,
                            pUFObj->pszFontName, gcidSuffix[0]);
                if ( kNoErr == retVal )
                    retVal = StrmPutStringEOL(stream, tempStr);
            }
        }
        else
        {
            /* Vertical font: we need 2 or 4 cidfonts. */
            char newCMapName[50];
            UFLsprintf(newCMapName, "%s%s",pCMap->CMapName, pUFObj->pszFontName);
            if ( kNoErr == retVal )
                retVal = T42SendCMapWinCharSetFFFF_V(pFont->pRotatedGlyphIDs,
                                                    (short)(pFont->numRotatedGlyphIDs),
                                                    pCMap, newCMapName, cidCount, stream);

            if (cidCount > NUM_32K_1)
            {
                /* Make a copy of the cid font so we can access 32K+ glyphs. */
                UFLsprintf(tempStr, "%lu dup 1 sub %lu IDStr2 /%s%s /%s%s T42CIDCP32K",
                            cidCount - (long)NUM_32K_1, (long)NUM_32K_1,
                            pUFObj->pszFontName, gcidSuffix[CIDSUFFIX_32K],
                            pUFObj->pszFontName, gcidSuffix[0]);
                if ( kNoErr == retVal )
                    retVal = StrmPutStringEOL(stream, tempStr);

                /* Make a copy of the cid font so we can access Rotated glyphs. */
                UFLsprintf(tempStr, "/%s%s /%s%s T42CIDCPR",
                            pUFObj->pszFontName, gcidSuffix[CIDSUFFIX_R],
                            pUFObj->pszFontName, gcidSuffix[0]);
                if ( kNoErr == retVal )
                    retVal = StrmPutStringEOL(stream, tempStr);

                /* Make a copy of the cid font so we can access Rotated glyphs at 32k+. */
                UFLsprintf(tempStr, "/%s%s /%s%s T42CIDCPR",
                            pUFObj->pszFontName, gcidSuffix[CIDSUFFIX_32KR],
                            pUFObj->pszFontName, gcidSuffix[CIDSUFFIX_32K]);
                if ( kNoErr == retVal )
                    retVal = StrmPutStringEOL(stream, tempStr);

                /* Now create the CID-Keyed Font: using 4 cidfonts. */
                UFLsprintf(tempStr, "/%s /%s [/%s%s ",
                            pUFObj->pszFontName, newCMapName,
                            pUFObj->pszFontName, gcidSuffix[0] );
                if ( kNoErr == retVal )
                    retVal = StrmPutStringEOL(stream, tempStr);

                UFLsprintf(tempStr, "/%s%s /%s%s /%s%s] composefont pop",
                            pUFObj->pszFontName, gcidSuffix[CIDSUFFIX_R],
                            pUFObj->pszFontName, gcidSuffix[CIDSUFFIX_32K],
                            pUFObj->pszFontName, gcidSuffix[CIDSUFFIX_32KR] );
                if ( kNoErr == retVal )
                    retVal = StrmPutStringEOL(stream, tempStr);
            }
            else
            {
                /* Make a copy of the cid font so we can access Rotated glyphs. */
                UFLsprintf(tempStr, "/%s%s /%s%s T42CIDCPR",
                            pUFObj->pszFontName, gcidSuffix[CIDSUFFIX_R],
                            pUFObj->pszFontName, gcidSuffix[0]);
                if ( kNoErr == retVal )
                    retVal = StrmPutStringEOL(stream, tempStr);

                /* Now create the CID-Keyed Font: using 2 cidfonts. */
                UFLsprintf(tempStr, "/%s /%s [/%s%s ",
                            pUFObj->pszFontName, newCMapName,
                            pUFObj->pszFontName, gcidSuffix[0] );
                if ( kNoErr == retVal )
                    retVal = StrmPutString(stream, tempStr);

                UFLsprintf(tempStr, "/%s%s ] composefont pop",
                            pUFObj->pszFontName, gcidSuffix[CIDSUFFIX_R] );
                if ( kNoErr == retVal )
                    retVal = StrmPutStringEOL(stream, tempStr);
            }
        }
    }

    if ( kNoErr == retVal )
    {
        if (bFullFont)
        {
            UFLDeletePtr(pUFObj->pMem, pFont->pStringLength);
            pFont->pStringLength = nil;
        }
    }

    if ( pFont->pMinSfnt )
    {
        UFLDeletePtr( pUFObj->pMem, pFont->pMinSfnt );
        pFont->pMinSfnt = 0;
    }

    // Free buffers allocated in this program  293130
    if ( kNoErr != retVal )
    {
       if (pFont->pHeader != nil)
          UFLDeletePtr(pUFObj->pMem, pFont->pHeader);

       if (pFont->pStringLength != nil)
          UFLDeletePtr(pUFObj->pMem, pFont->pStringLength);

       if (pFont->pLocaTable != nil)
          UFLDeletePtr(pUFObj->pMem, pFont->pLocaTable);

       if (pFont->pRotatedGlyphIDs != nil)
          UFLDeletePtr(pUFObj->pMem, pFont->pRotatedGlyphIDs);

       pFont->pStringLength = nil;
       pFont->pHeader = nil;
       pFont->pLocaTable = nil;
       pFont->pRotatedGlyphIDs = nil;
    }

    return retVal;
}


UFLErrCode
AddT42vmtxEntry(
    UFOStruct      *pUFObj,
    unsigned short wGlyfIndex,
    unsigned short cid,
    char           *cidFontName,
    UFLHANDLE      stream
    )
{
    char          tempStr[256];
    long          em, w1y, vx, vy, top;
    UFLBool       bUseDef;
    UFLErrCode    retVal = kNoErr;
    T42FontStruct *pFont = (T42FontStruct *)pUFObj->pAFont->hFont;

    //
    // Add Vertical metrics array Metrics2: [W1x W1y Vx Vy]
    // ONLY IF:
    // 1) the font is vertical,
    // 2) the Glyph is a Double-Byte char,
    // 3) and the glyph uses non-default Metrics2 values.
    //
    if (!IS_TYPE42CID_V(pUFObj->lDownloadFormat))
        return retVal;

    if (!IsDoubleByteGI(wGlyfIndex, pFont->pRotatedGlyphIDs, (short)(pFont->numRotatedGlyphIDs)))
        return retVal;

    GetMetrics2FromTTF(pUFObj, wGlyfIndex, &em, &w1y, &vx, &vy, &top, &bUseDef, 0);

    if (bUseDef)
        return retVal;

    //
    // Send Metrics2 array. Basically it is
    //
    // [0  -W1y/EM   Vx/EM   Vy/EM]
    //
    // But, to support both fixed and proportional fonts universally we set
    // TopSideBearing as Vy instead. In CDevProc this value and URy are added
    // to get real Vy value later. See the code emitting /CDevProc in the
    // CreateBaseFont function above for the details.
    //
    // We also set a negative value (-1 for now) as W1x to indicate CDevProc
    // that the paramenters are from this Metrics2 array. CDevProc will set it
    // back to the correct value, zero.
    //
    UFLsprintf(tempStr,
                "%ld [-1 %ld %ld div %ld %ld div %ld %ld div] /%s T0AddT42Mtx2",
                (long)cid, -w1y, em, vx, em, top, em, cidFontName);

    if ( kNoErr == retVal )
        retVal = StrmPutStringEOL(stream, tempStr);

    return retVal;
}


UFLErrCode
T42UpdateCIDMap(
    UFOStruct      *pUFObj,
    unsigned short wGlyfIndex,
    unsigned short cid,
    char           *cidFontName,
    UFLHANDLE      stream
    )
{
    char          tempStr[80];
    UFLErrCode    retVal = kNoErr;

    UFLsprintf(tempStr,  "%ld ", (long)2*cid);  /* 2*cid is the BYTE-index in CIDMap. */
    retVal = StrmPutString(stream, tempStr);

    if (retVal == kNoErr)
        retVal = StrmPutWordAsciiHex(stream, wGlyfIndex);

    UFLsprintf(tempStr,  " /%s UpdateCIDMap", cidFontName);

    if (retVal == kNoErr)
        retVal = StrmPutStringEOL(stream, tempStr);

    return retVal;
}


unsigned short GetCIDAndCIDFontName(
    UFOStruct       *pUFObj,
    unsigned short  wGid,
    char            *cidFontName
    )

/*++

    Retunrs cid - a number and the cidFontName.

--*/

{
    unsigned short  cid = 0;
    T42FontStruct   *pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    if ( IS_TYPE42CID_KEYEDFONT(pUFObj->lDownloadFormat) )
    {
        /* For CID-Keyed font, we control the cidFontName. */
        if (pFont->info.bUseIdentityCMap && wGid > NUM_32K_1)
        {
            /* 32K+ glyphs are re-mapped to the 32K CIDFont. */
            UFLsprintf(cidFontName, "%s%s", pUFObj->pszFontName, gcidSuffix[CIDSUFFIX_32K]);
            cid = (unsigned short) ((long)wGid-(long)NUM_32K_1);
        }
        else
        {
            UFLsprintf(cidFontName, "%s%s", pUFObj->pszFontName, gcidSuffix[0]);
            cid = wGid;
        }
    }
    else
    {
        UFLsprintf(cidFontName, "%s", pUFObj->pszFontName);
        /* Don't know how to assign a CID. */
    }

    return cid;
}


UFLErrCode
PutT42Char(
    UFOStruct       *pUFObj,
    unsigned short  wGlyfIndex,
    unsigned short  wCid,
    COMPOSITEGLYPHS *pCompGlyphs
    )
{
    unsigned short i = 0, j = 0, wIndex=0, wCompFlags=0;
    unsigned long  *glyphRanges;
    unsigned long  glyphOffset, glyphLength;
    UFLBool        bMoreComp = 0;
    char           *pGlyph;
    char           *pCompTmp;
    char           tempStr[80];
    UFLErrCode     retVal = kNoErr;
    UFLHANDLE      stream;
    char           nilStr[] = "\0\0";  // An empty/nil string.
    T42FontStruct  *pFont = (T42FontStruct *) pUFObj->pAFont->hFont;
    char           cidFontName[50] = "";
    unsigned short cid;

    glyphRanges = pFont->pStringLength;
    stream = pUFObj->pUFL->hOut;

    if (wGlyfIndex > UFO_NUM_GLYPHS(pUFObj))
    {
        // If the request is out of range, pretend it is downloaded, not-an-error!!
        return kNoErr;
    }

    if ( pFont->headTable.indexToLocFormat )
    {
        /* 0 for short offsets, 1 for long. */
        unsigned long PTR_PREFIX * locationTable = (unsigned long PTR_PREFIX *)pFont->pLocaTable;

        /*
         * Bad font protection : some fonts have bad "loca" data for a few
         * glyphs. These bad glyphs will be treated as /.notdef.
         */
//        if ( MOTOROLALONG(locationTable[wGlyfIndex+1]) < MOTOROLALONG(locationTable[wGlyfIndex]) )
//            return kNoErr;

        /* Get the offset to the glyph from the beginning of the glyf table. */
        glyphOffset = MOTOROLALONG(locationTable[wGlyfIndex]);
        if ( ( MOTOROLALONG(locationTable[wGlyfIndex+1]) < MOTOROLALONG(locationTable[wGlyfIndex]) ) ||
            ( ( MOTOROLALONG(locationTable[wGlyfIndex+1]) - MOTOROLALONG(locationTable[wGlyfIndex]) ) > 16384L) )
            glyphLength = GetLenByScanLoca( locationTable, wGlyfIndex, UFO_NUM_GLYPHS(pUFObj), pFont->headTable.indexToLocFormat );
        else
            glyphLength = (unsigned long)MOTOROLALONG(locationTable[wGlyfIndex+1]) - glyphOffset;
    }
    else
    {
        unsigned short PTR_PREFIX * locationTable = (unsigned short PTR_PREFIX *)pFont->pLocaTable;

        /*
         * Bad font protection : some fonts have bad "loca" data for a few
         * glyphs. These bad glyphs will be treated as /.notdef.
         * /
//        if ( MOTOROLAINT(locationTable[wGlyfIndex+1]) < MOTOROLAINT(locationTable[wGlyfIndex]) )
//            return kNoErr;

        /* Get the offset to the glyph from the beginning of the glyf table. */
        glyphOffset = (unsigned long)MOTOROLAINT(locationTable[wGlyfIndex]) * 2;
        if ( ( MOTOROLAINT(locationTable[wGlyfIndex+1]) < MOTOROLAINT(locationTable[wGlyfIndex]) ) ||
            ( ( MOTOROLAINT(locationTable[wGlyfIndex+1]) - MOTOROLAINT(locationTable[wGlyfIndex]) ) > 16384) )
            glyphLength = GetLenByScanLoca( locationTable, wGlyfIndex, UFO_NUM_GLYPHS(pUFObj), pFont->headTable.indexToLocFormat );
        else
            glyphLength = (unsigned long)MOTOROLAINT(locationTable[wGlyfIndex+1]) * 2 - glyphOffset;
    }

    /*
     * GlyphIndices that have no glyph description point to the same offset.
     * So, GlyphLength becomes 0. Handle these as special cases for 2015 and
     * pre-2015.
     */
    if ( !glyphLength )
    {
        /* Send parameters for /AddT42Char procedure. */
        retVal = StrmPutStringEOL(stream, nilStr);

        /*
         * Locate /sfnts string number in which the glyph occurs and offset of
         * the glyph in "that" string.
         */
        i = 1;
        while (glyphRanges[i] != 0)
        {
            if (glyphOffset < glyphRanges[i])
            {
                i--;  /* Gives the "actual" string index (as opposed to string number). */
                break;
            }
            i++; /* Go to the next string and check if Glyph belongs there. */
        }

        //
        // Send index of /sfnts string in which this glyph belongs.
        // Check if a valid index i was found.
        //
        if (glyphRanges[i] == 0)
        {
            /*
             * Oops, this should not have happened. But it will, with Monotype
             * Sorts or any font whose last few glyphs are not defined.
             * Roll back i to point to glyph index 0, the bullet character.
             * Anyway, it does not matter where this glyph (with no description)
             * points to, really. Only 2015 needs a real entry in /GlyphDirectory,
             * even for glyphs with no description, ie, the entry:
             * /GlyphIndex  < >  def  in the dict /GlyphDirectory.
             */
            i = 0;
            glyphOffset = 0;
        }

        retVal = StrmPutInt(stream, pFont->cNOtherTables + i);
        if ( kNoErr == retVal )
            retVal = StrmPutString(stream, " ");

        /* Send offset of the glyph in the particular /sfnts string. */
        if ( kNoErr == retVal )
            retVal = StrmPutInt(stream, glyphOffset - glyphRanges[i]);
        if ( kNoErr == retVal )
            retVal = StrmPutString(stream, " ");

        /* Send the glyph index. */
        if ( kNoErr == retVal )
            retVal = StrmPutInt(stream, wGlyfIndex);

        if ( kNoErr == retVal )
            retVal = StrmPutString(stream, " <> ");

        if ( IS_TYPE42CID(pUFObj->lDownloadFormat) )
        {
            cid = GetCIDAndCIDFontName(pUFObj, wGlyfIndex, cidFontName);

            UFLsprintf(tempStr, "/%s T0AddT42Char ", cidFontName);
            if ( kNoErr == retVal )
                retVal = StrmPutStringEOL(stream, tempStr);

            if (!pFont->info.bUseIdentityCMap )
                cid = wCid;

            // Add Vertical metrics to Metrics2 dict: [w1x w1y vx vy] if necessary.
            AddT42vmtxEntry(pUFObj, wGlyfIndex, wCid, cidFontName, stream);

            if (pFont->info.bUpdateCIDMap)
                T42UpdateCIDMap(pUFObj, wGlyfIndex, wCid, cidFontName, stream);

        }
        else
        {
            UFLsprintf(tempStr, "/%s AddT42Char ", pUFObj->pszFontName);
            if ( kNoErr == retVal )
            retVal = StrmPutStringEOL(stream, tempStr);
        }

        return retVal;
    }  /* if ( !glyphLength )  */


    /* Get the physical glyph data to lpGlyph. */

    pGlyph = (char *)UFLNewPtr(pUFObj->pMem, glyphLength);
    if (pGlyph == nil)
        retVal =  kErrOutOfMemory;

    if ( 0 == GETTTFONTDATA(pUFObj, GLYF_TABLE, glyphOffset,
                                (void *) pGlyph, glyphLength,
                                pFont->info.fData.fontIndex) )
        retVal = kErrGetFontData;

    /* Handle Composite Characters. */
    if ( kNoErr == retVal && *((short *)pGlyph) == MINUS_ONE)
    {
        pCompTmp = pGlyph;
        pCompTmp += 10; /* Move to beginning of glyph description. */

        do
        {
            wCompFlags = MOTOROLAINT(*((unsigned short *)pCompTmp));
            wIndex = MOTOROLAINT(((unsigned short *)pCompTmp)[1]);

            /* Download the first "component" glyph of this composite character. */
            if ( (wIndex < UFO_NUM_GLYPHS(pUFObj))
                 && !IS_GLYPH_SENT( pUFObj->pAFont->pDownloadedGlyphs, wIndex ) )
            {
                if (pFont->info.bUseIdentityCMap )
                {
                    if (wIndex > NUM_32K_1)
                    {
                        /* 32K+ glyphs are re-mapped to the 32K CIDFont. */
                        cid = (unsigned short) ((long)wIndex-(long)NUM_32K_1);
                    }
                    else
                    {
                        cid = wIndex;
                    }
                }
                else
                    cid = 0; /* Don't know the wCid. */

                retVal = PutT42Char(pUFObj, wIndex, cid, pCompGlyphs);

                if ( retVal == kNoErr )
                {
                    SET_GLYPH_SENT_STATUS( pUFObj->pAFont->pDownloadedGlyphs, wIndex );

                    /*
                     * If we ran out of space to keep track of the composite
                     * componets then allocate more space.
                     */
                    if ((pCompGlyphs->sCount >= pCompGlyphs->sMaxCount)
                        && (pCompGlyphs->pGlyphs != nil))
                    {
                        short sEnlargeSize = pCompGlyphs->sMaxCount + 50;
                        if (UFLEnlargePtr( pUFObj->pMem,
                                            (void **) &pCompGlyphs->pGlyphs,
                                            (sEnlargeSize * sizeof (unsigned short)), 1 ))
                        {
                            pCompGlyphs->sMaxCount = sEnlargeSize;
                        }
                        else
                        {
                            // For some reason we can't get more space.
                            // Then just don't do this at all.
                            UFLDeletePtr(pUFObj->pMem, pCompGlyphs->pGlyphs);
                            pCompGlyphs->pGlyphs = nil;
                            pCompGlyphs->sCount = pCompGlyphs->sMaxCount = 0;
                        }
                    }

                    /* Remember which composite glyph componet we downloaded. */
                    if (pCompGlyphs->pGlyphs)
                    {
                        *(pCompGlyphs->pGlyphs + pCompGlyphs->sCount) = wIndex;
                        pCompGlyphs->sCount++;
                    }
                }
            }

            /* Check for other components in this composite character. */
            if ( kNoErr == retVal && (wCompFlags & MORE_COMPONENTS) )
            {
                bMoreComp=1;

                /*
                 * Find out how far we need to advance lpCompTmp to get to next
                 * component of the composite character.
                 */
                if (wCompFlags & ARG_1_AND_2_ARE_WORDS)
                {
                    pCompTmp+=8;
                }
                else
                {
                    pCompTmp+=6;
                }

                /* Check what kind of scaling is done on the glyph component. */
                if (wCompFlags & WE_HAVE_A_SCALE)
                {
                    pCompTmp+=2;
                }
                else
                {
                    if (wCompFlags & WE_HAVE_AN_X_AND_Y_SCALE)
                    {
                        pCompTmp+=4;
                    }
                    else
                    {
                        if (wCompFlags & WE_HAVE_A_TWO_BY_TWO)
                            pCompTmp+=8;
                    }
                }
            }
            else
            {
                bMoreComp=0;
            }

        } while (bMoreComp && kNoErr == retVal); /* do~while loop */
    } /* If composite character */

    /*
     * Locate /sfnts string number in which the glyph occurs and offset of
     * the glyph in "that" string.
     */
    if ( kNoErr == retVal )
    {
        i = 1;
        while (glyphRanges[i] != 0)
        {
            if (glyphOffset < glyphRanges[i])
            {
                i--;  /* Gives the "actual" string index (as opposed to string number). */
                break;
            }
            i++;      /* Go to the next string and check if Glyph belongs there. */
        }
    }

    /* Send index of /sfnts string in which this glyph belongs. */
    if ( kNoErr == retVal )
        retVal = StrmPutInt(stream, pFont->cNOtherTables + i);
    if ( kNoErr == retVal )
        retVal = StrmPutString(stream, " ");

    /* Send offset of the glyph in the particular /sfnts string. */
    if ( kNoErr == retVal )
        retVal = StrmPutInt(stream, glyphOffset-glyphRanges[i]);
    if ( kNoErr == retVal )
        retVal = StrmPutString(stream, " ");

    /* Send the glyph index. */
    if ( kNoErr == retVal )
        retVal = StrmPutInt(stream, wGlyfIndex);
    if ( kNoErr == retVal )
        retVal = StrmPutString(stream, " ");


    /* Download the glyph in binary (or) AsciiHex format. */
    if ( kNoErr == retVal )
    {
        if ( StrmCanOutputBinary(stream) )
        {
            retVal = StrmPutInt(stream, glyphLength);

            if ( kNoErr == retVal )
                retVal = StrmPutString(stream, RDString);
            if ( kNoErr == retVal )
                retVal = StrmPutBytes(stream, pGlyph, (UFLsize_t) glyphLength, 0);
        }
        else
        {
            retVal = StrmPutString(stream, "<");
            if ( kNoErr == retVal )
                retVal = StrmPutAsciiHex(stream, pGlyph, glyphLength);
            if ( kNoErr == retVal )
                retVal = StrmPutString(stream, ">");
        }
    }

    if ( IS_TYPE42CID(pUFObj->lDownloadFormat) )
    {
        cid = GetCIDAndCIDFontName(pUFObj, wGlyfIndex, cidFontName);

        UFLsprintf(tempStr, "/%s T0AddT42Char ", cidFontName);
        if ( kNoErr == retVal )
            retVal = StrmPutStringEOL(stream, tempStr);

        if (!pFont->info.bUseIdentityCMap )
            cid = wCid;

        // Add Vertical metrics to Metrics2 dict: [w1x w1y vx vy] if necessary.
        AddT42vmtxEntry(pUFObj, wGlyfIndex, cid, cidFontName, stream);

        if (pFont->info.bUpdateCIDMap)
            T42UpdateCIDMap(pUFObj, wGlyfIndex, wCid, cidFontName, stream);

    }
    else
    {
        UFLsprintf(tempStr, "/%s AddT42Char ", pUFObj->pszFontName);
        if ( kNoErr == retVal )
            retVal = StrmPutStringEOL(stream, tempStr);
    }

    if ( pGlyph )
    {
        UFLDeletePtr(pUFObj->pMem, pGlyph);
        pGlyph = nil;
    }

    return retVal;
}


UFLErrCode
AddChars(
    UFOStruct           *pUFObj,
    const UFLGlyphsInfo *pGlyphs
    )
{
    short           i;
    char            tempStr[50];
    short           totalGlyphs;
    UFLErrCode      retVal = kNoErr;
    UFLHANDLE       stream;
    unsigned short  wIndex;
    char            *pGoodName;
    char            *pHintName;
    T42FontStruct   *pFont;
    UFLGlyphID      *glyphs;
    COMPOSITEGLYPHS compGlyphs;
    UFLBool         bAddCompGlyphAlternate = 0;
    unsigned short  cid = 0;

    pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    stream = pUFObj->pUFL->hOut;

    /* Make sure we have a non-0 pointer...  */
    if (pGlyphs == nil || pGlyphs->pGlyphIndices == nil || pGlyphs->sCount == 0)
        return retVal;

    /* Download the characters of the given string. */
    /* The main loop for downloading the glyphs.    */
    glyphs = pGlyphs->pGlyphIndices;

    /* Save a copy of Downloaded glpyh list - used to update CharStrings later. */
    UFLmemcpy((const UFLMemObj*)pUFObj->pMem,
                pUFObj->pAFont->pVMGlyphs,
                pUFObj->pAFont->pDownloadedGlyphs,
                (UFLsize_t)(GLYPH_SENT_BUFSIZE(UFO_NUM_GLYPHS(pUFObj))));

    totalGlyphs = 0;

    /* Keep track of composite glyphs that might of been downloaded. */
    compGlyphs.sMaxCount = pGlyphs->sCount* 2;
    compGlyphs.sCount =0;

    /* Update the charstring uses GoodNames only if the Encoding vector is nil. */
    if(pUFObj->pszEncodeName == nil)
        compGlyphs.pGlyphs = nil;
    else
        compGlyphs.pGlyphs =
            (unsigned short *)UFLNewPtr(pUFObj->pMem,
                                        compGlyphs.sMaxCount * sizeof (unsigned short));

    if ( compGlyphs.pGlyphs == nil)
    {
        compGlyphs.sMaxCount = 0;
    }

    for ( i = 0; kNoErr == retVal && i < pGlyphs->sCount; i++ )
    {
        wIndex = (unsigned short) glyphs[i] &0x0000FFFF ; /* LOWord is the real GID. */
        if (wIndex >= UFO_NUM_GLYPHS(pUFObj) )
            continue;

        if ( !IS_GLYPH_SENT( pUFObj->pAFont->pDownloadedGlyphs, wIndex ) )
        {
            if (pGlyphs->pCharIndex)
                cid = pGlyphs->pCharIndex[i];

            retVal = PutT42Char( pUFObj, wIndex, cid, &compGlyphs );
            SET_GLYPH_SENT_STATUS( pUFObj->pAFont->pDownloadedGlyphs, wIndex );
            totalGlyphs++;
        }
    }

    /* Make sure that .notdef is sent. */
    if ( kNoErr == retVal && pUFObj->flState >= kFontInit )
    {
        if ( !IS_GLYPH_SENT( pUFObj->pAFont->pDownloadedGlyphs, 0 ) )
        {
            cid = 0; /* Don't know its CID. */
            retVal = PutT42Char(pUFObj, 0x0000, cid, &compGlyphs);
            if ( kNoErr == retVal )
            {
                SET_GLYPH_SENT_STATUS( pUFObj->pAFont->pDownloadedGlyphs, 0 );
                totalGlyphs++;
            }
        }
    }

    /* Update the charstring uses GoodNames if the Encoding vector is nil. */
    if ((kNoErr == retVal) && (pUFObj->pszEncodeName == nil) && (totalGlyphs > 0))
    {
        /* CharStirng begins. */
        retVal = StrmPutString(stream, "/");
        if ( kNoErr == retVal )
            retVal = StrmPutString(stream, pUFObj->pszFontName);
        if ( kNoErr == retVal )
            retVal = StrmPutStringEOL(stream, " findfont /CharStrings get begin");

        /*
         * If we ran out of space in keeping with Composite Glyph Component,
         * then add composite component to Encoding the long way.
         */
        if (!compGlyphs.pGlyphs)
        {
            bAddCompGlyphAlternate = 1;
            compGlyphs.sCount = compGlyphs.sMaxCount =0;
        }

        /*
         * Update the CharStrings with all of the newly added Glyphs.
         * First go through the Main Glyph Index arrays.
         */
        for (i = 0; kNoErr == retVal && i < (pGlyphs->sCount + compGlyphs.sCount); i++)
        {
            // Get glyph index from either the regular glyphs list or the composite list.
            // LOWord is the read GID in either case.
            if ( i < pGlyphs->sCount)
                wIndex = (unsigned short) glyphs[i] & 0x0000FFFF;
            else
                wIndex = (unsigned short) compGlyphs.pGlyphs[i - pGlyphs->sCount] & 0x0000FFFF;

            if (wIndex >= UFO_NUM_GLYPHS(pUFObj) )
                continue;

            if ( (0 == pUFObj->pUFL->bDLGlyphTracking)
                    || (pGlyphs->pCharIndex == nil)    // DownloadFace
                    || (pUFObj->pEncodeNameList)       // DownloadFace
                    || !IS_GLYPH_SENT(pUFObj->pAFont->pVMGlyphs, wIndex) )
            {
                FindGlyphName(pUFObj, pGlyphs, i, wIndex, &pGoodName);

                // Fix bug 274008: check Glyph Name only for DownloadFace.
                if (pUFObj->pEncodeNameList)
                {
                    if ((UFLstrcmp( pGoodName, Hyphen ) == 0) && (i == 45))
                    {
                        // Add /minus to CharString.
                        UFLsprintf(tempStr, "/%s %d def", Minus, wIndex);
                        if ( kNoErr == retVal )
                            retVal = StrmPutStringEOL(stream, tempStr);
                    }
                    if ((UFLstrcmp( pGoodName, Hyphen ) == 0) && (i == 173))
                    {
                        // Add /sfthyphen to CharString.
                        UFLsprintf(tempStr, "/%s %d def", SftHyphen, wIndex);
                        if ( kNoErr == retVal )
                            retVal = StrmPutStringEOL(stream, tempStr);
                    }

                    if (!ValidGlyphName(pGlyphs, i, wIndex, pGoodName))
                        continue;

                    // Send only one ".notdef".
                    if ((UFLstrcmp( pGoodName, Notdef ) == 0)
                        && (wIndex == (unsigned short) (glyphs[0] & 0x0000FFFF))
                        && IS_GLYPH_SENT(pUFObj->pAFont->pVMGlyphs, wIndex))
                        continue;
                }

                if ( kNoErr == retVal )
                    retVal = StrmPutString(stream, "/");
                if ( kNoErr == retVal )
                    retVal = StrmPutString(stream, pGoodName);
                UFLsprintf(tempStr, " %d def", wIndex);

                if ( kNoErr == retVal )
                    retVal = StrmPutStringEOL(stream, tempStr);

                SET_GLYPH_SENT_STATUS( pUFObj->pAFont->pVMGlyphs, wIndex );
            }
        }

        // Do composite font this way only if we ran out of space.
        if (bAddCompGlyphAlternate)
        {
            /*
             * Now go through all VMGlyphs to see if there is any glyph are
             * downloaded as part of Composite glyph above. - fix bug 217228.
             * PPeng, 6-12-1997
             */
            for (wIndex  = 0; kNoErr == retVal && wIndex  < UFO_NUM_GLYPHS(pUFObj); wIndex++)
            {
                if ( (0 == pUFObj->pUFL->bDLGlyphTracking)
                     /* || (pGlyphs->pCharIndex == nil) */
                        || (IS_GLYPH_SENT(pUFObj->pAFont->pDownloadedGlyphs, wIndex)
                        && !IS_GLYPH_SENT(pUFObj->pAFont->pVMGlyphs, wIndex))
                )
                {
                    /* For composite glyphs, always try to use its good name. */
                    pHintName = nil;
                    pGoodName = GetGlyphName(pUFObj, (unsigned long) wIndex, pHintName);

                    retVal = StrmPutString(stream, "/");
                    if ( kNoErr == retVal )
                        retVal = StrmPutString(stream, pGoodName);
                    UFLsprintf(tempStr, " %d def", wIndex);

                    if ( kNoErr == retVal )
                        retVal = StrmPutStringEOL(stream, tempStr);

                    SET_GLYPH_SENT_STATUS( pUFObj->pAFont->pVMGlyphs, wIndex );
                }
            }
        }

        /* CharStirng end. */
        if ( kNoErr == retVal )
            retVal = StrmPutStringEOL(stream, "end");
    }

    /* Update the Encoding vector if we use GoodNames. */
    if ((kNoErr == retVal) && (pUFObj->pszEncodeName == nil) && (pGlyphs->sCount > 0))
    {
        /* Check pUFObj->pUpdatedEncoding to see if we really need to update it. */
        for ( i = 0; i < pGlyphs->sCount; i++ )
        {
            if ( (0 == pUFObj->pUFL->bDLGlyphTracking)
                    || (pGlyphs->pCharIndex == nil) // DownloadFace
                    || (pUFObj->pEncodeNameList)    // DownloadFace
                    || !IS_GLYPH_SENT( pUFObj->pUpdatedEncoding, pGlyphs->pCharIndex[i] ) )
            {
                // Found at least one not updated, do it (once) for all.
                retVal = UpdateEncodingVector(pUFObj, pGlyphs, 0, pGlyphs->sCount);
                break;
            }
        }
    }

    /* Update the FontInfo with Unicode information. */
    if ((kNoErr == retVal) && (pGlyphs->sCount > 0) && (pUFObj->dwFlags & UFO_HasG2UDict))
    {
        /* Check pUFObj->pAFont->pCodeGlyphs to see if we really need to update it. */
        for ( i = 0; i < pGlyphs->sCount; i++ )
        {
            wIndex = (unsigned short) glyphs[i] & 0x0000FFFF; /* LOWord is the real GID. */
            if (wIndex >= UFO_NUM_GLYPHS(pUFObj) )
                continue;

            if (!IS_GLYPH_SENT( pUFObj->pAFont->pCodeGlyphs, wIndex ) )
            {
                // Found at least one not updated, do it (once) for all.
                retVal = UpdateCodeInfo(pUFObj, pGlyphs);
                break;
            }
        }
    }

    if ( compGlyphs.pGlyphs )
    {
        UFLDeletePtr(pUFObj->pMem, compGlyphs.pGlyphs);
        compGlyphs.pGlyphs = nil;
    }

    return retVal;
}


UFLErrCode
T42VMNeeded(
    UFOStruct           *pUFObj,
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMNeeded,
    unsigned long       *pFCNeeded
    )
{
    unsigned long  vmUsed = 0;
    UFLBool        bFullFont;
    short          i;
    unsigned long  totalGlyphs;
    UFLErrCode     retVal = kNoErr;
    T42FontStruct  *pFont;
    UFLGlyphID     *glyphs;
    unsigned short wIndex;

    if (pUFObj->flState < kFontInit)
        return (kErrInvalidState);

    pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    if (pGlyphs == nil || pGlyphs->pGlyphIndices == nil || pVMNeeded == nil)
        return kErrInvalidParam;

    if ( pFCNeeded )
        *pFCNeeded = 0;

    *pVMNeeded = 0;

    glyphs = pGlyphs->pGlyphIndices;

    bFullFont = ( pGlyphs->sCount == -1 ) ? 1 : 0;

    if (( 0 == pFont->minSfntSize ) || (pFont->pHeader == nil))
        retVal = GetMinSfnt( pUFObj, bFullFont );

    if ( kNoErr == retVal )
    {
        /* Scan the list, check what characters that we have downloaded. */
        if ( !bFullFont )
        {
            UFLmemcpy( (const UFLMemObj* )pUFObj->pMem,
                        pUFObj->pAFont->pVMGlyphs,
                        pUFObj->pAFont->pDownloadedGlyphs,
                        (UFLsize_t)(GLYPH_SENT_BUFSIZE(UFO_NUM_GLYPHS(pUFObj))) );

            totalGlyphs = 0;

            for ( i = 0; i < pGlyphs->sCount; i++ )
            {
                wIndex = (unsigned short) glyphs[i] & 0x0000FFFF; /* LOWord is the real GID. */
                if (wIndex >= UFO_NUM_GLYPHS(pUFObj) )
                    continue;
                if ( !IS_GLYPH_SENT( pUFObj->pAFont->pVMGlyphs, wIndex ) )
                {
                    SET_GLYPH_SENT_STATUS( pUFObj->pAFont->pVMGlyphs, wIndex );
                    totalGlyphs++;
                }
            }
        }
        else
        {
            totalGlyphs = UFO_NUM_GLYPHS(pUFObj);
        }

        /*
         * Start with the size of the minimal sfnt if the header has not been
         * sent yet.
         */
        if (pUFObj->flState < kFontHeaderDownloaded)
        {
            vmUsed = pFont->minSfntSize;
        }

        /*
         * If incremental downloading and there are glyphs to check, add these
         * to total VMUsage of each glyph is the average size of each glyph in
         * the glyf table.
         */
        if ( bFullFont == 0 )
        {
            if ( GETPSVERSION(pUFObj) < 2015 )
            {
                /*
                 * For pre2015 printers, we need to pre-allocate VM for all
                 * Glyphs. The VM for whole font is allocated when the Header
                 * is Sent.
                 */
                if (pUFObj->flState < kFontHeaderDownloaded)
                {
                    vmUsed += GetGlyphTableSize( pUFObj );
                }
                else
                {
                    //
                    // After header is sent on pre-2015 printer, no more VM
                    // allocation for adding chars, so set to 0 -- VM for both
                    // Header and Glyph table are allocate already!
                    //
                    vmUsed = 0;
                }
            }
            else
            {
                if ( glyphs != nil )
                {
                    /* Check if this has been calculated yet. */
                    if (pFont->averageGlyphSize == 0)
                        GetAverageGlyphSize( pUFObj );
                    /* If this is still zero, there's a problem with the sfnt. */
                    if (pFont->averageGlyphSize == 0)
                        retVal = kErrBadTable;
                    else
                        vmUsed += totalGlyphs * pFont->averageGlyphSize;

                    // Fix bug 256940: make it compatible with 95 driver. jjia 7/2/98
                    if ((IS_TYPE42CID(pUFObj->lDownloadFormat))
                        && (pUFObj->flState < kFontHeaderDownloaded))
                    vmUsed += (UFO_NUM_GLYPHS(pUFObj)) * 2;
                }
            }
        }

        if ( kNoErr == retVal )
            *pVMNeeded = VMT42RESERVED( vmUsed );
    }

    return retVal;
}


UFLErrCode
DownloadFullFont(
    UFOStruct *pUFObj
    )
{
    UFLErrCode retVal = kNoErr;
    T42FontStruct *pFont = (T42FontStruct*)pUFObj;

    /*
     * Can only download full font if no header has been downloaded before.
     * The only possible state that meets this requirement is kFontInit.
     */
    if ( pUFObj->flState != kFontInit )
        return (kErrInvalidState);

    /* Create and  download the full font. */
    retVal = CreateBaseFont(pUFObj, 1 );

    if (retVal == kNoErr)
    {
        pUFObj->flState = kFontFullDownloaded;
    }

    return retVal;
}


/***************************************************************************
 *
 *                          DownloadIncrFont
 *
 *    Function: Adds all of the characters from pGlyphs that aren't already
 *              downloaded for the TrueType font.
 *
***************************************************************************/

UFLErrCode
T42FontDownloadIncr(
    UFOStruct           *pUFObj,
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMUsage,
    unsigned long       *pFCUsage
    )
{
    UFLErrCode      retVal = kNoErr;
    T42FontStruct   *pFont;

    if (pUFObj->flState < kFontInit)
        return (kErrInvalidState);

    if ( pFCUsage )
        *pFCUsage = 0;

    pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    if ( pUFObj->pUFL->outDev.pstream->pfDownloadProcset == 0 )
        return kErrDownloadProcset;

    if ( !pUFObj->pUFL->outDev.pstream->pfDownloadProcset(pUFObj->pUFL->outDev.pstream, kT42Header) )
        return kErrDownloadProcset;

    if ( IS_TYPE42CID_KEYEDFONT(pUFObj->lDownloadFormat) )
    {
        if ( !pUFObj->pUFL->outDev.pstream->pfDownloadProcset(pUFObj->pUFL->outDev.pstream, kCMap_FF) )
            return kErrDownloadProcset;
    }

    if ( pGlyphs == nil || pGlyphs->pGlyphIndices == nil)
       return kErrInvalidParam;

    /* Cannot download incrementally if the full font has already been downloaded. */
    if ( pUFObj->flState == kFontFullDownloaded )
        return kErrInvalidState;

    //
    // Check the VM usage - before sending the Header - on Pre-2015 printers,
    // VMUsage is 0 after the header is downloaded (pre-allocate).
    //
    retVal = T42VMNeeded( pUFObj, pGlyphs, pVMUsage, NULL ); /* NULL for pFCUsage */

    /* Create a base font if it has not been done before. */
    if ( pUFObj->flState == kFontInit )
    {
        retVal = CreateBaseFont( pUFObj, 0 );
        if ( retVal == kNoErr )
            pUFObj->flState = kFontHeaderDownloaded;
    }

    /* Download the glyphs. */
    if ( retVal == kNoErr )
        retVal = AddChars( pUFObj, pGlyphs);

    /* Change the font state. */
    if ( retVal == kNoErr )
        pUFObj->flState = kFontHasChars;

    return retVal;
}


UFLErrCode
T42UndefineFont(
    UFOStruct   *pUFObj
    )

/*++

    Send PS code to undefine fonts: /UDF and /UDR should be defined properly
    by client to something like:

    /UDF
    {
      IsLevel2
      {undefinefont}
      { pop }ifelse
    } bind def
    /UDR
    {
      IsLevel2
      {undefineresource}
      { pop pop }ifelse
    } bind def

--*/

{
    char          tempStr[100];
    UFLErrCode    retVal = kNoErr;
    UFLHANDLE     stream;
    short int     i;
    T42FontStruct *pFont;

    pFont = (T42FontStruct *) pUFObj->pAFont->hFont;

    if (pUFObj->flState < kFontHeaderDownloaded) return retVal;

    stream = pUFObj->pUFL->hOut;

    //
    // Send "/fontname undefinefont". IF CID/42, then undefine the CIDFont
    // resource first: (leave CMap in VM).
    //
    if ( IS_TYPE42CID_KEYEDFONT(pUFObj->lDownloadFormat) )
    {
        /*
         * Undefine CIDFont resources and CID-keyed font itself: there are 4
         * possible CIDFonts.
         *
         * e.g. /TT37820t0cid, /TT37820t0cidR, /TT37820t032K, /TT37820t032KR
         *
         * We can send "udefineresource" for them all since "undef" is very
         * forgiving, and one CID-keyed font: /TT3782053888t0.
         */
        for (i=0; i<NUM_CIDSUFFIX; i++)
        {
                UFLsprintf(tempStr, "/%s%s /CIDFont UDR",
                                pUFObj->pszFontName, gcidSuffix[i]);
                if ( kNoErr == retVal )
                    retVal = StrmPutStringEOL(stream, tempStr);
        }
    }

    // undefinefont
    if ( IS_TYPE42CIDFONT_RESOURCE(pUFObj->lDownloadFormat) )
    {
        UFLsprintf(tempStr, "/%s /CIDFont UDR", pUFObj->pszFontName);
    }
    else
    {
        UFLsprintf( tempStr, "/%s UDF", pUFObj->pszFontName );
    }

    if ( kNoErr == retVal )
        retVal = StrmPutStringEOL( stream, tempStr );

    return retVal;
}


UFOStruct*
T42FontInit(
    const UFLMemObj  *pMem,
    const UFLStruct  *pUFL,
    const UFLRequest *pRequest
    )
{
    UFOStruct        *pUFObj;
    T42FontStruct    *pFont;
    UFLTTFontInfo    *pInfo;
    long             maxGlyphs;

    /* MWCWP1 doesn't like the implicit cast from void* to UFOStruct*  --jfu */
    pUFObj = (UFOStruct*) UFLNewPtr( pMem, sizeof( UFOStruct ) );
    if (pUFObj == 0)
      return 0;

    /* Initialize data. */
    UFOInitData(pUFObj, UFO_TYPE42, pMem, pUFL, pRequest,
                (pfnUFODownloadIncr)  T42FontDownloadIncr,
                (pfnUFOVMNeeded)      T42VMNeeded,
                (pfnUFOUndefineFont)  T42UndefineFont,
                (pfnUFOCleanUp)       T42FontCleanUp,
                (pfnUFOCopy)          CopyFont );

    /* pszFontName should be ready/allocated - if not FontName, cannot continue. */
    if (pUFObj->pszFontName == nil || pUFObj->pszFontName[0] == '\0')
    {
      UFLDeletePtr(pMem, pUFObj);
      return nil;
    }

    pInfo = (UFLTTFontInfo *)pRequest->hFontInfo;

    maxGlyphs = pInfo->fData.cNumGlyphs;

    /* A convenience pointer used in GetNumGlyph() - must be set now. */
    pUFObj->pFData = &(pInfo->fData); /* Temporary assignment !! */
    if (maxGlyphs == 0)
      maxGlyphs = GetNumGlyphs( pUFObj );

    if ( NewFont(pUFObj, sizeof(T42FontStruct), maxGlyphs) == kNoErr )
    {
      pFont = (T42FontStruct*) pUFObj->pAFont->hFont;
      pFont->info = *pInfo;

      // Fix 309104
      pFont->nVObliqueElementIndex = pRequest->nT42VObliqueElementIndex;
      pFont->pszVObliqueTangentTheta = pRequest->pszT42VObliqueTangentTheta;

      /* A convenience pointer - set to the permanent one. */
      pUFObj->pFData = &(pFont->info.fData);  /* Real assignment to mem allocated by UFL. */

      /*
       * Get ready to find out correct glyphNames from "post" table -
       * set correct pFont->info.fData.fontIndex and offsetToTableDir.
       */
      if ( pFont->info.fData.fontIndex == FONTINDEX_UNKNOWN )
         pFont->info.fData.fontIndex = GetFontIndexInTTC(pUFObj);

      /* Get num of Glyphs in this TT file if not set yet. */
      if (pFont->info.fData.cNumGlyphs == 0)
         pFont->info.fData.cNumGlyphs = GetNumGlyphs( pUFObj );

      /* Copy or Set XUID array to our xuid structure. */
      if (pInfo->fData.xuid.sSize == 0)
      {
              /* sSize ==0 ==> UFL needs to figure out the XUID. */
              pUFObj->Xuid.sSize = CreateXUIDArray(pUFObj, nil);
              if (pUFObj->Xuid.sSize)
            /* MWCWP1 doesn't like the implicit cast from void* to unsigned long*  --jfu */
            pUFObj->Xuid.pXUID =
                     (unsigned long*) UFLNewPtr( pUFObj->pMem,
                                                   pUFObj->Xuid.sSize * sizeof(unsigned long) );
         if ( pUFObj->Xuid.pXUID )
         {
            pUFObj->Xuid.sSize = CreateXUIDArray(pUFObj, pUFObj->Xuid.pXUID);
         }
      }
      else
      {
         /* The XUID is passed in by client  - just copy it. */
         pUFObj->Xuid.sSize = pInfo->fData.xuid.sSize;

         if (pUFObj->Xuid.sSize)
            /* MWCWP1 doesn't like the implicit cast from void* to unsigned long*  --jfu */
            pUFObj->Xuid.pXUID =
                     (unsigned long*) UFLNewPtr( pUFObj->pMem,
                                                    pUFObj->Xuid.sSize * sizeof(unsigned long) );
         if ( pUFObj->Xuid.pXUID )
         {
            UFLmemcpy((const UFLMemObj* )pUFObj->pMem,
                            pUFObj->Xuid.pXUID,
                            pInfo->fData.xuid.pXUID,
                            pUFObj->Xuid.sSize * sizeof(unsigned long) );
         }
      }

      pFont->cNOtherTables    = 0;
      pFont->pHeader          = nil;
      pFont->pMinSfnt         = nil;
      pFont->pStringLength    = nil;
      pFont->pLocaTable       = nil;
      pFont->minSfntSize      = 0;
      pFont->averageGlyphSize = 0;
      pFont->pRotatedGlyphIDs = nil;

      if ( pUFObj->pUpdatedEncoding == 0 )
      {
         pUFObj->pUpdatedEncoding = (unsigned char *)UFLNewPtr(pMem, GLYPH_SENT_BUFSIZE(256));
      }

      if ( pUFObj->pUpdatedEncoding != 0 )  /* completed initialization */
         pUFObj->flState = kFontInit;
   }

   return pUFObj;
}

static unsigned long
GetLenByScanLoca(
    void PTR_PREFIX *locationTable,
    unsigned short  wGlyfIndex,
    unsigned long   cNumGlyphs,
    int             iLongFormat
    )
{
    unsigned long GlyphLen = 0;
    unsigned long i;
    unsigned long nextGlyphOffset = 0xFFFFFFFF;

    if (iLongFormat)
    {
        unsigned long PTR_PREFIX *locaTableL = locationTable;

        for (i=0; i<cNumGlyphs; i++)
        {
            if ( (MOTOROLALONG(locaTableL[i]) > MOTOROLALONG(locaTableL[wGlyfIndex])) &&
                 (MOTOROLALONG(locaTableL[i]) < nextGlyphOffset) )
            nextGlyphOffset = MOTOROLALONG(locaTableL[i]);
        }

        if ( nextGlyphOffset != 0xFFFFFFFF)
            GlyphLen = nextGlyphOffset - MOTOROLALONG(locaTableL[wGlyfIndex]);
    }
    else
    {
        unsigned short PTR_PREFIX *locaTableS = locationTable;

        for (i=0; i<cNumGlyphs; i++)
        {
            if ( (MOTOROLAINT(locaTableS[i]) > MOTOROLAINT(locaTableS[wGlyfIndex])) &&
                 (MOTOROLAINT(locaTableS[i]) < nextGlyphOffset) )
                nextGlyphOffset = MOTOROLAINT(locaTableS[i]);
        }

        if ( nextGlyphOffset != 0xFFFFFFFF)
            GlyphLen = (nextGlyphOffset - MOTOROLAINT(locaTableS[wGlyfIndex])) * 2;
    }
    return GlyphLen;
}
