/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: FILE.C                                                       */
/*                                                                           */
/* Description: This module contains the functions for file usage            */
/*                                                                           */
/*****************************************************************************/

#include "ps.h"         // Also includes PRINT.H, WINDOWS.H, GDIDEFS.INC etc..
#include "errors.h"

//these are primarily for debug purposes
//LATER: make this compiler switch dependent
#define ERecordError(a,b,c,d) 
#define CHECKFILENAME(lpz)  if(lpz==0L || lpz[0]=='\0'){ERecordError(E_file,EFILE_name,NULL,0);return(-1);}
#define CHECKFILEHANDLE(h)  if(h<0){ERecordError(E_file,EFILE_handle,NULL,0);return(0);}
#define CHECKFILEHANDLEL(h) if(h<0){ERecordError(E_file,EFILE_handle,NULL,0);return(0L);}
#define CHECKFILEHANDLEV(h) if(h<0){ERecordError(E_file,EFILE_handle,NULL,0);return;}

FLAG FAR PASCAL FExists(LPSTR lpzFile)
{
     SHORT hFile=_lopen(lpzFile,READ);

     if(hFile<0){
          return(FALSE);
     }
     _lclose(hFile);
     return(TRUE);
}

SHORT FAR PASCAL FCreate(LPSTR lpzFile,SHORT sMode)
{
     SHORT hFile;
     
     //LATER: if lpzFile=0L, or lpzFile="", the create a temp file
     //                  and return the name
     CHECKFILENAME(lpzFile);

     hFile=_lcreat(lpzFile,sMode);
     if(hFile<0){
          ERecordError(E_file,EFILE_create,lpzFile,lstrlen(lpzFile)+1);
     }
     return(hFile);
}
SHORT FAR PASCAL FOpen(LPSTR lpzFile,SHORT sMode)
{
     SHORT hFile;
     
     CHECKFILENAME(lpzFile);

     hFile=_lopen(lpzFile,sMode);
     if(hFile<0){
          ERecordError(E_file,EFILE_open,lpzFile,lstrlen(lpzFile)+1);
     }
     return(hFile);
}
SHORT FAR PASCAL FWrite(SHORT hFile,LP lp,SHORT sNumToWrite)
{
     register SHORT sNumWritten;

     CHECKFILEHANDLE(hFile);
     
     sNumWritten=_lwrite(hFile,lp,sNumToWrite);
     if(sNumWritten<sNumToWrite){
          ERecordError(E_file,EFILE_write,NULL,0) ;
     }
     return(sNumWritten);
}
SHORT FAR PASCAL FWriteMultiple(SHORT hFile,LP lp,SHORT sLen,SHORT sNum)
{
     /* perhaps have to do something different.  There is the
      * possiblility that sLen*sNum will be > 32K.
      */
     return(FWrite(hFile,lp,sLen*sNum));
}
DWORD FAR PASCAL FWriteMega(SHORT hFile,LP lp,DWORD dLen,DWORD dNum)
{
     register SHORT i;
     register SHORT sNumIterations;
     SHORT sRemainder;
     DWORD dNumWritten=0L;
     DWORD dNumToWrite=dLen*dNum;
     register DWORD dOffset;
     
     CHECKFILEHANDLEL(hFile);
     
     if(dNumToWrite<=0x0000ffff){
          dNumWritten=(DWORD)FWrite(hFile,lp,(SHORT)dNumToWrite);
     }else{
          sNumIterations=(WORD)(dNumToWrite/0x00007fff);
          sRemainder=(WORD)(dNumToWrite%0x00007fff);
          for(i=0,dOffset=0L;i<sNumIterations;i++){
               dNumWritten+=(DWORD)FWrite(hFile,&lp[dOffset],(SHORT)0x7fff);
               if(dNumWritten<0x00007fff) goto DONE;
               //if(EIsError()) goto DONE;
               dOffset+=0x00007fff;
          }
          dNumWritten+=(DWORD)FWrite(hFile,&lp[dOffset],sRemainder);
     }
DONE:
     return(dNumWritten);
}

FLAG FAR PASCAL FWriteChar(SHORT hFile,CHAR c)
{
     register SHORT sNumWritten;
     
     CHECKFILEHANDLE(hFile);
     
     if((sNumWritten=_lwrite(hFile,(LP)&c,sizeof(CHAR)))<sizeof(CHAR)){
          ERecordError(E_file,EFILE_write,NULL,0) ;
          return(FALSE);
     }
     return(TRUE);
}
FLAG FAR PASCAL FWriteShort(SHORT hFile,SHORT s)
{
     register SHORT sNumWritten;
     
     CHECKFILEHANDLE(hFile);
     
     if((sNumWritten=_lwrite(hFile,(LP)&s,sizeof(SHORT)))<sizeof(SHORT)){
          ERecordError(E_file,EFILE_write,NULL,0) ;
          return(FALSE);
     }
     return(TRUE);
}
FLAG FAR PASCAL FWriteLong(SHORT hFile,LONG l)
{
     register SHORT sNumWritten;
     
     CHECKFILEHANDLE(hFile);
     
     if((sNumWritten=_lwrite(hFile,(LP)&l,sizeof(LONG)))<sizeof(LONG)){
          ERecordError(E_file,EFILE_write,NULL,0) ;
          return(FALSE);
     }
     return(TRUE);
}
SHORT FAR PASCAL FRead(SHORT hFile,LP lp,SHORT sNumToRead)
{
     register SHORT sNumRead;

     CHECKFILEHANDLE(hFile);
     
     sNumRead=_lread(hFile,lp,sNumToRead);
     if(sNumRead<sNumToRead){
          ERecordError(E_file,EFILE_read,NULL,0) ;
     }
     return(sNumRead);
}
SHORT FAR PASCAL FReadMultiple(SHORT hFile,LP lp,SHORT sLen,SHORT sNum)
{
     register SHORT sNumRead;
     register SHORT sNumToRead=sLen*sNum;
     
     CHECKFILEHANDLE(hFile);
     
     sNumRead=_lread(hFile,lp,sNumToRead);
     if(sNumRead<sNumToRead){
          ERecordError(E_file,EFILE_read,NULL,0) ;
     }
     return(sNumRead);
}
DWORD FAR PASCAL FReadMega(SHORT hFile,LP lp,DWORD dLen,DWORD dNum)
{
     register SHORT i;
     register SHORT sNumIterations;
     SHORT sRemainder;
     DWORD dNumRead=0L;
     DWORD sNumToRead=dLen*dNum;
     register DWORD dOffset;
     
     CHECKFILEHANDLEL(hFile);
     
     if(sNumToRead<=0x0000ffff){
          dNumRead=(DWORD)FRead(hFile,lp,(SHORT)sNumToRead);
     }else{
          sNumIterations=(WORD)(sNumToRead/0x00007fff);
          sRemainder=(WORD)(sNumToRead%0x00007fff);
          for(i=0,dOffset=0L;i<sNumIterations;i++){
               dNumRead+=(DWORD)FRead(hFile,&lp[dOffset],(SHORT)0x7fff);
               if(dNumRead<0x00007fff) goto DONE;
               //if(EIsError()) goto DONE;
               dOffset+=0x00007fff;
          }
          dNumRead+=(DWORD)FRead(hFile,&lp[dOffset],sRemainder);
     }
DONE:
     return(dNumRead);
}
CHAR FAR PASCAL FReadChar(SHORT hFile)
{
     CHAR c;
     register SHORT sNumRead;
     
     CHECKFILEHANDLE(hFile);
     
     if((sNumRead=_lread(hFile,(LPCHAR)&c,sizeof(CHAR)))<sizeof(CHAR)){
          ERecordError(E_file,EFILE_read,NULL,0) ;
     }
     return(c);
}
SHORT FAR PASCAL FReadShort(SHORT hFile)
{
     SHORT s;
     register SHORT sNumRead;
     
     CHECKFILEHANDLE(hFile);
     
     if((sNumRead=_lread(hFile,(LPCHAR)&s,sizeof(SHORT)))<sizeof(SHORT)){
          ERecordError(E_file,EFILE_read,NULL,0) ;
     }
     return(s);
}
LONG FAR PASCAL FReadLong(SHORT hFile)
{
     LONG l;
     register SHORT sNumRead;
     
     CHECKFILEHANDLEL(hFile);
     
     if((sNumRead=_lread(hFile,(LPCHAR)&l,sizeof(LONG)))<sizeof(LONG)){
          ERecordError(E_file,EFILE_read,NULL,0) ;
     }
     return(l);
}
LONG FAR PASCAL FSeek(SHORT hFile,LONG lOffset,SHORT sOrigin)
{
     register LONG lNewFilePosition;
     
     CHECKFILEHANDLEL(hFile);
     
     lNewFilePosition=_llseek(hFile,lOffset,sOrigin);
     if(lNewFilePosition<0){
          ERecordError(E_file,EFILE_seek,NULL,0);
     }
     return(lNewFilePosition);
}
SHORT FAR PASCAL FClose(SHORT hFile)
{
     CHECKFILEHANDLE(hFile);
     
     hFile=_lclose(hFile);
     if(hFile<0){
          ERecordError(E_file,EFILE_close,NULL,0);
     }
     return(hFile);
}
SHORT FAR PASCAL FDelete(LPSTR lpzFile)
{
     //LATER: there must be a better way than this!
     // I wonder what kind of drugs the MS guys were
     // on when they thought of this?

     OFSTRUCT of;

     of.cBytes=sizeof(OFSTRUCT);
     of.fFixedDisk=TRUE;
     of.nErrCode=0;
     of.szPathName[0]='\0';

     //a return of -1 should indicate an error condition
     //
     return(OpenFile(lpzFile,(LPOFSTRUCT)&of,OF_DELETE));
}

