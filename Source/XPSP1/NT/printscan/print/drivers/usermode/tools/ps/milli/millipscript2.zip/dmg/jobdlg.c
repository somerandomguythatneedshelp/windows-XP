/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: JOBDLG.C                                                     */
/*                                                                           */
/* Description: This module contains the functions for ExitServer jobs       */
/*                                                                           */
/* Change History:                                                           */
/* L3_CLIP -- Level3 clipsave cliprestore support.  9/13/96  jjia            */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_DIALOGSSEG)

// This function is defined in TRAN\theader.c:
BOOL FAR PASCAL GetKeyVal(HKEY hv, LPSTR path_key, LPSTR val_key, LPSTR buffer, long *cl);

/*****************************************************************************/
/*                 DoHeaderDownloading                                       */
/* Purpose:                                                                  */
/*   This function attempts to download the full header to the port          */
/*                                                                           */
/* Parameters:                                                               */
/*   LPDRIVERINFO lpDrvInfo -- points to DRIVERINFO                          */
/*                                                                           */
/* Returns: short                                                            */
/*   short -- RC_ok or RC_fail                                               */
/*****************************************************************************/

short FAR PASCAL DoHeaderDownloading(LPDRIVERINFO lpDrvInfo)
{
    short retval;
    WORD pslen, wLen;
    LPSTR psptr = NULL;
    LPSTR         lpRes;
    HANDLE hMem, hJob, pshandle;
    HDC hDC;
    char tempstr[256];
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;
    LPPDEVICE      lppd = &lpDrvInfo->pDev;
    int i;
    BOOL bExitServer = FALSE;

    // headerResID[] contains all Resource IDs send in the middle of the header
    // JCL--Midlle--JCL  -- This structure is more easily extendable. 10-3-95
    int  headerResID[]={
#ifndef ADOBEPS42
        PSPROC_utils0_ps1,
        PSPROC_utils1_ps1,
        PSPROC_utils2_ps1,
        PSPROC_nup_ps1, 
        PSPROC_fatalerr_ps1,
        PSPROC_textenc_ps1, 
        PSPROC_text_ps1, 
        PSPROC_textbold_ps1,
        PSPROC_graph0_ps1, 
        PSPROC_graph1_ps1, 
        PSPROC_graph2_ps1, 
        PSPROC_imagebw0_ps1, 
        PSPROC_imagebw1_ps1, 
        PSPROC_imageco1_ps1, 
        PSPROC_imageco2_ps1, 
        PSPROC_type3hdr_ps1, 
        PSPROC_type1hdr_ps1, 
        PSPROC_rledecode,
        PSPROC_compat_ps1,
        PSPROC_type0hdr_ps1,  //PSPROC_type0hdr_ps2 is the same
        PSPROC_kanji_ps1,    // fix bug 163124
        PSPROC_kanji2_ps1,        

        // We may need to query the languages supported on the host
        // to only download 1 or 2 (Korean) cmaps. -- after renaming the procsetName
        PSPROC_cmap_128_ps2,  // for level 2 - CIDFont only
        PSPROC_cmap_129_ps2,
        PSPROC_cmap_130_ps2,
        PSPROC_cmap_134_ps2,
        PSPROC_cmap_136_ps2,
        PSPROC_cmap_FFFF_ps2,
#else
        PSPROC_utils0_ps2,
        PSPROC_utils2_ps2,
        PSPROC_nup_ps2, 
        PSPROC_fatalerr_ps1,
        PSPROC_text_ps2,
        PSPROC_textenc_ps2, // Fix bug 177259. Text should be downloaded before Encoding.
        PSPROC_textbold_ps2,
#ifdef ADD_EURO
        PSPROC_euro_ps2,
#endif

        PSPROC_graph0_ps2, 
        PSPROC_graph1_ps1, 
        PSPROC_imagebw0_ps2, 
        PSPROC_imageco2_ps2, 
        PSPROC_ufl_type3hdr_ps2, 
        PSPROC_type1hdr_ps2,
#ifdef  T3OUTLINE
        PSPROC_type3olhdr_ps2,
#endif
        PSPROC_compat_ps2,
        PSPROC_type0hdr_ps2,  //PSPROC_type0hdr_ps2 is the same
        PSPROC_kanji_ps2,    // send kanji.ps, fix bug 163124
        PSPROC_kanji2_ps2,
        
        // We may need to query the languages supported on the host
        // to only download 1 or 2 (Korean) cmaps. -- after renaming the procsetName
        PSPROC_cmap_128_ps2,  // for level 2 - CIDFont only
        PSPROC_cmap_129_ps2,
        PSPROC_cmap_130_ps2,
        PSPROC_cmap_134_ps2,
        PSPROC_cmap_136_ps2,
        PSPROC_cmap_FFFF_ps2,
        // fix bug 198997. jjia  3/17/97 
        PSPROC_textenc_ps2,
        PSPROC_greek_encoding,
        PSPROC_turkish_encoding,
        PSPROC_hebrew_encoding,
        PSPROC_arabic_encoding,
        PSPROC_baltic_encoding,
        PSPROC_russian_encoding,
        PSPROC_ee_encoding,
#endif
        };

    retval = OpenPrntrMgr(lppd->szPortName,"Header",&hJob,&hDC);
    if (retval == RC_userabort)
       return(retval);
    
    if (retval == RC_ok)
    {

        // Send protocol invocations -- if necessary
        
        // Send PJL, for PJL capable printers
        if (lpPrinterInfo->devcaps.PJLsupport)
        {
            pslen = CopyStringRefToLPBYTE(lppd->lpWPXblock, tempstr, ((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->JCLinfo.JCLBegin.dword);
            WritePrntrMgr((LPSTR)tempstr, pslen, hJob);
            pslen = CopyStringRefToLPBYTE(lppd->lpWPXblock, tempstr, ((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->JCLinfo.JCLToPSInterpreter.dword) ;
            WritePrntrMgr((LPSTR)tempstr, pslen, hJob);
        }
        // Send a CR, LF
        wLen = LoadString(ghDriverMod, PSFRAG_crlf, tempstr, sizeof(tempstr));
        if (wLen > 0)
            retval = WritePrntrMgr(tempstr, wLen, hJob);
        else
            retval = RC_fail;
        
        switch (lpPSExtDevmode->dm2.iDataOutputFormat)
        {
            case PROTOCOL_TBCP:
                // send ^AM for TBCP
                WritePrntrMgr((LPSTR)"\001M",2,hJob);
                break;
                
            case PROTOCOL_BCP:
            case PROTOCOL_ASCII:
                if (lpPSExtDevmode->dm2.bSendCtrlDBefore)
                {
                    // send a ^D protocol
                    WritePrntrMgr((LPSTR)"\004",1,hJob);
                }
                break;
        }
    }
    
    // Send some DSC comments
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(DSC_exitserver,hJob);

    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_1,hJob);

    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_2,hJob);
// DSC 3.1 DSC_requirements is deleted
//    if (retval == RC_ok)
//        retval = WritePrntrMgrLine(DSC_requirements,hJob);
    // No language features are required, so no need for something
    // after %%Requirements: .

    if (retval == RC_ok)
//        retval = WritePrntrMgrLine(DSC_docneedres,hJob);
// Use DSC 3.1 comments
        retval = WritePrntrMgrLine(DSC_docneededres,hJob);

    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_3,hJob);

    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_4,hJob);

    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_5,hJob);

    if (retval == RC_ok)
        retval = WritePrntrMgrLine(DSC_endcomments,hJob);

    // Send the PostScript for password
    pslen = 
        lpPrinterInfo->password.w.length;
    psptr = MGAllocLock(lppd, &pshandle,(DWORD)(pslen+1), GHND, FALSE);
    if (psptr != NULL)
        pslen = CopyStringRefToLPBYTE(lppd->lpWPXblock, psptr,
             lpPrinterInfo->password.dword);
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_6, hJob);

    if (retval == RC_ok)
    {
        retval = WritePrntrMgr(psptr, pslen, hJob);
        wLen = LoadString(ghDriverMod, PSFRAG_crlf, tempstr, sizeof(tempstr));
        if (wLen > 0)
            retval = WritePrntrMgr(tempstr,wLen, hJob);
        else
            retval = RC_fail;
    }
    
//    if (psptr != NULL)
//        MGUnlockFree(lppd, pshandle, FALSE);

//    psptr = NULL;
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_8,hJob);

    // Send the PostScript for ExitServer
    wLen = lpPrinterInfo->exitServer.w.length;

    // send %%BeginExitServer: (password)
    
    if (wLen > 0 ) // start the exitserver
    {
	     if (!lpPrinterInfo->password.dword)
        {
           lstrcpy( tempstr, psptr);
           retval = WritePrntrMgrDSC(DSC_beginexitserver, tempstr,hJob);
        }
        else  // use (Password)
        {
           lstrcpy(tempstr, (LPSTR)"(Password)");
           retval = WritePrntrMgrDSC(DSC_beginexitserver,tempstr, hJob);     
        }
        bExitServer = TRUE;
    }
    if (psptr != NULL)
        MGUnlockFree(lppd, pshandle, FALSE);
    
    psptr = MGAllocLock(lppd, &pshandle, (DWORD)(wLen+1), GHND, FALSE);
    if (psptr != NULL)
        pslen = CopyStringRefToLPBYTE(lppd->lpWPXblock, psptr,
           lpPrinterInfo->exitServer.dword);

//    if (retval == RC_ok)
//        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_7,hJob);

    if (pslen > 0)
    {
        retval = WritePrntrMgr(psptr, pslen, hJob);
        wLen = LoadString(ghDriverMod, PSFRAG_crlf, tempstr, sizeof(tempstr));
        if (wLen > 0)
            retval = WritePrntrMgr(tempstr,wLen, hJob);
        else
            retval = RC_fail;
    }
    if ( bExitServer )
        retval = WritePrntrMgrLine(DSC_endexitserver,hJob);

    if (psptr != NULL)
        MGUnlockFree(lppd, pshandle, FALSE);

//    if (retval == RC_ok)
//        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_8,hJob);

#ifndef ADOBEPS42
    // Now send the header for the L1/L2 compatibility header (Level 1 header)
    if (retval == RC_ok)
    {
        retval = GetResource(PSPROC_resemul_ps1, &lpRes, &wLen, &hMem);
        if (retval == RC_ok)
        {
            retval = WritePrntrMgr(lpRes, wLen, hJob);
         RemoveResource(hMem);
        }
    }
#endif

    if (retval == RC_ok)
    {
        // %% BeginResource: procset MS_Win_Driver 2.0 0
        // Fix bug 177406. DSC clean up: Do not use hard coded DSC string. jjia 10/14/96
        wLen = LoadString(ghDriverMod, PSFRAG_dscbeginresource, tempstr, sizeof(tempstr));
        retval = WritePrntrMgrDSC(DSC_beginresource, tempstr, hJob);
		      }
    
    if (retval == RC_ok)
    {
        // /MS_Win_Driver 200 dict dup begin
        retval = WritePrntrMgrLine(PSFRAG_declaredict, hJob);
    }
    
//// Begin Middle Resource -Use a loop to send all - Used to be many blocks.
    for (i=0; i < sizeof(headerResID)/sizeof(headerResID[0]); i++){
       if (retval == RC_ok)
       {
          retval = GetResource(headerResID[i], &lpRes, &wLen, &hMem);
          if (retval == RC_ok)
          {
            retval = WritePrntrMgr(lpRes, wLen, hJob);
            RemoveResource(hMem);
          }
       }
       else break;   // If any one fails, then not to continue Just as before.
    }
//// End-middle

/// Special Level-2 resource.
    if (retval == RC_ok)
    {
        if (lpPrinterInfo->devcaps.TTRasterizer == TTRAST_TYPE42)
        { 
            retval = GetResource(PSPROC_ufl_type42_ps2, &lpRes, &wLen, &hMem);
            if (retval == RC_ok)
            {
                retval = WritePrntrMgr(lpRes, wLen, hJob);
                RemoveResource(hMem);
            }
        }
    }
//// End-Specail Level-2 code

/// L3_CLIP
/// Level-3 resource.
    if (retval == RC_ok)
    {
        BOOL  Level3Clip = (GetPSVersion(lppd) >= 3000);
        if (Level3Clip)
        { 
            retval = GetResource(PSPROC_clipsave_ps3, &lpRes, &wLen, &hMem);
            if (retval == RC_ok)
            {
                retval = WritePrntrMgr(lpRes, wLen, hJob);
                RemoveResource(hMem);
            }
        }
    }
//// End Level-3 code

    // end /ProcSet defineresource pop
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_enddefresource, hJob);

    // %% EndResource
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(DSC_endresource, hJob);

    // Calibrated RGB procset resource
    // Always send it.  It gets invoked on a job-by-job basis.
    
    // /MS_Win_Driver /ProcSet findresource begin
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_beginprocset, hJob);

#ifndef ADOBEPS42
    if (retval == RC_ok)
        retval = GetResource(PSPROC_calrgb_ps1, &lpRes, &wLen, &hMem);

    if (retval == RC_ok)
    {
        retval = WritePrntrMgr(lpRes, wLen, hJob);
        RemoveResource(hMem);
    }
#endif

    // end
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_end,hJob);

    // %%EOF
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(DSC_eof,hJob);

    if (retval == RC_ok)
    {
        // Send JobTrailer protocol invocations -- if necessary
        
        switch (lpPSExtDevmode->dm2.iDataOutputFormat)
        {
            case PROTOCOL_TBCP:
                // send "ESC%-12345X"
                WritePrntrMgr((LPSTR)"\033%-12345X", 9, hJob);
                break;
                
            case PROTOCOL_BCP:
            case PROTOCOL_ASCII:
                if (lpPSExtDevmode->dm2.bSendCtrlDAfter)
                {
                    // send a trailing CONTROL D
                    WritePrntrMgr((LPSTR)"\004", 1, hJob);
                }
                break;
        }

        // Send a CR, LF
        wLen = LoadString(ghDriverMod, PSFRAG_crlf, tempstr, sizeof(tempstr));
        if (wLen > 0)
            retval = WritePrntrMgr(tempstr, wLen, hJob);
        else
            retval = RC_fail;

        // Send PJL, for PJL capable printers
        if (lpPrinterInfo->devcaps.PJLsupport)
        {
            pslen = CopyStringRefToLPBYTE(lppd->lpWPXblock, tempstr, ((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->JCLinfo.JCLEnd.dword) ;
            WritePrntrMgr((LPSTR)tempstr, pslen, hJob);
        }
    }
    
    ClosePrntrMgr(hJob,hDC);
    
    return(retval);
}

/****************************************************************************
*
*                       SwitchBetweenAsciiAndBinary
*  Purpose:
*       This function attempts to download PS which sets the printer into
*       binary mode or ascii mode (depending on keyword PRNMODE) to the
*       port stored in Devmode.
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice ptr
*
*  Returns:
*       short -- RC_ok or RC_fail
*
****************************************************************************/
short NEAR PASCAL SwitchBetweenAsciiAndBinary(LPDRIVERINFO lpDrvInfo, WORD wFlag) 
{
    short retval;
   
    WORD pslen, wLen;
    HANDLE pshandle;
    LPSTR psptr = NULL;
    LPSTR         lpRes;
    char tempstr[256];
    HANDLE  hJob , hMem;
    HDC hDC;
    BOOL bExitServer = FALSE;

    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;
    LPPDEVICE      lppd = &lpDrvInfo->pDev;

    retval = OpenPrntrMgr(lppd->szPortName, "Header", &hJob, &hDC);

    if (retval == RC_ok)
    {
      // Send protocol invocations -- if necessary

      // Send PJL, for PJL capable printers
      if (lpPrinterInfo->devcaps.PJLsupport)
      {
         pslen = CopyStringRefToLPBYTE(lppd->lpWPXblock, tempstr,
            lpPrinterInfo->JCLinfo.JCLBegin.dword);
         WritePrntrMgr((LPSTR)tempstr, pslen, hJob);
         pslen = CopyStringRefToLPBYTE(lppd->lpWPXblock, tempstr,
            lpPrinterInfo->JCLinfo.JCLToPSInterpreter.dword) ;
         WritePrntrMgr((LPSTR)tempstr, pslen, hJob);
      }
      // Send a CR, LF
      wLen = LoadString(ghDriverMod, PSFRAG_crlf, tempstr, sizeof(tempstr));
      if (wLen > 0)
         retval = WritePrntrMgr(tempstr, wLen, hJob);
      else
         retval = RC_fail;

      // Send JobHEader protocol invocations -- if necessary
      if (wFlag & PS_CTRL_D_BEFORE_MODE)
      {
          // send a ^D protocol
          WritePrntrMgr((LPSTR)"\004",1,hJob);
      }
   }

    // do some DSC comments
    if (retval == RC_ok)
       retval = WritePrntrMgrLine(DSC_exitserver, hJob);

    // %%Title: (Prolog)  -- not correct but here is a placeholder
    // if (retval == RC_ok)
    //    retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_1, hJob);

    // %%Creator: PostScript Driver .... 
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_2, hJob);
// DSC 3.1 DSC_requirements is deleted
//    if (retval == RC_ok)
//        retval = WritePrntrMgrLine(DSC_requirements, hJob);
    // No language features are required, so no need for something
    // after %%Requirements: .

    if (retval == RC_ok)
//        retval = WritePrntrMgrLine(DSC_docneedres, hJob);
// Use DSC 3.1 comments
        retval = WritePrntrMgrLine(DSC_docneededres, hJob);

    // %%DocumentData: Clean7Bit
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_4, hJob);

    // %%LanguageLevel: 1
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_5, hJob);

    // %%EndComments
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(DSC_endcomments, hJob);

    // if binary == TRUE do BEG_BCP (ascii -> binary) else
    //    (binary == FALSE) do END_BCP (binary -> ascii).
    if (retval == RC_ok)
    {
        // do BEG_BCP or END_BCP
        retval = GetResource((wFlag & PS_BCP_MODE) ? PSPROC_beg_bcp : PSPROC_end_bcp,
                             &lpRes,&wLen, &hMem);
       if (retval == RC_ok)
       {
          retval = WritePrntrMgr(lpRes,wLen, hJob);
          RemoveResource(hMem);
       }
    }

   // Send the PostScript for password
   pslen = lpPrinterInfo->password.w.length;
   psptr = MGAllocLock(lppd, &pshandle,(DWORD)(pslen+1), GHND, FALSE);
   if (psptr != NULL)
      pslen = CopyStringRefToLPBYTE(lppd->lpWPXblock, psptr,
               lpPrinterInfo->password.dword);
   if (retval == RC_ok)
      retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_6, hJob);

   if (retval == RC_ok)
   {
      retval = WritePrntrMgr(psptr, pslen, hJob);
      wLen = LoadString(ghDriverMod, PSFRAG_crlf, tempstr, sizeof(tempstr));
      if (wLen > 0)
         retval = WritePrntrMgr(tempstr,wLen, hJob);
      else
         retval = RC_fail;
   }

//    if (psptr != NULL)
//        MGUnlockFree(lppd, pshandle, FALSE);

//    psptr = NULL;
    if (retval == RC_ok)
        retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_8,hJob);

    // Send the PostScript for ExitServer
    wLen = lpPrinterInfo->exitServer.w.length;

    // send %%BeginExitServer: (password)
    
    if (wLen > 0 ) // start the exitserver
    {
	     if (!lpPrinterInfo->password.dword)
        {
           lstrcpy( tempstr, psptr);
           retval = WritePrntrMgrDSC(DSC_beginexitserver, tempstr,hJob);
        }
        else  // use (Password)
        {
           lstrcpy(tempstr, (LPSTR)"(Password)");
           retval = WritePrntrMgrDSC(DSC_beginexitserver,tempstr, hJob);     
        }
        bExitServer = TRUE;
    }
    if (psptr != NULL)
        MGUnlockFree(lppd, pshandle, FALSE);
    

//   if (retval == RC_ok)
//      retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_8, hJob);

   psptr = MGAllocLock(lppd, &pshandle, (DWORD)(wLen+1), GHND, FALSE);
   if (psptr != NULL)
      pslen = CopyStringRefToLPBYTE(lppd->lpWPXblock, psptr,
               lpPrinterInfo->exitServer.dword);

//   if (retval == RC_ok)
//      retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_7,hJob);

   if (retval == RC_ok)
   {
      retval = WritePrntrMgr(psptr, pslen, hJob);
      wLen = LoadString(ghDriverMod, PSFRAG_crlf, tempstr, sizeof(tempstr));
      if (wLen > 0)
         retval = WritePrntrMgr(tempstr,wLen, hJob);
      else
         retval = RC_fail;
   }
  
   if ( bExitServer )
        retval = WritePrntrMgrLine(DSC_endexitserver,hJob);

   if (psptr != NULL)
      MGUnlockFree(lppd, pshandle, FALSE);

  // if (retval == RC_ok)
  //    retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_8,hJob);

  //if (retval == RC_ok)
  //    retval = WritePrntrMgrLine(PSFRAG_DOWNHEAD_7, hJob);

   // now put out the second half of the appropriate procset
   // if binary == TRUE do BEG_BCP_A (ascii -> binary) else
   //    (binary == FALSE) do END_BCP_A (binary -> ascii).
   if (retval == RC_ok)
   {
       // do BEG_BCP or END_BCP
       retval = GetResource((wFlag & PS_BCP_MODE) ? PSPROC_beg_bcp_A : PSPROC_end_bcp_A,
                            &lpRes,&wLen, &hMem);
      if (retval == RC_ok)
      {
         retval = WritePrntrMgr(lpRes,wLen, hJob);
         RemoveResource(hMem);
      }
   }

   // %%EOF
   if (retval == RC_ok)
      retval = WritePrntrMgrLine(DSC_eof, hJob);

   if (retval == RC_ok)
   {
      // Send JobTrailer protocol invocations -- if necessary
      if (wFlag & PS_CTRL_D_AFTER_MODE)
      {
          // send a trailing CONTROL D
          WritePrntrMgr((LPSTR)"\004", 1, hJob);
      }

      // Send a CR, LF
      wLen = LoadString(ghDriverMod, PSFRAG_crlf, tempstr, sizeof(tempstr));
      if (wLen > 0)
         retval = WritePrntrMgr(tempstr, wLen, hJob);
      else
         retval = RC_fail;

      // Send PJL, for PJL capable printers
      if (lpPrinterInfo->devcaps.PJLsupport)
      {
         pslen = CopyStringRefToLPBYTE(lppd->lpWPXblock, tempstr,
            lpPrinterInfo->JCLinfo.JCLEnd.dword) ;
         WritePrntrMgr((LPSTR)tempstr, pslen, hJob);
      }
   }

    ClosePrntrMgr(hJob, hDC);
    return(retval);
}

/****************************************************************************
*
*                       DoSwitchBetweenAsciiAndBinary
*  Purpose:
*       This function attempts to download PS which sets the printer into
*       binary mode or ascii mode (depending on keyword PRNMODE) to the
*       port stored in Devmode.
*
*  Parameters:
*       LPPDEVICE lppd -- pdevice ptr
*
*  Returns:
*       short -- RC_ok or RC_fail
*
****************************************************************************/
short NEAR PASCAL DoSwitchBetweenAsciiAndBinary(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    WORD	wFlag = 0;

    // Note : We come into this function only if Ascii or BCP is chosen.
    if (IsDlgButtonChecked(hDlg, ID_ADV_BCP))
       wFlag |= PS_BCP_MODE;
    if (IsDlgButtonChecked(hDlg,ID_ADV_CTRL_D_BEFORE))
       wFlag |= PS_CTRL_D_BEFORE_MODE;
    if (IsDlgButtonChecked(hDlg,ID_ADV_CTRL_D_AFTER))
       wFlag |= PS_CTRL_D_AFTER_MODE;
    return (SwitchBetweenAsciiAndBinary(lpDrvInfo, wFlag));
}


// OEMPLUGI begin
short FAR PASCAL DoSwitchBetweenAsciiAndBinaryStub(LPDRIVERINFO lpDrvInfo, WORD wFlag)
{
  return(SwitchBetweenAsciiAndBinary(lpDrvInfo, wFlag));
}
// OEMPLUGI end


