/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ENUMOBJ.H                                                    */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/

short NEAR PASCAL EnumPen  (LP lpDevice,FARPROC lpCallbackProc,LP lpClientData);
short NEAR PASCAL EnumBrush(LP lpDevice,FARPROC lpCallbackProc,LP lpClientData);
short _loadds FAR  PASCAL EnumObj  (LP lpDevice,short sStyle,
                                    FARPROC lpCallbackProc,
                                    LP lpClientData);
