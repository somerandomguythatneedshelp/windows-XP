/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: DRVSTATE.H                                             */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

#if 0
BOOL FAR PASCAL Ps_GetPPDIntValue(LPPDEVICE lppd,LPSTR szKey,int FAR * value,
                                                         LPSTR nickname);
#endif

short FAR PASCAL GetPPDPaperMetrics(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode);
short FAR PASCAL GetCurrentResolution(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode,
                                      int FAR * X_Res, int FAR * Y_Res);
void FAR PASCAL AdjustResolution(LPPSEXTDEVMODE lpPSExtDevmode, 
				 LPINT res_x, LPINT res_y,
				 LPPOINT lpPoint);
short FAR PASCAL SetCTMatrix(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode,
			     LPPOINT ptCorner);
void DefaultPStoGDI(LPPSMATRIX  matrix, LPSHORT  x, LPSHORT  y);
void GDItoDefaultPS(LPPSMATRIX  matrix, LPSHORT  x, LPSHORT  y);
void FAR PASCAL  GDIorderRect(LPRECT  lpImageRect);
WORD FAR PASCAL DrvStateRead(LPPDEVICE, LPPSEXTDEVMODE);

