/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DLGID.H                                                      */
/*                                                                           */
/* Description: This module contains                                         */
/*                                                                           */
/*****************************************************************************/

#define IDDS_DEVMODE_CAPTION   -11191
#define IDDS_DIALECT_FIRST     -5037
#define IDDS_DIALECT_LAST      -5033
#define IDDS_MANUAL_FEED       -5032
#define IDDS_AUTOTRAYSELECT    -5031
#define IDDS_MIXEDBINS         -5030
#define IDDS_CUSTOMPAGE        -5029

#define IDOK                   1
#define IDCANCEL               2
#define IDIGNORE               5
#define NUM_ITEMS              11
#define ID_HELP                50
#define ID_PRNTR               51
#define ID_OUTPUTFMT_STATIC    101
#define ID_OPTIONS             110
#define ID_ABOUT               111
#define ID_PSLEVEL1            112
#define ID_PSLEVEL2            113
#define ID_ADD_PRNTR           114
#define ID_DEL_PRNTR           115
#define ID_TRUE_TYPE           118
#define ID_DEFAULT_MARGINS     200
#define ID_NO_MARGINS          201
#define ID_COMPRESSION         202
#define ID_OPTIONS2            205
#define ID_RESOURCES           206
#define ID_COLOR_CALIBRATE     207
#define ID_FAX_ENABLE          208
#define ID_FAX_CONFIGURE       209
#define ID_COLOR_ENABLE        210
#define ID_DEVICES             211
#define ID_FONTS               214
#define ID_JOB_CONTROL         215
#define ID_LEVEL2_GB           217
#define ID_MATCH_COLOR         219
#define ID_PROTOCOL_GB         220
#define ID_DEFAULT_PROTOCOL    221
#define ID_NONE_PROTOCOL       222
#define ID_JC_HANDSHAKE        231
#define ID_HANDSHAKE_HW        232
#define ID_HANDSHAKE_SW        233
#define ID_HEADER_GB           234
#define ID_ERROR_HNDLR_GB      237
#define ID_SEND_HANDSHAKE      238
#define ID_JC_ASCII_MODE       240
#define ID_JC_BINARY_MODE      241
#define ID_JC_SEND_MODE        242
#define ID_JC_HELP             243
#define ID_JC_PRNMODE_GB       245
#define ID_NOFONTS_GB          247
#define ID_NOFONTSDOWN         248
#define ID_CUST_X_OFFSET       253
#define ID_CUST_Y_OFFSET       254
#define CUST_X_SIZE            255
#define CUST_Y_SIZE            256
#define CUST_SIZE_BUTTON       257
#define PRINT_MODE_TEXT        258
#define ID_CP_INCHES           260
#define ID_CP_MILLIMETERS      261
#define ID_CP_UNITS            262
#define ID_SCROLL_ITEMS        300
#define ID_ITEM1               301
#define ID_ITEM2               302
#define ID_ITEM3               303
#define ID_ITEM4               304
#define ID_ITEM5               305
#define ID_ITEM6               306
#define ID_ITEM7               307
#define ID_ITEM8               308
#define ID_ITEM9               309
#define ID_ITEM10              310
#define ID_ITEM11              311
#define ID_ITEM1_VALUE         350
#define ID_ITEM2_VALUE         351
#define ID_ITEM3_VALUE         352
#define ID_ITEM4_VALUE         353
#define ID_ITEM5_VALUE         354
#define ID_ITEM6_VALUE         355
#define ID_ITEM7_VALUE         356
#define ID_ITEM8_VALUE         357
#define ID_ITEM9_VALUE         358
#define ID_ITEM10_VALUE        359
#define ID_ITEM11_VALUE        360
#define ID_PPDLIST             400
#define ID_PPDNAME             401
#define ID_PPDPATH             402
#define ID_PPD_DIR_LB          405
#define ID_INSTALL             410
#define ID_PICKNICK            411
#define ID_PICKNICK_PROMPT     420
#define ID_NICKLIST            421
#define ID_PS_PERF_GB          500
#define ID_PS_PERF_SPEED_RB    501
#define ID_PS_PERF_PORT_RB     502

/* Chicago begin */
#define ID_RESTORE_DEFAULTS    600

#define ID_LEFTMARGINE_RANGE   601
#define ID_RIGHTMARGINE_RANGE  602
#define ID_TOPMARGINE_RANGE    603
#define ID_BOTTOMMARGINE_RANGE 604

#define ID_TEXT_LEFTMARGINE    605
#define ID_TEXT_RIGHTMARGINE   606
#define ID_TEXT_TOPMARGINE     607
#define ID_TEXT_BOTTOMMARGINE  608
#define ID_LEFT_MARGIN         609
#define ID_RIGHT_MARGIN        610
#define ID_TOP_MARGIN          611
#define ID_BOTTOM_MARGIN       612
#define ID_USER_MARGINS        613
#define ID_PR_MEM_HELP_TEXT    614
#define ID_DONT_CLEAR_VM       615
#define ID_CLEAR_VM            616

#define ID_GROUP_DIMENSION     618
#define ID_VAL_WIDTH           619
#define ID_VAL_HEIGHT          620
#define ID_VAL_TOP             621
#define ID_VAL_BOTTOM          622
#define ID_VAL_LEFT            623
#define ID_VAL_RIGHT           624

#define ID_TEXT_WIDTH          702
#define ID_TEXT_HEIGHT         703
#define ID_TEXT_TOP            704
#define ID_TEXT_BOTTOM         705
#define ID_TEXT_LEFT           706
#define ID_TEXT_RIGHT          707

#define ID_RESOLUTION_STATIC            710
#define ID_RESOLUTION_CB                711
#define ID_COLOR_GROUP                  712
#define ID_COLOR_NO_MATCHING            713
#define ID_COLOR_USE_MATCHING           714 
#define ID_COLOR_ALWAYSICM              715 
// RS
#define ID_COLOR_CHOOSE_METHOD          716
// RS
// #define ID_HALFTONE_GROUP               716
// #define ID_GR_DONT_CHANGE               717
// #define ID_GR_USE_BELOW                 718
// #define ID_TEXT_SCREENFREQ              719
// #define ID_SCREENFREQUENCY              720
// #define ID_SCREENFREQUENCY_SPN          721
// #define ID_TEXT_SCREENANGLE             722
// #define ID_SCREENANGLE                  723
// #define ID_SCREENANGLE_SPN              724
// RS

#define ID_SPECIAL_GROUP                725
#define ID_ICON_NM                      726
#define ID_PRINTNEGATIVE                727
#define ID_PRINTMIRROR                  728
#define ID_SCALING_TEXT                 729
#define ID_SCALE                        730
#define ID_SCALE_SPN                    731
#define ID_TEXT_PERCENT                 732
#ifdef ADOBE_DRIVER  
#define ID_PAPER_HANDLING_GROUP         733
#define ID_GRAPHICS_PICTURE             734
#define ID_PRINT_PAGE_BORDER            735
#define ID_LAYOUT_STATIC                736            
#define ID_LAYOUTLIST                   737
#endif

#define ID_COMMUNICATIONS               740
#define ID_CUST_NAME                    741
#define ID_CUST_X_OFFSET_RANGE          742
#define ID_CUST_Y_OFFSET_RANGE          743
#define ID_CUST_X_RANGE                 744
#define ID_CUST_Y_RANGE                 745
#define ID_CUST_TRANSVERSE              746
#define ID_TEXT_CUST_X_SIZE             747
#define ID_TEXT_CUST_Y_SIZE             748
#define ID_OFFSET_GROUP                 749

#define ID_FONTS_EDIT_TABLE             750
#define ID_FONTS_SEND_TT_AS_PB          751
#define ID_FONTS_USE_TABLE              752
#define ID_FONTS_USE_PRINTER_FONTS      753
#define ID_FONTS_ALWAYS_DOWNLOAD_TT     754

#ifndef ADOBE_DRIVER_42
#define ID_ADV_LEVEL_1                  755
#define ID_ADV_LEVEL_2                  756
#define ID_ADV_COMPRESS                 757
#define ID_ADV_NO_COMPRESS              758
#else
#define ID_ADV_TEXT_LEVEL               755
#endif

#define ID_ADV_ASCII                    759
#define ID_ADV_BCP                      760
#define ID_ADV_TBCP                     761
#define ID_ADV_BINARY                   762
#define ID_ADV_SEND_MODE                763
#define ID_ADV_CTRL_D_BEFORE            764
#define ID_ADV_CTRL_D_AFTER             765

#define ID_ADV_TITLE                    766
#define ID_ADV_LEVEL                    767

#ifndef ADOBE_DRIVER_42
#define ID_ADV_BMP_CMP                  768
#else
#define ID_ADV_LEVEL_SPN                768
#endif

#define ID_ADV_DATA_FMT                 769
#ifdef ADOBE_DRIVER
#define ID_ADV_ALERT                    770
#endif

#define ID_FONTS_UPDATE                 771     // new button in Fonts Page
#define ID_FONTS_ADD_EURO               772 
 
#define IDS_UNITS_INCHES                800
#define IDS_UNITS_MILLIMETERS           801
#define IDS_TITLE_PAGE                  802
#define IDS_SUGGEST_MEMORY              803

#define IDS_OUTLINES                    804
#define IDS_BITMAPS                     805
#define IDS_NATIVE                      806
#define IDS_USE_PRINTER_HALFTONE        807
#define IDS_TITLE_USE_DEFAULTS          808
#define IDS_NUM_COPIES_CHANGED          809
#define IDS_TITLE_DRIVER                810
#define IDS_BASE_CUSTOM_NAME            811
#define IDS_CUSTOM_OTHER_PAPER          812
#ifdef Adobe_Driver
#define IDS_WRONG_OEM_DLL_VERSION       813
#endif


#if 0
#define ID_COLOR_8BIT                   820
#define ID_COLOR_FULL_COLOR             821
#define ID_COLOR_HOST_COLOR             822
#define ID_COLOR_MATCH_ACROSS_PRINTERS  823
#define ID_COLOR_PRINTER_CALIBRATION    824
#define ID_COLOR_HOST_CALIBRATION       825
#endif
/* Chicago end */

#define ID_LEFT_MARGIN_SPN              850
#define ID_RIGHT_MARGIN_SPN             851
#define ID_TOP_MARGIN_SPN               852
#define ID_BOTTOM_MARGIN_SPN            853

#define ID_CUST_X_OFFSET_SPN            872
#define ID_CUST_Y_OFFSET_SPN            873
#define CUST_X_SIZE_SPN                 874
#define CUST_Y_SIZE_SPN                 875
#define ID_CUST_X_OFFSET_TEXT           876
#define ID_CUST_Y_OFFSET_TEXT           877

#define ID_CM_GROUP                     889
#define ID_CM_NONE                      890
#define ID_CM_HOST                      891
#define ID_CM_PRINTER                   892
#define ID_CM_ICM                       893
#define ID_CM_TEXT1                     894
#define ID_CM_TEXT2                     895
#define ID_CM_TEXT3                     896

#define ID_INTENT_GROUP                 900
#define ID_CM_SATURATION                901
#define ID_CM_CONTRAST                  902
#define ID_CM_COLORMETRIC               903
#define ID_CM_ABSCOLORMETRIC            904

#ifdef PROOFING
#define ID_PROOFING_GROUP               910
#define ID_CM_PROOFING                  911
#define ID_CM_TEXT_PROFILE              912
#define ID_CM_PROFILE_CB                913
#define ID_CM_PROFILE_PROPERTIES        914
#endif

#define ID_FONTS_SEND_PS_AS             950
#define ID_FONTS_SEND_TT_AS             951
#define ID_TEXT_THRESHOLD               952
#define ID_FONTS_THRESHOLD              953
#define ID_FONTS_FAVOR_TT               954
#define ID_FONT_TEXT1                   955
#define ID_FONT_TEXT2                   956
#define ID_FONT_TEXT3                   957
#define ID_FONT_TEXT4                   958
#define ID_SUPPRESS_DEVFONTS            959
#define ID_FONTS_THRESHOLD_SPN          960
// added for italian driver UI.
#define ID_FONT_TEXT5                   961

#define ID_PREF_CHAR                    971
#define ID_PREF_WHOLE                   972
#define ID_PREF_FAST                    973
#define ID_PREF_EUDC                    974
    
#define ID_TEXT_SIZELIST            1500
#define ID_SIZENAME                 1501
#define ID_SIZELIST                 1502
#define ID_TEXT_COPIES              1503
#define ID_COPIES                   1504
#define ID_COPIES_SPN               1505
#define ID_CUSTOM_PAPER             1506
#define ID_MARGINS                  1507
#define ID_TEXT_SOURCELIST          1508
#define ID_SOURCELIST               1509 
#define ID_GROUP_PAPER_CONTROL      1510
#define ID_PAPER_PICTURE            1511
#define ID_COLLATE                  1512
#define ID_REVERSE_ORDER            1513
#define ID_TEXT_DUPLEXLIST          1514
#define ID_DUPLEXLIST               1515 
#ifdef ADOBE_DRIVER                 
#define ID_GROUP_ORIENTATION        1523
#define ID_ICON                     1524
#define ID_LOGO                     1525
#define ID_PORTRAIT                 1526
#define ID_LANDSCAPE                1527
#define ID_ROTATED                  1528
#define ID_PAPER_ADVANCED           1529
#else
#define ID_GROUP_ORIENTATION        1517
#define ID_ICON                     1518
#define ID_PORTRAIT                 1519
#define ID_LANDSCAPE                1520
#define ID_ROTATED                  1521
#define ID_PAPER_ADVANCED           1522
#endif

#define ID_TEXT_OUTPUTFMT           1550
#define ID_OUTPUTFMT                1551
#define ID_PS_HDR_GROUP             1552
#define ID_PS_HDR_DOWNLOAD          1553
#define ID_PS_HDR_ALREADY           1554
#define ID_DOWNLOAD_HEADER          1555
#define ID_ERROR_HANDLER            1556
#define ID_TIMEOUT_GROUP            1557
#define ID_JOB_TIMEOUT              1558
#define ID_JOB_TIMEOUT_SPN          1559
#define ID_TEXT_JOBTIMEOUT          1560
#define ID_TEXT_SECONDS1            1561
#define ID_WAIT_TIMEOUT             1562
#define ID_WAIT_TIMEOUT_SPN         1563
#define ID_TEXT_WAITTIMEOUT         1564
#define ID_TEXT_SECONDS2            1565
#define ID_ADVANCED                 1566

#define ID_TEXT_PRINTER_VM          1570
#define ID_PRINTER_VM               1571
#define ID_PRINTER_VM_SPN           1572
#define ID_PRINTER_FEATURES         1573
#define ID_DEVICE_LISTBOX           1574
#define ID_CHANGE_PRINTER_FEATURES  1575
#define ID_ACTIVE_ITEM              1576
#define ID_ACTIVE_ITEM_VALUE        1577

#define ID_INSTALLABLE_OPTIONS      1580
#define ID_DEV_I_OPT_LISTBOX        1581
#define ID_CHANGE_I_OPT             1582
#define ID_DEV_I_OPT_ACTIVE_ITEM    1583
#define ID_DEV_I_OPT_ACTIVE_ITEM_VALUE 1584 

#define CH_CUSTOMPAPER              5000
#define CH_CUSTOMOTHERPAPER         5001
#define CH_MARGINS                  5002
#define CH_COLOR_METHOD             5003
#define CH_ADVANCED                 5004
#define CH_MORE_PAPER               5005

#define CH_UICDIALOG                1200
#define ID_UIC_TITLE                1201
#define ID_UIC_GROUP                1202
#define ID_SELECTION1               1203
#define ID_SELECTION2               1204
#define ID_CANCEL_OPTION            1205
#define ID_IGNORE_OPTION            1206
#define ID_OK_OPTION                1207
#define ID_UIC_EDITBOX              1208
#define ID_OPTION1                  1209
#define ID_OPTION2                  1210

#define ID_TEXT_TYPELIST            1540
#define ID_TYPELIST                 1541
#define ID_TEXT_BINLIST             1542
#define ID_BINLIST                  1543
#define ID_SEPARATOR                1544

#define ID_VERSION                  1545
#define ID_DRIVERFILES              1546

#ifdef ADOBE_DRIVER
#define IDD_EDITWATERMARK       1600  // Dialog ID
#define ID_WATERMARK_TEXT       1602
#define ID_WATERMARK_FONT       1603
#define ID_WATERMARK_SIZE       1604
#define ID_WATERMARK_SIZESPN     1605
#define ID_WATERMARK_STYLE      1606
#define ID_WATERMARK_ANGLE      1607
#define ID_WATERMARK_ANGLESPN    1608
#define ID_WATERMARK_ANGLE_TRACKBAR 1609
#define ID_WATERMARK_RED               1610
#define ID_WATERMARK_REDSPN         1611
#define ID_WATERMARK_GREEN              1612
#define ID_WATERMARK_GREENSPN         1613
#define ID_WATERMARK_BLUE              1614
#define ID_WATERMARK_BLUESPN          1615
#define ID_WATERMARK_CHOOSECOLOR    1616
#define ID_WATERMARK_AUTOCENTER    1617
#define ID_WATERMARK_RELCENTER     1618
#define ID_WATERMARK_XPOS              1619
#define ID_WATERMARK_XPOSSPN          1620
#define ID_WATERMARK_YPOS              1621
#define ID_WATERMARK_YPOSSPN          1622
#define ID_WATERMARK_PREVIEW          1623
#define ID_TEXT_WM_SIZE             1624
#define ID_TEXT_WM_ANGLE            1625
#define ID_TEXT_WM_XPOS             1626
#define ID_TEXT_WM_YPOS             1627
#define ID_TEXT_WM_RED              1628
#define ID_TEXT_WM_GREEN            1629
#define ID_TEXT_WM_BLUE             1630

#define ID_WATERMARK_LIST            1631
#define ID_WATERMARK_EDIT            1632
#define ID_WATERMARK_NEW             1633
#define ID_WATERMARK_DELETE       1634
#define ID_WATERMARK_FIRSTPAGEONLY  1635
#define ID_WATERMARK_BACKGROUND    1636
#define ID_WATERMARK_OUTLINE          1637
#define ID_WATERMARK_DISPLAY          1638

#define IDD_WMDEL               1640
#define IDC_WMDNAME             1641

#define IDC_WM_UNIT             1642

#define ID_ALERT_FEATURE        1651
#define ID_ALERT_TRY                1652
#define ID_ALERT_PRINT          1653
#define ID_ALERT_ABORT          1654
#define ID_ALERT_STATIC         1655

#define CH_LOSESOFTFONTS_DLG    1660
#define ID_LOSESOFTFONTS_ICON   1661
#define ID_LOSESOFTFONTS_TEXT   1662

#define ID_TEXT_PRINTER_FONTCACHE   1670
#define ID_PRINTER_FONTCACHE        1671
#define ID_PRINTER_FONTCACHE_SPN    1672

#define IDD_PROFILE_PROPERTIES   1680
#define IDC_CP_DESC              1681
#define IDC_CP_ADDITIONAL        1682
#define IDC_CP_CPRT              1683
#define IDD_DESPOOLERR           1684
#define IDS_DESPOOLER            1685
#define IDS_DSPERRMSG            1686
#define IDC_DSPERRMSG            1687
#endif
