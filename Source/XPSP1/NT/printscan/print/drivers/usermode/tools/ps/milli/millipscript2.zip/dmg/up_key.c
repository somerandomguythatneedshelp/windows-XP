/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: UP_KEY.C                                                     */
/*                                                                           */
/* Description: Update old Microsoft Pscript printer installations to the    */
/*              new Adobe Pscript                                            */
/*                                                                           */
/*****************************************************************************/

#include "ps.h"         // Also includes PRINT.H, WINDOWS.H, GDIDEFS.INC etc..

#include "string.h"
#include "glstatic.h"
#include "errors.h"
#include "resrcid.h"
#include "truetype.h"
#include "upgrade.h"
#include "chicago.h"
#include "paper.h"

/*****************************************************************************/
/* Prototypes for routines used in this module only                          */
/*****************************************************************************/

short FAR PASCAL PPDCreateRealParamKeyword(HANDLE pihdl, int keyword_id,
   float fval, float lo_lim, float hi_lim) ;

/*****************************************************************************/
/*                 fnAddPageSize                                             */
/* Purpose:                                                                  */
/*   Call back function for the enumeration of printer paper sizes in order  */
/*   to create options for the storage of paper margin values.               */
/*                                                                           */
/* Parameters:                                                               */
/*   LPSTR keyword -- keyword we are enumerating options for                 */
/*   LPSTR option -- current option being enumerated                         */
/*   LPSTR option_translation -- translation string for this option          */
/*   short job_section -- job section (not used)                             */
/*   float order_num -- order number (not used)                              */
/*   LPSTR user_data -- hPrinter (handle to printer)                         */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE  => if success                                                     */
/*   FALSE => if failure                                                     */
/*****************************************************************************/

BOOL FAR PASCAL fnAddPageSize(LPSTR keyword, LPSTR option, LPSTR option_translation,
   short job_section, float order_num, LPSTR user_data)
{
#if 0
  HANDLE hPrinter;
  short enum_rc;
  char keyword2[MAX_KEYWORD_LEN] ;
  char pageSizeData[32];

  hPrinter = *((HANDLE FAR *)user_data);

  enum_rc = Ps_PPDGetKeywordOptionPS(hPrinter, keyword, option, 
                                     pageSizeData, sizeof(pageSizeData));

  if (enum_rc == PS_RC_OK)
    {
    LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_MARGINS, keyword2, sizeof(keyword2));
    enum_rc = Ps_PPDCreateKeywordOption(hPrinter, keyword2, option, NULL, 
                                        pageSizeData,
                                        DEF_JOB_SECTION, DEF_JOB_ORDER_NUM) ;
    }

  if (enum_rc == PS_RC_OK)
    return (TRUE);
  else
    return (FALSE);
#else
  return FALSE;
#endif
}

/************************************************************************/
/* This is a new reoutine that's needed to create keywords to support   */
/* Miscrosoft's pscript features. -jmk                                  */
/************************************************************************/

/*****************************************************************************/
/*                 PPDInitPrinterRecMicrosoft                                */
/* Purpose:                                                                  */
/*   Creates synthesized keywords to take care of new capabilities needed    */
/*   due to the conversion of pscript printers to AdobePS format as well     */
/*   as brand new capabilities being added.                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HANDLE hPrinter -- enumerator handle to the printer                     */
/*                                                                           */
/* Returns: short                                                            */
/*   RC_ok if success                                                        */
/*   RC_fail if failure                                                      */
/*****************************************************************************/

short FAR PASCAL PPDInitPrinterRecMicrosoft(HANDLE hPrinter)
{
#if 0
  short rc = RC_ok ;
  short enum_rc = PS_RC_OK;
  char keyword[MAX_KEYWORD_LEN] ;
  char option[MAX_OPTION_LEN] ;
  int i;
  float lo_lim, hi_lim, fval;
  char strBuff[64], strBuff2[64];

  if (enum_rc == PS_RC_OK);
    enum_rc = PPDCreateBinaryKeyword(hPrinter,ID_PPDSTR_KEY_MS_FAVORTT, FALSE);

  if (enum_rc == PS_RC_OK);
    enum_rc = PPDCreateBinaryKeyword(hPrinter,ID_PPDSTR_KEY_MS_TRANSVERSE, FALSE);

  if (enum_rc == PS_RC_OK);
    enum_rc = PPDCreateBinaryKeyword(hPrinter,ID_PPDSTR_KEY_MS_PRINTNEGATIVE, FALSE);

  if (enum_rc == PS_RC_OK);
    enum_rc = PPDCreateBinaryKeyword(hPrinter,ID_PPDSTR_KEY_MS_PRINTMIRROR, FALSE);

  if (enum_rc == PS_RC_OK);
    enum_rc = PPDCreateBinaryKeyword(hPrinter,ID_PPDSTR_KEY_MS_COMPRESS_BM, TRUE);

  if (enum_rc == PS_RC_OK);
    enum_rc = PPDCreateBinaryKeyword(hPrinter,ID_PPDSTR_KEY_MS_CLEAR_VM_PP, FALSE);

  if (enum_rc == PS_RC_OK);
    enum_rc = PPDCreateIntParamKeyword(hPrinter, ID_PPDSTR_KEY_MS_MIN_OUTLINE,
      MIN_OUTLINE_PPEM_DEF, MIN_OUTLINE_PPEM_LOW, MIN_OUTLINE_PPEM_HIGH);

  if (enum_rc == PS_RC_OK);
    {
    float defMemory;

    /* Get default memory from VMOption if it exists - John Kwan */
    defMemory = -1;

    LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_INSTALLEDMEMORY,keyword,sizeof(keyword));
    enum_rc = Ps_PPDGetKeywordOption(hPrinter, keyword, option,
                                     sizeof(option), NULL, 0);
    if (enum_rc == PS_RC_OK)
      { /* Installed memory exists */
      LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_VMOPTION, keyword, sizeof(keyword));
      enum_rc = Ps_PPDGetKeywordOptionPS(hPrinter, keyword, option,
                                         strBuff, sizeof(strBuff));

      if (enum_rc == PS_RC_OK)
        {
        defMemory = LPAToF(strBuff);
        }
      }
    else
      enum_rc == PS_RC_OK; /* Restore its ok value */

    if (defMemory < 0)
      { /* Couldn't get it from VMOption */
      /* Get default memory from FreeVM if it exists */
      LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_FREEVM, keyword, sizeof(keyword));
      enum_rc = Ps_PPDGetKeywordOptionPS(hPrinter, keyword, NULL,
                                         strBuff, sizeof(strBuff));
      if (enum_rc == PS_RC_OK)
        {
        defMemory = LPAToF(strBuff);
        }
      }

    if (defMemory < 0)
      { /* Ordinary default is last resort */
      defMemory = PRINTER_VM_DEF;
      }

    enum_rc = PPDCreateRealParamKeyword(hPrinter, ID_PPDSTR_KEY_MS_PRINTER_VM,
              defMemory, PRINTER_VM_LOW, PRINTER_VM_HIGH);
    }

   /* Create keyword and options for color usage */
   LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_COLOR, keyword, sizeof(keyword));
   enum_rc = Ps_PPDCreateKeyword(hPrinter, keyword, NULL, KWTYPE_NORMAL, 0) ;
   i = COLOR_FIRST ;
   while ((i <= COLOR_LAST) && (enum_rc == PS_RC_OK))
     {
     LoadDrvrString(ghDriverMod, ID_PPDSTR_BASE_COLOR+i, option,sizeof(option));
     enum_rc = Ps_PPDCreateKeywordOption(hPrinter, keyword, option, NULL, NULL,
                                         DEF_JOB_SECTION, DEF_JOB_ORDER_NUM) ;

     /* Set the default */
     if ((enum_rc == PS_RC_OK) && (i == COLOR_GRAYSCALE))
       enum_rc = Ps_PPDSetKeywordOption(hPrinter, keyword, option) ;
     i++ ;
     }

   /* Create keyword and options for layout */
   LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_LAYOUT, keyword, sizeof(keyword));
   enum_rc = Ps_PPDCreateKeyword(hPrinter, keyword, NULL, KWTYPE_NORMAL, 0) ;
   i = LAYOUT_FIRST ;
   while ((i <= LAYOUT_LAST) && (enum_rc == PS_RC_OK))
     {
     LoadDrvrString(ghDriverMod, ID_PPDSTR_BASE_LAYOUT+i, option,sizeof(option));
     enum_rc = Ps_PPDCreateKeywordOption(hPrinter, keyword, option, NULL, NULL,
                                         DEF_JOB_SECTION, DEF_JOB_ORDER_NUM) ;

     /* Set the default */
     if ((enum_rc == PS_RC_OK) && (i == LAYOUT_1_UP))
       enum_rc = Ps_PPDSetKeywordOption(hPrinter, keyword, option) ;
     i++ ;
     }

   /* Create keyword and options for multiple custom paper */
   LoadDrvrString(ghDriverMod,ID_PPDSTR_KEY_CUSTOMPAGE, keyword, sizeof(keyword));
   enum_rc = Ps_PPDGetKeywordOption(hPrinter, keyword, option,
                                    sizeof(option), NULL, 0) ;
   if (enum_rc == PS_RC_OK)
     {
     LoadDrvrString(ghDriverMod,ID_PPDSTR_KEY_CUSTOMPAGEPARAMS, keyword, sizeof(keyword));
     LoadDrvrString(ghDriverMod,ID_PPDSTR_PARAM_WIDTH,option, sizeof(option));
     enum_rc = Ps_PPDGetKeywordParamVal(hPrinter, keyword, option, PARAM_REAL, &fval, sizeof(float));
     }

   if (enum_rc != PS_RC_DATA_NOT_FOUND)
     { /* We are allowed custom page */
     /* Do the widths */
     LoadDrvrString(ghDriverMod,ID_PPDSTR_KEY_CUSTOMPAGEPARAMS, keyword, sizeof(keyword));
     LoadDrvrString(ghDriverMod,ID_PPDSTR_PARAM_WIDTH,option, sizeof(option));
     Ps_PPDGetKeywordParamVal(hPrinter, keyword, option, PARAM_REAL, &fval, sizeof(float));
     Ps_PPDGetKeywordParamBnds(hPrinter, keyword, option, PARAM_REAL, &lo_lim, &hi_lim);

     LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_CUSTOMWIDTH, keyword, sizeof(keyword));
     if (enum_rc == PS_RC_OK)
       enum_rc = Ps_PPDCreateKeyword(hPrinter, keyword, NULL, KWTYPE_PARAM, 0) ;
     LoadDrvrString(ghDriverMod, IDS_CUSTOM_SIZE_OPTION, strBuff, sizeof(strBuff));
     i = CUSTOM_FIRST ;
     while ((i <= CUSTOM_LAST) && (enum_rc == PS_RC_OK))
       {
       wsprintf(option, strBuff, i);
       enum_rc = Ps_PPDCreateKeywordParam(hPrinter, keyword, option, NULL,
                                          PARAM_REAL, sizeof(float));

       if (enum_rc == PS_RC_OK)
         enum_rc = Ps_PPDSetKeywordParamBnds(hPrinter, keyword, option,
                                             PARAM_REAL, &lo_lim, &hi_lim) ;
       if (enum_rc == PS_RC_OK)
         enum_rc = Ps_PPDSetKeywordParamVal(hPrinter, keyword, option,
                                            PARAM_REAL, &fval) ;
       i++ ;
       }

     /* Do the heights */
     LoadDrvrString(ghDriverMod,ID_PPDSTR_KEY_CUSTOMPAGEPARAMS, keyword, sizeof(keyword));
     LoadDrvrString(ghDriverMod,ID_PPDSTR_PARAM_HEIGHT,option, sizeof(option));
     Ps_PPDGetKeywordParamVal(hPrinter, keyword, option, PARAM_REAL, &fval, sizeof(float));
     Ps_PPDGetKeywordParamBnds(hPrinter, keyword, option, PARAM_REAL, &lo_lim, &hi_lim);

     LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_CUSTOMHEIGHT, keyword, sizeof(keyword));
     if (enum_rc == PS_RC_OK)
       enum_rc = Ps_PPDCreateKeyword(hPrinter, keyword, NULL, KWTYPE_PARAM, 0) ;
     LoadDrvrString(ghDriverMod, IDS_CUSTOM_SIZE_OPTION, strBuff, sizeof(strBuff));
     i = CUSTOM_FIRST ;
     while ((i <= CUSTOM_LAST) && (enum_rc == PS_RC_OK))
       {
       wsprintf(option, strBuff, i);
       enum_rc = Ps_PPDCreateKeywordParam(hPrinter, keyword, option, NULL,
                                          PARAM_REAL, sizeof(float));

       if (enum_rc == PS_RC_OK)
         enum_rc = Ps_PPDSetKeywordParamBnds(hPrinter, keyword, option,
                                             PARAM_REAL, &lo_lim, &hi_lim) ;
       if (enum_rc == PS_RC_OK)
         enum_rc = Ps_PPDSetKeywordParamVal(hPrinter, keyword, option,
                                            PARAM_REAL, &fval) ;
       i++ ;
       }

     /* Set up the Name storage */
     LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_CUSTOMNAME, keyword, sizeof(keyword));
     if (enum_rc == PS_RC_OK)
       enum_rc = Ps_PPDCreateKeyword(hPrinter, keyword, NULL, KWTYPE_NORMAL, 0) ;
     LoadDrvrString(ghDriverMod, IDS_CUSTOM_SIZE_OPTION, strBuff, sizeof(strBuff));
     LoadDrvrString(ghDriverMod, IDS_CUSTOM_SIZE_DISPLAY, strBuff2, sizeof(strBuff));
     i = CUSTOM_FIRST ;
     while ((i <= CUSTOM_LAST) && (enum_rc == PS_RC_OK))
       {
       char defName[MAX_CUST_PAPER_NAME];
       int j, optLen;

       wsprintf(option, strBuff, i);
       wsprintf(defName, strBuff2, i);
       optLen = lstrlen(defName);

       /* Make sure first custom paper name is at the maximum size */
       for (j = optLen; j < MAX_CUST_PAPER_NAME - 1; j++)
         {
         defName[j] = ' ';
         }
       defName[MAX_CUST_PAPER_NAME - 1] = '\0';

       enum_rc = Ps_PPDCreateKeywordOption(hPrinter, keyword, option, NULL,
                                           defName,
                                           DEF_JOB_SECTION, DEF_JOB_ORDER_NUM) ;

       /* Shorten the default name now that we have the proper space reserved */
       defName[optLen] = '|';
       defName[optLen+1] = '%';
       if (enum_rc == RC_ok)
         enum_rc = Ps_PPDSetKeywordOptionPS(hPrinter,
                                            keyword, option,
                                            defName, sizeof(defName));
       i++ ;
       }
     }
   else
     {
     enum_rc = PS_RC_OK;
     }

   /* Set up the margin storage */
   /* Create the Margins keyword */
   if (enum_rc == PS_RC_OK)
     {
     LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_MARGINS, keyword, sizeof(keyword));
     enum_rc = Ps_PPDCreateKeyword(hPrinter, keyword, NULL, KWTYPE_NORMAL, 0) ;
     }

   /* Enumerate and create the options for Margins - John Kwan */
   if (enum_rc == PS_RC_OK)
     {
     LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_IMGAREA, keyword, sizeof(keyword));
     if (Ps_PPDEnumKeywordOptions(hPrinter,keyword,fnAddPageSize,
                                  (LPSTR)&hPrinter)!= PS_RC_OK)
       enum_rc = PS_RC_FAIL;
     }

  if (enum_rc == PS_RC_OK);
    enum_rc = PPDCreateIntParamKeyword(hPrinter, ID_PPDSTR_KEY_USER_SCREENFREQUENCY,
              60, MIN_SCREEN_FREQ, MAX_SCREEN_FREQ);

  if (enum_rc == PS_RC_OK);
    enum_rc = PPDCreateIntParamKeyword(hPrinter, ID_PPDSTR_KEY_USER_SCREENANGLE,
              45, MIN_SCREEN_ANGLE, MAX_SCREEN_ANGLE);

  if (enum_rc == PS_RC_OK);
    enum_rc = PPDCreateBinaryKeyword(hPrinter,ID_PPDSTR_KEY_PJL_PROTOCOL, TRUE);

  if (enum_rc == PS_RC_OK);
    enum_rc = PPDCreateBinaryKeyword(hPrinter,ID_PPDSTR_KEY_DSC_CONFORMANCE, FALSE);

  if (enum_rc == PS_RC_OK);
    enum_rc = PPDCreateBinaryKeyword(hPrinter,ID_PPDSTR_KEY_VM_TRACKING, TRUE);

   /* Create DriverMarker keyword option to indicate Chicago compatible PPB */
   if (enum_rc == PS_RC_OK)
     {
     LoadDrvrString(ghDriverMod,ID_PPDSTR_KEY_DRVRMARK,keyword,sizeof(keyword));
     LoadDrvrString(ghDriverMod, ID_PPDSTR_DRVRMARK30, option,sizeof(option));
     enum_rc = Ps_PPDCreateKeywordOption(hPrinter, keyword, option, NULL,
         NULL, DEF_JOB_SECTION, DEF_JOB_ORDER_NUM) ;
     }
   if (enum_rc == PS_RC_OK)    // Change default Driver Marker to AdobePS 3.0
     enum_rc = Ps_PPDSetKeywordOption(hPrinter, keyword, option) ;

  if (enum_rc != PS_RC_OK)
    rc = RC_fail ;

  return (rc);
#else
  return FALSE;
#endif
}

/*****************************************************************************/
/*                 PPDCreateRealParamKeyword                                 */
/* Purpose:                                                                  */
/*   Checks the validity of certain user entered data in the                 */
/*   PostScript features dialog box. The first invalid or out of range entry */
/*   causes failure and the item in question will be highlighted.            */
/*                                                                           */
/* Parameters:                                                               */
/*   HANDLE pihdl -- handle to printer instance record                       */
/*   int keyword_id -- resource string table id for keyword                  */
/*   float fval -- initial value for new parameter                           */
/*   float lo_lim -- minimum valid value for new parameter                   */
/*   float hi_lim -- maximum valid value for new parameter                   */
/*                                                                           */
/* Returns: short                                                            */
/*   RC_ok if success                                                        */
/*   RC_fail if failure                                                      */
/*****************************************************************************/

short FAR PASCAL PPDCreateRealParamKeyword(HANDLE pihdl, int keyword_id,
   float fval, float lo_lim, float hi_lim)
{
#if 0
   short rc = RC_ok ;
   char keyword[MAX_KEYWORD_LEN] ;

   LoadDrvrString(ghDriverMod, keyword_id, keyword, sizeof(keyword)) ;
   rc = Ps_PPDCreateKeyword(pihdl, keyword, NULL, KWTYPE_PARAM, 0) ;
   if (rc == PS_RC_OK)
      rc = Ps_PPDCreateKeywordParam(pihdl, keyword, NULL, NULL, PARAM_REAL,
         sizeof(float)) ;
   if (rc == PS_RC_OK)
      rc = Ps_PPDSetKeywordParamBnds(pihdl, keyword, NULL, PARAM_REAL, &lo_lim,
         &hi_lim) ;
   if (rc == PS_RC_OK)
      rc = Ps_PPDSetKeywordParamVal(pihdl, keyword, NULL, PARAM_REAL, &fval) ;

   if (rc == PS_RC_OK)
      rc = RC_ok ;
   else
      rc = RC_fail ;

   return(rc) ;
#else
  return FALSE;
#endif
}
