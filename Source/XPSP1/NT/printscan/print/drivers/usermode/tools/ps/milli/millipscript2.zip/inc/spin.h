/*****************************************************************************/
/*                                                                           */
/* Include File Name: SPIN.H                                                 */
/*                                                                           */
/* Description: This include contains the prototypes for longspin.c          */
/*                                                                           */
/*****************************************************************************/

// Spin Button's class-specific window styles.
#define SPNS_WRAP          0x0001L

// Spin Button's class-specific window messages.
#define SPNM_SETTOPRANGE     (WM_USER + 0)
#define SPNM_SETBOTTOMRANGE  (WM_USER + 1)
#define SPNM_GETTOPRANGE     (WM_USER + 2)
#define SPNM_GETBOTTOMRANGE  (WM_USER + 3)
#define SPNM_SETCRNTVALUE    (WM_USER + 4)
#define SPNM_GETCRNTVALUE    (WM_USER + 5)

// Spin Button's notification codes sent in HIWORD of lParam 
// during a WM_COMMAND message.
#define SPNN_VALUECHANGE   (1)
#define SPNN_FIRSTTIMEDOWN (2)

BOOL FAR PASCAL RegisterLongSpinControlClass (HANDLE hInstance);
BOOL FAR PASCAL UnRegisterLongSpinControlClass (HANDLE hInstance);

