/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: CUSTPAP.H                                              */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHCustomPaperDlg(HWND hDlg, unsigned imsg, 
                                         WORD wParam, LONG lParam);
void NEAR DIALOGSSEG PASCAL GetCustomPageDimensions(LPDRIVERINFO lpDrvInfo,
                                                    LPWORD lpXSize, 
                                                    LPWORD lpYSize,
                                                    LPWORD lpXoffset, 
                                                    LPWORD lpYoffset);
double NEAR DIALOGSSEG PASCAL GetDlgItemDouble(HWND hDlg, int iCtrlID);
void FAR PASCAL RestoreCustPapDefaults(LPPSEXTDEVMODE lpPSExtDevmode,
                                       LPWPXBLOCKS lpWPXBlock);
