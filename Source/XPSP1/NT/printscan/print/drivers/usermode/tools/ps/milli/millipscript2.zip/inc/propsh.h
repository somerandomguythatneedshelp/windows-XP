/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PROPSH.H                                                     */
/*                                                                           */
/* Description: This module contains the functions prototypes for propsh.c   */
/*                                                                           */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHPropertySheetDlg(HWND hDlg, unsigned msg, 
                                           WORD wParam, LONG lParam);
