/* strmfont.c
              
                Copyright 1994-1997 -- Adobe Systems, Inc.
            PostScript is a trademark of Adobe Systems, Inc.
NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

Original version: Ron Fischer, Wed Mar 2nd, 1994
*/

/* -------------------------------------------------------------------------
     Header Includes
  --------------------------------------------------------------------------- */

//#ifdef STREAMER
//#undef STREAMER
//#endif

#ifdef FAUX
#undef FAUX
#endif


#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "..\streamer\package.h"
#endif

#define ANSI_C 1
#include "generic.h"

#pragma code_seg(_TRANSSEG)

#include <windows.h>
#include PACKAGE_SPECS
#include ATM

#include PUBLICTYPES
#include FP

#include PARSEGLU
#include STREAMER
#include STREAMER_FAUX
#include BUFFGLUE
#include "..\streamer\stream.h"
#include <fcntl.h>
#include <search.h>
#include "search.h"
#include "emap.h"


#define  IO_BUFFER_SIZE        10000
#define MAX_PC_BUFFER        32000


// These are defined in Windows.h for WINVER>=4.00
#define SHIFTJIS_CHARSET    128
#define HANGEUL_CHARSET     129
#define JOHAB_CHARSET       130
#define GB2312_CHARSET      134
#define CHINESEBIG5_CHARSET 136
#define GREEK_CHARSET            161
#define TURKISH_CHARSET          162
#define HEBREW_CHARSET           177
#define ARABIC_CHARSET           178
#define BALTIC_CHARSET      186
#define RUSSIAN_CHARSET          204
#define THAI_CHARSET                     222
#define EASTEUROPE_CHARSET       238
#define OEM_CHARSET         255 
#define MAC_CHARSET             77
// My own definition
#define UNDEFINE_CHARSET        OEM_CHARSET 

/* ---------------------------------------------------------------------------
     Typedefs
 --------------------------------------------------------------------------- */
typedef struct {
   T1FontPointer t1fptr;
   WORD *emap;
   BYTE    currentCharset;
   char fIsHybrid : 1;
   char fIsSynthetic : 1;
   char fHasSpecialProcset : 1;
} StrmFontRec;


typedef struct {
    int    charset;
    WORD* emap;
} StrmEncodeTbl;

StrmEncodeTbl encodeTbl[] = {
    { ANSI_CHARSET,    DriverWinAnsiEncode },
    { GREEK_CHARSET,    GreekEncode },
    { TURKISH_CHARSET,  TurkishEncode },
    { HEBREW_CHARSET,   HebrewEncode },
    { ARABIC_CHARSET,   ArabicEncode },
    { BALTIC_CHARSET,   BalticEncode },
    { RUSSIAN_CHARSET,  RussianEncode },
    { EASTEUROPE_CHARSET, EasternEuropeEncode },
    { MAC_CHARSET,         MacStandardEncode },
    { 0, 0 }
};

/* Global Variables */

WORD CommonEncode[] = {
426, 137, 375, 554, 464, 364, 391, 387, 530, 372,          // 0..9
434, 481, 369, 392, 366, 366, 366, 366, 366, 366,          // 10..19
366, 366, 366, 366, 366, 366, 366, 366, 366, 366,          // 20..29
366, 366, 542, 412, 515, 475, 390, 502, 346, 522,          // 30..39
499, 500, 353, 508, 377, 435, 503, 541, 585, 489,          // 40..49
557, 551, 419, 416, 540, 537, 400, 471, 376, 536,          // 50..59
458, 408, 427, 513, 354,   1,  14,  16,  21,  25,          // 60..69
 39,  40,  44,  45,  56,  57,  60,  66,  68,  74,          // 70..79
 88,  92,  93,  98, 103, 109, 121, 122, 123, 125,          // 80..89
128, 362, 357, 363, 351, 566, 426, 133, 356, 367,          // 90..99
380, 393, 414, 421, 433, 436, 449, 450, 453, 463,          // 100..109
467, 476, 497, 512, 523, 531, 545, 559, 573, 574,          // 110..119
575, 577, 581, 360, 358, 361, 352, 366,          // 120..127
};


// CodePage:   1
WORD DriverWinAnsiEncode[] = {
587, 366,          // 128..129
521, 418, 516, 401, 381, 382, 375, 505, 100, 431,          // 130..139
 75, 366, 130, 366, 366, 519, 520, 517, 518, 366,          // 140..149
404, 403, 554, 556, 533, 432, 480, 366, 583, 127,          // 150..159
542, 413, 373, 543, 379, 580, 365, 535, 387, 378,          // 160..169
493, 429, 460, 435, 528, 464, 385, 509, 558, 553,          // 170..179
137, 465, 498, 504, 372, 492, 494, 430, 491, 490,          // 180..189
552, 514,   7,   3,   5,  13,   6,  12,   2,  19,          // 190..199
 31,  26,  28,  29,  50,  46,  47,  48,  38,  72,          // 200..209
 79,  76,  77,  87,  78, 466,  86, 113, 110, 111,          // 210..219
112, 126, 108, 425, 342, 134, 136, 355, 138, 350,          // 220..229
139, 371, 399, 394, 396, 397, 440, 437, 438, 439,          // 230..239
411, 473, 482, 477, 478, 496, 479, 389, 495, 563,          // 240..249
560, 561, 562, 578, 550, 579         // 250..255
};


// CodePage:   2
WORD DriverOldWinAnsiEncode[] = {
587, 366,          // 128..129
521, 418, 516, 401, 381, 382, 375, 505, 366, 431,          // 130..139
 75, 366, 130, 366, 366, 519, 520, 517, 518, 366,          // 140..149
404, 403, 554, 366, 366, 432, 480, 366, 583, 127,          // 150..159
542, 413, 373, 543, 379, 580, 358, 535, 387, 366,          // 160..169
493, 429, 366, 435, 366, 464, 530, 366, 366, 366,          // 170..179
137, 366, 498, 504, 372, 366, 494, 430, 366, 366,          // 180..189
366, 514,   7,   3,   5,  13,   6,  12,   2,  19,          // 190..199
 31,  26,  28,  29,  50,  46,  47,  48, 366,  72,          // 200..209
 79,  76,  77,  87,  78, 366,  86, 113, 110, 111,          // 210..219
112, 366, 366, 425, 342, 134, 136, 355, 138, 350,          // 220..229
139, 371, 399, 394, 396, 397, 440, 437, 438, 439,          // 230..239
366, 473, 482, 477, 478, 496, 479, 366, 495, 563,          // 240..249
560, 561, 562, 366, 366, 579         // 250..255
};


// CodePage:   3
WORD StandardEncode[] = {
  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,          // 0..9
  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,          // 10..19
  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,          // 20..29
  0,   0, 542, 412, 515, 475, 390, 502, 346, 520,          // 30..39
499, 500, 353, 508, 377, 435, 503, 541, 585, 489,          // 40..49
557, 551, 419, 416, 540, 537, 400, 471, 376, 536,          // 50..59
458, 408, 427, 513, 354,   1,  14,  16,  21,  25,          // 60..69
 39,  40,  44,  45,  56,  57,  60,  66,  68,  74,          // 70..79
 88,  92,  93,  98, 103, 109, 121, 122, 123, 125,          // 80..89
128, 362, 357, 363, 351, 566, 519, 133, 356, 367,          // 90..99
380, 393, 414, 421, 433, 436, 449, 450, 453, 463,          // 100..109
467, 476, 497, 512, 523, 531, 545, 559, 573, 574,          // 110..119
575, 577, 581, 360, 358, 361, 352,   0, 587,   0,          // 120..129
  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,          // 130..139
  0,   0, 130,   0,   0,   0,   0,   0,   0,   0,          // 140..149
  0,   0,   0,   0,   0,   0,   0,   0, 583,   0,          // 150..159
  0, 413, 373, 543, 420, 580, 418, 535, 379, 522,          // 160..169
517, 429, 431, 432, 415, 417,   0, 404, 381, 382,          // 170..179
504,   0, 498, 366, 521, 516, 518,   0, 401, 505,          // 180..189
  0, 514,   0, 426, 137, 375, 554, 464, 364, 391,          // 190..199
387,   0, 530, 372,   0, 434, 481, 369, 403,   0,          // 200..209
  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,          // 210..219
  0,   0,   0,   0,   0,   2,   0, 493,   0,   0,          // 220..229
  0,   0,  65,  86,  75, 494,   0,   0,   0,   0,          // 230..239
  0, 139,   0,   0,   0, 392,   0,   0, 462, 495,          // 240..249
480, 425,   0,   0,   0,   0         // 250..255
};


// CodePage:  77
WORD MacStandardEncode[] = {
  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,          // 0..9
  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,          // 10..19
  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,          // 20..29
  0,   0, 542, 412, 515, 475, 390, 502, 346, 522,          // 30..39
499, 500, 353, 508, 377, 435, 503, 541, 585, 489,          // 40..49
557, 551, 419, 416, 540, 537, 400, 471, 376, 536,          // 50..59
458, 408, 427, 513, 354,   1,  14,  16,  21,  25,          // 60..69
 39,  40,  44,  45,  56,  57,  60,  66,  68,  74,          // 70..79
 88,  92,  93,  98, 103, 109, 121, 122, 123, 125,          // 80..89
128, 362, 357, 363, 351, 566, 426, 133, 356, 367,          // 90..99
380, 393, 414, 421, 433, 436, 449, 450, 453, 463,          // 100..109
467, 476, 497, 512, 523, 531, 545, 559, 573, 574,          // 110..119
575, 577, 581, 360, 358, 361, 352,   0,   6,  12,          // 120..129
 19,  26,  72,  78, 112, 134, 342, 136, 138, 355,          // 130..139
350, 371, 394, 399, 396, 397, 437, 440, 438, 439,          // 140..149
473, 477, 482, 478, 479, 496, 560, 563, 561, 562,          // 150..159
381, 385, 373, 543, 535, 366, 498, 425, 528, 378,          // 160..169
556, 137, 387, 472,   2,  86, 442, 509, 459, 428,          // 170..179
580, 465, 501, 544, 510, 507, 443, 493, 494,  82,          // 180..189
139, 495, 514, 413, 460, 525, 418, 349,  24, 429,          // 190..199
430, 401, 542,   7,  13,  87,  75, 480, 404, 403,          // 200..209
517, 518, 519, 520, 389, 461, 579, 127, 420, 379,          // 210..219
431, 432, 415, 417, 382, 504, 521, 516, 505,   5,          // 220..229
 28,   3,  29,  31,  46,  47,  48,  50,  76,  77,          // 230..239
348,  79, 110, 111, 113, 392, 375, 554, 464, 364,          // 240..249
391, 530, 372, 434, 481, 369         // 250..255
};


// CodePage: 1250
WORD EasternEuropeEncode[] = {
587,   0,          // 128..129
521,   0, 516, 401, 381, 382,   0, 505, 100, 431,          // 130..139
 99, 105, 130, 129,   0, 519, 520, 517, 518, 366,          // 140..149
404, 403,   0, 556, 533, 432, 532, 547, 583, 582,          // 150..159
542, 369, 364,  65, 379,  11, 365, 535, 387, 378,          // 160..169
101, 429, 460, 435, 528, 131, 385, 509, 481, 462,          // 170..179
137, 465, 498, 504, 372, 347, 534, 430,  63, 434,          // 180..189
456, 584,  94,   3,   5,   4,   6,  61,  17,  19,          // 190..199
 18,  26,  33,  29,  27,  46,  47,  22,  23,  69,          // 200..209
 70,  76,  77,  80,  78, 466,  95, 120, 110, 114,          // 210..219
112, 126, 106, 425, 524, 134, 136, 135, 138, 454,          // 220..229
368, 371, 370, 394, 405, 397, 395, 437, 438, 383,          // 230..239
384, 468, 469, 477, 478, 483, 479, 389, 526, 572,          // 240..249
560, 564, 562, 578, 548, 391         // 250..255
};


// CodePage: 1251
WORD RussianEncode[] = {
175, 176,          // 128..129
521, 222, 516, 401, 381, 382, 587, 505, 182, 431,          // 130..139
183, 185, 184, 233, 221, 519, 520, 517, 518, 366,          // 140..149
404, 403,   0, 556, 228, 432, 229, 231, 230, 234,          // 150..159
542, 186, 232, 181, 379, 174, 365, 535, 147, 378,          // 160..169
177, 429, 460, 435, 528, 180, 385, 509, 179, 225,          // 170..179
220, 465, 498, 504, 193, 340, 223, 430, 227, 178,          // 180..189
224, 226, 141, 142, 143, 144, 145, 146, 148, 149,          // 190..199
150, 151, 152, 153, 154, 155, 156, 157, 158, 159,          // 200..209
160, 161, 162, 163, 164, 165, 166, 167, 168, 169,          // 210..219
170, 171, 172, 173, 187, 188, 189, 190, 191, 192,          // 220..229
194, 195, 196, 197, 198, 199, 200, 201, 202, 203,          // 230..239
204, 205, 206, 207, 208, 209, 210, 211, 212, 213,          // 240..249
214, 215, 216, 217, 218, 219         // 250..255
};


// CodePage: 1252
WORD AnsiEncode[] = {
587,   0,          // 128..129
521, 418, 516, 401, 381, 382, 375, 505, 100, 431,          // 130..139
 75,   0,   0,   0,   0, 519, 520, 517, 518, 366,          // 140..149
404, 403, 554, 556, 533, 432, 480,   0,   0, 127,          // 150..159
542, 413, 373, 543, 379, 580, 365, 535, 387, 378,          // 160..169
493, 429, 460, 435, 528, 464, 385, 509, 558, 553,          // 170..179
137, 465, 498, 504, 372, 492, 494, 430, 491, 490,          // 180..189
552, 514,   7,   3,   5,  13,   6,  12,   2,  19,          // 190..199
 31,  26,  28,  29,  50,  46,  47,  48,  38,  72,          // 200..209
 79,  76,  77,  87,  78, 466,  86, 113, 110, 111,          // 210..219
112, 126, 108, 425, 342, 134, 136, 355, 138, 350,          // 220..229
139, 371, 399, 394, 396, 397, 440, 437, 438, 439,          // 230..239
411, 473, 482, 477, 478, 496, 479, 389, 495, 563,          // 240..249
560, 561, 562, 578, 550, 579         // 250..255
};


// CodePage: 1253
WORD GreekEncode[] = {
587,   0,          // 128..129
521, 418, 516, 401, 381, 382,   0, 505,   0, 431,          // 130..139
  0,   0,   0,   0,   0, 519, 520, 517, 518, 366,          // 140..149
404, 403,   0, 556,   0, 432,   0,   0,   0,   0,          // 150..159
542, 388,   9, 543, 379, 580, 365, 535, 387, 378,          // 160..169
493, 429, 460, 435, 528, 140, 385, 509, 558, 553,          // 170..179
555, 465, 498, 504,  35,  37,  55, 430,  85, 490,          // 180..189
119,  83, 447,   8,  15,  41,  24,  34, 132,  36,          // 190..199
107,  53,  58,  62,  67,  73, 124,  84,  90,  97,          // 200..209
  0, 102, 104, 117,  89,  20,  91,  82,  54, 118,          // 210..219
344, 407, 410, 448, 569, 343, 359, 422, 386, 406,          // 220..229
586, 409, 549, 445, 451, 455, 465, 474, 576, 487,          // 230..239
507, 529, 539, 538, 546, 568, 506, 374, 511, 485,          // 240..249
446, 570, 488, 571, 486,   0         // 250..255
};


// CodePage: 1254
WORD TurkishEncode[] = {
587,   0,          // 128..129
521, 418, 516, 401, 381, 382, 375, 505, 100, 431,          // 130..139
 75,   0,   0,   0,   0, 519, 520, 517, 518, 366,          // 140..149
404, 403, 554, 556, 533, 432, 480,   0,   0, 127,          // 150..159
542, 413, 373, 543, 379, 580, 365, 535, 387, 378,          // 160..169
493, 429, 460, 435, 528, 464, 385, 509, 558, 553,          // 170..179
137, 465, 498, 504, 372, 492, 494, 430, 491, 490,          // 180..189
552, 514,   7,   3,   5,  13,   6,  12,   2,  19,          // 190..199
 31,  26,  28,  29,  50,  46,  47,  48,  42,  72,          // 200..209
 79,  76,  77,  87,  78, 466,  86, 113, 110, 111,          // 210..219
112,  49, 101, 425, 342, 134, 136, 355, 138, 350,          // 220..229
139, 371, 399, 394, 396, 397, 440, 437, 438, 439,          // 230..239
423, 473, 482, 477, 478, 496, 479, 389, 495, 563,          // 240..249
560, 561, 562, 392, 534, 579         // 250..255
};


// CodePage: 1255
WORD HebrewEncode[] = {
587,   0,          // 128..129
521, 418, 516, 401, 381, 382, 375, 505,   0, 431,          // 130..139
  0,   0,   0,   0,   0, 519, 520, 517, 518, 366,          // 140..149
404, 403, 554, 556,   0, 432,   0,   0,   0,   0,          // 150..159
542,   0, 373, 543, 290, 580, 365, 535, 387, 378,          // 160..169
  0, 429, 460, 435, 528, 464, 385, 509, 558, 553,          // 170..179
137, 465, 498, 504,   0, 492,   0, 430, 491, 490,          // 180..189
552,   0, 329, 331, 330, 332, 323, 324, 325, 328,          // 190..199
327, 335,   0, 326, 336, 337, 291, 338, 339, 334,          // 200..209
333, 292, 320, 321, 322,   0,   0,   0,   0,   0,          // 210..219
  0,   0,   0,   0, 293, 294, 295, 296, 297, 298,          // 220..229
299, 300, 301, 302, 303, 304, 305, 306, 307, 308,          // 230..239
309, 310, 311, 312, 313, 314, 315, 316, 317, 318,          // 240..249
319,   0,   0, 287, 288,   0         // 250..255
};


// CodePage: 1256
WORD ArabicEncode[] = {
587, 283,          // 128..129
521, 418, 516, 401, 381, 382, 375, 505,   0, 431,          // 130..139
 75, 284, 285,   0, 286, 519, 520, 517, 518, 366,          // 140..149
404, 403,   0, 556,   0, 432, 480, 341, 289,   0,          // 150..159
542, 235, 373, 543, 379, 580, 365, 535, 387, 378,          // 160..169
  0, 429, 460, 435, 528, 464, 385, 509, 558, 553,          // 170..179
137, 465, 498, 504, 372, 492, 236, 430, 491, 490,          // 180..189
552, 237,   0, 238, 239, 240, 241, 242, 243, 244,          // 190..199
245, 246, 247, 248, 249, 250, 251, 252, 253, 254,          // 200..209
255, 256, 257, 258, 259, 466, 260, 261, 262, 263,          // 210..219
264, 265, 266, 267, 342, 268, 136, 269, 270, 282,          // 220..229
271, 371, 399, 394, 396, 397, 272, 273, 438, 439,          // 230..239
274, 275, 276, 277, 478, 278, 279, 389, 280, 563,          // 240..249
281, 561, 562, 287, 288,   0         // 250..255
};


// CodePage: 1257
WORD BalticEncode[] = {
587,   0,          // 128..129
521,   0, 516, 401, 381, 382,   0, 505,   0, 431,          // 130..139
  0,   0,   0,   0,   0, 519, 520, 517, 518, 366,          // 140..149
404, 403,   0, 556,   0, 432,   0,   0,   0,   0,          // 150..159
542, 369, 364, 543, 379,   0, 365, 535, 387, 378,          // 160..169
 96, 429, 460, 435, 528,   2, 530, 509, 481, 553,          // 170..179
137, 465, 498, 504, 372, 492, 527, 430, 491, 490,          // 180..189
552, 139,  11,  52,  10,  17,   6,  12,  33,  32,          // 190..199
 18,  26, 129,  30,  43,  59,  51,  64, 100,  69,          // 200..209
 71,  76,  81,  87,  78, 466, 116,  65,  99, 115,          // 210..219
112, 131, 130, 425, 347, 444, 345, 368, 138, 350,          // 220..229
405, 402, 370, 394, 582, 398, 424, 452, 441, 457,          // 230..239
533, 468, 470, 477, 484, 496, 479, 389, 567, 462,          // 240..249
532, 565, 562, 584, 583, 391         // 250..255
};


/* ---------------------------------------------------------------------------
     Static Variables
 --------------------------------------------------------------------------- */

    /* Values for getchstrFlag that describe what state */
    /* GetCharString is called in                */
#define FIRSTPASS    0
#define SECONDPASS    1
#define INC_DOWNLOAD    2
    /* getchstrFlag serves to tell the GetCharString */
    /* function whether this is the first pass of */
    /* the parser (in which case we truthfully */
    /* report all charstrings) or the second */
    /* pass (in which case we suppress all */
    /* charstrings except .notdef and Eth, if present) or subsequent */
    /* incremental GetCharStrings (in which case */
    /* we keep track of chars already reported */
    /* and do not report them more than once) */
PRIVATE int getchstrFlag = FIRSTPASS;
PRIVATE char *glyphArr;        /* For keeping track of charstrings already */
                /* downloaded                */
PRIVATE BOOL cacheIndsOff = false; /* Turn of caching of charstring indices */
                   /*  when we are searching for SEAC  */
                   /* constituents in a special encoded font */

PRIVATE HFILE inFile;        /* for the .PFB file */
PRIVATE Card32 PCBytesLeft = 0;  /* Used for PCGetBytes() */
PRIVATE StrmFontRec *strmfontrecPtr;    /* Current font data structure */
PRIVATE T1FontPointer fp;    /* Portion of previous var known to streamer */

PRIVATE LPPDEVICE exlppd;        /* To be used by the PutByte callback */
PRIVATE BOOL binaryOutput;    /* Whether job is Ascii/Binary */


FauxGlyphsStruct fauxGlyphs;

PRIVATE char *myBuffer;        /* File read buffer */
PRIVATE Card32 myBufferSize;    /* ... and its size */

/* ---------------------------------------------------------------------------
     Function Declarations
 --------------------------------------------------------------------------- */

boolean  MyRealloc ARGDECL2(void **, handle, Card32, size);
int _cdecl _far mycmpfunc(const void *, const void *);
                        /* To sort the charnames arr */
void SortFp();                    /* Ditto, will also reorder */
                        /* charstrings & charlengths */
int MyFindString(char *, char **, int);        /* Locate charname in array */
boolean  _cdecl _far MyFontAttribute ARGDEF1(Card16, type);
void SendProlog(StreamerOpts *, BOOL);
void SendEpilog(BOOL);

/* ---------------------------------------------------------------------------
     Macros
 --------------------------------------------------------------------------- */
#define CHAR_IS_SENT(arr, i)         ((arr)[1+((i)>>3)] & (1 << ((i)&7)))
#define SET_CHAR_SENT_STATUS(arr, i)     (arr)[1+((i)>>3)] |= (1 << ((i)&7))

/* ---------------------------------------------------------------------------
     Function: PCGetBytes()

     PCGetBytes() is a callback function used by the parser to read a font
     file.
  --------------------------------------------------------------------------- */

PRIVATE CardX PCGetBytes ARGDEF2(char ***, hndl, CardX *, len)
{
    typedef struct         /* Header of each PC font file segment */
    { 
        Card8  id;
        Card8  type;
        Card32 len;
    } PcSegDesc;

    PcSegDesc desc;                 /* Descriptor of font file segment */
    CardX bytesToRead;

    if (PCBytesLeft == 0)        /* read the segment header */
    { 
        //if encounter EOF then just return w/ true
        if ((*len = _lread(inFile, &desc, sizeof(desc))) == 0)
            return true;

        //we could be at EOF for reading a PFB
        if (*len < sizeof(desc)) 
        {
           //termination code for a Type1 PFB is 0x80 0x03
           if ((*len == 2) && (desc.id == 0x80) && (desc.type == 0x03))
           {
              //send back *len = 0 to indicate EOF
              *len = 0;
              return true;
           }
           else
             return false;
        } 

        if ( *len != sizeof(desc) )
            return false;
        if (desc.id != 128)
            return false;
        PCBytesLeft = desc.len;
    } /* end if */

    /* Read the segment data */
    /* Can't read more than (just under) 32K (parser problem) */
    bytesToRead = (CardX)MIN(MIN(PCBytesLeft, myBufferSize), MAX_PC_BUFFER);
    /* Always make sure not to leave less than 30 bytes unread */
//    if ((PCBytesLeft - bytesToRead != 0) && (PCBytesLeft - bytesToRead < 30))
//        bytesToRead = (CardX)PCBytesLeft - 30;
    *len = (CardX)_lread(inFile, myBuffer, (UINT)bytesToRead);

    if (*len <= 0)
        return false;

    PCBytesLeft -= *len;
    *hndl = &myBuffer;

    return true;
} /* end PCGetBytes() */



static CardX PutBytes (char * pData, unsigned long len)
{
    if (len > 65535)
        return false;
    if (binaryOutput)
        PSSendBitMapDataLevel1Binary(exlppd, pData, (int)len);
    else
        PSSendData(exlppd, pData, (WORD) len);
    return true;
} /* end PutBytes() */

/* ---------------------------------------------------------------------------
    Function GetSubr()

    Get a requested subroutine charstring and length.
 --------------------------------------------------------------------------- */

PRIVATE IntX GetSubr ARGDEF3(IntX, subrNo, CharDataPtr *, subrCharString, 
                             Card16 *, subrLen)
{
    /* First, add the bias back in */
    subrNo += fp->pFontDict[0]->subroutineNumberBias;

    if ((subrNo > (IntX)fp->pFontDict[0]->lenSubrArray) || (subrNo < 0))
        return false;

    if (fp->pSubrArray[0] != NULL)
    { 
        *subrCharString = fp->pSubrArray[0][subrNo];
        *subrLen = fp->subrLengths[0][subrNo];
    } /* end if */
    else
    { 
        *subrCharString = NULL;
        *subrLen = 0;
    } /* end else */

    return true;
} /* end GetSubr() */

PRIVATE WORD* GetEmap( int charset )
{
    WORD* emap;
    StrmEncodeTbl* pEncode ;

    emap = NULL;
    pEncode = encodeTbl;
    for ( ; pEncode->emap; pEncode++ ) {
        if ( charset == pEncode->charset ) {
            emap = pEncode->emap;
            break;
        }
    }
    return emap;            
}



/* ---------------------------------------------------------------------------
    Function GetCharString()

    Get a requested charstring. 
 --------------------------------------------------------------------------- */

PRIVATE IntX GetCharString ARGDEF5(IntX, index, IntX, indexType,
       CharDataPtr *, charString, Card16 *, charLen, Card8 **, charName)
{
    char *s;
    Int16 i, j;
    WORD* emap;

    if (indexType == INDEX_IS_CHARINDEX) { 
        if (index < fp->numCharStrings)            // Streamer callback through this case, but we never feed it any
            j = (Int16)index;                    // characters other than the two .NotDef and Eth characters.
        else                                    // We also uses this case to incremental add characters into a font.
            return false;                        // that has special encoding.
    } /* end else */
    else if (index < 256) {                        // We use this to add characters into a font that has "Standard" Encoding.

        if ( index <= 127 && 
             indexType != INDEX_IS_MACSTANDARDCS && 
             indexType != INDEX_IS_ENCODING )
            i = CommonEncode[index];
        else {  
            // Standard encoding has all the glyphs
            if (indexType == INDEX_IS_ENCODING) {
                 emap = StandardEncode;
                i = emap[index];
            }
            else {
            // Other encodings start at 128th glyph
                emap = strmfontrecPtr->emap;
                i = emap[index-128];
            }   
        }        
                
        s = EncodeNameList[i];

        j = MyFindString(s, fp->charNames, fp->numCharacters);
        
        if (j < 0)
            return false;

    } /* end if (indexType == INDEX_IS_ENCODING) */

    *charName = (Card8 *)fp->charNames[j];
        /* We suppress reporting the charstring if either: */
        /* 1) This is the parser's second pass and the       */
        /*    character is neither '.notdef' nor 'Eth'       */
        /* 2) This is an incremental download and the char  */
        /*    has already been downloaded previously       */
    if (getchstrFlag == INC_DOWNLOAD) {
        /* In the incremental download phase, we report just the */
        /* index into the internal array (or -1) if character was */
        /* reported before */
        if (CHAR_IS_SENT(glyphArr, j))
            *((int *)charLen) = -1;
        else {
            *((int *)charLen) = j;
            SET_CHAR_SENT_STATUS(glyphArr, j);
        }
    }
    else if (strcmp(*charName,".notdef") && strcmp(*charName,"Eth")) {
        /* In the SECONDPASS phase, we only download .notdef and Eth */
        /* if present */
        *charString = NULL;
        *charLen = 0;
    }
    else {
        *charString = fp->charStrings[j];
        *charLen = fp->charLengths[j];
        SET_CHAR_SENT_STATUS(glyphArr, j);
    }
    return true;
} /* end GetCharString() */

BOOL FAR PASCAL StreamerAble(LPSTR inFontName, LPSTR  *fpointer, LPSTR undefFont)
{
    CardX       code;
    BOOL  fRetVal, fT1Init;
    StrmFontRec **ppFontRec;

    if ( fpointer == 0 )
        return 0;


    if ( NULL == EncodeNameList && FALSE == LoadEncodeNameList() )
        return 0;

    fT1Init = 0;
    fRetVal = 1;
    ppFontRec = (StrmFontRec **) fpointer;
    strmfontrecPtr = 0;
    /* Set things up for PCGetBytes */
    if ((inFile = _lopen(inFontName, READ)) == HFILE_ERROR)
        fRetVal = 0;
    
    if ( fRetVal ) {
        PCBytesLeft = 0;
        myBuffer = NULL;
        strmfontrecPtr = (StrmFontRec *) malloc(sizeof(StrmFontRec));
        
        if ( strmfontrecPtr ) {
            strmfontrecPtr->fIsHybrid = 0;
            strmfontrecPtr->fIsSynthetic = 0;
            strmfontrecPtr->fHasSpecialProcset = 0;
        }
        else 
            fRetVal = 0;
    }    

    if ( fRetVal ) {
        if (!MyRealloc(&myBuffer, IO_BUFFER_SIZE))
            fRetVal = 0;
    }

    if ( fRetVal ) {
        myBufferSize = IO_BUFFER_SIZE;
        code = T1ParseInit(MyRealloc);   /* Initialize the parser */
        fRetVal = ( code == ST_NOERR ) ? 1 : 0;
        fT1Init = fRetVal;
    }
    
    if ( fRetVal ) {
        /* Parse the font, creating the FontRec structure */
        getchstrFlag = FIRSTPASS;
        fp = NULL;
        code = T1FontParse( &fp, PCGetBytes, NULL, NULL, NULL, NULL, NULL, NULL, MyFontAttribute );
#ifdef MM_INCR
        fRetVal = ( code == ST_NOERR &&                 // Can't support this font if this font is not parseable
                    strmfontrecPtr->fIsHybrid == 0 &&    // Can't support a hybrid font.
                    !( strmfontrecPtr->fIsSynthetic && fp->pFontDict[0]->numMasters > 1 )    // Can't support Synthetic MultiMaster font.
                     ) ? 1 : 0;
#else
        fRetVal = ( code == ST_NOERR &&                 // Can't support this font if this font is not parseable
                    strmfontrecPtr->fIsHybrid == 0 &&    // Can't support a hybrid font.
                    ( fp->pFontDict[0]->numMasters <= 1 )    // Can't support MultiMaster font.
                     ) ? 1 : 0;
#endif
    }


    strmfontrecPtr->emap = 0;
    strmfontrecPtr->currentCharset = (BYTE)UNDEFINE_CHARSET;

    
    _lclose(inFile);
    MyRealloc(&myBuffer, 0);
    

    if ( fRetVal == 0 ) {

        //fix bug 185656 TektonMM-Oblique does not print after TektoMM
        //This is because TektonMM-Oblique ask for TektoMM
        //therefore we have to undefine it here.
        //While download TektonMM-Oblique it will down load TektonMM again
        if ( fp && ((fp->baseMMFontName) && undefFont))
        {
           //skip the slash
           lstrcpy(undefFont, (fp->baseMMFontName)+1);
        };


        if ( strmfontrecPtr ) {
            free( strmfontrecPtr );
            strmfontrecPtr = 0;
        }    
        if ( fT1Init )
            T1ParseDeinit();
    }
    else
        strmfontrecPtr->t1fptr = fp;

    *ppFontRec = strmfontrecPtr;

    return fRetVal;
}

/* Check for special characters that could be defined in a font.  We
   use "space" and "hyphen" in the driver.  A font can define "nbspace"
   and "sfthyphen"
*/
   
BOOL NEAR PASCAL CheckForSpecialChar( char* name1, char* name2 )
{
    if ( ( !strcmp( name1, "nbspace" ) && !strcmp( name2, "space" ) ) ||
         ( !strcmp( name1, "sfthyphen" ) && !strcmp( name2, "hyphen" ) ) )
        return TRUE;
    else
        return FALSE;
}
            

/* 
    Download an empty base font. This function returns 
        0 - if it encounters error.
        1 - if it encounters no error and download the base font successfully.
        2 - if it encounters no error and download the base font successfully, and the font should be reencoded
*/
int FAR PASCAL StreamerDownLoadT1Font(LPPDEVICE lppd, LPSTR inFontName,
               LPSTR  fpointer, LPSTR  *pglyphdata,
               BOOL binary, BYTE charset )
{
    int  i;
    CardX code;
    StreamerOpts so;
    CharStrOpts co;
    BufferStatus b;
    BOOL    reEncode;

//   set binary =1 for debugging
//    binary = 1;  
            /* Squirrel away the arguments */
    strmfontrecPtr = (StrmFontRec*)fpointer;
    if ( strmfontrecPtr == 0 )
        return 0;

    fp = strmfontrecPtr->t1fptr;
    exlppd = lppd;
    binaryOutput = binary;
    
    inFile = HFILE_ERROR;
    PCBytesLeft = 0;
    myBuffer = NULL;
    
    code = 0;
        /* Set things up for PCGetBytes */
    if ((inFile = _lopen(inFontName, READ)) == HFILE_ERROR) {
        goto Exit;
    }
    
    if (!MyRealloc(&myBuffer, IO_BUFFER_SIZE)) {
        goto Exit;
    }

    myBufferSize = IO_BUFFER_SIZE;
/*
    if (fp->pFontDict[0]->numMasters > 1)         
        so.subrFlatten = ST_KEEP_SUBRS;        
        else
        */
        so.subrFlatten =     ST_FLATTEN_SUBRS;    

    so.sparseMethod =    ST_SPARSE_REMOVE;
    so.accessPrivateDict = true;
    so.uniqueID = ST_KEEP_UID;
    so.lenIV =  binary ? -1 : 4;
    so.eexec =  binary ? ST_NO_ENCRYPTION : ST_ENCRYPTHEX;
    so.blendLen = 0;
    so.snapShot = ST_NO_SNAPSHOT;
    so.PutBytes = PutBytes;
    so.doingFaux = false;
    so.MemoryRealloc = MyRealloc;

            
    if ( *pglyphdata == NULL ) {    
        /* IF NOT Allocated YET - do allocation, else just use it. */
        /* Allocate memory for incremental download bookkeeping */
        *pglyphdata = GlobalLock(GlobalAlloc(GHND, 1 + (fp->numCharacters+7)/8));
        if ( NULL == *pglyphdata )
            goto Exit;
            
    }

    /* First sort the charNames, charStrings */
    /* and charLengths array subfields in fp for the */
    /* convenience of GetCharString            */
    SortFp();
        
    glyphArr = *pglyphdata;

    reEncode = 0;
    strmfontrecPtr->currentCharset = charset;        
    glyphArr[0] = INDEX_IS_SPECIALENCODING;

    if ( charset == ANSI_CHARSET ) {
            /* Must know what encoding array will be used with this font */
            /* so as to know how character indices map to charstrings */
        if (fp->hasStandardEncoding)
            glyphArr[0] = INDEX_IS_WINANSI;
        else if (fp->specialEncoding != NULL) {
            /* The following logic is used in a postscript procedure */
            /* downloaded to printer. It decides when ANSI encoding */
            /* is to be asserted over the font's native encoding */
            
            for (i = 32; i < 127;i++) {
                if (strcmp(fp->specialEncoding[i], 
                       standardCharacters[standardEncoding[i]]))
                    break;
            }
            if (i == 127)
                glyphArr[0] = INDEX_IS_WINANSI;
            else
                glyphArr[0] = INDEX_IS_SPECIALENCODING;

        }
                                    
        if (glyphArr[0] == INDEX_IS_WINANSI) {
            for (i = 0; i < fp->numCharacters; i++) {
                if (!strcmp(fp->charNames[i],"Eth"))
                    break;
            }
            if (i == fp->numCharacters)
                glyphArr[0] = INDEX_IS_WINANSIOLD;
        }
        
        reEncode = (glyphArr[0] == INDEX_IS_WINANSI || glyphArr[0] == INDEX_IS_WINANSIOLD);
        
        if ( reEncode ) {                         
            strmfontrecPtr->emap = (glyphArr[0] == INDEX_IS_WINANSI) ? DriverWinAnsiEncode : DriverOldWinAnsiEncode;
        }    
    }            
    else {                            // charset != WINANSI
        WORD* emap = GetEmap( charset );
        if ( emap ) {
            strmfontrecPtr->emap = emap;
            if (fp->hasStandardEncoding) {
                glyphArr[0] = INDEX_IS_WINANSI;
                reEncode = 1;
            }    
            else if ( fp->specialEncoding != NULL ) {
                /* Check to see if we have the right encoding.  For example, Helvetica Cerillic would have the right encoding */
                for ( i = 32; i < 127; i++ ) {
                    if ( strcmp(fp->specialEncoding[i], EncodeNameList[CommonEncode[i]] ) )
                        break;
                }
                
                if (i == 127) {
                    for ( i = 128; i < 256; i++ ) {        
                        if ( strcmp( fp->specialEncoding[i], EncodeNameList[emap[i-128]] ) && 
                            ( !CheckForSpecialChar( fp->specialEncoding[i], EncodeNameList[emap[i-128]] ) ) )
                            break;
                    }

                    if ( i < 256 ) { 
                        reEncode = 1;
                    }    
                }        
            }
        }
        else {
            /*  We don't have the map for this charset.  If this font has a special encoding then we use the special encoding.
	            Otherwise, we return failure code and give up.
            */
            if ( fp->specialEncoding == NULL )
                goto Exit;
        }
    }    
        
    getchstrFlag = SECONDPASS;

    /* Stream the header of the font along with a skeleton */
    /*     charStrings dictionary */
    StreamerSetCharOpts(fp, &so, &co, GetCharString, GetSubr);

    StreamerStart(fp, &so, &co, &b, SUGGESTED_BUFSIZE);

    BufferSetEEKey(0, ST_NO_ENCRYPTION);
    if ( strmfontrecPtr->fIsSynthetic == 0 ) {
        _llseek(inFile, 0L, 0);
        PCBytesLeft = 0;
        code =  StreamCompleteFont(fp, &so, &co, &b, NULL, PCGetBytes);
        StreamerEnd(fp, &so, &b);
    }
    else {
        code  = StreamFont( fp, &so, &co, &b, (FauxInfoPointer)0 );    // We don't support fauxing (the last parameter == 0)
    }

        /* Clean up and leave ... */
    getchstrFlag = FIRSTPASS;

    code = (code != ST_NOERR) ? 0 : 1;
    
    if ( code && reEncode )
        code = 2;    

Exit:
    if ( inFile != HFILE_ERROR )
        _lclose( inFile );
    if ( myBuffer )
        MyRealloc(&myBuffer, 0);
    T1ParseDeinit();        // Now that we are done w/ the font, free Streamer's growable memory area.
    
    return (int)code;
}




/*
   ---------------------------------------------------------------------------
     Function: MyRealloc():

     Memory reallocation callback function
   ---------------------------------------------------------------------------
*/
boolean MyRealloc(void **handle, Card32 size)
{
//#ifdef PSDEBUG
//    unsigned long oldP = (unsigned long) *handle;
//    void **oldHandle = handle;
//#endif

    if ( size > 65535 )    {
        os_realloc(*handle, (size_t)0);
        return false;
    }
    *handle = os_realloc(*handle, (size_t) size);

//#ifdef PSDEBUG
//    if ((size != 0) && (oldP != 0)) {
//      //realloc memory. Not freeing pointer or allocating mem for first time.
//      unsigned long newP = (unsigned long) *handle;
//      if (oldP != newP) 
//         MessageBox(NULL, (LPSTR)"Caution! Streamer is reallocating an existing buffer and \r\n MyRealloc() returns a new pointer.",
//                     (LPSTR)"Debug Message", MB_OK | MB_ICONEXCLAMATION);
//    }
//#endif
    
    return(*handle != 0);
}


/*----------------------------------------------------------------*/
int FAR PASCAL StreamerUpdateT1Font(LPPDEVICE lppd, LPSTR fpointer,
             LPSTR glyphPtr, LPSTR lpStr, int cb, BOOL binary, BYTE charset)
{
    int i, j,  retval;
    CardX code = ST_NOERR;
    FauxInfoPointer fi = NULL;
    CharDataPtr charString;
    unsigned int charLen;
    unsigned char *charName, *charptr, *extrachars, index;
    int totalchars;
    StreamerOpts so;
    CharStrOpts co;
    BufferStatus b;
    long vmSize;
    int *charInds, nextcharInds, *iptr;

//   set binary =1 for debugging
//    binary = 1;

    if ( 0 == fpointer )    // Return error if we don't have this font record.
        return 0;

        /* Save up those precious functon arguments */
    exlppd = lppd;
    strmfontrecPtr = (StrmFontRec *) fpointer;
    fp = strmfontrecPtr->t1fptr;
    charptr = (unsigned char *) lpStr;

    if ( strmfontrecPtr->fIsHybrid )
        return 0;        // Return error if this font is a hybrid font.

        /* Set up streamer options */
    so.sparseMethod =     ST_SPARSE_REMOVE;
        /*
    if (fp->pFontDict[0]->numMasters > 1)
        so.subrFlatten =     ST_KEEP_SUBRS;
    else
        */
        so.subrFlatten =     ST_FLATTEN_SUBRS;    
    so.accessPrivateDict = true;
    so.uniqueID = ST_KEEP_UID;
    so.lenIV =      binary ? -1 : 4;
    so.eexec =     binary ? ST_NO_ENCRYPTION:ST_ENCRYPTHEX;
    so.blendLen = 0;
    so.snapShot = ST_NO_SNAPSHOT;
    so.PutBytes = PutBytes;
    so.doingFaux = false;
    so.MemoryRealloc = MyRealloc;

    StreamerSetCharOpts(fp, &so, &co, GetCharString, GetSubr);
    StreamerStart(fp, &so, &co, &b, SUGGESTED_BUFSIZE);

    if (!cb)
        cb = lstrlen(lpStr);
    getchstrFlag = INC_DOWNLOAD;    /* So GetCharString knows to do apprpriate */
                    /* bookkeeping                */
    binaryOutput = binary;
    glyphArr = glyphPtr;        /* For getCharString to keep track of which */
                    /* chars have been downloaded        */
    extrachars = NULL;        /* This will hold the SEAC constituent chars */
                    /* that may need to be downloaded    */
    if (!MyRealloc(&extrachars, 2*cb))/* In the worst case all input chars are SEAC */
        return(0);
    /* We need an array to store the list of required charstrings */
    /* Each input character could potentially require three charstrings */
    /* (in case it is a SEAC char). Hence an array three times the size */
    /* of the input string is required */
    charInds = (int *)NULL;
    if (!MyRealloc(&(unsigned char *)charInds, 3*cb*sizeof(int))) {
        MyRealloc(&extrachars, 0);
        return(0);
    }
    
    nextcharInds = 0;
    cacheIndsOff = false;

    totalchars = cb;    /* totalchars is the sum of the number of input */
                /* chars and any SEAC constituent chars that may be */
                /* needed        */

                    
    for (i = 0; i < totalchars; i++) { 
        if (i >= cb) {            /* Are we dealing with the SEAC constituents ?*/
            index = extrachars[i-cb];
            if (i == cb)
                  cacheIndsOff = (glyphPtr[0] == INDEX_IS_SPECIALENCODING);
            /* Searching for a SEAC constituent char in a special encoding font */
            /* Sort of like looking up a Swahili word in an English dictionary */
            /* Must turn off charstring index caching. */
       }
       else
            index = charptr[i];
        
       code = 0;                
       if (i < cb) {            /* The input chars may be encoded in a */
                                    /*    variety of ways */
            switch(glyphPtr[0]) {
                case INDEX_IS_WINANSI:
                case INDEX_IS_WINANSIOLD:
                    if ( charset == ANSI_CHARSET ) 
                        code = GetCharString(index, glyphPtr[0], &charString, &charLen, &charName);
                    else {
                        // The charset is the index encoding type.
                        code = GetCharString(index, charset, &charString, &charLen, &charName);
                    }        
                    break;
                    
                case INDEX_IS_SPECIALENCODING:
                    /* Search for the charName among the array of names */
                      j = MyFindString(fp->specialEncoding[index], fp->charNames, fp->numCharacters);

                    if (j >= 0)
                        code = GetCharString(j, INDEX_IS_CHARINDEX, &charString, &charLen, &charName);
                    break;


                default:
                    break;
            }
       }
       else         /* .... SEAC constituents are always understood */
                /* to be relative to standard Encoding     */
            code = GetCharString(index, INDEX_IS_ENCODING, &charString, &charLen, &charName);

        /* If charstring is found and not sparsed put it in array */
        if ((code) && (charLen != -1)) {
            /* charLen contains the index in the fp arrays of the desired glyph */
            charInds[nextcharInds++] = charLen;
            charString = fp->charStrings[charLen];
            charLen = fp->charLengths[charLen];
            if (CheckForSEAC(charString, charLen, fp, &co) == ST_NOERR)    {
                if ((co.baseChar != 0) || (co.accentChar != 0))
                {
                    extrachars[totalchars-cb] = (unsigned char)co.baseChar;
                    extrachars[totalchars-cb+1] = (unsigned char)co.accentChar;
                    totalchars += 2;
                }
            }
         }
   
    } /* end for */
    
    retval = 2;            /* Meaning all's well */
    if (nextcharInds) {    /* Anything needs to be downloaded ? */
            /* How much VM do we need ? */
        vmSize=0;
        for(i = 0,iptr = charInds;i < nextcharInds;i++, iptr++)
           vmSize += (16 + lstrlen(fp->charNames[*iptr]) + 
                fp->charLengths[*iptr]);
        if (VMCheck(lppd, VM_PST1_FONT, vmSize))
           retval = 1;
        else
        {
           SendProlog(&so, binary);
           for(i = 0, iptr = charInds;i < nextcharInds;i++, iptr++)
                  if (code = StreamCharString(fp->charStrings[*iptr], 
                          fp->charLengths[*iptr], 
                          fp->charNames[*iptr],
                          fp, &co, fi, &b))
             break;
               if (code != ST_NOERR)
                     retval = 0;
           SendEpilog(binary);

           VMUsed(lppd, VM_PST1_FONT, vmSize);
        }
    }
    StreamerEnd(fp, &so, &b);

    MyRealloc(&extrachars, 0);    /* Free up the alloc'd memory */
    MyRealloc(&(unsigned char *)charInds, 0);
    getchstrFlag = FIRSTPASS;

    return retval;
} /* end StreamerUpdateT1Font() */


void SortFp()
{
    WORD *sortarr;
    int i, j, next;
    char *thisName;
    CharDataPtr thisString;
    Card16 thisLen;

    sortarr = (WORD *)malloc(sizeof(WORD)*fp->numCharacters);
    for(i = 0;i < fp->numCharacters; i++)
    {
        // Testing to see if the font defines the numCharString is exactly what the font actually has
//        if (fp->charNames[i] != NULL && *(fp->charNames[i]) != '\0')
          if (fp->charNames[i] != NULL)
           sortarr[i] = (WORD)i;    /* Each entry in sortarr is the index of */
        else {
           // We don't have a real charstring, set the number of charstring to the actual number
           fp->numCharacters = i;
           fp->numCharStrings = i;
           break;
        }
                    /* of an entry in the charNames array    */
    }
    qsort(sortarr, fp->numCharacters, sizeof(WORD), mycmpfunc);
        /* Now the arrays charNames, charStrings and charLengths must */
        /* be reordered in accordance with the sorted order    */
    for (i =0;i < fp->numCharacters;i++) {
        if ((sortarr[i] == (WORD)-1) || (sortarr[i] == (WORD)i))
            continue;
        next = i;
        thisName = fp->charNames[i];
        thisLen = fp->charLengths[i];
        thisString = fp->charStrings[i];
        do{
           j = next;
           fp->charNames[j] = fp->charNames[sortarr[j]];
           fp->charLengths[j] = fp->charLengths[sortarr[j]];
           fp->charStrings[j] = fp->charStrings[sortarr[j]];
           next = sortarr[j];
           sortarr[j] = (WORD)-1;
        } while (next != i);
        fp->charNames[j] = thisName;
        fp->charLengths[j] = thisLen;
        fp->charStrings[j] = thisString;
    }
    free(sortarr);
}

int _cdecl _far mycmpfunc(const void *left, const void *right)
{
    return(strcmp(fp->charNames[*(WORD *)left], 
            fp->charNames[*(WORD *)right]));
}

int MyFindString(str, strtable, tabsize)
char *str, **strtable;
int tabsize;
{
    int low, high, mid, i;

    low = 0;
    high = tabsize - 1;
    do {
        mid = (low+high)/2;
        i = strcmp(str, strtable[mid]);
        if (i < 0)
            high = mid;
        else if (i > 0)
            low = mid;
        else
            return(mid);
    } while (high > low+1);
    
    if (low != high) {
        if (!strcmp(str, strtable[low]))
            return(low);
        if (!strcmp(str, strtable[high]))
            return(high);
    }
    return(-1);
}

boolean  _cdecl _far MyFontAttribute ARGDEF1(Card16, type)
{
    
    switch ( type ) {
    case ST_HYBRID_FONT:
        strmfontrecPtr->fIsHybrid = 1;
        break;
    case ST_SYNTHETIC_FONT:
        strmfontrecPtr->fIsSynthetic = 1;
        break;
    case ST_SPECIAL_PROCSET:
        strmfontrecPtr->fHasSpecialProcset = 1;
        break;
    }
    return 1;
} /* end myFontAttribute() */

void FAR PASCAL StreamerReleaseFontRec(LPVOID FAR *fontRecPtr)
{
    StrmFontRec *sfRec = *(StrmFontRec **)fontRecPtr;
    
    if (sfRec->t1fptr != NULL)
       T1FontRelease((T1FontHandle) &sfRec->t1fptr);
    MyRealloc(&(void *)sfRec, 0);
}

void SendProlog(StreamerOpts *pso, BOOL binflag)
{
    BufferSetEEKey(0, ST_NO_ENCRYPTION);
    BufferStringEOL("");
    BufferFlush();
    if (!binflag)
        StreamEEXEC(pso);
#ifdef ADD_EURO
    BufferStringEOL(" /UseT3EuroFont where {pop UseT3EuroFont}{false} ifelse ");
    BufferString("{/");
    BufferString(fp->fontName);
    BufferString(" findfont /FontType get 3 eq { /");
    BufferString(fp->fontName);
    BufferString("-Copy} { /");
    BufferString(fp->fontName);
    BufferStringEOL("} ifelse ");
    BufferString("} {/");
    BufferString(fp->fontName);
    BufferString("}");
    BufferStringEOL(" ifelse");
#else
    BufferString("/");
    BufferString(fp->fontName);
#endif
    BufferStringEOL(" findfont dup ");
    BufferStringEOL("/Private get dup rcheck");
    BufferStringEOL("{begin true}{pop false}ifelse exch");
    BufferStringEOL("/CharStrings get begin");
    BufferFlush();
}

void SendEpilog(BOOL binflag)
{
    int i;
    
    BufferStringEOL("");
    BufferStringEOL("end {end}if");/* end of the charstrings */
    if (!binflag)
        BufferStringEOL("mark currentfile closefile");
    BufferFlush();
    BufferSetEEKey(0, ST_NO_ENCRYPTION);
    BufferStringEOL("");
    if (!binflag) {
        for(i = 0;i < 8;i++)
            BufferStringEOL("0000000000000000000000000000000000000000000000000000000000000000");
        BufferStringEOL("cleartomark");
    }
    BufferFlush();
}
