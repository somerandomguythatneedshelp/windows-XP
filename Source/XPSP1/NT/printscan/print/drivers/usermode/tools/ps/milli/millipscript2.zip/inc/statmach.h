/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: STATMACH.H                                             */
/*                                                                           */
/* Description: This include contains the prototype for state machine        */
/*                                                                           */
/*****************************************************************************/

/*-  _____________________________________________________________________
 *- |
 *- | DRIVER CONTROL-SIDE STATE
 *- |
 *- | The driver's control side has a number of state variables.  They
 *- | are represented by a state machine plus a few independent state 
 *- | variables.  This module provides functions to query and set the
 *- | state machine and other variables.
 *- |
 *- | Calls to the driver's public entry points can cause tokens to be
 *- | generated.  They may also trigger state changes.  The state changes
 *- | may in turn cause tokens to be generated, as side effects.
 *- | One example of this is the interaction between the PASSTHROUGH
 *- | escape and other public entry points which draw on the page.
 *- | The tokens which correspond to calls to the PASSTHROUGH escape
 *- | are preceded and followed by tokens which initiate and terminate
 *- | the sequence.  However, there is no GDI call which explicitly 
 *- | terminates a sequence of PASSTHROUGH escapes -- any public entry
 *- | point which makes marks on the page terminates the sequence.
 *- | So, the state machine emits the initiating and terminating tokens
 *- | as a side effect of state transitions.
 *- |
 *- | There is a diagram of the state machine in ..\dmg\statmach.c.
 *- |______________________________________________________________________ */


//function prototypes

// These routines return TRUE if the current state is one of a set
// of desired states.  Clients should generally use these, because they
// can be more efficient than just OR'ing comparisons with individual 
// state values.

BOOL FAR PASCAL fInDocLppd(
        LPPDEVICE lppd          // Current PDevice (contains state info)
);
                                // Returns TRUE if state is one of those
                                // between StartDoc and EndDoc.

BOOL FAR PASCAL fEnabledLppd(
        LPPDEVICE lppd          // Current PDevice (contains state info)
);
                                // Returns TRUE if state is one of those
                                // between Enable() and Disable().



// Getting and setting current state of the state machine.


//extern ST stCurrentLppd(
//        LPPDEVICE lppd        // Current PDevice (contains state info)
//);
                                // Returns the current state.

BOOL FAR PASCAL fChangeStateLppdSt(
        LPPDEVICE lppd,         // Current PDevice (contains state info)
        ST   st                 // New state to set.
);
                                // Returns TRUE if the state was successfully
                                // set.  (FALSE can mean that the desired
                                // state isn't reachable from the current
                                // one.)


// Other state flags: Minimal header, DisableGDI, and MSRectHack.

//extern BOOL fIsMinHeaderLppd(
//       LPPDEVICE lppd         // Current PDevice (contains state info)
//);
                                // Returns TRUE if GDI imaging is disabled.

//extern void SetIsMinHeaderLppdF(
//       LPPDEVICE lppd,          // Current PDevice (contains state info)
//       BOOL f                   // New value for fIsMinHeader
//);

//extern BOOL fDisableGDILppd(
//       LPPDEVICE lppd           // Current PDevice (contains state info)
//);
                                  // Returns TRUE if GDI imaging is disabled.

//extern void SetDisableGDILppdF(
//       LPPDEVICE lppd,          // Current PDevice (contains state info)
//       BOOL f                   // New value for fDisableGDI
//);


//extern BOOL fDoMSRectHackLppd(
//        LPPDEVICE lppd          // Current PDevice (contains state info)
//);
                                  // Returns TRUE if GDI imaging is disabled.


//extern void SetDoMSRectHackLppdF(
//        LPPDEVICE lppd,         // Current PDevice (contains state info)
//        BOOL f                  // New value for fDoMSRectHack
//);


// Private: implementations of some of the above via macros.


#define stCurrentLppd(lppd)     ((ST) (lppd)->stCurrent)


#define fIsMinHeaderLppd(lppd)  ((BYTEFLAG) (lppd)->job.bfJobMinHeader )

#define SetIsMinHeaderLppdF(lppd, f)            \
            (lppd)->job.bfJobMinHeader = (BYTEFLAG)(f); 

#define fDisableGDILppd(lppd)   ((BOOL) ((lppd)->job.bfDisableGDI))

#define SetDisableGDILppdF(lppd, f)     \
        (lppd)->job.bfDisableGDI = (BYTEFLAG) (f);

#define fDoMSRectHackLppd(lppd) ((BOOL) ((lppd)->job.bfDoMSRectHack))

#define SetDoMSRectHackLppdF(lppd, f)   \
        (lppd)->job.bfDoMSRectHack = (BYTEFLAG) (f);


#define fDisableTranslate(lppd, f)  (lppd)->job.bfReset  = (BYTEFLAG) (f)                   
                                                                                       
#define fNoStateChange( lppd )   ((BOOL) ((lppd)->job.bfReset))
