/*
 *    Adobe Universal Font Library
 *
 *    Copyright (c) 1996 Adobe Systems Inc.
 *    All Rights Reserved
 *
 *    UFO.c - Universal Font Object
 *
 *
 * $Header:
 */

#include "UFO.h"
#include "UFLMem.h"
#include "UFLErr.h"
#include "UFOCff.h"
#include "UFOTTT1.h"
#include "UFOTTT3.h"
#include "UFOT42.h"
#include "UFLStd.h"
#include "ParseTT.h"

/* Private default methods using by the UFO base class */
UFLErrCode
UFODefaultVMNeeded(
    const UFOStruct     *pUFObj,
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMNeeded,
	unsigned long           *pFCNeeded
    )
{
    return kErrInvalidFontType;
}

UFLErrCode
UFODefaultUndefineFont(
    const UFOStruct *pUFObj
)
{
    return kErrInvalidFontType;
}

void
UFODefaultCleanUp(
    UFOStruct *pUFObj
    )
{
}

UFLErrCode
UFODefaultDownloadIncr(
    const UFOStruct     *pUFObj,
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMUsage,
	unsigned long           *pFCUsage
    )
{
    return kErrInvalidFontType;
}


UFOStruct *
UFODefaultCopy(
    UFOStruct *pUFObj
    )
{
    return nil;
}



/* Implementation */

void
UFOInitData(
    UFOStruct           *pUFObj,
    int                 ufoType,
    const UFLMemObj     *pMem,
    const UFLStruct     *pSession,
    const UFLRequest    *pRequest,
    pfnUFODownloadIncr  pfnDownloadIncr,
    pfnUFOVMNeeded      pfnVMNeeded,
    pfnUFOUndefineFont  pfnUndefineFont,
    pfnUFOCleanUp       pfnCleanUp,
    pfnUFOCopy          pfnCopy
    )
{
    short        sEncodeLen = 0;
    short        sNameLen = 0;

    pUFObj->ufoType = ufoType;
    pUFObj->pMem = pMem;
    pUFObj->pUFL = pSession;                                /* the session handle returned by FTLInit */
    pUFObj->hClientData = pRequest->hData;
    pUFObj->lProcsetResID = 0;                              /* Resource ID of the required procset */
    pUFObj->lDownloadFormat = pRequest->lDownloadFormat;

    /* If this flag is set to 1, then UFL will use the name passed in without parsing 'post' table */
    pUFObj->useMyGlyphName = pRequest->useMyGlyphName;

    pUFObj->pszFontName = nil;
    pUFObj->pszEncodeName = nil;
    pUFObj->dwFlags = 0;
    pUFObj->Xuid.sSize = 0;
    pUFObj->Xuid.pXUID = nil;
    pUFObj->bNT4SymbolFont = false;
    pUFObj->bUseHheaForVhea = pRequest->bUseHheaForVhea;  //bug 287084

    /* Allocate a buffer to hold both FontName and EncodeName -
     * will be freed in UFOCleanUpData()  */

    if (pRequest->pszFontName == nil || pRequest->pszFontName[0] == '\0')
	return;

    sNameLen = UFLstrlen(pRequest->pszFontName) + 1; // extra 1 for NULL

    if (pRequest->pszEncodeName)
	sEncodeLen = UFLstrlen(pRequest->pszEncodeName) + 1; // extra 1 for NULL

    pUFObj->pszFontName = (char *) UFLNewPtr(pUFObj->pMem, sNameLen + sEncodeLen);

    if (pUFObj->pszFontName != nil)
    {
	strcpy(pUFObj->pszFontName, pRequest->pszFontName);
	if (pRequest->pszEncodeName)
	{
	    pUFObj->pszEncodeName = pUFObj->pszFontName + sNameLen;
	    strcpy(pUFObj->pszEncodeName, pRequest->pszEncodeName);
	}
    }
        // The buffer that contains MacGlyphNameList 
        // are locked all the time. The containt in that buffer will not
        // be changed. So, we do'nt need to copy the data to the private
        // UFL buffer.

    if (pRequest->pMacGlyphNameList)
        pUFObj->pMacGlyphNameList = pRequest->pMacGlyphNameList;
    else
        pUFObj->pMacGlyphNameList = NULL;
        
    // Fix bug 274008
    if (pRequest->pEncodeNameList &&
        pRequest->pwCommonEncode  &&
        pRequest->pwExtendEncode)
    {
        // The glyph handles are in ANSI codepage order or other
        // standard codepage order (1250, 1251, ... 1257).
        // The buffer that contains EncodeNameList and CommonEncode
        // are locked all the time. The containt in that buffer will not
        // be changed. So, we do'nt need to copy the data to the private
        // UFL buffer.
        pUFObj->pEncodeNameList = pRequest->pEncodeNameList;
        pUFObj->pwCommonEncode  = pRequest->pwCommonEncode;
        pUFObj->pwExtendEncode  = pRequest->pwExtendEncode;
    }
    else
    {
        pUFObj->pEncodeNameList = NULL;
        pUFObj->pwCommonEncode  = NULL;
        pUFObj->pwExtendEncode  = NULL;
    }

    pUFObj->pAFont = nil;

    pUFObj->pUpdatedEncoding = nil;

    if ( pfnDownloadIncr == nil )
	pUFObj->pfnDownloadIncr = (pfnUFODownloadIncr)UFODefaultDownloadIncr;
    else
	pUFObj->pfnDownloadIncr = pfnDownloadIncr;

    if ( pfnVMNeeded == nil )
	pUFObj->pfnVMNeeded = (pfnUFOVMNeeded)UFODefaultVMNeeded;
    else
	pUFObj->pfnVMNeeded = pfnVMNeeded;

    if ( pfnUndefineFont == nil )
	pUFObj->pfnUndefineFont = (pfnUFOUndefineFont)UFODefaultUndefineFont;
    else
	pUFObj->pfnUndefineFont = pfnUndefineFont;

    if ( pfnCleanUp == nil )
	pUFObj->pfnCleanUp = (pfnUFOCleanUp)UFODefaultCleanUp;
    else
	pUFObj->pfnCleanUp = pfnCleanUp;

    if ( pfnCopy == nil )
	pUFObj->pfnCopy = (pfnUFOCopy)UFODefaultCopy;
    else
	pUFObj->pfnCopy = pfnCopy;

}

void UFOCleanUpData(
    UFOStruct *pUFObj
    )
{
    /* Free data that is NOT shared  */
    if (pUFObj->pszFontName)
    {
	UFLDeletePtr(pUFObj->pMem, pUFObj->pszFontName);
	pUFObj->pszFontName = nil;
    }

    if ( pUFObj->pUpdatedEncoding )
    {
	UFLDeletePtr(pUFObj->pMem, pUFObj->pUpdatedEncoding);
	pUFObj->pUpdatedEncoding = nil;
    }

    if (pUFObj->Xuid.pXUID)
    {
	UFLDeletePtr(pUFObj->pMem, pUFObj->Xuid.pXUID);
	pUFObj->Xuid.pXUID = nil;
    }
}

UFLBool
bUFOTestRestricted(
    const UFLMemObj *pMem,
    const UFLStruct *pSession,
    const UFLRequest *pRequest
    )
{
    UFOStruct *pUFObj;
	 UFLBool   bRetVal = 0;

    pUFObj = CFFFontInit( pMem, pSession, pRequest, &bRetVal );
    if ( pUFObj )
	    UFOCleanUp(pUFObj);

    return bRetVal;
}
UFOStruct *
UFOInit(
    const UFLMemObj *pMem,
    const UFLStruct *pSession,
    const UFLRequest *pRequest
    )
{
    UFOStruct *pUFObj;

    switch (pRequest->lDownloadFormat)
    {
    case kCFF:
    case kCFFCID_H:
    case kCFFCID_V:
        pUFObj = CFFFontInit( pMem, pSession, pRequest, NULL );
    break;

    case kTTType1:      /* TT Font, Use type 1 */
        pUFObj = TTT1FontInit( pMem, pSession, pRequest );
    break;

    case kTTType3:                 /* TT Font, Use type 3-only */
    case kTTType332:               /* TT Font, Use type 3/32 combo */
        pUFObj = TTT3FontInit( pMem, pSession, pRequest );
    break;

    case kTTType42:             /* TT Font, Use type 42 */
    case kTTType42CID_H:        /* TT Font, Use CID/42-H */
    case kTTType42CID_V:        /* TT Font, Use CID/42-V */
    case kTTType42CID_Resource_H: /* TT Font, Create CIDFont Resource only, no composefont */
    case kTTType42CID_Resource_V: /* TT Font, Create CIDFont Resource only, no composefont */
        pUFObj = T42FontInit( pMem, pSession, pRequest );
    break;

    default:
        pUFObj = nil;
    }

    return pUFObj;
}


void
UFOCleanUp(
    UFOStruct *pUFObj
    )
{
    /* Free data that is NOT shared  */
    UFOCleanUpData(pUFObj);

    /* Free data that is Shared - decrease refCount or really free buffers  */
    vDeleteFont(pUFObj);

    /* Finally Free the UFOStruct itself */
    UFLDeletePtr(pUFObj->pMem, pUFObj);

}


UFLErrCode
UFODownloadIncr(
    const UFOStruct     *pUFObj,
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMUsage,
	unsigned long           *pFCUsage
    )
{
    /* swong: pFCUsage for T32 FontCache tracking */
    return pUFObj->pfnDownloadIncr(pUFObj, pGlyphs, pVMUsage, pFCUsage );
}


UFLErrCode
UFOVMNeeded(
    const UFOStruct     *pUFObj,
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMNeeded,
    unsigned long       *pFCNeeded
    )
{
    /* swong: pFCNeeded for T32 FontCache tracking */
    return pUFObj->pfnVMNeeded(pUFObj, pGlyphs, pVMNeeded, pFCNeeded );
}


UFLErrCode
UFOUndefineFont(
    const UFOStruct *pUFObj
)
{
    return pUFObj->pfnUndefineFont( pUFObj );
}



UFOStruct *
UFOCopyFont(
    const UFOStruct *pUFObj,
    const UFLRequest* pRequest
    )
{
    return pUFObj->pfnCopy(pUFObj, pRequest);
}



UFLErrCode
UFOGIDsToCIDs(
    const UFOStruct    *pUFO,
    const short        cGlyphs,
    const UFLGlyphID   *pGIDs,
    unsigned short     *pCIDs
)
{
    CFFFontStruct   *pFont;

    if ( pUFO == nil || pUFO->pAFont == nil )
	return kErrInvalidHandle;

    pFont = (CFFFontStruct *) pUFO->pAFont->hFont;

    if ( pUFO->lDownloadFormat == kCFFCID_H ||
	 pUFO->lDownloadFormat == kCFFCID_V )
	return CFFGIDsToCIDs(pFont, cGlyphs, pGIDs, pCIDs);
    else
	return kErrInvalidFontType;
}

UFLErrCode
FindGlyphName(
    UFOStruct           *pUFObj,
    const UFLGlyphsInfo *pGlyphs,
    short               i,           // ANSI index
    unsigned short      wIndex,      // Glyph Index
    char                **pGoodName)
{
    char            *pHintName;
    // Fix bug 274008
    char            **pIndexTable;

    if (pUFObj->useMyGlyphName && pGlyphs->ppGlyphNames )
        pHintName = (char *)pGlyphs->ppGlyphNames[i];
    else
        pHintName = nil;

    if (pUFObj->useMyGlyphName && pHintName != nil)
         *pGoodName = pHintName;
    // Fix bug 274008 Get CharName from pre-defined table.
    // This is only for DownloadFace.
    else if (pUFObj->pEncodeNameList && (i < 256))
    {
        pIndexTable = (char **)(pUFObj->pEncodeNameList);
        if (i < 128)
            *pGoodName = pIndexTable[pUFObj->pwCommonEncode[i]];
        else
            *pGoodName = pIndexTable[pUFObj->pwExtendEncode[i - 128]];
    }
    else
        *pGoodName = GetGlyphName( pUFObj, wIndex, pHintName);

    return kNoErr;
}


/* this function actually generates some PostScript:
 * Updates endocing vector for entries from sStart to sEnd-1 */

UFLErrCode
UpdateEncodingVector(
    UFOStruct           *pUFObj,
    const UFLGlyphsInfo *pGlyphs,
    short int           sStart,
    short int           sEnd
)
{
    char            *pGoodName;
    UFLHANDLE       stream;
    short           i;
    char            buf[16];
    UFLErrCode      retVal = kNoErr ;
    unsigned short  wIndex;

    const static char encodingBegin[] = " findfont /Encoding get";
    const static char encodingEnd[] = "pop";

    if ( pUFObj->flState < kFontInit )
        return kErrInvalidState;

    /* both start and end must be in the range of 0 to sCount */
    if ( sStart < 0 || sEnd > pGlyphs->sCount || sStart >= sEnd)
        return kErrInvalidArg;

    stream = pUFObj->pUFL->hOut;

    retVal = StrmPutString( stream, "/" );
    if ( kNoErr == retVal )
        retVal = StrmPutString( stream, pUFObj->pszFontName );
    if ( kNoErr == retVal )
        retVal = StrmPutStringEOL( stream, encodingBegin );

    for ( i = sStart; retVal == kNoErr && i < sEnd; ++i )
    {
        if ( 0 == pUFObj->pUFL->bDLGlyphTracking || pGlyphs->pCharIndex == nil ||
             !IS_GLYPH_SENT( pUFObj->pUpdatedEncoding, pGlyphs->pCharIndex[i] ) )
        {
            wIndex = (unsigned short) pGlyphs->pGlyphIndices[i] & 0x0000FFFF;  /* loWord is the GID */

            FindGlyphName(pUFObj, pGlyphs, i, wIndex, &pGoodName);

            if (pGlyphs->pCharIndex)
                UFLsprintf(buf, "dup %d /", pGlyphs->pCharIndex[i]);
            else
                UFLsprintf(buf, "dup %d /", i);

            retVal = StrmPutString( stream, buf );
            if (retVal == kNoErr)
                retVal = StrmPutString( stream, pGoodName );
            if (retVal == kNoErr)
                retVal = StrmPutStringEOL( stream, " put");

            if (retVal == kNoErr && pGlyphs->pCharIndex )
                SET_GLYPH_SENT_STATUS( pUFObj->pUpdatedEncoding, pGlyphs->pCharIndex[i] );
        }
    }

    if ( kNoErr == retVal )
        retVal = StrmPutStringEOL( stream, encodingEnd );

    return retVal;

}

UFLErrCode
UpdateCodeInfo(
    UFOStruct           *pUFObj,
    const UFLGlyphsInfo *pGlyphs
)
{
    UFLGlyphID      *glyphs;
    char            *pHintName;
    char            *pGoodName;
    UFLHANDLE       stream;
    short           i;
    char            tempStr[100];
    UFLErrCode      retVal = kNoErr ;
    unsigned short  wIndex;

    if (!pGlyphs->pCode)
        return retVal;

    if ( pUFObj->flState < kFontInit )
        return kErrInvalidState;

    stream = pUFObj->pUFL->hOut;

    /* Output "/FontName /Font" or "/CIDFontResource /CIDFont" */

    if ( IS_TYPE42CID(pUFObj->lDownloadFormat) )
    {
        // IF CID/42-keyed font, then append "cid" to the CIDFont Name
        if ( IS_TYPE42CID_KEYEDFONT(pUFObj->lDownloadFormat) )
        {
            UFLsprintf( tempStr, " /%s%s", pUFObj->pszFontName, gcidSuffix[0]);
        }
        else
        {
            // CID_Resource also uses original fontName, client will produce new
            // names for composed font - with its own CMap !!
            UFLsprintf( tempStr, " /%s", pUFObj->pszFontName );
        }

        if ( kNoErr == retVal )
            retVal = StrmPutString( stream, tempStr );

        if ( kNoErr == retVal )
            retVal = StrmPutString( stream, " /CIDFont" );
    }
    else
    {
        UFLsprintf( tempStr, " /%s", pUFObj->pszFontName );
        if ( kNoErr == retVal )
            retVal = StrmPutString( stream, tempStr );

        if ( kNoErr == retVal )
            retVal = StrmPutString( stream, " /Font" );
    }

    if ( kNoErr == retVal )
        retVal = StrmPutStringEOL( stream, " G2UBegin" );

    glyphs = pGlyphs->pGlyphIndices;

    for ( i = 0; retVal == kNoErr && i < pGlyphs->sCount; ++i)
    {
        wIndex = (unsigned short) glyphs[i] & 0x0000FFFF ; /* loWord is the GlyphID */
        if (wIndex >= UFO_NUM_GLYPHS(pUFObj) )
            continue;

        if (!IS_GLYPH_SENT( pUFObj->pAFont->pCodeGlyphs, wIndex) )
        {

            /* we might not always have a vector of UNICODE encoding*/
            /* don't download anything, just say we did */
            if (pGlyphs->pCode && pGlyphs->pCode[i])
            {
                if ( IS_TYPE42CID(pUFObj->lDownloadFormat) )
                {
                    UFLsprintf(tempStr, "%d ", wIndex );
                }
                else
                {
                    if (pUFObj->useMyGlyphName && pGlyphs->ppGlyphNames )
                        pHintName = (char *)pGlyphs->ppGlyphNames[i];
                    else
                        pHintName = nil;

                    if (pUFObj->useMyGlyphName && pHintName != nil)
                        pGoodName = pHintName;
                    else
                        pGoodName = GetGlyphName( pUFObj, wIndex, pHintName);
                    UFLsprintf(tempStr, "/%s ", pGoodName);
                }

                if (retVal == kNoErr)
                    retVal = StrmPutString( stream, tempStr );

                /* support only one CodePoint per glyph */
                UFLsprintf(tempStr, "<%04X> def", pGlyphs->pCode[i]);

                if (retVal == kNoErr)
                    retVal = StrmPutStringEOL( stream, tempStr );

            }

            SET_GLYPH_SENT_STATUS( pUFObj->pAFont->pCodeGlyphs, wIndex );
        }
    }

    if ( kNoErr == retVal )
        retVal = StrmPutStringEOL( stream, "G2UEnd" );

    return retVal;
}


UFLErrCode
ReEncodePSFont(
    const UFOStruct *pUFObj,
    const char      *pszNewFontName,
    const char      *pszNewEncodingName
)
{
    UFLHANDLE       stream;
    UFLErrCode      retVal = kNoErr ;

    const static char copyFontBegin[] =
        " findfont dup maxlength dict begin {1 index /FID ne {def} {pop pop} ifelse} forall";

    const static char copyFontEnd[] =
        "  currentdict end definefont pop";

    stream = pUFObj->pUFL->hOut;

    retVal = StrmPutString( stream, "/" );
    if ( kNoErr == retVal )
        retVal = StrmPutString( stream, pszNewFontName );

    if ( kNoErr == retVal )
        retVal = StrmPutString( stream, "/" );
    if ( kNoErr == retVal )
        retVal = StrmPutString( stream, pUFObj->pszFontName );
    if ( kNoErr == retVal )
        retVal = StrmPutStringEOL( stream, copyFontBegin );

    /* put a new encoding vectory here */
    if ( kNoErr == retVal )
        retVal = StrmPutString( stream, "/Encoding " );
    if ( kNoErr == retVal )
    {
        if ( pszNewEncodingName == nil )
            retVal = StrmPutString( stream, gnotdefArray );
        else
            retVal = StrmPutString( stream, pszNewEncodingName );
    }
    if ( retVal == kNoErr )
        retVal = StrmPutStringEOL( stream, " def" );

    if ( kNoErr == retVal )
        retVal = StrmPutStringEOL( stream, copyFontEnd );

    return retVal;

}




UFLErrCode
NewFont(
    UFOStruct           *pUFObj,
    unsigned long       dwSize,
    const long          cGlyphs
)
{
    UFLErrCode      retVal = kNoErr ;

    if (pUFObj->pAFont == nil)
    {
        pUFObj->pAFont = (AFontStruct*) (UFOHandle)UFLNewPtr(pUFObj->pMem, sizeof(AFontStruct) );

        if (pUFObj->pAFont)
        {

            pUFObj->pAFont->hFont = (UFOHandle) UFLNewPtr(pUFObj->pMem, dwSize);
            if (pUFObj->pAFont->hFont)
            {
                /* Allocate the space for both pDownloadedGlyphs, pVMGlyphs and pCodeGlyphs at the same time */
                pUFObj->pAFont->pDownloadedGlyphs = (unsigned char *)UFLNewPtr(pUFObj->pMem, GLYPH_SENT_BUFSIZE(cGlyphs) * 3 );

                if (pUFObj->pAFont->pDownloadedGlyphs != nil)
                {                            /* Initialize this array - currently nothing is downloaded */
                    pUFObj->pAFont->pVMGlyphs = (unsigned char *) pUFObj->pAFont->pDownloadedGlyphs + GLYPH_SENT_BUFSIZE(cGlyphs) ;
                    pUFObj->pAFont->pCodeGlyphs = (unsigned char *)(unsigned char *) pUFObj->pAFont->pVMGlyphs + GLYPH_SENT_BUFSIZE(cGlyphs) ;
                }
                else
                    retVal = kErrOutOfMemory;
           }
           else
                retVal = kErrOutOfMemory;

        }
        else
            retVal = kErrOutOfMemory;
    }

    if (pUFObj->pAFont != nil)
        AFONT_AddRef(pUFObj->pAFont);

    return retVal;
}


void
vDeleteFont
(
UFOStruct
*pUFObj
)

{
    if (pUFObj->pAFont != nil)
    {

        /* Decrease RefCount */
        AFONT_Release(pUFObj->pAFont);

        if (AFONT_RefCount(pUFObj->pAFont) == 0 )
        {
            /* free format (Type1/3/42/cff) dependent shared data */
            pUFObj->pfnCleanUp(pUFObj);

            /* free Common shared data */

            if (pUFObj->pAFont->hFont)
                UFLDeletePtr(pUFObj->pMem, pUFObj->pAFont->hFont);

            if (pUFObj->pAFont->pDownloadedGlyphs)
                UFLDeletePtr(pUFObj->pMem, pUFObj->pAFont->pDownloadedGlyphs);

            if (pUFObj->pAFont->pTTpost)
                UFLDeletePtr(pUFObj->pMem, pUFObj->pAFont->pTTpost);

            UFLDeletePtr(pUFObj->pMem, pUFObj->pAFont);
            pUFObj->pAFont = nil;
        }

    }

}


UFOStruct *
CopyFont(
    const UFOStruct *pUFO,
    const UFLRequest* pRequest
    )

{
    UFOStruct   *pUFObj;
    short       sEncodeLen = 0;
    short       sNameLen = 0;
    long        fontStructSize, maxGlyphs;
    const char  *pszNewFontName;
    const char  *pszNewEncodingName;

    /* cannot/shouldnot copy a font if it is not created yet -prevent "courier" in the way */
    if (pUFO->flState < kFontHeaderDownloaded)
        return nil;

    pszNewFontName = pRequest->pszFontName;
    pszNewEncodingName = pRequest->pszEncodeName;

    if (pszNewFontName == nil || pszNewFontName[0] == '\0')
        return nil;

    // Determine downloaded font type
    switch (pUFO->ufoType)
    {
    case UFO_CFF:

        fontStructSize = sizeof(CFFFontStruct);
        maxGlyphs = ((CFFFontStruct *) pUFO->pAFont->hFont)->info.fData.maxGlyphs;
        break;

    case UFO_TYPE1:

        fontStructSize = sizeof(TTT1FontStruct);
        maxGlyphs = ((TTT1FontStruct *) pUFO->pAFont->hFont)->info.fData.maxGlyphs;
        break;

    case UFO_TYPE42:

        fontStructSize = sizeof(T42FontStruct);
        maxGlyphs = ((T42FontStruct *) pUFO->pAFont->hFont)->info.fData.maxGlyphs;
        break;

    case UFO_TYPE3:

        fontStructSize = sizeof(TTT3FontStruct);
        maxGlyphs = ((TTT3FontStruct *) pUFO->pAFont->hFont)->info.fData.maxGlyphs;
        break;

    default:
        return nil;
    }

    // Allocate memory for the UFOStruct and do a shallow copy

    pUFObj = (UFOStruct *) UFLNewPtr( pUFO->pMem, sizeof(UFOStruct) );

    if ( pUFObj == 0 )
        return nil;

    memcpy(pUFObj, pUFO, sizeof(UFOStruct));
    pUFObj->pszFontName = nil;
    pUFObj->pszEncodeName = nil;
    pUFObj->pUpdatedEncoding = nil;

    // BUGBUG - Should we do a deep copy of pXUID here?
    // We used to be not doing anything with pXUID ID, which is causing
    // the same memory to be freed more than once, resulting in a system crash.

    pUFObj->Xuid.sSize = 0;
    pUFObj->Xuid.pXUID = nil;

    /* actually NewFont== AddRef: */

    if ( NewFont(pUFObj, fontStructSize, maxGlyphs) != kNoErr )
    {
        /* actually Delete == Release */

        vDeleteFont(pUFObj);
        UFLDeletePtr(pUFObj->pMem, pUFObj);
        return nil;
    }

    /* now allocate for non-shared data */

    /* Allocate a buffer to hold both FontName and EncodeName -
     * will be freed in UFOCleanUpData()  */

    sNameLen = UFLstrlen(pszNewFontName) + 1; // extra 1 for NULL
    if (pszNewEncodingName)
        sEncodeLen = UFLstrlen(pszNewEncodingName) + 1;

    pUFObj->pszFontName = (char *) UFLNewPtr(pUFObj->pMem, sNameLen + sEncodeLen);

    if (pUFObj->pszFontName != nil)
    {
        strcpy(pUFObj->pszFontName, pszNewFontName);

        if (pszNewEncodingName)
        {
            pUFObj->pszEncodeName = pUFObj->pszFontName + sNameLen;
            strcpy(pUFObj->pszEncodeName, pszNewEncodingName);
        }
    }

    /* pszFontName should be ready/allocated - if not FontName, cannot continue */

    if (pUFObj->pszFontName == nil || pUFObj->pszFontName[0] == '\0')
    {
        /* actually Delete == Release */

        vDeleteFont(pUFObj);
        UFLDeletePtr(pUFObj->pMem, pUFObj->pszFontName);
        UFLDeletePtr(pUFObj->pMem, pUFObj);
            return nil;
    }

    /* BUT we need different EncodingVector for this newNamed copy if we need to update it*/

    if (pUFObj->pszEncodeName == nil || pUFObj->pszEncodeName[0] == '\0')
    {
        pUFObj->pUpdatedEncoding = (unsigned char *)UFLNewPtr(pUFObj->pMem, GLYPH_SENT_BUFSIZE(256));
    }
    else
    {
        /* the encoding is supplied and so are the glyph/char names later*/
    }

    /* Setup the new ClientData for this copy */
    pUFObj->hClientData = pRequest->hData;

    ReEncodePSFont( pUFO, pUFObj->pszFontName, pUFObj->pszEncodeName);

    return pUFObj;
}

void
VSetNumGlyphs(
    UFOStruct *pUFO,
    unsigned long cNumGlyphs
)
{
    TTT1FontStruct  *pFont = (TTT1FontStruct *) pUFO->pAFont->hFont;

    pFont->info.fData.cNumGlyphs = cNumGlyphs;
    return;
}

// Fix bug 274008
UFLBool
ValidGlyphName(
    const UFLGlyphsInfo *pGlyphs,
    short               i,           // ANSI index
    unsigned short      wIndex,      // Glyph Index
    char                *pGoodName)
{
    UFLGlyphID      *glyphs;
    glyphs = pGlyphs->pGlyphIndices;

    if ( i < pGlyphs->sCount)
    {
        if (UFLstrcmp( pGoodName, Notdef ) == 0)
        {
            if (wIndex != (unsigned short) (glyphs[0] & 0x0000FFFF))
                return false;
        }
        else if (UFLstrcmp( pGoodName, UFLSpace ) == 0)
        {
            if (wIndex != (unsigned short) (glyphs[0x20] & 0x0000FFFF))
                return false;
        }
        else if (UFLstrcmp( pGoodName, Hyphen ) == 0)
        {
            if (wIndex != (unsigned short) (glyphs[0x2d] & 0x0000FFFF))
                return false;
        }
        else if (UFLstrcmp( pGoodName, Bullet ) == 0)
        {
            if (wIndex != (unsigned short) (glyphs[0x95] & 0x0000FFFF))
                return false;
        }
    }
    return true;
}

