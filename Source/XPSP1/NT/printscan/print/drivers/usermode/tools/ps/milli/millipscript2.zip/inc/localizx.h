/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: LOCALIZX.H                                             */
/*                                                                           */
/* Description: This include file contains prototype for ...                 */
/*                                                                           */
/*****************************************************************************/

#define LID_null                                0
#define LID_errorcaption                        1
#define LID_errormembegin                       2
#define LID_errormemnomemory                    3
#define LID_errormemgeneral                     4
#define LID_errormemend                         5
#define LID_errortransbegin                     6
#define LID_errortransnotqfile                  7
#define LID_errortransend                       8
#define LID_errorfilebegin                      9
#define LID_errorfilecreate                    10
#define LID_errorfileopen                      11
#define LID_errorfileseek                      12
#define LID_errorfileread                      13
#define LID_errorfilereadimmediate             14
#define LID_errorfilereadEOF                   15
#define LID_errorfilewrite                     16
#define LID_errorfilewriteEOF                  17
#define LID_errorfileclose                     18
#define LID_errorfiledelete                    19
#define LID_errorfilehandle                    20       //an internal error
#define LID_errorfilename                      21       //an internal error
#define LID_errorfileend                       22
#define LID_errordmbegin                       23
#define LID_errordminuse                       24
#define LID_errordmend                         25
#define LID_errorspoolbegin                    26
#define LID_errorspoolend                      27
#define LID_errormsspoolbegin                  28
#define LID_errormsspoolgeneral                29
#define LID_errormsspoolappabort               30
#define LID_errormsspooluserabort              31
#define LID_errormsspooloutofdisk              32
#define LID_errormsspooloutofmem               33
#define LID_errormsspoolend                    34
#define LID_errorcommbegin                     35
#define LID_errorcommopen                      36
#define LID_errorcommopendual                  37
#define LID_errorcommclose                     38
#define LID_errorcommclosedual                 39
#define LID_errorcommread                      40
#define LID_errorcommreaddual                  41
#define LID_errorcommwrite                     42
#define LID_errorcommend                       43
#define LID_errorfontbegin                     44
#define LID_errorfontindex                     45
#define LID_errorfontdirectory                 46
#define LID_errorfontdirectoryread             47
#define LID_errorfontend                       48
#define LID_yes                                49
#define LID_no                                 50
#define LID_blurb                              51
#define LID_sendoutputto                       52
#define LID_landscape                          53
#define LID_end                                54
