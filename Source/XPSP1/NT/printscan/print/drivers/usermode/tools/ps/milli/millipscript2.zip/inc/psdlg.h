/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: PSDLG.H                                                */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHPostScriptDlg(HWND hdlg, unsigned msg, WORD wParam, 
                                        LONG lParam);
void FAR PASCAL RestorePostScriptDefaults(LPPSEXTDEVMODE lpPSExtDevmode,
                                          LPWPXBLOCKS lpWPXBlock,
                                          DWORD dwUIFlags);
