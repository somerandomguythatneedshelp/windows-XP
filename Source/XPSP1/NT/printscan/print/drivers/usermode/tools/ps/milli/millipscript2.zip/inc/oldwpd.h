/* 3.1 WPD Structures--combination of printcaps.h and fontinfo.h.
 * Constants have been modified to be unaffected by future changes
 * to windows.h
 */

// offsets for resources--can be changed as needed
#define PAPER_START     200  // 200-456
#define BIN_START       100  // 100-199
//  the stringID range 500-700  is reserved for errorMsg strings

// Offsets of indices in old string table
#define NORMALIMAGE       0L
#define MANUALIMAGE       4L
#define MANUALSWITCH      8L
#define SEL_INPUTSLOT        12L
#define TRANSFER         16L     // This is not used in the new format
#define WINDOWSAUTO      20L     // I don't think that this is used anywhere
#define SEL_DUPLEX           24L

// From old PRINTCAP.H

#define OLDNUMFEEDS      15      // (DMBIN_LAST-DMBIN_FIRST+2) = 14-1+2
#define OLDNUMPAPERS     41      // (DMPAPER_LAST-DMPAPER_FIRST+1) = 41-1+1
#define OLDNUMDEVICERES   4
#define OLDNUMDUPLEX      3

#define OLDCAPS_SIMPLEX      0x0001
#define OLDCAPS_DUPLEX_VERT  0x0002
#define OLDCAPS_DUPLEX_HORZ  0x0004
#define OLDCAPS_TRUETYPE     0x0008
#define OLDCAPS_TRUEIMAGE    0x0010
#define OLDCAPS_SETPAGE      0x0020

#define WIN31WPDVERSION      (0x0002)  // pPrinter->version # for 3.1 WPD


/*	Additional duplex constant.
 */
#define OLDCAPS_DUPLEX       (OLDCAPS_DUPLEX_VERT | OLDCAPS_DUPLEX_HORZ)

/*	Macro for detecting duplex.
 */
#define OLDIS_DUPLEX(pPrinter) \
	(((pPrinter)->version >= WIN31WPDVERSION) && ((pPrinter)->iCapsBits & OLDCAPS_DUPLEX))

/*	Macro for detecting truetype.
 */
#define OLDACCEPTS_TRUETYPE(pPrinter) \
	(((pPrinter)->version >= WIN31WPDVERSION) && ((pPrinter)->iCapsBits & OLDCAPS_TRUETYPE))

/*	Macro for detecting trueimage devices.
 */
#define OLDIS_TRUEIMAGE(pPrinter) \
	(((pPrinter)->version >= WIN31WPDVERSION) && ((pPrinter)->iCapsBits & OLDCAPS_TRUEIMAGE))

/* Macro for detecting devices supporting setpage to implement custom sizes
 */
#define OLDIS_SETPAGE(pPrinter) \
   (((pPrinter)->version >= WIN31WPDVERSION) && ((pPrinter)->iCapsBits & OLDCAPS_SETPAGE))

typedef struct {
	int iPaperType;
	RECT rcImage;
} OLDPAPER_REC, *POLDPAPER_REC, FAR *LPOLDPAPER_REC;


typedef struct {
	int	version;		// version number
	char	Name[32];		/* the printer name */
	int	defFeed;		/* default feeder (DMBIN_*) */
	BOOL	feed[OLDNUMFEEDS];
	int	defRes;
	int	defJobTimeout;
	BOOL	fEOF;
	BOOL	fColor;
	int	ScreenFreq;	// in 10ths of an inch
	int	ScreenAngle;	// in 10ths of a degree
        int     iMaxVM;         // amount of printer VM in K
	int	iDeviceRes[OLDNUMDEVICERES]; // device resolutions
	int	iCapsBits;	// various capabilities bits
	int	iNumPapers;	/* # of paper sizes supported */
	OLDPAPER_REC Paper[1];	/* variable size array of papers supported */
} OLDPRINTER, FAR *LPOLDPRINTER, *POLDPRINTER;


typedef struct { 
	DWORD	cap_loc;
	WORD	cap_len;
	DWORD	dir_loc;
	WORD	dir_len;
	DWORD	pss_loc;
	WORD	pss_len;
} OLDPS_RES_HEADER, *POLDPS_RES_HEADER, FAR *LPOLDPS_RES_HEADER;


// From old FONTINFO.H

typedef struct {
    short int dfType;
    short int dfPoints;
    short int dfVertRes;
    short int dfHorizRes;
    short int dfAscent;
    short int dfInternalLeading;
    short int dfExternalLeading;
    BYTE dfItalic;
    BYTE dfUnderline;
    BYTE dfStrikeOut;
    short int	dfWeight;
    BYTE dfCharSet;
    short int dfPixWidth;
    short int dfPixHeight;
    BYTE dfPitchAndFamily;
    short int dfAvgWidth;
    short int dfMaxWidth;
    BYTE dfFirstChar;
    BYTE dfLastChar;
    BYTE dfDefaultChar;
    BYTE dfBreakChar;
    short int	dfWidthBytes;
    unsigned long int	dfDevice;
    unsigned long int	dfFace;
    unsigned long int	dfBitsPointer;
    unsigned long int	dfBitsOffset;
    WORD dfSizeFields;
    DWORD dfExtMetricsOffset;
    DWORD dfExtentTable;
    DWORD dfOriginTable;
    DWORD dfPairKernTable;
    DWORD dfTrackKernTable;
    DWORD dfDriverInfo;
    DWORD dfReserved;
} OLDFONTINFO;
typedef OLDFONTINFO FAR *LPOLDFONTINFO;


/* The format of the printer font metrics file */

typedef struct {
    WORD dfVersion;
    DWORD dfSize;
    char dfCopyright[60];
    OLDFONTINFO df;
} OLDPFM;
typedef OLDPFM FAR *LPOLDPFM;


// I couldn't find this structure declared anywhere, so I'll put it here
// for now. There are actually three NUll-terminated strings after the
// FONTINFO structure. They are pointed to within the structure,
// with the beginning of the OLDFONTINFO structure assumed as offset 0.
// df.dfDevice      points to the device name (i.e., "PostScript")
// df.dfFace        points to the face name   (i.e., "Helvetica")
// font_name_offset points to the font name   (i.e., "hm")
typedef struct tagFONTENTRY
{
  short       size;
  short       font_name_offset;
  OLDFONTINFO df;
} FONTENTRY, *PFONTENTRY, FAR *LPFONTENTRY;


// Stuff from printers.h

// Extra DMPAPER_* values
#define OLDDMPAPER_LETTER_EXTRA            50  
#define OLDDMPAPER_LEGAL_EXTRA             51  
#define OLDDMPAPER_TABLOID_EXTRA           52  
#define OLDDMPAPER_A4_EXTRA                53  
#define OLDDMPAPER_LETTER_TRANSVERSE       54
#define OLDDMPAPER_A4_TRANSVERSE           55
#define OLDDMPAPER_LETTER_EXTRA_TRANSVERSE 56
#define OLDDMPAPER_A_PLUS                  57 
#define OLDDMPAPER_B_PLUS                  58 
#define OLDDMPAPER_LETTER_PLUS             59
#define OLDDMPAPER_A4_PLUS                 60 
#define OLDDMPAPER_A5_TRANSVERSE           61
#define OLDDMPAPER_B5_TRANSVERSE           62
#define OLDDMPAPER_A3_EXTRA                63
#define OLDDMPAPER_A5_EXTRA                64
#define OLDDMPAPER_B5_EXTRA                65
#define OLDDMPAPER_A2                      66
#define OLDDMPAPER_A3_TRANSVERSE           67
#define OLDDMPAPER_A3_EXTRA_TRANSVERSE     68
#define OLDDMPAPER_LAST                    OLDDMPAPER_A3_EXTRA_TRANSVERSE
#define OLDDMPAPER_USER                   256

// Private DMBIN_* values
#define OLDDMBIN_FIRST          OLDDMBIN_UPPER
#define OLDDMBIN_UPPER          1
#define OLDDMBIN_LOWER          2
#define OLDDMBIN_MIDDLE         3
#define OLDDMBIN_MANUAL         4
#define OLDDMBIN_ENVELOPE       5
#define OLDDMBIN_ENVMANUAL      6
#define OLDDMBIN_AUTO           7
#define OLDDMBIN_LARGECAPACITY 11
#define OLDDMBIN_CASSETTE      14
#define OLDDMBIN_LAST          OLDDMBIN_CASSETTE

// Miscellaneous definitions
#define _MAX_PATH             260
#define _MAX_NAMEONLY          13

#define NULLTERMINATED  ((WORD)-1)
#define NOMAP           ((WORD)-1)

// OFFSETINTOPI(lpArray)
//     lpArray is a pointer to an array of data
//     returns the offset minus the header size
#define OFFSETINTOPI(lpArray) ((WORD)((OFFSETOF(lpArray)-sizeof(OLDPS_RES_HEADER))))

// GET_PS_DWORD(lpOldData,dwOffset)
//     lpOldData is the beginning of the old string list.
//     dwOffset is the offset of the lookup in the string block
//     returns the DWORD pointed to
#define GET_PS_DWORD(lpOldData,dwOffset) *((LPDWORD)(((LPSTR)(lpOldData))+(dwOffset)))

// ADVANCE_BYTES(lpBase,Offset)
//     lpbase is a far pointer to the base location, which usually won't
//     be in bytes. Offset is the number of bytes to advance.
//     returns a LPSTR to lpbase+Offset bytes
#define ADVANCE_BYTES(lpBase,Offset) (((LPSTR)(lpBase))+(Offset))

// abs(a)
//  Standard definition of absolute value
#define abs(a) ((a)>=0?(a):(-(a)))

// This is an array of page dimensions (in .01 inch) for known page sizes.
// One entry per supported paper size, except DMPAPER_USER
typedef struct tagPAGEDIMENSION
{
  WORD     width;
  WORD     length;
  DSPUNITS NaturalUnit;
  BOOL     bUsed;
} PAGEDIMENSION;

// We need to map the compressed font names back to their original names.
typedef struct tagFONTMAP
{
  PSTR pszShortName;
  PSTR pszFullName;
} FONTMAP;


UINT FAR PASCAL GetDriverDirectory(LPSTR lpDir, WORD cnt);


