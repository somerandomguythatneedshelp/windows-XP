/**************************************************************************/
/*                                                                        */
/* GENERIC.H -- global include file for pscript driver                    */
/*                                                                        */
/**************************************************************************/


#define _DEBUGSEG       "_DEBUG"
#define _DEVMODESEG     "_DEVMODE"
#define _DIALOGSSEG     "_DIALOGS"
#define _DIBSEG         "_DIB"
#define _ENABLESEG      "_ENABLE"
#define _ENUMSEG        "_ENUM"
#define _ENUMERATORSEG  "_ENUMERATOR"
#define _EPSFUNCSSEG    "_EPSFUNCS"
#define _ESCAPESSEG     "_ESCAPES"
#define _ESCSTUBSSEG    "_ESCSTUBS"
#define _GRAPHSEG       "_GRAPH"
#define _LEVEL2SEG      "_LEVEL2"
#define _PORTSEG        "_PORT"
#define _REALIZESEG     "_REALIZE"
#define _STATESEG       "_STATE"
#define _STUBSSEG       "_STUBS"
#define _TESCAPESSEG    "_TESCAPES"
#define _TEXTSEG        "_TEXT"
#define _TEXTOUTSEG     "_TEXTOUT"
#define _TGRAPHSEG      "_TGRAPH"
#define _TRANSSEG       "_TRANS"
#define _TSTARTSEG      "_TSTART"
#define _TTFONTSSEG     "_TTFONTS"
#define _TUTILSSEG      "_TUTILS"
#define _UTILSSEG       "_UTILS"
#define _PFMPARSESEG    "_PFMPARSE"
#define _PARSE1SEG      "_PARSE1"
#define _PARSE2SEG      "_PARSE2"
#define _PARSE3SEG      "_PARSE3"
#define _FILEMAN1SEG    "_FILEMAN1"
#define _UPGRADESEG     "_UPGRADE"
#define _ICMSEG         "_ICM"
#define _ICM2SEG        "_ICM2"
#define _ICM3SEG        "_ICM3"
#define _OLDWPDSEG      "_OLDWPD"
#define _WATERMARKSEG      "_WATERMARK"
#define _FONTSDIALOGSEG    "_FONTSDIALOG"
#define _TTEXTSEG      "_TTEXT"

#define DEBUGSEG      __based(__segname(_DEBUGSEG))
#define DEVMODESEG    __based(__segname(_DEVMODESEG))
#define DIALOGSSEG    __based(__segname(_DIALOGSSEG))
#define DIBSEG        __based(__segname(_DIBSEG))
#define ENABLESEG     __based(__segname(_ENABLESEG))
#define ENUMSEG       __based(__segname(_ENUMSEG))
#define ENUMERATORSEG __based(__segname(_ENUMERATORSEG))
#define EPSFUNCSSEG   __based(__segname(_EPSFUNCSSEG))
#define ESCAPESSEG    __based(__segname(_ESCAPESSEG))
#define ESCSTUBSSEG   __based(__segname(_ESCSTUBSSEG))
#define GRAPHSEG      __based(__segname(_GRAPHSEG))
#define LEVEL2SEG     __based(__segname(_LEVEL2SEG))
#define PORTSEG       __based(__segname(_PORTSEG))
#define REALIZESEG    __based(__segname(_REALIZESEG))
#define STATESEG      __based(__segname(_STATESEG))
#define STUBSSEG      __based(__segname(_STUBSSEG))
#define TESCAPESSEG   __based(__segname(_TESCAPESSEG))
#define TEXTSEG       __based(__segname(_TEXTSEG))
#define TEXTOUTSEG    __based(__segname(_TEXTOUTSEG))
#define TGRAPHSEG     __based(__segname(_TGRAPHSEG))
#define TRANSSEG      __based(__segname(_TRANSSEG))
#define TSTARTSEG     __based(__segname(_TSTARTSEG))
#define TTFONTSSEG    __based(__segname(_TTFONTSSEG))
#define TUTILSSEG     __based(__segname(_TUTILSSEG))
#define UTILSSEG      __based(__segname(_UTILSSEG))
#define PFMPARSESEG   __based(__segname(_PFMPARSESEG))
#define PARSE1SEG     __based(__segname(_PARSE1SEG))
#define PARSE2SEG     __based(__segname(_PARSE2SEG))
#define PARSE3SEG     __based(__segname(_PARSE3SEG))
#define FILEMAN1SEG   __based(__segname(_FILEMAN1SEG))
#define UPGRADESEG    __based(__segname(_UPGRADESEG))
#define ICMSEG        __based(__segname(_ICMSEG))
#define ICM2SEG       __based(__segname(_ICM2SEG))
#define ICM3SEG       __based(__segname(_ICM3SEG))
#define OLDWPDSEG     __based(__segname(_OLDWPDSEG))
#ifdef ADOBE_DRIVER
#define WATERMARKSEG     __based(__segname(_WATERMARKSEG))
#endif
#define FONTSDIALOGSEG     __based(__segname(_FONTSDIALOGSEG))
#define TTEXTSEG     __based(__segname(_TTEXTSEG))


#include "errors.h"
#include "ps.h"
#include "keywfunc.h"
#include "..\dmg\dmg.h"
#include "..\dmg\dlgsfunc.h"
#include "..\dmg\chicago.h"
#include "ps_enumx.h"
#include "..\cont\cont.h"
// #include "..\cont\fonts.h"
#include "..\tran\pswtrans.h"
#include "..\tran\lv1funcs.h"
#include "..\tran\lv2funcs.h"
#include <commdlg.h>
#include <stdlib.h>
#include <time.h>
#include <dos.h>
#include <io.h>
#include <direct.h>
#include <limits.h>
#include <math.h>
#include <memory.h>
#include <commctrl.h>
#include <winerror.h>
#include "enumx.h"

// #include "addprn.h"
#include "advanced.h"
#include "atm.h"
#include "bitmap.h"
#include "cfont.h"
#include "cfuncs.h"
#include "concatx.h"
#include "custpap.h"
#include "clrdlg.h"
#include "csprof.h"
#include "getcsa.h"
#include "getcrd.h"
#include "profcrd.h"
#include "margins.h"
#include "device.h"
#include "devmode2.h"
#include "dlgid.h"
// #include "dlgs2.h"
#include "dlgsutil.h"
// #include "drivinit.h"
#include "drvfuncs.h"
#include "drvrdll.h"
#include "drvrmem.h"
#include "drvstate.h"
#include "enable.h"
#include "encode.h"
#include "enumfont.h"
#include "enumobj.h"
#include "enumstub.h"
#include "epsfuncs.h"
#include "errorid.h"
// #include "errors.h"
// #include "errors1.h"
#include "escapes.h"
// #include "escmg.h"
// #include "fax.h"
#include "file.h"
#include "fntcache.h"
#include "fonts.h"
// #include "fontutil.h"
// #include "gdi.h"
// #include "gdidm.h"
#include "getcharw.h"
// #include "globals.h"
#include "glstatic.h"
#include "graphics.h"
// #include "helper.h"
#include "jobdlg.h"

#include "lcalls.h"
// #include "localizx.h"
#include "oem.h"
// #include "optimize.h"
#include "paper.h"
// #include "pfm.h"
#include "pixel.h"
#include "port.h"
// #include "ppdparse.h"
#include "prntrmgr.h"
// #include "propsh.h"
#include "psdlg.h"
#include "ps_debug.h"
#include "qfile.h"
// #include "qprocs.h"
#include "qtokens.h"
#include "realize.h"
#include "resource.h"
#include "resourcx.h"
#include "resrcid.h"
// #include "spin.h"
// #include "spooler.h"
#include "statmach.h"
#include "status.h"
#include "stretchb.h"
#include "stretchd.h"
#include "sysrsrc.h"
#include "tflavors.h"
#include "trans.h"
// #include "trig.h"
#include "truetype.h"
#include "tstubs.h"
#include "ttdialog.h"
#include "ttext.h"
#include "ttfonts.h"
#include "tutils.h"
#include "unconcat.h"
#include "upgrade.h"
#include "uic.h"
#include "utils.h"
// #include "vecttext.h"
// #include "vttable.h"
#include "wpxinfo.h"
#include "wstdarg.h"
// #include "xfile.h"

#include "pfmparse.h"
#include "ppdparse.h"
#include "..\wpx\fproto.h"
#include "errorid.h"

#include "vmem.h"
#include "psdebug.h"
#include "oldwpd.h"

/* OEMPLUGI begin */
#include "oemplugi.h"
#include "oemstubs.h"
#include "devcapex.h"
/* OEMPLUGI end */

#include "dbcs.h"

#include "watermar.h"
#include "mmfonts.h"

extern DWORD __far dwHelpMap[];

