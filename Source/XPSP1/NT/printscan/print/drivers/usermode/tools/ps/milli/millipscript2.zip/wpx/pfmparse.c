/***********************************************************************

    MODULE:  pfmparse.c

    PROGRAM: 

    PURPOSE: Contains functions that parse pfm files and create mfd 
             files.

    FUNCTIONS:

***********************************************************************/

#include  "generic.h"
#include  "regsetup.h"
#pragma code_seg(_PFMPARSESEG)

LPBYTE StrHeap;
unsigned int date, ttime;

/*****************************************************************************
*                               ConvertFontsToMFD
*  Purpose:  This function converts all the fonts found in the Host PostScript
*  Fonts Registry, the True Type Fonts in the Registry and the possible 
*  ROM font in ADFONTS.MFM convert them to FONTSDIR.MFM
*
*  Input:  lpszMFDPath - full path of where the MFD will be store.
*          hpFontFile - list of all the fonts (PS&TT) from the registry
*          wNumFonts - number of fonts.
*          dwPSFRSerialNo - Host Postscript Fonts Serial number
*          dwTTFRSerialNo - True Type Fonts Serial number
*          dwMFMTimeStamp - ADFonts.MFM time Stamp ID.        
*          lpFriendlyName - printer current FriendlyName
*  Output:
*       RC_OK if successful, else RC_ERROR.
***************************************************************************/
WORD FAR PASCAL ConvertFontsToMFD(LPSTR lpszMFDPath, HPFONTFILE hpFontFile, WORD wNumFonts,
         DWORD dwPSFRSerialNo, DWORD dwTTFRSerialNo, DWORD dwMFMTimeStamp,
         LPSTR lpszFriendlyName)
{
   HFILE hfile = NULL, hMFMFile = NULL, hPPDMFMFile = NULL;
   OFSTRUCT ofFileStruct;
   WORD rc = RC_ERROR;
   LPFONTDIRECTORY lpFontDir = NULL;
   HPFONTDIRECTORY hpFontDir = NULL;
   HPFONTDIRECTORY hpTempFontDir = NULL;
   HPFONTDIRECTORY hpMatchDir = NULL;
   WORD count = 0;
   WORD wTempNumFonts = 0;
   WORD index = 0;
   LPPFMPROLOG FAR *lpfmList;
   DWORD           dwDirOffset = 0;
   DWORD           dwOffset = 0;
   LPFILEHDR       lpFileHdr = NULL;
   WORD  wSkippedFiles = 0;
   WORD wMFMFonts = 0;
   WORD wPPDMFMFonts = 0;
   char szMFMPath[BUF_SIZE];
   MFMHDR mfmHdr;
   FileRecord      *lpMFMFileRecord  =NULL;
   DWORD dwPFMSize = 0;
   long lFileInfoSize = 0;
   WORD wFontInfoSize = 0;
   LPFONTINFO lpFontInfo = NULL; 
   DWORD dwTempFontDirSize = 0;
   BOOL bMatch = TRUE;
	DWORD dwNewFontDirSize = 0;
   char  szMFMFileName[MFM_NAME_LENGTH];

   /* Open MFD File*/
   if ((hfile = OpenFile(lpszMFDPath, (LPOFSTRUCT) &ofFileStruct,
         OF_CREATE| OF_WRITE)) == HFILE_ERROR)
   {
      goto cleanup;
   }

   /* count number of fonts in MFM*/
   if (dwMFMTimeStamp)
   {
      //Get Full MFM path
      LoadString(ghDriverMod, IDS_MFM_FILE, szMFMFileName, MFM_NAME_LENGTH);

      GetMFMPath(szMFMPath, BUF_SIZE, szMFMFileName);
      if ((hMFMFile = OpenFile(szMFMPath, (LPOFSTRUCT)&ofFileStruct, OF_READ)) != HFILE_ERROR)
      {
         if (_lread(hMFMFile, (HPVOID) &mfmHdr, sizeof(MFMHDR)) == sizeof(MFMHDR)) 
           wMFMFonts = mfmHdr.wNumPFMBlocks;
      }
   }
   // look for OEM support PPDName.MFM if any
   if ((hPPDMFMFile = IsPPDMFMExist(lpszFriendlyName)) != NULL)
   {
        if (_lread(hPPDMFMFile, (HPVOID) &mfmHdr, sizeof(MFMHDR)) == sizeof(MFMHDR)) 
           wPPDMFMFonts = mfmHdr.wNumPFMBlocks;
      
   }

   /* Allocate space for the MFD file*/
   if (! MFDAllocateMemory((LPFILEHDR FAR *) &lpFileHdr,
                           (LPFONTDIRECTORY FAR *) &lpFontDir,
                           (LPPFMPROLOG FAR* FAR *) &lpfmList,
                           wNumFonts+wMFMFonts+wPPDMFMFonts))
   {
      goto cleanup;
   }

   /* don't want to reAllocate FontInfo structure for every PFM */
   /* do it once and reAllocate to a larger buffer as needed*/
   /* will free it at the end*/
   wFontInfoSize = (WORD) 5 * 1024; //use 5K buffer initially.
   if (!(lpFontInfo = (LPFONTINFO) GlobalAllocPtr(GHND, (DWORD)wFontInfoSize)))
      return (RC_ERROR);

   //moving pointer
   hpFontDir = (HPFONTDIRECTORY) lpFontDir;
   count = wNumFonts;


   /*Read each Font File record and convert to Font Record Format.*/
   /*A Font File record can be a PFM/PFB, SFNT or TrueType */
   while (count--)
   {
     switch (hpFontFile->wType)
      {
         case PFMPFB:
            rc = ConvertPFMToFD(hpFontFile, hpFontDir, (LPPFMPROLOG FAR *)&lpfmList[index], 
                                 (LPWORD) &wFontInfoSize, (LPFONTINFO FAR *) &lpFontInfo);
            break;
         case SFNT:
            rc = ConvertSFNTToFD(hpFontFile, hpFontDir, (LPPFMPROLOG FAR *)&lpfmList[index]);
            break;
         case TrueType:
            rc = ConvertTrueTypeToFD(hpFontFile, hpFontDir, (LPPFMPROLOG FAR *) &lpfmList[index]);
            break;
         default:
            rc = 0;
            break;
      }

      if (!rc)
      {
         /* Couldn't get data, so skip it*/
         hpFontFile++;
         wSkippedFiles++;
         continue;
      }

      /* set the remaining Font Directory entries*/
      /* Take care that MFD data does not overlap 64K boundaries*/
        if (dwOffset + hpFontDir->dwMetricSize > LIMIT_64K) 
        {
            dwDirOffset += LIMIT_64K - dwOffset;
            dwOffset = 0;
        }

       if (hpFontDir->dwMetricSize)  //TrueType fonts have no metrics
         hpFontDir->dwMetricOffset = dwDirOffset;
       dwDirOffset += hpFontDir->dwMetricSize;
       dwOffset += hpFontDir->dwMetricSize;

      // increment to the next index
      hpFontFile++;
      hpFontDir++;
      index++;
   } //while

   /* Inject MFM fonts */
   count = wMFMFonts;
   if (wMFMFonts && hMFMFile)
   {
     //read pass the MFM record directory
    _llseek(hMFMFile, (long) sizeof(FileRecord) * wMFMFonts, SEEK_CUR);

    /* Ceate Backup Fontdir to weed duplicates*/
    wTempNumFonts = wNumFonts - wSkippedFiles;
    if (wTempNumFonts)
    {
      dwTempFontDirSize = (DWORD) sizeof(FONTDIRECTORY) * (DWORD) wTempNumFonts ;
      if (! (hpTempFontDir = (HPFONTDIRECTORY) GlobalAllocPtr(GHND, dwTempFontDirSize)))
            goto cleanup;

      MemCopy((LPVOID) hpTempFontDir, (LPVOID) lpFontDir, (DWORD) dwTempFontDirSize);

      /* Sort font directory */
      HugeIsort((HPVOID) hpTempFontDir, wTempNumFonts - 1, 
              sizeof(FONTDIRECTORY), FontCompare);
     }

     //now we are ready to read MFM.  Add fonts that are not already added to FontDir
     // store info to FontDirectory
     while (count--)
     {
        bMatch = FALSE;
        dwPFMSize = ReadPFMWithProlog(hMFMFile, (HPVOID FAR*) &lpfmList[index]);
        if ((DWORD) wFontInfoSize < dwPFMSize)
        {
            if (!(lpFontInfo = (LPFONTINFO) ReallocBuffer((WORD)dwPFMSize, GHND, 
                                 (LPWORD) &wFontInfoSize, (LPBYTE FAR *) &lpFontInfo)))
               return (RC_ERROR);
        }

         if (! dwPFMSize || 
             !CopyPFMToFD(hpFontDir, (LPPFMPROLOG) lpfmList[index], dwPFMSize, lpFontInfo, (BYTE) PFM_FROM_ADFONTS_MFM))
         {
             wSkippedFiles += count; 
             break; //exit out of while loop when error is encountered
         }

       //is there a match
       if (hpMatchDir = SearchFontDir(hpTempFontDir, (LPSTR) hpFontDir->szFontName, wTempNumFonts,
                                      TRUE, FONT_NOHINT, 
                                      TRUE, (hpFontDir->defTextMetric).tmCharSet))
       {
          if (lstrcmpi(hpMatchDir->szFaceName, hpFontDir->szFaceName) == 0 && //same family
              (hpMatchDir->defTextMetric).tmCharSet == (hpFontDir->defTextMetric).tmCharSet && //same charset
              hpMatchDir->dwMetricSize) //A PostScript Font.
          {
            bMatch = TRUE;
          }
       }

       if (!bMatch)
       {  //not already added
         /* set the remaining Font Directory entries*/
            hpFontDir->dwOutlineSize = 0; //no outline.
            hpFontDir->bOutlnAvail = 0;

         /* Take care that MFD data does not overlap 64K boundaries*/
            if (dwOffset + hpFontDir->dwMetricSize > LIMIT_64K) 
            {
               dwDirOffset += LIMIT_64K - dwOffset;
               dwOffset = 0;
            }

            if (hpFontDir->dwMetricSize)  //TrueType fonts have no metrics
              hpFontDir->dwMetricOffset = dwDirOffset;
            dwDirOffset += hpFontDir->dwMetricSize;
            dwOffset += hpFontDir->dwMetricSize;

         // increment to the next index
            hpFontDir++;
            index++;
         }
         else
         { //added to Fontdirectory alread.  so we'll skipp it.
           wSkippedFiles++;
           GlobalFreePtr(lpfmList[index]);
         }

     } //while
	}

   /* Inject PPDMFM fonts */
   count = wPPDMFMFonts;
   if (wPPDMFMFonts && hPPDMFMFile)
   {
     //read pass the MFM record directory
    _llseek(hPPDMFMFile, (long) sizeof(FileRecord) * wPPDMFMFonts, SEEK_CUR);


    /* Create Backup Fontdir to weed duplicates*/

    wTempNumFonts = wNumFonts + wMFMFonts - wSkippedFiles;
    if (wTempNumFonts)
    {
      dwNewFontDirSize = (DWORD) sizeof(FONTDIRECTORY) * (DWORD) wTempNumFonts ;
      // reallocate only if the new size is bigger
      if ( dwTempFontDirSize < dwNewFontDirSize)
        if (! (hpTempFontDir = (HPFONTDIRECTORY) GlobalReAllocPtr(hpTempFontDir, dwNewFontDirSize, GMEM_ZEROINIT)))
            goto cleanup;

      MemCopy((LPVOID) hpTempFontDir, (LPVOID) lpFontDir, (DWORD) dwNewFontDirSize);
			 
      // Sort font directory including ADFONTS.MFM
      HugeIsort((HPVOID) hpTempFontDir, wTempNumFonts - 1, 
              sizeof(FONTDIRECTORY), FontCompare);
     }
     //now we are ready to read PPDMFM.  Add fonts that are not already added to FontDir
     // store info to FontDirectory
     while (count--)
     {
        bMatch = FALSE;
        dwPFMSize = ReadPFMWithProlog(hPPDMFMFile, (HPVOID FAR*) &lpfmList[index]);
        if ((DWORD) wFontInfoSize < dwPFMSize)
        {
            if (!(lpFontInfo = (LPFONTINFO) ReallocBuffer((WORD)dwPFMSize, GHND, 
                                 (LPWORD) &wFontInfoSize, (LPBYTE FAR *) &lpFontInfo)))
               return (RC_ERROR);
        }

         if (! dwPFMSize || 
             !CopyPFMToFD(hpFontDir, (LPPFMPROLOG) lpfmList[index], dwPFMSize, lpFontInfo, (BYTE)PFM_FROM_OEM_MFM))
         {
             wSkippedFiles += count; 
             break; //exit out of while loop when error is encountered
         }

       //is there a match
       if (hpMatchDir = SearchFontDir(hpTempFontDir, (LPSTR) hpFontDir->szFontName, wTempNumFonts,
                                      TRUE, FONT_NOHINT, 
                                      TRUE, (hpFontDir->defTextMetric).tmCharSet))
       {
          if (lstrcmpi(hpMatchDir->szFaceName, hpFontDir->szFaceName) == 0 && //same family
              (hpMatchDir->defTextMetric).tmCharSet == (hpFontDir->defTextMetric).tmCharSet && //same charset
              hpMatchDir->dwMetricSize) //A PostScript Font.
          {
            bMatch = TRUE;
          }
       }

       if (!bMatch)
       {  //not already added
         /* set the remaining Font Directory entries*/
            hpFontDir->dwOutlineSize = 0; //no outline.
            hpFontDir->bOutlnAvail = 0;

         /* Take care that MFD data does not overlap 64K boundaries*/
            if (dwOffset + hpFontDir->dwMetricSize > LIMIT_64K) 
            {
               dwDirOffset += LIMIT_64K - dwOffset;
               dwOffset = 0;
            }

            if (hpFontDir->dwMetricSize)  //TrueType fonts have no metrics
              hpFontDir->dwMetricOffset = dwDirOffset;
            dwDirOffset += hpFontDir->dwMetricSize;
            dwOffset += hpFontDir->dwMetricSize;

         // increment to the next index
            hpFontDir++;
            index++;
       }
       else
       { //added to Fontdirectory alread.  so we'll skipp it.
           wSkippedFiles++;
           GlobalFreePtr(lpfmList[index]);
       }

     } //while
	}
     if (hpTempFontDir)
        GlobalFreePtr(hpTempFontDir);

       //end of PFM from MFM injection.


   /*Update File Header */
   lpFileHdr->dwPSFRSerialNo = dwPSFRSerialNo;
   lpFileHdr->dwTTFRSerialNo = dwTTFRSerialNo;
   lpFileHdr->wVersionNumber = MFD_VERSION;
   lpFileHdr->wNumFonts = wNumFonts + wMFMFonts +wPPDMFMFonts - wSkippedFiles;
   lpFileHdr->dwTotalFontSize = dwDirOffset;
   lpFileHdr->dwMFMTimeStamp = dwMFMTimeStamp;

   /* Create MFD File */
   if (lpFileHdr->wNumFonts)
      rc = CreateMFDFile(hfile, lpFileHdr, lpFontDir, (LPPFMPROLOG FAR *) lpfmList);

cleanup:
   if (lpFontInfo)
     GlobalFreePtr(lpFontInfo);


   if (hMFMFile != HFILE_ERROR)
     _lclose(hMFMFile);
   if (hPPDMFMFile != HFILE_ERROR)
     _lclose(hPPDMFMFile);

   MFDFreeMemory(lpFileHdr, lpFontDir, (LPPFMPROLOG FAR* FAR*) &lpfmList, wNumFonts+wMFMFonts+wPPDMFMFonts);

   /*close files */
   _close(hfile);

   return rc;
}

WORD NEAR PASCAL CreateMFDFile(HFILE hFile, 
                               LPFILEHDR lpFileHdr, 
                               LPFONTDIRECTORY lpFontDir,
                               LPPFMPROLOG FAR* lpfmList)
{
    HPFONTDIRECTORY hpTempDir = NULL;   // Need this temp HUGE pointer, because lpFotnDir is huge now. 6-13-95
    HPFONTDIRECTORY hpOldFontDir = NULL;
    HPFONTDIRECTORY hpOldFontDirTop = NULL;
    DWORD           dwCurpos ;
    WORD            i;
    DWORD           dwFontDirSize;
    WORD            rc = RC_ERROR;
	 WORD				  sizeOfPFMProlog = sizeof(PFMPROLOG);

    /* Write file header */
    if (_lwrite(hFile, (HPVOID) lpFileHdr, (UINT) sizeof(FILEHDR)) == sizeof(FILEHDR))
    {
        //no fonts, just write header
        if (!lpFileHdr->wNumFonts)
        {
           rc = RC_OK;
           goto mfdfile_cleanup;
        }

        /* Backup Fontdir */
        dwFontDirSize = (DWORD) sizeof(FONTDIRECTORY) * (DWORD)lpFileHdr->wNumFonts;
        if (! (hpOldFontDir = 
               (HPFONTDIRECTORY) GlobalAllocPtr(GHND, dwFontDirSize)))
        {
            goto mfdfile_cleanup;
        }

        hpOldFontDirTop = hpOldFontDir;
        MemCopy((LPVOID) hpOldFontDir, (LPVOID) lpFontDir,
                (DWORD) dwFontDirSize);

        /* Sort font directory */
        HugeIsort((HPVOID) lpFontDir, lpFileHdr->wNumFonts - 1, 
              sizeof(FONTDIRECTORY), FontCompare);
        
        /* Add font index values */
        hpTempDir = lpFontDir;
        for (i = 0; i < lpFileHdr->wNumFonts; i++)
        {
            // dwMetricOffset was calculated from 0 since we didn't know 
            // number of font entries there was at the time.
            // so we must adjust it now.
//            hpTempDir->dwMetricOffset += dwFontDirSize; 
            //write the index
            hpTempDir->index = hpTempDir->wMMBIndex = i;
            hpTempDir++;   // Huge pointer incremental -- able to cross seg boundry
        }
        
        /* now is the time to find the MM base of MM Instance */
        /* more code to be add here. */

        /* Write font directory, use hwrite() for huge, 6-13-1995 */
        if (_hwrite(hFile, (HPVOID) lpFontDir, (long)dwFontDirSize) != (long)dwFontDirSize)
            goto mfdfile_cleanup;
                    
        /* Write font data */
        dwCurpos = 0;
        for (i = 0; i < lpFileHdr->wNumFonts; i++) {

          //TT fonts has no metric 
          if (hpOldFontDir->dwMetricSize)
            {
               /* To prevent overlap of 64K boundaries */
               if (dwCurpos != hpOldFontDir->dwMetricOffset)
               _llseek(hFile, (long) hpOldFontDir->dwMetricOffset - dwCurpos, SEEK_CUR);

               if (! _lwrite(hFile, (HPVOID) *lpfmList, 
                        (UINT) hpOldFontDir->dwMetricSize))
               {
                  goto mfdfile_cleanup;
               }
                        
               dwCurpos = hpOldFontDir->dwMetricOffset + hpOldFontDir->dwMetricSize;
            }
                        
            lpfmList++;   // huge pointer ++
            hpOldFontDir++;
        }

        rc = RC_OK; /* Everything is fine */
    }

    /* Clean up */
mfdfile_cleanup:
    if (hpOldFontDirTop)
        GlobalFreePtr(hpOldFontDirTop);

    _lclose(hFile);
    return rc;
}

WORD NEAR PASCAL ConvertSFNTToFD(HPFONTFILE hpFontFile, HPFONTDIRECTORY hpFontDir, LPPFMPROLOG FAR *lppfmData)
{
   /* fill in hpFontDir and lppPFMData */
   /* hpFontFile->szName1 is the SFNT File name and path */
   /*set version to SFNT number */

   /* not implemented*/
   return (0);
}

/* fill in hpFontDir and lppPFMData */
/* hpFontFile->szName1 is the Postscript Font Name*/
/* hpFontFile->szName2 is the entry retrieved from the registry*/
WORD NEAR PASCAL ConvertTrueTypeToFD(HPFONTFILE hpFontFile, HPFONTDIRECTORY hpFontDir, LPPFMPROLOG FAR *lppfmData)
{
   if (*hpFontFile->szName1)
   {
      MemSet((HPBYTE) hpFontDir, 0, (DWORD) sizeof(FONTDIRECTORY));
      lstrcpy(hpFontDir->szFontName, hpFontFile->szName1);
      lstrcpy(hpFontDir->szFaceName, hpFontFile->szName2);
      (hpFontDir->defTextMetric).tmCharSet = hpFontFile->lfCharSet;
      (hpFontDir->defTextMetric).tmWeight = hpFontFile->lfWeight;
      (hpFontDir->defTextMetric).tmItalic = hpFontFile->lfItalic;
      hpFontDir->dwMetricVersion = (DWORD) TrueType;
      return (RC_OK);
   }
   else 
     return (RC_ERROR);
}

WORD NEAR PASCAL CopyPFMToFD(HPFONTDIRECTORY hpFontDir, LPPFMPROLOG lppfmData, 
                             DWORD dwMetricSize, LPFONTINFO lpFontInfo, BYTE pfmSource)
{
   DWORD sizeOfPFMProlog = sizeof(PFMPROLOG);
   LPPFMHEADER lpPFMHdr = NULL;
   DWORD Offset = 0;
   LPPFMEXTENSION lpPFMExt;

#define BUMPFAR(x,y)  (((LP)(x))+(y))

   lpPFMHdr = 	(LPPFMHEADER) ((LPBYTE)(lppfmData) + sizeOfPFMProlog);
   MemCopy ((LP)lpFontInfo, (LP)lpPFMHdr, dwMetricSize-(DWORD)sizeOfPFMProlog);

   PatchPFMOffsets((LPPFMHEADER)lpFontInfo);
   lpPFMExt = (LPPFMEXTENSION) ((LPBYTE)lpFontInfo + sizeof(PFMHEADER));

   Offset = lpFontInfo->dfFace;
   lstrcpy (hpFontDir->szFaceName, (LPSTR)BUMPFAR(lpFontInfo, Offset));

   Offset = lpPFMExt->dfDriverInfo;
   lstrcpy (hpFontDir->szFontName, (LPSTR)BUMPFAR(lpFontInfo, Offset));

   hpFontDir->xRes = DEF_RESOLUTION;
   hpFontDir->yRes = DEF_RESOLUTION;

   MakeTextMetric(lpPFMHdr, &(hpFontDir->defTextMetric), hpFontDir->xRes, hpFontDir->yRes);
   hpFontDir->underline = lpPFMHdr->dfUnderline;
   hpFontDir->strikeout = lpPFMHdr->dfStrikeOut;
   hpFontDir->wMMBIndex =  hpFontDir->index  = 0;//init to 0;
   hpFontDir->dwMetricVersion = (DWORD) PFMPFB;
   hpFontDir->dwMetricSize = dwMetricSize;
   hpFontDir->pfmSource = pfmSource;

   return RC_OK;

}

WORD NEAR PASCAL ConvertPFMToFD(HPFONTFILE hpFontFile, HPFONTDIRECTORY hpFontDir, 
               LPPFMPROLOG FAR *lppfmData, LPWORD lpwFontInfoSize, LPFONTINFO FAR *lppFontInfo)
{
    DWORD dwMetricSize = 0;

    if (! (*hpFontFile->szName1))
      return (RC_ERROR);

    if (!(dwMetricSize = ReadMetricFile(hpFontFile->szName1, (HPVOID FAR *) lppfmData)))
      return (RC_ERROR);

    if ((DWORD) *lpwFontInfoSize < dwMetricSize)
    {
      if (!(*lppFontInfo = (LPFONTINFO) ReallocBuffer((WORD) dwMetricSize, GHND, 
                              lpwFontInfoSize, (LPBYTE FAR *) lppFontInfo)))
               return (RC_ERROR);
    }

    if (!CopyPFMToFD(hpFontDir, 
                     (LPPFMPROLOG) *lppfmData, 
                     (DWORD) dwMetricSize, 
                     (LPFONTINFO) *lppFontInfo, (BYTE) PFM_FROM_REGISTRY))
       return RC_ERROR;

    hpFontDir->dwOutlineSize = GetPFBSize(hpFontFile->szName2);

    //determine types of outline available for this font
    hpFontDir->bOutlnAvail = (BYTE) WhichOutlnType(hpFontDir);

   return RC_OK;
}


BYTE FAR PASCAL WhichOutlnType(HPFONTDIRECTORY hpFontDir)
{
   char szBaseName[PS_FILE_PATH_LENGTH];
   BYTE bOutlnAvail = 0;

   /* if mm instance get parentage information */
   /* 1st parameter is LPPDEVICE == NULL, not use in IsMMInstanceFont */
   if (IsMMInstanceFont(NULL, hpFontDir->szFaceName, (LPSTR)szBaseName, 1)) //byfamily ==1;
   {
     ;     
   }
   return ((BYTE) SINGLE_MASTER);
}
/*****************************************************************************
*                               MFDAllocateMemory
*  function:
*  parameters:
*  returns:
*       RC_OK if successful, else RC_ERROR.
***************************************************************************/
WORD NEAR PASCAL MFDAllocateMemory(LPFILEHDR FAR* lplpFileHdr, 
                                   LPFONTDIRECTORY FAR* lplpFontDir,
                                   LPPFMPROLOG FAR* FAR* lplpfmList,
                                   WORD wNumFonts)
{
    WORD rc = RC_ERROR;
    DWORD  dwFDirSize;

    /* Allocate File Header */
    if (*lplpFileHdr = (LPFILEHDR) GlobalAllocPtr(GHND, sizeof(FILEHDR)))
    {
        /* Allocate Font Directory */
        dwFDirSize = (DWORD)sizeof(FONTDIRECTORY) * wNumFonts;
        if (*lplpFontDir = (LPFONTDIRECTORY) GlobalAllocPtr(GHND, dwFDirSize))
        {
            /* Allocate array of pointers to store PFM */
            if (*lplpfmList = (LPPFMPROLOG FAR*) 
                GlobalAllocPtr(GHND, sizeof(LPPFMPROLOG) * wNumFonts))
                rc = RC_OK;
        }
    }
    return rc;
}


/*****************************************************************************
*                               MFDFReeMemory
*  function:
*  parameters:
*  returns:
*       Nothing
***************************************************************************/
void NEAR PASCAL MFDFreeMemory(LPFILEHDR lpFileHdr, 
                               LPFONTDIRECTORY lpFontDir,
                               LPPFMPROLOG FAR*  FAR* lplpfmList,
                               WORD wNumFonts)
{
    LPPFMPROLOG FAR* lpfdTemp;

    /* Free all memory */
    if (lpFileHdr)
        GlobalFreePtr(lpFileHdr);
    if (lpFontDir)
        GlobalFreePtr(lpFontDir);
    if (lplpfmList) 
    {
        WORD i;

        lpfdTemp = *lplpfmList;
        for (i = 0; i < wNumFonts; i++) 
        {
            if (*lpfdTemp)
                GlobalFreePtr(*lpfdTemp);
            lpfdTemp++;
        }
        GlobalFreePtr(*lplpfmList);
    }
}
DWORD NEAR PASCAL GetPFBSize(LPSTR lpPFBFileName)
{
   DWORD dwSize = 0;
   HFILE hfile = NULL;
   OFSTRUCT ofFileStruct;

   if (*lpPFBFileName)
   {
      if ((hfile = OpenFile(lpPFBFileName, (LPOFSTRUCT) &ofFileStruct, OF_READ))
            != HFILE_ERROR)
      {
         if (_llseek(hfile, 0, SEEK_END) != -1 )
         dwSize = _tell(hfile);
         _lclose(hfile);
      }
   }
   return dwSize;
}

DWORD NEAR PASCAL GetPFMVersion(LPPFMPROLOG lpPFM)
{
   return (0L);  
   // 0 is PFM
   //non 0 is SFNT version.
}

/*****************************************************************************
*                               IndexFontCompare
*  function:  Sort by Family Name
*  parameters:
*  returns:
*       RC_OK if successful, else RC_ERROR.
***************************************************************************/
int FAR PASCAL IndexFontCompare(LPVOID elem1, LPVOID elem2, HPVOID ppFDirs)
{
    LPDIRINDEX lpIndex1 = (LPDIRINDEX) elem1;
    LPDIRINDEX lpIndex2 = (LPDIRINDEX) elem2;
	 HPFONTDIRECTORY  FAR *hpFDirs = (HPFONTDIRECTORY FAR *) ppFDirs;
	 HPFONTDIRECTORY hpDir1, hpDir2;
    int rtnValue;

	 hpDir1 = (HPFONTDIRECTORY) hpFDirs[lpIndex1->wDirIndex];
	 hpDir2 = (HPFONTDIRECTORY) hpFDirs[lpIndex2->wDirIndex];
	 hpDir1 += lpIndex1->wDirRecIndex;
	 hpDir2 += lpIndex2->wDirRecIndex;

    if ((rtnValue = lstrcmpi(hpDir1->szFaceName, hpDir2->szFaceName)) == 0)
    {
      if ((rtnValue = lstrcmpi(hpDir1->szFontName, hpDir2->szFontName)) == 0)
      {
         if ( (hpDir1->defTextMetric).tmCharSet > (hpDir2->defTextMetric).tmCharSet)
            rtnValue = 1;
         else if ((hpDir1->defTextMetric).tmCharSet < (hpDir2->defTextMetric).tmCharSet)
            rtnValue = -1;
         else 
            rtnValue = 0;
      }
    }
    return (rtnValue);
}

BOOL FAR PASCAL InstallPrinterFonts(LPPRINTERINFO lpPInfo, 
                                    LPBYTE lpStrHeap, LPBYTE lpArrHeap)
{
    LPFONTLIST  lpFontList = (LPFONTLIST) ARRREF_TO_PTR(lpArrHeap, 
                                                        lpPInfo->FontList);
//	 HPFONTDIRECTORY  hpFontDir, hpTempFontDir;
	 HPFONTDIRECTORY  hpTempFontDir;
    LPFONTLIST  lpFL;
    LPSTR       lpStr;
    WORD       wNumFonts  = lpPInfo->FontList.w.length;
    WORD        i = wNumFonts;
	 WORD			 wNumMFDFonts = 0;
    BOOL        rc = FALSE;

    lpFL = lpFontList;          /* Save value */


//    hpFontDir = GetHostFontCache(&wNumMFDFonts);

    while (i--) 
    {
        lpStr = STRREF_TO_PTR(lpStrHeap, lpFontList->fontname);
//        if (hpTempFontDir = (HPFONTDIRECTORY) SearchFontDir(hpFontDir, lpStr, wNumMFDFonts,
//                                 TRUE, FONT_NOHINT))
//        {
//            lpFontList->custom = FALSE;
//            lpFontList->index = 0;  //don't use anymore
//            lpFontList->familyname.dword = 
//               (DWORD) addStringToTable((HPBYTE) hpTempFontDir->szFaceName);
//        }
//        else
//        {
            /* We do not support this font or can't be found */
//            lpFontList->custom = TRUE;

            lpFontList->custom = FALSE;
            lpFontList->index = 0xffff; /* May change later */
            lpFontList->familyname.w.length = 0; /* May change later */
//        }

      /* Must look at this logic again for Far East */
      /* ANG 11-3-95 */

      // Japan only. To support DBCS prop vertical device font.
        if (IsDBCSPFont(lpStr))
        {
            lpFontList++;
            i--;

//            if( hpTempFontDir
//						&& 0 == lstrcmpi(hpTempFontDir->szFontName, lpStr))
//            {
//					hpTempFontDir++;
            // Next font list has same fontname.
//                lpFontList->custom = FALSE;
//                lpFontList->index = 0; //don't use anymore
//                lpFontList->familyname.dword = 
//                (DWORD)addStringToTable((HPBYTE) hpTempFontDir->szFaceName);
//            }
//            else {
                /* We do not support this font */
//                lpFontList->custom = TRUE;

                lpFontList->custom = FALSE;
                lpFontList->index = 0xffff; /* May change later */
                lpFontList->familyname.w.length = 0; /* May change later */
//            }
        }
        else
        // Japan only. To support Mincho & Gothic family name.
        if (IsMinchoOrGothic(lpStr) && !Is90ms(lpStr))
        {
            lpFontList++;
            i--;

//            if( hpTempFontDir
//						&& 0 == lstrcmpi(hpTempFontDir->szFontName, lpStr))
//            {
					hpTempFontDir++;
				// Next font list has same fontname.
//                lpFontList->custom = FALSE;
//                lpFontList->index = 0; //don't use anymore
//                lpFontList->familyname.dword = 
//                (DWORD)addStringToTable((HPBYTE) hpTempFontDir->szFaceName);
//            }
//            else {
                /* We do not support this font */
//                lpFontList->custom = TRUE;

                lpFontList->custom = FALSE;
                lpFontList->index = 0xffff; /* May change later */
                lpFontList->familyname.w.length = 0; /* May change later */
//            }
        }

        lpFontList++;
    }
    rc = TRUE;

    /* Sort lpFontList based on font names */
    if (rc) 
    {
        StrHeap = lpStrHeap;
        Qsort((LPVOID) lpFL, 0, wNumFonts - 1,
              sizeof(FONTLIST), FontListCompare);
    }

    return rc;
}

DWORD FAR PASCAL CreatePFMFile(LPPFMPROLOG lpPFMProlog, LPSTR lpszPFMName, DWORD dwSize)
{
   HFILE hFile;
   OFSTRUCT        ofFileStruct;
   DWORD    dwBytes = 0;

   if (!(*lpszPFMName))
      return dwBytes;

   if ((hFile = OpenFile(lpszPFMName, (LPOFSTRUCT) &ofFileStruct, 
                       OF_CREATE | OF_WRITE)) == HFILE_ERROR)
      return dwBytes;

   dwBytes = _lwrite(hFile, (HPVOID)lpPFMProlog, (UINT) dwSize);

   _lclose(hFile);

   return dwBytes;
        
}





/*****************************************************************************
*                               FontCompare
*  function:  Sort by PS Name
*  parameters:
*  returns:
*       RC_OK if successful, else RC_ERROR.
***************************************************************************/
int FAR PASCAL FontCompare(LPVOID elem1, LPVOID elem2)
{
    int rtnValue;
    LPFONTDIRECTORY lpDir1 = (LPFONTDIRECTORY) elem1;
    LPFONTDIRECTORY lpDir2 = (LPFONTDIRECTORY) elem2;

   if ((rtnValue = lstrcmpi(lpDir1->szFontName, lpDir2->szFontName)) == 0)
    {
      if ( (lpDir1->defTextMetric).tmCharSet > (lpDir2->defTextMetric).tmCharSet)
        rtnValue = 1;
      else if ((lpDir1->defTextMetric).tmCharSet < (lpDir2->defTextMetric).tmCharSet)
       rtnValue = -1;
      else 
       rtnValue = 0;
    }
    return (rtnValue);

}


/*****************************************************************************
*                               FamilyCompare
*  function: Compare softfont based on FamilyName - lfFaceName
*  parameters:
*  returns:
*       RC_OK if successful, else RC_ERROR.
***************************************************************************/
int FAR PASCAL FamilyCompare(LPVOID elem1, LPVOID elem2)
{
    LPFONTDIRECTORY lpDir1 = (LPFONTDIRECTORY) elem1;
    LPFONTDIRECTORY lpDir2 = (LPFONTDIRECTORY) elem2;

    return (lstrcmpi(lpDir1->szFaceName, lpDir2->szFaceName));
}




int FAR PASCAL FontListCompare(LPVOID elem1, LPVOID elem2)
{
    LPFONTLIST lpFL1 = (LPFONTLIST) elem1;
    LPFONTLIST lpFL2 = (LPFONTLIST) elem2;
    return (lstrcmpi(STRREF_TO_PTR(StrHeap, lpFL1->fontname), 
                     STRREF_TO_PTR(StrHeap, lpFL2->fontname)));
}

HFILE FAR PASCAL IsPPDMFMExist(LPSTR lpszFriendlyName)
{

    LPPRINTERINFO lpPrinterInfo;
    LPSTR lpzDestDevice = NULL;
    LPSTR szPrinterName = NULL;
    DWORD dwType, dwNeeded;
    LPWPXBLOCKS    lpWPXblock;
    LPPDEVICE      lpDev;
    LPSTR szFileName;
    char szPath[BUF_SIZE];
    char szPCFileName[14];
    OFSTRUCT ofFileStruct;
    HFILE hMFMFile= NULL;

   //  return NULL; //temporary until we resolve DrvGetPrinterData

   if (lpszFriendlyName == NULL)
      return hMFMFile;
   if ((szPrinterName = GlobalAllocPtr(GDLLHND,  2*MAX_NAME_LEN+CCHDEVICENAME)) == NULL)
     return hMFMFile;

   if ((lpDev = GlobalAllocPtr(GDLLHND,  sizeof(PDEVICE))) == NULL)
     return hMFMFile;

    // Get printer model name
    lpzDestDevice = szPrinterName;
    lpzDestDevice[0] = '\0';               
    if (DrvGetPrinterData(lpszFriendlyName, (LPSTR)INT_PD_PRINTER_MODEL, &dwType, lpzDestDevice, 
                          CCHDEVICENAME, &dwNeeded) != ERROR_SUCCESS)
       goto notexist;

    if (! (lpWPXblock = GetPrinter(lpzDestDevice)))
      goto notexist;

    lpDev->lpWPXblock = lpWPXblock;
    lpPrinterInfo = (LPPRINTERINFO)(lpWPXblock->WPXprinterInfo);
    szFileName = StringRefToLPBYTE(lpDev, lpPrinterInfo->PCFileName.dword);

    lstrcpy(szPCFileName, szFileName);
    szPCFileName[lstrlen(szPCFileName)-3] = '\0';
    lstrcat(szPCFileName, "mfm");

    // get PCFileName, check if file exists
    // Use GetMFMPath();
    GetMFMPath(szPath, BUF_SIZE ,szPCFileName);

   hMFMFile = OpenFile(szPath, (LPOFSTRUCT)&ofFileStruct, OF_READ);

notexist:
   if (szPrinterName)
      GlobalFreePtr(szPrinterName);
   if (lpDev)
      GlobalFreePtr(lpDev);
      
   return hMFMFile;
}


