/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: CONCATX.H                                                    */
/*                                                                           */
/* Description: This module contains                                         */
/*                                                                           */
/*****************************************************************************/

#define CONCAT_VERSION         0x0210
#define CONCAT_MAX_NUM_PFMS    200
#define CONCAT_MAGIC_SIZE      80
#define CONCAT_IO_BUFF_SIZE    256
#define CONCAT_HEADER_LENGTH   CONCAT_MAGIC_SIZE + 4


/* 10 bytes */
typedef struct
{
   int min;
   int hour; /* 24 hour format */
   int day;
   int month;
   int year;
} Date;

/* 31 bytes */
typedef struct
{
   char FileName[13];
   long FileOffset;
   long FileLength;
   Date FileDate;
} FileRecord;
