/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: colordlg.c                                                   */
/*                                                                           */
/* Description: This module contains the functions for the Margins Dialog    */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "dlgsfunc.h"
#include "apd42map.hh"
#include <string.h>

#define COLORSPACE_GREY 0x1
#define COLORSPACE_RGB  0x2
#define COLORSPACE_CMYK 0x4

#pragma code_seg(_DIALOGSSEG)

extern char *strstr( const char*, const char* );

/***************************************************************************/
/*                   HashString                                            */
/*                                                                         */
/* Hash a string of characters                                             */
/*                                                                         */
/***************************************************************************/
DWORD FAR PASCAL HashString( LPSTR str, WORD len )
{
   DWORD value;
   WORD i;

   for( i=0, value=0; i<len; i++ )
      value += str[i];

   return( value );
}


/***************************************************************************/
/*                   CheckColorSpace                                       */
/* Purpose:                                                                */
/*    Check the color space of the ICM Profile                             */
/*                                                                         */
/* Parameters:                                                             */
/*    filename = full filename of profile                                  */
/*                                                                         */
/***************************************************************************/
BOOL PASCAL CheckColorSpace( LPSTR filename, UINT colorSpace )
{
   icHeader CPHeader;
   HFILE    hFile;
   SINT     Res;
   CSIG     CPColorSpaceTag;
   BOOL     result = FALSE;

   hFile = _lopen(filename, READ);
   if( hFile == HFILE_ERROR )
   {
       return(FALSE);
   }
   Res = _lread(hFile, (LPVOID) &CPHeader, sizeof(CPHeader));
   _lclose(hFile);
   if( (Res == HFILE_ERROR) || (Res != sizeof(CPHeader)) )
   {
       return(FALSE);
   }

   CPColorSpaceTag = SigtoCSIG(CPHeader.colorSpace);

   if( colorSpace & COLORSPACE_GREY )
      result = CPColorSpaceTag == icSigGrayData;

   if( !result && (colorSpace & COLORSPACE_RGB) )
      result = CPColorSpaceTag == icSigRgbData;

   if( !result && (colorSpace & COLORSPACE_CMYK) )
      result = CPColorSpaceTag == icSigCmykData;

   return( result );
}

#ifdef PROOFING
/***************************************************************************/
/*                   EnumICMProfile                                        */
/* Purpose:                                                                */
/*    Enumerate Installed ICM Profiles from the registry                   */
/*                                                                         */
/* Parameters:                                                             */
/*   action = action to take:                                              */
/*          ENUMICMP_INSERT: insert profiles into a comboBox               */
/*          ENUMICMP_MATCH:  match the profiles with a hash value          */
/*   hDlg = handle of dialog box containing the comboBox                   */
/*   n = id of comboBox or hash value to match                             */
/*   lpszProfile = buffer to hold the matched profile value.               */
/*               must be big enough to hold the profile path/filename      */
/*   size = size of buffer                                                 */
/*                                                                         */
/***************************************************************************/
BOOL FAR PASCAL EnumICMProfile( WORD action, HWND hDlg, DWORD n,
            LPSTR lpszProfile, int size )
{
   HKEY  hKey, hManufSubKey, hModelSubKey, hMediaSubKey, hDitherSubKey, hResolSubKey;
   char  szICMKey[256];  // ICM key path in registry
   char  szSubKey[256];
   int   manufacturer, model, mediatype, dithertype, resolution, k;
   int   lenPath, lenManufacturer, lenModel, lenMediaType, lenDitherType;
   LONG  retCode;
   BOOL  found = FALSE;

   if(action == ENUMICMP_MATCH && !lpszProfile) goto EndEnumICMProfile;

   if( !IsWin40() ) goto Win98;

   LoadString(ghDriverMod, IDS_REGSTR_PATH_ICM, szICMKey, sizeof(szICMKey));
   lenPath = lstrlen( szICMKey );

   // open the key "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\ICM\prtr"
   if(RegOpenKey(HKEY_LOCAL_MACHINE, szICMKey, &hKey) != ERROR_SUCCESS)
      goto EndEnumICMProfile;

   // enumerate manufacturers
   for(manufacturer = 0;
       RegEnumKey(hKey, manufacturer, szSubKey, sizeof(szSubKey))==ERROR_SUCCESS;
       manufacturer++ )
   {
      szICMKey[lenPath] = 0;
      lstrcat(szICMKey, "\\");
      lstrcat(szICMKey, szSubKey);
      lenManufacturer = lstrlen( szICMKey );

      // open the manufacturer subkey
      if(RegOpenKey(HKEY_LOCAL_MACHINE, szICMKey, &hManufSubKey) != ERROR_SUCCESS)
         continue;

      // enumerate models
      for(model=0;
          RegEnumKey(hManufSubKey, model, szSubKey, sizeof(szSubKey))==ERROR_SUCCESS;
          model++ )
      {
         szICMKey[lenManufacturer] = 0;
         lstrcat(szICMKey, "\\");
         lstrcat(szICMKey, szSubKey);
         lenModel = lstrlen( szICMKey );

         // open the model subkey
         if(RegOpenKey(HKEY_LOCAL_MACHINE, szICMKey, &hModelSubKey) != ERROR_SUCCESS)
            continue;

         // enumerate mediatype
         for(mediatype=0;
             RegEnumKey(hModelSubKey, mediatype, szSubKey, sizeof(szSubKey))==ERROR_SUCCESS;
             mediatype++ )
         {
            szICMKey[lenModel] = 0;
            lstrcat(szICMKey, "\\");
            lstrcat(szICMKey, szSubKey);
            lenMediaType = lstrlen( szICMKey );

            // open the mediatype subkey
            if(RegOpenKey(HKEY_LOCAL_MACHINE, szICMKey, &hMediaSubKey) != ERROR_SUCCESS)
               continue;

            // enumerate dithertype
            for(dithertype=0;
                RegEnumKey(hMediaSubKey, dithertype, szSubKey, sizeof(szSubKey))==ERROR_SUCCESS;
                dithertype++ )
            {
               szICMKey[lenMediaType] = 0;
               lstrcat(szICMKey, "\\");
               lstrcat(szICMKey, szSubKey);
               lenDitherType = lstrlen( szICMKey );

               // open the dithertype subkey
               if(RegOpenKey(HKEY_LOCAL_MACHINE, szICMKey, &hDitherSubKey) != ERROR_SUCCESS)
                  continue;

               // enumerate resolution
               for(resolution=0;
                   RegEnumKey(hDitherSubKey, resolution, szSubKey, sizeof(szSubKey))==ERROR_SUCCESS;
                   resolution++ )
               {
                  szICMKey[lenDitherType] = 0;
                  lstrcat(szICMKey, "\\");
                  lstrcat(szICMKey, szSubKey);

                  // open the dithertype subkey
                  if(RegOpenKey(HKEY_LOCAL_MACHINE, szICMKey, &hResolSubKey) != ERROR_SUCCESS)
                     continue;

                  retCode = ERROR_SUCCESS;
                  for( k=0; retCode==ERROR_SUCCESS; k++ )
                  {
                     BYTE value[256];
                     LONG SubKeySize = sizeof( szSubKey );
                     DWORD typeCode, valueSize = sizeof( value );

                     retCode=RegEnumValue(hResolSubKey, k, szSubKey, &SubKeySize,
                                          NULL, &typeCode, value, &valueSize);
                     if( retCode == ERROR_SUCCESS && typeCode == REG_SZ &&
                         valueSize && strstr( szSubKey, "profile" ) )
                     {
                        switch( action )
                        {
                           case ENUMICMP_INSERT:
                              if(CheckColorSpace((LPSTR)value, (UINT)(COLORSPACE_RGB|COLORSPACE_CMYK)))
                                 SendDlgItemMessage(hDlg, (WORD)n, CB_ADDSTRING, 0,
                                                    (LPARAM)(LPSTR)value);
                              break;

                           case ENUMICMP_MATCH:
                              if( n == HashString( value, lstrlen(value) ) )
                              {
                                  if( lstrlen(value) < size )
                                  {  lstrcpy( lpszProfile, value );
                                     found = TRUE;
                                  }
                                  goto EndEnumICMProfile;
                              }
                              break;
                        } // end switch
                     } // end if retCode...
                  } // end for k
                  RegCloseKey(hResolSubKey);

               } // end for resolution
               RegCloseKey(hDitherSubKey);

            } // end for dithertype
            RegCloseKey(hMediaSubKey);

         } // end for mediatype
         RegCloseKey(hModelSubKey);

      } // for model
      RegCloseKey(hManufSubKey);

   } // for manufacturer
   RegCloseKey(hKey);

   goto EndEnumICMProfile;

Win98:
   LoadString(ghDriverMod, IDS_REGSTR_PRN_PRINTER_0, szICMKey, sizeof(szICMKey));
   lenPath = lstrlen( szICMKey );

   // open the key "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Print\Printers"
   if(RegOpenKey(HKEY_LOCAL_MACHINE, szICMKey, &hKey) != ERROR_SUCCESS)
      goto EndEnumICMProfile;

   // enumerate printers
   for(model = 0;
       RegEnumKey(hKey, model, szSubKey, sizeof(szSubKey))==ERROR_SUCCESS;
       model++ )
   {
      szICMKey[lenPath] = 0;
      lstrcat(szICMKey, "\\");
      lstrcat(szICMKey, szSubKey);
      lstrcat(szICMKey, "\\");
      lstrcat(szICMKey, "PrinterDriverData" );

      // open the manufacturer subkey
      if(RegOpenKey(HKEY_LOCAL_MACHINE, szICMKey, &hModelSubKey) != ERROR_SUCCESS)
         continue;

      retCode = ERROR_SUCCESS;
      for( k=0; retCode==ERROR_SUCCESS; k++ )
      {
         BYTE value[256], *lpValue = value;
         char filename[256];
         LONG SubKeySize = sizeof( szSubKey );
         DWORD typeCode, valueSize = sizeof( value );
         BOOL done=FALSE;
         WORD len;

         retCode=RegEnumValue(hModelSubKey, k, szSubKey, &SubKeySize,
                              NULL, &typeCode, value, &valueSize);
         if( retCode == ERROR_SUCCESS && /*typeCode == REG_MULTI_SZ && */
             valueSize && !lstrcmp( szSubKey, "ICMProfile" ) )
         {
            switch( action )
            {
               case ENUMICMP_INSERT:
                  if( lpValue[0] == 0 && lpValue[1] == 0 )
                     done = TRUE;
                  while( !done )
                  {
                     if( GetSystemDirectory((LPSTR)filename, sizeof(filename)) )
                     {
                        strcat( filename, "\\Color\\" );
                        strcat( filename, lpValue );

                        if(CheckColorSpace((LPSTR)filename, (UINT)(COLORSPACE_RGB|COLORSPACE_CMYK)))
                           SendDlgItemMessage(hDlg, (WORD)n, CB_ADDSTRING, 0,
                                              (LPARAM)((LPSTR)lpValue));
                     }
                     len = lstrlen( lpValue );
                     lpValue = lpValue + len + 1;
                     if( *lpValue == 0 ) done = TRUE;
                  }
                  break;

               case ENUMICMP_MATCH:
                  if( lpValue[0] == 0 && lpValue[1] == 0 )
                     done = TRUE;
                  while( !done )
                  {
                     if( n == HashString( lpValue, lstrlen(lpValue) ) )
                     {
                        lstrcpy( lpszProfile, lpValue );
                        found = TRUE;
                        goto EndEnumICMProfile;
                     }
                     len = lstrlen( lpValue );
                     lpValue = lpValue + len + 1;
                     if( *lpValue == 0 ) done = TRUE;
                  }
                  break;
            } // end switch
         } // end if retCode...
      } // end for k
      RegCloseKey(hModelSubKey);
   } // end for model
   RegCloseKey(hKey);

EndEnumICMProfile:

   return( action==ENUMICMP_MATCH ? found : TRUE );
}
#endif

/***************************************************************************/
/*                   InitColorDlg                                          */
/*                                                                         */
/* The name says it all!                                                   */
/*                                                                         */
/***************************************************************************/

VOID NEAR PASCAL InitColorDlg(HWND hDlg,
                              LPDRIVERINFO lpDrvInfo)
{
  LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;

#ifndef ADOBEPS42
  // On level 1 printers, only color matching on host available.
  // Other methods should be grayed out.
  if (((LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo))->devcaps.languageLevel <= 1)
  {
      lpPSExtDevmode->dm.iColorMatchingMethod = COLOR_MATCHING_ON_HOST;
      EnableWindow(GetDlgItem(hDlg, ID_CM_PRINTER), FALSE);
      EnableWindow(GetDlgItem(hDlg, ID_CM_TEXT2), FALSE);
      EnableWindow(GetDlgItem(hDlg, ID_CM_ICM), FALSE);
      EnableWindow(GetDlgItem(hDlg, ID_CM_TEXT3), FALSE);
  }
#endif

#ifdef PROOFING
  SendDlgItemMessage( hDlg, ID_CM_PROFILE_CB, CB_SETCURSEL, 0, 0 );
  if( lpPSExtDevmode->dm2.dwProfile )
  {  char buffer[256], profile[256];

     CheckDlgButton( hDlg, ID_CM_PROOFING, TRUE );
     EnableWindow(GetDlgItem(hDlg, ID_CM_TEXT_PROFILE), TRUE);
     EnableWindow(GetDlgItem(hDlg, ID_CM_PROFILE_CB), TRUE);
     EnableWindow(GetDlgItem(hDlg, ID_CM_PROFILE_PROPERTIES), TRUE);
     EnableWindow(GetDlgItem(hDlg, ID_CM_ICM), FALSE);
     if( EnumICMProfile( ENUMICMP_MATCH, 0, lpPSExtDevmode->dm2.dwProfile,
                         (LPSTR)buffer, sizeof( buffer ) ) )
     {  BOOL found = FALSE;
        WORD i, count;
        count = (WORD)SendDlgItemMessage( hDlg, ID_CM_PROFILE_CB, CB_GETCOUNT, 0, 0 );
        for( i=0; !found && i<count; i++ )
        {
           SendDlgItemMessage( hDlg, ID_CM_PROFILE_CB, CB_GETLBTEXT,
                               (WPARAM)i, (LPARAM)((LPSTR)profile));
           if( !lstrcmp( buffer, profile ) ) found = TRUE;
        }
        if( found )
           SendDlgItemMessage( hDlg, ID_CM_PROFILE_CB, CB_SETCURSEL, i-1, 0 );
        else
           lpPSExtDevmode->dm2.dwProfile = 0;
     }
     else
        lpPSExtDevmode->dm2.dwProfile = 0;
  }
  else
  {
     CheckDlgButton( hDlg, ID_CM_PROOFING, FALSE );
     EnableWindow(GetDlgItem(hDlg, ID_CM_TEXT_PROFILE), FALSE);
     EnableWindow(GetDlgItem(hDlg, ID_CM_PROFILE_CB), FALSE);
     EnableWindow(GetDlgItem(hDlg, ID_CM_PROFILE_PROPERTIES), FALSE);
     EnableWindow(GetDlgItem(hDlg, ID_CM_ICM), TRUE);
  }
#endif

  if (lpPSExtDevmode->dm.useImageColorMatching == ICM_ALWAYS)
  {
      if (lpPSExtDevmode->dm.iColorMatchingMethod == COLOR_MATCHING_ON_HOST)
      {
        lpPSExtDevmode->dm.iColorMatchingMethod = COLOR_MATCHING_ON_PRINTER;
      }
      EnableWindow(GetDlgItem(hDlg, ID_CM_HOST), FALSE);
      EnableWindow(GetDlgItem(hDlg, ID_CM_TEXT1), FALSE);
  }
  else
  {
      EnableWindow(GetDlgItem(hDlg, ID_CM_HOST), TRUE);
      EnableWindow(GetDlgItem(hDlg, ID_CM_TEXT1), TRUE);
  }

  switch (lpPSExtDevmode->dm.iColorMatchingMethod)
  {
     case COLOR_MATCHING_ON_HOST:
        CheckRadioButton(hDlg, ID_CM_HOST, ID_CM_ICM, ID_CM_HOST);
        break;

     case COLOR_MATCHING_ON_PRINTER:
        CheckRadioButton(hDlg, ID_CM_HOST, ID_CM_ICM, ID_CM_PRINTER);
        break;

     case COLOR_MATCHING_PRINTER_CALIBRATION:
        CheckRadioButton(hDlg, ID_CM_HOST, ID_CM_ICM, ID_CM_ICM);
        break;
  }

  switch (lpPSExtDevmode->dm.iRenderingIntent)
  {
     case INTENT_SATURATION:
        CheckRadioButton(hDlg, ID_CM_SATURATION, ID_CM_ABSCOLORMETRIC, ID_CM_SATURATION);
        break;

     case INTENT_CONTRAST:
        CheckRadioButton(hDlg, ID_CM_SATURATION, ID_CM_ABSCOLORMETRIC, ID_CM_CONTRAST);
        break;

     case INTENT_COLORMETRIC:
        if( lpPSExtDevmode->dm.iAbsoluteColorimetric )
           CheckRadioButton(hDlg, ID_CM_SATURATION, ID_CM_ABSCOLORMETRIC, ID_CM_ABSCOLORMETRIC);
        else
           CheckRadioButton(hDlg, ID_CM_SATURATION, ID_CM_ABSCOLORMETRIC, ID_CM_COLORMETRIC);
        break;
  }
}

/*****************************************************************************/
/*                 RestoreColorDlgDefaults                                   */
/* Purpose:                                                                  */
/*   Figures out color dlg defaults and sets them                            */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPSEXTDEVMODE lpPSExtDevmode -- Pointer to the devmode structure       */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/

void FAR PASCAL RestoreColorDlgDefaults(LPPSEXTDEVMODE lpPSExtDevmode)
{
  if( lpPSExtDevmode->dm.useImageColorMatching == ICM_ALWAYS )
    lpPSExtDevmode->dm.iColorMatchingMethod = COLOR_MATCHING_ON_PRINTER;
  else
    lpPSExtDevmode->dm.iColorMatchingMethod = COLOR_MATCHING_ON_HOST;

#ifdef PROOFING
  lpPSExtDevmode->dm2.dwProfile=0;
#endif

  lpPSExtDevmode->dm.iRenderingIntent = INTENT_SATURATION;
}

/*****************************************************************************/
/*                 RestoreAndDisplayColorDlgDefaults                         */
/* Purpose:                                                                  */
/*   Figures out color dlg defaults and displays them                        */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   LPDRIVERINFO lpDrvInfo -- Pointer to the driver info structure          */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/

void NEAR PASCAL RestoreAndDisplayColorDlgDefaults(HWND hDlg,
                                                   LPDRIVERINFO lpDrvInfo)
{
  LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;

  RestoreColorDlgDefaults(lpPSExtDevmode);
  InitColorDlg(hDlg,lpDrvInfo);
}

/*****************************************************************************/
/*                 SaveColorDlg                                              */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the Color Matching dialog box                     */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   LPDRIVERINFO lpDrvInfo -- Pointer to the driver infor structure         */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE -- If successful                                                   */
/*   FALSE -- If failure                                                     */
/*****************************************************************************/

BOOL NEAR PASCAL SaveColorDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
   LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;

   if (IsDlgButtonChecked(hDlg,ID_CM_HOST))
      lpPSExtDevmode->dm.iColorMatchingMethod = COLOR_MATCHING_ON_HOST;
   else if (IsDlgButtonChecked(hDlg,ID_CM_PRINTER))
      lpPSExtDevmode->dm.iColorMatchingMethod = COLOR_MATCHING_ON_PRINTER;
   else
      lpPSExtDevmode->dm.iColorMatchingMethod = COLOR_MATCHING_PRINTER_CALIBRATION;

   if (IsDlgButtonChecked(hDlg,ID_CM_SATURATION))
      lpPSExtDevmode->dm.iRenderingIntent = INTENT_SATURATION;
   else if (IsDlgButtonChecked(hDlg,ID_CM_CONTRAST))
      lpPSExtDevmode->dm.iRenderingIntent = INTENT_CONTRAST;
   else
   {
      lpPSExtDevmode->dm.iRenderingIntent = INTENT_COLORMETRIC;
      lpPSExtDevmode->dm.iAbsoluteColorimetric = IsDlgButtonChecked(hDlg,ID_CM_COLORMETRIC)?0:1;
   }

#ifdef PROOFING
   if( IsDlgButtonChecked(hDlg,ID_CM_PROOFING) )
   {  char buffer[256];
      DWORD dwIndex = SendDlgItemMessage(hDlg, ID_CM_PROFILE_CB, CB_GETCURSEL, 0, 0);
      if (dwIndex != CB_ERR)
         SendDlgItemMessage(hDlg, ID_CM_PROFILE_CB, CB_GETLBTEXT,
                            (WPARAM)dwIndex, (LPARAM)((LPSTR)buffer));
      lpPSExtDevmode->dm2.dwProfile = HashString( (LPSTR)buffer, lstrlen(buffer) );
   }
   else
      lpPSExtDevmode->dm2.dwProfile = 0;
#endif

   return (TRUE);
}

/*****************************************************************************/
/*                 CHColorDlg                                                */
/* Purpose:                                                                  */
/*   Dialog Procedure for the Color Matching dialog box                      */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHColorDlg(HWND hDlg, unsigned imsg,
                                   WORD wParam, LONG lParam)
{
  LPDRIVERINFO lpDrvInfo;
  LPPSEXTDEVMODE lpPSExtDevmode, lpPSExtSavedDevmode;
#ifdef PROOFING
  WORD i;
  char buffer[256];
  HANDLE tmpH;
  LPSTR lpSavedProfile;
#endif

  if (lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
    {
    lpPSExtDevmode = lpDrvInfo->lpDM;
    }

  switch (imsg)
     {
     case WM_INITDIALOG:
       lpDrvInfo=(LPDRIVERINFO)lParam;
       SetWindowLong(hDlg,DWL_USER,(LPARAM)lpDrvInfo);
       lpPSExtDevmode=lpDrvInfo->lpDM;

       lpDrvInfo->hSavedDevmode = GlobalAlloc(GHND, sizeof(PSEXTDEVMODE));
       lpPSExtSavedDevmode = (LPPSEXTDEVMODE)GlobalLock(lpDrvInfo->hSavedDevmode);
       *lpPSExtSavedDevmode = *lpPSExtDevmode;
       GlobalUnlock(lpDrvInfo->hSavedDevmode);
#ifdef PROOFING
       EnumICMProfile( ENUMICMP_INSERT, hDlg, ID_CM_PROFILE_CB, NULL, 0 );
#endif
       InitColorDlg(hDlg,lpDrvInfo);
       break;

    case WM_CONTEXTMENU:
       if (wParam != -1)
       {
          WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                  (DWORD)(LPDWORD)dwHelpMap);
       }
       break;

    case WM_HELP:
       if (((LPHELPINFO) lParam)->hItemHandle != -1)
       {
          WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                  HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
       }
       break;

    case WM_COMMAND:
      switch (wParam)
        {
        case IDOK:
          if (!SaveColorDlg(hDlg,lpDrvInfo))
            break;

          GlobalFree(lpDrvInfo->hSavedDevmode);
          EndDialog(hDlg, wParam) ;
          break ;

        case IDCANCEL:
          /* Reset the Data */
          lpPSExtSavedDevmode = (LPPSEXTDEVMODE)GlobalLock(lpDrvInfo->hSavedDevmode);
          *lpPSExtDevmode = *lpPSExtSavedDevmode;
          GlobalUnlock(lpDrvInfo->hSavedDevmode);
          GlobalFree(lpDrvInfo->hSavedDevmode);
          EndDialog(hDlg, wParam) ;
          break ;

#ifndef USE_WHATSTHIS_HELP
        case ID_HELP:
            WinHelp(hDlg, szHelpFile, HELP_CONTEXT, IDH_PSCRIPT_SET_COLOR_RES);
            break;
#endif
        case ID_RESTORE_DEFAULTS:
          RestoreAndDisplayColorDlgDefaults(hDlg, lpDrvInfo);
          break;

#ifdef PROOFING
        case ID_CM_PROOFING:
          if( IsDlgButtonChecked( hDlg, ID_CM_PROOFING ) )
          {
             EnableWindow(GetDlgItem(hDlg, ID_CM_TEXT_PROFILE), TRUE);
             EnableWindow(GetDlgItem(hDlg, ID_CM_PROFILE_CB), TRUE);
             EnableWindow(GetDlgItem(hDlg, ID_CM_PROFILE_PROPERTIES), TRUE);
             EnableWindow(GetDlgItem(hDlg, ID_CM_ICM), FALSE);
             if (IsDlgButtonChecked(hDlg,ID_CM_ICM))
                CheckRadioButton(hDlg, ID_CM_HOST, ID_CM_ICM, ID_CM_PRINTER);
          }
          else
          {
             EnableWindow(GetDlgItem(hDlg, ID_CM_TEXT_PROFILE), FALSE);
             EnableWindow(GetDlgItem(hDlg, ID_CM_PROFILE_CB), FALSE);
             EnableWindow(GetDlgItem(hDlg, ID_CM_PROFILE_PROPERTIES), FALSE);
             EnableWindow(GetDlgItem(hDlg, ID_CM_ICM), TRUE);
          }
          break;

        case ID_CM_PROFILE_PROPERTIES:
          i = (WORD)SendDlgItemMessage( hDlg, ID_CM_PROFILE_CB, CB_GETCURSEL,
                             0, 0);
          SendDlgItemMessage( hDlg, ID_CM_PROFILE_CB, CB_GETLBTEXT,
                             (WPARAM)i, (LPARAM)((LPSTR)buffer));
          tmpH = lpDrvInfo->hSavedDevmode;
          if (lpDrvInfo->hSavedDevmode = GlobalAlloc(GHND, lstrlen(buffer)+1))
          {
             lpSavedProfile = (LPSTR)GlobalLock(lpDrvInfo->hSavedDevmode);
             lstrcpy( lpSavedProfile, buffer );
             if (DialogBoxParam(ghDriverMod,
                         MAKEINTRESOURCE(IDD_PROFILE_PROPERTIES), hDlg,
                         ProfilePropertiesDlg, (LPARAM)lpDrvInfo) == IDOK)
             GlobalUnlock(lpDrvInfo->hSavedDevmode);
             GlobalFree(lpDrvInfo->hSavedDevmode);
          }
          lpDrvInfo->hSavedDevmode = tmpH;
          break;
#endif

        default:
          return FALSE;

        } /* switch(wParam) */
      break ;

#ifdef PROOFING
    case WM_MEASUREITEM:
      HandleMeasureItem(hDlg, lpDrvInfo, (int)wParam,
                        (LPMEASUREITEMSTRUCT)lParam);
      break;

    case WM_DRAWITEM:
      HandleDrawItem(hDlg, lpDrvInfo, (int)wParam,
                     (LPDRAWITEMSTRUCT)lParam);
      break;
#endif

    default:
      return FALSE;
    } /* switch(imsg) */

  return TRUE;
}

#ifdef PROOFING

/*****************************************************************************/
/*                 ProfilePropertiesDlg                                      */
/* Purpose:                                                                  */
/*   Dialog Procedure for the ICM Profile Properties dialog box              */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL ProfilePropertiesDlg(HWND hDlg, unsigned imsg,
                                             WORD wParam, LONG lParam)
{
  LPDRIVERINFO   lpDrvInfo;
  LPPSEXTDEVMODE lpPSExtDevmode;
  LPSTR   lpSavedProfile = NULL;
  CHANDLE CP;
  HGLOBAL hMem, hData;
  MEMPTR  lpData;
  SINT    index=0, size=0;
  CSIG    CSig;
  BOOL    err = FALSE;
  char    buffer[300];

  if (lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
    {
    lpPSExtDevmode = lpDrvInfo->lpDM;
    }

  switch (imsg)
  {
     case WM_INITDIALOG:
       lpDrvInfo=(LPDRIVERINFO)lParam;
       SetWindowLong(hDlg,DWL_USER,(LPARAM)lpDrvInfo);
       lpPSExtDevmode=lpDrvInfo->lpDM;

       if(!(lpSavedProfile = (LPSTR)GlobalLock(lpDrvInfo->hSavedDevmode)))
          err = TRUE;

       // In Win95, the ICMProfiles have a path
       // In Win98, the ICMProfiles have no path info.
       if( !err )
       {
          if( IsWin40() )
             lstrcpy( buffer, ExtractFileName(lpSavedProfile) );
          else
             lstrcpy( buffer, lpSavedProfile );
          GetWindowText( hDlg, buffer+lstrlen(buffer), 300-lstrlen(buffer) );
          SetWindowText( hDlg, buffer );

          if( IsWin40() )
             lstrcpy( buffer, lpSavedProfile );
          else
          {
             UINT len = sizeof(buffer), result;
             result = GetSystemDirectory(buffer, len);
             if( result > len )
                err = TRUE;
             else
             {
                if( buffer[result] != '\\' ) lstrcat( buffer, "\\" );
                lstrcat( buffer, "Color\\" );
                lstrcat( buffer, lpSavedProfile );
             }
          }
       }

       if(!err && LoadCP( buffer, (HGLOBAL FAR *)(&hMem), (LPCHANDLE)(&CP) ))
       {
          if(DoesCPTagExist( CP, icSigProfileDescriptionTag ) &&
             GetCPTagIndex( CP, icSigProfileDescriptionTag, (LPSINT)&index ) &&
             GetCPElementSize( CP, index, (LPSINT)&size ) &&
             MemAlloc( size, (HGLOBAL FAR *)(&hData), (LPMEMPTR)(&lpData) ))
          {
             if (GetCPElement( CP, index, lpData, size ))
             {
                 lpData += sizeof(icTagBase) + sizeof(icUInt32Number);
                 SetWindowText( GetDlgItem(hDlg, IDC_CP_DESC), lpData );
             }
             MemFree(hData);
          }

          if(DoesCPTagExist( CP, icSigK007Tag ) &&
             GetCPTagIndex( CP, icSigK007Tag, (LPSINT)&index ) &&
             GetCPElementType( CP, index, (LPCSIG)(&CSig) ) &&
             CSig == icSigTextDescriptionType &&
             GetCPElementSize( CP, index, (LPSINT)&size ) &&
             MemAlloc( size, (HGLOBAL FAR *)(&hData), (LPMEMPTR)(&lpData) ))
          {
            if (GetCPElement( CP, index, lpData, size ))
            {
                lpData += sizeof(icTagBase) + sizeof(icUInt32Number);
                SetWindowText( GetDlgItem(hDlg, IDC_CP_ADDITIONAL), lpData );
             }
             MemFree(hData);
          }

          if(DoesCPTagExist( CP, icSigCopyrightTag ) &&
             GetCPTagIndex( CP, icSigCopyrightTag, (LPSINT)&index ) &&
             GetCPElementSize( CP, index, (LPSINT)&size ) &&
             MemAlloc( size, (HGLOBAL FAR *)(&hData), (LPMEMPTR)(&lpData) ))
          {
             if (GetCPElement( CP, index, lpData, size ))
             {
                lpData += sizeof(icTagBase);
                SetWindowText( GetDlgItem(hDlg, IDC_CP_CPRT), lpData );
             }
             MemFree(hData);
          }

          FreeCP(hMem);
       }
       if( lpSavedProfile) GlobalUnlock(lpDrvInfo->hSavedDevmode);
       break;

    case WM_COMMAND:
      switch (wParam)
      {
        case IDOK:
        case IDCANCEL:
          EndDialog(hDlg, wParam) ;
          break ;
      }

    default:
      return FALSE;

  } /* switch(imsg) */

  return TRUE;
}

#endif

