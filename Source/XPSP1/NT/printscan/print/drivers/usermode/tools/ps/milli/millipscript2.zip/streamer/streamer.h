/*
  streamer.h

  Header file for the streamer utility.

             Copyright (c) 1994 -- Adobe Systems Incorporated
    PostScript is a registered trademark of Adobe Systems Incorporated.

NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

*/

#ifndef STREAMER_H
#define STREAMER_H

#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif
#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES
#include PARSEGLU
#if CID
#include DECO_LIB
#endif

#include STREAMER_FAUX

/* Error values from the streamer function */

#define ST_NOERR		0	/* No error detected */
#define ST_BADOPTION		2	/* Invalid option in StreamerOpts */
#define ST_BUFFER_TOO_SMALL	3	/* The buffer is too small for data */
#define ST_OUT_OF_MEM     	4	/* No memory was available! */
#define ST_BAD_BLEND_DATA	5	/* Blend data was somehow bad */
#define ST_NO_DATA		6	/* T1FontPointer was bad */
#define ST_BAD_CHARSTRING	7	/* Could not process the charstring */
#define ST_CANT_CHANGE_ENCRYPTION 8	/* Tried to change encryption half way through... */
#define ST_NO_MEM_CALLBACK	9	/* Tried to start without a mem callback*/
#define ST_CALLBACKFAILED	10	/* One of the user callbacks failed */
#define ST_NO_CHARNAME		11	/* No charname given for a charstring */
#define ST_BUFFER_TOO_BIG	12	/* On 8 bit systems possible to get too big */

/* The user can choose an initial buffer size for the only big buffer(s) used. 
   (This size may be used for two buffers total, if hexencoding is used)
   SUGGESTED_BUFSIZE is a good starting point.  Too small and the code will
   become inefficient or need to expand the buffer at some point (probably
   would not occur if the buffer is bigger than 4K).  Too large and memory 
   is wasted.  Note that the initial allocation may be for slightly more 
   than the suggested size so I back down from 8K (it may be less efficient
   to use just over 8K, as opposed to just under).  And 8K is chosen because
   that should handle even Carta and Kanji fonts...
 */

#define SUGGESTED_BUFSIZE	48000


/* Types for the two call-backs to get charstrings and subr charstrings.
   Call-back should return true if successful, false on error.  There are
   two ways charstrings may be asked for: By encoding value (for SEAC
   characters), and by charString index.  If a SEAC character is found the
   font MUST have Standard Encoding (by the definition of SEAC in the 
   black book).  The encoding value occurs in the charstring.  However, for
   accessing general charstrings it is more convenient to specify the 
   charstring index in the range of 0...numCharStrings-1 (because standard
   encoding may not be in use, or additional chars may be present, etc.).
   If streamer requests a charstring by encoding and a NULL is returned
   the font is invalid.  If streamer requests a charstring by char index
   and a NULL is returned sparsing is occurring.  See the sparseMethod
   field of the StreamerOpts structure for more information on this. */

/* Streamer wants the charstring that corresponds to this standard encoding entry */
#define INDEX_IS_ENCODING	0x00	
/* Streamer wants the charstring at this position in the charstring dictionary */
#define INDEX_IS_CHARINDEX	0x01
#define INDEX_IS_NAME		0x02
/* maps character indexes as required by Windows ANSI.  A common font reencoding */
#define INDEX_IS_WINANSI        0x11
/* Font is mapped by a special encoding */
#define INDEX_IS_SPECIALENCODING 0x12
/* All chars are mapped to .notdef or some other dummy location */
#define INDEX_IS_NOENCODING     0x13
#define INDEX_IS_WINANSIOLD     0x14
/* Mapping to different Windows CharSet */
#define INDEX_IS_GREEKCS		0xA1
#define INDEX_IS_TURKISHCS		0xA2
#define INDEX_IS_HEBREWCS		0xB1
#define INDEX_IS_ARABICCS		0xB2
#define INDEX_IS_BALTICCS		0xBA
#define INDEX_IS_RUSSIANCS		0xCC
#define INDEX_IS_EECS			0xEE
#define INDEX_IS_MACSTANDARDCS	0x4D

typedef IntX (*GetCharStringFunc) ARGDECL5(IntX, index, IntX, indexType,
              CharDataPtr *, charString, Card16 *, charLen, Card8 **, charName);
typedef IntX (*GetSubrFunc) ARGDECL3(IntX, subrNo, CharDataPtr *, 
                                       subrCharString, Card16 *, subrLen);


/* Type for the PutBytesFunc call-back.  This is the call-back that gets
   the processed data from streamer (and does whatever it wants with it). 
   Returns true if successful, false on error. */

typedef CardX (*PutBytesFunc) ARGDECL2(char *, pData, Card32, len);


/* Default value for an invalid request is, in all cases, the first option */

/* Sparsing methods available: (valid for all fonts) */
/* When the code requests a charstring from the user and none is returned 
   sparsing is occuring (this is NOT referring to the SEAC case).  This
   flag indicates what to do in that situation. */
#define ST_SPARSE_REMOVE	0x00    /* When sparsing, remove charstring */
#define ST_SPARSE_ENDCHAR	0x01    /* When sparsing, leave just endchar*/

/* Snapshot options: (only valid for MM and Faux fonts) */
#define ST_NO_SNAPSHOT          0x00    /* Keep all masters */
#define ST_SNAPSHOT             0x01    /* Create a snapshot of the font */

/* Subroutine flattening options: (flattening required for MM fonts) */
/* NOTE:  Some old fonts have hint substitution built into the charstrings
   instead of into subr 4.  If these fonts are flattened or subr sparsed
   the resulting charstrings may not work on some old printers. */
#define ST_KEEP_SUBRS           0x00    /* Keep all subroutines intact */
#define ST_FLATTEN_SUBRS        0x01    /* Flatten/unwind all the subroutines */

/* Unique ID options: */
#define ST_KEEP_UID             0x00    /* Keep the font's unique ID */
#define ST_USER_UID             0x01    /* Use the user provided UID */

/* EExec options: */
#define ST_NO_ENCRYPTION	0x00    /* Do not encrypt the binary portion */
#define ST_ENCRYPT              0x01    /* eexec encryption on font */
#define ST_ENCRYPTHEX           0x02    /* eexec encryption and hexencoding */
/* Mask for only the encryption portion of this flag */
#define ST_ENCRYPT_MASK		0x01    

/* accessPrivateDict field: */
/* Set this field to true if any "noaccess" and "readonly" attributes for
   the private dictionary should be removed. */

/* lenIV field: */
/* This field is the actual value for lenIV (charstring) encryption.  */
/* Typically -1 (no encryption), 0 (encryption with no extra bytes, or 4 */
/* (encryption with 4 extra bytes). */

/* uniqueID field: */
/* The user can specify a special unique ID for use in the printer. */

/* blendVector field: */
/* The MM design vector.  It should have the correct number of entries  */
/* (as specified by blendLen).  This only applies for MM fonts. */

/* blendLen field: */
/* Number of elements in the blendVector. */

/* doingFaux field: */
/* For now this should always be set to 0.  (Faux is not quite working). 
   When faux is working there may be a different method for indicating a
   faux font. */

/* Call-backs are described above, where their types are defined */

/* Streamer Utility Options:
   All the flags MUST be set!  None of the other fields are required */
typedef struct
 { unsigned int sparseMethod:1,         /* Type of sparsing to use */
                snapShot:1,             /* Perform a snapshot */
                subrFlatten:1,          /* Flatten subrs */
                accessPrivateDict:1, /* prevents the noaccess,readonly attribs*/
                eexec:2;                /* Use eexec encryption? */
   Int16 lenIV;                         /* Output lenIV format */
   Card32 uniqueID;                     /* Optional (flag above) */
   Fixed *blendVector;			/* Blend vector for MM snapshots */
   Card16 blendLen;			/* Number of elements in blend vector */
   Card8 doingFaux;			/* Flag that says if we are doing faux*/
   PutBytesFunc PutBytes;               /* Call back for putting stream data */
   ReallocFunc MemoryRealloc;		/* Call back to get memory */
   GetFauxInfoFunc GetFauxInfo;		/* Call back to get faux info */
 } StreamerOpts, *PStreamerOpts;


/* Info used to process charstrings.  It is set with StreamerSetCharOpts()
   For faux fonts this needs to be set per charstring.  For snapshotting and
   other cases it only needs to be set once for all charstrings.  Note that
   the lenIV information contained here is also needed for subr streaming */

/* lenIV field: */
/* This field is the actual value for lenIV (charstring) encryption.  
   Typically -1 (no encryption), 0 (encryption with no extra bytes, or 4 
   (encryption with 4 extra bytes).  It should be the same as the value
   used in the StreamerOpts structure. */

/* canSparseSubrs field: */
/* This field is returned to the user by streamer.  It tells the user whether
   or not the subrs can be sparsed or flattened.  Basically it tells you that
   there is something (perhaps calculated subrs) preventing you from
   sparsing or flattening a font file safely.  Note that this would not
   apply to snapshots or faux fonts since they cannot (at this time) 
   contain calculated subrs, etc. */

/* Ajit says this is not needed */
/* accessCharStrings field: */
/* Set this field to true to prevent the noaccess attribute from being set 
   for each charstring dictionary entry.  Probably only used if you are 
   trying to dynamically add to the charstring dict. */

/* flattenCharStrs field: */
/* Indicates whether charStrings should be flattened or not.  Set by the
   snapShot and subrFlatten fields of StreamerOpts. */

/* charStringKey: */
/* The initial ee encryption key used for all charstrings and subrs.  This 
   cannot change within a font.  The default is 4330. */

/* lenIVBytes: */
/* Precalculated ee encrypted bytes (lenIV of them).  They are placed in front
   of every charstring and subr (so why recalculate them all the time?). */

/* doingFaux: */
/* For now this should always be set to 0.  (Faux is not quite working). 
   When faux is working there may be a different method for indicating a
   faux font. */

/* GetCharString: */
/* Call back to get charstrings.  It is used with seac so it will be called
   with the standard encoding position of the charstring it needs. */

/* GetSubr: */
/* Call back to get subroutines.  It is called with the subroutine number
   it needs. */

/* baseChar: */
/* Information returned to the user.  This is the base character the seac
   command uses.  If this field and the accentChar field are both 0 the 
   character is not a seac character. */

/* accentChar: */
/* Information returned to the user.  This is the accent character the seac
   command uses.  If this field and the basetChar field are both 0 the 
   character is not a seac character. */

typedef struct
 { Int16 lenIV;			    /* Desired lenIV, from StreamerOpts */

   unsigned int canSparseSubrs:1,   /* Tells the user if subrs can be sparsed */
#if 0
                accessCharStrings:1, /* prevents the noaccess attribute */
#endif
                flattenCharStrs:1;  /* Flatten charstrings */
   Card16 charStringKey;	    /* Key used for charstring EE encryption */
   Card8 lenIVBytes[4];         /* Encrypted bytes in front of charstrs&subrs */
   IntX doingFaux;		    /* Flag indicating if Faux fonting */
   GetCharStringFunc GetCharString; /* Call back to get a charstring */
   GetSubrFunc GetSubr;		    /* Call back to get subrs */

   /* If these are both 0 the character was not a SEAC */
   Card16 baseChar;			/* Base character needed for seac */
   Card16 accentChar;			/* Accent character needed for seac */
 } CharStrOpts;


/* All the info needed by the buffer code.  Don't change this values!
   addEOL is used to place EOLs in the hexencoded data (to avoid 1 huge
   string). */

typedef struct
 { Card8 *hexBuf;                  /* The buffer pointer */
   Card8 *bp;                      /* The buffer pointer */
   Card8 *bufStart;                /* The start of the buffer */
   Card32 bufSize;                 /* The buffer size */
   Card32 bufLeft;                 /* Length left in buffer */
   Card16 eexecKey;                /* The current eexecKey */
   Card8 eexec;                    /* The type of eexec encryption to use */
   Card8 addEOL;   /* Controls the placement of EOLs in hexencoded data */
 } BufferStatus, *PBufferStatus;



/*************************************************************************

Function name:  StreamerCheckOpts()

**************************************************************************

Date:           03/05/94
Author:         Ron Fischer (rff)
Source in:      streamer.c
Summary:        Check the validity of the streamer options.
Description:    Check the specified options, make sure they are valid and
                consistent.  For instance, it ST_SPARSE_BY_NAME is given
                then the sparseNames pointer should not be NULL
Parameters:     StreamerOpts s -- the streamer options struct

Return Values:  ST_NOERR if options are fine, ST_BADOPTION if an invalid
                option is detected.
Notes:
See also:

**************************************************************************/

PUBLIC IntX StreamerCheckOpts ARGDECL1(PStreamerOpts, s);


/*************************************************************************

Function name:  StreamerStart()

**************************************************************************

Date:           03/29/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Initialize the streamer code for a particular font
Description:    Sets up the streamer internals for a particular font
                (including the data buffer).  All relevant info is
                stored in the 3 structures.

Parameters:     fp -- contains font information
                s -- contains options for streamer
                co -- charString info (used for the GetSubr() callback)
                b -- contains the buffer's internal state
                bufSize -- starting size for the largest internal buffer(s).
                           Other buffers may be allocated, but this will
                           be the largest (it may take two allocations).
                           See SUGGESTED_BUFSIZE above.

Return Values:  ST_BUFFER_TOO_SMALL - couldn't get a big enough buffer
Notes:          Currently the buffer is flushed before any of the interface
                functions return.  This does not mean that the buffer status
                can be ignored!
See also:       StreamerEnd()

**************************************************************************/

PUBLIC IntX StreamerStart ARGDECL5(T1FontPointer, fp, PStreamerOpts, s,
        CharStrOpts *, co, PBufferStatus, b, Card32, bufSize);


/*************************************************************************

Function name:  StreamerEnd()

**************************************************************************

Date:           03/29/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Clear any state.   Free the internal buffer.
Description:    Clear any state.   Free the internal buffers (including
                the buildCharArray).

Parameters:     fp -- the pointer to font info
                s -- the streamer options
                b -- the internal buffer's state
Return Values:  none.
Notes:
See also:       StreamerStart()

**************************************************************************/

PUBLIC void StreamerEnd ARGDECL3(T1FontPointer, fp, PStreamerOpts, s,
                                PBufferStatus, b);


/*************************************************************************

Function name:  StreamFontDict()

**************************************************************************

Date:           03/28/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream the Font Dictionary portion of a font file
Description:    Stream all the info from the start of the font file to
                the encrypted portion (including the encoding vector).

Parameters:     fp - pointer to the font data
                s - streamer options
Return Values:  see the ST_ values in streamer.h
Notes:		A couple of the fields output by this procedure are the
                fontName and the unique ID fields.  The user may want
                to consider modifying these fields to avoid confusion
                with the original, unstreamed font.  Some sort of random
                key can be prepended to the original font name, for
                instance.
                The encoding vector is also output by this function.
See also:

**************************************************************************/

PUBLIC IntX StreamFontDict ARGDECL4(T1FontPointer, fp, PStreamerOpts, s,
                              FauxInfoPointer, fi, PBufferStatus, b);


/*************************************************************************

Function name:  StreamPrivateDict()

**************************************************************************

Date:           03/28/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream the Private Dictionary entries.
Description:    Streams the Private dictionary information, beginning
                with the encryption statement "currentfile eexec",
                ending after the OtherSubrs (before the subrs).

Parameters:     fp - the font specific data
                s - the streamer options

Return Values:  see the ST_ values in streamer.h
Notes:
See also:

**************************************************************************/

PUBLIC IntX StreamPrivateDict ARGDECL3(T1FontPointer, fp, PStreamerOpts, s,
                                       PBufferStatus, b);

/*************************************************************************

Function name:  StreamSubrs()

**************************************************************************

Date:           03/20/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream out the subroutines for a font
Description:    Stream out a font's subroutines, in the correct format.
                It can flatten subrs (remove all except possibly the
                5 standard subrs) or sparse subrs.  Subrs are sparsed by
                using the GetSubr() callback.  If a subr returned by the
                user from that callback is null, a stub will be put in
                it's place (some older parser will expect a stub--it's
                best to provide one).  Note that StreamCharString() should
                be called before attempting to sparse subrs--it will
                provide information about which subrs are used and whether
                or not they can be sparsed at all.

Parameters:     fp -- the font information
                so - the streamer options
                charOpts -- the charstring options (the lenIV info is
                            needed).
Return Values:  see ST_ values in streamer.h
Notes:          Subr flattening has a potential problem.  CheckSubrs() can
                be used to determine if 1st 5 standard subrs are present,
                but if all 5 are not there then it will allow flattening
                (even if some of them are there).  These subrs may not
                flatten well (or the code generated may not execute).  I
                have never actually found this problem.
See also:       StreamerSetCharOpts(), CheckSubrs()

**************************************************************************/

PUBLIC IntX StreamSubrs ARGDECL3(T1FontPointer, fp, CharStrOpts *, charOpts, 
               PBufferStatus, b);


/*************************************************************************

Function name:  StreamerSetCharOpts()

**************************************************************************

Date:           03/29/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Set the options for processing a charstring
Description:    Set all the options/values used in the processing of a
                charstring.  This is mainly snapshotting and encryption
                info.  This info is also needed to stream subrs.

Parameters:     fp -- the font information
                s -- the streamer options
                charOpts -- the initialized charstring options
                gc -- the GetCharString() callback
                gs -- the GetSubr() callback

Return Values:  none
Notes:
See also:       StreamCharString(), StreamSubrs()

**************************************************************************/

PUBLIC void StreamerSetCharOpts ARGDECL5(T1FontPointer, fp, PStreamerOpts, s,
      CharStrOpts *, charOpts, GetCharStringFunc, gc, GetSubrFunc, gs);


/*************************************************************************

Function name:  StreamCharString()

**************************************************************************

Date:           03/20/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream a charstring
Description:    Current implementation wants to snapshot&flatten!
                In general this should stream a charstring.  If snapshotting
                is not selected that will only consist of (possibly)
                changing the encryption of the charstring.  For snapshotting
                that will include snapshot and flattening.
Parameters:     dataP -- the pointer to the initial charstring
                length -- the length of the charstring
                charName -- the name of the charstring
                fp -- Font information
                opts -- the charstring options
                fi -- any Faux font information
                b -- the buffer info for the buffer to use
Return Values:  see ST_ values in streamer.h
Notes:
See also:

**************************************************************************/

PUBLIC IntX StreamCharString ARGDECL7(Card8 *, dataP, Int32, length,
   Card8 *, charName, T1FontPointer, fp, CharStrOpts *, opts,
   FauxInfoPointer, fi, PBufferStatus, b);


/*************************************************************************

Function name:  StreamFontEnd()

**************************************************************************

Date:           03/28/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream the end of font info (from the end of the charstrings
                to the eof).
Description:    Stream the end of font info (from the end of the charstrings
                to the eof).

Parameters:     

Return Values:  see the ST_ values in streamer.h
Notes:
See also:

**************************************************************************/

PUBLIC IntX StreamFontEnd ARGDECL2(PBufferStatus, b, PStreamerOpts, s);


/*************************************************************************

Function name:  StreamFont()

**************************************************************************

Date:           03/28/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream a Type 1 font
Description:    Create an output Type 1 font from input font data.
                Input font data is in the fp structure.  Charstrings and
                Subrs are accessed through callbacks.  Format and content
                of the output font is determined by the streamer options
                (see streamer.h)

Parameters:     fp -- the font specific data
                s -- the streamer options
                co -- the charstring options (set with StreamerSetCharOpts())
                b -- the buffer info for the buffer to use.

Return Values:  ST_NO_DATA -- The fp was null or invalid
                ST_NOERR -- everything was fine
                (other ST_ error values can be returned from nested funcs)
Notes:
See also:

**************************************************************************/

PUBLIC IntX StreamFont ARGDECL5(T1FontPointer, fp, PStreamerOpts, s,
              CharStrOpts *, co, PBufferStatus, b, FauxInfoPointer, fi);


/*************************************************************************

Function name:  BufferEncrypt()

**************************************************************************

Date:           03/20/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        eexec encrypt a buffer
Description:    eexec encrypt and possibly hexencode a buffer of lenght
                inLen.  If hexencoding is performed the outBuf will be
                just over twice as long as the inBuf (because of the 
                addition of end of line characters).  For hexencoding
                this function assumes the outBuf is well over 2X the
                size of the inBuf!!!!  Hexencoding is selected by
                setting eexecOpt = ST_ENCRYPTHEX.

Parameters:     inBuf -- the input data
                outBuf -- the output data
                inLen -- the number of bytes of input data
                outLen -- the number of bytes of output data
                KeyP -- the updated eexec key
                eexecOpt -- the type of eexec encryption.  It should
                    be either ST_ENCRYPT or ST_ENCRYPTHEX.

Return Values:  none (data is returned in outBuf)
Notes:		Charstrings and subrs use the same key (and key bytes)
                for each string (both subrs and charstrings).  Consult 
                "Adobe Type 1 Font Format" (the black book) for more
                information about using this function.
See also:

**************************************************************************/

PUBLIC void BufferEncrypt ARGDECL6(Card8 *, inBuf, Card8 *, outBuf,
              Int32, inLen , Int32 *, outLen, Card16 *, KeyP, Card8, eexecOpt);


/*************************************************************************

Function name:  StreamCompleteFont()

**************************************************************************

Date:           05/23/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream the complete font, including any generic PostScript
Description:    This routine streams a font file allowing the user to
                modify a couple fields.  It is used because often fonts
                contain "generic" PostScript which is not recognized by the
                parser but needs to passed through (for printers, perhaps).
                Fields the user can change include: subrs, charstrings,
                encoding, uid, font name, full name, and encryption.

Parameters:     fp -- the font pointer containing the info on the font.
                s -- the streamer options.
                charOpts -- the charstring options.
                b - the initial buffer status.
                fi - the faux font options (not actually used here).
                GetBytes - the callback used to get the font data.
Return Values:
Notes:          This routine is used as a 2nd pass through the data.  It
                is assumed that the first pass gathered the data into fp.
                An attempt was made to write this is such a fashion that
                a 1 pass version could be created.  Such a version would
                have complex buffering issues to handle.
See also:

**************************************************************************/

PUBLIC IntX StreamCompleteFont ARGDECL6(T1FontPointer, fp, PStreamerOpts, s,
       CharStrOpts *, charOpts, PBufferStatus, b, FauxInfoPointer, fi,
       GetBytesFunc, GetBytes);


/*************************************************************************

Function name:  StreamChars()

**************************************************************************

Date:           05/23/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream the characters in a font
Description:    This is a standalone function to stream the characters in
                a font.  It uses the GetCharString() callback to get the
                charstrings from a user, then StreamCharString() to process
                the charstring.

Parameters:     fp - the font record
                charOpts - the character options to use
                s - the streamer options to use
                b - the current buffer status
                fi - the faux font options
Return Values:  standard ST_ errors
Notes:
See also:       StreamCharString()

**************************************************************************/


PUBLIC IntX StreamChars ARGDECL5(T1FontPointer, fp, CharStrOpts *, charOpts,
              PStreamerOpts, s, PBufferStatus, b, FauxInfoPointer, fi);


/*************************************************************************

Function name:  StreamEEXEC()

**************************************************************************

Date:           05/26/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        stream the encryption info and set the buffer's flags
Description:    Stream the encryption info and set the buffer's flags

Parameters:    s - the streamer options (one of which is encryption)

Return Values:  standard ST_ errs
Notes:
See also:

**************************************************************************/

PUBLIC IntX StreamEEXEC ARGDECL1(PStreamerOpts, s);


/*************************************************************************

Function name:  StreamEncoding()

**************************************************************************
Date:           05/26/94 Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream the encoding info for a font.
Description:    Most fonts just have standard encoding, but symbol fonts (and others) have special encodings.  This routine will output either type.  The special encoding is taken from
                the array fp->specialEncoding.

Parameters:     fp - the font record
                hasStandardEncoding - a flag indicating the font is standard.

Return Values:  ST_ errors
Notes:
See also:

**************************************************************************/

PUBLIC IntX StreamEncoding  ARGDECL2(T1FontPointer, fp,
                                     Card8, hasStandardEncoding);


/*************************************************************************

Function name:  CheckForSeac()

**************************************************************************

Date:           06/14/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Check charstrings to find SEAC base and accent characters.
Description:    Performs a fast check of charstrings to determine if they
                are SEAC charstrings, and if they are, what the base
                and accent characters are (in the CharStrOpts struct).
                As soon as the loop determines that the charstring cannot
                be for a SEAC character it returns.

Parameters:     DataP - the charstring to examine
                Length - the length of the charstring.
                fp - the pointer to the Font Information record
                opts - the charstring options
Return Values:  standard ST values
Notes:
See also:

**************************************************************************/

PUBLIC IntX CheckForSEAC ARGDECL4(Card8 *, DataP, Int32, Length,
  T1FontPointer, fp, CharStrOpts *, opts);

#endif /* STREAMER_H */

