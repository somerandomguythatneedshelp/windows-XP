/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: TTFONTS.H                                              */
/*                                                                           */
/* Description: This include contains the structures and prototypes          */
/*              for the new type42 incremental and widefont support          */
/*                                                                           */
/*****************************************************************************/

typedef struct tagType42Header 
{
  DWORD tableVersionNumber;
  DWORD fontRevision;
  DWORD checkSumAdjustment;
  DWORD magicNumber;
  int   flags;
  unsigned int unitsPerEm;
  char timeCreated[8];
  char timeModified[8];
  WORD  xMin;
  WORD  yMin;
  WORD  xMax;
  WORD  yMax;
  int macStyle;
  int lowestRecPPEM;
  int fontDirectionHint;
  int indexToLocFormat;
  int glyfDataFormat;
} TYPE42HEADER, FAR *LPTYPE42HEADER;

#define MACSTYLE_BOLD_PRESENT 0x01
#define MACSTYLE_ITALIC_PRESENT 0x02

typedef struct tagNameHeader
{
  int FormatSelector;
  int RecordNumber;
  int StringOffsets;
} NAMEHEADER, FAR *LPNAMEHEADER;

typedef struct tagNameRecord
{
  int PlatformID;
  int EncodingID;
  int LanguageID;
  int NameID;
  int StrLen;
  int StrOffset;
} NAMERECORD, FAR *LPNAMERECORD;

typedef struct tagTABLEDIRECTORY
{
  DWORD version;
  unsigned numTables;
  unsigned searchRange;
  unsigned entrySelector;
  unsigned rangeshift;
} TABLEDIRECTORY, FAR *LPTABLEDIRECTORY;

typedef struct tagTABLEENTRY
{
  DWORD tag;
  DWORD checkSum;
  DWORD offset;
  DWORD length;
} TABLEENTRY, FAR *LPTABLEENTRY;

typedef struct tagCMAPHEADER
{
  unsigned version;
  unsigned numTables;
} CMAPHEADER, FAR *LPCMAPHEADER;

typedef struct tagCMAPTABLEDIRECTORY
{
  unsigned platformID;
  unsigned encoding;
  DWORD offset;
} CMAPTABLEDIRECTORY, FAR *LPCMAPTABLEDIRECTORY;

typedef struct tagCMAPUGLENCODING
{
  unsigned format;
  unsigned length;
  unsigned version;
  unsigned segCountX2;
  unsigned searchRange;
  unsigned entrySelector;
  unsigned rangeShift;
} CMAPUGLENCODING, FAR *LPCMAPUGLENCODING;

typedef struct tagCMAPCONTINUOUSENCODING
{
  unsigned format;
  unsigned length;
  unsigned version;
  BYTE     glyphIDArray[256];
} CMAPCONTINUOUSENCODING, FAR *LPCMAPCONTINUOUSENCODING;

typedef struct tagMAXPTABLE
{
  DWORD  tableVersionNumber;
  int    numGlyphs;
  int    maxPoints;
  int    maxContours;
  int    maxCompositePoints;
  int    maxCompositeContours;
  int    maxZones;
  int    maxTwilightPoints;
  int    maxStorage;
  int    maxFunctionDefs;
  int    maxInstructionDefs;
  int    maxStackElements;
  int    maxSizeOfInstructions;
  int    maxComponentElements;
  int    maxComponentDepth;
} MAXPTABLE, FAR *LPMAXPTABLE;


#define NUM_16KSTR    640
   // NUM_16KSTR*16K=640*16K = 10MByte
typedef struct tagTTFINFO
{
//   BYTE lfFaceName[FONTNAMESIZE];
   int   numGlyphs;

   DWORD headOffset;
   LPTYPE42HEADER lpHeadTable;
   int   longGlyfs;

   DWORD locaOffset;
   DWORD locaSize;
   void huge *lpLocaTable;

   DWORD glyfOffset;
   DWORD glyfSize;
   BYTE huge *lpGlyfTable;
   DWORD stringLength[NUM_16KSTR];   // NUM_16KSTR*16K=640*16K = 10MBytes. For a CJK font, 10MB is likely enough. 
       // It is OK to put such a humongous array in this struct since this
       // structure is really used inside a GlobalAllocated structure - in ttfonts.c.
   int nOtherTables;
} TTFINFO, FAR *LPTTFINFO;


/* NOTE: These must be used with valid variables or memory addresses (4 bytes or 2 bytes).
   No constants are allowed! */
#define MOTOROLALONG(a) (unsigned long)(((unsigned long)*((unsigned char *) &a) << 24) + \
                        ((unsigned long)*(((unsigned char *) &a) + 1) << 16) + \
                        ((unsigned long)*(((unsigned char *) &a) + 2) << 8)  + \
                        *(((unsigned char *)  &a) + 3) )

#define MOTOROLAINT(a)  (unsigned short)( ((unsigned short)*((unsigned char *)&a) << 8 ) + \
                                 (unsigned short)*(((unsigned char *)&a) + 1))

#define LOCA_TABLE  (DWORD)(0x61636F6C)  /* *(LPDWORD)"loca" - this one is special*/
#define GLYF_TABLE  (DWORD)(0x66796C67)  /* *(LPDWORD)"glyf" - this one is also special*/
#define VHEA_TABLE  (DWORD)(0x61656876) 
#define VMTX_TABLE  (DWORD)(0x78746d76)
#define HEAD_TABLE  (DWORD)(0x64616568)            //*(LPDWORD)"head",
#define OS2_TABLE  (DWORD)(0x322F534F)  /* *(LPDWORD)"OS/2" - this one is also special*/


#define TYPE42NAME_PS             6
#define TYPE42PLATFORM_WINDOWS    3
#define TYPE42ENCODING_UGL        4
#define TYPE42ENCODING_NONUGL     0
#define TYPE42ENCODING_CONTINUOUS 0


// for Composite Characters
#define MINUS_ONE                -1
#define ARG_1_AND_2_ARE_WORDS    0x0001
#define ARGS_ARE_XY_VALUES       0x0002
#define ROUND_XY_TO_GRID         0x0004
#define WE_HAVE_A_SCALE          0x0008
#define MORE_COMPONENTS          0x0020
#define WE_HAVE_AN_X_AND_Y_SCALE 0x0040
#define WE_HAVE_A_TWO_BY_TWO     0x0080
#define WE_HAVE_INSTRUCTIONS     0x0100
#define USE_MY_METRICS           0x0200


PSERROR FAR PASCAL TTDownLoadT42(LPPDEVICE lppd, LPPSFONTINFO lpFontInfo,
                              LPFONTDATARECORD lpFontDataRecord, BOOL bFullFont);

// for TrueImage
PSERROR FAR PASCAL TTDownLoadTTFont(LPPDEVICE lppd, LPPSFONTINFO FontInfo, BOOL bFullFont);



// for Type42 incremental downloading
int FAR PASCAL TTUpdateT42(LPPDEVICE lppd, LPPSFONTINFO lpFontInfo, 
                           LPFONTDATARECORD lpFontDataRecord, LPSTR lpStr, int cb);

int FAR PASCAL GetPSVersion(LPPDEVICE lppd);

DWORD FAR PASCAL GetTableDirectory(HDC hDC, LPTABLEDIRECTORY lpTableDir);
DWORD FAR PASCAL GetTableEntry(HDC hDC, LPTABLEENTRY lpTableEntry, LPTABLEDIRECTORY lpTableDir);
DWORD FAR PASCAL GetTableHDC(HDC hdc, DWORD tableName, BYTE huge *lpTable);
BOOL FAR PASCAL MakeXUIDVector (LPPDEVICE lppd,
                                LPLOGFONT lpLogFont, 
                                LPFONTDATARECORD lpFontDataRec, 
                                LPPSFONTINFO FontInfo);
DWORD FAR PASCAL GetTableCheckSum(LPTABLEDIRECTORY lpTableDir, LPTABLEENTRY lpTableEntry, DWORD tableName);

WORD FAR PASCAL GetOIDGlyphIndexDirect(LPPDEVICE lppd, LPFONTDATARECORD lpFontDataRecord,
           int oid, LPLOGFONT lplf, BOOL bEUDC);
