
typedef  struct  tagWPXNODE
{
   struct  tagWPXNODE  FAR  *  NextNode ;
   BYTE    modelname[60] ;       //  save alias name
   WORD    RefCount ;
   BOOL    deleteWhenRefCountZero ;
   WPXBLOCKS  WPXblock ;
}  WPXNODE, FAR *  LPWPXNODE ;



// Prototypes for functions in wpxinfo.c

BOOL FAR PASCAL GetFileModTimes(
LPBYTE lpPPDFile,
LPDWORD lpdwTime);

BOOL FAR PASCAL FreeWPXblocks(LPWPXBLOCKS lpWpx);

BOOL NEAR UTILSSEG PASCAL GetThisPrinter(
LPWPXBLOCKS  lpWPXblocks ,   // caller supplies 
LPBYTE  lpModelName) ;  // caller supplies 

BOOL FAR PASCAL FreePrinter(LPWPXBLOCKS lpWpx) ;

LPWPXBLOCKS  FAR PASCAL GetPrinter(
LPBYTE  lpModelName ) ;

BOOL FAR PASCAL TerminateWPXcache() ;
void FAR PASCAL SetWPXDeleteFlag(LPSTR);
