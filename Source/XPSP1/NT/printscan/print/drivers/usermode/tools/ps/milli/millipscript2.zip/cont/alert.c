/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1994 Adobe Systems, Inc. All rights reserved.               */
/*                                                                           */
/* Module Name: ALERT.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for  the incompatibility */
/*		alert dialog warning users of ESCAPEOPENCHANNEL and 	    */
/*		EPSPRINTING apps that Nup and watermarks may not work        */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include <toolhelp.h>
#include <ver.h>

#pragma code_seg(_ESCAPESSEG)

// Next function is defined in TRAN\theader.c:
BOOL FAR PASCAL GetKeyVal(HKEY hv, LPSTR path_key, LPSTR val_key, LPSTR buffer, long *cl);

// Next two are used in DMG\advanced.c
int FAR PASCAL GetShowAlert(void);
int FAR PASCAL SetShowAlert(int);

// Two locally used functions
int FAR PASCAL ProdVersionStr(LPSTR szExeName, LPSTR szExeVer);
int FAR PASCAL ModuleAndExeName(LPPDEVICE lppd, HTASK hTask, LPSTR szModuleName, LPSTR szExeName);
BOOL _loadds FAR PASCAL ConfirmWM_NUPDlgFunc(HWND,UINT,WPARAM,LPARAM);

// Return 0=abort. Otherwise=continue
GetWM_NUP_Confirmation(LPPDEVICE lppd)
{
LPPSDEVMODE psdm = (LPPSDEVMODE)&lppd->lpPSExtDevmode->dm;
int rc = 1;
HTASK hCurrTask;
char moduleName[10], tmpbuf[256], verStr[20];
char path_List[80];  // path to Compatible and Incompatible Lists
long  cb, ret;
int   show_alert=1;
int   bad_app=0;     // assumed innocent
char  path_AdobeDrv[128];
char  current_Key[64];

	/* Check if a watermark or nup feature exists */
	if ((!psdm->dwWatermarkID || (psdm->enumDialect == DIA_EPS)) 
       && (psdm->layout == ONE_UP)
       && (psdm->PaperOrient != OR_LANDSCAPE) 
       && !(psdm->bMirror) 
       && !(psdm->bNegImage)
       && (psdm->Scale == 100)
       && (psdm->useDefaultHalftoneParams)){
        show_alert=0;
        goto END_CHECK;
	   }

    // First See if we want the alert dialog be shown:
    show_alert = GetShowAlert();

    // Now check if the current app is Good or Bad. For Bad apps, we disable Nup/WM use registry
	moduleName[0]='\0'; tmpbuf[0]='\0'; verStr[0]='\0'; // initial to NULL;
    hCurrTask = GetCurrentTask(); // This must be the current Application calling us.
    ModuleAndExeName(lppd, hCurrTask, (LPSTR)moduleName, (LPSTR)tmpbuf); //borrow tmpbuf here
    ProdVersionStr((LPSTR)tmpbuf, (LPSTR)verStr);  // Version string 

    // Check if the current app is on the InCompatible List:
    bad_app=0;  // assumed GOOD for all Normal GDI Apps
    CompositeString(ghDriverMod, IDS_REGSTR_PATH_INCOMPAT_APPS, IDS_DRIVER_MANUFACTURER, 
                  0, (LPSTR) path_List, (WORD) sizeof(path_List));
    tmpbuf[0]='\0'; // initialize.

    cb = sizeof(tmpbuf);
    ret=GetKeyVal(HKEY_LOCAL_MACHINE, (LPSTR)path_List, (LPSTR)moduleName, (LPSTR)tmpbuf, &cb);
    if (ret==TRUE){
       if (tmpbuf[0]=='\0') {
          // all versions are covered
          bad_app=1;  // on Incompatible list - BAD
          }
       else if (lstrcmpi(verStr, tmpbuf)<=0){
          // tmpbuf is Maximal Incompatible Version
          bad_app=1;  // on Incompatible list - BAD
	     }
      }

END_CHECK:
   if (show_alert==0) rc=1;  // continue without showing In-compat Alert dialog

   if (show_alert==1){ 
       if(bad_app==1){
	   /* ... seek confirmation */
		switch(ConfirmWM_NUP(lppd))
		  {
		   case 0:	/* Continue with feature */
			lppd->disableWMark = 0;
			lppd->disableNUP = 0;
			break;

		   case 1:   /* Suppress feature */
			lppd->disableWMark = 1;
			lppd->disableNUP = 1;
         lppd->lpPSExtDevmode->dm.PaperOrient= OR_PORTRAIT;
         lppd->lpPSExtDevmode->dm.bMirror    = FALSE;
         lppd->lpPSExtDevmode->dm.bNegImage  = FALSE;
         lppd->lpPSExtDevmode->dm.Scale      = 100;
         lppd->lpPSExtDevmode->dm.useDefaultHalftoneParams = TRUE;
			break;

		   case 2:	/* Abort */
			rc = 0;
			break;
		  }
	    }
	 } // show==1
   else{
     if (bad_app==1){ 
       // only do this for bad apps -- Matt says this is the way. 6-19-95
       // If we don't show alert dialog, we still have a way to disable/enable them:
      CompositeString(ghDriverMod, IDS_REGSTR_PATH_ADOBEPS, IDS_DRIVER_MANUFACTURER, 
                  0, (LPSTR) path_AdobeDrv, (WORD) sizeof (path_AdobeDrv));
       LoadString(ghDriverMod, IDS_REGSTR_VAL_DISABLE_NUP, current_Key, sizeof(current_Key));
       tmpbuf[0]='\0'; 
       cb = sizeof(tmpbuf);
       ret=GetKeyVal(HKEY_LOCAL_MACHINE, (LPSTR)path_AdobeDrv, (LPSTR)current_Key, tmpbuf, &cb);
       if (lstrlen(tmpbuf)){
	      if (lstrcmp(tmpbuf,"0")==0) lppd->disableNUP = 0;
	      else lppd->disableNUP = 1;
	      }

       LoadString(ghDriverMod, IDS_REGSTR_VAL_DISABLE_WM, current_Key, sizeof(current_Key));
       tmpbuf[0]='\0'; // initialize. borrow this buffer here
       cb = sizeof(tmpbuf);
       ret=GetKeyVal(HKEY_LOCAL_MACHINE, (LPSTR)path_AdobeDrv, (LPSTR)current_Key, tmpbuf, &cb);
       if (lstrlen(tmpbuf)){
	      if (lstrcmp(tmpbuf,"0")==0) lppd->disableWMark = 0;
	      else lppd->disableWMark = 1;
	      }
       } //use registry if don't show alert for BAD APPS only.
     }  // end else - 

	return rc;
}


ConfirmWM_NUP(LPPDEVICE lppd)
{
int rc;
	rc=DialogBoxParam(ghDriverMod, (LPSTR)"CONFIRM_WM_NUPDLG",
			 GetActiveWindow(), 
			 ConfirmWM_NUPDlgFunc, (LPARAM) lppd);
    return rc;
}

BOOL _loadds FAR PASCAL ConfirmWM_NUPDlgFunc(HWND hDlg, UINT imsg, 
					     WPARAM wParam, LPARAM lParam)
{
    BOOL           result = TRUE ;
    LPPDEVICE      lppd;
    char alertval;
    int retval;
    
    /* Process hook function stuff */
    if(lppd=(LPPDEVICE)GetWindowLong(hDlg,DWL_USER))
    {
#ifdef USEHOOKPROC
        if(DrvProcessHookProc(lppd,hDlg,imsg,wParam,lParam,
                              "HookSetup"))
        {
            return TRUE;
        }
#endif
    }
    
    switch (imsg)
    {
        case WM_INITDIALOG:
            lppd=(LPPDEVICE)lParam;
            SetWindowLong(hDlg,DWL_USER,(LPARAM)lppd);
	         CheckRadioButton(hDlg,ID_ALERT_TRY,ID_ALERT_ABORT,ID_ALERT_TRY);
            break ;

        case WM_CONTEXTMENU:
            if (wParam != -1)
            {
                WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                        (DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_HELP:
            if (((LPHELPINFO) lParam)->hItemHandle != -1)
            {
                WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                        HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
            }
            break;
            
        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
		    alertval = 0;  //default
		    if (IsDlgButtonChecked(hDlg, ID_ALERT_TRY)) 
                retval = 0;
		    else if (IsDlgButtonChecked(hDlg, ID_ALERT_PRINT))
		    	retval = 1;
		    else if (IsDlgButtonChecked(hDlg, ID_ALERT_ABORT))
		    	retval = 2;

		    EndDialog(hDlg, retval);
                    break;
                    
                default:
                    result = FALSE ;
                    break ;
            } /* switch(wParam) */
            break ;
            
        default:
            result = FALSE ;
            break ;
    } /* switch(imsg) */
    
    return result ;
}

// Functions to read/write Registry: they are also used in DMG\advanced.c
int FAR PASCAL GetShowAlert(){
char  tmpbuf[256];
long  cb, ret;
int   show_alert = DEFAULT_SHOW_ALERT;
char  path_AdobeDrv[128];
char  current_Key[64];

    CompositeString(ghDriverMod, IDS_REGSTR_PATH_ADOBEPS, IDS_DRIVER_MANUFACTURER, 
                  0, (LPSTR) path_AdobeDrv, (WORD) sizeof (path_AdobeDrv));
    LoadString(ghDriverMod, IDS_REGSTR_VAL_SHOW_ALERT, current_Key, sizeof(current_Key));
    tmpbuf[0]='\0'; // initialize. 
    // read from registry
    cb = sizeof(tmpbuf);
    ret=GetKeyVal(HKEY_LOCAL_MACHINE, (LPSTR)path_AdobeDrv, (LPSTR)current_Key, tmpbuf, &cb);

 	if (lstrlen(tmpbuf))
	{
	    if (lstrcmp(tmpbuf,"0")==0) show_alert=0;  // don't show
	    else show_alert=1;   // show if other than 0;
	}

   return show_alert;
}

int FAR PASCAL SetShowAlert(int alertval){
    HKEY  hKey;
    long  cb, ret;
    char  path_AdobeDrv[128];
    char  current_Key[64];
    char  alertstr[10];  // an integer

       // Save show/no-show inf in registry:
      CompositeString(ghDriverMod, IDS_REGSTR_PATH_ADOBEPS, IDS_DRIVER_MANUFACTURER, 
                  0, (LPSTR) path_AdobeDrv, (WORD) sizeof (path_AdobeDrv));
       LoadString(ghDriverMod, IDS_REGSTR_VAL_SHOW_ALERT, current_Key, sizeof(current_Key));
       wsprintf(alertstr,"%d", alertval);

       ret=RegCreateKey(HKEY_LOCAL_MACHINE, (LPSTR)path_AdobeDrv, &hKey);
       if (ret==ERROR_SUCCESS){
          cb = lstrlen(alertstr)+1;  // including Null terminator
          ret = RegSetValueEx(hKey, (LPSTR)current_Key, 0, REG_SZ, (LPBYTE)alertstr, cb);
          RegCloseKey(hKey);
          }
    return 1;
}



// Functions to find out current task's name and its version
int FAR PASCAL ModuleAndExeName(LPPDEVICE lppd, HTASK hTask, LPSTR szModuleName, LPSTR szExeName)
{
	TASKENTRY FAR* lpTask;
	MODULEENTRY FAR *lpMod;
	HANDLE hlpTask, hlpMod;
	HINSTANCE hToolDll;
	typedef BOOL (WINAPI * FPTFH)(TASKENTRY FAR*, HTASK);
	typedef BOOL (WINAPI * FPMFH)(MODULEENTRY FAR*, HMODULE);
	static FPTFH fp_TaskFindHandle=NULL;
	static FPMFH fp_ModuleFindHandle=NULL;
	int retval;

    retval=0;
     hToolDll = LoadLibrary("Toolhelp.DLL");
 	 if ((UINT) hToolDll > HINSTANCE_ERROR)
	    {    /* Grab the proc if one exists */
		lpTask = (TASKENTRY FAR*) MGAllocLock(lppd, (LPHANDLE) &hlpTask,
			   (DWORD)sizeof(TASKENTRY), GHND, TRUE);
		lpMod = (MODULEENTRY FAR*) MGAllocLock(lppd, (LPHANDLE) &hlpMod,
			   (DWORD)sizeof(MODULEENTRY), GHND, TRUE);
		fp_TaskFindHandle  = (FPTFH)GetProcAddress(hToolDll, "TaskFindHandle");
		fp_ModuleFindHandle= (FPMFH)GetProcAddress(hToolDll, "ModuleFindHandle");
	     }
	 if ((UINT) hToolDll > HINSTANCE_ERROR &&
			fp_TaskFindHandle != NULL && lpTask!=NULL)
	    {
	    lpTask->dwSize = (DWORD) sizeof(TASKENTRY);
		// lpTask->hTask = hTask;
		lpTask->szModule[0]=0; // initial to NULL;
		(*fp_TaskFindHandle)(lpTask, hTask); // fill the task stucture
		lstrcpy((LPSTR)szModuleName, (LPSTR)(lpTask->szModule));
		retval=1;
		}

     // Special case:
     if (szModuleName==NULL || szModuleName[0]==0) return 0;  // means no module name is found

	 if ((UINT) hToolDll > HINSTANCE_ERROR &&
			fp_ModuleFindHandle != NULL && lpMod!=NULL)
		{
	    lpMod->dwSize = (DWORD) sizeof(MODULEENTRY);
		lpMod->szExePath[0]=0; // initial to NULL;
		(*fp_ModuleFindHandle)(lpMod, lpTask->hModule); // fill the module stucture
		lstrcpy((LPSTR)szExeName, (LPSTR)(lpMod->szExePath));
		retval=2;
		}

	if ((UINT) hToolDll > HINSTANCE_ERROR) FreeLibrary(hToolDll);
	if (hlpTask!=NULL) {MGUnlockFree(lppd, hlpTask, TRUE); }
	if (hlpMod!=NULL) {MGUnlockFree(lppd, hlpMod, TRUE); }
    return (retval);
 }


// 0: means no versioninfo is found. 1== means found a verison str.
int FAR PASCAL ProdVersionStr(LPSTR szExeName, LPSTR szExeVer)
{
    DWORD   handle, dwSize;
    LPBYTE  lpBuffer;
    char    szName[512];
    BOOL    retCode = 0;
    LPSTR   lpstrVffInfo;
    HANDLE  hMem;

    #define MAX_ANSWER_LEN  50
    static  char  verQueryAnswer[MAX_ANSWER_LEN];

    // Special case:
    if (szExeName==NULL || szExeName[0]==0) 
        return 0;                       // means no versioninfo is available.

    *verQueryAnswer = 0;                               // set defaul to ""
    
	// Get its Version:
    dwSize = GetFileVersionInfoSize(szExeName, (DWORD FAR *)&handle);
    if (dwSize > 0) {
	   hMem = GlobalAlloc(GMEM_MOVEABLE, dwSize);
	   if (!hMem) 
            return 0;                   // means no versioninfo is available.
	   lpstrVffInfo  = (LPSTR) GlobalLock(hMem);
       GetFileVersionInfo((LPSTR)szExeName, handle, dwSize, lpstrVffInfo);

       // We are searching hard-coded "040904E4" == Ansi block !!
	   lstrcpy ((LPSTR)szName, (LPSTR)"\\StringFileInfo\\040904E4\\");
	   lstrcat ((LPSTR)szName, (LPSTR)"ProductVersion");
	   retCode = VerQueryValue((LPVOID)lpstrVffInfo, (LPSTR)szName, 
                (void FAR* FAR*) &lpBuffer, (UINT FAR *) &dwSize);
       if (retCode)
            lstrcpy(szExeVer, (LPSTR)lpBuffer);
	   
       GlobalUnlock(hMem);
       GlobalFree(hMem);
     }
     return(retCode);  // 1 if version is found.
}


