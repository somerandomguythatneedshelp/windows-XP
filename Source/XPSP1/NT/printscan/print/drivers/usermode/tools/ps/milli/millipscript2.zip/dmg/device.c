/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DEVICE.C                                                     */
/*                                                                           */
/* Description: This module contains the functions for the Device            */
/*              Options Dialog                                               */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "spin.h"
#include "apd42map.hh"

#pragma code_seg(_DIALOGSSEG)

#define UPDATE_AVAILVM            0x0001
#define UPDATE_DOCSTICKY          0x0002
#define UPDATE_PRNTRSTICKY        0x0004
#define UPDATE_AVAILFCACHE        0x0008
#define UPDATE_ALL                0xFFFF
#define UPDATE_NONUICONSTRAINED   UPDATE_AVAILVM | UPDATE_AVAILFCACHE
#define UPDATE_UICONSTRAINED      UPDATE_DOCSTICKY | UPDATE_PRNTRSTICKY

#define TAB_POS                   90

FARPROC EditWndProc;
LRESULT _loadds FAR PASCAL PrinterVMDlg(HWND hDlg,
                                    unsigned imsg,
                                    WORD wParam,
                                    LONG lParam);

/*****************************************************************************/
/*                 InitDeviceDlg                                             */
/* Purpose:                                                                  */
/*   This function removes unnecessary controls from the dialog, and         */
/*   repositions the remaining controls so that intervening spaces are       */
/*   removed.                                                                */
/*                                                                           */
/* Parameters:                                                               */
/*   hDlg -- Handle to device dialog                                         */
/*   lpDrvInfo -- Points to DRIVERINFO structure                             */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

void NEAR PASCAL InitDeviceDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    DWORD dwUIFlags = lpDrvInfo->dwUIFlags[DI_DEVICE];
    int   yOffset = 0, y;

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_AVAILVM,
                     ID_TEXT_PRINTER_VM, ID_PRINTER_VM_SPN,
                     ID_TEXT_PRINTER_FONTCACHE);

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_AVAILFCACHE,
                     ID_TEXT_PRINTER_FONTCACHE, ID_PRINTER_FONTCACHE_SPN,
                     ID_PRINTER_FEATURES);

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_PRINTERFTRS,
                     ID_PRINTER_FEATURES, ID_PRINTER_FEATURES,
                     ID_INSTALLABLE_OPTIONS);

    y = yOffset;
    PositionControls(hDlg, NULL, (LPINT)&y, dwUIFlags&DI_PRINTERFTRS,
                     ID_DEVICE_LISTBOX, ID_ACTIVE_ITEM_VALUE,
                     ID_INSTALLABLE_OPTIONS);

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_IOPTIONS,
                     ID_INSTALLABLE_OPTIONS, ID_DEV_I_OPT_ACTIVE_ITEM_VALUE,
                     NULL);

    lpDrvInfo->iDocStickyIndex = lpDrvInfo->iPrinterStickyIndex = 0;
}


/*****************************************************************************/
/*                 AddItemToListBox                                          */
/* Purpose:                                                                  */
/*   This function, given a keyword, builds a string with the translation    */
/*   string of the keyword and its current option (separated by a TAB), and  */
/*   adds the string to the control specified by "ictrlID" at index "wIndex" */
/*   It actually uses the flag iAddType to add the string, and hence this    */
/*   function can be called for adding a string as well as inserting a       */
/*   string to a list box.                                                   */
/*                                                                           */
/* Parameters:                                                               */
/*   lppd -- Pointer to the PDEVICE structure.                               */
/*   hDlg -- Handle to device dialog                                         */
/*   ictrlID -- Control ID of the list box                                   */
/*   keyword -- Index of main keyword whose name and option are to be added  */
/*   iAddType -- Specifies parameter to SendDlgItemMessage                   */
/*   wIndex -- Index at which to add string. For LB_ADDSTRING it should be 0 */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

void NEAR PASCAL AddItemToListBox(LPPDEVICE lppd,
                                  HWND hDlg,
                                  int ictrlID,
                                  int keyword,
                                  int iAddType,
                                  WORD wIndex)
{
    int   option;
    char  desc[MAX_TR_STRING_LEN];
    char  buffer[MAX_TR_STRING_LEN * 2];

    KeywordGetKeywordTranslation(lppd, keyword, buffer, sizeof(buffer));

    TruncateToTabStop(hDlg, buffer, TAB_POS);
    lstrcat(buffer, "\t");

    // Get current option translation string
    KeywordGetCurrentOption(lppd, keyword, (LPWORD)&option);
    KeywordGetOptionTranslation(lppd, keyword, option, desc,
                                sizeof(desc));

    /* Set the option */
    lstrcat(buffer, desc);

    SendDlgItemMessage(hDlg, ictrlID, iAddType, wIndex,
                       (LPARAM)(LPCSTR)buffer);
}


/*****************************************************************************/
/*                 ShowActiveLabel                                           */
/* Purpose:                                                                  */
/*   This function, given a keyword, sets the control "iIDActiveItem" to     */
/*   the translation string of that keyword, build the combo box "ictrlID"   */
/*   with options for that keyword, and selects the current option.          */
/*                                                                           */
/* Parameters:                                                               */
/*   lpDrvInfo -- Points to DRIVERINFO structure                             */
/*   hDlg -- Handle to device dialog                                         */
/*   keyword -- Index of main keyword whose name and option are to be added  */
/*   iIDActiveItem -- Control ID whose text should be the active keyword     */
/*   ictrlID -- Control ID of the combo box associated with the current item */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

void NEAR PASCAL ShowActiveLabel(LPDRIVERINFO lpDrvInfo,
                                 HWND hDlg,
                                 int keyword,
                                 int iIDActiveItem,
                                 int ictrlID)
{
    LPPRINTERINFO lpPrinterInfo;
    LPMAINKEYHDR  lpCurMainKeyHdr ;
    int           option;
    char          desc[MAX_TR_STRING_LEN];
    BOOL          bSingleSelection = TRUE;

    KeywordGetKeywordTranslation(&lpDrvInfo->pDev, keyword, desc, sizeof(desc));
    SetDlgItemText(hDlg, iIDActiveItem, desc);

    lpPrinterInfo = (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + keyword;
//    bSingleSelection = (lpCurMainKeyHdr->UItype != PICKMANY);

    /* Redraw the active item's combo box */
    if (bSingleSelection)
    {
        BuildCBOptList(lpDrvInfo, hDlg, keyword, ictrlID);
    }
    ShowWindow(GetDlgItem(hDlg, ictrlID),
               bSingleSelection ? SW_SHOWNA : SW_HIDE);
    ShowWindow(GetDlgItem(hDlg, ictrlID + 1),
               bSingleSelection ? SW_HIDE : SW_SHOWNA);

//    ReSizeComboBox(hDlg, ictrlID);
    KeywordGetCurrentOption(&lpDrvInfo->pDev, keyword, (LPWORD)&option);
    SendDlgItemMessage(hDlg, ictrlID, CB_SETCURSEL, option, MAKELONG(0,-1));
}


/*****************************************************************************/
/*                          BuildPublicPPDItemsList                          */
/* Purpose::                                                                 */
/*   This functions builds the list boxes for document sticky and printer    */
/*   options.                                                                */
/*                                                                           */
/* Parameters:                                                               */
/*   lpDrvInfo -- Points to DRIVERINFO structure                             */
/*   hDlg -- Handle  to the dialog box                                       */
/*   iPublicType -- Type of public PPD (either Printer or Doc sticky)        */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

VOID NEAR PASCAL BuildPublicPPDItemsList(LPDRIVERINFO lpDrvInfo,
                                         HWND hDlg,
                                         int iPublicType)
{
    LPPRINTERINFO lpPrinterInfo;
    LPPDEVICE     lppd = &lpDrvInfo->pDev;
    int           i, iBaseIndex, iLength, iNumOpts, iTabPos;
    int           iIDListBox, iIDActiveItem, iIDValue;

    lpPrinterInfo = (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);

    /* Determine what do to by type */
    if (iPublicType == ID_DEV_PRINTER_STICKY)
    {
        /* Printer Sticky */
        iBaseIndex = lpPrinterInfo->PrinterSticky.w.offset;
        iLength    = lpPrinterInfo->PrinterSticky.w.length;
        iIDListBox    = ID_DEV_I_OPT_LISTBOX;
        iIDActiveItem = ID_DEV_I_OPT_ACTIVE_ITEM;
        iIDValue      = ID_DEV_I_OPT_ACTIVE_ITEM_VALUE;
    }
    else
    {
        /* Document Sticky */
        iBaseIndex = lpPrinterInfo->DocSticky.w.offset;
        iLength    = lpPrinterInfo->DocSticky.w.length;
        iIDListBox    = ID_DEVICE_LISTBOX;
        iIDActiveItem = ID_ACTIVE_ITEM;
        iIDValue      = ID_ACTIVE_ITEM_VALUE;
    }

    /* Disable Redraw */
    SendDlgItemMessage(hDlg, iIDListBox, WM_SETREDRAW, (WPARAM)FALSE, 0L);

    /* Clear out the list box */
    SendDlgItemMessage(hDlg, iIDListBox, LB_RESETCONTENT, 0, 0L);

    /* Set tab stop in middle */
    iTabPos = TAB_POS;
    SendDlgItemMessage(hDlg, iIDListBox, LB_SETTABSTOPS, (WPARAM)1,
                       (LPARAM)(int FAR *)&iTabPos);

    for (i=0; i<iLength; i++)
    {
        AddItemToListBox(lppd, hDlg, iIDListBox, iBaseIndex+i,
                         LB_ADDSTRING, 0);
    }

    /* Special case to handle Installable Memory */
    if (iPublicType == ID_DEV_PRINTER_STICKY)
    {
        KeywordGetNumOfOptions(&lpDrvInfo->pDev, IND_MEMORYINFO,
                               (LPWORD)&iNumOpts);
        if (iNumOpts > 0)
        {
            AddItemToListBox(lppd, hDlg, iIDListBox, IND_MEMORYINFO,
                             LB_ADDSTRING, 0);
        }
    }

    /* Enable Redraw */
    SendDlgItemMessage(hDlg, iIDListBox, WM_SETREDRAW, (WPARAM)TRUE, 0L);
}


/*****************************************************************************/
/*                 BuildDeviceDlg                                            */
/* Purpose:                                                                  */
/*   This function builds different elements of the device dialog, depending */
/*   on "buildFlags".                                                        */
/*                                                                           */
/* Parameters:                                                               */
/*   hDlg -- Handle to device dialog                                         */
/*   lpDrvInfo -- Points to DRIVERINFO structure                             */
/*   buildFlags -- Combination of UPDATE_xxxx flags defined at the top of    */
/*   this file                                                               */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

void NEAR PASCAL BuildDeviceDlg(HWND hDlg,
                                LPDRIVERINFO lpDrvInfo,
                                WORD buildFlags)
{
    LPPRINTERINFO lpPrinterInfo =
        (LPPRINTERINFO) lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;
    DWORD dwUIFlags = lpDrvInfo->dwUIFlags[DI_DEVICE];
    int   iNumOpts;

    // Set spin range for Available VM
    if ((buildFlags & UPDATE_AVAILVM) && (dwUIFlags & DI_AVAILVM))
    {
       SendDlgItemMessage(hDlg, ID_PRINTER_VM_SPN, SPNM_SETTOPRANGE, 0,
                           PRINTER_VM_HIGH) ;
       SendDlgItemMessage(hDlg, ID_PRINTER_VM_SPN, SPNM_SETBOTTOMRANGE, 0,
                           PRINTER_VM_LOW) ;
    }

    // Set spin range for Available Font cache
    if ((buildFlags & UPDATE_AVAILFCACHE) && (dwUIFlags & DI_AVAILFCACHE))
    {
        SendDlgItemMessage(hDlg, ID_PRINTER_FONTCACHE_SPN, UDM_SETRANGE, NULL,
                           MAKELPARAM(PRINTER_FCACHE_HIGH, PRINTER_FCACHE_LOW));
    }

    KeywordGetNumOfOptions(&lpDrvInfo->pDev, IND_MEMORYINFO,
                               (LPWORD)&iNumOpts);

    if ((buildFlags & UPDATE_DOCSTICKY) && (dwUIFlags & DI_PRINTERFTRS) &&
        (lpPrinterInfo->DocSticky.w.length != 0))
    {
        BuildPublicPPDItemsList(lpDrvInfo, hDlg, ID_DEV_DOCUMENT_STICKY);
    }

    if ((buildFlags & UPDATE_PRNTRSTICKY) && (dwUIFlags & DI_IOPTIONS) &&
        ((lpPrinterInfo->PrinterSticky.w.length != 0) || iNumOpts > 0))
    {
        BuildPublicPPDItemsList(lpDrvInfo, hDlg, ID_DEV_PRINTER_STICKY);
    }
}


/*****************************************************************************/
/*                 ShowDeviceDlg                                             */
/* Purpose:                                                                  */
/*   This function shows different parts of the device dialog based on       */
/*   "showFlags"                                                             */
/*                                                                           */
/* Parameters:                                                               */
/*   hDlg -- Handle to device dialog                                         */
/*   lpDrvInfo -- Points to DRIVERINFO structure                             */
/*   showFlags -- Combination of UPDATE_xxxx flags defined at the top of     */
/*   this file                                                               */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

void NEAR PASCAL ShowDeviceDlg(HWND hDlg,
                               LPDRIVERINFO lpDrvInfo,
                               WORD showFlags)
{
    LPPRINTERINFO lpPrinterInfo =
        (LPPRINTERINFO) lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;
    DWORD dwUIFlags = lpDrvInfo->dwUIFlags[DI_DEVICE];
    WORD  keyword;
    DWORD i;
    int   iLength;

    if ((showFlags & UPDATE_DOCSTICKY) && (dwUIFlags & DI_PRINTERFTRS))
    {
        keyword = lpPrinterInfo->DocSticky.w.offset +
            lpDrvInfo->iDocStickyIndex;

        if (lpPrinterInfo->DocSticky.w.length == 0)
        {
            /* Nothing to show */
            for (i=ID_DEVICE_LISTBOX; i<=ID_ACTIVE_ITEM_VALUE; i++)
            {
                ShowWindow(GetDlgItem(hDlg, (int)i), SW_HIDE);
            }
        }
        else
        {
            /* Highlight current item */
            SendDlgItemMessage(hDlg, ID_DEVICE_LISTBOX, LB_SETCURSEL,
                               lpDrvInfo->iDocStickyIndex, 0L);
            /* Update Active label */
            ShowActiveLabel(lpDrvInfo, hDlg, keyword, ID_ACTIVE_ITEM,
                            ID_ACTIVE_ITEM_VALUE);
        }
    }

    if ((showFlags & UPDATE_PRNTRSTICKY) && (dwUIFlags & DI_IOPTIONS))
    {
        int iNumOpts;

        iLength = lpPrinterInfo->PrinterSticky.w.length;
        keyword = (lpDrvInfo->iPrinterStickyIndex == iLength) ? IND_MEMORYINFO :
            lpPrinterInfo->PrinterSticky.w.offset +
            lpDrvInfo->iPrinterStickyIndex;

        KeywordGetNumOfOptions(&lpDrvInfo->pDev, IND_MEMORYINFO, (LPWORD)&iNumOpts);
        if ((lpPrinterInfo->PrinterSticky.w.length == 0) && (iNumOpts == 0))
        {
            /* Nothing to show */
            for (i=ID_DEV_I_OPT_LISTBOX; i<=ID_DEV_I_OPT_ACTIVE_ITEM_VALUE; i++)
            {
                ShowWindow(GetDlgItem(hDlg, (int)i), SW_HIDE);
            }
        }
        else
        {
            /* Highlight current item */
            SendDlgItemMessage(hDlg, ID_DEV_I_OPT_LISTBOX, LB_SETCURSEL,
                               lpDrvInfo->iPrinterStickyIndex, 0L);
            /* Update Active label */
            ShowActiveLabel(lpDrvInfo, hDlg, keyword,
                            ID_DEV_I_OPT_ACTIVE_ITEM,
                            ID_DEV_I_OPT_ACTIVE_ITEM_VALUE);
        }
    }


    // Set current spin value for Available VM
    if ((showFlags & UPDATE_AVAILVM) && (dwUIFlags & DI_AVAILVM))
    {
        i = (DWORD)lpDrvInfo->lpDM->dm2.fUserVMSelection / 1024;
        SendDlgItemMessage(hDlg, ID_PRINTER_VM_SPN, SPNM_SETCRNTVALUE, 0, i) ;
        SetDlgItemLong(hDlg, ID_PRINTER_VM, i, FALSE);
    }
    // Set current spin value for Available font cache
    if ((showFlags & UPDATE_AVAILFCACHE) && (dwUIFlags & DI_AVAILFCACHE))
    {
        i = (int) (lpDrvInfo->lpDM->dm2.fUserFCSelection / 1024);
        SendDlgItemMessage(hDlg, ID_PRINTER_FONTCACHE_SPN, UDM_SETPOS, NULL,
                           MAKELPARAM(i, NULL));
    }

}


/*****************************************************************************/
/*                                                                           */
/*                           CheckDevice                                     */
/* Purpose:                                                                  */
/*   Checks the validity of certain user entered data in the                 */
/*   Device options dialog box. The first invalid or out of range entry      */
/*   causes failure and the item in question will be highlighted.            */
/*                                                                           */
/* Parameters:                                                               */
/*   lpDrvInfo -- Pointer to DRIVERINFO structure                            */
/*   hDlg -- Handle to device features dialog                                */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE  => if success, entered values are fine                            */
/*   FALSE => if failure, at least one entered value is invalid              */
/*****************************************************************************/
BOOL NEAR PASCAL CheckDevice(LPDRIVERINFO lpDrvInfo, HWND hDlg)
{
    LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;
    DWORD          dwUIFlags = lpDrvInfo->dwUIFlags[DI_DEVICE];
    long           i;
    BOOL           bOK = TRUE;
    long           minVal, maxVal;

    // Check VM
   if (dwUIFlags & DI_AVAILVM)
   {
       i = GetDlgItemReal(hDlg, ID_PRINTER_VM, 0, ".", &bOK, FALSE);
       i = i << 10L;             /* Multiply by 1024 to convert from KB */

       // Check value against bounds
       if (bOK && ((float)i >=  lpPSExtDevmode->dm2.fMinVM &&
                   (float)i <= lpPSExtDevmode->dm2.fMaxVM))
       {
           lpPSExtDevmode->dm2.fUserVMSelection = (float)i;
       }
       else
       {
           bOK = FALSE;
       }
       if (!bOK)
       {
           minVal = (long)lpPSExtDevmode->dm2.fMinVM >> 10L; // must display
           maxVal = (long)lpPSExtDevmode->dm2.fMaxVM >> 10L; // in KB format
           goto VMErrors;
       }

VMErrors:
       if (!bOK)
       {
          ShowErrorValueMessage(hDlg, ID_PRINTER_VM, minVal, maxVal);
       }
   }

   // Check Font Cache
   if (bOK && dwUIFlags & DI_AVAILFCACHE)
   {
       i = GetDlgItemInt(hDlg, ID_PRINTER_FONTCACHE, &bOK, FALSE);
       i = i << 10L;             /* Multiply by 1024 to convert from KB */

       // Check value against bounds
       if (bOK && ((float)i >=  lpPSExtDevmode->dm2.fMinFontCache &&
                   (float)i <= lpPSExtDevmode->dm2.fMaxFontCache))
       {
           lpPSExtDevmode->dm2.fUserFCSelection = (float)i;
       }
       else
       {
           bOK = FALSE;
       }
       if (!bOK)
       {
           minVal = (long)lpPSExtDevmode->dm2.fMinFontCache >> 10L; // must display
           maxVal = (long)lpPSExtDevmode->dm2.fMaxFontCache>> 10L; // in KB format
           goto FCErrors;
       }

FCErrors:
       if (!bOK)
       {
          ShowErrorValueMessage(hDlg, ID_PRINTER_FONTCACHE, minVal, maxVal);
       }
   }
   return bOK;
}


/*****************************************************************************/
/*                 RestoreDeviceDefaults                                     */
/* Purpose:                                                                  */
/*                                                                           */
/*   This function restore values displayed in the device dialog to          */
/*   default values. It is called by InitDefaultDevmode and by               */
/*   RestoreDefaults to bring the data structure to the default values. This */
/*   function does not affect the display.                                   */
/*                                                                           */
/* Parameters:                                                               */
/*   lpPSEXtDevmode -- Pointer to PSEXTDEVMODE structure                     */
/*   lpWPXblock -- Pointer to WPXBLOCKS                                      */
/*   dwUIFlags -- Specifies which fields should be set to default values.    */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

void FAR PASCAL RestoreDeviceDefaults(LPPSEXTDEVMODE lpPSExtDevmode,
                                      LPWPXBLOCKS lpWPXBlock,
                                      DWORD dwUIFlags)
{
    int i, start, end;
    LPPRINTERINFO  lpPrinterInfo ;
    LPMAINKEYHDR   lpCurMainKeyHdr;

    lpPrinterInfo = (LPPRINTERINFO)(lpWPXBlock->WPXprinterInfo);
    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_MEMORYINFO;

    if (dwUIFlags & DI_PRINTERFTRS)
    {
        start = lpPrinterInfo->DocSticky.w.offset;
        end = start + lpPrinterInfo->DocSticky.w.length;

        for (i = start; i < end; i++)
        {
            ResetKeywordOption(lpPSExtDevmode, lpPrinterInfo, i);
        }
    }

    if (dwUIFlags & DI_IOPTIONS)
    {
        LPMAINKEYHDR  lpCurMainKeyHdr ;

        start = lpPrinterInfo->PrinterSticky.w.offset;
        end = start + lpPrinterInfo->PrinterSticky.w.length;

        for (i = start; i < end; i++)
        {
            ResetKeywordOption(lpPSExtDevmode, lpPrinterInfo, i);
        }

        lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_MEMORYINFO ;

        if (lpCurMainKeyHdr->OptionKeyWords.w.length > 0)
            ResetKeywordOption(lpPSExtDevmode, lpPrinterInfo, IND_MEMORYINFO);
    }

    /* Reset the free VM */
    if (dwUIFlags & DI_AVAILVM)
    {
        lpPSExtDevmode->dm2.fUserVMSelection  =
            (float)lpPrinterInfo->devcaps.iFreeVM * 1024;
    }
    /*  Reset the free font cache */
    if (dwUIFlags & DI_AVAILFCACHE)
    {
        // YCT make this value consistent with VM option entry
        lpPSExtDevmode->dm2.fUserFCSelection  =
            (float)lpPrinterInfo->devcaps.iFontCacheSize * 1024;

    }
}


/*****************************************************************************/
/*                 HandleListBoxSelection                                    */
/* Purpose:                                                                  */
/*   This function is called when the user moves the current selection in    */
/*   the docsticky or printersticky list boxes.  It updates the active label */
/*   and the associated combo box.                                           */
/*                                                                           */
/* Parameters:                                                               */
/*   lpDrvInfo -- Points to DRIVERINFO structure                             */
/*   hDlg -- Handle to device dialog                                         */
/*   wParam -- ID_DEVICE_LISTBOX => Docsticky list box, else printersticky   */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

void NEAR PASCAL HandleListBoxSelection(LPDRIVERINFO lpDrvInfo,
                                        HWND hDlg,
                                        WORD wParam)
{
    int new_index, old_index;

    new_index = LOWORD(SendDlgItemMessage(hDlg, wParam, LB_GETCURSEL, 0, NULL));

    old_index = (wParam == ID_DEVICE_LISTBOX) ?
        lpDrvInfo->iDocStickyIndex : lpDrvInfo->iPrinterStickyIndex;

    /*
     * Update Active label and combo box only if current
     * selection has really changed.
     */
    if (new_index != old_index)
    {
        if (wParam == ID_DEVICE_LISTBOX)
        {
            lpDrvInfo->iDocStickyIndex = new_index;
        }
        else
        {
            lpDrvInfo->iPrinterStickyIndex = new_index;
        }

        ShowDeviceDlg(hDlg, lpDrvInfo, (wParam == ID_DEVICE_LISTBOX) ?
                      UPDATE_DOCSTICKY : UPDATE_PRNTRSTICKY);
    }
}


/*****************************************************************************/
/*                 UpdateFreeVM                                              */
/* Purpose:                                                                  */
/*   This function is called when the user changes the current value of the  */
/*   IND_MEMORYINFO keyword. It first checks to see if the current value of  */
/*   of freeVM is the same as the available VM for the old option. If it is, */
/*   it changes it to the availVM value of the new option and shows it on    */
/*   screen. If it wasn't the same, it assumes that the user has tweaked it, */
/*   and asks the user if it should leave it as it is or change it, and acts */
/*   accordingly.                                                            */
/*                                                                           */
/* Parameters:                                                               */
/*   lpDrvInfo -- Points to DRIVERINFO structure                             */
/*   hDlg -- Handle to device dialog                                         */
/*   oldOpt -- Old memory option index.                                      */
/*   newOpt -- New memory option index.                                      */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

void NEAR PASCAL UpdateFreeVM(LPDRIVERINFO lpDrvInfo,
                              HWND hDlg,
                              WORD oldOpt,
                              WORD newOpt)
{
    LPPSEXTDEVMODE lpdm;
    LPWPXBLOCKS    lpWPXblock;
    LPPRINTERINFO  lpPrinterInfo;
    LPMAINKEYHDR   lpCurMainKeyHdr;
    LPMEMORYINFO   lpMemoryInfo;
    DWORD          availVM, freeVM, maxVM;
    BOOL           bOK, changeVM = TRUE;

    lpWPXblock = lpDrvInfo->pDev.lpWPXblock;
    lpPrinterInfo = (LPPRINTERINFO) lpWPXblock->WPXprinterInfo;
    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_MEMORYINFO;
    lpMemoryInfo = (LPMEMORYINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray,
                                          HIWORD(lpWPXblock->WPXarrays));
    lpdm = lpDrvInfo->lpDM;
    availVM = lpMemoryInfo[oldOpt].AvailibleVM;
    freeVM  = GetDlgItemReal(hDlg, ID_PRINTER_VM, 0, ".", &bOK, FALSE);
    maxVM = (DWORD)(lpdm->dm2.fMaxVM / 1024);
    if (!bOK)
    {
       freeVM = SendDlgItemMessage(hDlg, ID_PRINTER_VM_SPN, SPNM_GETCRNTVALUE, 0, 0) ;
    }


    if (availVM != freeVM && !(availVM > maxVM && freeVM == maxVM))
    {
        /* Check with the user if UserVMSelection should be changed */
        char strBuff[STR_BUFF_LEN], Title[STR_BUFF_LEN];

        LoadString(ghDriverMod, IDS_SUGGEST_MEMORY, strBuff, sizeof(strBuff));
        LoadString(ghDriverMod, IDS_TITLE_DRIVER, Title, sizeof(Title));
        if (MessageBox(hDlg, strBuff, Title,
                       MB_YESNO|MB_ICONQUESTION) != IDYES)
        {
            changeVM = FALSE;
        }
    }

    if (changeVM)
    {
        float vm = (float)lpMemoryInfo[newOpt].AvailibleVM * 1024;
        DWORD vmk = lpMemoryInfo[newOpt].AvailibleVM;

        if (vm > lpdm->dm2.fMaxVM)
        {
           vm = lpdm->dm2.fMaxVM;
           vmk = maxVM;
        }

        lpdm->dm2.fUserVMSelection = vm;

        if (lpDrvInfo->dwUIFlags[DI_DEVICE] & DI_AVAILVM)
        {
           SetDlgItemLong(hDlg, ID_PRINTER_VM, vmk, FALSE);
           SendDlgItemMessage(hDlg, ID_PRINTER_VM_SPN, SPNM_SETCRNTVALUE,
                              0, vmk) ;
        }

        vm = (float)lpMemoryInfo[newOpt].AvailibleFC * 1024;
        vmk = lpMemoryInfo[newOpt].AvailibleFC;

        if (vm > lpdm->dm2.fMaxFontCache )
        {
           vm = lpdm->dm2.fMaxFontCache;
           vmk = (DWORD)(lpdm->dm2.fMaxFontCache / 1024);
        }

        lpdm->dm2.fUserFCSelection = vm;

        if (lpDrvInfo->dwUIFlags[DI_DEVICE] & DI_AVAILFCACHE)
        {
            SetDlgItemInt(hDlg, ID_PRINTER_FONTCACHE, (int)vmk, FALSE);
        }

    }
}


/*****************************************************************************/
/*                 HandleComboBoxSelection                                   */
/* Purpose:                                                                  */
/*   This function is called when the user changes the current selection in  */
/*   the docsticky or printersticky active item combo box. It updates the    */
/*   display in the associated list box to show the keyword and the new      */
/*   option. It also updates FreeVM if applicable.                           */
/*   and the associated combo box.                                           */
/*                                                                           */
/* Parameters:                                                               */
/*   lpDrvInfo -- Points to DRIVERINFO structure                             */
/*   hDlg -- Handle to device dialog                                         */
/*   wParam -- ID_ACTIVE_TEM_VALUE => Docsticky conbo box, else              */
/*   printersticky one.                                                      */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

void NEAR PASCAL HandleComboBoxSelection(LPDRIVERINFO lpDrvInfo,
                                         HWND hDlg,
                                         WORD wParam)
{
    LPPRINTERINFO  lpPrinterInfo ;
    WORD i, old_mem, new_mem;
    int  iBaseIndex, iLength, keyword, new_index, old_index, lb_index;
    BOOL bMemoryKeyword = FALSE;


    lpPrinterInfo = (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);

    /* Get old memory keyword option */
    KeywordGetNumOfOptions(&lpDrvInfo->pDev, IND_MEMORYINFO, (LPWORD) &i);
    if (i > 0)
    {
        bMemoryKeyword = TRUE;
        KeywordGetCurrentOption(&lpDrvInfo->pDev, IND_MEMORYINFO,  &old_mem);
    }

    new_index = LOWORD(SendDlgItemMessage(hDlg, wParam, CB_GETCURSEL, 0, NULL));

    /* Get listbox index. This will help us find what keyword it is */
    lb_index = LOWORD(SendDlgItemMessage(hDlg, wParam - 3, LB_GETCURSEL,
                                         0, 0L));

    if (wParam == ID_ACTIVE_ITEM_VALUE)
    {
        iBaseIndex = lpPrinterInfo->DocSticky.w.offset;
        iLength    = lpPrinterInfo->DocSticky.w.length;
    }
    else
    {
        iBaseIndex = lpPrinterInfo->PrinterSticky.w.offset;
        iLength    = lpPrinterInfo->PrinterSticky.w.length;
    }

    keyword = (lb_index == iLength) ? IND_MEMORYINFO : iBaseIndex + lb_index;

    KeywordGetCurrentOption(&lpDrvInfo->pDev, keyword, (LPWORD)&old_index);

     /* Update List box only if current selection has really changed. */
    if (old_index != new_index)
    {
        WORD rc;

        rc = UICSetCurrentOption(lpDrvInfo, keyword, new_index, hDlg);

        if (rc == SCREENUPDATE_UICONSTRAINTS)
        {
#if 0
            /* Rebuild both combo boxes and set selections */
            /* Device sticky */
            if ((lpDrvInfo->dwUIFlags[DI_DEVICE] & DI_PRINTERFTRS) &&
                (lpPrinterInfo->DocSticky.w.length != 0))
            {
                ShowActiveLabel(lpDrvInfo, hDlg,
                                lpPrinterInfo->DocSticky.w.offset +
                                lpDrvInfo->iDocStickyIndex, ID_ACTIVE_ITEM,
                                ID_ACTIVE_ITEM_VALUE);
            }

            if ((lpDrvInfo->dwUIFlags[DI_DEVICE] & DI_IOPTIONS) &&
                (lpPrinterInfo->PrinterSticky.w.length != 0))
            {
                ShowActiveLabel(lpDrvInfo, hDlg,
                                (WORD)lpDrvInfo->iPrinterStickyIndex ==
                                lpPrinterInfo->PrinterSticky.w.length ?
                                IND_MEMORYINFO :
                                lpPrinterInfo->PrinterSticky.w.offset +
                                lpDrvInfo->iPrinterStickyIndex,
                                ID_DEV_I_OPT_ACTIVE_ITEM,
                                ID_DEV_I_OPT_ACTIVE_ITEM_VALUE);
            }

            rc = SCREENUPDATE_NONE;
#endif
            BuildDeviceDlg(hDlg, lpDrvInfo, UPDATE_UICONSTRAINED);
            ShowDeviceDlg(hDlg, lpDrvInfo, UPDATE_UICONSTRAINED);
        }

        if (rc == SCREENUPDATE_NONE)
        {
            /*
             * Update list box with new selection
             */

            /* Delete old string */
            SendDlgItemMessage(hDlg, wParam - 3, LB_DELETESTRING, lb_index, 0L);

            /* Insert new string */
            AddItemToListBox(&lpDrvInfo->pDev, hDlg, wParam - 3, keyword,
                             LB_INSERTSTRING, lb_index);
            SendDlgItemMessage(hDlg, wParam - 3, LB_SETCURSEL, lb_index, 0L);
        }
        else if (rc == SCREENUPDATE_CURRENT)
        {
            /* Update combo box selection */
            SendDlgItemMessage(hDlg, wParam, CB_SETCURSEL, old_index,
                               MAKELONG(0,-1));
        }
        else if (rc == SCREENUPDATE_ALL)
        {
            /* Redisplay all UI constrained options */
            BuildDeviceDlg(hDlg, lpDrvInfo, UPDATE_UICONSTRAINED);
            ShowDeviceDlg(hDlg, lpDrvInfo, UPDATE_UICONSTRAINED);
        }
    }

    if (bMemoryKeyword)
    {
        KeywordGetCurrentOption(&lpDrvInfo->pDev, IND_MEMORYINFO,  &new_mem);
        if (old_mem != new_mem)
        {
            UpdateFreeVM(lpDrvInfo, hDlg, old_mem, new_mem);
        }
    }

}


/*****************************************************************************/
/*                                                                           */
/*                              CHDeviceDlg                                  */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the Device Options property sheet dialog box.     */
/*                                                                           */
/* Parameters:                                                               */
/*   hDlg -- Handle to the dialog box window                                 */
/*   imsg -- Message                                                         */
/*   wParam -- Word parameter                                                */
/*   lParam -- Long parameter                                                */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/
BOOL _loadds FAR PASCAL CHDeviceDlg(HWND hDlg,
                                    unsigned imsg,
                                    WORD wParam,
                                    LONG lParam)
{
    LPDRIVERINFO   lpDrvInfo;
    LPPSEXTDEVMODE lpPSExtDevmode;
    LPPRINTERINFO  lpPrinterInfo;
    BOOL           result = TRUE;
    BOOL           bChanged = FALSE;
    BOOL           ok_flag;
    DWORD          i;
    HWND           hEdit;
    FARPROC        lpfnEditProc;

    if(lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
    {
#ifdef USEHOOKPROC
        /* Process hook function stuff */
        if(DrvProcessHookProc(&(lpDrvInfo->pDev),hDlg,imsg,wParam,lParam,
                              "HookSetup"))
        {
            return TRUE;
        }
#endif
        lpPrinterInfo =
            (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
        lpPSExtDevmode = lpDrvInfo->lpDM;
    }

    switch (imsg)
    {
        case WM_INITDIALOG:
            lpDrvInfo=(LPDRIVERINFO)(((LPPROPSHEETPAGE)lParam)->lParam);
            SetWindowLong(hDlg,DWL_USER,(LPARAM)lpDrvInfo);
            lpPSExtDevmode=lpDrvInfo->lpDM;
            lpDrvInfo->bPainting = TRUE;

            InitDeviceDlg(hDlg, lpDrvInfo);
            BuildDeviceDlg(hDlg, lpDrvInfo, UPDATE_NONUICONSTRAINED);
            ShowDeviceDlg(hDlg, lpDrvInfo, UPDATE_NONUICONSTRAINED);

            // subclass the ID_PRINTER_VM editbox to handle up/down arrow
            hEdit = GetDlgItem(hDlg, ID_PRINTER_VM);
            lpfnEditProc = MakeProcInstance( (FARPROC)PrinterVMDlg, ghDriverMod );
            EditWndProc = (FARPROC)GetWindowLong(hEdit, GWL_WNDPROC);
            SetWindowLong(hEdit, GWL_WNDPROC, (LONG)lpfnEditProc);

            lpDrvInfo->bPainting = FALSE;
            break ;

        case WM_BUILD_DLG:
          BuildDeviceDlg(hDlg, lpDrvInfo, wParam);
          break;

        case WM_SHOW_DLG:
          ShowDeviceDlg(hDlg, lpDrvInfo, wParam);
          break;

        case WM_CONTEXTMENU:
            if (wParam != -1)
            {
                WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                        (DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_HELP:
            if (((LPHELPINFO) lParam)->hItemHandle != -1)
            {
                WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                        HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_NOTIFY:
            switch (NOTIFY_CODE(lParam))
            {
                case PSN_SETACTIVE:
                    lpDrvInfo->bPainting = TRUE;
                    BuildDeviceDlg(hDlg, lpDrvInfo, UPDATE_UICONSTRAINED);
                    ShowDeviceDlg(hDlg, lpDrvInfo, UPDATE_UICONSTRAINED);
                    lpDrvInfo->bPainting = FALSE;
                    break;

                case PSN_KILLACTIVE:
                    if (!CheckDevice(lpDrvInfo, hDlg))
                    {
                        SetWindowLong(hDlg,DWL_MSGRESULT,TRUE);
                        return TRUE;
                    }
                    break;

                case PSN_APPLY:
                    if (lpDrvInfo->bChanged)
                    {
                        if (!UICCheckAllOptions(lpDrvInfo, hDlg, FALSE, 0))
                        {
                            SetWindowLong(hDlg,DWL_MSGRESULT,TRUE);
                            return TRUE;
                        }
                        UpdateGlobal(lpDrvInfo,TRUE);
                        WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
                        lpDrvInfo->bChanged = FALSE;
                    }
                    break;

                case PSN_RESET:
                    // If canceling, set lpDrvInfo->lpDM back to saved devmode
                    lpDrvInfo->lpDM=&(lpDrvInfo->DMSave);
                    WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
                    break;

            }  // switch(...)
            break;

        case WM_COMMAND:
            switch (wParam)
            {
                case ID_RESTORE_DEFAULTS:
                    RestoreDeviceDefaults(lpDrvInfo->lpDM,
                                          lpDrvInfo->pDev.lpWPXblock,
                                          lpDrvInfo->dwUIFlags[DI_DEVICE]);
                    lpDrvInfo->iDocStickyIndex =
                        lpDrvInfo->iPrinterStickyIndex = 0;
                    BuildDeviceDlg(hDlg, lpDrvInfo, UPDATE_UICONSTRAINED);
                    ShowDeviceDlg(hDlg, lpDrvInfo, UPDATE_ALL);
                    UICCheckAllOptions(lpDrvInfo, hDlg, TRUE,
                                       UPDATE_UICONSTRAINED);
                    bChanged = TRUE;
                    break;

                case ID_ABOUT:
                    DialogBoxParam(ghDriverMod,"AB",hDlg,
                                   fnAboutDlg, (LPARAM)lpDrvInfo);
                    break;

                case ID_DEVICE_LISTBOX:
                case ID_DEV_I_OPT_LISTBOX:
                    if (HIWORD(lParam) == LBN_SELCHANGE)
                    {
                        HandleListBoxSelection(lpDrvInfo, hDlg, wParam);
                        bChanged = TRUE;
                    }
                    break;

                case ID_ACTIVE_ITEM_VALUE:
                case ID_DEV_I_OPT_ACTIVE_ITEM_VALUE:
                 if (HIWORD(lParam) == CBN_SELCHANGE)
                 {
                     HandleComboBoxSelection(lpDrvInfo, hDlg, wParam);
                     bChanged = TRUE;
                 }
                 break ;

                case ID_PRINTER_VM:
                    if (HIWORD(lParam) == EN_CHANGE)
                    {
                        bChanged = TRUE;
                    }
                    break;

                case ID_PRINTER_VM_SPN:
                  if (HIWORD(lParam) == SPNN_VALUECHANGE)
                    {
                       i = SendDlgItemMessage (hDlg, ID_PRINTER_VM_SPN, SPNM_GETCRNTVALUE, 0, 0L);
                       SetDlgItemLong(hDlg, ID_PRINTER_VM, i, FALSE);
                       UpdateWindow(GetDlgItem(hDlg, ID_PRINTER_VM));
                    }

                  if (HIWORD(lParam) == SPNN_FIRSTTIMEDOWN)
                    {
                       i = GetDlgItemReal(hDlg, ID_PRINTER_VM, 0, ".", &ok_flag, FALSE);
                       if (ok_flag)
                       {
                          SendDlgItemMessage (hDlg, ID_PRINTER_VM_SPN, SPNM_SETCRNTVALUE, 0, i) ;
                       }
                    }
                  break;

                case ID_PRINTER_FONTCACHE:
                    if (HIWORD(lParam) == EN_CHANGE)
                        bChanged = TRUE;
                    break;

#ifndef USE_WHATSTHIS_HELP
                case ID_HELP:
                    WinHelp(hDlg, szHelpFile, HELP_CONTEXT,
                            IDH_PSCRIPT_ADJUST_PRNTR_FTRS);
                    break;
#endif
             default:
                 result = FALSE ;
                 break ;

         } // switch (wParam)
         break ;

        case WM_MEASUREITEM:
            HandleMeasureItem(hDlg, lpDrvInfo, (int)wParam,
                              (LPMEASUREITEMSTRUCT)lParam);
            break;

        case WM_DRAWITEM:
            HandleDrawItem(hDlg, lpDrvInfo, (int)wParam,
                           (LPDRAWITEMSTRUCT)lParam);
            break;

        default:
            result = FALSE ;
            break ;
    }  // switch(imsg)

    if (bChanged && lpDrvInfo && !lpDrvInfo->bChanged && !lpDrvInfo->bPainting)
    {
        lpDrvInfo->bChanged = TRUE;
        PropSheet_Changed( GetParent(hDlg), hDlg );
    }

    return result ;
} // CHDeviceDlg()


LRESULT _loadds FAR PASCAL PrinterVMDlg(HWND hDlg,
                                    unsigned imsg,
                                    WORD wParam,
                                    LONG lParam)
{   DWORD i, j;
    BOOL  ok_flag;
    char  buffer[64];

    switch(imsg)
    {
        case WM_KEYDOWN:
            switch( wParam )
            {
                case VK_UP:
                case VK_DOWN:
                    i = j = GetDlgItemReal(GetParent(hDlg), ID_PRINTER_VM, 0, ".", &ok_flag, FALSE);
                    if (ok_flag)
                    {
                        if (wParam == VK_UP && i < PRINTER_VM_HIGH)
                            i++;
                        else if (wParam == VK_DOWN && i > PRINTER_VM_LOW)
                            i--;
                    }
                    if( i != j )
                    {
                        wsprintf(buffer, "%ld", i);
                        SetWindowText(hDlg, (LPSTR)buffer);
                    }
                    return( TRUE );
            }
            break;
    }

    return CallWindowProc( EditWndProc, hDlg, imsg, wParam, lParam );

}
































