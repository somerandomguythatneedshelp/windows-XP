/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ESCSTUB2.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for ...                   */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_ESCSTUBSSEG)


// typedef required by ESCGetExtentTable()

typedef struct _GETX
{
   BYTE bFirst;
   BYTE bLast ;
}
GETX,FAR *LPGETX;

//max length of bin description reported by ESCEnumPaperBins().
#define MAX_BINNAME_LEN 24

#define SAVEPAPERBIN_MASK 0x8000
#define LINETO_FLAG     0x0002  // If this flag is set - use lineto
					// instead of moveto for the first command


//structure required for ESCGetSetPaperBins().
typedef struct tagBININFO
{
   short BinNumber ;
   short NbrofBins ;
   short Reserved[4] ;
} BININFO ;
typedef BININFO FAR *LPBININFO ;


//--------------------------------------------------------------------
// Function definitions:
//--------------------------------------------------------------------

#if 0

buggy, should this return widths in EMs ? well it doesn't.

/*****************************************************************************************
 *
 *      ESCGetExtentTable
 *
 *      May be called anywhere between Enable() and Disable().
 *      Never disabled.  Never causes a state transition.
 */

short FAR PASCAL ESCGetExtentTable(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
// GDI passes the Driver a pointer to an EXTTEXTDATA structure. This
// structure contains the universe of information. For reference the
// structure is shown below:
//
//       typedef struct _EXTTEXTDATA
//       {
//          short       sSize     ;
//          LP          lpInData  ;
//          LPPSFONTINFO  lpFontInfo;
//          LPTEXTXFORM lpXForm   ;
//          LPDRAWMODE  lpDrawMode;
//       }
//       EXTTEXTDATA, FAR *LPEXTTEXTDATA;
//
// All that is needed from this structure is the FONTINFO structure &
// the GETX structure. Therefore...

  BYTE          First,Last                                 ;
  short         Retn                                       ;
  LPEXTTEXTDATA lpetd      = (LPEXTTEXTDATA)lpInData       ;
  LPPSFONTINFO    lpFontInfo = (LPPSFONTINFO )lpetd->lpFontInfo;
  LPGETX        lpGetX     = (LPGETX)lpetd->lpInData       ;

  if( (lpetd      == (LPEXTTEXTDATA)NULL) ||
	   (lpFontInfo == (LPPSFONTINFO   )NULL) ||
	   ((lpFontInfo->dfType & 0x80) == 0   ))
  {
	   return(0)                                 ;       // Return number of bytes
  }                                                     // copied into lpOutData

  First= lpGetX->bFirst                         ;
  Last = lpGetX->bLast                          ;
  Retn = DevGetCharWidth((LP) lpDevice,(LPSHORT)lpOutData,(SHORT)First,
	  (short)Last,lpFontInfo,(LPDRAWMODE)0L,(LPTEXTXFORM)0L);

  return( Retn )                                ;
}
#endif

//This is another function whose values are dependent on the state
//of Relative Widths.  At present the EnableRelativeWidths procedure
//is not supported
//
short FAR PASCAL ESCGetPairKernTable(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
// GDI passes the Driver a pointer to an EXTTEXTDATA structure. This
// structure contains the universe of information. For reference the
// structure is shown below:
//
//       typedef struct _EXTTEXTDATA
//       {
//          short       sSize     ;
//          LP          lpInData  ;
//          LPPSFONTINFO  lpFontInfo;
//          LPTEXTXFORM lpXForm   ;
//          LPDRAWMODE  lpDrawMode;
//       }
//       EXTTEXTDATA, FAR *LPEXTTEXTDATA;


   LPEXTTEXTDATA lpetd      = (LPEXTTEXTDATA)lpInData;
   LPPSFONTINFO    lpFontInfo = (LPPSFONTINFO   )lpetd->lpFontInfo;
   LPFONTEXTRA   lpFontExtra= (LPFONTEXTRA)BUMPFAR (lpFontInfo, lpFontInfo->dfDriverInfo);
   LPKP          lpkp;
   LPWORD        lpwSrc,lpwLim                 ;
   LPPFMEXTENSION lpPFMExt;
   LPETM         lpETM;
   short         sTemp,sHeight                 ;
   FLAG flag                                   ;
   int  EM ;

  if( (lpetd                   == (LPEXTTEXTDATA)NULL) ||
	   (lpFontInfo              == (LPPSFONTINFO   )NULL) ||
	   (lpFontInfo->dfType      &  TYPE_TRUETYPE)       ||
	   (lpFontExtra             == (LPFONTEXTRA  )NULL) ||
	   (lpFontExtra->dwPairKern == 0)      ||
	   ((lpFontInfo->dfType     &  0x80) == 0   ))
  {
	   return(0)                                 ;       // Return failure
  }

   lpkp = (LPKP) BUMPFAR (lpFontInfo, lpFontExtra->dwPairKern);
   //there must be a good reason for scaling kerning information
   //based on the font's height, even though kerning is horizontal

   sHeight=lpetd->lpFontInfo->dfPixHeight;
   lpPFMExt = (LPPFMEXTENSION) ((LPBYTE) lpFontInfo + sizeof(PFMHEADER));
   lpETM = (LPETM) ((LPBYTE) lpFontInfo + lpPFMExt->dfExtMetricsOffset);
   EM = lpETM->etmMasterUnits;
   
   //this code was mainly taken from the MS driver
   //
   lpwSrc=(LPWORD)lpkp->rgPairs               ;         // Points to iKey in 0th pair
   lpwLim=(LPWORD)&lpkp->rgPairs[lpkp->cPairs];         // Points to iKey in last pair


   flag=FALSE                                 ;         // iKey comes before iKernAmount
   while(lpwSrc<lpwLim)
   {
	if(flag)
	{                                            // This state = TRUE
		sTemp = *lpwSrc++               ;         // sTemp = iKernAmount
		sTemp = MulDiv(sTemp,sHeight,EM);
		flag  = FALSE                   ;         // Next state = FALSE
	}
	else
	{                                            // This state = FALSE
		sTemp = *lpwSrc++               ;         // sTemp = iKey
		flag = TRUE                     ;         // Next state = TRUE
	}
	*((LPWORD)lpOutData)++ =sTemp      ;         // Save (iKey,iKernAmount)
   }                                                    // pairs for the application

   return(lpkp->cPairs)                       ;
}

/*
 *      ESCGetTrackKernTable
 *
 *      May be called anywhere between Enable() and Disable().
 *      Never disabled.  Never causes a state transition.
 */

short FAR PASCAL ESCGetTrackKernTable(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
// GDI passes the Driver a pointer to an EXTTEXTDATA structure. This
// structure contains the universe of information. For reference the
// structure is shown below:
//
//       typedef struct _EXTTEXTDATA
//       {
//          short       sSize     ;
//          LP          lpInData  ;
//          LPPSFONTINFO  lpFontInfo;
//          LPTEXTXFORM lpXForm   ;
//          LPDRAWMODE  lpDrawMode;
//       }
//       EXTTEXTDATA, FAR *LPEXTTEXTDATA;]
//
// lpOutData I believe is this.
//
// GDI passes the Driver a pointer to an Array of KERNTRACK structures.
// For reference the structure is shown below:
//
//       typedef struct
//       {
//          short cTracks    ;   // The number of kern tracks
//          TRACK rgTracks[1];   // The kern track information
//       } KT;

  short         nNumberOfTracks;        // Number of KernTracks filled.
  short         nMaxNumberOfTracks;
  LPTRACK       lpLclTrackKern;
  LPKT          lpFXTrackKern;
  LPEXTTEXTDATA lpetd;
  LPPSFONTINFO    lpFontInfo;
  LPFONTEXTRA   lpFontExtra;

  lpLclTrackKern  = (LPTRACK      )lpOutData;
  lpetd           = (LPEXTTEXTDATA)lpInData;
  lpFontInfo      = (LPPSFONTINFO   )lpetd->lpFontInfo;
  lpFontExtra     = (LPFONTEXTRA  ) BUMPFAR (lpFontInfo, lpFontInfo->dfDriverInfo);
  nNumberOfTracks = 0;

  if( (lpetd      == (LPEXTTEXTDATA)NULL) ||
	   (lpFontInfo == (LPPSFONTINFO   )NULL) ||
	   (lpFontInfo->dfType & TYPE_TRUETYPE)||
	   (lpOutData  == (LP           )NULL) ||
	   (lpFontExtra== (LPFONTEXTRA  )NULL))
  {
	   return(nNumberOfTracks);       // Return Number of KERNTABLES filled
  }
  lpFXTrackKern  = (LPKT) BUMPFAR (lpFontInfo, lpFontExtra->dwTrackKern);

  // This is a real problem with the interface.
  //  There can be more than one TRACK specified yet
  //  There can not be more than one TRACK ???

  nMaxNumberOfTracks = lpFXTrackKern->cTracks;

  // Now lets fill those KernTracking Tables.
  if( nMaxNumberOfTracks == 1 )
  {
	 *lpLclTrackKern = lpFXTrackKern->rgTracks[0];   // Copy the track kern.
  }
  else
  {
	 nMaxNumberOfTracks = 0;    //  Make sure there is no mistake.
  }

  return(nMaxNumberOfTracks);
}

short FAR PASCAL ESCExtTextOut(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
  return(0);       // Return Not Implemented
}

short FAR PASCAL ESCPostScriptData(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
   return( ESCPassThrough( lpDevice, lpInData, lpOutData ) );
}



short FAR PASCAL ESCGetSetScreenParams(LPPDEVICE  lpdv,LP lpbIn ,LP lpbOut)
{
   WORD freq, angle;  // in tenths of units.
   LPPSDEVMODE  dm1;

   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   LPBYTE      lpOptionsBlock;
   
   lpPrinterInfo = (LPPRINTERINFO)lpdv->lpWPXblock->WPXprinterInfo ;
   lpOptionsBlock = lpdv->lpWPXblock->WPXarrays ;
   
   dm1 = &lpdv->lpPSExtDevmode->dm ;

   /* return old parameters to caller */
   if (lpbOut)
   {
	  if  (dm1->useDefaultHalftoneParams )
	  {
	 LPRESOLUTIONINFO  lpResInfo ;
	 WORD  curResIndex ;

	 KeywordGetCurrentOption(lpdv, IND_RESOLUTIONINFO, &curResIndex) ;
	
	 lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_RESOLUTIONINFO ;

	 lpResInfo = 
		   (LPRESOLUTIONINFO)MAKELONG(lpCurMainKeyHdr->extraOptionArray,
					  HIWORD(lpOptionsBlock) );

	 freq =   (WORD)lpResInfo[curResIndex].ScreenFreq ;
	 angle =  (WORD)lpResInfo[curResIndex].ScreenAngle ;
	  }
	  else
	  {
	 freq = (WORD)dm1->ScreenFrequency;
	 angle = (WORD)dm1->ScreenAngle;
	  }
	  ((SCREENPARAMS FAR *)lpbOut)->angle = angle;
	  ((SCREENPARAMS FAR *)lpbOut)->frequency = freq;
   }

   /* if user wants to change parameters do it */
   if (lpbIn)
   {
	  dm1->useDefaultHalftoneParams = FALSE ;
	  dm1->ScreenFrequency = ((SCREENPARAMS FAR *)lpbIn)->frequency;
	  dm1->ScreenAngle = ((SCREENPARAMS FAR *)lpbIn)->angle;
   }
   return (1) ;
}



/*
 *      ESCGetFaceName
 *
 *      May be called anywhere between Enable() and Disable().
 *      Never disabled.  Never causes a state transition.
 */

short FAR PASCAL ESCGetFaceName(LPPDEVICE  lpDevice,LP lpInData,LP lpOutData)
{
// GDI passes the Driver a pointer to an EXTTEXTDATA structure. This
// structure contains the universe of information. For reference the
// structure is shown below:
//
//       typedef struct _EXTTEXTDATA
//       {
//          short       sSize     ;
//          LP          lpInData  ;
//          LPPSFONTINFO  lpFontInfo;
//          LPTEXTXFORM lpXForm   ;
//          LPDRAWMODE  lpDrawMode;
//       }
//       EXTTEXTDATA, FAR *LPEXTTEXTDATA;
//
// All that is needed from this structure is the FONTEXTRA structure
// which is contained in the FONTINFO structure which is contained
// in the EXTTEXTDATA structure. Therefore...

  LPEXTTEXTDATA lpetd;
  LPPSFONTINFO    lpFontInfo ;
  int           retval;
  LPTTFONTINFO lpTTFI = NULL;

  if( lpInData == (LP) NULL )
	return (-1) ;
  
  if( lpOutData == (LP) NULL)   // request for size
	return(60) ;             // min buffer size

  lpetd      = (LPEXTTEXTDATA)lpInData;
  lpFontInfo = (LPPSFONTINFO )lpetd->lpFontInfo;

  if( lpFontInfo  == (LPPSFONTINFO) NULL     )
	   return(-1)                                ;       // Return failure

  // When asked to give face name we have three different scenarios:
  //    - native PS font - return PS font name
  //    - TT font sent as Type1 or Type3 - return synthesized MSTT31....
  //        name so application can use this name in passthru
  //    - TT font substituted to PS - return the name of PS font


  // Check for substituted font
  if( lpFontInfo->dfType & TYPE_SUBSTITUTED ) // TT -> PS substitute
  {
    lpTTFI = (LPTTFONTINFO) BUMPFAR (lpFontInfo, lpFontInfo->dfBitsOffset);
	 lpFontInfo = (LPPSFONTINFO) BUMPFAR (lpFontInfo, lpTTFI->dwSubFontInfo);

  }
  // lpFontInfo now points to the actual structure that will be used
  //    on TRAN side for selected font


  if(  lpFontInfo->dfType & TYPE_TRUETYPE ) // TT font - return TT facename
  {
	 lpTTFI = (LPTTFONTINFO) ( ( (LPSTR)lpFontInfo ) + 
								lpFontInfo->dfBitsOffset ) ;
    if (lpFontInfo->dfType & TYPE_TTRESIDENT)
	   lstrcpy( lpOutData, lpTTFI->TTFaceName) ;  //ArialMT
    else
	   lstrcpy( lpOutData, lpTTFI->PSName) ;     //MSTT31xxxx
	 retval = 1 ;
  }else if( lpFontInfo->dfType & 0x80  ) // PS font - return name
  {
	 LPFONTEXTRA   lpFontExtra = (LPFONTEXTRA) BUMPFAR (lpFontInfo, lpFontInfo->dfDriverInfo);
    LPSTR lpszPSFace = (LPSTR) BUMPFAR(lpFontInfo, lpFontExtra->dwPSFace);
	 lstrcpy( lpOutData, lpszPSFace) ;
	 retval = 1 ;    // Success
  }else
	 retval = -1 ;   // Error

  // Parse the returning font name and substitute all out-of-range chars
  //        to '-'s.
  if( retval == 1 )
  {
	 while( *lpOutData )
	 {
	  if( (*lpOutData <= 0x20) || (*lpOutData > 0x7F ) )
		   *lpOutData = '-' ;
	  lpOutData++;
	 }
  }
  return ( retval ) ;
}


/***************
* Resume our dictionaries: copied from TARN\Tescapes.c
* - we don't susppend PASST here-because we don't have it
* !!! This function does something that should be done on TRAN side only - hack!
****************/
int SendDrvDictsResume(LPPDEVICE lppd)
 {
    BOOL bfBinaryOutput =
       (lppd->lpPSExtDevmode->dm2.iDataOutputFormat != PROTOCOL_ASCII);
    BOOL nodribble = (lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED);
    BOOL DownLoadHdr = lppd->lpPSExtDevmode->dm2.fHeader;
    int  procID;

    // Re-initialize before Min-header's DownlaodFace (2nd) call
    // by "AdobePS_Driver_Min /initialize get exec", fix bug 195830, PPeng, 2-21-97

    if (fIsMinHeaderLppd(lppd) )
    {
        procID = PSFRAG_epsprintsetup;     // "AdobePS_Driver_Min /initialize get exec" ...
    }
    else if ((DownLoadHdr == TRUE) || 
       (DIALECT_EPS == lppd->lpPSExtDevmode->dm2.bOutputDialect))
    {
#ifndef ADOBE_DRIVER_42
      if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
           (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS) &&
            bfBinaryOutput)
#endif
      {
         if (nodribble == FALSE)
         {
            // Adobe_Win_Driver_Incr_L2 dup /resume get exec
            procID = PSFRAG_resumedribble_L2;
         }
         else // complete header
         {
            // /Adobe_Win_Driver_L2 /ProcSet findresource dup /resume get exec
            procID = PSFRAG_resumeprocset_L2;
         }
      }
#ifndef ADOBE_DRIVER_42
      else  // level 1
      {
         if (nodribble == FALSE)
         {
            // Adobe_Win_Driver_Incr dup /resume get exec
            procID = PSFRAG_resumedribble;
         }
         else
         {
            // /Adobe_Win_Driver /ProcSet findresource dup /resume get exec
            procID = PSFRAG_resumeprocset;
         }
      }
#endif
    }
    else
    {
        // Case 6 -- header had been already down there, initialise it.
        // /Adobe_Win_Driver /ProcSet findresource dup /resume get exec
        procID = PSFRAG_resumeprocset;
    }
    
    PSSendFragment(lppd,procID);   // This function only send one line of PS code
    PSSendFragment(lppd, PSFRAG_crlf);
    return 1;
}

/***********
* For First_SD call, we need to initlaize our dict and arrange them correctly.
* For SEcond_SD call, we need to resume our dicts  because we suspend them at end
* of every PreStartdocDLF call - ResumeDrvDicts() are
* copied mostly from TRAN\TESCAPES.C - we don't susppend PASST here-because we don't have it
* !!! This function does something that should be done on TRAN side only - hack!
****************/
int InitPreStartDocDownload(LPPDEVICE lppd, int when){
  if (when==FIRST_SD){
     // Call StartDoc() without CDocBegin() to have All Tran-side poiters initiliazed
     lppd->SmsStartDoc = FIRST_SD; 
     ESCStartDoc(lppd, NULL, NULL); 
     lppd->SmsStartDoc = SECOND_SD; // Next time, Call CDocBegin() Only
     // Force the state machine temporarily to MARKED
     lppd->stCurrent = ST_MARKED_PAGE;
     //  Initialize procsetlist[] properly.
     InitProcsetList(lppd);
     if ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED) ||
         !(lppd->lpPSExtDevmode->dm2.fHeader) 
        ){
        // Either Portability-Mode(EPS,ARCHIVE,Portable), or Header is Downloaded
        // All procset will be there before %%EndProlog.
        lppd->lpProcsetstuff->allthere = TRUE;
        }
     if ( !fIsMinHeaderLppd(lppd) ){
        TSendPrologInit(lppd, (lppd->lpPSExtDevmode->dm.enumDialect == DIA_EPS));
        PSSendMySetup(lppd, NULL , SETUP_GDI_COORDS );
        }
     else{
        PSSendFragment(lppd, PSFRAG_epsprintsetup);     // "AdobePS_Driver_Min /initialize get exec" ...
        PSSendMySetup(lppd, NULL , SETUP_PS_COORDS );
        lppd->lpProcsetstuff->allthere = FALSE;  //for min-headers, re-send the minimal proc
        }
     }
  else if (when==SECOND_SD){
     // Force the state machine temporarily to MARKED
     lppd->stCurrent = ST_MARKED_PAGE;
     SendDrvDictsResume(lppd);
     }
  else ; // add more when here

  return 1;
}

/**************
* Suspend our dicts used in DownlaodFace time.
* So - Next SPCLpassThrough sees userdict on top as our doc says
* Copy most of the code from TRAN\TESCAPES.C - we don't need PASST here
* !!! This function does something that should be done on TRAN side only - hack!
***********/
int EndPreStartDocDownload(LPPDEVICE lppd){
   BOOL bfBinaryOutput =
      (lppd->lpPSExtDevmode->dm2.iDataOutputFormat != PROTOCOL_ASCII);
   BOOL nodribble = (lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED);
   BOOL DownLoadHdr = lppd->lpPSExtDevmode->dm2.fHeader;
   int  procID;

    // We also need to suspend after Min-header's DownlaodFace call
    // dictstack was initlaized by "AdobePS_Driver_Min /initialize get exec"
    // Need suspend to end two dicts - fix bug 195830, PPeng, 2-21-97

    if (fIsMinHeaderLppd(lppd) )
    {
        // AdobePS_Driver_Min /terminate get exec
        procID = PSFRAG_termMinHdr;
    }
    else if ((DownLoadHdr == TRUE) || 
       (DIALECT_EPS == lppd->lpPSExtDevmode->dm2.bOutputDialect))
    {
        // get the value for user selection of speed vs compatiblity
#ifndef ADOBE_DRIVER_42
        if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
             (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS) &&
              bfBinaryOutput )
#endif              
        {
             if (nodribble == FALSE)
             {
                // Adobe_Win_Driver_Incr_L2 dup /suspend get exec
                procID = PSFRAG_suspenddribble_L2;
             }
             else // complete header
             {
                // /Adobe_Win_Driver_L2 /ProcSet findresource dup /suspend get exec
                procID = PSFRAG_suspendprocset_L2;
             }
        }
#ifndef ADOBE_DRIVER_42          
        else    // level 1
        {
            if (nodribble == FALSE)
            {
                // Adobe_Win_Driver_Incr dup /suspend get exec
                procID = PSFRAG_suspenddribble;
            }
            else
            {
                // /Adobe_Win_Driver /ProcSet findresource dup /suspend get exec
                procID = PSFRAG_suspendprocset;
            }
        }
#endif          
    }
    else
    {
        // Case 6 -- header had been already down there, initialise it.
        // /Adobe_Win_Driver /ProcSet findresource dup /suspend get exec
        procID = PSFRAG_suspendprocset;
    }

    PSSendFragment(lppd,procID);   // This function only send one line of PS code
    PSSendFragment(lppd, PSFRAG_crlf);

    return 1;
}



short FAR PASCAL ESCDownLoadFace(LPPDEVICE lppd,LP lpInData,LP lpOutData)
/**********************************************************************
*
*       This function either informs or performs the softfont download
*       (PostScript, Type42, TrueType->Type1, Type3). 
*
*       May be called anytime between StartDoc and EndDoc.  
*       May cause state transition equivalent to marking a page.  
*       Never disabled.
*
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- ptr to LPEXTTEXTDATA
*       LP lpOutData -- ptr short which is the mode 
*                       0=inform 
*                       1=perform
*                       2=unconditionally download
*                                   
*
*  returns:
*       > 0 => success
*       <=0 => error
************************************************************************/
{
   LPEXTTEXTDATA ExtText   = (LPEXTTEXTDATA)lpInData;
   LPTEXTXFORM   lpTextXForm = (LPTEXTXFORM)ExtText->lpXForm;
   LPPSFONTINFO    lpFontInfo = (LPPSFONTINFO)ExtText->lpFontInfo;
   LPFONTEXTRA   FontExtra;
   LPPSFONTINFO    TranFontInfo;  /* The FONTINFO structure for the
			 * TRAN side font  - it can be different
			 * from the lpFontInfo if we substitute font */
   short         Mode      = *((short far * )lpOutData);
   short         retVal    = -1;
   short     old_VMTracking;  // rember old state for D.L.Face before startdoc
   BOOL   fnameChanged=FALSE;
   LPTTFONTINFO lpTTFontInfo;
   LPBYTE   lpFontName;
   
   if(lpFontInfo->dfType & TYPE_SUBSTITUTED)
   {
    lpTTFontInfo = (LPTTFONTINFO) BUMPFAR (lpFontInfo, lpFontInfo->dfBitsOffset);
	 TranFontInfo = (LPPSFONTINFO) BUMPFAR (lpFontInfo, lpTTFontInfo->dwSubFontInfo);
   }else
   {
	 TranFontInfo = lpFontInfo;
   }

   // It is possible that ATM realized the font, and so TranFontInfo 
   // is actually NULL. Check and fail if that is the case.
   if (!TranFontInfo)
      return -1;

   FontExtra=(LPFONTEXTRA) BUMPFAR (TranFontInfo, TranFontInfo->dfDriverInfo);

   //********************************************************************
   // If font is substituted lpFontInfo points to the actual
   // font that will be used on GDI side, while TranFontInfo points
   // to the font that will be used on TRAN side for the output.
   // In any case - lpFontInfo points to the font that will be used
   // for GDI-side calculations, while TranFontInfo points to the font
   // that will be used on TRAN side.
   //********************************************************************

   if (Mode == 0)
   {
		if ( (TranFontInfo->dfType & TYPE_TRUETYPE) ||
				  (FontExtra->dwSoftFont)
		   )
		{
			retVal = TRUE ;
		}
		else
		{
#ifdef ADD_EURO
			retVal = TRUE ;
#else
			retVal = FALSE ;
#endif
		}
   }
   else 
   {  
        // Pair up Initialize/Suspend inside this else part - fix bug 195830, PPeng, 2-21-1997
        // Do some initialization for Pre-StartDoc DownLoadFace calls
        if (lppd->SmsStartDoc == NORMAL_SD && lppd->stCurrent == ST_ENABLED)
        { // SmsStartDoc is NORMAL_SD and NOT startDOC yet. DO this only ONCE !!!
            InitPreStartDocDownload(lppd, FIRST_SD);
            old_VMTracking = lppd->doVMTracking;  
            lppd->doVMTracking = FALSE;  // hack!!
        }
        else if (lppd->SmsStartDoc == SECOND_SD)
        { // called at least once before
            InitPreStartDocDownload(lppd, SECOND_SD);
            old_VMTracking = lppd->doVMTracking;  
            lppd->doVMTracking = FALSE;  // hack!!
        }
        //else is normal/Old way call
       
        // OK, mark the state transition to a marked page.
    	if ( ( lppd->stCurrent == ST_EMPTY_PAGE ) ||
	         (fInDocLppd(lppd) && fChangeStateLppdSt(lppd, ST_MARKED_PAGE)) )
	    {
	        retVal = 1;  // maybe overwritten by failed SoftDownload().
	        if ( (TranFontInfo->dfType & TYPE_TRUETYPE) ||
				  (FontExtra->dwSoftFont)
	           )
	        {
#if 0  
// SAVE_RESTORE
// Since we don't send restore/save in downloading font, we don't need to do this.
	            BOOL temp2 = FALSE;

    	        // force "portability" to avoid restore/save that'll surprise the app.            

	            if (lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED) 
	            {
		            temp2 = TRUE;
		            lppd->lpPSExtDevmode->dm.enumDialect = DIA_PORTABLE;
	            }
#endif
	            InitializeDrvVariables(lppd->lpPSExtDevmode);

                VMRecoverDisable(lppd);
                START_PROFILE("CSoftFontLoad", PRFCSOFTFONTLOAD);
                // Get the return value - downlaod may fail !!

                lppd->fDBCS = 0; // initial this flag for every font.  
                // For FarEast Only for now. 12-1-1995
	            if (lppd->lpDownloadFaceStr!=NULL && lppd->lpDownloadFaceStr->wThird!=0)
	            {
                    if ((TranFontInfo->dfType &  PF_GLYPH_INDEX) &&
                        (TranFontInfo->dfType & TYPE_TRUETYPE) )
                    {
                        // Glyph-Index based TrueType font - supported by using the Highbyte:
                        lpTTFontInfo = (LPTTFONTINFO)((LPSTR)TranFontInfo + TranFontInfo->dfBitsOffset);
                        lpFontName = lpTTFontInfo->PSName;
                        lpTTFontInfo->HighByte = lppd->lpDownloadFaceStr->wSecond & 0xFF00 ;
                        //  tack on HighByte as part of FontName.
                        while(*lpFontName) lpFontName++ ;
                        wsprintf(lpFontName, "%2.2X", (lpTTFontInfo->HighByte >> 8) & 0x00FF);
                        fnameChanged = TRUE;
                    }
    	            retVal = CSoftFontLoad(lppd,TranFontInfo,lpTextXForm,
	                        (LPSTR)lppd->lpDownloadFaceStr->lpData, lppd->lpDownloadFaceStr->wThird);
	            }
	            else  // fall out of the ifdef !!! - so don't move the code around please!!!
    	        {
	                // Special case: if CSoftFontLoad is called with
	                //     NULL pointer to the string and size == 0, - 
	                //     download all characters of the font.
	                // Fixed bug Adobe - 50, Microsoft - 16078.
    	            //   16-Mar-1994  -by-   [olegs]
                    retVal = CSoftFontLoad(lppd,TranFontInfo,lpTextXForm, NULL, 0);
	            }
	            // We used to return 1 always - before 10-20-95. So we return fail
	            // only if failed and return 1 otherwise:
	            if (retVal>=0) retVal=1;  // just as before return 1 for success.
    	        STOP_PROFILE(PRFCSOFTFONTLOAD);
	            VMRecoverEnable(lppd);

#if 0  
// SAVE_RESTORE
// Since we don't send restore/save in downloading font, we don't need to do this.
      	        if (temp2)
	            {
		            lppd->lpPSExtDevmode->dm.enumDialect = DIA_SPEED;
	            }
#endif
	            InitializeDrvVariables(lppd->lpPSExtDevmode);
	        }

#ifdef  ADD_EURO
            else
            {
                retVal = CDeviceFontLoad(lppd,TranFontInfo,lpTextXForm);
	            // We used to return 1 always - before 10-20-95. So we return fail
	            // only if failed and return 1 otherwise:
	            if (retVal>=0) retVal=1;  // just as before return 1 for success.

            }
#endif
	    }                    // if(fInDocLppd ......)

        // reinit the size right after PERFORM - even the font is resident;
        if (lppd->lpDownloadFaceStr!=NULL && lppd->lpDownloadFaceStr->wThird) lppd->lpDownloadFaceStr->wThird = 0; 
        if (fnameChanged)
        {
           //  strip HighByte hexbytes from FontName.
           lpTTFontInfo = (LPTTFONTINFO)((LPSTR)TranFontInfo + TranFontInfo->dfBitsOffset);
           lpFontName = lpTTFontInfo->PSName;
           while(*lpFontName) lpFontName++ ;
           *(lpFontName - 2) = '\0' ;
        }

        // Pair up Initialize/Suspend inside this else part - fix bug 195830, PPeng, 2-21-1997
        if (lppd->SmsStartDoc==SECOND_SD)
        {
            // Suspend our dict - SendDrvSuspend()?
            EndPreStartDocDownload(lppd);
            // Force the state machine to the beginning of the earth 
            lppd->stCurrent = ST_ENABLED;
            lppd->doVMTracking = old_VMTracking;  // hack!!
        }

   }                       // else...

   return( retVal );
}


/*
 *      ESCEnablePairKerning
 *
 *      May be called anywhere between Enable() and Disable().
 *      If called after EndDoc, it has no effect.
 *      May be disabled. Never causes a state transition.
 */

short FAR PASCAL ESCEnablePairKerning(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
// This escape retrieves the current PairKern flag and returns it to GDI
// via the lpOutData buffer. In addition a new PairKern flag passed to
// us by GDI is saved for later use.

  LPPDEVICE     lppd     = (LPPDEVICE)lpDevice        ;
  LPEXTTEXTDATA lpetd    = (LPEXTTEXTDATA)lpInData    ;
  FLAG          fPairKern= (FLAG)lppd->text.bfPairKern;

  if(!lpetd) return(0)                          ;

  if (lpetd->lpInData && !fDisableGDILppd(lppd))       // Overwrite with new value
  {
	  lppd->text.bfPairKern=(BYTEFLAG)*((LPSHORT)lpetd->lpInData);
  }

  if(lpOutData)
  {
	 *((LPSHORT)lpOutData)=fPairKern             ;       // Return old value
  }

  return(1)                                     ;
}

/*
 *      ESCSetKernTrack
 *
 *      May be called anywhere between Enable() and Disable().
 *      If called after EndDoc, it has no effect.
 *      May be disabled. Never causes a state transition.
 */

short FAR PASCAL ESCSetKernTrack(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
// This escape retrieves the current Kern track and returns it to GDI
// via the lpOutData buffer. In addition a new Kern track passed to
// us by GDI is saved for later use.

  LPPDEVICE     lppd  = (LPPDEVICE)lpDevice     ;
  LPEXTTEXTDATA lpetd = (LPEXTTEXTDATA)lpInData ;
  short sCurrentTrack =  lppd->text.sTrack      ;       // Retrieved the current
				   // track.

  if(!lpetd) return(0)                          ;

  if(lpetd->lpInData && !fDisableGDILppd(lppd))
  {
	  lppd->text.sTrack=*((LPSHORT)lpetd->lpInData);     // Overwrite with the
  }                                                     // newly supplied value

  if(lpOutData)
  {
	  *((LPSHORT)lpOutData)=sCurrentTrack        ;       // Send back the former
  }                                                     // value.

  return(1)                                     ;       // Success
}

//this structure is used only by ESCSetAllJustValues() escape
//it is another instance of the EXTTEXTDATA data struct
//that GDI creates and fills.  Including, a pointer
//to a structure which varies depending on the escape...in
//this case EXTTEXTDATA.LPINDATA points to LPJUSTDATA

typedef struct _JUSTDATA
{
  short sCharExtra;
  WORD  wCharCount;
  short sWordExtra;
  WORD  wWordCount;
}
JUSTDATA, FAR * LPJUSTDATA;

void PASCAL CalcBreaks (LPJUSTBREAKREC lpJustBreak, short BreakExtra, WORD Count)
{

	 if (Count > 0) 
   {
	  /* Fill in JustBreak values.  May be positive or negative.
	   */
	  lpJustBreak->extra = BreakExtra / (short)Count;
	  lpJustBreak->rem = BreakExtra % (short)Count;
	  lpJustBreak->err = (short)Count / 2 + 1;
	  lpJustBreak->count = Count;
	  lpJustBreak->ccount = 0;
	  // Removed incorrect handling of negative adjustment
	  //  29-Mar-1993  -by-  [olegs]
	 } else 
   {
	  /* Count = zero, set up justification rec so the algorithm
	   * always returns zero adjustment.
	   */
	  lpJustBreak->extra = 0;
	  lpJustBreak->rem = 0;
	  lpJustBreak->err = 1;
	  lpJustBreak->count = 0;
	  lpJustBreak->ccount = 0;

	 }
}


/*
 *      ESCSetAllJustValues
 *
 *      May be called anywhere between Enable() and Disable().
 *      If called after EndDoc, it has no effect.
 *      May be disabled. Never causes a state transition.
 */

short FAR PASCAL ESCSetAllJustValues(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
// The EXTTEXTDATA structure is reproduced here for reference. This author
// doesn't believe that this Escape is documented to pass in this structure.
// However, previous versions of the printer driver behave as if GDI does
// does pass in this structure.

// typedef struct _EXTTEXTDATA
// {
//        short       sSize     ;
//        LP          lpInData  ;
//        LPPSFONTINFO  lpFontInfo;
//        LPTEXTXFORM lpXForm   ;
//        LPDRAWMODE  lpDrawMode;
// }
// EXTTEXTDATA, FAR *LPEXTTEXTDATA;

  LPPDEVICE     lppd      =(LPPDEVICE)lpDevice  ;
  LPEXTTEXTDATA lpExtText =(LPEXTTEXTDATA)lpInData;
  LPJUSTDATA    lpAllJust =(LPJUSTDATA)lpExtText->lpInData;
  LPPSFONTINFO  lpFontInfo=(LPPSFONTINFO)lpExtText->lpFontInfo    ;
  LPDRAWMODE    lpDrawMode=lpExtText->lpDrawMode    ;

  if(!lpExtText || lpFontInfo->dfCharSet==OEM_CHARSET)
  {
	  lppd->text.justType=JUST_standard          ;
	  return(0)                                  ;
  }

  if (fDisableGDILppd(lppd))    // GDI is disabled -- make this a NOP.
	  return(1);


  lpDrawMode->BreakErr = 1;
  lpDrawMode->TBreakExtra = 0;
  lpDrawMode->BreakExtra = 0;
  lpDrawMode->BreakRem = 0;
  lpDrawMode->BreakCount = 0;
  lpDrawMode->CharExtra = 0;


  if (lpFontInfo->dfCharSet == OEM_CHARSET) 
  {
   /*   Vector font: disable ALLJUSTVALUES and
	 *   return false.
	 */
	 lppd->text.justType = JUST_standard;
	 return(0);
  }

  if (lpExtText) 
  {

	 CalcBreaks (&lppd->text.jWord, lpAllJust->sWordExtra,
	  lpAllJust->wWordCount);
	 CalcBreaks (&lppd->text.jChar, lpAllJust->sCharExtra,
	  lpAllJust->wCharCount);

	 if (lppd->text.jWord.extra || lppd->text.jWord.rem || 
	  lppd->text.jChar.extra || lppd->text.jChar.rem ) 
   {
	  if (lppd->text.jChar.rem) 
	   {
		   lppd->text.justType = JUST_char;
	  } else 
	   {
		   lppd->text.justType = JUST_word;
	  }
	 } else 
   {
	  /* Zero justification == shut off ALLJUSTVALUES */
	  lppd->text.justType = JUST_standard;
	 }

  }
  return(1)                                     ;
}

//this is another strange escape!
//since the driver will use an ANSI mapping with the special
//publishing characters (single open and close quote, double open
//and close quote, bullet, en-dash, em-dash, non-breaking space)
//we will tell the app "Yes, we can do that"
//
/*
 *      ESCSetCharset
 *
 *      May be called anywhere between Enable() and Disable().
 *      If called after EndDoc, it has no effect.
 *      May be disabled. Never causes a state transition.
 */

short FAR PASCAL ESCSetCharset(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
   return(1);
}

//EscBeginPath
//
//Opens a path where the path consists of the OS_* (Output style) 
//primitives.  Paths can be contained within a path.

short FAR PASCAL ESCBeginPath(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
	 LPPDEVICE lppd ;
	 lppd = (LPPDEVICE) lpDevice ;

	 if( lppd->graphics.PathLevel == 0    )
	 {
	  lppd->job.bfIsCurrentPoint |= LINETO_FLAG ; // Remove
	  lppd->job.bfIsCurrentPoint ^= LINETO_FLAG ; //  the lineto flag
	 }
	 return  ( ++(lppd->graphics.PathLevel) );

}


short FAR PASCAL ESCClipToPath(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
  LPPDEVICE lppd ;

  lppd = (LPPDEVICE) lpDevice ;

   fChangeStateLppdSt(lppd, ST_MARKED_PAGE);
	 switch (LOWORD(*(LPDWORD)lpInData))
	 {
	 case CLIP_SAVE:  //gsave
	  CGraphSave(lppd);
	  break;

	 case CLIP_RESTORE: // grestore
	  CGraphRestore(lppd);
	  break;

	 case CLIP_INCLUSIVE:
	  //Clip to current path, either ALTERNATE or WINDING
     //CClip(lppd, HIWORD(*(LPDWORD)lpInData));
     //bug #265491 ignore the HIWORD
     CClip(lppd, FALSE);
  
	  break;

	 case CLIP_EXCLUSIVE:  //not supported
	  // Added to fix bug#267 in Harward Graphics.
	  // I don't know why, but this application uses 
	  // call to CLIP_TO_PATH to break the outline description
	  // of the characters.
	  //   20-Apr-1993  -by-  [olegs]
	  lppd->job.bfIsCurrentPoint |= LINETO_FLAG ; // Remove
	  lppd->job.bfIsCurrentPoint ^= LINETO_FLAG ; //  the lineto flag
	 default:
	  return 0;       /* not supported */
	 }
	 return 1;
}


short FAR PASCAL ESCEndPath(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
  DRAWMODE DrawMode;
  PBRUSH   PBrush;
  PPEN     PPen;
  WORD     renderMode;
  LPPDEVICE lppd ;

  lppd = (LPPDEVICE) lpDevice ;

   fChangeStateLppdSt(lppd, ST_MARKED_PAGE);
	 if( lppd->graphics.PathLevel == 0 ) // Something is wrong
	 {                              //  - return ERROR
	  return (-1);
	 }

	 --lppd->graphics.PathLevel ;

	 if(lppd->graphics.PathLevel == 0 )
	 {
	  renderMode = ((LPPATHINFO)lpInData)->RenderMode;
	  DrawMode.bkMode = ((LPPATHINFO)lpInData)->BkMode;
	  DrawMode.bkColor = ((LPPATHINFO)lpInData)->BkColor;
	   
	  if (renderMode == RM_CLOSED)
	  {
		   RealizeBrush(lppd,
			 (LPLOGBRUSH)&((LPPATHINFO)lpInData)->Brush,
				  (LPPBRUSH) &PBrush, NULL);

		   CDoBrush(lppd, (LPPBRUSH) &PBrush, (LPDRAWMODE)&DrawMode) ;
	  }
	  // Always realize the pen
	  //  Fixed ug 26 on 22-Feb-1993  -by-   [olegs]
	  if( renderMode != RM_NO_DISPLAY )
	  {
		   RealizePen(lppd, (LPLOGPEN)&((LPPATHINFO)lpInData)->Pen,
			 (LPPPEN) &PPen);
		   CDoPen(lppd, (LPPPEN) &PPen, (LPDRAWMODE)&DrawMode) ;
	  }
	 }
	 CEndPath(lppd, (LPPATHINFO)lpInData, (LPDRAWMODE)&DrawMode);
	 return ( lppd->graphics.PathLevel) ;
}

short FAR PASCAL ESCExtDeviceCaps(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
  if( lpOutData)
	 switch(*(WORD FAR *)lpInData)
	 {
	  case PATH_CAPS:
		   *(LPDWORD) lpOutData = PATH_ALTERNATE | PATH_WINDING | PATH_INCLUSIVE;
		   break;
	  case POLYGON_CAPS:
		   *(LPDWORD)lpOutData = 1500L;
		   break;
	  default:  //Capability not supported
		   return 0;
	 }
  return 4;     // Number of bytes required for storage
}

short FAR PASCAL ESCRestoreCTM(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
   if(!lpDevice->graphics.XformLevel)
      return(-1) ;

  fChangeStateLppdSt(lpDevice, ST_MARKED_PAGE);
  CRestoreCTM((LPPDEVICE)lpDevice);
  return (lpDevice->graphics.XformLevel);
}

short FAR PASCAL ESCSaveCTM(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
  CSaveCTM((LPPDEVICE)lpDevice);
  return (lpDevice->graphics.XformLevel);
}

/*
 *      ESCSetArcDirection
 *
 *      May be called anywhere between StartDoc and EndDoc.
 *      May be disabled. Never causes a state transition.
 */

short FAR PASCAL ESCSetArcDirection(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
  BYTE      NewArcDirection                     ;
  BYTE      OldArcDirection                     ;
  LPPDEVICE lppd                                ;

  lppd            =  (LPPDEVICE)lpDevice        ;       // Load lppd structure

  if (!fInDocLppd(lppd))        // We aren't between StartDoc and EndDoc -- fail
	  return(-1);

  OldArcDirection = lppd->graphics.bArcDirection;       // Retrieve the old value
  NewArcDirection = *(LPBYTE)lpInData           ;       // Get the new value
  if(NewArcDirection != OldArcDirection)
  {
	  lppd->graphics.bArcDirection=NewArcDirection;      // Save the new direction
	  CArcDirection(lppd,NewArcDirection)             ;       // Send the token
  }
  return((short)OldArcDirection)                ;       // Return the old value
}


short FAR PASCAL ESCSetBackgroundColor(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)    /* implemented? */
{
	 return(0);
}


/*
 *      ESCSetPolyMode
 *      May be called anywhere between StartDoc and EndDoc.
 *      May be disabled. Never causes a state transition.
 */

short FAR PASCAL ESCSetPolyMode(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
  BYTE      NewPolyMode                         ;
  BYTE      OldPolyMode                         ;
  LPPDEVICE lppd                                ;

  lppd        =  (LPPDEVICE)lpDevice            ;       // Load lppd structure

  if (!fInDocLppd(lppd))        // We aren't between StartDoc and EndDoc -- fail
	  return(-1);

  OldPolyMode =  lppd->graphics.bPolyMode       ;       // Retrieve the old value
  NewPolyMode = *(LPBYTE)lpInData               ;       // Get the new value
  if(NewPolyMode != OldPolyMode)
  {
	  lppd->graphics.bPolyMode=NewPolyMode       ;       // Save the new PolyMode
	  CPolyMode(lppd,NewPolyMode)                ;       // Send the token
  }
  return((short)OldPolyMode)                    ;       // Return the old value
}

short FAR PASCAL ESCSetScreenAngle(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
  return CSetScreenAngle(lpDevice,lpInData); 
}

short FAR PASCAL ESCSetSpread(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
	   short iSpread;
	   short retVal;

	  retVal = FALSE;

	  if(lpInData)
	   {
		   iSpread = * (short FAR *) lpInData;
		CSetSpread((LPPDEVICE) lpDevice,iSpread);
	   retVal = TRUE;
	  }

	  return retVal;
}


short FAR PASCAL ESCTransformCTM(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
  CTransformCTM((LPPDEVICE)lpDevice, (LPDWORD)lpInData);
  return TRUE;
}


short FAR PASCAL ESCSetClipBox(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
  CClipBox((LPPDEVICE)lpDevice, (LPRECT)lpInData);
  return 1;
}

short FAR PASCAL ESCSetBounds(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
	 POINT  pointA, pointB;
	 int    swap;
    PSDEVMODE dm = lpDevice->lpPSExtDevmode->dm;
    LPPRINTERINFO lpPrinterInfo = (LPPRINTERINFO)lpDevice->lpWPXblock->WPXprinterInfo;
    WORD   paperIndex;
    LPSTR  lpPPDVersion;

	  // lpbIn  is a rectangle in device coords.
	  // EpsRect will be in default Postscript coords.
	  pointA.x = ((LPRECT)lpInData)->left;
	  pointA.y = ((LPRECT)lpInData)->bottom;
	  pointB.x = ((LPRECT)lpInData)->right;
	  pointB.y = ((LPRECT)lpInData)->top;
 
	  GDItoDefaultPS(lpDevice->psmatrix, &pointA.x, &pointA.y);
	  GDItoDefaultPS(lpDevice->psmatrix, &pointB.x, &pointB.y);

	  if(pointA.y > pointB.y)     // need to swap
	  {
		swap = pointA.y;
		pointA.y = pointB.y;
		pointB.y = swap;
	  }

	  if(pointA.x > pointB.x)  // need to swap
	  {
		swap = pointA.x;
		pointA.x = pointB.x;
		pointB.x = swap;
	  }
	  ((LPPDEVICE)lpDevice)->bbox.top    = pointB.y;
	  ((LPPDEVICE)lpDevice)->bbox.bottom = pointA.y;
	  ((LPPDEVICE)lpDevice)->bbox.right  = pointB.x;
	  ((LPPDEVICE)lpDevice)->bbox.left   = pointA.x;

	  // set flag in PDEVICE to let TRANSLATE side know this ESC was called
	  ((LPPDEVICE)lpDevice)->job.bfESCSetBounds = TRUE;

     KeywordGetCurrentOption((LPPDEVICE)lpDevice, IND_PAPERINFO, &paperIndex) ;
     lpPPDVersion = StringRefToLPBYTE((LPPDEVICE)lpDevice, lpPrinterInfo->PPDVersion.dword);
     if ((paperIndex == lpPrinterInfo->devcaps.CustomPageSize)
         && (dm.currentCustPaper != APP_DEFINED)
         && dm.custPaper[dm.currentCustPaper].Transverse
         && (lstrcmp(lpPPDVersion, "4.3") < 0)          
         && (lpPrinterInfo->custpageinfo.isCutSheet))
     {
         WORD  temp;
     
	      temp = ((LPPDEVICE)lpDevice)->bbox.top;
	      ((LPPDEVICE)lpDevice)->bbox.top = ((LPPDEVICE)lpDevice)->bbox.right;
	      ((LPPDEVICE)lpDevice)->bbox.right  = temp;
     }
  return 1;
}




short FAR PASCAL ESCSetMirrorMode(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
	 return(0);//Not supported yet
}

short FAR PASCAL ESCSetScreenFrequency(LPPDEVICE lpDevice,LPFREQUENCY lpInData,LPFREQUENCY lpOutData)
{
	 return CSetScreenFrequency(lpDevice,lpInData,lpOutData); 
}

//
//-------------------------------------------------------------------------
// Local utility routines:
//-------------------------------------------------------------------------
#if 0
short FAR PASCAL MatchPaperSize(LPPDEVICE lppd, LPKEYWORDLISTREC PPDList, LPRECT lpTargetRect,
   int FAR *PPD_media_index, int FAR *orientation, BOOL FAR *nomargins_flag)
/**********************************************************************
*
*  function:
*       This routine searches the list of paper types supported by a
*       printer and identifies which one has an imageable area matching
*       a specified rectangle. It tests for variations in orientation and
*       margins.
*
*  parameters:
*       PPDList - list of PPD keywords, includes PAGESIZE keyword
*       lpTargetRect - ptr to the rectangle we are trying to match
*       PPD_media_index - ptr to index into list of PAGESIZE options
*          of the matching paper
*       orientation - ptr to matching orientation
*       nomargins_flag - ptr to flag indicating whether paper has margins
*
*  returns:
*       RC_ok if match is found, else RC_fail
*
************************************************************************/
{
   short num_paper_sizes, i, old_page_index, rc ;
   short s1, s2 ; //dummies
   RECT rect ;
   POINT pt ;
   char keyword[MAX_KEYWORD_LEN] ;
   BOOL match_flag = FALSE ;
   BYTE old_orientation;

   //Find out how many paper sizes are supported by the current printer.
   LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_PAGESIZE, keyword, sizeof(keyword)) ;
   KeywordListGetOptionRange(lppd, PPDList, keyword, &num_paper_sizes) ;

   //Save media option and orientation so we can restore it when through.
   KeywordListGetCurrentOption(lppd, PPDList, keyword, NULL, 0, &old_page_index) ;
   old_orientation = lppd->lpPSExtDevmode->dm.PaperOrient;

   //Keep checking supported paper sizes until a match is found or all checked.

   lppd->lpPSExtDevmode->dm.PaperOrient = DMORIENT_PORTRAIT;
   i = 0 ;
   while ((i < num_paper_sizes) && (!match_flag))
   {
	   //Change media option so GetPPDPaperMetrics routine will describe
	   // correct paper type.
	   KeywordListSetCurrentOption(lppd, PPDList, keyword, NULL, i) ;

	   //Get imageable area for i'th paper type.
	   GetPPDPaperMetrics(lppd, &(lppd->drvState), &pt, &rect, &s1, &s2) ;

	   //Compare target rect with i'th paper type.
	   (*PPD_media_index) = i ;
	   if (EqualRect(lpTargetRect, &rect))
	   {
	   //Target rect matches portrait orientation of i'th paper type.
	   (*orientation) = DMORIENT_PORTRAIT ;
	   (*nomargins_flag) = FALSE ;
	   match_flag = TRUE ;
	   }
	   else
	   {
	   FlopRect(&lppd->drvState, &rect, &rect) ;    // Convert to landscape.
	   if (EqualRect(lpTargetRect, &rect))
	   {
		   //Target rect matches landscape orientation of i'th paper type.
		   (*orientation) = lppd->drvState.fOrientRotate ? DMORIENT_ROT_LANDSCAPE : DMORIENT_LANDSCAPE ;
		   (*nomargins_flag) = FALSE ;
		   match_flag = TRUE ;
	   }
	   else
	   {
		   SetRect(&rect, 0, 0, pt.x, pt.y) ;//Construct full page rect.
		   if (EqualRect(lpTargetRect, &rect))
		   {
		  //Target rect matches full page portrait orientation of i'th paper type.
		  (*orientation) = DMORIENT_PORTRAIT ;
		  (*nomargins_flag) = TRUE ;
		  match_flag = TRUE ;
		   }
		   else
		   {
		  FlopRect(&lppd->drvState, &rect, &rect) ;//Convert to landscape.
		  if (EqualRect(lpTargetRect, &rect))
		  {
			  //Target rect matches full page landscape orientation of
			  // i'th paper type.
			  (*orientation) = lppd->drvState.fOrientRotate ? 
						 DMORIENT_ROT_LANDSCAPE : DMORIENT_LANDSCAPE ;
			  (*nomargins_flag) = TRUE ;
			  match_flag = TRUE ;
		  }
		   }  //else (!EqualRect)
		}     //else (!EqualRect)
	   }         //else (!EqualRect)

	   i++ ;
   } //while

   //Restore media option and orientation.
   KeywordListSetCurrentOption(lppd, PPDList, keyword, NULL, old_page_index) ;
   lppd->drvState.bOrientation = old_orientation;

   rc = RC_ok ;
   if (!match_flag)
	   rc = RC_fail ;

   return(rc) ;
}
#endif

