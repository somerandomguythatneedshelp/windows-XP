/*****************************************************************************/
/*                                                                           */
/* Module Name: SPIN.C                                                       */
/*                                                                           */
/*****************************************************************************/
#include <windows.h>
#include "spin.h"

#define CBWNDEXTRA            (14)
#define GWL_TOPRANGE          (0)
#define GWL_BOTTOMRANGE       (4)
#define GWL_CRNTVALUE         (8)
#define GWW_TRIANGLEDOWN      (12)

#define SPNM_SCROLLVALUE      (WM_USER + 500)

   // Time delay between scrolling events in milliseconds.
#define TIME_DELAY            (50)
#define FIRST_TIME_DELAY      (150)

typedef enum { TD_NONE, TD_UP, TD_DOWN } TRIANGLEDOWN;

char _szControlName[] = "LongSpin";

LONG FAR PASCAL LongSpinWndProc (HWND hWnd, WORD wMsg, WORD wParam, LONG lParam);

/*  call to initialize the custom control
 */
BOOL FAR PASCAL RegisterLongSpinControlClass (HANDLE hInstance) {
   WNDCLASS wc;
   wc.style         = CS_GLOBALCLASS | CS_HREDRAW | CS_VREDRAW;
   wc.lpfnWndProc   = (WNDPROC)LongSpinWndProc;
   wc.cbClsExtra    = 0;
   wc.cbWndExtra    = CBWNDEXTRA;
   wc.hInstance     = hInstance;
   wc.hIcon         = NULL;
   wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
   wc.hbrBackground = COLOR_BTNFACE + 1;
   wc.lpszMenuName  = NULL;
   wc.lpszClassName = _szControlName;
   return(RegisterClass(&wc));
}

/*  call to un-initialize the custom control
 */
BOOL FAR PASCAL UnRegisterLongSpinControlClass (HANDLE hInstance) {
   UnregisterClass(_szControlName, hInstance);
   return TRUE;
}
 
LONG NEAR PASCAL NotifyParent (HWND hWnd, WORD wNotifyCode)
{
   LONG lResult;
   lResult = SendMessage(GetParent(hWnd), WM_COMMAND,
               GetWindowWord(hWnd, GWW_ID),
               MAKELONG(hWnd, wNotifyCode));
   return(lResult);
}

VOID ShadeButton (HDC hDC, LPRECT prc, BOOL bDown)
{
    DWORD       dwShadowColor ;
    HBRUSH      hbrushShadow ;
    HBRUSH      hbrushHiLite ;
    RECT        trect ;

    dwShadowColor = GetSysColor (COLOR_BTNSHADOW) ;
    hbrushShadow = CreateSolidBrush (dwShadowColor) ;
    hbrushHiLite = GetStockObject (WHITE_BRUSH) ;

    if (bDown)
    {
        CopyRect (&trect, prc) ;
        trect.right = trect.left + 1 ;
        FillRect (hDC, &trect, hbrushShadow) ;

        CopyRect (&trect, prc) ;
        trect.bottom = trect.top + 1 ;
        FillRect (hDC, &trect, hbrushShadow) ;
    }
    else
    {
        CopyRect (&trect, prc) ;
        trect.left = trect.right - 1 ;
        FillRect (hDC, &trect, hbrushShadow) ;
    
        CopyRect (&trect, prc) ;
        trect.top = trect.bottom - 1 ;
        FillRect (hDC, &trect, hbrushShadow) ;
        
            // draw the highlighting on the left and top sides

        CopyRect (&trect, prc) ;
        trect.right = trect.left + 1 ;
        trect.bottom -= 1 ;
        FillRect (hDC, &trect, hbrushHiLite) ;
        
        CopyRect (&trect, prc) ;
        trect.bottom = trect.top + 1 ;
        trect.right -= 1 ;
        FillRect (hDC, &trect, hbrushHiLite) ;
    }

    DeleteObject (hbrushShadow) ;
}        

VOID DrawSpin (HWND hWnd, TRIANGLEDOWN tState)
{
    RECT        rc, trect ;
    HDC         hDC ;
    int         nX, nY ;
    DWORD       dwBackgroundColor ;
    HBRUSH      hbrushBackground ;

    hDC = GetDC (hWnd) ;

    GetClientRect (hWnd, &rc) ;

    dwBackgroundColor = GetSysColor (COLOR_BTNFACE) ;
    hbrushBackground = CreateSolidBrush (dwBackgroundColor) ;
    FillRect (hDC, &rc, hbrushBackground) ;
    DeleteObject (hbrushBackground) ;

    nX = rc.right / 2 ;
    nY = rc.bottom / 2 ;

       // Draw middle separator bar
    MoveTo (hDC, 0, nY) ;
    LineTo (hDC, rc.right, nY) ;

    SelectObject (hDC, GetStockObject (BLACK_BRUSH)) ;

       // Draw top triangle & fill it in
    MoveTo (hDC, nX, 2) ;
    LineTo (hDC, rc.right - 3, nY - 3) ;
    LineTo (hDC, 2, nY - 3) ;
    LineTo (hDC, nX, 2) ;
    FloodFill (hDC, nX, nY - 4, RGB (0, 0, 0)) ;

       // Draw bottom triangle & fill it in
    MoveTo (hDC, 2, nY + 3) ;
    LineTo (hDC, rc.right - 3, nY + 3) ;
    LineTo (hDC, nX, rc.bottom - 3) ;
    LineTo (hDC, 2, nY + 3) ;
    FloodFill (hDC, nX, nY + 4, RGB (0, 0, 0)) ;

    CopyRect (&trect, &rc) ;
    trect.bottom = nY ;
    ShadeButton (hDC, &trect, tState == TD_UP) ;

    CopyRect (&trect, &rc) ;
    trect.top = nY+1 ;
    ShadeButton (hDC, &trect, tState == TD_DOWN) ;

    ReleaseDC (hWnd, hDC) ;
}

/*  Custom control's window function
 */
LONG FAR PASCAL LongSpinWndProc (HWND hWnd, WORD wMsg, WORD wParam, LONG lParam) 
{
    LONG lResult = 0 ;
    POINT pt ;
    RECT rc ;
    LONG nCrntVal, nNewVal ;
    TRIANGLEDOWN TriangleDown, OldTriangleDown ;
    LONG dwTime, dwTopRange, dwBottomRange, dwDelAmount ;
    PAINTSTRUCT ps ;
    BOOL fWrap ;

    switch (wMsg) 
    {
        case WM_GETDLGCODE :
            lResult = DLGC_STATIC ;
            break ;

        case WM_CREATE :   // lParam == &CreateStruct
            SendMessage (hWnd, SPNM_SETTOPRANGE, 0, 0) ;
            SendMessage (hWnd, SPNM_SETBOTTOMRANGE, 0, 0) ;
            SendMessage (hWnd, SPNM_SETCRNTVALUE, 0, 0) ;

            if (!(((CREATESTRUCT FAR *)lParam)->cx & 1))
            {
                ((CREATESTRUCT FAR *)lParam)->cx -= 1 ;

                MoveWindow (hWnd,
                            ((CREATESTRUCT FAR *)lParam)->x,
                            ((CREATESTRUCT FAR *)lParam)->y,
                            ((CREATESTRUCT FAR *)lParam)->cx,
                           ((CREATESTRUCT FAR *)lParam)->cy,
                            FALSE) ;
            }

            MoveWindow (hWnd,
                        ((CREATESTRUCT FAR *)lParam)->x,
                        ((CREATESTRUCT FAR *)lParam)->y,
                        ((CREATESTRUCT FAR *)lParam)->cx,
                        ((CREATESTRUCT FAR *)lParam)->cx+6,
                        FALSE) ;
            break ;

        case WM_PAINT :
            BeginPaint (hWnd, &ps) ;
            DrawSpin (hWnd, GetWindowWord (hWnd, GWW_TRIANGLEDOWN)) ;
            EndPaint (hWnd, &ps) ;
            break ;

        case WM_LBUTTONDOWN :
                // Get coordinates for the Spin Button's window.
            GetClientRect (hWnd, &rc) ;

            if ((int) HIWORD (lParam) < rc.bottom / 2) // Up arrow
            {
                TriangleDown = TD_UP ;
            } 
            else 
            {
                TriangleDown = TD_DOWN ;
            }

                // Save which triangle the mouse was clicked over.
            SetWindowWord (hWnd, GWW_TRIANGLEDOWN, TriangleDown) ;

            DrawSpin (hWnd, TriangleDown) ;

            SetCapture (hWnd) ;

            dwDelAmount = FIRST_TIME_DELAY ;    // initial delay is longer

            NotifyParent(hWnd, SPNN_FIRSTTIMEDOWN) ;

            dwTime = GetTickCount() - 10 ;      // insure that this happens once

            do 
            {
                if (dwTime > (LONG)GetTickCount())    // If not time yet, skip
                {
                    continue ;
                }

                    // scroll value in Spin Button.
                SendMessage (hWnd, SPNM_SCROLLVALUE, 0, 0l) ;

                    // Get next time to scroll
                dwTime = GetTickCount() + dwDelAmount ;
                dwDelAmount = TIME_DELAY ;    // reset delay after first time

                    // continue while left mouse button is still down.
            } 
            while (GetAsyncKeyState (VK_LBUTTON) & 0x8000) ;

            ReleaseCapture () ;

            SetWindowWord (hWnd, GWW_TRIANGLEDOWN, TD_NONE) ;

                // Invalidate the entire window.  This will force Windows to send
                // a WM_PAINT message restoring the window to its original colors.
            InvalidateRect (hWnd, NULL, TRUE) ;
            break ;

        case SPNM_SCROLLVALUE :

                // Get the location of the mouse.
            GetCursorPos (&pt) ;

                // Convert the point from screen coordinates to client coordinates.
            ScreenToClient (hWnd, &pt) ;

                // If the point is NOT is Spin's client area, nothing to do.
            GetClientRect (hWnd, &rc) ;
            if (!PtInRect (&rc, pt)) 
            {
                break ;
            }

                // Get the Spin Button's current value and range, 
            nNewVal = SendMessage (hWnd, SPNM_GETCRNTVALUE, 0, 0l) ;
            nCrntVal = nNewVal ;
            dwTopRange = SendMessage(hWnd, SPNM_GETTOPRANGE, 0, 0l) ;
            dwBottomRange = SendMessage(hWnd, SPNM_GETBOTTOMRANGE, 0, 0l) ;

                // Get Spin Button's styles and test if the "wrap" flag is set.
            fWrap = (BOOL) (GetWindowLong(hWnd, GWL_STYLE) & SPNS_WRAP) ;

                // Determine whether the up- or down- triangle was selected.
            OldTriangleDown = GetWindowWord (hWnd, GWW_TRIANGLEDOWN) ;

                // Determine whether the mouse is now over the up- or down- triangle.
            TriangleDown = (pt.y < rc.bottom / 2) ? TD_UP : TD_DOWN ;

                // If the user has switched triangles, invert the entire rectangle.
                // This restores the half that was inverted in the WM_LBUTTONDOWN
                // message and inverts the new half.
            if (OldTriangleDown != TriangleDown) 
            {
                DrawSpin (hWnd, TriangleDown) ;
            }

            if (TriangleDown == TD_UP) 
            {
                // If value is not at top of range, increment it.
                if (dwTopRange > nCrntVal) 
                {
                    nNewVal++ ;
                }
                else 
                {
                    // If value at top of range and the "wrap" flag is set, 
                    // set the value to the bottom of the range.
                    if (fWrap) 
                    {
                        nNewVal = dwBottomRange ;
                    }
                }
            } 
            else 
            {
                    // If value is not at bottom of range, decrement it.
                if (dwBottomRange < nCrntVal) 
                {
                    nNewVal-- ;
                }
                else 
                {
                        // If value at bottom of range and the "wrap" flag 
                        //  is set, set the value to the top of the range.
                    if (fWrap) 
                    {
                        nNewVal = dwTopRange ;
                    }
                }
            }

                // If the value has been changed, set the new value.
            if (nNewVal != nCrntVal)
            {
                SendMessage (hWnd, SPNM_SETCRNTVALUE, 0, nNewVal) ;
            }

                // Set the new triangle that is down for the next call to here.
            SetWindowWord (hWnd, GWW_TRIANGLEDOWN, TriangleDown) ;
            break ;

        case SPNM_SETTOPRANGE :
            SetWindowLong (hWnd, GWL_TOPRANGE, lParam) ;
            break ;

        case SPNM_SETBOTTOMRANGE :
            SetWindowLong (hWnd, GWL_BOTTOMRANGE, lParam) ;
            break ;

        case SPNM_GETTOPRANGE :
            lResult = GetWindowLong (hWnd, GWL_TOPRANGE) ;
            break ;

        case SPNM_GETBOTTOMRANGE :
            lResult = GetWindowLong (hWnd, GWL_BOTTOMRANGE) ;
            break ;

        case SPNM_SETCRNTVALUE :
            SetWindowLong (hWnd, GWL_CRNTVALUE, lParam) ;
            NotifyParent(hWnd, SPNN_VALUECHANGE) ;
            break ;

        case SPNM_GETCRNTVALUE :
            lResult = GetWindowLong (hWnd, GWL_CRNTVALUE) ;
            break ;

        default :
            lResult = DefWindowProc (hWnd, wMsg, wParam, lParam) ;
            break ;
   }
   return (lResult) ;
}
