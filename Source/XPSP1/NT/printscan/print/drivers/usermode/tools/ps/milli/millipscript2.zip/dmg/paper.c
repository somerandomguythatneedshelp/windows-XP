/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PAPER.C                                                      */
/*                                                                           */
/* Description: This module contains the functions for the Paper Options     */
/*              Dialog                                                       */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "apd42map.hh"

#pragma code_seg(_DIALOGSSEG)

#define WM_DRAW_LOGO   WM_USER + 1

#define UPDATE_ORIENTATION       0x0001
#define UPDATE_DUPLEX            0x0002
#define UPDATE_PAPERSOURCE       0x0004
#define UPDATE_PAPERSIZE         0x0008
#define UPDATE_MEDIATYPE         0x0010
#define UPDATE_OUTPUTBIN         0x0020
#define UPDATE_CUSTOM            0x0040
#define UPDATE_COLLATE           0x0080
#define UPDATE_REVERSEORDER      0x0100

#define UPDATE_NONUICONSTRAINED  UPDATE_ORIENTATION | UPDATE_COLLATE | UPDATE_REVERSEORDER
#define UPDATE_UICONSTRAINED     UPDATE_PAPERSOURCE | UPDATE_PAPERSIZE | \
                                 UPDATE_CUSTOM | UPDATE_MEDIATYPE | \
                                 UPDATE_OUTPUTBIN | UPDATE_DUPLEX
#define UPDATE_ALL               UPDATE_UICONSTRAINED | UPDATE_NONUICONSTRAINED

#define SHOW_ORIENTATION         0
#define SHOW_PAPERSIZES          1
#define SWAP(a, b, c)            {c=a; a=b; b=c;}

char decimalSeparator[4];

/*****************************************************************************/
/*                 InitPaperDlg                                              */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to Paper dialog                                     */
/*   LPDRIVERINFO lpDrvInfo -- points to DRIVERINFO structure                */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

void NEAR PASCAL InitPaperDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    DWORD dwUIFlags = lpDrvInfo->dwUIFlags[DI_PAPER];
    int   yOffset = 0, xOffset = 0, y;

    PositionControls(hDlg, NULL, NULL, dwUIFlags&DI_CUSTOM,
                     ID_CUSTOM_PAPER, ID_CUSTOM_PAPER, NULL);

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_PAPERSIZE,
                     ID_TEXT_SIZELIST, ID_SIZELIST, ID_GROUP_ORIENTATION);

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_ORIENTATION,
                     ID_GROUP_ORIENTATION, ID_ROTATED, ID_GROUP_PAPER_CONTROL);

    y = yOffset;
    PositionControls(hDlg, NULL, (LPINT)&y, dwUIFlags&DI_PAPERSIZE,
                     ID_GROUP_DIMENSION, ID_VAL_RIGHT, NULL);

    y = yOffset;
    PositionControls(hDlg, NULL, (LPINT)&y, dwUIFlags&DI_PAPERSIZE,
                     ID_TEXT_WIDTH, ID_TEXT_RIGHT, NULL);

    PositionControls(hDlg, NULL, NULL, dwUIFlags&DI_PAPERSIZE,
                     ID_MARGINS, ID_MARGINS, NULL);

    if (dwUIFlags&(DI_DUPLEX | DI_COLLATE | DI_REVERSEORDER))
    {
        PositionControls(hDlg, NULL, (LPINT)&yOffset, TRUE,
                         ID_GROUP_PAPER_CONTROL, ID_DUPLEXLIST, ID_TEXT_SOURCELIST);

        y = 0;
        PositionControls(hDlg, NULL, (LPINT)&y, dwUIFlags&DI_COLLATE,
                         ID_COLLATE, ID_COLLATE, ID_REVERSE_ORDER);

        PositionControls(hDlg, NULL, (LPINT)&y, dwUIFlags&DI_REVERSEORDER,
                         ID_REVERSE_ORDER, ID_REVERSE_ORDER, ID_TEXT_DUPLEXLIST);

        PositionControls(hDlg, NULL, (LPINT)&y, dwUIFlags&DI_DUPLEX,
                         ID_TEXT_DUPLEXLIST, ID_DUPLEXLIST, NULL);
    }
    else
    {
        PositionControls(hDlg, NULL, NULL, FALSE,
                     ID_GROUP_PAPER_CONTROL, ID_GROUP_PAPER_CONTROL, NULL);

        PositionControls(hDlg, NULL, (LPINT)&yOffset, FALSE,
                         ID_PAPER_PICTURE, ID_DUPLEXLIST, ID_TEXT_SOURCELIST);
    }

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_PAPERSOURCE,
                     ID_TEXT_SOURCELIST, ID_SOURCELIST, ID_TEXT_BINLIST);

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_OUTPUTBIN,
                     ID_TEXT_BINLIST, ID_BINLIST, ID_TEXT_TYPELIST);

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_MEDIATYPE,
                     ID_TEXT_TYPELIST, ID_TYPELIST, NULL);
}


/*****************************************************************************/
/*                 BuildPaperDlg                                             */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to Paper dialog                                     */
/*   LPDRIVERINFO lpDrvInfo -- points to DRIVERINFO structure                */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

void NEAR PASCAL BuildPaperDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
                (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    DWORD          dwUIFlags = lpDrvInfo->dwUIFlags[DI_PAPER];
    int            curr_ctrl_opt_id, i;
    char           tmpstring[64];
    char           strBuff[STR_BUFF_LEN];

    if (dwUIFlags & DI_PAPERSOURCE)
    {
        BuildCBOptList(lpDrvInfo, hDlg, IND_INPUTSLOTINFO, ID_SOURCELIST);
    }

    if (dwUIFlags & DI_PAPERSIZE)
    {
        SendDlgItemMessage(hDlg, ID_SIZELIST, LB_SETCOLUMNWIDTH,
                           32*2, 0L);
        BuildCBOptList(lpDrvInfo, hDlg, IND_PAPERINFO, ID_SIZELIST) ;
    }

    if (dwUIFlags & DI_CUSTOM)
    {
        // Show the custom paper button
        ShowWindow(GetDlgItem(hDlg, ID_CUSTOM_PAPER), SW_SHOWNA);

        // Remove the CustomPaper item that a bug in the WPX handler left in
        // I was talked into removing it here after the fact. The proper
        // way of doing it is to fix the WPX handler.
        i = (int)SendDlgItemMessage(hDlg, ID_SIZELIST, LB_GETCOUNT, 0, 0L);
        SendDlgItemMessage(hDlg, ID_SIZELIST, LB_DELETESTRING, i - 1, 0L);

        for (i=0; i<NUM_CUST_SIZES; i++)
        {
            curr_ctrl_opt_id = LOWORD(SendDlgItemMessage(hDlg, ID_SIZELIST,
                                                         LB_ADDSTRING, 0,
               (DWORD)((LPSTR)lpPSExtDevmode->dm.custPaper[i].CustomName)));

            // Use -(i+1) to mark this option as special.
            SendDlgItemMessage(hDlg, ID_SIZELIST, LB_SETITEMDATA,
                               curr_ctrl_opt_id, (LONG) -(i+1)) ;
        }

        if (lpPSExtDevmode->dm.currentCustPaper == APP_DEFINED)
        {
            LoadDrvrString(ghDriverMod, IDS_CUSTOM_OTHER_PAPER, tmpstring,
                           sizeof(tmpstring));
            curr_ctrl_opt_id = LOWORD(SendDlgItemMessage(hDlg, ID_SIZELIST,
                              LB_ADDSTRING, 0, (DWORD)(LPSTR)tmpstring));

            SendDlgItemMessage(hDlg, ID_SIZELIST, LB_SETITEMDATA,
                               curr_ctrl_opt_id,(LONG)-(APP_DEFINED + 1));
        }
    }

    if (dwUIFlags & DI_MEDIATYPE)
    { /* We can do MediaType */
        BuildCBOptList(lpDrvInfo, hDlg, IND_MEDIATYPEINFO, ID_TYPELIST);
    }

    if (dwUIFlags & DI_OUTPUTBIN)
    { /* We can do OutputBin */
        BuildCBOptList(lpDrvInfo, hDlg, IND_OUTPUTBININFO, ID_BINLIST );
    }

    if (dwUIFlags & DI_DUPLEX)
    {
        SendDlgItemMessage(hDlg, ID_DUPLEXLIST, CB_RESETCONTENT, 0, 0L);

        for (i=IDS_BASE_DUPLEX_NAME; i<= IDS_BASE_DUPLEX_NAME+2; i++)
        {
            LoadString(ghDriverMod, i, strBuff, sizeof(strBuff));
            SendDlgItemMessage(hDlg, ID_DUPLEXLIST, CB_ADDSTRING, 0,
                           (LPARAM)(LPSTR)strBuff);
        }
    }

}

/*****************************************************************************/
/*                 SetPaperOrientation                                       */
/* Purpose:                                                                  */
/*   Shows icon and check radio button appropriate to current orientation    */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to Paper dialog                                     */
/*   PAP_ORIENT orientation -- Orientation selected                          */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

VOID NEAR PASCAL SetPaperOrientation(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    HANDLE hicon;
    PAP_ORIENT orientation = lpDrvInfo->pDev.lpPSExtDevmode->dm.PaperOrient;

    CheckRadioButton( hDlg, ID_PORTRAIT, ID_LANDSCAPE,
                     orientation == OR_PORTRAIT ? ID_PORTRAIT : ID_LANDSCAPE);
    CheckDlgButton(hDlg, ID_ROTATED, orientation == OR_ROTLANDSCAPE);
    EnableWindow(GetDlgItem(hDlg,ID_ROTATED), orientation != OR_PORTRAIT);

    if (orientation != OR_PORTRAIT)
    {
        /* Check which way icon should be rotated */
        LPPRINTERINFO lpPrinterInfo =
            (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);

        if (! lpPrinterInfo->devcaps.landscapeOrientPlus90)
            orientation ^= 3;   /* Toggles between values 1 & 2 */
    }
    hicon = lpDrvInfo->lpGetIconResource(orientation + PORTRAIT_ICON);

#if 1
    SendDlgItemMessage(hDlg, ID_ICON, STM_SETICON, (WORD)hicon, 0L);
#else
    if (IsWin31())
    { /* Win 3.1 and above */
        SendDlgItemMessage( hDlg, ID_ICON, STM_SETICON, (WORD)hicon, 0L );
    }
    else
    { /* Win 3.0 */
        SetDlgItemText( hDlg, ID_ICON, MAKEINTRESOURCE(hicon));
    }
#endif
}


/*****************************************************************************/
/*                 ShowPageGroup                                             */
/* Purpose:                                                                  */
/*   Shows (or hides) either the page related controls or the orientation    */
/*   related controls.                                                       */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the paper dialog box                             */
/*   BYTE showType -- Specifies Orientation, Paper size or none              */
/*   int iUnits -- ID_CP_INCHES or ID_CP_MILLIMETERS for units to use        */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL ShowPageGroup(HWND hDlg, BYTE showType, int iUnits)
{
    char strBuff[64];
    int  showOrientation = SW_SHOWNA, showPaper = SW_SHOWNA;
    WORD i;

    if (showType == SHOW_PAPERSIZES)
    {
        /* Show the page dimension stuff */
        if (iUnits == ID_CP_INCHES)
            LoadString(ghDriverMod, IDS_UNITS_INCHES, strBuff, sizeof(strBuff));
        else
            LoadString(ghDriverMod, IDS_UNITS_MILLIMETERS, strBuff,
                       sizeof(strBuff));
        SetDlgItemText(hDlg, ID_GROUP_DIMENSION, strBuff);

        showOrientation = SW_HIDE;
    }
    else
    {
        /* Show the orientation stuff */
        LoadString(ghDriverMod, IDS_TITLE_PAGE, strBuff, sizeof(strBuff));
        SetDlgItemText(hDlg, ID_GROUP_ORIENTATION, strBuff);

        showPaper = SW_HIDE;
    }

    /* Orientation stuff */
    for (i=ID_GROUP_ORIENTATION; i<=ID_ROTATED; i++)
    {
        ShowWindow(GetDlgItem(hDlg, i), showOrientation);
    }

    /* Paper size stuff */
    /* Do not hide controls if they have already been destroyed */
    if (GetDlgItem(hDlg, ID_GROUP_DIMENSION) != 0)
    {
        for (i=ID_GROUP_DIMENSION; i<=ID_VAL_RIGHT; i++)
        {
            ShowWindow(GetDlgItem(hDlg, i), showPaper);
            ShowWindow(GetDlgItem(hDlg, i-ID_GROUP_DIMENSION+ID_TEXT_WIDTH),
                       showPaper);
        }
    }
}

void NEAR PASCAL AppendPaperDims(LPDRIVERINFO lpDrvInfo, LPSTR buffer)
{
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    WORD dimX, dimY, qdimx, rdimx, qdimy, rdimy, nDecimals, x, y;
    int  i, iunits;
    char decimalSeparator[4], fmt[50];

    /* Get current keyword option and check for custom paper. If custom, call
       GetCustomPageDimensions(). Check to see if we should use inches or mm
       based on country code. Do Multdiv to get the dims in the rigt units,
       and then display it */
    KeywordGetCurrentOption(&lpDrvInfo->pDev, IND_PAPERINFO, (LPWORD)&i);
    if ((WORD)i != lpPrinterInfo->devcaps.CustomPageSize)
    {
        GetPaperDimensionAndArea(&lpDrvInfo->pDev, &dimX, &dimY, NULL, NULL,
                                 NULL, NULL);
    }
    else
    {
        GetCustomPageDimensions(lpDrvInfo, &dimX, &dimY, &qdimx, &qdimx);
    }

    GetDecimalSeparator(decimalSeparator, sizeof(decimalSeparator));

    // convert from points to user units
    iunits = GetMeasurementUnit(FALSE);
    if (iunits == ID_CP_INCHES)
    {
        x = 72;
        y = 1;
        nDecimals = 2;
    }
    else  // millimeters
    {
        x = 720;
        y = 254;
        nDecimals = 1;
    }

    FixedMulDiv(dimX, y, x, nDecimals, &qdimx, &rdimx);
    FixedMulDiv(dimY, y, x, nDecimals, &qdimy, &rdimy);

    wsprintf((LPSTR)fmt, " (%%d%%s%%0%d.%dd x %%d%%s%%0%d.%dd %%s)", nDecimals,
             nDecimals, nDecimals, nDecimals);
    wsprintf(&buffer[lstrlen(buffer)], fmt,
             qdimx, (LPSTR)decimalSeparator, rdimx,
             qdimy, (LPSTR)decimalSeparator, rdimy,
             iunits == ID_CP_INCHES ? (LPSTR)"in" : (LPSTR)"mm");
}


/*****************************************************************************/
/*                 ShowPaperDlg                                              */
/* Purpose:                                                                  */
/*   Shows all current parameters for the paper dialog                       */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to Paper dialog                                     */
/*   LPDRIVERINFO lpDrvInfo -- points to DRIVERINFO structure                */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

VOID NEAR PASCAL ShowPaperDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    LPPDEVICE      lppd = &(lpDrvInfo->pDev);
    DWORD          dwUIFlags = lpDrvInfo->dwUIFlags[DI_PAPER];
    WORD           i;
    char           buffer[128];

    if (dwUIFlags & DI_ORIENTATION)
    {
        SetPaperOrientation(hDlg, lpDrvInfo) ;
        ShowPageGroup(hDlg, SHOW_ORIENTATION, 0);
    }

    if (dwUIFlags & DI_PAPERSOURCE)
    {
        KeywordGetCurrentOption(lppd, IND_INPUTSLOTINFO, (LPWORD)&i);
        SendDlgItemMessage(hDlg, ID_SOURCELIST, CB_SETCURSEL, i, 0L);
    }

    if (dwUIFlags & DI_PAPERSIZE)
    {
        KeywordGetCurrentOption(lppd, IND_PAPERINFO, (LPWORD)&i);
        if (i != lpPrinterInfo->devcaps.CustomPageSize)
        {
            SendDlgItemMessage(hDlg, ID_SIZELIST, LB_SETCURSEL, i, 0L);
            lpDrvInfo->Paper_opt_index = i;

            SendDlgItemMessage(hDlg, ID_SIZELIST, LB_GETTEXT, i,
                               (long)((LPSTR)buffer));
            AppendPaperDims(lpDrvInfo, buffer);
            SetDlgItemText(hDlg, ID_SIZENAME, (LPSTR)buffer);
            // if it is doc sticky request,gray out the Unprintable Area
            // enable the window if custom paper is selected. bug # 163628
            if(!(lpDrvInfo->wFlags & DI_PROPSHEET))
            {
               EnableWindow(GetDlgItem(hDlg, ID_MARGINS),
                     i == lpPrinterInfo->devcaps.CustomPageSize);
            }
        }
    }

    if (dwUIFlags & DI_CUSTOM)
    {
        KeywordGetCurrentOption(lppd, IND_PAPERINFO, (LPWORD)&i);

        EnableWindow(GetDlgItem(hDlg, ID_CUSTOM_PAPER),
                     i == lpPrinterInfo->devcaps.CustomPageSize);
        /* NOTE !! Uses the fact that APP_DEFINED = NUM_CUST_SIZES */
        if (i == lpPrinterInfo->devcaps.CustomPageSize)
        {
            KeywordGetNumOfOptions(lppd, IND_PAPERINFO, (LPWORD)&i);
            i += lpPSExtDevmode->dm.currentCustPaper - 1;

            SendDlgItemMessage(hDlg, ID_SIZELIST, LB_SETCURSEL, i, 0L);

            lpDrvInfo->Paper_opt_index =
                - (int)(lpPSExtDevmode->dm.currentCustPaper+1);

            SendDlgItemMessage(hDlg, ID_SIZELIST, LB_GETTEXT, i,
                               (long)((LPSTR)buffer));
            AppendPaperDims(lpDrvInfo, buffer);
            SetDlgItemText(hDlg, ID_SIZENAME, (LPSTR)buffer);
        }
    }

    if (dwUIFlags & DI_MEDIATYPE)
    {
        KeywordGetCurrentOption(lppd, IND_MEDIATYPEINFO, (LPWORD)&i);
        SendDlgItemMessage(hDlg, ID_TYPELIST, CB_SETCURSEL, i, 0L);
    }

    if (dwUIFlags & DI_OUTPUTBIN)
    {
        KeywordGetCurrentOption(lppd, IND_OUTPUTBININFO, (LPWORD)&i);
        SendDlgItemMessage(hDlg, ID_BINLIST, CB_SETCURSEL, i, 0L);
    }

    if (dwUIFlags & DI_DUPLEX)
    {
        KeywordGetCurrentOption(lppd, IND_DUPLEXINGINFO, (LPWORD)&i);
        SendDlgItemMessage(hDlg, ID_DUPLEXLIST, CB_SETCURSEL, i, 0L);
    }

    if (dwUIFlags & DI_COLLATE)
    {
        KeywordGetCurrentOption(lppd, IND_COLLATIONINFO, (LPWORD)&i);
        CheckDlgButton(hDlg, ID_COLLATE, i);
    }

    if (dwUIFlags & DI_REVERSEORDER)
    {
        KeywordGetCurrentOption(lppd, IND_OUTPUTORDERINFO, (LPWORD)&i);
        CheckDlgButton(hDlg, ID_REVERSE_ORDER, i);
    }

    if (dwUIFlags & (DI_DUPLEX | DI_COLLATE | DI_REVERSEORDER))
       ValidatePicture(hDlg,ID_PAPER_PICTURE,FALSE);
}


void NEAR PASCAL RefreshUIConstraints(LPDRIVERINFO lpDrvInfo, HWND hDlg,
                                      HDC hdc, RECT FAR* lprc, int index)
{
    LPPRINTERINFO lpPrinterInfo;
    DWORD dwItemData;
    int   i, option = index;
    BOOL  bConstraint;

    dwItemData = SendDlgItemMessage(hDlg, ID_SIZELIST, LB_GETITEMDATA, index,0);
    i = LOWORD(dwItemData);

    lpPrinterInfo = (LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo);
    if (i < 0)
    {
        option = lpPrinterInfo->devcaps.CustomPageSize;
    }
    bConstraint = IsKeywordOptConstrained(&lpDrvInfo->pDev, IND_PAPERINFO,
                                          option);

    if ((!bConstraint && HIWORD(dwItemData)) ||
        (bConstraint && !HIWORD(dwItemData)))
    {
        InvalidateRect(hDlg, lprc, FALSE);
    }
}

/*****************************************************************************/
/*                 RefreshPaperDlg                                           */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to Paper dialog                                     */
/*   LPDRIVERINFO lpDrvInfo -- points to DRIVERINFO structure                */
/*   WORD wRefreshFlags -- Update flags indicating what level of update      */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

VOID NEAR PASCAL RefreshPaperDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo,
                                 WORD wRefreshFlags)
{
    RECT           rc;
    LPPDEVICE      lppd = &(lpDrvInfo->pDev);
    DWORD          dwUIFlags = lpDrvInfo->dwUIFlags[DI_PAPER];
    int            i, num_opts;
    HANDLE         hdc;
    char           buffer[128];

    if ((dwUIFlags & DI_PAPERSIZE) && (wRefreshFlags & UPDATE_PAPERSIZE))
    {
        /* Update paper name above listbox */
        i = LOWORD(SendDlgItemMessage(hDlg, ID_SIZELIST, LB_GETCURSEL, 0, 0L));
        SendDlgItemMessage(hDlg, ID_SIZELIST, LB_GETTEXT, i,
                           (long)((LPSTR)buffer));
        AppendPaperDims(lpDrvInfo, buffer);
        SetDlgItemText(hDlg, ID_SIZENAME, (LPSTR)buffer);

        /* For each paper size, send an invalidate rectangle message */
        num_opts = (int)SendDlgItemMessage(hDlg, ID_SIZELIST, LB_GETCOUNT,
                                           0, 0L);

        hdc= GetDC(GetDlgItem(hDlg, ID_SIZELIST));
        for (i = 0; i < num_opts; i++)
        {
            SendDlgItemMessage(hDlg, ID_SIZELIST, LB_GETITEMRECT, i,
                           (long)(RECT FAR*)&rc);
            RefreshUIConstraints(lpDrvInfo, hDlg, hdc, &rc, i);
        }
        ReleaseDC(GetDlgItem(hDlg, ID_SIZELIST), hdc);
    }

    if ((dwUIFlags & DI_PAPERSOURCE) && (wRefreshFlags & UPDATE_PAPERSOURCE))
    {
        KeywordGetCurrentOption(lppd, IND_INPUTSLOTINFO, (LPWORD)&i);
        SendDlgItemMessage(hDlg, ID_SOURCELIST, CB_SETCURSEL, i, 0L);
    }

    if ((dwUIFlags & DI_MEDIATYPE) && (wRefreshFlags & UPDATE_MEDIATYPE))
    {
        KeywordGetCurrentOption(lppd, IND_MEDIATYPEINFO, (LPWORD)&i);
        SendDlgItemMessage(hDlg, ID_TYPELIST, CB_SETCURSEL, i, 0L);
    }

    if ((dwUIFlags & DI_OUTPUTBIN) && (wRefreshFlags & UPDATE_OUTPUTBIN))
    {
        KeywordGetCurrentOption(lppd, IND_OUTPUTBININFO, (LPWORD)&i);
        SendDlgItemMessage(hDlg, ID_BINLIST, CB_SETCURSEL, i, 0L);
    }

    if ((dwUIFlags & DI_DUPLEX) && (wRefreshFlags & UPDATE_DUPLEX))
    {
        KeywordGetCurrentOption(lppd, IND_DUPLEXINGINFO, (LPWORD)&i);
        SendDlgItemMessage(hDlg, ID_DUPLEXLIST, CB_SETCURSEL, i, 0L);
        ValidatePicture(hDlg,ID_PAPER_PICTURE,FALSE);

    }

    if ((dwUIFlags & DI_COLLATE) && (wRefreshFlags & UPDATE_COLLATE))
    {
        KeywordGetCurrentOption(lppd, IND_COLLATIONINFO, (LPWORD)&i);
        CheckDlgButton(hDlg, ID_COLLATE, i);
        ValidatePicture(hDlg,ID_PAPER_PICTURE,FALSE);
    }

    if ((dwUIFlags & DI_REVERSEORDER) && (wRefreshFlags & UPDATE_REVERSEORDER))
    {
        KeywordGetCurrentOption(lppd, IND_OUTPUTORDERINFO, (LPWORD)&i);
        CheckDlgButton(hDlg, ID_REVERSE_ORDER, i );
        ValidatePicture(hDlg,ID_PAPER_PICTURE,FALSE);
    }
}


/*****************************************************************************/
/*                 ControlMouseHitTest                                       */
/* Purpose:                                                                  */
/*   Detects mouse message in control or not given x,y relative to dialog    */
/*   client.                                                                 */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to Paper features dialog                            */
/*   int iCtrlID -- Control ID for the target icon that is the hit area      */
/*   int x -- x coordinate of mouse down                                     */
/*   int y -- y coordinate of mouse down                                     */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE  => if mouse down is in hit area                                   */
/*   FALSE => if mouse down is not in hit area                               */
/*****************************************************************************/

BOOL NEAR PASCAL ControlMouseHitTest(HWND hDlg, int iCtrlID, int x, int y)
{
    RECT  ctrlRect;
    POINT ctrlPt;
    HWND  hCtrl;
    int   xext, yext;

    hCtrl = GetDlgItem(hDlg, iCtrlID);
    GetWindowRect(hCtrl, &ctrlRect);
    xext = ctrlRect.right - ctrlRect.left;
    yext = ctrlRect.bottom - ctrlRect.top;
    ctrlPt.x = ctrlRect.left;
    ctrlPt.y = ctrlRect.top;
    ScreenToClient(hDlg, &ctrlPt);

    return ((x >= ctrlPt.x) && (x <= (ctrlPt.x + xext)) &&
            (y >= ctrlPt.y) && (y <= (ctrlPt.y + yext)));
}


/*****************************************************************************/
/*                 GetPaperDimensionAndArea                                  */
/* Purpose:                                                                  */
/*   Gets overall paper dimension in points. Valid for portrait orientation  */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPDEVICE lppd -- pdevice                                               */
/*   LPDRVSTATE lpDrvState -- Driver State                                   */
/*   float FAR *lpDimX -- return buffer for X dimension                      */
/*   float FAR *lpDimY -- return buffer for Y dimension                      */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL GetPaperDimensionAndArea(LPPDEVICE lppd, LPWORD lpDimX,
                                          LPWORD lpDimY, LPWORD lpX1,
                                          LPWORD lpY1, LPWORD lpX2, LPWORD lpY2)
{
    LPPRINTERINFO lpPrinterInfo =
        (LPPRINTERINFO) lppd->lpWPXblock->WPXprinterInfo;
    LPBYTE        lpOptionsBlock = lppd->lpWPXblock->WPXarrays;
    LPMAINKEYHDR  lpCurMainKeyHdr ;
    LPPAPERINFO   lpPaperInfo ;
    int           iOption;

    /* Find out current media option from PageSize. */
    KeywordGetCurrentOption(lppd , IND_PAPERINFO, &iOption) ;
    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;

    lpPaperInfo = (LPPAPERINFO)MAKELONG(
          lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );

    if (lpDimY)
        *lpDimY = lpPaperInfo[iOption].length;
    if (lpDimX)
        *lpDimX = lpPaperInfo[iOption].width;

    if (lpX1)
        *lpX1 = lpPaperInfo[iOption].imageableArea.left;
    if (lpY1)
        *lpY1 = lpPaperInfo[iOption].imageableArea.bottom;
    if (lpX2)
        *lpX2 = lpPaperInfo[iOption].imageableArea.right;
    if (lpY2)
        *lpY2 = lpPaperInfo[iOption].imageableArea.top;
}


/*****************************************************************************/
/*                 OrientationConversion                                     */
/* Purpose:                                                                  */
/*   Sends in a set of orientation in portrait and get back margins and dim  */
/*   correct for current orientation.                                        */
/*                                                                           */
/* Parameters:                                                               */
/*   LPWORD lpDimX -- Paper width                                            */
/*   LPWORD lpDimY -- Paper height                                           */
/*   LPWORD lpDx1 -- Lower X margin                                          */
/*   LPWORD lpDy1 -- Lower Y margin                                          */
/*   LPWORD lpDx2 -- Upper X margin                                          */
/*   LPWORD lpDy2 -- Upper Y margin                                          */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL OrientationConversion(LPPSEXTDEVMODE lpPSExtDevmode,
                                       LPWORD lpDimX, LPWORD lpDimY,
                                       LPWORD lpDx1, LPWORD lpDy1,
                                       LPWORD lpDx2, LPWORD lpDy2)

{
/*****************************************************************************/
/* Calculate all values using points and in integers first to avoid loss     */
/* due to rounding. We only use floats when we convert to real units for     */
/* output. If we are portrait we have the following:                         */
/* The following diagram shows the dimension relationships. -John Kwan       */
/*                                                                           */
/*   -----------------dimY                                                   */
/*   |      dy2      |                                                       */
/*   |  -----------  |y2                                                     */
/*   |  |         |  |                                                       */
/*   |  |         |  |        dx1 = x lower margin = x1 - 0                  */
/*   |  |         |  |        dx2 = dimX - x2                                */
/*   |dx1         |dx2        dy1 = y1                                       */
/*   |  |         |  |        dy2 = dimY - y2                                */
/*   |  |         |  |                                                       */
/*   |  |         |  |                                                       */
/*   |  -----------  |y1                                                     */
/*   |  x1  dy1   x2 |                                                       */
/*   -----------------y=0                                                    */
/* x=0               dimX                                                    */
/*                                                                           */
/* Margins: L, R, T, B                                                       */
/* Portrait         : L = dx1,  R = dx2,  T = dy2,  B = dy1, Page top Up     */
/* Landscape        : L = dy2,  R = dy1,  T = dx2,  B = dx1, Page top Right  */
/* Rotated Landscape: L = dy1,  R = dy2,  T = dx1,  B = dx2, Page top Left   */
/*                                                                           */
/*****************************************************************************/

    WORD temp;

    switch (lpPSExtDevmode->dm.PaperOrient)
    {
        case OR_PORTRAIT:
            /* Do nothing with DimX and DimY here */
            SWAP(*lpDy1, *lpDy2, temp);
            break;

        case OR_LANDSCAPE: /* 90 degree clockwise rotation of image */
            /* Swap *lpDimX and *lpDimY here */
            SWAP(*lpDimX, *lpDimY, temp);

            SWAP(*lpDx1, *lpDy2, temp);
            SWAP(*lpDy1, *lpDx2, temp);
            break;

        case OR_ROTLANDSCAPE: /* 90 degrees counter-clockwise */
            /* Swap *lpDimX and *lpDimY here */
            SWAP(*lpDimX, *lpDimY, temp);

            SWAP(*lpDx1, *lpDy1, temp);
            SWAP(*lpDx2, *lpDy2, temp);
            break;
    }
}


/*****************************************************************************/
/*                 SetPageSize                                               */
/* Purpose:                                                                  */
/*   Displays the page dimensions and margins in the paper features property */
/*   sheet dialog box.                                                       */
/*                                                                           */
/* Parameters:                                                               */
/*   LPDRIVERINFO lpDrvInfo -- points to DRIVERINFO structure                */
/*   HWND hDlg -- Handle to the paper dialog box                             */
/*   int units -- type of units used (ID_CP_INCHES, ID_CP_MILLIMETERS)       */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL SetPageSize(LPDRIVERINFO lpDrvInfo, HWND hDlg, int units)
{
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;
    WORD  dx1, dx2, dy1, dy2, x1, x2, y1, y2, x, y;
    WORD  dimX, dimY, qdimx, qdimy, rdimx, rdimy, nDecimals;
    int   PPD_opt_index ;        /* index into PPD keyword's list of options */
    int   LB_opt_index ;         /* index into Combo box's list of options */
    char  decimalSeparator[4];

    /* find out if we are dealing with a custom paper size */
    LB_opt_index = LOWORD(SendDlgItemMessage(hDlg, ID_SIZELIST, LB_GETCURSEL,
                                             0, NULL)) ;

    /* Find out which option in a PPD keyword's list was selected. */
    PPD_opt_index = LOWORD(SendDlgItemMessage(hDlg, ID_SIZELIST,
                                              LB_GETITEMDATA, LB_opt_index, 0));
    if (PPD_opt_index < 0)
    {
        /* CustomPaper */
        GetCustomPageDimensions(lpDrvInfo, &x2, &y2, &x1, &y1);
        dimX = x2;
        dimY = y2;
        x1   = 0;
        y1   = 0;
    }
    else
    {
        /* Ordinary Paper */
        GetPaperDimensionAndArea(&lpDrvInfo->pDev, &dimX, &dimY, &x1, &y1,
                                 &x2, &y2);
        x1 = lpPSExtDevmode->dm2.revisedPaperMargins[PPD_opt_index].left;
        y1 = lpPSExtDevmode->dm2.revisedPaperMargins[PPD_opt_index].bottom;
        x2 = lpPSExtDevmode->dm2.revisedPaperMargins[PPD_opt_index].right;
        y2 = lpPSExtDevmode->dm2.revisedPaperMargins[PPD_opt_index].top;

    }

    /* Calculate margins */
    x2 = dimX - x2;
    y2 = dimY - y2;

    OrientationConversion(lpPSExtDevmode, &dimX, &dimY, &x1, &y1, &x2, &y2);

    /* Get the decimal separator */
    GetDecimalSeparator(decimalSeparator, sizeof(decimalSeparator));

    // convert from points to user units
    if (units == ID_CP_INCHES)
    {
        x = 72;
        y = 1;
        nDecimals = 2;
    }
    else  // millimeters
    {
        x = 720;
        y = 254;
        nDecimals = 1;
    }

    FixedMulDiv(dimX, y, x, nDecimals, &qdimx, &rdimx);
    FixedMulDiv(dimY, y, x, nDecimals, &qdimy, &rdimy);
    FixedMulDiv(x1,   y, x, nDecimals, &x1,    &dx1);
    FixedMulDiv(x2,   y, x, nDecimals, &x2,    &dx2);
    FixedMulDiv(y1,   y, x, nDecimals, &y1,    &dy1);
    FixedMulDiv(y2,   y, x, nDecimals, &y2,    &dy2);

    // display the values
    DisplayFixedPointNumber(hDlg, ID_VAL_WIDTH,  qdimx, rdimx,
                            decimalSeparator, nDecimals);
    DisplayFixedPointNumber(hDlg, ID_VAL_HEIGHT, qdimy, rdimy,
                            decimalSeparator, nDecimals);

    DisplayFixedPointNumber(hDlg, ID_VAL_TOP, y1, dy1,
                            decimalSeparator, nDecimals);
    DisplayFixedPointNumber(hDlg, ID_VAL_LEFT, x1, dx1,
                            decimalSeparator, nDecimals);
    DisplayFixedPointNumber(hDlg, ID_VAL_BOTTOM, y2, dy2,
                            decimalSeparator, nDecimals);
    DisplayFixedPointNumber(hDlg, ID_VAL_RIGHT , x2, dx2,
                            decimalSeparator, nDecimals);
}

/*****************************************************************************/
/*                 ResetKeywordOption                                        */
/* Purpose:                                                                  */
/*   Procedure to Reset the given keyword option to its default              */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPSEXTDEVMODE lpPSExtDevmode -- pointer to the PSExtDevmode            */
/*   LPPRINTERINFO lpPrinterInfo -- pointer to the printer info              */
/*   int iKeywordIndex -- index to the given keyword                         */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void FAR PASCAL ResetKeywordOption(LPPSEXTDEVMODE lpPSExtDevmode,
                                    LPPRINTERINFO lpPrinterInfo,
                                    int iKeywordIndex)
{
    LPOPTIONSTATE  lpOptionState ;
    LPMAINKEYHDR  lpCurMainKeyHdr ;

    lpOptionState = lpPSExtDevmode->dm.optionState;

    lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + iKeywordIndex ;
    lpOptionState[iKeywordIndex].optionKeyIndex =
        lpCurMainKeyHdr->DefaultOptionIndex ;
    lpOptionState[iKeywordIndex].nextState = 0xFFFF ;
}

void FAR PASCAL RestorePaperDefaults(LPPSEXTDEVMODE lpPSExtDevmode,
                                     LPWPXBLOCKS lpWPXBlock,
                                     DWORD dwUIFlags)
{
  int i;
  unsigned int CurPaper;
  LPPRINTERINFO  lpPrinterInfo ;

  lpPrinterInfo = (LPPRINTERINFO)(lpWPXBlock->WPXprinterInfo);

  /* Restore Orientation */
  if (dwUIFlags & DI_ORIENTATION)
      lpPSExtDevmode->dm.PaperOrient = OR_PORTRAIT;

  /* Restore duplex */
  if (dwUIFlags & DI_DUPLEX)
      ResetKeywordOption(lpPSExtDevmode, lpPrinterInfo, IND_DUPLEXINGINFO);

  /* Restore source list */
  if (dwUIFlags & DI_PAPERSOURCE)
      ResetKeywordOption(lpPSExtDevmode, lpPrinterInfo, IND_INPUTSLOTINFO);

  /* Restore size */
  if (dwUIFlags & DI_PAPERSIZE)
      DefaultPaperSize(lpPSExtDevmode, lpWPXBlock);

  /* Restore media type */
  if (dwUIFlags & DI_MEDIATYPE)
      ResetKeywordOption(lpPSExtDevmode, lpPrinterInfo, IND_MEDIATYPEINFO);

  /* Restore output bin */
  if (dwUIFlags & DI_OUTPUTBIN)
      ResetKeywordOption(lpPSExtDevmode, lpPrinterInfo, IND_OUTPUTBININFO);

  /* Restore output order */
  if (dwUIFlags & DI_COLLATE)
      ResetKeywordOption(lpPSExtDevmode, lpPrinterInfo, IND_COLLATIONINFO);

  /* Restore output order */
  if (dwUIFlags & DI_REVERSEORDER)
  {
      ResetKeywordOption(lpPSExtDevmode, lpPrinterInfo, IND_OUTPUTORDERINFO);
      lpPSExtDevmode->dm.bOutputOrder =
          lpPrinterInfo->mainKeyHdrs[IND_OUTPUTORDERINFO].DefaultOptionIndex;
  }

  /* Restore custom paper */
  if (dwUIFlags & DI_CUSTOM)
  {
      for (i = 0 ; i < NUM_CUST_SIZES ; i++)
      {
          lpPSExtDevmode->dm.currentCustPaper = i;
          RestoreCustPapDefaults(lpPSExtDevmode, lpWPXBlock);

          // initialize HWmargins
          lpPSExtDevmode->dm.custPaper[i].HWmargins.left   =
                                 lpPrinterInfo->custpageinfo.HWmargins.left;
          lpPSExtDevmode->dm.custPaper[i].HWmargins.top    =
                                 lpPrinterInfo->custpageinfo.HWmargins.top;
          lpPSExtDevmode->dm.custPaper[i].HWmargins.right  =
                                 lpPrinterInfo->custpageinfo.HWmargins.right;
          lpPSExtDevmode->dm.custPaper[i].HWmargins.bottom =
                                 lpPrinterInfo->custpageinfo.HWmargins.bottom;
      }

      rawKeywordGetCurrentOption(lpWPXBlock,
                                 lpPSExtDevmode->dm.optionState,
                                 IND_PAPERINFO, &CurPaper);
      if (CurPaper == lpPrinterInfo->devcaps.CustomPageSize )
      {
          lpPSExtDevmode->dm.currentCustPaper = 0 ; // select first cust size.
      }
      else
      {
          lpPSExtDevmode->dm.currentCustPaper = 0xFFFF ;
      }
  }
}

/*****************************************************************************/
/*                 ResetPaperDefaults                                        */
/* Purpose:                                                                  */
/*   Procedure to restore paper property sheet items to PPD defaults         */
/*                                                                           */
/* Parameters:                                                               */
/*   LPDRIVERINFO lpDrvInfo -- pointer to DRIVERINFO sturucture              */
/*   HWND hDlg -- dialog box handle                                          */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL ResetPaperDefaults(LPDRIVERINFO lpDrvInfo, HWND hDlg)
{
    DWORD dwUIFlags = lpDrvInfo->dwUIFlags[DI_PAPER];

    RestorePaperDefaults(lpDrvInfo->lpDM,
                         lpDrvInfo->pDev.lpWPXblock, dwUIFlags);

    if (dwUIFlags & DI_CUSTOM)
    {
        EnableWindow(GetDlgItem(hDlg, ID_CUSTOM_PAPER),
                     lpDrvInfo->lpDM->dm.currentCustPaper != 0xFFFF);
    }
}


/*****************************************************************************/
/*                 HandlePaperUpdate                                         */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   LPDRIVERINFO lpDrvInfo -- pointer to DRIVERINFO sturucture              */
/*   HWND hDlg -- dialog box handle                                          */
/*   WORD wFlag --                                                           */
/*   WORD result -- what to update                                           */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL HandlePaperUpdate(LPDRIVERINFO lpDrvInfo, HWND hDlg,
                                   WORD wFlag, WORD result)
{
    WORD UpdateWhat;

    switch (result)
    {
        case SCREENUPDATE_UICONSTRAINTS:
            UpdateWhat = UPDATE_UICONSTRAINED;
            break;

        case SCREENUPDATE_ALL:
            UpdateWhat = UPDATE_ALL;
            break;

        case SCREENUPDATE_CURRENT:
            UpdateWhat= wFlag;
            /*
             * If wFlag is UPDATE_PAPERSIZE, set the current selection, as
             * RefreshPaperDlg doesn't do it.
             */
            if (wFlag == UPDATE_PAPERSIZE)
            {
                int i;

                KeywordGetCurrentOption(&lpDrvInfo->pDev, IND_PAPERINFO,
                                        (LPWORD)&i);
                SendDlgItemMessage(hDlg, ID_SIZELIST, LB_SETCURSEL, i, 0L);
            }
            break;

        case SCREENUPDATE_NONE:
            UpdateWhat = UPDATE_PAPERSIZE;
            break;
    }

    RefreshPaperDlg(hDlg, lpDrvInfo, UpdateWhat);
}


/*****************************************************************************/
/*                 GetCurrentValues                                          */
/* Purpose: Get the current selection in a listbox/combobox                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- dialog box handle                                          */
/*   WORD wParam -- listbox/combobox dialog item id                          */
/*   LPWORD lpCBindex -- return index in listbox/combobox                    */
/*   LPWORD lpPPDindex -- return the associated PPD option index for         */
/*                        lpCBindex                                          */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL GetCurrentValues(HWND hDlg, WORD wParam, LPWORD lpCBindex,
                                  LPWORD lpPPDindex)
{
    int imsg, imsg2;

    imsg =  (wParam == ID_SIZELIST) ? LB_GETCURSEL : CB_GETCURSEL;
    imsg2 = (wParam == ID_SIZELIST) ? LB_GETITEMDATA : CB_GETITEMDATA;

    // Find out which item in the combo list was selected.
    *lpCBindex = LOWORD(SendDlgItemMessage(hDlg, wParam, imsg, 0, NULL));

    // Find out which option in the PPD keyword list was selected.
    *lpPPDindex = LOWORD(SendDlgItemMessage(hDlg, wParam, imsg2, *lpCBindex,0));
}


/*****************************************************************************/
/*                 UpdateCustomPaperName                                     */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   LPDRIVERINFO lpDrvInfo -- pointer to DRIVERINFO sturucture              */
/*   HWND hDlg -- dialog box handle                                          */
/*                                                                           */
/* Returns: void                                                             */
/*****************************************************************************/

void NEAR PASCAL UpdateCustomPaperName(LPDRIVERINFO lpDrvInfo, HWND hDlg)
{
    /*
     * Check if paper name changed. If so, change it in
     * the PAPERSIZE combo box.
     */
    LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->pDev.lpPSExtDevmode;
    LPSTR          lpszNew;
    WORD           index = lpPSExtDevmode->dm.currentCustPaper;
    char           lpszOld[MAX_CUST_PAPER_NAME];

    lpszNew = lpPSExtDevmode->dm.custPaper[index].CustomName;

    KeywordGetNumOfOptions(&lpDrvInfo->pDev, IND_PAPERINFO, (LPWORD)&index);
    index += lpPSExtDevmode->dm.currentCustPaper - 1;
    SendDlgItemMessage(hDlg, ID_SIZELIST, LB_GETTEXT, index,
                       (LONG) ((LPSTR)lpszOld));

    if (lstrcmp(lpszOld, lpszNew) != 0)
    {
        SendDlgItemMessage(hDlg, ID_SIZELIST, WM_SETREDRAW, FALSE, NULL);
        SendDlgItemMessage(hDlg, ID_SIZELIST, LB_DELETESTRING, index, 0L);
        SendDlgItemMessage(hDlg, ID_SIZELIST, LB_INSERTSTRING, index,
                           (LONG)((LPSTR)lpszNew));
        SendDlgItemMessage(hDlg, ID_SIZELIST, WM_SETREDRAW, TRUE, NULL);

        SendDlgItemMessage(hDlg, ID_SIZELIST, LB_SETITEMDATA, index,
                           -(int)(lpPSExtDevmode->dm.currentCustPaper+1));
    }

    // Always send LB_SETCURSEL message so that the paper icon is updated
    // too if its width and/or height has been changed.
    SendDlgItemMessage(hDlg, ID_SIZELIST, LB_SETCURSEL, index, 0L);

    RefreshPaperDlg(hDlg, lpDrvInfo, UPDATE_PAPERSIZE);
}

/*****************************************************************************/
/*                 CHPaperDlg                                                */
/* Purpose:                                                                  */
/*   Dialog Procedure for the Paper Features property sheet dialog box.      */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE -- If procedure processes message                                  */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHPaperDlg(HWND hDlg, unsigned imsg, WORD wParam,
                                   LONG lParam)
{
    LPPRINTERINFO    lpPrinterInfo;
    LPPSEXTDEVMODE   lpPSExtDevmode;
    LPDRIVERINFO     lpDrvInfo;
    DWORD            dwUIFlags;
    WORD             rc, id;
    int              status = RC_ok ;
    int              PPD_opt_index; /* index into PPD keyword's list of options */
    int              CB_opt_index ; /* index into Combo box's list of options */
    BOOL             result = TRUE ;
    BOOL             bChanged = FALSE;
    int              collate, reverseOrder, duplex, orientation, nBmp, nMaskBmp;
    RECT             rcParent;
    LPDRAWITEMSTRUCT lpdis;

    /* Process hook function stuff */
    if(lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
    {
#ifdef USEHOOKPROC
        if(DrvProcessHookProc(&(lpDrvInfo->pDev),hDlg,imsg,wParam,lParam,
                              "HookSetup"))
        {
            return TRUE;
        }
#endif

        lpPSExtDevmode = lpDrvInfo->lpDM;
    }

    switch (imsg)
    {
        case WM_INITDIALOG:
            lpDrvInfo=(LPDRIVERINFO)(((LPPROPSHEETPAGE)lParam)->lParam);
            SetWindowLong(hDlg,DWL_USER,(LPARAM)lpDrvInfo);
            lpPSExtDevmode=lpDrvInfo->lpDM;
            lpDrvInfo->bPainting = TRUE;

            GetDecimalSeparator(decimalSeparator, sizeof(decimalSeparator));

            // Destroy unwanted controls and create combo boxes
            InitPaperDlg(hDlg, lpDrvInfo);
            BuildPaperDlg(hDlg, lpDrvInfo);
            ShowPaperDlg(hDlg, lpDrvInfo);
            ValidatePicture(hDlg,ID_PAPER_PICTURE,FALSE);
            lpDrvInfo->bPainting = FALSE;

            break ;

        case WM_BUILD_DLG:
            BuildPaperDlg(hDlg, lpDrvInfo);
            break;

        case WM_SHOW_DLG:
            ShowPaperDlg(hDlg, lpDrvInfo);
            break;

        case WM_LBUTTONDOWN:
            dwUIFlags = lpDrvInfo->dwUIFlags[DI_PAPER];

            /* If both of these are not set, no change in UI */
            if ((dwUIFlags & DI_ORIENTATION) && (dwUIFlags & DI_PAPERSIZE))
            {
                /* x == LOWORD(lParam) && y == HIWORD(lParam) */
                if (ControlMouseHitTest(hDlg, ID_ICON,  LOWORD(lParam),
                                        HIWORD(lParam)))
                {
                    int iUnits;

                    /* Detect if shifted or not */
                    if ((wParam & MK_SHIFT) == MK_SHIFT)
                        iUnits = GetMeasurementUnit(TRUE);
                    else
                        iUnits = GetMeasurementUnit(FALSE);

                    SetPageSize(lpDrvInfo, hDlg, iUnits);

                    ShowPageGroup(hDlg, SHOW_PAPERSIZES, iUnits);
                    SetCapture(hDlg);
                }
            }
            break;

        case WM_LBUTTONUP:
            dwUIFlags = lpDrvInfo->dwUIFlags[DI_PAPER];

            /* If both of these are not set, no change in UI */
            if ((dwUIFlags & DI_ORIENTATION) && (dwUIFlags & DI_PAPERSIZE))
            {
                ShowPageGroup(hDlg, SHOW_ORIENTATION, 0);
                ReleaseCapture();
            }
            break;

        case WM_CONTEXTMENU:
            if (wParam != -1)
            {
                WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                        (DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_HELP:
            if (((LPHELPINFO) lParam)->hItemHandle != -1)
            {
                WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                        HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_NOTIFY:
            switch (NOTIFY_CODE(lParam))
            {
                case PSN_SETACTIVE:
                    // Refresh controls affected by UI constraints on screen
                    lpDrvInfo->bPainting = TRUE;
                    RefreshPaperDlg(hDlg, lpDrvInfo, UPDATE_UICONSTRAINED);
                    lpDrvInfo->bPainting = FALSE;
                    break;

                case PSN_KILLACTIVE:
                    break;

                case PSN_APPLY:
                    if (lpDrvInfo->bChanged)
                    {
                        if (!UICCheckAllOptions(lpDrvInfo, hDlg, FALSE, 0))
                        {
                            SetWindowLong(hDlg,DWL_MSGRESULT,TRUE);
                            return TRUE;
                        }
                        UpdateGlobal(lpDrvInfo,TRUE);
                        WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
                        lpDrvInfo->bChanged = FALSE;
                    }
                    break;

                case PSN_RESET:
                    // If canceling, set lpDrvInfo->lpDM back to the
                    // saved devmode
                    lpDrvInfo->lpDM=&(lpDrvInfo->DMSave);
                    WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
                    break;
            }
            break;

        case WM_COMMAND:
            switch (wParam)
            {
                case ID_RESTORE_DEFAULTS:
                    ResetPaperDefaults(lpDrvInfo, hDlg);
                    BuildPaperDlg(hDlg, lpDrvInfo);
                    ShowPaperDlg(hDlg, lpDrvInfo);
                    UICCheckAllOptions(lpDrvInfo, hDlg, TRUE,
                                       UPDATE_UICONSTRAINED);
                    bChanged = TRUE;
                    break;

                case ID_SOURCELIST:
                    if (HIWORD(lParam) != CBN_SELCHANGE)
                        return result;

                    // Update paper source.
                    GetCurrentValues(hDlg, wParam, &CB_opt_index,
                                     &PPD_opt_index);
                    rc = UICSetCurrentOption(lpDrvInfo, IND_INPUTSLOTINFO,
                                             PPD_opt_index, hDlg);
                    HandlePaperUpdate(lpDrvInfo, hDlg, UPDATE_PAPERSOURCE, rc);
                    bChanged = TRUE;
                    break ;

                case ID_SIZELIST:
                    if (HIWORD(lParam) != LBN_SELCHANGE)
                        return result;

                    // Update paper size.
                    GetCurrentValues(hDlg, wParam, &CB_opt_index,
                                     &PPD_opt_index);
                    rc = UICSetCurrentOption(lpDrvInfo, IND_PAPERINFO,
                                             PPD_opt_index, hDlg);
                    HandlePaperUpdate(lpDrvInfo, hDlg, UPDATE_PAPERSIZE,
                                      rc);

                    // Set based on current index
                    if (rc != SCREENUPDATE_CURRENT)
                    {
                        lpDrvInfo->Paper_opt_index = PPD_opt_index;
                    }

                    if (lpDrvInfo->dwUIFlags[DI_PAPER] & DI_CUSTOM)
                    {
                        /* Enable or disable CustomPageSize button */
                        EnableWindow(GetDlgItem(hDlg, ID_CUSTOM_PAPER),
                                     lpDrvInfo->Paper_opt_index < 0);
                        // Enable or disable the Unprintable Area button
                        // when custom paper is selected or deselcted.
                        if ( !(lpDrvInfo->wFlags & DI_PROPSHEET))

                           EnableWindow(GetDlgItem(hDlg, ID_MARGINS),
                                     lpDrvInfo->Paper_opt_index < 0);
                    }
                    bChanged = TRUE;
                    break ;

                case ID_CUSTOM_PAPER:
                    id = lpPSExtDevmode->dm.currentCustPaper < NUM_CUST_SIZES ?
                             CH_CUSTOMPAPER : CH_CUSTOMOTHERPAPER;
                    rc = DialogBoxParam(ghDriverMod, MAKEINTRESOURCE(id), hDlg,
                                        CHCustomPaperDlg, (LPARAM)lpDrvInfo);

                    /*
                     * If the user has changed custom paper name in the
                     * dialog, it should be updated in the paper size listbox.
                     */
                    if (rc == IDOK)
                    {
                        UpdateCustomPaperName(lpDrvInfo, hDlg);
                        bChanged = TRUE;
                    }
                    break ;

                case ID_ABOUT:
                    DialogBoxParam(ghDriverMod, "AB", hDlg,
                                   fnAboutDlg, (LPARAM)lpDrvInfo);
                    break;

                case ID_MARGINS:
                    lpPrinterInfo = (LPPRINTERINFO)lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;
                    if (((lpDrvInfo->Paper_opt_index >= 0) &&
                         (lpDrvInfo->Paper_opt_index < MAXPAPERMARGINS))
                      || ((lpDrvInfo->Paper_opt_index < 0) &&
                          (lpPrinterInfo->custpageinfo.isCutSheet)))
                    {
                        if (DialogBoxParam(ghDriverMod,
                                           MAKEINTRESOURCE(CH_MARGINS),
                                           hDlg, CHMarginsDlg,
                                           (LPARAM)lpDrvInfo) == IDOK)
                            bChanged = TRUE;
                    }
                    else
                    { /*
                       * Either roll-fed custom paper or paper > MAXPAPERMARGINS.
                       * In either case, cannnot show margins. Display
                       * the right message to user.
                       */
                        DrvrStringMessageBox(hDlg,
                                             (lpDrvInfo->Paper_opt_index < 0) ?
                                             DLGS_NO_MARGINS_FOR_CUSTPAP :
                                             DLGS_NO_MARGINS,
                                             NULL, MB_ICONSTOP | MB_OK);
                    }
                    break;

                case ID_PORTRAIT:     //Update paper orientation.
                case ID_LANDSCAPE:
                    if (wParam == ID_PORTRAIT)
                    {
                        /* Leave bIsRotated alone to remember its state */
                        lpPSExtDevmode->dm.PaperOrient = OR_PORTRAIT;
                    }
                    else
                    {
                        if (lpPSExtDevmode->dm2.bIsRotated == FALSE)
                        { /* Not checked */
                            lpPSExtDevmode->dm.PaperOrient = OR_LANDSCAPE;
                        }
                        else
                        { /* Checked */
                            lpPSExtDevmode->dm.PaperOrient = OR_ROTLANDSCAPE;
                        }
                    }

                    //Update Display.
                    SetPaperOrientation(hDlg, lpDrvInfo) ;
                    ShowPageGroup(hDlg, SHOW_ORIENTATION, 0);
                    ValidatePicture(hDlg,ID_PAPER_PICTURE,FALSE);
                    bChanged = TRUE;
                    break;

                case ID_ROTATED:
                    if (IsDlgButtonChecked(hDlg, ID_ROTATED) == 0)
                    { /* Not checked */
                        lpPSExtDevmode->dm.PaperOrient = OR_LANDSCAPE;
                        lpPSExtDevmode->dm2.bIsRotated = FALSE;
                    }
                    else
                    { /* Checked */
                        lpPSExtDevmode->dm.PaperOrient = OR_ROTLANDSCAPE;
                        lpPSExtDevmode->dm2.bIsRotated = TRUE;
                    }

                    //Update Display.
                    SetPaperOrientation(hDlg, lpDrvInfo) ;
                    ShowPageGroup(hDlg, SHOW_ORIENTATION, 0);
                    ValidatePicture(hDlg,ID_PAPER_PICTURE,FALSE);
                    bChanged = TRUE;
                    break;

#ifndef USE_WHATSTHIS_HELP
                case ID_HELP:
                    WinHelp(hDlg, szHelpFile, HELP_CONTEXT,
                            IDH_PSCRIPT_SET_PAPER_OPTIONS);
                    break;
#endif
                case ID_TYPELIST:
                    if (HIWORD(lParam) == CBN_SELCHANGE) //Combo list selection.
                    {
                        GetCurrentValues(hDlg, wParam, &CB_opt_index,
                                         &PPD_opt_index);
                        // Update MediaType
                        rc = UICSetCurrentOption(lpDrvInfo, IND_MEDIATYPEINFO,
                                                 PPD_opt_index, hDlg);
                        HandlePaperUpdate(lpDrvInfo, hDlg, UPDATE_MEDIATYPE, rc);
                        bChanged = TRUE;
                    }
                    else
                        return result;
                    break;

                case ID_BINLIST:  // Update OutputBin
                    if (HIWORD(lParam) == CBN_SELCHANGE) //Combo list selection.
                    {
                        GetCurrentValues(hDlg, wParam, &CB_opt_index,
                                         &PPD_opt_index);
                        rc = UICSetCurrentOption(lpDrvInfo, IND_OUTPUTBININFO,
                                                 PPD_opt_index, hDlg);
                        HandlePaperUpdate(lpDrvInfo, hDlg, UPDATE_OUTPUTBIN, rc);
                        bChanged = TRUE;
                    }
                    else
                        return result;
                    break;

                case ID_COLLATE:
                    rc = UICSetCurrentOption(lpDrvInfo, IND_COLLATIONINFO,
                                   IsDlgButtonChecked(hDlg, ID_COLLATE) ?
                                       COLLATE_TRUE : COLLATE_FALSE, hDlg);
                    HandlePaperUpdate(lpDrvInfo, hDlg, UPDATE_COLLATE, rc);
                    ValidatePicture(hDlg,ID_PAPER_PICTURE,FALSE);
                    bChanged = TRUE;
                    break;

                case ID_REVERSE_ORDER:
                    reverseOrder = IsDlgButtonChecked(hDlg, ID_REVERSE_ORDER) ?
                                      OUTPUTORDER_REVERSE : OUTPUTORDER_NORMAL;
                    lpPSExtDevmode->dm.bOutputOrder = reverseOrder;
                    rc = UICSetCurrentOption(lpDrvInfo, IND_OUTPUTORDERINFO,
                                             reverseOrder, hDlg);
                    HandlePaperUpdate(lpDrvInfo, hDlg, UPDATE_REVERSEORDER, rc);
                    ValidatePicture(hDlg,ID_PAPER_PICTURE,FALSE);
                    bChanged = TRUE;
                    break;

                case ID_DUPLEXLIST:
                    if (HIWORD(lParam) == CBN_SELCHANGE) //Combo list selection.
                    {
                        GetCurrentValues(hDlg, wParam, &CB_opt_index,
                                         &PPD_opt_index);
                        rc = UICSetCurrentOption(lpDrvInfo, IND_DUPLEXINGINFO,
                                             CB_opt_index, hDlg);
                        HandlePaperUpdate(lpDrvInfo, hDlg, UPDATE_DUPLEX, rc);
                        ValidatePicture(hDlg,ID_PAPER_PICTURE,FALSE);
                        bChanged = TRUE;
                    }
                    break;

                case ID_LOGO:
                    if (WinExec("adonline.exe", SW_SHOWNORMAL) < 32)
                       DrvrStringMessageBox(hDlg,DLGS_ADONLINE,NULL,MB_ICONSTOP|MB_OK);
                    break;

                default:
                    result = FALSE ;
                    break ;
            } /* switch(wParam) */
            break ;

//        case WM_DRAW_LOGO:
            // draw logo bitmap
//            DrawPicture( hDlg, ID_GROUP_ORIENTATION, LOGO_BMP, LOGO_MASK_BMP );
//            break;

        case WM_PAINT:
            if(IsWindowVisible(GetDlgItem(hDlg, ID_GROUP_ORIENTATION)))
            {
               PostMessage(hDlg, WM_DRAW_LOGO, 0, 0L);
            }
            else
            {
               // earse logo bitmap
               GetWindowRect(hDlg, &rcParent);
               InvalidateRect(hDlg, &rcParent, FALSE);
            }
            return(FALSE);

        case WM_MEASUREITEM:
            HandleMeasureItem(hDlg, lpDrvInfo, (int)wParam,
                              (LPMEASUREITEMSTRUCT)lParam);
            break;

        case WM_DRAWITEM:
            lpdis = (LPDRAWITEMSTRUCT)lParam;
            if( wParam == ID_PAPER_PICTURE )
            {
                orientation = lpPSExtDevmode->dm.PaperOrient == OR_PORTRAIT ? 0 :
                                    ( lpPSExtDevmode->dm2.bIsRotated ? 2 : 1 );
                collate = IsDlgButtonChecked(hDlg,ID_COLLATE) ? 1 : 0;
                reverseOrder = IsDlgButtonChecked(hDlg,ID_REVERSE_ORDER) ? 1 : 0;
                duplex = LOWORD(SendDlgItemMessage(hDlg, ID_DUPLEXLIST, CB_GETCURSEL, 0, NULL));
                nBmp = PAPER_CONTROL_BMP + orientation*12 + duplex*4 +
                       collate*2 + reverseOrder;
                nMaskBmp = PAPER_CONTROL_MASK_BMP + 4 * (orientation?1:0) +
                           2 * (duplex?1:0) + collate;
                DrawPicture( hDlg, ID_PAPER_PICTURE, nBmp, nMaskBmp, 0, 0, 0 );
            }
            else if( wParam == ID_LOGO )
            {
               switch (lpdis->itemAction)
               {
                  case ODA_DRAWENTIRE:
                     if( lpdis->itemState & ODS_FOCUS )
                         HandleDrawButton( hDlg, lpdis, FOCUS, 0, 0 );
                     else
                         HandleDrawButton( hDlg, lpdis, NOFOCUS, 0, 0 );
                     break;

                  case ODA_SELECT:
                     if( lpdis->itemState & ODS_SELECTED )
                         HandleDrawButton( hDlg, lpdis, PUSHED, 3, 3 );
                     else
                         HandleDrawButton( hDlg, lpdis, FOCUS, 0, 0 );
                     break;

                  case ODA_FOCUS:
                     if( lpdis->itemState & ODS_FOCUS )
                         HandleDrawButton( hDlg, lpdis, FOCUS, 0, 0 );
                     break;
               }
            }
            else HandleDrawItem(hDlg, lpDrvInfo, (int)wParam, lpdis);
            break;

        default:
            result = FALSE ;
            break ;
    } /* switch(imsg) */

    if (bChanged && lpDrvInfo && !lpDrvInfo->bChanged && !lpDrvInfo->bPainting)
    {
        lpDrvInfo->bChanged = TRUE;
        PropSheet_Changed( GetParent(hDlg), hDlg );
    }

    return result ;
}
