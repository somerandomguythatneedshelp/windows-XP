/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: OEM.H                                                        */
/*                                                                           */
/* Description: Contains prototypes and defines for OEM DLLs                 */
/*                                                                           */
/*****************************************************************************/

/* The version of the driver this oem dll supports */

#define OEM_DLL_VERSION      0x0210

/***************************************************************************/
/* The dialog templates must have the following names:                     */
/*                                                                         */
/* OEM_SETUP31 Setup dialog box for Windows 3.1                            */
/* OEM_SETUP30 Setup dialog box for Windows 3.0                            */
/* OEM_ABOUT About dialog box                                              */
/* OEM_FEATURES Printer features dialog box                                */
/* OEM_PSOPTIONS Postscript options dialog box                             */
/* OEM_JOBCONTROL Job Control dialog box                                   */
/* OEM_CUSTOMPAPER Custom paper dialog box                                 */
/* OEM_ADDPRN30 PPD search dialog box for windows 3.0                      */
/* OEM_ADDPRN31 PPD search dialog box for windows 3.1                      */
/* OEM_TRUETYPE TrueType substitutions dialog box                          */
/*                                                                         */
/***************************************************************************/

/***************************************************************************/
/*                                                                         */
/* Hook proceedures for dialog processing                                  */
/*                                                                         */
/***************************************************************************/

BOOL CALLBACK HookSetup(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK HookAbout(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK HookFeatures(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK HookOptions(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK HookJobControl(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK HookCustomPaper(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK HookAddPrinter30(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK HookTrueType(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);

/***************************************************************************/
/*                                                                         */
/* OEM replacement dialog proceedures                                      */
/*                                                                         */
/***************************************************************************/

BOOL CALLBACK OEMSetup(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK OEMAbout(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK OEMFeatures(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK OEMOptions(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK OEMJobControl(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK OEMCustomPaper(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK OEMAddPrinter30(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK OEMTrueType(HWND hDlg, unsigned msg, WPARAM wParam, LPARAM lParam);

typedef BOOL (CALLBACK *LPOEMPROC)(HWND, unsigned, WPARAM, LPARAM);

/***************************************************************************/
/*                                                                         */
/* Misc. Functions                                                         */
/*                                                                         */
/***************************************************************************/

WORD FAR PASCAL OEMInstall(HWND hWnd, LPSTR lpszModelName, LPSTR lpszOldPort,
                           LPSTR lpszNewPort, LPPDEVICE lpPDevice,
                           WORD version);
typedef WORD (CALLBACK *LPOEMINSTALL)(HWND, LPSTR, LPSTR, LPSTR, LPPDEVICE,
                                      WORD);

/* OEMCUST -jmk begin */
#if 0
int FAR PASCAL OEMStartDoc(LPPDEVICE lpPDevice);
typedef int (CALLBACK *LPOEMSTARTDOC)(LPPDEVICE);

int FAR PASCAL OEMEndDoc(LPPDEVICE lpPDevice);
typedef int (CALLBACK *LPOEMENDDOC)(LPPDEVICE);
#endif
/* OEMCUST -jmk end */
