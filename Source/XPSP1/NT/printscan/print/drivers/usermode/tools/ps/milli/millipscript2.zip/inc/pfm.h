/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PFM.H                                                        */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/


// the definitions of these types are taken from the DDK book
// "Printers and Fonts Kit" chapters 2 and 4
//
// EXCEPTIONS: in the book the PFMHEADER section comprises what
// is described here as the PFMPROLOG and the PFMHEADER.  This is
// done in order to read the prolog in a separate step to extract
// version and size info BEFORE reading the header.  In addition
// the header will map more closely to part of the FONTINFO structure

typedef struct _PFMPROLOG
{
   unsigned short int dfVersion;
   unsigned long int  dfSize;
   char               dfCopyright[60];
}PFMPROLOG, FAR *LPPFMPROLOG;

typedef struct _PFMHEADER
{
   short int dfType;
   short int dfPoints;
   short int dfVertRes;
   short int dfHorizRes;
   short int dfAscent;
   short int dfInternalLeading;
   short int dfExternalLeading;
   BYTE      dfItalic;
   BYTE      dfUnderline;
   BYTE      dfStrikeOut;
   short int dfWeight;
   BYTE      dfCharSet;
   short int dfPixWidth;
   short int dfPixHeight;
   BYTE      dfPitchAndFamily;
   short int dfAvgWidth;
   short int dfMaxWidth;
   BYTE      dfFirstChar;
   BYTE      dfLastChar;
   BYTE      dfDefaultChar;
   BYTE      dfBreakChar;
   short int dfWidthBytes;
   unsigned long int  dfDevice;
   unsigned long int  dfFace;
   unsigned long int  dfBitsPointer;
   unsigned long int  dfBitsOffset;
}PFMHEADER, FAR *LPPFMHEADER;

typedef struct _PFMEXTENSION
{
   WORD  dfSizeFields;
   DWORD dfExtMetricsOffset;
   DWORD dfExtentTable;
   DWORD dfOriginTable;
   DWORD dfPairKernTable;
   DWORD dfTrackKernTable;
   DWORD dfDriverInfo;
   DWORD dfReserved;
}PFMEXTENSION, FAR *LPPFMEXTENSION;

typedef struct _PFM
{
   PFMPROLOG    prolog;
   PFMHEADER    hdr;
   PFMEXTENSION ext;
   //-----------------------THE LINE-------------------
   //the rest of the PFM contents are positioned
   //at varying positions using ptrs from the
   //header and extension sections and contain...
   //
   //device name...char[]
   //MS face name...char[]
   //EXTTEXTMETRIC structure
   //extent table (character widths)
   //PS face name
   //pair kern table
   //track kern table
   //
   //NOTE: one cannot assume that a given PS PFM file
   //is organized as described here.  You MUST use the
   //references in the header and extension sections
   //to access elements below the line.
}PFM, FAR *LPPFM, FAR * FAR * LPLPPFM;

