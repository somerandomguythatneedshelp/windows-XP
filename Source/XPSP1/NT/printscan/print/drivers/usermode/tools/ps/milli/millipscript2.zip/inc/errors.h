/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ERRORS.H                                                     */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/

// function return codes
enum
{
   RC_begin=-1,
   RC_ok,
   RC_fail,
   RC_fatal,
   RC_file,        //a file error caused failure
   RC_status,      //fail due to status, refer to status info
   RC_hold,        //called procedure was put on hold
   RC_comm,        //a comm layer error
   RC_data,
   RC_not_found,   //Couldn't find something.
   RC_userabort,
   RC_end
};

//error message styles
enum
{
   MBANG_begin,
   MBANG_1button,  // single O.K. button
   MBANG_2button,  // O.K. and CANCEL buttons
   MBANG_3button,  // YES, NO, and CANCEL (not multi-lingual)
   MBANG_end
};

// It is about time we standardize the error code returned by the pscript
// driver internal functions. The idea is that some day all driver functions
// that are internal (ie not part of the DDI) will return these values.
// The DDI's will map them and return the appropriate error code to GDI.
// PSERROR is an enumeration where the value of 0 is reserved for success, 
// negative values imply failure (nothing more can be done) and positive values
// imply warning (well.. shouldn't have happened, but can proceed -> if debug
// build give warning).
typedef enum {
    PS_LOWVM_VMRECOVER  = -10,
    PS_BUFFER_NULL      = -9,   // A needed buffer is null. Alloc must have failed elsewhere.

    PS_ENGINEREALIZEFONT_FAILED = -8, // EngineRealizeFont(Ext) failed

    PS_SPOOL_OPEN_ERROR = -7,   // OpenJob() failed
    PS_SPOOL_WRITE_ERROR= -6,   // WriteSpool() failed
    PS_SPOOL_CLOSE_ERROR= -5,   // CloseJob() failed

    PS_LOADRESOURCE_FAILED = -4,// LoadResource() failed
    PS_FINDRESOURCE_FAILED = -3,// FindResource() failed

    PS_ALLOC_FAILED     = -2,   // GlobalAlloc() or LocalAlloc() failed

    PS_GENERIC_FAIL     = -1,   // try not to use this - be more specific
    PS_SUCCESS          =  0,   // success
    PS_GENERIC_WARNING  =  1,   // try not to use this - be more specific
} PSERROR;


#define PS_ERROR(rc)    ((PSERROR)(rc) < 0)

// error categories
#define E_memory     0
#define E_file       1
#define E_translate  2
#define E_MSspool    3          //Microsoft spooler errors in Windows.h
#define E_devmode    4
#define E_font       5
#define E_system     6

//E_memory category error entries:
#define EMEM_insufficient     0
#define EMEM_general          1
#define EMEM_cannot_free      2
#define EMEM_cannot_realloc   3
#define EMEM_buf_exceeds_64k  4
#define EMEM_end             20

//E_file category error entries:
#define EFILE_create        0
#define EFILE_open          1
#define EFILE_seek          2
#define EFILE_read          3
#define EFILE_readimmediate 4
#define EFILE_readEOF       5
#define EFILE_write         6
#define EFILE_writeEOF      7
#define EFILE_close         8
#define EFILE_delete        9

//internal errors:
#define EFILE_handle       10
#define EFILE_name         11

#define EFILE_end          30

//E_translate category error entries:
#define ETRAN_begin     0      //temporary!
#define ETRAN_notqfile  0
#define ETRAN_end      30

//E_MSspool category error entries:
// MS Spool errors are negative; they are defined in Windows.h .
#define EMSSPOOL_unknown        0
#define EMSSPOOL_multipleJobs  -6

// Define max absolute value of MS Spool errors:
#define EMSSPOOL_end            6

//E_devmode category error entries:
#define EDM_inuse         0
#define EDM_read_failure  1
#define EDM_end          30

//E_font category error entries:
#define EFONT_index          0
#define EFONT_directory      1
#define EFONT_directoryread  2
#define EFONT_end           30

//E_system category error entries:
#define ESYS_MultidevReentrancy   0
#define ESYS_IllegalReentrancy    1
#define ESYS_ReentrancyOverflow   2
#define ESYS_end                 15

//Offsets into the string table for the error categories:
#define ID_memory    0
#define ID_file      ID_memory+EMEM_end+1
#define ID_translate ID_file+EFILE_end+1
#define ID_MSspool   ID_translate+ETRAN_end+1
#define ID_devmode   ID_MSspool+EMSSPOOL_end+1
#define ID_font      ID_devmode+EDM_end+1
#define ID_system    ID_font+EFONT_end+1


