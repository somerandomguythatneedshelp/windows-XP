/*
 * This file contains functions that help in profiling and memory tracing.
 * This file is conditionally compiled and linked into the postscript driver
 * if one of the following are defined - PS_PROFILE, STATPROF, PS_MEMTRACE.
 */

#include "generic.h"
#include "..\..\..\..\..\core\inc\krnlcmn.h"  // For GetProcessDword()

#pragma code_seg(_DEBUGSEG)


typedef void _huge* HPVOID;

#ifdef PS_MEMTRACE
#undef GlobalAlloc
#undef GlobalFree

HANDLE    hFile;
OFSTRUCT  ofFileStruct;

void FAR PASCAL MemCheckStart(void)
{

    UINT    flags = OF_WRITE;

    if ((hFile = OpenFile("c:\\pscript.mem", (LPOFSTRUCT) &ofFileStruct,
                          OF_EXIST)) == HFILE_ERROR)
      flags |= OF_CREATE;

    if (hFile = OpenFile("c:\\pscript.mem", (LPOFSTRUCT) &ofFileStruct, flags))
    {
        _llseek(hFile, 0, 2); /* Move to end of file */
       _lwrite(hFile, (HPVOID) "*********xxxxxx*********\r\n",26);
    }

}


void FAR PASCAL MemCheckEnable(void)
{
    if (hFile)
       _lwrite(hFile, (HPVOID) "********* Begin Enable *********\r\n",34);
}


void FAR PASCAL MemCheckDisable(void)
{
    if (hFile)
    {
       _lwrite(hFile, (HPVOID) "********* End Disable *********\r\n",33);
      _lclose(hFile);
      MemCheckStart();
   }
}


void FAR PASCAL MemCheckEnd(void)
{
    if (hFile)
      _lclose(hFile);
}


HGLOBAL FAR PASCAL MemCheckGlobalAlloc(UINT fuAlloc, DWORD cbAlloc,
                                       LPSTR lpszFile, int line)
{
    HGLOBAL rc;
    char    buffer[100];

    rc = GlobalAlloc(fuAlloc, cbAlloc);

    if (hFile)
      _lwrite(hFile, (HPVOID) buffer,
              wsprintf(buffer,
                  "Alloc Handle: 0x%x, At File %s Line #%d: Bytes %lu(0x%lx)\r\n",
                  rc, lpszFile, line, cbAlloc, cbAlloc));
    return rc;
}


HGLOBAL FAR PASCAL MemCheckGlobalFree(HGLOBAL hglb, LPSTR lpszFile, int line)
{
    HGLOBAL rc;
    char    buffer[100];

    rc = GlobalFree(hglb);

    if (hFile)
      _lwrite(hFile, (HPVOID) buffer,
              wsprintf(buffer,
                 "Free  Handle: 0x%x, At File %s Line #%d, Return value:0x%x\r\n",
                 hglb, lpszFile, line, rc));
    return rc;
}

#endif

#if (defined(PS_PROFILE) || defined(STATPROF))
#if 0
PROFREC PsProfile[MAXPROFRECORDS];
#else
LPPROFREC PsProfile = NULL;
#endif
BOOL bInitStat;
BOOL bStatRunning;

#ifdef STATPROF
#include <sys\stat.h>
#endif

void FAR PASCAL InitProfile(void)
{
    LPPROFREC lpProf;
    int       i;

    if (PsProfile)
        return;
    PsProfile =
        (LPPROFREC)GlobalAllocPtr(GHND, MAXPROFRECORDS * sizeof(PROFREC));
    lpProf = PsProfile;
    for (i=0; i<MAXPROFRECORDS; i++) {
        lpProf->time = 0;
        lpProf->szStr[0] = '\0';
        lpProf->nCalls = 0;
        lpProf++;
    }

#ifdef STATPROF
    if (! bInitStat) {
        InitStat();
        ConfigElapsed();
        bInitStat = TRUE;
        bStatRunning = FALSE;
    }
#endif
}

void FAR PASCAL EndProfile(void)
{
    /* Write profile info to file */
    OFSTRUCT  ofFileStruct;
    LPPROFREC lpProf = PsProfile;
    HFILE   hFile;
    char    buffer[200];
    UINT    flags = OF_WRITE;
    int     i;
    char    *msec="msec", *usec="usec", *szUnits;
    LONG    lTotal = 0;
    struct _dosdate_t dosdate;
    struct _dostime_t dostime;
#ifdef STATPROF
    szUnits = usec;
#else
    szUnits = msec;
#endif

    _dos_getdate(&dosdate);
    _dos_gettime(&dostime);
    if ((hFile = OpenFile("c:\\pscript.prf", (LPOFSTRUCT) &ofFileStruct,
                          OF_EXIST)) == HFILE_ERROR)
      flags |= OF_CREATE;

    if (hFile = OpenFile("c:\\pscript.prf", (LPOFSTRUCT) &ofFileStruct, flags)) {
        _llseek(hFile, 0, 2); /* Move to end of file */
        _lwrite(hFile, (HPVOID) "\n",2);

        _lwrite(hFile, (HPVOID) buffer,
             wsprintf(buffer, "%2.2u/%2.2u/%4.4u  %2.2u:%2.2u:%2.2u\n",
             dosdate.day, dosdate.month, dosdate.year, dostime.hour, dostime.minute, dostime.second));
        _lwrite(hFile, (HPVOID) buffer,
             wsprintf(buffer, "Total Time(%s)     %%      Hit Count     Function Name\n",
             (LPSTR)szUnits));
        _lwrite(hFile, (HPVOID) buffer,
             wsprintf(buffer, "----------------------------------------------------------\n"));

        for (i=0; i<MAXPROFRECORDS; i++) {
            lTotal += lpProf->time;
            lpProf++;
        }
        lpProf = PsProfile;
        for (i=0; i<MAXPROFRECORDS; i++) {
            if (lpProf->szStr[0])
            {
              _lwrite(hFile, (HPVOID) buffer,
                 wsprintf(buffer, "  %10lu      %5lu      %5lu        ",
                    lpProf->time, (lpProf->time*100)/lTotal, lpProf->nCalls));
              _lwrite(hFile, (HPVOID) buffer,
                 wsprintf(buffer, "%s\n", lpProf->szStr ));
            }
            lpProf++;
        }
        _lclose(hFile);
    }
#ifdef STATPROF
    StopElapsed();
    ResetElapsed();
    bStatRunning = FALSE;
#endif

    GlobalFreePtr( PsProfile);
    PsProfile = NULL;
}


BOOL _loadds FAR PASCAL PrfDevBitBlt(LP lpDest,short DestX,short DestY,LPBITMAP lpSrc,
                             short SrcX,short SrcY,short XExt,short YExt,
                             DWORD dRop, LPPBRUSH lpPBrush,LPDRAWMODE lpDrawMode)
{
    BOOL rc;

    START_PROFILE("BitBlt", PRFBITBLT);

    rc = DevBitBlt(lpDest, DestX, DestY, lpSrc, SrcX, SrcY, XExt, YExt, dRop,
                   lpPBrush, lpDrawMode);

    STOP_PROFILE(PRFBITBLT);

    return rc;
}

DWORD _loadds FAR PASCAL PrfColorInfo(LP lp,DWORD dColorIn,LPPCOLOR lpPColor)
{
    DWORD rc;

    START_PROFILE("ColorInfo", PRFCOLORINFO);

    rc = ColorInfo(lp, dColorIn, lpPColor);

    STOP_PROFILE(PRFCOLORINFO);

    return rc;
}

#if 1
WORD _loadds FAR PASCAL PrfControl(LP lpDevice,WORD wEscNum,LP lpInData,
                                   LP lpOutData)
{
    LPPDEVICE lppd;
    WORD wRC=0;

    // ResetDC puts the old pdevice into "lpInData"
    lppd=(LPPDEVICE) lpDevice;

    // make sure its our pdevice
    if (lppd->sMagic == LUCAS)
    {
        if ( fEnabledLppd( lppd ) )
        {
          // Control() never causes state transitions, though
          // individual ESC handlers may.

            switch(wEscNum)
            {
              case NEWFRAME:
               START_PROFILE("NEWFRAME", PRFNEWFRAME);
               wRC = ESCNewFrame(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFNEWFRAME);
              break;

              case ABORTDOC:
               START_PROFILE("ABORTDOC", PRFABORTDOC);
               wRC = ESCAbortDoc(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFABORTDOC);
              break;

              case NEXTBAND:
               START_PROFILE("NEXTBAND", PRFNEXTBAND);
               wRC = ESCNextBand(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFNEXTBAND);
              break;

              case SETCOLORTABLE:
               START_PROFILE("SETCOLORTABLE", PRFSETCOLORTABLE);
               wRC = ESCSetColorTable(lppd,lpInData,lpOutData);
               START_PROFILE("", PRFSETCOLORTABLE);
              break;

              case GETCOLORTABLE:
               START_PROFILE("GETCOLORTABLE", PRFGETCOLORTABLE);
               wRC = 0;
               STOP_PROFILE(PRFGETCOLORTABLE);
              break;

              case FLUSHOUTPUT:
               START_PROFILE("FLUSHOUTPUT", PRFFLUSHOUTPUT);
               wRC = ESCFlushOutput(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFFLUSHOUTPUT);
              break;

              case DRAFTMODE:
               START_PROFILE("DRAFTMODE", PRFDRAFTMODE);
               wRC = 0;
               STOP_PROFILE(PRFDRAFTMODE);
              break;

              case QUERYESCSUPPORT:
               START_PROFILE("QUERYESCSUPPORT", PRFQUERYESCSUPPORT);
               wRC = ESCQueryEscSupport(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFQUERYESCSUPPORT);
              break;

              case SETABORTPROC:
               START_PROFILE("SETABORTPROC", PRFSETABORTPROC);
               wRC = ESCSetAbortProc(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETABORTPROC);
              break;

              case STARTDOC:
               INIT_PROFILE();
//               START_PROFILE("Doc Profile", DOCPRINT);
               START_PROFILE("STARTDOC", PRFSTARTDOC);
               wRC = ESCStartDoc(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSTARTDOC);
              break;

              case ENDDOC:
               START_PROFILE("ENDDOC", PRFENDDOC);
               wRC = ESCEndDoc(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFENDDOC);
//               STOP_PROFILE(DOCPRINT);
               END_PROFILE();
              break;

              case GETPHYSPAGESIZE:
               START_PROFILE("GETPHYSPAGESIZE", PRFGETPHYSPAGESIZE);
               wRC = ESCGetPhysPageSize(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFGETPHYSPAGESIZE);
              break;

              case GETPRINTINGOFFSET:
               START_PROFILE("GETPRINTINGOFFSET", PRFGETPRINTINGOFFSET);
               wRC = ESCGetPrintingOffset(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFGETPRINTINGOFFSET);
              break;

              case GETSCALINGFACTOR:
               START_PROFILE("GETSCALINGFACTOR", PRFGETSCALINGFACTOR);
               wRC = ESCGetScalingFactor(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFGETSCALINGFACTOR);
              break;

              case SETCOPYCOUNT:
               START_PROFILE("SETCOPYCOUNT", PRFSETCOPYCOUNT);
               wRC = ESCSetCopyCount(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETCOPYCOUNT);
              break;

              case SELECTPAPERSOURCE:
               START_PROFILE("SELECTPAPERSOURCE", PRFSELECTPAPERSOURCE);
               wRC = 0;
               STOP_PROFILE(PRFSELECTPAPERSOURCE);
              break;

              case PASSTHROUGH:
               START_PROFILE("PASSTHROUGH", PRFPASSTHROUGH);
               if (lppd->job.bfESCOpenChannel) {
                   wRC = ESCPostScriptPass(lppd,lpInData,lpOutData);
               }
               else {
                   wRC = ESCPassThrough(lppd,lpInData,lpOutData);
               }
               STOP_PROFILE(PRFPASSTHROUGH);
              break;

              case GETTECHNOLOGY:
               START_PROFILE("GETTECHNOLOGY", PRFGETTECHNOLOGY);
               wRC = ESCGetTechnology(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFGETTECHNOLOGY);
              break;

              case SETLINECAP:
               START_PROFILE("SETLINECAP", PRFSETLINECAP);
               wRC = ESCSetLineCap(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETLINECAP);
              break;

              case SETLINEJOIN:
               START_PROFILE("SETLINEJOIN", PRFSETLINEJOIN);
               wRC = ESCSetLineJoin(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETLINEJOIN);
              break;

              case SETMITERLIMIT:
               START_PROFILE("SETMITERLIMIT", PRFSETMITERLIMIT);
               wRC = ESCSetMiterLimit(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETMITERLIMIT);
              break;

              case BANDINFO:
               START_PROFILE("BANDINFO", PRFBANDINFO);
               wRC = 0;
               STOP_PROFILE(PRFBANDINFO);
              break;

              case DRAWPATTERNRECT:
               START_PROFILE("DRAWPATTERNRECT", PRFDRAWPATTERNRECT);
               wRC = 0;
               STOP_PROFILE(PRFDRAWPATTERNRECT);
              break;

              case GETVECTORPENSIZE:
               START_PROFILE("GETVECTORPENSIZE", PRFGETVECTORPENSIZE);
               wRC = 0;
               STOP_PROFILE(PRFGETVECTORPENSIZE);
              break;

              case GETVECTORBRUSHSIZE:
               START_PROFILE("GETVECTORBRUSHSIZE", PRFGETVECTORBRUSHSIZE);
               wRC = 0;
               STOP_PROFILE(PRFGETVECTORBRUSHSIZE);
              break;

              case ENABLEDUPLEX:
               START_PROFILE("ENABLEDUPLEX", PRFENABLEDUPLEX);
               wRC = ESCEnableDuplex(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFENABLEDUPLEX);
              break;

              case GETSETPAPERBINS:
               START_PROFILE("GETSETPAPERBINS", PRFGETSETPAPERBINS);
               wRC = ESCGetSetPaperBins(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFGETSETPAPERBINS);
              break;

              case GETSETPAPERORIENTATION:
               START_PROFILE("GETSETPAPERORIENTATION", PRFGETSETPAPERORIENTATION);
               wRC = ESCGetSetPaperOrientation(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFGETSETPAPERORIENTATION);
              break;

              case ENUMPAPERBINS:
               START_PROFILE("ENUMPAPERBINS", PRFENUMPAPERBINS);
               wRC = ESCEnumPaperBins(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFENUMPAPERBINS);
              break;

              case SETDIBSCALING:
               START_PROFILE("SETDIBSCALING", PRFSETDIBSCALING);
               wRC = ESCSetDIBScaling(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETDIBSCALING);
              break;

              case EPSPRINTING:
               START_PROFILE("EPSPRINTING", PRFEPSPRINTING);
               wRC = ESCEPSPrinting(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFEPSPRINTING);
              break;

              case ENUMPAPERMETRICS:
               START_PROFILE("ENUMPAPERMETRICS", PRFENUMPAPERMETRICS);
               wRC = ESCEnumPaperMetrics(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFENUMPAPERMETRICS);
              break;

              case GETSETPAPERMETRICS:
               START_PROFILE("GETSETPAPERMETRICS", PRFGETSETPAPERMETRICS);
               wRC = ESCGetSetPaperMetrics(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFGETSETPAPERMETRICS);
              break;

              case GETVERSION:
               START_PROFILE("GETVERSION", PRFGETVERSION);
               wRC = 0;
               STOP_PROFILE(PRFGETVERSION);
              break;

          case GETSETSCREENPARAMS:
               wRC = ESCGetSetScreenParams(lppd,lpInData,lpOutData);
              break;

          case GETDIBSUPPORT:
           wRC = ESCGetDIBSupport(lppd,lpInData,lpOutData);
              break;

              case POSTSCRIPTDATA:
               START_PROFILE("POSTSCRIPTDATA", PRFPOSTSCRIPTDATA);
               wRC = ESCPassThrough(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFPOSTSCRIPTDATA);
              break;

              case POSTSCRIPTIGNORE:
               START_PROFILE("POSTSCRIPTIGNORE", PRFPOSTSCRIPTIGNORE);
               wRC = ESCPostScriptIgnore(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFPOSTSCRIPTIGNORE);
              break;

              case GETEXTENDEDTEXTMETRICS:
               START_PROFILE("GETEXTENDEDTEXTMETRICS", PRFGETEXTENDEDTEXTMETRICS);
               wRC = ESCGetExtendedTextMetrics(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFGETEXTENDEDTEXTMETRICS);
              break;

              case GETEXTENTTABLE:
               START_PROFILE("GETEXTENTTABLE", PRFGETEXTENTTABLE);
//               wRC = ESCGetExtentTable(lppd,lpInData,lpOutData);
               wRC = 0;
               STOP_PROFILE(PRFGETEXTENTTABLE);
              break;

              case GETPAIRKERNTABLE:
               START_PROFILE("GETPAIRKERNTABLE", PRFGETPAIRKERNTABLE);
               wRC = 0;
               STOP_PROFILE(PRFGETPAIRKERNTABLE);
              break;

              case GETTRACKKERNTABLE:
               START_PROFILE("GETTRACKKERNTABLE", PRFGETTRACKKERNTABLE);
               wRC = 0;
               STOP_PROFILE(PRFGETTRACKKERNTABLE);
              break;

              case EXTEXTOUT:
               START_PROFILE("EXTEXTOUT", PRFEXTEXTOUT);
               wRC = 0;
               STOP_PROFILE(PRFEXTEXTOUT);
              break;

              case GETFACENAME:
               START_PROFILE("GETFACENAME", PRFGETFACENAME);
               wRC = ESCGetFaceName(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFGETFACENAME);
              break;

              case DOWNLOADFACE:
               START_PROFILE("DOWNLOADFACE", PRFDOWNLOADFACE);
               wRC = ESCDownLoadFace(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFDOWNLOADFACE);
              break;

              case ENABLERELATIVEWIDTHS:
               START_PROFILE("ENABLERELATIVEWIDTHS", PRFENABLERELATIVEWIDTHS);
               wRC = 0;
               STOP_PROFILE(PRFENABLERELATIVEWIDTHS);
              break;

              case ENABLEPAIRKERNING:
               START_PROFILE("ENABLEPAIRKERNING", PRFENABLEPAIRKERNING);
               wRC = ESCEnablePairKerning(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFENABLEPAIRKERNING);
              break;

              case SETKERNTRACK:
               START_PROFILE("SETKERNTRACK", PRFSETKERNTRACK);
               wRC = ESCSetKernTrack(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETKERNTRACK);
              break;

              case SETALLJUSTVALUES:
               START_PROFILE("SETALLJUSTVALUES", PRFSETALLJUSTVALUES);
               wRC = ESCSetAllJustValues(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETALLJUSTVALUES);
              break;

              case SETCHARSET:
               START_PROFILE("SETCHARSET", PRFSETCHARSET);
               wRC = ESCSetCharset(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETCHARSET);
              break;

              case BEGINPATH:
               START_PROFILE("BEGINPATH", PRFBEGINPATH);
               wRC = ESCBeginPath(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFBEGINPATH);
              break;

              case CLIPTOPATH:
               START_PROFILE("CLIPTOPATH", PRFCLIPTOPATH);
               wRC = ESCClipToPath(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFCLIPTOPATH);
              break;

              case ENDPATH:
               START_PROFILE("ENDPATH", PRFENDPATH);
               wRC = ESCEndPath(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFENDPATH);
              break;

              case EXTDEVICECAPS:
               START_PROFILE("EXTDEVICECAPS", PRFEXTDEVICECAPS);
               wRC = ESCExtDeviceCaps(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFEXTDEVICECAPS);
              break;

              case RESTORECTM:
               START_PROFILE("RESTORECTM", PRFRESTORECTM);
               wRC = ESCRestoreCTM(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFRESTORECTM);
              break;

              case SAVECTM:
               START_PROFILE("SAVECTM", PRFSAVECTM);
               wRC = ESCSaveCTM(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSAVECTM);
              break;

              case SETARCDIRECTION:
               START_PROFILE("SETARCDIRECTION", PRFSETARCDIRECTION);
               wRC = ESCSetArcDirection(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETARCDIRECTION);
              break;

              case SETBACKGROUNDCOLOR:
               START_PROFILE("SETBACKGROUNDCOLOR", PRFSETBACKGROUNDCOLOR);
               wRC = ESCSetBackgroundColor(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETBACKGROUNDCOLOR);
              break;

              case SETPOLYMODE:
               START_PROFILE("SETPOLYMODE", PRFSETPOLYMODE);
               wRC = ESCSetPolyMode(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETPOLYMODE);
              break;

              case SETSCREENANGLE:
               START_PROFILE("SETSCREENANGLE", PRFSETSCREENANGLE);
               wRC = ESCSetScreenAngle(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETSCREENANGLE);
              break;

              case SETSPREAD:
               START_PROFILE("SETSPREAD", PRFSETSPREAD);
               wRC = ESCSetSpread(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETSPREAD);
              break;

              case TRANSFORMCTM:
               START_PROFILE("TRANSFORMCTM", PRFTRANSFORMCTM);
               wRC = ESCTransformCTM(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFTRANSFORMCTM);
              break;

              case SETCLIPBOX:
               START_PROFILE("SETCLIPBOX", PRFSETCLIPBOX);
               wRC = ESCSetClipBox(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETCLIPBOX);
              break;

              case SETBOUNDS:
               START_PROFILE("SETBOUNDS", PRFSETBOUNDS);
               wRC = ESCSetBounds(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETBOUNDS);
              break;

//********* New Aldus Escapes **********************************

              case OPENCHANNEL:
               START_PROFILE("OPENCHANNEL", PRFOPENCHANNEL);
               wRC = ESCOpenChannel(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFOPENCHANNEL);
              break;

              case DOWNLOADHEADER:
               START_PROFILE("DOWNLOADHEADER", PRFDOWNLOADHEADER);
               wRC = ESCDownLoadHeader(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFDOWNLOADHEADER);
              break;

              case CLOSECHANNEL:
               START_PROFILE("CLOSECHANNEL", PRFCLOSECHANNEL);
               wRC = ESCCloseChannel(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFCLOSECHANNEL);
              break;

              case SETGDIXFORM:
               START_PROFILE("SETGDIXFORM", PRFSETGDIXFORM);
               wRC = ESCSetGDIXForm(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFSETGDIXFORM);
              break;

              case RESETPAGE:
               START_PROFILE("RESETPAGE", PRFRESETPAGE);
               wRC = ESCResetPage(lppd,lpInData,lpOutData);
               STOP_PROFILE(PRFRESETPAGE);
              break;

              case POSTSCRIPT_PASSTHROUGH:
               START_PROFILE("POSTSCRIPT_PASSTHROUGH", PRFPOSTSCRIPT_PASSTHROUGH);
               if (!(GetProcessDword(NULL, GPD_FLAGS) & GPF_WIN16_PROCESS) &&
                   (GetAppCompatFlags(0) & GACF_FORCEREGPASSTHRU))
               {
                   wRC = ESCPassThrough(lppd, lpInData, lpOutData);
               }
               else
               {
                  wRC = ESCPostScriptPass(lppd,lpInData,lpOutData);
               }

               STOP_PROFILE(PRFPOSTSCRIPT_PASSTHROUGH);
              break;

              case RESETDC:
               START_PROFILE("RESETDC", PRFRESETDC);
               wRC = ESCResetDC(lppd,(LPPDEVICE)lpInData);
               STOP_PROFILE(PRFRESETDC);
              break;

              // Special Passthrough, 5-1-1995
              case SPCLPASSTHROUGH:  // kept for AdobePS 3.01's backward compatible
                wRC = ESCSpecialPass(lpDevice, lpInData, lpOutData);
               break;
            
              case SPCLPASSTHROUGH2:  // callable by multiple times - new ID to diff from 3.0.1
               // In this case, the first 4 bytes is a DWORD to sepcify vmUsage.
               lppd->vmUsedPreStartDoc += (float) *((LPDWORD)lpInData) ;
               wRC = ESCSpecialPass(lpDevice, (LP)((LPBYTE)lpInData+sizeof(DWORD)), lpOutData);
              break;

#ifndef MICROSOFT_DRIVER_VERSION
              case SPCLPSINJECTION:   // callable by multiple times          new ID for 4.2
               // The first 4 bytes is a DWORD to sepcify length of PSData
               wRC = ESCPSInjection(lpDevice, lpInData, lpOutData);
              break;

            
              case DOWNLOADFACESTR:  // send the string for Next (Incremental) Escape(DOWNLOADFACE), added 11-27-95
               wRC = ESCDownLoadFaceStr(lpDevice,lpInData,lpOutData);
              break;
#endif
              default:
               wRC = 0;        // not implemented
              break;
            }
        }
        else
        {   // if (fEnabled...) ... else
              // i.e. we are being called at an illegal time.
            wRC = (WORD)-1;   // Return a general "failure" code.
        }
    }
    return(wRC);
}
#else

WORD _loadds FAR PASCAL PrfControl(LP lpDevice,WORD wEscNum,LP lpInData,LP lpOutData)
{
    WORD rc;
    LPPDEVICE lppd;

    // ResetDC puts the old pdevice into "lpInData"
    lppd=(LPPDEVICE) lpDevice;

    // make sure its our pdevice
    if (lppd->sMagic == LUCAS)
    {
        if ( fEnabledLppd( lppd ) )
        {
          // Control() never causes state transitions, though
          // individual ESC handlers may.

            switch(wEscNum)
            {
               case STARTDOC:
                  INIT_PROFILE();
                  break;

               case ENDDOC:
                  END_PROFILE();
                  break;
            }
        }
    }

    START_PROFILE("Control", PRFCONTROL);

    rc = Control(lpDevice, wEscNum, lpInData, lpOutData);

    STOP_PROFILE(PRFCONTROL);

    return rc;
}
#endif

VOID _loadds FAR PASCAL PrfDevDisable(LP lpDevice)
{
    START_PROFILE("Disable", PRFDISABLE);

    DevDisable(lpDevice);

    STOP_PROFILE(PRFDISABLE);

}

short _loadds FAR PASCAL PrfDevEnable(LP lpData,WORD wStyle,LPSTR lpzDestDevice,
          LPSTR lpzPort,LPDEVMODE lpDevMode)
{
    short rc;

    START_PROFILE("Enable", PRFENABLE);

    rc = DevEnable(lpData, wStyle, lpzDestDevice, lpzPort, lpDevMode);

    STOP_PROFILE(PRFENABLE);

    return rc;
}

WORD _loadds FAR PASCAL PrfEnumDFonts(LP lpDevice, LPSTR lpszFaceName,
                              FARPROC lpCallbackProc, LP lpClientData)
{
    WORD rc;

    START_PROFILE("EnumDFonts", PRFENUMDFONTS);

    rc = EnumDFonts(lpDevice, lpszFaceName, lpCallbackProc, lpClientData);

    STOP_PROFILE(PRFENUMDFONTS);

    return rc;
}

short _loadds FAR PASCAL PrfEnumObj(LP lpDevice,short sStyle,FARPROC lpCallbackProc,
                LP lpClientData)
{
    short rc;

    START_PROFILE("EnumObj", PRFENUMOBJ);

    rc = EnumObj(lpDevice, sStyle, lpCallbackProc, lpClientData);

    STOP_PROFILE(PRFENUMOBJ);

    return rc;
}

short _loadds FAR PASCAL PrfOutput(LP lpDevice,short sStyle,short sCount,LPPOINT lppt,
                           LPPPEN lpPPen,LPPBRUSH lpPBrush,
                           LPDRAWMODE lpDrawMode,LPRECT lpClipRect)
{
    short rc;

    START_PROFILE("Output", PRFOUTPUT);

    rc = Output(lpDevice, sStyle, sCount, lppt, lpPPen, lpPBrush,
                lpDrawMode, lpClipRect);

    STOP_PROFILE(PRFOUTPUT);

    return rc;
}

DWORD _loadds FAR PASCAL PrfPixel(LP lpDevice,short sX,short sY,DWORD dPhysColor,
                          LPDRAWMODE lpDrawMode)
{
    DWORD rc;

    START_PROFILE("Pixel", PRFPIXEL);

    rc = Pixel(lpDevice, sX, sY, dPhysColor, lpDrawMode);

    STOP_PROFILE(PRFPIXEL);

    return rc;
}

WORD _loadds FAR PASCAL PrfRealizeObject(LP lpDevice,short sStyle,LP lpInObj,
                                 LP lpOutObj,LP lpData)
{
    WORD rc;

    switch(sStyle) {
      case OBJ_PEN:
        /* Fall thru */
      case -OBJ_PEN:
        START_PROFILE("Realize Pen", PRFREALIZEPEN);
        rc = RealizeObject(lpDevice, sStyle, lpInObj, lpOutObj, lpData);
        STOP_PROFILE(PRFREALIZEPEN);
        break;
      case OBJ_BRUSH:
        /* Fall thru */
      case -OBJ_BRUSH:
        START_PROFILE("Realize Brush", PRFREALIZEBRUSH);
        rc = RealizeObject(lpDevice, sStyle, lpInObj, lpOutObj, lpData);
        STOP_PROFILE(PRFREALIZEBRUSH);
        break;
      case OBJ_FONT:
        /* Fall thru */
      case -OBJ_FONT:
        START_PROFILE("Realize Font", PRFREALIZEFONT);
        rc = RealizeObject(lpDevice, sStyle, lpInObj, lpOutObj, lpData);
        STOP_PROFILE(PRFREALIZEFONT);
        break;
    }

    return rc;
}

SHORT _loadds FAR PASCAL PrfDevScanLR(LP lpDevice,SHORT sX,SHORT sY,DWORD dPColor,
                              SHORT sStyle)
{
    SHORT rc;

    START_PROFILE("ScanLR", PRFSCANLR);

    rc = DevScanLR(lpDevice, sX, sY, dPColor, sStyle);

    STOP_PROFILE(PRFSCANLR);

    return rc;
}

short _loadds FAR PASCAL PrfDeviceMode(HWND hWnd,HANDLE hInst,LPSTR lpzDevice,
                               LPSTR lpzPort)
{
    short rc;

    START_PROFILE("DeviceMode", PRFDEVMODE);

    rc = DeviceMode(hWnd, hInst, lpzDevice, lpzPort);

    STOP_PROFILE(PRFDEVMODE);

    return rc;
}

DWORD _loadds FAR PASCAL PrfDevExtTextOut(LPPDEVICE   lpdv, int ix, int iy,
                                  LPRECT  lprcClip, LPSTR   lpbSrc, int cbSrc,
                                  LPPSFONTINFO  lpFontInfo, LPDRAWMODE lpdm,
                                  LPTEXTXFORM lpTextXForm, LPSHORT lpdx,
                                  LPRECT  lprcOpaq, WORD    options)
{
    DWORD rc;

    START_PROFILE("ExtTextOut", PRFEXTTEXTOUT);

    rc = DevExtTextOut(lpdv, ix, iy, lprcClip, lpbSrc, cbSrc, lpFontInfo,
                       lpdm, lpTextXForm, lpdx, lprcOpaq, options);

    STOP_PROFILE(PRFEXTTEXTOUT);

    return rc;
}

short _loadds FAR PASCAL PrfDevGetCharWidth(LP lpDevice,LPSHORT lpsCharWidth,
                                    short sFirstChar,short sLastChar,
                                    LPPSFONTINFO lpFontInfo,
                                    LPDRAWMODE lpDrawMode,
                                    LPTEXTXFORM lpTextXForm)
{
    short rc;

    START_PROFILE("GetCharWidth", PRFCHARWIDTH);

    rc = DevGetCharWidth(lpDevice, lpsCharWidth, sFirstChar, sLastChar,
                         lpFontInfo, lpDrawMode, lpTextXForm);

    STOP_PROFILE(PRFCHARWIDTH);

    return rc;
}

SHORT _loadds FAR PASCAL PrfDeviceBitmap(LP lpDevice,SHORT sCommand,LPBITMAP lpBitmap,
                                 LP lpBits)
{
    SHORT rc;

    START_PROFILE("DeviceBitmap", PRFDEVBITMAP);

    rc = DeviceBitmap(lpDevice, sCommand, lpBitmap, lpBits);

    STOP_PROFILE(PRFDEVBITMAP);

    return rc;
}


SHORT _loadds FAR PASCAL PrfFastBorder(LPRECT lpRect,WORD wBorderWidth,WORD wBorderDepth,
                               DWORD dROP,LP lpDevice,LPPBRUSH lpPBrush,
                               LPDRAWMODE lpDrawMode,LPRECT lpClipRect)
{
    SHORT rc;

    START_PROFILE("FastBorder", PRFFASTBORDER);

    rc = FastBorder(lpRect, wBorderWidth, wBorderDepth, dROP, lpDevice,
                    lpPBrush, lpDrawMode, lpClipRect);

    STOP_PROFILE(PRFFASTBORDER);

    return rc;
}

SHORT _loadds FAR PASCAL PrfSetAttribute(LP lpDevice,SHORT sStateNum,SHORT sIndex,
                                 SHORT sAttribute)
{
    SHORT rc;

    START_PROFILE("SetAttribute", PRFSETATTR);

    rc = SetAttribute(lpDevice, sStateNum, sIndex, sAttribute);

    STOP_PROFILE(PRFSETATTR);

    return rc;
}

short _loadds FAR PASCAL PrfDIBToDevice(LP lpDevice,WORD DestX,WORD DestY,WORD Start,
                                WORD RstrLines,LPRECT lpClip,
                                LPDRAWMODE lpDrawMode,LP lpBits,
                                LPBITMAPINFO lpBitmapInfo,LPSTR lpConversion)
{
    short rc;

    START_PROFILE("DIBToDevice", PRFDIBTODEVICE);

    rc = DIBToDevice(lpDevice, DestX, DestY, Start, RstrLines, lpClip,
                     lpDrawMode, lpBits, lpBitmapInfo, lpConversion);

    STOP_PROFILE(PRFDIBTODEVICE);

    return rc;
}


short _loadds FAR PASCAL PrfDevStretchBlt(LP lpDest,short DestX,short DestY,
                                  short DestXE,short DestYE,LPBITMAP DevBitmap,
                                  short SrcX,short SrcY, short SrcXE,short SrcYE,
                                  DWORD rop,LPPBRUSH lpPBrush,
                                  LPDRAWMODE lpDrawMode,LPRECT lpClip)
{
    short rc;

    START_PROFILE("StretchBlt", PRFSTRETCHBLT);

    rc = DevStretchBlt(lpDest, DestX, DestY, DestXE, DestYE, DevBitmap, SrcX,
                       SrcY, SrcXE, SrcYE, rop, lpPBrush, lpDrawMode, lpClip);

    STOP_PROFILE(PRFSTRETCHBLT);

    return rc;
}

short _loadds FAR PASCAL PrfStretchDIB(LP lpDevice,WORD GetSet,
                               WORD DestX,WORD DestY,WORD DestXE,WORD DestYE,
                               WORD SrcX ,WORD SrcY ,WORD SrcXE ,WORD SrcYE ,
                               LP   lpBits,LPBITMAPINFO lpBitmapInfo,
                               LPSTR ConversionInfo,DWORD rop,LPPBRUSH lpPBrush,
                               LPDRAWMODE lpdm,LPRECT lpClip)
{
    short rc;

    START_PROFILE("StetchDIB", PRFSTRETCHDIB);

    rc = StretchDIB(lpDevice, GetSet, DestX, DestY, DestXE, DestYE, SrcX, SrcY,
                    SrcXE, SrcYE, lpBits, lpBitmapInfo, ConversionInfo, rop,
                    lpPBrush, lpdm, lpClip);

    STOP_PROFILE(PRFSTRETCHDIB);

    return rc;
}

short _loadds FAR PASCAL PrfExtDeviceMode(HWND hWnd, HANDLE hInst, LPDEVMODE lpdmOutput,
                                  LPSTR lpDevName, LPSTR lpPort,
                                  LPDEVMODE lpdmInput, LPSTR lpProfile,
                                  WORD wMode)
{
    short rc;

    START_PROFILE("ExtDeviceMode", PRFEXTDEVMODE);

    rc = ExtDeviceMode(hWnd, hInst, lpdmOutput, lpDevName, lpPort,
                       lpdmInput, lpProfile, wMode);

    STOP_PROFILE(PRFEXTDEVMODE);

    return rc;
}


DWORD _loadds FAR PASCAL PrfDeviceCapabilities(LPSTR lpzDevice,LPSTR lpzPort,WORD wIndex,
                                       LP lpOut,LPDEVMODE lpDevMode)
{
    DWORD rc;

    START_PROFILE("DeviceCaps", PRFDEVCAPS);

    rc = DeviceCapabilities(lpzDevice, lpzPort, wIndex, lpOut, lpDevMode);

    STOP_PROFILE(PRFDEVCAPS);

    return rc;
}

#if 0
DWORD _loadds FAR PASCAL PrfStrBlt(LP lp,SHORT sX,SHORT sY,LPRECT lpClipRect,LPSTR lpz,
                           SHORT sCount,LPPSFONTINFO lpFontInfo,
                           LPDRAWMODE lpDrawMode, LPTEXTXFORM lpTextXForm)
{
    DWORD rc;

    START_PROFILE("StrBlt", PRFSTRBLT);

    rc = StrBlt(lp, sX, sY, lpClipRect, lpz, sCount, lpFontInfo,
                lpDrawMode, lpTextXForm);

    STOP_PROFILE(PRFSTRBLT);

    return rc;
}

WORD _loadds FAR PASCAL PrfDevInstall(HWND hWnd, LPSTR lpszModelName, LPSTR lpszOldPort,
                              LPSTR   lpszNewPort)
{
    WORD rc;

    START_PROFILE("DevCaps", PRFDEVCAPS);

    rc = DevInstall(hWnd, lpszModelName, lpszOldPort, lpszNewPort);

    STOP_PROFILE(PRFDEVCAPS);

    return rc;
}


short _loadds WINAPI PrfExtDeviceModePropSheet(HINSTANCE            hInst,
                                       LPDEVMODE            lpdmOutput,
                                       LPSTR                lpDevName,
                                       LPSTR                lpPort,
                                       LPDEVMODE            lpdmInput,
                                       LPSTR                lpProfile,
                                       WORD                 wMode,
                                       LPFNADDPROPSHEETPAGE lpfnAdd,
                                       LPARAM               lParam)
{
    short rc;

    START_PROFILE("ExtDevModePropSheet", PRFPROPSHEET);

    rc = ExtDeviceModePropSheet(hInst, lpdmOutput, lpDevName, lpPort, lpdmInput,
                                lpProfile, wMode, lpfnAdd, lParam);

    STOP_PROFILE(PRFPROPSHEET);

    return rc;
}
#endif
#endif

