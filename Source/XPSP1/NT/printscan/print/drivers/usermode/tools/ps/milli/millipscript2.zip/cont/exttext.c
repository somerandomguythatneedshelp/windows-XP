/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: EXTTEXT.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for ExtTextOut            */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_TEXTOUTSEG)


/* ExtTextOut() options switches */
#define EXTTEXT_D1 0x0002
#define EXTTEXT_D2 0x0004


#define _1BIT     1
#define _2BIT     2

#ifdef ADOBE_DRIVER
// externs from  EXTTEXTW.C for Wide (Composite) font handling.

LONG NEAR TEXTOUTSEG PASCAL ShowTextWide(LPPDEVICE lpdv, int ix, int iy, 
                                          LPWORD lpbSrc, int abscbSrc,
                                          LPPSFONTINFO lpFontInfo, LPDRAWMODE lpdm,
                                          LPTEXTXFORM lpTextXForm, LPSHORT lpdx, 
                                          LPPSFONTINFO TranFontInfo,
                                          long  lsize);
#endif

extern BOOL bATMWorkAround;

/*------------------------------- local functions ------------------------*/

// void NEAR TEXTOUTSEG EscapementTransform(LPPDEVICE  lppd, short  tx,  
//                   short  ty,  short  Escapement);

BOOL NEAR TEXTOUTSEG PASCAL SetJustification(LPPDEVICE, LPDRAWMODE, 
                                             LPJUSTBREAKREC, LPJUSTBREAKREC);
short NEAR TEXTOUTSEG PASCAL GetJustBreak(LPJUSTBREAKREC);
int NEAR TEXTOUTSEG PASCAL KernAmount(int k0, int k1, int p0, int p1, int x, 
                                      int cb);
short NEAR TEXTOUTSEG PASCAL SendClipOrOpaq(LPPDEVICE,WORD,DWORD,LPRECT,LPRECT,
                                            LPRECT, int );
int NEAR TEXTOUTSEG PASCAL PairKern(LPKP lpkp, int iCh1, int iCh2);

VOID NEAR TEXTOUTSEG PASCAL DumpStr(LPPDEVICE lpdv, LPPSFONTINFO lpFontInfo, 
  LPTEXTXFORM lpTextXForm,
  LPDRAWMODE lpdm, int ix, int iy, LPSTR lpbStr, long cxStr, int count,
  int CharExtra, int BreakExtra, LPINT lpdx);
DWORD NEAR TEXTOUTSEG PASCAL ShowStr(LPPDEVICE lpdv, int ix, int iy, 
                                     LPSTR lpbSrc, int cb,
  LPPSFONTINFO lpFontInfo, LPDRAWMODE lpdm, LPTEXTXFORM lpTextXForm, 
  LPSHORT lpdx, LPPSFONTINFO TranFontInfo);
LONG NEAR TEXTOUTSEG PASCAL GetTranStrSize(LPPDEVICE lpdv, 
                                     LPPSFONTINFO lpFontInfo,
                                     LPSTR lpbStr, int count, 
                                     LPWORD lpBreakCnt,
                                     WORD   offset);

DWORD NEAR TEXTOUTSEG PASCAL ShowStrInBBox(LPPDEVICE lpdv,
                                     int ix,
                                     int iy,
                                     LPSTR lpbSrc,
                                     int cb,
                                     LPDRAWMODE  lpdm,
                                     LPTEXTXFORM lpTextXForm,
                                     LPSHORT lpdx,
                                     LPPSFONTINFO TranFontInfo,
                                     long lsize);

DWORD NEAR TEXTOUTSEG PASCAL StrBBox(LPPDEVICE lpdv,
                                     int ix,
                                     int cb,
                                     LPPSFONTINFO  lpFontInfo,
                                     LPDRAWMODE  lpdm,
                                     LPSHORT lpdx);

int NEAR TEXTOUTSEG PASCAL KernAmount(k0, k1, p0, p1, x, cb)
int k0, k1; /* The minimum, maximum kern amount */
int p0, p1; /* The minimum, maximum point size */
int x;      /* The point size of the font being kerned */
int cb;     /* The number of bytes to kern */
{
     int iKernAmount;

     long lk0, lk1;
     long lp0, lp1;
     long lx, lcb;
     long lnum, ldiv;


     if (x<p0)
          iKernAmount = cb * k0;
     else if (x > p1)
          iKernAmount = cb * k1;
     else{
          lk0 = k0;  lk1 = k1;
          lp0 = p0;  lp1 = p1;
          lx = x;    lcb = cb;

          lnum = ((lk1 - lk0) * lx  + (lk0 * lp1 - lk1 * lp0)) * lcb;
          ldiv = lp1 - lp0;
          if (lnum<0)
               lnum -= ldiv/2;
          else
               lnum += ldiv/2;
          iKernAmount = (int)(lnum/ldiv);
     }
     return(iKernAmount);
}

int NEAR TEXTOUTSEG PASCAL PairKern( lpkp, iCh1, iCh2)
LPKP lpkp;      /* Far ptr to the pair kerning table */
int iCh1;       /* The first character of the kerning pair */
int iCh2;       /* The second character of the kerning pair */
{
     int iMax;
     int iMin;
     int i;
     int iKey;
     int iKernAmount;

     if(!lpkp)
       return(0);

     iKey = (iCh2<<8) | (iCh1 & 0x00ff);

     iMin = 0;
     iMax = lpkp->cPairs;
     i = iMax/2;
     while (iMax > iMin){
          if (iKey > lpkp->rgPairs[i].iKey)
               iMin = i + 1;
          else if (iKey < lpkp->rgPairs[i].iKey)
               iMax = i - 1;
          else
               break;
          i = iMin + (iMax - iMin)/2;
     };

     if (lpkp->rgPairs[i].iKey==iKey)
          iKernAmount = lpkp->rgPairs[i].iKernAmount;
     else
          iKernAmount = 0;
     return(iKernAmount);
}

/***********************************************************************
 *SetJustification
 *
 *  Set up the justification records and return TRUE if justification
 *  will be required on the line.  The justification values can come
 *  from two places:
 *
 *  1. Windows GDI SetTextCharacterExtra() and
 *      SetTextJustification(), which handle only
 *      positive justification.
 *  2. The SETALLJUSTVALUES escape, which handles negative
 *      and positive justification.
 *
 *  Windows' justification parameters are stored in the DRAWMODE struct,
 *  while SETALLJUSTVALUES stuff comes from our DEVICE struct.
 *
 *  Aldus Corporation 19 January 1987--sjp
 ************************************************************************/

BOOL NEAR TEXTOUTSEG PASCAL SetJustification(LPPDEVICE lpdv, LPDRAWMODE lpdm, 
                    LPJUSTBREAKREC lpJustifyWB, LPJUSTBREAKREC lpJustifyLTR)
{
     if ( lpdv->text.justType == JUST_standard) {
          /*  Normal Windows justification.
           */
          if (lpdm->TBreakExtra) {
               lpJustifyWB->extra = lpdm->BreakExtra;
               lpJustifyWB->rem = lpdm->BreakRem;
               lpJustifyWB->err = lpdm->BreakErr;
               lpJustifyWB->count = lpdm->BreakCount;
               lpJustifyWB->ccount = 0;
          } else {
               lpJustifyWB->extra = 0;
               lpJustifyWB->rem = 0;
               lpJustifyWB->err = 1;
               lpJustifyWB->count = 0;
               lpJustifyWB->ccount = 0;
          }

          lpJustifyLTR->extra = lpdm->CharExtra;
          lpJustifyLTR->rem = 0;
          lpJustifyLTR->err = 1;
          lpJustifyLTR->count = 0;
          lpJustifyLTR->ccount = 0;
     } else {
          /*  SETALLJUSTVALUES -- the records were filled when the
           *  escape was called, now make local copies.
           */
          MemCopy((LPSTR)lpJustifyWB, (LPSTR) & lpdv->text.jWord,
               sizeof(JUSTBREAKREC));
          MemCopy((LPSTR)lpJustifyLTR, (LPSTR) & lpdv->text.jChar,
               sizeof(JUSTBREAKREC));
     }
     /*  Advise the caller as to whether or not justification
      *  adjustments will be required.
      */
     if (lpJustifyWB->extra || lpJustifyWB->rem || 
          lpJustifyLTR->extra || lpJustifyLTR->rem) {
          return TRUE;
     } else 
          return FALSE;
}


/***********************************************************************
 *GetJustBreak
 *
 *  Calculate the additional pixels to add/subtract from the horizontal
 *  position.
 *Aldus Corporation 19 January 1987--sjp
 ************************************************************************/

short NEAR TEXTOUTSEG PASCAL GetJustBreak (LPJUSTBREAKREC lpJustBreak )
{
     short   adjust = lpJustBreak->extra;

     // Keep Break->err positive and every application of
     //  justification must decrease Break->err
     //  Changed to handle negative Break->rem
     //    29-Mar-1993  -by-  [olegs]

     if ( lpJustBreak->rem >= 0 )
     {
          lpJustBreak->err -= lpJustBreak->rem ;
          if ( lpJustBreak->err <= 0 )        // Overshot - correct it
          {
               adjust++ ;
               lpJustBreak->err += (short)lpJustBreak->count;
          }
     }else
     {
          lpJustBreak->err += lpJustBreak->rem ;
          if ( lpJustBreak->err <= 0 )        // Overshot - correct it
          {
               adjust-- ;
               lpJustBreak->err += (short)lpJustBreak->count;
          }
     }

     // Bump the counter ( if still are within counter limits )
     if( lpJustBreak->count &&
          ( ++lpJustBreak->ccount > lpJustBreak->count ) )
               adjust = 0;

     return adjust;
}


/********************************************************
* Name: TrackKern()
*
* Action: Compute the amount of track kerning to add to
*     the string length.
*
**********************************************************/

int NEAR TEXTOUTSEG PASCAL TrackKern(LPPDEVICE lpdv, LPPSFONTINFO lpFontInfo, int cb)
{
     int iTrack;
     int iKernAmount;
     TRACK FAR * lpTrack;
     LPKT lpkt;
     LPFONTEXTRA FontExtra=(LPFONTEXTRA) BUMPFAR(lpFontInfo,lpFontInfo->dfDriverInfo);

     iKernAmount = 0;
     lpkt = (LPKT) BUMPFAR (lpFontInfo, FontExtra->dwTrackKern);
     iTrack = lpdv->text.sTrack;
     if (lpkt && iTrack > 0) 
     {
          if (iTrack <= lpkt->cTracks) 
       {
               lpTrack = &lpkt->rgTracks[lpdv->text.sTrack - 1];

               iKernAmount = KernAmount(lpTrack->iKernMin, lpTrack->iKernMax,
                    lpTrack->iPtMax, lpTrack->iPtMin, Scale(FontExtra->sPSyScale, 72, 
                         lpdv->DeviceRes.x_res), cb);
          }
     }
     return(iKernAmount);
}


/****************************************************************
* Name: GetTranStrSize()
*
* Action: Get the size of the PS string taking in account
*  all possible Track Kerning, Pair Kerning ....
*
*  offset is a new variable needed to sync the substring lpbStr to the 
*  charwidth array (lpTranCharWidths) of the entire string !
*
*   ATTENTION: The result is returned in the DIGITIZED font units!!!!
*
*****************************************************************/

LONG NEAR TEXTOUTSEG PASCAL GetTranStrSize(LPPDEVICE lpdv, 
                                           LPPSFONTINFO lpFontInfo,
                                           LPSTR lpbStr, int count,
                                           LPWORD lpBreakCount,
                                           WORD   offset)
{
   LPFONTEXTRA FontExtra = NULL;
   LPKP lpPairKern = NULL;
   LPTTFONTINFO lpTTFontInfo;
   short   i,j;
   int     iCh;        // Current char
   int     iPrevCh;    // Previous char
   LPWORD  lpTranCharWidths;   // LP to array of widths on TRAN side
                               //  in the units that this font ws digitized.

   //  Font Parameters
   WORD         dfBreakChar ;
   WORD         dfFirstChar ;
   BOOL        fVariablePitch;
   WORD    HighByte ;   
   LPREALIZEBUFS  lpCache ;
   LPGIASSIGNED  lpMatchGas = NULL; // would be set latter if SOI

   DWORD    TranStrWidth  ; // Width of the string on TRAN side

   if ( count == 0 )
            return (0L) ;


   lpCache = &lpdv->GlobalBuffer.RealizeBufs ;


   // Get information about the font - first, last chars, break character

   if(lpFontInfo->dfType & PF_GLYPH_INDEX)
   {
      dfFirstChar = 0 ;
      
      dfBreakChar      = *(LPWORD)&lpFontInfo->dfDefaultChar  ;
   }
   else
   {
      dfFirstChar     = ((WORD)lpFontInfo->dfFirstChar) & 0x00ff;
      dfBreakChar     = ((WORD)(lpFontInfo->dfBreakChar + dfFirstChar)) & 0x00ff;
   }

   if ( lpFontInfo->dfType & TYPE_TRUETYPE )
   {
      lpTTFontInfo    = (LPTTFONTINFO) ((LPSTR)lpFontInfo +
                                 lpFontInfo->dfBitsOffset);

      HighByte = lpTTFontInfo->HighByte  ;

      if ( lpFontInfo->dfType & TYPE_OUTLINE )
         lpTranCharWidths = lpCache->lpdWidths + lpCache->offsetWidths;
      else
         lpTranCharWidths = lpCache->rgwWidths + lpCache->offsetWidths;
   }
   else
   {
      HighByte = 0 ;

      FontExtra  = (LPFONTEXTRA) BUMPFAR( lpFontInfo, lpFontInfo->dfDriverInfo);
      lpTranCharWidths = lpCache->devlpdWidths + lpCache->offsetWidths;
   }


   //*******************************************************************
   if ( lpFontInfo->dfPitchAndFamily & 1) // Variable width font
   {
         fVariablePitch = TRUE;
   }
   else
   {
      fVariablePitch   = FALSE;

#if 0
      forget all this stuff about average widths.

      if ( lpFontInfo->dfType & TYPE_TRUETYPE )
      {
         if ( lpFontInfo->dfType & TYPE_OUTLINE )
            {
            TAvgWidth = lpTTFontInfo->xFontInfo->dfAvgWidth ;
            }
         else
            {
            TAvgWidth = lpFontInfo->dfAvgWidth ;
         //  Take the width of any character  NOT!
         //  TAvgWidth = lpTranCharWidths[dfFirstChar+32] ;
            }
      }
      else
      {
         TAvgWidth = FontExtra->psAvgWidth ;
      }
#endif
   }

   /*  Zip through the string substituting any
   * characters outside of the valid range into dfDefaultChar.
   * Also apply Pair Kerning rules to the character pairs.
   */
   TranStrWidth    = 0L;
   iCh             = 0;
   if (lpBreakCount)
       *lpBreakCount = 0;

/* The input string might be in SOI format already.  So we need to
   translate it back to the real character.
   */
   if ( lpFontInfo->dfType & TYPE_TRUETYPE )
   {
            lpTTFontInfo    = (LPTTFONTINFO) ((LPSTR)lpFontInfo +
                                 lpFontInfo->dfBitsOffset);
   }
   else
      lpTTFontInfo = NULL;

   if (lpTTFontInfo)
   {
      char FontName[FONTNAMESIZE];  // for TT font, we use "MSTT31abcd00" -maximal length=14
      LPSTR lpFontName = (LPSTR)FontName;

      // Get the  SOI assigment pointer.
      lstrcpy(FontName, lpTTFontInfo->PSName); // make a local copy we can modify
      REMOVE_SHOW_ORDER_SUBSTRING(lpFontName);   // remove the fontid 00.
      if (CheckGIAssignedRecord(lpdv, FontName, &lpMatchGas)==0)
              lpMatchGas = NULL;
   }


   for ( i = 0,j = 0; i  < count ; i++ )
   {
      iPrevCh = iCh;
      iCh = ( (int) lpbStr[i] ) & 0x00FF ;
      iCh = HighByte | (WORD)iCh ;
      if (lpMatchGas)
      { //convert SOI to GI or CC.
         (WORD) iCh = GetGIFromAssignmentID(lpMatchGas, (WORD) iCh);
      }

//      if ( ((WORD)iCh   < dfFirstChar   ) ||
//            ((WORD)iCh   > dfLastChar    )   )
//               iCh  =  dfDefaultChar ;

      // Update BreakCount
      if (((WORD) iCh == dfBreakChar) && lpBreakCount)
          (*lpBreakCount)++;

      // Get character width: no table - use average width
      //  Width is calculated in PS font units - 1/1000 of EM-square
      //  or in native digitizer units in the case of TT->Type42
      TranStrWidth += lpTranCharWidths[i+offset] ;

      if( fVariablePitch  &&      // Apply pair kerning
         !(lpFontInfo->dfType & TYPE_TRUETYPE )    &&   // to PS font only
         lpdv->text.bfPairKern )
      {
          lpPairKern = (LPKP) BUMPFAR(lpFontInfo, FontExtra->dwPairKern);
               TranStrWidth += PairKern(lpPairKern, iPrevCh,
                                             iCh) ;
      }

   }

   //  If Postscript output - correct  the size by applying Track Kerning
   if (!(lpFontInfo->dfType & TYPE_TRUETYPE))
   {
      TranStrWidth += TrackKern(lpdv, lpFontInfo, count) ;
      // Convert string width from PS units to device units
      TranStrWidth *= FontExtra->sPSxScale;
   }
   else       // TrueType font
   {
      // Scale the width for all Type 1 and Type 42 chars.
      // Type 3 doesn't require that because the characters' widths
      // was already scaled by initrgwWidths(lpdv, lpFontInfo) call
      if ( lpFontInfo->dfType & TYPE_OUTLINE )
      {
         TranStrWidth *= lpTTFontInfo->sx ;
      }
   }

   return(TranStrWidth);
   // Comment : 20-Jun-1994  -by-  [olegs]
   // This function should return the width of the string as DWORD 
   //  with maximum available precision. To do that we accumulate the
   //  width of the string in the native units for the specific type of
   //  the font being used:
   //     - TTRefEM for Type 1 and Type 42
   //     - GDI Pixels for Type 3 fonts
   //     - 1000-per-EM for real PostScript font
   //     - Whatever was told to us for resident TT fonts that have a .PFM
   //
}


/****************************************************************
* Name: DumpStr()
*
* Action: Execute the Postscript calls necessary to output a
* string of text.
* The function takes as parameters the string to output,  the length
*   of the resulting output in GDI space. It will try to find the best
*   fit for the given string on the TRAN side.
*
*   The algorithm so far is:
*   -   Find the size of the string on the TRAN side using
*    all applicable modifications - Track Kerning, Pair Kerning,....
*   -   Calculate how many additional points should we add to every
*    regular character and to the every break character.
*   -   Make a call on TRAN side with those parameters.
*
*****************************************************************/

#pragma  optimize ("se", off)
#pragma  optimize ("d", on)




VOID NEAR TEXTOUTSEG PASCAL DumpStr(LPPDEVICE lpdv, LPPSFONTINFO lpFontInfo, 
  LPTEXTXFORM lpTextXForm,
  LPDRAWMODE lpdm, int ix, int iy, LPSTR lpbStr, long cxStr, int count,
  int CharExtra, int BreakExtra, LPINT lpdx)
{
     short   i;
     int     iCh;            // Current char
     LPSTR   lpSubString ;   // Pointer to the current run substring
     POINT   CurrentPoint ;  // Where to place the current run
     LONG      lNextPos;    // Relative position of the next char in run

     //  Font Parameters
     int         dfBreakChar ;
     int         dfFirstChar ;

     LONG        lCharExtra;
     LONG        lBreakExtra;
     LONG        lError;   // Difference between GDI and TRAN sizes

     WORD        CharCount   ;   // Number of chars in the Substring
     WORD        BreakCount  ;   // Number of Break characters in the string
     WORD    HighByte ;   
     LONG        lGDIStrWidth;      // Width of the string in GDI units
     DWORD       EM ;
     LPSTR lpLastSubString;
     WORD wLastCharCount;
     LPLONG lplCharExtra; // a buffer for each lCharExtra value per run
     WORD wRuns;
     BOOL bCont;
     LPGIASSIGNED  lpMatchGas = NULL; // would be set latter if SOI
     LPTTFONTINFO lpTTFontInfo = NULL;

     if ( count == 0 )
             return;

     // Find the value of EM - the size of the digitization grid
     // for the specific font.
     // The GetTranStrSize() function will return the size of the
     //  output string in EM-units.
     // For Type 1, 3, 42 - any TT font - it is usually 2048,
     // for PostScript font - it can be either 1000 for real PostScript
     // fonts, or something else for Printer-resident TT fonts.
     //  Added  20-Jun-1994  -by-  [olegs]

     if ( lpFontInfo->dfType & TYPE_TRUETYPE )
     {
        // For Type 1 and Type 42 the width of the string returned by
        // the call to the  GetTranStrSize() function is in TTRefEM units,
        // while for Type 3 it will be in GDI pixels.
        if ( lpFontInfo->dfType & TYPE_OUTLINE )
        {
            LPTTFONTINFO lpTTFontInfo;
            lpTTFontInfo    = (LPTTFONTINFO) ((LPSTR)lpFontInfo +
                                 lpFontInfo->dfBitsOffset);
            EM = (DWORD) lpTTFontInfo->TTRefEM ;
        }else
        {
            EM = 1; // One Type 3 unit is equal 1 GDI pixel
        }
     }else
     {
        LPPFMEXTENSION lpPFMExt;
        LPETM lpETM;
        lpPFMExt = (LPPFMEXTENSION) ((LPBYTE) lpFontInfo + sizeof(PFMHEADER));
        lpETM = (LPETM) ((LPBYTE) lpFontInfo + lpPFMExt->dfExtMetricsOffset);
        EM = (DWORD) lpETM->etmMasterUnits;
     }   

     //********************************************
     //              Initialize vars

     CurrentPoint.x = ix;
     CurrentPoint.y = iy;
     lCharExtra     = CharExtra *EM;
     lBreakExtra    = BreakExtra*EM;
     //********************************************

     // Get information about the font - first, last chars, break character
   if(lpFontInfo->dfType & PF_GLYPH_INDEX)
   {
      LPTTFONTINFO lpTTFontInfo;

      lpTTFontInfo    = (LPTTFONTINFO) ((LPSTR)lpFontInfo +
                                 lpFontInfo->dfBitsOffset);

      HighByte = lpTTFontInfo->HighByte  ;

      dfFirstChar = 0 ;
      dfBreakChar      = *(LPWORD)&lpFontInfo->dfDefaultChar  ;
   }
   else
   {
      HighByte = 0 ;
      dfFirstChar     = ((WORD)lpFontInfo->dfFirstChar) & 0x00ff;
      dfBreakChar     = ((WORD)(lpFontInfo->dfBreakChar + dfFirstChar)) & 0x00ff;
   }

     START_PROFILE("CTextBegin", PRFCTEXTBEGIN);
     CTextBegin(lpdv,(LPPOINT) &CurrentPoint, lpFontInfo, lpTextXForm);
     STOP_PROFILE(PRFCTEXTBEGIN);

/* The input string might be in SOI format already.  So we need to
   translate it back to the real character.
   */
   if ( lpFontInfo->dfType & TYPE_TRUETYPE )
   {
            lpTTFontInfo    = (LPTTFONTINFO) ((LPSTR)lpFontInfo +
                                 lpFontInfo->dfBitsOffset);
   }
   else
      lpTTFontInfo = NULL;

   if (lpTTFontInfo)
   {
      char FontName[FONTNAMESIZE];  // for TT font, we use "MSTT31abcd00" -maximal length=14
      LPSTR lpFontName = (LPSTR)FontName;

      // Get the  SOI assigment pointer.
      lstrcpy(FontName, lpTTFontInfo->PSName); // make a local copy we can modify
      REMOVE_SHOW_ORDER_SUBSTRING(lpFontName);   // remove the fontid 00.
      if (CheckGIAssignedRecord(lpdv, FontName, &lpMatchGas)==0)
              lpMatchGas = NULL;
   }

     if( lpdx )
     {   // Special case - output the string using width vector.
          // During the output we can break the string into multiple runs.

          WORD  offset ;   // aligns lpSubString properly with CharWidthArray
                
          WORD  fLeadByte = FALSE;
          
          /*
          * First pass, calculate how many runs.
          */
          wRuns = 0;
          lplCharExtra = (LPLONG)GlobalAllocPtr(GHND, count * sizeof (LONG));
          if (lplCharExtra == NULL)
              return;
          // This is just a talisman. Real initialization for the element zero
          // is done at the line assigning lCharExtra to lplCharExtra[wRuns]
          // below when wRuns is zero.
          lplCharExtra[0] = lCharExtra;

          lNextPos = 0L;
          offset = BreakCount = 0;
          lpSubString = lpbStr ;
          CharCount = 0;      // Counter on characters in a substring
          
          for(i=0; i < count ; i++)
          {
               iCh = ( (int) lpbStr[i] ) & 0x00FF; // Get current char

               if( !(lpFontInfo->dfType & PF_GLYPH_INDEX) &&
                   IsDBCSCharSet(lpFontInfo->dfCharSet) &&
                   !lpMatchGas &&
                   (fLeadByte = IsDBCSLeadByteEx(lpFontInfo->dfCharSet,(BYTE)iCh)))
               {
                   lNextPos += lpdx[i] * EM;     // Position for the next char
                   i++;
                   CharCount++;
               }

               iCh = HighByte | (WORD)iCh ;
               if (lpMatchGas)
               { //convert SOI to GI or CC.
                        (WORD) iCh = GetGIFromAssignmentID(lpMatchGas, (WORD) iCh);
               }
               if( iCh == dfBreakChar )    // If it is break character - 
                    BreakCount++ ;          //   bump break counter

               CharCount++ ;               // Bump char counter

               lNextPos += lpdx[i] * EM;     // Position for the next char
               lError = lNextPos - ( GetTranStrSize(lpdv,
                                                    lpFontInfo, 
                                                    lpSubString, 
                                                    CharCount, 
                                                    NULL,
                                                    offset
                                                    ) 
                      + lCharExtra * CharCount + lBreakExtra * BreakCount);
               if(  lError )
                                   // Aha!!! - we  are off the target - something
                                   //  should be done - play with CharExtra, or with
                                   //  BreakExtra. If all possible adjustments were
                                   //  already made - break the run.
               {
                    if( ( iCh == dfBreakChar )  &&   // This is break character,
                         ( BreakCount == 1)      &&   //  .. first time,
                         ( BreakExtra    ==  0)       //  .. BreakExtra wasn't used
                      )   
                    {
                         lBreakExtra = lError ;
                         continue;                   // One more chance ....
                    }
                         
                    if(  
                         ( ( CharCount == 1 ) ||   
                           ( CharCount == 2 && fLeadByte)) &&   // First time
                         ( lBreakExtra == 0L  ) &&   // No space adjustment
                         ( iCh != dfBreakChar ) &&   // Non-break char
                         ( CharExtra == 0 )       )  // CharExtra wasn't used
                    {
                         lCharExtra += lError ;

                         // This is the first step to optimize continuous ashow
                         // command lines having same x displacement operand.
                         // Remember the x displacement value for this run.
                         lplCharExtra[wRuns] = lCharExtra;

                         continue;                   // One more chance ....
                    }
                    //*********************************************************
                    // We tried everything and cannot adjust - break the run
                    //  Output accumulated run

                    wRuns ++;

                    //---------------------------------------------------------
                    // Prepare for the next run
                    // Roll back the next position variable to find the starting
                    //  point of the next run. The next run starts where previous

                    lpSubString = lpSubString + CharCount - (fLeadByte?2:1);
                    offset += CharCount - (fLeadByte?2:1);
                    i -= fLeadByte?2:1;

                    lNextPos = 0;
                    BreakCount = 0;
                    CharCount = 0;
                    lCharExtra     = CharExtra *EM;
                    lBreakExtra    = BreakExtra*EM;
               }
          }
          wRuns ++;

          /*
           *  Second pass, print.
           */

          if ((count == 1 ) ||
              (100 * wRuns - count - 200 <= 0 ) ||
              GetPSVersion(lpdv) < 2015)
          {
              /*
               * using old show, ashow ....
               */

               // In this second pass, optimization for the continuous ashow
               // lines having same x displacement operand is done. Each x
               // displacement operand per run is calculated in the first
               // pass already so that we can see the x displacement operand
               // of the NEXT run when working on the CURRENT run. As long as
               // they are same, we accumulate the runs and then emit them in
               // one ashow line.

               // These variables are used to remember the beginning of the
               // string and its length of the accumulated runs.

               fLeadByte = FALSE;

               lNextPos = 0L;
               offset = BreakCount = 0;
               lpSubString = lpbStr ;
               CharCount = 0;      // Counter on characters in a substring

               lCharExtra     = CharExtra *EM;
               lBreakExtra    = BreakExtra*EM;

               lpLastSubString = lpSubString;
               wLastCharCount = 0;
               wRuns = 0;

               for(i=0; i < count ; i++)
               {
                   iCh = ( (int) lpbStr[i] ) & 0x00FF; // Get current char

                   if( !(lpFontInfo->dfType & PF_GLYPH_INDEX) &&
                       IsDBCSCharSet(lpFontInfo->dfCharSet) &&
                       !lpMatchGas &&
                       (fLeadByte = IsDBCSLeadByteEx(lpFontInfo->dfCharSet,(BYTE)iCh)))
                   {
                       lNextPos += lpdx[i] * EM;     // Position for the next char
                       i++;
                       CharCount++;
                   }

                   iCh = HighByte | (WORD)iCh ;
                   if (lpMatchGas)
                   { //convert SOI to GI or CC.
                        (WORD) iCh = GetGIFromAssignmentID(lpMatchGas, (WORD) iCh);
                   }
                   if( iCh == dfBreakChar )    // If it is break character - 
                        BreakCount++ ;          //   bump break counter
        
                   CharCount++ ;               // Bump char counter
        
                   lNextPos += lpdx[i] * EM;     // Position for the next char
                   lError = lNextPos - ( GetTranStrSize(lpdv,
                                                        lpFontInfo, 
                                                        lpSubString, 
                                                        CharCount, 
                                                        NULL,
                                                        offset
                                                        ) 
                          + lCharExtra * CharCount + lBreakExtra * BreakCount);
                   if(  lError )
                                       // Aha!!! - we  are off the target - something
                                       //  should be done - play with CharExtra, or with
                                       //  BreakExtra. If all possible adjustments were
                                       //  already made - break the run.
                   {
                        if( ( iCh == dfBreakChar )  &&   // This is break character,
                             ( BreakCount == 1)      &&   //  .. first time,
                             ( BreakExtra    ==  0)       //  .. BreakExtra wasn't used
                          )   
                        {
                           // Make sure not to use very small extra width.

                           if ((lError > -(LONG)EM) && (lError < (LONG)EM) ||
                              ((lError == -(LONG)EM) || (lError == (LONG)EM)) )
                                 lError = 0;
                             
                             lBreakExtra = lError ;
                             continue;                   // One more chance ....
                        }
                               
                        if(  
                             ( ( CharCount == 1 ) ||   
                               ( CharCount == 2 && fLeadByte)) &&   // First time
                             ( lBreakExtra == 0L  ) &&   // No space adjustment
                             ( iCh != dfBreakChar ) &&   // Non-break char
                             ( CharExtra == 0 )       )  // CharExtra wasn't used
                        {
                                lCharExtra += lError ;
                                continue;                   // One more chance ....
                        }

                        //*********************************************************
                        // We tried everything and cannot adjust - break the run
                        //  Output accumulated run
// Disabled to optimize the continuous ashow lines having same x displacement operand.
// -Kei- 6/6/97
//                        START_PROFILE("CTextrun", PRFCTEXTRUN);
//                        CTextRun(lpdv, lpSubString, CharCount-(fLeadByte?2:1), 
//                                 lBreakExtra/(double) EM,
//                                 lCharExtra/(double) EM, lpFontInfo, lpTextXForm, NULL);
//                        STOP_PROFILE(PRFCTEXTRUN);

                        // Here we accumulate the runs having same x displacement
                        // operand, then emit the result if the x displacement
                        // operand of the next run is different from the current one.

                        if (lplCharExtra[wRuns + 1] != lCharExtra)
                        {
                            CTextRun(lpdv, lpLastSubString,
                                        wLastCharCount + CharCount - (fLeadByte?2:1),
                                        lBreakExtra / (double)EM,
                                        lplCharExtra[wRuns] / (double)EM,
				                        lpFontInfo, lpTextXForm, NULL);
                                        
                            lpLastSubString = lpSubString + CharCount - (fLeadByte?2:1);
	                         wLastCharCount = 0;
                        }
                        else
                        {
                            wLastCharCount += CharCount - (fLeadByte?2:1);
                        }
                        
                        wRuns++;

                        //---------------------------------------------------------
                        // Prepare for the next run
                        // Roll back the next position variable to find the starting
                        //  point of the next run. The next run starts where previous

                        lpSubString = lpSubString + CharCount - (fLeadByte?2:1);
                        offset += CharCount - (fLeadByte?2:1);
                        i -= fLeadByte?2:1;

                        lNextPos = 0;
                        BreakCount = 0;
                        CharCount = 0;
                        lCharExtra     = CharExtra *EM;
                        lBreakExtra    = BreakExtra*EM;
                   }
               }

               // Flush the last, unemitted run.
 	            bCont = FALSE;
               if (wLastCharCount)
               {
                   if (lplCharExtra[wRuns] == lCharExtra)
                      wLastCharCount += CharCount;
                   else  // Here is another run
                      bCont = TRUE;
                   CTextRun(lpdv, lpLastSubString, wLastCharCount,
                               lBreakExtra / (double)EM, lCharExtra / (double)EM,
                               lpFontInfo, lpTextXForm, NULL);
          		    if (bCont)
			             CTextRun(lpdv, lpSubString, CharCount , lBreakExtra/(double) EM,
                                lCharExtra/(double) EM, lpFontInfo, lpTextXForm, NULL);

                }
                else
                {
				    START_PROFILE("CTextrun", PRFCTEXTRUN);
				    CTextRun(lpdv, lpSubString, CharCount , lBreakExtra/(double) EM,
                                lCharExtra/(double) EM, lpFontInfo, lpTextXForm, NULL);
                    STOP_PROFILE(PRFCTEXTRUN);
                }
          }
          else
          {
             /*
              * Using xshow : do not break string
              */

              START_PROFILE("CTextrun", PRFCTEXTRUN);
              CTextRun(lpdv, lpbStr, count , 0L, 0L, lpFontInfo, lpTextXForm, lpdx);
              STOP_PROFILE(PRFCTEXTRUN);
          }

          GlobalFreePtr(lplCharExtra);
     }else
     {
          // Get the size of the string as it will appear on paper
          //  taking  in account track kerning, pair kerning and so on.
          lGDIStrWidth =  GetTranStrSize(lpdv, lpFontInfo, lpbStr, count,
                                         (LPWORD) &BreakCount, 0
                                          );
          //**************************************************************************
          //              TRICKY PART !!!!!!
          //  We have the size of the string if we output it on TRAN side in
          //      dGDIStrWidth.
          //  We also have the size of the string we reported to GDI - it's
          //      in cxStr. What shall we do if they differ? The answer is -
          //      to stretch/expand the resulting string so it will fit into the
          //      space we reported back to GDI. The next question is - how to
          //      stretch/expand, how many pixels add to each char, to every break.
          //      We should analyze the CharCount, CharExtra, BreakCount,
          //      BreakExtra values passed to us in order to find how.
          //**************************************************************************



          lError = cxStr * EM - (lGDIStrWidth +
                                   lCharExtra * count  +
                                   lBreakExtra * BreakCount );

          // Fix bug 190218.  1/23/97   jjia
          // Make sure not to use very small extra width.
          if ((lError > -(LONG)EM) && (lError < (LONG)EM) ||
              (((lError == -(LONG)EM) || (lError == (LONG)EM)) && (count >= 10)))
              lError = 0;


          START_PROFILE("CTextrun", PRFCTEXTRUN);
          CTextRun(lpdv, lpbStr, count, lBreakExtra/(double) EM,
                     (lCharExtra + (lError/(double) count) ) / (double) EM,
                               lpFontInfo, lpTextXForm, NULL);
          STOP_PROFILE(PRFCTEXTRUN);

     }
     START_PROFILE("CTextEnd", PRFCTEXTEND);
     CTextEnd(lpdv, lpFontInfo, lpTextXForm, (WORD) cxStr );
     STOP_PROFILE(PRFCTEXTEND);
}


#pragma  optimize ("d", off)
#pragma  optimize ("se", on)


/****************************************************************
* Name: ShowStr()
*
* Action: This routine can either draw text on an output device
*     or take the measurement of a string of text depending
*     on the sign of the bytecount.  If the bytecount is
*     positive, then the string is actually drawn.  If the
*     bytecount is negative, then ShowStr just returns the
*     height and width of the string concatenated into a long
*     integer.
*
*
* Returns: A long value which is the concatenation of the
*      text height and string width.
*
*      The high-order word contains the string height,
*      and the low-order word contains the string width.
*
*****************************************************************/

DWORD NEAR TEXTOUTSEG PASCAL ShowStr(lpdv, ix, iy, lpbSrc, cb,
          lpFontInfo, lpdm, lpTextXForm, lpdx, TranFontInfo)

LPPDEVICE   lpdv;           /* Far ptr the device descriptor */
int ix;                     /* The horizontal origin */
int iy;                     /* The vertical origin */
LPSTR   lpbSrc;             /* Far ptr to the source string */
int cb;                     /* Size of the source string */
LPPSFONTINFO  lpFontInfo;     /* Far ptr to the PSFONTINFO (font metrics) structure */
LPDRAWMODE  lpdm;           /* Far ptr to the justification info, etc. */
LPTEXTXFORM lpTextXForm;    /* Font transformation structure */
LPSHORT lpdx;               /* Far ptr to delta-x moves */
LPPSFONTINFO TranFontInfo;    /* Far ptr to the PSFONTINFO (font metrics)
                                    * structure  used for an actual TRAN-side output*/
{               
     DWORD          gdiStrWidth;
     DWORD          ret;                  // Return value
     int           i,j;
     int           iCh;

     int           GDICharExtra;
     int           cxChar;       // Char Width

     WORD           dfBreakChar;
     WORD           dfFirstChar;
     WORD            HighByte ;

     LPWORD   lpGDICharWidths;

     BOOL          fPrint = ( cb > 0 ) ;
//   LPFONTEXTRA   FontExtra;     no use.  jjia    7/26/96
     LPTTFONTINFO  lpttfi = (LPTTFONTINFO) ((LPSTR)lpFontInfo +
                                        lpFontInfo->dfBitsOffset);
     JUSTBREAKREC  justifyLetter;
     JUSTBREAKREC  justifyWord;
     LPGIASSIGNED  lpMatchGas = NULL; // would be set latter if SOI

     if ( cb == 0 )
          return(0x1L);       // Return Success

     if (!fPrint)
          cb = -cb;           //  Keep cb positive

//   No use.    jjia      7/26/96 
//   if ( lpFontInfo->dfType & TYPE_TRUETYPE )
//        {
//        FontExtra = NULL;
//        }
//   else
//        FontExtra=(LPFONTEXTRA) BUMPFAR(lpFontInfo,lpFontInfo->dfDriverInfo);

   // Get information about the font - first, last chars, break character

   if(lpFontInfo->dfType & PF_GLYPH_INDEX)
   {
      HighByte = lpttfi->HighByte ;
      dfFirstChar = 0 ;
      dfBreakChar      = *(LPWORD)&lpFontInfo->dfDefaultChar  ;
   }
   else
   {
      HighByte = 0 ;
      dfFirstChar     = ((WORD)lpFontInfo->dfFirstChar) & 0x00ff;
      dfBreakChar     = ((WORD)(lpFontInfo->dfBreakChar + dfFirstChar)) & 0x00ff;
   }

   SetJustification(lpdv, lpdm, &justifyWord, &justifyLetter);


   /* Get GDI width tables.  */
   {
      LPREALIZEBUFS  lpCache ;

      lpCache = &lpdv->GlobalBuffer.RealizeBufs ;

      // Remember: all width tables are now like lpdx.

      if (lpFontInfo->dfType & TYPE_TRUETYPE )
         lpGDICharWidths = lpCache->rgwWidths + lpCache->offsetWidths;
      else
         lpGDICharWidths = lpCache->devlpsWidths + lpCache->offsetWidths;
   }

   //***********************************************************************
   //                   IMPORTANT !!!!
   //   On GDI side when we calculate the string size we don't care about
   // what size it will take on TRAN side. Our goal is to give back to GDI
   // the size of string using the font metrics known to GDI. Later in
   // DumpStr we will take in account all parameters of TRAN-side font and
   // will try to tweak the TRAN-font parameters to fit the text into space
   // reserved by GDI.
   //***********************************************************************

   gdiStrWidth   = 0L;

/* The input string might be in SOI format already.  So we need to
   translate it back to the real character.
   */
   if(lpFontInfo->dfType & TYPE_TRUETYPE) //we must be doing TT, ATM/PFB or OTF
   {
     lpttfi  =   (LPTTFONTINFO) ((LPSTR)lpFontInfo +
                                        lpFontInfo->dfBitsOffset);
   }
   else
     lpttfi = NULL;

   if (lpttfi)
   {
      char FontName[FONTNAMESIZE];  // for TT font, we use "MSTT31abcd00" -maximal length=14
      LPSTR lpFontName = (LPSTR)FontName;

      // Get the  SOI assigment pointer.
      lstrcpy(FontName, lpttfi->PSName); // make a local copy we can modify
      REMOVE_SHOW_ORDER_SUBSTRING(lpFontName);   // remove the fontid 00.
      if (CheckGIAssignedRecord(lpdv, FontName, &lpMatchGas)==0)
              lpMatchGas = NULL;
   }

  /*  For each character in the string.         */
  for ( i = 0,j = 0; i < cb; i++)
  {
//   if word chars are used, reconstitute them.
//   if we ignore the highbyte, false dfBreakChars will result
     iCh = ((int) lpbSrc[i] ) & 0x00ff;
     iCh = HighByte | (WORD)iCh ;

     if (lpMatchGas)
     { //convert SOI to GI or CC.
         (WORD) iCh = GetGIFromAssignmentID(lpMatchGas, (WORD) iCh);
     }

     /*  Get character width             */
     cxChar = lpGDICharWidths[i];

     GDICharExtra = 0;  // start with no adjustment at all
     /*  Apply letter justification  first       */
     GDICharExtra += GetJustBreak(&justifyLetter);

     /*  Apply word justification for break characters only .    */
     if (   (WORD)iCh == dfBreakChar   )
          GDICharExtra += GetJustBreak(&justifyWord);

     // If width vector is supplied - use it as character default width
     if ( lpdx )
          GDICharExtra += lpdx[i] ;
     else
          GDICharExtra += cxChar;
     gdiStrWidth  += GDICharExtra ;
  }

// In case of dx array the last element can be invalid - so use the
// natural width of the character instead.
//  if ( lpdx )
//  {
//    gdiStrWidth  -= GDICharExtra ;  // Roll back by dx 
//    gdiStrWidth  += cxChar ;
//  }

  if (fPrint)
  {
     DumpStr(lpdv, TranFontInfo, lpTextXForm, lpdm, ix, iy,
                    lpbSrc, gdiStrWidth, cb ,
                         justifyLetter.extra, justifyWord.extra, lpdx );
  }else
  {
     lpdm->BreakErr = justifyWord.err;   // Update the BreakErr field in
                                                  //  DRAWMODE
       if (lpdv->text.justType != JUST_standard)
       {
            lpdv->text.jWord.err = justifyWord.err;
            lpdv->text.jWord.ccount = justifyWord.ccount;
            lpdv->text.jChar.err = justifyLetter.err;
            lpdv->text.jChar.ccount = justifyLetter.ccount;
       }
  }
  if ( gdiStrWidth > 0x7FFFL )  // overflow - return special code
          ret = MAKELONG( 0x7FFF, ix );
  else
          ret = MAKELONG( (WORD) gdiStrWidth, lpFontInfo->dfPixHeight);

  return ret;

}

/****************************************************************
* Name: ShowStrInBBox()
*
* Action: This routine draw text on an output device
*
* Returns: A long value which is the concatenation of the
*      text height and string width.
*
*      The high-order word contains the string height,
*      and the low-order word contains the string width.
*
*****************************************************************/

DWORD NEAR TEXTOUTSEG PASCAL ShowStrInBBox(lpdv, ix, iy, lpbSrc, cb,
          lpdm, lpTextXForm, lpdx, TranFontInfo, lsize)

LPPDEVICE   lpdv;           /* Far ptr the device descriptor */
int ix;                     /* The horizontal origin */
int iy;                     /* The vertical origin */
LPSTR   lpbSrc;             /* Far ptr to the source string */
int cb;                     /* Size of the source string */
LPDRAWMODE  lpdm;           /* Far ptr to the justification info, etc. */
LPTEXTXFORM lpTextXForm;    /* Font transformation structure */
LPSHORT lpdx;               /* Far ptr to delta-x moves */
LPPSFONTINFO TranFontInfo;  /* Far ptr to the PSFONTINFO (font metrics)
                             * structure  used for an actual TRAN-side output*/
long lsize;
{
    DWORD         gdiStrWidth = LOWORD(lsize);
    JUSTBREAKREC  justifyLetter;
    JUSTBREAKREC  justifyWord;

    if ( cb == 0 )
        return(0x1L);       // Return Success

    SetJustification(lpdv, lpdm, &justifyWord, &justifyLetter);

    DumpStr(lpdv, TranFontInfo, lpTextXForm, lpdm, ix, iy,
            lpbSrc, gdiStrWidth, cb ,
            justifyLetter.extra, justifyWord.extra, lpdx );
    return lsize;
}

/*****************************************************************
*
*****************************************************************/

DWORD NEAR TEXTOUTSEG PASCAL StrBBox(lpdv, ix, cb,
          lpFontInfo, lpdm, lpdx)
                                                                      
LPPDEVICE   lpdv;           /* Far ptr the device descriptor */
int ix;                     /* The horizontal origin */
int cb;                     /* Size of the source string */
LPPSFONTINFO  lpFontInfo;     /* Far ptr to the PSFONTINFO (font metrics) structure */
LPDRAWMODE  lpdm;           /* Far ptr to the justification info, etc. */
LPSHORT lpdx;               /* Far ptr to delta-x moves */
{               
    DWORD         gdiStrWidth = 0L;
    DWORD         ret;                  // Return value
    int           i;
    LPWORD        lpGDICharWidths;
    JUSTBREAKREC  justifyLetter;
    JUSTBREAKREC  justifyWord;
    LPREALIZEBUFS lpCache;

    if ( cb == 0 )
        return(0x1L);       // Return Success

    SetJustification(lpdv, lpdm, &justifyWord, &justifyLetter);

    /* Get GDI width tables.  */
    lpCache = &lpdv->GlobalBuffer.RealizeBufs ;

    // Remember: all width tables are now like lpdx.

    if (lpFontInfo->dfType & TYPE_TRUETYPE )
        lpGDICharWidths = lpCache->rgwWidths;
    else
        lpGDICharWidths = lpCache->devlpsWidths;

    // For each character in the string.
    // If width vector is supplied - use it as character default width
    if ( lpdx )
    {
        for ( i = 0; i < cb; i++)
            gdiStrWidth += lpdx[i];
    }
    else
    {
        for ( i = 0; i < cb; i++)
            gdiStrWidth += lpGDICharWidths[i];
    }
    //  Apply word justification for break characters only .
    gdiStrWidth = (DWORD)((long)gdiStrWidth +
                  justifyWord.extra * (long)justifyWord.count + justifyWord.rem);

    //  Apply letter justification.
    gdiStrWidth = (DWORD)((long)gdiStrWidth +
                  justifyLetter.extra * cb + justifyLetter.rem);

    if ( gdiStrWidth > 0x7FFFL )  // overflow - return special code
          ret = MAKELONG( 0x7FFF, ix );
    else
          ret = MAKELONG( (WORD) gdiStrWidth, lpFontInfo->dfPixHeight);

    return ret;
}

/***************************************************************
* Name: ExtTextOut()
*
* Action: This routine is used to draw text strings on the display
*     surface.  Most of the real work is done by the ShowStr routine.
*     The main goal of ExtTextOut is to break the source string up
*     into the pieces that can be handled directly by the printer
*     and to simulate the characters that the printer can't handle.
*
******************************************************************/

DWORD _loadds FAR PASCAL DevExtTextOut(lpdv, ix, iy, lprcClip, orglpbSrc, cbSrc, 
                                       lpFontInfo, lpdm, lpTextXForm,
                                       orglpdx, lprcOpaq, options)

LPPDEVICE   lpdv;       /* Far ptr the device descriptor */
int ix;     /* The horizontal origion */
int iy;     /* The vertical origion */
LPRECT  lprcClip;   /* Far ptr to the clipping rectangle */
LPSTR   orglpbSrc;     /* Far ptr to the source string */
int cbSrc;      /* Size of the source string */
LPPSFONTINFO  lpFontInfo;     /* Far ptr to the PSFONTINFO structure */
LPDRAWMODE lpdm;    /* Far ptr to the justification info, etc. */
LPTEXTXFORM lpTextXForm;    /* Font transformation structure */
LPSHORT orglpdx;       /* Far ptr to array of delta-x moves */
LPRECT  lprcOpaq;   /* Far ptr to opaque rectangle */
WORD    options;    /* 2.0+ option switches */
{
   RECT        cliprect, opaqrect;
   long        lsize = 0;
   BOOL        bClip;      // Was clipping rectangle output or not
   LPFONTEXTRA FontExtra;  /* Far ptr to the extended device font structure */
   LPTTFONTINFO lpTTFontInfo ;
   WORD   count, abscbSrc, i , dfLastChar, xAdvance = 0;
   int  signcbSrc , Escapement = 0 ;
   LPSTR   lpbSrc = orglpbSrc;
   LPSHORT lpdx = orglpdx ;
   LPREALIZEBUFS  lpCache ;
   PSERROR   rc;
   int iDLFontFormat;
   LPPSFONTINFO  TranFontInfo;/* The PSFONTINFO structure for the
                               * TRAN side font  - it can be different
                               * from the lpFontInfo if we substitute font
                               */
   int  DisableFullDown = 0;
   BOOL bTranTTFont, bTranGlyphIdx , bSingleFont;

   //********************************************************************
   // init.
   //********************************************************************
   if (lpdv->sMagic != LUCAS ||
      (!fInDocLppd(lpdv) && cbSrc >= 0))
   {
         return (0); /* fail: this is not our PDEVICE or
                        trying to print before a startdoc*/
   }
   else if (fDisableGDILppd(lpdv))
       return 1;


   if (fInDocLppd(lpdv))
   {
       // if we have a buffered bitmap, flush it before any textout
       // operation is done - check for buffered bitmap before calling function
       // to avoid loading DIB segment unnecessarily.
       if (lpdv->GlobalBuffer.hBitmapBf && lpdv->GlobalBuffer.lpBitmapBf)
       {
           HandleBufferedBitmap((LP)lpdv);
       }
   }    

   if(cbSrc < 0)
   {
      abscbSrc = -cbSrc;
      signcbSrc = -1 ;
   }
   else
   {
      abscbSrc = cbSrc;
      signcbSrc = 1 ;
   }

   //********************************************************************
   // compute character width vector
   //********************************************************************

   if( cbSrc  &&  lpFontInfo->dfType & TYPE_TRUETYPE) 
   {
      rc = initrgwWidths(lpdv, lpFontInfo, orglpbSrc, abscbSrc);
      if (PS_ERROR(rc))
          return 0;    // fail
          
      if ( lpFontInfo->dfType & TYPE_OUTLINE )
      {
         rc = initlpdWidths(lpdv, lpFontInfo, orglpbSrc, abscbSrc);
         if (PS_ERROR(rc))
             return 0; // fail
      }
   }
   else if (cbSrc)
   {
      rc = initDeviceWidths(lpdv, lpFontInfo, orglpbSrc, abscbSrc);
      if (PS_ERROR(rc))
          return 0;  // fail
   }

   if(lpFontInfo->dfType & TYPE_SUBSTITUTED)
   {
      LPTTFONTINFO tempTT = (LPTTFONTINFO) ((LPBYTE) lpFontInfo +lpFontInfo->dfBitsOffset);
      TranFontInfo = (LPPSFONTINFO) BUMPFAR (lpFontInfo, tempTT->dwSubFontInfo);
      if( cbSrc  &&   !(TranFontInfo->dfType & TYPE_TRUETYPE) )
      {
         rc = initDeviceWidths(lpdv, TranFontInfo, orglpbSrc, abscbSrc);
         if (PS_ERROR(rc))
             return 0;   // fail
      }
   }
   else
         TranFontInfo = lpFontInfo;

   bTranTTFont = (TranFontInfo->dfType & TYPE_TRUETYPE)? 1 : 0;
   bTranGlyphIdx = (TranFontInfo->dfType & PF_GLYPH_INDEX)? 1 : 0;

   //********************************************************************
   // For Far East. DBCS font flag initialize.
   //********************************************************************
   lpdv->fDBCS = 0;
   if( IsDBCSCharSet(TranFontInfo->dfCharSet))
   {

      lpdv->fDBCS |= DBCS_FONT;
      if(!bTranTTFont )
      {
         char far *lpFaceName;

         lpdv->fDBCS |= DBCS_DEVICE;
         lpFaceName = (char far*)lpFontInfo+TranFontInfo->dfFace;
         if( *lpFaceName == '@' )
         {
            if( (lpFontInfo->dfPitchAndFamily & 0x01) &&
                TranFontInfo->dfCharSet == SHIFTJIS_CHARSET)
                lpdv->fDBCS |= DBCS_83PV_VERT;   // this is for J only.
            else
                lpdv->fDBCS |= DBCS_VERT;        // This is for CJK vertical printing.
         }
      }

   }


   if( bTranTTFont )
   {
      lpTTFontInfo = (LPTTFONTINFO)((LPSTR)TranFontInfo + 
                                       TranFontInfo->dfBitsOffset);

      Escapement = lpTTFontInfo->lfCopy.lfEscapement;
   }
   else 
   {
      FontExtra=(LPFONTEXTRA) BUMPFAR(TranFontInfo,TranFontInfo->dfDriverInfo);

      Escapement = FontExtra->sEscapement;
   }

   //********************************************************************
   //  If font is substituted lpFontInfo points to the actual
   //   font that will be used on GDI side, while TranFontInfo points
   //   to the font that will be used on TRAN side for the output.
   //  In any case - lpFontInfo points to the font that will be used
   //  for GDI-side calculations, while TranFontInfo points to the font
   //  that will be used on TRAN side.
   //********************************************************************
   //              Clipping rectangle handling
   //********************************************************************
   /* Make local copies of the clip and opaque rectangles so we
   * may freely modify them. */
   if (lprcClip)
   {
         cliprect = *lprcClip;
         lprcClip = &cliprect;
   }

   if (lprcOpaq)
   {
         opaqrect = *lprcOpaq;
         lprcOpaq = &opaqrect;
   }
      /* Modify opaque and clip regions per options switches. */
   if (lprcOpaq)
   {
      if (options & EXTTEXT_D2)
      {
         /*   lprcOpaq should be used as a clipping rectangle.
         */
         if (lprcClip)
            IntersectRect(lprcClip, lprcClip, lprcOpaq);
         else
         {
            cliprect = *lprcOpaq;
            lprcClip = &cliprect;
         }
      }
      if (options & EXTTEXT_D1)
      {
         /*   lprcOpaq should be used as an opaque rectangle.
            */
         if (lprcClip)
            IntersectRect(lprcOpaq, lprcClip, lprcOpaq);

      } 
      else
         lprcOpaq = NULL;
   }

   if(cbSrc == 0)   //  you did everything that needed to be done!
      return(1L) ;  //  non-zero signifies success in this case.

   //********************************************************************
   // Call ICM functions.
   //********************************************************************
   if(cbSrc >= 0)
   {
        fChangeStateLppdSt(lpdv, ST_MARKED_PAGE);
        // If bATMWorkAround, do not access lpdm->ICMCXform.
       if(!bATMWorkAround &&
           (((WORD)lpdm->ICMCXform != (WORD)lpdv->graphics.hCMTransform) ||
            (lpdm->ICMCXform == NULL) && (lpdv->graphics.hDefCMTransform)
           ))
       {
            // ALWAYS_ICM
            if ((lpdm->ICMCXform == NULL) &&
                (lpdv->graphics.hDefCMTransform))
            {
                if ((WORD)lpdv->graphics.hDefCMTransform != (WORD)lpdv->graphics.hCMTransform)
                    CICMColor(lpdv, lpdv->graphics.hDefCMTransform);
            }
            else
            {
                CICMColor(lpdv, lpdm->ICMCXform);
            }
       }
   }

   //********************************************************************
   //  convert all out of range chars to default chars!
   //********************************************************************
   if( bTranTTFont  && bTranGlyphIdx )
   {
      LPWORD  lpwSrc ;
      lpwSrc = (LPWORD)lpbSrc ;

      dfLastChar      = *(LPWORD)&TranFontInfo->dfFirstChar - 1 ;

      for(i = 0 ; i < abscbSrc ; i++)
      {
         if(lpwSrc[i] > dfLastChar)
            lpwSrc[i] = 0 ;  //  dfDefaultChar
      }
   }

   lpCache = &lpdv->GlobalBuffer.RealizeBufs ;
   // reset this sucker for every TextOut() call, fix bug 151158, 6-11-96
   lpCache->offsetWidths = 0 ;

   //********************************************************************
   // compute text extent for opaquing and clip rect.
   //********************************************************************
   if( (cbSrc > 0)  &&  ((lpdm->bkMode == OPAQUE) || lprcClip || lprcOpaq) )
   {
      int  xsize, ysize;
      RECT realRect;
      BOOL bRealRect = FALSE;

   // Later when we actually output the string, we transform Glyph-index string
   // to Show-order-index String. 
   // It is NOT necessary to do it just to get the placement - still use old way !!

      lsize = StrBBox(lpdv, ix, (int)abscbSrc, lpFontInfo, lpdm, lpdx);

      xsize = LOWORD(lsize) + xAdvance ;
      ysize = HIWORD(lsize) ;

      if (xsize && ysize && ( xsize  != 0x7FFF ) )
      {
          SetRect(&realRect, ix, iy, ix + xsize, iy + ysize);
          bRealRect = TRUE;
      }

      // Send ClipRect here. Text bbox is saved in realRect.
      // if realRect is included in the ClipRect, do not send ClipRect.
      if (lprcClip || lprcOpaq)
      {
          if (bRealRect)
          {
              bClip = SendClipOrOpaq(lpdv,options,lpdm->LbkColor,
                                     lprcClip,lprcOpaq,&realRect, Escapement);
          }
          else
          {
              bClip = SendClipOrOpaq(lpdv,options,lpdm->LbkColor,
                                     lprcClip,lprcOpaq, NULL, 0);
          }
      }

      if ((lpdm->bkMode == OPAQUE ) && bRealRect)
      {   //  set clipping rect here ...
          COpaqueBox(lpdv, &realRect, lpdm->LbkColor, Escapement);
      }
   }

   if (cbSrc < 0 )
   {
      //********************************************************************
      // calculate BBox.
      //********************************************************************

      lsize = StrBBox(lpdv, ix, (int)abscbSrc, lpFontInfo, lpdm, lpdx);
   }
   else
   {
      //********************************************************************
      // Perform actual output.
      //********************************************************************

       lpbSrc = orglpbSrc;
       xAdvance = 0;

       // If TrueType font is resident then must be T42. -ANG-6/11/96
       if(bTranTTFont)
       {
           iDLFontFormat = lpTTFontInfo->iDLFontFormat;
       }
       else
           iDLFontFormat = lpdv->lpPSExtDevmode->dm2.iDLFontFmt;


       // Now get ready to download font(s) if necessary. Before enter these functions
       // in ttext.c or exttextw.c, we need to disable FullDown Loading for CJK Fonts
       // This is for GDI Apps. Disable CJK Full down for Escape DownloadFace are in ttext.c

       if ( (IsDBCSCharSet(TranFontInfo->dfCharSet)) &&
            (lpdv->lpPSExtDevmode->dm2.bFullDown) )
       {
            lpdv->lpPSExtDevmode->dm2.bFullDown = FALSE;
            DisableFullDown = 1;
       }

#ifdef ADOBE_DRIVER
   if ((iDLFontFormat == TT_DLFORMAT_TYPE42) &&
       (bTranTTFont && bTranGlyphIdx) &&
       (IsDBCSCharSet(TranFontInfo->dfCharSet)) && //do wide for DBCS only. UFL change
       (lpTTFontInfo->dwProperties & TTFI_IS_TYPE42ABLE) // No check for Type42Able in Show/RunTextExtentWide()
      )
   {
      lsize = ShowTextWide(lpdv, ix, iy, (LPWORD)lpbSrc, cbSrc, lpFontInfo,
                              lpdm, lpTextXForm, lpdx, TranFontInfo, lsize);
   }
   else     // do as before 
#endif
   {
      // Code to transform Glyph-index string to Show-order-index String.
      // Only do this transfor when we are asked to perform the actual output
      LPWORD  lpwSrc, lpwTmp=NULL;   // Src - may be modified by GIAssignment

      if( 3*(abscbSrc+1) > lpdv->GlobalBuffer.cSubStringBuf)
      {  // 3*length. 1-is used for lpActSrc later. 2-used for lpwTmp (as WORD).
         lpdv->GlobalBuffer.lpSubStringBuf =
             ReallocBuffer(3*(abscbSrc+1), GHND|GMEM_DDESHARE, 
                &lpdv->GlobalBuffer.cSubStringBuf,
                (LPBYTE  FAR  *)&lpdv->GlobalBuffer.lpSubStringBuf) ;
         if (!(lpdv->GlobalBuffer.lpSubStringBuf))
             goto FAILED_RETURN;
      }


      if ((bTranTTFont)  && (bTranGlyphIdx) &&
          (!lpdv->lpPSExtDevmode->dm2.bFullDown) &&  // Fast only if NOT full download
          (lpdv->lpPSExtDevmode->dm2.bTrueTypeFast)
         )
      {
          LPBYTE   lpFontName = lpTTFontInfo->PSName;
          lpwTmp =(LPWORD)((LPBYTE)(lpdv->GlobalBuffer.lpSubStringBuf+abscbSrc+1));
          // Get the  GIAssignment:
          if (GetGIAssignmentStr(lpdv, (LPSTR)lpFontName, (LPWORD)lpbSrc, (LPWORD)lpwTmp, abscbSrc))
             lpwSrc = lpwTmp;
          else // old way 
             lpwSrc = (LPWORD)lpbSrc ;
      }
      else // old way 
          lpwSrc = (LPWORD)lpbSrc ;

      lpCache->offsetWidths = 0 ;

      bSingleFont = FALSE;
      while(1)  //  you are stuck in here until conditions are met.
      {
         LPBYTE  lpActSrc ;  // holds runs of bytes to be output.

         if( bTranTTFont  &&  bTranGlyphIdx )
         {
            WORD   HighByte ;
         
            HighByte = *lpwSrc & 0xFF00 ;

            lpTTFontInfo->HighByte = HighByte ;

            {
            //  tack on HighByte as part of FontName.
               LPBYTE   lpFontName = lpTTFontInfo->PSName;

               APPEND_SHOW_ORDER_SUBSTRING(lpFontName, lpTTFontInfo->HighByte);
            }

            //  cannot just translate values for dfBreakChar
            //  and DefaultChar to a one byte charglyph!
            //  so this has already been done at start of ExtTextOut

            for(i = 1 ; i < abscbSrc ; i++)
            {
               if(HighByte  != (lpwSrc[i] & 0xFF00))
                  break;
            }

            //   count holds number of chars in substring.
            count = i ;

            if ((int)count == cbSrc)
                bSingleFont = TRUE;

            //  now create substring buffer to hold count bytes.

            lpActSrc = lpdv->GlobalBuffer.lpSubStringBuf;  //this is the substring !!!

            for(i = 0 ; i < count ; i++)
            {
               lpActSrc[i] = (BYTE)(lpwSrc[i] & 0x00FF) ;
            }

            //  adjust placeholders, etc
            (LPWORD)lpbSrc += count ;  // is this working?
            (LPWORD)lpwSrc += count ;  // Advance lpwSrc as well. 9-26-95
            abscbSrc -= count ;     
         }
         else
         {
            if( bTranTTFont)
               lpTTFontInfo->HighByte = 0 ;
            lpActSrc = lpbSrc ;
            count = abscbSrc ;
            bSingleFont = TRUE;
         }

         fChangeStateLppdSt(lpdv, ST_MARKED_PAGE);

         // download a softfont, if necessary
         if( (bTranTTFont)  || (FontExtra->dwSoftFont) ) 
         {
            START_PROFILE("CSoftFontLoad", PRFCSOFTFONTLOAD);
            rc = CSoftFontLoad(lpdv,TranFontInfo,lpTextXForm,lpActSrc,count);
            STOP_PROFILE(PRFCSOFTFONTLOAD);
            if (PS_ERROR(rc))
            {
                //  the rest of this code is only executed for WideFonts !
                //  now restore original PSname !!!
                if( bTranTTFont  &&  bTranGlyphIdx )
                {
                    LPBYTE   lpFontName = lpTTFontInfo->PSName;
                    //      strip HighByte hexbytes from FontName.
                    REMOVE_SHOW_ORDER_SUBSTRING(lpFontName);
                }
                goto FAILED_RETURN;
            }
         }

         // set the text color
         CPenFGColor(lpdv,lpdm->TextColor);

         if (bSingleFont && lsize)
         {
            //   Do not need to calculate the BBox of the string.
            if(Escapement && xAdvance)
            {
               ShowStrInBBox(lpdv, 
                    ix + RCos(xAdvance, Escapement) , 
                    iy - RSin(xAdvance, Escapement), lpActSrc, 
                    count, lpdm, lpTextXForm,
                    lpdx, TranFontInfo, lsize);
            }
            else
               ShowStrInBBox(lpdv, ix + xAdvance , iy, lpActSrc,
                    count, lpdm, lpTextXForm,
                    lpdx, TranFontInfo, lsize);
         }
         else
         {
            if(Escapement && xAdvance)
            {
               lsize = ShowStr(lpdv, 
                            ix + RCos(xAdvance, Escapement) , 
                            iy - RSin(xAdvance, Escapement), lpActSrc, 
                            count, lpFontInfo, lpdm, lpTextXForm,
                            lpdx, TranFontInfo);
            }
            else
               lsize = ShowStr(lpdv, ix + xAdvance , iy, lpActSrc, count,
                            lpFontInfo, lpdm, lpTextXForm, lpdx, TranFontInfo);
         }

         if( !(bTranTTFont  &&  bTranGlyphIdx ))
            break;

         //  the rest of this code is only executed for WideFonts !
         //  now restore original PSname !!!
         {
            LPBYTE   lpFontName = lpTTFontInfo->PSName;
            //  strip HighByte hexbytes from FontName.
            REMOVE_SHOW_ORDER_SUBSTRING(lpFontName);
         }

         if(!abscbSrc)
            break;     // no more substrings to print.

         if(lpdx)
            lpdx += count ;

         lpCache->offsetWidths += count ;

         //  advance position of next text substring.
         xAdvance += LOWORD(lsize) ;  // are we correctly processing
      }
   }  // else( !(Type42 && WideFont))
   if (DisableFullDown)
   {
       lpdv->lpPSExtDevmode->dm2.bFullDown = TRUE;
       DisableFullDown = 0;
   }
   }  // else( cbSrc >= 0 )


   if (bClip && (cbSrc >= 0) )
         CClipEnd(lpdv);

   return (MAKELONG(LOWORD(lsize) + xAdvance, HIWORD(lsize)));

FAILED_RETURN:
   if (DisableFullDown){
       lpdv->lpPSExtDevmode->dm2.bFullDown = TRUE;
       DisableFullDown = 0;
   }

   return 0;

}

//***********************************************************************************
//
//              SendClipOrOpaq
//
//  Returns:    FALSE - if no clip rect was sent
//              TRUE  - clip rect was sent
//
short NEAR TEXTOUTSEG PASCAL SendClipOrOpaq(LPPDEVICE lppd,WORD wOptions,DWORD rgb,
                                            LPRECT lpClipRect,LPRECT lpOpaqueRect,
                                            LPRECT lpRealRect, int Escapement )
{
   RECT  ClipRect,OpaqRect,IntrRect;             
   int   options;
   BOOL  bRet;

   bRet = TRUE;
// There are 16 cases which may arise from the 4 arguments lpClipRect,
// lpOpaqueRect,ETO_CLIPPED and ETO_OPAQUE. These cases are
//
//  CLIP  OPAQ &ClipRect &OpaqRect           Action
//  ----|-----|---------|---------|---------------------------
//    0 |   0 |  = Null |  = Null | No clip, no opaque
//    0 |   0 |  = Null | != Null | No clip, no opaque
//    0 |   0 | != Null |  = Null | CClipRect(&ClipRect), no opaque
//    0 |   0 | != Null | != Null | CClipRect(&ClipRect), no opaque
//    --|-----|---------|---------|---------------------------
//    0 |   1 |  = Null |  = Null | No clip, no opaque
//    0 |   1 |  = Null | != Null | No clip, COpaqBox(&OpaqueRect)
//    0 |   1 | != Null |  = Null | CClipRect(&ClipRect), no opaque
//    0 |   1 | != Null | != Null | CClipRect(&ClipRect),COpaqBox(&ClipRect & &OpaqRect)
//    --|-----|---------|---------|---------------------------
//    1 |   0 |  = Null |  = Null | No clip, no opaque
//    1 |   0 |  = Null | != Null | CClipRect(&OpaqueRect), no opaque
//    1 |   0 | != Null |  = Null | CClipRect(&ClipRect), no opaque
//    1 |   0 | != Null | != Null | CClipRect(&ClipRect & &OpaqRect),no opaque
//    --|-----|---------|---------|---------------------------
//    1 |   1 |  = Null |  = Null | No clip, no opaque
//    1 |   1 |  = Null | != Null | CClipRect(&OpaqueRect)
//    1 |   1 | != Null |  = Null | CClipRect(&ClipRect), no opaque
//    1 |   1 | != Null | != Null | CClipRect(&ClipRect & &OpaqRect),
//      |     |         |         | COpaqBox(&ClipRect & &OpaqRect)


  options = (wOptions & 0x0006) << 1;       // options = ETO_CLIPPED | ETO_OPAQ
  if(lpOpaqueRect)
  {     OpaqRect    = *lpOpaqueRect;        // Make a copy of OpaqueRect
          options    |= _1BIT;         
  }

  if(lpClipRect)
  {     ClipRect    = *lpClipRect;          // Make a copy of ClipRect
          options    |= _2BIT;         
  }

  if(lpClipRect && lpOpaqueRect)
  {
     IntersectRect(&IntrRect,lpClipRect,lpOpaqueRect);
  }

  switch(options)
  {                                                // CLIP:OPAQ ClipRect OpaqRect
   case  0: bRet =FALSE;                    break; //    0:0    = Null  = Null
   case  1: bRet =FALSE;                    break; //    0:0    = Null   =!Null
   case  2: bRet = CClipRect(lppd,&ClipRect, lpRealRect, Escapement);
                                            break; //    0:0    =!Null   = Null
   case  3: bRet = CClipRect(lppd,&ClipRect, lpRealRect, Escapement);
                                            break; //    0:0    =!Null   =!Null
   case  4: bRet =FALSE;                    break; //    0:1    = Null  = Null
   case  5: COpaqueBox(lppd,&OpaqRect,rgb, 0);
            bRet =FALSE;                    break; //    0:1    = Null   =!Null
   case  6: bRet = CClipRect(lppd,&ClipRect, lpRealRect, Escapement);
                                            break; //    0:1    =!Null   = Null

   case  7: bRet = CClipRect(lppd,&ClipRect, lpRealRect, Escapement);
            COpaqueBox(lppd,&IntrRect,rgb, 0);
                                            break; //    0:1    =!Null   =!Null
   case  8: bRet =FALSE;                    break; //    1:0    = Null   = Null
   case  9: bRet = CClipRect(lppd,&OpaqRect, lpRealRect, Escapement);
                                            break; //    1:0    = Null   =!Null
   case 10: bRet = CClipRect(lppd,&ClipRect, lpRealRect, Escapement);
                                            break; //    1:0    =!Null   = Null
   case 11: bRet = CClipRect(lppd,&IntrRect, lpRealRect, Escapement);
                                            break; //    1:0    =!Null   =!Null
   case 12: bRet =FALSE;                    break; //    1:1    = Null   = Null
   case 13: bRet = CClipRect(lppd,&OpaqRect, lpRealRect, Escapement);
                                            break; //    1:1    = Null   =!Null
   case 14: bRet = CClipRect(lppd,&ClipRect, lpRealRect, Escapement);
                                            break; //    1:1    =!Null   = Null

   case 15: bRet = CClipRect(lppd,&IntrRect, lpRealRect, Escapement);
            COpaqueBox(lppd,&IntrRect,rgb, 0);
                                            break; //    1:1    =!Null   =!Null
  }
  return(bRet);
}

