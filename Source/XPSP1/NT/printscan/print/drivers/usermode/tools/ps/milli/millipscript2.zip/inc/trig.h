/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: TRIG.H                                                 */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

#define TANRADIX 10
#define SINRADIX 1
#define COSRADIX 1

//the bases are hard coded here, and reflect decisions made when
//the trig tables were generated.  If you change these, you MUST
//change the basis on which they were chosen, AND you must make
//sure that overflow does not occur and accuracy is maintained
//
#define BASE 16384

SHORT FAR PASCAL PSArcTan(LPSHORT lpsTangent,SHORT sOpp,SHORT sAdj);
SHORT FAR PASCAL WinSin(LPSHORT lpsSine,SHORT sAngle);
SHORT FAR PASCAL WinCos(LPSHORT lpsSine,SHORT sAngle);

