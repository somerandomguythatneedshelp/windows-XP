/*
 *	Font Translation Library
 *
 *	Copyright (c) 1995 Adobe Systems Inc.
 *	All Rights Reserved
 *
 *	UFLConfig.h
 *
 *		X Windows version of UFLConfig
 *
 * $Header: $
 */

#ifndef _H_UFLConfig
#define _H_UFLConfig

#define SWAPBITS 0

typedef int		BOOL;
#define FALSE	0
#define TRUE	(!FALSE)

typedef long	LONG;

#define UFLEXPORT
#define UFLEXPORTPTR
#define UFLCALLBACK
#define UFLCALLBACKDECL UFLCALLBACK

#define PTR_PREFIX

#endif

