/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ESCSTUBS.c                                                   */
/*                                                                           */
/* Description: This module contains the functions for ...                   */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_ESCSTUBSSEG)

#define MAX_PSSIZE   ((DWORD)0xFFFF)   /* maximum PS data buffer size */

// typedef required by ESCGetExtentTable()

typedef struct _GETX
{
   BYTE bFirst;
   BYTE bLast ;
}
GETX,FAR *LPGETX;


//max length of bin description reported by ESCEnumPaperBins().
#define MAX_BINNAME_LEN 24

#define SAVEPAPERBIN_MASK 0x8000
#define RC_no_match -1
#define RC_no_xlat_data -2


//structure required for ESCGetSetPaperBins().
typedef struct tagBININFO
{
   short BinNumber ;
   short NbrofBins ;
   short Reserved[4] ;
} BININFO ;
typedef BININFO FAR *LPBININFO ;

//--------------------------------------------------------------------
// Prototypes for local functions:
//--------------------------------------------------------------------
// short FAR PASCAL MatchPaperSize(LPPDEVICE lppd, LPKEYWORDLISTREC PPDList, LPRECT lpNewRect,
//   int FAR *PPD_media_index, int FAR *orientation, BOOL FAR *no_margins_flag) ;
BOOL ValidateDIB(LPBITMAPINFOHEADER lpInfo);

//
//--------------------------------------------------------------------
// Function definitions:
//--------------------------------------------------------------------
short FAR PASCAL ESCNotImplemented(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
     return(0);
}

//

short FAR PASCAL ESCGetSetPaperBins(LPPDEVICE lppd,LP lpInData,LP lpOutData)
/**********************************************************************
*
*  function:
*       Report the number of paper bins available on a printer
*       or set the current bin.  When setting the current bin, 
*       four cases are possible:
*           1. Driver is to save bin setting as the default.
*              This has no effect on the current job.
*           2. Driver is apply bin setting immediately, and 
*              it is before StartDoc.  Simply update tables
*              and the bin setting will be applied at StartDoc time.
*           3. Driver is to apply bin setting immediately, and
*              state is EMPTY_PAGE.  We could send the bin setting
*              as part of the page setup, when it happens.  Also
*              send it for every subsequent page until the end of
*              the job.
*           4. Driver is to apply bin setting immediately, and 
*              state is MARKED_PAGE.  Leave bin setting as is for
*              the current page, but apply the given bin setting for
*              all subsequent pages.
*
*       This implementation does not permit a switch to manual feed
*       in the middle of a job.  It isn't clear whether that is correct --
*       it may be legal to switch to manual feed even in the middle of 
*       a job.
*
*       Legal anytime betweeen Enable() and Disable().  However, setting
*       the paper bin after EndDoc has no effect.
*       Does not cause a state transition.  Never disabled.
*
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- ptr to BININFO struct identifying new current bin
*       LP lpOutData -- ptr to BININFO struct identifying old current bin &
*                       number of available bins
*  returns:
*       >0 => success
*       <=0 => error
************************************************************************/
{
   LPBININFO binfoOut ;
   LPMAINKEYHDR  lpInputSlotInfoHdr ;
   LPINPUTSLOTINFO   lpExtraInputSlotInfo ;
   LPPRINTERINFO  lpPrinterInfo;
   LPBYTE   lpOptionsBlock ;
   WORD     numEntries, wIndex, new_bin, i;
   short  result  ;


   result = -1 ;
   lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo;
   lpOptionsBlock = lppd->lpWPXblock->WPXarrays;

   lpInputSlotInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;

   lpExtraInputSlotInfo = (LPINPUTSLOTINFO)MAKELONG(
       lpInputSlotInfoHdr->extraOptionArray, HIWORD(lpOptionsBlock) );

   numEntries = lpInputSlotInfoHdr->OptionKeyWords.w.length ;

   if (lpOutData)
   {
      //-----------------------------------------------------------------
      // Report the current bin & the number of bins.
      //-----------------------------------------------------------------
      binfoOut = (LPBININFO) lpOutData ;

      if(KeywordGetCurrentOption(lppd, IND_INPUTSLOTINFO, &wIndex) )
         result = 1 ;

      
      binfoOut->BinNumber =  lpExtraInputSlotInfo[wIndex].slotID ;
      binfoOut->NbrofBins =  numEntries ;
   }

   if (lpInData)
   {
      //-----------------------------------------------------------------
      // Set the current bin.
      //-----------------------------------------------------------------
      new_bin = ((LPBININFO) lpInData)->BinNumber ;
      new_bin = new_bin & (~SAVEPAPERBIN_MASK) ;   //Reset bit flag.
      result = -1 ;  // double jeopardy !

      for (i = 0; i < numEntries ; i ++)
      {
         if (new_bin == lpExtraInputSlotInfo[i].slotID)
         {
            if(IsKeywordOptConstrained(lppd, IND_INPUTSLOTINFO, i) )
               break ;  // forget this option !
            if(KeywordSetCurrentOption(lppd, IND_INPUTSLOTINFO, i) )
               result = 1 ;
            break;
         }
      }
   }
   return(result);
}

#if 0
   short result = 1 ;
   LPPDEVICE lppd ;
   int j, num_bins_to_check, new_bin, bin, old_PPD_index, new_PPD_index ;
   LPBININFO binfoOut ;
   char keyword[MAX_KEYWORD_LEN] ;
   char option[MAX_OPTION_LEN] ;
   BOOL save_to_DB ;

   lppd = (LPPDEVICE) lpDevice ;
   KeywordListLock(lppd, &(*lppd).drvState.PPDList, TRUE) ;
   LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_INPUTSLOT, keyword, sizeof(keyword)) ;
   KeywordListGetOptionRange(lppd,&(*lppd).drvState.PPDList, keyword,
                                     &num_bins_to_check) ;
   KeywordListGetCurrentOption(lppd, &(*lppd).drvState.PPDList, keyword,
                                         option, sizeof(option), &old_PPD_index) ;

   //--------------------------------------------------------------------
   // Identify the current bin.
   //--------------------------------------------------------------------
   if (GetCurrBinPPDVal(lppd, &(*lppd).drvState.PPDList, ID_PPDSTR_KEY_MANUALFEED))
       bin = DMBIN_MANUAL ;
   else
   {
       if (GetCurrBinPPDVal(lppd, &(*lppd).drvState.PPDList, ID_PPDSTR_KEY_AUTOTRAYSELECT)
               && (num_bins_to_check > 1) )
           bin = DMBIN_AUTO ;
       else
       {
           // Convert from PPD slot name to ordinal value
           bin = XlateFromPPD(option, ID_PPDSTR_BASE_INPUTSLOT,
                                   DMBIN_FIRST,DMBIN_LAST) ;
           if (bin == SINGLE_SLOT)
               bin = DMBIN_ONLYONE ;
           if (bin == RC_no_match)
               bin = old_PPD_index + DMOPT_USER; // user/printer specific bin type          
       }
   }  // not Manual Feed         

   if (lpOutData)
   {
       //-----------------------------------------------------------------
       // Report the current bin & the number of bins.
       //-----------------------------------------------------------------
       binfoOut = (LPBININFO) lpOutData ;
       (*binfoOut).BinNumber = bin ;

       // Calculate number of bins - count bin types known to Microsoft AND 
       // printer PPD defined bins not known to Microsoft: Report all bins.

       (*binfoOut).NbrofBins = num_bins_to_check;   // report all bins

#if 0
       (*binfoOut).NbrofBins = 0 ;
       i = 0;
       while (i < num_bins_to_check)
       {
           option[0] = 0 ;
           KeywordListGetOption(lppd, &(*lppd).drvState.PPDList, keyword,
                                     option, sizeof(option), &i, NULL, 0) ;
           if (XlateFromPPD(option, ID_PPDSTR_BASE_INPUTSLOT, DMBIN_FIRST,
                  DMBIN_LAST) >= 0)
           (*binfoOut).NbrofBins++ ; // Microsoft knows about this bin. Report it.
           i++ ;
       }
#endif //0

       // We assume that manual feed is supported iff. we have PostScript to
       // turn it on & off.
       if (GetCurrPPDOptPSLen(lppd, &(*lppd).drvState.PPDList,ID_PPDSTR_KEY_MANUALFEED,
                                     &j) == RC_ok)
           (*binfoOut).NbrofBins++ ;//DMBIN_MANUAL
       if (num_bins_to_check > 1)
           (*binfoOut).NbrofBins++ ;//DMBIN_AUTO
   }

   if (lpInData)
   {
       //-----------------------------------------------------------------
       // Set the current bin.
       //-----------------------------------------------------------------
       new_bin = (*((LPBININFO) lpInData)).BinNumber ;
       save_to_DB = !(new_bin & SAVEPAPERBIN_MASK) ;//Set bit => temp change.
       new_bin = new_bin & (~SAVEPAPERBIN_MASK) ;   //Reset bit flag.

       if (new_bin == DMBIN_MANUAL)
       {
           if (fInDocLppd(lppd))
               result = -1 ;//Don't allow switch to manual mid-job.
           else
           {
               // We are going into manual feed mode.
               SetCurrBinPPDVal(lppd, &(*lppd).drvState.PPDList,
                                     ID_PPDSTR_KEY_MANUALFEED, TRUE) ;
               if (save_to_DB)
               {
                  // Update permanent database.
                  if (WriteCurrPPDKeywDataToDB(lppd,&(*lppd).drvState.PPDList,
                              ID_PPDSTR_KEY_MANUALFEED, (*lppd).drvState.zNickName)
                          != RC_ok)
                       result = -1 ;
               }
            }  //else not InDocument.
       }     //if (new_bin == DMBIN_MANUAL)
       else  if (new_bin == DMBIN_AUTO)
             {
                  if (fInDocLppd(lppd))
                      result = -1 ;//Don't allow switch to Auto Tray Select mid-job.
                  else
                  {
                      // We are going into Auto Tray Select mode.
                      SetCurrBinPPDVal(lppd, &(*lppd).drvState.PPDList,
                                             ID_PPDSTR_KEY_AUTOTRAYSELECT, TRUE) ;

                      if (save_to_DB)
                      {
                          // Update permanent database.
                          if (WriteCurrPPDKeywDataToDB(lppd,&(*lppd).drvState.PPDList,
                              ID_PPDSTR_KEY_AUTOTRAYSELECT, (*lppd).drvState.zNickName)
                              != RC_ok)
                          result = -1 ;
                      }
                  }  //else not InDocument.
               } 
               else  if (new_bin >= 0)
                      {
                          //Handle problem caused by (DMBIN_UPPER == DMBIN_ONLYONE) !
                          if ((new_bin == DMBIN_ONLYONE) && (num_bins_to_check == 1))
                              new_bin = SINGLE_SLOT ;

                          // Store bin selection in DrvState's PPDList, 
                          // considering UI Constraints
                          if (SetCurrPPDOptValConstrained(lppd, &(*lppd).drvState, 
                                ID_PPDSTR_KEY_INPUTSLOT, ID_PPDSTR_BASE_INPUTSLOT, new_bin)
                                 != RC_ok)
                              result = -1 ; 

                          if (result > 0)
                          {  // turn-off Auto Tray Select
                              SetCurrBinPPDVal(lppd, &(*lppd).drvState.PPDList,
                                                ID_PPDSTR_KEY_AUTOTRAYSELECT, FALSE); 
                              if (fInDocLppd(lppd))
                              {
                                 KeywordListGetCurrentOption(lppd, &(*lppd).drvState.PPDList, 
                                      keyword, option, sizeof(option), &new_PPD_index) ;
                                 if (new_PPD_index != old_PPD_index)
                                     // Send a token to the translation layer.
                                     CPaperSource(lppd,option) ;
                              }

                              if (save_to_DB)
                              {
                                     // Write current bin to permanent database.
                                 if (WriteCurrPPDKeywDataToDB(lppd, 
                                      &(*lppd).drvState.PPDList,ID_PPDSTR_KEY_INPUTSLOT, 
                                         (*lppd).drvState.zNickName) != RC_ok)
                                     result = -1 ;
                                 if (result > 0)
                                 {
                                     if (WriteCurrPPDKeywDataToDB(lppd,&(*lppd).drvState.PPDList,
                                             ID_PPDSTR_KEY_AUTOTRAYSELECT, 
                                             (*lppd).drvState.zNickName) != RC_ok)
                                             result = -1 ;
                                 }
                              }  // save_to_DB
                          }     // result > 0
                       }        // (new_bin >= 0)
   }                       // if (lpInData)

   KeywordListUnlock(&(*lppd).drvState.PPDList) ;
   return(result) ;
   return -1;
}
#endif

//
/*****************************************************************************
*
* FUNCTION: ESCGetSetPaperOrientation
*
*       Legal anytime betweeen Enable() and Disable().  However, setting
*       the paper orientation after EndDoc has no effect.
*       Does not cause a state transition.  Never disabled.
*
* DESCRIPTION: This function returns or sets the current paper orientation.
*
* PSUEDO CODE
* -----------
*
* PARAMETERS        TYPE          PURPOSE
* ----------        ----          -------
* lpDevice          * PDEVICE     Destination device bitmap.
* lpInData          LPORIENT      Data Structure with new Orientation.
* lpOutData         NULL          Not Used.
*
* RETURNS           MEANING
* -------           -------
* -1                Escape Failed
*  1                Portriat
*  2                LandScape.
*
* NOTES:
* lpInData == NULL  Current orientation.
* lpInData != NULL  Previous orientation.
*
*****************************************************************************/
short FAR PASCAL ESCGetSetPaperOrientation(LPPDEVICE lppd,LP lpInData,LP lpOutData)
{
   short       nRetOrient;
   LPPSDEVMODE   lpCurdm1 ;

   // Get the current PaperOrientation.
   lpCurdm1 = &lppd->lpPSExtDevmode->dm ;

   if(lpCurdm1->PaperOrient == OR_PORTRAIT)
      nRetOrient = DMORIENT_PORTRAIT;
   else
      nRetOrient = DMORIENT_LANDSCAPE;

   if( lpInData != NULL )   //  change the current PaperOrientation.
   {
      if(((LPORIENT)lpInData)->Orientation == DMORIENT_PORTRAIT)
      {
         lpCurdm1->PaperOrient = OR_PORTRAIT ;
      }
      else   //  any landscape is OK.
      {
         if(lpCurdm1->PaperOrient == OR_PORTRAIT)
               lpCurdm1->PaperOrient = OR_LANDSCAPE ;
      }
   }
   return (nRetOrient) ;
}

#if 0
     short       nRetOrient;
     LPPDEVICE   lppd;

     lppd = (LPPDEVICE)lpDevice;

     // Get the current PaperOrientation.

     /* This is redundant but it makes sure its one of three values. */


   switch( lppd->drvState.bOrientation )
     {
        case DMORIENT_LANDSCAPE :
        case DMORIENT_ROT_LANDSCAPE :
        {
       nRetOrient = DMORIENT_LANDSCAPE;
       break;
        }
        case DMORIENT_PORTRAIT :
        default :
        {
      nRetOrient = DMORIENT_PORTRAIT;
      break;
        }
     } /* switch */

     // If lpInData != NULL change the current PaperOrientation.
     if( lpInData != NULL )
     {
      switch( ((LPORIENT)lpInData)->Orientation )
      {
        case 2 :  /* LandScape */
        {
             if( lppd->drvState.fOrientRotate == TRUE )
             {
            lppd->drvState.bOrientation = DMORIENT_ROT_LANDSCAPE;
             }
             else
             {
            lppd->drvState.bOrientation = DMORIENT_LANDSCAPE;
             }
             break;
        }
        case 1 :   /* Portrait */
        default :  /* Portrait */
        {
             lppd->drvState.bOrientation = DMORIENT_PORTRAIT;
             break;
        }
      } /* switch */
      /* Send a token if in the document */
      if (fInDocLppd(lppd))
      {
           CPageOrientation(lppd, lppd->drvState.bOrientation );
      }

      /* Set the PPD database to this orientation */
        //First update the PPDList in PDEVICE.
      SetCurrPPDOptVal(lppd, &(lppd->drvState.PPDList), ID_PPDSTR_KEY_ORIENT,
             ID_PPDSTR_BASE_ORIENT,lppd->drvState.bOrientation    );
        //Next commit the change to the permanent database.
      if (WriteCurrPPDKeywDataToDB(lppd, &(*lppd).drvState.PPDList,
           ID_PPDSTR_KEY_ORIENT, (*lppd).drvState.zNickName)
            != RC_ok)
          nRetOrient = -1 ;
     }
     return( nRetOrient );
     return -1;
} /* End of ESCGetSetPaperOrientation */
#endif

//
short FAR PASCAL ESCEnumPaperBins(LPPDEVICE lppd ,LP lpInData,LP lpOutData)
/**********************************************************************
*
*  function:
*       Reports a list of the paper bins supported by the printer
*       described in PDEVICE.
*
*       Legal anytime betweeen Enable() and Disable().  
*       Does not cause a state transition.  Never disabled.
*
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- ptr to max # of bins that may be listed
*       LP lpOutData -- ptr to loc to which list is copied
*  returns:
*       >0 => success
*       <0 => error
************************************************************************/
{
   LPMAINKEYHDR  lpInputSlotInfoHdr ;
   LPINPUTSLOTINFO   lpExtraInputSlotInfo ;
   LPPRINTERINFO  lpPrinterInfo;
   LPBYTE   lpOptionsBlock ;
   WORD  num_bins_requested, i, numEntries;
   LPSHORT bin_id ;
   LPSTR bin_desc ;

   
   if (!lpInData || !lpOutData)
       return -1 ;

   lpPrinterInfo = (LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo;
   lpOptionsBlock = lppd->lpWPXblock->WPXarrays;

   lpInputSlotInfoHdr = lpPrinterInfo->mainKeyHdrs + IND_INPUTSLOTINFO ;

   lpExtraInputSlotInfo = (LPINPUTSLOTINFO)MAKELONG(
         lpInputSlotInfoHdr->extraOptionArray, HIWORD(lpOptionsBlock) );

   numEntries = lpInputSlotInfoHdr->OptionKeyWords.w.length ;

   num_bins_requested = *(LPWORD) lpInData ;
   if(num_bins_requested < numEntries)
      numEntries = num_bins_requested ;

   //Initialize the output data.
   MemSet(lpOutData, 0, 
          ((DWORD) num_bins_requested)*
          (MAX_BINNAME_LEN + (DWORD) sizeof(int)));

   //Construct the list of paper bins.  2 separate arrays.
   bin_id = (LPSHORT) lpOutData ;
   bin_desc = (LPSTR) lpOutData + num_bins_requested*sizeof(int) ;

   // check for supported bins and construct the list of paper bins.

   for (i = 0; i < numEntries ; i ++)
   {
      bin_id[i] = lpExtraInputSlotInfo[i].slotID ;

      KeywordGetOptionTranslation( lppd,  IND_INPUTSLOTINFO, i,
                                    bin_desc, MAX_BINNAME_LEN) ;
      bin_desc += MAX_BINNAME_LEN ;
   }        // for(..)

   return(1) ;
}


#if 0
   short result ;
   LPPDEVICE lppd ;
   int num_bins_requested, i, j, num_bins_to_check ;
   int num_bins_found = 0 ;
   LPSHORT bin_id ;
   LPSTR bin_desc ;
   char keyword[MAX_KEYWORD_LEN] ;
   char option[MAX_OPTION_LEN] ;

   if (!lpInData || !lpOutData)
       result = -1 ;
   else
   {
       lppd = (LPPDEVICE) lpDevice ;
       KeywordListLock(lppd, &(*lppd).drvState.PPDList, TRUE) ;
       num_bins_requested = *((LPSHORT) lpInData) ;

       //Initialize the output data.
       MemSet(lpOutData, 0, 
              ((DWORD) num_bins_requested)*
              (MAX_BINNAME_LEN + (DWORD) sizeof(int)));

       //Construct the list of paper bins.
       bin_id = (LPSHORT) lpOutData ;
       bin_desc = (LPSTR) lpOutData + num_bins_requested*sizeof(int) ;
       LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_INPUTSLOT, keyword, sizeof(keyword)) ;
       KeywordListGetOptionRange(lppd, &(*lppd).drvState.PPDList, keyword,
                                         &num_bins_to_check) ;
       i = 0 ;
       while ( (num_bins_found < num_bins_requested) &&
                (i < num_bins_to_check) )
       {
           option[0] = 0 ;
          KeywordListGetOption(lppd, &(*lppd).drvState.PPDList, keyword,
                                        option, sizeof(option), &i, NULL, 0) ;
#if 1
           if (IsKeywordOptionConstrained(lppd, &lppd->drvState, keyword, option) == FALSE)
           { 
#endif
               // Convert from PPD slot name to ordinal value spec'ed by Microsoft.
               j = XlateFromPPD(option, ID_PPDSTR_BASE_INPUTSLOT, DMBIN_FIRST,
                                        DMBIN_LAST) ;
               if (j == RC_no_match)  // option not in our string resource table
                  j = i + DMOPT_USER; // user/printer specific option (non MS defined)

               // Handle problem caused by (DMBIN_UPPER == DMBIN_ONLYONE) !
               if (j == SINGLE_SLOT)
                  j = DMBIN_ONLYONE ;

               if (j >= 0) // valid bin type, so report it.
               {
                  (*bin_id) = j ;
                  bin_id++ ;
                  lstrcpyn(bin_desc, option, MAX_BINNAME_LEN) ;
                  bin_desc += MAX_BINNAME_LEN ;
                  num_bins_found++ ;
               }
#if 1
           }        // IsKeywordOptionConstrained(.....)
#endif
           i++ ;    // increment while loop count
       }           // while(...)

       // Check if Manual Feed is supported
       if (num_bins_found < num_bins_requested)
       {
           if (GetCurrPPDOptPSLen(lppd, &(*lppd).drvState.PPDList,
                  ID_PPDSTR_KEY_MANUALFEED, &j) == RC_ok)
           {
               (*bin_id) = DMBIN_MANUAL ;
               LoadDrvrString(ghDriverMod, ID_USA+IDDS_MANUAL_FEED, bin_desc,
                                 MAX_BINNAME_LEN-1) ;
               bin_desc += MAX_BINNAME_LEN ;
               num_bins_found++ ;
               bin_id++ ;
           }
       }

       // Check if Auto Tray Select is supported
       if (num_bins_found < num_bins_requested)
       {
           if ( num_bins_to_check > 1)
           {
               (*bin_id) = DMBIN_AUTO ;
               LoadDrvrString(ghDriverMod, ID_USA+IDDS_AUTOTRAYSELECT, bin_desc,
                                 MAX_BINNAME_LEN-1) ;
           }
       }

       KeywordListUnlock(&(*lppd).drvState.PPDList) ;
       result = 1 ;
   }

   return(result) ;
   return -1;
#endif

short FAR PASCAL ESCSetDIBScaling(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
/**********************************************************************
*
*  function:
*       Defines the scaling to apply to the subsequent calls to 
*       DIBToDevice().
*
*       Legal anytime betweeen Enable() and Disable().  
*       Does not cause a state transition.  Never disabled.
*
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- ptr to max # of bins that may be listed
*       LP lpOutData -- ptr to loc to which list is copied
*  returns:
*       >0 => success
*       <0 => error
************************************************************************/
{
  typedef struct
  {
      short ScaleMode         ;
      short xScale            ;
      short yScale            ;
  } DIBSCALE, FAR *LPDIBSCALE;

  LPPDEVICE lppd      = (LPPDEVICE)lpDevice               ;

  short PrevScaleMode = lppd->graphics.ScaleMode          ;
  short ScaleMode     = ((LPDIBSCALE)lpInData)->ScaleMode ;
  short xScale        = ((LPDIBSCALE)lpInData)->xScale    ;
  short yScale        = ((LPDIBSCALE)lpInData)->yScale    ;


  switch(ScaleMode)
  {
   case 0:
   case 1:
   case 2:
      lppd->graphics.ScaleMode = ScaleMode       ;
      lppd->graphics.xScale    = xScale          ;
      lppd->graphics.yScale    = yScale          ;
      return(PrevScaleMode)                      ;

   default:
      return(-1)                                 ;
  }
}

/**********************************************************************
*                       ESCEPSPrinting
*  function:
*       turns minimal header mode (EPS printing) on and off.
*       Minimal header mode is for the use of applications that 
*       do all imaging via custom PostScript language code, rather
*       than via GDI.  In minimal header mode, the driver is responsible
*       only for invoking the paper source, size, and orientation, and
*       ejecting each page.  The application must call Escape PassThrough
*       or Escape PostScriptData for all imaging.  In minimal header
*       mode, all GDI imaging is disabled.
*
*       May be called only between Enable() and StartDoc.
*       Does not cause a state transition.  Is not disabled when GDI
*       is disabled.
*
*  prototype:
*       short FAR PASCAL ESCEPSPrinting(LPPDEVICE lpDevice,LP lpInData,LP lpOutData);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData -- LPBOOL TRUE => do EPS, FALSE => do normal PS
*       LP lpOutData -- not used
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

short FAR PASCAL ESCEPSPrinting(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
     {
     LPPDEVICE lppd;
     FLAG fEPSPrinting;
     short retval;

     lppd=(LPPDEVICE)lpDevice;
     fEPSPrinting= ( *((LPFLAG)lpInData) == 1 );

     if (stCurrentLppd(lppd) == ST_ENABLED)
          {
          SetIsMinHeaderLppdF( lppd, fEPSPrinting );
          SetDisableGDILppdF(  lppd, fEPSPrinting );

          retval = 1;     // success
          }
     else    // if (stCurrent... == ST_ENABLED) ... 
          {
          // We are not between Enable() and StartDoc.  Return error code.

          retval = 0;     // failure
          }

     return(retval);
     }

//
short FAR PASCAL ESCEnumPaperMetrics(LPPDEVICE lppd,LP lpInData,LP lpOutData)
/**********************************************************************
*
*  function:
*       This routine returns a list of rectangles describing imageable
*       areas for the types of paper supported by a printer. Two rectangles
*       are returned for a paper type: one for the imageable area and
*       another describing the entire area of the physical page. This is
*       nonsense carried over from the earlier Drivers for compatibility.
*       Rectangles are in device coordinates and they describe areas
*       corresponding to portrait orientation.
*
*       May be called any time between Enable and Disable.  
*       Does not change driver state.  Never disabled.
*
*  parameters:
*       LP lpDevice -- PDEVICE pointer
*       LP lpInData -- ptr to mode,
*          if 0, then just report how many rects are available,
*          if 1, then copy rects to lpOutData
*       LP lpOutData -- ptr to loc to which rectangle list is copied
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/
{
   WORD   numPapers, dex , res_x, res_y;
   LPRECT rect_list ;
   short mode ;
   LPPRINTERINFO  lpPrinterInfo ;
   LPMAINKEYHDR  lpCurMainKeyHdr ;
   LPBYTE      lpOptionsBlock;
   LPPAPERINFO  lpPaperInfo ;
   LPWPXBLOCKS   lpWPXblock ;
   LPPSDEVMODE  dm1;
   POINT pt ;

   if(! (lpInData && lpOutData))
      return -1 ;  // no way to communicate !

   mode = *((LPSHORT) lpInData) ;
   rect_list = (LPRECT) lpOutData ;

   //  need current x and y resolution.

   res_x = lppd->DeviceRes.x_res ;
   res_y = lppd->DeviceRes.y_res ;

   KeywordGetNumOfOptions(lppd, IND_PAPERINFO, &numPapers);

   if (mode == 0)                    // Just return # of rectangles needed
   {
      *(LPSHORT)lpOutData = 2 * numPapers ;  //2 rects per paper size
      return(1);
   }

   lpWPXblock = lppd->lpWPXblock  ;
   dm1 = &lppd->lpPSExtDevmode->dm ;

   lpPrinterInfo = (LPPRINTERINFO)lpWPXblock->WPXprinterInfo ;
   lpOptionsBlock = lpWPXblock->WPXarrays ;
   lpCurMainKeyHdr = lpPrinterInfo->mainKeyHdrs + IND_PAPERINFO ;

   lpPaperInfo = (LPPAPERINFO)MAKELONG(
      lpCurMainKeyHdr->extraOptionArray, HIWORD(lpOptionsBlock) );


   for (dex = 0; dex < numPapers; dex++)
   {
      if (dex == lpPrinterInfo->devcaps.CustomPageSize) 
      {
         RECT  hwMargins = dm1->custPaper[dm1->currentCustPaper].HWmargins;

         if (dm1->currentCustPaper == 0xFFFF)
         {
             pt.x =
                (WORD)(dm1->custPaper[0].customWidth);
             pt.y =
                (WORD)(dm1->custPaper[0].customHeight);
         }
         else if (dm1->currentCustPaper != APP_DEFINED)
         {
             pt.x =
                (WORD)(dm1->custPaper[dm1->currentCustPaper].customWidth);
             pt.y =
                (WORD)(dm1->custPaper[dm1->currentCustPaper].customHeight);
         }
         else
         {
             // App defined custom paper.
             pt.x = (WORD)dm1->appCustWidth;
             pt.y = (WORD)dm1->appCustHeight;
         }

         //  construct imageable area rectangle for paper based on
         //  HWmargins.  (in PS coords)

         rect_list->top    = pt.y - hwMargins.top ;
         rect_list->right  = pt.x - hwMargins.right ;
         rect_list->bottom = hwMargins.bottom ;
         rect_list->left   = hwMargins.left ;
      } 
      else   
      {  
         *rect_list = lpPaperInfo[dex].imageableArea ;   
         pt.x = lpPaperInfo[dex].width  ;
         pt.y = lpPaperInfo[dex].length ;
      } 
      //  transform rectangle from PS coords to GDI
      //  we could be subject to overflow here, but who cares.

      rect_list->top = pt.y - rect_list->top ;
      rect_list->bottom = pt.y - rect_list->bottom ;
      
      rect_list->top = MulDiv(rect_list->top, res_y, 72);
      rect_list->bottom = MulDiv(rect_list->bottom, res_y, 72);
      rect_list->left = MulDiv(rect_list->left, res_x, 72);
      rect_list->right = MulDiv(rect_list->right, res_x, 72);
      rect_list++ ;

      pt.x = MulDiv(pt.x, res_x, 72);
      pt.y = MulDiv(pt.y, res_y, 72);
      SetRect(rect_list, 0, 0, pt.x, pt.y) ;
      rect_list++ ;
   }
   return 1 ;
}
       
#if 0
   LPPDEVICE lppd ;
   short mode, rect_num, num_paper_sizes, max_paper_types, i, old_page_index ;
   short s1, s2 ; //dummies
   LPRECT rect_list ;
   POINT pt ;
   char keyword[MAX_KEYWORD_LEN] ;
   char option[MAX_OPTION_LEN] ;
   char trans[MAX_TR_STRING_LEN] ;
   BOOL custompaper = FALSE;
   BOOL NoConstraint = FALSE;

   lppd = (LPPDEVICE) lpDevice ;
   mode = *((LPSHORT) lpInData) ;
   KeywordListLock(lppd, &(*lppd).drvState.PPDList, TRUE) ;

   // Find out how many paper sizes are supported by the current printer.
   LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_PAGESIZE, keyword, sizeof(keyword)) ;
   KeywordListGetOptionRange(lppd, &(*lppd).drvState.PPDList,keyword,&num_paper_sizes) ;

   max_paper_types = num_paper_sizes;

   if ( (DoesKeywordExist(lppd, &(*lppd).drvState.PPDList, ID_PPDSTR_KEY_CUSTOMPAGE) == TRUE) &&
          (DoesKeywordExist(lppd, &(*lppd).drvState.PPDList, ID_PPDSTR_KEY_CUSTOMPAGEPARAMS) == TRUE))
   {
       max_paper_types++;                           // increment for CustomPage
   }
     
   if (mode == 0)                    // Just return # of rectangles available
       (*((LPSHORT) lpOutData)) = max_paper_types*2 ;  //2 rects per paper size
   else                                   //Construct list of imageable areas
   {
       rect_list = (LPRECT) lpOutData ;
       rect_num = 0 ;
       KeywordListGetCurrentOption(lppd, &(*lppd).drvState.PPDList, keyword,
                          NULL, 0, &old_page_index) ; //Keep track of media option

       for (i = 0; i < max_paper_types; i++)
       {
           trans[0]  = (char)0;
           option[0] = (char)0;

           // Change media option so GetPPDPaperMetrics routine will describe
           // correct paper type

           if (i == num_paper_sizes)
           {                       // turn custompage ON, to get paper metrics
               custompaper = GetCurrBinPPDVal(lppd, &(*lppd).drvState.PPDList, 
                                                             ID_PPDSTR_KEY_CUSTOMPAGE);
               SetCurrBinPPDVal(lppd, &(*lppd).drvState.PPDList, ID_PPDSTR_KEY_CUSTOMPAGE, TRUE);
               NoConstraint = TRUE;
           }
           else
           {
               KeywordListGetOption(lppd, &(*lppd).drvState.PPDList, keyword, option,
                                        MAX_OPTION_LEN, &i, trans, MAX_TR_STRING_LEN) ;
               if (IsKeywordOptionConstrained(lppd, &lppd->drvState, keyword, 
                                                        option) == FALSE)
               { 
                  KeywordListSetCurrentOption(lppd, &(*lppd).drvState.PPDList, keyword,
                                                        NULL, i) ;
                  NoConstraint = TRUE;
               }
           }

           if (NoConstraint)   // current PaperSize option is not constrained..
           {
               NoConstraint = FALSE;          // reset constraint flag

               // Get imageable area for i'th paper type and store in rect_list.
               GetPPDPaperMetrics(lppd, &(lppd->drvState),&pt,&rect_list[rect_num],
                                      &s1, &s2) ;
               rect_num++ ;

               // Store rectangle describing entire sheet of paper in rect_list.
               SetRect(&rect_list[rect_num], 0, 0, pt.x, pt.y) ;
               rect_num++ ;
           }
           if (i == num_paper_sizes)         // restore custompage ON/OFF status
               SetCurrBinPPDVal(lppd, &(*lppd).drvState.PPDList, 
                                             ID_PPDSTR_KEY_CUSTOMPAGE, custompaper);
       }  // for(...)

       KeywordListSetCurrentOption(lppd, &(*lppd).drvState.PPDList, keyword,
                                          NULL, old_page_index); // restore media option
   }  // else mode != 0

   KeywordListUnlock(&(*lppd).drvState.PPDList) ;
   return(1);
   return -1;
}
#endif

//
short FAR PASCAL ESCGetSetPaperMetrics(LPPDEVICE lpDevice,LP lpNewPaper,LP lpOldPaper)
/**********************************************************************
*
*  function:
*       Report the printer's current paper metrics and/or select a new
*       paper type that matches supplied paper metrics.
*
*       May be called anytime between Enable and Disable.  However,
*       attempting to set paper metrics after EndDoc has no effect.
*       Never disabled.  Does not change driver state.
*
*  parameters:
*       LP lpDevice -- PDEVICE pointer
*       LP lpNewPaper -- ptr to RECT describing new imageable area.
*       LP lpOldPaper -- ptr to RECT describing old imageable area.
*
*  returns:
*       > 0 => success
*       < 0 => error
************************************************************************/
{
#if 0
   short result = 1 ;
   LPPDEVICE lppd ;
   LPKEYWORDLISTREC PPDList ;
   int old_orientation, orientation, old_PPD_media_index, PPD_media_index ;
   BOOL old_nomargins_flag, nomargins_flag ;
   LPRECT lpOldRect, lpNewRect ;
   short s1, s2 ; //dummies
   POINT pt ;
   char keyword[MAX_KEYWORD_LEN] ;
   char option[MAX_OPTION_LEN] ;
   char trans[MAX_TR_STRING_LEN] ;
   HANDLE pihdl = NULL ;

   lppd = (LPPDEVICE) lpDevice ;
   PPDList = &(*lppd).drvState.PPDList ;
   KeywordListLock(lppd,PPDList, TRUE) ;

   //-----------------------------------------------------------------
   // Get info describing current(=old) paper.
   //-----------------------------------------------------------------
   old_orientation = (*lppd).drvState.bOrientation ;
   old_nomargins_flag = (*lppd).drvState.bfNoMargins ;
   LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_PAGESIZE, keyword, sizeof(keyword)) ;
   KeywordListGetCurrentOption(lppd, PPDList, keyword, NULL, 0,&old_PPD_media_index);

   if (lpOldPaper)
   {
       //-----------------------------------------------------------------
       // Return the imageable area of the old paper.
       //-----------------------------------------------------------------
       lpOldRect = (LPRECT) lpOldPaper ;
       GetPPDPaperMetrics(lppd, &(lppd->drvState), &pt, lpOldRect, &s1, &s2) ;
       if (old_nomargins_flag) // GetPPDPaperMetrics() accounts for CustomPaper                  
       {  //Report entire page as imageable area.
           SetRect(lpOldRect, 0, 0, pt.x, pt.y) ;
           if ((old_orientation == DMORIENT_LANDSCAPE)  ||
                (old_orientation == DMORIENT_ROT_LANDSCAPE ))
               FlopRect(&(lppd->drvState), lpOldRect, lpOldRect) ;//Convert rect to landscape.
       }  // no_margins_flag
   }

   if (lpNewPaper)
   {
       //-----------------------------------------------------------------
       // Find the paper size that matches the NewPaper.
       //-----------------------------------------------------------------
       lpNewRect = (LPRECT) lpNewPaper ;
       if (MatchPaperSize(lppd, PPDList, lpNewRect, &PPD_media_index,
                                 &orientation, &nomargins_flag) != RC_ok)
           result = -1 ;
       else
       {   //Don't allow change to margins in the middle of a job.
           if (fInDocLppd(lppd) && (old_nomargins_flag != nomargins_flag))
               result = -1 ;
       }
       if (result > 0)
       {
           //-----------------------------------------------------------------
           // Update paper size, orientation, margins for the current job.
           //-----------------------------------------------------------------
           KeywordListGetOption(lppd, PPDList, keyword, option, sizeof(option),
                                     &PPD_media_index, trans, MAX_TR_STRING_LEN); 
                                                                       // Get option string.

           if (IsKeywordOptionConstrained(lppd, &lppd->drvState, keyword, option) 
                                                            == FALSE)
           { 
               KeywordListSetCurrentOption(lppd, PPDList, keyword, NULL, PPD_media_index) ;
               SetCurrPPDOptVal(lppd, PPDList, ID_PPDSTR_KEY_ORIENT,
                                     ID_PPDSTR_BASE_ORIENT, orientation) ;

               lppd->drvState.fOrientRotate = 
                              (orientation == DMORIENT_ROT_LANDSCAPE) ? TRUE : FALSE;
               (*lppd).drvState.bOrientation = (BYTE) orientation ;
               SetCurrBinPPDVal(lppd, PPDList, ID_PPDSTR_KEY_NOMARGINS, nomargins_flag) ;
               (*lppd).drvState.bfNoMargins= (BYTEFLAG) nomargins_flag ;

               // update imageable area, paper dimensions based on new paper size, orientation.
               GetPPDPaperMetrics(lppd, &(lppd->drvState), &(lppd->drvState.ptPaperDim),
                                      &(lppd->drvState.imageRect), &s1, &s2); 

               if (fInDocLppd(lppd))
               {
                  //---------------------------------------------------------
                  // Send tokens to the translation layer.
                  //---------------------------------------------------------
                  if (old_PPD_media_index != PPD_media_index)
                      CPaperSize(lppd,option) ;

                  if (old_orientation != orientation)
                      CPageOrientation(lppd,orientation) ;
               }

               //-----------------------------------------------------------------
               // Update permanent database.
               //-----------------------------------------------------------------
               pihdl = Ps_EnumOpen((*lppd).drvState.zNickName, 0);//Open printer rec.
               if (!pihdl)
                  result = -1 ;
               // Store paper size.
               else  if (Ps_PPDSetKeywordOption(pihdl, keyword, option) != PS_RC_OK)
                          result = -1 ;
                      else //Store orientation.
                      {
                          LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_ORIENT, keyword,sizeof(keyword)) ;
                          KeywordListGetCurrentOption(lppd, PPDList, keyword, option,
                                                               sizeof(option), &s1) ;
                          if (Ps_PPDSetKeywordOption(pihdl, keyword, option) != PS_RC_OK)
                              result = -1 ;
                      }

               if (result > 0) //Store nomargins flag.
               {
                  LoadDrvrString(ghDriverMod, ID_PPDSTR_KEY_NOMARGINS, keyword,
                                     sizeof(keyword)) ;
                  KeywordListGetCurrentOption(lppd, PPDList, keyword, option,
                                                            sizeof(option), &s1) ;
                  if (Ps_PPDSetKeywordOption(pihdl, keyword, option) != PS_RC_OK)
                      result = -1 ;
               }

               if (pihdl) //Close printer rec.
               {
                  if (Ps_EnumClose(pihdl) != PS_RC_OK)
                  {
                      if (result > 0)
                          result = -1 ;
                  }
               }
           }  // IsKeywordOptionConstrained(...)
       }     // if (result > 0)
   }        // if (lpNewPaper)

   KeywordListUnlock(PPDList) ;
   return(result) ;
#else
   return -1;
#endif
}

//
short FAR PASCAL ESCPostScriptIgnore(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
/**********************************************************************
*
*  function:
*       On a PostScript language driver, lpInData contains a flag
*       telling whether GDI imaging calls are to be disabled.  (On
*       other drivers, this escape is ignored.)
*
*       May be called anytime between StartDoc and EndDoc.  However,
*       it is a NOP if fDoMinHeader is true (minimal header mode 
*       disables GDI, and we don't want apps re-enabling it).
*       Does not change driver state.
*
*  parameters:
*       LP lpDevice -- PDEVICE pointer
*       short far *lpInData -- ptr new value of Disable GDI flag
*       LP lpOutData        -- not used, may be NULL
*
*  returns:
*       previous value of "Disable GDI" flag.
*
************************************************************************/
{
     LPPDEVICE   lppd         = (LPPDEVICE) lpDevice;
     BOOL        fDisableGDI;
     BOOL        fPrev        = fDisableGDILppd(lppd);

     if (fInDocLppd(lppd) && !fIsMinHeaderLppd(lppd) && (lpInData != NULL))
     {
     fDisableGDI = ( *((short far *) lpInData) != 0 );
     SetDisableGDILppdF( lppd, fDisableGDI );
     }

     return( fPrev );
}


/*
 *      ESCGetExtendedTextMetrics
 *
 *      May be called anywhere between Enable() and Disable().
 *      Never disabled.  Never causes a state transition.
 */

short FAR PASCAL ESCGetExtendedTextMetrics(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
// GDI passes the Driver a pointer to an EXTTEXTDATA structure. This
// structure contains the universe of information. For reference the
// structure is shown below:
//
//       typedef struct _EXTTEXTDATA
//       {
//          short       sSize     ;
//          LP          lpInData  ;
//          LPPSFONTINFO  lpFontInfo;
//          LPTEXTXFORM lpXForm   ;
//          LPDRAWMODE  lpDrawMode;
//       }
//       EXTTEXTDATA, FAR *LPEXTTEXTDATA;
//
// All that is needed from this structure is the EXTTEXTMETRIC structure
// which is contained in the FONTEXTRA structure which is contained in
// the FONTINFO structure. Therefore...

  LPEXTTEXTDATA lpetd    ;
  LPPSFONTINFO    lpFontInfo ;
  LPFONTEXTRA   lpFontExtra  ;
  LPETM         lpETM        ;
  short         sETMSize     ;

  lpetd      = (LPEXTTEXTDATA)lpInData       ;

  if (lpetd == (LPEXTTEXTDATA)NULL)
       return(0)  ;       // Return number of bytes

  lpFontInfo = (LPPSFONTINFO )lpetd->lpFontInfo;

  if( lpFontInfo == (LPPSFONTINFO)NULL  ||  
         (lpFontInfo->dfType & 0x80) == 0   )
       return(0)  ;       // Return number of bytes

  lpFontExtra  = (LPFONTEXTRA) BUMPFAR( lpFontInfo, lpFontInfo->dfDriverInfo);

  if ( lpFontExtra == (LPFONTEXTRA)NULL )
       return(0)  ;       // Return number of bytes
                          // copied into lpOutData

  lpETM = (LPETM) BUMPFAR (lpFontInfo, lpFontExtra->dwExtTextMetrics) ;

  if ( lpETM == (LPETM)NULL )
       return(0)  ;       // Return number of bytes

  sETMSize   = *((LPSHORT)lpetd->lpInData)   ;


  if(sETMSize > sizeof(ETM)) 
      sETMSize=sizeof(ETM) ;       // Limit number bytes to the
                                   // size of the ETM structure

  MemCopy(lpOutData,(LP)lpETM,(DWORD)sETMSize)  ;       // Copy the data
  return(sETMSize)                              ;       // Return number bytes copied
}                                                       // to the caller.


/*
 *	ESCGetDIBSupport
 *
 *      May be called anywhere between Enable() and Disable().
 *      Never disabled.  Never causes a state transition.
 */

short FAR PASCAL ESCGetDIBSupport(LPPDEVICE lpDevice,LP lpInData,LP lpOutData)
{
  // GDI passes the Driver a pointer to an BitmapInfo structure.

  if (ValidateDIB((LPBITMAPINFOHEADER)lpInData))
    *lpOutData = (QDI_SETDIBITS || QDI_DIBTOSCREEN || QDI_STRETCHDIB);
  else
    *lpOutData = 0;

  return ('RP');
}
/*
 * ValidateDIB
 *
 * Validates the DIB and reject formats that pscript cannot deal with.
 *
 * Entry:
 *	 ds:si -> DIB Info header.
 *	 ebx   -> max compression type that we support.
 *
 * Return:
 *	 eax = 1 if the DIB Engine can support the DIB.
 *	     = 0 if the DIB type is not supported.
 *
 */

BOOL ValidateDIB(LPBITMAPINFOHEADER lpInfo)
{
  LPBITMAPV4HEADER lpV4;

  lpV4 = (LPBITMAPV4HEADER)lpInfo;

  if (lpInfo->biCompression != BI_BITFIELDS)  // bit fields ?
  {					      // not all are valid.
    if (lpInfo->biCompression == BI_RGB)      // max compression type
    {
      if ((lpInfo->biBitCount ==  1) ||
	  (lpInfo->biBitCount ==  4) ||
	  (lpInfo->biBitCount ==  8) ||
	  (lpInfo->biBitCount == 16) ||
	  (lpInfo->biBitCount == 24) ||
	  (lpInfo->biBitCount == 32)   )
      {
	return (TRUE);
      }
      return (FALSE);
    }
    else
      return (FALSE);			      // do not do these compressions
  }
  else
  {
    if (lpInfo->biBitCount == 16)	      // Bitfields supported on 16 Bpp.
    {					      // Check supported bitfields.
      if (lpV4->bV4BlueMask  == 0x001F)       // Blue mask must be first 5 bits.
      {
	if (lpV4->bV4GreenMask	 == 0x03E0)   // Green mask may be middle 5 bits.
	{
	  if (lpV4->bV4RedMask == 0x7C00)     // Red mask must be last 5 bits.
	    return (TRUE);
	}
	else if (lpV4->bV4GreenMask == 0x07E0) // Green mask may be middle 6 bits.
	{
	  if (lpV4->bV4RedMask == 0xF800)     // Red mask must be last 5 bits.
	    return (TRUE);
	}
	return (FALSE);
      }
    }
    else if (lpInfo->biBitCount == 32)	      // Bitfields supported on 32 Bpp.
    {					      // Check supported 24Bpp format.
      if ((lpV4->bV4BlueMask  == 0x0000FF)&&  // Blue mask must be first 8 bits.
	  (lpV4->bV4GreenMask == 0x00FF00)&&  // Green mask must be scnd 8 bits.
	  (lpV4->bV4RedMask   == 0xFF0000))   // Red masm must be last 8 bits.
	return (TRUE);
      else
	return (FALSE);
    }
    else
      return (FALSE);			      // invalid header
  }
}

/**********************************************************************
*                       ESCSpecialPass(lpDevice,lpInData,lpOutData);
*  function:
*   Special passthrough. It enables applications to send data directly to the printer,
*   by passing the standard printer driver code. The difference between this special
*   and ordinary PASSTHROUGH is that SPCLPASSTHROUGH must be called before anything else
*   (STARTDOC, EPSPRINTING, etc) to allow sending PS after the driver sends its procsets
*   PASSTHROUGH can only be called at the beginning of te first page after all the driver
*   procsets and documnet setup are sent. If an app wants to send anything before
*   the first page, it must use this ESC. Dirver keeps the lpInData passed in with
*   this special passthrough and sends it after its own procsets are sent.
*        --- From ERS 2.2A3
*   Copied from 3.0 driver on 5-1-1995
*
*   May be called only between Enable and StartDoc, before EPSPRINTING.
*       Does not cause a state transition.  Is not disabled when GDI
*       is disabled.
*
*  prototype:
*       short FAR PASCAL ESCSpecialPass(lpDevice,lpInData,lpOutData);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData --  Pointer to a buffer in which the first 16 bits specifies
*           the number of bytes in the buffer. The remaining bytes should be sent to printer
*       LP lpOutData -- not used
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/

short FAR PASCAL ESCSpecialPass(LP lpDevice,LP lpInData,LP lpOutData)
	{
	LPPDEVICE lppd;
	LPWLPBYTE lpTemp;
	short retval;

	lppd=(LPPDEVICE)lpDevice;

	if (stCurrentLppd(lppd) == ST_ENABLED)
	   { // need check this logic carefully.
	   lpTemp = (LPWLPBYTE)lpInData;
	   lppd->bCopyToSpecial=TRUE;      // after this flag is set, all data goes to lpSpecialPSData.
       PSSendData(lppd, (LPBYTE)&(lpTemp->lpData), lpTemp->wLen);
	   
	   retval = 1;     // success
	   }
	else    // if (stCurrent... == ST_ENABLED) ... 
		{
		// We are not between Enable() and StartDoc.  Return error code.

		retval = 0;     // failure
		}

	return(retval);
	}


/**********************************************************************
*                       ESCPSInjection(lpDevice,lpInData,lpOutData);
*  function:
*   PostScript Injection ESC call. It enables applications to send data directly to the printer,
*   by passing the standard printer driver code. It allows PostScript code to be inserted
*   berfore,after or replace at the available PostScript injection point. 
*
*  prototype:
*       short FAR PASCAL ESCPSInjection(lpDevice,lpInData,lpOutData);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData --  Pointer to a buffer in which the first 8 bytes as:
*       DWORD   size of PostScript data
*		  WORD    injection point id
*		  WORD    page number if appicable
*       LPBYTE  The remaining bytes should be sent to printer
*       LP lpOutData -- not used
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/
short FAR PASCAL ESCPSInjection(LP lpDevice,LP lpInData,LP lpOutData)
{
	LPPDEVICE lppd;
	LPPSINJECTBYTE lpTemp;
	short retval;
//   DWORD dwLen;

	lppd=(LPPDEVICE)lpDevice;

	lpTemp = (LPPSINJECTBYTE)lpInData;
   lppd->bCopyToInjectBuff=TRUE;      // after this flag is set, all data goes to
   //need pass in the complete structure here	

   /*  need handle this in next level, since the PSINJECTBYTE structure 
       change
   if ( lpTemp->dwLen > MAX_PSSIZE)
   {
     dwLen = lpTemp->dwLen;
     while ( dwLen > MAX_PSSIZE ) 
     {
         PSSendData(lppd, (LPBYTE)lpInData, (WORD)MAX_PSSIZE);
         dwLen -= MAX_PSSIZE;
         // now the data is part of LPINJECTBYTE need change it

         lpTemp->lpData += MAX_PSSIZE;  //
     }
     PSSendData(lppd, (LPBYTE)lpInData, (WORD)dwLen);
   }
   else
   */
   PSSendData(lppd, (LPBYTE)lpInData, (WORD)lpTemp->dwLen);
   lppd->bCopyToInjectBuff=FALSE;      	   
	retval = 1;     // success

	return(retval);
}



/**********************************************************************
*                    ESCDownLoadFaceStr(lpDevice,lpInData,lpOutData);
*  function:
*   Copy a String and its length to PDEVICE. It enables applications to do Incremental Downlaoding
*   with Escape(DOWNLOADFACE) call. The string is going to be used by next Escape(DOWNLOADFACE) call
*   And the buffers will be marked as 0 length immediatelly after that to ensure the
*   next Escape(DOWNLOADFACE) can be for whole font.
*
*   May be called any time after Enable and before EndDoc,
*   Is not disabled when GDI is disabled.
*
*  prototype:
*       short FAR PASCAL ESCDownLoadFaceStr(lpDevice,lpInData,lpOutData);
*  parameters:
*       LP lpDevice -- PDEVICE pointer;
*       LP lpInData --  Pointer to a buffer in which the first 6 bytes specifies
*           3 WORDS:
*           wFirst - Reserved to extend the font to OCF for Glyph-index
*                     it must be 0 for current implementation
*           wSecond -  the High byte used to form WORDS with remaining bytes in the buffer.
*           wThird -  the number of bytes in the remaining buffer.
*           The remaining (wThird) bytes will be used in next Escape(DOWNLOADFACE)
*       LP lpOutData -- not used
*  returns:
*       >0 => success
*       -1 => error
************************************************************************/
short FAR PASCAL ESCDownLoadFaceStr(LP lpDevice,LP lpInData,LP lpOutData)
	{
	LPPDEVICE lppd;
	LPW3LPBYTE lpTemp;
	short retval;

	lppd=(LPPDEVICE)lpDevice;

    // Reset the FontDataList for OpenChannel - because of bug fix for 143628 
    // we register the F0 for OpenChannel -there is no other way to inform th edriver
    //  to discard previouys downlaoded fonts. We use this escape for that purpose as well.
    // For minheaders, we do this at the end of every page.
    if (lppd->job.bfESCOpenChannel){
       InitFontDataList( lppd );  
       }

    lpTemp = (LPW3LPBYTE)lpInData;  //lpTemp->wThird+sieof(W3LPBYTE) is the length of the lpInData.
    if (lpTemp==NULL || lpTemp->wFirst!=0) return -2;  // Use wFrist to extend to OCF/GI
    
    if ((DWORD)lpTemp->wThird+sizeof(W3LPBYTE) >= lppd->dwDownloadFaceStr){
       if(lppd->lpDownloadFaceStr)
          GlobalFreePtr((LPVOID)lppd->lpDownloadFaceStr) ;
       lppd->dwDownloadFaceStr = (DWORD)lpTemp->wThird+sizeof(W3LPBYTE)+1; // update size. 1 more is for NULL
       lppd->lpDownloadFaceStr = (LPW3LPBYTE)GlobalAllocPtr(GHND|GMEM_DDESHARE, lppd->dwDownloadFaceStr);
       if (lppd->lpDownloadFaceStr){
          // Warning: lpData is allocated above together.
          lppd->lpDownloadFaceStr->lpData =
              (LPBYTE)lppd->lpDownloadFaceStr + sizeof(W3LPBYTE);  // notice how lpData is allocated here.
          }
       else {
          lppd->dwDownloadFaceStr = 0;  // alloc failed, reset the size.
       }
    }

    if ((DWORD)lpTemp->wThird+sizeof(W3LPBYTE) < lppd->dwDownloadFaceStr && lppd->lpDownloadFaceStr!=NULL){
       lppd->lpDownloadFaceStr->wThird = lpTemp->wThird;  // wLength in lpData
       lppd->lpDownloadFaceStr->wSecond = lpTemp->wSecond;
       MemCopy((LPBYTE)lppd->lpDownloadFaceStr->lpData, (LPBYTE)&(lpTemp->lpData), (DWORD)lpTemp->wThird);
       retval = 1;     // success
    }
    else {
       retval = -1;  // fail
    }
   

	return(retval);
	}


