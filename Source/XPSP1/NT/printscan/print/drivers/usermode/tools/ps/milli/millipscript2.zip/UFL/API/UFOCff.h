/*
 *    Adobe Universal Font Library
 *
 *    Copyright (c) 1996 Adobe Systems Inc.
 *    All Rights Reserved
 *
 *    UFOCFF.h -- Universal Font Object to be used w/ CFF font.
 *
 *
 * $Header:
 */

#ifndef _H_UFOCFF
#define _H_UFOCFF

/*============================================================================
 * Include files used by this interface
 *==========================================================================*/
#include "UFO.h"
#include "xcf_pub.h"

typedef struct
{
     // CFF Data starts from here.

    XFhandle          hFont;
    UFLCFFFontInfo    info;

    // These fields are used to get CFF data if the client does not provided
    // the whole CFF table.

    unsigned long     cbBuf;    // Size of the pbuf
    unsigned char     *pBuf;    // Buffer used to retrieve data
} CFFFontStruct;

UFOStruct*
CFFFontInit(
    const UFLMemObj*  pMem,
    const UFLStruct*  pUFL,
    const UFLRequest* pRequest,
    UFLBool*          pTestRestricted
    );

UFLErrCode
CFFGIDsToCIDs(
    const CFFFontStruct*   pFont,
    const short            cGlyphs,
    const UFLGlyphID*      pGIDs,
    unsigned short*        pCIDs
    );

#endif
