/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ADVANCED.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for the Advanced          */
/*              Dialog                                                       */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "apd42map.hh"

#pragma code_seg(_DIALOGSSEG)

// Next two are defined in CONT\alert.c
int FAR PASCAL GetShowAlert(void);
int FAR PASCAL SetShowAlert(int);


/*****************************************************************************/
/*                 ShowAdvancedOnScreen                                      */
/* Purpose:                                                                  */
/*   Shows updated advanced features on the dialog.                          */
/*                                                                           */
/* Parameters:                                                               */
/*   LPDRIVERINFO -- DRIVERINFO structure                                    */
/*   HWND hDlg    -- Handle to Advanced features dialog                      */
/*   BOOL bInit   -- TRUE on initialization, FALSE otherwise                 */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/
VOID NEAR PASCAL ShowAdvancedOnScreen(LPDRIVERINFO lpDrvInfo,
                                      HANDLE       hDlg,
                                      BOOL         bInit,
                                      BOOL         bRestore)
{
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
            (LPPRINTERINFO)lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;
    BOOL           bBinary;

    // Initialize stuff from the devmode only when the dialog initializes
    if(bInit)
    {
#ifndef ADOBE_DRIVER_42
        CheckRadioButton(hDlg,ID_ADV_LEVEL_1,ID_ADV_LEVEL_2,
            lpPSExtDevmode->dm2.bfUseLevel2?ID_ADV_LEVEL_2:ID_ADV_LEVEL_1);

        CheckRadioButton(hDlg,ID_ADV_COMPRESS, ID_ADV_NO_COMPRESS,
            lpPSExtDevmode->dm2.bCompress?ID_ADV_COMPRESS:ID_ADV_NO_COMPRESS);

        EnableWindow(GetDlgItem(hDlg,ID_ADV_LEVEL_2),
            (((LPPRINTERINFO)(lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo))->devcaps.languageLevel > 1));
#else
#ifndef MICROSOFT_DRIVER_VERSION
//  Set this up for testing lpPrinterInfo->devcaps.languageLevel = 3; lpPSExtDevmode->dm2.useLanguageLevel = 2;

        SendDlgItemMessage(hDlg, ID_ADV_LEVEL, EM_LIMITTEXT, 2, 0) ;

        SendDlgItemMessage(hDlg, ID_ADV_LEVEL_SPN, UDM_SETRANGE, NULL,
                           MAKELPARAM(lpPrinterInfo->devcaps.languageLevel, MIN_PSLEVEL));
        SendDlgItemMessage(hDlg, ID_ADV_LEVEL_SPN, UDM_SETPOS, NULL,
                           MAKELPARAM(lpPSExtDevmode->dm2.useLanguageLevel, NULL));
#else
       CheckDlgButton(hDlg,ID_ADV_LEVEL_SPN, lpPSExtDevmode->dm2.useLanguageLevel == 2 ? BST_CHECKED : BST_UNCHECKED);

       EnableWindow(GetDlgItem(hDlg,ID_ADV_LEVEL_SPN),(lpPrinterInfo->devcaps.languageLevel > 2));

#endif

#endif

        if (!lpPrinterInfo->devcaps.BCPsupport)
        {
            EnableWindow(GetDlgItem(hDlg,ID_ADV_BCP), FALSE);
            if (lpPSExtDevmode->dm2.iDataOutputFormat == PROTOCOL_BCP)
                lpPSExtDevmode->dm2.iDataOutputFormat = PROTOCOL_ASCII;
        }

        if (!lpPrinterInfo->devcaps.TBCPsupport)
        {
            EnableWindow(GetDlgItem(hDlg,ID_ADV_TBCP), FALSE);
            if (lpPSExtDevmode->dm2.iDataOutputFormat == PROTOCOL_TBCP)
                lpPSExtDevmode->dm2.iDataOutputFormat = PROTOCOL_ASCII;
        }

        CheckRadioButton( hDlg, ID_ADV_ASCII, ID_ADV_BINARY,
            ID_ADV_ASCII + lpPSExtDevmode->dm2.iDataOutputFormat);

        CheckDlgButton(hDlg, ID_ADV_CTRL_D_BEFORE, lpPSExtDevmode->dm2.bSendCtrlDBefore);
        CheckDlgButton(hDlg, ID_ADV_CTRL_D_AFTER , lpPSExtDevmode->dm2.bSendCtrlDAfter);
#ifdef ADOBE_DRIVER
        if(bRestore)
        {
            CheckDlgButton(hDlg, ID_ADV_ALERT, DEFAULT_SHOW_ALERT);
        }
        else
        {
           CheckDlgButton(hDlg, ID_ADV_ALERT, GetShowAlert());
        }
#endif
    }

    /* Show CTRL+D buttons when not binary */
    bBinary=!IsDlgButtonChecked(hDlg,ID_ADV_BINARY);
    EnableWindow(GetDlgItem(hDlg,ID_ADV_CTRL_D_BEFORE), bBinary);
    EnableWindow(GetDlgItem(hDlg,ID_ADV_CTRL_D_AFTER ), bBinary);

    if (lpPrinterInfo->devcaps.BCPsupport)
    {
        /* Show the Send Mode button if protocol is BCP or ASCII */
        EnableWindow(GetDlgItem(hDlg,ID_ADV_SEND_MODE),
                     IsDlgButtonChecked(hDlg,ID_ADV_BCP) ||
                     IsDlgButtonChecked(hDlg,ID_ADV_ASCII));
    }
}

void FAR PASCAL RestoreAdvancedDefaults(LPPSEXTDEVMODE lpPSExtDevmode,
                                        LPWPXBLOCKS lpWPXBlock)
{
    LPPRINTERINFO  lpPrinterInfo ;

    lpPrinterInfo = (LPPRINTERINFO)(lpWPXBlock->WPXprinterInfo);

#ifndef ADOBE_DRIVER_42
    lpPSExtDevmode->dm2.bfUseLevel2 =
        (lpPrinterInfo->devcaps.languageLevel >= 2) ;
    lpPSExtDevmode->dm2.bCompress = lpPSExtDevmode->dm2.bfUseLevel2;
#else
    lpPSExtDevmode->dm2.useLanguageLevel = lpPrinterInfo->devcaps.languageLevel;
#endif
     if (lpPrinterInfo->devcaps.iDefaultProtocol > 0)
       lpPSExtDevmode->dm2.iDataOutputFormat = lpPrinterInfo->devcaps.iDefaultProtocol - 1;
    else
       lpPSExtDevmode->dm2.iDataOutputFormat = PROTOCOL_ASCII;

    lpPSExtDevmode->dm2.bSendCtrlDBefore  = FALSE;
    lpPSExtDevmode->dm2.bSendCtrlDAfter   = TRUE;
}

#ifdef ADOBE_DRIVER_42
BOOL NEAR PASCAL CheckPSLevel( HWND hDlg, LPDRIVERINFO lpDrvInfo, int* pLevel )
{
    LPPRINTERINFO  lpPrinterInfo =
            (LPPRINTERINFO)lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;

#ifndef MICROSOFT_DRIVER_VERSION
    int ctrlID, i;
    BOOL fOk;

    ctrlID = ID_ADV_LEVEL ;
    i = GetDlgItemInt( hDlg, ctrlID, &fOk, FALSE) ;
    if ( fOk ){
        if ( i >= MIN_PSLEVEL && i <= lpPrinterInfo->devcaps.languageLevel ){
            *pLevel = i;
        }
        else
            fOk = FALSE;
    }

    if ( !fOk )
      ShowErrorValueMessage(hDlg, ctrlID, MIN_PSLEVEL, lpPrinterInfo->devcaps.languageLevel);

    return fOk;

#else

    if (IsDlgButtonChecked(hDlg, ID_ADV_LEVEL_SPN) == BST_CHECKED)
        *pLevel = 2;
    else
        *pLevel = lpPrinterInfo->devcaps.languageLevel;

    return TRUE;
#endif

}
#endif
/*****************************************************************************/
/*                 CHAdvancedDlg                                             */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the Advanced Features dialog box.                 */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHAdvancedDlg(HWND hDlg, unsigned imsg, WORD wParam,
                                      LONG lParam)
{
    LPDRIVERINFO   lpDrvInfo;
    LPWPXBLOCKS    lpWPXblock;
    LPPSEXTDEVMODE lpPSExtDevmode, lpPSExtSavedDevmode;
#ifdef ADOBE_DRIVER
    char alertval;
#endif

    if(lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
    {
#ifdef USEHOOKPROC
        /* Process hook function stuff */
        if(DrvProcessHookProc(&(lpDrvInfo->pDev),hDlg,imsg,wParam,lParam,
                              "HookSetup"))
        {
            return TRUE;
        }
#endif

        lpPSExtDevmode=lpDrvInfo->lpDM;
    }

    switch (imsg)
    {
        case WM_INITDIALOG:
            // Note that since this is a modal dialog, lpDrvInfo is passed
            // directly, rather than via LPPROPSHEETPAGE->lParam.
            lpDrvInfo=(LPDRIVERINFO)lParam;
            SetWindowLong(hDlg,DWL_USER,(LPARAM)lpDrvInfo);
            lpPSExtDevmode=lpDrvInfo->lpDM;

            lpDrvInfo->hSavedDevmode = GlobalAlloc(GHND, sizeof(PSEXTDEVMODE));
            lpPSExtSavedDevmode =
                (LPPSEXTDEVMODE)GlobalLock(lpDrvInfo->hSavedDevmode);
            *lpPSExtSavedDevmode = *lpPSExtDevmode;
            GlobalUnlock(lpDrvInfo->hSavedDevmode);

            /* If printer doesn't have BCP support, remove "SendMode" button */
            if (!((LPPRINTERINFO)lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo)->devcaps.BCPsupport)
            {
                DestroyWindow(GetDlgItem(hDlg, ID_ADV_SEND_MODE));
            }

            /* Now initialize the dialog's widgets */
            ShowAdvancedOnScreen(lpDrvInfo, hDlg, TRUE, FALSE);
            break ;

        case WM_CONTEXTMENU:
            if (wParam != -1)
            {
                WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                        (DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_HELP:
            if (((LPHELPINFO) lParam)->hItemHandle != -1)
            {
                WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                        HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
            }
            break;


        case WM_COMMAND:
            switch (wParam)
            {
                case ID_ADV_ASCII:
                case ID_ADV_BCP:
                case ID_ADV_TBCP:
                case ID_ADV_BINARY:
                    ShowAdvancedOnScreen(lpDrvInfo, hDlg, FALSE, FALSE);
                    break;

                case ID_ADV_SEND_MODE:
                    if(IDOK ==  DrvrStringMessageBox(hDlg,
                                                     DLGS_szSetPrinterOK,
                                                     DLGS_szSetPrinter,
                                                     MB_OKCANCEL |
                                                     MB_ICONQUESTION))
                    {
                        /* Download the Header! */
                        DoSwitchBetweenAsciiAndBinary(hDlg, lpDrvInfo);
                    }
                    break;

                case IDOK:
                    /*
                     * Save the state!
                     * Don't check the state of ID_ADV_LEVEL_2, since it may be
                     * disabled.
                     */
#ifndef ADOBE_DRIVER_42
                    lpPSExtDevmode->dm2.bfUseLevel2=!IsDlgButtonChecked(hDlg,
                                                                ID_ADV_LEVEL_1);
                    lpPSExtDevmode->dm2.bCompress=IsDlgButtonChecked(hDlg,
                                                              ID_ADV_COMPRESS);
#else
                    if ( !CheckPSLevel( hDlg, lpDrvInfo, &lpPSExtDevmode->dm2.useLanguageLevel ) )
                          break;
#endif
                    if(IsDlgButtonChecked(hDlg,ID_ADV_ASCII))
                        lpPSExtDevmode->dm2.iDataOutputFormat=PROTOCOL_ASCII;
                    else if(IsDlgButtonChecked(hDlg,ID_ADV_BCP))
                        lpPSExtDevmode->dm2.iDataOutputFormat=PROTOCOL_BCP;
                    else if(IsDlgButtonChecked(hDlg,ID_ADV_TBCP))
                        lpPSExtDevmode->dm2.iDataOutputFormat=PROTOCOL_TBCP;
                    else
                        lpPSExtDevmode->dm2.iDataOutputFormat=PROTOCOL_BINARY;

                    lpPSExtDevmode->dm2.bSendCtrlDBefore=
                        IsDlgButtonChecked(hDlg,ID_ADV_CTRL_D_BEFORE);
                    lpPSExtDevmode->dm2.bSendCtrlDAfter=
                        IsDlgButtonChecked(hDlg,ID_ADV_CTRL_D_AFTER);

#ifdef ADOBE_DRIVER
            if (IsDlgButtonChecked(hDlg, ID_ADV_ALERT)) alertval=1;
            else alertval=0;
            SetShowAlert(alertval);
#endif

                    GlobalFree(lpDrvInfo->hSavedDevmode);

                    EndDialog(hDlg, wParam) ;
                    break ;

                case IDCANCEL:
                    /* Reset the Data */
                    lpPSExtSavedDevmode =
                        (LPPSEXTDEVMODE)GlobalLock(lpDrvInfo->hSavedDevmode);
                    *lpPSExtDevmode = *lpPSExtSavedDevmode;
                    GlobalUnlock(lpDrvInfo->hSavedDevmode);
                    GlobalFree(lpDrvInfo->hSavedDevmode);

                    EndDialog(hDlg, wParam) ;
                    break ;
#ifndef USE_WHATSTHIS_HELP
                case ID_HELP:
                    WinHelp(hDlg, szHelpFile, HELP_CONTEXT,
                            IDH_PSCRIPT_DATA_ENCOD_FORMAT);
                    break;
#endif

                case ID_RESTORE_DEFAULTS:
                    lpWPXblock = lpDrvInfo->pDev.lpWPXblock;
                    RestoreAdvancedDefaults(lpPSExtDevmode,lpWPXblock);
                    ShowAdvancedOnScreen(lpDrvInfo, hDlg, TRUE, TRUE);
                    break;

                default:
                    return FALSE;
            } /* switch(wParam) */
            break ;

        default:
            return FALSE;
    } /* switch(imsg) */

    return TRUE;
} /* End CHAdvancedDlg */
