/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TFLAVORS.H                                                   */
/*                                                                           */
/* Description: This module contains the function prototypes for TFLAVORS.C  */
/*                                                                           */
/* Change History :                                                          */
/* L3_MASK -- Support level3 transparent image.   9/19/96   jjia             */
/*                                                                           */
/*****************************************************************************/

#define PPSLEVEL1        1
#define PPSLEVEL2        2
#define EPSLEVEL1        3
#define EPSLEVEL2        4
#define AI3              5
#define MINIMALHDR       6
#define EPSFILE_EPSPRINT 7

#define CP_CLIP          1
#define CP_RESTORE       2
#define CP_SAVE          3

#define CTMSAVE          1
#define CTMRESTORE       2

//              -----   Pens     -----

typedef short (FAR PASCAL *TPEN           )(LPPDEVICE,LPPPEN );
typedef short (FAR PASCAL *TPENCAP        )(LPPDEVICE,BYTE   );
typedef short (FAR PASCAL *TPENFGCOLOR    )(LPPDEVICE,DWORD  );
typedef short (FAR PASCAL *TPENBGCOLOR    )(LPPDEVICE,DWORD  );
typedef short (FAR PASCAL *TPENJOIN       )(LPPDEVICE,BYTE   );
typedef short (FAR PASCAL *TPENMITERLIMIT )(LPPDEVICE,short  );
typedef short (FAR PASCAL *TPENSTYLE      )(LPPDEVICE,BYTE   );
typedef short (FAR PASCAL *TPENWIDTH      )(LPPDEVICE,POINT  );


//              -----   Brushes  -----

typedef short (FAR PASCAL *TBRUSHBGCOLOR  )(LPPDEVICE,DWORD );
typedef short (FAR PASCAL *TBRUSHFGCOLOR  )(LPPDEVICE,DWORD );
typedef short (FAR PASCAL *TBRUSHHATCH    )(LPPDEVICE,BYTE  );
typedef short (FAR PASCAL *TBRUSHPATTERN  )(LPPDEVICE,LPPAT );
typedef short (FAR PASCAL *TBRUSHSTYLE    )(LPPDEVICE,BYTE  );


//              -----   Shapes   -----

typedef short (FAR PASCAL *TARC           )(LPPDEVICE,LPRECT ,LPPOINT,LPPOINT            );
typedef short (FAR PASCAL *TCHORD         )(LPPDEVICE,LPRECT ,FLAG ,FLAG,LPPOINT,LPPOINT );
typedef short (FAR PASCAL *TELLIPSE       )(LPPDEVICE,LPRECT ,FLAG ,FLAG                 );
typedef short (FAR PASCAL *TCIRCLE        )(LPPDEVICE,LPRECT ,FLAG ,FLAG                 );
typedef short (FAR PASCAL *TLINE          )(LPPDEVICE,LPPOINT                            );
typedef short (FAR PASCAL *TPIE           )(LPPDEVICE,LPRECT ,FLAG ,FLAG,LPPOINT,LPPOINT );
typedef short (FAR PASCAL *TPOLYGON       )(LPPDEVICE,LPPOINT,FLAG ,FLAG,FLAG,short      );
typedef short (FAR PASCAL *TPOLYLINE      )(LPPDEVICE,LPPOINT,short                      );
typedef short (FAR PASCAL *TPOLYBEZIER    )(LPPDEVICE,LPPOINT,short                      );
typedef short (FAR PASCAL *TRECTANGLE     )(LPPDEVICE,LPRECT ,FLAG ,FLAG                 );
typedef short (FAR PASCAL *TROUNDRECTANGLE)(LPPDEVICE,LPRECT ,FLAG ,FLAG,LPPOINT         );
typedef short (FAR PASCAL *TSCANLINE      )(LPPDEVICE,LPPOINT,FLAG ,FLAG,short           );
typedef short (FAR PASCAL *TSCANLINEBEGIN )(LPPDEVICE);
typedef short (FAR PASCAL *TSCANLINEEND   )(LPPDEVICE);
typedef short (FAR PASCAL *TPOLYMODE      )(LPPDEVICE,BYTE);

//              -----   Bitmaps & DIBs -----

typedef short (FAR PASCAL *TBMOPAQUEBOX   )(LPPDEVICE,LPRECT,DWORD        );
typedef short (FAR PASCAL *TOPAQUEBOX     )(LPPDEVICE,LPRECT,DWORD,WORD   );
typedef short (FAR PASCAL *TBITMAPHEADER  )(LPPDEVICE,LPRECT,LPRECT,DWORD );
typedef short (FAR PASCAL *TBITMAPDATA    )(LPPDEVICE,LPBITMAP,LPRECT,SHORT );
typedef short (FAR PASCAL *TBITMAPOPERATOR)(LPPDEVICE,BOOL,DWORD,DWORD,DWORD);
// L3_MASK FAST_IMAGE
typedef short (FAR PASCAL *TDIBDATABITS   )(LPPDEVICE,LPDRAWMODE,LPRECT,LPRECT,LPSTR,LPBITMAPINFO,LPSTR, SHORT, float far *);

typedef short (FAR PASCAL *TGRAYTABLE     )(LPPDEVICE,LPBYTE ,WORD        );
// L3_MASK FAST_IMAGE
typedef short (FAR PASCAL *TDIBHEADER     )(LPPDEVICE,LPDRAWMODE,LPRECT,LPRECT,BOOL,LPBITMAPINFO,SHORT, float far *);

typedef short (FAR PASCAL *TCOLORTABLE    )(LPPDEVICE,LPDWORD,WORD        );
// FAST_IMAGE
typedef short (FAR PASCAL *TDIBOPERATOR   )(LPPDEVICE,short,SHORT         );
typedef short (FAR PASCAL *TICMCOLOR      )(LPPDEVICE,DWORD               );
// L3_MASK
typedef short (FAR PASCAL *TDIBCLIPRGNS   )(LPPDEVICE,LPDRAWMODE,LPRECT,LPRECT,LPSTR,LPBITMAPINFO);


//              -----   Text and Fonts -----

typedef short (FAR PASCAL *TTEXTBEGIN)(LPPDEVICE,LPPOINT,LPPSFONTINFO,LPTEXTXFORM);
typedef short (FAR PASCAL *TTEXTRUN  )(LPPDEVICE,LPSTR , int, double, double, LPPSFONTINFO, LPTEXTXFORM, LPINT);
typedef short (FAR PASCAL *TTEXTEND  )(LPPDEVICE,LPPSFONTINFO,LPTEXTXFORM, int);
typedef PSERROR (FAR PASCAL *TSOFTFONTLOAD)(LPPDEVICE,LPPSFONTINFO,LPTEXTXFORM,LPSTR,short);
#ifdef ADD_EURO
typedef PSERROR (FAR PASCAL *TDEVICEFONTLOAD)(LPPDEVICE,LPPSFONTINFO,LPTEXTXFORM);
#endif

#ifdef ADOBE_DRIVER
typedef short (FAR PASCAL *TTEXTRUNWIDE)(LPPDEVICE, LPWORD, int, double, double,LPPSFONTINFO,LPTEXTXFORM, LPINT);
#endif


//              -----   Management  -----

typedef short (FAR PASCAL *TDRIVERDATA    )(LPPDEVICE,short);
typedef short (FAR PASCAL *TDOCUMENTPAGEBEGIN)(LPPDEVICE);
typedef short (FAR PASCAL *TDOCUMENTPAGEEND  )(LPPDEVICE);
typedef short (FAR PASCAL *TDOCUMENTABORT )(LPPDEVICE);
typedef short (FAR PASCAL *TDOCUMENTEND   )(LPPDEVICE);
typedef short (FAR PASCAL *TDOCUMENTFLUSH )(LPPDEVICE);
typedef short (FAR PASCAL *TDOCUMENTBEGIN )(LPPDEVICE);
typedef short (FAR PASCAL *TCLIPRECT      )(LPPDEVICE,LPRECT,LPRECT,int);
typedef short (FAR PASCAL *TCLIPEND       )(LPPDEVICE);
typedef short (FAR PASCAL *TJOBTYPE       )(LPPDEVICE,short);
typedef short (FAR PASCAL *TJOBTITLE      )(LPPDEVICE,LPSTR);
typedef short (FAR PASCAL *TJOBCOPIES     )(LPPDEVICE,WORD);
typedef short (FAR PASCAL *TJOBDUPLEX     )(LPPDEVICE,WORD);
typedef short (FAR PASCAL *TBACKGROUNDMODE)(LPPDEVICE,BYTE);
typedef short (FAR PASCAL *TCOLORBG       )(LPPDEVICE,DWORD);
typedef short (FAR PASCAL *TARCDIRECTION  )(LPPDEVICE,BYTE);
typedef short (FAR PASCAL *TDOCUMENTPAGERESET)(LPPDEVICE);
typedef short (FAR PASCAL *TSETSCREENFREQUENCY)(LPPDEVICE,short);
typedef short (FAR PASCAL *TSETSCREENANGLE)(LPPDEVICE,short);

typedef short (FAR PASCAL *TSETGDIXFORM)(LPPDEVICE);
typedef short (FAR PASCAL *TDOWNLOADHEADER)(LPPDEVICE,WORD);

//              ----   Escapes ---------

typedef short (FAR PASCAL *TRAWPRINTERSTART)(LPPDEVICE);
typedef short (FAR PASCAL *TRAWPRINTERDATA) (LPPDEVICE,LP , WORD);
typedef short (FAR PASCAL *TRAWPRINTEREND)  (LPPDEVICE);
typedef short (FAR PASCAL *TPAGEORIENTATION)(LPPDEVICE,WORD);
typedef short (FAR PASCAL *TPAPERSOURCE)(LPPDEVICE,LPSTR);
typedef short (FAR PASCAL *TPAPERSIZE)(LPPDEVICE,LPSTR);
typedef short (FAR PASCAL *TMSRECTHACK)(LPPDEVICE,BOOL,LPRECT,LPRECT);
typedef void  (FAR PASCAL *TCLIPPATH)(LPPDEVICE,WORD,WORD);
typedef void  (FAR PASCAL *TENDPATH)(LPPDEVICE, LPPATHINFO, LPDRAWMODE);
typedef void  (FAR PASCAL *TCTMSAVERESTORE)(LPPDEVICE, WORD);
typedef void  (FAR PASCAL *TCTMTRANSFORM)(LPPDEVICE, LPDWORD);
typedef void  (FAR PASCAL *TCLIPBOX)(LPPDEVICE, LPRECT);

typedef struct _TFUNCTIONPTRS
{
   TPEN              rTPen             ;   // Sets the state for entire Pen
   TPENCAP           rTPenCap          ;   // Sets pen state for endcap
   TPENFGCOLOR       rTPenFGColor      ;   // Sets pen FGcolor for styled lines
   TPENBGCOLOR       rTPenBGColor      ;   // Sets pen BBcolor for styled lines
   TPENJOIN          rTPenJoin         ;   // Sets pen state for penjoin
   TPENMITERLIMIT    rTPenMiterLimit   ;   // Sets pen state for the miterlimit
   TPENSTYLE         rTPenStyle        ;   // Sets pen state style - solid or dashed
   TPENWIDTH         rTPenWidth        ;   // Sets pen state for pen line width
   
   TBRUSHBGCOLOR     rTBrushBGColor    ;   // Sets brush BGColor for patterns
   TBRUSHFGCOLOR     rTBrushFGColor    ;   // Sets brush FGColor for patterns
   TBRUSHHATCH       rTBrushHatch      ;   // Sets brush hatch type
   TBRUSHPATTERN     rTBrushPattern    ;   // Sets brush pattern
   TBRUSHSTYLE       rTBrushStyle      ;   // Sets brush style - solid,hatched,patterned
   
   TARC              rTArc             ;   // Outputs PostScript for an arc
   TCHORD            rTChord           ;   // Outputs PostScript for a chord
   TELLIPSE          rTEllipse         ;   // Outputs PostScript for an ellipse
   TCIRCLE           rTCircle          ;   // Outputs PostScript for a circle
   TLINE             rTLine            ;   // Outputs PostScript for a line
   TPIE              rTPie             ;   // Outputs PostScript for a pie wedge
   TPOLYGON          rTPolygon         ;   // Outputs PostScript for a polygon
   TPOLYLINE         rTPolyLine        ;   // Outputs PostScript for a polyline
   TPOLYBEZIER       rTPolyBezier      ;   // Outputs PostScript for a polyBezier
   TRECTANGLE        rTRectangle       ;   // Outputs PostScript for a rectangle
   TROUNDRECTANGLE   rTRoundRectangle  ;   // Outputs PostScript for a roundrect
   TSCANLINE         rTScanLine        ;   // Outputs PostScript for a raster line
   TSCANLINEBEGIN    rTScanLineBegin   ;   // Outputs PostScript for a start raster
   TSCANLINEEND      rTScanLineEnd     ;   // Outputs PostScript for an end raster
   TPOLYMODE         rTPolyMode        ;   // Sets PolyMode=BEZIER,POLYSEGMENT,POLYLINE
   
   TBMOPAQUEBOX      rTBMOpaqueBox     ;   // Outputs PostScript for a WHITE/BLACK box
   TOPAQUEBOX        rTOpaqueBox       ;   // Outputs PostScript for a WHITE/BLACK box
   TBITMAPHEADER     rTBitmapHeader    ;   // Outputs PostScript for bitmap prolog
   TBITMAPDATA       rTBitmapData      ;   // Outputs PostScript for bitmap data
   TBITMAPOPERATOR   rTBitmapOperator  ;   // Outputs PostScript for bitmap Operator
   TDIBDATABITS      rTDIBDataBits     ;   // Outputs PostScript for DIB data
   TGRAYTABLE        rTGrayTable       ;   // Outputs PostScript data for DIB grayscales
   TDIBHEADER        rTDIBHeader       ;   // Outputs PostScript for DIB header
   TCOLORTABLE       rTColorTable      ;   // Outputs PostScript for DIB color table
   TDIBOPERATOR      rTDIBOperator     ;   // Outputs PostScript for DIB operator
   TICMCOLOR         rTICMColor        ;   // Outputs PostScript for Device Indep. Color
// L3_MASK
   TDIBCLIPRGNS      rTDIBClipRgns     ;   // Outputs PostScript for clip regions

   TDRIVERDATA       rTDriverData      ;   // Copies Control state to Translation state
   TDOCUMENTPAGEBEGIN rTDocumentPageBegin; // Marks the beginning of a page
   TDOCUMENTPAGEEND  rTDocumentPageEnd ;   // Marks the ending of a page
   TDOCUMENTABORT    rTDocumentAbort   ;   //
   TDOCUMENTEND      rTDocumentEnd     ;   //
   TDOCUMENTFLUSH    rTDocumentFlush   ;   //
   TDOCUMENTBEGIN    rTDocumentBegin   ;   //
   TCLIPRECT         rTClipRect        ;   //
   TCLIPEND          rTClipEnd         ;   //
   TJOBTYPE          rTJobType         ;   //
   TJOBTITLE         rTJobTitle        ;   //
   TJOBCOPIES        rTJobCopies       ;   //
   TJOBDUPLEX        rTJobDuplex       ;   //
   TBACKGROUNDMODE   rTBackgroundMode  ;   //
   TCOLORBG          rTColorBG         ;   //
   TARCDIRECTION     rTArcDirection    ;   // Sets state for direction = CW or CCW
   
   TRAWPRINTERSTART  rTRawPrinterStart ;   //
   TRAWPRINTERDATA   rTRawPrinterData  ;   //
   TRAWPRINTEREND    rTRawPrinterEnd   ;   //
   
   TTEXTBEGIN        rTTextBegin       ;   // Setup for outputting text
   TTEXTRUN          rTTextRun         ;   // Outputs a run of characters
   TTEXTEND          rTTextEnd         ;   // Finishes a series of text runs
   TSOFTFONTLOAD     rTSoftFontLoad    ;   // Downloads a softfont to the printer
#ifdef ADD_EURO
   TDEVICEFONTLOAD   rTDeviceFontLoad  ;   // Downloads Add character Euro to device font.
#endif
#ifdef ADOBE_DRIVER
   TTEXTRUNWIDE      rTTextRunWide     ;   // Outputs a run of characters as 2 bytes/char.
#endif
   
   TPAGEORIENTATION  rTPageOrientation ;   // Sets the page orientation.
   TPAPERSOURCE      rTPaperSource ;       // Sets the paper source, eg. upper tray
   TPAPERSIZE        rTPaperSize ;         // Sets the paper size, eg. legal.
   TMSRECTHACK       rTMSRectHack ;        // Emits MS compatibility ops
   
   TCLIPPATH           rTClipPath;         // Saves/restores/alters clip path
   TENDPATH            rTEndPath;          // Strokes/Fills current path
   TCTMSAVERESTORE     rTCTMSaveRestore;      
   TCTMTRANSFORM       rTCTMTransform;
   TDOCUMENTPAGERESET  rTDocumentPageReset;  // Reinitializes page after resetDC
   TSETSCREENFREQUENCY rTSetScreenFrequency; // MGX set screen frequency
   TSETSCREENANGLE     rTSetScreenAngle;     // MGX set screen angle
   TCLIPBOX            rTClipBox;
   TSETGDIXFORM        rTSetGDIXForm;
   TDOWNLOADHEADER     rTDownLoadHeader;
} TFUNCTIONPTRS, FAR * LPTFUNCTIONPTRS;

VOID  FAR PASCAL FlavorOfPostScript(LPPDEVICE lppd, short Flavor);
short FAR PASCAL AssignDLLTokens(LPPDEVICE lppd, HANDLE hTokenDLL);
