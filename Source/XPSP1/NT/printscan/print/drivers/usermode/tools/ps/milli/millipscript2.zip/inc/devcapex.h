/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1994 Adobe Systems, Inc. All rights reserved.               */
/*                                                                           */
/* Module Name: DEVCAPEX.H                                                   */
/*                                                                           */
/* Description: This module contains the defines and function prototypes     */
/*   for DeviceCapabilityEx.                                                 */
/*                                                                           */
/*****************************************************************************/

#define   DCEX_GETDOCSTICKYSIZE                1
#define   DCEX_GETDWORD                        2
#define   DCEX_GETKEYWORDID                    3
#define   DCEX_GETKEYWORDNUMOPTIONS            4
#define   DCEX_GETKEYWORDOPTIONDWORD           5
#define   DCEX_GETKEYWORDOPTIONPS              6
#define   DCEX_GETKEYWORDOPTIONSTRING          7
#define   DCEX_GETKEYWORDOPTIONTRANSLATION     8
#define   DCEX_GETKEYWORDSTRING                9
#define   DCEX_GETKEYWORDTRANSLATION           10
#define   DCEX_GETSTRING                       11
#define   DCEX_ISKEYWORDOPTIONCONSTRAINED      12
#define   DCEX_SETDWORD                        13
#define   DCEX_SETFILTER                       14
#define   DCEX_SETSTRING                       15

DWORD _loadds FAR PASCAL DeviceCapabilitiesEx(LPSTR lpzFriendly,
                                     WORD   wCapability,  LPDEVMODE lpDevMode,
                                     int    iDataItemID,  LPSTR lpString,
                                     BOOL   bFromWPX,     int iIDOption,
                                     WORD far * lpSize,   DWORD dwData,
                                     LPSTR  lpModuleName);
typedef DWORD (_loadds FAR PASCAL *LPDEVICECAPABILITIESEX)(LPSTR lpzFriendly,
                                     WORD   wCapability,  LPDEVMODE lpDevMode,
                                     int    iDataItemID,  LPSTR lpString,
                                     BOOL   bFromWPX,     int iIDOption,
                                     WORD far * lpSize,   DWORD dwData,
                                     LPSTR  lpModuleName);



