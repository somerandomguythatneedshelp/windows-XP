/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: DLGS2.H                                                */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

int AdvancePastViableKeywords(LPPDEVICE lppd, LPKEYWORDLISTREC PPDList,
                              int iViableKeywordIndex);
