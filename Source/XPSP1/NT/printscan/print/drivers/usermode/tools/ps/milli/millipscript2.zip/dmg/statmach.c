/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: STATMACH.C                                                   */
/*                                                                           */
/* Description: This module contains the function ...                        */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_STATESEG)


/* Local functions */



/*****************************************************************************
* 
*  DRIVER CONTROL-SIDE STATE
* 
*  The driver's control side has a number of state variables.  They
*  are represented by a state machine plus a few independent state 
*  variables.  This module provides functions to query and set the
*  state machine and other variables.
* 
*  Calls to the driver's public entry points can cause tokens to be
*  generated.  They may also trigger state changes.  The state changes
*  may in turn cause tokens to be generated, as side effects.
*  One example of this is the interaction between the PASSTHROUGH
*  escape and other public entry points which draw on the page.
*  The tokens which correspond to calls to the PASSTHROUGH escape
*  are preceded and followed by tokens which initiate and terminate
*  the sequence.  However, there is no GDI call which explicitly 
*  terminates a sequence of PASSTHROUGH escapes -- any public entry
*  point which makes marks on the page terminates the sequence.
*  So, the state machine emits the initiating and terminating tokens
*  as a side effect of state transitions.
* 
*  This is a diagram of the state machine:
* 
*  +----------------+
*  | INITIAL        |
*  +----------------+
*    |     Enable()
*    |     Side-effects: none (done by Enable)
*    v
*  +----------------+
*  | ENABLED        |
*  +----------------+
*   |   |     Escape(StartDoc)
*   |   |     Side-effects: none (done by StartDoc)
*   |   |     However, could include:
*   |   |       StartTranslation
*   |   |       CDriverData
*   |   |       CDocumentBegin
*   |Disable()    
*   |Side-effects:        
*   |        None         
*   |   |
*   |   v  
*   | +----------------+   
*   | |                |
*   | | JOB_STARTED    |
*   | |                |  Any imaging operation   
*   | +----------------+  Side-effects:           Escape(PassThrough)
*   |         |           Page size/orient info?  Side-effects:
*   |         \           CPageBegin              CRawPrinterStart
*   |          \-------\ 
*   |                   \     +----------------+
*   | +----------------+ \--->|                |      +----------------+
*   | |                |----->|                |----->|                |
*   | | EMPTY_PAGE     |      | MARKED_PAGE    |      | RAW_DATA       |
*   | |                |<-----|                |<-----|                |
*   | +----------------+      +----------------+      +----------------+
*   |   |
*   |   |                 Escape(NewFrame)        Anything but PassThrough
*   |   |                 CDocumentPage           CRawPrinterEnd
*   |   |
*   |   |  Escape(End/AbortDoc)
*   |   |  Side-effects:
*   |   |  CColorBG ?
*   |   v
*   | +----------------+
*   | | JOB_DONE       |
*   | +----------------+
*   |   |
*   |   |  Escape(End/AbortDoc)
*   |   |  Side-effects:  EndTranslation
*   v   v
*  +----------------+
*  | ENDED          |
*  +----------------+
*    |  
*    |  Disable()
*    |  Side-effects: none (done by Disable)
*    v
*  +----------------+
*  | TERMINAL       |
*  +----------------+
*  
*  
*  Notes: 
* 
*  1. The states INITIAL and TERMINAL are a bit silly, really.  They
*  are present only so that we can recognise calls to any entry point 
*  while in these states as an error.  However, the state is stored in 
*  a PDEVICE struct.  Before Enable() and after Disable(), there is no
*  PDEVICE struct allocated, so there is nowhere for the state information
*  to exist!  An app could try to call an entry point under these 
*  circumstances, but it would fail -- they would have to pass in an 
*  LPPDEVICE which is NULL or bogus, and in either case we would fail
*  pretty hopelessly.
*  
*  2. The state JOB_STARTED is almost completely equivalent to EMPTY_PAGE.
*  It represents a document with no pages yet imaged.  GDI does not 
*  allow a 0-page print job. If you attempt to print a blank page from
*  Write, it sends escape StartDoc, then EndDoc, without any imaging 
*  or NewFrame calls; but a blank page is expected to emerge.
* 
*  3. The transition from ENABLED to ENDED occurs only when 
*  Enable() has opened an information context instead of a full-blown
*  device context (for printing).  We could add another ENABLED state
*  to represent this.  Such a state would have only a transition to 
*  ENDED, and no imaging calls would be permitted.  Since our imple-
*  mentation currently does exactly the same thing for information-only
*  and full-blown device contexts, we have not bothered with this check.
* 
*****************************************************************************/
/******************************************************************************
*                               fDoSideEffectsLppdSt2
*  Purpose:
*       This routine is used to implement the side effects of moving the
*       state machine from one state to an adjacent state.  This is the
*       only part of the state machine code which emits tokens.
*
*  Parameters:
*       LPPDEVICE lppd   -- pointer to PDEVICE associated with current device context
*       ST        stFrom -- previous state of machine
*       ST        stTo   -- desired state (must be adjacent to stTo).
*
*  Returns: BOOL
*       TRUE if side effects were successful.
*
******************************************************************************/
BOOL NEAR PASCAL fDoSideEffectsLppdSt2( LPPDEVICE lppd, ST stFrom, ST stTo )
{
   BOOL fRC = TRUE;   // Return code

   // This routine is currently implemented as a switch statement,
   // since there is usually only one transition from a given state.
   // There are only two states with two transitions from them.
   
   switch (stFrom)
   {
      case ST_INITIAL:
         /* side effects for INITIAL to ENABLED: none */
         break;
      
      case ST_ENABLED:
         /* side effects for ENABLED to JOB_STARTED: none */
         /* side effects for ENABLED to ENDED: none */
         lppd->job.bfCopyCountSent = FALSE;
         break;
      
      case ST_JOB_STARTED:
         /* Side effects for JOB_STARTED to MARKED_PAGE: */
         
         // This is the same as EMPTY_PAGE to MARKED_PAGE. 
         if (stTo == ST_MARKED_PAGE)
            CDocumentPageBegin( lppd );
         break;
      
      case ST_EMPTY_PAGE:
         if (stTo == ST_MARKED_PAGE)
         {
            /* side effects for EMPTY_PAGE to MARKED_PAGE: */
            CDocumentPageBegin( lppd );
         }
         break;
      
      case ST_MARKED_PAGE:
         // bitmap maybe buffered for output
         // check if this state change signals an end of
         // a buffered bitmap that need to be taken care of
         // Check for bitmap existence before calling function
         // so that DIBSEG doesn't get loaded unnecessarily.
         if (lppd->GlobalBuffer.hBitmapBf && lppd->GlobalBuffer.lpBitmapBf)
         {
             HandleBufferedBitmap((LP)lppd);    
         }
         if (stTo == ST_EMPTY_PAGE)
         {
            /* side effects for MARKED_PAGE to EMPTY_PAGE */
            CDocumentPageEnd( lppd );
         }
         else
         {
            /* side effects for MARKED_PAGE to RAW_DATA */
            CRawPrinterStart( lppd );
         }
         break;
      
      case ST_RAW_DATA:
         /* side effects for RAW_DATA to MARKED_PAGE */
         SetDoMSRectHackLppdF( lppd, FALSE ); // Turn off MS Rect hack
         CRawPrinterEnd( lppd );
         break;
      
      case ST_JOB_DONE:
         /* side effects for JOB_DONE to ENDED */
         break;
      
      case ST_ENDED:
         /* side effects for ENDED to TERMINAL: none */
         break;
         
      case ST_TERMINAL:
         // ST_TERMINAL is the last state.  There can't be any 
         // transitions *from* it.
      case ST_NULL:
         // ST_NULL is just for administration.  It has no transitions.
      default:
         // There had better not be any other states!
         fRC = FALSE;
         break;
      
   } // switch (stFrom)
   
   return( fRC ); 
   
} // END fDoSideEffectsLppdSt2




/*****************************************************************************
*                               fChangeStateLppdSt
*  Purpose:
*       Performs the state transitions necessary to move form the current
*       state to the given state.  Performs side effects as state transitions
*       happen.
*
*  Parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE structure associated with current
*                         device context.
*       ST        stTo -- state to which to move the state machine.
*
*  Returns: BOOL
*       TRUE  -- if the state transition was successful.  
*       FALSE -- if not.
* 
*  Note:
*       One reason for failure is that the desired state is not reachable
*       from the current state.  In that case, the machine will be left
*       at the original state or at some intermediate state.
*
*****************************************************************************/
BOOL FAR PASCAL fChangeStateLppdSt(LPPDEVICE lppd, ST stTo)
{
   BOOL fRC;   // Return code
   ST stFrom;  // place to hold the current state.
   ST stTemp;  // Next state to move to.
   
   // State machine routing table.
   // For any transition from one state to another, this table gives the
   // state adjacent to the current one in the direction of the destination.
   // If there is no route from the current state to the destination, this
   // table contains the current state ID, as an error flag.
   
   static ST rgrgstNext[ST_MAX][ST_MAX] = 
   {
      /*****************************************************************************
      * from \ to:   ST_Null         ST_Initial      ST_Enabled      ST_Job_Started
      *              ST_Empty_Page   ST_Marked_Page  ST_Raw_Data     ST_Job_Done
      *              ST_Ended        ST_Terminal 
      *****************************************************************************/
      
      /* Null    */ { ST_NULL,        ST_NULL,        ST_NULL,        ST_NULL,
                      ST_NULL,        ST_NULL,        ST_NULL,        ST_NULL,
                      ST_NULL,        ST_NULL
                    },
      /* Initial */ { ST_NULL,        ST_INITIAL,     ST_ENABLED,     ST_ENABLED,
                      ST_ENABLED,     ST_ENABLED,     ST_ENABLED,     ST_ENABLED,
                      ST_ENABLED,     ST_ENABLED
                    },
      /* Enabled */ { ST_NULL,        ST_NULL,        ST_ENABLED,     ST_JOB_STARTED,
                      ST_JOB_STARTED, ST_JOB_STARTED, ST_JOB_STARTED, ST_JOB_STARTED,
                      ST_ENDED,       ST_ENDED
                    },
      /* Job_Strt*/ { ST_NULL,        ST_NULL,        ST_NULL,        ST_JOB_STARTED,
                      ST_MARKED_PAGE, ST_MARKED_PAGE, ST_MARKED_PAGE, ST_JOB_DONE, 
                      ST_MARKED_PAGE, ST_MARKED_PAGE
                    },
      /* Em_Page */ { ST_NULL,        ST_NULL,        ST_NULL,        ST_NULL,
                      ST_EMPTY_PAGE,  ST_MARKED_PAGE, ST_MARKED_PAGE, ST_JOB_DONE,
                      ST_JOB_DONE,    ST_JOB_DONE
                    },
      /* Mkd_Pag */ { ST_NULL,        ST_NULL,        ST_NULL,        ST_NULL,
                      ST_EMPTY_PAGE,  ST_MARKED_PAGE, ST_RAW_DATA,    ST_EMPTY_PAGE,  
                      ST_EMPTY_PAGE,  ST_EMPTY_PAGE
                    },
      /* Raw_Data*/ { ST_NULL,        ST_NULL,        ST_NULL,        ST_NULL,
                      ST_MARKED_PAGE, ST_MARKED_PAGE, ST_RAW_DATA,    ST_MARKED_PAGE, 
                      ST_MARKED_PAGE, ST_MARKED_PAGE
                    },
      /* Job_Done*/ { ST_NULL,        ST_NULL,        ST_ENABLED,     ST_NULL,
                      ST_NULL,        ST_NULL,        ST_NULL,        ST_JOB_DONE,
                      ST_ENDED,       ST_ENDED
                    },
      /* Ended   */ { ST_NULL,        ST_NULL,        ST_NULL,        ST_NULL,
                      ST_NULL,        ST_NULL,        ST_NULL,        ST_NULL,
                      ST_ENDED,       ST_TERMINAL
                    },
      /* Terminal*/ { ST_NULL,        ST_NULL,        ST_NULL,        ST_NULL,
                      ST_NULL,        ST_NULL,        ST_NULL,        ST_NULL,
                      ST_NULL,        ST_TERMINAL
                    }
   };
   
   
   stFrom = lppd->stCurrent;
   fRC = TRUE;
   
   while (fRC && (stTo != stFrom))
   {
      stTemp = rgrgstNext[stFrom][stTo];
      
      if (stTemp == ST_NULL)
      {
         // ST_NULL means there is no path from stFrom to stTo.  
         // Return an error.
         
         fRC = FALSE;
      }
      else
      {  // i.e. (stTemp != ST_NULL)
         // Assert(fRC == TRUE).  It has to be true to get into the
         // loop, and the only place it could have been set FALSE so
         // far was in the 'then' branch of this 'if' statement.
         // Therefore, we don't need to have 'fRC &&' in the next stmt.
         
         fRC = fDoSideEffectsLppdSt2( lppd, stFrom, stTemp );
         lppd->stCurrent = stTemp;
         stFrom = stTemp;
      }
   } // while
   
   return( fRC );
   
} // END fChangeStateLppdSt


/*****************************************************************************
*                               fInDocLppd
*  Purpose:
*       Returns TRUE if the state machine is currently in one of the states
*       between Escapes STARTDOC and ENDDOC.  Functionally equivalent to:
*
*       (stCurrentLppd(lppd) == ST_EMPTY_PAGE) || ....
*
*       Clients may prefer to use this routine because it provides a degree 
*       of insulation from changes in the state structure, and because it 
*       can use private knowledge of the implementation of the state machine 
*       to be more efficient.
*
*  Parameters:
*       LPPDEVICE lppd   - pointer to PDEVICE associated with current device context
*
*  Returns: BOOL
*       TRUE if the state machine is in a state which occurs after
*       Escape STARTDOC but before Escape ENDDOC.
*
*****************************************************************************/
BOOL FAR PASCAL fInDocLppd( LPPDEVICE lppd )
{
   return((ST_JOB_STARTED <= lppd->stCurrent) 
           && (lppd->stCurrent <= ST_RAW_DATA));

} // END fInDocLppd


/******************************************************************************
*                               fEnabledLppd
*  Purpose:
*       Returns TRUE if the state machine is currently in one of the states
*       between Enable() and Disable().  Functionally equivalent to:
*
*       (stCurrentLppd(lppd) == ST_ENABLED) || ....
*
*       Clients may prefer to use this routine because it provides a degree 
*       of insulation from changes in the state structure, and because it 
*       can use private knowledge of the implementation of the state machine 
*       to be more efficient.
*
*  Parameters:
*       LPPDEVICE lppd -- pointer to PDEVICE associated with current device context
*
*  Returns: BOOL
*       TRUE if the state machine is in a state which occurs after
*       Enable() but before Disable().
*
******************************************************************************/
BOOL FAR PASCAL fEnabledLppd( LPPDEVICE lppd )
{
   return((ST_ENABLED <= lppd->stCurrent) 
           && (lppd->stCurrent <= ST_ENDED));

} // END fEnableLppd


