/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: UNCONCAT.H                                             */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

int UnConcat(LPSTR lpFontsMfm, LPSTR lpDestPath, LPSTR lpIoBuff);
