/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: XFILE.H                                                */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

#define XTYPE_disk 0
#define XTYPE_memory 1


// function prototypes for xfile stuff
// xfiles are disk or memory based files

FLAG FAR PASCAL XInit(LPXFILE lpxQFile,BYTE bType,LPSTR lpzFile);

LONG FAR PASCAL XMaxSize(LPXFILE lpXFile,LONG lMax);
FLAG FAR PASCAL XFEmpty(LPXFILE lpXFile);

SHORT FAR PASCAL XFCreate(LPXFILE,SHORT);
SHORT FAR PASCAL XFOpen(LPXFILE,SHORT);
SHORT FAR PASCAL XFClose(LPXFILE);
FLAG FAR PASCAL XFDelete(LPXFILE);
LONG FAR PASCAL XFSeek(LPXFILE,LONG,SHORT);
#define XFCurPos(x) XFSeek(x,0L,1)
#define XFSkip(x,y) XFSeek(x,(LONG)(y),1)
#define XFHome(x) XFSeek(x,0L,0)
#define XFEnd(x) XFSeek(x,0L,2)
SHORT FAR PASCAL XFWrite(LPXFILE,LP,SHORT);
SHORT FAR PASCAL XFWriteMultiple(LPXFILE,LP,SHORT,SHORT);
DWORD FAR PASCAL XFWriteMega(LPXFILE,LP,DWORD,DWORD);
FLAG FAR PASCAL XFWriteChar(LPXFILE,CHAR);
FLAG FAR PASCAL XFWriteShort(LPXFILE,SHORT);
FLAG FAR PASCAL XFWriteLong(LPXFILE,LONG);
SHORT FAR PASCAL XFRead(LPXFILE,LP,SHORT);
SHORT FAR PASCAL XFReadMultiple(LPXFILE,LP,SHORT,SHORT);
DWORD FAR PASCAL XFReadMega(LPXFILE,LP,DWORD,DWORD);
CHAR FAR PASCAL XFReadChar(LPXFILE);
SHORT FAR PASCAL XFReadShort(LPXFILE);
LONG FAR PASCAL XFReadLong(LPXFILE);

SHORT FAR PASCAL XMCreate(LPXFILE,SHORT);
SHORT FAR PASCAL XMOpen(LPXFILE,SHORT);
SHORT FAR PASCAL XMClose(LPXFILE);
FLAG FAR PASCAL XMDelete(LPXFILE);
LONG FAR PASCAL XMSeek(LPXFILE,LONG,SHORT);
#define XMCurPos(x) XMSeek(x,0L,1)
#define XMSkip(x,y) XMSeek(x,(LONG)(y),1)
#define XMHome(x) XMSeek(x,0L,0)
#define XMEnd(x) XMSeek(x,0L,2)
SHORT FAR PASCAL XMWrite(LPXFILE,LP,SHORT);
SHORT FAR PASCAL XMWriteMultiple(LPXFILE,LP,SHORT,SHORT);
DWORD FAR PASCAL XMWriteMega(LPXFILE,LP,DWORD,DWORD);
FLAG FAR PASCAL XMWriteChar(LPXFILE,CHAR);
FLAG FAR PASCAL XMWriteShort(LPXFILE,SHORT);
FLAG FAR PASCAL XMWriteLong(LPXFILE,LONG);
SHORT FAR PASCAL XMRead(LPXFILE,LP,SHORT);
SHORT FAR PASCAL XMReadMultiple(LPXFILE,LP,SHORT,SHORT);
DWORD FAR PASCAL XMReadMega(LPXFILE,LP,DWORD,DWORD);
CHAR FAR PASCAL XMReadChar(LPXFILE);
SHORT FAR PASCAL XMReadShort(LPXFILE);
LONG FAR PASCAL XMReadLong(LPXFILE);

SHORT FAR PASCAL XMNullCreate(LPXFILE lpXFile,SHORT sMode);
SHORT FAR PASCAL XMNullOpen(LPXFILE lpXFile,SHORT sMode);
SHORT FAR PASCAL XMNullClose(LPXFILE lpXFile);
SHORT FAR PASCAL XMNullDelete(LPXFILE lpXFile);
