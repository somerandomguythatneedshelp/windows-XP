/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DLGSFUNC.H                                                   */
/*                                                                           */
/* Description: This module contains ...                                     */
/*                                                                           */
/*****************************************************************************/

//---------------------------------------------------------------------------
// Defines
//---------------------------------------------------------------------------

#define MAX_CAPTION_LEN 70
#define MAX_FILEPATH_LEN 128

#define ID_PRNTR_SIZE   100                  // size of Driver Name + Nickname

//---------------------------------------------------------------------------
// DLGS.C Function Prototypes.  Now in one of DEVMDLGS.C, DEVMDLG2.C, CUSTDLG.C
//  OPT1DLG.C, OPT2DLG.C
//---------------------------------------------------------------------------

VOID NEAR DIALOGSSEG PASCAL ShowPaperOrientation(HWND hparentwndw,int orientation);
VOID NEAR DIALOGSSEG PASCAL Show_PPD_DB(HWND hdlg, int first_keyword_index) ;
VOID NEAR DIALOGSSEG PASCAL FmtDevicePort(LPPDEVICE lppd, LPSTR s, WORD max_slen) ;
int  NEAR DIALOGSSEG PASCAL GetNewPrinter(LPPDEVICE, HANDLE, LPPSEXTDEVMODE);
VOID NEAR DIALOGSSEG PASCAL ShowPIonScreen1(LPPDEVICE, HANDLE, LPPSEXTDEVMODE, BOOL);
BOOL NEAR DIALOGSSEG PASCAL CheckScreen1(LPPDEVICE, HANDLE, LPPSEXTDEVMODE);
BOOL NEAR DIALOGSSEG PASCAL CheckOptions1(LPPDEVICE, HANDLE, LPPSEXTDEVMODE);
void NEAR DIALOGSSEG PASCAL DisplayCustomPageSize(HWND hdlg, int units, double xsize,
                                       double ysize);
void NEAR DIALOGSSEG PASCAL RetrieveCustomPageSize(HWND hdlg, int units, double FAR * xsize,
                                        double FAR * ysize);
short NEAR DIALOGSSEG PASCAL BuildCBPaperSrcOptList(LPDRIVERINFO lpDrvInfo, HANDLE hdlg,
                                        WORD KeywordIndex, int ctrl_id) ;

VOID NEAR DIALOGSSEG PASCAL FmtDevicePortNick(LPPDEVICE lppd /* LPPSEXTDEVMODE lpPSExtDevmode */, 
                                 LPSTR s, WORD max_slen) ;

BOOL FAR PASCAL   CenterPopup( HWND, HWND );

BOOL NEAR DIALOGSSEG PASCAL   CallHelpFile(HWND,WORD,LPDRIVERINFO);

                /* These were added to ADOBEPS.DEF Exports */
BOOL NEAR DIALOGSSEG PASCAL fnJobControlDialog(HWND hWnd, WORD wMsg,
                                     WORD wParam, LONG lParam);
BOOL NEAR DIALOGSSEG PASCAL fnHeaderDialog(HWND hWnd, WORD wMsg,
                                 WORD wParam, LONG lParam);
BOOL NEAR DIALOGSSEG PASCAL fnCustomPaperDialog(HWND hWnd, WORD wMsg,
                                      WORD wParam, LONG lParam);

        /***** Callbacks *****/

typedef BOOL _loadds FAR PASCAL DLG_CALLBACK(HWND hdlg, unsigned imsg, 
                                             WORD wparam,  LONG lparam) ;

DLG_CALLBACK fnDevmodeDlg ;
DLG_CALLBACK fnOptions1Dlg ;
DLG_CALLBACK fnNoNicknameDlg ;
DLG_CALLBACK fnPickNickDlg ;
DLG_CALLBACK fnNoPrinterDlg ;
DLG_CALLBACK fnAboutDlg ;

BOOL NEAR DIALOGSSEG PASCAL fnLookForPrinter(LPSTR refName, LPSTR found_flg) ;
BOOL NEAR DIALOGSSEG PASCAL fnListPrinter(LPSTR refName, LPSTR hdlg_ptr) ;

//---------------------------------------------------------------------------
// DLGS2.C Function Prototypes
//---------------------------------------------------------------------------

BOOL NEAR DIALOGSSEG PASCAL fnOptions2Dlg(HWND hdlg, unsigned imsg,
                              WORD wparam, LONG lparam) ;

int PASCAL NumPublicPPDItems(LPPDEVICE lppd, LPPSEXTDEVMODE lpPSExtDevmode) ;

VOID NEAR DIALOGSSEG PASCAL BuildCBOptList(LPDRIVERINFO lpDrvInfo, HANDLE hdlg,
                               WORD KeywordIndex, int ctrl_id) ;

VOID NEAR DIALOGSSEG PASCAL BuildLBOptList(LPDRIVERINFO lpDrvInfo, HANDLE hdlg,
                     WORD keyword_index, LPSTR lpReturnOptStr);

BOOL NEAR DIALOGSSEG PASCAL IsDialectDLLPresent(int dialect);

//---------------------------------------------------------------------------
// ADDPRN.C Function Prototypes
//---------------------------------------------------------------------------

DLG_CALLBACK fnAddPrinterDlg ;

VOID NEAR DIALOGSSEG PASCAL ExitAddPrinterDlg(LPPDEVICE lppd, HWND hdlg, int status) ;
VOID NEAR DIALOGSSEG UpdateListBox(LPPDEVICE lppd, HWND hDlg) ;
VOID NEAR DIALOGSSEG ChangeDefExt(LPSTR Ext, LPSTR Name) ;
VOID NEAR DIALOGSSEG SeparateFile(HWND hDlg, LPSTR lpDestPath,
                              LPSTR lpDestFileName,
                              LPSTR lpSrcFileName) ;
VOID NEAR DIALOGSSEG AddExt(LPSTR Name, LPSTR Ext) ;
