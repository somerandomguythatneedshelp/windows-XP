/* CM_VerSion parse.h atm05 1.4 10794.eco sum= 47035 */
/* CM_VerSion parse.h atm04 1.6 04398.eco sum= 65163 */
/*
  parse.h -- interface for parsing font files

Copyright (c) 1989-1992 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of
Adobe Systems Incorporated.  Many of the intellectual and
technical concepts contained herein are proprietary to Adobe,
are protected as trade secrets, and are made available only to
Adobe licensees for their internal use.  Any reproduction or
dissemination of this software is strictly forbidden unless
prior written permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks of
Adobe Systems Incorporated.

Original version: Mike Byron 
Edit History:
Ron Fischer: Thu Mar 4 15:54:54 1992
Paul Haahr: Fri Oct 2 11:10:49 1992
Naoki Hotta: Mon Aug 24 15:19:02 PDT 1992
Naoki Hotta: Wed Mar  4 16:17:56 PST 1992
Craig Rublee: Wed Apr 15 14:26:41 PDT 1992
Paul Haahr: Sun Nov 24 19:31:50 1991
End Edit History.

Revision History
  93/3/4 15:55:55 rfischer
  Integrated v04.010 changes in with CID version.

  92/8/24 15:19:02 hotta
  Added new composite font support.
  New entry point ParseEncoding() for new composite control file and
  for composite font rearrange file.

  92/3/4 16:17:56 hotta
  Added original font support to parse 1 byte katakana characters.
  Changed FontProtection callback to pass 2 parameters: the length and a
  pointer to the data. This was done so that the parser does not need to 
  know the structure of the protect record.

  92/3/3 14:40:05 rublee

  Increased the size of TOKENBUFFER_MIN  from 1024 to 1036 if the COMPOSITE_FONT
  compiler switch is set to true. This is needed to hold the 
  CharOffset data in a derived font. 

  92/2/27 19:31:50 rublee
  Incorporated changes to allow compilation in 16 bit environemnts

  Revision 6.2  91/11/22  11:56:43  rublee
  moved RANDOMACESS definition from parse.c

  Revision 6.1  91/10/07  18:22:42  rublee

End Revision History.
*/


#ifndef	PARSE_H
#define PARSE_H

/*
 * The font parser justs parses.  It doesn't do storage allocation
 * since the strategies for storing font data will vary widely.  The
 * basic task involves filling out a FontDesc data structure (see
 * the interface to the buildch package).  Callbacks are used to
 * read the font file, report back various font information, and to
 * indicate data that is to be shared with other fonts.
 *
 * Most callback procedure return a boolean: a true result indicates that
 * everything is fine and the parsing will continue; false will abort the
 * parse immediately.  Any non-scalar data received via a callback must be
 * copied---it almost certainly will not stick around after the call.
 *
 * RANDOMACCESS means the parser gives back info on where CharStrings
 * and Subroutines are in the font file.  This can be used to retrieve
 * these things without reparsing the entire file.  The CharString
 * and Subroutine procs have three extra args for this:  the GetBytes
 * buffer count of the first char in the data, the offset into that
 * buffer, and the current valye of the key for eexec decryption.  It
 * is the caller's responsibility to figure out how to use this
 * information to best advantage.  It will probably mean keeping some
 * amount of info about each GetByte buffer, etc.
 *
 * COMPOSITE_FONT means the parser will be used with composites fonts.  This
 * version supports several extra public interfaces and callbacks
 * which are discussed below.  [COMPOSITE_FONT parsing is neither documented
 * nor implemented well.  Part of this is because the organization,
 * which seems to work well for PostScript products, is very poor from
 * the perspective of ATM, and part of it is because I am unclear on how
 * all the parseprocs work and what they do.  Paul Haahr, 10 Nov 91.]
 */



/*********************** O P T I O N S ***********************/

#define ORIGINAL_FONT 1 /* Make these definitions match ATM-J Mac */
#define FAST_GETTOKEN 0
#define COPYPROTECT 1

/*
 * COMPOSITE_FONT -- if true, the parser supports the postscript composite font extensions
 */

#ifdef STREAMER_DBCS	/* OEMATM uses the DBCS switch for composite fonts */
#define COMPOSITE_FONT STREAMER_DBCS
#endif

#ifdef KANJI /* MACATM and WINDOWS ATM use the KANJI switch for composite fonts */
#define COMPOSITE_FONT KANJI
#endif

#ifndef	COMPOSITE_FONT
#define	COMPOSITE_FONT	0
#endif

/*
 * RANDOMACCESS -- if true, the callbacks for CharStrings are passed the 
   GetBytes call number, character index, and current eexec decryption key 
   in order that it can seek directly to the appropriate place in the font file.
 */

#ifndef	RANDOMACCESS
#define	RANDOMACCESS	0
#endif

#ifndef STREAMFONT
#define STREAMFONT 1 /* This should be moved somewhere more global... */
#endif

/* Definitions used with STREAMFONT. */
#define SUBR_POSITION		1
#define CHARSTRING_POSITION	2
#define UID_POSITION		3
#define FONTNAME_POSITION	4
#define EEXEC_POSITION		5
#define ENCODING_POSITION	6
#define FULLNAME_POSITION	7
#define PRIVATE_POSITION	8
#define EEXEC_OFF_POSITION	9
#define LENIV_POSITION		10	
#define FONTINFO_POSITION	11	
#define FONT_TYPE_POSITION	12	
#define ATTRIBS_POSITION	13
#define BACKUP_POSITION		20

typedef enum _t_FontSpecialAttribute {
	ST_HYBRID_FONT = 1,
	ST_SYNTHETIC_FONT,
	ST_SPECIAL_PROCSET
} FontSpecialAttribute;


/******************* P A R S E   P R O C S *******************/


typedef struct _t_ParseProcs {

/*
 * interface to operating system services
 */

  /*
   * GetBytes -- read bytes to parse
   *	a false return indicates some sort of I/O problem; early (unexpected)
   *	end of file being the most common.  EOF is indicated by a return of
   *	0 bytes read.
   */
  boolean (*GetBytes) ARGDECL2(char ***, hndl, CardX *, len);

  /*
   * GrowBuff -- grow a growable buffer
   *	This should update the GrowableBuffer structure with the new info.
   *	The pointer to the data may move when this is called, so pointers
   *	into the old data need to be fixed, etc.  If copyflag is true, the
   *	contents of the old buffer are copied into the new buffer.  minMore
   *	should be set low, like to the size of the one additional item that
   *	is needed to keep processing.  Let the caller take care of how to
   *	allocate memory.
   */
  boolean (*GrowBuff) ARGDECL4(GrowableBuffer *, b, Int32, minMore, boolean, copyflag, void *, pClientHook);

/*
 * Encoding procedures
 */

  boolean (*UseStandardEncoding) ARGDECL0();
  boolean (*UseSpecialEncoding) ARGDECL1(IntX, count);
  boolean (*SpecialEncoding) ARGDECL2(IntX, i, char *, charname);

  boolean (*UseStandardAccentEncoding) ARGDECL0();
  boolean (*UseSpecialAccentEncoding) ARGDECL1(IntX, count);
  boolean (*SpecialAccentEncoding) ARGDECL2(IntX, i, char *, charname);

/*
 * Font information procedures
 */

  boolean (*StartEexecSection) ARGDECL0();
  boolean (*FontType) ARGDECL1(Int32, fontType);
  boolean (*FontName) ARGDECL1(char *, name);
  boolean (*BaseMMFontName) ARGDECL1(char *, name);
  boolean (*Notice) ARGDECL1(char *, str);
  boolean (*FullName) ARGDECL1(char *, name);
  boolean (*FamilyName) ARGDECL1(char *, name);
  boolean (*Weight) ARGDECL1(char *, str);
  boolean (*version) ARGDECL1(char *, str);
  boolean (*ItalicAngle) ARGDECL1(Fixed, p);
  boolean (*isFixedPitch) ARGDECL1(boolean, flg);
  boolean (*UnderlinePosition) ARGDECL1(Fixed, p);
  boolean (*UnderlineThickness) ARGDECL1(Fixed, p);
  boolean (*PublicUniqueID) ARGDECL1(Int32, id);

/* OtherSubrs 
   Give the user the othersubr PostScript (as arrays of bytes).  Some
   users may need to dump this with a modified font file so printers can
   process the file.
 */
  boolean (*OtherSubrs) ARGDECL2(Card8 *, s, Card16, count);

#if STREAMFONT
/* FontDataStream
   Streams the font out to the user, only stripping subrs and charstrings.
 */
  boolean (*FontDataStream) ARGDECL2(char, c, Card32, count);

/* KeyPosition
   Returns the position of some key value in the streamed font. 
 */
  boolean (*KeyPosition) ARGDECL2(Card8, type, Card32, count);

  /* Set if the font is a hybrid font */
  boolean (*FontAttribute) ARGDECL1(Card16, type);
#endif /* STREAMFONT */

/*
 * CharStrings
 *	AllocCharStrings is first called with an upper bound on the number
 *	of charstrings.  then CharString is called for each charstring;
 *	if RANDOMACCESS is on, enough information is returned that the
 *	caller can recreate the necessary state to read from the middle of
 *	the file.  ShareCharStrings is called before any calls to indicate
 *	that the CharStrings are identical to those from the named font;
 *	if the caller of ParseFont can get to those outlines, it should
 *	return true and the charstrings will be skipped
 */

  boolean (*AllocCharStrings) ARGDECL1(IntX, count);
#if RANDOMACCESS
  boolean (*CharString) ARGDECL6(CardX, buffNum, CardX, byteNum, Card32, cryptNum,
  				 char *, key, CharDataPtr, val, CardX, len);
#else
  boolean (*CharString) ARGDECL3(char *, key, CharDataPtr, val, CardX, len);
#endif
  boolean (*ShareCharStrings) ARGDECL1(char *, fontname);

/*
 * Subroutines
 *	used similarly to the CharStrings procedures.  if AllocSubroutines
 *	gets called with 0, it means that the number of subroutines is not known
 *	ahead of time.  It should be assumed that the number of subroutines is
 *	at least 200.
 */

  boolean (*AllocSubroutines) ARGDECL1(IntX, count);
  boolean (*Subroutine) ARGDECL3(IntX, index, CharDataPtr, val, CardX, len);
  boolean (*ShareSubroutines) ARGDECL1(char *, fontname);

/*
 * multiple master fonts
 */

  boolean (*WeightVector) ARGDECL2(Fixed *, wv, IntX, wvlen);
  boolean (*ResizeFontDesc) ARGDECL2(FontDesc **, fontdescp, Card32, size);
  boolean (*BlendNumberDesigns) ARGDECL1(CardX, n);
  boolean (*BlendNumberAxes) ARGDECL1(CardX, n);
  boolean (*BlendAxisType) ARGDECL2(CardX, axis, char *, name);
  boolean (*BlendDesignMapping) ARGDECL4(CardX, axis, int, n, Fixed *, from, Fixed *, to);
  boolean (*BlendDesignPositions) ARGDECL2(int, master, Fixed *, dv);
  boolean (*BlendUnderlinePosition) ARGDECL2(int, master, Fixed, x);
  boolean (*BlendUnderlineThickness) ARGDECL2(int, master, Fixed, x);
  boolean (*BlendItalicAngle) ARGDECL2(int, master, Fixed, x);

#if COMPOSITE_FONT
/*
 * COMPOSITE_FONT/composite fonts
 *	TODO: document these
 *
 * procedures that take length arguments can also take -1 to imply
 * an unknown length until the end of the array is seen.  when the
 * call is made with UNKNOWN_LENGTH, the elements will follow, and
 * then an "allocation" call will be made again with the actual
 * length after all the elements have been called.  thus, the
 * /PGFArray field can be filled either with the sequence:
 *
 *	(*procs->AllocPGFArray)(2);
 *	(*procs->PGFArray)(0, "GothicBBB-Medium::JIS83-1");
 *	(*procs->PGFArray)(1, "GothicBBB-Medium::Symbol");
 *
 * or with
 *
 *	(*procs->AllocPGFArray)(UNKNOWN_LENGTH);
 *	(*procs->PGFArray)(0, "GothicBBB-Medium::JIS83-1");
 *	(*procs->PGFArray)(1, "GothicBBB-Medium::Symbol");
 *	(*procs->AllocPGFArray)(2);
 */

#define	UNKNOWN_LENGTH	(-1)

  /* extra encoding support */
  boolean (*UseNamedEncoding) ARGDECL1(char *, name);

  /* renderer/metrics support for COMPOSITE_FONT */
  boolean (*WritingMode) ARGDECL1(Int32, wmode);
  boolean (*CDevProc) ARGDECL1(int, cdev);

  /* composite font features */
  boolean (*OriginalFont) ARGDECL1(char *, name);
  boolean (*FMapType) ARGDECL1(IntX, fmt);
  boolean (*EscChar) ARGDECL1(Int32, escape);
  boolean (*SubsVector) ARGDECL2(IntX, len, CharDataPtr, svec);
  boolean (*AllocFDepVector) ARGDECL1(IntX, len);
  boolean (*FDepVector) ARGDECL2(IntX, i, char *, name);
  boolean (*AllocPGFArray) ARGDECL1(IntX, len);
  boolean (*PGFArray) ARGDECL2(IntX, i, char *, name);
  boolean (*CharOffsets) ARGDECL2(IntX, len, CharDataPtr, cp);
  boolean (*UseNamedCharStrings) ARGDECL1(char *, name);
  boolean (*PrefEnc) ARGDECL1(char *, name);
  boolean (*NumericEncoding) ARGDECL2(IntX, index, IntX, n);

  /* fast composite fonts */
  boolean (*MDID) ARGDECL1(Int32, id);
  boolean (*AllocMDFV) ARGDECL1(IntX, len);
  boolean (*MDFVBegin) ARGDECL4(IntX, i, char *, encoding, char *, charstrings, FCdBBox *, bbox);
  boolean (*MDFVFont) ARGDECL2(IntX, index, char *, name);
  boolean (*MDFVEnd) ARGDECL3(IntX, numfonts, FracMtx *, mtx, IntX, cdevproc);
  boolean (*FDepVector_MDFF) ARGDECL6(IntX, i, char *, name, boolean, flag,
				      IntX, mdfv, IntX, len, CharDataPtr, cp);

  /* primogenital font support */
  boolean (*PGFontID) ARGDECL1(Int32, id);

  /* specifier for alternate rasterizer (eCCRun -> double encryption) */
  boolean (*RunInt) ARGDECL1(char *, key);

#if COPYPROTECT
  boolean (*FontProtection) ARGDECL2(IntX, len, CharDataPtr, cp);
#endif


  /* new composite font support */
  boolean (*GDBytes) ARGDECL1(Int32, n);
  boolean (*FDBytes) ARGDECL1(Int32, n);
  boolean (*CIDCount) ARGDECL1(Int32, n);
  boolean (*CIDMapOffset) ARGDECL1(Int32, n);
  boolean (*CIDFontVersion) ARGDECL1(Int32, n);
  boolean (*Registry) ARGDECL1(char *, name);
  boolean (*Ordering) ARGDECL1(char *, name);
  boolean (*Supplement) ARGDECL1(Int32, n);
  boolean (*FDArrayFontName) ARGDECL1(char *, name);
  boolean (*CIDFDArray) ARGDECL1(Int32, n);
  boolean (*BeginCIDFontDict) ARGDECL2(Int32, i, FontDesc **, fontp);
  boolean (*EndCIDFontDict) ARGDECL1(Int32, i);
  boolean (*CIDStartData) ARGDECL2(CardX, buffNum, CardX, byteNum);
  boolean (*UIDBase) ARGDECL1(Int32, n);
  boolean (*XUID) ARGDECL3(Int32, v1, Int32, v2, Int32, v3);

  /* CID (NCF) specific private dict support */ 

  boolean (*SDBytes) ARGDECL1(Int32, n);
  boolean (*SubrMapOffset) ARGDECL1(Int32, n);
  boolean (*SubrCount) ARGDECL1(Int32, n);


  /* encoding files and rearranged font */
  boolean (*cidrange) ARGDECL5(Card32, srcCodeLo, IntX, srcCodeLoLen,
                               Card32, srcCodeHi, IntX, srcCodeHiLen, Card32, dstGlyphIDLo);
  boolean (*cidchar) ARGDECL3(Card32, srcCode, IntX, srcCodeLen, Card32, dstGlyphID);
  boolean (*notdefchar) ARGDECL3(Card32, srcCode, IntX, srcCodeLen, Card32, dstGlyphID); 
  boolean (*notdefrange) ARGDECL5(Card32, srcCodeLo, IntX, srcCodeLoLen, 
                                  Card32, srcCodeHi, IntX, srcCodeHiLen, Card32, dstGlyphIDLo);
  boolean (*codespacerange) ARGDECL4(Card32, srcCode1, IntX, srcCode1Len, Card32, srcCode2, IntX, srcCode2Len);
  boolean (*rearrangedfont) ARGDECL1(char *, name);
  boolean (*componentfont) ARGDECL2(IntX, i, char *, name);
  boolean (*endcomponentfont) ARGDECL1(IntX, i);
  boolean (*usematrix) ARGDECL2(IntX, i, FixMtx, *m);
  boolean (*usefont) ARGDECL1(Card16, i);
  boolean (*bfrange_code) ARGDECL5(Card32, srcCodeLo, IntX, srcCodeLoLen,
                                   Card32, srcCodeHi, IntX, srcCodeHiLen, Card32, dstCodeLo);
  boolean (*bfrange_name) ARGDECL6(Card32, srcCodeLo, IntX, srcCodeLoLen, 
                                   Card32, srcCodeHi, IntX, srcCodeHiLen, IntX, i, char *, dstChar);
  boolean (*bfchar_code) ARGDECL3(Card32, srcCode, IntX, srcCodeLen, Card32, dstCode);
  boolean (*bfchar_name) ARGDECL3(Card32, srcCode, IntX, srcCodeLen, char *, dstCharName);
  boolean (*UseCMap) ARGDECL1(char *, name);

#endif /* COMPOSITE_FONT */

} ParseFontProcs, *PParseFontProcs;

#if COMPOSITE_FONT
/* The minimum must be long enough to hold the longest token in the font. 
   For composite fonts longets token is the string containing the Character
   offset data. The data is 6 bytes for each character in a row. The longest
   therefore is 6 * 256 = 1536. */
#define TOKENBUFFER_MIN  1536
#else
#define TOKENBUFFER_MIN  1024
#endif
#define	TOKENBUFFER_GROW 1024

#define	MAXBLENDDESIGNMAP 64	/* maximum number of points in the design map */


#if COMPOSITE_FONT

#define	PGFontType	1000

/* types of CDevProc results */
#define	NoCDevProc	0
#define	StdCDevProc	1
#define	UnknownCDevProc	-1

#endif



/******************** I N T E R F A C E S ********************/


/*
 * InitParseTables
 *	call at the dawn of time to initialize internal data structures for
 *	the parser.
 *
 *	can return either PE_NOERR or PE_CANTHAPPEN
 */

extern IntX InitParseTables ARGDECL0();


/*
 * ParseFont
 *	parse a font file.  the caller should have opened the file and
 *	should pass the contents to the ParseFont through the procs->GetBytes
 *	callback routine.
 */

extern IntX ParseFont ARGDECL5(
  FontDesc **, fontdescp,	/* where to store the font data */
  ParseFontProcs *, procs,	/* Callback procs */
  GrowableBuffer *, tokBuffer,	/* Growable buffer to contain a token. */
  GrowableBuffer *, inBuf,	/* input lookaside buffer */
  void *, pClientHook		/* Client's data */
);

#if COMPOSITE_FONT
extern IntX ParseEncoding ARGDECL4(
  ParseFontProcs *, parseprocs, /* callback procs */
  GrowableBuffer *, growbuf,    /* growable buffer to contain a token. */
  GrowableBuffer *, lookaside,  /* input lookaside buffer */
  void *, pClientHook		/* Client's data */
);
#endif

IntX InspectChars  ARGDECL3 (IntX, start, IntX, readNCh, char*, buffer);


/* ParseFont return codes */
#define PE_EXITEARLY	  1     /* StartEexecSection returned false */
#define PE_NOERR	  0	/* No error */
#define PE_READ		 -1	/* I/O problem reading file. Probably EOF. */
#define PE_BIGTOKEN	 -2	/* Token too big */
#define PE_CALLER	 -3	/* Callback proc said abort (except GetBytes) */
#define PE_BADFILE	 -4	/* Found something unexpected in font file */
#define PE_BADFONTTYPE	 -5	/* Font is not type 0 or 1 */
#define PE_BUFFSMALL	 -6	/* Some buffer is too small */
#define PE_CARTBADSYNTH	 -7	/* A bad synthetic cartridge font. */
#define	PE_BADBLEND	 -8	/* an inconsistency in the number of blends */
#define	PE_CANTHAPPEN	 -9	/* assertion failure---internal problem */
#define	PE_BADNUMBER	-10	/* poorly formatted number */
#define PE_BADVERSION	-11	/* CID version information was inconsistent */

#endif	/* PARSE_H */
