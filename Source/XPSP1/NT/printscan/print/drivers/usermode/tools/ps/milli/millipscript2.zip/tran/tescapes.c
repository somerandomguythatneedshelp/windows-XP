//*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TESCAPES.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for  ...                  */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_TESCAPESSEG)

short FAR PASCAL DownloadCompatProcset(LPPDEVICE lppd, short psetnum);

/*****************************************************************************
*                               TJobCopies
*  function:
*       processes a token for the number of copies (sets the number of
*       copies in the Translate side PDEVICE).
*  prototype:
*       short FAR PASCAL TJobCopies(LPPDEVICE lppd, WORD wCopies);
*  paremeters:
*       LPPDEVICE lppd -- pdevice pointer
*       WORD wCopies -- number of copies
*  returns:
*       short RC_ok => success
*****************************************************************************/

short FAR PASCAL TJobCopies(LPPDEVICE lppd, WORD wCopies)
        {
        LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
        lppd->lpPSExtDevmode->dm.dm.dmCopies =  wCopies ;

        PSSendFragment(lppd,PSFRAG_beginsafe);

         (*tempptr->PSSendShort)(lppd,wCopies);
         (*tempptr->PSSendCRLF)(lppd);

         PSSendProc(lppd,PSPROC_copies);
         (*tempptr->PSSendCRLF)(lppd);

         PSSendFragment(lppd,PSFRAG_endsafe);
         (*tempptr->PSSendCRLF)(lppd);

        return(RC_ok);
        }

/*****************************************************************************
*                               TJobDuplex
*  function:
*       processes a token for the duplex type (sets the duplex type
*       in the Translate side PDEVICE).
*  prototype:
*       short FAR PASCAL TJobDuplex(LPPDEVICE lppd, WORD type);
*  paremeters:
*       LPPDEVICE lppd -- pdevice pointer
*       WORD type
*            DMDUP_SIMPLEX || DMDUP_VERTICAL || DMDUP_HORIZONTAL
*  returns:
*       short RC_ok => success
*****************************************************************************/

short FAR PASCAL TJobDuplex(LPPDEVICE lppd, WORD type )
{
      /* We know that the type must be OK to get here so   */
      /* set the PPD database to the requested Duplex type */
      lppd->lpPSExtDevmode->dm.dm.dmDuplex = type ;
      return(RC_ok);
} /* End of TJobDuplex */

/*****************************************************************************
*                               TJobTitle
*  function:
*       processes a token for the job title (sets the title in the
*       Translate side PDEVICE).
*  prototype:
*       short FAR PASCAL TJobTitle(LPPDEVICE lppd, LPSTR szTitle);
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*       LPSTR szTitle -- title string (< 64 bytes including null)
*  returns:
*       short RC_ok => success
*****************************************************************************/

short FAR PASCAL TJobTitle(LPPDEVICE lppd, LPSTR szTitle)
        {
        lstrcpy(lppd->szTitle,szTitle);
        return(RC_ok);
        }

/***********************************************************************
*                       TRawPrinterStart
*  function:
*       Prepares the driver and initiates PassThrough from Applications.
*       Also downloads the Adobe Windows Compatibility ProcSet which mainly has
*       emulations of procs from PSCRIPT that some applications use.
*
*  prototype:
*       short FAR PASCAL TRawPrinterStart(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       short RC_ok => success, RC_fail => failure
************************************************************************/

short FAR PASCAL TRawPrinterStart(LPPDEVICE lppd)
{
   short sRC;
   LPASCIIBINPTRS tempptr;
   BOOL bfBinaryOutput =
      (lppd->lpPSExtDevmode->dm2.iDataOutputFormat != PROTOCOL_ASCII);

   // Fix bug 164116 (1)
   BOOL nodribble = ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED) &&
                     (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS));

   BOOL DownLoadHdr = lppd->lpPSExtDevmode->dm2.fHeader;

   VMRecoverDisable(lppd);
   VMCheck(lppd, VM_PASSTHROUGH, 0);
   VMRecoverEnable(lppd);
   PSSetNoCurrentPoint(lppd);
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
        
   if (lppd->VMDisabledOnPassThru && DoVMTracking(lppd))
   {
       PSSendRestore(lppd);

       // In speed mode, resend mysetup
       if (lppd->lpPSExtDevmode->dm.enumDialect == DIA_SPEED)
       {
           PSSendFragment(lppd, PSFRAG_mysetup);
           PSSendFragment(lppd, PSFRAG_concat);
           (*tempptr->PSSendCRLF)(lppd);
           PSSendNegativeImage(lppd, TRUE);
       }
       VMDisable(lppd);
   }

   sRC = TokenNeedsProcset(lppd, PASST);

   if (sRC == RC_ok) 
   {
    // Fix bug 164116.   SAVE_RESTORE   1/30/97   jjia
    // The current font is changed to Courier in the procset COMPAT.
    // We have to clear current font information saved in host GSTATE 
    // to force the driver to re-select font after passthrough.
    lppd->lpGSStack->lpgGState->currentFontData.FontName[0] = (char)0;
    // Force the driver to re-send color after passthrough.
    lppd->lpGSStack->lpgGState->bColorSpaceChanged = TRUE;

    // terminate calrgb procset if (color_matching == TRUE)
    if (lppd->lpPSExtDevmode->dm.iColorMatchingMethod == COLOR_MATCH_ACROSS_PRINTERS)
    {
        // /Adobe_Win_CalRGB /ProcSet findresource dup /terminate get exec
        PSSendFragment(lppd,PSFRAG_termcalrgb);
        (*tempptr->PSSendCRLF)(lppd);
    }


   PSSendFragment(lppd,PSFRAG_setupcompatmatrix);      
   (*tempptr->PSSendCRLF)(lppd);

   if ((DownLoadHdr == TRUE) || 
   (DIALECT_EPS == lppd->lpPSExtDevmode->dm2.bOutputDialect))
                                                
      {
          // get the value for user selection of speed vs compatiblity
#ifndef ADOBEPS42
        if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
             (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS) &&
              bfBinaryOutput )
          {
#endif
             if (nodribble == FALSE)
             {
                // Adobe_Win_Driver_Incr_L2 dup /suspend get exec
                PSSendFragment(lppd,PSFRAG_suspenddribble_L2);
             }
             else // complete header
             {
                // /Adobe_Win_Driver_L2 /ProcSet findresource dup /suspend get exec
                PSSendFragment(lppd,PSFRAG_suspendprocset_L2);
             }
#ifndef ADOBEPS42
          }
          else    // level 1
          {
             if (nodribble == FALSE)
             {
                // Adobe_Win_Driver_Incr dup /suspend get exec
                PSSendFragment(lppd,PSFRAG_suspenddribble);
             }
             else
             {
                // /Adobe_Win_Driver /ProcSet findresource dup /suspend get exec
                PSSendFragment(lppd,PSFRAG_suspendprocset);
             }
          }
#endif
      }
      else
      {
          // Case 6 -- header had been already down there, initialise it.
          // /Adobe_Win_Driver /ProcSet findresource dup /suspend get exec
          PSSendFragment(lppd,PSFRAG_suspendprocset);
      }
      (*tempptr->PSSendCRLF)(lppd);

      // sRC=PSSendGSave(lppd);

      // Initialize Adobe compatibility procset (has some procs from PSCRIPT 
      //    that some applications assume as available and use)
      // NOTE: initialized only once per job. For Speed option, done at first
      //       instance of ESCPassThrough. For Portability, done at job Prolog
      //       with the main Adobe driver procset - 7/13/93 - ShyamV - bug382.
      //
      //          Adobe_Win_Compat dup /initialize get exec

      if (lppd->job.bfESCPassThrough == FALSE)  
      {
         PSSendFragment(lppd,PSFRAG_initcompatprocset);
         (*tempptr->PSSendCRLF)(lppd);
         lppd->job.bfESCPassThrough = TRUE;  // set flag that /initialize done
      }

      //
      // start new entry
      sRC = SavePassthroughInfo(lppd);
   }
   return(sRC);
}

/***********************************************************************
*                       TRawPrinterData
*  function:
*       sends Raw Data straight to the printer
*  prototype:
*       short FAR PASCAL TRawPrinterData(LPPDEVICE lppd, LP lpData, WORD nbytes)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*       LP lpdata -- the printer data
*       WORD nbytes -- the number of bytes to send
*  returns:
*       short RC_ok => success, RC_fail => failure
************************************************************************/
short FAR PASCAL TRawPrinterData(LPPDEVICE lppd, LP lpData, WORD nbytes)
{
   LPPASSTHROUGHENTRY currententry;
   // Fixed bug 459, where on Passthru we can get BINARY data, which
   //   should be TBCP/BCP encapsulated.
   PSSendBitMapDataLevel1Binary(lppd, (BYTE huge *) lpData, (DWORD) nbytes);

   if (lppd->lpPassThroughRootEntry != NULL)
   {
      currententry = (LPPASSTHROUGHENTRY)((BYTE *)lppd->lpPassThroughCurrentEntry+
                  HEADERSIZE + lppd->iCurrIndex * sizeof(PASSTHROUGHENTRY));

      currententry->dataLen += nbytes;
   }
   return(RC_ok);
}

/***********************************************************************
*                       TRawPrinterEnd
*  function:
*       sends a GRestore to the printer
*  prototype:
*       short FAR PASCAL TRawPrinterEnd(LPPDEVICE lppd)
*  parameters:
*       LPPDEVICE lppd -- pdevice pointer
*  returns:
*       short RC_ok => success, RC_fail => failure
************************************************************************/

short FAR PASCAL TRawPrinterEnd(LPPDEVICE lppd)
{
   short sRC;
   LPASCIIBINPTRS tempptr;

   BOOL bfBinaryOutput =
      (lppd->lpPSExtDevmode->dm2.iDataOutputFormat != PROTOCOL_ASCII);

   // Fix bug 164116 (1)
   BOOL nodribble = ((lppd->lpPSExtDevmode->dm.enumDialect != DIA_SPEED) &&
                     (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS));

   BOOL DownLoadHdr = lppd->lpPSExtDevmode->dm2.fHeader;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   sRC = RC_ok;

   // Send a CRLF.  This provides a PostScript language delimiter
   // between the raw printer data, and makes sure the following
   // DSC comment is in column 1.

   PrintPassthroughEndDSC(lppd);

   // suspend the Adobe compatibility procset
   // Adobe_Win_Compat dup /suspend get exec
   PSSendFragment(lppd,PSFRAG_suspendcompatprocset);
   (*tempptr->PSSendCRLF)(lppd);
   lppd->job.bfESCPassThrough = FALSE;

   // Commentary: At the end of the job, in the trailer, compatibility procset 
   // should be terminated formally, just like Adobe_Win_Procset, the main 
   // Windows procset. Since there is nothing specific that needs to be done
   // at the end of the job for compat procset, we are holding off on /terminate.
   // This discourse is in the spirit of propagating good PS programming practices.
   //   7/13/93 - /terminate now done since /suspend is not done - ShyamV - bug382

   //sRC=PSSendGRestore(lppd);

   if ((DownLoadHdr == TRUE) || 
       (DIALECT_EPS == lppd->lpPSExtDevmode->dm2.bOutputDialect))
   {
#ifndef ADOBEPS42
      if ( (lppd->lpPSExtDevmode->dm2.bfUseLevel2 == TRUE) &&
           (lppd->lpPSExtDevmode->dm.enumDialect != DIA_EPS) &&
            bfBinaryOutput)
      {
#endif
         if (nodribble == FALSE)
         {
            // Adobe_Win_Driver_Incr_L2 dup /resume get exec
            PSSendFragment(lppd,PSFRAG_resumedribble_L2);
         }
         else // complete header
         {
            // /Adobe_Win_Driver_L2 /ProcSet findresource dup /resume get exec
            PSSendFragment(lppd,PSFRAG_resumeprocset_L2);
         }
#ifndef ADOBEPS42
      }
      else  // level 1
      {
         if (nodribble == FALSE)
         {
            // Adobe_Win_Driver_Incr dup /resume get exec
            PSSendFragment(lppd,PSFRAG_resumedribble);
         }
         else
         {
            // /Adobe_Win_Driver /ProcSet findresource dup /resume get exec
            PSSendFragment(lppd,PSFRAG_resumeprocset);
         }
      }
#endif
   }
   else
   {
      // Case 6 -- header had been already down there, initialise it.

      // /Adobe_Win_Driver /ProcSet findresource dup /resume get exec
      PSSendFragment(lppd,PSFRAG_resumeprocset);
   }
   (*tempptr->PSSendCRLF)(lppd);

   // reset the colorspace - NOP in level1, current colorspace in Level2
   PSSendFragment(lppd, PSFRAG_refreshColorSpace);
   // Color space may be changed.   jjia  5/30/96
   lppd->lpGSStack->lpgGState->bColorSpaceChanged = TRUE; 
   (*tempptr->PSSendCRLF)(lppd);

    // resume calrgb procset if (color_matching == TRUE)
    if (lppd->lpPSExtDevmode->dm.iColorMatchingMethod == COLOR_MATCH_ACROSS_PRINTERS)
    {
        // /Adobe_Win_CalRGB /ProcSet findresource dup /resume get exec
        PSSendFragment(lppd,PSFRAG_resumecalrgb);
        (*tempptr->PSSendCRLF)(lppd);
    }
    (*tempptr->PSSendCRLF)(lppd);

   return(sRC);
}


