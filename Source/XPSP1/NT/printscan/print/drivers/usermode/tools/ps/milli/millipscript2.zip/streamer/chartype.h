/* CM_VerSion chartype.h atm04 1.3 04307.eco sum= 25960 */
/*
  chartype.h -- character type table for Type 1 parser

Copyright (c) 1991-1992 Adobe Systems Incorporated.
All rights reserved.

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript is a registered trademark of Adobe Systems Incorporated.
Display PostScript is a trademark of Adobe Systems Incorporated.

Original version: 
Edit History:
Paul Haahr: Mon Apr 6 12:48:11 1992
End Edit History.

Revision History
  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/CHARTYPE.H_V  $
 *- |
 *- |   Rev 1.1   28 Jun 1995 16:57:02   peterb
 *- |specified size of exter atmparse_chartype[] array to fix C4746 warning
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:07:04   unknown
 *- |Initial revision.
  Revision 6.1  91/10/07  18:22:27  rublee



End Revision History.

*/

/*
 * Definitions for character types.  Used for both <ctype.h>-like character
 * predicates and hex->internal number conversion.  The table is defined in
 * chartype.c.
 */

#ifndef	CHARTYPE_H
#define CHARTYPE_H

#if OS!=os_windows3
extern unsigned char atmparse_chartab[256];
#else
extern unsigned char NEAR atmparse_chartab[256];
#endif

#define HEXVAL          0x0f
#define ISWHITESPACE    0x10
#define ISTOKENEND      0x20
#define ISDIGIT         0x40
#define ISHEXDIGIT      0x80

#define iswhitespace(c) (atmparse_chartab[c] & ISWHITESPACE)
#define istokenend(c)   (atmparse_chartab[c] & ISTOKENEND)
#define isdigit(c)      (atmparse_chartab[c] & ISDIGIT)
#define ishexdigit(c)   (atmparse_chartab[c] & ISHEXDIGIT)

#endif	/* CHARTYPE_H */
