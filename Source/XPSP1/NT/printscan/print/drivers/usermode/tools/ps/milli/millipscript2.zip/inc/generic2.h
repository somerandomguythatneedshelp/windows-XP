#define _XCFSEG1                 "_XCF1"
#define _XCFSEG2                 "_XCF2"
#define _XCFSEG3                 "_XCF3"
#define _XCFSEG4                 "_XCF4"
#define _XCFSEG5                 "_XCF5"
#define _XCFSEG6                 "_XCF6"
#define _XCFSEG7                 "_XCF7"
#define _XCFSEG8                 "_XCF8"


#define _UFLSEG1                 "_UFL1"
#define _UFLSEG2                 "_UFL2"
#define _UFLSEG3                 "_UFL3"
#define _UFLSEG4                 "_UFL4"
#define _UFLSEG5                 "_UFL5"
#define _UFLSEG6                 "_UFL6"
#define _UFLSEG7                 "_UFL7"
#define _UFLSEG8                 "_UFL8"
#define _UFLSEG9                 "_UFL9"
#define _UFLSEG10                 "_UFL10"
#define _UFLSEG11                 "_UFL11"

#define XCFSEG1      __based(__segname(_XCFSEG1))
#define XCFSEG2      __based(__segname(_XCFSEG2))
#define XCFSEG3      __based(__segname(_XCFSEG3))
#define XCFSEG4      __based(__segname(_XCFSEG4))
#define XCFSEG5      __based(__segname(_XCFSEG5))
#define XCFSEG6      __based(__segname(_XCFSEG6))
#define XCFSEG7      __based(__segname(_XCFSEG7))
#define XCFSEG8      __based(__segname(_XCFSEG8))


#define UFLSEG1      __based(__segname(_UFLSEG1))
#define UFLSEG2      __based(__segname(_UFLSEG2))
#define UFLSEG3      __based(__segname(_UFLSEG3))
#define UFLSEG4      __based(__segname(_UFLSEG4))
#define UFLSEG5      __based(__segname(_UFLSEG5))
#define UFLSEG6      __based(__segname(_UFLSEG6))
#define UFLSEG7      __based(__segname(_UFLSEG7))
#define UFLSEG8      __based(__segname(_UFLSEG8))
#define UFLSEG9      __based(__segname(_UFLSEG9))
#define UFLSEG10      __based(__segname(_UFLSEG10))
#define UFLSEG11      __based(__segname(_UFLSEG11))

