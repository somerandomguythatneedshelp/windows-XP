/*  parse2.c  - some functions used to parse PPD functions  */

#include  "generic.h"

#pragma code_seg(_PARSE2SEG)

// this array holds a unique list of main keywords whose contents is
// initially the set of predefined main keywords enumerated in KEYWORD.
// plus all new main keywords parsed directly from the PPD file
// plus all new main keywords introduced via OpenUI.

LPSTRINGREF  lpMainKeyWordsTable ;

WORD     numMainKeyWords ;  // indexes first empty slot in array.

BOOL     bUseSetResolution ,   // which resolution command to scan for
         bAutoSelect ,         // specify autoSelect input tray.
         bManFeed,
         bSTOverflow  ,
         bCustomSize ;   //  warn UI to allocate space for extra sizes.

LPKEYENTRY  lpKeyEntry;   //  index of all main keyword statments in PPD file
WORD        numKeywords ;

ENCODING    LangEncoding ;  //  Enum of various possible encodings.

DWORD  ScreenFreq , ScreenAngle ;

LPUI_CONSTRAINTS   lpUI_constraints ;  // points to array of constraints.
WORD   max_constraints ;  // initialized to array size
WORD   curConstraint ;   // initialized to zero.

HPBYTE  hpBuf ;  // Points to very start of PPD buffer (offset zero)
long    sizeHpBuf ;  // total size of PPD  buffer. Used only by
               //  InsertFileContents(), but requires initialization
               //  outside of that recursive function.
LPBYTE   lpStringPtr ;  //  points to uninitialized portion of string table.
DWORD  PPDchecksum ;  //  checksum for PPD file.

BOOL    FAR  PASCAL  createWPXfileFromPPDnow(
LPBYTE  PPDfilename,  // full pathname of root PPD file, including extension
LPBYTE  WPXfilename)  // full pathname of target WPD file
{
   DWORD  curOffset ;  // allows me to detect segment overflow.


   long     bufCount ;    // number bytes read into hpBuf.
   WORD     numOpenUIs, numFonts, numResolutions, numSetResolutions,
            numOutputBins, numInputSlots, numPaperDim, numMediaType,
            numDuplex, numCollate, numOutputOrder, 
            numInstalledMemory, i , j,  nDocSticky, nPrinterSticky,
            numFontCacheSize/*RS, numDuplex*/;
   BOOL     status;


   LPNEWUIKEYWORDS     lpNewUIKeywords ;  // temp storage

   // these are the four allocated blocks that permanently store WPX info.

   LPBYTE   lpPrinterInfoBlock, lpOptionsBlock, lpStringTable;


   WORD     PrinterInfo_len, OptionArray_len, stringtab_len,
            UI_constraint_len;  // how many bytes to write out to file.

   LPPRINTERINFO  lpPrinterInfo;  // points to PRINTERINFO structure
                  //  in the lpPrinterInfoBlock.
   LPMAINKEYHDR       lpMainKeyHdrs  ;  // points to array of MAINKEYHDRs
                  //  in the lpPrinterInfoBlock.
   WORD    numMainKeyHdrs  ;

   status = FALSE;  //  failed unless I say otherwise.
   bSTOverflow = FALSE;  // initially string table isn't overflowed

   hpBuf =      NULL ;  //  each pointer accesses a global memory block.
   sizeHpBuf = 0  ;
   lpKeyEntry = NULL ;  //  init pointers to failure condition.
   lpMainKeyWordsTable  = NULL ;
   lpNewUIKeywords  = NULL ;
   lpPrinterInfoBlock = NULL ;  
   lpOptionsBlock  = NULL ;
   lpUI_constraints  = NULL ;
   lpStringTable  = NULL ;

   bufCount = InsertFileContents(PPDfilename, 0L, 0L);
   PPDchecksum = crc32(hpBuf, bufCount);

   if(!bufCount)
      goto  Terminate;     // No WPD file created.

   hpBuf[bufCount] = '\0' ;  // temporary firewall. EOF indicator.

   // a debug check, this must always be true:  sizeHpBuf > bufCount

   //   at this point hpBuf contains contents of root and all included ppd files
   lpKeyEntry = (LPKEYENTRY)GlobalAllocPtr(GHND, NUMKEYENTRY * sizeof(KEYENTRY)); 
   if(!lpKeyEntry)
      goto  Terminate;

   lpMainKeyWordsTable = (LPSTRINGREF)GlobalAllocPtr(GHND, MAXMAINKEYWORDSTABLESIZ * sizeof(STRINGREF)); 
   if(!lpMainKeyWordsTable)
      goto  Terminate;


   if(!(lpStringTable = (LPBYTE)GlobalAllocPtr(GHND, 0x10000L)))
      goto  Terminate;

   lpStringPtr = lpStringTable ;


   initMainKeyWordsTable();

   numKeywords = IndexKeywords(lpKeyEntry, hpBuf, bufCount);
   //  at this point, lpKeyEntry is initialized with all relavent
   //  keywords and their locations.  .flags = 0 at this time.

   loadSymbolTable( lpKeyEntry, numKeywords) ;

   fillKeyEntries(lpKeyEntry, numKeywords);

   SetKeyEntryFlags(lpKeyEntry, numKeywords ) ;

   SetKeyEntryJCLFlag(lpKeyEntry, numKeywords ) ;

//   want to read version 3.0 PPD's too.
//   if(confirmVersion(lpKeyEntry, numKeywords) == FALSE)
//      goto  Terminate;

   // ---- count number of certain objects ----

   numOpenUIs = numFonts = numResolutions = numSetResolutions =  
      numOutputBins = numInputSlots = numPaperDim  = numMediaType = 
      numInstalledMemory = numFontCacheSize = numDuplex = 
      numCollate = numOutputOrder = 0; 
   bUseSetResolution = bManFeed = bCustomSize = bAutoSelect = FALSE;
                        //  Until proven otherwise

   for(i = 0 ; i < numKeywords ; i++)
   {
      switch (lpKeyEntry[i].keyword )
      {
         case (OPENUI):
            numOpenUIs++;
            break;
         case (FONT):
            // if the font encoding is not supported by our driver, don't 
            // bother to save it so we don't waste string table's space
            if(SupportedEncoding(lpKeyEntry[i].value))
            {
               numFonts++;

               if (IsDBCSPFont(lpKeyEntry[i].option))
                  numFonts++;
               else
               if (IsMinchoOrGothic(lpKeyEntry[i].option)
                   && !Is90ms(lpKeyEntry[i].option))
                  numFonts++;
            }
            break;
         case (RESOLUTION):
         case (JCLRESOLUTION):
            numResolutions++;
            break;
         case (SETRESOLUTION):
            numSetResolutions++;
            break;
         case (OUTPUTBIN):
            numOutputBins++;
            break;
         case (INPUTSLOT):
            numInputSlots++;
            break;
         case (PAPERDIMENSION):
            numPaperDim++;
            break;
         case (MEDIATYPE):
            numMediaType++;
            break;
         case (VMOPTION):                      
            numInstalledMemory++;
            break;
         case (DUPLEX): 
            numDuplex++;
            break;
         case (COLLATE): 
            numCollate++;
            break;
         case (OUTPUTORDER): 
            numOutputOrder++;
            break;
         case (FONTCACHESIZE):                     
            numFontCacheSize++;
            break;
         case (MANUALFEED):
            bManFeed = TRUE;
            break;
         case (CUSTOMPAGESIZE):
            bCustomSize = TRUE;
            break;
         default:
            break;
      }
   }

   if(numInputSlots > 1)   
   {
      // If there are more than one input slots, add AutoSelect as 
      // another input slot.
      bAutoSelect = TRUE;
   }

   //  adjustments to counts:

   if(!numResolutions  &&  numSetResolutions)
   {
      numResolutions = numSetResolutions ;
      bUseSetResolution = TRUE;  //  if this is the only way to change
                           // resolutions, we will reluctantly use it.
   }


   numInputSlots++;     //  reserve one slot for Mixed Bins just in case
   if(bAutoSelect)
      numInputSlots++;     //  AutoSelect is another inputslot
   if(bManFeed)
      numInputSlots++;     //  manual feed is another inputslot
   if(!numResolutions)
      numResolutions = 1;  //  create default resolution of 300x300 dpi
                           //  if none exists.

//   Eric's UI specifies displaying 3 user named Custom Paper sizes
//   this is a task I will leave to the paper UI control.
//   remember: WPX info is static and common to all driver instances!
//   UI must determine if printer supports custom sizes and if so
//   allocates extra list boxes to hold them.

   if(bCustomSize)      // used to track UI constraints and
      numPaperDim++;    // OrderDependency.

   if (numOpenUIs)
   {
      DWORD   ndoc_nprinter ;

      lpNewUIKeywords = (LPNEWUIKEYWORDS)GlobalAllocPtr(GHND, 
                     (long)(numOpenUIs * sizeof(NEWUIKEYWORDS)));
      if(!lpNewUIKeywords)
         goto  Terminate;

      ndoc_nprinter = CountNewUIKeywords(lpKeyEntry, lpNewUIKeywords) ;
      nDocSticky = HIWORD(ndoc_nprinter);
      nPrinterSticky = LOWORD(ndoc_nprinter);
      numOpenUIs = nDocSticky + nPrinterSticky ;
   }
   else
      nDocSticky = nPrinterSticky = 0 ;

   //  we have enough info to allocate the main PRINTERINFO struct.

   numMainKeyHdrs = IND_NUMPREDEFINEDHDRS + numOpenUIs ;

   PrinterInfo_len = sizeof(PRINTERINFO) + numMainKeyHdrs * sizeof(MAINKEYHDR) ;

   lpPrinterInfoBlock = (LPBYTE)GlobalAllocPtr(GHND, (long)PrinterInfo_len);
   if(!lpPrinterInfoBlock)
      goto  Terminate;

   lpPrinterInfo = (LPPRINTERINFO) lpPrinterInfoBlock ;

   lpMainKeyHdrs = (LPMAINKEYHDR)(lpPrinterInfo + 1) ;
 
   //  determine number and type of option arrays needed.
   //  begin initializing ARRAYREF entries in lpMainKeyHdrs with 
   //  references to the option arrays as the calculation proceeds.

   curOffset = 0L ;  // points to unassigned portion of memory for secondary
                     //  arrays.

   lpPrinterInfo->numMainKeyHdrs = numMainKeyHdrs ;
   lpPrinterInfo->PrinterSticky.w.length = nPrinterSticky ;
   lpPrinterInfo->PrinterSticky.w.offset = IND_NUMPREDEFINEDHDRS;
   lpPrinterInfo->DocSticky.w.length = nDocSticky ;
   lpPrinterInfo->DocSticky.w.offset = IND_NUMPREDEFINEDHDRS + nPrinterSticky ;

   lpPrinterInfo->FontList.w.offset = (WORD)curOffset ;  // first secondary array
   lpPrinterInfo->FontList.w.length = numFonts ;

   curOffset +=  numFonts * sizeof(FONTLIST) ;

   lpMainKeyHdrs[IND_PAPERINFO].OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs[IND_PAPERINFO].OptionKeyWords.w.length = numPaperDim ;
   curOffset +=  numPaperDim * sizeof(GENERIC_OPTION);
   lpMainKeyHdrs[IND_PAPERINFO].extraOptionArray = (WORD)curOffset ;

   curOffset +=  numPaperDim * sizeof(PAPERINFO) ;

   lpMainKeyHdrs[IND_PAGEREGIONINFO].OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs[IND_PAGEREGIONINFO].OptionKeyWords.w.length = numPaperDim ;

   curOffset +=  numPaperDim * sizeof(GENERIC_OPTION) ;

   lpMainKeyHdrs[IND_DUPLEXINGINFO].OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs[IND_DUPLEXINGINFO].OptionKeyWords.w.length = numDuplex;

   curOffset +=  NUM_DUPLEX_MODES * sizeof(GENERIC_OPTION) ;

   lpMainKeyHdrs[IND_INPUTSLOTINFO].OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs[IND_INPUTSLOTINFO].OptionKeyWords.w.length = numInputSlots ;
   curOffset +=  numInputSlots * sizeof(GENERIC_OPTION);
   lpMainKeyHdrs[IND_INPUTSLOTINFO].extraOptionArray = (WORD)curOffset ;

   curOffset +=  numInputSlots * sizeof(INPUTSLOTINFO) ;

   lpMainKeyHdrs[IND_RESOLUTIONINFO].OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs[IND_RESOLUTIONINFO].OptionKeyWords.w.length = numResolutions ;
   curOffset +=  numResolutions * sizeof(GENERIC_OPTION) ;
   lpMainKeyHdrs[IND_RESOLUTIONINFO].extraOptionArray = (WORD)curOffset ;

   curOffset +=  numResolutions * sizeof(RESOLUTIONINFO) ;

   lpMainKeyHdrs[IND_OUTPUTBININFO].OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs[IND_OUTPUTBININFO].OptionKeyWords.w.length = numOutputBins ;

   curOffset +=  numOutputBins * sizeof(GENERIC_OPTION) ;

   lpMainKeyHdrs[IND_MEDIATYPEINFO].OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs[IND_MEDIATYPEINFO].OptionKeyWords.w.length = numMediaType ;

   curOffset +=  numMediaType * sizeof(GENERIC_OPTION) ;

   lpMainKeyHdrs[IND_MEMORYINFO].OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs[IND_MEMORYINFO].OptionKeyWords.w.length = numInstalledMemory ;
   curOffset +=  numInstalledMemory * sizeof(GENERIC_OPTION) ;
   lpMainKeyHdrs[IND_MEMORYINFO].extraOptionArray = (WORD)curOffset ;

   curOffset +=  numInstalledMemory * sizeof(MEMORYINFO) ;
   
   lpMainKeyHdrs[IND_COLLATIONINFO].OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs[IND_COLLATIONINFO].OptionKeyWords.w.length = numCollate;

   curOffset +=  NUM_COLLATE_MODES * sizeof(GENERIC_OPTION) ;

   lpMainKeyHdrs[IND_OUTPUTORDERINFO].OptionKeyWords.w.offset = (WORD)curOffset ;
   lpMainKeyHdrs[IND_OUTPUTORDERINFO].OptionKeyWords.w.length = numOutputOrder;

   curOffset +=  NUM_OUTPUTORDER_MODES * sizeof(GENERIC_OPTION) ;

   {  // do this before addTransStringToTable is ever called.
      HPBYTE  hpCur ;

      //  determine LanguageEncoding to be used.
      hpCur = NULL;
      LangEncoding = NOENCODING ;

      for(i = 0 ; i < numKeywords ; i++)
      {
         if(lpKeyEntry[i].keyword == LANGUAGEENCODING)
         {
            hpCur = lpKeyEntry[i].value;
            break;  //   scan for this keyword.  stop at first occurance
         }
      }

      if(hpCur  &&  !hstrcmp("ISOLatin1", hpCur))
      {
         LangEncoding = ISOLATIN1 ;
         InitISOLatin1Table() ;
      }
   }


   for( nPrinterSticky = nDocSticky = i = 0 ; i < numOpenUIs ; i++)
   {
      LPMAINKEYHDR      lpCurMainKeyHdr ;
      WORD              numOptions ;


      for(numOptions = j = 0 ; j < numKeywords ; j++)
      {
         if (lpNewUIKeywords[i].keyword == lpKeyEntry[j].keyword) 
            numOptions++ ;
      }

      if(lpNewUIKeywords[i].UItype == PICKMANY)
            numOptions++ ;  // must reserve room for required "None" option
      else  if(lpNewUIKeywords[i].UItype == BOOLEAN  &&  numOptions < 2)
            numOptions = 2 ;  // must reserve room for True and False.
         
      if(lpNewUIKeywords[i].PrntrSticky)
      {
         lpCurMainKeyHdr = lpMainKeyHdrs + IND_NUMPREDEFINEDHDRS + nPrinterSticky ;
         nPrinterSticky++ ;
      }
      else
      {
         lpCurMainKeyHdr = lpMainKeyHdrs + IND_NUMPREDEFINEDHDRS + 
            lpPrinterInfo->PrinterSticky.w.length + nDocSticky ;
         nDocSticky++ ;
      }

      lpCurMainKeyHdr->MainKeyID = lpNewUIKeywords[i].keyword ;
      lpCurMainKeyHdr->UItype = lpNewUIKeywords[i].UItype ;
      lpCurMainKeyHdr->OptionKeyWords.w.offset = (WORD)curOffset ;
      lpCurMainKeyHdr->OptionKeyWords.w.length = numOptions ;
      lpCurMainKeyHdr->MainKey.dword = lpMainKeyWordsTable[lpNewUIKeywords[i].keyword].dword ;
      lpCurMainKeyHdr->MainTranslation.dword = 
            addTransStringToTable(lpNewUIKeywords[i].optionTrans) ;

      curOffset +=  numOptions * sizeof(GENERIC_OPTION) ;
   }

   if(curOffset != (DWORD)(WORD)curOffset)
      goto  Terminate;  // Needs more than 64k to hold secondary arrays.

   OptionArray_len = (WORD)curOffset ;

   lpOptionsBlock = (LPBYTE)GlobalAllocPtr(GHND, (long)OptionArray_len);
   if(!lpOptionsBlock)
      goto  Terminate;


   UI_constraint_len = NUM_CONSTR * sizeof(UI_CONSTRAINTS) ;

   if(!(lpUI_constraints = (LPUI_CONSTRAINTS)GlobalAllocPtr(GHND, UI_constraint_len)))
      goto  Terminate;

   max_constraints = NUM_CONSTR ;

   if(OFFSETOF(lpOptionsBlock)  ||  OFFSETOF(lpStringTable))
   {
      errorMsg(CREATEWPXFILEFROMPPDNOW, ERR_GMEM_OFFSET_NONZERO);
      goto  Terminate;
   }


   status = initWPXinfo(lpPrinterInfo, lpOptionsBlock, lpStringTable,
                        PPDfilename);

   UI_constraint_len = curConstraint * sizeof(UI_CONSTRAINTS) ;

   if(!status)
      goto  Terminate;

#if 0
//   construct font summary here

   FontDirSiz = makeFontSum(lpOptionsBlock, lpKeyEntry, numKeywords, lpPFMindex);

   MapToID(lpPrinterInfo, lpStringTable);

#endif

//   write wpx file here.

   stringtab_len = lpStringPtr - lpStringTable ;

                                                                    
      //  this block just restricts scope of local variables
   {  //  writing stringTable to file.

      WORD   count;
      OFSTRUCT   OpenBuf ;  // for OpenFile()
      HFILE  hWPX ;  //  holds handle to Index file
      WPX_HEADER  wpxHeader;

      status = TRUE;  //  until a write error occurs.


      wpxHeader.PrinterInfo_len   = PrinterInfo_len ;
      wpxHeader.OptionArray_len   = OptionArray_len ;
      wpxHeader.stringtab_len     = stringtab_len ;
      wpxHeader.UI_constraint_len = UI_constraint_len ;

      wpxHeader.PrinterInfo_loc   = (long)sizeof(WPX_HEADER);
      wpxHeader.OptionArray_loc   = wpxHeader.PrinterInfo_loc + PrinterInfo_len ;
      wpxHeader.stringtab_loc     = wpxHeader.OptionArray_loc + OptionArray_len ;
      wpxHeader.UI_constraint_loc = wpxHeader.stringtab_loc + stringtab_len ;


      hWPX = OpenFile(WPXfilename, &OpenBuf, 
                  OF_CREATE | OF_WRITE | OF_SHARE_DENY_WRITE);

      if(hWPX == HFILE_ERROR) 
      {
         errorMsg(CREATEWPXFILEFROMPPDNOW, ERR_FILE_WRITEACCESS);
         errorMsg(CREATEWPXFILEFROMPPDNOW, ERR_CREATING_WPX_FILE);
         errorString(WPXfilename);
         goto  Terminate;
      }
      //  write wpxHeader
      count = sizeof(WPX_HEADER) ;
                  
      if(count != _lwrite(hWPX, &wpxHeader,  count))
         status = FALSE;
      else if(PrinterInfo_len != _lwrite(hWPX, lpPrinterInfoBlock,  PrinterInfo_len))
         status = FALSE;
      else if(OptionArray_len != _lwrite(hWPX, lpOptionsBlock,  OptionArray_len))
         status = FALSE;
      else if(stringtab_len != _lwrite(hWPX, lpStringTable,  stringtab_len))
         status = FALSE;
      else if(UI_constraint_len != _lwrite(hWPX, lpUI_constraints,  UI_constraint_len))
         status = FALSE;

      if(status == FALSE)
      {
         errorMsg(CREATEWPXFILEFROMPPDNOW, ERR_FILE_WRITE_FAILED);
         errorMsg(CREATEWPXFILEFROMPPDNOW, ERR_CREATING_WPX_FILE);
         errorString(WPXfilename);
      }

      _lclose(hWPX);
   }


   // ---- termination actions -----
Terminate:
   if(hpBuf)
      GlobalFreePtr(hpBuf);
   if(lpKeyEntry)
      GlobalFreePtr(lpKeyEntry);
   if(lpMainKeyWordsTable)
      GlobalFreePtr(lpMainKeyWordsTable);
   if(lpNewUIKeywords)
      GlobalFreePtr(lpNewUIKeywords);
   if(lpPrinterInfoBlock)
      GlobalFreePtr(lpPrinterInfoBlock);
   if(lpOptionsBlock)
      GlobalFreePtr(lpOptionsBlock);
   if(lpUI_constraints)
      GlobalFreePtr(lpUI_constraints);
   if(lpStringTable)
      GlobalFreePtr(lpStringTable);
   return(status);
}





/*  InsertFileContents() - function allocs or reallocs an hpBuf
   to hold contents of file that will be read in.  Reads included
   PPD files recursively.
   assumes  hpBuf and its size (global variables) reflect reality 
      both should be set to zero if no buffer has yet been allocated.
      note:  due to reallocation, this function may
      alter both hpBuf and its size  
   return value:  new insertionPt. Should point after file that was just
      read in.   a return value of 0 indicates fatal error. 
   bytesToShift:  is unchanged by this function 
*/
long  NEAR   PARSE2SEG PASCAL InsertFileContents(
LPBYTE  filename,  // file containing contents to be read
long    insertionPt ,  // offset at which to insert contents from filename.
long    bytesToShift ) // number of bytes residing in hpBuf beyond the
                        // insertionPt.  They need to be shifted
                        // otherwise they will be overwritten
{
   extern HPBYTE  hpBuf ;  // Points to very start of buffer (offset zero)
   extern long    sizeHpBuf ;  // total size of buffer.
   BYTE   incFilename[256] ;    //  holds value of *include keyword.
   long  fileSize, li,     //  li is just a long counter.
         actualSize,       //  actual number of bytes written to hpBuf
         scanCount   ;     //  number of bytes to scan.
   HFILE  hfile ;
   OFSTRUCT   OpenBuf ;  // for OpenFile()
   
/*  suggested load code: if 'filename' contains a filename only
   then prepend the path to the main ppd dir. ie: SYSTEM\PPDS
   else use 'filename' as is  */

//   hfile = _lopen(filename, READ | OF_SHARE_DENY_WRITE);
   hfile = OpenFile(filename, &OpenBuf, READ | OF_SHARE_DENY_WRITE);
      //  note: default to searching main ppd
      // directory unless explicity directed
      // otherwise.  otherwise you may end up
      // opening the same file, over and over again!
      // PPD headers are kept in a header directory
      // this directory is searched first.
      // if no PPD file for specified file is found
      // here then the main PPD dir is searched.
      // in no case must there be 2 or more PPDs
      // for the same printer in the first directory
      // encountered.  The 2nd directroy may have
      // multiple PPD's since these are accessed by
      // includes.

   if(hfile == HFILE_ERROR) 
   {
      errorMsg(INSERTFILECONTENTS, ERR_FILE_READACCESS);
      errorMsg(INSERTFILECONTENTS, ERR_CANT_FIND_PPD_FILE);
      errorString(filename);
      goto  abortInsertFileContents;
   }
   //  determine fileSize;
   fileSize = _llseek(hfile, 0L, 2);   //  seek end of file
   _llseek(hfile, 0L, 0);              //  seek beginning of file.

   //  add one byte for prepending newline. another byte for future firewall
   actualSize = insertionPt+bytesToShift+fileSize+2 ;
   if(actualSize  > sizeHpBuf)
   {
      HPBYTE  hpTmpBuf;

      if(sizeHpBuf > 0x40000)
      {
         errorMsg(INSERTFILECONTENTS, ERR_PPD_SELF_REFERENCING);
         goto  abortInsertFileContents;
      }
      if(hpBuf)    //  realloc to obtain larger buffer.
      {
         hpTmpBuf = GlobalReAllocPtr(hpBuf, actualSize , GMEM_MOVEABLE);

         if(hpTmpBuf)
         {
            sizeHpBuf = actualSize;
            hpBuf = hpTmpBuf ;
         }
         else
         {
            errorMsg(INSERTFILECONTENTS, ERR_GLOBALREALLOC_FAILED);
            goto  abortInsertFileContents;
         }
      }
      else  //  need to alloc a buffer.  hpBuf and size are zero.
      {
         hpBuf = GlobalAllocPtr(GHND, actualSize );  //  alloc one 64k segment
         if(hpBuf)
            sizeHpBuf = actualSize ;
         else
         {
            errorMsg(INSERTFILECONTENTS, ERR_GLOBALALLOC_FAILED);
            goto  abortInsertFileContents;
         }
      }
      if(!hpBuf)   // if error condition exists
         goto  abortInsertFileContents;
   }

   shiftNBytes(hpBuf + insertionPt + fileSize + 1, hpBuf + insertionPt, 
               bytesToShift) ;
                        // shiftNBytes(hpDest, hpSrc, numBytes) 
   hpBuf[insertionPt++] = '\n' ;  // prepend newline.
   // read contents of filename  into space vacated in hpBuf
   actualSize = _hread(hfile, hpBuf+insertionPt,  fileSize);  
   _lclose(hfile);
   if(actualSize == -1)
   {
      errorMsg(INSERTFILECONTENTS, ERR_FILE_READ_FAILED);
      errorMsg(INSERTFILECONTENTS, ERR_READING_FRM_PPDFILE);
      errorString(filename);
      goto  abortInsertFileContents;
   }
   for(li = actualSize ; li < fileSize ; li++)
      hpBuf[insertionPt + li] = '\n' ;  //  fill unused space with newlines

   // at this point hpBuf contains:
   // | insertionPt bytes + '\n' | fileSize new bytes | bytesToShift |       unused bytes    |
   //                            |<--- scanCount  --->|
   //                            ^-start scan         ^-stop scan here
   //  after ScanForInclude:
   //                            |byteScaned|scanCount|
   //                                       ^-new InsertionPt.
   // after InsertFileContents:
   //                            |byteScaned| included file |scanCount| bytesToShift | unused|
   //                                                       ^-InsertionPt.

   scanCount =  fileSize ;

   while(1)
   {
      long  bytesScanned ;  //  number of bytes scanned by ScanForInclude()

      //  nothing to scan for if scanCount is zero!
      //  or if we overscanned causing bytesScanned > scanCount.
      if(scanCount <= 0)
         break;  //  no more include files encountered.
      bytesScanned = ScanForInclude(insertionPt, scanCount, incFilename, 256);
      insertionPt += bytesScanned ;
      scanCount  -=  bytesScanned ;


      if(*incFilename)  
      {
         insertionPt = InsertFileContents(incFilename, insertionPt, bytesToShift+scanCount);
         if(!insertionPt)
            goto  abortInsertFileContents;
      }
      else if(!bytesScanned)
      {   //  fatal error occured inside  ScanForInclude.
         goto  abortInsertFileContents;
      }
   }
   return(insertionPt);  //  points to byte beyond last byte of buffer.

abortInsertFileContents:

   if(hpBuf)
   {
      GlobalFreePtr(hpBuf);
      hpBuf = NULL;  // killed hpBuf
   }
   sizeHpBuf = 0 ;
   return(0L);  // signal fatal error
}


/*  shiftNBytes() - this function shifts a group of bytes to the right
   (to occupy higher addresses).
    no telling what will happen if hpSrc > hpDest !!!
*/

void   NEAR  PARSE2SEG PASCAL  shiftNBytes( 
HPBYTE   hpDest,
HPBYTE   hpSrc ,
long     numBytes)
{
   hpDest += numBytes ;
   hpSrc += numBytes ;

   while(numBytes--)
      *(--hpDest) = *(--hpSrc) ;
}


/*  ScanForInclude() - 
//  function scans up to scanCount bytes in hpBuf from 
//  offset StartScan,  for string "*include filename", 
//  if found, returns number of bytes scanned up to this point.
//  
//  if no include  keyword found, incFilename will contain
//    '\0' (null string).
//  otherwise incFilename will contain path of included file.
*/

long  NEAR  PARSE2SEG PASCAL  ScanForInclude(
long  StartScan ,
long  scanCount ,
LPBYTE    incFilename ,
WORD   bufSiz )  //  max num bytes to write into  buffer incFilename.
{
   long  i ;  // number of bytes scanned - initially zero
   LPBYTE   keyword = "*Include:";
   HPBYTE  hpFilename, hpNext ;
   BOOL  bMatch ;
   WORD  keylen ;

   keylen = lstrlen(keyword) ;

   for(i = 0 ; i < scanCount ; i++)
   {
      long  k = StartScan+i ;
      WORD  j;
   
      if(  hpBuf[k] == '*'  &&  //  maybe a keyword
         ( hpBuf[k-1] == 10 || hpBuf[k-1] == 13 )) 
      {
         bMatch = TRUE ;
         for(j = 0 ; j < keylen ; j++)
         {
            if(hpBuf[k+j] != keyword[j])
            {
               bMatch = FALSE ;
               break;
            }
         }
         if(bMatch)  // we are on to something here!
         {           // parse quoted string.
            long  nbytes;

            hpNext = hpBuf+k+keylen ;  // later points after quoted literal
            hpFilename = extractQuotedLiteral(&hpNext, FALSE);
            //  filename must not be replaced by a symbol.
            if(!hpFilename)  // error extracting quoted literal.
            {        //  if overflowed incFilename...
               errorMsg(SCANFORINCLUDE , ERR_INCLUDE);
               errorMsg(SCANFORINCLUDE , ERR_KEYWORD_HAS_NO_VALUE);
               incFilename[0] = '\0';
               return(0);     // signal fatal error condition
            }

            nbytes = addQuotedStringToTable(hpFilename, incFilename, bufSiz) ;
               //  this writes translated quoted string to incFilename.

            while(*hpFilename)
               hpFilename++ ;

            *hpFilename = '"' ;  // restore terminating quote

            if(HIWORD(nbytes) >= bufSiz)  
            {        //  if overflowed incFilename...
               errorMsg(SCANFORINCLUDE, ERR_INCLUDE);
               errorMsg(SCANFORINCLUDE , ERR_BUFFER_OVERFLOW);
               errorString(incFilename);
               incFilename[0] = '\0';
               return(0);     // signal fatal error condition
            }
            return(hpNext + 1 - (hpBuf+StartScan)); // num bytes scanned.
            // this includes quoted value containing filename.
         }
      }
   }
   incFilename[0] = '\0';  //  no include directives found.
   return(scanCount) ;
}



/*  the following routine has one weak point:  if the second or subsequent
   line of multiline quoted string or invocation string begins with
   *keyword  where keyword is one of the enumerated keywords, than
   it will be mistaken for an actual keyword entry and be added to the
   KeyEntry table.  Subsequent parsing routines should be aware of this
   possibility and replace any inadvertant entries with GARBAGE.  
   This is done in fillKeyEntries()  */

WORD   NEAR  PARSE2SEG PASCAL  IndexKeywords(
LPKEYENTRY  lpKeyEntry,
HPBYTE   hpBuf,
long     bufCount )    // number bytes to read in hpBuf.
//  return value:  numKeywords ;  //  number of keyentry's actually used.
{
   WORD    numKeywords = 0 ;  //  number of matching keywords found in hpBuf.
   long    i; //  scans through hpBuf.
   WORD    j; //  scans each character of candidate keyword.

   for(i = 0 ; i < bufCount ; i++)
   {
      if(  hpBuf[i] == '*'  &&  //  maybe a keyword
         ( hpBuf[i-1] == 10 || hpBuf[i-1] == 13 )) //  start of newline
      {  // every keyword will be preceeded by newline cause I 
         // prepended a newline to every file!

         /*  at this point all chars that lie between Ascii 33 to 126
         inclusive (except linebreak chars, colon, space, or tab 
         which terminate the keyword)
         are part of the keyword.  A keyword which is terminated
         by or contains any excluded characters is illegal  */


         i ++ ;   // point to start of keyword. 

         for(j = 0 ; 1 ; j++)
         {
            BYTE  curChar;
            WORD  termination = NOTREADY ;

            curChar = hpBuf[i+j];

            if(curChar == ':')
            {
               termination = COLON;
            }
            else  if(curChar == 32  ||  curChar == 9)
            {
               termination = WHITESPACE;
            }
            else if(curChar == 10  ||  curChar == 13)
            {
               termination = NEWLINE;
            }
            else  if(curChar < 33  ||  curChar > 126)
            {
               break;  // out of j loop.
            }
            if (termination != NOTREADY)
            {
               KEYWORD   keyword;

               if(!j)
                  break;  // nothing after the *
               if(j == 1  &&  hpBuf[i] == '%')
                  break;  // just a comment.

               if((keyword = determineKeywordValue(hpBuf+i, j)) == GARBAGE)
                  break;  // unable to add entry to MainKeyWordsTable

               if(numKeywords >= NUMKEYENTRY)
               {
                  errorMsg(INDEXKEYWORDS, ERR_TOOMANY_KEYWORDS);
                  return(numKeywords);
               }

               lpKeyEntry[numKeywords].termination = termination ;
               lpKeyEntry[numKeywords].keyword = keyword;
               lpKeyEntry[numKeywords].option = hpBuf +i+j+1 ;
               lpKeyEntry[numKeywords].flags = 0 ;

               numKeywords++ ;
               break;  // out of j loop.
            }
         }   // end of j loop.

         i-- ;  // point back to *.  otherwise will miss  \n*\n*keyword
      }  //  end if block
   }     //  end i loop
   return(numKeywords);    
}

/*  
 *  hpBuf points to a Keyword, your job (if you choose to accept)
 *  is to return the index of the MainKeyWordsTable which holds
 *  this Keyword.  If this isn't in the table, add it and
 *  return the index of the new entry.
 *
 */

WORD   NEAR  PASCAL  determineKeywordValue(HPBYTE   hpBuf, WORD  keyLen)
{
   BYTE  keyword[MAXKEYLEN+1] ;
   LPBYTE  existingKey ;
   WORD    i ;

   if(keyLen > MAXKEYLEN)
      return(GARBAGE);
   
   hstrcpyn(keyword, hpBuf, (long)keyLen) ;

   for(i = 0 ; i < numMainKeyWords ; i++)
   {
      existingKey = StringRefToLP(lpMainKeyWordsTable[i]) ;
      if(!lstrcmp(existingKey, keyword))
         return(i);  // found a match in table
   }

   if(numMainKeyWords >= MAXMAINKEYWORDSTABLESIZ)
      return(GARBAGE);   // no room in keyword table.

   lpMainKeyWordsTable[numMainKeyWords].dword = addStringToTable(keyword);
   numMainKeyWords++ ;

   return(numMainKeyWords - 1) ;
}


/*
 *  return index of entry if its one of the undefined keywords
 *  listed in MainKeyWordsTable else return GARBAGE.
 *
 *
 */


WORD   FAR  PASCAL  searchKeywordValue(HPBYTE   hpBuf)
{
   BYTE  keyword[MAXKEYLEN+1] ;
   LPBYTE  existingKey ;
   WORD    i ;

   if(!hpBuf)
      return(GARBAGE);  // no match found.

   // hpBuf contains null-terminated option keyword.

   hstrcpyn(keyword, hpBuf+1, (long)MAXKEYLEN) ;  // possible to over read buffer
      //  if not null terminated, but it always is!  note we must skip the *.
   keyword[MAXKEYLEN] = '\0' ;  //  just in case option keyword was too long

   for(i = ENDOFLIST ; i < numMainKeyWords ; i++)
   {
      existingKey = StringRefToLP(lpMainKeyWordsTable[i]) ;
      if(!lstrcmp(existingKey, keyword))
         return(i);  // found a match in table
   }

   return(GARBAGE);  // no match found.
}




/*  this function creates a normal far pointer (LPBYTE) reference
   for a given STRINGREF.  (assumes storage into main Heap)  */

LPBYTE  FAR  PASCAL  StringRefToLP(STRINGREF  stringRef)
{
   return((LPBYTE)MAKELONG( stringRef.w.offset, HIWORD(lpStringPtr) ));
}



/*  fill SYMBOLVALUE KeyEntry table entries .option with 
   a huge pointer to null terminated ^Symbolname, 
   and .value entries with huge pointers to the null terminated 
   literal strings.  If syntax error is encountered remove entry
   from table using the GARBAGE keyword.
*/



WORD  NEAR  PASCAL  loadSymbolTable(
   LPKEYENTRY  lpKeyEntry,
   WORD        numKeywords )
{
   //  some SYMBOLVALUE  keywords may be invalid, thus the actual
   //  number of symbols may be less than the number of symbol keywords.
   //  return the actual number of valid symbols.  GARBAGE out invalid
   //  KeyEntries, no fatal errors generated here.

   WORD  i , numSymbols = 0;
   HPBYTE  hpCur, hpNext;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if( lpKeyEntry[i].keyword == SYMBOLVALUE )
      {
         if(lpKeyEntry[i].termination != WHITESPACE)
         {
            errorMsg(LOADSYMBOLTABLE, ERR_SYMBOLVALUE);
            errorMsg(LOADSYMBOLTABLE, ERR_OPTION_PARSING);
            lpKeyEntry[i].keyword = GARBAGE ;  // disable entry.
            continue;
         }
         hpNext =  lpKeyEntry[i].option ;
         //  lpNext originally points to token, afterward
         //  points to next token.
         hpCur = extractOption(&hpNext, TRUE, NULL) ;
         //  extract an SymbolName option token beginning with ^. NULL terminated
         //  lpNext points to Byte after COLON.  (bypassing translation
         //  string if any.)
         if(!hpCur)   //  NULL indicates faulty entry.
         {
            lpKeyEntry[i].keyword = GARBAGE ;
            errorMsg(LOADSYMBOLTABLE, ERR_SYMBOLVALUE);
            errorMsg(LOADSYMBOLTABLE, ERR_EXPECTED_SYMBOLNAME);
            continue;  //  NULL is returned if token encountered 
               // does not conform to that expected for Symbol.
         }
         lpKeyEntry[i].option = hpCur ;
         hpCur = extractQuotedLiteral(&hpNext, FALSE);
            //  Symbol value may not be another symbol.
            //  hpCur points to a NULL - terminated string of arbitary length.
         lpKeyEntry[i].value = hpCur ;
         //  if quoted value is omitted, lpCur = NULL. This is indistinguishable
         //  from a parsing error.
         numSymbols++ ;
      }
   }
   return(numSymbols);
}



/*  extractOption  is a single use routine.  It munges the
   translation string indicator / causing lpNext to point
   possibly to start of translation string instead of after
   the colon.   That's ok, it is used only to initialize
   KeyEntry table.  Returns pointers to the option keyword,
   the option keyword translation string if any and the
   value string if any.
*/



HPBYTE  NEAR  PASCAL  extractOption(
LPHPBYTE  lphpNext ,  //  initially points to token, later points
                     // to next token, or NULL if none found.
                     //  note:  return string may be zero length!
BOOL    bSymbol ,     //  TRUE if parsing for symbolName
LPHPBYTE  lphpTranslation)  // places pointer to option translation string here.
                     // may be NULL if caller not interested.
{
   HPBYTE  hpCur ;
   BYTE    byte  ;
   BOOL    bTranslation ;

   while(1) //  filter out leading whitespace and illegal chars.
   {
      byte = *(*lphpNext) ;

      if(byte != 9  &&  byte != 32)  //  not  whitespace
         break;
      (*lphpNext)++ ;
   }
   hpCur = *lphpNext ;

   if(bSymbol)
   {
      if(byte != '^')    //  symbolName option must start with ^.
      {
         *lphpNext = NULL ;  //  no more tokens in string.
         return(NULL);  //  illegal option
      }
   }
   else  if(byte == '^')    //  normal option must not start with ^.
   {
      *lphpNext = NULL ;  //  no more tokens in string.
      return(NULL);  //  illegal option
   }

   bTranslation = FALSE ;  //  set flag if translation string.

   if(lphpTranslation)
      *lphpTranslation = NULL ;  // assume no translation string

   while(1) 
   {
      byte = *(*lphpNext) ;

      if(!bTranslation  &&  (byte == 9  ||  byte == 32))
      {      //  whitespace acceptable inside Translation string.
         *lphpNext = NULL ;  //  no more tokens in string.
         errorMsg(EXTRACTOPTION, ERR_OPTION_NOT_ENDS_IN_WHITESPACE);
         errorString(hpCur);
         return(NULL);  //  illegal option
      }
      if(byte == 10  ||  byte == 13)
      {
         errorMsg(EXTRACTOPTION, ERR_OPTION_NOT_ENDS_IN_NEWLINE);
         errorString(hpCur);
         *lphpNext = NULL ;  //  no more tokens in string.
         return(NULL);  //  illegal option
      }

      if(byte == ':')
      {
         *(*lphpNext) = '\0' ;  // null terminate current token.
         (*lphpNext)++ ;    //  point to next token.
         return(hpCur);
      }
      
      if(byte == '/' &&  !bTranslation)  // translation string follows.
      {
         *(*lphpNext) = '\0' ;  // null terminate current token.
         if(lphpTranslation)
            *lphpTranslation = *lphpNext + 1 ;
         bTranslation = TRUE ;
      }
      if(!byte) 
      {
         errorMsg(EXTRACTOPTION, ERR_UNEXPECTED_NULL);
         errorString(hpCur);
         *lphpNext = NULL ;  //  no more tokens in string.
         return(NULL);  //  illegal option
      }

      (*lphpNext)++ ;
   }
}



void  NEAR  PASCAL  SetKeyEntryFlags(
   LPKEYENTRY  lpKeyEntry,
   WORD        numKeywords )
{
   /*  this functions marks all KeyEntries bracketed by Open/CloseGroup
      InstallableOptions as being of the type InstallableOptions.
      They will be considered printer sticky options by the driver.  */

   WORD  i ;
   BOOL  bInstallableOption = FALSE ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if( lpKeyEntry[i].keyword == OPENGROUP)
      {
         if(bInstallableOption)
            errorMsg(SETKEYENTRYFLAGS, ERR_OPENGROUPS_NESTED);
         if(lpKeyEntry[i].value  &&  
            !hstrcmp((HPBYTE)"InstallableOptions", lpKeyEntry[i].value))  
               bInstallableOption = TRUE ;
      }
      else if( lpKeyEntry[i].keyword == CLOSEGROUP)
      {
         if(lpKeyEntry[i].value  &&  
            !hstrcmp((HPBYTE)"InstallableOptions", lpKeyEntry[i].value))  
         {
            if(!bInstallableOption)
               errorMsg(SETKEYENTRYFLAGS, ERR_OPEN_CLOSEGROUP_MISMATCH);
         }
         else
         {
            if(bInstallableOption)
               errorMsg(SETKEYENTRYFLAGS, ERR_OPEN_CLOSEGROUP_MISMATCH);
         }
         bInstallableOption = FALSE ;
      }
      else if (lpKeyEntry[i].keyword != GARBAGE  &&  bInstallableOption) 
      {
         lpKeyEntry[i].flags |= GROUP_INSTALLABLE_OPTIONS ;
      }
   }
}


void  NEAR  PASCAL  SetKeyEntryJCLFlag(
   LPKEYENTRY  lpKeyEntry,
   WORD        numKeywords )
{
   /*  this functions marks all KeyEntries bracketed by JCLOpen/JCLCloseUI
      as being of the type JCLKEYWORD  which invokes quoted string
      processing rather than invocation string processing at
      fillKeyEntries() time.  In addition, we rename some keywords
      so the JCL keywords are processed by the same code that processes
      normal keywords.  */


   WORD  i ;
   BOOL  bJCLkeyword = FALSE ;

   for(i = 0 ; i < numKeywords ; i++)
   {
      if( lpKeyEntry[i].keyword == JCLOPENUI)
      {
         if(bJCLkeyword)
            errorMsg(SETKEYENTRYJCLFLAG, ERR_OPENGROUPS_NESTED);
         bJCLkeyword = TRUE ;
         lpKeyEntry[i].keyword = OPENUI ;
      }
      else if( lpKeyEntry[i].keyword == JCLCLOSEUI)
      {
         if(!bJCLkeyword)
            errorMsg(SETKEYENTRYJCLFLAG, ERR_OPEN_CLOSEGROUP_MISMATCH);
         bJCLkeyword = FALSE ;
         //  lpKeyEntry[i].keyword = CLOSEUI ;  Serves no purpose
         //  this key isn't parsed!
      }
      else if (lpKeyEntry[i].keyword != GARBAGE  &&  bJCLkeyword) 
      {
         lpKeyEntry[i].flags |= JCLKEYWORD ;
      }
   }
}



/* a value token is a quoted value if the first non-whitespace
   character is either " or ^.  This routine should be called
   to parse and NULL terminate this token.
   return value points to start of quoted string (just after
   first double quote.  The last quote is replaced by NULL
   a zero length quoted value is represented by a pointer to 
   a byte with value zero.  
   An NULL is returned if either the quoted value is entirely omitted
   or a parsing error occured.  Users of this routine should
   not treat a NULL return value necessarily as a Fatal error.
   (of course if they require a string and its missing, it may
   end up as a Fatal error).

   lphpNext is  set to point to terminating byte of string.
   (a translation string may follow, which we gleefully ignore).
*/
HPBYTE  FAR  PASCAL  extractQuotedLiteral(
LPHPBYTE  lphpNext,  //  initially points at or before quote
BOOL    symbolOK )  //  set true if a symbol may be used instead of literal.
{
   HPBYTE  hpCur ;
   BYTE    byte  ;
   

   while(1) //  filter out leading whitespace and illegal chars.
   {
      byte = *(*lphpNext) ;
               
      if(byte != 9  &&  byte != 32)  //  not  whitespace
         break;
      (*lphpNext)++ ;
   }

   if(byte == '"')  // most common case
   {
      (*lphpNext)++ ;
      hpCur = *lphpNext ;  // points to start of string.
              
      while(1) //  stop when terminating " is encountered.
      {
         byte = *(*lphpNext) ;
         if(byte == '"')  
         {
            *(*lphpNext) = '\0' ;  // null terminate string.
            return(hpCur);   // lphpNext points to end of string.
         }    
         if(!byte) 
         {
            errorMsg(EXTRACTQUOTEDLITERAL, ERR_UNEXPECTED_NULL);
            errorString(hpCur);
            return(NULL);  //  illegal option
         }
         (*lphpNext)++ ;
      }
   }
   else if (symbolOK  &&  byte == '^')  //  symbol token encountered
   {
      WORD  i;
      LPBYTE   lpBuf ;
      BYTE  buffer[45];  // enough to handle any option keyword like 
                        //  a symbol name.

      hpCur = extractStringValue(lphpNext);  // extract entire string
      hstrcpyn((HPBYTE)buffer, hpCur, 44);   // copy string to local buffer.
      lpBuf = buffer;  
      lpBuf = extractStringToken(&lpBuf);  // extracting individual tokens.
      //  lpBuf  points to the encountered symbolName
      //  lphpNext  points to end of string value.
      for(i = 0 ; i < numKeywords  ; i++)
      {
         if( lpKeyEntry[i].keyword == SYMBOLVALUE )
         {
            if(!hstrcmp((HPBYTE)lpBuf, lpKeyEntry[i].option))  
            {     // symbolName matches entry in Table.
               return(lpKeyEntry[i].value);   //  may return a NULL
            }
         }
      }
      errorMsg(EXTRACTQUOTEDLITERAL, ERR_UNDEFINED_SYMBOL);
      errorString(buffer);
      return(NULL);  //  no definition found.
   }
   // if(first byte is neither '"' nor '^')
   errorMsg(EXTRACTQUOTEDLITERAL, ERR_EXPCTD_QUOTED_VAL);
   errorString(*lphpNext);
   return(NULL);  //  no valid invocation value found.
}


/* hstrcmp() - compare two NULL terminated strings
   return 0 if match, non-zero otherwise.
   handles huge pointers.  */

WORD  FAR  PASCAL  hstrcmp(HPBYTE  str1, HPBYTE  str2) 
{
   while(*str1  ||  *str2)
   {
      if(*str1++  !=  *str2++)
         return(1);
   }
   return(0);

}

void  FAR  PASCAL  hstrcpyn(
HPBYTE  hpDest,
HPBYTE  hpSrc,
long    count )
{
   while(*hpSrc  &&  count--)
      *hpDest++ = *hpSrc++ ;

   *hpDest = '\0' ;
   return;
}

/*  - parses remainder of PPD entry referenced 
   by each element in KeyEntry table.  Obtains pointer to option Keyword
   and NULL terminated string representing contents of string value,
   or Invocation Value or untranslated Quoted String.
   A NULL for either the option or the value indicates object did
   not exist or a parsing error occured. (eg value began with quote
   but NULL was encountered before closing double quote was encountered!).
   disables any keyword missing an option keyword.  

   Special treatment to remove keywords that are actually part of
   a quoted string.

   Note this is the only time the huge buffer is ever modified
   and even then its only to NULL terminate option and value strings.
*/


void  NEAR  PASCAL  fillKeyEntries(
LPKEYENTRY  lpKeyEntry,
WORD        numKeywords )  // hpBuf is unnecessary! the entry table has all pointers!
{
   WORD  i ;
   HPBYTE  hpLastQuote = NULL;  // tracks position of last closing quote

   for(i = 0 ; i < numKeywords ; i++)
   {
      HPBYTE  hpNext ;
      
      if( lpKeyEntry[i].keyword == SYMBOLVALUE   ||
            lpKeyEntry[i].keyword == GARBAGE )
         continue ;  // ignore these.

      if(hpLastQuote  &&  (long)(hpLastQuote - lpKeyEntry[i].option) > 0)
      {
         lpKeyEntry[i].keyword = GARBAGE ;
         continue ;  // ignore these entries since they reside 
      }              //         within previous quoted string.
      switch(lpKeyEntry[i].termination)
      {

         case   NEWLINE:
            lpKeyEntry[i].option = NULL ;
            lpKeyEntry[i].value  = NULL ;
            lpKeyEntry[i].optionTrans = NULL ;
            break;
         case   COLON:  //  no option keyword
            hpLastQuote = lpKeyEntry[i].option ;
            lpKeyEntry[i].value =  extractValue(&hpLastQuote, 
                                       &(lpKeyEntry[i].bValueQuoted)) ;
            lpKeyEntry[i].option = NULL ;
            lpKeyEntry[i].optionTrans = NULL ;
            break;
         case   WHITESPACE:  //  both option keyword and value expected.

            hpNext =  lpKeyEntry[i].option ;
            lpKeyEntry[i].option = extractOption(&hpNext, FALSE, 
                                                &(lpKeyEntry[i].optionTrans)) ;
            if(!lpKeyEntry[i].option)   //  NULL indicates faulty option.
            {
               lpKeyEntry[i].keyword = GARBAGE ;
               errorMsg(FILLKEYENTRIES, ERR_EXPCTD_OPTION_KEYWORD);
               break;
            }
            hpLastQuote = hpNext ;
            lpKeyEntry[i].value =  extractValue(&hpLastQuote, 
                                       &(lpKeyEntry[i].bValueQuoted)) ;
            break;
         default:
            lpKeyEntry[i].keyword = GARBAGE ;
            break;
      }
   }
}


HPBYTE  NEAR  PASCAL  extractValue(
LPHPBYTE    lphpToken ,  // returns pointer to end of string.
LPBOOL    lpbQuoted )  //  function sets to TRUE if value was quoted or Symbol
{

   *lpbQuoted = FALSE ;  // default assumption.

   while(**lphpToken == 32  ||  **lphpToken == 9)
      (*lphpToken)++ ;  //  skip all whitespace.

   if(**lphpToken == 10  ||  **lphpToken == 13  || **lphpToken == '\0')
      return(NULL);  // no value found!

   if(**lphpToken == '"'  ||  **lphpToken == '^')
   {
      *lpbQuoted = TRUE ;
      return (extractQuotedLiteral(lphpToken, TRUE)) ;
   }
   return (extractStringValue(lphpToken) ) ;
}



/*  WARNING: single use routine - replaces delimiter by NULL.
   lphpNext points to string terminator.
   return value points to start of string. (may be zero length)
   or set to NULL upon error.
*/
HPBYTE   NEAR  PASCAL  extractStringValue(
LPHPBYTE    lphpNext)  //  initially points to string value, later points
                     // to end of string value.
{
   HPBYTE  hpCur ;
   BYTE    byte  ;

   while(1) //  filter out leading whitespace and illegal chars.
   {
      byte = *(*lphpNext) ;

      if(byte != 9  &&  byte != 32)  //  not  whitespace
         break;
      (*lphpNext)++ ;
   }
   hpCur = *lphpNext ;
   
   while(1) //  stop when newline or / is encountered.
   {
      byte = *(*lphpNext) ;
      if(byte == 10  ||  byte == 13  ||  byte == '/'  ||  byte == 0)
      {
         *(*lphpNext) = '\0' ;  // null terminate current token.
         return(hpCur);
      }
      (*lphpNext)++ ;
   }
}


/*  extracts individual whitespace delimited tokens from a multitoken
   NULL terminated string.   NOTE: for 3 reasons this routine 
   does not operate on the huge buffer:
   (a) does not recognize full range of possible string terminators
   (b) function is destructive - thus will destroy the original.
   (c) designed to handle far pointers not huge.
*/
LPBYTE  FAR  PASCAL  extractStringToken(
LPLPBYTE    lplpNext )  //  initially points to token, later points
                     // to next token, or NULL if none found.
                     //  note:  return string may be zero length!
{
   LPBYTE  lpCur ;
   BYTE    byte  ;

   while(1) //  filter out leading whitespace and illegal chars.
   {
      byte = *(*lplpNext) ;

      if(byte != 9  &&  byte != 32  &&  byte != 10  && byte != 13 )
         break;        //  not  whitespace
      (*lplpNext)++ ;
   }
   lpCur = *lplpNext ;
   
   while(1) //  stop when NULL or whitespace is encountered
   {
      byte = *(*lplpNext) ;
      if(byte == 0)
      {
         *lplpNext = NULL ;  //  no more tokens in string.
         return(lpCur);
      }
      else if(byte == 9  ||  byte == 32  ||  byte == 10  || byte == 13 )
      {        //  whitespace delimiters
         *(*lplpNext) = '\0' ;  // null terminate current token.
         (*lplpNext)++ ;    //  point to next token.
         return(lpCur);
      }
      (*lplpNext)++ ;
   }
}


long  FAR  PASCAL  addTransStringToTable(
HPBYTE   hpStr)   //  translation source string
{
   extern  BYTE  ISOLatin1Table[256];           /* defined in parse4.c  */
   long   lstringRef ;
   STRINGREF  stringRef ;

   stringRef.dword = lstringRef = addQuotedStringToTable(hpStr, NULL, 0) ;
   if( LangEncoding == ISOLATIN1 )
      EncodeString(ISOLatin1Table, stringRef) ;

   return(lstringRef) ;
}


/*  reads in a NULL terminated string from hpStr and translates
//  any <Hex substrings> encountered.
//
//  functions in two ways: if lpBuf is not NULL
//  writes translated string to lpBuf. But never exceeds bufsiz bytes
//  always truncates string with NULL byte even
//  if string would otherwise overrun bufsiz.
//  returns in HIWORD, number of bytes written to lpBuf including NULL.
//
//  ----  or  if  lpBuf  is  NULL ---
//
//  the recipient of the translated string is the string table.
//  In this case no NULL termination is supplied.
//  returns offset (loword) to string table and num bytes written (hiword).
//  this function parses hexsubstrings and writes the parsed string
//  to the stringtable.

   possible errors: string table could get full.

*/
long  FAR  PASCAL  addQuotedStringToTable(
HPBYTE   hpStr,   //  source string
LPBYTE   lpBuf,   //  possible destination
WORD     bufSiz)  //  size of lpBuf if any.
{
   WORD    i,   StartOffset;   //  i counts num of bytes added to table.
   BOOL    bHexMode = FALSE, bUpdateStringPtr = FALSE;
   BYTE    lowNibble, highNibble;

   extern  LPBYTE   lpStringPtr ;

   if(!hpStr )   // check for NULL source
      return(0L) ;

   //  lpStringPtr is a global which points to location to add a new string.
   //  this makes constantly passing in lpStringTable unnecessary.
   if(!lpBuf)
   {
      if(bSTOverflow)
         return(0L) ;  //  sorry, no more strings can be stored.

      lpBuf = lpStringPtr;
      bufSiz = (WORD)(-(short)(OFFSETOF(lpBuf) + 1)) ;  // bytes remaining in buffer.
            // Adding 1 prevents and offset of zero from signifying no room.
            // should be equivalent to bufSiz = 64k - (WORD)lpBuf ;
      bUpdateStringPtr = TRUE ;
   }


   StartOffset = OFFSETOF(lpBuf) ;

   for(i = 0 ; *hpStr  &&  (i+2) < bufSiz ; )
   {
      if(bHexMode)
      {
         if(*hpStr == '>')  // end of Hexstring
         {
            hpStr++ ;
            bHexMode = FALSE ;
         }
         else
         {
            lowNibble = ReadHexDigit(*hpStr);   // returns 0-15 or 0xFF for error
            hpStr++ ;
            if(lowNibble != 0xFF)  // we have a valid hex digit
            {
               if(highNibble != 0xFF)  //  previous hex digit exists.
               {
                  *lpBuf++  = highNibble | lowNibble ;
                  i++ ;
                  highNibble = 0xFF;  //  ready to form new hex value.
               }
               else
                  highNibble = lowNibble << 4 ;  // init highNibble.
            }  // just ignore any invalid non-hex chars
         }
      }
      else
      {
         if(*hpStr == '<')  // start of Hexstring
         {
            hpStr++ ;
            bHexMode = TRUE ;
            highNibble = 0xFF;  //  no prevs hex value.
         }
         else
         {
            *lpBuf++ = *hpStr++ ;
            i++ ;
         }
      }
   }
   *lpBuf++ = '\0' ;  // NULL terminate.  

   if(bUpdateStringPtr)
   {
      if((i+2) >= bufSiz)
      {
         bSTOverflow = TRUE ;
         errorMsg(ADDQUOTEDSTRINGTOTABLE, ERR_STRINGTABLE_OVERFLOW);

         return(0L) ;  // nothing to add.
      }
      lpStringPtr = lpBuf ;
   }
   return(MAKELONG(StartOffset, i)) ;
}

/*  reads in a NULL terminated string from hpStr and translates
//  any <Hex substrings> encountered.
//
//  functions in two ways: if lpBuf is not NULL
//  writes translated string to lpBuf. But never exceeds bufsiz bytes
//  always truncates string with NULL byte even
//  if string would otherwise overrun bufsiz.
//  returns in HIWORD, number of bytes written to lpBuf including NULL.
//
//  ----  or  if  lpBuf  is  NULL ---
//
//  the recipient of the translated string is the string table.
//  In this case no NULL termination is supplied.
//  returns offset (loword) to string table and num bytes written (hiword).
//  this function parses hexsubstrings and writes the parsed string
//  to the stringtable.

   possible errors: string table could get full.

*/
long  FAR  PASCAL  addParenStringToTable(
HPBYTE   hpStr,   //  source string
LPBYTE   lpBuf,   //  possible destination
WORD     bufSiz)  //  size of lpBuf if any.
{
   WORD    i =0;
   WORD    StartOffset;   //  i counts num of bytes added to table.
   BOOL    bHexMode = FALSE, bUpdateStringPtr = FALSE;
   BYTE    lowNibble, highNibble;

   extern  LPBYTE   lpStringPtr ;

   if(!hpStr )   // check for NULL source
      return(0L) ;

   // search for left Paren
   while ((*hpStr != '(') && hpStr)
   {
     hpStr++;
   }

   if (!hpStr)     //didn't find left paren.
      return(0L) ;
   else
       hpStr++;    //increment pass the paren.

   //  lpStringPtr is a global which points to location to add a new string.
   //  this makes constantly passing in lpStringTable unnecessary.
   if(!lpBuf)
   {
      if(bSTOverflow)
         return(0L) ;  //  sorry, no more strings can be stored.

      lpBuf = lpStringPtr;
      bufSiz = (WORD)(-(short)(OFFSETOF(lpBuf) + 1)) ;  // bytes remaining in buffer.
            // Adding 1 prevents and offset of zero from signifying no room.
            // should be equivalent to bufSiz = 64k - (WORD)lpBuf ;
      bUpdateStringPtr = TRUE ;
   }


   StartOffset = OFFSETOF(lpBuf) ;

   while ((*hpStr != ')') && hpStr)
   {
      if(bHexMode)
      {
         if(*hpStr == '>')  // end of Hexstring
         {
            hpStr++ ;
            bHexMode = FALSE ;
         }
         else
         {
            lowNibble = ReadHexDigit(*hpStr);   // returns 0-15 or 0xFF for error
            hpStr++ ;
            if(lowNibble != 0xFF)  // we have a valid hex digit
            {
               if(highNibble != 0xFF)  //  previous hex digit exists.
               {
                  *lpBuf++  = highNibble | lowNibble ;
                  i++ ;
                  highNibble = 0xFF;  //  ready to form new hex value.
               }
               else
                  highNibble = lowNibble << 4 ;  // init highNibble.
            }  // just ignore any invalid non-hex chars
         }
      }
      else
      {
         if(*hpStr == '<')  // start of Hexstring
         {
            hpStr++ ;
            bHexMode = TRUE ;
            highNibble = 0xFF;  //  no prevs hex value.
         }
         else
         {
            *lpBuf++ = *hpStr++ ;
            i++ ;
         }
      }
   }
   *lpBuf++ = '\0' ;  // NULL terminate.  

   if(bUpdateStringPtr)
   {
      if((i+2) >= bufSiz)
      {
         bSTOverflow = TRUE ;
         errorMsg(ADDQUOTEDSTRINGTOTABLE, ERR_STRINGTABLE_OVERFLOW);

         return(0L) ;  // nothing to add.
      }
      lpStringPtr = lpBuf ;
   }
   return(MAKELONG(StartOffset, i)) ;
}


long  FAR  PASCAL  addStringToTable(
HPBYTE   hpStr)
//  returns offset (loword) to string table and num bytes written (hiword).
//  copies NULL terminated string to string table.
{
   WORD    i,   StartOffset;  
   extern  LPBYTE   lpStringPtr ;  //  points to uninitialized portion of table.
   //  lpStringPtr is a global which points to location to add a new string.
   //  this makes constantly passing in lpStringTable unnecessary.

   if(!hpStr  ||  !*hpStr  ||  bSTOverflow) 
      return(0L) ;  // nothing to add.

   StartOffset = OFFSETOF(lpStringPtr) ;  //  note, assume memory block starts
                                       //  at offset zero. or at least allocs
                                       //  return pointers with the same offsets

   for(i = 0 ; *hpStr ; i++)
   {
      if(StartOffset + 2 + i < StartOffset)
      {
         bSTOverflow = TRUE ;
         errorMsg(ADDSTRINGTOTABLE, ERR_STRINGTABLE_OVERFLOW);

         return(0L) ;  // nothing to add.
      }
      *lpStringPtr++ = *hpStr++ ;
   }
   *lpStringPtr++ = '\0' ;  // add null termination.

   return(MAKELONG(StartOffset, i)) ;
}

long  FAR  PASCAL  addBracedStringToTable(
HPBYTE   hpStr)
//  returns offset (loword) to string table and num bytes written (hiword).
//  copies NULL terminated string to string table.
{
   WORD    i = 0;
   WORD   StartOffset;  
   extern  LPBYTE   lpStringPtr ;  //  points to uninitialized portion of table.
   //  lpStringPtr is a global which points to location to add a new string.
   //  this makes constantly passing in lpStringTable unnecessary.

   if (hpStr)
   {
      while (*hpStr && *hpStr != '(')
         hpStr++;
   }
   if (*hpStr)
      hpStr++; //advance pass '('

   if(!hpStr  ||  !*hpStr  ||  bSTOverflow) 
      return(0L) ;  // nothing to add.

   StartOffset = OFFSETOF(lpStringPtr) ;  //  note, assume memory block starts
                                       //  at offset zero. or at least allocs
                                       //  return pointers with the same offsets

   while(*hpStr && *hpStr !=')') 
   {
      if(StartOffset + 2 + i < StartOffset)
      {
         bSTOverflow = TRUE ;
         errorMsg(ADDSTRINGTOTABLE, ERR_STRINGTABLE_OVERFLOW);

         return(0L) ;  // nothing to add.
      }
      *lpStringPtr++ = *hpStr++ ;
      i++;
   }
   *lpStringPtr++ = '\0' ;  // add null termination.

   return(MAKELONG(StartOffset, i)) ;
}

BYTE     NEAR  PASCAL  ReadHexDigit(
BYTE     hexDigit)  //  should be a value from '0' - '9' , 'a' - 'f'
                     //  or the value 0xFF is returned.
{
   if(hexDigit >= '0'  &&  hexDigit <= '9')
      return(hexDigit - '0');
   if(hexDigit >= 'a'  &&  hexDigit <= 'f')
      return(hexDigit - 'a' + 10);
   if(hexDigit >= 'A'  &&  hexDigit <= 'F')
      return(hexDigit - 'A' + 10);
   return(0xFF);    //  a value from 0x0 to 0xf or 0xFF if error
}




#if 0

/*  returns size of FontDir created - maybe zero if no fonts
   were referenced in the PPD file or if no PFM files were located
   don't interpret this as a fatal error   */

WORD  NEAR  PASCAL  makeFontSum(
LPBYTE      lpFontDir,
LPKEYENTRY  lpKeyEntry,
WORD        numKeywords,
LPBYTE      lpPFMindex)
{
   WORD  numFonts = 0, i, j,
         cbsize  ;
   LPBYTE   lpDefaultFont;  
   HPBYTE   hpCur;
   BYTE    Buffer[256], CurFont[256], PFMfileName[_MAX_PATH];


   cbsize = 2;  //  store  numFonts in the first two bytes of lpFontDir !

   //  parsing for the default font.

   for(i = 0 ; i < numKeywords ; i++ )
   {
      if(lpKeyEntry[i].keyword == DEFAULTFONT)
         break;
   }
   if(i < numKeywords  &&  (hpCur = lpKeyEntry[i].value))
   {
      if((lpKeyEntry[i].bValueQuoted))
      {
         errorMsg(MAKEFONTSUM, ERR_DEFAULTFONT);
         errorMsg(MAKEFONTSUM, ERR_EXPCTD_STRING_NOT_QUOTED);
         goto   parseFonts;   //  for non fatal errors
      }
      hstrcpyn(Buffer, hpCur, 255);
      lpDefaultFont = Buffer;
      lpDefaultFont = extractStringToken(&lpDefaultFont);
      if(!hstrcmp(lpDefaultFont, "Error"))
         goto   parseFonts;  // any Font gets to be the default.

      // call this to fill in PFMfileName
      if(!obtainPFMfiles(lpDefaultFont, PFMfileName, _MAX_PATH, lpPFMindex))
      {
         errorMsg(MAKEFONTSUM, ERR_CANT_FIND_ASSOC_PFM_FILE);
         goto   parseFonts;   //  for non fatal errors
      }
      cbsize += extractSummaryFromPFM(PFMfileName, lpFontDir+cbsize, &numFonts);
   }

parseFonts:
   
   for(i = 0 ; i < numKeywords ; i++ )
   {
      if(cbsize > 0xfe80)
      {
         errorMsg(MAKEFONTSUM, ERR_TOO_MANY_FONTS);
         break;         
      }

      if(lpKeyEntry[i].keyword != FONT)
         continue ;   //  should drop to end of for loop.
      if(!(hpCur = lpKeyEntry[i].option))  //  missing option keyword
         continue ;   //  should drop to end of for loop.
      hstrcpyn(CurFont, hpCur, 256);

      for(j = 0 ; j < i ; j++)  // has this font been processed previously?
      {
         HPBYTE   hpDoneFont;

         if(lpKeyEntry[j].keyword != FONT)
            continue ;   //  should drop to end of for loop.
         if(!(hpDoneFont = lpKeyEntry[j].option))
            continue ;   //  should drop to end of for loop.
         if(!hstrcmp(CurFont, hpDoneFont))
            break;
      }
      if(j < i ||  !hstrcmp(CurFont, lpDefaultFont))
         continue;   //  this entry has already been added.


      // call this to fill in PFMfileName
      if(!obtainPFMfiles(CurFont, PFMfileName, _MAX_PATH, lpPFMindex))
      {
         errorMsg(MAKEFONTSUM, ERR_CANT_FIND_ASSOC_PFM_FILE);
         continue;   //  next font!!!
      }
      cbsize += extractSummaryFromPFM(PFMfileName, lpFontDir+cbsize, &numFonts);
   }
   *(LPWORD)lpFontDir = numFonts;
   return(cbsize);
}


#endif

/*  this function accesses lpKeyEntry for OpenUI entries and
   initializes the NEWUIKEYWORDS table.   Each entry in the table
   will be unique and will not be a predefined keyword.
*/


DWORD  NEAR  PASCAL  CountNewUIKeywords(LPKEYENTRY  lpKeyEntry, 
         LPNEWUIKEYWORDS  lpNewUIKeywords)
{
   WORD   numNewUIKeywords = 0, nPrntrSticky = 0, nDocSticky = 0 , 
         i, j, optionkey;

   //  definition of  numKeywords:  num defined entries - lpKeyEntry[numKeywords]


   for(i = 0 ; i < numKeywords ; i++)
   {
      if (lpKeyEntry[i].keyword  ==  OPENUI)
      {
         optionkey = searchKeywordValue(lpKeyEntry[i].option);
         //  eliminate references to predefined keywords.

         if(optionkey != GARBAGE )
         {
            LPBYTE   lpBuf ;
            BYTE  buffer[45];  // enough to handle any valid OpenUI value string

            // check to eliminate redundant OpenUI statements
            // with the same option keyword.

            for(j = 0 ; j < numNewUIKeywords ; j++)
            {
               if(optionkey == lpNewUIKeywords[j].keyword)
                  goto  SKIPKEYWORD ;  // jump to end of for loop.
            }

            lpNewUIKeywords[numNewUIKeywords].keyword = optionkey ;
               // index to   lpMainKeyWordsTable[optionkey]
            lpNewUIKeywords[numNewUIKeywords].optionTrans = 
                                 lpKeyEntry[i].optionTrans ;


            // copy huge string to local buffer.
            hstrcpyn((HPBYTE)buffer, lpKeyEntry[i].value, 44);   
            lpBuf = buffer;  
            lpBuf = extractStringToken(&lpBuf);  // extracting UItype

            if(!lstrcmp("PickOne", lpBuf) )
               lpNewUIKeywords[numNewUIKeywords].UItype = PICKONE ;
            else if(!lstrcmp("Boolean", lpBuf) )
               lpNewUIKeywords[numNewUIKeywords].UItype = BOOLEAN ;
            else if(!lstrcmp("PickMany", lpBuf) )
               lpNewUIKeywords[numNewUIKeywords].UItype = PICKMANY ;
            else 
               lpNewUIKeywords[numNewUIKeywords].UItype = UI_NONE ;


            if(lpNewUIKeywords[numNewUIKeywords].UItype != UI_NONE)
            {
               if (lpKeyEntry[i].flags & GROUP_INSTALLABLE_OPTIONS)
               {
                  lpNewUIKeywords[numNewUIKeywords].PrntrSticky = TRUE ;
                  nPrntrSticky++ ;
               }
               else
               {
                  lpNewUIKeywords[numNewUIKeywords].PrntrSticky = FALSE ;
                  nDocSticky++ ;
               }
               numNewUIKeywords = nPrntrSticky + nDocSticky ;
            }
         }
      }
SKIPKEYWORD:   ;
   }

   return(MAKELONG(nPrntrSticky, nDocSticky));
                   //   LOword , HIword 
}



void  NEAR  PASCAL  initMainKeyWordsTable(void)
{
   // note:  we assume all indicies are unique and contiguous
   // starting from zero.

   lpMainKeyWordsTable[PPDVERSION].dword = addStringToTable("PPD-Adobe"); 
   lpMainKeyWordsTable[MODELNAME].dword = addStringToTable("ModelName");
   lpMainKeyWordsTable[NICKNAME].dword = addStringToTable("NickName");
   lpMainKeyWordsTable[SHORTNICKNAME].dword = addStringToTable("ShortNickName");
   lpMainKeyWordsTable[COLORDEVICE].dword = addStringToTable("ColorDevice");
   lpMainKeyWordsTable[LANGUAGELEVEL].dword = addStringToTable("LanguageLevel"),
   lpMainKeyWordsTable[PROTOCOLSS].dword = addStringToTable("Protocols");
   lpMainKeyWordsTable[FREEVM].dword = addStringToTable("FreeVM");
   lpMainKeyWordsTable[FONTCACHESIZE].dword = addStringToTable("FCacheSize");
   lpMainKeyWordsTable[ORDERDEPENDENCY].dword = addStringToTable("OrderDependency");
   lpMainKeyWordsTable[PAGESIZE].dword = addStringToTable("PageSize");
   lpMainKeyWordsTable[DEFAULTPAGESIZE].dword = addStringToTable("DefaultPageSize");
   lpMainKeyWordsTable[Q_PAGESIZE].dword = addStringToTable("?PageSize");
   lpMainKeyWordsTable[PAGEREGION].dword = addStringToTable("PageRegion");
   lpMainKeyWordsTable[IMAGEABLEAREA].dword = addStringToTable("ImageableArea");
   lpMainKeyWordsTable[PAPERDIMENSION].dword = addStringToTable("PaperDimension");
   lpMainKeyWordsTable[LANDSCAPEORIENTATION].dword = addStringToTable("LandscapeOrientation");
   lpMainKeyWordsTable[CUSTOMPAGESIZE].dword = addStringToTable("CustomPageSize");
   lpMainKeyWordsTable[PARAMCUSTOMPAGESIZE].dword = addStringToTable("ParamCustomPageSize");
   lpMainKeyWordsTable[MAXMEDIAWIDTH].dword = addStringToTable("MaxMediaWidth");
   lpMainKeyWordsTable[HWMARGINS].dword = addStringToTable("HWMargins");
   lpMainKeyWordsTable[MEDIATYPE].dword = addStringToTable("MediaType");
   lpMainKeyWordsTable[DEFAULTMEDIATYPE].dword = addStringToTable("DefaultMediaType");
   lpMainKeyWordsTable[Q_MEDIATYPE].dword = addStringToTable("?MediaType");
   lpMainKeyWordsTable[INPUTSLOT].dword = addStringToTable("InputSlot");
   lpMainKeyWordsTable[DEFAULTINPUTSLOT].dword = addStringToTable("DefaultInputSlot");
   lpMainKeyWordsTable[Q_INPUTSLOT].dword = addStringToTable("?InputSlot");
   lpMainKeyWordsTable[REQUIRESPAGEREGION].dword = addStringToTable("RequiresPageRegion");
   lpMainKeyWordsTable[OUTPUTBIN].dword = addStringToTable("OutputBin");
   lpMainKeyWordsTable[DEFAULTOUTPUTBIN].dword = addStringToTable("DefaultOutputBin");
   lpMainKeyWordsTable[Q_OUTPUTBIN].dword = addStringToTable("?OutputBin");
   lpMainKeyWordsTable[MANUALFEED].dword = addStringToTable("ManualFeed");
   lpMainKeyWordsTable[DUPLEX].dword = addStringToTable("Duplex");
   lpMainKeyWordsTable[Q_DUPLEX].dword = addStringToTable("?Duplex");
   lpMainKeyWordsTable[DEFAULTDUPLEX].dword = addStringToTable("DefaultDuplex");
   lpMainKeyWordsTable[MIRRORPRINT].dword = addStringToTable("MirrorPrint");
//   lpMainKeyWordsTable[NEGATIVEPRINT].dword = addStringToTable("NegativePrint");
   lpMainKeyWordsTable[DEFAULTRESOLUTION].dword = addStringToTable("DefaultResolution");
   lpMainKeyWordsTable[RESOLUTION].dword = addStringToTable("Resolution");
   lpMainKeyWordsTable[Q_RESOLUTION].dword = addStringToTable("?Resolution");
   lpMainKeyWordsTable[SETRESOLUTION].dword = addStringToTable("SetResolution");
   lpMainKeyWordsTable[SCREENFREQ].dword = addStringToTable("ScreenFreq");
   lpMainKeyWordsTable[SCREENANGLE].dword = addStringToTable("ScreenAngle");
   lpMainKeyWordsTable[SCREENFREQRES].dword = addStringToTable("ResScreenFreq");
   lpMainKeyWordsTable[SCREENANGLERES].dword = addStringToTable("ResScreenAngle");
   lpMainKeyWordsTable[FONT].dword = addStringToTable("Font");
   lpMainKeyWordsTable[DEFAULTFONT].dword = addStringToTable("DefaultFont");
   lpMainKeyWordsTable[PASSWORD].dword = addStringToTable("Password");
   lpMainKeyWordsTable[EXITSERVER].dword = addStringToTable("ExitServer");
   lpMainKeyWordsTable[SYMBOLVALUE].dword = addStringToTable("SymbolValue");   //  macrosubstitution
   lpMainKeyWordsTable[OPENUI].dword = addStringToTable("OpenUI");  // extensible keywords
   lpMainKeyWordsTable[OPENGROUP].dword = addStringToTable("OpenGroup");  // extensible keywords
   lpMainKeyWordsTable[CLOSEGROUP].dword = addStringToTable("CloseGroup");  // extensible keywords
   lpMainKeyWordsTable[UICONSTRAINT].dword = addStringToTable("UIConstraints");
   lpMainKeyWordsTable[TTRASTERIZER].dword = addStringToTable("TTRasterizer");  //  handles Native TrueType, Type 42 fonts
   lpMainKeyWordsTable[JCLBEGIN].dword = addStringToTable("JCLBegin");  
   lpMainKeyWordsTable[JCLTOPS].dword = addStringToTable("JCLToPSInterpreter");
   lpMainKeyWordsTable[JCLEND].dword = addStringToTable("JCLEnd");  

   lpMainKeyWordsTable[JCLOPENUI].dword = addStringToTable("JCLOpenUI");  
   lpMainKeyWordsTable[JCLCLOSEUI].dword = addStringToTable("JCLCloseUI");  
   lpMainKeyWordsTable[DEFAULTJCLRESOLUTION].dword = addStringToTable("DefaultJCLResolution");
   lpMainKeyWordsTable[JCLRESOLUTION].dword = addStringToTable("JCLResolution");  
   lpMainKeyWordsTable[Q_JCLRESOLUTION].dword = addStringToTable("?JCLResolution");  
   lpMainKeyWordsTable[INSTALLEDMEMORY].dword = addStringToTable("InstalledMemory");  
   lpMainKeyWordsTable[DEFAULTINSTALLEDMEMORY].dword = addStringToTable("DefaultInstalledMemory");
   lpMainKeyWordsTable[VMOPTION].dword = addStringToTable("VMOption");  
   lpMainKeyWordsTable[LANGUAGEENCODING].dword = addStringToTable("LanguageEncoding");  
   lpMainKeyWordsTable[PCFILENAME].dword = addStringToTable("PCFileName");  
   lpMainKeyWordsTable[PRODUCT].dword = addStringToTable("Product");  
   lpMainKeyWordsTable[PSVERSION].dword = addStringToTable("PSVersion");  
   lpMainKeyWordsTable[PATCHFILE].dword = addStringToTable("PatchFile");  
   lpMainKeyWordsTable[JOBPATCHFILE].dword = addStringToTable("JobPatchFile");  
#ifdef Adobe_Driver
   lpMainKeyWordsTable[FAXSUPPORT].dword = addStringToTable("FaxSupport");  
   lpMainKeyWordsTable[COLLATE].dword = addStringToTable("Collate");  
   lpMainKeyWordsTable[Q_COLLATE].dword = addStringToTable("?Collate");  
   lpMainKeyWordsTable[DEFAULTCOLLATE].dword = addStringToTable("DefaultCollate");  
   lpMainKeyWordsTable[OUTPUTORDER].dword = addStringToTable("OutputOrder"); 
   lpMainKeyWordsTable[DEFAULTOUTPUTORDER].dword = addStringToTable("DefaultOutputOrder"); 
   lpMainKeyWordsTable[Q_OUTPUTORDER].dword = addStringToTable("?OutputOrder");  
   lpMainKeyWordsTable[ADHASEURO].dword = addStringToTable("ADHasEuro");  
//#ifdef ADOBE_WEB
   lpMainKeyWordsTable[WEBURL].dword = addStringToTable("WebURL");  
   lpMainKeyWordsTable[WEBSERVER].dword = addStringToTable("WebServer");  
   lpMainKeyWordsTable[WEBPORT].dword = addStringToTable("WebPort");  
   lpMainKeyWordsTable[WEBPRINTER].dword = addStringToTable("WebPrinter");  
   lpMainKeyWordsTable[WEBPRINTERNAME].dword = addStringToTable("WebPrinterName");  
   lpMainKeyWordsTable[WEBCOMMPROTOCOL].dword = addStringToTable("WebCommProtocol");  
   lpMainKeyWordsTable[WEBPPD].dword = addStringToTable("WebPPD");  
   lpMainKeyWordsTable[WEBNOTICE].dword = addStringToTable("WebNotice");  
//#endif
#endif
   lpMainKeyWordsTable[ADDEFAULTPROTOCOL].dword = addStringToTable("ADDefaultProtocol");  

//  ----- the following are Microsoft specific keywords ----
   lpMainKeyWordsTable[TRUEIMAGEDEVICE].dword = addStringToTable("TrueImageDevice");  //  has trueimage extensions
// Added for ICM support (fix bug 118385).  jjia.  10/18/95
   lpMainKeyWordsTable[MANUFACTURER].dword = addStringToTable("Manufacturer");
   lpMainKeyWordsTable[JOBTIMEOUT].dword = addStringToTable("SuggestedJobTimeout");
   lpMainKeyWordsTable[WAITTIMEOUT].dword = addStringToTable("SuggestedWaitTimeout");
   lpMainKeyWordsTable[PRINTPSERRORS].dword = addStringToTable("PrintPSErrors");

   numMainKeyWords = ENDOFLIST;
}

// OEMPLUGI begin

void FAR PASCAL initMainKeyWordsTableStub(void)
{
  initMainKeyWordsTable();
}

// OEMPLUGI end



/*
 *  Crc - 32 BIT ANSI X3.66 CRC checksum files
 *
 *
 * Copyright (C) 1986 Gary S. Brown.  You may use this program, or
 * code or tables extracted from it, as desired without restriction.
 */



static DWORD  PARSE2SEG  crc_32_tab[] = { /* CRC polynomial 0xedb88320 */
0x00000000, 0x77073096, 0xee0e612c, 0x990951ba, 0x076dc419, 0x706af48f, 0xe963a535, 0x9e6495a3,
0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988, 0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91,
0x1db71064, 0x6ab020f2, 0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9, 0xfa0f3d63, 0x8d080df5,
0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172, 0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b,
0x35b5a8fa, 0x42b2986c, 0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423, 0xcfba9599, 0xb8bda50f,
0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924, 0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d,
0x76dc4190, 0x01db7106, 0x98d220bc, 0xefd5102a, 0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433,
0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x086d3d2d, 0x91646c97, 0xe6635c01,
0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e, 0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457,
0x65b0d9c6, 0x12b7e950, 0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7, 0xa4d1c46d, 0xd3d6f4fb,
0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0, 0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9,
0x5005713c, 0x270241aa, 0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81, 0xb7bd5c3b, 0xc0ba6cad,
0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a, 0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683,
0xe3630b12, 0x94643b84, 0x0d6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1,
0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb, 0x196c3671, 0x6e6b06e7,
0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc, 0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5,
0xd6d6a3e8, 0xa1d1937e, 0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55, 0x316e8eef, 0x4669be79,
0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236, 0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f,
0xc5ba3bbe, 0xb2bd0b28, 0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a, 0x9c0906a9, 0xeb0e363f, 0x72076785, 0x05005713,
0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38, 0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21,
0x86d3d2d4, 0xf1d4e242, 0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69, 0x616bffd3, 0x166ccf45,
0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2, 0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db,
0xaed16a4a, 0xd9d65adc, 0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693, 0x54de5729, 0x23d967bf,
0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94, 0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d
};



DWORD  FAR  PASCAL  crc32(HPBYTE buff, DWORD  length)
{
  DWORD  crc, charcnt;
  BYTE    c;


  crc = 0xFFFFFFFF;
  charcnt = 0;

  for (charcnt = 0 ; charcnt < length ; charcnt++)
  {
    c = buff[charcnt] ;
    crc = crc_32_tab[(crc ^ c) & 0xff] ^ (crc >> 8);
  }

  return crc;
}


