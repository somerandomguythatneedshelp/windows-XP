/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ENUMOBJ.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for object enumeration.   */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_ENUMSEG)


enum{
        COLOR_begin,
        COLOR_black=COLOR_begin,
        COLOR_white,
        COLOR_endmono,
        COLOR_red=COLOR_endmono,
        COLOR_green,
        COLOR_blue,
        COLOR_yellow,
        COLOR_magenta,
        COLOR_cyan,
        COLOR_end
};

//the order here is recommended in the DDK documentation
//
COLORREF ENUMSEG color[8]={
        RGB(0x00,0x00,0x00),//black
        RGB(0xff,0xff,0xff),//white
        RGB(0xff,0x00,0x00),//red
        RGB(0x00,0xff,0x00),//green
        RGB(0x00,0x00,0xff),//blue
        RGB(0xff,0xff,0x00),//yellow
        RGB(0xff,0x00,0xff),//magenta
        RGB(0x00,0xff,0xff) //cyan
};

#define PENWIDTH_default 1

short FAR PASCAL dmEnumObj(LP,short,FARPROC,LP);

/**************************************************************************
*                       EnumPen
*  function:
*       Enumerates pens by calling the callback function passed in.
*  called:
*       short NEAR PASCAL EnumPen(LP lpDevice, FARPROC lpCallbackProc,
*                                  LP lpClientData)
*  parameters:
*       LP lpDevice -- PDEVICE pointer
*       FARPROC lpCallbackProc -- function pointer to callback
*       LP lpClientData -- client data to be passed to callback
*  returns:
*       1 for no objects (or error), else last return from callback
**************************************************************************/

short NEAR PASCAL EnumPen(LP lpDevice,FARPROC lpCallbackProc,LP lpClientData)
{
   LPPDEVICE lppd=(LPPDEVICE)lpDevice;
   LOGPEN logPen;  //logical pen used to hold data to return to client
   short i;
   short sRC = 1 ;
   int lastcolor;

   logPen.lopnWidth.x=logPen.lopnWidth.y=PENWIDTH_default;

   if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR )
   {
        lastcolor = COLOR_end;
   }
   else
   {
        lastcolor = COLOR_endmono;
   }

   // for each of the pen styles...
   //
   logPen.lopnStyle=PENSTYLE_solid;
   while ((logPen.lopnStyle < PENSTYLE_end) && (sRC != 0))
   {
      // for each of the colors...
      //
      i = COLOR_begin;
      while ((i < lastcolor) && (sRC != 0))
      {
         logPen.lopnColor=color[i];
         sRC = (*lpCallbackProc)((LPLOGPEN)&logPen,lpClientData) ;

         i++;
      }
      logPen.lopnStyle++;
   }

   return(sRC);
}

/**************************************************************************
*                       EnumBrush
*  function:
*       Enumerates brushes by calling the callback function passed in.
*  called:
*       short NEAR PASCAL EnumBrush(LP lpDevice, FARPROC lpCallbackProc,
*                                  LP lpClientData)
*  parameters:
*       LP lpDevice -- PDEVICE pointer
*       FARPROC lpCallbackProc -- function pointer to callback
*       LP lpClientData -- client data to be passed to callback
*  returns:
*       1 for no objects (or error), else last return from callback
**************************************************************************/

short NEAR PASCAL EnumBrush(LP lpDevice,FARPROC lpCallbackProc,LP lpClientData)
{
   LPPDEVICE lppd=(LPPDEVICE)lpDevice;
   LOGBRUSH logBrush;      //logical brush used to hold data to return to client
   short i;
   short sRC = 1;
   int lastcolor;

   // hollow brush first...
   //
   logBrush.lbStyle=BS_HOLLOW;
   logBrush.lbColor=RGB_WHITE;
   logBrush.lbBkColor=RGB_WHITE;
   logBrush.lbHatch=0;
   sRC = (*lpCallbackProc)((LPLOGBRUSH)&logBrush,lpClientData) ;


   if (sRC != 0) //Callback func returns 0 if it wants us to quit enumerating.
   {
      // hatch brushes in black and white only, I guess this
      // is because there would be too many combinations if
      // all possible color combinations were enumerated.
      //
      logBrush.lbStyle=BS_HATCHED;
      logBrush.lbColor=RGB_BLACK;
      logBrush.lbBkColor=RGB_WHITE;

      logBrush.lbHatch=BRUSHHATCH_horiz;
      while ((logBrush.lbHatch < BRUSHHATCH_end) && (sRC != 0))
      {
         sRC = (*lpCallbackProc)((LPLOGBRUSH)&logBrush,lpClientData) ;
         logBrush.lbHatch++;
      }
   } //if (sRC)

   if (sRC != 0) //Callback func returns 0 if it wants us to quit enumerating.
   {
      // now, all the solid brushes...all colors
      //
      logBrush.lbStyle=BS_SOLID;

      if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR )
      {
         lastcolor = COLOR_end;
      }
      else
      {
           lastcolor = COLOR_endmono;
      }

      i = COLOR_begin;
      while ((i < lastcolor) && (sRC != 0))
      {
         logBrush.lbColor=color[i];
         sRC = (*lpCallbackProc)((LPLOGPEN)&logBrush,lpClientData) ;

         i ++;
      }
   } //if (sRC)

   return(sRC);
}

/**************************************************************************
*                       EnumObj
*  function:
*       EnumObj entry point.
*  prototype:
*       short FAR PASCAL EnumObj(LP lpDevice,short sStyle,
*                                FARPROC lpCallbackProc, LP lpClientData)
*  parameters:
*       LP lpDevice -- PDEVICE pointer
*       short sStyle -- one of OBJ_PEN or OBJ_BRUSH
*       FARPROC lpCallbackProc -- function pointer to callback
*       LP lpClientData -- client data to be passed to callback
*  returns:
*       1 for no objects (or error), else last return from callback
**************************************************************************/

short _loadds FAR PASCAL EnumObj(LP lpDevice,short sStyle,FARPROC lpCallbackProc,
                                 LP lpClientData)
{
   LPPDEVICE lppd=(LPPDEVICE)lpDevice;
   short sMagic=*((LPSHORT)lpDevice);
   short sRC = TRUE ; //This returned if callback never returns 0, or if error.


   //if this call to a memory bitmap?
   if(!sMagic)
   {
      sRC = dmEnumObj(lpDevice,sStyle,lpCallbackProc,lpClientData);
   }
   //...or a call to someone else (how does this occur?)
   else if(sMagic!=LUCAS)
   {
        sRC = 1 ;
   }
   else
   {
      switch(sStyle)
      {
         case OBJ_PEN:
                  sRC = EnumPen(lpDevice,lpCallbackProc,lpClientData);
         break;
         case OBJ_BRUSH:
                  sRC = EnumBrush(lpDevice,lpCallbackProc,lpClientData);
         break;
         default:
         //bad style return...essentially can't enumerate
         //...how does this happen?
         sRC = 1 ;
         break;
      }
   }
   if (sRC)  //Force return value to be BOOLEAN.
   {
      sRC = 1;
   }
   return(sRC);
}
