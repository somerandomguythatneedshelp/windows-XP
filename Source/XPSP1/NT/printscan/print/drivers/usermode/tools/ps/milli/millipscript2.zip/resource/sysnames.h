/*
 * systemnames.h
 *
 * Copyright (c) 1989-1991 Adobe Systems Incorporated.
 * All rights reserved.
 *
 * This file may be freely copied and redistributed as long as:
 *   1) This entire notice continues to be included in the file, 
 *   2) If the file has been modified in any way, a notice of such
 *      modification is conspicuously indicated.
 *
 * PostScript, Display PostScript, and Adobe are registered trademarks of
 * Adobe Systems Incorporated.
 * 
 * ************************************************************************
 * THE INFORMATION BELOW IS FURNISHED AS IS, IS SUBJECT TO CHANGE WITHOUT
 * NOTICE, AND SHOULD NOT BE CONSTRUED AS A COMMITMENT BY ADOBE SYSTEMS
 * INCORPORATED. ADOBE SYSTEMS INCORPORATED ASSUMES NO RESPONSIBILITY OR 
 * LIABILITY FOR ANY ERRORS OR INACCURACIES, MAKES NO WARRANTY OF ANY 
 * KIND (EXPRESS, IMPLIED OR STATUTORY) WITH RESPECT TO THIS INFORMATION, 
 * AND EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR PARTICULAR PURPOSES AND NONINFINGEMENT OF THIRD PARTY RIGHTS.
 * ************************************************************************
 */
	 {"abs",0}
	,{"Courier",199}
	,{"Courier-Bold",200}
	,{"Courier-BoldOblique",201}
	,{"Courier-Oblique",202}
	,{"FontDirectory",197}
	,{"Helvetica",203}
	,{"Helvetica-Bold",204}
	,{"Helvetica-BoldOblique",205}
	,{"Helvetica-Oblique",206}
	,{"SharedFontDirectory",198}
	,{"Symbol",207}
	,{"Times-Bold",208}
	,{"Times-BoldItalic",209}
	,{"Times-Italic",210}
	,{"Times-Roman",211}
	,{"add",1}
	,{"aload",2}
	,{"anchorsearch",3}
	,{"and",4}
	,{"arc",5}
	,{"arcn",6}
	,{"arct",7}
	,{"arcto",8}
	,{"array",9}
	,{"ashow",10}
	,{"astore",11}
	,{"awidthshow",12}
	,{"begin",13}
	,{"bind",14}
	,{"bitshift",15}
	,{"ceiling",16}
	,{"charpath",17}
	,{"clear",18}
	,{"cleartomark",19}
	,{"clip",20}
	,{"clippath",21}
	,{"closepath",22}
	,{"concat",23}
	,{"concatmatrix",24}
	,{"copy",25}
	,{"count",26}
	,{"counttomark",27}
	,{"currentcmykcolor",28}
	,{"currentcolor",213}
	,{"currentcolorspace",214}
	,{"currentdash",29}
	,{"currentdict",30}
	,{"currentfile",31}
	,{"currentfont",32}
	,{"currentglobal",215}
	,{"currentgray",33}
	,{"currentgstate",34}
	,{"currenthsbcolor",35}
	,{"currentlinecap",36}
	,{"currentlinejoin",37}
	,{"currentlinewidth",38}
	,{"currentmatrix",39}
	,{"currentpoint",40}
	,{"currentrgbcolor",41}
	,{"currentshared",42}
	,{"curveto",43}
	,{"cvi",44}
	,{"cvlit",45}
	,{"cvn",46}
	,{"cvr",47}
	,{"cvrs",48}
	,{"cvs",49}
	,{"cvx",50}
	,{"def",51}
	,{"defineusername",52}
	,{"dict",53}
	,{"div",54}
	,{"dtransform",55}
	,{"dup",56}
	,{"end",57}
	,{"eoclip",58}
	,{"eofill",59}
	,{"eoviewclip",60}
	,{"eq",61}
	,{"exch",62}
	,{"exec",63}
	,{"execform",216}
	,{"execuserobject",212}
	,{"exit",64}
	,{"file",65}
	,{"fill",66}
	,{"filter",217}
	,{"findfont",67}
	,{"findresource",218}
	,{"flattenpath",68}
	,{"floor",69}
	,{"flush",70}
	,{"flushfile",71}
	,{"for",72}
	,{"forall",73}
	,{"ge",74}
	,{"get",75}
	,{"getinterval",76}
	,{"globaldict",219}
	,{"grestore",77}
	,{"gsave",78}
	,{"gstate",79}
	,{"gt",80}
	,{"identmatrix",81}
	,{"idiv",82}
	,{"idtransform",83}
	,{"if",84}
	,{"ifelse",85}
	,{"image",86}
	,{"imagemask",87}
	,{"index",88}
	,{"ineofill",89}
	,{"infill",90}
	,{"initviewclip",91}
	,{"inueofill",92}
	,{"inufill",93}
	,{"invertmatrix",94}
	,{"itransform",95}
	,{"known",96}
	,{"le",97}
	,{"length",98}
	,{"lineto",99}
	,{"load",100}
	,{"loop",101}
	,{"lt",102}
	,{"makefont",103}
	,{"makepattern",220}
	,{"matrix",104}
	,{"maxlength",105}
	,{"mod",106}
	,{"moveto",107}
	,{"mul",108}
	,{"ne",109}
	,{"neg",110}
	,{"newpath",111}
	,{"not",112}
	,{"null",113}
	,{"or",114}
	,{"pathbbox",115}
	,{"pathforall",116}
	,{"pop",117}
	,{"print",118}
	,{"printobject",119}
	,{"put",120}
	,{"putinterval",121}
	,{"rcurveto",122}
	,{"read",123}
	,{"readhexstring",124}
	,{"readline",125}
	,{"readstring",126}
	,{"rectclip",127}
	,{"rectfill",128}
	,{"rectstroke",129}
	,{"rectviewclip",130}
	,{"repeat",131}
	,{"restore",132}
	,{"rlineto",133}
	,{"rmoveto",134}
	,{"roll",135}
	,{"rotate",136}
	,{"round",137}
	,{"save",138}
	,{"scale",139}
	,{"scalefont",140}
	,{"search",141}
	,{"selectfont",142}
	,{"setbbox",143}
	,{"setcachedevice",144}
	,{"setcachedevice2",145}
	,{"setcharwidth",146}
	,{"setcmykcolor",147}
	,{"setcolor",221}
	,{"setcolorspace",222}
	,{"setdash",148}
	,{"setfont",149}
	,{"setglobal",223}
	,{"setgray",150}
	,{"setgstate",151}
	,{"sethsbcolor",152}
	,{"setlinecap",153}
	,{"setlinejoin",154}
	,{"setlinewidth",155}
	,{"setmatrix",156}
	,{"setpagedevice",224}
	,{"setpattern",225}
	,{"setrgbcolor",157}
	,{"setshared",158}
	,{"shareddict",159}
	,{"show",160}
	,{"showpage",161}
	,{"stop",162}
	,{"stopped",163}
	,{"store",164}
	,{"string",165}
	,{"stringwidth",166}
	,{"stroke",167}
	,{"strokepath",168}
	,{"sub",169}
	,{"systemdict",170}
	,{"token",171}
	,{"transform",172}
	,{"translate",173}
	,{"truncate",174}
	,{"type",175}
	,{"uappend",176}
	,{"ucache",177}
	,{"ueofill",178}
	,{"ufill",179}
	,{"undef",180}
	,{"upath",181}
	,{"userdict",182}
	,{"ustroke",183}
	,{"viewclip",184}
	,{"viewclippath",185}
	,{"where",186}
	,{"widthshow",187}
	,{"write",188}
	,{"writehexstring",189}
	,{"writeobject",190}
	,{"writestring",191}
	,{"wtranslation",192}
	,{"xor",193}
	,{"xshow",194}
	,{"xyshow",195}
	,{"yshow",196}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
	,{(char *) NULL, (int) NULL}
