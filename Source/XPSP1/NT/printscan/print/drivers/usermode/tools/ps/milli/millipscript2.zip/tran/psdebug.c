/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: psdebug.c                                                    */
/*                                                                           */
/* Description: This module contains the function                            */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_DEBUGSEG)

#ifdef PSDEBUG


/***************************************************************************
*                                 PSDebugVMStatus
*
*  Purpose: Send a Postscript vmstatus to the printer
*
*  Parameters:
*      LPPDEVICE lppd - the printer device
*    
*  Returns: nothing
*                                                                           
***************************************************************************/
VOID PSDebugVMStatus(LPPDEVICE lppd)
{
   LPASCIIBINPTRS tempptr;

   if (lppd->doVMTracking <= 0 || !lppd->lpPSExtDevmode->dm2.bVM_Tracking)
      return;
   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   PSSendString(lppd, "vmstatus");
   (*tempptr->PSSendCRLF)(lppd);
} // PSDebugVMStatus

/***************************************************************************
*                                 PSDebugVMPrint
*
*  Purpose: Send a Postscript vmstatus to the printer and send Postscript
*           to print out the result at the lower left corner of the page.
*           Note this only works after the document page has been setup.
*
*  Parameters:
*      LPPDEVICE lppd - the printer device
*      LPSTR lpStr - option string to print with the vm status
*    
*  Returns: nothing
*                                                                           
***************************************************************************/
VOID PSDebugVMPrint(LPPDEVICE lppd, LPSTR lpStr)
{
   LPASCIIBINPTRS tempptr;
   static SHORT yPosition = 18;

   if (lppd->doVMTracking <= 0 || !lppd->lpPSExtDevmode->dm2.bVM_Tracking)
      return;

   if (!lpStr)
      {
      if (GetProfileInt("PscriptDebug", "VMPrint", 0) == 1)
         yPosition = 18;
      else
         yPosition = 0;
      return;
      }

   if (!yPosition)
      return;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   PSSendString(lppd, "vmstatus");
   (*tempptr->PSSendCRLF)(lppd);

   PSSendString(lppd, " /vmsave save def");
   (*tempptr->PSSendCRLF)(lppd);

   PSSendString(lppd, " /Times-BoldItalic findfont 6 scalefont setfont");
   (*tempptr->PSSendCRLF)(lppd);

   PSSendString(lppd, " /vmstr 20 string def");
   (*tempptr->PSSendCRLF)(lppd);

   PSSendString(lppd, " initmatrix 18 ");
   (*tempptr->PSSendShort)(lppd, yPosition);
   PSSendString(lppd, "moveto");
   (*tempptr->PSSendCRLF)(lppd);

   PortWrite(lppd, " ", 1);
   PortWrite(lppd, lpStr, lstrlen(lpStr));
   PortWrite(lppd, " show", 5);
   PortWrite(lppd, " ( EstUsed ) show ", 18);
   (*tempptr->PSSendFloat)(lppd, lppd->vmEstimateUsed);
   PortWrite(lppd, " vmstr cvs show", 15);
   PortWrite(lppd, " ( VMSelec ) show ", 18);
   (*tempptr->PSSendFloat)(lppd, lppd->lpPSExtDevmode->dm2.fUserVMSelection);
   PortWrite(lppd, " vmstr cvs show", 15);
   (*tempptr->PSSendCRLF)(lppd);

   PortWrite(lppd, " ( Max ) show", 13);
   PortWrite(lppd, " vmstr cvs show", 15);

   PortWrite(lppd, " ( Used ) show", 14);
   PortWrite(lppd, " vmstr cvs show", 15);

   PortWrite(lppd, " ( Level ) show", 15);
   PortWrite(lppd, " vmstr cvs show", 15);
   (*tempptr->PSSendCRLF)(lppd);

   PSSendString(lppd, " vmsave restore");
   (*tempptr->PSSendCRLF)(lppd);

   yPosition += 8;

} // PSDebugVMPrint

#endif // PSDEBUG

