/****************************************************************************
*                                                                            *
*  REGSETUP.C -                                                              *
*                                                                            *
*  Copyright (c) Adobe Systems, Inc., 1996.  All Rights Reserved.            *
*                                                                            *
*  Author     John Patterson                                                 *
*  Date       01/01/96                                                       *
*  Revision   0.1�1                                                          *
*  Last Modified: Alice Ng 3/28/96
*                                                                            *
****************************************************************************/

#include "generic.h"
#include <string.h>

#pragma code_seg(_UTILSSEG)

#define MAXXUID                 20
#define MAXPSNAME               64

#define TYPE42NAME_PS               6
#define TYPE42PLATFORM_WINDOWS      3
#define PLATFORM_APPLE              1
#define WINDOWS_UNICODE_ENCODING    1
#define APPLE_ROMAN_ENCODING        0
#define WINDOWS_LANG_ENGLISH        0x0409
#define APPLE_LANG_ENGLISH          0
#define LOCA_TABLE  (DWORD)(0x61636F6C)  /* *(LPDWORD)"loca" - this one is special*/
#define GLYF_TABLE  (DWORD)(0x66796C67)  /* *(LPDWORD)"glyf" - this one is also special*/
#define OS2_TABLE  (DWORD)(0x322F534F)   /* *(LPDWORD)"OS/2" - this one is also special*/
#define MAXP_TBL (DWORD)(0x7078616D)     //*(LPDWORD)"maxp" 
#define HEAD_TBL (DWORD)(0x64616568)     //*(LPDWORD)"head" 
#define CVT_TBL  (DWORD)(0x20747663)     //*(LPDWORD)"cvt "
#define FPGM_TBL (DWORD)(0x6D677066)     //*(LPDWORD)"fpgm"
#define HHEA_TBL (DWORD)(0x61656868)     //*(LPDWORD)"hhea"
#define HMTX_TBL (DWORD)(0x78746D68)     //*(LPDWORD)"hmtx"
#define PREP_TBL (DWORD)(0x70657270)     //*(LPDWORD)"prep"

//possible font attributes
#define BOLDPRESENT       0x01
#define ITALICPRESENT     0x02
#define BOLDITALICPRESENT 0x04
#define BASESTYLEPRESENT   0x08

#define NAME_TBL 0x656D616e //'name' table in TTF file.

int WINAPI EnumFontFamiliesEx(HDC, LPLOGFONT, FONTENUMPROC, LPARAM,DWORD);

//The following should be in the string table.
char UTILSSEG szOutiBold []       = "-Bold" ;
char UTILSSEG szOutiItalic []     = "-Italic" ;
char UTILSSEG szOutiBoldItalic [] = "-BoldItalic" ;
char UTILSSEG szIniBold []        = "Bold" ;
char UTILSSEG szIniItalic []      = "Italic" ;
char UTILSSEG szIniBoldItalic []  = "BoldItalic" ;
char UTILSSEG szNullString[]      = "";



int NEAR PASCAL FontAttribOrd (LPLOGFONT lplf)
{
    int iValue = 0 ;
    
    if (lplf->lfWeight > FW_MEDIUM)
    {
        iValue += 1 ;
    }
    
    if (lplf->lfItalic)
    {
        iValue += 2 ;
    }
    
    return iValue ;
}

LPSTR NEAR PASCAL FixStyleTrueType (LPLOGFONT lplf)
{
    
    switch (FontAttribOrd (lplf))
    {
        case 3 :
            return szOutiBoldItalic ;
            
        case 2 :
            return szOutiItalic ;
            
        case 1 :
            return szOutiBold ;
            
        case 0 :
        default :
            return szNullString ;
    }
}

int FAR PASCAL ExtractString(LPSTR szString, LPSTR szSubString, WORD wIString, WORD cbSize, char cDelimiter)
{
   WORD wStart = 0;   
   WORD i = 0;

   //find the start of where to copy
   wIString--; //find the delimiter before the ith String.
   while (wIString && szString[wStart] != '\0')
   {
      if (szString[wStart] == cDelimiter)
        wIString--;
      wStart++;
   }

   if (wIString)  //didn't have the ithString.
   {
      *szSubString = '\0';
      return 0;
   }
      
   //find the end of string to copy
   while( (szString[wStart] != cDelimiter) &&
          (szString[wStart] != '\0') && 
          (i < cbSize))
   {
      szSubString[i++] = szString[wStart++];
   }

   if (i == cbSize)
     return 0; //ran out of room in the string buffer.
   else
      szSubString[i] = '\0';  

   return 1;
}

int FAR PASCAL ExistRegEntry (LPSTR lpSubKey, LPSTR lpKey)
{
    HKEY hkey;
    int rc = 0;

    if (RegOpenKey ( HKEY_LOCAL_MACHINE, lpSubKey , &hkey ) == ERROR_SUCCESS)
    {
      if (RegQueryValueEx(hkey,lpKey,NULL,NULL, NULL, NULL) == ERROR_SUCCESS)
      {
         rc = 1;
      }
    }
        
   RegCloseKey (hkey) ;
   return rc ;
}


VOID huge * FAR PASCAL GetTable (BYTE huge *Sfnt, DWORD tableName)
{
    LPTABLEDIRECTORY tableDirectory = (LPTABLEDIRECTORY) Sfnt ;
    LPTABLEENTRY tableEntry = (LPTABLEENTRY) ((LPSTR)tableDirectory + sizeof (TABLEDIRECTORY)) ;
    UINT i = 0 ;

    while (i < MOTOROLAINT (tableDirectory->numTables))
    {
        if (tableEntry->tag == tableName)
        {
            break ;
        }
        else
        {
            tableEntry = (LPTABLEENTRY)((LPSTR) tableEntry + sizeof (TABLEENTRY)) ;
            i++ ;
        }
    }
    if (i < MOTOROLAINT (tableDirectory->numTables))
    {
        return (VOID huge *)(Sfnt + MOTOROLALONG (tableEntry->offset)) ;
    }
    else
    {
        return NULL ;
    }
}

int FAR PASCAL TTExtractPsName (LPLOGFONT lplf, LPSTR pszPostScriptName, HDC hDC)
{
//
//  Some information for the interested programmer:
//      In TrueType font we can have multiple PS names, each for different
//      platform. In order to cope with this we implemented the priorities. 
//      The highest priority is Microsoft platform.
//
    WORD i ;
    LPSTR lpName ;
    LPSTR lpTemp ;
    WORD nRecords ;
    WORD wNameSize ;
    DWORD nFontSize ;
    HFONT hFont = NULL ;
    HFONT hPrevFont = NULL ;
    BYTE  huge * lpSfnt = NULL ;
    BOOL bNameFound = FALSE ;
    BOOL bDataFound = FALSE ;
    LPNAMERECORD lpNameRecord ;
    LPNAMEHEADER lpNameHeader ; 


    // GetFontData requires a screen DC to operate
    if (hDC == NULL)
    {
        goto TEPNexit ;
    }

    hFont = CreateFontIndirect (lplf) ;
    if (hFont == NULL)
    {
        goto TEPNexit ;
    }

    hPrevFont = SelectObject (hDC, hFont) ;
    if (hPrevFont == NULL)
    {
        goto TEPNexit ;
    }
    
       // get the size of the TrueType font file "name" table
    nFontSize = GetTableHDC(hDC, (DWORD)NAME_TBL, (BYTE) NULL);


     // allocate buffer for this font
    lpSfnt = (BYTE huge *) GlobalAllocPtr(GHND, nFontSize) ;
    if (lpSfnt == NULL)
    {
        goto TEPNexit ;
    }

    // Load the TrueType font file "name" table
    if (GetTableHDC(hDC, (DWORD)NAME_TBL, (BYTE huge *) lpSfnt) == -1)
    {
        goto TEPNexit ;
    }

    bDataFound = TRUE ;
    lpNameHeader = (LPNAMEHEADER) lpSfnt;
    nRecords = MOTOROLAINT (lpNameHeader->RecordNumber) ;
    lpNameRecord = (LPNAMERECORD)((LPSTR) lpNameHeader + sizeof(NAMEHEADER)) ;

    for (i = 0, bNameFound = FALSE ; i < nRecords ; i++) 
    {
        if (MOTOROLAINT (lpNameRecord[i].NameID) == TYPE42NAME_PS)
        {
            // The logic is: store the info if found PS name first time,
            // if another PS name found - store it only if it is satisfy the criteria
            //Microsoft-Unicode-English or Apple-Roman-English.

            if (!bNameFound ||
                (MOTOROLAINT (lpNameRecord[i].PlatformID) == TYPE42PLATFORM_WINDOWS &&
                 MOTOROLAINT (lpNameRecord[i].EncodingID) == WINDOWS_UNICODE_ENCODING &&
                 MOTOROLAINT (lpNameRecord[i].LanguageID) == WINDOWS_LANG_ENGLISH) ||
                (MOTOROLAINT (lpNameRecord[i].PlatformID) == PLATFORM_APPLE &&
                 MOTOROLAINT (lpNameRecord[i].EncodingID) == APPLE_ROMAN_ENCODING &&
                 MOTOROLAINT (lpNameRecord[i].LanguageID) == APPLE_LANG_ENGLISH)
               )
            {
                bNameFound = TRUE ;
                lpName = (LPSTR)((LPSTR) lpNameHeader + 
                            MOTOROLAINT(lpNameHeader->StringOffsets) +
                                MOTOROLAINT(lpNameRecord[i].StrOffset)) ;
                wNameSize = MOTOROLAINT(lpNameRecord[i].StrLen) ;
                if (MOTOROLAINT (lpNameRecord[i].PlatformID) == TYPE42PLATFORM_WINDOWS )
                  break;

            }
        }
    }
    if (bNameFound)
    {
        if (wNameSize && (*lpName == '\0'))
        {       // Darn!!! We have UNICODE encoding - grab every second char
            lpTemp = pszPostScriptName ;
            lpName++ ;          // next Char
            wNameSize /= 2 ;    // count bytes
            wNameSize = min (wNameSize, MAXPSNAME) ;
            while (wNameSize)
            {
                *lpTemp++ = *lpName ;
                lpName += 2 ;
                wNameSize-- ;
            }
            *lpTemp = '\0' ;
        }
        else
        {
            strncpy (pszPostScriptName, lpName, wNameSize);
            pszPostScriptName[wNameSize+1] = '\0';
        }                                

        while(*pszPostScriptName)
        {
            if ((*pszPostScriptName <= 0x20) || (*pszPostScriptName > 0x7F ))
            {
                *pszPostScriptName = '-' ;
            }
            pszPostScriptName++ ;
        }
    }                                 

TEPNexit:

    if (hPrevFont != NULL)
    {
        SelectObject (hDC, hPrevFont) ;
    }
    
    if (hFont != NULL)
    {
        DeleteObject (hFont) ;
    }
    

    if (lpSfnt != NULL)
    {
        GlobalFreePtr(lpSfnt) ;
    }
    
    if (!bNameFound)
    {
        strcpy (pszPostScriptName, lplf->lfFaceName) ;
        strcat (pszPostScriptName, FixStyleTrueType (lplf)) ;

        while(*pszPostScriptName)
        {
            if ((*pszPostScriptName <= 0x20) || (*pszPostScriptName > 0x7F ))
            {
                *pszPostScriptName = '-' ;
            }
            pszPostScriptName++ ;
        }
    }

    return bDataFound ;
}

int CALLBACK EnumTTFamily (const ENUMLOGFONT FAR* elf, 
               const NEWTEXTMETRIC FAR* ptm, 
               int nFontType,
               LPARAM lParam)
{
  LPTTENUMSTRUCT lpTTData = (LPTTENUMSTRUCT) lParam; 


//   if (IsCharSetSupported(elf->elfLogFont.lfCharSet) && IsRealTTFont((LPLOGFONT) &(elf->elfLogFont)))
   if (IsCharSetSupported(elf->elfLogFont.lfCharSet))
   {
      if (lpTTData->hpTTFonts != NULL)
      {
         if (lpTTData->nTTFontsCounter < lpTTData->nTTFonts)
         {
            HPFONTFILE  hpTTFonts = (HPFONTFILE) lpTTData->hpTTFonts + lpTTData->nTTFontsCounter;

            //save all info wanted for this TTFont.
            if (TTExtractPsName((LPLOGFONT) &(elf->elfLogFont), (LPSTR)hpTTFonts->szName1, (HDC) lpTTData->hDC))
            {
               lstrcpy((LPSTR)hpTTFonts->szName2, (LPSTR)elf->elfLogFont.lfFaceName);
               hpTTFonts->lfWeight = elf->elfLogFont.lfWeight;
               hpTTFonts->lfCharSet = elf->elfLogFont.lfCharSet;
               hpTTFonts->lfItalic = elf->elfLogFont.lfItalic;
            }
            else
               lpTTData->nTTFontsCounter --; //will be increment back to original later
              
         }
         else
         {
            lpTTData->nTTFontsCounter = 0;
            return 0; //something is wrong.
         }
      }
      //increment number of fonts.
      lpTTData->nTTFontsCounter++;
   }

  return 1;  
}


int CALLBACK EnumTTRoot (const ENUMLOGFONT FAR* elf, 
               const NEWTEXTMETRIC FAR* ptm, 
               int nFontType,
               LPARAM lParam)
{                  
  LPTTENUMSTRUCT lpTTData = (LPTTENUMSTRUCT) lParam; 
  HDC hDC = lpTTData->hDC;
  LOGFONT        lf;
   
    if (nFontType & TRUETYPE_FONTTYPE)
    {
      memset((char *)&lf, 0, sizeof(lf));
      lf.lfCharSet = DEFAULT_CHARSET;
      lf.lfPitchAndFamily = 0;        /* FIXME: hebrew and arabic - MONO FONT?*/
      lstrcpy ((LPSTR)lf.lfFaceName, (LPSTR)elf->elfLogFont.lfFaceName) ;
      EnumFontFamiliesEx (hDC, &lf, EnumTTFamily, lParam, 0L);
    }
    return TRUE ;
}

WORD FAR PASCAL GetTrueTypeFonts(HPFONTFILE hpFontData, FONTENUMPROC lpEnumProcEx,  WORD numFonts)
{
  LOGFONT        lf;
  TTENUMSTRUCT   ttData;

  if (ttData.hDC = GetDC(NULL))
  {
    ttData.nTTFonts = numFonts;
    ttData.nTTFontsCounter = 0;
    ttData.hpTTFonts = hpFontData;
    memset((char *)&lf, 0, sizeof(lf));
    lf.lfCharSet = DEFAULT_CHARSET;
    lf.lfPitchAndFamily = 0;        /* FIXME: hebrew and arabic - MONO FONT?*/
    EnumFontFamiliesEx(ttData.hDC, &lf, (FONTENUMPROC)lpEnumProcEx, (LPARAM) &ttData, 0L);
  }
  ReleaseDC(NULL, ttData.hDC);

  return (ttData.nTTFontsCounter);
}

int CALLBACK TTPSName (const ENUMLOGFONT FAR* elf, 
               const NEWTEXTMETRIC FAR* ptm, 
               int nFontType,
               LPARAM lParam)
{
  LPTTENUMSTRUCT lpTTData = (LPTTENUMSTRUCT) lParam; 
  HPFONTFILE  hpTTFonts = lpTTData->hpTTFonts;
  int rc = TRUE;

  if  (((elf->elfLogFont).lfWeight == hpTTFonts->lfWeight) &&
         ((elf->elfLogFont).lfItalic == hpTTFonts->lfItalic) &&
         ((elf->elfLogFont).lfCharSet == hpTTFonts->lfCharSet) &&
         lpTTData->hDC != NULL)
  {
     TTExtractPsName ((LPLOGFONT)&(elf->elfLogFont), hpTTFonts->szName1, lpTTData->hDC);
     rc = FALSE; //don't enumerate any more
  }

  return rc;
}

WORD FAR PASCAL GetTTInfo(LPFONTFILE lpFontData, FONTENUMPROC lpEnumProcEx, LPLOGFONT lplf)
{
  LOGFONT        lf;
  TTENUMSTRUCT   ttData;

  if (ttData.hDC = GetDC(NULL))
  {
     lf = *lplf;
     lstrcpy ((LPSTR)lf.lfFaceName, (LPSTR)lpFontData->szName2) ;
     TTExtractPsName ((LPLOGFONT)&lf, (LPSTR)lpFontData->szName1, ttData.hDC);
  }
   ReleaseDC(NULL, ttData.hDC);

   return TRUE;
}



WORD FAR PASCAL CGetMaxNumberOfGlyphs(LPLOGFONT lpLogFont)
{
   MAXPTABLE *lpMaxpTable;
   WORD MaxNumberOfGlyphs = 0 ;
   LPTABLEENTRY lpTblEntry = NULL;
   HDC hDC = NULL ;
   HFONT hFont = NULL ;
   HFONT hPrevFont = NULL ;
   DWORD nFontSize ;
   BYTE  huge * lpSfnt = NULL ;

    if ((hDC = GetDC(NULL)) == NULL)
        goto exit ;

    if ((hFont = CreateFontIndirect (lpLogFont) )== NULL)
        goto exit ;

    if ((hPrevFont = SelectObject (hDC, hFont))== NULL)
        goto exit ;

     // get the size of the TrueType font file "maxp" table
    nFontSize = GetTableHDC(hDC, (DWORD)MAXP_TBL, (BYTE) NULL);
     // allocate buffer for this font
    lpSfnt = (BYTE huge *) GlobalAllocPtr(GHND, nFontSize) ;
    if (lpSfnt == NULL)
    {
        goto exit ;
    }

    // Load the TrueType font file "maxp" table
    if (GetTableHDC(hDC, (DWORD)MAXP_TBL, (BYTE huge *) lpSfnt) == -1)
    {
        goto exit ;
    }
    
   lpMaxpTable = (MAXPTABLE *)lpSfnt;
   MaxNumberOfGlyphs = MOTOROLAINT(lpMaxpTable->numGlyphs);

exit:
    if (hPrevFont != NULL)
        SelectObject (hDC, hPrevFont) ;
    if (hFont != NULL)
        DeleteObject (hFont) ;
    if (lpSfnt != NULL)
        GlobalFreePtr(lpSfnt) ;
    if (hDC != NULL)
       ReleaseDC(NULL, hDC);
   return (MaxNumberOfGlyphs);
}

int FAR PASCAL IsLocaTblFaulty(LPLOGFONT lpLogFont)
{
   MAXPTABLE *lpMaxpTable;
   WORD MaxNumberOfGlyphs = 0 ;
   TYPE42HEADER *lpHeadTable;
   LPTABLEENTRY lpTblEntry = NULL;
   HDC hDC = NULL ;
   HFONT hFont = NULL ;
   HFONT hPrevFont = NULL ;
   DWORD dMaxpTsize=0, dLocaTsize=0, dHeadTsize=0 ;
   BYTE  huge * lpSfnt = NULL ;
   DWORD GlyphOffset = 0, nextGlyphOffset = 0;
   WORD wGlyfIndex = 0;
   int locaTableOK = 0;  //init
   BYTE  huge * lpLoca = NULL ;



   if (!IsRealTTFont(lpLogFont))
      return (locaTableOK);

    if ((hDC = GetDC(NULL)) == NULL)
        goto exit ;

    if ((hFont = CreateFontIndirect (lpLogFont) )== NULL)
        goto exit ;

    if ((hPrevFont = SelectObject (hDC, hFont))== NULL)
        goto exit ;

     // get the size of the TrueType font file "maxp", "head" and "loca" table
    dMaxpTsize = GetTableHDC(hDC, (DWORD)MAXP_TBL, (BYTE) NULL);
    dLocaTsize = GetTableHDC(hDC, (DWORD)LOCA_TABLE, (BYTE) NULL);
    dHeadTsize = GetTableHDC(hDC, (DWORD)HEAD_TBL, (BYTE) NULL);

     // allocate buffer for this font
    lpSfnt = (BYTE huge *) GlobalAllocPtr(GHND, dMaxpTsize+dHeadTsize) ;

    /* To smoothly cross over 64K boundry, alloc for the loca separately */
    lpLoca = (BYTE huge *) GlobalAllocPtr(GHND, dLocaTsize) ;

    if (lpSfnt == NULL || lpLoca == NULL)
    {
        goto exit ;
    }

    // Load the TrueType font file "maxp" table
    if (GetTableHDC(hDC, (DWORD)MAXP_TBL, (BYTE huge *) lpSfnt) == -1)
    {
        goto exit ;
    }
    lpMaxpTable = (MAXPTABLE *)lpSfnt;
    MaxNumberOfGlyphs = MOTOROLAINT(lpMaxpTable->numGlyphs);

    // Load the TrueType font file "Head" table
    if (GetTableHDC(hDC, (DWORD)HEAD_TBL, (BYTE huge *) (lpSfnt+dMaxpTsize)) == -1)
    {
        goto exit ;
    }
    lpHeadTable = (TYPE42HEADER *) ( (BYTE huge *) lpSfnt + dMaxpTsize);

    // Load the TrueType font file "loca" table
    if (GetTableHDC(hDC, (DWORD)LOCA_TABLE, (BYTE huge *) lpLoca) == -1)
    {
        goto exit ;
    }

    //check if there a any problems with the loca table
   if (MOTOROLAINT(lpHeadTable->indexToLocFormat))
   {
      DWORD huge * locationTable = (DWORD huge *) lpLoca;

      // Get the offset to the glyph from the beginning of the glyf table
      while (wGlyfIndex < MaxNumberOfGlyphs)
      {
        GlyphOffset=MOTOROLALONG(locationTable[wGlyfIndex]);
        nextGlyphOffset=MOTOROLALONG(locationTable[wGlyfIndex+1]);
        if ((nextGlyphOffset < GlyphOffset) ||
            (nextGlyphOffset - GlyphOffset > (DWORD) MAX_GLYPH_LENGTH))
        {
          locaTableOK = (int) LOCA_TBL_FAULTY;
          goto exit;
        }
        wGlyfIndex++;
     }
   }
   else
   {
      WORD huge * locationTable = (WORD huge *) lpLoca ;

      // Get the offset to the glyph from the beginning of the glyf table
      while (wGlyfIndex < MaxNumberOfGlyphs)
      {
        GlyphOffset=(DWORD)MOTOROLAINT(locationTable[wGlyfIndex])*2;
        nextGlyphOffset=(DWORD)MOTOROLAINT(locationTable[wGlyfIndex+1])*2;
        if ((nextGlyphOffset < GlyphOffset) ||
            (nextGlyphOffset - GlyphOffset > (DWORD) MAX_GLYPH_LENGTH))
        {
          locaTableOK = (int) LOCA_TBL_FAULTY;
          goto exit;
        }
        wGlyfIndex++;
      }
   }

   locaTableOK = (int) LOCA_TBL_OK; //if we didn't drop out and go to this point the font is ok.
    
    

exit:
    if (hPrevFont != NULL)
        SelectObject (hDC, hPrevFont) ;
    if (hFont != NULL)
        DeleteObject (hFont) ;
    if (lpSfnt != NULL)
        GlobalFreePtr(lpSfnt) ;
    if (lpLoca != NULL)
        GlobalFreePtr(lpLoca) ;
    if (hDC != NULL)
        ReleaseDC (NULL, hDC) ;
   return (locaTableOK);
}

BOOL NEAR PASCAL CalculateXUID(LPTABLEDIRECTORY lpTableDir, LPTABLEENTRY lpTableEntry, LPSTR lpszXUID)
{
   DWORD checkSum = 0;
   DWORD tempCheckSum = 0;
   WORD  ithTableEntry = 0;

//due to bug 287085 where some font vendors give bogus checksum values
//we ara changing the algo for calculating checksums.

   for (ithTableEntry; ithTableEntry < MOTOROLAINT(lpTableDir->numTables) ; ++ithTableEntry)
   {
      checkSum += (DWORD) lpTableEntry->tag;
      checkSum += (DWORD) lpTableEntry->checkSum;
      checkSum += (DWORD) lpTableEntry->offset;
      checkSum += (DWORD) lpTableEntry->length;
      lpTableEntry = (LPTABLEENTRY)((LPSTR)lpTableEntry + sizeof(TABLEENTRY));

   }

#if 0


   tempCheckSum = GetTableCheckSum(lpTableDir, lpTableEntry, LOCA_TABLE);
   if (!tempCheckSum)
     goto exit;
   else
     checkSum += tempCheckSum;

   tempCheckSum = GetTableCheckSum(lpTableDir, lpTableEntry, GLYF_TABLE);
   if (!tempCheckSum)
     goto exit;
   else
     checkSum += tempCheckSum;

   tempCheckSum = GetTableCheckSum(lpTableDir, lpTableEntry, OS2_TABLE);
   if (!tempCheckSum)
     goto exit;
   else
     checkSum += tempCheckSum;
#endif

/* fix bug 225354, JJia, 7-23-97, use HEX instead ....
   ASCII85encode((LPBYTE)&checkSum, sizeof(checkSum), lpszXUID);
*/
   if (lpszXUID)
      wsprintf(lpszXUID, "%lx", checkSum);

   return TRUE;

}

BOOL FAR PASCAL ExtractXUID (LPLOGFONT lpLogFont, LPSTR lpszXUID, BOOL bAscii)
{
    LPTABLEENTRY lpTblEntry = NULL;
    HDC hDC = NULL ;
    HFONT hFont = NULL ;
    HFONT hPrevFont = NULL ;
    BOOL bDataFound = FALSE ;
    TABLEDIRECTORY  tableDir;
    DWORD size = 0;
    WORD len = 0, i = 0;

    *lpszXUID = '\0';
    if ((hDC = GetDC(NULL)) == NULL)
        goto exit ;

    if ((hFont = CreateFontIndirect (lpLogFont) )== NULL)
        goto exit ;

    if ((hPrevFont = SelectObject (hDC, hFont))== NULL)
        goto exit ;

    //get the number of tables
    memset((char *)&tableDir, 0, sizeof(TABLEDIRECTORY));
    size = GetTableDirectory(hDC, (LPTABLEDIRECTORY)&tableDir);
    if (!tableDir.numTables)
      goto exit;
    //get the size of the Table Entry
    if ((size = GetTableEntry(hDC, NULL, (LPTABLEDIRECTORY)&tableDir)) <= 0)
       goto exit; // get size only
    if ((lpTblEntry = (LPTABLEENTRY) GlobalAllocPtr(GHND, size)) == NULL)
       goto exit;
    //get the content of the Table Directory Entry
    size = GetTableEntry(hDC, lpTblEntry, (LPTABLEDIRECTORY)&tableDir); // get data

    /* Fix bug 225354, Use the HEX XUID directly, JJia */
    bDataFound = CalculateXUID((LPTABLEDIRECTORY) &tableDir, lpTblEntry, lpszXUID) ;

exit:
    if (hPrevFont != NULL)
        SelectObject (hDC, hPrevFont) ;
    if (hFont != NULL)
        DeleteObject (hFont) ;
    if (hDC != NULL)
        ReleaseDC (NULL,hDC) ;
    if (lpTblEntry != NULL)
      GlobalFreePtr(lpTblEntry);

    return bDataFound;
}

BOOL FAR PASCAL HasRequiredTables(LPLOGFONT lpLogFont)
{   
   BOOL  result = FALSE;
   HDC   hDC = NULL ;
   HFONT hFont = NULL ;
   HFONT hPrevFont = NULL ;

   if( IsRealTTFont(lpLogFont) &&
       (hDC = GetDC(NULL)) &&
       (hFont = CreateFontIndirect(lpLogFont)) &&
       (hPrevFont = SelectObject(hDC, hFont)) )
   {
       result = GetTableHDC(hDC, (DWORD)LOCA_TABLE, (BYTE) NULL) &&
                GetTableHDC(hDC, (DWORD)GLYF_TABLE, (BYTE) NULL) &&
                GetTableHDC(hDC, (DWORD)MAXP_TBL,   (BYTE) NULL) &&
                GetTableHDC(hDC, (DWORD)HEAD_TBL,   (BYTE) NULL) &&
                GetTableHDC(hDC, (DWORD)CVT_TBL,    (BYTE) NULL) &&
                GetTableHDC(hDC, (DWORD)FPGM_TBL,   (BYTE) NULL) &&
                GetTableHDC(hDC, (DWORD)HHEA_TBL,   (BYTE) NULL) &&
                GetTableHDC(hDC, (DWORD)PREP_TBL,   (BYTE) NULL) &&
                GetTableHDC(hDC, (DWORD)HMTX_TBL,   (BYTE) NULL);
   }
   
   if (hPrevFont != NULL)
      SelectObject (hDC, hPrevFont) ;
   if (hFont != NULL)
      DeleteObject (hFont) ;
   if (hDC != NULL)
      ReleaseDC (NULL, hDC) ;
   return (result);
}
