/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993-1995 Adobe Systems Inc.. All rights reserved.          */
/*                                                                           */
/* Module Name: mmfonts.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for  Multiple Master Fonts */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include <string.h>
#include <ctype.h>

#define ATMFile               (LPSTR)"ATM.INI"
#define ATMMMFONTSSECTION     (LPSTR)"MMFonts"  // MultiMaster fonts section. base font only. 2-6-1995
#define ATMFONTSSECTION       (LPSTR)"Fonts"  // Fonts section. 

#pragma code_seg(_TEXTOUTSEG)


/* Functions check Multiple Master fonts: added 2-6-1995. based on suggestions from ATM group
 * Copied from 3.0 Driver with minor adjustment for 4.1, 3-8-1995 */

// Locally used function:
short FAR PASCAL GetAllEntriesINI(LPHANDLE UserHandle,LPSTR ApplKey,LPSTR Buffer,LPINT lpSize, LPSTR INIFile,LPPDEVICE lppd);

 
/* If there is any Multiple Master Fonts, return 1, else return 0. */
short FAR PASCAL ExistMMFonts()
{
    char     value[MAX_PS_NAME];        // temp array
    int NumChar;

    NumChar =0;
    value[0]=0;
    NumChar = GetPrivateProfileString(ATMMMFONTSSECTION,NULL,"",
                     (LPSTR)value, sizeof(value), ATMFile);
    if ( NumChar>0){
       // Entries found:
       return 1;
       }
    // default return 0. be careful when add other cases.
    return 0;
}

/* If the fontname passed in is a MutiMaster base font, return 1; else return 0
 * If fontName is Family name (byFamilyName=1), we can directly look into ATM.INI to decide.
 * If fontName is the MenuName, then we use the menu name to find its Family name
 * and then do partial matching to find the excat entry name in ATM.INI
 */
short FAR PASCAL IsMMBaseFont(LPPDEVICE lppd, LPSTR szFontName, int byFamilyName)
{
  LPSTR  nameInATM; // temp pointers
  LPSTR     workBuf;
  HANDLE    hWorkBuf;
  int       workBufSize;
  int       found;
  LPSTR     pt1;

    if (szFontName==NULL || szFontName[0]==0) return 0;  // handle special cases first.
    if (ExistMMFonts()==0) return 0;  // special case
    
    if (byFamilyName==1){
       nameInATM = szFontName;  // szFontName is Family name.
       }
    else{
      // Don't know how to find the family name yet.
      // Not used yet. 3-9-95
       nameInATM = szFontName;  // szFontName is Family name.
	   }

    /* GET ALL THE MMFONTS entries*/
    workBufSize    = 16000;  // it will be increased in GetAllEntriesATMINI() if not enough.
    workBuf = (LPSTR)MGAllocLock(lppd,&hWorkBuf,(DWORD)workBufSize,GHND,0);
    if (workBuf == NULL)
        return 0;

    pt1 = workBuf;
    GetAllEntriesINI(&hWorkBuf,ATMMMFONTSSECTION,workBuf,&workBufSize, ATMFile, lppd);

    // LOOP GETTING ALL THE MMFONTS name in ATM.INI and compare one by one
    found=0;
    while (*pt1)
       {
       // compare the nameInATM first, this is done by a partial match.
       // e.g. familyname=CafliScrMM and CafliScrMM,ITALIC is the entry
       // Make sure the partial match starts from beginning.
       // e.g. GaramondMM and AGaramondMM are different (also partial match)
       // And Make sure the partial match ends correctly.
       // e.g. "MinioMM,Italic" and "MinioMMEp" are different MM fonts. MinioMM
       // is MM Font only if the first one is found.
       if ( (_fstrstr((LPSTR)pt1, (LPSTR)nameInATM)!=NULL) &&
            (pt1[0]==nameInATM[0]) &&
            (pt1[lstrlen(nameInATM)]==0 || pt1[lstrlen(nameInATM)]==',')
          ){
          // partial match:
          if (byFamilyName==1){
              // There is no more information
              found=1;
              break;
              }
          else{
              // Exact match is found: same pfb/pfm file names,
              // don't know how to do it yet. Just partial match for now. 3-8-95
              found=1;
              break;
              }
          }
       pt1+=lstrlen(pt1); // Skip current Entry
       pt1++;             // skip NULL separator;
       } // end while.

    MGUnlockFree(lppd, hWorkBuf, 0);

    return found;
}


/* If the fontname passed in is a MutiMaster instance, return 1; else return 0
 * If it is an instance, return the Base Font in baseFontName
*/
short FAR PASCAL IsMMInstanceFont(LPPDEVICE lppd, LPSTR szFontName, LPSTR szBaseFontName, int byFamily)
{
  char  name_in[MAX_PS_NAME];  // temp array
  LPSTR p, q; // temporary pointers to manipulate temporary array.
  int retVal;

   if (szFontName==NULL || szFontName[0]==0) return 0;  // handle special cases first.
   if (ExistMMFonts()==0) return 0;  // special case

   //Initialize vars
   name_in[0]=0;
   szBaseFontName[0]=0;
   lstrcpy((LPSTR)name_in, szFontName); // make a temporary copy.
   p=(LPSTR)name_in;
   q=(LPSTR)name_in;
   // Scan the fontname for _digit:
   while(p!=NULL && *p!=0){
      p++;
      if (*p=='_' && isdigit(*(p+1)) ){
         *p=0;
         lstrcpy((LPSTR)szBaseFontName, q); // copy the base font name
         }
      }
   // Check the szbaseFontName to see if it is a MM Base Font:
   retVal = IsMMBaseFont(lppd, (LPSTR)szBaseFontName, byFamily);
   return retVal;
}


/***************************************************************************
 * Return all entries in the particular sectionand increase the buffer if necessary
 * retVal=0: OK; -1:Failed (nothing found or ReAllocation failed)
 */

short FAR PASCAL GetAllEntriesINI(LPHANDLE UserHandle,LPSTR ApplKey,LPSTR Buffer,LPINT lpSize, LPSTR INIFile, LPPDEVICE lppd)
{
  int    Size = *lpSize;
  int    SizeIncr;
  short  RetCode = 0;  // OK - default. -1 == FAIL
  int    NumChar;
  HANDLE NewHandle;

  if( (ApplKey != NULL) && (_fstrlen(ApplKey) != 0) && (Buffer != NULL))
  {
      NumChar = GetPrivateProfileString(ApplKey,NULL,"",Buffer,Size,INIFile);
      while( (NumChar == (Size-2)) && (RetCode != -1) )
      {
           MGUnlock(*UserHandle);
           SizeIncr = Size >> 1;
           Size = Size + SizeIncr;
           NewHandle = MGReAlloc(lppd, *UserHandle, (DWORD)Size, GHND, 0);
           if(NewHandle != NULL)
           {
             *UserHandle = NewHandle;
              Buffer     = MGLock(lppd, *UserHandle,0);
              if(Buffer != NULL)
                 NumChar = GetPrivateProfileString(ApplKey,NULL,"",Buffer,Size,INIFile);
              else
                 RetCode = -1;
           }
           else
              RetCode = -1;
      }

      if(RetCode == 0)
         *lpSize = Size;
  }
  else
     RetCode = -1;

  return(RetCode);
}


/* This function just realize the passed in font and send it.
 * without checking for MM instance.
 * It is used to send the corrsponding MM Base font for an MM Insatance
 * And also this function only works for Type1 fonts. Doesn't work for
 * TruType fonts because RealizeObject() will fail. See wm.c for comments.
 */
int TRealizeAndSendFont(LPPDEVICE lppd, LPLOGFONT lpfont, LPSTR strText, int nText, BOOL bMinHeader)
{
TEXTXFORM textXform;
LPPSFONTINFO fontInfoPtr;
LPFONTEXTRA fontExtra;
LPTFUNCTIONPTRS funcptr;
int sFontInfoSize;
POINT cp;

	sFontInfoSize = RealizeObject((LP) lppd, OBJ_FONT, (LP) lpfont,
					(LP) NULL, (LP) &textXform);
	fontInfoPtr =  (LPPSFONTINFO)GlobalAllocPtr(GHND,sFontInfoSize);
	
	if (sFontInfoSize==0 || fontInfoPtr==NULL) return 0;
	
	if (RealizeObject((LP) lppd, OBJ_FONT, 
		  (LP) lpfont, (LP) fontInfoPtr, (LP) &textXform))
	   {
	   /* download the font, if necessary */
	   fontExtra = (LPFONTEXTRA)BUMPFAR (fontInfoPtr, fontInfoPtr->dfDriverInfo);
	   if (fontInfoPtr->dfType & TYPE_TRUETYPE ||
				  (fontExtra->dwSoftFont))
	      {
 	      funcptr = (LPTFUNCTIONPTRS) lppd->lpTFuncPtr;
		  funcptr->rTSoftFontLoad(lppd, fontInfoPtr,
				(LPTEXTXFORM) &textXform, strText, nText);
          }
	   /* First make sure the font instance is created and associated */
	   /* procsets are downloaded */
       if (!bMinHeader)         //Fix bug 118925, jjia  9/14/95 
       {
            cp.x = cp.y = 0;
            TTextBegin(lppd, &cp, fontInfoPtr, &textXform);
            TTextEnd(lppd, fontInfoPtr, &textXform, 0);
       }

	   GlobalFreePtr((LPBYTE) fontInfoPtr);
	   }
	   
	return 1;
}

