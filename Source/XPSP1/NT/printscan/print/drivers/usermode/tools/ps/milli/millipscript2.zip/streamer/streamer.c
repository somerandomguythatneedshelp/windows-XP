/* streamer.c - tests the streamer package

              Copyright 1994 -- Adobe Systems, Inc.
            PostScript is a trademark of Adobe Systems, Inc.
NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

Original version: Ron Fischer, Fri Mar 4nd, 1994
*/

/* -------------------------------------------------------------------------
     Header Includes
  --------------------------------------------------------------------------- */

#if OS!=os_msdos
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#endif

#include PACKAGE_SPECS
#include ATM

#if OS==os_msdos
#include <io.h>
#include <conio.h>
#elif OS==os_sparc
#include <unistd.h>
#endif

#if ISP==isp_sparc && OS==os_sun
#include <sys/stdtypes.h>
#endif

#include PUBLICTYPES
#include FP

#include BUILDCH

#include STREAMER
#include PARSEGLU

#include "buffglue.h"
#include "charstr.h"

/* eexec keys for file encryption and charstrings (and subr) encryption */
#define EEXEC_KEY 55665
#define CHARS_KEY 4330

/* Commonly used string */
#define PS_DefString	" def"


/* Note that there are two valid forms for subr 4 */

#define SUBR0LEN	11
#define SUBR1LEN	5
#define SUBR2LEN	5
#define SUBR3LEN	1
#define SUBR4V1LEN	8
#define SUBR4V2LEN	9

#define SUBR0 "\x8E\x8B\x0C\x10\x0C\x11\x0C\x11\x0C\x21\x0B"
#define SUBR1 "\x8B\x8C\x0C\x10\x0B"
#define SUBR2 "\x8B\x8D\x0C\x10\x0B"
#define SUBR3 "\x0B"
#define SUBR4V1 "\x8C\x8E\x0C\x10\x0C\x11\x0A\x0B"
#define SUBR4V2 "\x8E\x8C\x8E\x0C\x10\x0C\x11\x0A\x0B"


/*************************************************************************

Function name:  StreamerCheckOpts()

**************************************************************************

Date:           03/05/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Check the validity of the streamer options.
Description:    Check the specified options, make sure they are valid and 
                consistent.  For instance, it ST_SPARSE_BY_NAME is given
                then the sparseNames pointer should not be NULL
Parameters:     StreamerOpts s -- the streamer options struct
                
Return Values:  ST_NOERR if options are fine, ST_BADOPTIONS if an invalid
                option is detected.
Notes:          
See also:       

**************************************************************************/

PUBLIC IntX StreamerCheckOpts ARGDEF1(PStreamerOpts, so)
{
if ((so->lenIV < -1) || (so->lenIV > 4))
   return ST_BADOPTION;

if ((so->snapShot == ST_SNAPSHOT) && (so->blendVector == NULL))
   return ST_BADOPTION;

if (so->PutBytes == NULL)
   return ST_BADOPTION;

if (so->MemoryRealloc == NULL)
   return ST_NO_MEM_CALLBACK;

return ST_NOERR;
} /* end StreamerCheckOpts() */
         

    /* Write out the font matrix */
PRIVATE IntX StreamFontMatrix ARGDEF3(T1FontPointer, fp, Card8, doingFaux,
                                      FauxInfoPointer, fi)
{
register FontDesc *fontDict;
unsigned char s[20];                         /* More than enough */


/* Hmmm, Shawn was looking in the FontValues structure for this matrix! */
fontDict = fp->pFontDict[0];                     

BufferString((Card8 *)"/FontMatrix [");

FracToString(fontDict->fontMatrix.a, 6, s);      /* Convert to String */
BufferString((Card8 *)s);                             /* Stream out */
BufferChar(' ');

FracToString(fontDict->fontMatrix.b,  6, s);      /* Convert to String */
BufferString((Card8 *)s);                             /* stream out */
BufferChar(' ');

if (doingFaux)
   FracToString(fontDict->fontMatrix.c + fixmul(fontDict->fontMatrix.a,
                     fi->ItalicAngle), 8, s);
else
   FracToString(fontDict->fontMatrix.c, 6, s);   /* Convert to String */
BufferString((Card8 *)s);                             /* Stream out */
BufferChar(' ');

if (doingFaux)
   FracToString(fontDict->fontMatrix.d + fixmul(fontDict->fontMatrix.b, fi->ItalicAngle), 8, s);
else
   FracToString(fontDict->fontMatrix.d, 6, s);   /* Convert to String */
   BufferString((Card8 *)s);                             /* Stream out */
BufferChar(' ');

FracToString(fontDict->fontMatrix.tx, 6, s);     /* Convert to String */
BufferString((Card8 *)s);                             /* Stream out */
BufferChar(' ');

FracToString(fontDict->fontMatrix.ty, 6, s);     /* Convert to String */
BufferString((Card8 *)s);                             /* Stream out */

BufferStringEOL((Card8 *)"] readonly def");

return ST_NOERR;
} /* end StreamFontMatrix() */


PRIVATE IntX StreamBlueValues ARGDEF2(FontDesc *, fd, FontValues *, fv)
{
CardX  j;
Card32 bottomMask;

if (fd->numBlueValues == 0)
   return ST_NOERR;

BufferString((Card8 *)"/BlueValues [");

bottomMask = 1L;

for (j = 0; j < fd->numBlueValues; j++)
 { if (j == 0 || ((fd->blueZones & bottomMask) == 0))
    { BufferFixed(fv->blueValues[j].botEdge);
      BufferChar(' ');

      BufferFixed(fv->blueValues[j].topEdge);
      BufferChar(' ');
    } /* end if */

   bottomMask <<= 1;
 } /* end for */

BufferStringEOL((Card8 *)"] def");

return ST_NOERR;
} /* end StreamBlueValues() */


PRIVATE IntX StreamOtherBlues ARGDEF2(FontDesc *, fd, FontValues *, fv)
{
CardX j;
Card32 bottomMask;
boolean seen = false;

bottomMask = 1L;

for (j = 0; j < fd->numBlueValues; j++)
 { if (j != 0 && ((fd->blueZones & bottomMask) != 0))
    { if (seen == false)
       { BufferString((Card8 *)"/OtherBlues [");
         seen = true;
       } /* end if */

      BufferFixed(fv->blueValues[j].botEdge);
      BufferChar(' ');
   
      BufferFixed(fv->blueValues[j].topEdge);
      BufferChar(' ');
    } /* end if */
   bottomMask <<= 1;
 } /* end for */

if (seen)
   BufferStringEOL((Card8 *)"] def");

return ST_NOERR;
} /* end StreamOtherBlues() */


PRIVATE IntX StreamFamilyBlues ARGDEF2(FontDesc *, fd, FontValues *, fv)
{
CardX  j;
Card32 bottomMask;

if (fd->numFamilyBlues < 1)
   return ST_NOERR;

BufferString((Card8 *)"/FamilyBlues [");

bottomMask = 1L;

for (j = 0; j < fd->numFamilyBlues; j++)
 { if (j == 0 || ((fd->familyBlueZones & bottomMask) == 0))
    { BufferFixed(fv->familyBlueValues[j].botEdge);
      BufferChar(' ');

      BufferFixed(fv->familyBlueValues[j].topEdge);
      BufferChar(' ');
    } /* end if */

   bottomMask <<= 1;
 } /* end for */

BufferStringEOL((Card8 *)"] def");

return ST_NOERR;
} /* end StreamFamilyBlues() */


PRIVATE IntX StreamFamilyOtherBlues ARGDEF2(FontDesc *, fd, FontValues *, fv)
{
CardX j;
Card32 bottomMask;
boolean seen = false;

bottomMask = 1L;

for (j = 0; j < fd->numFamilyBlues; j++)
 { if (j != 0 && ((fd->familyBlueZones & bottomMask) != 0))
    { if (seen == false)
       { BufferString((Card8 *)"/FamilyOtherBlues [");
         seen = true;
       } /* end if */

      BufferFixed(fv->familyBlueValues[j].botEdge);
      BufferChar(' ');

      BufferFixed(fv->familyBlueValues[j].topEdge);
      BufferChar(' ');
    } /* end if */

   bottomMask <<= 1;
 } /* end for */

if (seen)
   BufferStringEOL((Card8 *)"] def");

return ST_NOERR;
} /* end StreamFamilyOtherBlues() */


PRIVATE IntX StreamStdW ARGDEF1(FontValues *, fv)
{
long  Val;

Val = fv->stdHW;

if (Val)
 { BufferString((Card8 *)"/StdHW [");

   if ((Val = fv->stdHW) != 0)
    { BufferFixed(Val);
      BufferChar(' ');
    } /* end if */

   BufferStringEOL((Card8 *)"] def");
 } /* end if */

Val = fv->stdVW;

if (Val)
 { BufferString((Card8 *)"/StdVW [");

   if ((Val = fv->stdVW) != 0)
    { BufferFixed(Val);
      BufferChar(' ');
    } /* end if */

   BufferStringEOL((Card8 *)"] def");
 } /* end if */

return BufferError();
} /* end StreamStdW() */


PRIVATE IntX StreamStemSnap ARGDEF2(FontDesc *, fd, FontValues *, fv)
{
CardX j;

if (fd->lenStemSnapH) 		/* First check whether there are any! */
 { BufferString((Card8 *)"/StemSnapH [");

   for (j = 0; j < fd->lenStemSnapH; j++)
    { BufferFixed(fv->stemSnapH[j]);
      BufferChar(' ');
    } /* end for */
      
   BufferStringEOL((Card8 *)"] def");
 } /* end if */
   
if (fd->lenStemSnapV)
 { BufferString((Card8 *)"/StemSnapV [");
   
   for (j = 0; j < fd->lenStemSnapV; j++)
    { BufferFixed(fv->stemSnapV[j]);
      BufferChar(' ');
    } /* end for */
   
   BufferStringEOL((Card8 *)"] def");
 } /* end if */

return ST_NOERR;
} /* end StreamStemSnap() */


PRIVATE IntX StreamBlueStuff ARGDEF1(FontValues *, fv)
{
long  Val;

/* Stream BlueScale only if it is not the default value of .039625 */

if ((Val = fv->blueScale) != 0x00000A25)
 { BufferString((Card8 *)"/BlueScale ");
   BufferFixed(Val);
   BufferStringEOL((Card8 *)PS_DefString);
 } /* end if */

/* Stream BlueFuzz only if it is not the default value of 1 */

if ((Val = fv->blueFuzz) != 0x00010000)
 { BufferString((Card8 *)"/BlueFuzz ");
   BufferFixed(Val);
   BufferStringEOL((Card8 *)PS_DefString);
 } /* end if */

/* Stream BlueShift only if it is not the default value of 7 */

if ((Val = fv->blueShift) != 0x00070000)
 { BufferString((Card8 *)"/BlueShift ");					// Add space after the key TH 03/26/96 
   BufferFixed(Val);
   BufferStringEOL((Card8 *)PS_DefString);
 } /* end if */

return BufferError();
} /* end StreamBlueStuff() */


PRIVATE IntX StreamForceBold ARGDEF1(FontValues *, fv)
{
if (fv->flags & FONT_FORCEBOLD_USED)
 { if (fv->flags & FONT_FORCEBOLD)
      BufferStringEOL((Card8 *)"/ForceBold true def");
   else
      BufferStringEOL((Card8 *)"/ForceBold false def");
 } /* end if */

return ST_NOERR;
} /* end () */


/*************************************************************************

Function name:  MakeFontVal()

**************************************************************************

Date:           03/18/94
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        
Description:    
                
Parameters:     
                
Return Values:  
Notes:          
See also:       

**************************************************************************/

PRIVATE IntX MakeFontVal ARGDEF2(T1FontPointer, fp, PStreamerOpts, s)
{
if ((fp->pFontDict[0]->numMasters > 1) && ((s->snapShot == ST_SNAPSHOT)
    || s->doingFaux))
 { if (s->blendLen != fp->numAxes)
      return ST_BAD_BLEND_DATA;
   if (!GetWeightVector(fp->ds, fp->weightVector, s->blendVector))
      return ST_BAD_BLEND_DATA;

   BlendHintData(fp->pFontDict[0], fp->weightVector, &fp->defaultVals);
 } /* end if */
else fp->defaultVals = *fp->pFontDict[0]->values;

return ST_NOERR;
} /* end MakeFontVal() */


/*************************************************************************

Function name:  StreamChars()

**************************************************************************

Date:           05/23/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream the characters in a font
Description:    This is a standalone function to stream the characters in 			a font.  It uses the GetCharString() callback to get the
		charstrings from a user, then StreamCharString() to process
          	the charstring.
                
Parameters:     fp - the font record
                charOpts - the character options to use
		s - the streamer options to use
		b - the current buffer status
		fi - the faux font options
Return Values:  standard ST_ errors
Notes:          
See also:       StreamCharString()

**************************************************************************/

PUBLIC IntX StreamChars ARGDEF5(T1FontPointer, fp, CharStrOpts *, charOpts,
              PStreamerOpts, s, PBufferStatus, b, FauxInfoPointer, fi)
{
IntX i, code = ST_NOERR;
CharDataPtr charString;
Card16 charLen;
Card8 *charName;
CardX sparseMethod = s->sparseMethod;

BufferString((Card8 *)"/CharStrings ");
BufferInt(fp->numCharStrings);
BufferStringEOL((Card8 *)" dict dup begin");

for (i = 0; i < fp->numCharStrings; i++)
 { code = charOpts->GetCharString(i, INDEX_IS_CHARINDEX, &charString, &charLen,
                           &charName);
   if (!code)
      return ST_CALLBACKFAILED;

   /* For Faux fonts I must get the blend/design vector and use this to
      get the weight vector and blend hints. */
   if (s->doingFaux && (charString != NULL))
    { Card8 dummy;
      if ((*s->GetFauxInfo)(i, INDEX_IS_NAME, (char *)charName, s->blendVector, &dummy))
       { code = MakeFontVal(fp, s);
         if (code != ST_NOERR)
            return code;
       } /* end if */
      else /* Can't get faux info--this char is NOT in the faux set-exclude it*/
       { charString = NULL;
         /* Too late to change number of charstrings--don't want to lie */
         sparseMethod = ST_SPARSE_ENDCHAR;
       } /* end else */
    } /* end if */

   /* If charString is NULL don't want to accidently report error. */
   code = ST_NOERR;	

   if ((charString != NULL) || (sparseMethod != ST_SPARSE_REMOVE))
      code = StreamCharString(charString, charLen, charName, fp, charOpts, fi, b);

   if (code != ST_NOERR)
      return code;

#define TESTSEAC 1
#if TESTSEAC
   if (charString != NULL)
      code = CheckForSEAC(charString, charLen, fp, charOpts);
   if (code != ST_NOERR)
      return code;
#endif /* TESTSEAC */
 } /* end for */

BufferStringEOL((Card8 *)"end");

BufferFlush();
return BufferError();
} /* end StreamChars() */


/*************************************************************************

Function name:  CheckSubrs()

**************************************************************************

Date:           
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        
Description:    The first five subrs can be a special case--you would not
                want to flatten or try to trace into them if they are the
                normal flex/hint substitution subrs described in the black
                book.
                
Parameters:     
                
Return Values:  
Notes:          
See also:       

**************************************************************************/

PRIVATE void CheckSubrs ARGDEF2(T1FontPointer, fp, CharStrOpts *, co)
{
int j;
CharDataPtr subrPtr, defaultSubr;
Card16 subrLen;

fp->standardSubrs = true;

if (fp->pFontDict[0]->lenSubrArray < 4)
 { fp->standardSubrs = false;
   return;
 } /* end if */

/* NOTE:  I don't want to use strncmp because subrs could contain CRs, etc. */
(*co->GetSubr)(0, &subrPtr, &subrLen);
if (subrPtr == NULL)
 { fp->standardSubrs = false;
   return;
 } /* end if */
defaultSubr = (CharDataPtr)SUBR0;
for (j = 0; j < SUBR0LEN; j++)
   if (defaultSubr[j] != subrPtr[j])
    { fp->standardSubrs = false;
      return;
    } /* end if */

(*co->GetSubr)(1, &subrPtr, &subrLen);
if (subrPtr == NULL)
 { fp->standardSubrs = false;
   return;
 } /* end if */
defaultSubr = (CharDataPtr)SUBR1;
for (j = 0; j < SUBR1LEN; j++)
   if (defaultSubr[j] != subrPtr[j])
    { fp->standardSubrs = false;
      return;
    } /* end if */

(*co->GetSubr)(2, &subrPtr, &subrLen);
if (subrPtr == NULL)
 { fp->standardSubrs = false;
   return;
 } /* end if */
defaultSubr = (CharDataPtr)SUBR2;
for (j = 0; j < SUBR2LEN; j++)
   if (defaultSubr[j] != subrPtr[j])
    { fp->standardSubrs = false;
      return;
    } /* end if */

(*co->GetSubr)(3, &subrPtr, &subrLen);
if (subrPtr == NULL)
 { fp->standardSubrs = false;
   return;
 } /* end if */
defaultSubr = (CharDataPtr)SUBR3;
for (j = 0; j < SUBR3LEN; j++)
   if (defaultSubr[j] != subrPtr[j])
    { fp->standardSubrs = false;
      return;
    } /* end if */

fp->subr4 = NOTSTANDARDV;
if (fp->pFontDict[0]->lenSubrArray < 5)
   return;

(*co->GetSubr)(4, &subrPtr, &subrLen);
if (subrPtr == NULL)
   return;

defaultSubr = (CharDataPtr)SUBR4V1;
for (j = 0; j < SUBR4V1LEN; j++)
   if (defaultSubr[j] != subrPtr[j])
      break;

/* Must have failed the previous loop */
if (j < SUBR4V1LEN)			/* Two valid forms for subr 4 */
 { defaultSubr = (CharDataPtr)SUBR4V2;
   for (j = 0; j < SUBR4V2LEN; j++)
      if (defaultSubr[j] != subrPtr[j])
         return;
   
   fp->subr4 = STANDARDV2;
 } /* end if */
else
   fp->subr4 = STANDARDV1;

} /* end CheckSubrs() */


/*************************************************************************

Function name:  StreamSubrs()

**************************************************************************

Date:           03/20/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream out the subroutines for a font
Description:    Stream out a font's subroutines, in the correct format.
                It can flatten subrs (remove all except possibly the
                5 standard subrs) or sparse subrs.  Subrs are sparsed by
                using the GetSubr() callback.  If a subr returned by the
                user from that callback is null, a stub will be put in 
                it's place (some older parser will expect a stub--it's
                best to provide one).  Note that StreamCharString() should
                be called before attempting to sparse subrs--it will 
                provide information about which subrs are used and whether
                or not they can be sparsed at all.
                
Parameters:     fp -- the font information
                so - the streamer options
                charOpts -- the charstring options (the lenIV info is 
                            needed).
Return Values:  see ST_ values in streamer.h
Notes:          Subr flattening has a potential problem.  CheckSubrs() can
                be used to determine if 1st 5 standard subrs are present,
                but if all 5 are not there then it will allow flattening
                (even if some of them are there).  These subrs may not
                flatten well (or the code generated may not execute).  I
                have never actually found this problem.
See also:       StreamerSetCharOpts(), CheckSubrs()

**************************************************************************/

PUBLIC IntX StreamSubrs ARGDEF3(T1FontPointer, fp, CharStrOpts *, charOpts, 
                                 PBufferStatus, b)
{
BufferRestore(b);
if (charOpts->flattenCharStrs) 
 { if (!fp->standardSubrs) 	/* Most parsers expect some subrs - so a stub!*/
      BufferStringEOL((Card8 *)"/Subrs 1 array");
   else if (fp->subr4 == NOTSTANDARDV)
      BufferStringEOL((Card8 *)"/Subrs 4 array");
   else
      BufferStringEOL((Card8 *)"/Subrs 5 array");

   if (!fp->standardSubrs)
    { if (charOpts->lenIV == -1)		/* Easy case - No encryption */
         BufferStringEOL((Card8 *)"dup 0 1 RD \x0B NP");
      else
       { Card8 s[16];
         Card16 charStringKey;
         charStringKey = charOpts->charStringKey;
         os_sprintf((char *)s, "dup 0 %d RD ", SUBR3LEN+charOpts->lenIV);
         BufferString((Card8 *)s);
         BufferChars(charOpts->lenIVBytes, charOpts->lenIV);
         os_strcpy((char *)s, SUBR3);
         BufferAndEncrypt(s, (Card32)os_strlen((char *)s), &charStringKey);
         BufferStringEOL((Card8 *)" NP");
       } /* end else */
    } /* end if */
   else
    { if (charOpts->lenIV == -1)		/* Easy case - No encryption */
       { BufferStringEOL((Card8 *)"dup 0 11 RD \x8E\x8B\x0C\x10\x0C\x11\x0C\x11\x0C\x21\x0B NP");
         BufferStringEOL((Card8 *)"dup 1 5 RD \x8B\x8C\x0C\x10\x0B NP");
         BufferStringEOL((Card8 *)"dup 2 5 RD \x8B\x8D\x0C\x10\x0B NP");
         BufferStringEOL((Card8 *)"dup 3 1 RD \x0B NP");
         if (fp->subr4 == STANDARDV1)
            BufferStringEOL((Card8 *)"dup 4 8 RD \x8C\x8E\x0C\x10\x0C\x11\x0A\x0B NP");
         else if (fp->subr4 == STANDARDV2)
            BufferStringEOL((Card8 *)"dup 4 9 RD \x8E\x8C\x8E\x0C\x10\x0C\x11\x0A\x0B NP");
       } /* end if */
      else
       { Card8 s[16];
         Card16 charStringKey;
      
         charStringKey = charOpts->charStringKey;
         os_sprintf((char *)s, "dup 0 %d RD ", SUBR0LEN+charOpts->lenIV);
         BufferString((Card8 *)s);
         BufferChars(charOpts->lenIVBytes, charOpts->lenIV);
         os_strcpy((char *)s, SUBR0);
         BufferAndEncrypt(s, os_strlen((char *)s), &charStringKey);
         BufferStringEOL((Card8 *)" NP");
   
         charStringKey = charOpts->charStringKey;
         os_sprintf((char *)s, "dup 1 %d RD ", SUBR1LEN+charOpts->lenIV);
         BufferString((Card8 *)s);
         BufferChars(charOpts->lenIVBytes, charOpts->lenIV);
         os_strcpy((char *)s, SUBR1);
         BufferAndEncrypt(s, (Card32)os_strlen((char *)s), &charStringKey);
         BufferStringEOL((Card8 *)" NP");
         
         charStringKey = charOpts->charStringKey;
         os_sprintf((char *)s, "dup 2 %d RD ", SUBR2LEN+charOpts->lenIV);
         BufferString((Card8 *)s);
         BufferChars(charOpts->lenIVBytes, charOpts->lenIV);
         os_strcpy((char *)s, SUBR2);
         BufferAndEncrypt(s, (Card32)os_strlen((char *)s), &charStringKey);
         BufferStringEOL((Card8 *)" NP");
      
         charStringKey = charOpts->charStringKey;
         os_sprintf((char *)s, "dup 3 %d RD ", SUBR3LEN+charOpts->lenIV);
         BufferString((Card8 *)s);
         BufferChars(charOpts->lenIVBytes, charOpts->lenIV);
         os_strcpy((char *)s, SUBR3);
         BufferAndEncrypt(s, (Card32)os_strlen((char *)s), &charStringKey);
         BufferStringEOL((Card8 *)" NP");
   
         charStringKey = charOpts->charStringKey;
         if (fp->subr4 == STANDARDV1)
          { os_sprintf((char *)s, "dup 4 %d RD ", SUBR4V1LEN+charOpts->lenIV);
            BufferString((Card8 *)s);
            BufferChars(charOpts->lenIVBytes, charOpts->lenIV);
            os_strcpy((char *)s, SUBR4V1);
            BufferAndEncrypt(s, (Card32)os_strlen((char *)s), &charStringKey);
            BufferStringEOL((Card8 *)" NP");
          } /* end if */
         else if (fp->subr4 == STANDARDV2)
          { os_sprintf((char *)s, "dup 4 %d RD ", SUBR4V2LEN+charOpts->lenIV);
            BufferString((Card8 *)s);
            BufferChars(charOpts->lenIVBytes, charOpts->lenIV);
            os_strcpy((char *)s, SUBR4V2);
            BufferAndEncrypt(s, (Card32)os_strlen((char *)s), &charStringKey);
            BufferStringEOL((Card8 *)" NP");
          } /* end else */

       } /* end else */
    } /* end else */
 } /* end if */
else	/* Not flattening or snapshotting (which requires flattening) */
 { IntX i;
   Card8 s[20], r[2];
   CharDataPtr subrPtr;
   Card16 charStringKey;
   Card16 subrLen;

   os_sprintf((char *)s, "/Subrs %d array", fp->pFontDict[0]->lenSubrArray);

   BufferStringEOL((Card8 *)s);
   for (i = 0; i < (IntX)fp->pFontDict[0]->lenSubrArray; i++)
    { (*charOpts->GetSubr)(i, &subrPtr, &subrLen);

      if (subrPtr != NULL)
       { if (charOpts->lenIV > -1)
          { os_sprintf((char *)s, "dup %d %d RD ", i, subrLen + charOpts->lenIV);
            BufferString(s);
            BufferChars(charOpts->lenIVBytes, charOpts->lenIV);
            charStringKey = charOpts->charStringKey;
            BufferAndEncrypt(subrPtr, subrLen, &charStringKey);
            BufferStringEOL((Card8 *)" NP");
          } /* end if */
         else 					/* No encryption */
          { os_sprintf((char *)s, "dup %d %d RD ", i, subrLen);
            BufferString(s);
            BufferChars(subrPtr, subrLen);
            BufferStringEOL((Card8 *)" NP");
          } /* end if */
       } /* end if */
      else /* No subr at this point--just create a "return" subr */
       { r[0] = '\x0B';
         r[1] = '\0';
         if (charOpts->lenIV > -1)
          { os_sprintf((char *)s, "dup %d %d RD ", i, 1 + charOpts->lenIV);
            BufferString(s);
            BufferChars(charOpts->lenIVBytes, charOpts->lenIV);
            charStringKey = charOpts->charStringKey;
            BufferAndEncrypt(r, 1, &charStringKey);
            BufferStringEOL((Card8 *)" NP");
          } /* end if */
         else 					/* No encryption */
          { os_sprintf((char *)s, "dup %d 1 RD /x0B NP", i);
            BufferStringEOL(s);
          } /* end else */
       } /* end else */
     
      BufferFlush();	/* Maybe there won't be much to flush, but if this */
			/* isn't called the buffer gets almost full then */
			/* BufferAndEncrypt is called and the buffer must be */
			/* expanded unnecessarily. */
    } /* end for */
 } /* end else */

BufferStringEOL((Card8 *)"ND");
BufferFlush();
BufferSave(b);

return BufferError();
} /* end StreamSubrs() */


/*************************************************************************

Function name:  StreamEncoding()

**************************************************************************

Date:           05/26/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream the encoding info for a font.
Description:    Most fonts just have standard encoding, but symbol fonts
		(and others) have special encodings.  This routine will
		output either type.  The special encoding is taken from
		the array fp->specialEncoding.
                
Parameters:     fp - the font record
		hasStandardEncoding - a flag indicating the font is standard.
                
Return Values:  ST_ errors
Notes:          
See also:       

**************************************************************************/

PUBLIC IntX StreamEncoding  ARGDEF2(T1FontPointer, fp, 
                                     Card8, hasStandardEncoding)
{
BufferString((Card8 *)"/Encoding ");/* Write out the encoding next! */

if (hasStandardEncoding)
 { BufferStringEOL((Card8 *)"StandardEncoding def");
   return ST_NOERR;
 } /* end if */
else
 { Int16 i;
   BufferStringEOL((Card8 *)"256 array");
   BufferStringEOL((Card8 *)"0 1 255 {1 index exch /.notdef put} for");
   if (fp->specialEncoding != NULL)
    { char s[128];/* Should handle all but real ridiculous charstring names */
      for (i = 0; i < 256; i++)
         if (os_strcmp(fp->specialEncoding[i], ".notdef"))
          { os_sprintf(s, "dup %d /%s put", i, fp->specialEncoding[i]);
            BufferStringEOL((Card8 *)s);
          } /* end if */
    } /* end if */
   BufferStringEOL((Card8 *)"readonly def");
 } /* end else */

return BufferError();
} /* end StreamEncoding() */


/* Shawn's code handles 2 cases--Faux and MM.  This code should use a 3rd */
/* mode--dump the existing FontBBox if not snapshotting. */

PRIVATE IntX StreamFontBBox  ARGDEF3(FontDesc *, fd, IntX, doingFaux, 
                                     FontValues, defaultVals)
{
Int32  BLX,
      BLY,
      TRX,
      TRY;

BLX = defaultVals.fontBBox.bl.x;
BLY = defaultVals.fontBBox.bl.y;
TRX = defaultVals.fontBBox.tr.x;
TRY = defaultVals.fontBBox.tr.y;

BufferString((Card8 *)"/FontBBox {");

BufferFixed(BLX); 		/* We have already rounded these, if needed */
BufferChar(' ');

BufferFixed(BLY);
BufferChar(' ');

BufferFixed(TRX);
BufferChar(' ');

BufferFixed(TRY);

BufferStringEOL((Card8 *)"} readonly def");

return BufferError();
} /* end StreamFontBBox() */


/*************************************************************************

Function name:  StreamerSetCharOpts()

**************************************************************************

Date:           03/29/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Set the options for processing a charstring
Description:    Set all the options/values used in the processing of a
                charstring.  This is mainly snapshotting and encryption
                info.  This info is also needed to stream subrs.
                
Parameters:     fp -- the font information
                s -- the streamer options
                charOpts -- the initialized charstring options
                gc -- the GetCharString() callback
                gs -- the GetSubr() callback

Return Values:  none
Notes:          
See also:       StreamCharString(), StreamSubrs()

**************************************************************************/

PUBLIC void StreamerSetCharOpts ARGDEF5(T1FontPointer, fp, PStreamerOpts, s, 
       CharStrOpts *, charOpts, GetCharStringFunc, gc, GetSubrFunc, gs)
{
Int32 dummyLen;

charOpts->doingFaux = s->doingFaux;

charOpts->canSparseSubrs = true;	/* Initially, we think we can */
charOpts->flattenCharStrs = s->snapShot | s->subrFlatten;
charOpts->GetCharString = gc;
charOpts->GetSubr = gs;

charOpts->lenIVBytes[0] = '\0';
charOpts->lenIVBytes[1] = '\0';
charOpts->lenIVBytes[2] = '\0';
charOpts->lenIVBytes[3] = '\0';
charOpts->lenIV = s->lenIV;

charOpts->charStringKey = CHARS_KEY;
if (s->lenIV > -1)	/* Init the encryption key */
    BufferEncrypt(charOpts->lenIVBytes, charOpts->lenIVBytes, s->lenIV, 
                  &dummyLen, &charOpts->charStringKey, ST_ENCRYPT);

} /* end StreamerSetCharOpts() */



/*************************************************************************

Function name:  StreamFontDict()

**************************************************************************

Date:           03/28/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream the Font Dictionary portion of a font file
Description:    Stream all the info from the start of the font file to 
                the encrypted portion (including the encoding vector).
                
Parameters:     fp - pointer to the font data
                s - streamer options
Return Values:  see the ST_ values in streamer.h
Notes:          
See also:       

**************************************************************************/

PUBLIC IntX StreamFontDict ARGDEF4(T1FontPointer, fp, PStreamerOpts, s,
                                   FauxInfoPointer, fi, PBufferStatus, b)
{
IntX code, numEntries = 10;

BufferRestore(b);
BufferSetEEKey(0, ST_NO_ENCRYPTION);	/* No encryption at start */

/* Should we have a comment in here somewhere alluding to the fact that */
/* this is a modified font? */
BufferString((Card8 *)"%!PS-AdobeFont-1.0: ");
BufferString((Card8 *)fp->fontName);
BufferChar(' ');
if (fp->Version)
   BufferStringEOL((Card8 *)fp->Version);

BufferString((Card8 *)"%%CreationDate: ");
BufferTime();			/* Apt to vary--make it easy to change */

if ((fp->pFontDict[0]->numMasters > 1) && (s->snapShot == ST_SNAPSHOT))
   numEntries += 1;	/* Leave room for blend stuff */

BufferStringEOL((Card8 *)"11 dict begin");
BufferString((Card8 *)"/FontInfo ");
BufferInt(numEntries);
BufferStringEOL((Card8 *)" dict dup begin");
   
if (fp->Version)
 { BufferString((Card8 *)"/version (");
   BufferString((Card8 *)fp->Version);
   BufferStringEOL((Card8 *)") readonly def");
 } /* end if */

//Change so that the copyright is all in one line. TH 03/27/96
//BufferStringEOL((Card8 *)"/Copyright ((C) 1994 Adobe Systems Inc. All rights reserved.");
BufferString((Card8 *)"/Copyright ((C) 1996 Adobe Systems Inc. All rights reserved.");
BufferStringEOL((Card8 *)") readonly def");

BufferString((Card8 *)"/FullName (");
BufferString((Card8 *)fp->FullName);
BufferStringEOL((Card8 *)") readonly def");

BufferString((Card8 *)"/FamilyName (");
BufferString((Card8 *)fp->FamilyName);
BufferStringEOL((Card8 *)") readonly def");

/* For MM snapshots and faux fonts we don't really know the name of the weight.
   So we use this field as part of the "breadcrumbs" to indicate to other
   programs what has happened to this font. */ 
BufferString((Card8 *)"/Weight (");
if (s->snapShot)
   BufferString((Card8 *)"SnapshotMM");
else if (s->doingFaux)
   BufferString((Card8 *)"SnapshotFaux");
else
   BufferString((Card8 *)fp->Weight);
BufferStringEOL((Card8 *)") readonly def");

/* This "breadcrumb" is the real clue that streamer processed the file.  In
   all files streamer touches it will add this entry.  */
BufferString((Card8 *)"/BaseFontName /");
BufferString((Card8 *)fp->fontName);
BufferStringEOL((Card8 *)PS_DefString);

if (s->snapShot)
 { Card16 i;
   BufferString((Card8 *)"/BaseFontBlend [ ");
   for (i = 0; i < s->blendLen; i++)
      BufferFixed(s->blendVector[i]);
   BufferStringEOL((Card8 *)" ] def");
 } /* end if */

BufferString((Card8 *)"/ItalicAngle ");
BufferFixed(fp->ItalicAngle);
BufferStringEOL((Card8 *)PS_DefString);

if (fp->isFixedPitch)
   BufferStringEOL((Card8 *)"/isFixedPitch true def");
else
   BufferStringEOL((Card8 *)"/isFixedPitch false def");

BufferString((Card8 *)"/UnderlinePosition ");

BufferFixed(fp->UnderlinePosition);
BufferStringEOL((Card8 *)PS_DefString);

BufferString((Card8 *)"/UnderlineThickness ");
BufferFixed(fp->UnderlineThickness);
BufferStringEOL((Card8 *)PS_DefString);

BufferStringEOL((Card8 *)"end readonly def");        /* End FontInfo dict */

BufferString((Card8 *)"/FontName /");
BufferString((Card8 *)fp->fontName);
BufferStringEOL((Card8 *)PS_DefString);

BufferString((Card8 *)"/PaintType ");
BufferInt((*(fp->pFontDict))->paintType);
BufferStringEOL((Card8 *)PS_DefString);

BufferStringEOL((Card8 *)"/FontType 1 def");
StreamFontMatrix(fp, s->doingFaux, fi);    /* Write out the font matrix */

code = StreamEncoding(fp, (Card8)fp->hasStandardEncoding);
if (code != ST_NOERR)
    return ST_NOERR;

/****** Turn this off since we are doing font subsetting *********
BufferString((Card8 *)"/UniqueID ");
BufferInt(fp->uniqueID);
BufferStringEOL((Card8 *)PS_DefString);
******************************************************************/

StreamFontBBox(fp->pFontDict[0], s->doingFaux, fp->defaultVals);

BufferStringEOL((Card8 *)"currentdict end");

BufferFlush();
BufferSave(b);
return BufferError();
} /* end StreamFontDict() */


/*************************************************************************

Function name:  StreamEEXEC()

**************************************************************************

Date:           05/26/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        stream the encryption info and set the buffer's flags
Description:    Stream the encryption info and set the buffer's flags
                
Parameters:    s - the streamer options (one of which is encryption)
                
Return Values:  standard ST_ errs
Notes:          
See also:       

**************************************************************************/

PUBLIC IntX StreamEEXEC ARGDEF1(PStreamerOpts, s)
{
/* Decide whether we need Exec encryption?  If so stream the right
   stuff and prepare for encryption. */
if (s->eexec != ST_NO_ENCRYPTION)
 { long FourBytes = 0L;

   BufferStringEOL((Card8 *)"currentfile eexec");
   BufferFlush();               /* Empty the buffer out */
   BufferSetEEKey((Card16)EEXEC_KEY, (Card8)s->eexec);
                                /* Always LenIV = 4 for output */
   BufferChars((unsigned char *) &FourBytes, 4);
 } /* end if */
else /* eexec makes the systemdict current.  When encryption is off this
        must be done explicitly. */
   BufferStringEOL((Card8 *)"systemdict begin"); 

return ST_NOERR;
} /* end StreamEEXEC() */


/*************************************************************************

Function name:  StreamPrivateDict()

**************************************************************************

Date:           03/28/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream the Private Dictionary entries.
Description:    Streams the Private dictionary information, beginning 
                with the encryption statement "currentfile eexec",
                (or the "systemdict begin" for completely unencrypted
                fonts.  Note that these cannot be parsed by ATM, only 
                PostScript (and streamer) understand them).
                ending after the OtherSubrs (before the subrs).
                
Parameters:     fp - the font specific data
                s - the streamer options
                
Return Values:  see the ST_ values in streamer.h
Notes:          
See also:       

**************************************************************************/

PUBLIC IntX StreamPrivateDict ARGDEF3(T1FontPointer, fp, PStreamerOpts, s,
                                      PBufferStatus, b)
{
IntX numEntries = 20;
float defaultExpFactor = (float)0.06;

BufferRestore(b);
StreamEEXEC(s);

if (s->lenIV != 4)
   numEntries++;
BufferString((Card8 *)"dup /Private ");
BufferInt(numEntries);
BufferStringEOL((Card8 *)" dict dup begin");

BufferStringEOL((Card8 *)"/RD {string currentfile exch readstring pop} executeonly def");
BufferStringEOL((Card8 *)"/ND {noaccess def} executeonly def");
BufferStringEOL((Card8 *)"/NP {noaccess put} executeonly def");
// Add these definitions just in case the font uses these to define /OtherSubrs.  TH 03/26/96.
//BufferStringEOL((Card8 *)"/-| {string currentfile exch readstring pop}executeonly def");
//BufferStringEOL((Card8 *)"/|- {noaccess def}executeonly def");
//BufferStringEOL((Card8 *)"/| {noaccess put}executeonly def");

BufferStringEOL((Card8 *)"/MinFeature {16 16} def");
BufferStringEOL((Card8 *)"/password 5839 def");
if (s->lenIV != 4)
 { BufferString((Card8 *)"/lenIV ");
   BufferInt(s->lenIV);
   BufferStringEOL((Card8 *)PS_DefString);
 } /* end if */

StreamBlueValues(fp->pFontDict[0], &fp->defaultVals);
StreamOtherBlues(fp->pFontDict[0], &fp->defaultVals);
StreamFamilyBlues(fp->pFontDict[0], &fp->defaultVals);
StreamFamilyOtherBlues(fp->pFontDict[0], &fp->defaultVals);
StreamStdW(&fp->defaultVals);
StreamStemSnap(fp->pFontDict[0], &fp->defaultVals);


if ((*(fp->pFontDict))->languageGroup != 0)
 { BufferString((Card8 *)"/LanguageGroup ");
   BufferInt(fp->pFontDict[0]->languageGroup);
   BufferStringEOL((Card8 *)PS_DefString);

   if (fp->pFontDict[0]->languageGroup == 1)
      BufferStringEOL((Card8 *)"/RndStemUp false def");

   /* Again, Shawn was reaching into fontvals & I found it in FontDesc */
   if (fp->pFontDict[0]->expansionFactor != pflttofix(&defaultExpFactor))
    { BufferString((Card8 *)"/ExpansionFactor ");
      BufferFixed(fp->pFontDict[0]->expansionFactor);
      BufferStringEOL((Card8 *)PS_DefString);
    } /* end if */
 } /* end if */

StreamBlueStuff(&fp->defaultVals);
StreamForceBold(&fp->defaultVals);

if ((fp->pFontDict[0]->numMasters > 1) && (s->snapShot == ST_SNAPSHOT))
   BufferStringEOL((Card8 *)"3 index /Blend get /Private get begin");

/* Just 4 place holders for the Flex and HintSubst other subrs */
if (fp->pOtherSubrs == NULL)
   BufferStringEOL((Card8 *)"/OtherSubrs [ {} {} {} {} ] def");
else
 { BufferStringEOL((Card8 *)"/OtherSubrs");
   BufferChars(fp->pOtherSubrs, fp->otherSubrSize);
   BufferStringEOL((Card8 *)" ");
 } /* end else */

BufferFlush();
BufferSave(b);
return BufferError();
} /* end StreamPrivateDict() */


/*************************************************************************

Function name:  StreamFontEnd()

**************************************************************************

Date:           03/28/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream the end of font info (from the end of the charstrings
                to the eof).
Description:    Stream the end of font info (from the end of the charstrings
                to the eof).
                
Parameters:     
                
Return Values:  see the ST_ values in streamer.h
Notes:          
See also:       

**************************************************************************/

PUBLIC IntX StreamFontEnd ARGDEF2(PBufferStatus, b, PStreamerOpts, s)
{
IntX i;

BufferRestore(b);
BufferStringEOL((Card8 *)"end");
//Comment out to support incremental download
//BufferStringEOL((Card8 *)"readonly put");
//BufferStringEOL((Card8 *)"noaccess put");
BufferStringEOL((Card8 *)"put");
BufferStringEOL((Card8 *)"put");
BufferStringEOL((Card8 *)"dup /FontName get exch definefont pop");

  if (s->eexec != ST_NO_ENCRYPTION)	
  { BufferStringEOL((Card8 *)"mark currentfile closefile");

   BufferFlush();                            /* Empty everything out again */
   BufferSetEEKey(0, ST_NO_ENCRYPTION);      /* Turn off encryption */

   BufferStringEOL((Card8 *)"");
   for (i = 0; i < 8; i++)                   /* Write 512 ascii zeroes */
      BufferStringEOL((Card8 *)"0000000000000000000000000000000000000000000000000000000000000000");
   BufferStringEOL((Card8 *)"cleartomark");           /* Say bye bye */
 } /* end if */
else
   BufferStringEOL((Card8 *)"end");	/* "end" for systemdict begin */

BufferFlush();                            /* Empty out this stuff */
BufferSave(b);
return BufferError();;
} /* end StreamFontEnd() */



/*************************************************************************

Function name:  StreamerStart()

**************************************************************************

Date:           03/29/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Initialize the streamer code for a particular font
Description:    Sets up the streamer internals for a particular font
                (including the data buffer).  All relevant info is 
                stored in the 3 structures.
                
Parameters:     fp -- contains font information
                s -- contains options for streamer
                b -- contains the buffer's internal state
                
Return Values:  ST_BUFFER_TOO_SMALL - couldn't get a big enough buffer
Notes:          Currently the buffer is flushed before any of the interface
                functions return.  This does not mean that the buffer status
                can be ignored! 
See also:       StreamerEnd()

**************************************************************************/

PUBLIC IntX StreamerStart ARGDEF5(T1FontPointer, fp, PStreamerOpts, s,
          CharStrOpts *, co, PBufferStatus, b, Card32, bufSize)
{

if (s->MemoryRealloc == NULL)
   return ST_NO_MEM_CALLBACK;

MemoryRealloc = s->MemoryRealloc;

BufferInitialize(bufSize, s);
BufferSave(b);

/* Allocate the buildCharArray (memory used by newer fonts) */
if ((fp->buildCharArray == NULL) &&
    !MemoryRealloc((void **)&fp->buildCharArray, 
                   fp->pFontDict[0]->lenBuildCharArray*sizeof(Fixed)))
   return ST_OUT_OF_MEM;

/* This info is used by the charstrings and font dicts. */
/* For Faux fonts I may need to call MakeFontVal for each character. */
MakeFontVal(fp, s); 

CheckSubrs(fp, co);

return BufferError();
} /* end StreamerStart() */


/*************************************************************************

Function name:  StreamFont()

**************************************************************************

Date:           03/28/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Stream a Type 1 font
Description:    Create an output Type 1 font from input font data.
                Input font data is in the fp structure.  Charstrings and 
                Subrs are accessed through callbacks.  Format and content
                of the output font is determined by the streamer options
                (see streamer.h)
                
Parameters:     fp -- the font specific data
                s -- the streamer options
                
Return Values:  ST_NO_DATA -- The fp was null or invalid
                ST_NOERR -- everything was fine
                (other ST_ error values can be returned from nested funcs)
Notes:          
See also:       

**************************************************************************/

PUBLIC IntX StreamFont ARGDEF5(T1FontPointer, fp, PStreamerOpts, s,
       CharStrOpts *, charOpts, PBufferStatus, b, FauxInfoPointer, fi)
{
IntX i, code = ST_NOERR, sparseMethod = s->sparseMethod;
CharDataPtr charString;
Card16 charLen;
Card8 *charName;

if (fp == NULL)			/* Better be a T1FontPointer! */
   return ST_NO_DATA;

StreamFontDict(fp, s, fi, b);
StreamPrivateDict(fp, s, b);

/* Note that the subrs need the lenIV info from the charstrings */
StreamSubrs(fp, charOpts, b);

if (BufferError() != ST_NOERR)
   return BufferError();

/* A small amount of PostScript must be generated around the charstrings */
BufferString((Card8 *)"2 index /CharStrings ");
BufferInt(fp->numCharStrings);
BufferStringEOL((Card8 *)" dict dup begin");
BufferSave(b);

for (i = 0; i < fp->numCharStrings; i++)
 { code = charOpts->GetCharString(i, INDEX_IS_CHARINDEX, &charString, &charLen,
                           &charName);
   if (!code)
      return ST_CALLBACKFAILED;

   /* For Faux fonts I must get the blend/design vector and use this to
      get the weight vector and blend hints. */
   if (s->doingFaux && (charString != NULL))
    { Card8 dummy;
      if ((*s->GetFauxInfo)(i, INDEX_IS_NAME, (char *)charName, s->blendVector, &dummy))
       { code = MakeFontVal(fp, s);
         if (code != ST_NOERR)
            return code;
       } /* end if */
      else /* Can't get faux data so this charstring isn't in faux set. */
       { charString = NULL;
         /* Too late to change number of charstrings--don't want to lie */
         sparseMethod = ST_SPARSE_ENDCHAR;
       } /* end else */

    } /* end if */

   /* If charString is NULL don't want to accidently report error. */
   code = ST_NOERR;	

   if ((charString != NULL) || (sparseMethod != ST_SPARSE_REMOVE))
      code = StreamCharString(charString, charLen, charName, fp, charOpts, fi, b);
   if (code != ST_NOERR)
      return code;
 } /* end for */

BufferStringEOL((Card8 *)"end"); 		/* end of the charstrings */
BufferSave(b);

StreamFontEnd(b, s);

return BufferError();
} /* end StreamFont() */


/*************************************************************************

Function name:  StreamerEnd()

**************************************************************************

Date:           03/29/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Clear any state.   Free the internal buffer.
Description:    Clear any state.   Free the internal buffers (including
                the buildCharArray).
                
Parameters:     fp -- the pointer to font info
                s -- the streamer options
                b -- the internal buffer's state
Return Values:  none.
Notes:          
See also:       StreamerStart()

**************************************************************************/

PUBLIC void StreamerEnd ARGDEF3(T1FontPointer, fp, PStreamerOpts, s, 
                                PBufferStatus, b)
{
BufferRestore(b);
BufferDeinit(s);
BufferSave(b);

/* Deallocate the buildCharArray (memory used by newer fonts) */
if (fp->buildCharArray != NULL)
   MemoryRealloc((void **)&fp->buildCharArray, 0);
} /* end StreamerEnd() */



