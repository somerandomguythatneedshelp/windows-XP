/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: STATUS.H                                               */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

enum   //Driver entry point id's
{
   ID_BITBLT,
   ID_COLORINFO,
   ID_CONTROL,
   ID_DEVICEBITMAP,
   ID_DEVICECAPS,
   ID_DEVICEMODE,
   ID_DIBTODEVICE,
   ID_DISABLE,
   ID_ENABLE,
   ID_ENUMDFONTS,
   ID_ENUMOBJ,
   ID_EXTDEVICEMODE,
   ID_EXTTEXTOUT,
   ID_FASTBORDER,
   ID_GETCHARWIDTH,
   ID_OUTPUT,
   ID_PIXEL,
   ID_REALIZEOBJECT,
   ID_SCANLR,
   ID_SETATTRIBUTE,
   ID_STRBLT,
   ID_STRETCHBLT,
   ID_STRETCHDIB
} ;

// N.B. The function fIsMarkingS in ..\dmg\status.c lists attributes
// of members of the above enumeration.  If you add or remove members 
// above, be sure to update fIsMarkingS as well.


//function prototypes

VOID FAR PASCAL EntryMonitor(int entry_id, LPPDEVICE lppd) ;
VOID FAR PASCAL ExitMonitor(int entry_id, LPPDEVICE lppd ) ;
