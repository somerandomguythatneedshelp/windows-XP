/***********************************************************************

    MODULE:  fntcache.c

    PROGRAM:

    PURPOSE: Contains font file management functions for the PScript driver.

    FUNCTIONS:

***********************************************************************/

#include "generic.h"
#include "regsetup.h"
#include "ctype.h"
#include <string.h>

#pragma code_seg(_ENUMSEG)

char ENUMSEG cszType1[] = " (Type 1)";  // notice space befor (
char ENUMSEG cszPFM[] =  "M";
char ENUMSEG cszPFB[] =  "B";
char ENUMSEG cszVBar[] = "|";
char ENUMSEG cVBar =     '|';
char ENUMSEG cszColon[] =":";
char ENUMSEG cColon =    ':';
char ENUMSEG cszComma[] =",";
char ENUMSEG cComma = ',';

// These registry keys are hard coded as all othe reg keys in Microsoft's WINREG.H.
// Not "\\" at the beginning, otherwise RegOpenKey() will FAIL in Win95 !!!!!!!
char ENUMSEG gszRegCurVersion[] =      "SOFTWARE\\Microsoft\\Windows\\CurrentVersion";
char ENUMSEG gszRegFontsPath[] =      "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\PostScriptFonts";
char ENUMSEG gszRegFontsCache[] =      "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\PostScriptFonts\\NameCache";
char ENUMSEG gszRegFontsPathPaths[] = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\PostScriptFonts\\Paths";
 // AdobePS's MFD file name key in reg: Port="MFDFile.MFD". Our MFD is in diff format from PScript, so we use diff subfolder
char ENUMSEG gszSerial[] = "SerialNumber";  // Key to notify other interested parties about our changes in Registry
char ENUMSEG gszSecondSerial[] = "SecondarySerialNumber"; //Key to identify another serial number
char ENUMSEG gszDriverSubKey[] = "System\\CurrentControlSet\\Control\\Print\\Environments\\Windows 4.0\\Drivers\\";
char ENUMSEG gszWPXKey[]       = "WPX File";
char ENUMSEG gszPort[] = "PORT";      //Port for this friendly name printer.
char ENUMSEG cszSFNT[] =  "T";
char ENUMSEG cszROMVer[] =  "V";
char ENUMSEG cROMVer =  'V';
char ENUMSEG cszDLVer[] =  "v";
char ENUMSEG cDLVer =  'v';
char ENUMSEG cszXUID[] =  "X";
char ENUMSEG cszROM[] =  "ROM";
char ENUMSEG cszDevice[] = "D";
char ENUMSEG gszPFMDir[] = "pfm";
char ENUMSEG gszLOFRegKey[] = "ResidentFontsFile";
char ENUMSEG gszRegFontsR[] = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Fonts";
char ENUMSEG gszFontsDirRegKey[] = "MFD0";
char ENUMSEG gszFontsDirCkSumKey[] = "MFD0CkSum";
#ifdef MICROSOFT_DRIVER_VERSION
char ENUMSEG gszFontsDIR[] = "PSFNTDIR.MFD";
#else
char ENUMSEG gszFontsDIR[] = "FONTSDIR.MFD";
#endif
char ENUMSEG gszMFMCrc[] = "MFMtoHostPS";
char ENUMSEG gszFontsLastUpdate[] = "ResidentFontLastUpdate";
char ENUMSEG gszATMCkSum[] = "ATMCkSum";
char ENUMSEG gszNoEnum[] = "z";
char ENUMSEG gszNoEnumRealize[] = "Z";

#define PSFR 0
#define ATMDB 1

#define PFM  0x01
#define PFB  0x20

#define SHIFTJIS_CHARSET    128
#define HANGEUL_CHARSET     129
#define JOHAB_CHARSET       130
#define GB2312_CHARSET      134
#define CHINESEBIG5_CHARSET 136

CACHEHDR chFonts;

WORD crc_16_tab[] = {
    0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50a5, 0x60c6, 0x70e7,
    0x8108, 0x9129, 0xa14a, 0xb16b, 0xc18c, 0xd1ad, 0xe1ce, 0xf1ef,
    0x1231, 0x0210, 0x3273, 0x2252, 0x52b5, 0x4294, 0x72f7, 0x62d6,
    0x9339, 0x8318, 0xb37b, 0xa35a, 0xd3bd, 0xc39c, 0xf3ff, 0xe3de,
    0x2462, 0x3443, 0x0420, 0x1401, 0x64e6, 0x74c7, 0x44a4, 0x5485,
    0xa56a, 0xb54b, 0x8528, 0x9509, 0xe5ee, 0xf5cf, 0xc5ac, 0xd58d,
    0x3653, 0x2672, 0x1611, 0x0630, 0x76d7, 0x66f6, 0x5695, 0x46b4,
    0xb75b, 0xa77a, 0x9719, 0x8738, 0xf7df, 0xe7fe, 0xd79d, 0xc7bc,
    0x48c4, 0x58e5, 0x6886, 0x78a7, 0x0840, 0x1861, 0x2802, 0x3823,
    0xc9cc, 0xd9ed, 0xe98e, 0xf9af, 0x8948, 0x9969, 0xa90a, 0xb92b,
    0x5af5, 0x4ad4, 0x7ab7, 0x6a96, 0x1a71, 0x0a50, 0x3a33, 0x2a12,
    0xdbfd, 0xcbdc, 0xfbbf, 0xeb9e, 0x9b79, 0x8b58, 0xbb3b, 0xab1a,
    0x6ca6, 0x7c87, 0x4ce4, 0x5cc5, 0x2c22, 0x3c03, 0x0c60, 0x1c41,
    0xedae, 0xfd8f, 0xcdec, 0xddcd, 0xad2a, 0xbd0b, 0x8d68, 0x9d49,
    0x7e97, 0x6eb6, 0x5ed5, 0x4ef4, 0x3e13, 0x2e32, 0x1e51, 0x0e70,
    0xff9f, 0xefbe, 0xdfdd, 0xcffc, 0xbf1b, 0xaf3a, 0x9f59, 0x8f78,
    0x9188, 0x81a9, 0xb1ca, 0xa1eb, 0xd10c, 0xc12d, 0xf14e, 0xe16f,
    0x1080, 0x00a1, 0x30c2, 0x20e3, 0x5004, 0x4025, 0x7046, 0x6067,
    0x83b9, 0x9398, 0xa3fb, 0xb3da, 0xc33d, 0xd31c, 0xe37f, 0xf35e,
    0x02b1, 0x1290, 0x22f3, 0x32d2, 0x4235, 0x5214, 0x6277, 0x7256,
    0xb5ea, 0xa5cb, 0x95a8, 0x8589, 0xf56e, 0xe54f, 0xd52c, 0xc50d,
    0x34e2, 0x24c3, 0x14a0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
    0xa7db, 0xb7fa, 0x8799, 0x97b8, 0xe75f, 0xf77e, 0xc71d, 0xd73c,
    0x26d3, 0x36f2, 0x0691, 0x16b0, 0x6657, 0x7676, 0x4615, 0x5634,
    0xd94c, 0xc96d, 0xf90e, 0xe92f, 0x99c8, 0x89e9, 0xb98a, 0xa9ab,
    0x5844, 0x4865, 0x7806, 0x6827, 0x18c0, 0x08e1, 0x3882, 0x28a3,
    0xcb7d, 0xdb5c, 0xeb3f, 0xfb1e, 0x8bf9, 0x9bd8, 0xabbb, 0xbb9a,
    0x4a75, 0x5a54, 0x6a37, 0x7a16, 0x0af1, 0x1ad0, 0x2ab3, 0x3a92,
    0xfd2e, 0xed0f, 0xdd6c, 0xcd4d, 0xbdaa, 0xad8b, 0x9de8, 0x8dc9,
    0x7c26, 0x6c07, 0x5c64, 0x4c45, 0x3ca2, 0x2c83, 0x1ce0, 0x0cc1,
    0xef1f, 0xff3e, 0xcf5d, 0xdf7c, 0xaf9b, 0xbfba, 0x8fd9, 0x9ff8,
    0x6e17, 0x7e36, 0x4e55, 0x5e74, 0x2e93, 0x3eb2, 0x0ed1, 0x1ef0};

BOOL bInitFontCache=FALSE;
BOOL bInitFontCache2=FALSE;
DATETIME DateTime;


/********************************************************
**
** Function:   AddListOfFontCache
**
********************************************************/
VOID NEAR PASCAL AddListOfFontCache(LPFONTCACHE lpCache)
{
    LPFONTCACHE lptemp;

    lptemp = chFonts.lpCacheStart;
    if (! lptemp)
    {
        /* Font Cache Empty */
        chFonts.lpCacheStart = lpCache;
        chFonts.wNumFontCached = 1;
    }
    else
    {
        chFonts.lpCacheStart= lpCache;  //add new cache to the begining.
        chFonts.wNumFontCached++;
    }

    lpCache->lpNextCache = lptemp;
    lpCache->wUseCount = 0;
    lpCache->bDelete = FALSE;
}

/********************************************************
**
** Function:   RemoveListOfFontCache
**
********************************************************/
LPFONTCACHE NEAR PASCAL RemoveListOfFontCache(LPFONTCACHE FAR *lpHeader, LPFONTCACHE lpCache, WORD FAR *numCache)
{
    LPFONTCACHE lptemp = NULL;


    if (!*lpHeader || !lpCache)
     return lptemp;

    if ( *lpHeader == lpCache) //if we are looking at the head cache.
    {
        lptemp = *lpHeader = lpCache->lpNextCache;
    }
    else
    {
      lptemp = *lpHeader;
      while( lptemp->lpNextCache != lpCache)
      {
         lptemp = lptemp->lpNextCache;
      }
      lptemp->lpNextCache = lpCache->lpNextCache;
      lptemp = lpCache->lpNextCache;
    }

    GlobalFreePtr(lpCache->hpDirIndex);
    GlobalFreePtr(lpCache);
    *numCache--;

    return (lptemp);
}

HPFONTDIRECTORY FAR PASCAL GetHostFontCache(LPWORD lpwNumFonts)

{
   if (GetMFDsCached(FALSE, NULL) != RC_ERROR)
   {
      *lpwNumFonts = (chFonts.lpFontDirCurrent)->wNumFonts[PSFR];
      return (HPFONTDIRECTORY) (chFonts.lpFontDirCurrent)->hpFontDirTab[PSFR];
   }

   return (HPFONTDIRECTORY) NULL;
}


/********************************************************
** Function:   GetFontCache
**
**        Get List of Font cached, or create one if necessary.
**        Create and load FontDirectory MFD.
** Input: LPSTR lpszFriendly Name - Friendly Name of printer instance
** Output: LPFONTCACHE - Long pointer to Font Cache.
*********************************************************/
LPFONTCACHE FAR PASCAL GetFontCache(LPSTR lpszFriendlyName)
{
   LPFONTCACHE lpCache = NULL;
   char szLOFName[PS_FILE_PATH_LENGTH]; //might need to create new file
   char szPrnInstKey[BUF_SIZE];
   HKEY hkey = NULL;
   SERIALNUMS prnInstData;
   DWORD dwCBSize = BUF_SIZE;
   char szTempBuffer[BUF_SIZE];
   BOOL bUpdatedResReg = FALSE;
   BOOL bUpdatePortFonts = FALSE;

   if (!*lpszFriendlyName) //null printer instance
      return NULL;

   //**Note** chFonts have cached the PSFont SerialNo and TTFont SerialNo
   //set path to resident font for specific printer.
   LoadString(ghDriverMod, IDS_REGSTR_RESIDENT_FONTS, szTempBuffer, BUF_SIZE);
   wsprintf((LPSTR)szPrnInstKey, szTempBuffer, lpszFriendlyName);

   /* Get Resident Font Serial number*/
   prnInstData.dwResFontsSerialNo = GetSerialNo(szPrnInstKey);
   prnInstData.dwScndPSFRSerialNo = GetSecondSerialNo(gszRegFontsPath);

   /* merge font from win.ini if it is first time loading printer cache*/
   GetMFDsCached(chFonts.lpCacheStart?FALSE:TRUE , (LPSTR) lpszFriendlyName);

   if ((lpCache = GetListOfFontFrCache(lpszFriendlyName, chFonts, (LPSERIALNUMS) &prnInstData)) == NULL)
   {
      /* if we have not load this printer instance then update the port info*/
      /* however, if this is the first time loading printer cache */
      /* then send false because we called it above*/
      GetMFDsCached(chFonts.lpCacheStart?TRUE:FALSE, (LPSTR) lpszFriendlyName);

      //Update resident registry if not already done so.
      if (!bUpdatedResReg)
         UpdateResidentFonts(lpszFriendlyName, prnInstData.dwResFontsSerialNo);

      prnInstData.dwResFontsSerialNo = GetSerialNo(szPrnInstKey); //might of changed

      if (!(chFonts.lpFontDirCurrent)->wTotalNumFonts) //create a dummy font cache.
      {
CreateDummyCache:
        if ((lpCache = (LPFONTCACHE) GlobalAllocPtr(GDLLHND, sizeof(FONTCACHE))) == NULL)
            return NULL;

         lstrcpy(lpCache->szFriendlyName,lpszFriendlyName);
         lpCache->wNumFonts = 0;
         lpCache->dwResFontsSerialNo = prnInstData.dwResFontsSerialNo;
         lpCache->dwPSFRSerialNo = (chFonts.lpFontDirCurrent)->dwPSFRSerialNo;
         lpCache->dwMFD0TimeStamp = (chFonts.lpFontDirCurrent)->dwTimeStamp[PSFR]; //MFD0 TimeStamp
         lpCache->dwSecondPSFRSerialNo = prnInstData.dwScndPSFRSerialNo;
         lpCache->dwTTFRSerialNo = (chFonts.lpFontDirCurrent)->dwTTFRSerialNo;
         lpCache->bDelete = FALSE;
      }
      else if ((lpCache = GetListOfFonts(lpszFriendlyName,
                                    chFonts,
                                    (LPSERIALNUMS) &prnInstData)) == NULL)
      {
         CreateMFDFileName(szLOFName);
         if (prnInstData.dwResFontsSerialNo = CreateListOfFonts(lpszFriendlyName, chFonts, (LPSTR) szLOFName, &prnInstData))
         {
            /* Add path to registry*/
            SetListOfFontsFileName(lpszFriendlyName, szLOFName);
            if (lpCache = LoadListOfFonts(szLOFName,
                                          chFonts,
                                          (LPSERIALNUMS) &prnInstData))
            {
               /*Resident Font Serial number might of changed*/
               /* Set Resident Font Serial number*/
               SetSerialNo((LPSTR)szPrnInstKey, prnInstData.dwResFontsSerialNo);
            }
         }
         if (!lpCache) //failed to create or load font
            goto CreateDummyCache;
      }

      /* Add cache List of Font linked list*/
      if (lpCache)
      {
         lpCache->hpFontDirs = (chFonts.lpFontDirCurrent)->hpFontDirTab;
         lpCache->hpPFMPrologs = (chFonts.lpFontDirCurrent)->hpPFMProlog;
         AddListOfFontCache(lpCache);
      }
   }

   /* Increment use count*/
   if (lpCache)
   {
      lpCache->wUseCount++;
   }

   return lpCache;
}

/********************************************************
** Function:   GetListOfFontFrCache
**
**        Get List of Font from cached
** Input: LPSTR lpszFriendly Name - Friendly Name of printer instance
**        DWORD serialNo - the cache found must be bDelete == FALSE
**                         and serialNo matches.
** Output: LPFONTCACHE - Long pointer to Font Cache.
*********************************************************/
LPFONTCACHE NEAR PASCAL GetListOfFontFrCache(LPSTR lpszFriendlyName, CACHEHDR ch, LPSERIALNUMS lpPIData)
{
   LPFONTCACHE lpCache = chFonts.lpCacheStart;

   while (lpCache)
   {
      if ((lstrcmpi((LPSTR) lpCache->szFriendlyName, lpszFriendlyName) == 0) &&
          (lpCache->bDelete == FALSE) &&
          (lpCache->wNumFonts <= (chFonts.lpFontDirCurrent)->wTotalNumFonts)) //in case FONTDIR.MFD free from under us.
      {
         if ((lpCache->dwResFontsSerialNo == lpPIData->dwResFontsSerialNo)
            && (lpCache->dwSecondPSFRSerialNo == lpPIData->dwScndPSFRSerialNo)
            && (lpCache->dwPSFRSerialNo == (ch.lpFontDirCurrent)->dwPSFRSerialNo)
            && (lpCache->dwMFD0TimeStamp == (ch.lpFontDirCurrent)->dwTimeStamp[PSFR])
            && (lpCache->dwTTFRSerialNo == (ch.lpFontDirCurrent)->dwTTFRSerialNo))
         {
                return lpCache; //found it.
         }
         /* This cache has the wrong serial number */
         /* for a friendly printer. A new one will be created*/
         /* So delete this one if not being use*/
         else if (!lpCache->wUseCount)
         {     //This cache is obsolete
            lpCache = RemoveListOfFontCache((LPFONTCACHE FAR *) &(chFonts.lpCacheStart), lpCache, (WORD FAR *) &(chFonts.wNumFontCached));
            continue;
         }
      }

     lpCache = lpCache->lpNextCache;
   }

   return (LPFONTCACHE) NULL;
}


/********************************************************
**
** Function:   GetListOfFonts
**
********************************************************/
LPFONTCACHE NEAR PASCAL GetListOfFonts(LPSTR lpszFriendlyName, CACHEHDR ch,  LPSERIALNUMS lpPIData)
{
   char szPrnInstValue[SM_BUF];
   DWORD   cbSize = SM_BUF;
   OFSTRUCT ofFileStruct;
   LPFONTCACHE lpCache = NULL;

   GetListOfFontsFileName(lpszFriendlyName,  (LPSTR) szPrnInstValue, cbSize);

   //if the file exist for this friendly printer
   if (szPrnInstValue[0] &&
      (OpenFile((LPSTR)szPrnInstValue,(LPOFSTRUCT) &ofFileStruct,
                                 OF_EXIST) !=HFILE_ERROR))
   {
      /* load it */
      lpCache = LoadListOfFonts(szPrnInstValue, ch, lpPIData);
   }
   if ((lpCache == NULL) && szPrnInstValue[0])
      remove(szPrnInstValue);

   return lpCache;
}

/********************************************************
**
** Function:   LoadListOfFonts
**
********************************************************/
LPFONTCACHE NEAR PASCAL LoadListOfFonts(LPSTR lpszIndexTbl,
                                       CACHEHDR ch,
                                       LPSERIALNUMS lpPIData)
{
   LPFONTCACHE lpCache = NULL;
   HFILE       hFile;
   OFSTRUCT    ofFileStruct;
   DIRINDEXHDR  dirIndexHdr;
   DWORD     dwIndexSize = 0;
   WORD      rc = RC_ERROR;

   if (!lpszIndexTbl[0])
      return lpCache;

   if ((hFile = OpenFile(lpszIndexTbl,
               (LPOFSTRUCT) &ofFileStruct, OF_READ)) != HFILE_ERROR)
   {
      /* continue to read the rest of the file if the serial numbers match*/
      if ((_lread(hFile, &dirIndexHdr, sizeof(DIRINDEXHDR))== sizeof(DIRINDEXHDR))
               && (dirIndexHdr.dwPSFRSerialNo == (ch.lpFontDirCurrent)->dwPSFRSerialNo)
               && (dirIndexHdr.dwMFD0TimeStamp == (ch.lpFontDirCurrent)->dwTimeStamp[PSFR])
               && (dirIndexHdr.dwResFontsSerialNo == lpPIData->dwResFontsSerialNo)
               && (dirIndexHdr.dwSecondPSFRSerialNo == lpPIData->dwScndPSFRSerialNo)
               && (dirIndexHdr.dwTTFRSerialNo == (ch.lpFontDirCurrent)->dwTTFRSerialNo))
      {
         /* allocate space for the rest of the data*/
         if ((lpCache = (LPFONTCACHE) GlobalAllocPtr(GDLLHND, sizeof(FONTCACHE))) == NULL)
            goto cleanup;

         /*read in the friendly Printer Name*/
         if (dirIndexHdr.wFriendlyNameLen)
         {
            //stored friendly name to cache
            if (_lread(hFile, lpCache->szFriendlyName, dirIndexHdr.wFriendlyNameLen)
                  != dirIndexHdr.wFriendlyNameLen)
            {
               goto cleanup;
            }
         }

         /* allocate space and read the rest of the data*/
         lpCache->wNumFonts = dirIndexHdr.wTotalFonts;
         lpCache->wUseCount = 0;
         lpCache->bDelete = FALSE;
         lpCache->dwResFontsSerialNo = dirIndexHdr.dwResFontsSerialNo;
         lpCache->dwSecondPSFRSerialNo = dirIndexHdr.dwSecondPSFRSerialNo;
         lpCache->dwPSFRSerialNo = dirIndexHdr.dwPSFRSerialNo;
         lpCache->dwTTFRSerialNo = dirIndexHdr.dwTTFRSerialNo;
         lpCache->dwMFD0TimeStamp = dirIndexHdr.dwMFD0TimeStamp;
         //friendly name was stored above.

         dwIndexSize = sizeof(DIRINDEX) * dirIndexHdr.wTotalFonts;
         if (!dwIndexSize)
         {  //no fonts in this index table
            lpCache->hpDirIndex = NULL;
            rc = RC_OK;
         }
         else
         {
            lpCache->hpDirIndex = (HPDIRINDEX) GlobalAllocPtr(GDLLHND, dwIndexSize);
            if (!lpCache->hpDirIndex)
               goto cleanup;

            /* read the rest of the Index Table/List of Fonts */
            if (_hread(hFile, (HPVOID) lpCache->hpDirIndex,
                  (long) dwIndexSize) == (long) dwIndexSize)
            {
               rc = RC_OK;
            }
         }
      }
   }

cleanup:
   if (rc == RC_ERROR)
   {
      if (lpCache)
      {
         if (lpCache->hpDirIndex)
            GlobalFreePtr(lpCache->hpDirIndex);
         GlobalFreePtr(lpCache);
      }
   }

   /*close File*/
   _lclose(hFile);

   return (rc == RC_OK) ? lpCache : NULL;
}

/********************************************************
**
** Function:   GetListOfFontFileName
**
********************************************************/
void NEAR PASCAL GetListOfFontsFileName(LPSTR lpszFriendlyName, LPSTR lpszLOFFile, DWORD cbSize)
{
   HKEY hkey = NULL;
   DWORD dwType;
   LPSTR szPrnInstKey = NULL;
   LPSTR szTempBuffer = NULL;

   *lpszLOFFile = '\0';

   if ((szPrnInstKey = GlobalAllocPtr(GDLLHND,  2* SM_BUF)) == NULL)
     return;
   szTempBuffer =  szPrnInstKey+SM_BUF;

   LoadString(ghDriverMod, IDS_REGSTR_PRN_PRINTER, szTempBuffer, SM_BUF);
   wsprintf((LPSTR)szPrnInstKey, szTempBuffer, lpszFriendlyName);

   if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR) szPrnInstKey, (HKEY FAR *) &hkey)
      == ERROR_SUCCESS)
   {
      //if a key exist for this friendly printer
      if (RegQueryValueEx(hkey, (LPSTR)gszLOFRegKey, 0, (LPDWORD) &dwType,
         (LPSTR) lpszLOFFile, (LPDWORD)&cbSize) != ERROR_SUCCESS)
      {
         *lpszLOFFile = '\0';
      }
   }

   if (hkey)
      RegCloseKey(hkey);
   if (szPrnInstKey)
    GlobalFreePtr(szPrnInstKey);
   return;
}

/********************************************************
**
** Function:   SetListOfFontsFileName
**
********************************************************/
void NEAR PASCAL SetListOfFontsFileName(LPSTR lpszFriendlyName, LPSTR lpszLOFFile)
{

   HKEY hkey = NULL;
   LPSTR szPrnInstKey = NULL;
   LPSTR szTempBuffer = NULL;

   if ((szPrnInstKey = GlobalAllocPtr(GDLLHND,  2* SM_BUF)) == NULL)
     return;
   szTempBuffer = szPrnInstKey+SM_BUF;

   LoadString(ghDriverMod, IDS_REGSTR_PRN_PRINTER, szTempBuffer, SM_BUF);
   wsprintf((LPSTR)szPrnInstKey, szTempBuffer, lpszFriendlyName);

   //If the key does not exist, create it.
   if (RegCreateKey(HKEY_LOCAL_MACHINE, (LPSTR)szPrnInstKey, (HKEY FAR *) &hkey)
       == ERROR_SUCCESS)
   {
      RegSetValueEx(hkey, (LPSTR)gszLOFRegKey, 0, REG_SZ,
               lpszLOFFile, lstrlen(lpszLOFFile) +1);
   }

   if (hkey)
      RegCloseKey(hkey);

   if (szPrnInstKey)
    GlobalFreePtr(szPrnInstKey);

   return;
}



//Recreate Name Cache from PostscriptName to Family Name
//This section is created for the benefit for the font downloader.
VOID NEAR PASCAL UpdatePSRegCache(HPFONTDIRECTORY hpFontDir, WORD numFonts)
{
   HPFONTDIRECTORY curFontDir = NULL, nextFontDir = NULL;
   LPSTR lpszValue = NULL;
   HKEY hkey = NULL;
   char szAdditionalCS[10];

   if (!hpFontDir || !numFonts)
     return;

   if ((lpszValue = GlobalAllocPtr(GDLLHND,  BUF_SIZE)) == NULL)
     goto cleanup;

   //delete the registry and recreate it.
   RegDeleteKey(HKEY_LOCAL_MACHINE, (LPSTR)gszRegFontsCache) ;

   if (RegCreateKey(HKEY_LOCAL_MACHINE, (LPSTR)gszRegFontsCache, (HKEY FAR*)&hkey)
            != ERROR_SUCCESS)
      goto cleanup;

   while (numFonts > 0 )
   {
     //we want Postscript fonts only
     if (hpFontDir->dwMetricVersion == (DWORD) TrueType) //TrueTypeFont
     {
       hpFontDir++;
       numFonts--;
       continue;
     }

      curFontDir = hpFontDir;

      wsprintf (
         lpszValue,
         "%s|%d|%c|%d",
         curFontDir->szFaceName,
         (curFontDir->defTextMetric).tmWeight,
         (curFontDir->defTextMetric).tmItalic ? 'T' : 'F',
         (curFontDir->defTextMetric).tmCharSet);

      nextFontDir = ++hpFontDir; //see if the next is same as current
      numFonts--;

      while(numFonts &&
            lstrcmpi(curFontDir->szFontName, nextFontDir->szFontName)== 0)
      {
        if ((curFontDir->defTextMetric).tmCharSet != (nextFontDir->defTextMetric).tmCharSet)
        {
          wsprintf((LPSTR) szAdditionalCS, ",%d", (nextFontDir->defTextMetric).tmCharSet);
          lstrcat(lpszValue, (LPSTR) szAdditionalCS);
         }

        nextFontDir++;
        numFonts--;
      }//inner While

      hpFontDir = nextFontDir;

      //add to the registry
      if (RegSetValueEx(hkey, (LPSTR)curFontDir->szFontName, 0, REG_SZ,
               lpszValue, lstrlen(lpszValue) +1) != ERROR_SUCCESS)
        goto cleanup;

   } //outter while

cleanup:
  if (lpszValue)
    GlobalFreePtr(lpszValue);
  if (hkey)
    RegCloseKey(hkey);
}

/********************************************************
**
** Function:   GetMFDsCached
**
********************************************************/
WORD FAR PASCAL GetMFDsCached(BOOL bUpdatePortFonts, LPSTR lpszFriendlyName)
{
   WORD  status = RC_ERROR;
   DWORD dwPSFRSerialNo = 0xFFFFFFFF;
   DWORD dwTTFRSerialNo = 0xFFFFFFFF;
   DWORD dwMFD0TimeStamp = 0xFFFFFFFF;
   char szMFDName[MFD_NAME_LENGTH];
   DWORD dwCBSize = SM_BUF;
   char szTempBuf[SM_BUF];

   dwPSFRSerialNo = GetSerialNo(gszRegFontsPath);
   dwTTFRSerialNo = GetSerialNo(gszRegFontsR);

   if (!dwPSFRSerialNo)
   //The PS registry was wipped out.  Need to recreate it.
   // However, if this is the 1st time loading
   // no need to do it here.
   {

      ResetFontCache();

      if (bInitFontCache)
         InitNewFontDirCache();

   }

   if (!bInitFontCache)
   {
      InitFontCache();    //init header cache
      InitNewFontDirCache(); //init current FONTDIR
   }

   //can't allocate space for FONTSDIR.MFD something is wrong.
   if (chFonts.lpFontDirCurrent == NULL)
    return (RC_ERROR);

   //if 1st time load or cache was flushed
   if (bUpdatePortFonts || !(chFonts.lpFontDirCurrent)->dwPSFRSerialNo)
   {
     //copy all fonts from the port in Win.ini to registry
     if (GetPortFromFriendlyName(lpszFriendlyName, (LPSTR)szTempBuf, dwCBSize))
     {
         SynIniFilesToRegistry((LPSTR)szTempBuf, TRUE); //update win.ini only
     }
   }


   /* Serial number matched therefore the cache must be ok*/
   /* If hpFontDirTable[] was flushed, the serial number would be 0*/
   if (((chFonts.lpFontDirCurrent)->dwPSFRSerialNo == dwPSFRSerialNo) &&
       ((chFonts.lpFontDirCurrent)->dwTTFRSerialNo == dwTTFRSerialNo) &&
       (dwPSFRSerialNo) &&  //and PSregistry was not delete from under us
       (dwTTFRSerialNo))  //and TT registry was not delete from under us.
      return (RC_OK);

   //make sure the driver is update with ATM.ini
   //don't need to do it very often.
   //1. When we are loaded the first time
   //2. If UpdateSoftFont was called.
   //3. When the PS registry was deleted from under us.
   if (!bInitFontCache2)
   {
      bInitFontCache2 = TRUE;
      SynIniFilesToRegistry((LPSTR)NULL, FALSE);  //get fonts in ATM.ini
   }

   //PostScriptFonts SerialNumber could of changed.
   dwPSFRSerialNo = GetSerialNo(gszRegFontsPath);

   //get FontsDir.MFD path, if available, from the registry
   GetFontsMFDFrReg(gszFontsDirRegKey, (LPSTR) szMFDName, MFD_NAME_LENGTH);

   if ((status = GetFontsMFD((LPCACHEHDR) &chFonts, (LPSTR) szMFDName, dwPSFRSerialNo, dwTTFRSerialNo)) == RC_ERROR)
   {  /* Either no MFD or MFD of wrong version*/
      CreateFontsName((LPSTR)szMFDName, (WORD) MFD_NAME_LENGTH);
      if ((status = CreateFontsMFD((LPSTR) szMFDName, (LPDWORD) &dwPSFRSerialNo,
                      (LPDWORD) &dwTTFRSerialNo, (chFonts.lpFontDirCurrent)->dwMFMTimeStamp,
                      lpszFriendlyName)) == RC_OK)
      {
         SetFontsMFDToReg(gszFontsDirRegKey, szMFDName);
         CompositeString(ghDriverMod, IDS_REGSTR_PATH_FONTSINFO, IDS_DRIVER_MANUFACTURER,
                  IDS_DRIVER_VERSION, szTempBuf, SM_BUF);
         SetRegDWord(szTempBuf,gszFontsDirCkSumKey,(DWORD)GetTimeStampID(szMFDName));
        if (LoadMFDData((LPSTR)szMFDName, chFonts.lpFontDirCurrent,
                        dwPSFRSerialNo, dwTTFRSerialNo, PSFR))
        {
            //Recreate Name Cache from PostscriptName to Family Name
            UpdatePSRegCache((chFonts.lpFontDirCurrent)->hpFontDirTab[PSFR], (chFonts.lpFontDirCurrent)->wNumFonts[PSFR]);
        }
      }

      //fail to create or load MFD. assumed no fonts
      if (!(chFonts.lpFontDirCurrent)->hpFontDirTab[PSFR])
      {
      //Save the Serial number in cache  so we won't be asked to create it again.
         (chFonts.lpFontDirCurrent)->dwPSFRSerialNo = dwPSFRSerialNo;
         (chFonts.lpFontDirCurrent)->dwTTFRSerialNo = dwTTFRSerialNo;
         (chFonts.lpFontDirCurrent)->dwTimeStamp[PSFR] = dwMFD0TimeStamp;
         status = RC_OK;
      }
   }

   if ((chFonts.lpFontDirCurrent)->wNumFonts[PSFR] &&
         (chFonts.lpFontDirCurrent)->hpFontDirTab[PSFR] && status == RC_OK)
   {
      //Save the Serial number in cache
      (chFonts.lpFontDirCurrent)->dwPSFRSerialNo = dwPSFRSerialNo;
      (chFonts.lpFontDirCurrent)->dwTTFRSerialNo = dwTTFRSerialNo;
      CompositeString(ghDriverMod, IDS_REGSTR_PATH_FONTSINFO, IDS_DRIVER_MANUFACTURER,
                  IDS_DRIVER_VERSION, szTempBuf, SM_BUF);
      if (!((chFonts.lpFontDirCurrent)->dwTimeStamp[PSFR] = GetRegDWord(szTempBuf,gszFontsDirCkSumKey)))
      {  //For some reason the TimeStamp wasn't set
         SetRegDWord(szTempBuf,gszFontsDirCkSumKey,(DWORD)GetTimeStampID(szMFDName));
         (chFonts.lpFontDirCurrent)->dwTimeStamp[PSFR] = GetRegDWord(szTempBuf,gszFontsDirCkSumKey);
      }
    }

    (chFonts.lpFontDirCurrent)->wTotalNumFonts = (chFonts.lpFontDirCurrent)->wNumFonts[PSFR]; //+chFonts.wNumFonts[ATMDB]
    return status;
}

/********************************************************
**
** Function:   SetRegDWord
**
********************************************************/
DWORD FAR PASCAL SetRegDWord(LPSTR lpszPath, LPSTR lpszKey, DWORD dwNewSerial)
{
   HKEY hkey;
   DWORD dwType, dwSerial = 0, cbSize = sizeof(DWORD);
   unsigned int x =0,  y = 0;

   if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR) lpszPath, (HKEY FAR *) &hkey)
      == ERROR_SUCCESS)
   {
      // no Serial number pass-in, then increment old serail#
      if (!dwNewSerial)
      {
         RegQueryValueEx(hkey, (LPSTR)lpszKey, 0, (LPDWORD) &dwType,
               (LPSTR)&dwSerial, (LPDWORD)&cbSize);

         if (!dwSerial) //no previous serial number.
            dwSerial = GetTickCount(); // Use a random function here.

        dwNewSerial = ++dwSerial;
       }

      RegSetValueEx(hkey, (LPSTR)lpszKey, 0, REG_DWORD,
         (LPSTR)&dwNewSerial, sizeof(DWORD));

   }
   //if no previous serial number, then get one randomly
   else if (RegCreateKey(HKEY_LOCAL_MACHINE, (LPSTR)lpszPath, (HKEY FAR *) &hkey)
       == ERROR_SUCCESS)
   {
      if (!dwNewSerial)
         dwNewSerial = GetTickCount(); // Use a random function here.

      RegSetValueEx(hkey, (LPSTR)lpszKey, 0, REG_DWORD,
         (LPSTR)&dwNewSerial, sizeof(DWORD));
   }

   RegCloseKey(hkey);

   return dwNewSerial;   //the new serial Number
}
/********************************************************
**
** Function:   GetRegDWord
**
********************************************************/
DWORD FAR PASCAL GetRegDWord(LPSTR lpszPath, LPSTR lpszKey)
{
   HKEY hkey;
   DWORD dwType, dwSerial = 0, cbSize = sizeof(DWORD);

   if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR) lpszPath, (HKEY FAR *) &hkey)
      == ERROR_SUCCESS)
   {
      RegQueryValueEx(hkey, (LPSTR)lpszKey, 0, (LPDWORD) &dwType,
               (LPSTR)&dwSerial, (LPDWORD)&cbSize);

   }
   RegCloseKey(hkey);

   return dwSerial;
}

DWORD FAR PASCAL GetSerialNo(LPSTR lpszPath)
{
   return (GetRegDWord(lpszPath, gszSerial));
}

DWORD FAR PASCAL SetSerialNo(LPSTR lpszPath, DWORD dwValue)
{
   return(SetRegDWord(lpszPath, gszSerial, dwValue));
}

DWORD FAR PASCAL GetSecondSerialNo(LPSTR lpszPath)
{
   return (GetRegDWord(lpszPath, gszSecondSerial));
}

DWORD FAR PASCAL SetSecondSerialNo(LPSTR lpszPath, DWORD dwValue)
{
   return(SetRegDWord(lpszPath, gszSecondSerial, dwValue));
}



/********************************************************
**
** Function:   GetFontsMFDFrReg
**
********************************************************/
WORD NEAR PASCAL GetFontsMFDFrReg(LPSTR lpszKey, LPSTR lpszMFDFileName, DWORD cbSize)
{
   DWORD  dwType;
   HKEY  hkey;
   DWORD dwCBSize = cbSize;
   LPSTR szBuffer = NULL;
   WORD rc = 0;

   *lpszMFDFileName = '\0';

   if ((szBuffer = GlobalAllocPtr(GDLLHND,  BUF_SIZE)) == NULL)
     return rc;

   CompositeString(ghDriverMod, IDS_REGSTR_PATH_FONTSINFO, IDS_DRIVER_MANUFACTURER,
                  IDS_DRIVER_VERSION, szBuffer, BUF_SIZE);

   if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR) szBuffer, (HKEY FAR *) &hkey)
      == ERROR_SUCCESS)
   {
      RegQueryValueEx(hkey, (LPSTR)lpszKey, 0, (LPDWORD) &dwType,
               (LPSTR)lpszMFDFileName, (LPDWORD) &dwCBSize);
     rc = 1;
   }
    if (hkey)
      RegCloseKey(hkey);

    if (szBuffer)
      GlobalFreePtr(szBuffer);

    return rc;
}

/********************************************************
**
** Function:   SetFontsMFDToReg
**
********************************************************/
VOID NEAR PASCAL SetFontsMFDToReg(LPSTR lpszKey, LPSTR lpszMFDFileName)
{
   DWORD cbSize = sizeof(DWORD);
   LPSTR szBuffer = NULL;
   HKEY hkey = NULL;

   if ((szBuffer = GlobalAllocPtr(GDLLHND,  BUF_SIZE)) == NULL)
     return;

   CompositeString(ghDriverMod, IDS_REGSTR_PATH_FONTSINFO, IDS_DRIVER_MANUFACTURER,
                  IDS_DRIVER_VERSION, szBuffer, BUF_SIZE);

   if (RegCreateKey(HKEY_LOCAL_MACHINE, (LPSTR) szBuffer, (HKEY FAR *) &hkey)
      == ERROR_SUCCESS)
   {
      RegSetValueEx(hkey, (LPSTR)lpszKey, 0, REG_SZ,
               lpszMFDFileName, lstrlen(lpszMFDFileName) +1);
   }

    if (hkey)
      RegCloseKey(hkey);
    if (szBuffer)
      GlobalFreePtr(szBuffer);

}

/********************************************************
**
** Function:   CreateFontsName
**
********************************************************/
VOID NEAR PASCAL CreateFontsName(LPSTR lpszName, WORD cbSize)
{
   int j;

   /* find the windows directory*/
   GetWindowsDirectory(lpszName, cbSize);
   j = lstrlen(lpszName);
   if (lpszName[j-1] != '\\')
   {
      lstrcat(lpszName, (LPSTR) "\\");
   }
   /* create name with gszFontsDIR key*/
   lstrcat(lpszName, (LPSTR)gszFontsDIR);

}

/********************************************************
**
** Function:   CreateFDBFontName
**
********************************************************/
VOID NEAR PASCAL CreateFDBFontName(LPSTR szName)
{
/*REVIEW*/
   /* find the windows directory*/
   /* create name with gszFontsFDB key*/
}
/********************************************************
** Function:   GetFontsMFD
**        The cache has become invalid.  We need to load FontsDIR.MFD
**        from file.
** Input:  CACHEHDR ch - Cache header, reservior of cache pointers of DIR/MFD and TBL/MFD
**         DWORD dwPSFRSerial  - PostScript Font Registry Serial number.
**         DWORD dwTTFRSerial  - TrueType Font Registry Serial number.
** Output: WORD - status of loading DIR/MFD from file.
**    return RC_ERROR if
**         1) PS Font Registry changed and DIR/MFD needs to rebuild.
**         2) TT Font Registry changed and DIR/MFD needs to rebuild.
*********************************************************/
WORD NEAR PASCAL GetFontsMFD(LPCACHEHDR lpCH, LPSTR lpszMFDPath, DWORD dwPSFRSerialNo, DWORD dwTTFRSerialNo)
{
   OFSTRUCT ofFileStruct;
   WORD rc = RC_ERROR;
   LPFONTDIRCACHE lpCHFD = lpCH->lpFontDirCurrent;

   if (lpszMFDPath[0] &&
       (OpenFile((LPSTR)lpszMFDPath,(LPOFSTRUCT) &ofFileStruct,
                                 OF_EXIST) !=HFILE_ERROR))
   {
      if (LoadMFDData(lpszMFDPath, lpCH->lpFontDirCurrent,
                      dwPSFRSerialNo, dwTTFRSerialNo, PSFR))
      {
         rc = RC_OK;
      }
   }
   return rc;
}

WORD NEAR PASCAL CreateFontsMFD(LPSTR lpszMFDPath, LPDWORD lpdwPSFRSerialNo,
                                  LPDWORD lpdwTTFRSerialNo,
                                  DWORD dwMFMTimeStamp, LPSTR lpszFriendlyName)
{
   WORD rc = RC_ERROR;
   WORD wNumFonts = 0;
   HPFONTFILE hpFontPtr = NULL;
   HPFONTFILE hpTempFont = NULL;

   /* delete the old mfd if it existed*/
   if (*lpszMFDPath)
      remove(lpszMFDPath);

   /*Gather all the fonts info from TrueTypeFonts Reg*/
   if (!MergeTTFontsFromReg(&hpFontPtr, &wNumFonts))
     goto cleanup;

   /* Gather all the fonts info from HPFR*/
   if (!MergePSFontsFromReg(&hpFontPtr, &wNumFonts))
     goto cleanup;

   /* if either of the serial number is 0, then change it to a valid number*/
   if (!(*lpdwPSFRSerialNo))
        *lpdwPSFRSerialNo = SetSerialNo((LPSTR)gszRegFontsPath, 0); //set HPFR serial number
   if (!(*lpdwTTFRSerialNo))
        *lpdwTTFRSerialNo = SetSerialNo((LPSTR)gszRegFontsR, 0); //set TrueType Serial No

   rc = ConvertFontsToMFD(lpszMFDPath, hpFontPtr, wNumFonts,
                          *lpdwPSFRSerialNo, *lpdwTTFRSerialNo, dwMFMTimeStamp,
                          lpszFriendlyName);

cleanup:
   if (hpFontPtr)
     GlobalFreePtr(hpFontPtr);

   return (rc);
}


BOOL IsDBCSPFM(LPSTR szPFMName)
{
LPPFMHEADER  lpPFMHdr = NULL;
DWORD        dwPFMSize;
BOOL         ret =FALSE;
   /* Read PFM data - also allocate lpPFMHdr */
   dwPFMSize = ReadPFMFile(szPFMName, (LPVOID FAR*) &lpPFMHdr);
   if (dwPFMSize && lpPFMHdr ){
      if (IsDBCSCharSet(lpPFMHdr->dfCharSet)) ret = TRUE;
      }
   if (lpPFMHdr) GlobalFreePtr(lpPFMHdr);
  return ret;
}


WORD NEAR PASCAL MergeTTFontsFromReg(HPFONTFILE *phpPFMFile, LPWORD lpwNumFonts)
{
   HPFONTFILE hpFontPtr;
   HPFONTFILE hpTTFontData = NULL;
   WORD numTTFonts = 0;
   WORD oldNumFonts = *lpwNumFonts;
   WORD newNumFonts = 0;
   WORD      wPfmBlock;   // Number of PFM blocks already passed. It is larger than i;
   WORD i, j;
   WORD sizeOfFontFile = (WORD) sizeof(FONTFILE);

   //get available TrueType fonts
   numTTFonts = GetTrueTypeFonts(NULL, EnumTTRoot, 0);
   if (!numTTFonts)
     return(1);  //no more just return.

   if ((hpTTFontData = (HPFONTFILE) GlobalAllocPtr(GDLLHND, sizeof(FONTFILE)*(DWORD)numTTFonts)) != NULL)
   {
      //numTTFonts could be a smaller value when it returns.
      numTTFonts = GetTrueTypeFonts(hpTTFontData, EnumTTRoot, numTTFonts);
   }

   //Sort the font list so we can remove duplicate fonts.
   HugeIsort((HPVOID) hpTTFontData, numTTFonts-1, sizeof(FONTFILE), EnumFontsCompare);

   //remove duplicates and invalid font.
   i = 0;
   while (i < numTTFonts)
   {
     j = i+1;
     while (j < numTTFonts &&
            ((((lstrcmp((hpTTFontData+i)->szName1, (hpTTFontData+j)->szName1) == 0) && //duplicate
              (hpTTFontData+i)->lfCharSet == (hpTTFontData+j)->lfCharSet))
            || *((hpTTFontData+j)->szName2) == '\0')) // or invalid font.

     {
        *((hpTTFontData+j)->szName1) = '\0'; //same entry.  Mark it removed.
        j++;
     }
     newNumFonts++;
     i=j;
  }

  //allocate space for list of unique TrueType Fonts
  if (*phpPFMFile == NULL)
         *phpPFMFile = (HPFONTFILE) GlobalAllocPtr(GDLLHND, ((DWORD)newNumFonts) * sizeOfFontFile);
   else *phpPFMFile = (HPFONTFILE) GlobalReAllocPtr(*phpPFMFile,
         ((DWORD)(oldNumFonts+newNumFonts)) * sizeOfFontFile, GMEM_ZEROINIT );

   // ReAlloc with flag GMEM_ZEROINIT may fail if this function is called again be careful
   if (! phpPFMFile)
         goto exit;

   /* For each entry, get the value */
   hpFontPtr = *phpPFMFile+oldNumFonts; // Start from the end of old fonts Plus OldExtra
   wPfmBlock = (WORD)oldNumFonts; // where we start the new PFMs
   i = j = 0;
   while (i < numTTFonts && j < newNumFonts)
   {
      if ( *((hpTTFontData+i)->szName1) )
      {
         MemCopy((HPVOID)((HPFONTFILE)hpFontPtr+j), (HPVOID)((HPFONTFILE)hpTTFontData+i), (DWORD)sizeOfFontFile);
         (hpFontPtr+j)->wType = TrueType;
         j++;
      }
      i++;
   }

    *lpwNumFonts = oldNumFonts+newNumFonts;

exit:
   GlobalFreePtr(hpTTFontData);
   return 1;
}


int NEAR PASCAL ValidKey(LPSTR lpValue)
{
    LPSTR lpTemp;
    BOOL  bAllNum = TRUE;
    int   Count = 0;

    lpTemp = lpValue = AnsiNext(lpValue);

    while (bAllNum && *lpTemp != '\0' && *lpTemp != ':')
    {
        if (isdigit((int) *(lpTemp)) == 0)
            bAllNum = FALSE;
        else
            Count++;
        lpTemp = AnsiNext(lpTemp);
    }

    if ((*lpTemp == ':') && (bAllNum) && (Count > 0) )
    {
        return 1;
    }
    else
    {
      return 0;
    }
}

// This function Compares if lpValue has lpString as the first substring
// If Yes - returns the substring after lpString, else returns -1.
int NEAR PASCAL FindStringKeyPos(LPSTR lpValue, LPSTR lpString)
{
    LPSTR lpStart = NULL;
    DWORD dwLen = lstrlen(lpString);
    int  iPos = 0;

    while (1)
    {
       if ((MemComp((LPVOID)lpValue, (LPVOID)lpString, dwLen) == 0) &&
           ( ValidKey(lpValue)))
       {
           break;
       }
       else
       {
           // Skip to end of section
            while ((*lpValue != '\0') && (*lpValue != cVBar))
            {
                lpValue = AnsiNext(lpValue);
                iPos++;
            }
            if (*lpValue == '\0')
            {
               iPos = -1;
               return iPos;
            }
            lpValue = AnsiNext(lpValue);  // Move past cSeperator
            iPos++;
       }
    }
    return iPos;
}

LPSTR NEAR PASCAL FindStringKeyGen(LPSTR lpValue, LPSTR lpString,char lpDelimiter, LPWORD lpwLength)
{
    LPSTR lpStart = NULL;
    DWORD dwLen = lstrlen(lpString);

    while (1)
    {
       if ((MemComp((LPVOID)lpValue, (LPVOID)lpString, dwLen) == 0) &&
          (ValidKey(lpValue)) )
       {
           // Found the match
           lpStart = lpValue;
           while ((*lpValue != lpDelimiter) && (*lpValue != '\0'))
               lpValue = AnsiNext(lpValue);
           *lpwLength = lpValue - lpStart;
           break;
       }
       else
       {
           // Skip to end of section
            while ((*lpValue != lpDelimiter) && (*lpValue != '\0'))
                lpValue = AnsiNext(lpValue);
            if (*lpValue == '\0')
                break;
                lpValue = AnsiNext(lpValue);  // Move past cSeperator
       }
    }
    return lpStart;
}

LPSTR NEAR PASCAL FindStringKey(LPSTR lpValue, LPSTR lpString,LPWORD lpwLength)
{
   WORD wLen = lstrlen(lpString);
   LPSTR lpPtr = NULL;

   if ((lpPtr = FindStringKeyGen(lpValue, lpString,cVBar, lpwLength)) != NULL)
   {
      lpPtr += wLen;  //advance pass the string we are looking for.
      *lpwLength -= wLen;
   }
   return(lpPtr);
}

WORD NEAR PASCAL MergePSFontsFromReg(HPFONTFILE *phpPFMFile, LPWORD lpwNumFonts)
{

    HKEY      hkey = NULL;
    LPSTR     lpName = NULL, lpValue = NULL, lpTempValue = NULL;
    DWORD     dwRegIndex, dwType;
    DWORD     cbName, cbValue;
    HPFONTFILE hpFontPtr;
    WORD      oldNumFonts, newNumFonts;
    LONG      tmp;         // a singed tmp to do math
    DWORD     extraPFMs;   // Number of Extra PFMs to overcome 64K boundry problem
    int       numPPerSeg;
    WORD      wPfmBlock;   // Number of PFM blocks already passed. It is larger than i;
    WORD      wDiff;
    int       iPFMPos, iSFNTPos;
    WORD      wMetricFile;


    oldNumFonts = *lpwNumFonts;  // Number of fonts already in hpPFMFile.
    numPPerSeg = (LONG)LIMIT_64K / sizeof(FONTFILE);  // num of blocks on one seg
    newNumFonts=0; // Initial, otherwise GPF if ATM.INI doesn't exist

    if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR)gszRegFontsPath, (HKEY FAR*)&hkey)
        != ERROR_SUCCESS)
        goto mergereg_exit;

    // Allocate memory to retrieve font name and value string
    if ((lpName = (LPSTR)GlobalAllocPtr(GHND, 2*BUF_SIZE)) == NULL)
        goto mergereg_exit;
    lpValue = lpName + BUF_SIZE;

    // Enumerate all the values for this key, First Count Only.
    dwRegIndex = 0;
    while ((cbName = cbValue = BUF_SIZE) &&
           RegEnumValue(hkey, dwRegIndex, lpName, (LPDWORD)&cbName,
               NULL, (LPDWORD)&dwType, lpValue, (LPDWORD)&cbValue)
           == ERROR_SUCCESS && ++dwRegIndex )
    {
        // count only.
        //each PS entry can have multiple SFNT and one PFM/PFB pair.
        //For accurate counting, we must look inside the value retrieved.

       // Check if lpFontName ends with cszType1
       wDiff = lstrlen(lpName) - lstrlen(cszType1);
       if (lstrcmp(lpName + wDiff, (LPSTR)cszType1) == 0)
       {
        //Is there a PFM?
         if (FindStringKeyPos(lpValue,cszPFM) != -1)
            newNumFonts++;

         //Are there SFNTs?
         lpTempValue = lpValue;
         while (lpTempValue[0])
         {
            if (FindStringKeyPos(lpTempValue, cszSFNT)  != -1)
            {
              newNumFonts++;
              lpTempValue = SkipToNext(lpTempValue);
            }
            else
              *lpTempValue = '\0';
         }
       }
    }    //end while()- count # of fonts.


    //Are there any Postscript fonts
    if (newNumFonts > 0)  // There are some softfonts in Registry !!
    {
      tmp = (LONG)numPPerSeg;
      tmp = (LONG)((float)(oldNumFonts+newNumFonts) / tmp +0.5);        // num of extra PFM blocks needed
      extraPFMs = (DWORD) tmp;
      newNumFonts += (WORD)extraPFMs;

      if (*phpPFMFile == NULL)
            *phpPFMFile = (HPFONTFILE) GlobalAllocPtr(GDLLHND, ((DWORD)newNumFonts) * sizeof(FONTFILE));
      else *phpPFMFile = (HPFONTFILE) GlobalReAllocPtr(*phpPFMFile,
            ((DWORD)(oldNumFonts+newNumFonts)) * sizeof(FONTFILE), GMEM_ZEROINIT );

      // ReAlloc with flag GMEM_ZEROINIT may fail if this function is called again be careful
      if (! phpPFMFile)
            goto mergereg_exit;

      /* For each entry, get the value */
      hpFontPtr = *phpPFMFile+oldNumFonts; // Start from the end of old fonts Plus OldExtra
      wPfmBlock = (WORD)oldNumFonts; // where we start the new PFMs

      // Enumerate all the values for this key, and extract PFM/PFB or SFNT
      // information from each one of them.
      dwRegIndex = 0;
      while ((cbName = cbValue = BUF_SIZE) &&
            RegEnumValue(hkey, dwRegIndex, lpName, (LPDWORD)&cbName,
               NULL, (LPDWORD)&dwType, lpValue, (LPDWORD)&cbValue)
            == ERROR_SUCCESS  && ++dwRegIndex)
      {
         // We are not interested in anything that is not REG_SZ
         // The registry may be changed after we count it. So add these low index
         if (dwType != REG_SZ || dwRegIndex > newNumFonts)
               continue;

         // Check if lpFontName ends with cszType1
         wDiff = lstrlen(lpName) - lstrlen(cszType1);
         if (lstrcmp(lpName + wDiff, (LPSTR)cszType1) != 0)
               continue;

         lpTempValue = lpValue; //use lpTempValue to walk the string.
         while (lpTempValue)
         {
            //fix bug 299651
            //Use Better key search method for M#:, B#:, and T#:
            //Replaced FindStringPos() with FindStringKeyPos()
            //Replaced FindString() with FindStringKey()

            iPFMPos = FindStringKeyPos(lpTempValue, cszPFM);
            iSFNTPos = FindStringKeyPos(lpTempValue, cszSFNT);

            //if they are the same, then we didn't find a string
            if (iPFMPos == iSFNTPos)
               break;

            if (iPFMPos < 0)
               wMetricFile = SFNT;
            else if (iSFNTPos < 0)
               wMetricFile = PFMPFB;
            else if (iSFNTPos < iPFMPos)
               wMetricFile = SFNT;
            else
               wMetricFile = PFMPFB;

            lpTempValue = MakePFMPFBSFNT(lpTempValue, hpFontPtr, wMetricFile);

            // make sure just added entry is not a DBCS DownloadAble Font - we canot download DBCS PS-Font
            // if (hpFontPtr->szName2[0]!='\0' && IsDBCSPFM((LPSTR)hpFontPtr->szName1) )
            //{
            //   hpFontPtr->szName1[0]='\0';
            //   hpFontPtr--;  // will increase later, - This entry won't appear in MFD file!
            //}

            hpFontPtr++;
            wPfmBlock++;

            // Skip the block on the seg boundry:
            if ((wPfmBlock)%numPPerSeg==0){
                  hpFontPtr++;
                  wPfmBlock++;     // it doesn't match I any more.
            }

         }//inner while()
      }//end while()
    }//end-if (newNumFonts > 0)

    *lpwNumFonts = oldNumFonts+newNumFonts;

mergereg_exit:
    if (hkey)
        RegCloseKey(hkey);
    if (lpName)
        GlobalFreePtr(lpName); // lpValue was allocated as part of lpName

    return 1;
}

// Function to build PFM/PFB from Reg's Value
// After we get string, skip to the next section.
LPSTR NEAR PASCAL MakePFMPFBSFNT(LPSTR lpValue, HPFONTFILE hpFontPtr, WORD wType)
{
    BOOL    rc = FALSE;
    char    szTmp[MAX_PATH];
    LPSTR   lpPtr;
    WORD    wLength;
    LPSTR   lpSkipStr;
    LPSTR   lpMetricStr;

    // lpValue is in format: "M101:hlv___.pfm|B102:hlv____.pfb". or
    // in another order:     "B101:hlv___.pfb|M102:hlv____.pfm"
    //

            //fix bug 299651
            //Use Better key search method for M#:, B#:, and T#:
            //Replaced FindStringPos() with FindStringKeyPos()
            //Replaced FindString() with FindStringKey()

    lpSkipStr = lpValue; //in case we can't find the string.

    // Search for SFNT or PFM
    lpMetricStr = wType ? (LPSTR) cszSFNT: (LPSTR) cszPFM;

       lpPtr = FindStringKey(lpValue, lpMetricStr, &wLength);

    if (lpPtr)
    {
       lpSkipStr = lpPtr;
       lstrcpyn(szTmp, lpPtr, wLength+1);
       ExpandPSFontsPath((LPSTR)szTmp, (LPSTR) hpFontPtr->szName1);

       if ((hpFontPtr->wType = wType) == PFMPFB)
       {
         // Search PFB again from start of lpValue
         if ((lpPtr = FindStringKey(lpValue, cszPFB, &wLength)) != NULL)
         {
            lstrcpyn(szTmp, lpPtr, wLength+1);
            ExpandPSFontsPath((LPSTR)szTmp, (LPSTR) hpFontPtr->szName2);
         }
       }

      lpSkipStr = SkipToNext(lpSkipStr); //skip pass the PFM entry.
     }

    return lpSkipStr;
}



//This function skip to the next postion after the bar separator.
LPSTR FAR PASCAL SkipToNext(LPSTR lpValue)
{

   if (!lpValue)
      return (LPSTR) NULL;

   // Skip to end of section
   while ((*lpValue != cVBar) && (*lpValue != '\0'))
         lpValue = AnsiNext(lpValue);

   if (*lpValue == cVBar)
         lpValue = AnsiNext(lpValue);  // Move past cSeperator

    return lpValue;
}

// This function Compares if lpValue has lpString as the first substring
// If Yes - returns the substring after lpString, else returns -1.
int NEAR PASCAL FindStringPos(LPSTR lpValue, LPSTR lpString)
{
    LPSTR lpStart = NULL;
    DWORD dwLen = lstrlen(lpString);
    int  iPos = 0;

    while (1)
    {
       if (MemComp((LPVOID)lpValue, (LPVOID)lpString, dwLen) == 0)
       {
           // Found the match
           break;
       }
       else
       {
           // Skip to end of section
            while ((*lpValue != '\0') && (*lpValue != cVBar))
            {
                lpValue = AnsiNext(lpValue);
                iPos++;
            }
            if (*lpValue == '\0')
            {
               iPos = -1;
               return iPos;
            }
            lpValue = AnsiNext(lpValue);  // Move past cSeperator
            iPos++;
       }
    }
    return iPos;
}

WORD NEAR PASCAL LoadMFDData(LPSTR lpszMFDFile, LPFONTDIRCACHE lpFontDirCurrent,
                                       DWORD dwPSFRSerialNo, DWORD dwTTFRSerialNo,
                                       WORD index)
{
    FILEHDR     fileHdr;
    OFSTRUCT    ofFileStruct;
    DWORD       dwDirSize;
    HPFONTDIRECTORY hpFontDir = NULL;
    HPPFMPROLOG hpPFMProlog = NULL;
    HFILE       hFile;
    WORD        rc = RC_ERROR;

    lpFontDirCurrent->wNumFonts[index] = 0;

    if (! *lpszMFDFile)
       return rc;
    if ((hFile = OpenFile(lpszMFDFile, (LPOFSTRUCT) &ofFileStruct,
                          OF_READ)) != HFILE_ERROR)
    {
        /* Read Header */
        if (_lread(hFile, (HPVOID) &fileHdr,
                   sizeof(FILEHDR)) == sizeof(FILEHDR))
        {
            if (fileHdr.dwPSFRSerialNo != dwPSFRSerialNo ||
               fileHdr.dwTTFRSerialNo != dwTTFRSerialNo ||
               fileHdr.dwMFMTimeStamp != lpFontDirCurrent->dwMFMTimeStamp)
                goto mfddata_cleanup;

            dwDirSize = ((DWORD) sizeof(FONTDIRECTORY) * (DWORD) fileHdr.wNumFonts);

            /* Allocate Font Directory */
            hpFontDir =
                (HPFONTDIRECTORY) GlobalAllocPtr(GDLLHND, (DWORD) dwDirSize);

            if (! hpFontDir)
                goto mfddata_cleanup;

             hpPFMProlog =
               (HPPFMPROLOG) GlobalAllocPtr(GDLLHND, (DWORD) fileHdr.dwTotalFontSize);

             if (!hpPFMProlog)
               goto mfddata_cleanup;

        }

        /* Read Font Directory */
        if (_hread(hFile, (HPVOID) hpFontDir, (long) dwDirSize) == (long) dwDirSize)
            {
               lpFontDirCurrent->wNumFonts[index] = fileHdr.wNumFonts;
            }


        //  Read Metric Data
        if ((fileHdr.dwTotalFontSize == 0) ||
            (_hread(hFile, (HPVOID) hpPFMProlog, (long) fileHdr.dwTotalFontSize)
              == (long) fileHdr.dwTotalFontSize))
        {
                rc = RC_OK;
        }
    }

mfddata_cleanup:
    if (rc == RC_ERROR)
    {
        /* Free memory */
        if (hpFontDir)
            GlobalFreePtr(hpFontDir);
        hpFontDir = NULL;

        if (hpPFMProlog)
            GlobalFreePtr(hpPFMProlog);
        hpPFMProlog = NULL;
    }

    lpFontDirCurrent->hpFontDirTab[index] = hpFontDir;
    lpFontDirCurrent->hpPFMProlog[index] = hpPFMProlog;

    /* Close file */
    _lclose(hFile);

    return rc;
}


DWORD FAR PASCAL ReadMetricFile(LPSTR lpszMetricFile, HPVOID FAR *lplpPFMData)
{
   OFSTRUCT ofFileStruct;
   DWORD    rc = 0;
   HFILE    hFile = NULL;

   if ((hFile = OpenFile(lpszMetricFile, (LPOFSTRUCT) &ofFileStruct, OF_READ)) != HFILE_ERROR)
   {
      rc = ReadPFMWithProlog(hFile, lplpPFMData);
      _lclose(hFile);
   }
   return rc;
}

DWORD FAR PASCAL ReadPFMWithProlog(HFILE hFile, HPVOID FAR *lplpPFMData)
{
   DWORD    rc = 0;
   PFMPROLOG pfmProlog;
   DWORD    dwPrologSize = sizeof(PFMPROLOG);
   UINT     nbytes;
   long     beginProlog;

//Find size of PFM block, and allocate space.
   beginProlog = _tell(hFile);
   if ((nbytes = _lread(hFile, (HPVOID) &pfmProlog,
      (UINT) dwPrologSize)) == dwPrologSize)
   {
      if (lplpPFMData)
      {
         if (*lplpPFMData = (HPVOID) GlobalAllocPtr(GHND, pfmProlog.dfSize))
         {
            //Read the whole darn PFM including the Prolog.
            //we need to rewind back to the beginning of the prolog.
            _lseek(hFile, beginProlog, SEEK_SET);

            //Copy the Prolog
            if ((nbytes =_lread(hFile, (HPVOID) *lplpPFMData ,
                        (UINT) pfmProlog.dfSize)) == pfmProlog.dfSize)
               rc = pfmProlog.dfSize;
            else
               GlobalFreePtr(*lplpPFMData);
         }
      }
   }
   return rc;
}



HPPFMHEADER FAR PASCAL GetMetricCache(HPFONTDIRECTORY hpFontDir, BYTE bMFDIndex, HPPFMPROLOG hpPFMProlog)
{
   HPPFMPROLOG hpCurPFMProlog = NULL;
   HPPFMHEADER hpCurPFMHeader = NULL;

   if (!hpPFMProlog)
     return NULL;

   hpCurPFMProlog = DIR_TO_METRIC(hpFontDir, hpPFMProlog);
   hpCurPFMHeader = (HPPFMHEADER)  ((BYTE _huge*) hpCurPFMProlog + sizeof(PFMPROLOG));

   return(hpCurPFMHeader);
}

DWORD FAR PASCAL ReadPFMFromMFD(LPSTR lpszMFDFile, LPVOID FAR* lplpPFMData,
                                DWORD dwOffset)
{
    OFSTRUCT   ofFileStruct;
    DWORD      rc = 0;
    HFILE      hFile;

    if ((hFile = OpenFile(lpszMFDFile, (LPOFSTRUCT) &ofFileStruct,
                        OF_READ)) != HFILE_ERROR)
    {
        _llseek(hFile, dwOffset, SEEK_CUR);
        rc = ReadPFMData(hFile, lplpPFMData);
        _lclose(hFile);
    }

    return rc;
}

WORD FAR PASCAL GetPFB(LPSTR lpPSFontName, LPSTR lpValue)
{
   WORD rc = RC_ERROR;
   LPSTR szAllPath = NULL, szPFBPath= NULL, szFontName = NULL;
   DWORD dwType, cbSize = MAX_PATH;
   LPSTR lpPtr;
   WORD wLength;
   HKEY hkey;

   *lpValue = '\0';

   if ((szAllPath = GlobalAllocPtr(GDLLHND,  3* MAX_PATH)) == NULL)
     return rc;
   szPFBPath = szAllPath+MAX_PATH;
   szFontName = szAllPath+2*MAX_PATH;

   lstrcpy((LPSTR)szFontName, lpPSFontName);
   if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR)gszRegFontsPath, (HKEY FAR*)&hkey)
        == ERROR_SUCCESS)
   {
      lstrcat((LPSTR)szFontName, cszType1);
      if (RegQueryValueEx(hkey, (LPSTR)szFontName, 0, (LPDWORD) &dwType,
         (LPSTR) szAllPath, (LPDWORD)&cbSize) == ERROR_SUCCESS)
      {
         if ((lpPtr = FindStringKey(szAllPath, cszPFB, &wLength)) != NULL)
         {
            lstrcpyn(szPFBPath, lpPtr, wLength+1);
            ExpandPSFontsPath((LPSTR)szPFBPath, lpValue);
            rc = RC_OK;
            }
      }
   }
   if (hkey)
      RegCloseKey(hkey);

   if (szAllPath)
    GlobalFreePtr(szAllPath);

   return rc;
}

WORD NEAR PASCAL GetNumASCIIZStrings(LPSTR lpszBuffer)
{
    WORD wNumStrings = 0;

    while (lpszBuffer && lpszBuffer[0]) {
        wNumStrings++;
        lpszBuffer += lstrlen(lpszBuffer) + 1;
    }
    return wNumStrings;
}


LPSTR NEAR PASCAL FindString(LPSTR lpValue, LPSTR lpString, LPWORD lpwLength)
{
   WORD wLen = lstrlen(lpString);
   LPSTR lpPtr = NULL;

   if ((lpPtr = FindStringGen(lpValue, lpString, cVBar, lpwLength)) != NULL)
   {
      lpPtr += wLen;  //advance pass the string we are looking for.
      *lpwLength -= wLen;
   }
   return(lpPtr);
}

// This function Compares if lpValue has lpString as the first substring
// If Yes - returns the substring after lpString, else returns NULL.
LPSTR NEAR PASCAL FindStringGen(LPSTR lpValue, LPSTR lpString, char lpDelimiter, LPWORD lpwLength)
{
    LPSTR lpStart = NULL;
    DWORD dwLen = lstrlen(lpString);

    while (1)
    {
       if (MemComp((LPVOID)lpValue, (LPVOID)lpString, dwLen) == 0)
       {
           // Found the match
           lpStart = lpValue;
           while ((*lpValue != lpDelimiter) && (*lpValue != '\0'))
               lpValue = AnsiNext(lpValue);
           *lpwLength = lpValue - lpStart;
           break;
       }
       else
       {
           // Skip to end of section
            while ((*lpValue != lpDelimiter) && (*lpValue != '\0'))
                lpValue = AnsiNext(lpValue);
            if (*lpValue == '\0')
                break;
                lpValue = AnsiNext(lpValue);  // Move past cSeperator
       }
    }
    return lpStart;
}

// Pass-in lpszName must be a Filename with a path !
// This function not only breaks lpszName to a Short-hand-key lpszKey and a Filename
// It also write the new lpszkey/Pathname pair to PostScripFont\Paths. It is not very fast.
// The return string is the file name without path.
LPSTR NEAR PASCAL RegisterPSFontsPath(LPSTR lpszName, LPSTR lpszKey)
{
    LPSTR     lpch = NULL;
    LPSTR     lpszFile=NULL;
    HKEY      hkey = NULL;
    LPSTR     lpName = NULL, lpValue = NULL;
    DWORD     dwRegIndex, dwType;
    DWORD     cbName, cbValue;
    BOOL      bKnownPath = FALSE;
    int       i;

    if (RegCreateKey(HKEY_LOCAL_MACHINE, (LPSTR)gszRegFontsPathPaths, (HKEY FAR*)&hkey)
        != ERROR_SUCCESS)
        goto SepReg_exit;

    lpch = lstrrchr(lpszName, '\\');

    if (lpch==NULL){
        // Safe protection - lpszName is a filename without path
        lpszFile = lpszName;
        lpszKey[0]='\0';
        goto SepReg_exit;
    }

    if (lpch && *lpch) lpszFile = lpch+1; // skip the '\'.
    if (lpch && *lpch) *lpch = '\0';      // lpszName is a directory now.

    // Allocate memory to retrieve font name and value string
    if ((lpName = (LPSTR)GlobalAllocPtr(GHND, 2*BUF_SIZE)) == NULL)
        goto SepReg_exit;
    lpValue = lpName + BUF_SIZE;   // One allocate for two buffers.

    // Enumerate all the values for this key
    // Search the registry to see if lpszName is already defined as one of 0,1,2,...
    dwRegIndex = 0;
    while ((cbName = cbValue = BUF_SIZE) &&
            RegEnumValue(hkey, dwRegIndex, lpName, (LPDWORD)&cbName,
            NULL, (LPDWORD)&dwType, lpValue, (LPDWORD)&cbValue)
           == ERROR_SUCCESS  && ++dwRegIndex)
        {
        // We are not interested in anything that is not REG_SZ
        if (dwType != REG_SZ)  continue;
        if (lstrcmpi(lpszName, lpValue)==0){ //Path names are case-insensitive
             lstrcpy(lpszKey, lpName);
             bKnownPath = TRUE;
             break;
             }
        }

     if (!bKnownPath){ // Create a new path key/val pair - borrow lpKey, lpValue
        i=0;
        while(1){
           wsprintf(lpName, "%d", i);
           cbValue = BUF_SIZE;
           if (RegQueryValueEx(hkey, lpName, 0, (LPDWORD)&dwType,
               lpValue, (LPDWORD)&cbValue) != ERROR_SUCCESS)
                 {
                  RegSetValueEx(hkey, lpName, 0, REG_SZ,
                        lpszName, lstrlen(lpszName)+1);
                  lstrcpy(lpszKey, lpName);
                  break;
                 }
            i++;
        }
     }

SepReg_exit:
    if (hkey)
        RegCloseKey(hkey);
    if (lpName)
        GlobalFreePtr(lpName);  // lpValue was allocated as part of lpName

    return lpszFile;
}


// Function to build Key-Value pair from PFM/PFB. We don't open reg in this function to save time.
// Because a flat section in Registry will be full at 61K bytes, we register
// PSFonts Paths as different keys to shorten the entries - lpValue is simplified.
BOOL FAR PASCAL MakeFontKeyVal(LPSTR lpszPFMName, LPSTR lpszPFBName,
     LPSTR lpFontNameKey, LPSTR lpValue, WORD addPath, WORD addType1String)
{
    LPPFMHEADER lpPFMHdr;
    BOOL        rc = FALSE;
    char    szPFMKey[10];  // to hold a integer
    char    szPFBKey[10];
    LPSTR   lpPfm, lpPfb; // Pointers point to the PFM/PFB without Path in lpszPFM/BName

    if (ReadPFMFile(lpszPFMName, (LPVOID FAR*) &lpPFMHdr))
    {
        lstrcpy(lpFontNameKey, (LPBYTE)lpPFMHdr + ((LPPSFONTINFO)lpPFMHdr)->dfDriverInfo - sizeof(PFMPROLOG));
        if (addType1String)
          lstrcat(lpFontNameKey, cszType1);
        *lpValue = '\0';  //clear the buffer

        if (addPath & PFM)  //create PFM path
        {
          lpPfm=RegisterPSFontsPath(lpszPFMName, (LPSTR)szPFMKey);

          lstrcat(lpValue, cszPFM);
          lstrcat(lpValue, (LPSTR)szPFMKey);
          lstrcat(lpValue, cszColon);
          lstrcat(lpValue, lpPfm);
        }


        if (lpszPFBName && lpszPFBName[0] && (addPath & PFB)) //create PFB path
        {
            lpPfb=RegisterPSFontsPath(lpszPFBName, (LPSTR)szPFBKey);
            lstrcat(lpValue, cszVBar);
            lstrcat(lpValue, cszPFB);
            lstrcat(lpValue, (LPSTR)szPFBKey);
            lstrcat(lpValue, cszColon);
            lstrcat(lpValue, lpPfb);
        }
        GlobalFreePtr(lpPFMHdr);
        rc = TRUE;
    }

    return rc;
}

// Pass-in lpszExpandedName has at least MAX_PATH long
// lpPtr has format "2001:helv____.pfb" OR ":c:\win95\fonts\pfm\bo_____.pfm"
BOOL NEAR PASCAL ExpandPSFontsPath(LPSTR lpszPtr, LPSTR lpszExpandedName)
{
    LPSTR   lpch;
    LPSTR   lpFile;
    char    szKey[32];  // to hold a integer-key such as "2001".
    int     i;
    BOOL    rc= FALSE;
    HKEY    hkey = NULL;
    DWORD   dwType, cbSize;

    RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR)gszRegFontsPathPaths, (HKEY FAR*)&hkey);
    // If OpenKey Fails, treat all Paths as full path - follow th same code path here:

    lpszExpandedName[0]='\0';  // init.
    lpch = lstrchr(lpszPtr, cColon);  // find first ':'
    if (lpch==NULL)  goto ExpandPath_exit;  // cannot expand

    if (lpch && *lpch){
        lpFile = lpch+1;    // skip ":", lpFile is the File Name
        *lpch='\0';
        }
    lstrcpyn(szKey, lpszPtr, sizeof(szKey)-1);

    // Use this key to get the PFM or PFB Path:
    cbSize = MAX_PATH;  // lpszExpandedName has at least MAX_PATH long
    if (RegQueryValueEx(hkey, (LPSTR)szKey, 0, (LPDWORD)&dwType,
          lpszExpandedName, (LPDWORD)&cbSize) == ERROR_SUCCESS)
       {
        i = lstrlen(lpszExpandedName);
        if (i>0 && lpszExpandedName[i-1]!='\\')
           lstrcat(lpszExpandedName, "\\"); // append a \ if not there
       }
    lstrcat(lpszExpandedName, lpFile);

    rc=TRUE;

ExpandPath_exit:
    if (hkey)
        RegCloseKey(hkey);
    return rc;
}

// Function to build PFM/PFB from Reg's Value
BOOL NEAR PASCAL MakePFMPFB(LPSTR lpszPFMName, LPSTR lpszPFBName,
     LPSTR lpValue)
{
    BOOL    rc = FALSE;
    char    szTmp[MAX_PATH];
    LPSTR   lpPtr;
    WORD    wLength;

    // lpValue is in format: "M101:hlv___.pfm|B102:hlv____.pfb". or
    // in another order:     "B101:hlv___.pfb|M102:hlv____.pfm"
    if ((lpPtr = FindString(lpValue, cszPFM, &wLength)) != NULL)
       {
       lstrcpyn(szTmp, lpPtr, wLength+1);
       ExpandPSFontsPath((LPSTR)szTmp, lpszPFMName);
       // Search PFB again from start of lpValue
       if ((lpPtr = FindString(lpValue, cszPFB, &wLength)) != NULL){
          lstrcpyn(szTmp, lpPtr, wLength+1);
          ExpandPSFontsPath((LPSTR)szTmp, lpszPFBName);
          }
       rc = TRUE;
       }
    return rc;
}


DWORD NEAR PASCAL MergeIniFileToRegistry(LPSTR lpszIniFile, LPSTR lpszSection, BOOL bDeleteAll, BOOL bDeleteDownloadAble, DWORD dwDrvSum)
{
    LPSTR     lpszBuffer=NULL, aptr;
    char FAR* lpch;
    WORD      i= 0;
    WORD      newNumFonts =0; // max 642K fonts - a Section is limited by 64K bytes in INI file.
    LPSTR     lpszValue=NULL;   // 2 * MAX_PATH; For value of entries in INI file
    LPSTR     lpFontNameKey=NULL; // BUF_SIZE>11+MAX_NAME_LEN=61. plus the length of " (Type 1)"
    LPSTR     lpFontValue=NULL;   // BUF_SIZE=1K >PATH Plus "FIL:PFM:" "FIL:PFB:"
    LPSTR     lpFontTemp = NULL;
    LPSTR     lpFontAppendValue = NULL;
    HKEY      hkey = NULL;
    BOOL      bRegUpdated = 0;
    DWORD dwType;
    DWORD dwCBSize;
    WORD    wLength;
    DWORD    dwCheckSum = 0;
    WORD    length = 0;



    // Use one allocate for two bufers.
    if ((lpszValue = GlobalAllocPtr(GHND, 2*MAX_PATH + 4 * BUF_SIZE)) == NULL)
        goto mergeini_exit;
    lpFontNameKey = lpszValue +  2*MAX_PATH;  // lpszValue wants to be 2*MAX_PATH long
    lpFontValue = lpFontNameKey +  BUF_SIZE;
    lpFontTemp = lpFontNameKey + 2*BUF_SIZE;
    lpFontAppendValue = lpFontNameKey + 3*BUF_SIZE;

    /* Allocate buffer - max size of section is 64K */
    lpszBuffer = (LPBYTE) GlobalAllocPtr(GDLLHND, LIMIT_64K);
    if (! lpszBuffer)
        goto mergeini_exit;

    /* Get all entries in szSection */
    if (GetPrivateProfileString((LPSTR) lpszSection, (LPSTR) NULL, (LPSTR) "",
                         lpszBuffer, (WORD) ((DWORD) LIMIT_64K - 1), lpszIniFile) != 0)
    {
       // Find out how many entries we got:
       aptr = lpszBuffer; // don't modify the Buffer - need it later.
       while (aptr && *aptr)
       {

          //calculate check sum while counting # of entries.

         //add up the value as well
         GetPrivateProfileString((LPSTR) lpszSection, aptr,
                        (LPSTR) "", lpszValue, BUF_SIZE, lpszIniFile);
         length = lstrlen(lpszValue);
         while (length) //just add up the name
           dwCheckSum +=lpszValue[length--];

          newNumFonts++;
          aptr += lstrlen(aptr)+1;

       }

      //if no Postscript Font section, we want to create a serial number too.
      // always update if postscript section is gone.
      if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR)gszRegFontsPath, (HKEY FAR*)&hkey)
            != ERROR_SUCCESS)
      {
         bRegUpdated =1;
         RegCloseKey(hkey);
      }
      else if (dwCheckSum == dwDrvSum)  //No need to update if check sum ok.
        goto mergeini_exit;


      if (RegCreateKey(HKEY_LOCAL_MACHINE, (LPSTR)gszRegFontsPath, (HKEY FAR*)&hkey)
            != ERROR_SUCCESS)
        goto mergeini_exit;

      if (newNumFonts > 0)
       {
         /* For each entry, get the value */
         i=0;
         while ((i < newNumFonts) && lpszBuffer
               && (dwCBSize = BUF_SIZE))
         {
            GetPrivateProfileString((LPSTR) lpszSection, lpszBuffer,
                        (LPSTR) "", lpszValue, BUF_SIZE, lpszIniFile);
            if (lpszValue[0])
            {
               /*
                  * Value is of the form <PFM FILE>[,<PFB FILE>].
                  * If comma is present, PFB File is also given.
                  */
               if (lpch = lstrchr( lpszValue, ','))
               {
                  *lpch = '\0';
                  lpch++;
                  // Now lpch is the DownloadAble PFB Path !!!
                  if (!bDeleteAll && bDeleteDownloadAble)
                     WritePrivateProfileString((LPSTR)lpszSection, lpszBuffer, NULL, lpszIniFile);
               }
               // Now, lpszValue is the PFM Path!!
               // Build the Key/Val pair ro appear in Registry - only for DownloadAbles (lpch!=NULL):
//               if ((lpch!=NULL) &&  add PFM only stmts too, bug 186654, ang 1/21/97
                 if (MakeFontKeyVal(lpszValue, (LPSTR)lpch, lpFontNameKey, lpFontValue, 0, 1))
               {
                  // add to Registry: if it does not exist
                  if (RegQueryValueEx(hkey, (LPSTR)lpFontNameKey, 0, (LPDWORD)&dwType, lpFontTemp, (LPDWORD) &dwCBSize) != ERROR_SUCCESS)
                  {
                     MakeFontKeyVal(lpszValue, (LPSTR)lpch, lpFontNameKey, lpFontValue, PFM|PFB, 1);
                     if (RegSetValueEx(hkey, (LPSTR)lpFontNameKey, 0, REG_SZ, lpFontValue,
                                 lstrlen(lpFontValue)+1) == ERROR_SUCCESS)
                      bRegUpdated =1;
                  }
                  else if (*lpFontTemp && (FindString(lpFontTemp, cszPFM, &wLength) == NULL))
                  {
                     MakeFontKeyVal(lpszValue, (LPSTR)lpch, lpFontNameKey, lpFontAppendValue, PFM, 1);
                     lstrcat(lpFontTemp, cszVBar);
                     lstrcat(lpFontTemp, lpFontAppendValue);
                     if (RegSetValueEx(hkey, (LPSTR)lpFontNameKey, 0, REG_SZ, lpFontTemp,
                                 lstrlen(lpFontTemp)+1) == ERROR_SUCCESS)
                        bRegUpdated =1;
                  }
                  else if (*lpFontTemp && (lpch!=NULL) && (FindString(lpFontTemp, cszPFB, &wLength) == NULL))
                  {
                     MakeFontKeyVal(lpszValue, (LPSTR)lpch, lpFontNameKey, lpFontAppendValue, PFB, 1);
                     //no need for the vBar. already added by MakeFontKeyValue.
                     lstrcat(lpFontTemp, lpFontAppendValue);
                     if (RegSetValueEx(hkey, (LPSTR)lpFontNameKey, 0, REG_SZ, lpFontTemp,
                                 lstrlen(lpFontTemp)+1) == ERROR_SUCCESS)
                        bRegUpdated =1;
                  }
               }
            }  // end for "if (lpszValue[0])"

            i++; //process next font

            /* Next entry */
            lpszBuffer += lstrlen(lpszBuffer) + 1;

           } //end for outer while loop
        }  // end if(newNum>0)

    //want to close key hear because SetSerialNo will use that section too
    if (hkey)
        RegCloseKey(hkey);

     // Update the Registry's SerialNumber so others (Pscript4.1) knows the changes
     if (bRegUpdated)
      {
           SetSerialNo((LPSTR)gszRegFontsPath, 0);

      }
    } //end Of GetProfileString



    if (bDeleteAll)
       WritePrivateProfileString((LPSTR)lpszSection, NULL, NULL, lpszIniFile);

mergeini_exit:
    if (hkey)
        RegCloseKey(hkey);
    if (lpszValue)
        GlobalFreePtr(lpszValue); // lpszFontNameKey and lpszFontVal were allocated as part of lpszValue;
    if (lpszBuffer)
        GlobalFreePtr(lpszBuffer);

    return (dwCheckSum);
}



BOOL NEAR PASCAL AddFontToList(LPSTR lpFontName, LPSTR lpValue,
      HPPFMFILE hpPFMPtr)
{
    WORD  wDiff, i = 0;
    BOOL  rc = FALSE;

    // Check if lpFontName ends with cszType1
    wDiff = lstrlen(lpFontName) - lstrlen(cszType1);
    if (lstrcmp(lpFontName + wDiff, (LPSTR)cszType1) == 0)
    {
       // Expand Possible Macros for the Paths used in lpValue
       rc=MakePFMPFB(hpPFMPtr->szPFMName, hpPFMPtr->szPFBName, lpValue);
    }
    return rc;
}

/*  This function searches hpPFMFile from 0 to block numFonts:
 *  - If found the entry lpszPFM, then Add PFB if PFB is not present, and return TRUE
 *  - If not found, return FALSE  */
int NEAR PASCAL IsInPFMBlock(HPPFMFILE hpPFMFile, WORD numFonts, LPSTR lpszPFM, LPSTR lpszPFB)
{
    HPPFMFILE hpPFMPtr;
    int found=0;
    WORD i;

    hpPFMPtr=hpPFMFile;
    i=0;
    while(i<numFonts && hpPFMPtr && !found){
       found = !(lstrcmpi((LPSTR) hpPFMPtr->szPFMName, (LPSTR) lpszPFM) );
       if (found && !hpPFMPtr->szPFBName[0]){
          // If PFB is Not already present, then add it there and set a flag:
          lstrcpy((LPSTR) hpPFMPtr->szPFBName, lpszPFB);
          hpPFMPtr->wAddedByOther=1;
          break;
       }
       hpPFMPtr++;
       i++;
      }

   return found;
}


int FAR PASCAL MergeRegistrySoftFonts(HPPFMFILE *phpPFMFile, LPWORD lpwNumFonts)
{
    HKEY      hkey = NULL;
    LPSTR     lpName = NULL, lpValue = NULL;
    DWORD     dwRegIndex, dwType;
    DWORD     cbName, cbValue;
    HPPFMFILE hpPFMPtr;
    WORD      oldNumFonts, newNumFonts;
    LONG      tmp;         // a singed tmp to do math
    DWORD     extraPFMs;   // Number of Extra PFMs to overcome 64K boundry problem
    int       numPPerSeg;
    WORD      wPfmBlock;   // Number of PFM blocks already passed. It is larger than i;

    oldNumFonts = *lpwNumFonts;  // Number of fonts already in hpPFMFile.
    numPPerSeg = (LONG)LIMIT_64K / sizeof(PFMFILE);  // num of blocks on one seg
    newNumFonts=0; // Initial, otherwise GPF if ATM.INI doesn't exist

    if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR)gszRegFontsPath, (HKEY FAR*)&hkey)
        != ERROR_SUCCESS)
        goto mergereg_exit;

    // Allocate memory to retrieve font name and value string
    if ((lpName = (LPSTR)GlobalAllocPtr(GDLLHND, 2*BUF_SIZE)) == NULL)
        goto mergereg_exit;
    lpValue = lpName + BUF_SIZE;

    // Enumerate all the values for this key, First Count Only.
    dwRegIndex = 0;
    while ((cbName = cbValue = BUF_SIZE) &&
           RegEnumValue(hkey, dwRegIndex, lpName, (LPDWORD)&cbName,
               NULL, (LPDWORD)&dwType, lpValue, (LPDWORD)&cbValue)
           == ERROR_SUCCESS  && ++dwRegIndex)
       {
        ;  // count only.
        }

    newNumFonts = (WORD) dwRegIndex;
    if (newNumFonts > 0)  // There is some softfonts in Registry !!
        {
         tmp = (LONG)numPPerSeg;
         tmp = (LONG)((float)(oldNumFonts+newNumFonts) / tmp +0.5);        // num of extra PFM blocks needed
         extraPFMs = (DWORD) tmp;
         newNumFonts += (WORD)extraPFMs;
         if (phpPFMFile==NULL)
              *phpPFMFile = (HPPFMFILE) GlobalAllocPtr(GDLLHND, ((DWORD)newNumFonts) * sizeof(PFMFILE));
         else *phpPFMFile = (HPPFMFILE) GlobalReAllocPtr(*phpPFMFile,
              ((DWORD)(oldNumFonts+newNumFonts)) * sizeof(PFMFILE), GMEM_ZEROINIT );
         // ReAlloc with flag GMEM_ZEROINIT may fail if this function is called again be careful
         if (! phpPFMFile)
             goto mergereg_exit;

         /* For each entry, get the value */
         hpPFMPtr = *phpPFMFile+oldNumFonts; // Start from the end of old fonts Plus OldExtra
         wPfmBlock = (WORD)oldNumFonts; // where we start the new PFMs

         // Enumerate all the values for this key, and extract PFM and PFB
         // information from each one of them.
         dwRegIndex = 0;
         while ((cbName = cbValue = BUF_SIZE) &&
              RegEnumValue(hkey, dwRegIndex, lpName, (LPDWORD)&cbName,
                 NULL, (LPDWORD)&dwType, lpValue, (LPDWORD)&cbValue)
              == ERROR_SUCCESS  && ++dwRegIndex)
         {
           // We are not interested in anything that is not REG_SZ
           // The registry may be changed after we count it. So add these low index
            if (dwType != REG_SZ || dwRegIndex > newNumFonts)
                 continue;
            // Extract the PFM and PFB path from lpValue and add it to the hpPFMPtr list:
            AddFontToList(lpName, lpValue, hpPFMPtr);

            // Update the bAddedByOther flag if the just added one overwrites a DownloadED entry
            // Discard this entry if PFB is not found. fix bug 142680, 2-5-96
            if ((hpPFMPtr->szPFBName[0]=='\0') ||
                (IsInPFMBlock(*phpPFMFile, oldNumFonts, hpPFMPtr->szPFMName, hpPFMPtr->szPFBName))
              // make sure just added entry is not a DBCS DownloadAble Font - we canot download DBCS PS-Font
              || (hpPFMPtr->szPFBName[0]!='\0' && IsDBCSPFM((LPSTR)hpPFMPtr->szPFMName) )

              )
               {
                 hpPFMPtr->szPFMName[0]='\0';
                 hpPFMPtr->szPFBName[0]='\0'; // clean up for next check pfm/pfb pair
                 hpPFMPtr--;  // will increase later, - This entry won't appear in MFD file!
               }

             hpPFMPtr++;
             wPfmBlock++;
             // Skip the block on the seg boundry:
             if ((wPfmBlock)%numPPerSeg==0){
                 hpPFMPtr++;
                 wPfmBlock++;     // it doesn't match I any more.
             }
           }  // end while()
        }

    *lpwNumFonts = oldNumFonts+newNumFonts;

mergereg_exit:
    if (hkey)
        RegCloseKey(hkey);
    if (lpName)
        GlobalFreePtr(lpName); // lpValue was allocated as part of lpName

    return 1;
}



int FAR PASCAL MergeOtherSoftFonts(HPPFMFILE *phpPFMFile, LPWORD lpwNumFonts, LPSTR lpszIniFile, LPSTR lpszSection)
{
    LPSTR     lpszBuffer, aptr;
    char FAR* lpch;
    WORD      i;
    LPSTR     lpszValue = NULL;   /* For value of entries */
    HPPFMFILE hpPFMPtr;
    WORD      oldNumFonts, newNumFonts;
    LONG      tmp;         // a singed tmp to do math
    DWORD     extraPFMs;   // Number of Extra PFMs to overcome 64K boundry problem
    int       numPPerSeg;
    WORD      wPfmBlock;   // Number of PFM blocks already passed. It is larger than i;

    /* Allocate buffer - max size of section is 64K */
    lpszBuffer = (LPBYTE) GlobalAllocPtr(GDLLHND, LIMIT_64K);
    if (! lpszBuffer)
        goto mergeother_exit;

    lpszValue = (LPBYTE) GlobalAllocPtr(GDLLHND, BUF_SIZE);
    if (! lpszValue)
        goto mergeother_exit;

    oldNumFonts = *lpwNumFonts;  // Number of fonts already in hpPFMFile.

    numPPerSeg = (LONG)LIMIT_64K / sizeof(PFMFILE);  // num of blocks on one seg
    newNumFonts=0; // Initial, otherwise GPF if ATM.INI doesn't exist

    /* Get all entries in szSection */
    if (GetPrivateProfileString((LPSTR) lpszSection, (LPSTR) NULL, (LPSTR) "",
                         lpszBuffer, (WORD) ((DWORD) LIMIT_64K - 1), lpszIniFile) != 0)
    {
       // Find out how many entries we got:
       newNumFonts=0;
       aptr = lpszBuffer; // don't modify the Buffer - need it later.
       while (aptr && *aptr){
          newNumFonts++;
          aptr += lstrlen(aptr)+1;
          }

        if (newNumFonts > 0)
        {

            tmp = (LONG)numPPerSeg;
            tmp = (LONG)((float)(oldNumFonts+newNumFonts) / tmp +0.5);        // num of extra PFM blocks needed
            extraPFMs = (DWORD) tmp;
            newNumFonts += (WORD)extraPFMs;

            if (phpPFMFile==NULL)
                 *phpPFMFile = (HPPFMFILE) GlobalAllocPtr(GDLLHND, ((DWORD)newNumFonts) * sizeof(PFMFILE));
            else *phpPFMFile = (HPPFMFILE) GlobalReAllocPtr(*phpPFMFile,
                ((DWORD)(oldNumFonts+newNumFonts)) * sizeof(PFMFILE), GMEM_ZEROINIT );
            // ReAlloc with flag GMEM_ZEROINIT may fail if this function is called again be careful
            if (! phpPFMFile)
                goto mergeother_exit;  // unable to allocate memory, just return;

            /* For each entry, get the value */
            hpPFMPtr = *phpPFMFile+oldNumFonts; // Start from the end of old fonts Plus OldExtra

            i=0;
            wPfmBlock = (WORD)oldNumFonts; // where we start the new PFMs
            while (i < newNumFonts && lpszBuffer)
            {
               GetPrivateProfileString((LPSTR) lpszSection, lpszBuffer,
                         (LPSTR) "", (LPSTR) lpszValue, BUF_SIZE, lpszIniFile);
               if (*lpszValue){
                  /*
                   * Value is of the form <PFM FILE>[,<PFB FILE>].
                   * If comma is present, PFB File is also given.
                   */
                  if (lpch = lstrchr((LPSTR) lpszValue, ',')) {
                      *lpch = '\0';
                      lpch++;
                      lstrcpy((LPSTR) hpPFMPtr->szPFBName, (LPSTR) lpch);
                   }
                  lstrcpy((LPSTR) hpPFMPtr->szPFMName, (LPSTR) lpszValue);

                 // Update the bAddedByOther flag if the just added one overwrites a DownloadED entry
                  if (IsInPFMBlock(*phpPFMFile, oldNumFonts, hpPFMPtr->szPFMName, hpPFMPtr->szPFBName)
                 // make sure just added entry is not a DBCS DownloadAble Font - we canot download DBCS PS-Font
                     || (hpPFMPtr->szPFBName[0]!='\0' && IsDBCSPFM((LPSTR)hpPFMPtr->szPFMName) )
                     )
                    {
                      hpPFMPtr->szPFMName[0]='\0';
                      hpPFMPtr--;  // will increase later, - This entry won't appear in MFD file!
                    }

                   hpPFMPtr++;
                   i++; wPfmBlock++;
                   // Skip the block on the seg boundry:
                   if ((wPfmBlock)%numPPerSeg==0){
                      hpPFMPtr++;
                      wPfmBlock++;     // it doesn't match I any more.
                     }
                 }
              else i++;

              /* Next entry */
              lpszBuffer += lstrlen(lpszBuffer) + 1;
           }
        }
    }

    *lpwNumFonts = oldNumFonts+newNumFonts;

mergeother_exit:
    if (lpszBuffer)
        GlobalFreePtr(lpszBuffer);
    if (lpszValue)
        GlobalFreePtr(lpszValue);


    return 1;
}







BOOL NEAR PASCAL CheckFontCRC(LPFILEHDR lpFileHdr, LPCRCINFO lpCRCInfo,
                              BOOL bDriverFonts)
{
    LPWORD lpCRC_16_tab = (LPWORD) crc_16_tab;
    WORD   wCRCVal = 0xffff;
    WORD   i;

    if (lpFileHdr->wVersionNumber != (WORD) MFD_VERSION)
        return FALSE;

    if (bDriverFonts == FALSE)
    {
        /* Do checksum based on pfm and pfb file names */
        HPPFMFILE hpPFMFile = (HPPFMFILE) lpCRCInfo->lpBuffer;

        for (i=0; i<lpCRCInfo->wNumber; i++) {
            wCRCVal = CalcCRC(hpPFMFile->szPFMName,
                              lstrlen((LPSTR) hpPFMFile->szPFMName),
                              wCRCVal, lpCRC_16_tab);
            if (hpPFMFile->szPFBName[0])
                wCRCVal = CalcCRC(hpPFMFile->szPFBName,
                                  lstrlen((LPSTR) hpPFMFile->szPFBName),
                                  wCRCVal, lpCRC_16_tab);
            hpPFMFile++;
        }
    }
    else
    {
        /* Driver supported fonts - Do checksum based on fonts.mfm file time */
        LPDATETIME lpDateTime = (LPDATETIME) lpCRCInfo->lpBuffer;

        wCRCVal = CalcCRC((LPBYTE) &lpDateTime->date, sizeof(unsigned int),
                          wCRCVal, lpCRC_16_tab);
        wCRCVal = CalcCRC((LPBYTE) &lpDateTime->time, sizeof(unsigned int),
                          wCRCVal, lpCRC_16_tab);
    }

    return (wCRCVal == lpFileHdr->wCrcVal);
}


/****************** Exported Functions *******************/
void NEAR PASCAL InitNewFontDirCache()
{
   LPFONTDIRCACHE lpNewFontDir = NULL;

   lpNewFontDir = (LPFONTDIRCACHE) GlobalAllocPtr(GDLLHND, sizeof(FONTDIRCACHE));
   if (lpNewFontDir)
   {
    lpNewFontDir->hpFontDirTab[PSFR] = NULL;
    lpNewFontDir->hpFontDirTab[ATMDB] = NULL;
    lpNewFontDir->wNumFonts[PSFR] = 0;
    lpNewFontDir->wNumFonts[ATMDB] = 0;
    lpNewFontDir->dwTimeStamp[PSFR]=0;
    lpNewFontDir->wTotalNumFonts = 0;
    lpNewFontDir->dwPSFRSerialNo = 0;
    lpNewFontDir->dwTTFRSerialNo = 0;
    lpNewFontDir->dwMFMTimeStamp = 0;
    lpNewFontDir->dwMFMTimeStamp = GetMFMTimeStampID();

    lpNewFontDir->lpNextCache = chFonts.lpFontDirCurrent;
    chFonts.lpFontDirCurrent = lpNewFontDir;
    chFonts.wNumFontDir++;

   }
}

void FAR PASCAL InitFontCache(void)
{

    chFonts.lpFontDirCurrent = chFonts.lpFontDirEnd = NULL;
    chFonts.lpCacheStart = chFonts.lpCacheEnd = NULL;
    chFonts.wNumFontCached =  chFonts.wNumFontDir = 0;

    bInitFontCache = TRUE;
}


WORD FAR PASCAL CalcCRC(LPBYTE lpbString, WORD wByteCount,
                        WORD wCRCVal, LPWORD lpCRC_16_tab)
{
    BYTE  c;
    WORD  i;

    for (i = 0 ; i < wByteCount ; i++) {
        c = (BYTE)(wCRCVal >> 8) ^ lpbString[i] ;
        wCRCVal <<= 8;
        wCRCVal ^= lpCRC_16_tab[c];
    }

    return(wCRCVal);
}


void FAR PASCAL CreateMFDFileName(LPSTR lpszFileName)
{
    OFSTRUCT ofFileStruct;
    DWORD    x;
    int      i = 0, j, l;

   GetWindowsDirectory(lpszFileName, PS_FILE_PATH_LENGTH);
   l = lstrlen(lpszFileName);
#ifdef MICROSOFT_DRIVER_VERSION
   if (lpszFileName[l-1] != '\\')
      lstrcat(lpszFileName, (LPSTR) "\\PS");
   else
      lstrcat(lpszFileName, (LPSTR) "PS");
#else
   if (lpszFileName[l-1] != '\\')
      lstrcat(lpszFileName, (LPSTR) "\\AD");
   else
      lstrcat(lpszFileName, (LPSTR) "AD");
#endif
   l = lstrlen(lpszFileName);

    while (i++ <= 5) {
        x = GetTickCount();

        for (j=0; j<6; j++) {
            lpszFileName[l+j] =
              (char) ((int) ((x % 16) >= 10 ? 'A' - 10 : '0') + (int) (x % 16));
            x = x / 16;
        }
        lpszFileName[l+j] = '\0';

        lstrcat(lpszFileName, (LPSTR) ".MFD");

        if (OpenFile(lpszFileName, (LPOFSTRUCT) &ofFileStruct,
                     OF_EXIST) == HFILE_ERROR)
            break;
    }

    if (i >= 6)
        lpszFileName[0] = '\0';
}



void FAR PASCAL FreeCache(LPFONTCACHE lpCache)
{

    if (lpCache && lpCache->wUseCount)
    {
        lpCache->wUseCount--;
    }
}


void FAR PASCAL FreeFontCacheMemory(void)
{
    LPFONTCACHE lpCache = chFonts.lpCacheStart;
    LPFONTDIRCACHE lpFontDirCache = chFonts.lpFontDirCurrent;
    LPFONTCACHE lpFC;
    LPFONTDIRCACHE lpFCDir;
    int i;

    //free all font cache memory
    while (lpCache) {
        /* Make sure this is not a dummy entry - See GetSoftFontCache() */
        if (lpCache->hpDirIndex)
        {
            GlobalFreePtr(lpCache->hpDirIndex);
        }

        lpFC = lpCache;
        lpCache = lpFC->lpNextCache;

        GlobalFreePtr(lpFC);
   }

   //Clean all FontsDir.mfd
   while (lpFontDirCache)
   {
      lpFCDir = lpFontDirCache;
      lpFontDirCache = lpFontDirCache->lpNextCache;

      //free all MFDs
      for (i  = 0 ; i < MAX_MFD; i++)
      {
         if (lpFCDir->hpFontDirTab[i])
         {
            GlobalFreePtr(lpFCDir->hpFontDirTab[i]);
            lpFCDir->hpFontDirTab[i]  = NULL;
         }
         if (lpFCDir->hpPFMProlog[i])
         {
            GlobalFreePtr(lpFCDir->hpPFMProlog[i]);
            lpFCDir->hpPFMProlog[i]  = NULL;
         }

         lpFCDir->wNumFonts[i] = 0;
         lpFCDir->dwTimeStamp[i] = 0;
      }//for

      lpFCDir->dwPSFRSerialNo = 0;
      lpFCDir->dwTTFRSerialNo = 0;
      lpFCDir->dwMFMTimeStamp = 0;
    }//while

    chFonts.lpCacheStart = chFonts.lpCacheEnd = NULL;
    chFonts.lpFontDirCurrent = chFonts.lpFontDirEnd = NULL;
    chFonts.wNumFontCached = chFonts.wNumFontDir = 0;
}


/*****************************************************************************
*                               ReadPFMData
*  function:
*  parameters:
*  returns:
*       RC_OK if successful, else RC_ERROR.
***************************************************************************/
DWORD FAR PASCAL ReadPFMData(HFILE hFile, LPVOID FAR* lplpPFMData)
{
    PFMPROLOG   pfmProlog;
    DWORD       dwPrologSize = sizeof(PFMPROLOG);
    DWORD       dwPFMSize;
    DWORD       rc = 0;
    UINT        nbytes;

    /* Find size of PFM block, and allocate space */
    if ((nbytes = _lread(hFile, (HPVOID) &pfmProlog,
                         (UINT) dwPrologSize)) == dwPrologSize)
    {
        dwPFMSize = pfmProlog.dfSize - dwPrologSize;
        if (lplpPFMData)
        {
            if (*lplpPFMData = (LPVOID) GlobalAllocPtr(GDLLHND, dwPFMSize))
            {
                nbytes = _lread(hFile, (HPVOID) *lplpPFMData, (UINT) dwPFMSize);
                if (nbytes == dwPFMSize)
                    rc = dwPFMSize;
                else
                    GlobalFreePtr(*lplpPFMData);
            }
        }
    }
    return rc;
}


/*****************************************************************************
*                               ReadPFMFile
*  function:
*  parameters:
*       LPSTR lpszPFMFile -- name of PFM file to read.
*  returns:
*       RC_OK if successful, else RC_ERROR.
***************************************************************************/
DWORD FAR PASCAL ReadPFMFile(LPSTR lpszPFMFile, LPVOID FAR* lplpPFMData)
{
    OFSTRUCT   ofFileStruct;
    DWORD      rc = 0;
    HFILE      hFile;

    if ((hFile = OpenFile(lpszPFMFile, (LPOFSTRUCT) &ofFileStruct,
                          OF_READ)) != HFILE_ERROR)
    {
        rc = ReadPFMData(hFile, lplpPFMData);
        _lclose(hFile);
    }

    return rc;
}


DWORD FAR PASCAL ReadPFMFromMFM(LPSTR lpszMFMFile, LPVOID FAR* lplpPFMData,
                                DWORD dwOffset)
{
    OFSTRUCT   ofFileStruct;
    DWORD      rc = 0;
    HFILE      hFile;

    if ((hFile = OpenFile(lpszMFMFile, (LPOFSTRUCT) &ofFileStruct,
                          OF_READ)) != HFILE_ERROR)
    {
        _llseek(hFile, dwOffset, SEEK_CUR);
        rc = ReadPFMData(hFile, lplpPFMData);
        _lclose(hFile);
    }

    return rc;
}


/*****************************************************************************
*                               MakeTextMetric
*  function:
*  parameters:
*  returns:
*       No return value
***************************************************************************/
void FAR PASCAL MakeTextMetric(LPPFMHEADER lpPFMHdr, LPTEXTMETRIC lpTextMetric,
                                WORD wXres, WORD wYres)
{
    WORD wXscale, wYscale;
    WORD wIntLead, wExtLead;
    WORD wAveCharWidth;
    int  EM;
    BYTE PitchAndFamily;

    if (lpTextMetric)
    {
        LPPFMEXTENSION lpPFMExt;
        LPETM lpETM;

        lpPFMExt = (LPPFMEXTENSION) ((LPBYTE) lpPFMHdr + sizeof(PFMHEADER));
        lpETM = (LPETM) ((LPBYTE) lpPFMHdr + lpPFMExt->dfExtMetricsOffset);
        EM = lpETM->etmMasterUnits;

        wYscale = MulDiv(POINTS10, wYres, POINTS_PER_INCH);
        wXscale = MulDiv(wYscale, wXres, wYres);
        wIntLead = lpPFMHdr->dfInternalLeading;
        wExtLead = lpPFMHdr->dfExternalLeading;
        SetLeading(lpPFMHdr->dfPitchAndFamily, POINTS10, wYscale, wYres,
                   (LPWORD) &wIntLead, (LPWORD) &wExtLead, EM, lpPFMHdr->dfCharSet);

        wAveCharWidth = MulDiv(lpPFMHdr->dfAvgWidth, wXscale, EM);

#if 0
        /*
         * In PFMHEADER, if bit 0 is set, it is variable pitch. In TEXTMETRIC,
         * if bit 0 is set, it is fixed pitch, if bit 1 is set it is
         * variable pitch. So convert.
         */
        PitchAndFamily = lpPFMHdr->dfPitchAndFamily & 0x01 ?
            (lpPFMHdr->dfPitchAndFamily & 0xf0) | 0x02 :
            lpPFMHdr->dfPitchAndFamily | 0x01;
#else
        // Win31 DDK is WRONG. TEXTMETRIC & PFMHEADER have identical
        // PitchAndFamily. In LOGFONT is this value + 1.
        PitchAndFamily = lpPFMHdr->dfPitchAndFamily;
#endif
        /*
         * Note that wYscale happens to be height of 10pt character
         * in device coordinates.
         */

        lpTextMetric->tmHeight = wYscale + wIntLead;
        lpTextMetric->tmAscent = MulDiv(lpPFMHdr->dfAscent, wYscale, EM);
        lpTextMetric->tmDescent = lpTextMetric->tmHeight -
            lpTextMetric->tmAscent;
        lpTextMetric->tmInternalLeading = wIntLead;
        lpTextMetric->tmExternalLeading = wExtLead;
        lpTextMetric->tmAveCharWidth = wAveCharWidth;
        lpTextMetric->tmMaxCharWidth = MulDiv(lpPFMHdr->dfMaxWidth,
                                              wXscale, EM);
        lpTextMetric->tmWeight = lpPFMHdr->dfWeight;
        lpTextMetric->tmItalic = lpPFMHdr->dfItalic;
        lpTextMetric->tmUnderlined = 0;
        lpTextMetric->tmStruckOut = 0;
        lpTextMetric->tmFirstChar = lpPFMHdr->dfFirstChar;
        lpTextMetric->tmLastChar = lpPFMHdr->dfLastChar;
        lpTextMetric->tmDefaultChar = lpPFMHdr->dfDefaultChar +
            lpPFMHdr->dfFirstChar;
        lpTextMetric->tmBreakChar = lpPFMHdr->dfBreakChar +
            lpPFMHdr->dfFirstChar;
        lpTextMetric->tmPitchAndFamily = PitchAndFamily;
        lpTextMetric->tmCharSet = lpPFMHdr->dfCharSet;
        lpTextMetric->tmOverhang = 0;
        lpTextMetric->tmDigitizedAspectX = lpPFMHdr->dfHorizRes;
        lpTextMetric->tmDigitizedAspectY = lpPFMHdr->dfVertRes;
    }
}



WORD NEAR PASCAL DeleteFontCache(LPCSTR lpszPrinter)
{
   LPFONTCACHE lpCache, lpFC, lpNewStart, lpPrev;
   int numCache = chFonts.wNumFontCached;
   WORD countInUse = 0;
   char szPrnInstValue[SM_BUF];
   DWORD   cbSize = SM_BUF;


   /* if lpszPrinter then delete PI***.MFD per lpszPrinter */
   /* else remove all PI***.MFD and FontCaches */
   lpNewStart = chFonts.lpCacheStart;
   lpPrev = NULL;
   lpCache = lpNewStart;

   /* delete 1 or more printers from font cache */
   while (lpCache)
   {
     if (*lpszPrinter)
     { //delete one printer. find the right one
       if (lstrcmpi((LPSTR)lpCache->szFriendlyName, lpszPrinter) !=0)
       {
         lpCache = lpCache->lpNextCache;
         continue; //loop until we find it.
       }
     }


     //delete adxxx.Mfd file
      GetListOfFontsFileName(lpCache->szFriendlyName,  (LPSTR) szPrnInstValue, cbSize);
      if (*szPrnInstValue)
      {
         remove(szPrnInstValue);
      }

      //free from cache or mark as deleted.
      if (lpCache->wUseCount == 0)
      {
         GlobalFreePtr(lpCache->hpDirIndex);
         lpFC = lpCache;
         lpCache = lpCache->lpNextCache;

         // Update new start, new prev
         if (lpNewStart == lpFC) lpNewStart=lpCache;
         if (lpPrev) lpPrev->lpNextCache=lpCache;

         GlobalFreePtr(lpFC);
         numCache--;  // just lost a cache - one dollar.
      }
      else
      {
         lpCache->bDelete = TRUE;
         countInUse += lpCache->wUseCount;
         lpPrev = lpCache;
         lpCache = lpCache->lpNextCache;
      } //free from cache or mark as deleted
   } //while

   chFonts.lpCacheStart = lpNewStart;
   chFonts.wNumFontCached = numCache;

   return(countInUse);
}

/********************************************************
**
** Function:   CreateListOfFonts
**
********************************************************/
DWORD NEAR PASCAL CreateListOfFonts(LPSTR lpszFriendlyName, CACHEHDR ch, LPSTR lpszLOFName, LPSERIALNUMS lpPIData)
{
   OFSTRUCT ofFileStruct;
   DIRINDEXHDR dirIndexHdr;
   DWORD dwDirIndexSize;
   HPDIRINDEX hpDirIndex, hpTempDirIndex;
   DWORD rc = RC_ERROR;
   HFILE hfile  = NULL;
   WORD numFontsInTable = 0;
   DWORD dwResFontsSerialNo = 0;
   WORD  wNumResidentFonts  = 0;
   LPRESIDENTFONT lpResidentFonts = NULL;

   if (!lpszLOFName[0])
     return (rc);

   /* The MFD must be load before this point.  Otherwise this function
      was not called from GetFontCache*/
   /* Check all the parameters to build an IndexTable/ListOfFonts
      is available*/
   if (!(ch.lpFontDirCurrent)->hpFontDirTab[PSFR] && !(ch.lpFontDirCurrent)->hpFontDirTab[ATMDB])
     return (rc);
   if (!(ch.lpFontDirCurrent)->wNumFonts[PSFR] && !(ch.lpFontDirCurrent)->wNumFonts[ATMDB])
     return (rc);

   /*Allocate space for the index table*/
   dwDirIndexSize = (DWORD) sizeof(DIRINDEX) * ((ch.lpFontDirCurrent)->wNumFonts[PSFR]+ (ch.lpFontDirCurrent)->wNumFonts[ATMDB]);
   if (!(hpDirIndex = (HPDIRINDEX) GlobalAllocPtr(GDLLHND, dwDirIndexSize)) )
      return (rc);

   /* get a sorted list of all the resident font from the registry for this printer*/
   wNumResidentFonts = GetResidentFontsList(lpszFriendlyName,
                                           (LPRESIDENTFONT FAR*) &lpResidentFonts,
                                           (DWORD FAR *)&dwResFontsSerialNo);

   /*fill the index table*/
   numFontsInTable  = FillIndexTable(hpDirIndex, numFontsInTable, (ch.lpFontDirCurrent)->hpFontDirTab, (ch.lpFontDirCurrent)->wNumFonts[PSFR], 0, wNumResidentFonts, lpResidentFonts);
// numFontsInTable += FillIndexTable(hpDirIndex, numFontsInTable, (ch.lpFontDirCurrent)->hpFontDirTab, (ch.lpFontDirCurrent)->wNumFonts[ATMDB], 1, wNumResidentFonts, lpResidentFonts);

   /*set info in index header */
   //don't want to use the lpPIData->dwResFontsSerialNo because it might of changed
   dirIndexHdr.dwResFontsSerialNo =  dwResFontsSerialNo;
   dirIndexHdr.dwMFD0TimeStamp =  (ch.lpFontDirCurrent)->dwTimeStamp[PSFR];
   dirIndexHdr.dwPSFRSerialNo = (ch.lpFontDirCurrent)->dwPSFRSerialNo;
   dirIndexHdr.dwTTFRSerialNo = (ch.lpFontDirCurrent)->dwTTFRSerialNo;
   dirIndexHdr.dwSecondPSFRSerialNo = lpPIData->dwScndPSFRSerialNo;
   dirIndexHdr.wVersionNumber = MFD_VERSION;
   dirIndexHdr.wFriendlyNameLen = (lpszFriendlyName[0]) ? lstrlen(lpszFriendlyName) +1 : 0;
   dirIndexHdr.wTotalFonts = numFontsInTable;

   /*Sort Index Table*/
   hpTempDirIndex = hpDirIndex;
   HugeIsortByIndex((HPVOID) hpTempDirIndex, dirIndexHdr.wTotalFonts -1,
            (WORD)sizeof(DIRINDEX), IndexFontCompare, (HPVOID) &(ch.lpFontDirCurrent)->hpFontDirTab);

   if ((hfile = OpenFile(lpszLOFName, (LPOFSTRUCT) &ofFileStruct,
                        OF_CREATE | OF_WRITE)) != HFILE_ERROR)
   {
       if (CreateLOFMFDFile(hfile, (LPDIRINDEXHDR) &dirIndexHdr, hpDirIndex, lpszFriendlyName))
         rc = dwResFontsSerialNo;
   }

   if (hpDirIndex)
      GlobalFreePtr(hpDirIndex);
   if (hfile)
      _lclose(hfile);
   if (lpResidentFonts)
      FreeResidentFontsList(lpResidentFonts, wNumResidentFonts);
   return rc;
}

WORD FAR PASCAL CreateLOFMFDFile(HFILE hfile, LPDIRINDEXHDR lpIndexHdr,
                                 HPDIRINDEX hpDirIndex, LPSTR lpszFriendlyName)
{
   WORD rc = RC_ERROR;

   /*Write the Index Table Header*/
   if (_lwrite(hfile, (HPVOID) lpIndexHdr, sizeof(DIRINDEXHDR)) == sizeof(DIRINDEXHDR))
   {
      /* write Friendly Name*/
      if (lpIndexHdr->wFriendlyNameLen)
      {
         _lwrite (hfile, (HPVOID) lpszFriendlyName, lpIndexHdr->wFriendlyNameLen);
      }

      /*write Index Table*/
      if (_hwrite(hfile, (HPVOID) hpDirIndex, (long) sizeof(DIRINDEX) * (lpIndexHdr->wTotalFonts)) ==
            (long) sizeof(DIRINDEX) * (lpIndexHdr->wTotalFonts))
      {
         rc = RC_OK;
      }
   }
   return rc;
}
BOOL NEAR PASCAL IsGlyIndexCapable(LPRESIDENTFONT tempResidentFont)
{
   WORD  wLength;
  return((FindString(tempResidentFont->lpValue, cszXUID, &wLength) != NULL));
}

/********************************************************
**
** Function:   FillIndexTable
**
********************************************************/
WORD NEAR PASCAL FillIndexTable(HPDIRINDEX hpDirIndexHead,
                                 WORD numFontsInTable,
                                 HPFONTDIRECTORY hpFontDirs[],
                                 WORD wNumFontRec,
                                 WORD ithMFD,
                                 WORD wNumResidentFonts,
                                 LPRESIDENTFONT lpResidentFonts)
{
   HPFONTDIRECTORY hpFDir, hpTempFDir;
   HPFONTDIRECTORY hpFontDirList;
   HPDIRINDEX hpDirIndex;
   LPRESIDENTFONT tmpResidentFont = NULL;
   WORD  wFontCount = 0, nFontsInDirList = wNumFontRec;
   LPSTR lpPtr = NULL;
   HKEY  hKeyHPFR = NULL, hKeyTTFR = NULL;

   hpFontDirList = hpFDir = hpFontDirs[ithMFD];
   hpDirIndex = hpDirIndexHead + numFontsInTable;
   RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR) gszRegFontsPath, (HKEY FAR *) &hKeyHPFR);

   if (hpFDir)
   {
      while (wNumFontRec--)
      {
         hpDirIndex->wDirIndex = (BYTE) ithMFD;
         hpDirIndex->wDirRecIndex = hpFDir->index;
         hpDirIndex->statusFlag = 0; //init to 0

         /* determine status flag*/

         /* Determine outline types availability*/
         hpDirIndex->statusFlag |= hpFDir->bOutlnAvail;

         /* Is this a true type font?*/
        if (hpFDir->dwMetricVersion == (DWORD) TrueType) //TrueTypeFont
               hpDirIndex->statusFlag |= (BYTE) TT_FONT;
        else
               hpDirIndex->statusFlag |= (BYTE) PS_FONT;

         /* set font D/L'ed status*/
         if ((tmpResidentFont = InResidentFontList(hpFDir->szFontName,
                                       wNumResidentFonts,
                                       lpResidentFonts)) != NULL)
         {
            //if TrueType font and not DL loaded then ignore.
            //GDI will handle it.
            if ((hpDirIndex->statusFlag & MASK_PS_TT) == TT_FONT)
            {
               //determine what kind of TrueType Font.
               if (IsGlyIndexCapable(tmpResidentFont))
               {
                  hpDirIndex->statusFlag |= (BYTE) FONT_ON_DEVICE;
                  hpDirIndex->statusFlag |= (BYTE) GI_CC;
               }
              //if does not have XUID,therefore not T42
              // so it is an Ares PS of a TT equivalent,ie Arial
              // there will be a separate entry for this font as type PS.
              // no longer mark a TT font at CC_ONLY
              // else
              //    hpDirIndex->statusFlag |= (BYTE) CC_ONLY;
            }
            else
            {  //PostScript Fonts

               /*Skip CJK PS fonts in the PPD with different charsets from the one of the current system */
               /*  to suppress the display of these fonts since their font names don't show properly */
               if (_fstrstr(tmpResidentFont->lpValue, cszROM))
               { //PPD base fonts
                  LANGID LangID = GetSystemDefaultLangID();
                  BYTE   charset = hpFDir->defTextMetric.tmCharSet;

                  if ((charset==SHIFTJIS_CHARSET    && LangID!=LANGUAGE_J ) ||
                      (charset==HANGEUL_CHARSET     && LangID!=LANGUAGE_K ) ||
                      (charset==JOHAB_CHARSET       && LangID!=LANGUAGE_K ) ||
                      (charset==GB2312_CHARSET      && LangID!=LANGUAGE_CS) ||
                      (charset==CHINESEBIG5_CHARSET && LangID!=LANGUAGE_CT))
                  {
                     hpFDir++;
                     continue;
                  }
               }
               else
               { // Downloaded font.  This one came from WIN.INI
                 // We only care to match WIN.INI downloaded font with
                 // Registry fonts. NOT ADFONTS_MFM or OEM_MFM fonts.
                 if (hpFDir->pfmSource != (BYTE) PFM_FROM_REGISTRY)
                 {
                     hpFDir++;
                     continue;
                 }
               }

               if (MatchVersion(tmpResidentFont, hpFDir->dwMetricVersion))
                  hpDirIndex->statusFlag |= (BYTE) FONT_ON_DEVICE;
               else if (UseThisMetricFile(hpFontDirs[ithMFD], wNumFontRec, tmpResidentFont, hpFDir->dwMetricVersion))
                  hpDirIndex->statusFlag |= (BYTE) FONT_ON_DEVICE;
            }
         }

         /*Skip if FE DBCS font and not DownLoaded. .*/
         if (((hpDirIndex->statusFlag & MASK_PS_TT) == PS_FONT) &&
              IsDBCSCharSet(hpFDir->defTextMetric.tmCharSet) &&
             ((hpDirIndex->statusFlag & MASK_FONT_DL) != FONT_ON_DEVICE))
           {
               hpFDir++;
               continue;
           }


         /*Skip if TT font and not DownLoaded.  Let the Engine handle it.*/
         if (((hpDirIndex->statusFlag & MASK_PS_TT) == TT_FONT) &&
             ((hpDirIndex->statusFlag & MASK_FONT_DL) != FONT_ON_DEVICE))
           {
               hpFDir++;
               continue;
           }

         /*Skip if PS font, not DownLoaded and no PFB.*/
         if (((hpDirIndex->statusFlag & MASK_PS_TT) == PS_FONT) &&
             ((hpDirIndex->statusFlag & MASK_FONT_DL) != FONT_ON_DEVICE) &&
             !hpFDir->dwOutlineSize)
           {
               hpFDir++;
               continue;
           }


         /* This could also be a multi-master instance or a faux font.*/
         /* Therefore, should also check whether the parent has been D/L'ed */
         if (hpFDir->index != hpFDir->wMMBIndex)
         {
            hpTempFDir = hpFontDirs[ithMFD] + hpFDir->wMMBIndex;
            if ((tmpResidentFont = InResidentFontList(hpTempFDir->szFontName,
                                          wNumResidentFonts,
                                          lpResidentFonts)) != NULL)
            {
               if (MatchVersion(tmpResidentFont, hpTempFDir->dwMetricVersion))
                  hpDirIndex->statusFlag |= (BYTE) FONT_ON_DEVICE;
               else if (UseThisMetricFile(hpFontDirs[ithMFD], wNumFontRec, tmpResidentFont, hpTempFDir->dwMetricVersion))
                  hpDirIndex->statusFlag |= (BYTE) FONT_ON_DEVICE;
            }
         }

         /* set EnumStatus to Visible*/
         SetFontVisibility(hKeyHPFR, hKeyTTFR, hpFontDirList, hpFDir,
                           nFontsInDirList, &(hpDirIndex->statusFlag));

         hpDirIndex++;
         wFontCount++;
         hpFDir++;
      }
   }

   RegCloseKey(hKeyHPFR);
   RegCloseKey(hKeyTTFR);

   return(wFontCount);
}
/********************************************************
**
** Function:   SetFontVisibility
**
********************************************************/
VOID NEAR PASCAL SetFontVisibility(HKEY hKeyHPFR, HKEY hKeyTTFR,
      HPFONTDIRECTORY hpFontDirList, HPFONTDIRECTORY hpCurFont,
      WORD nFontsInDirList, BYTE *statusFlag)
{
   /* Look up Font in HPFR or TT */
   /* parse value for Z, z */
   /* if Z, then ENUM_RLZE_NOT_VISIBLE*/
   /* if z, then RLZE_VISIBLE */
   /* if no Z or z , then ENUM_RLZE_VISIBLE*/
   char szValue[SM_BUF];
   char szKey[80];
   DWORD dwCBSize = SM_BUF;
   DWORD dwType;
   WORD wLength =0;
   HPFONTDIRECTORY hpMatchDir;

   lstrcpy((LPSTR)szKey, hpCurFont->szFontName);

   switch (*statusFlag & MASK_PS_TT)
   {
      case PS_FONT:
      // if postscript font and it has a TrueType equivalent then supress
      // enumeration.  Except for Symbol.  We still want to enumerate this one.
      if (lstrcmpi("Symbol", hpCurFont->szFaceName) !=0 )
      {
         if (hpMatchDir = (HPFONTDIRECTORY) SearchFontDir(hpFontDirList, (LPSTR)hpCurFont->szFontName,
                                    nFontsInDirList, TRUE, FONT_NOHINT,
                                    FALSE, 0))
         {
            while (hpMatchDir &&
                  lstrcmpi(hpMatchDir->szFontName, hpCurFont->szFontName) == 0)
            {
               //a potential match is found.
               if (!hpMatchDir->dwMetricSize && // a true type font
                   (hpMatchDir->defTextMetric.tmCharSet == hpCurFont->defTextMetric.tmCharSet) &&
                   lstrcmpi(hpMatchDir->szFaceName, hpCurFont->szFaceName) ==0 )
               { //can realize but not enumerate
                  *statusFlag |= (BYTE) RLZE_VISIBLE;
                  return;
               }//if

               if( hpMatchDir != hpFontDirList+(nFontsInDirList-1) )
                  hpMatchDir++; //examine next record
               else
                  hpMatchDir = NULL; // no more record;
            }//while
         }//if
      }//if

      lstrcat((LPSTR)szKey, cszType1);
      if (ERROR_SUCCESS == RegQueryValueEx(hKeyHPFR, (LPSTR)szKey, 0,
                         (LPDWORD)&dwType, (LPSTR)szValue, (LPDWORD)&dwCBSize))
      {
         //if postscpipt font then check enum status
         if (FindStringGen((LPSTR)szValue, gszNoEnum, cVBar, &wLength) != NULL)
            *statusFlag |= (BYTE) RLZE_VISIBLE;
         else if (FindStringGen((LPSTR)szValue, gszNoEnumRealize, cVBar, &wLength) != NULL)
            *statusFlag |= (BYTE) ENUM_RLZE_NOT_VISIBLE;
         else
            *statusFlag |= (BYTE) ENUM_RLZE_VISIBLE;
      }
      else
         *statusFlag |= (BYTE) ENUM_RLZE_VISIBLE;
      return;

      case TT_FONT:
           *statusFlag |= (BYTE) ENUM_RLZE_VISIBLE;
        return;
   }

}
/********************************************************
**
** Function:   GetResidentFontsList
** Input:      lpszFriendlyName = Name of Printer
** Output:     lppResidentFont = list of font found in the
**                Resident Font section of the Registry.
**             *dwResFontSeriaNo = serial number of that section.
**             return value    = number of fonts found.
**
********************************************************/
WORD FAR PASCAL GetResidentFontsList(LPSTR lpszFriendlyName,
                                 LPRESIDENTFONT FAR *lppResidentFonts,
                                 DWORD FAR * dwResFontsSerialNo)
{
   LPSTR szPrnInstKey = NULL, szTempBuffer = NULL;

   if ((szPrnInstKey = GlobalAllocPtr(GDLLHND,  2* SM_BUF)) == NULL)
     return 0;
   szTempBuffer = szPrnInstKey+SM_BUF;

   /* Get Resident Font Serial number*/
   LoadString(ghDriverMod, IDS_REGSTR_RESIDENT_FONTS, szTempBuffer, SM_BUF);
   wsprintf((LPSTR)szPrnInstKey, szTempBuffer, lpszFriendlyName);
   *dwResFontsSerialNo = GetSerialNo(szPrnInstKey);

   if (! *dwResFontsSerialNo)
      *dwResFontsSerialNo = 1;

   if (szPrnInstKey)
    GlobalFreePtr(szPrnInstKey);

   return (GetRegResFonts(lppResidentFonts, lpszFriendlyName));
}

/********************************************************
**
** Function:   FreeResidentFontsList
**
********************************************************/
VOID FAR PASCAL FreeResidentFontsList(LPRESIDENTFONT lpResidentFonts, WORD wNumFonts)
{
   LPRESIDENTFONT lpTempResidentFont;

   if (!lpResidentFonts)
      return;

   lpTempResidentFont = lpResidentFonts;
   while (wNumFonts--)
   {
      if (lpTempResidentFont)
      {
         if (lpTempResidentFont->lpFontName)
            GlobalFreePtr(lpTempResidentFont->lpFontName);
      }
      lpTempResidentFont++;
   }

   GlobalFreePtr(lpResidentFonts);

}

/********************************************************
**
** Function:   InResidentFontList
** Input:      lpszFontName  - Name of font to search.
**             wNumFonts - number of font in the Residents Font List
**             lpResidentFont - Resident Font List
**
**  Output:    return Pointer to the Resident Font.
********************************************************/
LPRESIDENTFONT FAR PASCAL InResidentFontList(LPSTR lpszFontName,
                  WORD wNumFonts, LPRESIDENTFONT lpResidentFonts)
{
   int            l, u, m;
   LPRESIDENTFONT tmpResidentFont = NULL;
   int            value;
   WORD           found = 0;
   LPSTR          lpStr = NULL;
   DWORD          dwRegResMetric =0;

   if (wNumFonts == 0 || !lpResidentFonts || !lpszFontName)
      return 0;

     l = 0;
     u = wNumFonts -1;

     while ((l <=u) && !found)
     {
         m = (l +u)/2;  /* get index of middle record*/
         tmpResidentFont = (lpResidentFonts)+m; /* move to the half-way point*/
         value = lstrcmpi(lpszFontName, tmpResidentFont->lpFontName);

         if (value >0)
            l = m+1;    /* look in the upper half*/
         else if (value == 0)
         {
            l = m;
            found = 1;   /* found it*/
         }
         else
            u = m -1;    /* look in the lower half*/

     }

     if (found)
       return tmpResidentFont;
     else
       return NULL;
}

//call by UpdateSoftFont and when we change ports
void FAR PASCAL ResetResidentFontRegistry(LPSTR lpszFriendlyName)
{

   LPSTR szTempBuffer = NULL, szName = NULL, szPrnInstKey = NULL;
   DWORD dwRegIndex;
   DWORD cbName;
   DWORD dwType;
   HKEY  hkey, hkeyPrnInst;

   if ((szTempBuffer = GlobalAllocPtr(GDLLHND,  3*BUF_SIZE)) == NULL)
     return;

     szName = szTempBuffer + BUF_SIZE;
     szPrnInstKey = szTempBuffer +(2* BUF_SIZE);

   if (lpszFriendlyName)
   {    //delete Resident font for provided instance.

      //set path to specific printer instance.
      LoadString(ghDriverMod, IDS_REGSTR_PRN_PRINTER, szTempBuffer, BUF_SIZE);
      wsprintf((LPSTR)szPrnInstKey, szTempBuffer, lpszFriendlyName);

      if (RegOpenKey(HKEY_LOCAL_MACHINE, szPrnInstKey, (HKEY FAR *) &hkey) != ERROR_SUCCESS)
         return;

      if (RegQueryValueEx(hkey, (LPSTR)gszLOFRegKey, 0, (LPDWORD) &dwType,
         (LPSTR) szTempBuffer, (LPDWORD)&cbName) == ERROR_SUCCESS)
      {
         remove(szTempBuffer); //remove printer instance MFD
      }
      RegDeleteKey(hkey, "ResidentFonts");
   }
   else
   {
      //get to the all the printer instances
      LoadString(ghDriverMod, IDS_REGSTR_PRN_PRINTER_0, szTempBuffer, BUF_SIZE);
      if (RegOpenKey(HKEY_LOCAL_MACHINE, szTempBuffer, (HKEY FAR *) &hkey) != ERROR_SUCCESS)
         return;

      //enumerate all the printer instances
      dwRegIndex =0;
      while ((cbName = BUF_SIZE) &&
           RegEnumKey(hkey, dwRegIndex, (LPSTR)szName, (DWORD)cbName)
           == ERROR_SUCCESS && ++dwRegIndex)
      {
         //for each printer instance
         LoadString(ghDriverMod, IDS_REGSTR_PRN_PRINTER, szTempBuffer, BUF_SIZE);
         wsprintf((LPSTR)szPrnInstKey, szTempBuffer, szName);

         if (RegOpenKey(HKEY_LOCAL_MACHINE, szPrnInstKey, (HKEY FAR *) &hkeyPrnInst) == ERROR_SUCCESS)
         {
            RegDeleteKey(hkeyPrnInst, "ResidentFonts");
            if (RegQueryValueEx(hkeyPrnInst, (LPSTR)gszLOFRegKey, 0, (LPDWORD) &dwType,
               (LPSTR) szTempBuffer, (LPDWORD)&cbName) == ERROR_SUCCESS)
            {
               remove(szTempBuffer); //remove printer instance MFD
            }
            RegCloseKey(hkeyPrnInst);
         }//if key is available then delete
      }//while to enumerate all printer instances
   }//else for delete all Prn Inst's "ResidentFonts"

   if (hkey)
     RegCloseKey(hkey);

   //Free memory we used
   if (szTempBuffer)
     GlobalFreePtr(szTempBuffer);

}


void NEAR PASCAL ResetPortCheckSum(LPSTR szPort)
{
   LPSTR szTempBuffer = NULL;
   HKEY  hkey;

   if ((szTempBuffer = GlobalAllocPtr(GDLLHND,  BUF_SIZE)) == NULL)
     return;

   CompositeString(ghDriverMod, IDS_REGSTR_PATH_FONTSINFO, IDS_DRIVER_MANUFACTURER,
                  IDS_DRIVER_VERSION, szTempBuffer, BUF_SIZE);

   if (szPort)
   {    //reset specified port
      lstrcat (szTempBuffer, "\\");
      lstrcat (szTempBuffer, (LPSTR) gszPort);
      if (RegOpenKey(HKEY_LOCAL_MACHINE, szTempBuffer, (HKEY FAR *) &hkey) != ERROR_SUCCESS)
        return;
      RegDeleteValue(hkey, (LPSTR) szPort);
   }
   else
   {
      if (RegOpenKey(HKEY_LOCAL_MACHINE, szTempBuffer, (HKEY FAR *) &hkey) != ERROR_SUCCESS)
           return;
      RegDeleteKey(hkey, gszPort);
   }


   if (hkey)
     RegCloseKey(hkey);

   //Free memory we used
   if (szTempBuffer)
     GlobalFreePtr(szTempBuffer);
}

void FAR PASCAL ResetFontCache()
{
      HKEY hkey;
      LPSTR szTempBuf = NULL;

      if ((szTempBuf = GlobalAllocPtr(GDLLHND,  SM_BUF)) == NULL)
        return;

      /* delete all the cache for all printer instance*/
      DeleteFontCache("");

      /*delete all the ports*/
      ResetPortCheckSum(NULL);

      /* reset internal cache for mergining ATM.INI*/
      CompositeString(ghDriverMod, IDS_REGSTR_PATH_FONTSINFO, IDS_DRIVER_MANUFACTURER,
                  IDS_DRIVER_VERSION, szTempBuf, SM_BUF);
      if (RegOpenKey(HKEY_LOCAL_MACHINE, szTempBuf, (HKEY FAR *) &hkey) == ERROR_SUCCESS)
      {
         RegDeleteValue(hkey, (LPSTR) gszATMCkSum);
         RegCloseKey(hkey);
      }

      /*delete FontsDir.mfd*/
      if (GetFontsMFDFrReg(gszFontsDirRegKey, (LPSTR) szTempBuf, SM_BUF))
      {
         remove(szTempBuf);
      }

      //ATM.ini will be updated.
      bInitFontCache2 = FALSE;

      if (szTempBuf)
        GlobalFreePtr(szTempBuf);

}

void __loadds FAR PASCAL UpdateSoftFonts(LPSTR lpszFriendlyName)
{
   HKEY hkey;

   ResetFontCache();

   /*delete all Printer Instances' Resident Font Section*/
   ResetResidentFontRegistry(NULL);

   // WCC 10/5/98
   // delete all Postscript fonts section
   if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR)gszRegCurVersion, (HKEY FAR *) &hkey) == ERROR_SUCCESS)
   {
      RegDeleteKey(hkey, "PostScriptFonts");
      RegCloseKey(hkey);
   }

   InitNewFontDirCache();

}

// Function Exported to support third parties to update SoftFont Cache

// This is the MicroSoft PScript for win96's entry name:
BOOL __loadds FAR PASCAL UpdateSoftFontInfo()
{
    // Just call our UpdateSoftFonts() !!
    UpdateSoftFonts((LPSTR) NULL);
    return TRUE; // always return true.
}

int FAR PASCAL ResidentFontCompare(LPVOID elem1, LPVOID elem2)
{
    LPRESIDENTFONT lpDir1 = (LPRESIDENTFONT ) elem1;
    LPRESIDENTFONT lpDir2 = (LPRESIDENTFONT ) elem2;

    if (lpDir1 && lpDir2)
      return (lstrcmpi(lpDir1->lpFontName, lpDir2->lpFontName));
    else if(!lpDir1 && !lpDir2)
      return (0);  //equal
    else if (!lpDir2)
      return (1);  // str1 > str2
    else
      return (-1); // str1 < str2
}

int FAR PASCAL EnumFontsCompare(LPVOID elem1, LPVOID elem2)
{
    int rtnValue;
    LPFONTFILE lpDir1 = (LPFONTFILE) elem1;
    LPFONTFILE lpDir2 = (LPFONTFILE) elem2;

    if ((lpDir1) && (lpDir2))
    {
      if ((rtnValue = lstrcmpi(lpDir1->szName1, lpDir2->szName1)) == 0)
      {
         if ( lpDir1->lfCharSet > lpDir2->lfCharSet)
         rtnValue = 1;
         else if (lpDir1->lfCharSet < lpDir2->lfCharSet)
         rtnValue = -1;
         else
         rtnValue = 0;
      }
    }
    else
    {
      if (!(lpDir1))
        rtnValue = 1;
      else if (!(lpDir2))
        rtnValue =-1;
      else
        rtnValue = 0;
    }


    return (rtnValue);
}

WORD FAR PASCAL GetRomFonts(LPRESIDENTFONT FAR *lppResidentFonts, LPSTR lpszFriendlyName)
{
   LPSTR szPSFontName = NULL;
   LPSTR szVersion = NULL;
   LPSTR szDevName =NULL;
   LPSTR lpzDestDevice = NULL;
   DWORD dwType, dwNeeded;
   LPWPXBLOCKS    lpWPXblock;
   LPBYTE      lpStrHeap;
   LPBYTE      lpArrHeap;
   LPFONTLIST  lpFontList, lpFL;
   WORD     i = 0;
   WORD     wFonts = 0;
   LPSTRINGREF lpName;
   LPRESIDENTFONT lpRF;
   LPPRINTERINFO  lpPInfo;
   LPSTRINGREF lpVersion;
   DWORD l=0;
   WORD         wNumMFDFonts = 0;
   HPFONTDIRECTORY  hpFontDir, hpTempFontDir;

   if ((szPSFontName = GlobalAllocPtr(GDLLHND,  2*MAX_NAME_LEN+CCHDEVICENAME)) == NULL)
     return(0);
   szVersion = szPSFontName + MAX_NAME_LEN;
   szDevName = szPSFontName + 2*MAX_NAME_LEN;

    hpFontDir = GetHostFontCache(&wNumMFDFonts);

    if (!hpFontDir || !wNumMFDFonts)
      goto cleanup;

    // Get printer model name
    lpzDestDevice = (LPSTR) szDevName;
    lpzDestDevice[0] = '\0';
    if (DrvGetPrinterData(lpszFriendlyName, (LPSTR)INT_PD_PRINTER_MODEL, &dwType, lpzDestDevice,
                          CCHDEVICENAME, &dwNeeded) != ERROR_SUCCESS)
       goto cleanup;

    if (! (lpWPXblock = GetPrinter(lpzDestDevice)))
      goto cleanup;

    lpStrHeap = (LPBYTE) lpWPXblock->WPXstrings;
    lpArrHeap = (LPBYTE) lpWPXblock->WPXarrays;
    lpPInfo = (LPPRINTERINFO) lpWPXblock->WPXprinterInfo;
    lpFontList = (LPFONTLIST) ARRREF_TO_PTR(lpArrHeap, lpPInfo->FontList);
    i  = lpPInfo->FontList.w.length;

    if (!(*lppResidentFonts = (LPRESIDENTFONT)
      GlobalAllocPtr(GDLLHND, ((DWORD)sizeof(RESIDENTFONT) * (DWORD)i))))
    {
      wFonts = 0;
      goto cleanup;
    }

    lpFL = lpFontList;
    lpRF = *lppResidentFonts;
    wFonts = 0;
    while( i--)
    {
         //get PostScript name
         lpName = (LPSTRINGREF) &lpFL->fontname;
         lstrcpy (szPSFontName, STRREF_TO_PTR(lpStrHeap,(*lpName)));
         if (hpTempFontDir = (HPFONTDIRECTORY) SearchFontDir(hpFontDir, (LPSTR) szPSFontName, wNumMFDFonts,
                                TRUE, FONT_NOHINT, FALSE, 0))
         {
            lpVersion = (LPSTRINGREF) &lpFL->version;
            lstrcpy (szVersion, STRREF_TO_PTR(lpStrHeap,(*lpVersion)));

            //do one allocate for both psname and version
            l = (DWORD)lstrlen(hpTempFontDir->szFontName)+1;
            if ((lpRF->lpFontName = (LPSTR)
               GlobalAllocPtr(GDLLHND, (DWORD) l+ lstrlen(szVersion) +1 )) == NULL)
               break;
            lpRF->lpValue = lpRF->lpFontName+l;

            //copy the PSname and the version info.
            lstrcpy(lpRF->lpFontName, hpTempFontDir->szFontName);
            lstrcpy(lpRF->lpValue,szVersion);

            wFonts++;
            lpRF++;
       }

       lpFL++;
     }

   // sort the list here.

    HugeQsort((HPVOID) *lppResidentFonts, 0, wFonts -1 ,
           sizeof(RESIDENTFONT), ResidentFontCompare);


cleanup:
   if (szPSFontName)
    GlobalFreePtr(szPSFontName);

   return (wFonts);
}

WORD FAR PASCAL GetRegResFonts(LPRESIDENTFONT FAR *lppResidentFonts, LPSTR lpszFriendlyName)
{
   HKEY hkey = NULL;
   DWORD cbName, cbValue;
   LPSTR lpName = NULL, lpValue = NULL, lpszPrnInstKey = NULL;
   DWORD dwType, dwRegIndex = 0;
   WORD wFonts=0;
   LPRESIDENTFONT lpRF;
   DWORD dwNewNumFonts = 0;
   DWORD l=0;

    // Allocate memory to retrieve font name and value string and registry pat
    if ((lpName = (LPSTR)GlobalAllocPtr(GDLLHND, 3*BUF_SIZE)) == NULL)
       return wFonts;
    lpValue = lpName + BUF_SIZE;
    lpszPrnInstKey = lpValue +BUF_SIZE;

    //use lpValue as temp.
   LoadString(ghDriverMod, IDS_REGSTR_RESIDENT_FONTS, lpValue, BUF_SIZE);
   wsprintf((LPSTR)lpszPrnInstKey, lpValue, lpszFriendlyName);


   //Open Registry
   if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR)lpszPrnInstKey, (HKEY FAR *) &hkey)
       == ERROR_SUCCESS)
   {
      // Enumerate all the values for this key, First Count Only.
      while ((cbName = cbValue = BUF_SIZE) &&
            RegEnumValue(hkey, dwRegIndex, lpName, (LPDWORD)&cbName,
                  NULL, (LPDWORD)&dwType, lpValue, (LPDWORD)&cbValue)
            == ERROR_SUCCESS && ++dwRegIndex )
      {
         // count only.
         ;
      }    //end while()- count # of fonts.

   //Allocate space
    if (!(*lppResidentFonts = (LPRESIDENTFONT)
      GlobalAllocPtr(GDLLHND, ((DWORD)sizeof(RESIDENTFONT) * (DWORD)dwRegIndex))))
       goto cleanup;

    dwNewNumFonts = dwRegIndex;
    dwRegIndex = 0;
    //cycle the list once more to add the stuff
    lpRF = *lppResidentFonts;
    while ((cbName = cbValue = BUF_SIZE) &&
            RegEnumValue(hkey, dwRegIndex, lpName, (LPDWORD)&cbName,
               NULL, (LPDWORD)&dwType, lpValue, (LPDWORD)&cbValue)
            == ERROR_SUCCESS  && ++dwRegIndex)
      {
         // We are not interested in anything that is not REG_SZ
         // The registry may be changed after we count it.
         // If it's more than we expected then just skip it.
         if (dwType != REG_SZ || dwRegIndex > dwNewNumFonts)
               continue;

         //allocate space
         l = (DWORD)lstrlen(lpName)+1;
         //do one allocation for 2 buffers
         if ((lpRF->lpFontName = (LPSTR)
               GlobalAllocPtr(GDLLHND, (DWORD) l+ lstrlen(lpValue) +1 )) == NULL)
            break;
         lpRF->lpValue = lpRF->lpFontName+l;

         lstrcpy(lpRF->lpFontName, lpName);
         lstrcpy(lpRF->lpValue, lpValue);

         wFonts++;
         lpRF++;
       }

    HugeQsort((HPVOID) *lppResidentFonts, 0, wFonts - 1 ,
           sizeof(RESIDENTFONT), ResidentFontCompare);

   }

cleanup:

   if (hkey)
     RegCloseKey(hkey);
   if(lpName)
      GlobalFreePtr(lpName); //lpValue and lpszPrnInstKey was allocated here.

   return wFonts;
}


VOID FAR PASCAL UpdateResidentFonts(LPSTR lpszFriendlyName, DWORD dwSerial)
{
   LPSTR szPrnInstKey = NULL;
   LPSTR szPrnInstResident = NULL;
   LPSTR szTempBuffer = NULL;
   DWORD dwCRC = 0;

   if ((szPrnInstKey = GlobalAllocPtr(GDLLHND,  3* SM_BUF)) == NULL)
     return;

   szTempBuffer = szPrnInstKey+SM_BUF;
   szPrnInstResident = szPrnInstKey+(2* SM_BUF);

   /*get crc for current WPX file*/
   LoadString(ghDriverMod, IDS_REGSTR_PRN_PRINTER, szTempBuffer, SM_BUF);
   wsprintf((LPSTR)szPrnInstKey, szTempBuffer, lpszFriendlyName);
   dwCRC = GetRegDWord(szPrnInstKey, gszFontsLastUpdate);

   if (NeedToUpdateResRegistry(lpszFriendlyName, &dwCRC, dwSerial))  //update only if Serial number does not exist
   {
      if (UpdatePrnInstResidentFonts(lpszFriendlyName))
      {
         //path to resident fonts
         LoadString(ghDriverMod, IDS_REGSTR_RESIDENT_FONTS, szTempBuffer, SM_BUF);
         wsprintf((LPSTR)szPrnInstResident, szTempBuffer, lpszFriendlyName);
         SetSerialNo((LPSTR)szPrnInstResident, dwSerial);   //update the serial number
      }

      SetRegDWord(szPrnInstKey, gszFontsLastUpdate, dwCRC);
   }

   //free memory used
   if (szPrnInstKey)
      GlobalFreePtr(szPrnInstKey);
}

/* This function Merge Resident Font (Fonts with .PFM only) from
Win.ini 's [Postscript,<PORT>] section to the
printer ResidentFonts section in the registry.
return True if new entries are added to the registry
*/
WORD NEAR PASCAL MergeIniResFonts(LPSTR lpszFriendlyName, LPSTR lpszIniFile)
{
    LPSTR     lpszBuffer=NULL, aptr;
    char FAR* lpch;
    WORD      i= 0;
    WORD      newNumFonts =0; // max 642K fonts - a Section is limited by 64K bytes in INI file.
    LPSTR     lpszValue=NULL;   // 2 * MAX_PATH; For value of entries in INI file
    LPSTR     lpFontNameKey=NULL; // BUF_SIZE>11+MAX_NAME_LEN=61. plus the length of " (Type 1)"
    LPSTR     lpFontValue=NULL;   // BUF_SIZE=1K >PATH Plus "FIL:PFM:" "FIL:PFB:"
    LPSTR     lpFontTemp = NULL;
    LPSTR     lpFontAppendValue = NULL;
    LPSTR     lpszSection = NULL;

    HKEY      hkey = NULL;
    BOOL      bRegUpdated = 0;
    DWORD dwType;
    DWORD dwCBSize = BUF_SIZE;
    DWORD    dwCheckSum = 0;
    WORD    length = 0;

    // Use one allocate for two bufers.
    if ((lpszValue = GlobalAllocPtr(GHND, 2*MAX_PATH + 5 * BUF_SIZE)) == NULL)
        goto mergeini_exit;
    lpFontNameKey = lpszValue +  2*MAX_PATH;  // lpszValue wants to be 2*MAX_PATH long
    lpFontValue = lpFontNameKey +  BUF_SIZE;
    lpFontTemp = lpFontNameKey + 2*BUF_SIZE;
    lpFontAppendValue = lpFontNameKey + 3*BUF_SIZE;
    lpszSection = lpFontNameKey + 4*BUF_SIZE;


    /* Allocate buffer - max size of section is 64K */
    lpszBuffer = (LPBYTE) GlobalAllocPtr(GDLLHND, LIMIT_64K);
    if (!lpszBuffer)
        goto mergeini_exit;

    if (!lpszFriendlyName)
        goto mergeini_exit;

    GetPortFromFriendlyName(lpszFriendlyName, (LPSTR)lpFontTemp, (DWORD) dwCBSize);

    LoadString(ghDriverMod, IDS_POSTSCRIPT, (LPSTR)lpszSection , BUF_SIZE);
    lstrcat((LPSTR) lpszSection, lpFontTemp);
    if (lpFontTemp[lstrlen(lpFontTemp) - 1] == ':')
        lpszSection[lstrlen(lpszSection) - 1] = '\0';

    /* Get all entries in szSection */
    if (GetPrivateProfileString((LPSTR) lpszSection, (LPSTR) NULL, (LPSTR) "",
                         lpszBuffer, (WORD) ((DWORD) LIMIT_64K - 1), lpszIniFile) != 0)
    {
       // Find out how many entries we got:
       aptr = lpszBuffer; // don't modify the Buffer - need it later.
       while (aptr && *aptr)
       {
          newNumFonts++;
          aptr += lstrlen(aptr)+1;
       }


      //if no Postscript Font section, we want to create a serial number too.
      //lpFontAppendvalue contain full path to resident font registry
      LoadString(ghDriverMod, IDS_REGSTR_RESIDENT_FONTS, lpFontTemp, BUF_SIZE);
      wsprintf((LPSTR)lpFontAppendValue, lpFontTemp, lpszFriendlyName);
      if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR)lpFontAppendValue, (HKEY FAR*)&hkey)
            != ERROR_SUCCESS)
      {
         bRegUpdated =1;
         RegCloseKey(hkey);
      }

      if (RegCreateKey(HKEY_LOCAL_MACHINE, (LPSTR)lpFontAppendValue, (HKEY FAR*)&hkey)
            != ERROR_SUCCESS)
        goto mergeini_exit;

      if (newNumFonts > 0)
       {
         /* For each entry, get the value */
         i=0;
         while ((i < newNumFonts) && lpszBuffer
               && (dwCBSize = BUF_SIZE))
         {
            GetPrivateProfileString((LPSTR) lpszSection, lpszBuffer,
                        (LPSTR) "", lpszValue, BUF_SIZE, lpszIniFile);
            if (lpszValue[0])
            {
               /* * Value is of the form <PFM FILE>[,<PFB FILE>].
                  * If comma is present, PFB File is also given.
               */
               if (lpch = lstrchr( lpszValue, ','))
               {
                  *lpch = '\0';
                  lpch++;
               }

               // Now, if lpszValue is the PFM Path!!
               if ((lpch==NULL) &&  //add PFM only stmts.
                   MakeFontKeyVal(lpszValue, (LPSTR)lpch, lpFontNameKey, lpFontValue, 0, 0))
               {
                  // add to Registry: if it does not exist
                  if (RegQueryValueEx(hkey, (LPSTR)lpFontNameKey, 0, (LPDWORD)&dwType, lpFontTemp, (LPDWORD) &dwCBSize) != ERROR_SUCCESS)
                  {
                     lstrcpy (lpFontTemp, cszDevice);
                     lstrcat (lpFontTemp, cszColon);
                     lstrcat (lpFontTemp, "VM");
                     if (RegSetValueEx(hkey, (LPSTR)lpFontNameKey, 0, REG_SZ, lpFontTemp,
                                 lstrlen(lpFontTemp)+1) == ERROR_SUCCESS)
                      bRegUpdated =1;
                  }
                  else if (*lpFontTemp)
                  {
                     //or Add "D:VM" if "D:" section not exist or only "D:ROM" exists.
                     LPSTR lpPtrDest = NULL;
                     LPSTR lpPtrSrc = NULL;

                     //see if there is a device string
                     lpPtrDest = FindString(lpFontTemp, cszDevice, &length);
                     if (!lpPtrDest)
                     {  // No "D:" section
                        length = lstrlen(lpFontTemp);
                        if (length && lpFontTemp[length] != cVBar)
                           lstrcat((LPSTR)lpFontTemp, (LPSTR)cszVBar);
                        lstrcat (lpFontTemp, cszDevice);
                        lstrcat (lpFontTemp, cszColon);
                        lstrcat (lpFontTemp, "VM");
                        if (RegSetValueEx(hkey, (LPSTR)lpFontNameKey, 0, REG_SZ, lpFontTemp,
                                 lstrlen(lpFontTemp)+1) == ERROR_SUCCESS)
                         bRegUpdated =1;
                     }
                     //advance to begining of device then try to find VM entry
                     else if (lpPtrDest++ && FindStringGen((LPSTR)lpPtrDest, "VM", cComma, &length) == NULL)
                     {  //"D:: exist, but "VM" is not in there

                        lstrcpy(lpFontValue, lpFontTemp);
                        lpPtrDest = FindString(lpFontTemp, cszDevice, &length);
                        lpPtrSrc = FindString(lpFontValue, cszDevice, &length);

                        //increment pass "D:"
                        lpPtrDest ++; //pointer to next device
                        lpPtrSrc ++; //pointer to next device

                        //insert VM string to destination
                        lstrcpy(lpPtrDest, "VM,");
                        lpPtrDest +=3; //pointer to next device

                        length = lstrlen(lpPtrSrc);
                        lstrcpyn (lpPtrDest, lpPtrSrc, length+1);

                        if (RegSetValueEx(hkey, (LPSTR)lpFontNameKey, 0, REG_SZ, lpFontTemp,
                                lstrlen(lpFontTemp)+1) == ERROR_SUCCESS)
                        bRegUpdated =1;
                      }
                  }//else
               }//if pfm only statments
            }  // end for "if (lpszValue[0])"

            i++; //process next font

            /* Next entry */
            lpszBuffer += lstrlen(lpszBuffer) + 1;

           } //end for outer while loop
        }  // end if(newNum>0)


     // Update the Registry's SerialNumber so others (Pscript4.1) knows the changes
     if (bRegUpdated)
      {
           DWORD     dwType, dwSerial=0, cbSize = sizeof(DWORD);
           RegQueryValueEx(hkey, (LPSTR)gszSerial, 0, (LPDWORD)&dwType,
                    (LPSTR)&dwSerial, (LPDWORD)&cbSize);
           dwSerial++;  // Increase by 1 (or start from 1)
           //Set the new value:
           RegSetValueEx(hkey, (LPSTR)gszSerial, 0, REG_DWORD,
               (LPSTR)&dwSerial, sizeof(DWORD));
        }
    } //end Of GetProfileString



mergeini_exit:
    if (hkey)
        RegCloseKey(hkey);
    if (lpszValue)
        GlobalFreePtr(lpszValue); // lpszFontNameKey and lpszFontVal were allocated as part of lpszValue;
    if (lpszBuffer)
        GlobalFreePtr(lpszBuffer);
    return(bRegUpdated);
}

WORD NEAR PASCAL UpdatePrnInstResidentFonts(LPSTR lpFriendlyName)
{
   LPRESIDENTFONT lpROMFonts= NULL, lpRegResFonts = NULL;
   WORD wROMFonts = 0, wRegResFonts =0;
   WORD modified = 0;

   modified = MergeIniResFonts(lpFriendlyName, "Win.INI");
   wROMFonts = GetRomFonts(&lpROMFonts, lpFriendlyName);
   wRegResFonts = GetRegResFonts(&lpRegResFonts, lpFriendlyName);

   modified |= RmObsRomFontsFrReg(lpROMFonts, lpRegResFonts, wRegResFonts, wROMFonts, lpFriendlyName);
   modified |= AddResFontToReg(lpROMFonts, lpRegResFonts, wRegResFonts, wROMFonts, lpFriendlyName);

   FreeResidentFontsList(lpRegResFonts, wRegResFonts);
   FreeResidentFontsList(lpROMFonts, wROMFonts);

   return modified;

}

WORD NEAR PASCAL RmObsRomFontsFrReg(LPRESIDENTFONT lpROMFonts, LPRESIDENTFONT lpRegResFonts,
   WORD wRegResFonts, WORD wROMResFonts, LPSTR lpszFriendlyName)
{
   HKEY hkey = NULL;
   WORD modified = 0;
   WORD i;
   LPSTR szPrnInstKey = NULL;
   LPSTR szTempBuffer = NULL;

   if ((szPrnInstKey = GlobalAllocPtr(GDLLHND,  2* SM_BUF)) == NULL)
     return modified;
   szTempBuffer =  szPrnInstKey+SM_BUF;

   if (!wRegResFonts || !wROMResFonts)
     return modified;

   LoadString(ghDriverMod, IDS_REGSTR_RESIDENT_FONTS, szTempBuffer, SM_BUF);
   wsprintf((LPSTR)szPrnInstKey, szTempBuffer, lpszFriendlyName);

   //Open Registry
   if (RegOpenKey(HKEY_LOCAL_MACHINE, (LPSTR)szPrnInstKey, (HKEY FAR *) &hkey)
       == ERROR_SUCCESS)
   {
      for (i = 0; i < wRegResFonts; i++, lpRegResFonts++)
      {
         if (InResidentFontList(lpRegResFonts->lpFontName, wROMResFonts, lpROMFonts) == NULL)
         {
             modified = RemoveRomEntry(hkey, lpRegResFonts) || modified;
         }
      }
   }
   //close Registry
   if (szPrnInstKey)
    GlobalFreePtr(szPrnInstKey);

   if (hkey)
      RegCloseKey(hkey);

   return modified;
}


//if ROM is the only device then, remove the whole entry from registry.
//otherwise just strip off the ROM version and ROM key then write the
//modified value to the Registry.
//return 1 if modified the registry.  Return 0 if not.
WORD NEAR PASCAL RemoveRomEntry(HKEY hkey, LPRESIDENTFONT lpObsoleteFont)
{
    LPSTR lpPtr = NULL;
    WORD wLength = 0;
    LPSTR szValue = NULL;
    WORD modified = 0;

   if ((szValue = GlobalAllocPtr(GDLLHND,  BUF_SIZE)) == NULL)
     return modified;  //always return

    //strip ROM version number.
    RemoveValue(lpObsoleteFont->lpValue, cszROMVer, cVBar);

    //Get Device key string
    lpPtr = FindString(lpObsoleteFont->lpValue, cszDevice, &wLength);

    if (wLength < 2)  //it should have a colon plus at least 1 more char.
    {
      //malform device string or does not contain a rom section
      // ignore it
      goto exit;
    }
    else
    {
      //save Device Key string with out the key and colon.
      lstrcpyn((LPSTR)szValue, AnsiNext(lpPtr), wLength);

      //ROM key not in string. Nothing to edit
      if (FindStringGen((LPSTR)szValue, cszROM, cComma, &wLength) == NULL)
        goto exit;

      //remove rom key and trailing comma
      RemoveValue(szValue, cszROM, cComma);

      //The string could of been "D:VM,ROM"
      //and RemoveValue will have a trailing comma in the result.
      if ((wLength = lstrlen(szValue)) > 0
           && *(szValue+wLength-1) == cComma)
      {
         *(szValue+wLength-1) = '\0';  //remove trailing comma.
      }

    }

    // remove the key if ROM is the only string
    if (*szValue == NULL)
        RegDeleteValue(hkey, (LPSTR)lpObsoleteFont->lpFontName);
    else
    {
      //remove the old device string.
      RemoveValue((LPSTR)lpObsoleteFont->lpValue, cszDevice, cVBar);

      //add the new device string
      if ((wLength = lstrlen(lpObsoleteFont->lpValue)) > 0
           && *(lpObsoleteFont->lpValue+wLength-1) != cVBar)
      {
         lstrcat(lpObsoleteFont->lpValue, cszVBar);
      }
      lstrcat(lpObsoleteFont->lpValue, cszDevice);
      lstrcat(lpObsoleteFont->lpValue, cszColon);
      lstrcat(lpObsoleteFont->lpValue, szValue);

      //write it to the registry
      RegSetValueEx(hkey, (LPSTR)lpObsoleteFont->lpFontName, 0, REG_SZ,
               (LPSTR)lpObsoleteFont->lpValue, lstrlen((LPSTR)lpObsoleteFont->lpValue) +1);

      modified = 1;
    }
exit:
   if (szValue)
    GlobalFreePtr(szValue);
   return modified;
}

WORD NEAR PASCAL AddResFontToReg(LPRESIDENTFONT lpROMFonts, LPRESIDENTFONT lpRegResFonts,
   WORD wRegResFonts, WORD wROMResFonts, LPSTR lpszFriendlyName)
{
   WORD i;
   WORD modified = 0;
   LPSTR szPrnInstKey = NULL;
   LPSTR szTempBuffer = NULL;
   HKEY  hkey = NULL;
   LPRESIDENTFONT lpTempRegFont = NULL;

   if (!wROMResFonts)
     return  modified; //nothing to add

   if ((szPrnInstKey = GlobalAllocPtr(GDLLHND,  2* SM_BUF)) == NULL)
     return modified;

   szTempBuffer =  szPrnInstKey+SM_BUF;

   LoadString(ghDriverMod, IDS_REGSTR_RESIDENT_FONTS, szTempBuffer, SM_BUF);
   wsprintf((LPSTR)szPrnInstKey, szTempBuffer, lpszFriendlyName);

   //Open Registry
   if (RegCreateKey(HKEY_LOCAL_MACHINE, (LPSTR)szPrnInstKey, (HKEY FAR *) &hkey)
       == ERROR_SUCCESS)
   {
      for (i = 0; i < wROMResFonts; i++, lpROMFonts++)
      {
         if ((lpTempRegFont = InResidentFontList(lpROMFonts->lpFontName, wRegResFonts, lpRegResFonts))
                     != NULL)
               modified |= AddRomEntry(hkey, lpROMFonts, lpTempRegFont);
         else
               modified |= AddRomEntry(hkey, lpROMFonts, NULL);
      }
   }
   //close Registry
   if (hkey)
      RegCloseKey(hkey);

   if (szPrnInstKey)
    GlobalFreePtr(szPrnInstKey);

   return modified;
}




WORD NEAR PASCAL AddRomEntry(HKEY hkey, LPRESIDENTFONT lpAddFont, LPRESIDENTFONT lpExistingFont)
{
   LPSTR szValue = NULL;
   LPSTR lpPtr1 = NULL, lpPtr2 = NULL;
   LPSTR lpDeviceString = NULL;
   WORD wLength;
   char szROMVersion[40];  //rom version string
   WORD i = 0;

  if ((szValue = GlobalAllocPtr(GDLLHND,  SM_BUF)) == NULL)
        return 0;

   if (lpExistingFont != NULL)
   {
     //Does the device entry exist? ie. "D:..."
     lpDeviceString = FindString(lpExistingFont->lpValue, cszDevice, &wLength);

      lstrcpy(szROMVersion, cszROMVer);
      lstrcat(szROMVersion, cszColon);
      lstrcat(szROMVersion, lpAddFont->lpValue);


     if (lpDeviceString)
     {

        lpDeviceString = AnsiNext(lpDeviceString);  //Don't include the colon
        lstrcpyn(szValue, lpDeviceString, wLength);
         //Is ROM entry in it?
        lpPtr1 = FindStringGen((LPSTR)szValue, cszROM, cComma, &wLength);
     }

     //see if correct version is in it.
     lpPtr2 = FindString(lpExistingFont->lpValue, cszROMVer, &wLength);
     if (lpPtr2)
     {
        lpPtr2 = AnsiNext(lpPtr2);  //Don't include the colon
        lstrcpyn(szValue,lpPtr2, wLength);
         //Is version correct in it?
        if (lstrcmpi((LPSTR)szValue, lpAddFont->lpValue) == 0)
          lpPtr2 = szValue; //found exact match
        else
          lpPtr2 = NULL;
     }

     if (lpPtr1)  //ROM string existed
     {
        if (!lpPtr2) //version did not match
        {
           //strip version from Existing string.
           RemoveValue(lpExistingFont->lpValue, cszROMVer, cVBar);
           //append new string
          lstrcpy((LPSTR)szValue, (LPSTR)lpExistingFont->lpValue);
          wLength = lstrlen(szValue);
          if (wLength && szValue[wLength] != cVBar)
            lstrcat((LPSTR)szValue, (LPSTR)cszVBar);
          lstrcat((LPSTR)szValue, (LPSTR)szROMVersion);
        }
        else       //version matched.
        {

         if (szValue)
            GlobalFreePtr(szValue);
          return 0;  //rom entry existed, version matched. Nothing more todo.
        }
     } // ROM string exist.
     else   // no ROM string, therefor no ROMversion either.
     {
         //insert ROM string into exisiting DEVICE section.
         if ((lpPtr1 = FindString(lpExistingFont->lpValue, cszDevice, &wLength)) != NULL)
         {
           lpPtr1 = AnsiNext(lpPtr1); //walk pass colon.
           lpPtr2 = lpExistingFont->lpValue; //existing entry
           i = 0;
           while (lpPtr1 !=  lpPtr2)  //copy everything upto the point of insertion
           {
             szValue[i++] = *lpPtr2;
             lpPtr2++;
           }

           lstrcat((LPSTR)szValue, (LPSTR) cszROM);  //add rom string
           i += lstrlen(cszROM);

           if (lpPtr2)
           {
              if (*lpPtr2 != cVBar)  //we are not at the end of this section
              {
                 lstrcat((LPSTR)szValue, (LPSTR) cszComma);  //add rom string
                 i++;
              }
              //copy remember of string
              while (*lpPtr2 != '\0')
              {
                 szValue[i++] = *lpPtr2;
                 lpPtr2++;
              }
           }

           szValue[i] = '\0';  //append terminator
         }
         else
         {  //no device section.
           lstrcpy((LPSTR)szValue, (LPSTR)lpExistingFont->lpValue);
           wLength = lstrlen(szValue);
           if (wLength && szValue[wLength] != cVBar)
               lstrcat((LPSTR)szValue, (LPSTR)cszVBar);
           lstrcat((LPSTR)szValue, (LPSTR) cszDevice);
           lstrcat((LPSTR)szValue, (LPSTR) cszColon);
           lstrcat((LPSTR)szValue, (LPSTR) cszROM);
         }
         //append version string
        wLength = lstrlen(szValue);
        if (wLength && szValue[wLength] != cVBar)
            lstrcat((LPSTR)szValue, (LPSTR)cszVBar);
        lstrcat((LPSTR)szValue, (LPSTR)szROMVersion);
     }
   }
   else  //no exisiting entry in registry
   {
      //add version and Rom key to string
      MakeResFontValue(lpAddFont->lpValue, szValue);
   }

// add/replaced entry in registry.
   RegSetValueEx(hkey, (LPSTR)lpAddFont->lpFontName, 0, REG_SZ,
         (LPSTR)szValue, lstrlen((LPSTR)szValue) +1);

   if (szValue)
            GlobalFreePtr(szValue);
   return (1);
}

void NEAR PASCAL MakeResFontValue(LPSTR lpVersion, LPSTR lpValue)
{

      lstrcpy(lpValue, cszDevice);
      lstrcat(lpValue, cszColon);
      lstrcat(lpValue, cszROM);

   //add version to String
   if (lpVersion != NULL)
   {
      lstrcat(lpValue, cszVBar);
      lstrcat(lpValue, cszROMVer);
      lstrcat(lpValue, cszColon);
      lstrcat(lpValue, lpVersion);
   }
}

//if lpString ="V:xxxxx|v:xxxxx|D:xxxx", lpKey="V", lpDelimiter='|'
//the remove whole string in place up to | or eoln.
//The result is "v:xxxxxx|D:xxxxx"
void NEAR PASCAL RemoveValue(LPSTR lpString, LPSTR lpKey, char lpDelimiter)
{
  LPSTR lpRemove = NULL;
  LPSTR lpAfterKey = NULL;
  WORD  wLength = 0;
  WORD  i = 0;
  BOOL  removedDelimiter = FALSE;

  if ((lpRemove = FindStringGen(lpString, lpKey, lpDelimiter, &wLength)) !=NULL)
  {
     //if Key is not 1st position & a delimiter is before it, remove delimiter
     if (*lpString != *lpKey)
     {
        if (*(lpRemove-1) == lpDelimiter) //a delimiter before the string
        {
          lpRemove--;
          removedDelimiter = TRUE;
          wLength++;
        }
     }

     lpAfterKey = lpRemove + wLength;
     if ( *lpAfterKey != '\0'  && !removedDelimiter)
         lpAfterKey++; //go pass the delimiter.

     while (*(lpAfterKey+i) != '\0')
     {
        *(lpRemove+i) = *(lpAfterKey+i); //copy everything after the obs string.
        i++;
     }
     *(lpRemove+i) = *(lpAfterKey+i); //eoln character.
  }

}

/********************************************************
** Function:   GetMFMPath
**
** Get full path of ADFonts.MFM ID
** Input: buffer of BUF_SIZE and input MFMFileName
** Output: fill buffer with path.  Return 1 for success.
*********************************************************/
WORD FAR PASCAL GetMFMPath(LPSTR szPath, WORD bufSize, LPSTR szMFMFileName)
{

   //Get Full MFM path
   *szPath = '\0';
   GetDriverDirectory(szPath, bufSize);
   if (*szPath)
      {
         if (szPath[lstrlen(szPath) -1] != '\\')
            lstrcat((LPSTR)szPath, (LPSTR)"\\");
         lstrcat((LPSTR)szPath, (LPSTR)szMFMFileName);
      }
   else
      lstrcpy((LPSTR)szPath, (LPSTR)szMFMFileName);

   return 1;
}

DWORD NEAR PASCAL GetTimeStampID (LPSTR szPath)
{
  OFSTRUCT  ofFileStruct;
   HFILE hfile;
   LPWORD lpCRC_16_tab = (LPWORD) crc_16_tab;
   WORD tempCRC = 0;

   /*get time stamp of the MFM file*/
   if ((hfile = OpenFile((LPSTR) szPath,
                                 (LPOFSTRUCT) &ofFileStruct,
                                 OF_READ)) == HFILE_ERROR)

    {
      return 0;  //can't read MFM file
    }
    else
    {
#ifdef _M_I86MM                                        /* medium model      */
   _dos_getftime(hfile,
        (unsigned *) OFFSETOF((unsigned FAR*) &DateTime.date),
        (unsigned *) OFFSETOF((unsigned FAR*) &DateTime.time));
#else
   _dos_getftime(hfile, &DateTime.date, &DateTime.time);
#endif
   _lclose(hfile);
   }

   /* calculate CRC of base on timestamp of the file*/
   tempCRC = 0xffff;  //init
   tempCRC = CalcCRC((LPBYTE) &(DateTime.date), sizeof(unsigned int),
                          tempCRC, lpCRC_16_tab);
   tempCRC= CalcCRC((LPBYTE) &(DateTime.time), sizeof(unsigned int),
                          tempCRC, lpCRC_16_tab);

  return (DWORD) tempCRC;
}

/********************************************************
** Function:   GetMFMTimeStampID
**
** Get ADFonts.MFM ID base on time stamp.  Take timestamp and calculate
** crc value.
** Input:
** Output: CRC base on MFM time stamp
*********************************************************/
DWORD FAR PASCAL GetMFMTimeStampID ()
{
   char  szPath[SM_BUF];
   char  szMFMFileName[MFM_NAME_LENGTH];

   //Get Full MFM path
   LoadString(ghDriverMod, IDS_MFM_FILE, szMFMFileName, MFM_NAME_LENGTH);

   //Get Full MFM path
   GetMFMPath((LPSTR)szPath, SM_BUF, (LPSTR)szMFMFileName);

   return ( GetTimeStampID((LPSTR)szPath) );
}

BOOL FAR PASCAL NeedToUpdateResRegistry(LPSTR lpszFriendlyName, LPDWORD lpdwCRCVal, DWORD dwSerial)
{
   BOOL bUpdate = FALSE;
   DWORD dwType = 0, dwNeeded;
   LPWPXBLOCKS lpWPXblock;
   LPPRINTERINFO lpPInfo;
   LPSTR lpzDestDevice = NULL, szTempBuffer = NULL, szPort = NULL;
   DWORD dwTempCRC = 0, dwPortCkSum =0;
   DWORD dwCBSize = SM_BUF;

   //use one alloc for all mem us in this function
   if ((lpzDestDevice = GlobalAllocPtr(GDLLHND,  CCHDEVICENAME+2*SM_BUF)) == NULL)
     goto exit;

   szTempBuffer = lpzDestDevice+CCHDEVICENAME;
   szPort = szTempBuffer+SM_BUF;

    // check if WPX file had changed
    // Get printer model name
    lpzDestDevice[0] = '\0';
    if (DrvGetPrinterData(lpszFriendlyName, (LPSTR)INT_PD_PRINTER_MODEL, &dwType, lpzDestDevice,
                          CCHDEVICENAME, &dwNeeded) != ERROR_SUCCESS)
      goto exit;

    if (! (lpWPXblock = GetPrinter(lpzDestDevice)))
      goto exit;

   /* calculate CRC of base on timestamp of the file*/
   lpPInfo = (LPPRINTERINFO) lpWPXblock->WPXprinterInfo;
   //dwRandom is set when WPX is created. If this value changed that mean
   //WPX was changed.
   dwTempCRC = lpPInfo->dwRandom;


   /* port check sum*/
   GetPortFromFriendlyName(lpszFriendlyName, (LPSTR)szPort, dwCBSize);
   CompositeString(ghDriverMod, IDS_REGSTR_PATH_FONTSINFO, IDS_DRIVER_MANUFACTURER,
         IDS_DRIVER_VERSION, szTempBuffer, BUF_SIZE);
   lstrcat (szTempBuffer, "\\");
   lstrcat (szTempBuffer, (LPSTR) gszPort);
   dwPortCkSum = GetRegDWord(szTempBuffer, szPort);

   //new Crc is WPX+ port ck SUM
   dwTempCRC += dwPortCkSum;

   /* compare it with the values in the registry*/
   /* WPX + serial # from resident font registry*/
   if (dwTempCRC  != *lpdwCRCVal)
   {
      bUpdate = TRUE; //entry does not match
      *lpdwCRCVal = dwTempCRC;
      goto exit;
   }

   /* If the resident font section does not exist then update*/
   if (dwSerial == 0)
      bUpdate = TRUE;

exit:
   //free mem use
   if (lpzDestDevice)
      GlobalFreePtr(lpzDestDevice);
   return(bUpdate);
}

BOOL FAR PASCAL NeedToMergeIniFiles(LPSTR lpszFriendlyName)
{
   LPFONTCACHE lpCache = chFonts.lpCacheStart;
      while (lpCache)
   {
      if ((lstrcmpi((LPSTR) lpCache->szFriendlyName, lpszFriendlyName) == 0)
         && (lpCache->bDelete == FALSE))
      {
               return FALSE; //found it. No need to update
      }

     lpCache = lpCache->lpNextCache;
   }

   return TRUE; //didn't find it.  So update.
}


BOOL NEAR PASCAL MatchVersion(LPRESIDENTFONT tempResidentFont, DWORD dwMetricVersion )
{
   LPSTR lpPtr = NULL;
   char  szMetric[20];
   WORD  wLength;

   // don't worry about version checking yet.
   return TRUE;

   //ROM version
   if ((lpPtr = FindString(tempResidentFont->lpValue, cszROMVer, &wLength)) != NULL)
   {
      lstrcpyn((LPSTR) szMetric, ++lpPtr, wLength);  //copy pass the colon.
      if ((double)dwMetricVersion == (double) atof(szMetric))
      {
         return TRUE;  //Matched
      }
   }
   //Downloaded version
  if ((lpPtr = FindString(tempResidentFont->lpValue, cszDLVer, &wLength)) != NULL)
   {
      lstrcpyn((LPSTR) szMetric, ++lpPtr, wLength);  //copy pass the colon.
      if ((double)dwMetricVersion == (double) atof(szMetric))
      {
         return TRUE;  //Matched
      }
   }

      //return FALSE;
}

BOOL NEAR PASCAL UseThisMetricFile(LPFONTDIRECTORY lpFontDir,
                                  WORD wNumFonts,
                                  LPRESIDENTFONT tmpResidentFont,
                                  DWORD dwMetricVersion)
{
   LPFONTDIRECTORY lpFDir = NULL;
   BOOL found = FALSE;
   WORD i;

   //if no other SFNT that match and this a PFM
   //then assume correct version.
   //otherwise skip this one.
   i = wNumFonts;
   if ((lpFDir = SearchFontDir(lpFontDir, tmpResidentFont->lpFontName, wNumFonts,
                               TRUE, FONT_NOHINT,
                               FALSE, 0)) !=NULL)
   {
      while (!(lstrcmpi((LPSTR)lpFDir->szFontName, tmpResidentFont->lpFontName)))
      {
         if (MatchVersion(tmpResidentFont, lpFDir->dwMetricVersion))
         {
             found = TRUE;
             break;
         }
         if (lpFDir->index < wNumFonts-1)
            lpFDir++;
         else
            break;
      }
   }
   // if can't find a matching SFNT and this is a PFM then use it.
   if (!found && dwMetricVersion == 256)
      found = TRUE;

   return found;
}

VOID FAR PASCAL SynIniFilesToRegistry(LPSTR lpszPort, BOOL bWinIniOnly)
{
    DWORD     dwWinVersion;
    BOOL      bDel = FALSE;
    HCURSOR   hcurOld=0, hcurWait;
    DWORD     dwCheckSum = 0;
    DWORD     dwNewCheckSum = 0;
    LPSTR     szSection = NULL, szTempBuffer = NULL;

    hcurWait = LoadCursor(NULL, IDC_WAIT);
    hcurOld = SetCursor(hcurWait);


   if ((szSection = GlobalAllocPtr(GDLLHND,  SM_BUF+BUF_SIZE)) == NULL)
     return;
   szTempBuffer = szSection+SM_BUF;

    if (lpszPort)
    {
      LoadString(ghDriverMod, IDS_POSTSCRIPT, (LPSTR)szSection, SM_BUF);
      lstrcat((LPSTR) szSection, lpszPort);
      if (lpszPort[lstrlen(lpszPort) - 1] == ':')
        szSection[lstrlen(szSection) - 1] = '\0';

      // Merge the WIN.INI and ATM.INI entries to Registry
      dwWinVersion = GetVersion();  // Delete Win.INI junk only if Ver>4.0 (Win96 or later)
      if (LOBYTE(LOWORD(dwWinVersion))>=4 && HIBYTE(LOWORD(dwWinVersion))>0)
         bDel=TRUE;

      //get check sum
      CompositeString(ghDriverMod, IDS_REGSTR_PATH_FONTSINFO, IDS_DRIVER_MANUFACTURER,
                  IDS_DRIVER_VERSION, szTempBuffer, BUF_SIZE);
      lstrcat(szTempBuffer, "\\");
      lstrcat (szTempBuffer, (LPSTR) gszPort);

      dwCheckSum = GetRegDWord(szTempBuffer, lpszPort);

      dwNewCheckSum = MergeIniFileToRegistry((LPSTR)"WIN.INI", (LPSTR)szSection, FALSE, bDel, dwCheckSum);

      //set checksum
      if (dwNewCheckSum != dwCheckSum)
         SetRegDWord(szTempBuffer, lpszPort, dwNewCheckSum);
    }

    if (!bWinIniOnly)
    {
      //get check sum
      CompositeString(ghDriverMod, IDS_REGSTR_PATH_FONTSINFO, IDS_DRIVER_MANUFACTURER,
                  IDS_DRIVER_VERSION, szTempBuffer, BUF_SIZE);
      dwCheckSum = GetRegDWord(szTempBuffer, gszATMCkSum);

      dwNewCheckSum = MergeIniFileToRegistry((LPSTR)"ATM.INI", (LPSTR)"FONTS", FALSE, FALSE, dwCheckSum);

      //set check sum
      if (dwNewCheckSum != dwCheckSum)
         SetRegDWord(szTempBuffer, gszATMCkSum, dwNewCheckSum);
    }
    if (hcurOld)
        SetCursor(hcurOld);
    if (szSection)
      GlobalFreePtr(szSection);


}

BOOL NEAR PASCAL GetPortFromFriendlyName(LPSTR lpszFriendlyName, LPSTR lpszPort, DWORD cbSize)
{
  HKEY hkey = NULL;
  DWORD dwType = 0;
  BOOL rc = TRUE;
  LPSTR szPrnInstKey = NULL;
  LPSTR szTempBuffer = NULL;

  *lpszPort = '\0';
   if ((szPrnInstKey = GlobalAllocPtr(GDLLHND,  2* SM_BUF)) == NULL)
     return FALSE;
   szTempBuffer =  szPrnInstKey+SM_BUF;

   if (!lpszFriendlyName || *lpszFriendlyName == '\0')
   {
      return  FALSE;
   }
   LoadString(ghDriverMod, IDS_REGSTR_PRN_PRINTER, szTempBuffer, SM_BUF);
   wsprintf((LPSTR)szPrnInstKey, szTempBuffer, lpszFriendlyName);

   if (RegOpenKey(HKEY_LOCAL_MACHINE, szPrnInstKey, (HKEY FAR *) &hkey)
      == ERROR_SUCCESS)
   {
      //if a key exist for this friendly printer
      if (RegQueryValueEx(hkey, gszPort, 0, (LPDWORD) &dwType,
         (LPSTR) lpszPort, (LPDWORD)&cbSize) != ERROR_SUCCESS)
      {
         *lpszPort = '\0';
         rc = FALSE;
      }
   }
   RegCloseKey(hkey);
   if (szPrnInstKey)
     GlobalFreePtr(szPrnInstKey);

   return rc;
}







