/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ENABLE.C                                                     */
/*                                                                           */
/* Description: This module contains the function for enabling the           */
/*              .......                                                      */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_ENABLESEG)

// default GDIINFO values

#define DP_future     0
#define DP_undefined  0

#define DP_version    GDI_VERSION
#define DP_technology DT_RASPRINTER
#define DP_horzsize   216                          //width in mm
#define DP_vertsize   279                          //height in mm
#define DP_horzres    ((RES*8)+((RES+1)/2))        //width in pixels
#define DP_vertres    (RES*11)                                             //height in pixels
#define DP_bitspixel  1                            //LATER: make this device dependent
#define DP_planes     1                            //LATER: make this device dependent
#define DP_numbrushes 17                           //LATER: change this
#define DP_numpens    8                            //LATER: change this
#define DP_numfonts   4                            //LATER: make this device dependent
#define DP_numcolors  8                            //LATER: make this device dependent
#define DP_devicesize sizeof(PDEVICE)
#define CC_ROUNDRECT  0x0100                       //move to windows.h or gdi.h
#define DP_curves                \
                    (CC_NONE         \
                    | CC_POLYBEZIER  \
                    | CC_CIRCLES     \
                    | CC_PIE         \
                    | CC_CHORD       \
                    | CC_ELLIPSES    \
                    | CC_WIDE        \
                    | CC_STYLED      \
                    | CC_WIDESTYLED  \
                    | CC_INTERIORS   \
                    | CC_ROUNDRECT)
#define DP_lines                 \
                    (LC_NONE         \
                    | LC_POLYLINE    \
                    /* |LC_MARKER */ \
                    /* |LC_POLYMARKER */ \
                    | LC_WIDE        \
                    | LC_STYLED      \
                    | LC_WIDESTYLED  \
                    | LC_INTERIORS)

#define DP_polygonals            \
                    (PC_NONE         \
                    | PC_POLYGON     \
                    | PC_RECTANGLE   \
                    | PC_WINDPOLYGON \
                    | PC_SCANLINE    \
                    | PC_WIDE        \
                    | PC_STYLED      \
                    | PC_WIDESTYLED  \
                    | PC_INTERIORS)
#define DP_text                   \
                    ( TC_OP_CHARACTER \
                    | TC_OP_STROKE    \
                    | TC_CP_STROKE    \
                    | TC_CR_90        \
                    | TC_CR_ANY       \
                    | TC_SF_X_YINDEP  \
                    | TC_SA_DOUBLE    \
                    | TC_SA_INTEGER   \
                    | TC_SA_CONTIN    \
                    | TC_EA_DOUBLE    \
                    | TC_IA_ABLE      \
                    | TC_UA_ABLE      \
                    | TC_SO_ABLE )

#define DP_clip                   \
                    (CP_NONE          \
                    | CP_RECTANGLE)

#define DP_raster                     \
                       ( RC_BITBLT        \
                       | RC_BITMAP64      \
                       | RC_GDI20_OUTPUT  \
                       | RC_DIBTODEV      \
                       | RC_STRETCHBLT    \
                       | RC_STRETCHDIB    )
#define DP_aspectx     100
#define DP_aspecty     100
#define DP_aspectxy    141
#define DP_stylelen    (DP_aspectxy*2)
#define DP_mlowin      {254,254}
#define DP_mlovpt      {RES,-RES}
#define DP_mhiwin      {2540,2540}
#define DP_mhivpt      {RES,-RES}
#define DP_elowin      {100,100}
#define DP_elovpt      {RES,-RES}
#define DP_ehiwin      {1000,1000}
#define DP_ehivpt      {RES,-RES}
#define DP_twpwin      {1440,1440}
#define DP_twpvpt      {RES,-RES}
#define DP_logpixelsx  RES
#define DP_logpixelsy  RES
#define DP_dcmanage    DC_SPDevice
#define DP_palcolors   0 // palette stuff is device dependent
#define DP_palreserved 0 // palette stuff is device dependent
#define DP_palresolut  0 // palette stuff is device dependent

GDIINFO gdiInfo={
          DP_version,
          DP_technology,
          DP_horzsize,
          DP_vertsize,
          DP_horzres,
          DP_vertres,
          DP_bitspixel,
          DP_planes,
          DP_numbrushes,
          DP_numpens,
          DP_future,
          DP_numfonts,
          DP_numcolors,
          DP_devicesize,
          DP_curves,
          DP_lines,
          DP_polygonals,
          DP_text,
          DP_clip,
          DP_raster,
          DP_aspectx,
          DP_aspecty,
          DP_aspectxy,
          DP_stylelen,
          DP_mlowin,
          DP_mlovpt,
          DP_mhiwin,
          DP_mhivpt,
          DP_elowin,
          DP_elovpt,
          DP_ehiwin,
          DP_ehivpt,
          DP_twpwin,
          DP_twpvpt,
          DP_logpixelsx,
          DP_logpixelsy,
          DP_dcmanage,
          DP_future,
          DP_future,
          DP_future,
          DP_future,
          DP_future,
          DP_palcolors,
          DP_palreserved,
          DP_palresolut
};

// defines for different types of style parameter
#define PDEVICEINIT     0x0000          // Initialize hardware
#define PDEVICEREQUEST  0x8000          // Get the size of PDEVICE
#define GDIINIT         0x0001          // Initialize GDIINFO and copy
#define GDIINFOREQUEST  0x8001          // Return size of GDIINFO

//;               dpCapsFE capability bits
#define FEC_EUDC_ABLE   0x100       // can handle EUDC in device font.


BOOL FAR IsFilePort(LPSTR lpszPort) ;

/*****************************************************************************/
/*                 IsTrueTypeEnabled                                         */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE  => if success,                                                    */
/*   FALSE => if failure,                                                    */
/*****************************************************************************/

BOOL IsTrueTypeEnabled()
{
   BOOL bEnabled = FALSE;

   if( GetProfileInt("TrueType", "TTEnable", 1 ) &&
       GetProcAddress(GetModuleHandle("GDI"),"EngineDeleteFont") &&
       (GetWinFlags() & WF_PMODE))
   {
       bEnabled = TRUE;
   } 
   return(bEnabled);
}


/*****************************************************************************/
/*                InitGDIInfo                                                */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   LPPDEVICE lppd -- pdevice                                               */
/*   LPDGIINFO lpgi                                                          */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE  => if success,                                                    */
/*   FALSE => if failure, at least one entered value is invalid              */
/*****************************************************************************/

VOID InitGDIInfo(LPPDEVICE lppd, LPGDIINFO lpgi)
{
   RECT rect ;
   short Scale = lppd->lpPSExtDevmode->dm.dm.dmScale;

   // set all gdiInfo fields correctly, let's start with all defaults

   *lpgi=gdiInfo;
   // set color based on bfusecolor
   if (lppd->lpPSExtDevmode->dm.dm.dmColor == DMCOLOR_COLOR )
   {
      lpgi->dpNumColors = 8;           // say that all devices are color
      lpgi->dpNumPens = 8;
   }
   else
   {
      lpgi->dpNumColors = 2;           // unless the user explicitly tells
      lpgi->dpNumPens = 2;             // us to use BW.
   }

   if ( lppd->lpPSExtDevmode->dm.marginState == NO_MARGINS) //Full page is imageable.
   {
      SetRect(&rect, 0, 0, lppd->ptPaperDim.x, lppd->ptPaperDim.y) ;
   }
   else
   {
      rect = lppd->imageRect ;
   }
 
   lpgi->dpHorzSize = MulDiv(rect.right - rect.left,
                        MMPERINCHX10, lppd->DeviceRes.x_res*10) ;
   lpgi->dpVertSize = MulDiv(rect.bottom - rect.top,
                        MMPERINCHX10, lppd->DeviceRes.y_res*10) ;

   lpgi->dpHorzRes = rect.right - rect.left ;
   lpgi->dpVertRes = rect.bottom - rect.top ;
  
   // Calculate device Aspect Ratio values for non-square printer resolutions

   if (lppd->DeviceRes.x_res != lppd->DeviceRes.y_res)
   {
      short AspectX = lppd->DeviceRes.y_res;
      short AspectY = lppd->DeviceRes.x_res;
      double AspectXY;

      // scale aspect ratio numbers to < 1000 (see DDK GDIINFO documentation)
      while ((AspectX >1000) || (AspectY >1000)) 
      {
         AspectX /= 2;
         AspectY /= 2;
      }
      AspectXY = (double)sqrt( (double)((long)AspectX*(long)AspectX) +
                 (double)((long)AspectY*(long)AspectY) );

      // scale aspect ratios down further so AspectXY is < 1000
      while (AspectXY >1000)
      {
         AspectX /= 2;
         AspectY /= 2;
         AspectXY = (double)sqrt( (double)((long)AspectX*(long)AspectX) +
                    (double)((long)AspectY*(long)AspectY) );
      }  
      lpgi->dpAspectX = AspectX;
      lpgi->dpAspectY = AspectY;
      lpgi->dpAspectXY = (int)AspectXY;
      lpgi->dpStyleLen = lpgi->dpAspectXY*2;
   }  // end of Aspect Ratio calculations

   // Now scale everything per the user's selected scaling factor.

   lpgi->dpHorzSize = MulDiv(lpgi->dpHorzSize,100,Scale);
   lpgi->dpVertSize = MulDiv(lpgi->dpVertSize,100,Scale);

   lpgi->dpMLoVpt.x   = MulDiv(  lppd->DeviceRes.x_res,Scale,100);
   lpgi->dpMLoVpt.y   = MulDiv( -lppd->DeviceRes.y_res,Scale,100);
   lpgi->dpMHiVpt.x   = MulDiv(  lppd->DeviceRes.x_res,Scale,100);
   lpgi->dpMHiVpt.y   = MulDiv( -lppd->DeviceRes.y_res,Scale,100);
   lpgi->dpELoVpt.x   = MulDiv(  lppd->DeviceRes.x_res,Scale,100);
   lpgi->dpELoVpt.y   = MulDiv( -lppd->DeviceRes.y_res,Scale,100);
   lpgi->dpEHiVpt.x   = MulDiv(  lppd->DeviceRes.x_res,Scale,100);
   lpgi->dpEHiVpt.y   = MulDiv( -lppd->DeviceRes.y_res,Scale,100);
   lpgi->dpTwpVpt.x   = MulDiv(  lppd->DeviceRes.x_res,Scale,100);
   lpgi->dpTwpVpt.y   = MulDiv( -lppd->DeviceRes.y_res,Scale,100);
   lpgi->dpLogPixelsX = MulDiv(  lppd->DeviceRes.x_res,Scale,100);
   lpgi->dpLogPixelsY = MulDiv(  lppd->DeviceRes.y_res,Scale,100);
   lpgi->dpCaps1      = C1_TT_CR_ANY  | C1_GLYPH_INDEX 
           | C1_ICM 
            ;
   lpgi->dpCapsFE     = FEC_WIFE_ABLE;
   if (lppd->lpPSExtDevmode->dm2.bEUDCAble){
      lpgi->dpCapsFE |= FEC_EUDC_ABLE;
     }

}


PSERROR NEAR PASCAL InitRealizeBuffers(LPPDEVICE  lppd)
{
   LPREALIZEBUFS  lpCache ;
   PSERROR        rc = PS_SUCCESS;

   lpCache = &lppd->GlobalBuffer.RealizeBufs ;

   if (lpCache->lpScoreArray =
      (LPBYTE) GlobalAllocPtr(GHND|GMEM_DDESHARE, 40))
       lpCache->cScoreArray = 40 ;

   if (lpCache->lpTTFI =
      (LPPSFONTINFO) GlobalAllocPtr(GHND|GMEM_DDESHARE, 132))
       lpCache->cTTFI = 132 ;

   if (lpCache->lpFI =
      (LPPSFONTINFO) GlobalAllocPtr(GHND|GMEM_DDESHARE, 132))
       lpCache->cFI = 132 ;

   if (!lpCache->lpScoreArray || !lpCache->lpTTFI || !lpCache->lpFI)
   {
       rc = PS_ALLOC_FAILED;
       goto EndInitRealizeBuffers;
   }

   lpCache->nTTrealized = 0 ;

   lpCache->lpFontCache =  NULL ;

   lpCache->lpdWidths  =  NULL ;
   lpCache->rgwWidths  =  NULL ;
   lpCache->devlpdWidths  =  NULL ;
   lpCache->devlpsWidths  =  NULL ;
   lpCache->sizlpdWidths  =  0 ;
   lpCache->sizrgwWidths  =  0 ;
   lpCache->sizdevlpdWidths  =  0 ;
   lpCache->sizdevlpsWidths  =  0 ;

   // strictly speaking, not a Realization Buffer, but
   // nevertheless must be allocated at enable time.

   if (lppd->GlobalBuffer.lpSubStringBuf = 
         GlobalAllocPtr(GHND|GMEM_DDESHARE, 16))
   {
       lppd->GlobalBuffer.cSubStringBuf = 16 ;
   }
   else
       rc = PS_ALLOC_FAILED;

EndInitRealizeBuffers:
   if (PS_ERROR(rc))
   {
       if (lpCache->lpScoreArray)
       {
           GlobalFreePtr(lpCache->lpScoreArray);
           lpCache->lpScoreArray = NULL;
           lpCache->cScoreArray = 0;
       }
       if (lpCache->lpTTFI)
       {
           GlobalFreePtr(lpCache->lpTTFI);
           lpCache->lpTTFI = NULL;
           lpCache->cTTFI = 0;
       }
       if (lpCache->lpFI)
       {
           GlobalFreePtr(lpCache->lpFI);
           lpCache->lpFI = NULL;
           lpCache->cFI = 0;
       }
       if (lppd->GlobalBuffer.lpSubStringBuf)
       {
           GlobalFreePtr(lppd->GlobalBuffer.lpSubStringBuf);
           lppd->GlobalBuffer.lpSubStringBuf = NULL;
           lppd->GlobalBuffer.cSubStringBuf = 0;
       }
   }
   return rc;
}



/*************************************************************************/
/*                       InitPDevice                                     */
/*  function:                                                            */
/*       initializes a PDevice structure for printing                    */
/*  prototype:                                                           */
/*       FLAG InitPDevice(LPPDEVICE lppd);                               */
/*  parameters:                                                          */
/*       LPPDEVICE lppd -- pointer to the PDEVICE being initialized      */
/*  returns:                                                             */
/*       None                                                            */
/*************************************************************************/

PSERROR FAR PASCAL InitPDevice(LPPDEVICE lppd)
{
   PSERROR rc;

   //zero everything
   MemSet((LP)lppd,0,(DWORD) sizeof(PDEVICE));//Windows specific stuff

   lppd->wSpoolError = 1 ;  // positive means no WriteSpool Errors.
   lppd->sMagic=LUCAS;
   lppd->cTTFontList = 0;
   lppd->sTTFontList = 0;
   lppd->lpTTFontList = NULL;
   lppd->FontDataHandle = NULL;  // handle to the font data list structure
   lppd->lpFontDataList = (LPFONTDATALIST)NULL; // ptr to the font data list structure
   lppd->ProcsetstuffHandle = NULL;   // handle to the procset data
   lppd->lpProcsetstuff = (LPPROCSETDOWNLOAD)NULL; // ptr to the procset data
   lppd->hdlGSStack = NULL;      // handle to the Gstate Stack
   lppd->lpGSStack = (LPGSSTACKREC)NULL;    // ptr to the Gstate stack
   lppd->hDriverTokenDLL = NULL; // DLL handle for external translator DLL.
   lppd->hAltTrans = NULL;       // handle for data space for use by
                                 // alternate translators
   lppd->lpAltTrans = (LPVOID)NULL;  // pointer to the data space for alternate
                                    // translators

   // Initialize graphics state data

   lppd->graphics.bArcDirection  = COUNTERCLOCKWISE      ;
   lppd->graphics.bBackgroundMode= TRANSPARENT           ;
   lppd->graphics.dBGColor       = RGB_WHITE             ;
   lppd->graphics.dFGColor       = RGB_BLACK             ;
   lppd->graphics.bPolyMode      = PM_POLYLINE;          ;
   lppd->graphics.PathLevel     = 0                      ;
   lppd->graphics.XformLevel     = 0                     ;
   lppd->graphics.ScaleMode      = 0                     ;
   lppd->graphics.xScale         = 0                     ;
   lppd->graphics.yScale         = 0                     ;
   //ALWAYS_ICM
   lppd->graphics.hDefCMTransform = 0                    ;

   lppd->pagebackground = -1;

   // Initialize TT Font Substitution Table.
   lppd->wFontSubsEntries = 0;
   rc = CreateFontSubsTable(lppd);
   if (PS_ERROR(rc))
       return rc;
  
   rc = InitRealizeBuffers(lppd);
   if (PS_ERROR(rc))
       return rc;

   //initialize the pen and brush state  -- is this redundant with above?
   CInitPen(lppd);
   CInitBrush(lppd);

   lppd->job.bfESCSetBounds = FALSE;   // flag to inform TRANSLATE side of escape      
   lppd->job.bfESCPassThrough = FALSE; // flag to inform TRANSLATE side of escape      
   lppd->job.bfInStretchDib = FALSE;   // flag to block nested StretchDib calls.
   lppd->job.bfInWriteSpool = FALSE;

   lppd->job.bfTTEnabled = IsTrueTypeEnabled();

   // Initialise state machine to ST_INITIAL
   lppd->stCurrent = ST_INITIAL;

   // Enable VM tracking to begin with.
   lppd->doVMTracking = 1;
   lppd->doVMRecovery = 1;
   lppd->vmEstimateUsed = 0;

   // Initialize to no buffered bitmaps.
   lppd->GlobalBuffer.hBitmapBf = NULL;
   lppd->GlobalBuffer.lpBitmapBf = NULL;
   lppd->GlobalBuffer.handleBitmapNow = FALSE;
   lppd->GlobalBuffer.bFlushInProgress = FALSE;

#ifdef ADOBE_DRIVER
   lppd->SmsStartDoc=NORMAL_SD;  // default is normal startdoc()
   lppd->bCopyToSpecial=FALSE;      // after this flag is set to TRUE, all data goes to lpSpecialPSData.
   lppd->lpSpecialPSData=NULL;   // Special passthrough PS data and DownloadFace's fontdata go here
   lppd->vmUsedPreStartDoc =0 ;
   lppd->WMarkHandle=NULL;       // Handle to the Watermark cached FontInfo stuff,
   lppd->lpWMark=NULL;    // Pointer to Watermark cached FontInfo,
   lppd->bCopyToInjectBuff=FALSE;      // after this flag is set to TRUE, all data goes to Inject buffer.
   lppd->lpPSInjectData=NULL;   // APP Injection passthrough PS data record pointer
   lppd->lpPSInjectRoot=NULL;   // APP Injection passthrough PS data anchor
   lppd->lpCurrentBuffer=NULL;   // APP Injection passthrough PS data buffer pointer

   lppd->dwDownloadFaceStr=0;  // length of buffer lpDownloadFaceStr
   lppd->lpDownloadFaceStr=NULL ; // String used for next Escape(DownloadFace) call. 
   lppd->nPreStartDocFonts=0; 

#endif
#ifdef ADD_EURO
   lppd->lpEuroFontList = NULL;
   lppd->lpSCDParams = NULL;
   lppd->NumEuroFonts = 0;
#endif

   return PS_SUCCESS;
}


/***************************************************************************/
/*                       Enable                                            */
/*  function:                                                              */
/*       initializes and returns a PDEVICE or a GDIINFO structure.  This   */
/*       is a GDI entry point.                                             */
/*  prototype:                                                             */
/*       short FAR PASCAL Enable(LP lpData,WORD wStyle,LPSTR lpzDestDevice,*/
/*                               LPSTR lpzPort,LPDEVMODE lpDevMode)        */
/*  parameters:                                                            */
/*       LP        lpData -- pointer to the PDEVICE or GDIINFO being       */
/*                           initialized and returned                      */
/*       WORD      wStyle -- specify action to take                        */
/*       LPSTR     lpzDestDevice -- friendly name of device                */
/*       LPSTR     lpzPort -- output port name                             */
/*       LPDEVMODE lpDevMode -- points to DEVMODE struct                   */
/*  returns:                                                               */
/*       size (in bytes) necessary to keep structure                       */
/***************************************************************************/

short _loadds FAR PASCAL DevEnable(LP lpData,WORD wStyle,LPSTR lpFriendly,
                                   LPSTR lpzPort,LPDEVMODE lpDevMode)
{
    LPPDEVICE      lppd = NULL;
    LPPSEXTDEVMODE lpExtDevMode, lpLocalExtDevmode = NULL ;
    LPSTR          lpzDestDevice;
    LPWPXBLOCKS    lpWPXblock;
    DWORD          dwType, dwNeeded;
    WORD           wRet = 0;
    char           szDevName[CCHDEVICENAME];
    PSERROR        rc;

#ifdef PS_MEMTRACE
   MemCheckEnable();
#endif

    // Get printer model name
    lpzDestDevice = (LPSTR) szDevName;
    lpzDestDevice[0] = '\0';                /* Null intialize it */
    if (DrvGetPrinterData(lpFriendly, (LPSTR)INT_PD_PRINTER_MODEL, &dwType, lpzDestDevice, 
                          CCHDEVICENAME, &dwNeeded) != ERROR_SUCCESS)
    {
        /* Unknown model - use default printer. */
        LoadString(ghDriverMod, IDS_DEFAULTPRINTER, lpzDestDevice, CCHDEVICENAME);
    }    

    lpExtDevMode = lpLocalExtDevmode = 
        (LPPSEXTDEVMODE) GlobalAllocPtr(GHND|GMEM_DDESHARE,
                                        dsizeof(PSEXTDEVMODE));
    if (!lpExtDevMode)
        goto CleanUpEnable;

    lpWPXblock = GetPrinter(lpzDestDevice ) ;

    if(!lpWPXblock)
      goto  CleanUpEnable;

    if (DrvGetPrinterData(lpFriendly, (LPSTR)INT_PD_DEFAULT_DEVMODE, &dwType, 
                            (LPBYTE)lpExtDevMode, sizeof(PSEXTDEVMODE),
                            &dwNeeded) == ERROR_SUCCESS)
    {
        MERGETYPE mergeType;
        // Check the TypeWide/Full/Fast flags value in Win.ini. They are used to
        // Overwrite the printer settings at Print Time only.
        // If the flag does not exist, then don't do anything.
        lpExtDevMode->dm2.bTrueTypeWide =  GetProfileInt("TrueType", "TrueTypeWide",
               lpExtDevMode->dm2.bTrueTypeWide); // If not exist then use orig val 
        lpExtDevMode->dm2.bFullDown =  GetProfileInt("TrueType", "TrueTypeFull",
               lpExtDevMode->dm2.bFullDown); 
        lpExtDevMode->dm2.bTrueTypeFast =  GetProfileInt("TrueType", "TrueTypeFast",
               lpExtDevMode->dm2.bTrueTypeFast);

        // May be this is the logical place to use Logic to Overwrite conflict settings:
        // Cannot do Fast for CharCode (notWide) or FullDownloading.
        if (!lpExtDevMode->dm2.bTrueTypeWide || lpExtDevMode->dm2.bFullDown)
              lpExtDevMode->dm2.bTrueTypeFast = 0 ;

        if((mergeType = GetMergeType(lpWPXblock, 
                                     lpExtDevMode)) != MERGE_FULL)
        {
            PSEXTDEVMODE dmTemp;
            
            dmTemp = *lpExtDevMode;    /* Save the bad cached devmode */

            // For a cached devmode, DOCRESTRICTED is actually
            // CACHEDRESTRICTED.
            if (mergeType == MERGE_DOCRESTRICTED)
                mergeType = MERGE_CACHEDRESTRICTED;
            PsExtDevmodeMerge(lpExtDevMode, (LPPSEXTDEVMODE) &dmTemp,
                              lpzDestDevice, lpFriendly, TRUE);
        }
    }
    else
    {
        InitDefaultDevmode( lpWPXblock, lpExtDevMode, lpFriendly);
        UpdatePublicDevmode(lpWPXblock, lpExtDevMode);
    }
    
    FreePrinter(lpWPXblock);

    if(lpDevMode)
    {
        // Merge lpDevMode into it.
        PsExtDevmodeMerge(lpExtDevMode, (LPPSEXTDEVMODE) lpDevMode,
                          lpzDestDevice, lpFriendly, FALSE);
    }

   switch ( wStyle )
   {
      case PDEVICEINIT:       // Initialize the PDEVICE with default parameters
      case PDEVICEREQUEST:    // Return the size of PDEVICE
              if(lpData)
              {
                  lppd = (LPPDEVICE) lpData;
                  rc = InitPDevice(lppd) ; // Finally  init PD
                  if (PS_ERROR(rc))
                  {
                      FreePDeviceBufs(lppd);
                      goto CleanUpEnable;
                  }

                  lstrcpy(lppd->szPortName, lpzPort);
                  // Create ExtDevmode structure for lppd
                  lppd->lpPSExtDevmode = 
                      (LPPSEXTDEVMODE) GlobalAllocPtr(GHND|GMEM_DDESHARE,
                                                      dsizeof(PSEXTDEVMODE));
                  if (!lppd->lpPSExtDevmode)
                      goto CleanUpEnable;

                  *(lppd->lpPSExtDevmode) = *lpExtDevMode;

                  lppd->lpWPXblock = GetPrinter(lpzDestDevice ) ;
                  DrvStateRead(lppd, lppd->lpPSExtDevmode ) ;
                  fChangeStateLppdSt(lppd, ST_ENABLED);
              }
              wRet = sizeof(PDEVICE);
              break;

      case GDIINIT:           // Initialize GDIINFO and copy
      case GDIINFOREQUEST:    // Return size of GDIINFO
              if(lpData)
              {
                  // Create Fake PDevice
                  lppd = (LPPDEVICE) GlobalAllocPtr( GHND|GMEM_DDESHARE, dsizeof(PDEVICE) );
                  if (!lppd)
                      goto CleanUpEnable;

                  rc = InitPDevice(lppd) ; // Finally  init PPD
                  if (PS_ERROR(rc))
                      goto LocalCleanup;

                  lstrcpy(lppd->szPortName, lpzPort);
                  // Create ExtDevmode structure for lppd
                  lppd->lpPSExtDevmode = 
                      (LPPSEXTDEVMODE) GlobalAllocPtr(GHND|GMEM_DDESHARE,
                                                      dsizeof(PSEXTDEVMODE) );
                  if (!lppd->lpPSExtDevmode)
                      goto LocalCleanup;

                  *(lppd->lpPSExtDevmode) = *lpExtDevMode;

                  lppd->lpWPXblock = GetPrinter(lpzDestDevice ) ;
                  if (!lppd->lpWPXblock)
                      goto LocalCleanup;

                  DrvStateRead(lppd, lpExtDevMode ) ;

                  // Initialize GDIINFO structure
                  InitGDIInfo(lppd,(LPGDIINFO)lpData);
                  wRet = sizeof(GDIINFO);

                  /* Clean up */
LocalCleanup:
                  FreePDeviceBufs(lppd);  // undoes buffers created by initPDevice()
                  if (lppd->lpPSExtDevmode)
                      GlobalFreePtr(lppd->lpPSExtDevmode);
                  if (lppd->lpWPXblock)
                      FreePrinter(lppd->lpWPXblock);
                  GlobalFreePtr(lppd);
              }
              else
                  wRet = sizeof(GDIINFO);
              break;

    }

CleanUpEnable:

    /* More clean up */
    if (lpLocalExtDevmode)
        GlobalFreePtr(lpLocalExtDevmode);

    return(wRet);
}


/****************************************************************************/
/*                                                                          */
/* Be VERY careful before you touch how the                                 */
/* checking for FILE(:) section of Enable and others that use the file      */
/* port cache in the enumerator works. In particular there are cases where  */
/* we may determine something to be a file port by IsFilePort but process it*/
/* as if it were a real non-file port when it comes to the file port cache. */
/* In some cases we have to only match PART of the port name to FILE.       */
/* Most notably the case of CorelDraw where they send us in a port where    */
/* the first four letters are FILE but they purposely want it to be not     */
/* recognized as FILE when we do the OpenJob call so that it can fail and   */
/* their own "Ask user for a file name" dialog box can be brought up instead*/
/* of the standard Microsoft one. Please talk to me first or consult ADOBEPS*/
/* 2.1 bug 279 documentation before you touch any of this. -John Kwan       */    
/*                                                                          */
/*   /* Note: Some apps send the port in with the ":" and some don't        */
/*      while others (WinWord 2.0a) send it in both ways. We need to        */
/*      survive both so we append a ":" if it is missing and isn't a        */
/*      file name otherwise we leave it alone                               */
/*                                                                          */
/****************************************************************************/

/*****************************************************************************/
/*                  IsFilePort                                               */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   LPSTR lpszPort --                                                       */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE  => No match for the port name                                     */
/*   FALSE => Find match for the port name in WIN.INI                        */
/*****************************************************************************/


BOOL FAR IsFilePort(LPSTR lpszPort)
{
   char strBuff[MAX_PORT_NAME];
   char FileBuff[MAX_PORT_NAME];
// char portsArray[MAX_PORT_NAME * 16]; // Limitation on 16 ports 
   LPSTR portsArray;
   LPSTR lpTestPort;
   int portsArraySize;
   int TestPortLen;
   char PortBuffer[MAX_PORT_NAME]; // Working copy of the port/
   int iPortBufferLen, i;

   // Some apps send the port in with the ":" some don't so we need to survive
   // both types... 
   lstrcpyn(PortBuffer, lpszPort, MAX_PORT_NAME - 2);
   iPortBufferLen = lstrlen(PortBuffer);

   // Check for special case - <driveletter>:\<path>\<filename>
   // Also make sure network paths do not get ':' appended.
   if (PortBuffer[1] != (char)':' && !(PortBuffer[0] == '\\' && 
       PortBuffer[1] == '\\'))
   {
      if (PortBuffer[iPortBufferLen - 1] != (char) ':')
      {
         lstrcat(PortBuffer, ":");
         iPortBufferLen++;
      }
      // Find the colon and place zero byte after it 
      for (i=0; i < iPortBufferLen; i++)
      {
         PortBuffer[i] = (char)toupper(PortBuffer[i]);
         if (PortBuffer[i] == (char)':' )
         {
            PortBuffer[i+1] = '\0';
            break ;
         }
      }
   }

   // Test if it is equal to FILE: 
   LoadString(ghDriverMod, GLBL_szFilePort, FileBuff, sizeof(FileBuff));
   if (lstrcmp(FileBuff, PortBuffer) == 0)
      return (TRUE);

   portsArraySize = MAX_PORT_NAME * 16;     // Limitation on 16 ports 
   if (!(portsArray = GlobalAllocPtr(GHND, portsArraySize)))
   {
      lstrcpy(lpszPort, PortBuffer );
      return (TRUE);
   }
   MemSet(portsArray,0,(DWORD)portsArraySize);

   // Test if it is equal to one of the ports other than FILE: in win.ini 
   LoadString(ghDriverMod, GLBL_szPortsSection, strBuff, sizeof(strBuff));
   GetProfileString(strBuff, NULL, "", portsArray, portsArraySize);
   lpTestPort = portsArray;

   while (lstrlen(lpTestPort) > 0)
   {
      if (lstrcmp(lpTestPort, PortBuffer) == 0)
      { // It matched one of the ports in win.ini
         lstrcpy(lpszPort, PortBuffer );
         GlobalFreePtr(portsArray);
         return(FALSE) ;
      }

      TestPortLen = lstrlen(lpTestPort);
      lpTestPort = lpTestPort + TestPortLen + 1; // Take care of the NULL terminator 
   }

   // No match to port names - return processed filename
   //  with TRUE flag.
   lstrcpy(lpszPort, PortBuffer );
   GlobalFreePtr(portsArray);
   return (TRUE);
}
