/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1996,1997 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TMASK.H                                                      */
/*                                                                           */
/* Description: This module contains PostScript Level 2/3 Masked image       */
/*              defines and  prototype support                               */
/*                                                                           */
/*****************************************************************************/

short FAR PASCAL TDIBClipRgns(LPPDEVICE lppd, LPDRAWMODE lpdm,
                              LPRECT DstRect, LPRECT SrcRect,
                              LPSTR lpDataBits, LPBITMAPINFO lpBitmapInfo);
