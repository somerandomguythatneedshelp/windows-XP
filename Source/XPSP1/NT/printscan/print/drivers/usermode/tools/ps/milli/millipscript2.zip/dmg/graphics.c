/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: GRAPHICS.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for the Graphics          */
/*              Options Dialog                                               */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "apd42map.hh"

#pragma code_seg(_DIALOGSSEG)

#define UPDATE_RESOLUTION          0x0001
#define UPDATE_ALL                 0xffff
#define UPDATE_UICONSTRAINED       UPDATE_RESOLUTION
#define UPDATE_NONUICONSTRAINED    0x0002

BOOL FAR PASCAL ICMProfileInstalled(LPPRINTERINFO lpPrinterInfo, LPSTR lpszFriendlyName);

/*****************************************************************************/
/*                 InitGraphicsDlg                                           */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   LPDRIVERINFO lpDrvinfo -- Pointer to driver info structure              */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/

VOID NEAR PASCAL InitGraphicsDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    DWORD dwUIFlags = lpDrvInfo->dwUIFlags[DI_GRAPHICS];
    int   yOffset = 0, i;
    char  strBuff[STR_BUFF_LEN];

    PositionControls(hDlg, NULL, NULL, dwUIFlags&DI_PRINTPAGEBORDER,
                     ID_PRINT_PAGE_BORDER, ID_PRINT_PAGE_BORDER, NULL);

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_RESLN,
                     ID_RESOLUTION_STATIC, ID_RESOLUTION_CB, ID_SPECIAL_GROUP);
    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_SPECIAL,
                     ID_SPECIAL_GROUP, ID_PRINTMIRROR, ID_PAPER_HANDLING_GROUP);
    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_LAYOUT,
                     ID_PAPER_HANDLING_GROUP, ID_LAYOUTLIST, ID_SCALING_TEXT);
    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_SCALE,
                     ID_SCALING_TEXT, ID_TEXT_PERCENT, ID_COLOR_GROUP);
    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_COLOR,
                     ID_COLOR_GROUP, ID_COLOR_CHOOSE_METHOD, NULL);

    if (dwUIFlags & DI_LAYOUT)
    {
        SendDlgItemMessage(hDlg, ID_LAYOUTLIST, CB_RESETCONTENT, 0, 0L);

        for (i=IDS_BASE_LAYOUT_NAME; i<= IDS_BASE_LAYOUT_NAME+5; i++)
        {
            LoadString(ghDriverMod, i, strBuff, sizeof(strBuff));
            SendDlgItemMessage(hDlg, ID_LAYOUTLIST, CB_ADDSTRING, 0,
                                 (LPARAM)(LPSTR)strBuff);
        }
    }

}

/*****************************************************************************/
/*                 ReInitGraphicsDlg                                         */
/* Purpose: Show or hide color UI when ICC profiles are added or removed     */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   LPDRIVERINFO lpDrvinfo -- Pointer to driver info structure              */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/

VOID NEAR PASCAL ReInitGraphicsDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    DWORD dwUIFlags = lpDrvInfo->dwUIFlags[DI_GRAPHICS];
    int   id;

    for (id=ID_COLOR_GROUP; id<=ID_COLOR_CHOOSE_METHOD; id++)
    {
        HWND hwnd = GetDlgItem(hDlg,id);
        if (dwUIFlags&DI_COLOR)
        {
            EnableWindow(hwnd, TRUE);
            ShowWindow(hwnd, SW_SHOWNA);
        }
        else
        {
            EnableWindow(hwnd, FALSE);
            ShowWindow(hwnd, SW_HIDE);
        }
    }
}

/*****************************************************************************/
/*                 BuildGraphicsDlg                                          */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   LPDRIVERINFO lpDrvinfo -- Pointer to driver info structure              */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/

VOID NEAR PASCAL BuildGraphicsDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo,
                                  WORD buildFlags)
{   if (buildFlags & UPDATE_RESOLUTION)
    {
        BuildCBOptList(lpDrvInfo, hDlg, IND_RESOLUTIONINFO, ID_RESOLUTION_CB);
    }

    if (buildFlags & UPDATE_NONUICONSTRAINED)
    {
        /* Set scaling spin range */
        SendDlgItemMessage(hDlg, ID_SCALE, EM_LIMITTEXT, 4, 0) ;
        SendDlgItemMessage(hDlg, ID_SCALE_SPN, UDM_SETRANGE, NULL,
                           MAKELPARAM(MAX_SCALING_PERCENT,
                                      MIN_SCALING_PERCENT));
    }
}

/*****************************************************************************/
/*                 ShowGraphicsDlg                                           */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   LPDRIVERINFO lpDrvinfo -- Pointer to driver info structure              */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/

VOID NEAR PASCAL ShowGraphicsDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo,
                                 WORD showFlags)
{
    LPPSEXTDEVMODE lpPSExtDevmode = lpDrvInfo->lpDM;
    int            i, iconID;
    HANDLE         hicon;
    WORD           show;
    DWORD dwUIFlags = lpDrvInfo->dwUIFlags[DI_GRAPHICS];

    if (showFlags & UPDATE_RESOLUTION)
    {
        /* Set current resolution */
        KeywordGetCurrentOption(&lpDrvInfo->pDev, IND_RESOLUTIONINFO,
                                (LPWORD)&i);
        SendDlgItemMessage(hDlg, ID_RESOLUTION_CB, CB_SETCURSEL, i, 0L);
    }

    if (showFlags & UPDATE_NONUICONSTRAINED)
    {
        /* Now initialize the dialog's widgets */
        show = lpPSExtDevmode->dm.useImageColorMatching;
        CheckRadioButton( hDlg, ID_COLOR_NO_MATCHING, ID_COLOR_ALWAYSICM,
                   show==ICM_ALLOW ? ID_COLOR_USE_MATCHING :
                   (show==ICM_ALWAYS ? ID_COLOR_ALWAYSICM : ID_COLOR_NO_MATCHING) );

        if( show == ICM_ALLOW || show == ICM_ALWAYS )
           EnableWindow(GetDlgItem(hDlg, ID_COLOR_CHOOSE_METHOD), TRUE);
        else
           EnableWindow(GetDlgItem(hDlg, ID_COLOR_CHOOSE_METHOD), FALSE);

         /* Negative image & Miroring options */
        CheckDlgButton(hDlg, ID_PRINTNEGATIVE, lpPSExtDevmode->dm.bNegImage);
        CheckDlgButton(hDlg, ID_PRINTMIRROR, lpPSExtDevmode->dm.bMirror);
        iconID = NM_BASE_ICON + (lpPSExtDevmode->dm.bMirror ? 2 : 0) +
                 (lpPSExtDevmode->dm.bNegImage ? 1 : 0);
        hicon = lpDrvInfo->lpGetIconResource(iconID);
        SendDlgItemMessage(hDlg, ID_ICON_NM, STM_SETICON, (WORD)hicon, 0L);

        /* Scaling */
        SendDlgItemMessage(hDlg, ID_SCALE_SPN, UDM_SETPOS, NULL,
                           MAKELPARAM(lpPSExtDevmode->dm.Scale, NULL));

        /* Layout */
        SendDlgItemMessage(hDlg, ID_LAYOUTLIST, CB_SETCURSEL, lpPSExtDevmode->dm.layout, 0L);
        ValidatePicture(hDlg,ID_GRAPHICS_PICTURE,FALSE);

        /* Print page border */
        if (dwUIFlags & DI_PRINTPAGEBORDER)
        {
           CheckDlgButton(hDlg, ID_PRINT_PAGE_BORDER, lpDrvInfo->lpDM->dm2.bPrintPageBorder);
           if( lpPSExtDevmode->dm.layout > ONE_UP )
              EnableWindow(GetDlgItem(hDlg, ID_PRINT_PAGE_BORDER), TRUE);
           else
              EnableWindow(GetDlgItem(hDlg, ID_PRINT_PAGE_BORDER), FALSE);
        }


    }
}


/*****************************************************************************/
/*                 CheckGraphics                                             */
/* Purpose:                                                                  */
/*   Checks the validity of certain user entered data in the                 */
/*   Graphics features dialog box. The first invalid or out of range entry   */
/*   causes failure and the item in question will be highlighted.            */
/*                                                                           */
/* Parameters:                                                               */
/*   LPDRIVERINFO lpDrvInfo -- ptr to DRIVERINFO structure                   */
/*   HWND hDlg -- Handle to PostScript features dialog                       */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE  => if success, entered values are fine                            */
/*   FALSE => if failure, at least one entered value is invalid              */
/*****************************************************************************/

BOOL NEAR PASCAL CheckGraphics(LPDRIVERINFO lpDrvInfo, HWND hDlg)
{
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;
    int            ctrl_id = 0, i;
    BOOL           bOK = FALSE;
    long           maxVal, minVal;

    /* Check scaling. */
    ctrl_id = ID_SCALE;
    i = GetDlgItemInt(hDlg, ID_SCALE, &bOK, FALSE);
    if (!bOK)
    {
        maxVal = MAX_SCALING_PERCENT;
        minVal = MIN_SCALING_PERCENT;
        goto Errors;
    }

    if (i >= MIN_SCALING_PERCENT && i <= MAX_SCALING_PERCENT)
    {
        lpPSExtDevmode->dm.Scale = i;
    }
    else
    {
        maxVal = MAX_SCALING_PERCENT;
        minVal = MIN_SCALING_PERCENT;
        bOK = FALSE;
        goto Errors;
    }

    lpPSExtDevmode->dm.bNegImage = IsDlgButtonChecked(hDlg,ID_PRINTNEGATIVE);
    lpPSExtDevmode->dm.bMirror = IsDlgButtonChecked(hDlg,ID_PRINTMIRROR);
    bOK = TRUE;

Errors:
    if (!bOK)
    {
       ShowErrorValueMessage(hDlg, ctrl_id, minVal, maxVal);
    }

    return bOK;
}


/*****************************************************************************/
/*                         RestoreGraphicsDefaults                           */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
 /*                                                                           */
/* Returns:                                                                  */
/*                                                                           */
/*****************************************************************************/

void FAR PASCAL RestoreGraphicsDefaults(LPPSEXTDEVMODE lpPSExtDevmode,
                                        LPWPXBLOCKS lpWPXBlock,
                                        DWORD dwUIFlags)
{
    LPPRINTERINFO lpPrinterInfo ;
    LPBYTE        lpOptionsBlock;

    lpPrinterInfo = (LPPRINTERINFO)(lpWPXBlock->WPXprinterInfo);
    lpOptionsBlock = lpWPXBlock->WPXarrays ;

    /* Color matching */
    if (dwUIFlags & DI_COLOR)
    {
        lpPSExtDevmode->dm.useImageColorMatching = ICM_ALLOW;
    }

    /* Negative and mirror image */
    if (dwUIFlags & DI_SPECIAL)
    {
        lpPSExtDevmode->dm.bNegImage = FALSE;
        lpPSExtDevmode->dm.bMirror = FALSE;
    }

    /* Scaling */
    if (dwUIFlags & DI_SCALE)
        lpPSExtDevmode->dm.Scale = 100;

    /* Resolution */
    if (dwUIFlags & DI_RESLN)
        ResetKeywordOption(lpPSExtDevmode, lpPrinterInfo, IND_RESOLUTIONINFO);

    // Print page border
    if (dwUIFlags & DI_PRINTPAGEBORDER)
    {
       lpPSExtDevmode->dm2.bPrintPageBorder = TRUE;
    }

    // layout
    if (dwUIFlags & DI_LAYOUT)
    {
       lpPSExtDevmode->dm.layout = ONE_UP;
    }
}


/*****************************************************************************/
/*                         HandleResolutionChange                            */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   LPDRIVERINFO lpDrvinfo -- Pointer to driver info structure              */
/*                                                                           */
/* Returns:                                                                  */
/*                                                                           */
/*****************************************************************************/

VOID NEAR PASCAL HandleResolutionChange(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;
    int            CB_opt_index, PPD_opt_index;
    WORD           rc;

    /* Find out which item in the combo list was selected. */
    CB_opt_index = LOWORD(SendDlgItemMessage(hDlg, ID_RESOLUTION_CB,
                                             CB_GETCURSEL, 0, NULL)) ;
    /* Find out which option in the keyword's list was selected. */
    PPD_opt_index = LOWORD(SendDlgItemMessage(hDlg, ID_RESOLUTION_CB,
                                              CB_GETITEMDATA, CB_opt_index, 0));

    /* Update the keyword option. */
    rc = UICSetCurrentOption(lpDrvInfo, IND_RESOLUTIONINFO, PPD_opt_index,hDlg);

    if (rc == SCREENUPDATE_UICONSTRAINTS)
    {
        BuildGraphicsDlg(hDlg,lpDrvInfo, UPDATE_UICONSTRAINED);
        rc = SCREENUPDATE_ALL;  /* To fall into the next if() */
    }

    if (rc == SCREENUPDATE_CURRENT || rc == SCREENUPDATE_ALL)
    {
        ShowGraphicsDlg(hDlg, lpDrvInfo, UPDATE_UICONSTRAINED);
    }
}

/*****************************************************************************/
/*                 CHGraphicsDlg                                             */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the Graphics Features property sheet dialog box.  */
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns:                                                                  */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHGraphicsDlg(HWND hDlg, unsigned imsg, WORD wParam,
                                      LONG lParam)
{
    LPDRIVERINFO   lpDrvInfo;
    LPPSEXTDEVMODE lpPSExtDevmode;
    BOOL           result = TRUE ;
    BOOL           bChanged = FALSE;
    int            border, layout, oldOption, orientation, nBmp, nMaskBmp;

    if(lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
    {
#ifdef USEHOOKPROC
        /* Process hook function stuff */
        if(DrvProcessHookProc(&(lpDrvInfo->pDev),hDlg,imsg,wParam,lParam,
                              "HookSetup"))
        {
            return TRUE;
        }
#endif

        lpPSExtDevmode = lpDrvInfo->lpDM;
    }

    switch (imsg)
    {
        case WM_INITDIALOG:
#if 0
            if (IsWin40() && UsePropertySheet())
                lpDrvInfo=(LPDRIVERINFO)(((LPPROPSHEETPAGE)lParam)->lParam);
            else
                lpDrvInfo=(LPDRIVERINFO)lParam;
#endif
            lpDrvInfo=(LPDRIVERINFO)(((LPPROPSHEETPAGE)lParam)->lParam);
            SetWindowLong(hDlg,DWL_USER,(LPARAM)lpDrvInfo);
            lpDrvInfo->bPainting = TRUE;

            GetDecimalSeparator(decimalSeparator, sizeof(decimalSeparator));
            InitGraphicsDlg(hDlg,lpDrvInfo);
            BuildGraphicsDlg(hDlg,lpDrvInfo, UPDATE_NONUICONSTRAINED);
            ShowGraphicsDlg(hDlg,lpDrvInfo, UPDATE_NONUICONSTRAINED);
            lpDrvInfo->bPainting = FALSE;

            lpPSExtDevmode = lpDrvInfo->lpDM;
            break ;

        case WM_BUILD_DLG:
          BuildGraphicsDlg(hDlg, lpDrvInfo, wParam);
          break;

        case WM_SHOW_DLG:
          ShowGraphicsDlg(hDlg, lpDrvInfo, wParam);
          break;

        case WM_CONTEXTMENU:
            if (wParam != -1)
            {
                WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                        (DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_HELP:
            if (((LPHELPINFO) lParam)->hItemHandle != -1)
            {
                WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                        HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_NOTIFY:
            switch (NOTIFY_CODE(lParam))
            {
                case PSN_SETACTIVE:
                    if( !IsWin40() )
                    {   DWORD dwTemp = lpDrvInfo->dwUIFlags[DI_GRAPHICS];

                        // color profiles can be added or removed from the Color Management Tab in Win98.
                        // check and enable/disable Color UI.
                        if (ICMProfileInstalled((LPPRINTERINFO)lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo,
                            lpDrvInfo->pDev.lpPSExtDevmode->dm.dm.dmDeviceName))
                            dwTemp |= DI_COLOR;
                        else
                            dwTemp &= ~DI_COLOR;
                        if( lpDrvInfo->dwUIFlags[DI_GRAPHICS] != dwTemp )
                        {
                            lpDrvInfo->dwUIFlags[DI_GRAPHICS] = dwTemp;
                            ReInitGraphicsDlg(hDlg,lpDrvInfo);
                        }
                    }
                    lpDrvInfo->bPainting = TRUE;
                    BuildGraphicsDlg(hDlg,lpDrvInfo, UPDATE_UICONSTRAINED);
                    ShowGraphicsDlg(hDlg, lpDrvInfo, UPDATE_UICONSTRAINED);
                    lpDrvInfo->bPainting = FALSE;
                    break;

                case PSN_KILLACTIVE:
                    if (!CheckGraphics(lpDrvInfo,hDlg))
                    {
                        SetWindowLong(hDlg,DWL_MSGRESULT,TRUE);
                        return TRUE;
                    }
                    break;

                case PSN_APPLY:
                    if (lpDrvInfo->bChanged)
                    {
                        if (!UICCheckAllOptions(lpDrvInfo, hDlg, FALSE, 0))
                        {
                            SetWindowLong(hDlg,DWL_MSGRESULT,TRUE);
                            return TRUE;
                        }
                        UpdateGlobal(lpDrvInfo,TRUE);
                        WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
                        lpDrvInfo->bChanged = FALSE;
                    }
                    break;

                case PSN_RESET:
                    // If canceling, set lpDrvInfo->lpDM to saved devmode
                    lpDrvInfo->lpDM = &(lpDrvInfo->DMSave);
                    WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
                    break;
            }
            break;

        case WM_COMMAND:
            switch (wParam)
            {
                case ID_RESTORE_DEFAULTS:
                    RestoreGraphicsDefaults(lpDrvInfo->lpDM,
                                            lpDrvInfo->pDev.lpWPXblock,
                                            lpDrvInfo->dwUIFlags[DI_GRAPHICS]);
                    BuildGraphicsDlg(hDlg,lpDrvInfo, UPDATE_UICONSTRAINED);
                    ShowGraphicsDlg(hDlg, lpDrvInfo, UPDATE_ALL);
                    UICCheckAllOptions(lpDrvInfo, hDlg, TRUE,
                                       UPDATE_UICONSTRAINED);
                    bChanged = TRUE;
                    break;

                case ID_ABOUT:
                    DialogBoxParam(ghDriverMod,"AB",hDlg,
                                   fnAboutDlg, (LPARAM)lpDrvInfo);
                    break;

                case ID_COLOR_NO_MATCHING:
                case ID_COLOR_USE_MATCHING:
                case ID_COLOR_ALWAYSICM:
                    if( wParam == ID_COLOR_USE_MATCHING )
                       lpPSExtDevmode->dm.useImageColorMatching = ICM_ALLOW;
                    else if( wParam == ID_COLOR_ALWAYSICM )
                       lpPSExtDevmode->dm.useImageColorMatching = ICM_ALWAYS;
                    else
                       lpPSExtDevmode->dm.useImageColorMatching = ICM_DISABLE;
                    if( lpPSExtDevmode->dm.useImageColorMatching == ICM_ALLOW ||
                        lpPSExtDevmode->dm.useImageColorMatching == ICM_ALWAYS )
                       EnableWindow(GetDlgItem(hDlg, ID_COLOR_CHOOSE_METHOD), TRUE);
                    else
                       EnableWindow(GetDlgItem(hDlg, ID_COLOR_CHOOSE_METHOD), FALSE);
                    bChanged = TRUE;
                    break;

                case ID_COLOR_CHOOSE_METHOD:
                    if (DialogBoxParam(ghDriverMod,
                                       MAKEINTRESOURCE(CH_COLOR_METHOD), hDlg,
                                       CHColorDlg, (LPARAM)lpDrvInfo) == IDOK)
                        bChanged = TRUE;

                    break;

                case ID_PRINTNEGATIVE:
                case ID_PRINTMIRROR:
                    {
                        int    iconID;
                        HANDLE hicon;

                        iconID = NM_BASE_ICON +
                           (IsDlgButtonChecked(hDlg, ID_PRINTMIRROR) ? 2 : 0) +
                           (IsDlgButtonChecked(hDlg, ID_PRINTNEGATIVE) ? 1 : 0);
                        hicon = lpDrvInfo->lpGetIconResource(iconID);
                        SendDlgItemMessage(hDlg, ID_ICON_NM, STM_SETICON,
                                           (WORD)hicon, 0L);
                        bChanged = TRUE;
                    }
                    break;

                case ID_RESOLUTION_CB:
                    if (HIWORD(lParam) == CBN_SELCHANGE)
                    {
                        HandleResolutionChange(hDlg,lpDrvInfo);
                        bChanged = TRUE;
                    }
                    break ;

                case ID_SCALE:
                    if (HIWORD(lParam) == EN_CHANGE)
                        bChanged = TRUE;
                    break;

                case ID_PRINT_PAGE_BORDER:
                    if(IsDlgButtonChecked(hDlg, ID_PRINT_PAGE_BORDER))
                       lpDrvInfo->lpDM->dm2.bPrintPageBorder = TRUE;
                    else
                       lpDrvInfo->lpDM->dm2.bPrintPageBorder = FALSE;
                    ValidatePicture(hDlg,ID_GRAPHICS_PICTURE,FALSE);
                    bChanged = TRUE;
                    break;

                case ID_LAYOUTLIST:
                    oldOption = lpPSExtDevmode->dm.layout;
                    layout = LOWORD(SendDlgItemMessage(hDlg, ID_LAYOUTLIST,
                                        CB_GETCURSEL, 0, NULL));
                    if( layout != oldOption )
                    {
                       lpPSExtDevmode->dm.layout = layout;
                       EnableWindow(GetDlgItem(hDlg, ID_PRINT_PAGE_BORDER), layout>ONE_UP);
                       ValidatePicture(hDlg,ID_GRAPHICS_PICTURE,FALSE);
                       bChanged = TRUE;
                    }
                    break;

#ifndef USE_WHATSTHIS_HELP
                case ID_HELP:
                    WinHelp(hDlg, szHelpFile, HELP_CONTEXT,
                            IDH_PSCRIPT_SET_COLOR_RES);
                    break;
#endif

                default:
                    result = FALSE ;
                    break ;

            } /* switch(wParam) */
            break ;

        case WM_MEASUREITEM:
            HandleMeasureItem(hDlg, lpDrvInfo, (int)wParam,
                              (LPMEASUREITEMSTRUCT)lParam);
            break;

        case WM_DRAWITEM:
            if( wParam == ID_GRAPHICS_PICTURE )
            {
               border = lpDrvInfo->lpDM->dm2.bPrintPageBorder ? 1 : 0;
               layout = LOWORD(SendDlgItemMessage(hDlg, ID_LAYOUTLIST, CB_GETCURSEL, 0, NULL));
               orientation = lpPSExtDevmode->dm.PaperOrient == OR_PORTRAIT ? 0 : 1;
               // border only applies for 2-up to 16-up
               if( layout == ONE_UP ) border = 0;

               if( border )
                   nBmp = PAPER_HANDLING_BORDER_BMP +
                          orientation*(NUM_LAYOUTS-1) + (layout-1);
               else
                   nBmp = PAPER_HANDLING_BMP + orientation*NUM_LAYOUTS + layout;

               if( orientation )
                  nMaskBmp = PAPER_HANDLING_LANDSCAPE_MASK_BMP;
               else
                  nMaskBmp = PAPER_HANDLING_PORTRAIT_MASK_BMP;

               DrawPicture( hDlg, ID_GRAPHICS_PICTURE, nBmp, nMaskBmp, 0, 0, 0 );
            }
            else
              HandleDrawItem(hDlg, lpDrvInfo, (int)wParam,
                             (LPDRAWITEMSTRUCT)lParam);
            break;

        default:
            result = FALSE ;
            break ;
    } /* switch(imsg) */

    if (bChanged && lpDrvInfo && !lpDrvInfo->bChanged && !lpDrvInfo->bPainting)
    {
        lpDrvInfo->bChanged = TRUE;
        PropSheet_Changed( GetParent(hDlg), hDlg );
    }

    return result ;
} /* End CHGraphicsDlg */
