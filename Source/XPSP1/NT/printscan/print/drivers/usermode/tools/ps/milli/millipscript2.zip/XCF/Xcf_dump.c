/* @(#)CM_VerSion xcf_dump.c atm09 1.2 16499.eco sum= 47764 atm09.002 */
/* @(#)CM_VerSion xcf_dump.c atm08 1.5 16343.eco sum= 38966 atm08.005 */
/***********************************************************************/
/*                                                                     */
/* Copyright 1995-1996 Adobe Systems Incorporated.                     */
/* All rights reserved.                                                */
/*                                                                     */
/* Patents Pending                                                     */
/*                                                                     */
/* NOTICE: All information contained herein is the property of Adobe   */
/* Systems Incorporated. Many of the intellectual and technical        */
/* concepts contained herein are proprietary to Adobe, are protected   */
/* as trade secrets, and are made available only to Adobe licensees    */
/* for their internal use. Any reproduction or dissemination of this   */
/* software is strictly forbidden unless prior written permission is   */
/* obtained from Adobe.                                                */
/*                                                                     */
/* PostScript and Display PostScript are trademarks of Adobe Systems   */
/* Incorporated or its subsidiaries and may be registered in certain   */
/* jurisdictions.                                                      */
/*                                                                     */
/***********************************************************************/

/***********************************************************************
Original version: John Felton, April 17, 1996
************************************************************************/

/* -------------------------------------------------------------------------
     Header Includes 
  --------------------------------------------------------------------------- */

#include "xcf_pub.h"
#include "xcf_priv.h"

#define MAX_LINE_LENGTH 1024

#ifdef __cplusplus
extern "C" {
#endif

static void PutStringID(XCF_Handle h, StringID sid)
{
	char PTR_PREFIX *str;
	Card16 len;

	XCF_LookUpString(h, sid, &str, &len);
	XCF_PutData(h,(Card8 PTR_PREFIX *)str,len);
}

static void PutLine(XCF_Handle h, char PTR_PREFIX *str)
	{
	XCF_PutString(h, str);
	XCF_PutString(h, XCF_NEW_LINE);
	}

static void PutNumber(XCF_Handle h, Int32 n)
{
  char str[30];
 
  h->callbacks.sprintf(str, "%ld", n);
  XCF_PutString(h, str);
}

static void PutFixedNumber(XCF_Handle h, Fixed n)
{
	char str[30];
	
	h->callbacks.sprintf(str, "%.12lg", FIXED_TO_REAL(n));
	XCF_PutString(h,str);
}


/*
Dictionary Entries

*** Font Info Dict ***

version
Notice
FullName
FamilyName
Weight
isFixedPitch		Default = "false"
ItalicAngle			Default = 0
UnderlinePosition	Default = -100
UnderlineThickness	Default = 50
Copyright
SyntheticBase
BaseFontName
BaseFontBlend

*** Font Dict ***

FontName
Encoding			Default = StandardEncoding
PaintType			Default = 0
FontType			Default = 2
FontMatrix			Default = [0.001 0 0 0.001 0 0]
FontBBox
UniqueID
XUID
StrokeWidth			Default = 0
Private
CharStrings
BlendDesignMap
BlendAxisTypes
WeightVector

*** Private Dict ***

BlueValues				Default = [] -- Emit empty brackets if there are no BlueValues
OtherBlues
FamilyBlues
FamilyOtherBlues
StdHW
StdVW
BlueScale				Default = 0.039625
BlueShift				Default = 7
BlueFuzz				Default = 1
StemSnapH
StemSnapV
ForceBold				Default = "false"
ForceBoldThreshold		Default = 0
lenIV
LanguageGroup			Default = 0
ExpansionFactor			Default = 0.06
initialRandomSeed		Default = 0
PostScript
defaultWidthX
nominalWidthX
NDV
CDV
lenBuildCharArray
*/

static void AppendStr(XCF_Handle h, char PTR_PREFIX *dest, char PTR_PREFIX *src)
{
	Card16 destLength = h->callbacks.strlen(dest);
	Card16 srcLength = h->callbacks.strlen(src);

	h->callbacks.memcpy(&dest[destLength], src, (unsigned short int) (srcLength+1));
}

/*
static void ByteToBinaryString(XCF_Handle h, char PTR_PREFIX *dest, Card8 value)
{
	Card8 bit = 0x080;
	while (bit)
	{
		*dest++ = (bit & value) ? '1' : '0';
		bit = bit>>1;
	}
	*dest = 0;
}
*/
#define LINE_LENGTH_LIMIT	78
static void PutCharstringData(XCF_Handle h, char PTR_PREFIX *str, CardX *charsOnLine)
{
	Card16 length = h->callbacks.strlen(str);
	if ((*charsOnLine + length) > LINE_LENGTH_LIMIT)
	{
		XCF_PutString(h, XCF_NEW_LINE);
		XCF_PutString(h, "  ");
		*charsOnLine = 2;
	}
	XCF_PutData(h,(Card8 PTR_PREFIX *)str, length);
	*charsOnLine += length;
}

static void csDump (XCF_Handle h, Int32 length, Card8 *strng, Int32 nMasters,
										CardX PTR_PREFIX *charsOnLine)
	{
	static char *opname[32] =
		{
		/*  0 */ "reserved0",
		/*  1 */ "hstem",
		/*  2 */ "compose",
		/*  3 */ "vstem",
		/*  4 */ "vmoveto",
		/*  5 */ "rlineto",
		/*  6 */ "hlineto",
		/*  7 */ "vlineto",
		/*  8 */ "rrcurveto",
		/*  9 */ "closepath",
		/* 10 */ "callsubr",
		/* 11 */ "return",
		/* 12 */ "escape",
		/* 13 */ "hsbw",
		/* 14 */ "endchar",
		/* 15 */ "moveto",
		/* 16 */ "blend",
		/* 17 */ "curveto",
		/* 18 */ "hstemhm",
		/* 19 */ "hintmask",
		/* 20 */ "cntrmask",
		/* 21 */ "rmoveto",
		/* 22 */ "hmoveto",
		/* 23 */ "vstemhm",
		/* 24 */ "rcurveline",
		/* 25 */ "rlinecurve",
		/* 26 */ "vvcurveto",
		/* 27 */ "hhcurveto",
		/* 28 */ "shortint",
		/* 29 */ "callgsubr",
		/* 30 */ "vhcurveto",
		/* 31 */ "hvcurveto",
		};
	static char *escopname[] =
		{
		/*  0 */ "dotsection",
		/*  1 */ "vstem3",
		/*  2 */ "hstem3",
		/*  3 */ "and",
		/*  4 */ "or",
		/*  5 */ "not",
		/*  6 */ "seac",
		/*  7 */ "sbw",
		/*  8 */ "store",
		/*  9 */ "abs",
		/* 10 */ "add",
		/* 11 */ "sub",
		/* 12 */ "div",
		/* 13 */ "load",
		/* 14 */ "neg",
		/* 15 */ "eq",
		/* 16 */ "callother",
		/* 17 */ "pop",
		/* 18 */ "drop",
		/* 19 */ "setvw",
		/* 20 */ "put",
		/* 21 */ "get",
		/* 22 */ "ifelse",
		/* 23 */ "random",
		/* 24 */ "mul",
		/* 25 */ "div2",
		/* 26 */ "sqrt",
		/* 27 */ "dup",
		/* 28 */ "exch",
		/* 29 */ "index",
		/* 30 */ "roll",
		/* 31 */ "reservedESC31",
		/* 32 */ "reservedESC32",
		/* 33 */ "setcurrentpt",
		/* 34 */ "hflex",
		/* 35 */ "flex",
		/* 36 */ "hflex1",
		/* 37 */ "flex1",
		/* 38 */ "cntron",
		};
	Int32 single;
	Int32 stems = 0;
	Int32 args = 0;
	Int32 i = 0;
	char line[MAX_LINE_LENGTH];
	char temp[MAX_LINE_LENGTH];

	while (i < length)
		{
		IntX op = strng[i];
		switch (op)
			{
		case tx_reserved0:
		case t1_compose:
		case tx_vmoveto:
		case tx_rlineto:
		case tx_hlineto:
		case tx_vlineto:
		case tx_rrcurveto:
		case t1_closepath:
		case tx_callsubr:
		case tx_return:
		case t1_hsbw:
		case tx_endchar:
		case t1_moveto:
		case t1_curveto:
		case tx_rmoveto:
		case tx_hmoveto:
		case t2_rcurveline:
		case t2_rlinecurve:
		case t2_vvcurveto:
		case t2_hhcurveto:
		case t2_callgsubr:
		case tx_vhcurveto:
		case tx_hvcurveto:
/*			printf("%s ", opname[op]); */
			h->callbacks.sprintf(line, "%s ", opname[op]); 
			PutCharstringData(h, line, charsOnLine);
			args = 0;
			i++;
			break;
		case tx_hstem:
		case tx_vstem:
		case t2_hstemhm:
		case t2_vstemhm:
/*			printf("%s ", opname[op]); */
			h->callbacks.sprintf(line, "%s ", opname[op]);
			PutCharstringData(h, line, charsOnLine);
			stems += args / 2;
			args = 0;
			i++;
			break;
		case t2_hintmask:
		case t2_cntrmask:
			{
			Int32 bytes;
			if (args > 0)
				stems += args / 2;
			bytes = (stems + 7) / 8;
/*			printf("%s[", opname[op]); */
			h->callbacks.sprintf(line, "%s[", opname[op]);
			i++;
			while (bytes--)
			{
/*				printf("%02x", strng[i++]); */
/*				ByteToBinaryString(h, temp, strng[i++]); */
				h->callbacks.sprintf(temp, "%02x", strng[i++]);
				AppendStr(h, line, temp);
			}
/*			printf("] "); */
			AppendStr(h, line, "] ");
			PutCharstringData(h, line, charsOnLine);
			args = 0;
			break;
			}
		case tx_escape:
			{
			/* Process escaped operator */
			IntX escop = strng[i + 1];
			if (escop > ARRAY_LEN(escopname) - 1)
/*				printf("? "); */
				PutCharstringData(h, "? ", charsOnLine);
			else
			{
/*				printf("%s ", escopname[escop]); */
				h->callbacks.sprintf(line, "%s ", escopname[escop]);
				PutCharstringData(h, line, charsOnLine);
			}
			args = 0;
			i += 2;
			break;
			}
		case t2_blend:
/*			printf("%s ", opname[op]); */
			h->callbacks.sprintf(line, "%s ", opname[op]);
			PutCharstringData(h, line, charsOnLine);
			args -= single * (nMasters - 1);
			i++;
			break;
		case t2_shortint:
/*			printf("%d ", strng[i + 1]<<8|strng[i + 2]); */
			h->callbacks.sprintf(line, "%d ", strng[i + 1]<<8|strng[i + 2]);
			PutCharstringData(h, line, charsOnLine);
			args++;
			i += 3;
			break;
		case 247: 
		case 248: 
		case 249: 
		case 250:
			/* +ve 2 byte number */
/*			printf("%d ", 108 + 256 * (strng[i] - 247) + strng[i + 1]); */
			h->callbacks.sprintf(line, "%d ", 108 + 256 * (strng[i] - 247) + strng[i + 1]);
			PutCharstringData(h, line, charsOnLine);
			args++;
			i += 2;
			break;
		case 251:
		case 252:
		case 253:
		case 254:
			/* -ve 2 byte number */
/*			printf("%d ", -108 - 256 * (strng[i] - 251) - strng[i + 1]); */
			h->callbacks.sprintf(line, "%d ", -108 - 256 * (strng[i] - 251) - strng[i + 1]);
			PutCharstringData(h, line, charsOnLine);
			i += 2;
			args++;
			break;
		case 255:
			{
			/* 5 byte number */
			Int32 value = (Int32)strng[i + 1]<<24 | (Int32)strng[i + 2]<<16 |
				strng[i + 3]<<8 | strng[i + 4];
#if 0
			if (-32000 <= value && value <= 32000)
			{
/*				printf("%ld ", value); */
				h->callbacks.sprintf(line, "%ld ", value);
				PutCharstringData(h, line, charsOnLine);
			}
			else
#endif /* JUDY */
			{
/*				printf("%g ", value / 65536.0); */
				h->callbacks.sprintf(line, "%g ", value / 65536.0);
				PutCharstringData(h, line, charsOnLine);
			}
			args++;
			i += 5;
			break;
			}
		default:
			/* 1 byte number */
			single = strng[i] - 139;
/*			printf("%d ", single); */
			h->callbacks.sprintf(line, "%d ", single);
			PutCharstringData(h, line, charsOnLine);
			args++;
			i++;
			break;
			}
		}
/*	printf("\n"); */
	XCF_PutString(h, XCF_NEW_LINE);
	}

static void WriteIndexEntryAsString(XCF_Handle h, IndexDesc *desc, unsigned int index)
{
	XCF_LookUpTableEntry(h, desc, index);
	XCF_PutString(h, "[");
	PutNumber(h, index);
	XCF_PutString(h, "] = ");
	XCF_PutData(h, h->inBuffer.start, h->inBuffer.blockLength);
}

#define MAX_CSTR_LINE_LENGTH 500
static void WriteIndexEntryAsCharstring(XCF_Handle h, IndexDesc *desc,
																				unsigned int index, boolean subrs)
{
	char cstr[MAX_CSTR_LINE_LENGTH];
  char line[MAX_LINE_LENGTH];
	unsigned short int length;
  CardX charsOnLine = 0;

	XCF_LookUpTableEntry(h, desc, index);
	length = (unsigned short int) MIN(h->inBuffer.blockLength, MAX_CSTR_LINE_LENGTH);
	h->callbacks.memcpy(cstr, h->inBuffer.start, length);

	PutCharstringData(h, "[", &charsOnLine);
	h->callbacks.sprintf(line, "%d", index);
	PutCharstringData(h, line, &charsOnLine);
	PutCharstringData(h, "] ", &charsOnLine);
	
	if (!subrs)
  {
    if (CIDFONT)
		{
		  char str[50];
		  h->callbacks.sprintf(str,"{%ld:%ld}",
			  (long int)XCF_GetFDIndex(h, (Int32)(index)),
			  index? (long int)h->type1.pCharset[index-1]: 0);
		  PutCharstringData(h, str, &charsOnLine);
	  }
	  else if (index)
		{
      char PTR_PREFIX *str;
      Card16 len;
			XCF_LookUpString(h, h->type1.pCharset[index-1], &str, &len);
			XCF_PutData(h,(Card8 PTR_PREFIX *)str,len);
			charsOnLine += len;
		}
	 else
		  PutCharstringData(h, ".notdef", &charsOnLine);
  }

	PutCharstringData(h, " = ", &charsOnLine);

	csDump(h, length, (Card8 *)cstr, h->dict.numberOfMasters ? h->dict.numberOfMasters :
1, &charsOnLine);
}

static void StartSection(XCF_Handle h, char PTR_PREFIX *sectionName, boolean global, char *extra)
{
	XCF_PutString(h, XCF_NEW_LINE "@");
	XCF_PutString(h, sectionName);
	if (!global)
	{
		XCF_PutString(h, " <");
		XCF_LookUpTableEntry(h, &h->fontSet.fontNames, h->fontSet.fontIndex);
		XCF_PutData(h, h->inBuffer.start, h->inBuffer.blockLength);
		XCF_PutString(h, ">");
	}
	if (extra != NULL)
		XCF_PutString(h, extra);
	XCF_PutString(h, XCF_NEW_LINE);
}

static void DumpStringIndex(XCF_Handle h)
{
	unsigned int index = 0;

	StartSection(h, "STRING INDEX", true, NULL);
	for (index=0; index  < h->fontSet.strings.count; ++index)
	{
		XCF_PutString(h, "SID(");
		PutNumber(h, (Card32) index + h->fontSet.stringIDBias);
		XCF_PutString(h, ")=<");
    XCF_LookUpTableEntry(h, &h->fontSet.strings, index);
	  XCF_PutData(h, h->inBuffer.start, h->inBuffer.blockLength);
		XCF_PutString(h, ">" XCF_NEW_LINE);
	}
}

static void DumpFontNameIndex(XCF_Handle h, int	dumpCompleteFontSet)
{
	unsigned int index = 0;

	StartSection(h, "FONT NAME INDEX", true, NULL);
	if (dumpCompleteFontSet)
	{
		for (index=0; index  < h->fontSet.fontNames.count; ++index)
		{
			WriteIndexEntryAsString(h, &h->fontSet.fontNames, index);
			XCF_PutString(h, XCF_NEW_LINE);
		}
	}
	else
	{
		WriteIndexEntryAsString(h, &h->fontSet.fontNames, h->fontSet.fontIndex);
		XCF_PutString(h, XCF_NEW_LINE);
	}
}


static void DumpHeader(XCF_Handle h)
{
	StartSection(h, "HEADER", true, NULL);
	XCF_PutString(h, "MajorVersion = ");
	PutNumber(h, (Card32) h->fontSet.majorVersion);
	XCF_PutString(h, XCF_NEW_LINE);
	XCF_PutString(h, "MinorVersion = ");
	PutNumber(h, (Card32) h->fontSet.minorVersion);
	XCF_PutString(h, XCF_NEW_LINE);
	XCF_PutString(h, "HeaderSize = ");
	PutNumber(h, (Card32) h->fontSet.headerSize);
	XCF_PutString(h, XCF_NEW_LINE);
	XCF_PutString(h, "OffsetSize = ");
	PutNumber(h, (Card32) h->fontSet.offsetSize);
	XCF_PutString(h, XCF_NEW_LINE);
}

	
static void PrintMissing(XCF_Handle h, char *defaultValue)
{
	if (defaultValue[0])
	{
		XCF_PutString(h, defaultValue);
		XCF_PutString(h, " (default)");
	}
	XCF_PutString(h, XCF_NEW_LINE);
}

static void WriteFontMatrix(XCF_Handle h, char *name, char PTR_PREFIX
														(*matrix)[FONT_MATRIX_ENTRY_SIZE], IntX count, char
														*defaultValue)
{
	IntX i;
	if ((!count) && (!defaultValue[0]))
		return;

	XCF_PutString(h, name);
	XCF_PutString(h, " = ");

	if (!count)
	{
		PrintMissing(h, defaultValue);
		return;
	}

	for (i=0; i < count; ++i)
	{
    XCF_PutString(h, matrix[i]);
    XCF_PutString(h, " ");
  }
  XCF_PutString(h, XCF_NEW_LINE);
}

static void WriteDictSIDLine(XCF_Handle h, char *name, Card32 sid[], IntX count, char *defaultValue)
{
	IntX i;
	if ((!count) && (!defaultValue[0]))
		return;

	XCF_PutString(h, name);
	XCF_PutString(h, " = ");

	if (!count)
	{
		PrintMissing(h, defaultValue);
		return;
	}

	for (i=0; i < count; ++i)
	{
		PutStringID(h, (StringID)sid[i]);
/*
		if (count > 1)
		{
			XCF_PutString(h, " (SID = ");
			PutNumber(h, sid[i]);
			XCF_PutString(h, ") ");
		}
		else
		{
			XCF_PutString(h, " // SID = ");
			PutFixedNumber(h, sid[i]);
		}
*/
	}
	XCF_PutString(h, XCF_NEW_LINE);
}

static void WriteDictIntLine(XCF_Handle h, char *name, Int32 numbers[],
														 IntX count, char *defaultValue)
{
  IntX i;

  if (!count && !defaultValue[0])
    return;

	XCF_PutString(h, name);
	XCF_PutString(h, " = ");

	if (!count)
	{
		PrintMissing(h, defaultValue);
		return;
	}

  for (i = 0; i < count; i++)
  {
    PutNumber(h, numbers[i]);
    XCF_PutString(h, " ");
  }
  XCF_PutString(h, XCF_NEW_LINE);
}

static void WriteDictFracLine(XCF_Handle h, char *name, Frac numbers[], IntX
															count, boolean delta, char *defaultValue)
{
  Frac number;
  Frac value[MAX_RASTERIZER_STACK_SIZE] = {0};
  IntX masterIx = 0;
	IntX i;
  char str[30];

	if ((!count) && (!defaultValue[0]))
		return;

	XCF_PutString(h, name);
	XCF_PutString(h, " = ");

	if (!count)
	{
		PrintMissing(h, defaultValue);
		return;
	}
	for (i=0; i < count; ++i)
	{
		if (delta)
    {
			number = numbers[i] + value[masterIx];
  		value[masterIx++] = number;
      if (masterIx >= h->dict.numberOfMasters)
        masterIx = 0;
    }
		else
			number = numbers[i];
		XCF_Fixed2CString(number, str, 7, true);
    XCF_PutString(h, str);
		XCF_PutString(h, " ");
	}
	XCF_PutString(h, XCF_NEW_LINE);
}

static void WriteDictNumberLine(XCF_Handle h, char *name, Fixed numbers[], IntX count, boolean delta, char *defaultValue)
{
	Fixed number;
  Fixed value[MAX_RASTERIZER_STACK_SIZE] = {0};
  IntX masterIx = 0;
	IntX i;

	if ((!count) && (!defaultValue[0]))
		return;

	XCF_PutString(h, name);
	XCF_PutString(h, " = ");

	if (!count)
	{
		PrintMissing(h, defaultValue);
		return;
	}

	for (i=0; i < count; ++i)
	{
		if (delta)
    {
			number = numbers[i] + value[masterIx];
  		value[masterIx++] = number;
      if (masterIx >= h->dict.numberOfMasters)
        masterIx = 0;
    }
		else
			number = numbers[i];
		PutFixedNumber(h, number);
		XCF_PutString(h, " ");
	}
	XCF_PutString(h, XCF_NEW_LINE);
}

static void WriteDictBooleanLine(XCF_Handle h, char *name, Fixed values[], IntX count, char *defaultValue)
{
	IntX i;

	if ((!count) && (!defaultValue[0]))
		return;

	XCF_PutString(h, name);
	XCF_PutString(h, " = ");

	if (!count)
	{
		PrintMissing(h, defaultValue);
		return;
	}

	for (i=0; i < count; ++i)
	{

		if (values[i])
			XCF_PutString(h, "true ");
		else
			XCF_PutString(h, "false ");
	}
	XCF_PutString(h, XCF_NEW_LINE);
}

static void DumpPrivateDict(XCF_Handle h, char *extra)
{
	StartSection(h, "PRIVATE DICTIONARY", false, extra);

	WriteDictNumberLine(h, "BlueValues", h->dict.blueValues, h->dict.blueValuesCount, true, "");
	WriteDictNumberLine(h, "OtherBlues", h->dict.otherBlues, h->dict.otherBluesCount, true, "");
	WriteDictNumberLine(h, "FamilyBlues", h->dict.familyBlues, h->dict.familyBluesCount, true, "");
	WriteDictNumberLine(h, "FamilyOtherBlues", h->dict.familyOtherBlues, h->dict.familyOtherBluesCount, true, "");

	WriteDictFracLine(h, "BlueScale", h->dict.blueScale, h->dict.blueScaleCount, true, "0.039625");
	WriteDictNumberLine(h, "BlueShift", h->dict.blueShift, h->dict.blueShiftCount, true, "7");
	WriteDictNumberLine(h, "BlueFuzz", h->dict.blueFuzz, h->dict.blueFuzzCount, true, "1");
	WriteDictBooleanLine(h, "ForceBold", h->dict.forceBold, h->dict.forceBoldCount, "false");
	WriteDictNumberLine(h, "StdHW", h->dict.stdHW, h->dict.stdHWCount, true, "");
	WriteDictNumberLine(h, "StdVW", h->dict.stdVW, h->dict.stdVWCount, true, "");
	WriteDictNumberLine(h, "ForceBoldThreshold", &h->dict.forceBoldThreshold, h->dict.forceBoldThresholdCount, false, "0");
	WriteDictIntLine(h, "LanguageGroup", (Int32 *)&h->dict.languageGroup, h->dict.languageGroupCount, "0");
	WriteDictFracLine(h, "ExpansionFactor", &h->dict.expansionFactor, h->dict.expansionFactorCount, false, "0.06");
	WriteDictNumberLine(h, "initialRandomSeed", &h->dict.initialRandomSeed, h->dict.initialRandomSeedCount, false, "0");
	WriteDictNumberLine(h, "defaultWidthX", &h->dict.defaultWidthX, h->dict.defaultWidthXCount, false, "");
	WriteDictNumberLine(h, "nominalWidthX", &h->dict.nominalWidthX, h->dict.nominalWidthXCount, false, "");
	WriteDictIntLine(h, "lenIV", &h->dict.lenIV, h->dict.lenIVCount, "-1");		
	WriteDictIntLine(h, "lenBuildCharArray", &h->dict.lenBuildCharArray, h->dict.lenBuildCharArrayCount, "");

	if (h->dict.embeddedPostscriptCount)
	{
		PutLine(h, "EmbeddedPostScript = ");
		PutStringID(h, (StringID)h->dict.embeddedPostscript);
		XCF_PutString(h, XCF_NEW_LINE);
		PutLine(h, "End EmbeddedPostScript");
	}

}


static void DumpFontDict(XCF_Handle h, char *extra)
{
	StartSection(h, "FONT DICTIONARY", false, extra);

	WriteDictSIDLine(h, "Notice", &h->dict.notice, h->dict.noticeCount, "");
	WriteDictSIDLine(h, "Copyright", &h->dict.copyright, h->dict.copyrightCount, "");
	WriteDictSIDLine(h, "version", &h->dict.version, h->dict.versionCount, "");
	WriteDictSIDLine(h, "FullName", &h->dict.fullName, h->dict.fullNameCount, "");
	WriteDictSIDLine(h, "FamilyName", &h->dict.familyName, h->dict.familyNameCount, "");
	WriteDictSIDLine(h, "BaseFontName", &h->dict.baseFontName, h->dict.baseFontNameCount, "");
	WriteDictNumberLine(h, "BaseFontBlend", h->dict.baseFontBlend, h->dict.baseFontBlendCount, false, "");
	WriteDictSIDLine(h, "Weight", &h->dict.weight, h->dict.weightCount, "");
	WriteDictNumberLine(h, "ItalicAngle", h->dict.italicAngle, h->dict.italicAngleCount, true, "0");
	WriteDictBooleanLine(h, "isFixedPitch", h->dict.isFixedPitch, h->dict.isFixedPitchCount, "false");
	WriteDictNumberLine(h, "UnderlinePosition", h->dict.underlinePosition, h->dict.underlinePositionCount, true, "-100");
	WriteDictNumberLine(h, "UnderlineThickness", h->dict.underlineThickness, h->dict.underlineThicknessCount, true, "50");
	WriteDictSIDLine(h, "BlendAxisTypes", h->dict.blendAxisTypes, h->dict.blendAxisTypesCount, "");

	WriteDictNumberLine(h, "PaintType", &h->dict.paintType, h->dict.paintTypeCount, false, "0");
	WriteDictIntLine(h, "FontType", &h->dict.fontType, h->dict.fontTypeCount, "2");
	WriteDictNumberLine(h, "WeightVector", h->dict.weightVector, h->dict.numberOfMasters, false, "");
	WriteFontMatrix(h, "FontMatrix", h->dict.fontMatrix, h->dict.fontMatrixCount,  "0.001 0 0 0.001 0 0");
	WriteDictNumberLine(h, "FontBBox", h->dict.fontBBox, h->dict.fontBBoxCount, false, "");
	WriteDictIntLine(h, "UniqueID", (Int32 *)&h->dict.uniqueID, h->dict.uniqueIDCount, "");
	WriteDictIntLine(h, "XUID", (Int32 *)&h->dict.xUID, h->dict.xUIDCount, "");
	WriteDictNumberLine(h, "StrokeWidth", h->dict.strokeWidth, h->dict.strokeWidthCount, true, "0");
	WriteDictNumberLine(h, "SyntheticBase", &h->dict.syntheticBase, h->dict.syntheticBaseCount, false, "");

}

static void DumpCIDFontDict(XCF_Handle h, char *extra)
{
	StartSection(h, "FONT DICTIONARY", false, extra);

	WriteDictSIDLine(h, "version", &h->dict.version, h->dict.versionCount, "");
	WriteDictIntLine(h, "CIDFontType", (Int32 *)&h->dict.uniqueID, h->dict.uniqueIDCount, "");
	
	WriteDictSIDLine(h, "Registry", &h->dict.ROS[0], h->dict.ROSCount == 3, "");
	WriteDictSIDLine(h, "Ordering", &h->dict.ROS[1], h->dict.ROSCount == 3, "");
	WriteDictIntLine(h, "Supplement", (Int32 *)&h->dict.ROS[2], h->dict.ROSCount == 3, "");
	
	WriteDictNumberLine(h, "FontBBox", h->dict.fontBBox, h->dict.fontBBoxCount, false, "");
	
	WriteDictIntLine(h, "UIDBase", (Int32 *)&h->dict.uidBase, h->dict.uidBaseCount, "");
	WriteDictIntLine(h, "XUID", (Int32 *)&h->dict.xUID, h->dict.xUIDCount, "");
	
	WriteDictSIDLine(h, "Notice", &h->dict.notice, h->dict.noticeCount, "");
	WriteDictSIDLine(h, "Copyright", &h->dict.copyright, h->dict.copyrightCount, "");
	WriteDictSIDLine(h, "FullName", &h->dict.fullName, h->dict.fullNameCount, "");
	WriteDictSIDLine(h, "FamilyName", &h->dict.familyName, h->dict.familyNameCount, "");
	WriteDictSIDLine(h, "BaseFontName", &h->dict.baseFontName, h->dict.baseFontNameCount, "");
	WriteDictNumberLine(h, "BaseFontBlend", h->dict.baseFontBlend, h->dict.baseFontBlendCount, false, "");

	WriteDictIntLine(h, "CIDCount", &h->dict.cidCount, h->dict.cidCountCount, "");
}

static Offset ReadTableInfo(XCF_Handle h, Offset pos, IndexDesc PTR_PREFIX *pIndex)
{
	XCF_ReadBlock(h, pos, 2);
	pIndex->count = XCF_Read2(h);
	if (pIndex->count == 0)
	{
		pIndex->offsetSize = 1;
		pIndex->offsetArrayOffset = 0;
		pIndex->dataOffset = 0;
		return pos + 2;
	}

	XCF_ReadBlock(h, pos + 2, 1);
	pIndex->offsetSize = XCF_Read1(h);
	if ((pIndex->offsetSize == 0) || (pIndex->offsetSize > 4))
		XCF_FATAL_ERROR(h, XCF_InvalidOffsetSize, "Invalid offset size in table.", pIndex->offsetSize);
	pIndex->offsetArrayOffset = pos + 3;
	pIndex->dataOffset = pIndex->offsetArrayOffset + ((pIndex->count+1)*pIndex->offsetSize) - 1;;
	XCF_LookUpTableEntry(h, pIndex, pIndex->count-1);
	return h->inBuffer.blockOffset + h->inBuffer.blockLength; 
}

static Card16 CalculateSubrBias(CardX subrCount)
{
	if (subrCount < 1240)
		return(107);
	else if (subrCount < 33900)
		return(1131); 
		return(32768);
}

static void DumpLocalSubrIndex(XCF_Handle h)
{
	unsigned int index = 0;

	StartSection(h, "LOCAL SUBR INDEX", false, NULL);
	for (index=0; index  < h->dict.localSubrs.count; ++index)
	{
		WriteIndexEntryAsCharstring(h, &h->dict.localSubrs, index, true);
	}
}

static enum XCF_Result ReadAndDumpCIDFontDicts(XCF_Handle h)
	{
	/* some code stolen from Process_CIDFont */
	Card8 offSize;
	Offset index;
	Offset dataStart;
	Card32 dictOffset;
	Card32 nextdictOffset;
	Card32 dictLength;
	Card16 fd;
	char extra[50];
	
	/* must have 1 offset to FontDict */
	if (h->dict.cidFDArrayCount != 1)
		return XCF_InvalidCIDFont;
		
	XCF_ReadBlock(h, (Offset) h->dict.cidFDArray, 3);
	h->type1.cid.fdCount = XCF_Read2(h);
	offSize = XCF_Read1(h);
	
	if (h->type1.cid.fdCount > MAX_FD)
		XCF_FATAL_ERROR(h, XCF_InvalidCIDFont, "too many FDs", h->type1.cid.fdCount);
	
	/* We can avoid reading the first offset, which is 1. */
	index = (Offset) h->dict.cidFDArray + 3 + offSize;
	dataStart = index + (offSize * h->type1.cid.fdCount) - 1;
	dictOffset = 1;
		
	h->callbacks.sprintf(extra, " <%ld>", (long int)h->type1.cid.fdCount);
	StartSection(h, "FDARRAY", false, extra);

	for (fd = 0; fd < h->type1.cid.fdCount ; ++fd)
		{
		char extra[100];
		char PTR_PREFIX *str;
		Card16 len;
		char dictname[100];
		
		/* Clear dictionary data before filling. */
		h->callbacks.memset(&h->dict, 0, sizeof(DictEntriesStruct));
		/* Read next Offset */
		XCF_ReadBlock(h, index, offSize);
		nextdictOffset = XCF_Read(h, offSize);
		index += offSize;
		
		/* Read dict */
		dictLength = nextdictOffset - dictOffset;
		XCF_ReadBlock(h, dataStart + dictOffset, dictLength);
		
		/* Process font dict */
		XCF_ReadDictionary(h);

    /* Process Private dict */
		XCF_ReadBlock(h, h->fontSet.fontPrivDictInfo.offset,
                  h->fontSet.fontPrivDictInfo.size);
		XCF_ReadDictionary(h);
    if (h->dict.subrsCount != 0)
    {
      /* The local subrs offset is relative to the private dict data. */
		  ReadTableInfo(h,
               (Offset) (h->dict.subrs + h->fontSet.fontPrivDictInfo.offset),
               &h->dict.localSubrs);
      h->dict.localSubrBias = CalculateSubrBias(h->dict.localSubrs.count);
    }

		/* Advance to next index element */
		dictOffset = nextdictOffset;

		XCF_LookUpString(h, (StringID) h->dict.fdFontName, &str, &len);
		h->callbacks.memcpy(dictname, str, len);
		dictname[len] = '\0';
		h->callbacks.sprintf(extra, " <%ld:%s>", (long int)fd, dictname);
		DumpFontDict(h, extra);
		DumpPrivateDict(h, extra);
  	DumpLocalSubrIndex(h);
		}
	return XCF_Ok;
	}

static void DumpCharStringIndex(XCF_Handle h)
{
	unsigned int index = 0;

	StartSection(h, "CHARSTRING INDEX", false, NULL);
	for (index=0; index  < h->fontSet.charStrings.count; ++index)
	{
		WriteIndexEntryAsCharstring(h, &h->fontSet.charStrings, index, false);
	}
}

static void DumpDesignVector(XCF_Handle h, char PTR_PREFIX *name, StringID sid)
{
  char PTR_PREFIX *str;
  Card16 length;
  CardX charsOnLine = 0;

  StartSection(h, name, false, NULL);
  XCF_LookUpString(h, sid, &str, &length);
  csDump(h, length, (Card8 *)str,
         h->dict.numberOfMasters ? h->dict.numberOfMasters : 1, &charsOnLine);
}

static void DumpGlobalSubrIndex(XCF_Handle h)
{
	unsigned int index = 0;

	StartSection(h, "GLOBAL SUBR INDEX", true, NULL);
	for (index=0; index  < h->fontSet.globalSubrs.count; ++index)
	{
		WriteIndexEntryAsCharstring(h, &h->fontSet.globalSubrs, index, true);
	}
}

static void DumpEncoding(XCF_Handle h)
{
	char str[50];
	CardX i;

	StartSection(h, "ENCODING", false, NULL);

	if ((!h->dict.encodingCount) || (h->dict.encoding == cff_StandardEncoding))
		XCF_PutString(h, "<STANDARD ENCODING>" XCF_NEW_LINE);
	else if (h->dict.encoding == cff_ExpertEncoding)
		XCF_PutString(h, "<EXPERT ENCODING>" XCF_NEW_LINE);
	else
	{
		for (i=0;i<256;++i)
		{
			if (h->type1.pEncoding[i] != NOTDEF_SID)
			{
				h->callbacks.sprintf(str,"[%ld] = ",(long int)i);
				XCF_PutString(h, str);
				PutStringID(h, h->type1.pEncoding[i]);
				XCF_PutString(h, XCF_NEW_LINE);
			}
		}
	}
}

static void DumpCharset(XCF_Handle h)
{
	char str[50];
	CardX i;

	StartSection(h, CIDFONT ? "CID-CHARSET" : "CHARSET", false, NULL);

	if (CIDFONT)
		{
    /* Output the notdef character, which is always required. */
    XCF_PutString(h, "     0");
		for (i=0;i<h->type1.charsetSize;++i)
			{
				if (i % 10 == 0)
					XCF_PutString(h, XCF_NEW_LINE);
				h->callbacks.sprintf(str,"%6ld",(long int)h->type1.pCharset[i]);
				XCF_PutString(h, str);
			}
		XCF_PutString(h, XCF_NEW_LINE);
		}
	else if ((!h->dict.charsetCount) || (h->dict.charset == cff_ISOAdobeCharset))
		XCF_PutString(h, "<ISO ADOBE>" XCF_NEW_LINE);
	else if (h->dict.charset == cff_ExpertCharset)
		XCF_PutString(h, "<EXPERT>" XCF_NEW_LINE);
	else if (h->dict.charset == cff_ExpertSubsetCharset)
		XCF_PutString(h, "<EXPERT SUBSET>" XCF_NEW_LINE);
	else
	{
		for (i=0;i<h->type1.charsetSize;++i)
		{
			h->callbacks.sprintf(str,"[%ld] = ",(long int)i);
			XCF_PutString(h, str);
			PutStringID(h, h->type1.pCharset[i]);
			XCF_PutString(h, XCF_NEW_LINE);
		}
	}
}

void XCF_DumpFontSpecificCFFSections(XCF_Handle h)
{
	char fontName[200];
	unsigned short int length;

	XCF_LookUpTableEntry(h, &h->fontSet.fontNames, h->fontSet.fontIndex);
	length = (unsigned short int) MIN(199, h->inBuffer.blockLength);
	h->callbacks.memcpy(fontName, h->inBuffer.start, length);
	fontName[length] = 0;

	if (CIDFONT)
		{
		DumpCIDFontDict(h, " <TOP-LEVEL>");
		ReadAndDumpCIDFontDicts(h);
		/* note no encoding is emitted */
		}
	else
		{
		DumpFontDict(h, NULL);
		DumpPrivateDict(h, NULL);
  	DumpLocalSubrIndex(h);
		DumpEncoding(h);
		}
		
	DumpCharset(h);
  if (h->dict.numberOfMasters)
  {
    DumpDesignVector(h, "NDV", h->dict.ndv);
    DumpDesignVector(h, "CDV", h->dict.cdv);
  }
	DumpCharStringIndex(h);
}
	
void XCF_DumpGlobalCFFSections(
						XCF_Handle h,								/* In */
						int	dumpCompleteFontSet)					/* In */
{
	DumpHeader(h);
	DumpFontNameIndex(h, dumpCompleteFontSet);
	DumpStringIndex(h);
	DumpGlobalSubrIndex(h);

}

#ifdef __cplusplus
}
#endif
