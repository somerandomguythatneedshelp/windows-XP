/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: TFLAVORS.C                                                   */
/*                                                                           */
/* Description: This module contains the functions for                       */
/*                                                                           */
/*  Change History :                                                         */
/*                                                                           */
/*  L3_MASK  -- Support level3 masked images.   9/23/96   jjia               */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
// L3_MASK
#include "tmask.h"

#pragma code_seg(_TSTARTSEG)


/*****************************************************************************
*
*                       AssignDLLTokens
*
* Function:    This is for DLL assignment of tokens into the DRVR translate side.
*
* Called:      VOID FAR PASCAL FlavorOfPostScript(LPPDEVICE lppd, short Flavor)
*
* Parameters:  LPPDEVICE lppd 
*              short     Flavor
*
* Returns:      RC_ok means good pointers; RC_fail means 
*               one of the GetProcAddress's failed
*
*****************************************************************************/

VOID FAR PASCAL FlavorOfPostScript(LPPDEVICE lppd, short Flavor)
{
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;


// Perform the default function assignments. This covers the
// case Printer PostScript - Level1
//
// PPSLEVEL1

       tempptr->rTPen               = TPen               ;
       tempptr->rTPenCap            = TPenCap            ;
       tempptr->rTPenFGColor        = TPenFGColor        ;
       tempptr->rTPenBGColor        = TPenBGColor        ;
       tempptr->rTPenJoin           = TPenJoin           ;
       tempptr->rTPenMiterLimit     = TPenMiterLimit     ;
       tempptr->rTPenStyle          = TPenStyle          ;
       tempptr->rTPenWidth          = TPenWidth          ;

       tempptr->rTBrushBGColor      = TBrushBGColor      ;
       tempptr->rTBrushFGColor      = TBrushFGColor      ;
       tempptr->rTBrushHatch        = TBrushHatch        ;
       tempptr->rTBrushPattern      = TBrushPattern      ;
       tempptr->rTBrushStyle        = TBrushStyle        ;

       tempptr->rTArc               = TArc               ;
       tempptr->rTChord             = TChord             ;
       tempptr->rTEllipse           = TEllipse           ;
       tempptr->rTCircle            = TCircle            ;
       tempptr->rTLine              = TLine              ;
       tempptr->rTPie               = TPie               ;
       tempptr->rTPolygon           = TPolygon           ;
       tempptr->rTPolyLine          = TPolyLine          ;
       tempptr->rTPolyBezier        = TPolyBezier        ;
       tempptr->rTRectangle         = TRectangle         ;
       tempptr->rTRoundRectangle    = TRoundRectangle    ;
       tempptr->rTScanLine          = TScanLine          ;
       tempptr->rTScanLineBegin     = TScanLineBegin     ;
       tempptr->rTScanLineEnd       = TScanLineEnd       ;
       tempptr->rTPolyMode          = TPolyMode          ;

       tempptr->rTBMOpaqueBox       = TBMOpaqueBox       ;
       tempptr->rTOpaqueBox         = TOpaqueBox         ;

#ifndef ADOBEPS42
       tempptr->rTBitmapHeader      = TBitmapHeader      ;
       tempptr->rTBitmapOperator    = TBitmapOperator    ;
       tempptr->rTBitmapData        = TBitmapData        ;
       tempptr->rTDIBHeader         = TDIBHeader         ;
       tempptr->rTDIBDataBits       = TDIBDataBits       ;
       tempptr->rTDIBOperator       = TDIBOperator       ;
#else
       tempptr->rTBitmapHeader      = TBitmapHeader2     ;
       tempptr->rTBitmapOperator    = TBitmapOperator2   ;
       tempptr->rTBitmapData        = TBitmapData2       ;
       tempptr->rTDIBHeader         = TDIBHeader2        ;
       tempptr->rTDIBDataBits       = TDIBDataBits2      ;
       tempptr->rTDIBOperator       = TDIBOperator2      ;
#endif
       tempptr->rTGrayTable         = TGrayTable         ;
       tempptr->rTColorTable        = TColorTable        ;
//L3_MASK
       tempptr->rTDIBClipRgns       = TDIBClipRgns       ;

       tempptr->rTDriverData        = TDriverData        ;
       tempptr->rTDocumentPageBegin = TDocumentPageBegin ;
       tempptr->rTDocumentPageEnd   = TDocumentPageEnd   ;
       tempptr->rTDocumentAbort     = TDocumentAbort     ;
       tempptr->rTDocumentEnd       = TDocumentEnd       ;
       tempptr->rTDocumentFlush     = TDocumentFlush     ;
       tempptr->rTDocumentBegin     = TDocumentBegin     ;
       tempptr->rTClipRect          = TClipRect          ;
       tempptr->rTClipEnd           = TClipEnd           ;
       tempptr->rTJobType           = TJobType           ;
       tempptr->rTJobTitle          = TJobTitle          ;
       tempptr->rTJobCopies         = TJobCopies         ;
       tempptr->rTJobDuplex         = TJobDuplex         ;
       tempptr->rTBackgroundMode    = TBackgroundMode    ;
       tempptr->rTColorBG           = TColorBG           ;
       tempptr->rTArcDirection      = TArcDirection      ;

       tempptr->rTRawPrinterStart   = TRawPrinterStart   ;
       tempptr->rTRawPrinterData    = TRawPrinterData    ;
       tempptr->rTRawPrinterEnd     = TRawPrinterEnd     ;

       tempptr->rTTextBegin         = TTextBegin         ;
       tempptr->rTTextRun           = TTextRun           ;
       tempptr->rTTextEnd           = TTextEnd           ;
       tempptr->rTSoftFontLoad      = TSoftFontLoad      ;
#ifdef ADD_EURO
       tempptr->rTDeviceFontLoad    = TDeviceFontLoad    ;
#endif
       tempptr->rTPageOrientation   = TPageOrientation   ;
       tempptr->rTPaperSource       = TPaperSource       ;
       tempptr->rTPaperSize         = TPaperSize         ;
       tempptr->rTMSRectHack        = TMSRectHack        ;
       tempptr->rTClipPath          = TClipPath          ;
       tempptr->rTEndPath           = TEndPath           ;
       tempptr->rTCTMSaveRestore    = TCTMSaveRestore    ;
       tempptr->rTCTMTransform      = TCTMTransform      ;
       tempptr->rTClipBox           = TClipBox           ;
       tempptr->rTICMColor          = TICMColor          ;


       tempptr->rTSetScreenFrequency = TSetScreenFrequency; 
       tempptr->rTSetScreenAngle     = TSetScreenAngle;       

// Aldus' specific escapes
   tempptr->rTSetGDIXForm          = TSetGDIXForm ; 
   tempptr->rTDownLoadHeader       = TDownLoadHeader; 


// The defaults have been assigned. If Printer PostScript Level2 is desired
// only the functions which are different from the defaults need to be assigned.

#ifndef ADOBEPS42
     if(Flavor==PPSLEVEL2)
     {
       tempptr->rTBitmapHeader      = TBitmapHeader2     ;
       tempptr->rTBitmapOperator    = TBitmapOperator2   ;
       tempptr->rTBitmapData        = TBitmapData2       ;


     // Use Level 2 functions for DIBs too          
     //  added on 28-Jan-1993  -by- [olegs]
       tempptr->rTDIBHeader         = TDIBHeader2        ;
       tempptr->rTDIBDataBits       = TDIBDataBits2      ;
       tempptr->rTDIBOperator       = TDIBOperator2      ;

     }

// The defaults have been assigned. If EPS Level1 is desired only the functions
// which are different from the defaults need to be assigned.

     if(Flavor==EPSLEVEL1)
     {
       tempptr->rTDocumentBegin     = TDocumentBeginEPS  ;
       tempptr->rTDocumentEnd       = TDocumentEndEPS    ;
       tempptr->rTDocumentPageBegin = TDocumentPageBeginEPS;
       tempptr->rTSoftFontLoad      = TSoftFontLoad      ;
//    tempptr->rTSoftFontLoad      = TSoftFontLoadEPS   ;// This is a noop function.
                                                                      // Keeps *.pfb files out of
                                                                      // EPS files .. per legal.
       tempptr->rTJobCopies         = TJobCopiesEPS      ;// The following should
       tempptr->rTJobDuplex         = TJobDuplexEPS      ;// not be done for EPS
       tempptr->rTPaperSource       = TPaperSourceEPS    ;// Hence noops.
       tempptr->rTPaperSize         = TPaperSizeEPS      ;
       tempptr->rTPageOrientation   = TPageOrientationEPS;
     }
#endif

// The defaults have been assigned. If EPS Level2 is desired only the functions
// which are different from the defaults need to be assigned.

     if(Flavor==EPSLEVEL2)
     {
       tempptr->rTDocumentBegin     = TDocumentBeginEPS  ;
       tempptr->rTDocumentEnd       = TDocumentEndEPS    ;
       tempptr->rTDocumentPageBegin = TDocumentPageBeginEPS;

#ifndef ADOBEPS42
       tempptr->rTBitmapHeader      = TBitmapHeader2     ;
       tempptr->rTBitmapOperator    = TBitmapOperator2   ;
       tempptr->rTBitmapData        = TBitmapData2       ;

     // Use Level 2 functions for DIBs too          
     //  added on 28-Jan-1993  -by- [olegs]

       tempptr->rTDIBHeader         = TDIBHeader2        ;
       tempptr->rTDIBDataBits       = TDIBDataBits2      ;
       tempptr->rTDIBOperator       = TDIBOperator2      ;
#endif

       tempptr->rTSoftFontLoad      = TSoftFontLoad      ;
//    tempptr->rTSoftFontLoad      = TSoftFontLoadEPS   ;// This is a noop function.
                                                                      // Keeps *.pfb files out of
                                                                      // EPS files .. per legal.
       tempptr->rTJobCopies         = TJobCopiesEPS      ;// The following should
       tempptr->rTJobDuplex         = TJobDuplexEPS      ;// not be done for EPS
       tempptr->rTPaperSource       = TPaperSourceEPS    ;// Hence noops.
       tempptr->rTPaperSize         = TPaperSizeEPS      ;
       tempptr->rTPageOrientation   = TPageOrientationEPS;
     }

// The defaults have been assigned. If EPSFILE_EPSPRINT is desired only the functions
// which are different from the defaults need to be assigned.
// The MinHeaderEPS variants of TDocumentPageBegin and End are commented out
// because it turns out that the standard PageBegin and End work just fine.

     if(Flavor==EPSFILE_EPSPRINT)
     {
       tempptr->rTDocumentBegin     = TDocumentBeginMinHeaderEPS      ;
       tempptr->rTDocumentEnd       = TDocumentEndMinHeaderEPS        ;
       tempptr->rTDocumentPageBegin = TDocumentPageBeginEPS;
       // tempptr->rTDocumentPageBegin = TDocumentPageBeginMinHeaderEPS  ;
       // tempptr->rTDocumentPageEnd   = TDocumentPageEndMinHeaderEPS    ;
       tempptr->rTRawPrinterStart   = TRawPrinterStart_MinHdr         ;
       tempptr->rTRawPrinterEnd     = TRawPrinterEnd_MinHdr;
       tempptr->rTSoftFontLoad      = TSoftFontLoadMin   ; 
//    tempptr->rTSoftFontLoad      = TSoftFontLoadEPS   ;// This is a noop function.
                                                                      // Keeps *.pfb files out of
                                                                      // EPS files .. per legal.
       tempptr->rTJobCopies         = TJobCopiesEPS      ;// The following should
       tempptr->rTJobDuplex         = TJobDuplexEPS      ;// not be done for EPS
       tempptr->rTPaperSource       = TPaperSourceEPS    ;// Hence noops.
       tempptr->rTPaperSize         = TPaperSizeEPS      ;
       tempptr->rTPageOrientation   = TPageOrientationEPS;
     }

// The defaults have been assigned. If MINIMALHDR is desired only the functions
// which are different from the defaults need to be assigned.

     if(Flavor==MINIMALHDR)                          // EPS Printing
     {
       tempptr->rTDocumentBegin     = TDocumentBeginMinHeader  ;
       tempptr->rTDocumentEnd       = TDocumentEndMinHeader    ;
       tempptr->rTRawPrinterStart   = TRawPrinterStart_MinHdr  ;
       tempptr->rTRawPrinterEnd     = TRawPrinterEnd_MinHdr    ;
       tempptr->rTSoftFontLoad      = TSoftFontLoadMin         ;
     }

#ifdef ADOBE_DRIVER
   // Add pointers to Type42 widefont routines
   tempptr->rTTextRunWide       = TTextRunWide       ;
#endif

   // Fix bug 118619. 9-5-95
   if (lppd->job.bfESCOpenChannel){ 
       tempptr->rTSoftFontLoad      = TSoftFontLoadMin   ;
   }

}


/*****************************************************************************
*
*        AssignDLLTokens
*
* Function: This is for DLL assignment of tokens into the DRVR translate side.
*
* Called: short FAR PASCAL AssignDLLTokens(LPPDEVICE lppd, HANDLE hTokenDLL )
*
* Parameters: LPPDEVICE lppd
*             HANDLE    hTokenDLL )
*
* Returns:    RC_ok  means good pointers; RC_fail means one of the GetProcAddress's failed
*
*****************************************************************************/

short FAR PASCAL AssignDLLTokens(LPPDEVICE lppd, HANDLE hTokenDLL )
{
   FARPROC tempaddr;
   short retval;
   LPTFUNCTIONPTRS tempptr;

   tempptr = (LPTFUNCTIONPTRS)lppd->lpTFuncPtr;
   retval = RC_fail;

   tempaddr = GetProcAddress( hTokenDLL, (LPCSTR)"TPen" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPen = (TPEN)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, (LPCSTR)"TPenCap" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPenCap = (TPENCAP)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPenFGColor" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPenFGColor = (TPENFGCOLOR)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPenBGColor" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPenBGColor = (TPENBGCOLOR)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPenJoin" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPenJoin = (TPENJOIN)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPenMiterLimit" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPenMiterLimit = (TPENMITERLIMIT)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPenStyle" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPenStyle = (TPENSTYLE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPenWidth" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPenWidth = (TPENWIDTH)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TBrushBGColor" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTBrushBGColor = (TBRUSHBGCOLOR)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TBrushFGColor" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTBrushFGColor = (TBRUSHFGCOLOR)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TBrushHatch" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTBrushHatch = (TBRUSHHATCH)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TBrushPattern" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTBrushPattern = (TBRUSHPATTERN)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TBrushStyle" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTBrushStyle = (TBRUSHSTYLE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TArc" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTArc = (TARC)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TChord" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTChord = (TCHORD)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TEllipse" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTEllipse = (TELLIPSE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TCircle" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTCircle = (TCIRCLE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TLine" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTLine = (TLINE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPie" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPie = (TPIE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPolygon" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPolygon = (TPOLYGON)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPolyLine" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPolyLine = (TPOLYLINE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPolyBezier" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPolyBezier = (TPOLYBEZIER)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TRectangle" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTRectangle = (TRECTANGLE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TRoundRectangle" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTRoundRectangle = (TROUNDRECTANGLE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TScanLine" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTScanLine = (TSCANLINE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TScanLineBegin" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTScanLineBegin = (TSCANLINEBEGIN)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TScanLineEnd" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTScanLineEnd = (TSCANLINEEND)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPolyMode" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPolyMode = (TPOLYMODE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TBMOpaqueBox" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTBMOpaqueBox = (TBMOPAQUEBOX)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TOpaqueBox" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTOpaqueBox = (TOPAQUEBOX)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TBitmapHeader" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTBitmapHeader = (TBITMAPHEADER)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TBitmapOperator" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTBitmapOperator = (TBITMAPOPERATOR)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TBitmapData" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTBitmapData = (TBITMAPDATA)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TDIBHeader" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTDIBHeader = (TDIBHEADER)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TDIBDataBits" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTDIBDataBits = (TDIBDATABITS)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TGrayTable" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTGrayTable = (TGRAYTABLE)tempaddr;

   tempaddr  = GetProcAddress( hTokenDLL, "TColorTable" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTColorTable = (TCOLORTABLE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TDIBOperator" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTDIBOperator = (TDIBOPERATOR)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TDriverData" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTDriverData = (TDRIVERDATA)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TDocumentPageBegin" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTDocumentPageBegin = (TDOCUMENTPAGEBEGIN)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TDocumentPageEnd" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTDocumentPageEnd = (TDOCUMENTPAGEEND)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TDocumentAbort" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTDocumentAbort = (TDOCUMENTABORT)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TDocumentEnd" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTDocumentEnd = (TDOCUMENTEND)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TDocumentFlush" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTDocumentFlush = (TDOCUMENTFLUSH)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TDocumentBegin" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTDocumentBegin = (TDOCUMENTBEGIN)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TClipRect" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTClipRect = (TCLIPRECT)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TClipEnd" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTClipEnd = (TCLIPEND)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TJobType" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTJobType = (TJOBTYPE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TJobTitle" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTJobTitle = (TJOBTITLE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TJobCopies" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTJobCopies = (TJOBCOPIES)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TJobDuplex" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTJobDuplex = (TJOBDUPLEX)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TBackgroundMode" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTBackgroundMode = (TBACKGROUNDMODE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TColorBG" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTColorBG = (TCOLORBG)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TArcDirection" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTArcDirection = (TARCDIRECTION)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TRawPrinterStart" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTRawPrinterStart = (TRAWPRINTERSTART)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TRawPrinterData" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTRawPrinterData = (TRAWPRINTERDATA)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TRawPrinterEnd" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTRawPrinterEnd = (TRAWPRINTEREND)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TTextBegin" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTTextBegin = (TTEXTBEGIN)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TTextRun" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTTextRun = (TTEXTRUN)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TTextEnd" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTTextEnd = (TTEXTEND)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TSoftFontLoad" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTSoftFontLoad = (TSOFTFONTLOAD)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPageOrientation" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPageOrientation = (TPAGEORIENTATION)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPaperSource" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPaperSource = (TPAPERSOURCE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TPaperSize" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTPaperSize = (TPAPERSIZE)tempaddr;

   tempaddr = GetProcAddress( hTokenDLL, "TMSRectHack" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTMSRectHack = (TMSRECTHACK)tempaddr;
 
  tempaddr = GetProcAddress( hTokenDLL, "TClipPath" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTClipPath = (TCLIPPATH)tempaddr;
 
   retval = RC_ok;

  tempaddr = GetProcAddress( hTokenDLL, "TCTMTransform" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTCTMTransform = (TCTMTRANSFORM)tempaddr;

  tempaddr = GetProcAddress( hTokenDLL, "TCTMSaveRestore" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTCTMSaveRestore = (TCTMSAVERESTORE)tempaddr;
 
  tempaddr = GetProcAddress( hTokenDLL, "TClipBox" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTClipBox = (TCLIPBOX)tempaddr;
 
#ifdef ADOBE_DRIVER
   tempaddr = GetProcAddress( hTokenDLL, "TTextRunWide" );
   if (tempaddr == NULL)
     goto DLLTOKENSERROUT;
   else
     tempptr->rTTextRunWide = (TTEXTRUNWIDE)tempaddr;
#endif

   retval = RC_ok;

DLLTOKENSERROUT:
   return(retval);

} /* AssignDLLTokens */

