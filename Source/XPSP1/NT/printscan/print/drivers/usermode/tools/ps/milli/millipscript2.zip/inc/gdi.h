/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: GDI.H                                                        */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/


#define     ENABLE_pass1        0x0001  /* Inquire GDI Info        */
#define     ENABLE_DC           0x0000  /* Inquire/Enable for device context */
#define     ENABLE_IC           0x8000  /* Inquire/Enable for info context       */

/* The output styles */
#define     OS_POLYBEZIER       1
#define     OS_ARC              3
#define     OS_SCANLINES        4
#define     OS_RECTANGLE        6
#define     OS_ELLIPSE          7
#define     OS_MARKER           8
#define     OS_POLYLINE         18
#define     OS_ALTPOLYGON       22
#define     OS_WINDPOLYGON      20
#define     OS_PIE              23
#define     OS_POLYMARKER       24
#define     OS_CHORD            39
#define     OS_CIRCLE           55
#define     OS_ROUNDRECT        72
#define     OS_BEGINNSCAN       80
#define     OS_ENDNSCAN         81

/* This bit in the dfType field signals that the dfBitsOffset field is an
   absolute memory address and should not be altered. */
#define PF_BITS_IS_ADDRESS  4

/* This bit in the dfType field signals that the font is device realized. */
#define PF_DEVICE_REALIZED  0x80

/* These bits in the dfType give the fonttype -
   raster, vector, other1, other2. */
#define PF_RASTER_TYPE      0
#define PF_VECTOR_TYPE      1
#define PF_OTHER1_TYPE      2
#define PF_OTHER2_TYPE      3

//choices for the dpDCManage field in GDIINFO
#define DC_SPDevice   1
#define DC_1PDevice   2
#define DC_IgnoreDFNP 4

#define C1_TT_CR_ANY    0x0004

#define OVERHANG 0

//Japanese character set
#define EXT_RKSJ_CHARSET 128

// The pair kerning structure
// Note: the kern amount is given in hundreths of a point per character
typedef struct _KP
{
   int cPairs;            // The number of kerning pairs
   struct
   {
      int iKey;           // The kerning pair concatenated into a key
                          // NOTE: this is syntactically different from
                          // the way this is defined in the DDK, but
                          // represents the equivalent...union(byte[2],word)
      int iKernAmount;
   }rgPairs[1];
}KP, FAR *LPKP;


/* The info for a single kern track */
typedef struct _TRACK
{
   short  iDegree ;      // The degree of kerning
   short  iPtMin  ;      // The minimum point size
   short  iKernMin;      // The minimum kern amount
   short  iPtMax  ;      // The maximum point size
   short  iKernMax;      // The maximum kern amount
}TRACK, FAR *LPTRACK  ;

// The track kerning table for a font
typedef struct _KT
{
   short cTracks    ;   // The number of kern tracks
   TRACK rgTracks[1];   // The kern track information
}KT, FAR *LPKT;

typedef struct _ETM
{
   short  etmSize;
   short  etmPointSize;
   short  etmOrientation;
   short  etmMasterHeight;
   short  etmMinScale;
   short  etmMaxScale;
   short  etmMasterUnits;
   short  etmCapHeight;
   short  etmXHeight;
   short  etmLowerCaseAscent;
   short  etmLowerCaseDescent;
   short  etmSlant;
   short  etmSuperScript;
   short  etmSubScript;
   short  etmSuperScriptSize;
   short  etmSubScriptSize;
   short  etmUnderlineOffset;
   short  etmUnderlineWidth;
   short  etmDoubleUpperUnderlineOffset;
   short  etmDoubleLowerUnderlineOffset;
   short  etmDoubleUpperUnderlineWidth;
   short  etmDoubleLowerUnderlineWidth;
   short  etmStrikeOutOffset;
   short  etmStrikeOutWidth;
   WORD   etmNKernPairs;
   WORD   etmNKernTracks;
}ETM, FAR *LPETM;

//the extra font stuff that is needed by the driver that
//will be in the FONTINFO structure below the 2nd line
typedef struct _FONTEXTRA
{
   SHORT   sPSxScale       ;  // The PS x scale factor for this font instance
   SHORT   sPSyScale       ;  // The PS y scale factor for this font instance
   SHORT   sOrientation    ;  // The character orientation
   SHORT   sEscapement     ;  // The angle a line of text makes wrt. horizontal
   SHORT   sFontid         ;  // The PI dependent font id
   LPSTR   lpzMSFace       ;  // Windows FaceName
   LPSTR   lpzPSFace       ;  // PostScript FaceName
   LPSTR   lpzDevice       ;  // "PostScript"
   LPSHORT lpsWidths       ;  // A pointer to the character widths table
   LPKT    lpTrackKern     ;  // A pointer to the track kern table
   LPKP    lpPairKern      ;  // A pointer to the pair kern table
   LPETM   lpExtTextMetrics;  // A pointer to the ExtTextMetrics table
   char    lpSoftFont[80]  ;  // The name of the softfont *.pfb file.
   BOOL    fTategaki       ;  // true => vertical writing
   short   psAvgWidth      ;  // unscaled average width
   short   lpdWidths[256]  ;  // unscaled widths
}FONTEXTRA, FAR *LPFONTEXTRA;

//if the size of FONTINFO is desired consider...
//1. if only the std stuff is needed do "sizeof(FONTINFO)"
//2. if the complete size is desired, you must get the size of the
//   related PFM minus sizeof(PFMPROLOG) plus sizeof(FONTEXTRA)
typedef struct
{
   //this stuff makes up the "std" struct...if there
   //is such a thing
   //
   short int dfType;
   short int dfPoints;
   short int dfVertRes;
   short int dfHorizRes;
   short int dfAscent;
   short int dfInternalLeading;
   short int dfExternalLeading;
   BYTE      dfItalic;
   BYTE      dfUnderline;
   BYTE      dfStrikeOut;
   short int dfWeight;
   BYTE      dfCharSet;
   short int dfPixWidth;
   short int dfPixHeight;
   BYTE      dfPitchAndFamily;
   short int dfAvgWidth;
   short int dfMaxWidth;
   BYTE      dfFirstChar;
   BYTE      dfLastChar;
   BYTE      dfDefaultChar;
   BYTE      dfBreakChar;
   short int dfWidthBytes;
   unsigned long int  dfDevice;
   unsigned long int  dfFace;
   unsigned long int  dfBitsPointer;
   unsigned long int  dfBitsOffset;
   WORD      dfSizeFields;
   DWORD     dfExtMetricsOffset;
   DWORD     dfExtentTable;
   DWORD     dfOriginTable;
   DWORD     dfPairKernTable;
   DWORD     dfTrackKernTable;
   DWORD     dfDriverInfo;       //will hold the ptr to the "below the 2nd line" data
   DWORD     dfReserved;
   //
   //-----------------THE FIRST LINE-------------------
   //The rest of the FONTINFO contents are positioned
   //at varying positions using offsets from the main
   //structure above. All of this information is gotten
   //from the PFM file that was used to create it. This
   //data includes...
   //
   //      device name...char[]
   //      MS face name...char[]
   //      EXTTEXTMETRIC structure
   //      extent table (character widths)
   //      PS face name
   //      pair kern table
   //      track kern table
   //
   //----------------THE SECOND LINE-------------------
   //Data related to the particular instance of a font
   //is stored after everything else.  In addition it
   //contains the relavant pointers to the stuff above
   //and below the first line.
   //
   //      FONTEXTRA fontExtra
}FONTINFO, FAR *LPFONTINFO;


typedef struct
{
   short int  ftHeight;
   short int  ftWidth;
   short int  ftEscapement;
   short int  ftOrientation;
   short int  ftWeight;
   BYTE       ftItalic;
   BYTE       ftUnderline;
   BYTE       ftStrikeOut;
   BYTE       ftOutPrecision;
   BYTE       ftClipPrecision;
   unsigned short int ftAccelerator;
   short int  ftOverhang;
}TEXTXFORM, FAR *LPTEXTXFORM;

typedef struct
{
   short int         Rop2;
   short int         bkMode;
   unsigned long int bkColor;
   unsigned long int TextColor;
   short int         TBreakExtra;
   short int         BreakExtra;
   short int         BreakErr;
   short int         BreakRem;
   short int         BreakCount;
   short int         CharExtra;
   unsigned long int LbkColor;
   unsigned long int LTextColor;
   DWORD             hcmTransform;
}DRAWMODE, FAR *LPDRAWMODE;


typedef struct
{
   short int  dpVersion;
   short int  dpTechnology;
   short int  dpHorzSize;
   short int  dpVertSize;
   short int  dpHorzRes;
   short int  dpVertRes;
   short int  dpBitsPixel;
   short int  dpPlanes;
   short int  dpNumBrushes;
   short int  dpNumPens;
   short int  futureuse;
   short int  dpNumFonts;
   short int  dpNumColors;
   short int  dpDEVICEsize;
   unsigned short int  dpCurves;
   unsigned short int  dpLines;
   unsigned short int  dpPolygonals;
   unsigned short int  dpText;
   unsigned short int  dpClip;
   unsigned short int  dpRaster;
   short int  dpAspectX;
   short int  dpAspectY;
   short int  dpAspectXY;
   short int  dpStyleLen;
   POINT      dpMLoWin;
   POINT      dpMLoVpt;
   POINT      dpMHiWin;
   POINT      dpMHiVpt;
   POINT      dpELoWin;
   POINT      dpELoVpt;
   POINT      dpEHiWin;
   POINT      dpEHiVpt;
   POINT      dpTwpWin;
   POINT      dpTwpVpt;
   short int  dpLogPixelsX;
   short int  dpLogPixelsY;
   short int  dpDCManage;
   short int  dpCaps1;        //for TT rotating abilities
   short int  futureuse4;
   short int  futureuse5;
   short int  futureuse6;
   short int  futureuse7;
   short int  dpPalColors;    /* for version 0x300 devices */
   short int  dpPalReserved;  /* for version 0x300 devices */
   short int  dpPalResolut;   /* for version 0x300 devices */
}GDIINFO, FAR *LPGDIINFO;

//This structure is an enigma.  Nobody seems to use it
//so why is it here...My hypothesis is that is is a remnant
//from a much more complicated time in a galaxy far, far away...
//...no seriously it probably has ties to the old EXTTEXTOUT
//escape that has been superseded by the ExtTextOut() OEM function
//
typedef struct _APPEXTTEXTDATA
{
   short   x;
   short   y;
   int     count;
   RECT    ClipRect;
   LPSTR   lpStr;
   short   far *lpWidths;
}APPEXTTEXTDATA, FAR *LPAPPEXTTEXTDATA;

//the EXTTEXTDATA structure is goofy, the second entry (lpInData) takes
//on a variety of meanings depending on the escape.  I believe
//that GDI takes the data from the application and generates
//this bastard structure so that text escapes can be insured
//that whatever data they might need, they'll be able to get
//...sometimes the APPEXTTEXTDATA is referenced by the lpInData
//entry.
//
typedef struct _EXTTEXTDATA
{
   short       sSize;
   LP          lpInData;    //generic pointer to situation dependent data
   LPFONTINFO  lpFontInfo;
   LPTEXTXFORM lpXForm;
   LPDRAWMODE  lpDrawMode;
}EXTTEXTDATA, FAR *LPEXTTEXTDATA;

//  ORIENT structure.
//  This structure specifies a paper orientation.
//
//  member Orientation is either DMORIENT_PORTRAIT or DMORIENT_LANDSCAPE.
//
typedef struct
{
   SHORT  Orientation;
   SHORT  Reserved1;
   SHORT  Reserved2;
   SHORT  Reserved3;
   SHORT  Reserved4;
} ORIENT, FAR *LPORIENT;

typedef     struct  
{           
   short int   erType;         
   short int   erPoints;        
   short int   erVertRes;            
   short int   erHorizRes;        
   short int   erAscent;        
   short int   erInternalLeading; 
   short int   erExternalLeading; 
   BYTE        erItalic;       
   BYTE        erUnderline;       
   BYTE        erStrikeOut;       
   short int   erWeight;        
   BYTE        erCharSet;            
   short int   erPixWidth;        
   short int   erPixHeight;       
   BYTE        erPitchAndFamily;  
   short int   erAvgWidth;        
   short int   erMaxWidth;        
   BYTE        erFirstChar;       
   BYTE        erLastChar;        
   BYTE        erDefaultChar;     
   BYTE        erBreakChar;       
   short int   erWidthBytes;      
   unsigned long int   erDevice;  
   unsigned long int   erFace;    
   unsigned long int   erBitsPointer;
   unsigned long int   erBitsOffset;
   BYTE erReservedByte;       
   short int   erUnderlinePos;  
   short int   erUnderlineThick;
   short int   erStrikeoutPos;  
   short int   erStrikeoutThick;
   short       erEFontIndex;     
   short       erEM;             
   long        erSpotSizeX;      
   long        erSpotSizeY;      
   short       erEscapement;  
   short       erScaleX;      
   short       erHeightEM;       
   short       erCharBias;       
   long        erhFontFile;      
   short       erhPFont;         
   short       erTempOffset;     
   short       erTempBufferSize;
   short       erWidthTable;    
   short       erACTable;        
   long        erSizePFont;     
   long        erBlockSizeInc;   
   long        erCurrOffset;     
   long        erFreeSize;       
} SCALABLEFONTINFO;        




