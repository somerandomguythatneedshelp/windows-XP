/****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PS_ENUMX.H                                                   */
/*                                                                           */
/* Description: This module contains some enumerator spill-overs             */
/*                                                                           */
/*****************************************************************************/

/* 
 * Error Handling is in the returns.
 *
 *  These will be phased out. 
 */
#define PS_RC_OK 0
#define PS_RC_FAIL -1
#define PS_RC_DATA_NOT_FOUND -10
#define PS_RC_BUF_EXCEEDS_64K -11

/* function return codes */
enum
{
   PDM_RC_begin=-3,    // -3
   PDM_RC_badPPD,      // -2 Bad ppd passed as a parameter.
   PDM_RC_fail,        // -1
   PDM_RC_ok,          //  0
   PDM_RC_fatal,       // +1
   PDM_RC_file,        // +2 a file error caused failure
   PDM_RC_status,      // +3 fail due to status, refer to status info
   PDM_RC_hold,        // +4 called procedure was put on hold
   PDM_RC_comm,        // +5 a comm layer error
   PDM_RC_data,        // +6
   PDM_RC_not_found,   // +7 Couldn't find something.
   PDM_RC_bad_version, // +8 Version numbers dont agree.
   PDM_RC_duplicate,   // +9 duplicate of what ever.
   PDM_RC_end
};

typedef short PDM_ERROR;

#define COMM_ENUM_CHANGE                11

/* FOLLOWING ARE PRIVATE MESSAGE TYPES THAT ARE A NOTIFICATION
   OF CHANGES TO THE ENUMERATOR DATABASE THAT COULD BE OF
   INTEREST TO RUNNING APPLICATIONS */
#define PS_ENUM_CHANGE WM_USER + 0x701
#define PS_NEW_PRINTER      101
#define PS_FONTS_CHANGE     102
#define PS_DEVICES_CHANGE   103
#define PS_NEW_COMM         104

#define PS_EO_READ    1
#define PS_EO_WRITE   2
#define PS_EO_LOCK    4

/* PPD RELATED CONSTANTS: ****************************/
 /* KEYWORD TYPES: */
#define KWTYPE_NORMAL 0
#define KWTYPE_PARAM  1

 /* PARAMETER TYPES: */
#define PARAM_INT 0
#define PARAM_REAL 1
#define PARAM_STRING 2

 /* KEYWORD FLAG MASKS. */
#define NO_UI_FLAG     0
#define UI_FLAG        1
#define OEM_FLAG       2
#define UI_OR_OEM_FLAG 3

 /* JOB SECTIONS USED TO SPECIFY ORDER DEPENDENCIES: */
#define SECT_EXITSERVER     0
#define SECT_PROLOG         1
#define SECT_DOCUMENTSETUP  2
#define SECT_PAGESETUP      3
#define SECT_ANYSETUP       4
#define SECT_JCLSETUP       5

#define DEF_JOB_SECTION  SECT_DOCUMENTSETUP
#define DEF_JOB_ORDER_NUM  (float) 0.0
/*****************************************************/

/* THE FOLLOWING STRUCTURE WILL BE FILLED IN WITH ADDRESSES
   OF VARIOUS INFORMATIONAL ITEMS AND THE ADDRESS OF THIS
   STRUCTURE IS PASSED AS THE long PARAMETER IN THE PRIVATE
   MESSAGES DESCRIBED ABOVE */
typedef struct {
    LPSTR refName;
    LPSTR devName;
    LPSTR fontName;
} PS_MESSAGE_INFO;

/************** PS_INIT * FUNCTION PROTOTYPES ***************/

#if 0
HANDLE FAR PASCAL Ps_EnumOpen(LPSTR refName, short version);
typedef HANDLE (FAR PASCAL *LPPs_EnumOpen)(LPSTR refName, short version);

PDM_ERROR FAR PASCAL Ps_EnumClose(HANDLE enumHandle);
typedef PDM_ERROR (FAR PASCAL *LPPs_EnumClose)(HANDLE enumHandle);

PDM_ERROR FAR PASCAL Ps_RegisterClientInstance(HANDLE hWnd, BOOL flag);
PDM_ERROR FAR PASCAL Ps_SendChangeMessages(short msgType, short flag,PS_MESSAGE_INFO FAR *msgInfo);
BOOL      FAR PASCAL Ps_TestNewPrinter(LPSTR newName);
BOOL      FAR PASCAL Ps_TestNewComm(void);
short FAR PASCAL Ps_EnumVersion(void);
typedef short (FAR PASCAL *LPPs_EnumVersion)(void);

void FAR PASCAL Ps_UpdateHostFonts(void);

PDM_ERROR FAR PASCAL Ps_InitEnumerator(void);
PDM_ERROR FAR PASCAL Ps_KillEnumerator(void);
PDM_ERROR FAR PASCAL Ps_SaveEnumState(void);
#endif

#if 0
#ifndef NOCOMM
PDM_ERROR FAR PASCAL Ps_SetCommValue(LPSTR port, DCB FAR *dcb);
PDM_ERROR FAR PASCAL Ps_GetCommValue(LPSTR port, DCB FAR *dcb);
#endif
#endif

#if 0
BOOL      FAR PASCAL Ps_NeedToResync( HANDLE enumHandle, LPSTR refName);
BOOL      FAR PASCAL Ps_KnowsDevice(HANDLE enumHandle,LPSTR refName,LPSTR devName);
BOOL      FAR PASCAL Ps_KnowsFont(HANDLE enumHandle,LPSTR refName,LPSTR devName,LPSTR fontName);

typedef BOOL FAR PASCAL ENUMNEWFONTS(LPSTR, int, int, LPSTR);
PDM_ERROR FAR PASCAL Ps_EnumNewFonts( HANDLE enumHandle, LPSTR refName,
    LPSTR device, ENUMNEWFONTS *EnumNewFonts, LPSTR data);

typedef BOOL FAR PASCAL ENUMNEWDEVICES(LPSTR, LPSTR);
PDM_ERROR FAR PASCAL Ps_EnumNewDevices( HANDLE enumHandle, LPSTR refName,
    ENUMNEWDEVICES *EnumNewDevices, LPSTR data);
#endif

/****************** PS_PRINT * PROTOTYPES ****************************/

#define MAX_PS_NAME           50
#define PS_FILE_PATH_LENGTH  MAX_PATH
// #define PS_POSTSCRIPT_NAME     0
// #define PS_FAMILY_NAME         1
// #define PS_FACES               2
#define DEVNAMESIZE           15

                                                  // ResourceType = -1 Type 1 font
                                                  // ResourceType = -2 Type 2 font
                                                  // ResourceType = -3 Pattern
                                                  // ResourceType = -4 Unused
                                                  // ResourceType = -5   "
                                                  // ResourceType = -6   "
                                                  // ResourceType = -7   "
typedef struct
{
   short      bResourceType;                      // Negative -> Resource type.0 or Pos -> deleted
   BOOL       bVolatile;                          // Font is lost on power down of printer
   char       syncFlag;
   char       szResourceFamilyName[MAX_PS_NAME];  // e.g. Courier
   char       szResourceMenuName[MAX_PS_NAME];    // e.g. Courier-Bold
   char       szResourcePath[PS_FILE_PATH_LENGTH];// *.pfb pathname
   char       szResourceMetricsPath[PS_FILE_PATH_LENGTH];   // *.pfm pathname
   char       RESERVED[10];
   long       lResourceFileSize;                  // *.pfb FileSize
   long       lResourceUsage_FirstPass;           // VM usage
   long       lResourceUsage_NextPass;            // VM usage
   int        RecordNumber;                       // Number of rb record in *.ebf file
   LOGFONT    lf;                                 // Logical font associated with *.pfm file
   TEXTMETRIC tm;                                 // Textmetric structure associated with *.pfm file
} resourceBlock,FAR *LPRESBLOCK;

/* values returned from PS devstatus operator */

typedef struct
{
   char  szFileTypeIdentifier[32];  // ^Z and NULL terminated description
   WORD  wFileVersion;              // 10 = version 1.0
   char  szDevName[DEVNAMESIZE];    // "HOSTFONT","VM",PrinterMemory",etc.
   char  szDevNickname[50];         // "refName,devName"
   char  cDeviceStatus;             // 99=inactive, 0-7=SCSI port, 65=A slot, 66=B slot
   char  cFlags[19];                // Extra flags for future expansion
                                    // we need one:
                                    // cFlags[18] is now used to store the
                                    // device number for the printer type if
                                    // the Microsoft driver is being used.
                                    // this is taken from the "device = "
                                    // line of the Microsoft driver win.ini
                                    // record.  This flag only has meaning
                                    // if szDevName = "VM" and refName =
                                    // "PostScript,COM1" (or something)
   short iClassNumber;              // 1 - mag disk
                                    // 2 - cd rom
                                    // 3 - font cart
                                    // 4 - mag cart
   BOOL  bVolatility;               // Device can be removed on power down
   BOOL  bSearchable;               // Always FALSE
   BOOL  bExternalFormat;           // Not Used
   BOOL  bWriteable;                // Always TRUE  never tested
   BOOL  bHasNames;                 // Always TRUE  never tested
   BOOL  bMounted;                  // Always TRUE  never tested
   BOOL  bRemovable;                // Always FALSE never tested
   short iSearchOrder;              // Always 0     never tested
   short iCapacityUnits;
   long  lSize;
   long  lFree;
   short fontCount;                 // Total number of fonts
   short recordCount;               // Total number of resourceBlocks(including unused ones)
   short nextRecord;                // Next available index
} devBlock,FAR *LPDEVBLOCK;


/**************************************************************/

 /* call-back routines */
typedef BOOL FAR PASCAL ENUMPRINTERS(LPSTR refName, LPSTR uData);
typedef BOOL FAR PASCAL ENUMDEVICES(LPSTR device, LPSTR uData);

/**************************************************************/
short FAR PASCAL Ps_CurrentPrinter(LPSTR refName, LPSTR port);
PDM_ERROR FAR PASCAL Ps_EnumPrinters (ENUMPRINTERS *, LPSTR);
typedef PDM_ERROR (FAR PASCAL *LPPs_EnumPrinters)(ENUMPRINTERS *, LPSTR);

PDM_ERROR FAR PASCAL Ps_EnumDevices  ( HANDLE, LPSTR, ENUMDEVICES *, LPSTR);
typedef PDM_ERROR (FAR PASCAL *LPPs_EnumDevices)( HANDLE, LPSTR, ENUMDEVICES *, LPSTR);

PDM_ERROR FAR PASCAL Ps_GetDeviceInfo( HANDLE enumHandle,LPSTR refName,LPSTR device,LPDEVBLOCK db);
PDM_ERROR FAR PASCAL Ps_SetDeviceInfo( HANDLE enumHandle,LPSTR refName,LPSTR device,LPDEVBLOCK db);

PDM_ERROR FAR PASCAL Ps_AddPrinter   ( HANDLE EnumHandle,LPSTR pathToPPD,LPSTR refName, LPSTR port);
PDM_ERROR FAR PASCAL Ps_ExtAddPrinter( HANDLE EnumHandle,LPSTR pathToPPD,LPSTR refName, LPSTR port, LPSTR lpDevType);
typedef PDM_ERROR (FAR PASCAL *LPPs_ExtAddPrinter)(HANDLE EnumHandle,LPSTR pathToPPD,LPSTR refName, LPSTR port, LPSTR lpDevType);

PDM_ERROR FAR PASCAL Ps_DeletePrinter( HANDLE enumHandle, LPSTR refName);
typedef PDM_ERROR (FAR PASCAL *LPPs_DeletePrinter)( HANDLE enumHandle, LPSTR refName);

PDM_ERROR FAR PASCAL Ps_ExtDeletePrinter( HANDLE enumHandle, LPSTR refName, LPSTR lpDevType, LPSTR lpPort);
typedef PDM_ERROR (FAR PASCAL *LPPs_ExtDeletePrinter)( HANDLE enumHandle, LPSTR refName, LPSTR lpDevType, LPSTR lpPort);

PDM_ERROR FAR PASCAL Ps_AddDevice    (HANDLE enumHandle,LPSTR RefName,LPDEVBLOCK dv);
PDM_ERROR FAR PASCAL Ps_DeleteDevice ( HANDLE enumHandle,LPSTR RefName, LPSTR devName);
PDM_ERROR FAR PASCAL Ps_LoadCurrentPrinterFontData( HANDLE EnumHandle,LPSTR refName, int flag);

PDM_ERROR FAR PASCAL Ps_QueryPrinterAtPort(LPSTR port, LPSTR refName,WORD max_refName_len);
PDM_ERROR FAR PASCAL Ps_ExtQueryPrinterAtPort(LPSTR port, LPSTR lpDevType, LPSTR refName,WORD max_refName_len);
typedef PDM_ERROR (FAR PASCAL *LPPs_ExtQueryPrinterAtPort)(LPSTR port, LPSTR lpDevType, LPSTR refName,WORD max_refName_len);

PDM_ERROR FAR PASCAL Ps_AssignPrinterToPort(HANDLE enumHandle,LPSTR refName, LPSTR port);
typedef PDM_ERROR (FAR PASCAL *LPPs_AssignPrinterToPort)(HANDLE enumHandle,LPSTR refName, LPSTR port);

PDM_ERROR FAR PASCAL Ps_ExtAssignPrinterToPort(HANDLE enumHandle,LPSTR refName, LPSTR lpNewPort, LPSTR lpOldPort, LPSTR lpDevType);
typedef PDM_ERROR (FAR PASCAL *LPPs_ExtAssignPrinterToPort)(HANDLE enumHandle,LPSTR refName, LPSTR lpNewPort, LPSTR lpOldPort, LPSTR lpDevType);

PDM_ERROR FAR PASCAL Ps_SetPortBuffer(HTASK hTask, LPSTR lpPort);
typedef PDM_ERROR (FAR PASCAL *LPPs_SetPortBuffer)(HTASK hTask, LPSTR lpPort);

PDM_ERROR FAR PASCAL Ps_GetPortBuffer(HTASK hTask, LPSTR lpPort);
typedef PDM_ERROR (FAR PASCAL *LPPs_GetPortBuffer)(HTASK hTask, LPSTR lpPort);

PDM_ERROR FAR PASCAL Ps_ClearPortBufferItem(HTASK hTask);
typedef PDM_ERROR (FAR PASCAL *LPPs_ClearPortBufferItem)(HTASK hTask);

HGLOBAL FAR PASCAL Ps_GetDrvStateCacheHandle(void);
typedef HGLOBAL (FAR PASCAL *LPPs_GetDrvStateCacheHandle)(void);

HGLOBAL FAR PASCAL Ps_GlobalAlloc(LONG lSize, WORD wFlags);
typedef HGLOBAL (FAR PASCAL *LPPs_GlobalAlloc)(LONG lSize, WORD wFlags);

HGLOBAL FAR PASCAL Ps_GlobalReAlloc(HGLOBAL hOrigHandle, LONG lSize, WORD wFlags);
typedef HGLOBAL (FAR PASCAL *LPPs_GlobalReAlloc)(HGLOBAL hOrigHandle, LONG lSize, WORD wFlags);

HGLOBAL FAR PASCAL Ps_GlobalFree(HGLOBAL hOrigHandle);
typedef HGLOBAL (FAR PASCAL *LPPs_GlobalFree)(HGLOBAL hOrigHandle);

PDM_ERROR FAR PASCAL Ps_ClearPortBuffer(void);

void FAR PASCAL ConvertTranslation(LPSTR buffer);
typedef void (FAR PASCAL *LPConvertTranslation)(LPSTR buffer);

/****************** PS_FONT * PROTOTYPES **************************/

typedef BOOL FAR PASCAL ENUMFONTS(resourceBlock FAR *, LPSTR);

PDM_ERROR FAR PASCAL Ps_EnumExtFonts( HANDLE, LPSTR, LPSTR,ENUMFONTS *, LPWORD, short, LPSTR, LPSTR);
typedef PDM_ERROR (FAR PASCAL *LPPs_EnumExtFonts)( HANDLE, LPSTR, LPSTR,ENUMFONTS *, LPWORD, short, LPSTR, LPSTR);

PDM_ERROR FAR PASCAL Ps_EnumExtMetricsFlag( HANDLE EnumHandle, LPSTR refName,
                             LPSTR devName, LPSTR fontName, LPRESBLOCK rb,int flag);


PDM_ERROR FAR PASCAL Ps_EnumExtMetrics( HANDLE enumHandle, LPSTR refName, LPSTR devName,LPSTR fontName, LPRESBLOCK rb);
PDM_ERROR FAR PASCAL Ps_FindFontFace( HANDLE, LPSTR);

PDM_ERROR FAR PASCAL Ps_AddFont( HANDLE,LPSTR,LPSTR,LPSTR,LPSTR,LPSTR);
typedef PDM_ERROR (FAR PASCAL *LPPs_AddFont)( HANDLE,LPSTR,LPSTR,LPSTR,LPSTR,LPSTR); // Chicago

PDM_ERROR FAR PASCAL Ps_DeleteFont( HANDLE enumHandle, LPSTR refName, LPSTR devName,LPSTR fontName);
PDM_ERROR FAR PASCAL Ps_DeleteAllFonts( HANDLE EnumHandle,LPSTR refName,LPSTR devName);
PDM_ERROR FAR PASCAL Ps_AddWinIni(HANDLE enumHandle,LPSTR pfmPath, LPSTR pfbPath, LPSTR refName);
PDM_ERROR FAR PASCAL Ps_GetFontNames(LPSTR pfmPath, LPSTR familyName, LPSTR faceName);


/****************** PS_KEYWD * PROTOTYPES **************************/

 /* call-back routines */

typedef BOOL FAR PASCAL ENUM_KEYWORD_FUNC(LPSTR keyword,
   LPSTR keyword_translation, short keyword_type, BYTE flags, LPSTR user_data);
typedef BOOL FAR PASCAL ENUM_OPTION_FUNC(LPSTR keyword, LPSTR option,
   LPSTR option_translation, short dcmt_section, float order_num,
   LPSTR user_data) ;
typedef BOOL FAR PASCAL ENUM_PARAM_FUNC(LPSTR keyword, LPSTR param,
   LPSTR param_translation, short param_type, WORD max_param_len,
   VOID FAR *val, LPSTR user_data) ;
typedef BOOL FAR PASCAL ENUM_UICONST_FUNC(LPSTR KeywordA,LPSTR OptionA,
                                          LPSTR KeywordB, LPSTR OptionB,
                                          LPSTR userdata);

/**************************************************************/
short FAR PASCAL Ps_PPDEnumKeywords(short EnumHandle, BYTE flags,
   ENUM_KEYWORD_FUNC *enum_func, LPSTR user_data) ;
typedef short (FAR PASCAL *LPPs_PPDEnumKeywords)(short EnumHandle, BYTE flags,
   ENUM_KEYWORD_FUNC *enum_func, LPSTR user_data) ;

short FAR PASCAL Ps_PPDEnumKeywordOptions(short EnumHandle, LPSTR keyword,
   ENUM_OPTION_FUNC *enum_func, LPSTR user_data) ;
typedef short (FAR PASCAL *LPPs_PPDEnumKeywordOptions)(short EnumHandle, LPSTR keyword,
   ENUM_OPTION_FUNC *enum_func, LPSTR user_data) ;

short FAR PASCAL Ps_PPDEnumKeywordParams(short EnumHandle, LPSTR keyword,
   ENUM_PARAM_FUNC *enum_func, LPSTR user_data) ;
typedef short (FAR PASCAL *LPPs_PPDEnumKeywordParams)(short EnumHandle, LPSTR keyword,
   ENUM_PARAM_FUNC *enum_func, LPSTR user_data) ;

short FAR PASCAL Ps_PPDGetKeywordDesc(short EnumHandle, LPSTR keyword,
   LPSTR desc, WORD max_desc_len, LPBYTE flags) ;
typedef short (FAR PASCAL *LPPs_PPDGetKeywordDesc)(short EnumHandle, LPSTR keyword,
   LPSTR desc, WORD max_desc_len, LPBYTE flags) ;

short FAR PASCAL Ps_PPDSetKeywordOption(short EnumHandle, LPSTR keyword,
   LPSTR option) ;
typedef short (FAR PASCAL *LPPs_PPDSetKeywordOption)(short EnumHandle, LPSTR keyword,
   LPSTR option) ;

short FAR PASCAL Ps_PPDSetKeywordOptionPS(short EnumHandle, LPSTR keyword,
   LPSTR option, LPSTR PS, WORD PS_len); /* Chicago 3 */
typedef short (FAR PASCAL *LPPs_PPDSetKeywordOptionPS)(short EnumHandle, LPSTR keyword,
   LPSTR option, LPSTR PS, WORD PS_len);

short FAR PASCAL Ps_PPDGetKeywordOption(short EnumHandle, LPSTR keyword,
   LPSTR option, WORD max_option_len, LPSTR option_translation,
   WORD max_translation_len) ;
typedef short (FAR PASCAL *LPPs_PPDGetKeywordOption)(short EnumHandle, LPSTR keyword,
   LPSTR option, WORD max_option_len, LPSTR option_translation,
   WORD max_translation_len) ;

short FAR PASCAL Ps_PPDGetKeywordOptionPS(short EnumHandle, LPSTR keyword,
   LPSTR option, LPSTR PS_buffer, WORD max_buf_len) ;
typedef short (FAR PASCAL *LPPs_PPDGetKeywordOptionPS)(short EnumHandle, LPSTR keyword,
   LPSTR option, LPSTR PS_buffer, WORD max_buf_len) ;

short FAR PASCAL Ps_PPDGetKeywordOptionPSLen(short EnumHandle, LPSTR keyword,
   LPSTR option) ;
typedef short (FAR PASCAL *LPPs_PPDGetKeywordOptionPSLen)(short EnumHandle, LPSTR keyword,
   LPSTR option) ;

short FAR PASCAL Ps_PPDGetKeywordJobOrder(short EnumHandle, LPSTR keyword,
   LPSTR option, short FAR *dcmt_section, float FAR *order_num) ;

short FAR PASCAL Ps_PPDSetKeywordParamVal(short EnumHandle, LPSTR keyword,
   LPSTR param, short param_type, VOID FAR *val) ;
typedef short (FAR PASCAL *LPPs_PPDSetKeywordParamVal)(short EnumHandle, LPSTR keyword,
   LPSTR param, short param_type, VOID FAR *val) ;

short FAR PASCAL Ps_PPDGetKeywordParamVal(short EnumHandle, LPSTR keyword,
   LPSTR param, short param_type, VOID FAR *val, WORD max_param_len) ;
typedef short (FAR PASCAL *LPPs_PPDGetKeywordParamVal)(short EnumHandle, LPSTR keyword,
   LPSTR param, short param_type, VOID FAR *val, WORD max_param_len) ;

short FAR PASCAL Ps_PPDSetKeywordParamBnds(short EnumHandle, LPSTR keyword,
   LPSTR param, short param_type, VOID FAR *lo_lim, VOID FAR *hi_lim) ;
typedef short (FAR PASCAL *LPPs_PPDSetKeywordParamBnds)(short EnumHandle, LPSTR keyword,
   LPSTR param, short param_type, VOID FAR *lo_lim, VOID FAR *hi_lim) ;

short FAR PASCAL Ps_PPDGetKeywordParamBnds(short EnumHandle, LPSTR keyword,
   LPSTR param, short param_type, VOID FAR *lo_lim, VOID FAR *hi_lim) ;
typedef short (FAR PASCAL *LPPs_PPDGetKeywordParamBnds)(short EnumHandle, LPSTR keyword,
   LPSTR param, short param_type, VOID FAR *lo_lim, VOID FAR *hi_lim) ;

short FAR PASCAL Ps_PPDCreateKeyword(short EnumHandle, LPSTR keyword,
   LPSTR keyword_translation, short keyword_type, BYTE flags) ;
typedef short (FAR PASCAL *LPPs_PPDCreateKeyword)(short EnumHandle, LPSTR keyword,
   LPSTR keyword_translation, short keyword_type, BYTE flags) ;

short FAR PASCAL Ps_PPDCreateKeywordOption(short EnumHandle, LPSTR keyword,
   LPSTR option, LPSTR option_translation, LPSTR PS, short dcmt_section,
   float order_num) ;
typedef short (FAR PASCAL *LPPs_PPDCreateKeywordOption)(short EnumHandle, LPSTR keyword,
   LPSTR option, LPSTR option_translation, LPSTR PS, short dcmt_section,
   float order_num) ;

short FAR PASCAL Ps_PPDCreateKeywordParam(short EnumHandle, LPSTR keyword,
   LPSTR param, LPSTR param_translation, short param_type, WORD max_param_len);
typedef short (FAR PASCAL *LPPs_PPDCreateKeywordParam)(short EnumHandle, LPSTR keyword,
   LPSTR param, LPSTR param_translation, short param_type, WORD max_param_len);

int FAR PASCAL Ps_PPDEnumUIConstraints(short EnumHandle,
                          ENUM_UICONST_FUNC *enum_func, LPSTR userdata);
typedef int (FAR PASCAL *LPPs_PPDEnumUIConstraints)(short EnumHandle,
                          ENUM_UICONST_FUNC *enum_func, LPSTR userdata);

int FAR PASCAL Ps_PPDCreateUIConstraint(short EnumHandle,
                                        LPSTR KeywordA, LPSTR OptionA,
                                        LPSTR KeywordB, LPSTR OptionB);
typedef int (FAR PASCAL *LPPs_PPDCreateUIConstraint)(short EnumHandle,
                                        LPSTR KeywordA, LPSTR OptionA,
                                        LPSTR KeywordB, LPSTR OptionB);

PDM_ERROR FAR PASCAL Ps_PPDKeywordExist( HANDLE hEnum, LPSTR Keyword );
typedef PDM_ERROR (FAR PASCAL *LPPs_PPDKeywordExist)( HANDLE hEnum, LPSTR Keyword );
/****************** PS_KEYWD CONSTANTS **************************/

//The following lengths include the NULL that terminates a string:
#define MAX_KEYWORD_LEN   41  /*Maximum length of a PPD Keyword            */
#define MAX_OPTION_LEN    41  /*Maximum length of a PPD Keyword Option     */
#define MAX_PARAMNAME_LEN 41  /*Maximum length of a PPD Keyword param name */
#define MAX_TR_STRING_LEN 41  /*Maximum length of a translation string     */

/****************** PS_EXPND * PROTOTYPES **************************/

           /* call-back routine */

typedef int FAR PASCAL EXPNDPROC(LPSTR, short, short, LPSTR);

#define COMM_OK                         0
#define COMM_CANCEL                     1
#define COMM_TIMEOUT                    3
#define COMM_DONE                       4
#define COMM_MEMORY_ERROR               5
#define COMM_FILE_ERROR                 6
#define COMM_COMM_ERROR                 7
#define COMM_RESOURCE_ERROR             8
#define COMM_ENUM_ERROR                 9
#define COMM_ENUM_BUSY                  10
#define COMM_DEV_UNMOUNTED              11


int FAR PASCAL Ps_ExpandFontFile(LPSTR, EXPNDPROC *, LPSTR);


/* NEW STUFF: */


/* CHANGING THE FOLLOWING WILL FORCE THE ENUM DATABASE TO BE
   RECOMPUTED AND REWRITTEN */
#define ENUMDATA_VERSION  18

// The following is used to check the validity of binary PPD data.
#define ENUMPPB_VERSION 59

// record structure for UIConstraint records
// note: this type is used in both the enumerator
// and the driver.
typedef struct _UICONSTRECORD
        {
        char KeywordA[MAX_KEYWORD_LEN];
        char OptionA[MAX_OPTION_LEN];
        char KeywordB[MAX_KEYWORD_LEN];
        char OptionB[MAX_OPTION_LEN];
        } UICONSTRECORD, FAR * LPUICONSTRECORD;


/****************** PS_CACHE  **************************/

short far PASCAL GetPFMData(short EnumHandle,LPSTR NickName,LPSTR devName,int Index,LPHANDLE UserPFMh);
typedef short (far PASCAL *LPGetPFMData)(short EnumHandle,LPSTR NickName,LPSTR devName,int Index,LPHANDLE UserPFMh);

PDM_ERROR FAR PASCAL GetpfmFontName(int fh, LPSTR buffer); /* Chicago */
typedef PDM_ERROR (FAR PASCAL *LPGetpfmFontName)(int fh, LPSTR buffer); /* Chicago */

#if 0
// The definitions of these types are taken from the DDK book
// "Printers and Fonts Kit" chapters 2 and 4
//
// EXCEPTIONS: in the book the PFMHEADER section comprises what
// is described here as the PFMPROLOG and the PFMHEADER.  This is
// done in order to read the prolog in a separate step to extract
// version and size info BEFORE reading the header.  In addition
// the header will map more closely to part of the FONTINFO structure

typedef struct _PFMPROLOG
{
        unsigned short int dfVersion;
        unsigned long  int dfSize;
        char           dfCopyright[60];
}
PFMPROLOG, FAR *LPPFMPROLOG;

typedef struct _PFMHEADER
{
        short int dfType;
        short int dfPoints;
        short int dfVertRes;
        short int dfHorizRes;
        short int dfAscent;
        short int dfInternalLeading;
        short int dfExternalLeading;
        BYTE      dfItalic;
        BYTE      dfUnderline;
        BYTE      dfStrikeOut;
        short int dfWeight;
        BYTE      dfCharSet;
        short int dfPixWidth;
        short int dfPixHeight;
        BYTE      dfPitchAndFamily;
        short int dfAvgWidth;
        short int dfMaxWidth;
        BYTE      dfFirstChar;
        BYTE      dfLastChar;
        BYTE      dfDefaultChar;
        BYTE      dfBreakChar;
        short int dfWidthBytes;
        unsigned long int dfDevice;
        unsigned long int dfFace;
        unsigned long int dfBitsPointer;
        unsigned long int dfBitsOffset;
}
PFMHEADER, FAR *LPPFMHEADER;

typedef struct _PFMEXTENSION
{
        WORD  dfSizeFields;
        DWORD dfExtMetricsOffset;
        DWORD dfExtentTable;
        DWORD dfOriginTable;
        DWORD dfPairKernTable;
        DWORD dfTrackKernTable;
        DWORD dfDriverInfo;
        DWORD dfReserved;
}
PFMEXTENSION, FAR *LPPFMEXTENSION;

typedef struct _PFM
{
        PFMPROLOG    prolog;
        PFMHEADER    hdr;
        PFMEXTENSION ext;
}
PFMstruct, FAR *LPPFMstruct, FAR * FAR * LPLPPFMstruct;

#endif
