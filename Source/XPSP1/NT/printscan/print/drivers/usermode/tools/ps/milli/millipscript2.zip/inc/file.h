/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: FILE.H                                                       */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/

SHORT FAR PASCAL FCreate(LPSTR lpzFile,SHORT sMode);
SHORT FAR PASCAL FOpen(LPSTR lpsFile,SHORT sMode);
SHORT FAR PASCAL FWrite(SHORT hFile,LP lp,SHORT sNumToWrite);
SHORT FAR PASCAL FWriteMultiple(SHORT hFile,LP lp,SHORT sLen,SHORT sNum);
DWORD FAR PASCAL FWriteMega(SHORT hFile,LP lp,DWORD dLen,DWORD dNum);
FLAG  FAR PASCAL FWriteChar(SHORT hFile,CHAR c);
FLAG  FAR PASCAL FWriteShort(SHORT hFile,SHORT s);
FLAG  FAR PASCAL FWriteLong(SHORT hFile,LONG l);
SHORT FAR PASCAL FRead(SHORT hFile,LP lp,SHORT sNumToRead);
SHORT FAR PASCAL FReadMultiple(SHORT hFile,LP lp,SHORT sLen,SHORT sNum);
DWORD FAR PASCAL FReadMega(SHORT hFile,LP lp,DWORD dLen,DWORD dNum);
CHAR  FAR PASCAL FReadChar(SHORT hFile);
SHORT FAR PASCAL FReadShort(SHORT hFile);
LONG  FAR PASCAL FReadLong(SHORT hFile);
LONG  FAR PASCAL FSeek(SHORT hFile,LONG lOffset,SHORT sOrigin);

#define FCurPos(x) FSeek(x,0L,1)
#define FSkip(x,y) FSeek(x,(LONG)(y),1)
#define FHome(x)   FSeek(x,0L,0)
#define FEnd(x)    FSeek(x,0L,2)

SHORT FAR PASCAL FClose(SHORT hFile);
SHORT FAR PASCAL FDelete(LPSTR lpsFile);

