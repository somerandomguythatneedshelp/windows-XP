/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: UNCONCAT.C                                                   */
/*                                                                           */
/* Description: This module contains the functions to unconcat and remove    */
/*              individual *.pfm files from the fonts.mfm file               */
/*                                                                           */
/* The format of the fonts.mfm file is as follows:                           */
/*                                                                           */
/* 1. Magic Bytes, Identifier string for this file type with high bit        */
/*    set, 80 bytes even if not all bytes are used for the ID string         */
/*                                                                           */
/* 2. Version integer, format is 0x0210 for version 2.10, etc. 2 bytes       */
/*                                                                           */
/* 3. iNumPfms integer, tells us how many pfm files are in here, 2 bytes     */
/*                                                                           */
/* 4. FileRecord array, iNumPfm * sizeof(FileRecord) bytes                   */
/*                                                                           */
/* 5. Actual PFM files, variable length, iNumPfm of them in here             */
/*                                                                           */
/*****************************************************************************/

#include "ps.h"         // Also includes PRINT.H, WINDOWS.H, GDIDEFS.INC etc..

#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "string.h"
#include "fcntl.h"
#include "sys\types.h"
#include "sys\stat.h"
#include "io.h"
#include "dos.h"
#include "errno.h"
#include "lcalls.h"

#include "concatx.h"

/*****************************************************************************/
/* Static variables used only in this file                                   */
/*****************************************************************************/

static union REGS inregs, outregs;
static struct SREGS segregs;

/*****************************************************************************/
/*                 OpenFileRead                                              */
/* Purpose:                                                                  */
/*   Open a file for reading only                                            */
/*                                                                           */
/* Parameters:                                                               */
/*   LPSTR lpFile -- name of file to be openned for reading                  */
/*                                                                           */
/* Returns: HFILE                                                            */
/*   Handle to the opened file                                               */
/*****************************************************************************/

HFILE OpenFileRead(LPSTR lpFile)
{
  HFILE hFile;
  OFSTRUCT ofst;

  hFile = OpenFile(lpFile, &ofst, OF_READ);

  return (hFile);
}

/*****************************************************************************/
/*                 OpenFileWrite                                             */
/* Purpose:                                                                  */
/*   Open a file for writing only                                            */
/*                                                                           */
/* Parameters:                                                               */
/*   LPSTR lpFile -- name of file to be openned for writing                  */
/*                                                                           */
/* Returns: HFILE                                                            */
/*   Handle to the opened file                                               */
/*****************************************************************************/

HFILE OpenFileWrite(LPSTR lpFile)
{
  HFILE hOutFile;
  OFSTRUCT ofst;

  hOutFile = OpenFile(lpFile, &ofst, OF_CREATE|OF_WRITE);

  return (hOutFile);
}

/*****************************************************************************/
/*                 CloseFile                                                 */
/* Purpose:                                                                  */
/*   Close a file                                                            */
/*                                                                           */
/* Parameters:                                                               */
/*   HFILE hFile -- Handle of file to be closed                              */
/*                                                                           */
/* Returns: VOID                                                             */
/*****************************************************************************/

void CloseFile(HFILE hFile)
{
  _lclose (hFile);
}

/*****************************************************************************/
/*                 YankOutOnePfm                                             */
/* Purpose:                                                                  */
/*   Yanks out one pfm file from fonts.mfm                                   */
/*                                                                           */
/* Parameters:                                                               */
/*   HFILE hFontsFile -- handle to fonts.mfm file                            */
/*   int iIndex -- zero based index of pfm file to be extracted              */
/*   LPSTR lpDestPath -- path of directory where pfm files will be copied to */
/*   LPSTR lpIoBuff -- pointer to buffer to be used for I/O                  */
/*                                                                           */
/* Returns: int                                                              */
/*   0 if successful                                                         */
/*  -1 if failure                                                            */
/*****************************************************************************/

int YankOutOnePfm(HFILE hFontsFile, int iIndex, LPSTR lpDestPath, 
  LPSTR lpIoBuff)
{
  HFILE hPfmFile;
  FileRecord PfmFileRecord;
  LONG lBytesLeft;
  char pathBuff[128];
  WORD FileTime, FileDate;

  /* Get the Font File Record */
  lseek(hFontsFile, (LONG)(CONCAT_HEADER_LENGTH + iIndex * sizeof(FileRecord)),
        SEEK_SET);
  _lread(hFontsFile, &PfmFileRecord, sizeof(FileRecord));

  /* Calculate the interrupt date format - John Kwan */
  FileTime = PfmFileRecord.FileDate.min * 32 +
             PfmFileRecord.FileDate.hour * 2048;
  FileDate = PfmFileRecord.FileDate.day +
             PfmFileRecord.FileDate.month * 32 +
             (PfmFileRecord.FileDate.year - 80) * 512;

  /* Figure out the file to write */
  lstrcpy(pathBuff, lpDestPath);
  lstrcat(pathBuff, PfmFileRecord.FileName);

  /* See if a file existed and if it is newer or not */
  hPfmFile = OpenFileRead(pathBuff);
  if (hPfmFile != HFILE_ERROR)
    { /* old file existed by that name */
    WORD DiskFileTime, DiskFileDate;

    inregs.x.ax = 0x5700;
    inregs.x.bx = hPfmFile;
    lint86x(0x21, &inregs, &outregs, &segregs);
    DiskFileTime = outregs.x.cx;
    DiskFileDate = outregs.x.dx;

    CloseFile(hPfmFile);

    if (DiskFileDate > FileDate)
      return (0);
    else
      {
      if (DiskFileDate == FileDate)
        { /* Same Date, check time */
        if (DiskFileTime > FileTime)
          return (0);
        }
      }
    }

  /* Write it out */
  hPfmFile = OpenFileWrite(pathBuff);
  if (hPfmFile == HFILE_ERROR)
    return (-1);
  lseek(hFontsFile, PfmFileRecord.FileOffset, SEEK_SET);
  lBytesLeft = PfmFileRecord.FileLength;
  while (lBytesLeft > CONCAT_IO_BUFF_SIZE)
    {
    _lread(hFontsFile, lpIoBuff, CONCAT_IO_BUFF_SIZE);
    _lwrite(hPfmFile, lpIoBuff, CONCAT_IO_BUFF_SIZE);
    lBytesLeft = lBytesLeft - CONCAT_IO_BUFF_SIZE;
    }

  if (lBytesLeft > 0)
    {
    _lread(hFontsFile, lpIoBuff, (int)lBytesLeft);
    _lwrite(hPfmFile, lpIoBuff, (int)lBytesLeft);
    }

  /* Update the date of the file */
  inregs.x.ax = 0x5701;
  inregs.x.bx = hPfmFile;
  inregs.x.cx = FileTime;
  inregs.x.dx = FileDate;
  lint86x(0x21, &inregs, &outregs, &segregs);

  CloseFile(hPfmFile);

  return (0);
}

/*****************************************************************************/
/*                 UnConcat                                                  */
/* Purpose:                                                                  */
/*   UnConcats or takes apart the fonts.mfm file                             */
/*                                                                           */
/* Parameters:                                                               */
/*   LPSTR lpFontsMfm -- fully qualified name of fonts.mfm file              */
/*   LPSTR lpDestPath -- path of where pfm files are to be copied to         */
/*   LPSTR lpIoBuff -- pointer to buffer to be used for I/O                  */
/*                                                                           */
/* Returns: int                                                              */
/*   0 if successful                                                         */
/*  -1 if failure                                                            */
/*****************************************************************************/

int UnConcat(LPSTR lpFontsMfm, LPSTR lpDestPath, LPSTR lpIoBuff)
{
  int iNumPfms;
  int iVersion;
  int iStrLen, i;
  char magicString[CONCAT_MAGIC_SIZE];
  HFILE hFontsFile;

  /* Open the fonts file */
  hFontsFile = OpenFileRead(lpFontsMfm);
  if (hFontsFile == HFILE_ERROR)
    return (-1);

  /* Check the magic string for validity */
  lstrcpy(magicString, "Adobe Systems, Inc. Printer Font Metrics compressed file.");
  iStrLen = lstrlen(magicString);

  /* Read in the magic string */
  _lread(hFontsFile, lpIoBuff, CONCAT_MAGIC_SIZE);
  for (i=0; i<iStrLen; i++)
    {
    *(lpIoBuff + i) = *(lpIoBuff + i) & (char)0x7F;
    }

  /* Compare magic string */
  if (lstrcmp(lpIoBuff, magicString) != 0)
    {
    CloseFile(hFontsFile);
    return (-1);
    }

  /* Check the version */
  _lread(hFontsFile, &iVersion, sizeof(int));
  if (iVersion != CONCAT_VERSION)
    {
    CloseFile(hFontsFile);
    return (-1);
    }

  /* Get the number of pfms */
  _lread(hFontsFile, &iNumPfms, sizeof(int));

  /* Write out the pfm files */
  for (i = 0; i < iNumPfms; i++)
    {
    if (YankOutOnePfm(hFontsFile, i, lpDestPath, lpIoBuff) != 0)
      {
      CloseFile(hFontsFile);
      return (-1);
      }
    }

  CloseFile(hFontsFile);

  return (0);
}
