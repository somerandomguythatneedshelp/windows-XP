#ifndef _PFMPARSE_H
#define _PFMPARSE_H  1

/* NEAR functions */
WORD NEAR PFMPARSESEG PASCAL CreateMFDFile(HFILE hFile, 
                               LPFILEHDR lpFileHdr, 
                               LPFONTDIRECTORY lpFontDir,
                               LPPFMPROLOG FAR* lpfmList) ;
WORD NEAR PFMPARSESEG PASCAL MFDAllocateMemory(LPFILEHDR FAR* lplpFileHdr, 
                                   LPFONTDIRECTORY FAR* lplpFontDir,
                                   LPPFMPROLOG FAR* FAR* lplpfmList,
                                   WORD wNumFonts);
void NEAR PFMPARSESEG PASCAL MFDFreeMemory(LPFILEHDR lpFileHdr, 
                               LPFONTDIRECTORY lpFontDir,
                               LPPFMPROLOG FAR* FAR* lpfmList,
                               WORD wNumFonts);
WORD NEAR PFMPARSESEG PASCAL ConvertSFNTToFD(HPFONTFILE hpFontFile, HPFONTDIRECTORY hpFontDir, LPPFMPROLOG FAR *lppfmData);
WORD NEAR PFMPARSESEG PASCAL ConvertTrueTypeToFD(HPFONTFILE hpFontFile, HPFONTDIRECTORY hpFontDir, LPPFMPROLOG FAR *lppfmData);
WORD NEAR PFMPARSESEG PASCAL ConvertPFMToFD(HPFONTFILE, HPFONTDIRECTORY, LPPFMPROLOG FAR *,
                                             LPWORD, LPFONTINFO FAR *);
DWORD NEAR PFMPARSESEG PASCAL GetPFBSize(LPSTR lpPFBFileName);
DWORD NEAR PFMPARSESEG PASCAL GetPFMVersion(LPPFMPROLOG lpPFM);
WORD NEAR PASCAL CopyPFMToFD(HPFONTDIRECTORY, LPPFMPROLOG, 
                             DWORD, LPFONTINFO, BYTE);

/* FAR functions */
WORD FAR PASCAL GetMFMPath(LPSTR, WORD, LPSTR);
BOOL FAR PASCAL InstallPrinterFonts(LPPRINTERINFO, LPBYTE, LPBYTE);
int FAR PASCAL FontListCompare(LPVOID, LPVOID);
int FAR PASCAL FontCompare(LPVOID, LPVOID);
HFILE FAR PASCAL IsPPDMFMExist(LPSTR);

DWORD FAR PFMPARSESEG PASCAL CreatePFMFile(LPPFMPROLOG lpPFMProlog, 
                                LPSTR lpszPFMName, 
                                DWORD dwSize);
int FAR PASCAL IndexFontCompare(LPVOID elem1, LPVOID elem2, HPVOID ppFDirs);
BYTE FAR PASCAL WhichOutlnType(HPFONTDIRECTORY hpFontDir);

WORD FAR PASCAL ConvertFontsToMFD(LPSTR, HPFONTFILE, WORD, DWORD, DWORD, DWORD, LPSTR);

#endif  /* ifndef _PFMPARSE_H */
