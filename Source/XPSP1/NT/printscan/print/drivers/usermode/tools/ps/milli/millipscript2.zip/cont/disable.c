/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: DISABLE.C                                                    */
/*                                                                           */
/* Description: This module contains the functions for  ...                  */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"

#pragma code_seg(_ENABLESEG)


void FAR PASCAL FreeTTFontTable(LPPDEVICE lpdv) ;
void FAR PASCAL FreeSpecialPSData(LPPDEVICE lppd); // in TRAN\psdata.c
void FAR PASCAL FreePSInjectionRecord(LPPDEVICE lppd); // in TRAN\psdata.c


// undoes buffers created by initPDevice()

VOID   FAR  PASCAL  FreePDeviceBufs(LPPDEVICE lppd)
{
   LPREALIZEBUFS  lpCache ;

   lpCache = &lppd->GlobalBuffer.RealizeBufs ;
   
   if(lpCache->lpScoreArray)
      GlobalFreePtr(lpCache->lpScoreArray) ;
   lpCache->cScoreArray = 0 ;

   if(lpCache->lpTTFI)
      GlobalFreePtr(lpCache->lpTTFI) ;
   lpCache->cTTFI = 0 ;

   if(lpCache->lpFI)
      GlobalFreePtr(lpCache->lpFI) ;
   lpCache->cFI = 0 ;

   if (lppd->lptm)
      GlobalFreePtr(lppd->lptm);

   if (lppd->lpFontSubsTable)
      GlobalFreePtr(lppd->lpFontSubsTable);
/* --ang 2/25/96
  Don't free lpCache->lpFontCache here because 
  RealizeFont doesn't call disable every time. 
  This may result in lpFontCache->wUseCount never goes to 0.
  Do FreeCache at 2nd pass of RealizeFont time instead.
*/

   if(lpCache->lpdWidths)
      GlobalFreePtr(lpCache->lpdWidths) ;
   if(lpCache->rgwWidths)
      GlobalFreePtr(lpCache->rgwWidths) ;
   if(lpCache->devlpdWidths)
      GlobalFreePtr(lpCache->devlpdWidths) ;
   if(lpCache->devlpsWidths)
      GlobalFreePtr(lpCache->devlpsWidths) ;

   lpCache->lpdWidths  =  NULL ;
   lpCache->rgwWidths  =  NULL ;
   lpCache->devlpdWidths  =  NULL ;
   lpCache->devlpsWidths  =  NULL ;
   lpCache->sizlpdWidths  =  0 ;
   lpCache->sizrgwWidths  =  0 ;
   lpCache->sizdevlpsWidths  =  0 ;
   lpCache->sizdevlpdWidths  =  0 ;


   if(lppd->GlobalBuffer.lpSubStringBuf)
      GlobalFreePtr(lppd->GlobalBuffer.lpSubStringBuf) ;
   lppd->GlobalBuffer.cSubStringBuf = 0 ;
   lppd->GlobalBuffer.lpSubStringBuf = NULL ;

#ifdef Adobe_Driver   
   if (lppd->hOEMFilterData)
   {
      GlobalFree(lppd->hOEMFilterData);
      lppd->hOEMFilterData = (HANDLE)NULL;
   }
#endif
#ifdef ADD_EURO
   if (lppd->lpEuroFontList)
       FreeEuroFontList(&lppd->lpEuroFontList);
   if (lppd->lpSCDParams)
   {
       GlobalFreePtr(lppd->lpSCDParams);
       lppd->lpSCDParams = NULL;
   }
   lppd->NumEuroFonts = 0;
#endif

}



/*****************************************************************************/
/*                 DevDisable                                                */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*   LP  -- lpdevice                                                         */
/*                                                                           */
/* Returns:                                                                                */                                              
/*****************************************************************************/


VOID _loadds FAR PASCAL DevDisable(LP lpDevice)
{
   LPPDEVICE lppd;
   BOOL  fIgnore;

   lppd = (LPPDEVICE)lpDevice;

   // check for our pdevice
   if (lppd->sMagic == LUCAS)
   {
      // Close out any pending code generation.
      if( stCurrentLppd( lppd ) != ST_ENDED    &&
          stCurrentLppd( lppd ) != ST_ENABLED  &&
       fNoStateChange( lppd ) != TRUE )
      {                                                   
         ESCAbortDoc( lppd, NULL, NULL );
      }

      // we've reset DC & not actually ending the job
      if(fNoStateChange( lppd ) != TRUE)   
      {
         fIgnore = fChangeStateLppdSt(lppd, ST_TERMINAL);
      }

      //Free the dynamic portions of PDEVICE.
      FreePDeviceBufs(lppd);  // undoes buffers created by initPDevice()
      PsExtDevmodeDestroy(lppd->lpPSExtDevmode);
      FreePrinter(lppd->lpWPXblock);
      FreeTTFontTable(lppd) ;
      FreeSpecialPSData(lppd);
      FreePSInjectionRecord(lppd);

   }
     
#ifdef PS_MEMTRACE
   MemCheckDisable();
#endif
}




