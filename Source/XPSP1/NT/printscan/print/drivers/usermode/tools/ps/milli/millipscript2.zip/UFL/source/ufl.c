/*
 *    Adobe Universal Font Library
 *
 *    Copyright (c) 1996 Adobe Systems Inc.
 *    All Rights Reserved
 *
 *    UFL.c
 *
 *  To Do:
 *
 * $Header: $
 */


#include "UFL.h"
#include "UFLMem.h"
#include "UFLStd.h"
#include "UFLPriv.h"
#include "UFLErr.h"
#include "UFO.h"


/* Global: this string is shared among all T1/T3/T42 downloading */
const char *gnotdefArray = " 256 array 0 1 255 {1 index exch /.notdef put} for ";
const char *Notdef    = ".notdef";
const char *Hyphen    = "hyphen";
const char *Minus     = "minus";
const char *SftHyphen = "sfthyphen";
const char *UFLSpace     = "space";
const char *Bullet    = "bullet";

UFLHANDLE 
UFLInit( 
    const UFLBool           bDLGlyphTracking,
    const UFLMemObj         *pMemObj, 
    const UFLFontProcs      *pFontProcs, 
    const UFLOutputDevice   *pOutDev 
    )
{
    UFLStruct    *pUFL;

    if ( pMemObj == 0 || pFontProcs == 0 || pOutDev == 0 )
	return 0;

    pUFL = (UFLStruct *)UFLNewPtr( pMemObj, sizeof(*pUFL) );
    if ( pUFL ) 
    {
	pUFL->bDLGlyphTracking = bDLGlyphTracking;
	pUFL->mem              = *pMemObj;
	pUFL->fontProcs        = *pFontProcs;
	pUFL->outDev           = *pOutDev;
	pUFL->hOut = StrmInit( &pUFL->mem, pUFL->outDev.pstream, (const UFLBool)pOutDev->bAscii );

	if ( !pUFL->hOut ) 
	{
	    UFLDeletePtr( pMemObj, pUFL );
	    pUFL = 0;
	}
    }

    return (UFLHANDLE)pUFL;
}


void 
UFLCleanUp( 
    UFLHANDLE h 
    )
{
    UFLStruct    *pUFL = (UFLStruct *)h;

    StrmCleanUp( pUFL->hOut );
    UFLDeletePtr( &pUFL->mem, h );
}

UFLBool
bUFLTestRestricted(
    const UFLHANDLE  h, 
    const UFLRequest *pRequest 
    )
{
    UFLStruct    *pUFL = (UFLStruct *)h;
    
    if ( pUFL == 0 )
	return 0;

    return bUFOTestRestricted( &pUFL->mem, pUFL, pRequest );
}

UFO 
UFLNewFont( 
    const UFLHANDLE  h, 
    const UFLRequest *pRequest 
    )
{
    UFLStruct    *pUFL = (UFLStruct *)h;
    
    if ( pUFL == 0 )
	return 0;

    return UFOInit( &pUFL->mem, pUFL, pRequest );
}

/*===========================================================================
UFLDownloadIncr -- Downloads a font incrementally.  The first time this is 
called for a particular font, it will create a base font, and download a set of
requested characters.  Subsequent calls on the same font will download additional
characters.
    aFont (in) -- UFL handle that is obtained when UFLBeginFont is called.

    pGlyphs (in) -- Pointer to a UFLGlyphsInfo - has all the information
	about this updating, including:
	Number of glyphs to be output 
	List of output glyphs, each glyph is 2 bytes long 
	List of glyph names.  This list can be NULL. If this is 
	   the case, UFL uses the name defined in the font 
	A list of indices to be used to index the ppGlyphNames list.
	A List of Unicode or Script-code points
	... and ... depends on the extension to UFLGlyphsInfo structure ....
    
    returns:
	noErr or error code if unsuccessful
==============================================================================*/

UFLErrCode 
UFLDownloadIncr( 
    const UFO           h,   
    const UFLGlyphsInfo *pGlyphs,
    unsigned long       *pVMUsage,
	unsigned long           *pFCUsage
    )
{
    if ( h == 0 )
	return kErrInvalidHandle;

    /* swong: pFCNeeded for T32 FontCache tracking */
    return UFODownloadIncr( (UFOStruct *)h, pGlyphs, pVMUsage, pFCUsage );
}

/*===========================================================================
UFLVMNeeded -- Get a guestimate of VM needed for a download request.
    aFont (in) -- UFL handle that is obtained when UFLBeginFont is called.
    pGlyphs (in) -- Pointer to a UFLGlyphsInfo - has all the information
	about this updating, including:
	Number of glyphs to be output 
	List of output glyphs, each glyph is 2 bytes long 
	List of glyph names.  This list can be NULL. If this is 
	   the case, UFL uses the name defined in the font 
	A list of indices to be used to index the ppGlyphNames list.
	A List of Unicode or Script-code points
	... and ... depends on the extension to UFLGlyphsInfo structure ....

    pVMNeeded (in) -- Pointer to the VMNeeded result.
    
    returns:
	noErr or error code if unsuccessful
==============================================================================*/

UFLErrCode 
UFLVMNeeded( 
    const UFO            h, 
    const UFLGlyphsInfo  *pGlyphs,
    unsigned long        *pVMNeeded,
    unsigned long            *pFCNeeded)
{
	if ( h == 0 )
		return kErrInvalidHandle;

    /* swong: pFCNeeded for T32 FontCache tracking */
    return UFOVMNeeded( (UFOStruct *)h, pGlyphs, pVMNeeded, pFCNeeded );
}

void 
UFLDeleteFont( 
    UFO h 
    )
{
	if ( h == 0 ) return ;

    UFOCleanUp( (UFOStruct *)h );
}


UFLErrCode 
UFLUndefineFont( 
	const UFO   h
)
{
	if ( h == 0 )
		return kErrInvalidHandle;

	return UFOUndefineFont( (UFOStruct *)h);
}


UFO
UFLCopyFont( 
	const UFO   h,
    const UFLRequest* pRequest
)
{
	if ( h == 0 )
		return NULL;

	return UFOCopyFont( (UFOStruct *)h, pRequest );
}




/*===========================================================================
UFLGIDsToCIDs -- This function can only be used with a CID CFF font. It 
    is used to obtain CIDs from a list of GIDs.

    aFont (in)   -- UFL handle that is obtained when UFLBeginFont is called.
    cGlyphs (in) -- Number of glyhs (GIDs) to be converted.
    pGIDs  (in)  -- GID list.
    pCIDs  (out) -- Result CIDs.

    returns:
	noErr or error code if unsuccessful

==============================================================================*/
UFLErrCode
UFLGIDsToCIDs(
   const UFO          aCFFFont, 
   const short        cGlyphs,
   const UFLGlyphID   *pGIDs,
   unsigned short     *pCIDs
   )
{
	if ( aCFFFont == 0 )
		return kErrInvalidHandle;

    return
	/* MWCWP1 doesn't like the implicit cast from void*const to t_UFOStruct*  --jfu */
	UFOGIDsToCIDs((UFOStruct *) aCFFFont, cGlyphs, pGIDs, pCIDs);
}

