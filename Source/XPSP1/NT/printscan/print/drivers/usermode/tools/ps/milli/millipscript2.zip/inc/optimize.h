/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: OPTIMIZE.H                                                   */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/*****************************************************************************/


//NOTES:
//
//things to keep track of...
//number of pages a font is used in
//number of times font is used per page
//page list for each font + usage?
//font list for each page + usage?
//what about font instances?
//

typedef struct _OPTFONT
{
   BYTE bUsage;    /* instance,page,job */
   BYTE bType;     /* normal,bold,italic,bolditalic */
   BYTE bStyle;    /* normal,bold,italic,underline,shadow,strikethrough */
}OPTFONT, FAR * LPOPTFONT;

typedef struct _OPTFONTPAGE
{
   WORD wPageNum;
   WORD wFont;
}OPTFONTPAGE, FAR * LPOPTFONTPAGE;

typedef struct _OPTPAGE
{
   LONG lBegin;    /* file pointer to start of page */
   LONG lEnd;      /* file pointer to end of page */
}OPTPAGE, FAR * LPOPTPAGE;

/* line,box,rbox,ellipse,circle,image */
typedef DWORD OPTGRAPHICS, FAR * LPOPTGRAPHICS;

typedef struct _OPTIMIZE
{
   MEMORY mFont;
   MEMORY mFontPage;
   MEMORY mPage;
   MEMORY mGraphics;
   MEMORY mForms;
   MEMORY mPatterns;
}OPTIMIZE, FAR * LPOPTIMIZE;


