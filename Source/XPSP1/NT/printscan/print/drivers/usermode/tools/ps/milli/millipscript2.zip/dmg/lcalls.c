/*******************************************************************/
/*  Lcalls.c Dummy module to fake long calls until we can write one*/
/*******************************************************************/

#include "generic.h"

#pragma code_seg(_TSTARTSEG)

#if 0
#include "Windows.h"
#include "dos.h"
#include "time.h"
#include "math.h"
#include "stdlib.h"
#include "string.h"
#include "errno.h"
#include "lcalls.h"
#endif

/*******************************************************************/

double latof(LPSTR lpStr)
{
  return (atof((const char near *)LOWORD((DWORD)lpStr)));
}

/*******************************************************************/

LPSTR l_strdate(LPSTR lpStr)
{ 
  time_t timer;
  struct tm *timeS;
      
  time (&timer);         
  if( timeS = localtime (&timer) )
     wsprintf (lpStr, "%02d/%02d/%04d", timeS->tm_mon+1, timeS->tm_mday, timeS->tm_year+1900);
  else
     *lpStr = NULL;                      

  return (lpStr);
}

/*******************************************************************/

LPSTR l_strtime(LPSTR lpStr)
{
  return ((LPSTR)_strtime((char near *)LOWORD((DWORD)lpStr)));
}

/*******************************************************************/

#if 0
LPSTR lstrchr(LPSTR lpStr, int i)
{
  return ((LPSTR)(strchr((const char near *)LOWORD((DWORD)lpStr),i)));
}

/*******************************************************************/

int latoi(LPSTR lpStr)
{
  return (atoi((const char near *)LOWORD((DWORD)lpStr)));
}

/*******************************************************************/

unsigned l_dos_findfirst(LPSTR lpStr, unsigned u, struct find_t FAR *lpFileInfo)
{
  return (_dos_findfirst((const char near *)LOWORD((DWORD)lpStr),
                         u,
                         (struct find_t near *)LOWORD((DWORD)lpFileInfo)
                         ));
}

/*******************************************************************/

unsigned l_dos_findnext(struct find_t FAR *lpFileInfo)
{
  return (_dos_findnext((struct find_t near *)LOWORD((DWORD)lpFileInfo)));
}

/*******************************************************************/

int lint86x(int i, 
            union REGS FAR *lpInRegs,
            union REGS FAR *lpOutRegs,
            struct SREGS FAR *lpSegRegs)
{
  return (_int86x(i,
                  (union _REGS near *)LOWORD((DWORD)lpInRegs),
                  (union _REGS near *)LOWORD((DWORD)lpOutRegs),
                  (struct _SREGS near *)LOWORD((DWORD)lpSegRegs)
                  ));
}
#endif

