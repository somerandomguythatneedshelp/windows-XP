/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1994 Adobe Systems, Inc. All rights reserved.               */
/*                                                                           */
/* Module Name: OEMPLUGI.H                                                   */
/*                                                                           */
/* Description: This module contains the defines and function prototypes     */
/*   for OEM Customization use.                                              */
/*                                                                           */
/*****************************************************************************/

//  All of these enumerations correspond to UI options.
#define OEM_VERSION 0x0100
#define OEM_DRV_VERSION 0x0410

#ifndef _INC_DEVMODE

#define CUSTOMNAMELEN   64

#define WMNAMELEN       18

typedef  enum {ONE_UP, TWO_UP, FOUR_UP, SIX_UP, NINE_UP, SIXTEEN_UP, 
               NUM_LAYOUTS} LAYOUT ;
typedef  enum {OR_PORTRAIT, OR_LANDSCAPE, OR_ROTLANDSCAPE} PAPER_ORIENTATION  ;
typedef  enum {DIA_SPEED, DIA_PORTABLE, DIA_EPS, DIA_ARCHIVE, 
               DIA_PJL_ARCHIVE} DIALECT ;
typedef  enum {TTSUBSFORMAT_TABLE , TTSUBSFORMAT_USEPRINTER, 
               TTSUBSFORMAT_DOWNLOADTT} TT_SUBS_SOURCE ;

typedef  enum {COLOR_8BIT, COLOR_FULL_COLOR } COLOR ;

typedef  enum {ICM_DISABLE, ICM_ALLOW, ICM_ALWAYS} COLOR_ICM;

typedef  enum {COLOR_MATCH_DONT_CARE, COLOR_MATCH_NONE,
               COLOR_MATCHING_ON_HOST, COLOR_MATCHING_ON_PRINTER,
               COLOR_MATCHING_PRINTER_CALIBRATION, COLOR_MATCH_ACROSS_PRINTERS}
               COLOR_METHOD ;

typedef  enum {INTENT_DONT_CARE, INTENT_SATURATION, INTENT_CONTRAST,
               INTENT_COLORMETRIC} RENDERING_INTENT ;

typedef  enum {NO_MARGINS,  DEFAULT_MARGINS } MARGINS ;

typedef  enum {PS_DLFORMAT_OUTLINES = 1, PS_DLFORMAT_BITMAPS,
               PS_DLFORMAT_NATIVE, PS_DLFORMAT_DONT_SEND } PS_DLFORMAT ;

typedef  enum {TT_DLFORMAT_NONE, TT_DLFORMAT_TYPE1,  TT_DLFORMAT_TYPE3,
               TT_DLFORMAT_TYPE42, TT_DLFORMAT_TRUEIMAGE} TT_DL_FORMAT ;

typedef  enum {PROTOCOL_ASCII,
              PROTOCOL_BCP, PROTOCOL_TBCP, PROTOCOL_BINARY } PROTOCOLS ;

typedef  enum  {ASCII= 1, BCP, TBCP, BINARY} DEFAULTPROTOCOL;

// UIConstraint
// Structure to be used with DrvValidateOptionArray function. THuynh 10/25/95
// UICARRAY structure.  OEM needs to allocate an array of UICARRAY that
// can be filled with the current options and the suggested options.
typedef struct _tagUICARRAY
{
      WORD wOldOption;
      WORD wNewOption;
} UICARRAY, FAR * LPUICARRAY;

// UICONFLICT structure.
typedef struct _tagUICONFLICT
{
      WORD wMainConstrainer;
      WORD wOptionConstrainer;
      WORD wMainConstrained;
      WORD wOptionConstrained;
} UICONFLICT, FAR * LPUICONFLICT;
              
#endif

// Definition of OEMInitDll's wEntry
typedef enum {ADVSETUPDLG, EXTDEVMODE, PROPSHEET, DEVINSTALL, PRINTING, DEVICECAP, VALIDATEDM}ENTRY_TYPE;

// Definition of OEMStartDoc's wPrintJobType 
typedef enum {PRESTARTDOC, PREMINHEADER, STARTDOCJOB, OPENCHANNELJOB, MINHEADERJOB, RESETDCCALL} PRINTJOB_TYPE;


// Alert value definition
typedef enum {ENABLE_FEATURE_NO_ALERT, DISABLE_FEATURE_NO_ALERT, DISPLAY_ALERT}ALERT_TYPE;

// values for bHalftoneModified flag
#define MODIFIED_NONE       0x00
#define MODIFIED_FREQ       0x01
#define MODIFIED_ANGLE      0x02
#define MODIFIED_BOTH       0x03


// UIConstraint
// Return value from DRVValidateOptionArray
#define VAL_NO_CONSTRAINT   0
#define VAL_CONSTRAINT      1
#define VAL_INVALID_PARAM   2
#define VAL_BUFFER_TOO_SMALL 3

// Flags used to identify poscript mode used in SendMode.
#define PS_BCP_MODE     0x01
#define PS_CTRL_D_BEFORE_MODE   0x02
#define PS_CTRL_D_AFTER_MODE    0x04


/* The following are general defines */

#define MAX_NUM_CUSTOM_PAPERS     3
#define MAX_NUM_PAPER_MARGINS   100
#define MAX_NUM_PAPER_SIZES     100
#define MAX_NUM_OPTION_STATES   100
#define MAX_NUM_OEM_DATA         10

/* The following indicies are the dwPSIndex in OEMSendPS */

#define PS_INDEX_JCL_BEGIN             1
#define PS_INDEX_JCL_END               2
#define PS_INDEX_JCL_FEATURE           3
#define PS_INDEX_JCL_TO_PS_INTERPRETER 4
#define PS_INDEX_PS_ADOBE              5
#define PS_INDEX_TITLE                 6
#define PS_INDEX_CREATOR               7
#define PS_INDEX_CREATION_DATE         8
#define PS_INDEX_BOUNDING_BOX          9
#define PS_INDEX_PAGES_AT_END          10
#define PS_INDEX_PAGE_ORDER            11
#define PS_INDEX_REQUIREMENTS          12               //d DSC 3.1
#define PS_INDEX_PLUS_FONT             13
#define PS_INDEX_DOCUMENT_NEEDED_FONTS_AT_END    14  // d DSC 3.1
#define PS_INDEX_DOCUMENT_SUPPLIED_FONTS_AT_END  15  // d DSC 3.1
#define PS_INDEX_DOCUMENT_DATA                   16
#define PS_INDEX_LANGUAGE_LEVEL        17
#define PS_INDEX_END_COMMENTS          18
#define PS_INDEX_BEGIN_PROLOG          19
#define PS_INDEX_END_PROLOG            20
#define PS_INDEX_PROCSET               21   //d DSC 3.1
#define PS_INDEX_RESOURCE              23
#define PS_INDEX_BEGIN_SETUP           25
#define PS_INDEX_END_SETUP             26
#define PS_INDEX_FEATURE               27
#define PS_INDEX_PAGE_NUMBER           28
#define PS_INDEX_BEGIN_PAGE_SETUP      29
#define PS_INDEX_END_PAGE_SETUP        30
#define PS_INDEX_INCLUDE_FONT          31 // d DSC 3.1
#define PS_INDEX_BEGIN_FONT            32 // d DSC 3.1
#define PS_INDEX_END_FONT              33   // d DSC 3.1
#define PS_INDEX_PAGE_TRAILER          34
#define PS_INDEX_TRAILER               35
#define PS_INDEX_DOCUMENT_NEEDED_FONTS_NAME      36 // d DSC 3.1
#define PS_INDEX_DOCUMENT_SUPPLIED_FONTS_NAME    37 // d DSC 3.1
#define PS_INDEX_PAGES_NUMBER          38
#define PS_INDEX_EOF                   39
#define PS_INDEX_LEADING_CTRL_D        40
#define PS_INDEX_TRAILING_CTRL_D       41
#define PS_INDEX_LEADING_CTRL_AM       42
#define PS_INDEX_TBCP_END              43
#define PS_INDEX_SHOWPAGE              44
#define PS_INDEX_OPENCHANNEL           45     // open channel pass through
#define PS_INDEX_USER                  46     // user name        
#define PS_INDEX_P8BIT                 47
#define PS_INDEX_PHYSICAL_PAGES       48
#define PS_INDEX_VMSAVE_BEGIN          49
#define PS_INDEX_VMSAVE_END            50
#define PS_INDEX_VMRESTORE_BEGIN       51
#define PS_INDEX_VMRESTORE_END        52
#define PS_INDEX_RESTORE_BEGIN        53
#define PS_INDEX_RESTORE_END             54
#define PS_INDEX_SAVE_BEGIN            55
#define PS_INDEX_SAVE_END               56
#define PS_INDEX_ECHO                   57
#define PS_INDEX_BEGINDOCUMENT        58   //d DSC 3.1
#define PS_INDEX_ENDDOCUMENT           59     //d DSC 3.1
#define PS_INDEX_INCLUDEPROCSET        60   //d DSC 3.1
#define PS_INDEX_VIEWING_ORIENTATION   61
#define PS_INDEX_BEGIN_DEFAULTS        62
#define PS_INDEX_END_DEFAULTS          63
#define PS_INDEX_DOCUMENT_NEEDED_RESOURCES      64
#define PS_INDEX_DOCUMENT_SUPPLIED_RESOURCES    65
#define PS_INDEX_DOCUMENT_NEEDED_RESOURCES_AT_END      14
#define PS_INDEX_DOCUMENT_SUPPLIED_RESOURCES_AT_END    15
#define PS_INDEX_INCLUDE_RESOURCES     66
#define PS_INDEX_BEGIN_RESOURCES       67   // use in PS_INDEX_RESOURCE
#define PS_INDEX_END_RESOURCES         68
#define PS_INDEX_PAGE_BOUNDINGBOX      69
#define PS_INDEX_BEGINUNCOUNTEDDATA    70
#define PS_INDEX_ENDUNCOUNTEDDATA      71
// for NT compatibility
#define PS_INDEX_ENDPAGECOMMENTS       72
#define PS_INDEX_PLATECOLOR            73
#define PS_INDEX_DOCUMENTPROCESSCOLORS         74
#define PS_INDEX_DOCUMENTPROCESSCOLORSATEND    75


/* Property page defines to turn on or off standard property pages */

#define PS_DISPLAY_ALL              0xFFFFFFFF
#define PS_DISPLAY_PAPER            0x00000001
#define PS_DISPLAY_GRAPHICS         0x00000002
#define PS_DISPLAY_FONTS            0x00000004
#define PS_DISPLAY_DEVICE_OPTIONS   0x00000008
#define PS_DISPLAY_POSTSCRIPT       0x00000010
#define PS_DISPLAY_WATERMARKS       0x00000020
#define PS_DISPLAY_NONE             0x00000000


/* Maximum translation string length */
#define MAX_TRANS_STRING_LEN      128

typedef struct {
    LPSTR   lpModuleName;
    LPSTR   lpUserString;
    WORD    wDataSize;
    LPBYTE  lpOEMData;
} OEMFILTERINFO, FAR *LPOEMFILTERINFO;

typedef enum {APP_FILTER, FAX_FILTER, OEM_FILTER}OEMFILTER_TYPE;

#define MAX_OEMFILTER  3

/* DLL Types used */
#define DLL_TYPE_OEM_CUST    1
#define DLL_TYPE_PS_FAX      2
#define DLL_TYPE_APP         3

#define DLL_TYPE_WEB_PRINTER 4

/* The following are the predefined iDataItemID numbers */

/* All items identified as ID_DM_DM_ refer to fields inside the public
   devmode portion of the devmode for current values */

#define ID_DM_DM_DEVICENAME              1
#define ID_DM_DM_SPECVERSION             2
#define ID_DM_DM_ORIENTATION             3
#define ID_DM_DM_PAPERSIZE               4
#define ID_DM_DM_PAPERLENGTH             5
#define ID_DM_DM_PAPERWIDTH              6
#define ID_DM_DM_SCALE                   7
#define ID_DM_DM_COPIES                  8
#define ID_DM_DM_DEFAULTSOURCE           9
#define ID_DM_DM_PRINTQUALITY            10
#define ID_DM_DM_COLOR                   11
#define ID_DM_DM_DUPLEX                  12
#define ID_DM_DM_YRESOLUTION             13
#define ID_DM_DM_TTOPTION                14
#define ID_DM_DM_COLLATE                 15

/* All items identified as ID_DM_ are in the private portion of the devmode
   for the current values */

#define ID_DM_COPIES                     16
#define ID_DM_LAYOUT                     17
#define ID_DM_PRINT_PAGE_BORDER          18
#define ID_DM_PAPER_ORIENTATION          19
#define ID_DM_USE_IMAGE_COLOR_MATCHING   22
#define ID_DM_COLOR_METHOD               23
#define ID_DM_RENDERING_INTENT           24
#define ID_DM_USE_HALFTONE_PARAMS        25
#define ID_DM_SCREEN_FREQ                26
#define ID_DM_SCREEN_ANGLE               27
#define ID_DM_NEGATIVE_IMAGE             28
#define ID_DM_MIRROR                     29
#define ID_DM_DIALECT                    31
#define ID_DM_CURRENT_CUST_PAPER         36
#define ID_DM_APP_CUST_WIDTH             37
#define ID_DM_APP_CUST_HEIGHT            38
#define ID_DM_DOWNLOAD_HEADER            39
#define ID_DM_USE_ERROR_HANDLER          40
#define ID_DM_USER_VM_SELECTION          41
#define ID_DM_PPD_PASSWORD               42
#define ID_DM_TT_DL_FORMAT               43
#define ID_DM_PS_DL_FORMAT               44
#define ID_DM_TT_SUBS_SOURCE             45
#define ID_DM_MIN_OUTLINE_PPEM           46
#define ID_DM_JOB_TIMEOUT                47
#define ID_DM_WAIT_TIMEOUT               48
#define ID_DM_USE_LEVEL2                 49
#define ID_DM_BITMAP_COMPRESSION         50
#define ID_DM_PROTOCOL                   51
#define ID_DM_SEND_CTRL_D_BEFORE         52
#define ID_DM_SEND_CTRL_D_AFTER          53
#define ID_DM_IS_ROTATED                 54

//#define ID_DM_PJL_PROTOCOL             55  not supported
//#define ID_DM_VM_TRACKING              56  not supported
#define ID_DM_MIN_VM_BOUND               57
#define ID_DM_MAX_VM_BOUND               58
#define ID_DM_ALLOW_EXIT_SERVER          60
#define ID_DM_FAVOR_TRUETYPE             62  
#define ID_DM_USE_LANGUAGE_LEVEL         63
#define ID_DM_USER_FONTCACHE_SELECTION   64
// 65 is not used
#define ID_DM_AVAILABLE_VM               66
/* 67 is not used */
#define ID_DM_TT_RASTERIZER_TYPE         68
#define ID_DM_WATERMARK_FIRSTPAGEONLY    69
#define ID_DM_WATERMARK_FOREGROUND       70
#define ID_DM_WATERMARK_OUTLINE          71
#define ID_DM_WATERMARK                  72
/* 73 is not used */
/* 74 is not used */
#define ID_DM_ABSOLUTECOLORMETRIC        75
#define ID_DM_LPSZOUTPUT                 76
#define ID_DM_ADD_EURO                   77
/* 78 is not used */
/* 79 is not used */
/* 80 is not used */
/* 81 is not used */
#define ID_DM_FAXING_P                   82
#define ID_DM_FAXING_D                   83

#define ID_DM_FAX_35FONTS_ONLY           85
#define ID_DM_HALFTONE_MODIFIED          86

#define ID_DM_FULL_DOWNLOAD              93
#define ID_DM_TRUETYPE_WIDE              94
#define ID_DM_TRUETYPE_FAST              95

// Flags only meanifull for Far-East Win'95
#define ID_DM_EUDC_ABLE                  96

#define ID_DM_DMMEDIATYPE                97
#define ID_DM_DITHERTYPE                 98
#define ID_DM_COLLATE                    99

#define ID_DM_AVAILABLE_FONTCACHE        100
#define ID_DM_MIN_FONTCACHE_BOUND        101
#define ID_DM_MAX_FONTCACHE_BOUND        102


/* All items identified as ID_DEFAULT_ refer to the private portion of the
   devmode as built from default values from the PPD */
#define ID_DEFAULT_RES_SCREEN_FREQ           500
#define ID_DEFAULT_RES_SCREEN_ANGLE          501

#define ID_DEFAULT_LANDSCAPE_ORIENTATION_PLUS90     553
#define ID_DEFAULT_CUSTOM_PAGE_SIZE          567
#define ID_DEFAULT_CUSTOM_MIN_WIDTH          569
#define ID_DEFAULT_CUSTOM_MAX_WIDTH          570
#define ID_DEFAULT_CUSTOM_MIN_HEIGHT         571
#define ID_DEFAULT_CUSTOM_MAX_HEIGHT         572

#define ID_DEFAULT_CUSTOM_MIN_WIDTHOFFSET    573
#define ID_DEFAULT_CUSTOM_MAX_WIDTHOFFSET    574
#define ID_DEFAULT_CUSTOM_MIN_HEIGHTOFFSET   575
#define ID_DEFAULT_CUSTOM_MAX_HEIGHTOFFSET   576

#define ID_DEFAULT_PJL_SUPPORT               577
#define ID_DEFAULT_BCP_SUPPORT               578
#define ID_DEFAULT_TBCP_SUPPORT              579
#define ID_DEFAULT_LANGUAGE_LEVEL            580
#define ID_DEFAULT_FREE_VM                   581
#define ID_DEFAULT_PPDFILENAME               585

#define ID_DEFAULT_CUSTOM_IS_CUTSHEET        586
#define ID_DEFAULT_CUSTOM_MARGIN_LEFT        587
#define ID_DEFAULT_CUSTOM_MARGIN_RIGHT       588
#define ID_DEFAULT_CUSTOM_MARGIN_TOP         589
#define ID_DEFAULT_CUSTOM_MARGIN_BOTTOM      590

#define ID_DEFAULT_DUPLEX                    591
#define ID_DEFAULT_COLORDEVICE               592
#define ID_DEFAULT_PCFILENAME                593
#define ID_DEFAULT_PRODUCT                   594
#define ID_DEFAULT_PSVERSION                 595
#define ID_DEFAULT_MODELNAME                 596
#define ID_DEFAULT_MANUFACTURER              597
#define ID_DEFAULT_PASSWORD                  598
#define ID_DEFAULT_PATCHFILE                 599

#define ID_DEFAULT_FAX_SUPPORT               600
#define ID_DEFAULT_TRUEIMAGE                 601
#define ID_DEFAULT_USER_DEFINED_PROTOCOL     602

#define ID_DEFAULT_JOB_TIMEOUT               603
#define ID_DEFAULT_WAIT_TIMEOUT              604
#define ID_DEFAULT_USE_ERROR_HANDLER         605
#define ID_DEFAULT_ERROR_HANDLER_EXIST       606
#define ID_DEFAULT_PRINTER_FONTCACHE         607

#define ID_DEFAULT_COLLATE                   608
#define ID_DEFAULT_OUTPUTORDER               609
#define ID_DEFAULT_MANUALFEED                610

/* This is the general data that there's only one copy of. */
#define ID_ALERT_INCOMPATIBLE            700

/* This flag checks if ICM profile exist or not */
#define ID_CHECK_ICMPROFILE              701

/* These are the commands into the driver for OEMDoCommand */

#define ID_COMMAND_ENUMDFONTS            1000
#define ID_COMMAND_CANCEL                1001
#define ID_COMMAND_UPDATE_GLOBAL         1002
#define ID_COMMAND_SEND_MODE             1006
#define ID_COMMAND_DOWNLOAD_HEADER       1007

/* Margins are handled by adding the number of the paper index to the base
   number defined here. For example, if you want the left margin of the 5th
   paper you add 4 to ID_DM_MARGIN_BASE_LEFT. All indicies are 0 based */

#define ID_DM_MARGIN_BASE_LEFT           1200
#define ID_DM_MARGIN_BASE_RIGHT          1300
#define ID_DM_MARGIN_BASE_TOP            1400
#define ID_DM_MARGIN_BASE_BOTTOM         1500

/* Paper lengths and withs are handled by adding the 0 based index of the
   paper to the base index */

#define ID_DEFAULT_PAPER_HEIGHT_BASE         2000
#define ID_DEFAULT_PAPER_WIDTH_BASE          2100

/* Custom Paper is handled by adding the number of the Custom Paper index 
   to the base numbers defined here. For example, if you want the width
   of the second custom paper you add 1 to ID_DEFAULT_CUSTOM_WIDTH_BASE.
   All indicies are 0 based */

#define ID_DM_CUSTOM_NAME_BASE           2200
#define ID_DM_CUSTOM_WIDTH_BASE          2300
#define ID_DM_CUSTOM_HEIGHT_BASE         2400
#define ID_DM_CUSTOM_TRANSVERSE_BASE     2500
#define ID_DM_CUSTOM_WIDTH_OFFSET_BASE   2600
#define ID_DM_CUSTOM_HEIGHT_OFFSET_BASE  2700
#define ID_DM_CUSTOM_MARGIN_LEFT_BASE    4400
#define ID_DM_CUSTOM_MARGIN_RIGHT_BASE   4500
#define ID_DM_CUSTOM_MARGIN_TOP_BASE     4600
#define ID_DM_CUSTOM_MARGIN_BOTTOM_BASE  4700


#ifndef PRINTCAP_DEFINED

/* These are the predefined headers currently in use */
#define  IND_PAPERINFO       0
#define  IND_PAGEREGIONINFO  1   // use generic option struct
#define  IND_DUPLEXINGINFO   2   // use generic option struct
#define  IND_INPUTSLOTINFO   3
#define  IND_RESOLUTIONINFO  4  
#define  IND_OUTPUTBININFO   5   // use generic option struct
#define  IND_MEDIATYPEINFO   6   // use generic option struct
#define  IND_MEMORYINFO      7
#define  IND_COLLATIONINFO   8
#define  IND_OUTPUTORDERINFO 9
#define  IND_NUMPREDEFINEDHDRS  10   // one more than last value.

#endif

/* The following is the base value for the predefined header option states.
   To get the ID for a particular option state add the zero based index to
   the base. The DM refers to the current values. The DEFAULT refers to the 
   default values found in the PPD */

#define ID_DM_PREDEFINED_OPTIONS_BASE    3400
#define ID_DM_PAPERSIZE                  (ID_DM_PREDEFINED_OPTIONS_BASE+IND_PAPERINFO)
#define ID_DM_PAGEREGION                 (ID_DM_PREDEFINED_OPTIONS_BASE+IND_PAGEREGIONINFO)
#define ID_DM_DUPLEX                     (ID_DM_PREDEFINED_OPTIONS_BASE+IND_DUPLEXINGINFO)
#define ID_DM_INPUTSLOT                  (ID_DM_PREDEFINED_OPTIONS_BASE+IND_INPUTSLOTINFO)
#define ID_DM_RESOLUTION                 (ID_DM_PREDEFINED_OPTIONS_BASE+IND_RESOLUTIONINFO)
#define ID_DM_OUTPUTBIN                  (ID_DM_PREDEFINED_OPTIONS_BASE+IND_OUTPUTBININFO)
#define ID_DM_MEDIATYPE                  (ID_DM_PREDEFINED_OPTIONS_BASE+IND_MEDIATYPEINFO)
#define ID_DM_INSTALLED_MEMORY           (ID_DM_PREDEFINED_OPTIONS_BASE+IND_MEMORYINFO)
#define ID_DM_COLLATION                  (ID_DM_PREDEFINED_OPTIONS_BASE+IND_COLLATIONINFO)
#define ID_DM_OUTPUTORDER                (ID_DM_PREDEFINED_OPTIONS_BASE+IND_OUTPUTORDERINFO)

/* The following is the base value for the Document sticky option states.
   To get the ID for a particular option state add the zero based index to
   the base. The DM refers to the current values. The DEFAULT refers to the 
   default values found in the PPD */

#define ID_DM_DOCUMENT_STICKY_OPTIONS_BASE     3600

/* The following is the base value for the Printer sticky option states.
   To get the ID for a particular option state add the zero based index to
   the base. The DM refers to the current values. The WPX refers to the 
   default values found in the PPD */

#define ID_DM_PRINTER_STICKY_OPTIONS_BASE      3800

/* To find out the number of document or printer sticky options that a 
   particular printer has use these two following identifiers. You can
   only use these to get the value. If you try to set these you will
   get an error as a result. */

#define ID_DEFAULT_NUM_DOCUMENT_STICKY_OPTIONS     4000
#define ID_DEFAULT_NUM_PRINTER_STICKY_OPTIONS      4001

/* General other keywords */

#define ID_DM_KNOWN_KEYWORD_BASE               4100

/* These are OEM Useable DWORD area. There are 10 of them starting from
   the base stated here */

#define ID_DM_OEM_DATA_BASE                    4301     
                                                   
/* The following is the base value for JobPatchFile. It is zero-based. */
#define ID_DEFAULT_JOBPATCHFILE_BASE           5000

/*******************************************************************/
/* BITMAP IDs                                                      */
/*******************************************************************/
#ifndef SMALL_UIC_BMP
#define SMALL_UIC_BMP       3650
#endif

#ifndef SMALL_UIC_MASK
#define SMALL_UIC_MASK      3651
#endif

#ifndef LARGE_UIC_BMP
#define LARGE_UIC_BMP       3652
#endif

#ifndef LARGE_UIC_MASK
#define LARGE_UIC_MASK      3653
#endif

#ifndef PAPER_CONTROL_BMP
#define PAPER_CONTROL_BMP  12
#endif
#ifndef PAPER_PDNCNRN_BMP
#define PAPER_PDNCNRN_BMP  12
#endif
#ifndef PAPER_PDNCNRY_BMP
#define PAPER_PDNCNRY_BMP  13
#endif
#ifndef PAPER_PDNCYRN_BMP
#define PAPER_PDNCYRN_BMP  14
#endif
#ifndef PAPER_PDNCYRY_BMP
#define PAPER_PDNCYRY_BMP  15
#endif
#ifndef PAPER_PDLCNRN_BMP
#define PAPER_PDLCNRN_BMP  16
#endif
#ifndef PAPER_PDLCNRY_BMP
#define PAPER_PDLCNRY_BMP  17
#endif
#ifndef PAPER_PDLCYRN_BMP
#define PAPER_PDLCYRN_BMP  18
#endif
#ifndef PAPER_PDLCYRY_BMP
#define PAPER_PDLCYRY_BMP  19
#endif
#ifndef PAPER_PDSCNRN_BMP
#define PAPER_PDSCNRN_BMP  20
#endif
#ifndef PAPER_PDSCNRY_BMP
#define PAPER_PDSCNRY_BMP  21
#endif
#ifndef PAPER_PDSCYRN_BMP
#define PAPER_PDSCYRN_BMP  22
#endif
#ifndef PAPER_PDSCYRY_BMP
#define PAPER_PDSCYRY_BMP  23
#endif

#ifndef PAPER_LDNCNRN_BMP
#define PAPER_LDNCNRN_BMP  24
#endif
#ifndef PAPER_LDNCNRY_BMP
#define PAPER_LDNCNRY_BMP  25
#endif
#ifndef PAPER_LDNCYRN_BMP
#define PAPER_LDNCYRN_BMP  26
#endif
#ifndef PAPER_LDNCYRY_BMP
#define PAPER_LDNCYRY_BMP  27
#endif
#ifndef PAPER_LDLCNRN_BMP
#define PAPER_LDLCNRN_BMP  28
#endif
#ifndef PAPER_LDLCNRY_BMP
#define PAPER_LDLCNRY_BMP  29
#endif
#ifndef PAPER_LDLCYRN_BMP
#define PAPER_LDLCYRN_BMP  30
#endif
#ifndef PAPER_LDLCYRY_BMP
#define PAPER_LDLCYRY_BMP  31
#endif
#ifndef PAPER_LDSCNRN_BMP
#define PAPER_LDSCNRN_BMP  32
#endif
#ifndef PAPER_LDSCNRY_BMP
#define PAPER_LDSCNRY_BMP  33
#endif
#ifndef PAPER_LDSCYRN_BMP
#define PAPER_LDSCYRN_BMP  34
#endif
#ifndef PAPER_LDSCYRY_BMP
#define PAPER_LDSCYRY_BMP  35
#endif

#ifndef PAPER_RDNCNRN_BMP
#define PAPER_RDNCNRN_BMP  36
#endif
#ifndef PAPER_RDNCNRY_BMP
#define PAPER_RDNCNRY_BMP  37
#endif
#ifndef PAPER_RDNCYRN_BMP
#define PAPER_RDNCYRN_BMP  38
#endif
#ifndef PAPER_RDNCYRY_BMP
#define PAPER_RDNCYRY_BMP  39
#endif
#ifndef PAPER_RDLCNRN_BMP
#define PAPER_RDLCNRN_BMP  40
#endif
#ifndef PAPER_RDLCNRY_BMP
#define PAPER_RDLCNRY_BMP  41
#endif
#ifndef PAPER_RDLCYRN_BMP
#define PAPER_RDLCYRN_BMP  42
#endif
#ifndef PAPER_RDLCYRY_BMP
#define PAPER_RDLCYRY_BMP  43
#endif
#ifndef PAPER_RDSCNRN_BMP
#define PAPER_RDSCNRN_BMP  44
#endif
#ifndef PAPER_RDSCNRY_BMP
#define PAPER_RDSCNRY_BMP  45
#endif
#ifndef PAPER_RDSCYRN_BMP
#define PAPER_RDSCYRN_BMP  46
#endif
#ifndef PAPER_RDSCYRY_BMP
#define PAPER_RDSCYRY_BMP  47
#endif

#ifndef PAPER_CONTROL_MASK_BMP
#define PAPER_CONTROL_MASK_BMP        48
#endif
#ifndef PAPER_CONTROL_PDNCN_MASK_BMP
#define PAPER_CONTROL_PDNCN_MASK_BMP  48
#endif
#ifndef PAPER_CONTROL_PDNCY_MASK_BMP
#define PAPER_CONTROL_PDNCY_MASK_BMP  49
#endif
#ifndef PAPER_CONTROL_PDYCN_MASK_BMP
#define PAPER_CONTROL_PDYCN_MASK_BMP  50
#endif
#ifndef PAPER_CONTROL_PDYCY_MASK_BMP
#define PAPER_CONTROL_PDYCY_MASK_BMP  51
#endif
#ifndef PAPER_CONTROL_LDNCN_MASK_BMP
#define PAPER_CONTROL_LDNCN_MASK_BMP  52
#endif
#ifndef PAPER_CONTROL_LDNCY_MASK_BMP
#define PAPER_CONTROL_LDNCY_MASK_BMP  53
#endif
#ifndef PAPER_CONTROL_LDYCN_MASK_BMP
#define PAPER_CONTROL_LDYCN_MASK_BMP  54
#endif
#ifndef PAPER_CONTROL_LDYCY_MASK_BMP
#define PAPER_CONTROL_LDYCY_MASK_BMP  55
#endif

#define PAPER_PDNCNRNM_BMP      PAPER_CONTROL_PDNCN_MASK_BMP
#define PAPER_PDNCNRYM_BMP      PAPER_CONTROL_PDNCN_MASK_BMP
#define PAPER_PDNCYRNM_BMP      PAPER_CONTROL_PDNCY_MASK_BMP
#define PAPER_PDNCYRYM_BMP      PAPER_CONTROL_PDNCY_MASK_BMP 
#define PAPER_PDLCNRNM_BMP      PAPER_CONTROL_PDYCN_MASK_BMP
#define PAPER_PDLCNRYM_BMP      PAPER_CONTROL_PDYCN_MASK_BMP
#define PAPER_PDLCYRNM_BMP      PAPER_CONTROL_PDYCY_MASK_BMP
#define PAPER_PDLCYRYM_BMP      PAPER_CONTROL_PDYCY_MASK_BMP
#define PAPER_PDSCNRNM_BMP      PAPER_CONTROL_PDYCN_MASK_BMP
#define PAPER_PDSCNRYM_BMP      PAPER_CONTROL_PDYCN_MASK_BMP
#define PAPER_PDSCYRNM_BMP      PAPER_CONTROL_PDYCY_MASK_BMP
#define PAPER_PDSCYRYM_BMP      PAPER_CONTROL_PDYCY_MASK_BMP

#define PAPER_LDNCNRNM_BMP      PAPER_CONTROL_LDNCN_MASK_BMP
#define PAPER_LDNCNRYM_BMP      PAPER_CONTROL_LDNCN_MASK_BMP
#define PAPER_LDNCYRNM_BMP      PAPER_CONTROL_LDNCY_MASK_BMP
#define PAPER_LDNCYRYM_BMP      PAPER_CONTROL_LDNCY_MASK_BMP
#define PAPER_LDLCNRNM_BMP      PAPER_CONTROL_LDYCN_MASK_BMP
#define PAPER_LDLCNRYM_BMP      PAPER_CONTROL_LDYCN_MASK_BMP
#define PAPER_LDLCYRNM_BMP      PAPER_CONTROL_LDYCY_MASK_BMP
#define PAPER_LDLCYRYM_BMP      PAPER_CONTROL_LDYCY_MASK_BMP
#define PAPER_LDSCNRNM_BMP      PAPER_CONTROL_LDYCN_MASK_BMP
#define PAPER_LDSCNRYM_BMP      PAPER_CONTROL_LDYCN_MASK_BMP
#define PAPER_LDSCYRNM_BMP      PAPER_CONTROL_LDYCY_MASK_BMP
#define PAPER_LDSCYRYM_BMP      PAPER_CONTROL_LDYCY_MASK_BMP

#define PAPER_RDNCNRNM_BMP      PAPER_CONTROL_LDNCN_MASK_BMP
#define PAPER_RDNCNRYM_BMP      PAPER_CONTROL_LDNCN_MASK_BMP
#define PAPER_RDNCYRNM_BMP      PAPER_CONTROL_LDNCY_MASK_BMP
#define PAPER_RDNCYRYM_BMP      PAPER_CONTROL_LDNCY_MASK_BMP
#define PAPER_RDLCNRNM_BMP      PAPER_CONTROL_LDYCN_MASK_BMP
#define PAPER_RDLCNRYM_BMP      PAPER_CONTROL_LDYCN_MASK_BMP
#define PAPER_RDLCYRNM_BMP      PAPER_CONTROL_LDYCY_MASK_BMP
#define PAPER_RDLCYRYM_BMP      PAPER_CONTROL_LDYCY_MASK_BMP
#define PAPER_RDSCNRNM_BMP      PAPER_CONTROL_LDYCN_MASK_BMP
#define PAPER_RDSCNRYM_BMP      PAPER_CONTROL_LDYCN_MASK_BMP
#define PAPER_RDSCYRNM_BMP      PAPER_CONTROL_LDYCY_MASK_BMP
#define PAPER_RDSCYRYM_BMP      PAPER_CONTROL_LDYCY_MASK_BMP

#ifndef PAPER_HANDLING_BMP
#define PAPER_HANDLING_BMP   56
#endif
#ifndef GRAPHICS_L01OPPN_BMP
#define GRAPHICS_L01OPPN_BMP 56
#endif
#ifndef GRAPHICS_L02OPPN_BMP
#define GRAPHICS_L02OPPN_BMP 57
#endif
#ifndef GRAPHICS_L04OPPN_BMP
#define GRAPHICS_L04OPPN_BMP 58
#endif
#ifndef GRAPHICS_L06OPPN_BMP
#define GRAPHICS_L06OPPN_BMP 59
#endif
#ifndef GRAPHICS_L09OPPN_BMP
#define GRAPHICS_L09OPPN_BMP 60
#endif
#ifndef GRAPHICS_L16OPPN_BMP
#define GRAPHICS_L16OPPN_BMP 61
#endif

#ifndef GRAPHICS_L01OLPN_BMP
#define GRAPHICS_L01OLPN_BMP 62
#endif
#ifndef GRAPHICS_L02OLPN_BMP
#define GRAPHICS_L02OLPN_BMP 63
#endif
#ifndef GRAPHICS_L04OLPN_BMP
#define GRAPHICS_L04OLPN_BMP 64
#endif
#ifndef GRAPHICS_L06OLPN_BMP
#define GRAPHICS_L06OLPN_BMP 65
#endif
#ifndef GRAPHICS_L09OLPN_BMP
#define GRAPHICS_L09OLPN_BMP 66
#endif
#ifndef GRAPHICS_L16OLPN_BMP
#define GRAPHICS_L16OLPN_BMP 67
#endif

#ifndef PAPER_HANDLING_BORDER_BMP
#define PAPER_HANDLING_BORDER_BMP 68 
#endif
#ifndef GRAPHICS_L02OPPY_BMP
#define GRAPHICS_L02OPPY_BMP 68
#endif
#ifndef GRAPHICS_L04OPPY_BMP
#define GRAPHICS_L04OPPY_BMP 69
#endif
#ifndef GRAPHICS_L06OPPY_BMP
#define GRAPHICS_L06OPPY_BMP 70
#endif
#ifndef GRAPHICS_L09OPPY_BMP
#define GRAPHICS_L09OPPY_BMP 71
#endif
#ifndef GRAPHICS_L16OPPY_BMP
#define GRAPHICS_L16OPPY_BMP 72
#endif

#ifndef GRAPHICS_L02OLPY_BMP
#define GRAPHICS_L02OLPY_BMP 73
#endif
#ifndef GRAPHICS_L04OLPY_BMP
#define GRAPHICS_L04OLPY_BMP 74
#endif
#ifndef GRAPHICS_L06OLPY_BMP
#define GRAPHICS_L06OLPY_BMP 75
#endif
#ifndef GRAPHICS_L09OLPY_BMP
#define GRAPHICS_L09OLPY_BMP 76
#endif
#ifndef GRAPHICS_L16OLPY_BMP
#define GRAPHICS_L16OLPY_BMP 77
#endif

#ifndef PAPER_HANDLING_PORTRAIT_MASK_BMP
#define PAPER_HANDLING_PORTRAIT_MASK_BMP  78
#endif
#ifndef PAPER_HANDLING_LANDSCAPE_MASK_BMP
#define PAPER_HANDLING_LANDSCAPE_MASK_BMP 79 
#endif

#define GRAPHICS_L01OPPNM_BMP PAPER_HANDLING_PORTRAIT_MASK_BMP
#define GRAPHICS_L02OPPNM_BMP PAPER_HANDLING_PORTRAIT_MASK_BMP
#define GRAPHICS_L04OPPNM_BMP PAPER_HANDLING_PORTRAIT_MASK_BMP
#define GRAPHICS_L06OPPNM_BMP PAPER_HANDLING_PORTRAIT_MASK_BMP
#define GRAPHICS_L09OPPNM_BMP PAPER_HANDLING_PORTRAIT_MASK_BMP
#define GRAPHICS_L16OPPNM_BMP PAPER_HANDLING_PORTRAIT_MASK_BMP

#define GRAPHICS_L01OLPNM_BMP PAPER_HANDLING_LANDSCAPE_MASK_BMP
#define GRAPHICS_L02OLPNM_BMP PAPER_HANDLING_LANDSCAPE_MASK_BMP
#define GRAPHICS_L04OLPNM_BMP PAPER_HANDLING_LANDSCAPE_MASK_BMP
#define GRAPHICS_L06OLPNM_BMP PAPER_HANDLING_LANDSCAPE_MASK_BMP
#define GRAPHICS_L09OLPNM_BMP PAPER_HANDLING_LANDSCAPE_MASK_BMP
#define GRAPHICS_L16OLPNM_BMP PAPER_HANDLING_LANDSCAPE_MASK_BMP

#define GRAPHICS_L02OPPYM_BMP PAPER_HANDLING_PORTRAIT_MASK_BMP
#define GRAPHICS_L04OPPYM_BMP PAPER_HANDLING_PORTRAIT_MASK_BMP
#define GRAPHICS_L06OPPYM_BMP PAPER_HANDLING_PORTRAIT_MASK_BMP
#define GRAPHICS_L09OPPYM_BMP PAPER_HANDLING_PORTRAIT_MASK_BMP
#define GRAPHICS_L16OPPYM_BMP PAPER_HANDLING_PORTRAIT_MASK_BMP

#define GRAPHICS_L02OLPYM_BMP PAPER_HANDLING_LANDSCAPE_MASK_BMP
#define GRAPHICS_L04OLPYM_BMP PAPER_HANDLING_LANDSCAPE_MASK_BMP
#define GRAPHICS_L06OLPYM_BMP PAPER_HANDLING_LANDSCAPE_MASK_BMP
#define GRAPHICS_L09OLPYM_BMP PAPER_HANDLING_LANDSCAPE_MASK_BMP
#define GRAPHICS_L16OLPYM_BMP PAPER_HANDLING_LANDSCAPE_MASK_BMP

/*******************************************************************/
/* ICON IDs                                                        */
/*******************************************************************/

#define LOGO_BMP      10
#define LOGO_MASK_BMP 11

/* Paper sizes */
#define PAPER_BASE_ICON          20
#define PAPER_LETTER_ICON        21
#define PAPER_LETTERSMALL_ICON   22
#define PAPER_TABLOID_ICON       23
#define PAPER_LEDGER_ICON        24
#define PAPER_LEGAL_ICON         25
#define PAPER_STATEMENT_ICON     26
#define PAPER_EXECUTIVE_ICON     27
#define PAPER_A3_ICON            28
#define PAPER_A4_ICON            29
#define PAPER_A4SMALL_ICON       30
#define PAPER_A5_ICON            31
#define PAPER_B4_ICON            32
#define PAPER_B5_ICON            33
#define PAPER_FOLIO_ICON         34
#define PAPER_QUARTO_ICON        35
#define PAPER_10X14_ICON         36
#define PAPER_11X17_ICON         37
#define PAPER_NOTE_ICON          38
#define PAPER_ENV9_ICON          39
#define PAPER_ENV10_ICON         40
#define PAPER_ENV11_ICON         41
#define PAPER_ENV12_ICON         42
#define PAPER_ENV14_ICON         43
#define PAPER_C_ICON             44
#define PAPER_D_ICON             45
#define PAPER_E_ICON             46
#define PAPER_ENVDL_ICON         47
#define PAPER_ENVC5_ICON         48
#define PAPER_ENVC3_ICON         49
#define PAPER_ENVC4_ICON         50
#define PAPER_ENVC6_ICON         51
#define PAPER_ENVC65_ICON        52
#define PAPER_ENVB4_ICON         53
#define PAPER_ENVB5_ICON         54
#define PAPER_ENVB6_ICON         55
#define PAPER_ITALY_ICON         56
#define PAPER_MONARCH_ICON       57
#define PAPER_PERSONAL_ICON      58
#define PAPER_FAN_US_ICON        59
#define PAPER_FAN_GM_STD_ICON    60
#define PAPER_FAN_GM_LGL_ICON    61

#define PAPER_JIS_B4_ICON        62
#define PAPER_JPN_POSTCARD_ICON  63
#define PAPER_9X11_ICON          64
#define PAPER_10X11_ICON         65
#define PAPER_15X11_ICON         66

#define PAPER_LETEXTRA_ICON      70
#define PAPER_LEGEXTRA_ICON      71
#define PAPER_TABEXTRA_ICON      72
#define PAPER_A4EXTRA_ICON       73
#define PAPER_LETTERTRANS_ICON   74
#define PAPER_A4TRANS_ICON       75
#define PAPER_LETTEREXTRANS_ICON 76
#define PAPER_SUPERA_ICON        77
#define PAPER_SUPERB_ICON        78
#define PAPER_LETTERPLUS_ICON    79
#define PAPER_A4PLUS_ICON        80
#define PAPER_A5TRANS_ICON       81
#define PAPER_B5TRANS_ICON       82
#define PAPER_A3EXTRA_ICON       83
#define PAPER_A5EXTRA_ICON       84
#define PAPER_B5EXTRA_ICON       85
#define PAPER_A2_ICON            86
#define PAPER_A3TRANS_ICON       87
#define PAPER_A3EXTRANS_ICON     88

#define PAPER_LAST_ICON          PAPER_A3EXTRANS_ICON

#define PAPER_USER_ICON          276
#define PAPER_OTHER_ICON         277
#define PAPER_DEFAULT_ICON       277

#ifndef _icons_h_
// Layout icons
#define ONEUP_ICON              500
#define TWOUP_ICON              501
#define FOURUP_ICON             502
#endif

#define SIXUP_ICON              503
#define NINEUP_ICON             504
#define SIXTEENUP_ICON          505

#ifndef _icons_h_
// Orientation
#define PORTRAIT_ICON           525
#define LANDSCAPE_ICON          526
#define ROTATED_LAND_ICON       527

// Duplex
#define DUPLEX_P_NONE_ICON      550
#define DUPLEX_L_NONE_ICON      551
#define DUPLEX_R_NONE_ICON      552
#define DUPLEX_P_LONG_ICON      553
#define DUPLEX_L_LONG_ICON      554
#define DUPLEX_R_LONG_ICON      555
#define DUPLEX_P_SHORT_ICON     556
#define DUPLEX_L_SHORT_ICON     557
#define DUPLEX_R_SHORT_ICON     558

// Graphics
#define NM_BASE_ICON            575
#define NEGATIVE_ICON           576
#define MIRROR_ICON             577
#define NEGATIVE_MIRROR_ICON    578

#endif

/*******************************************************************/
/* OEM DLL exports these routines                                  */
/*******************************************************************/


BOOL _loadds FAR PASCAL OEMInitDll(LPSTR lpszFriendlyName,
                             LPSTR lpszPort,
                             LPDWORD lpdwDrvVersion,
                             LPDWORD lpdwOEMVersion);
typedef BOOL (_loadds FAR PASCAL *LPOEMINITDLL)(LPSTR lpszFriendlyName,
                             LPSTR lpszPort,
                             LPDWORD lpdwDrvVersion,
                             LPDWORD lpdwOEMVersion);

HANDLE _loadds FAR PASCAL OEMBeginSession(HANDLE hContext, 
                             HINSTANCE hDriverMod,
                             LPSTR lpszFriendlyName,
                             LPSTR lpszPort,
                             DWORD dwTimeStamp,
                             DWORD dwRandom,
                             ENTRY_TYPE flEntry);
typedef HANDLE (_loadds FAR PASCAL *LPOEMBEGINSESSION)(HANDLE hContext,
                             HINSTANCE hDriverMod,
                             LPSTR lpszFriendlyName,
                             LPSTR lpszPort,
                             DWORD dwTimeStamp,
                             DWORD dwRandom,
                             ENTRY_TYPE flEntry);


WORD _loadds FAR PASCAL OEMGetDocStickySize();
typedef WORD (_loadds FAR PASCAL *LPOEMGETDOCSTICKYSIZE)();

WORD _loadds FAR PASCAL OEMDevInstall(HANDLE hOEM,
                             HWND hWnd,
                             LPSTR lpszModelName,
                             LPSTR lpszOldPort,
                             LPSTR lpszNewPort);
typedef WORD (_loadds FAR PASCAL *LPOEMDEVINSTALL)(HANDLE hOEM,
                             HWND hWnd,
                             LPSTR lpszModelName,
                             LPSTR lpszOldPort,
                             LPSTR lpszNewPort);

BOOL _loadds FAR PASCAL OEMGetPropertyPages(HANDLE hOEM,
                             LPPROPSHEETPAGE lpPropSheetArray,
                             int FAR *lpNumOEMPropPages,
                             DWORD FAR *lpdwDriverPropPagesToDisplay);
                             
typedef BOOL (_loadds FAR PASCAL *LPOEMGETPROPERTYPAGES)(HANDLE hOEM,
                             LPPROPSHEETPAGE lpPropSheetArray,
                             int FAR *lpNumOEMPropPages,
                             DWORD FAR *lpdwDriverPropPagesToDisplay);
                             
BOOL _loadds FAR PASCAL OEMDeviceCapabilities(HANDLE hOEM, 
                             LPSTR lpszDevice, 
                             LPSTR lpszPort, 
                             WORD  fwCapability, 
                             LPSTR lpszOutput,
                             DWORD *lpdwRetVal);

typedef BOOL (_loadds FAR PASCAL *LPOEMDEVICECAPABILITIES)(HANDLE hOEM, 
                             LPSTR lpszDevice, 
                             LPSTR lpszPort, 
                             WORD  fwCapability, 
                             LPSTR lpszOutput,
                             DWORD *lpdwRetVal);

SHORT _loadds FAR PASCAL OEMStartDoc(HANDLE        hOEM,
                                     LPSTR         lpJobName, 
                                     PRINTJOB_TYPE wPrintJobType);
typedef SHORT (_loadds FAR PASCAL *LPOEMSTARTDOC)(HANDLE        hOEM,
                                                  LPSTR         lpJobName, 
                                                  PRINTJOB_TYPE wPrintJobType);

WORD _loadds FAR PASCAL OEMEndDoc(HANDLE hOEM);
typedef BOOL (_loadds FAR PASCAL *LPOEMENDDOC)(HANDLE hOEM);

void _loadds FAR PASCAL OEMAbortDoc(HANDLE hOEM);
typedef void (_loadds FAR PASCAL *LPOEMABORTDOC)(HANDLE hOEM);

BOOL _loadds FAR PASCAL OEMInsertPSBefore(HANDLE hOEM, DWORD dwPSIndex,
                             LPSTR FAR *lplpOEMPS, unsigned int FAR *lpOEMPSLen);
typedef BOOL (_loadds FAR PASCAL *LPOEMINSERTPSBEFORE)(HANDLE hOEM, DWORD dwPSIndex,
                             LPSTR FAR *lplpOEMPS, unsigned int FAR *lpOEMPSLen);

void _loadds FAR PASCAL OEMChangeDriverPS(HANDLE hOEM, DWORD dwPSIndex,
                             LPSTR FAR *lplpDriverPS, unsigned int FAR *lpDriverPSLen);
typedef void (_loadds FAR PASCAL *LPOEMCHANGEDRIVERPS)(HANDLE hOEM, DWORD dwPSIndex,
                             LPSTR FAR *lplpOEMPS, unsigned int FAR *lpOEMPSLen);

BOOL _loadds FAR PASCAL OEMInsertPSAfter(HANDLE hOEM, DWORD dwPSIndex,
                             LPSTR FAR *lplpOEMPS, unsigned int FAR *lpOEMPSLen);
typedef BOOL (_loadds FAR PASCAL *LPOEMINSERTPSAFTER)(HANDLE hOEM, DWORD dwPSIndex,
                             LPSTR FAR *lplpOEMPS, unsigned int FAR *lpOEMPSLen);

void _loadds FAR PASCAL OEMEndSession(HANDLE hOEM);
typedef void (_loadds FAR PASCAL *LPOEMENDSESSION)(HANDLE hOEM);

void _loadds FAR PASCAL OEMTermDll();
typedef void (_loadds FAR PASCAL *LPOEMTERMDLL)();

HANDLE _loadds FAR PASCAL OEMOpenJob(LPSTR  lpOutput,
                                    LPSTR   lpTitle,
                                    HDC     hdc,
                                    WORD    wNumFilters,
                                    LPOEMFILTERINFO lpFilterInfo
                                    );                           

typedef HANDLE (_loadds FAR PASCAL *LPOEMOPENJOB)(LPSTR lpOutput,
                                                LPSTR   lpTitle,
                                                HDC     hdc,
                                                WORD    wNumFilters,
                                                LPOEMFILTERINFO lpFilterInfo
                                                );                           

int _loadds FAR PASCAL OEMStartSpoolPage(HANDLE hJob);  

typedef int (_loadds FAR PASCAL *LPOEMSTARTSPOOLPAGE)(HANDLE hJob);

int _loadds FAR PASCAL OEMWriteSpool(HANDLE hJob, 
                                     LPSTR  lpData,
                                     WORD   cch
                                    );
typedef int (_loadds FAR PASCAL *LPOEMWRITESPOOL)(HANDLE hJob,
                                                  LPSTR  lpData,
                                                  WORD   cch
                                                 );
int _loadds FAR PASCAL OEMEndSpoolPage(HANDLE hJob);
typedef int (_loadds FAR PASCAL *LPOEMENDSPOOLPAGE)(HANDLE hJob);

int _loadds FAR PASCAL OEMDeleteJob(HANDLE hJob,
                                    WORD    wDummy
                                   );
typedef int (_loadds FAR PASCAL *LPOEMDELETEJOB)(HANDLE hJob,
                                                 WORD   wDummy
                                                 );

int _loadds FAR PASCAL OEMCloseJob(HANDLE hJob);
typedef int (_loadds FAR PASCAL *LPOEMCLOSEJOB)(HANDLE hJob); 

void _loadds FAR PASCAL OEMValidateDevmode(HANDLE hOEM);
typedef void (_loadds FAR PASCAL *LPOEMVALIDATEDEVMODE)(HANDLE hOEM);

/*******************************************************************/
/* AdobePS exports these routines                                  */
/*******************************************************************/

int _loadds FAR PASCAL DRVGetKeywordID(HANDLE hContext, LPSTR lpKeyword);
typedef int (_loadds FAR PASCAL *LPDRVGETKEYWORDID)(HANDLE hContext, LPSTR lpKeyword);

BOOL _loadds FAR PASCAL DRVGetKeywordString(HANDLE hContext, int iDataItemID,
                                     LPSTR lpBuffer, unsigned int FAR *lpSize);
typedef BOOL (_loadds FAR PASCAL *LPDRVGETKEYWORDSTRING)(HANDLE hContext, int iDataItemID,
                                     LPSTR lpBuffer, unsigned int FAR *lpSize);

BOOL _loadds FAR PASCAL DRVSetDWord(HANDLE hContext, int iDataItemID, DWORD dwData);
typedef BOOL (_loadds FAR PASCAL *LPDRVSETDWORD)(HANDLE hContext, int iDataItemID, DWORD dwData);

DWORD _loadds FAR PASCAL DRVGetDWord(HANDLE hContext, int iDataItemID, BOOL bResult);
typedef DWORD (_loadds FAR PASCAL *LPDRVGETDWORD)(HANDLE hContext, int iDataItemID, BOOL bResult);

BOOL _loadds FAR PASCAL DRVSetString(HANDLE hContext, int iDataItemID, LPSTR lpszData, unsigned int uiLength);
typedef BOOL (_loadds FAR PASCAL *LPDRVSETSTRING)(HANDLE hContext, int iDataItemID, LPSTR lpszData, unsigned int uiLength);

BOOL _loadds FAR PASCAL DRVGetString(HANDLE hContext, int iDataItemID,
                                     LPSTR lpBuffer, unsigned int FAR *lpSize, BOOL bResult);
typedef BOOL (_loadds FAR PASCAL *LPDRVGETSTRING)(HANDLE hContext, int iDataItemID,
                                     LPSTR lpBuffer, unsigned int FAR *lpSize, BOOL bResult);

int _loadds FAR PASCAL  DRVGetKeywordNumOptions(HANDLE hContext, int iDataItemID);
typedef int (_loadds FAR PASCAL *LPDRVGETKEYWORDNUMOPTIONS)(HANDLE hContext, int iDataItemID);

BOOL _loadds FAR PASCAL DRVGetKeywordTranslation(HANDLE hContext,
                                                 int iDataItemID,
                                                 LPSTR lpBuffer,
                                                 unsigned int FAR *lpSize);
typedef BOOL (_loadds FAR PASCAL *LPDRVGETKEYWORDTRANSLATION)(HANDLE hContext,
                                                 int iDataItemID,
                                                 LPSTR lpBuffer,
                                                 unsigned int FAR *lpSize);

BOOL _loadds FAR PASCAL DRVGetKeywordOptionString(HANDLE hContext,
                                          int iDataItemID,
                                          int iIDOption,
                                          LPSTR lpOptionBuffer,
                                          unsigned int FAR *lpSize);
typedef BOOL (_loadds FAR PASCAL *LPDRVGETKEYWORDOPTIONSTRING)(HANDLE hContext,
                                          int iDataItemID,
                                          int iIDOption,
                                          LPSTR lpOptionBuffer,
                                          unsigned int FAR *lpSize);

BOOL _loadds FAR PASCAL DRVGetKeywordOptionTranslation(HANDLE hContext,
                                               int iDataItemID,
                                               int iIDOption,
                                               LPSTR lpOptionBuffer,
                                               unsigned int FAR *lpSize);
typedef BOOL (_loadds FAR PASCAL *LPDRVGETKEYWORDOPTIONTRANSLATION)(HANDLE hContext,
                                               int iDataItemID,
                                               int iIDOption,
                                               LPSTR lpOptionBuffer,
                                               unsigned int FAR *lpSize);

BOOL _loadds FAR PASCAL DRVGetKeywordOptionPS(HANDLE hContext,
                                      int iDataItemID,
                                      int iIDOption,
                                      LPSTR lpPSStringBuffer,
                                      unsigned int FAR *lpSize);
typedef BOOL (_loadds FAR PASCAL *LPDRVGETKEYWORDOPTIONPS)(HANDLE hContext,
                                      int iDataItemID,
                                      int iIDOption,
                                      LPSTR lpPSStringBuffer,
                                      unsigned int FAR *lpSize);

DWORD _loadds FAR PASCAL DRVGetKeywordOptionDWord(HANDLE hContext,
                                                 int iDataItemID,
                                                 int iIDOption,
                                                                 BOOL bResult);
typedef DWORD (_loadds FAR PASCAL *LPDRVGETKEYWORDOPTIONDWORD)(
                                                 HANDLE hContext,
                                                 int iDataItemID,
                                                 int iIDOption,
                                                                 BOOL bResult);
BOOL _loadds FAR PASCAL  DRVIsKeywordOptionConstrained(HANDLE hContext, 
                                                       int iDataItemID,
                                                       int iIDOption);
typedef BOOL (_loadds FAR PASCAL *LPDRVISKEYWORDOPTIONCONSTRAINED)(
                                                       HANDLE hContext,
                                                       int iDataItemID,
                                                       int iIDOption);


BOOL _loadds FAR PASCAL  DRVDoCommand(HANDLE hContext,
                                      int iIDCommand,
                                      FARPROC lpfn,
                                      DWORD dwData);
typedef BOOL (_loadds FAR PASCAL  *LPDRVDOCOMMAND)(
                                      HANDLE hContext,
                                      int iIDCommand,
                                      FARPROC lpfn,
                                      DWORD dwData);


BOOL _loadds FAR PASCAL DRVSetFilter(HANDLE hContext,
                                 LPSTR  lpModuleName,
                                 LPSTR  lpUser,
                                 WORD   wDataSize,
                                 LPBYTE  lpData
                                );
typedef BOOL (_loadds FAR PASCAL *LPDRVSETFILTER)(HANDLE hContext,
                                 LPSTR  lpModuleName,
                                 LPSTR  lpUser,
                                 WORD   wDataSize,
                                 LPBYTE  lpData
                                );

HANDLE _loadds FAR PASCAL DRVLoadIcon(HANDLE hContext,
                                         int    iId
                                        );
                                        
typedef HANDLE (_loadds FAR PASCAL *LPDRVLOADICON)(HANDLE hContext,
                                                      int   iId
                                                     );
                                                     
HANDLE _loadds FAR PASCAL DRVLoadBitmap(HANDLE hContext,
                                         int    iId
                                        );
                                        
typedef HANDLE (_loadds FAR PASCAL *LPDRVLOADBITMAP)(HANDLE hContext,
                                                      int   iId
                                                     );
                                                                                                          
// UIConstraint                                                     
// Argument: 
// If lpArray, lpwElements are both NULL pointer:
//   1. DevMode will be updated with a valid optionArray.  
//   2. If lpConflict exists, it is initialized if there is no conflict.
//
// If lpArray and lpcElements are both valid pointer:
//   If *lpcElements < required size, it will be filled with the 
//      required number of elements for lpArray. 
//   Otherwise:
//   1. lpArray is updated with valid optionArray.
//   2. If lpConflict exists, it is initialized if there is a conflict.

WORD _loadds FAR PASCAL DRVValidateOptionArray(HANDLE hContext,
                                    LPUICARRAY        lpArray,
                                    unsigned int FAR* lpwElements,
                                    LPUICONFLICT      lpConflict
                                        );
                                        
typedef WORD (_loadds FAR PASCAL *LPDRVVALIDATEOPTIONARRAY)(HANDLE hContext,
                                    LPUICARRAY        lpArray,
                                    unsigned int FAR* lpwElements,
                                    LPUICONFLICT      lpConflict
                                        );


