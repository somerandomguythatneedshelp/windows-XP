/*  functions in fileman1.c: */

#define  ADDINDEXENTRY  1
#define  VERIFYTREE     2
#define  APPENDPATH     3
#define  EXTRACTFILENAMEFROMINDEX  4
#define  READFILEINTOHBUF          5
#define  INDEXWPXS                 6
#define  ENUMFILESINDIRECTORY      7
#define  PWSTRNCMP                 9
#define  PWSTRCPY                  10
#define  EXTRACTWPXMODELNAME       11
#define  APPENDENTRYTOINDEX        12
#define  CREATEWPXFILE             13
#define  CREATEWPXFILEFROMPPDS     14
#define  INDEXPPDS                 15
#define  EXTRACTPPDMODELNAME       16
#define  FILENAMEONLY              17
#define  ERRORMSG                  18
#define  OBTAINWPXFILE             19
#define  EXTRACTPFMFACENAME        20
#define  INDEXPFMS                 21
#define  GETPFMFILENAME            22
#define  CREATENEWWPXFILE          23
#define  LIBMAIN                   24
#define  INDEXSUBDIR               25


/*  functions in getwpx.c: */

#define  fn_WEP                    100

/*  functions in parse1.c: */

#define  INITWPXINFO               200
#define  INITPAPERINFO             201
#define  INITINPUTSLOTINFO         202
#define  INITDUPLEXINGINFO         203
#define  INITRESOLUTIONINFO        204
#define  INITOUTPUTBININFO         205
#define  INITMEDIATYPEINFO         206
#define  INITPRINTERCAPS           207
#define  INITPRINTERINFO           208
#define  INITCUSTPAGEINFO          209
#define  EXTRACTPARAMS             210
#define  CONVSTRTOINT              211
#define  EXTRACTRESOLUTION         212
#define  STRTBLCMP                 213
#define  INITINSTALLEDMEMORYINFO   214
#define  INITCOLLATIONINFO         215
#define  INITOUTPUTORDERINFO       216

/*  functions in parse2.c: */

#define  CREATEWPXFILEFROMPPDNOW   300
#define  INSERTFILECONTENTS        301
#define  SHIFTNBYTES               302
#define  SCANFORINCLUDE            303
#define  INDEXKEYWORDS             304
#define  DETERMINEKEYWORDVALUE     305
#define  SEARCHKEYWORDVALUE        306
#define  STRINGREFTOLP             307
#define  LOADSYMBOLTABLE           308
#define  EXTRACTOPTION             309
#define  EXTRACTQUOTEDLITERAL      310
#define  HSTRCMP                   311
#define  HSTRCPYN                  312
#define  FILLKEYENTRIES            313
#define  EXTRACTVALUE              314
#define  EXTRACTSTRINGVALUE        315
#define  EXTRACTSTRINGTOKEN        316
#define  ADDQUOTEDSTRINGTOTABLE    317
#define  ADDSTRINGTOTABLE          318
#define  READHEXDIGIT              319
#define  MAKEFONTSUM               320
#define  COUNTNEWUIKEYWORDS        321
#define  INITMAINKEYWORDSTABLE     322
#define  SETKEYENTRYFLAGS          323
#define  SETKEYENTRYJCLFLAG        324

/*  functions in parse3.c: */

#define  INITOPENUISTRUCTS         400
#define  INITORDERDEPENDENCY       401
#define  REMOVEZEROOPTIONS         402
#define  INITUICONSTRAINTS         403
#define  INITJCLINFO               404
#define  INITFONTLIST              405
#define  FINDQUERYANDDEFAULTKEYWORD     406
#define  ADDCONSTRAINT             407

/*  functions in parse4.c: */

#define  SETSLOTID                 500
#define  SETPAPERID                501
#define  SCALEPAPERIDTABLE         502


/*  functions in pfmparse.c: */

#define  CONVERTPFMTOMFD           600
#define  CONVERTMFMTOMFD           601
#define  INSTALLPRINTERFONTS       602

/*  functions in utils.c: */

#define  QSORT                     700


/*  List of error messages  */

#define   ERR_FILE_READACCESS    0
//   Unable to find/open requested file.

#define   ERR_FILE_WRITEACCESS   1
//   Unable to Create/open requested file.

#define   ERR_FILE_READ_FAILED   2
//      _hread or _lread failed

#define   ERR_FILE_WRITE_FAILED  3
//      _hwrite or _lwrite failed

#define   ERR_GLOBALALLOC_FAILED    4
//   GlobalAlloc  failed.

#define   ERR_GLOBALREALLOC_FAILED  5
// GlobalReAlloc  failed.

#define   ERR_GMEM_OFFSET_NONZERO   6
// Invalid Assumption. Global Memory does not begin at offset zero.





#define   ERR_CANT_FIND_WPX_FILES    50
//      Unable to locate any WPX files

#define   ERR_CANT_FIND_PPD_FILES    51
//      Unable to locate any PPD files

#define   ERR_CANT_FIND_PPD_FILE     52
//      Unable to locate this PPD file

#define   ERR_CANT_FIND_PFM_FILES    53
//      Unable to locate any PFM files

#define   ERR_CANT_FIND_ASSOC_PFM_FILE   54
//  Can not find PFM file associated with this font.



#define   ERR_READING_WPX_HEADER         100
//      Unable to read Header from WPX file.

#define   ERR_READING_WPX_PRINTINFO      101
//      Unable to read PrinterInfo from WPX file.

#define   ERR_READING_FRM_PPDFILE        102
// Unable to read specified PPD file.

#define   ERR_READING_MODELNAME          103
//      Unable to read ModelName from WPX file

#define   ERR_INDEXING_PPD               104
//      Error attempting to index PPD file

#define   ERR_APPENDING_ENTRY            105
//      unable to append new index entry

#define   ERR_CREATING_PFM_INDEX         106
//      Failed to write out PFM Index

#define   ERR_CREATING_WPX_INDEX         107
//      Failed to write out WPX Index

#define   ERR_CREATING_PPD_INDEX         108
//      Failed to write out PPD Index



#define   ERR_TOOMANY_TO_INDEX           150
//      Too many files to be indexed

#define   ERR_TOOMANY_KEYWORDS           151
// Too many keywords to process.  Exceeds NUMKEYENTRY

#define   ERR_TOO_MANY_FONTS             152
//  Too Many Fonts.  Dangerously close to overflowing FontDir

#define   ERR_MODELNAME_TOO_LONG         153
//      ModelName in WPX file too long for index!

#define   ERR_BUFFER_OVERFLOW            154
//  Caller supplied buffer too small to contain FileName 

#define   ERR_PPD_SELF_REFERENCING       155
// PPD file is including itself or is too large.

#define   ERR_STRINGTABLE_OVERFLOW       156
//  No more room in StringTable !



#define   ERR_CREATING_WPX_FILE          200
//      WPX file was not created.

#define   ERR_INCOMPATIBLE_WPX_VER       201
//      WPX file is an unknown or Incompatible version
//      Try deleting all WPX files on your computer



#define   ERR_KEYWORD_HAS_NO_VALUE       250
//    No value associated with keyword

#define   ERR_KEYWORD_HAS_NO_INVC_VALUE  251
//    No invocation value associated with keyword

#define   ERR_NO_PAPERSIZES              252
//  This PPD file contains no PaperSizes - This is Totally Bogus!

#define   ERR_KEYWORD_NOT_FOUND          253
//  specified keyword was not found

#define   ERR_TOKENS_MISSING             254
//  one or more tokens in string value are missing

#define   ERR_UNDEFINED_SYMBOL           255
//  This SymbolName is Undefined

#define   ERR_UNKNOWNSECTION             256
//  OrderDependency specifies an Unknown section for this command.



#define   ERR_EXPCTD_TWO_TOKENS          300
//  expected two tokens in string value

#define   ERR_EXPCTD_FOUR_TOKENS         301
//  expected four tokens in string value

#define   ERR_EXPCTD_QUOTED_NOT_STRING   302
//  expected quoted value, not string value

#define   ERR_EXPCTD_STRING_NOT_QUOTED   303
//  expected string value, not quoted value

#define   ERR_EXPCTD_INVOCATN_NOT_STRING 304
//  expected invocation value, not string value

#define   ERR_EXPECTED_SYMBOLNAME        305
//  expected token of form ^symbolname.

#define   ERR_EXPCTD_QUOTED_VAL          306
//  expected Quoted value which begins with double quote or ^

#define   ERR_EXPCTD_OPTION_KEYWORD      307
//  Expected option after this keyword

#define   ERR_BOOLEAN_NEEDS_TWO_OPTIONS  308
//  A UItype = Boolean requires two options:  TRUE and FALSE.



#define   ERR_CONV_STRING_TO_DECIMAL     350
//  or error encountered in converting string token to decimal value

#define   ERR_PARSING_OPTION             351
// Error parsing (resolution) option

#define   ERR_OPTION_PARSING             352
//  Syntax error parsing option field for this keyword.

#define   ERR_OPTION_NOT_ENDS_IN_WHITESPACE   353
//  Keyword option must be terminated by colon, not whitespace

#define   ERR_OPTION_NOT_ENDS_IN_NEWLINE      354
//  Keyword option must be terminated by colon, not newline

#define   ERR_UNEXPECTED_NULL                 355
//  "NULL unexpectedly encountered-reached EOF?

#define   ERR_PPD_SYNTAX_MODELNAME            356
//      Syntax error in Modelname field

#define   ERR_OPENGROUPS_NESTED        357
//    Two OpenGroup statements encountered without 
//    an intervening CloseGroup

#define   ERR_OPEN_CLOSEGROUP_MISMATCH  358
//    Option for CloseGroup doesn't match Option given in OpenGroup



#define   ERR_PAPERDIMENSION           400
//    The keyword PaperDimension:

#define   ERR_IMAGEABLEAREA            401
// The Keyword ImageableArea

#define   ERR_PAGESIZE                 402
// The Keyword PageSize

#define   ERR_PAGEREGION               403
// The Keyword PageRegion

#define   ERR_DEFAULTPAGESIZE          404
// The Keyword DefaultPageSize

#define   ERR_INPUTSLOT                405
// The Keyword InputSlot

#define   ERR_REQUIRESPAGEREGION       406
// The Keyword RequiresPageRegion

#define   ERR_MANUALFEED_TRUE          407
// The Keyword ManualFeed TRUE:

#define   ERR_DEFAULTINPUTSLOT         408
// The Keyword DefaultInputSlot

#define   ERR_DUPLEX_NONE              409
// The Keyword Duplex None:

#define   ERR_DUPLEX_DUPLEXTUMBLE      410
// The Keyword Duplex DuplexTumble:

#define   ERR_DUPLEX_DUPLEXNOTUMBLE    411
// The Keyword Duplex DuplexNoTumble:

#define   ERR_DUPLEX_SIMPLEXTUMBLE     412
// The Keyword Duplex SimplexTumble:

#define   ERR_SETRESOLUTION            413
// The Keyword SetResolution

#define   ERR_RESOLUTION               414
// The Keyword Resolution

#define   ERR_DEFAULTRESOLUTION        415
// The Keyword DefaultResolution

#define   ERR_OUTPUTBIN                416
// The Keyword OutputBin

#define   ERR_DEFAULTOUTPUTBIN         417
// The Keyword DefaultOutputBin

#define   ERR_MEDIATYPE                418
// The Keyword MediaType

#define   ERR_DEFAULTMEDIATYPE         419
// The Keyword DefaultMediaType

#define   ERR_COLORDEVICE              420
// The Keyword ColorDevice

#define   ERR_LANGUAGELEVEL            421
// The Keyword LanguageLevel

#define   ERR_PROTOCOLS                422
// The Keyword Protocols

#define   ERR_LANDSCAPEORIENTATION     423
// The Keyword LandscapeOrientation

#define   ERR_TRUEIMAGEDEVICE          424
// The Keyword TrueImageDevice

#define   ERR_TTRASTERIZER             425
// The Keyword TTRasterizer

#define   ERR_SCREENFREQ               426
// The Keyword ScreenFrequency

#define   ERR_SCREENANGLE              427
// The Keyword ScreenAngle

#define   ERR_FREEVM                   428
// The Keyword FreeVM

#define   ERR_MODELNAME                429
//  any of the Modelname Keywords

#define   ERR_MANUALFEED_FALSE         430
// The Keyword ManualFeed  False:

#define   ERR_PASSWORD                 431
// The Keyword Password

#define   ERR_EXITSERVER               432
// The Keyword ExitServer

#define   ERR_MAXMEDIAWIDTH            433
// The Keyword MaxMediaWidth

#define   ERR_HWMARGINS                434
// The Keyword HWMargins

#define   ERR_PARAMCUSTOMPAGESIZE      435
// The Keyword ParamCustomPageSize

#define   ERR_INCLUDE                  436
// The keyword Include

#define   ERR_SYMBOLVALUE              437
//  The Keyword  SymbolValue

#define   ERR_DEFAULTFONT              438
//  The keyword DefaultFont

#define   ERR_OPENUI                   439
//  The Keyword  OpenUI

#define   ERR_DEFAULTOPENUI            440
//  The keyword formed by prepending Default to the keyword
//  introduced by OpenUI
                                       
#define   ERR_ORDERDEPENDENCY          441
//  The Keyword  OrderDependency

#define   ERR_UICONSTRAINT             442
//  The Keyword UI constraint

#define   ERR_INSTALLEDMEMORY          443
//  The Keyword VMOption !

#define   ERR_SCREENFREQRES            444
//  The Keyword ScreenFreqRes !

#define   ERR_SCREENANGLERES           445
//  The Keyword ScreenAngleRes !

/* RS
#define   ERR_COLLATE                  446 
//  The keyword COLLATE
*/

#ifdef Adobe_Driver
#define   ERR_FAXSUPPORT               447
//  The keyword FaxSupport
#endif


#define   ERR_PATCHFILE                448
// The Keyword PatchFile

#define   ERR_JOBPATCHFILE             449
// The Keyword JobPatchFile

#define   ERR_FONTCACHESIZE            450
// The Keyword FCacheSize

#define   ERR_WAITTIMEOUT              451
// The keyword SuggestedWaitTimeout

#define   ERR_JOBTIMEOUT               452
// The keyword SuggestedJobTimeout

#define   ERR_PRINTPSERRORS            453
// The keyword PrinterPSErrors

#define   ERR_COLLATE_TRUE             454 
//  The keyword Collate True

#define   ERR_COLLATE_FALSE            455
//  The keyword Collate False

#define   ERR_OUTPUTORDER_NORMAL       456
//  The keyword OutputOrder Normal

#define   ERR_OUTPUTORDER_REVERSE      457
//  The keyword OutputOrder Reverse  

#define   ERR_DEFAULTOUTPUTORDER       458
//  The keyword DefaultOutputOrder

#define   ERR_ADHASEURO                459
//  The keyword ADHasEuro
