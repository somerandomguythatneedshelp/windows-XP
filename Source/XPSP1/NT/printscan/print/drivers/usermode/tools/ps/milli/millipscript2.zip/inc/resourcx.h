/*****************************************************************************
*                                                                           
* Module Name: RESOURCX.H
*                                                                           
* Description: 
*              
*****************************************************************************/

#define RES_begin 256
#define RES_trig  257
#define RES_end   258


//the types of trig resources

#define RESTRIG_begin   0
#define RESTRIG_tangent 1
#define RESTRIG_sine    2
#define RESTRIG_end     3



