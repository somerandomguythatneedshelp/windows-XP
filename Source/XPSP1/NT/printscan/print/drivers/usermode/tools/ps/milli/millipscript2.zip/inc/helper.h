/*   helper.h  */

BOOL  FAR  PASCAL  KeywordGetNumOfOptions(
LPPDEVICE  lppd ,
WORD  MainKeywordIndex,
LPWORD  lpNumOptions);


BOOL  FAR  PASCAL  KeywordGetKeywordTranslation(
LPPDEVICE  lppd ,
WORD  MainKeywordIndex,
LPBYTE  FAR  *lplpTranslation,
LPWORD  lpLen);


BOOL  FAR  PASCAL  KeywordGetOptionTranslation(
LPPDEVICE  lppd ,
WORD  MainKeywordIndex,
WORD  OptionKeywordIndex,
LPBYTE  FAR  *lplpTranslation,
LPWORD  lpLen) ;


BOOL  FAR  PASCAL  KeywordGetOptionPS(
LPPDEVICE  lppd ,
WORD  MainKeywordIndex,
WORD  OptionKeywordIndex,
LPBYTE  FAR  *lplpInvocation,
LPWORD  lpLen) ;


LPBYTE   FAR  PASCAL  StringRefToLPBYTE(
LPPDEVICE  lppd ,
DWORD    dwstringref) ;


BOOL    FAR  PASCAL  KeywordSetCurrentOptionArray(
LPPDEVICE  lppd ,
WORD  MainKeywordIndex, 
LPBOOL  lpOptionArray);


BOOL    NEAR  PASCAL  modifyOptionState(
LPOPTIONSTATE  lpOptionState ,
WORD  MainKeywordIndex, 
LPBOOL  lpOptionArray,
WORD    numMainKeyHdrs,
WORD    numOptions );


BOOL    FAR  PASCAL  KeywordGetCurrentOptionArray(
LPPDEVICE  lppd ,
WORD  MainKeywordIndex, 
LPBOOL  lpOptionArray) ;


BOOL    FAR  PASCAL  KeywordGetCurrentOption(
LPPDEVICE  lppd ,
WORD  MainKeywordIndex, 
LPWORD  lpOptionIndex) ;


BOOL    FAR  PASCAL  KeywordSetCurrentOption(
LPPDEVICE  lppd ,
WORD  MainKeywordIndex, 
WORD  OptionIndex) ;


BOOL    FAR  PASCAL  KeywordNextOrderedKeyword(
LPPDEVICE  lppd ,
LPWORD  lpKeywordIndex, 
WORD  CurrentKeywordIndex) ;


BOOL    FAR  PASCAL  KeywordOptionConstraintArray(
LPPDEVICE  lppd ,
WORD  MainKeywordIndex, 
LPBOOL  lpOptionArray) ;


BOOL    FAR  PASCAL  IsKeywordOptConstrained(
LPPDEVICE  lppd ,
WORD  MainKeywordIndex, 
WORD  OptionKeywordIndex) ;



BOOL    FAR  PASCAL  KeywordGetFirstOptionNotConstrained(
LPPDEVICE  lppd ,
WORD  MainKeywordIndex, 
LPWORD  lpOptionKeywordIndex) ;














