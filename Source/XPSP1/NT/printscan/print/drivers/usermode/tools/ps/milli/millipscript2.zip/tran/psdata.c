/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PSDATA.C                                                     */
/*                                                                           */
/* Description: This module contains the functions for                       */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include <string.h>
#include <ctype.h>

#pragma code_seg(_TRANSSEG)


#define  CTRLA    (BYTE)0x01
#define  CTRLC    (BYTE)0x03
#define  CTRLD    (BYTE)0x04
#define  CTRLE    (BYTE)0x05
#define  CTRLQ    (BYTE)0x11
#define  CTRLS    (BYTE)0x13
#define  CTRLT    (BYTE)0x14
#define  CTRLLBRK (BYTE)0x1B
#define  CTRLBKSL (BYTE)0x1C

#define PS_BUFSIZE 5000
#define STRINGBUFSIZE 1024
#define PS_SPCLSIZE   ((DWORD)0xFFFF)   /* special ps data buffer size */

#define  LOW      0x00
#define  HIGH     0x01

#define MAX(a,b)         ( a > b ? a : b )

BYTE HexTable[16] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 
                   'B', 'C', 'D', 'E', 'F'};

DWORD FAR PASCAL CToPSStr(BYTE huge *lpzPS, BYTE huge *lpzC, DWORD dwLen);
VOID   FAR PASCAL PSSendDirect(LPPDEVICE lppd, BYTE huge *lpData, DWORD dwNBytes);
short FAR PASCAL PSSendPJLStart(LPPDEVICE lppd);

PSOP gPSop[ MAX_PSOP - MIN_PSOP + 1 ] =
 {
 {"Ac " /* "arc "        */ ,0x0592},           //  PSOP_arc
 {"Ac " /* "arc "        */ ,0x0592},           //  PSOP_circulararc
 {"Ac " /* "arc "        */ ,0x0592},           //  PSOP_ellipticalarc
 {"An " /* "arcn "       */ ,0x0692},           //  PSOP_arcn
 {"arct "                   ,0x0792},           //  PSOP_circpiestroke
 {"A "  /* "ashow "      */ ,0x0a92},           //  PSOP_ashow
 {"D "  /* "awidthshow " */ ,0x0c92},           //  PSOP_awidthshow
 {"C "  /* "closepath "  */ ,0x1692},           //  PSOP_closepath
 {"def "/* "def "        */ ,0x3392},           //  PSOP_def
 {"V "  /* "div "        */ ,0x3692},           //  PSOP_div
 {"O "  /* "eofill "     */ ,0x3b92},           //  PSOP_eofill
 {"L "  /* "fill "       */ ,0x4292},           //  PSOP_circpiefill
 {"L "  /* "fill "       */ ,0x4292},           //  PSOP_fill
 {"; "  /* "grestore "   */ ,0x4d92},           //  PSOP_grestore
 {": "  /* "gsave "      */ ,0x4e92},           //  PSOP_gsave
 {"I "  /* "lineto "     */ ,0x6392},           //  PSOP_lineto
 {"M "  /* "moveto "     */ ,0x6b92},           //  PSOP_moveto
 {"N "  /* "newpath "    */ ,0x6f92},           //  PSOP_newpath
 {"-C " /* "rcurveto "   */ ,0x7a92},           //  PSOP_rcurveto
 {"- "  /* "rlineto "    */ ,0x8592},           //  PSOP_rlineto
 {"-M " /* "rmoveto "    */ ,0x8692},           //  PSOP_rmoveto
 {"+S " /* "scale "      */ ,0x8b92},           //  PSOP_scale
 {"Ji " /* "setfont "    */ ,0x9592},           //  PSOP_setfont
 {"Lc " /* "setlinecap " */ ,0x9992},           //  PSOP_setlinecap
 {"Lj " /* "setlinejoin "*/ ,0x9a92},           //  PSOP_setlinejoin
 {"Lw " /* "setlinewidth "*/,0x9b92},           //  PSOP_setlinewidth
 {"S "  /* "show "       */ ,0xa092},           //  PSOP_show
 {"XS " /* "xshow "      */ ,0xc292},           //  PSOP_xshow
 {"LH " /* "showpage "   */ ,0xa192},           //  PSOP_showpage
 {"K "  /* "stroke "     */ ,0xa792},           //  PSOP_stroke
 {"+ "  /* "translate "  */ ,0xad92},           //  PSOP_translate
 {"W "  /* "widthshow "  */ ,0xbb92},           //  PSOP_widthshow
 {"R "  /* "rotate "     */ ,0x8892}            //  PSOP_rotate
};

typedef struct _IndexMatch{
     DWORD  psIndex;
     PSInjectionPoint  psInjectID;
}   IndexMatch;

#define MATCH_ENTRY     28
 
IndexMatch  TRANSSEG MatchMap[MATCH_ENTRY] =
{
 {PS_INDEX_PS_ADOBE      ,IPS_PSADOBE},
 {PS_INDEX_PAGES_AT_END  ,IPS_PAGESATEND},
 {PS_INDEX_PAGES_NUMBER  ,IPS_PAGES},
 {PS_INDEX_PAGE_ORDER    ,IPS_PAGEORDER},
 {PS_INDEX_VIEWING_ORIENTATION    ,IPS_ORIENTATION},
 {PS_INDEX_DOCUMENT_NEEDED_RESOURCES   , IPS_DOCUMENTNEEDEDRESOURCES}, 
 {PS_INDEX_DOCUMENT_SUPPLIED_RESOURCES, IPS_DOCUMENTSUPPLIEDRESOURCES},
 {PS_INDEX_BOUNDING_BOX  ,IPS_BOUNDINGBOX},
 {PS_INDEX_PAGE_BOUNDINGBOX  ,IPS_PAGEBOUNDINGBOX},
// {PS_INDEX_REQUIREMENTS  ,IPS_REQUIREMENTS},
 {PS_INDEX_END_COMMENTS  ,IPS_ENDCOMMENTS},
 {PS_INDEX_BEGIN_PROLOG  ,IPS_BEGINPROLOG},
 {PS_INDEX_END_PROLOG    ,IPS_ENDPROLOG},
 {PS_INDEX_BEGIN_SETUP   ,IPS_BEGINSETUP},
 {PS_INDEX_END_SETUP     ,IPS_ENDSETUP},
 {PS_INDEX_TRAILER       ,IPS_TRAILER},
 {PS_INDEX_BEGIN_DEFAULTS,IPS_BEGINDEFAULTS},
 {PS_INDEX_END_DEFAULTS  ,IPS_ENDDEFAULTS},
 {PS_INDEX_EOF           ,IPS_EOF},
 {PS_INDEX_PAGE_NUMBER   ,IPS_PAGE_PAGENUMBER},
 {PS_INDEX_BEGIN_PAGE_SETUP   ,IPS_PAGE_BEGINSETUP},
 {PS_INDEX_END_PAGE_SETUP     ,IPS_PAGE_ENDSETUP},
 {PS_INDEX_PAGE_TRAILER       ,IPS_PAGE_TRAILER},
 {PS_INDEX_PHYSICAL_PAGES     ,0}, // match with nothing
 {PS_INDEX_ENDPAGECOMMENTS    ,IPS_ENDPAGECOMMENTS},
 {PS_INDEX_PLATECOLOR         ,IPS_PLATECOLOR},
 {PS_INDEX_DOCUMENTPROCESSCOLORS    ,IPS_DOCUMENTPROCESSCOLORS},
 {PS_INDEX_DOCUMENTPROCESSCOLORSATEND    ,IPS_DOCUMENTPROCESSCOLORSATEND},
 {PS_INDEX_SHOWPAGE           ,IPS_PAGE_SHOWPAGE}
};                               

/**********************************************************************
*                       BCPConvertToBinary
*
*  Function:  Makes a block of binary data compatible with BCP by "escaping"
*             any special characters which might be in the data.
*
*  Called:    WORD FAR PASCAL BCPConvertToBinary(LPBYTE InData,LPBYTE BinaryData,
*                                          WORD Number)
*
*  Parameters:  LPBYTE InData --     pointer to the input binary data
*               LPBYTE BinaryData -- pointer to the output binary data
*               WORD   Number --     the number of bytes to be converted
*
*  Returns:   WORD -- number of converted bytes
*
**********************************************************************/

WORD FAR PASCAL BCPConvertToBinary(BYTE huge * InData,BYTE huge * BinaryData,WORD Number)
{
   WORD  OutputNumber;
   WORD  i;

   OutputNumber =  0;
   for(i=0; i< Number; i++)
   {
   switch(*InData)
   {
      case CTRLA   :
      case CTRLC   :
      case CTRLD   :
      case CTRLE   :
      case CTRLQ   :
      case CTRLS   :
      case CTRLT   :
      case CTRLBKSL:
      *BinaryData = CTRLA;
      BinaryData++;
      *BinaryData = (BYTE)(*InData ^ 0x40);
      BinaryData++;
      InData++;
      OutputNumber += 2;
      break;

      default      :
      *BinaryData = *InData;
      BinaryData++;
      InData++;
      OutputNumber++;
      break;
   }
   }

   return(OutputNumber);
}

/**********************************************************************
*                       NOConvertToBinary
*
*  Function: This function is used in place of BCP or EBCP conversion when 
*            the "no protocol" switch is set.
*
*  Called:   WORD FAR PASCAL NOConvertToBinary(LPBYTE InData,LPBYTE BinaryData,
*                                              WORD Number)
*
*  Parameters:  LPBYTE InData -- pointer to the input binary data
*               LPBYTE BinaryData -- pointer to the output binary data
*               WORD   Number --  the number of bytes to be converted
*
*  Returns:     WORD -- number of converted bytes
*
**********************************************************************/

WORD FAR PASCAL NOConvertToBinary(BYTE huge * InData,BYTE huge *  BinaryData,WORD Number)
{
   MemCopy(BinaryData,InData,(DWORD) Number);

   return(Number);
}

/**********************************************************************
*                       EBCPConvertToBinary
*
*  Function:   Makes a block of binary data compatible with EBCP by "escaping"
*              any special characters which might be in the data.
*
*  Called:     WORD FAR PASCAL EBCPConvertToBinary(LPBYTE InData,LPBYTE BinaryData,
*                                          WORD Number)
*
*  Parameters:  LPBYTE InData -- pointer to the input binary data
*               LPBYTE BinaryData -- pointer to the output binary data
*               WORD Number --  the number of bytes to be converted
*
*  Returns:     WORD -- number of converted bytes
*
**********************************************************************/

WORD FAR PASCAL EBCPConvertToBinary(BYTE huge * InData,BYTE huge * BinaryData,WORD Number)
{
   WORD  OutputNumber;
   WORD  i;

   OutputNumber =  0;
   for(i=0; i< Number; i++)
   {
   switch(*InData)
   {
      case CTRLA   :
      case CTRLC   :
      case CTRLD   :
      case CTRLE   :
      case CTRLQ   :
      case CTRLS   :
      case CTRLT   :
      case CTRLLBRK:
      case CTRLBKSL:
      *BinaryData = CTRLA;
      BinaryData++;
      *BinaryData = (BYTE)(*InData ^ 0x40);
      BinaryData++;
      InData++;
      OutputNumber += 2;
      break;

      default      :
      *BinaryData = *InData;
      BinaryData++;
      InData++;
      OutputNumber ++;
      break;
   }
   }

   return(OutputNumber);
}
// The following two routines support four cases for Bitmaps:
//
//      DataType        Form
//      -----------|-------------
//         0       | Unpacked binary data               - level1
//         1       | Unpacked hex    data               - level1
//         2       | Packed binary data( RLE only)      - level2
//         3       | Packed ascii85 data(RLE + ascii85) - level2

/**********************************************************************
*                       PSSendBitMapTypeAscii7
*
*  Function:   Sends an integer that describes the type of ASCII bitmap
*
*  Called:     VOID FAR PASCAL PSSendBitMapTypeAscii7(LPPDEVICE lppd, short Flavor)
*
*  Parameters:  LPPDEVICE  lppd     Pointer to PDEVICE structure
*               short      Flavor   Differentiates between Level 1 and Level 2
*
*  Returns:     Nothing
*
**********************************************************************/

VOID FAR PASCAL PSSendBitMapTypeAscii7(LPPDEVICE lppd, short Flavor)
{
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   if(Flavor==PPSLEVEL2)
   {
   (*tempptr->PSSendShort)(lppd,3);
   }
   else
   {
      if (RLEDecodeNeeded(lppd))
         (*tempptr->PSSendShort)(lppd,5);
      else
      (*tempptr->PSSendShort)(lppd,1);

   }
}

/**********************************************************************
*                       PSSendBitMapTypeBinary
*
*  Function:   Sends an integer that describes the type of binary bitmap 
*
*  Called:     VOID FAR PASCAL PSSendBitMapTypeBinary(LPPDEVICE lppd, short Flavor)
*
*  Parameters:  LPPDEVICE  lppd     Pointer to PDEVICE structure
*               short      Flavor   Differentiates between Level 1 and Level 2
*
*  Returns:     Nothing
*
**********************************************************************/

VOID FAR PASCAL PSSendBitMapTypeBinary(LPPDEVICE lppd, short Flavor)
{
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   if(Flavor==PPSLEVEL2)
   {
   (*tempptr->PSSendShort)(lppd,2);
   }
   else
   {
      if (RLEDecodeNeeded(lppd))
         (*tempptr->PSSendShort)(lppd,4);
      else
         (*tempptr->PSSendShort)(lppd,0);
   }
}

/**********************************************************************
*                       PSSendBitMapTerminatorAscii7
*
*  Function:   Sends an terminator for an ASCII bitmap
*
*  Called:     VOID FAR PASCAL PSSendBitMapTerminatorAscii7(LPPDEVICE lppd)
*
*  Parameters:  LPPDEVICE  lppd     Pointer to PDEVICE structure
*
*  Returns:     Nothing
*
**********************************************************************/

VOID FAR PASCAL PSSendBitMapTerminatorAscii7(LPPDEVICE lppd)
{
  PSSendFragment(lppd,PSFRAG_crlf);
}
/**********************************************************************
*                       PSSendBitMapTerminatorBinary
*
*  Function:   Sends a terminator for a binary bitmap
*
*  Called:     VOID FAR PASCAL PSSendBitMapTerminatorBinary(LPPDEVICE lppd)
*
*  Parameters:  LPPDEVICE  lppd     Pointer to PDEVICE structure
*
*  Returns:     Nothing
*
**********************************************************************/

VOID FAR PASCAL PSSendBitMapTerminatorBinary(LPPDEVICE lppd)
{
  PSSendFragment(lppd,PSFRAG_space);
}

/**********************************************************************
*                       PSSendBeginProtocol
*
*  Function:   Sends the protocol at the beginning of a job.
*
*  Called:     short FAR PASCAL PSSendBeginProtocol(LPPDEVICE lppd);
*
*  Parameters: LPPDEVICE lppd   Pointer to PDEVICE structure
*
*  Returns:    short RC_ok or RC_fail
*
**********************************************************************/

short FAR PASCAL PSSendBeginProtocol(LPPDEVICE lppd)
{
   short retval;
   char  protout[4];
   WORD  ProtocolOption;
   BOOL  fProtocolNone = FALSE;

   retval = RC_ok;

   fProtocolNone = 
     (lppd->lpPSExtDevmode->dm2.bOutputDialect == (BYTE) DIALECT_EPS);

   if (fProtocolNone == FALSE)
   {
     //  output PJL protocol first!
     if(((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->devcaps.PJLsupport)
     {
        if (lppd->lpPSExtDevmode->dm2.bPJL_Protocol)
                  {
           PSSendPJLStart(lppd);
                  }
     }


     // For archive output formats, skip start-of-job protocol
     if (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE ||
         lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE)
         return(retval);

     // Send start-of-job protocol: ^AM for EBCP (TBCP), 
     // maybe ^D for BCP/Normal.

   // Get the current protocol
   ProtocolOption = lppd->lpPSExtDevmode->dm2.iDataOutputFormat;

   switch(ProtocolOption)
   {
     case PROTOCOL_TBCP :   // TBCP
      // send ^AM
      lstrcpy((LPSTR)protout,(LPSTR)"\001M");
                AdobeOEMSendPSStub(lppd, PS_INDEX_LEADING_CTRL_AM, 
                                   protout, 2);
      break;

     case PROTOCOL_BCP  :
     case PROTOCOL_ASCII:
         // Now we have the UI to specify where to put ^D
         //  Added 20-Jan-1994  -by-  [olegs]
         
         if(lppd->lpPSExtDevmode->dm2.bSendCtrlDBefore)
         {
             lstrcpy((LPSTR)protout,(LPSTR)"\004");
             AdobeOEMSendPSStub(lppd, PS_INDEX_LEADING_CTRL_D, 
                                protout, 1);
         }
        break;

   }
   }

   return(retval);
}

/**********************************************************************
*                       PSSendPJLStart
*
*  Function:  Sends the JCL protocol at the beginning of a job, followed by
*             the specified JCL Setup items, based on the StartJCLJob, JCLOpenUI
*             and JCLToPSInterpreter sections from the PPD for the current printer.
*
*  Called:    short FAR PASCAL PSSendPJLStart(LPPDEVICE lppd);
*
*  Parameters:  LPPDEVICE lppd  Pointer to PDEVICE structure
*
*  Returns:     short RC_ok or RC_fail
*
**********************************************************************/

short FAR PASCAL PSSendPJLStart(LPPDEVICE lppd)
{
   LPBYTE  lpOutBuf, lpSrcBuf;
   WORD    length ;
   int    rc;
   WORD   KeywordIndex, CurrentKeywordIndex, OptionIndex;
   STRINGREF   invoc ;

   lpOutBuf = GlobalAllocPtr(GHND, PS_BUFSIZE) ;
   if(!lpOutBuf)
      return(0) ;  // failure.

   invoc.dword =
     ((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->JCLinfo.JCLBegin.dword ;

   lpSrcBuf = StringRefToLPBYTE(lppd, invoc.dword) ;

   AdobeOEMSendPSStub(lppd, PS_INDEX_JCL_BEGIN, lpSrcBuf, invoc.w.length);

   //Send PostScript for the stuff from the "JCLSetup" section of the PPD

   // Get first keyword index
   rc = KeywordNextOrderedKeyword(lppd,(LPWORD)&KeywordIndex, FIRST_LAST_KEYWORD-JCLSETUP);

   while (rc == TRUE && KeywordIndex != FIRST_LAST_KEYWORD)
   {
      KeywordGetCurrentOption(lppd, KeywordIndex, (LPWORD) &OptionIndex);

      //Send PPD PostScript.
      length = PS_BUFSIZE ;
      length = KeywordGetOptionPS(lppd, KeywordIndex, OptionIndex, lpOutBuf, 
                              (LPWORD) &length) ;

      AdobeOEMSendPSStub(lppd, PS_INDEX_JCL_FEATURE, lpOutBuf, length);

//    PSSendData(lppd, lpOutBuf, length) ;

      // Get next keyword index
      CurrentKeywordIndex = KeywordIndex;
      rc = KeywordNextOrderedKeyword(lppd, (LPWORD)&KeywordIndex, CurrentKeywordIndex);
   }

//   length = CopyStringRefToLPBYTE(lppd->lpWPXblock, lpOutBuf,
//     ((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->JCLinfo.JCLToPSInterpreter.dword) ;

   invoc.dword =
     ((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->JCLinfo.JCLToPSInterpreter.dword ;

   lpSrcBuf = StringRefToLPBYTE(lppd, invoc.dword) ;

   AdobeOEMSendPSStub(lppd, PS_INDEX_JCL_TO_PS_INTERPRETER, lpSrcBuf, invoc.w.length);

   GlobalFreePtr(lpOutBuf) ;
   return RC_ok;
}

/**********************************************************************
*                       PSSendEndProtocol
*
*  Function:  Sends the protocol at the end of a job.
*
*  Called:    short FAR PASCAL PSSendEndProtocol(LPPDEVICE lppd);
*
*  Parameters:  LPPDEVICE lppd  Pointer to PDEVICE structure
*
*  Returns:     short RC_ok or RC_fail
*
**********************************************************************/

short FAR PASCAL PSSendEndProtocol(LPPDEVICE lppd)
{
    short retval;
    char  protout[20];
    PROTOCOLS ProtocolOption;
    BOOL  fProtocolNone = FALSE;
    HANDLE bufhdl = NULL ;
    LPSTR  buf    = NULL ;
    retval = RC_ok;
    
    fProtocolNone = 
        (lppd->lpPSExtDevmode->dm2.bOutputDialect == (BYTE) DIALECT_EPS);

    if (fProtocolNone == FALSE)
    {
   // Send end-of-job protocol: ESC%-12345X for EBCP, ^D for BCP/Normal.
        
     // For archive output formats, skip end-of-job protocol
     if (lppd->lpPSExtDevmode->dm.enumDialect == DIA_ARCHIVE ||
         lppd->lpPSExtDevmode->dm.enumDialect == DIA_PJL_ARCHIVE)
         goto SendPJLProtocol;

   // Get current protocol
   ProtocolOption = lppd->lpPSExtDevmode->dm2.iDataOutputFormat;
        
        switch(ProtocolOption)
        {
            case PROTOCOL_TBCP: // TBCP
              /* If no explicit EndJCLJob quoted string, send "ESC%-12345X" */
              lstrcpy((LPSTR)protout,(LPSTR)"\033%-12345X");
              AdobeOEMSendPSStub(lppd, PS_INDEX_TBCP_END, protout, 9);
              break;

      case PROTOCOL_ASCII:
      case PROTOCOL_BCP  :
            //================================================
            // Now we have the UI to specify where to put ^D
            //  Added 20-Jan-1994  -by-  [olegs]
            
            if(lppd->lpPSExtDevmode->dm2.bSendCtrlDAfter)
            {
                               lstrcpy((LPSTR)protout,(LPSTR)"\004");
                               AdobeOEMSendPSStub(lppd, PS_INDEX_TRAILING_CTRL_D, 
                                                  protout, 1);
            }
            break;
      default           :
            break;
      }

SendPJLProtocol:
     //  output PJL protocol last!
     if(((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->devcaps.PJLsupport)
     {
         LPBYTE  lpSrcBuf;
         STRINGREF   invoc ;

         if (lppd->lpPSExtDevmode->dm2.bPJL_Protocol)
         {
            // Fix bug 187223. Do not send PJL END protocol for "Pure Binary" mode.
            if (ProtocolOption != PROTOCOL_BINARY) 
            {
                invoc.dword =
                ((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->JCLinfo.JCLEnd.dword ;

                lpSrcBuf = StringRefToLPBYTE(lppd, invoc.dword) ;
   
                AdobeOEMSendPSStub(lppd, PS_INDEX_JCL_END,
                                        lpSrcBuf, invoc.w.length);
            }
            else
            {
                protout[0] = 0;
                AdobeOEMSendPSStub(lppd, PS_INDEX_JCL_END, protout, 0);
            }
         }
     }
   }
   return(retval);
}
/**********************************************************************
*                       PSSendProc
*
*  Function:  Retrieves a "Proc" from the resources and ships it out to the
*             port
*
*  Called:    short FAR PASCAL PSSendProc(LPPDEVICE lppd, short sProcID)
*
*  Parameters:  LPPDEVICE lppd -- pdevice pointer
*               short sProcID  -- procset ID from resrcid.h
*
*  Returns:     short RC_ok or RC_fail
*
**********************************************************************/
#undef GlobalUnlock
short FAR PASCAL PSSendProc(LPPDEVICE lppd, short sProcID)
{
   short sRC;
   DWORD wLen;
   HANDLE hRes;
   HANDLE hMem;
   LP lpRes;
   char buff[255];
   LPSTR lpTmp, lpDest, offset;

   sRC=RC_fail;
   hRes = FindResource(ghDriverMod,(LPSTR)((LONG)sProcID),(LPSTR)((LONG)PS_proc));
   if (hRes != 0)
   {
   hMem = LoadResource(ghDriverMod,hRes);
   if (hMem != NULL)
   {
      lpRes = (LP)LockResource(hMem);
      if (lpRes != NULL)
      {
      //get the length of the resource
      wLen = SizeofResource(ghDriverMod,hRes);
      // Make the last byte (either NULL or LF) to NULL. Fix a GPF inside _fstrstr() below.
      lpRes[wLen-1] = (char) 0;
      // get rid of a trailing NULL
      while (lpRes[wLen-1] == (char)0)
         wLen --;
        //
        // Check for either %%BeginProcSet or %%BeginResource proset
        //
      if (_fstrstr((LPSTR)lpRes, "%%BeginProcSet:") != NULL)
          
          AdobeOEMSendPSStub(lppd, PS_INDEX_PROCSET, lpRes, (WORD)wLen);
      else
      {
         if ((offset = _fstrstr((LPSTR)lpRes, "%%BeginResource: ")) != NULL)
         {
         // save the %%BeginResource: file name version  info
           
           lpTmp = lpRes+ (offset-lpRes) + 17;
           lpDest = buff;
           while (*lpTmp != 0x0D && *lpTmp != 0x0A)
           {
              *lpDest++ = *lpTmp++;
           }
           *lpDest = '\0';
            if( (_fstrstr((LPSTR)buff, "file ") != NULL) ||
                (_fstrstr((LPSTR)buff, "procset ") != NULL ))

               AddFileDSCEntry(lppd,buff,TRUE);  //TRUE == File Supplied
           
           AdobeOEMSendPSStub(lppd, PS_INDEX_RESOURCE, lpRes, (WORD)wLen);
         }
         else
             PortWrite(lppd,lpRes,(WORD)wLen); 
      }

      sRC=RC_ok;
      UnlockResource(hMem);   // This is actually a GlobalUnlock()
      }
      FreeResource(hMem);
    }
   }
   return(sRC);
}
#define GlobalUnlock(h)  

/*****************************************************************************
*
*                              PSSendMySetup
*
* Function: Send the mysetup definition. Routine sets up the jobCTM for a call to SendCTM
*
*
* Parameters:  lppd         LPPDEVICE     pdevice pointer
*              lpRect       LPRECT        imageable area.
*              sSendType    SETUP_TYPE    the type of setup to send.
*                                 SETUP_GDI_COORDS - standard GDI coord sys.
*                                 SETUP_PS_COORDS -  Minheader coord sys.
*                                 SETUP_EPS_COORDS - EPS coord sys.
*                                 SETUP_XGDI_COORDS - Aldus' coord sys.
*
* RETURNS           MEANING
* -------           -------
* short             RC_ok
*
*****************************************************************************/
short FAR PASCAL PSSendMySetup(LPPDEVICE lppd, LPRECT lpRect, SHORT sSendType  )
{
   float     ZERO_Trans;        // value 0.0, in appropriate type.
   float     ONE_Trans;         // value 1.0, in appropriate type.
   float     flScaleX;          // Scale factor from GDI units to PS units
   float     flScaleY;          // Scale factor from GDI units to PS units
   PSMATRIX  Matrix;
   short     i;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   ZERO_Trans = (float) 0.0;
   ONE_Trans  = (float) 1.0;
   flScaleX    = ((float) 72.0)/ lppd->DeviceRes.x_res;
   flScaleY    = ((float) 72.0)/ lppd->DeviceRes.y_res;

   if( sSendType == SETUP_GDI_COORDS )
   {
     // Standard Postscript output for Driver - Pick CTM values from PDEVICE
     Matrix[0] = lppd->psmatrix[0];
     Matrix[1] = lppd->psmatrix[1];
     Matrix[2] = lppd->psmatrix[2];
     Matrix[3] = lppd->psmatrix[3];
     Matrix[4] = lppd->psmatrix[4];
     Matrix[5] = lppd->psmatrix[5];
   }
   else  if( sSendType == SETUP_EPS_COORDS )
       {
         // EPS output  - do not rotate in landscape mode
         if (lppd->lpPSExtDevmode->dm.bMirror)
         {
             // Fixed bug 142464. Support mirror printing. 4/23/96 jjia
             Matrix[0] = -flScaleX;
             Matrix[1] = ZERO_Trans;
             Matrix[2] = ZERO_Trans;
             Matrix[3] = -flScaleY;
             Matrix[4] = lpRect->right * flScaleX;
             Matrix[5] = lpRect->bottom * flScaleY;
         }
         else
         {
             Matrix[0] = flScaleX;
             Matrix[1] = ZERO_Trans;
             Matrix[2] = ZERO_Trans;
             Matrix[3] = -flScaleY;
             Matrix[4] = lpRect->left * flScaleX;
             Matrix[5] = lpRect->bottom * flScaleY;
         }
       }
       else  if( sSendType == SETUP_XGDI_COORDS )
            {
              WORD  xM, yM;
              if (lppd->lpPSExtDevmode->dm.PaperOrient == OR_PORTRAIT)
              {
                xM = lpRect->left ;
                yM = lpRect->bottom ;
              }
              else
              {
                xM = lpRect->top ;
                yM = lpRect->right ;
              }
              // Aldus output  - always portrait 
              Matrix[0] = flScaleX;
              Matrix[1] = ZERO_Trans;
              Matrix[2] = ZERO_Trans;
              Matrix[3] = -flScaleY;
              Matrix[4] = xM * flScaleX;
              Matrix[5] = yM * flScaleY;
            }
            else
            {
              // Standard Minimal header output for Driver 

              switch (lppd->lpPSExtDevmode->dm.PaperOrient)
              {
                case OR_PORTRAIT :
                  Matrix[0] = ONE_Trans;
                  Matrix[1] = ZERO_Trans;
                  Matrix[2] = ZERO_Trans;
                  Matrix[3] = ONE_Trans;
                  Matrix[4] = ZERO_Trans;
                  Matrix[5] = ZERO_Trans;
                break;

                case OR_LANDSCAPE :
                  // take into account landscape orientation - bug #17791 - ShyamV - 3/14/94
                  if (((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->devcaps.landscapeOrientPlus90) 
                  {
                     Matrix[0] = ZERO_Trans;
                     Matrix[1] = ONE_Trans;
                     Matrix[2] = -ONE_Trans;
                     Matrix[3] = ZERO_Trans;
                     Matrix[4] = lppd->ptPaperDim.y * flScaleX;
                     Matrix[5] = ZERO_Trans;
                  }
                  else
                  {
                     Matrix[0] = ZERO_Trans;
                     Matrix[1] = -ONE_Trans;
                     Matrix[2] = ONE_Trans;
                     Matrix[3] = ZERO_Trans;
                     Matrix[4] = ZERO_Trans;
                     Matrix[5] = lppd->ptPaperDim.x * flScaleY;
                  }
                break;

                case OR_ROTLANDSCAPE :
                  if (((LPPRINTERINFO)lppd->lpWPXblock->WPXprinterInfo)->devcaps.landscapeOrientPlus90) 
                  {
                     Matrix[0] = ZERO_Trans;
                     Matrix[1] = -ONE_Trans;
                     Matrix[2] = ONE_Trans;
                     Matrix[3] = ZERO_Trans;
                     Matrix[4] = ZERO_Trans;
                     Matrix[5] = lppd->ptPaperDim.x * flScaleY;
                  }
                  else
                  {
                     Matrix[0] = ZERO_Trans;
                     Matrix[1] = ONE_Trans;
                     Matrix[2] = -ONE_Trans;
                     Matrix[3] = ZERO_Trans;
                     Matrix[4] = lppd->ptPaperDim.y * flScaleX;
                     Matrix[5] = ZERO_Trans;
                  }
                break;
              }  // switch(..)
            }

   PSSendFragment(lppd,PSFRAG_slash);
   PSSendFragment(lppd,PSFRAG_mysetup);
   PSSendFragment(lppd,PSFRAG_leftbracket);
   for(i=0;i<6;i++)
   {
    (*tempptr->PSSendEx6Float)(lppd,Matrix[i]);
    lppd->lpGSStack->lpgGState->jobCTM[ i ] = Matrix[ i ];
   }

   PSSendFragment( lppd,PSFRAG_rightbracket );
   (*tempptr->PSSendBasic)( lppd,PSOP_def );
   (*tempptr->PSSendCRLF)( lppd );

   return( RC_ok );
} // PSSendMySetup 


/*****************************************************************************
*
*                          CToPSStr
*
* Function: Converts unprintable characters to an escape sequence; escapes
*           special characters
*
* Called: DWORD CToPSStr(BYTE huge *lpzPS, BYTE huge *lpzC, DWORD dwLen)
*
* Parameters:   BYTE huge *lpzPS    Output string
*               BYTE huge *lpzC     Input string of chars to be converted or escaped
*               DWORD      dwLen    Length of string to be converted
*               
* 
* Returns:  Length of output string
*
*****************************************************************************/
DWORD FAR PASCAL CToPSStr(BYTE huge *lpzPS, BYTE huge *lpzC, DWORD dwLen)
{
    DWORD   dwCounter ;     // Number of actual bytes in output buffer
    BYTE    cChar;          // Current char we work with
    
    //  We must first check for counters, then for the end of the string
    
    dwCounter = 0;
    while(  dwLen  /* &&  ( cChar = *lpzC ) */  )
    {  // note zero is a perfectly valid glyph index, it doesn't mean EOL !
     //do we need to escape the char?
     //
     cChar = *lpzC ;

     if(( cChar < (char)32) || ( cChar > (char)127))
     {
         // characters outside the printable range are converted to an
         // octal escape sequence
         *lpzPS++ ='\\';

         *lpzPS++ = (CHAR)((cChar & 0x00C0) >> 6) + (CHAR)'0';  // 0000 0000 1100 0000
         *lpzPS++ =(CHAR)((cChar & 0x0038) >> 3) + (CHAR)'0';  // 0000 0000 0011 1000
         *lpzPS++ =(CHAR)((cChar & 0x0007) >> 0) + (CHAR)'0';  // 0000 0000 0000 0111

         dwCounter += 4 ;
     }
     else
     {
         //do we need to escape the printable char?
         //
         if(( cChar == '(') ||
        ( cChar == ')') ||
        ( cChar == '\\'))
         {
         // insert an escape character before these special chars
         *lpzPS++ = '\\';
         dwCounter++;
         }
         *lpzPS++ = cChar;
         dwCounter++;
     } 
     lpzC++ ;
     dwLen--;
    }

    //return the length of the output string
    return(dwCounter);
}

//these are the routines that will generate code in the 7-bit ascii
//mode, so they are allowed to send direct ascii out to the port
//

/*****************************************************************************
*
*                          PSSendTextAscii7
*
* Function: 
*
* Called:  short FAR PASCAL PSSendTextAscii7(LPPDEVICE lppd, LPSTR lpz)
*
* Parameters: LPPDEVICE lppd
*             LPSTR     lpz
*               
* Returns:  RC_ok
*
*****************************************************************************/

short FAR PASCAL PSSendTextAscii7(LPPDEVICE lppd, LPSTR lpz)
{
  //insert a left parenthesis
  PortWrite(lppd,LPARAN, lstrlen(LPARAN));

  PSSendStringAscii7( lppd, lpz, lstrlen(lpz) );

  PortWrite(lppd,RPARAN, lstrlen(RPARAN));
  return(RC_ok);                                 
}

/*****************************************************************************
*
*                          PSSendTextCharAscii7
*
* Function: 
*
* Called:  short FAR PASCAL PSSendTextCharAscii7(LPPDEVICE lppd, LPSTR lpz,
*                                                int count)
*
* Parameters: LPPDEVICE lppd     PDEVICE pointer
*             LPSTR     lpz      pointer to string of chars to send
*             int       count    Number of characters to send
*               
* Returns:  RC_ok
*
*****************************************************************************/

short FAR PASCAL PSSendTextCharAscii7(LPPDEVICE lppd, LPSTR lpz, int count)
{
  //insert a left parenthesis
  PortWrite(lppd,LPARAN, lstrlen(LPARAN));

  PSSendStringAscii7( lppd, lpz, count );

  PortWrite(lppd,RPARAN, lstrlen(RPARAN));
  return(RC_ok);                                 
}

/*****************************************************************************
*
*                            PSSendStringAscii7
*
* Function: This function outputs an unescaped string to the port.
*
* Called:   short FAR PASCAL PSSendStringAscii7(LPPDEVICE lppd, LPSTR lpz, int count)
*
* Parameters:   LPPDEVICE  lppd     The device context 
*               LPSTR      lpz      The string to output.
*               int        count    Number of chars (before escaping) to send
* 
* Returns:  short   PS_RC_ok      All went according to plan
*
*****************************************************************************/
short FAR PASCAL PSSendStringAscii7(LPPDEVICE lppd, LPSTR lpz, int count)
{
   HANDLE hTemp = NULL;
   BYTE huge *lpTemp;                               
   DWORD  dwLen;                                    

   dwLen = 4L * count ;    // The worst case - all non-printable
            // characters represented as /nnn.
   // This is the only function that uses this varaible
   if (!lppd->GlobalBuffer.lpStringAscii7)
       return RC_fail;
       
   // Check if Memory Block allocated (and kept track of in PDevice) is sufficient.
   if (lppd->GlobalBuffer.dStringAscii7 < dwLen)
   {
     MGUnlockFree(lppd, lppd->GlobalBuffer.hStringAscii7, TRUE);
     lppd->GlobalBuffer.lpStringAscii7 = (BYTE huge *) MGAllocLock(lppd,
                 (LPHANDLE)&lppd->GlobalBuffer.hStringAscii7,
                 dwLen,GHND,TRUE);
     if (lppd->GlobalBuffer.lpStringAscii7 == NULL)
     {
              lppd->GlobalBuffer.dStringAscii7 = 0;
              return RC_fail;
     }
     lppd->GlobalBuffer.dStringAscii7 = dwLen;
   }      
   lpTemp = (BYTE huge *)lppd->GlobalBuffer.lpStringAscii7;

   dwLen = CToPSStr( lpTemp, (BYTE huge *) lpz, (DWORD) count );

   PSSendDirect(lppd, lpTemp, dwLen);  //  Send Data direct, without
                  //  BCP and TBCP stuff because
                  //  we have all bytes in range
                  //  from  32 to 127
   return(RC_ok);
}

/*****************************************************************************
*
*                            PSSendCharAscii7
*
* Function: This function outputs a single ASCII character
*
* Called:   short FAR PASCAL PSSendCharAscii7(LPPDEVICE lppd, LPSTR lpz)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               LPSTR      lpz      The char to output.
* 
* Returns:  short   PS_RC_ok      All went according to plan
*
*****************************************************************************/

short FAR PASCAL PSSendCharAscii7(LPPDEVICE lppd, LPSTR character)
{
  PortWrite(lppd,(LP)character,1);
  return(RC_ok);                     
}

/*****************************************************************************
*
*                            PSSendDataAscii7
*
* Function: This function outputs ablock of ASCII data to the port.
*
* Called:   short FAR PASCAL PSSendDataAscii7(LPPDEVICE lppd, LP DataBlk,
*                                             WORD NumBytes)
*
* Parameters:   LPPDEVICE  lppd      The device context 
*               LPSTR      lpz       The string to output.
*               WORD       NumBytes  Number of bytes of data to send
* 
* Returns:  short   PS_RC_ok     
*
*****************************************************************************/

short FAR PASCAL PSSendDataAscii7(LPPDEVICE lppd, LP DataBlk,WORD NumBytes)
{
  PortWrite(lppd,DataBlk,NumBytes);
  return(RC_ok);                     
}

/*****************************************************************************
*
*                 PSSendShortAscii7
*
* Function: This function outputs a short number to the port.
*
* Called:   short FAR PASCAL PSSendShortAscii7(LPPDEVICE lppd,short sNum)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               short      sNum     The number to output.
* 
* Returns:  short   PS_RC_ok   
*
*****************************************************************************/

short FAR PASCAL PSSendShortAscii7(LPPDEVICE lppd, short sNum)
{
   char zTemp[12];
   short sLen;

   sLen=wsprintf((LPSTR)zTemp,(LPSTR)"%d ",sNum);
   PortWrite(lppd,(LPSTR)zTemp,sLen);

   return(sLen);
}

/*****************************************************************************
*
*                            PSSendFloatAscii7
*
* Function: This function outputs afloating point number to the port.
*
* Called:   short FAR PASCAL PSSendFloatAscii7(LPPDEVICE lppd, float num)
*
* Parameters:   LPPDEVICE  lppd     The device context 
*               float      num      The number to output.
* 
* Returns:  short   String length  
*
*****************************************************************************/

short FAR PASCAL PSSendFloatAscii7(LPPDEVICE lppd, float Num)
{
   char  NumString[20];
   LONG  Integer;
   LONG  Fraction;
   float fValue;
   char  *p;

   fValue = (float)fabs(Num) + (float)0.00005; // fValue = 128.76644
   Integer = (LONG)floor((double)fValue);    // Integer = 128

   fValue = (fValue - (float)Integer);        // fValue = 0.76644
   Fraction = (LONG)(fValue * (float)10000.0);// Fraction = 7664

   p = NumString;
   if (Num < (float)0.0)
   {
       *p++ =  '-';
   }

   // Send integer part. If the integer part is 0, do not send any thing. jjia  6/11/96
   if (Integer != 0 || Fraction == 0)
       p += wsprintf(p,"%0.1ld",Integer);

   if( 0L != Fraction )
   {
       p += wsprintf(p,".%0.4ld", Fraction);
       while ( *(--p) == '0')     // scan back until hit non-zero
        ;
       p++ ;
   }

   *p++ =  ' '; // Add space at the end of the string
   PortWrite(lppd,NumString, ( p - NumString) );

   return((short)(p - NumString ));
}

/*****************************************************************************
*
*                            PSSendEx6FloatAscii7
*
* Function: This function outputs afloating point number to the port.
*
* Called:   short FAR PASCAL PSSendEx6FloatAscii7(LPPDEVICE lppd, float num)
*
* Parameters:   LPPDEVICE  lppd     The device context 
*               float      num      The number to output.
* 
* Returns:  short   String length  
*
*****************************************************************************/

short FAR PASCAL PSSendEx6FloatAscii7(LPPDEVICE lppd, float Num)
{
   char  NumString[20];
   LONG  Integer;
   LONG  Fraction;
   float fValue;
   char  *p;

   fValue = (float)fabs(Num) + (float)0.0000005; // fValue = 128.76644
   Integer = (LONG)floor((double)fValue);    // Integer = 128

   fValue = (fValue - (float)Integer);        // fValue = 0.76644
   Fraction = (LONG)(fValue * (float)1000000.0);// Fraction = 7664

   p = NumString;
   if (Num < (float)0.0)
   {
       *p++ =  '-';
   }

   // Send integer part. If the integer part is 0, do not send any thing. jjia  6/11/96
   if (Integer != 0 || Fraction == 0)
       p += wsprintf(p,"%0.1ld",Integer);

   if( 0L != Fraction )
   {
       p += wsprintf(p,".%0.6ld", Fraction);
       while ( *(--p) == '0')     // scan back until hit non-zero
        ;
       p++ ;
   }

   *p++ =  ' '; // Add space at the end of the string
   PortWrite(lppd,NumString, ( p - NumString) );

   return((short)(p - NumString ));
}

/*****************************************************************************
*
*                         PSSendHexByteAscii7
*
* Function: This function outputs a formatted hex byte to the port.
*
* Called:   short FAR PASCAL PSSendHexByteAscii7(LPPDEVICE lppd, BYTE Num)
*
* Parameters:   LPPDEVICE  lppd     The device context 
*               BYTE       num      The hex byte to output.
* 
* Returns:  short   PS_RC_ok  
*
*****************************************************************************/

short FAR PASCAL PSSendHexByteAscii7(LPPDEVICE lppd, BYTE Num)
{
   CHAR  NumString[20];                          
   int   Length;                                 

   Length = wsprintf(NumString,"%2.2X ",Num);       // Convert Num to Hex
   PortWrite(lppd,NumString,Length);       // Write to the Port

   return(RC_ok);                                
}

/*****************************************************************************
*
*                 PSSendBitMapDataLevel1Ascii7
*
* Function: This function outputs a bitmap in ascii7 encoding to the port
*
* Called:   short FAR PASCAL PSSendBitMapDataAscii7(LPPDEVICE lppd, LPSTR lpz, int count)
*
* Parameters:   LPPDEVICE  lppd     The device context 
*               BYTE huge *DataSrc
*               DWORD      NumBytes
* 
* Returns:   Nothing
*
*****************************************************************************/
VOID FAR PASCAL PSSendBitMapDataLevel1Ascii7(LPPDEVICE lppd, BYTE huge *DataSrc,
                                  DWORD NumBytes)
{
  BYTE   Datum;
  LPSTR  pTemp;
  BYTE   huge *DataBlk;
  DWORD  j;
  int    CRLFLength;
  char   strCRLF[10];
  int    Length;
  int    strSize;

  unsigned char ptrString[256];  // Stack buffer is OK. Buffer is fixed 66 bytes.
             // GlobalAlloc() was overkill!! - ShyamV - 7/21/93
  strSize = sizeof(strCRLF);

  CRLFLength = LoadDrvrString(ghDriverMod,PSFRAG_crlf,strCRLF,strSize);
  strCRLF[CRLFLength] = '\0';

  pTemp = ptrString;
  DataBlk = DataSrc;
  Length  = 0;

  for (j = 0; j < NumBytes; j++)               //   for all pixels in line
  {
     Datum   = *DataBlk++;                //     get either 2 or 1 datum(s)
     *pTemp++ = HexTable[((BYTE)(Datum >> 4)) & 0x0f];
     *pTemp++ = HexTable[((BYTE)Datum) & 0x0f];
     Length += 2;

     if( Length >= 0x40 )   // End of the line reached
     {
       lstrcpy( (LPSTR)pTemp, (LPSTR)strCRLF);
       Length += CRLFLength;
       PortWrite(lppd, ptrString, Length); // Write to the Port

       // Reset local buffer pointer and counter
       pTemp = ptrString ;
       Length = 0;
     }
  }

  PortWrite(lppd, ptrString, Length); // Write to the Port

  if( Length != 0 )  // No CRLF was issued recently
      PortWrite(lppd,(LPSTR) strCRLF, CRLFLength); // Write to the Port

}

/*****************************************************************************
*
*                         PSSendHexColorAscii7
*
* Function: This function outputs a hex number
*
* Called:   short FAR PASCAL PSSendHexColorAscii7(LPPDEVICE lppd, DWORD Num)
*
* Parameters:   LPPDEVICE  lppd     The device context 
*               DWORD      Num      The number to output.
* 
* Returns:  short   PS_RC_ok      All went according to plan
*
*****************************************************************************/

short FAR PASCAL PSSendHexColorAscii7(LPPDEVICE lppd, DWORD Num)
{
   CHAR  NumString[20];                          
   int   Length;                                 
   
   // If supplied color is in CMYK format - send 4 bytes, otherwise -
   //   send 3 bytes.
   //   Added to support ICM 
   //   05-Jan-94  -by-  [olegs]
   if( lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT )
   {
      Length = wsprintf(NumString,"%8.8lX ", Num); // Convert Num to Hex
   }else
   {
      Length = wsprintf(NumString,"%6.6lX ", (Num & 0x00FFFFFFL));  // Convert Num to Hex
   }
   PortWrite(lppd,NumString,Length);       // Write to the Port
   
   return(RC_ok);                                
}


char gzTrue[]="true ";
char gzFalse[]="false ";

/*****************************************************************************
*
*                 PSSendBooleanAscii7
*
* Function: This function outputs a boolean value in ascii7 encoding to the port
*
* Called:   short FAR PASCAL PSSendBooleanAscii7(LPPDEVICE lppd, FLAG flag)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               FLAG       flag     The boolean value to output (TRUE or FALSE).
* 
* Returns:  short   PS_RC_ok   
*
*****************************************************************************/

short FAR PASCAL PSSendBooleanAscii7(LPPDEVICE lppd, FLAG flag)
{
     LPSTR lpz;
     short sLen;

     if(flag) lpz=(LPSTR)gzTrue;
     else lpz=(LPSTR)gzFalse;

     sLen = lstrlen(lpz);
     PortWrite(lppd,lpz,sLen);

     return(RC_ok);
}

/*****************************************************************************
*
*                 PSSendBooleanBinary
*
* Function: This function outputs a binary boolean value to the port.
*
* Called:   short FAR PASCAL PSSendBooleanBinary(LPPDEVICE lppd, FLAG flag
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               FLAG       flag     The boolean value to output (TRUE or FALSE).
* 
* Returns:  short   PS_RC_ok      All went according to plan
*
*****************************************************************************/

short FAR PASCAL PSSendBooleanBinary(LPPDEVICE lppd, FLAG flag)
{
  BYTE  BinaryData[2];     
  WORD  Number;            
  BYTE  Token      = 0x8d; 
  BYTE  Zero       = 0;    
  BYTE  One        = 1;    
  LPASCIIBINPTRS tempptr;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

  Number = 1;
  if(flag)
     Number = (*tempptr->ConvertToBinary)((LPBYTE)&One,(LPBYTE)&BinaryData,Number);
  else
     Number = (*tempptr->ConvertToBinary)((LPBYTE)&Zero,(LPBYTE)&BinaryData,Number);

  PortWrite(lppd,(LP)&Token,(WORD)1);
  PortWrite(lppd,(LP)&BinaryData,(WORD)Number);

  return(RC_ok);
}

/**********************************************************************
*                       PSSendCTM
*
*  Function:   sends a "Current Transformation Matrix" out
*
*  Called:     short FAR PASCAL PSSendCTM(LPPDEVICE lppd, LPPSMATRIX lpCTM)
*
*  Parameters:   LPPDEVICE  lppd  -- pdevice pointer
*                LPPSMATRIX lpCTM -- pointer to the CTM matrix structure
*
*  Returns:    RC_ok -- always
*
**********************************************************************/

short FAR PASCAL PSSendCTM(LPPDEVICE lppd, LPPSMATRIX lpCTM)
{
   register short i;
   FLAG           fMDiff;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   fMDiff = TRUE;
   for(i = 0; i < 6 && fMDiff; i++)
   {
     fMDiff = (lpCTM[ i ] == lppd->lpGSStack->lpgGState->jobCTM[ i ]) && fMDiff;
   }

   if( fMDiff == FALSE )
   {

     PSSendFragment(lppd,PSFRAG_slash);              
     PSSendFragment(lppd,PSFRAG_mysetup);            
     PSSendFragment(lppd,PSFRAG_leftbracket);        
     for(i=0;i<6;i++)
     {
        (*tempptr->PSSendEx6Float)(lppd,lpCTM[i]);
        lppd->lpGSStack->lpgGState->jobCTM[ i ] = lpCTM[ i ];
     }
     PSSendFragment(lppd,PSFRAG_rightbracket);
     (*tempptr->PSSendBasic)(lppd,PSOP_def);
     (*tempptr->PSSendCRLF)(lppd);
   }
   return(RC_ok);
}

/*****************************************************************************
*
*                 PSSendBoxAscii7
*
* Function: This function outputs a rectangle in ascii7 encoding to the port
*
* Called:   short FAR PASCAL PSSendBox(LPPDEVICE lppd, FLAG flag)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               LPRECT     lpRect     The rectangle to be output 
* 
* Returns:  short   PS_RC_ok   
*
*****************************************************************************/

short FAR PASCAL PSSendBBoxAscii7(LPPDEVICE lppd, LPRECT lpRect, 
                                  LPSTR lpOutBuff)
{
   char zTemp[8];
   short sLen;


#if  0

   -------- WRONG ---- WRONG ----- WRONG ------------------------------
   lppd->bbox   is ALWAYS in default PS coordinates
   this function does no coordinate transformations
   it simply sends the bbox as is.
   ---------- READ and UNDERSTAND all warning labels before use -------

   int tempnum;

   // The Rectangle passed can be in GDI units or already scaled to 
   //   default PS units. In the later case the bfESCSetBounds  flag is set.

   if (!lppd->job.bfESCSetBounds)
   {
    // If it is not EPS file - flip the bounding box so it will
    //   always be the same regardless of the orientation.
    // For EPS files ( because they are output in potrait orientation
    //   always), the bounding box should be equal to the imageable area.
    // Added 16-Jul-93  -by-  [olegs]
    if( ( lppd->lpPSExtDevmode->dm2.bOutputDialect != DIALECT_EPS) &&
   ( (lppd->lpPSExtDevmode->dm.dm.dmOrientation == DMORIENT_ROT_LANDSCAPE) ||
    (lppd->lpPSExtDevmode->dm.dm.dmOrientation == DMORIENT_LANDSCAPE)        
   )
     )
/*************************************************************************

****** FLOPRECT IS IN CUTILS.C & CUTILS.H******************************

    FlopRect( (LPDRVSTATE)&lppd->drvState, lpRect, lpRect);
**************************************************************************/

    // if imageable area straddles the negative axes, take the absolute values
    if (lpRect->top < 0)
    {
      lpRect->bottom = abs(lpRect->top) + lpRect->bottom;
      lpRect->top = 0;
    }
    if (lpRect->left < 0)
    {
      lpRect->right = abs(lpRect->left) + lpRect->right;
      lpRect->left = 0;
    }

    tempnum = lpRect->top;

    lpRect->left  = MulDiv(lpRect->left,  72,lppd->DeviceRes.x_res);
    lpRect->top   = MulDiv(lpRect->bottom,72,lppd->DeviceRes.y_res);
    lpRect->right = MulDiv(lpRect->right, 72,lppd->DeviceRes.x_res);
    lpRect->bottom= MulDiv(tempnum,       72,lppd->DeviceRes.y_res);
   }

#endif
   
   sLen=wsprintf((LPSTR)zTemp,(LPSTR)"%d ",lpRect->left);
//   PortWrite(lppd,(LP)zTemp,sLen);
   lstrcat(lpOutBuff,zTemp);

   sLen+=wsprintf((LPSTR)zTemp,(LPSTR)"%d ",lpRect->bottom);
//   PortWrite(lppd,(LP)zTemp,sLen);
   lstrcat(lpOutBuff,zTemp);

   sLen+=wsprintf((LPSTR)zTemp,(LPSTR)"%d ",lpRect->right);
//   PortWrite(lppd,(LP)zTemp,sLen);
   lstrcat(lpOutBuff,zTemp);

   sLen+=wsprintf((LPSTR)zTemp,(LPSTR)"%d ",lpRect->top);
//   PortWrite(lppd,(LP)zTemp,sLen);
   lstrcat(lpOutBuff,zTemp);

//   return(RC_ok);
  return(sLen);
}



short FAR PASCAL PSSendFragmentAscii7(LPPDEVICE lppd, WORD FragID)
{
  int NumBytes;
  char tempbuffer[STRINGBUFSIZE+1];

  NumBytes = LoadDrvrString(ghDriverMod,FragID,tempbuffer,STRINGBUFSIZE);
  PortWrite(lppd,tempbuffer,(WORD)NumBytes);
  return( (short)NumBytes );
}

short FAR PASCAL PSGetFragmentLength(LPPDEVICE lppd, WORD FragID)
{
  int NumBytes;
  char tempbuffer[STRINGBUFSIZE+1];

  NumBytes = LoadDrvrString(ghDriverMod,FragID,tempbuffer,STRINGBUFSIZE);
  return( (short)NumBytes );
}


/**********************************************************************
*                       PSSendBasicAscii7
*
*  Function:  Send a PostScript operator in ASCII7 format
*
*  Called:     short FAR PASCAL PSSendBasicAscii7(LPPDEVICE lppd, short sOpid
*
*  Parameters:   LPPDEVICE  lppd  -- pdevice pointer
*                short      sOpid -- the PS operator id
*
*  Returns:    RC_ok -- always
*
**********************************************************************/

short FAR PASCAL PSSendBasicAscii7(LPPDEVICE lppd, short sOpid)
    {
    WORD len;

    //send the PostScript operator, if it is in range...
    //arguments can be sent without an operator, in the event
    //there are repetitive arguments to an operator.
    //
    //LATER: if all is well, this conditional should not be necessary
    //
    if((sOpid >= MIN_PSOP ) && (sOpid <= MAX_PSOP))
     {
     len = lstrlen(gPSop[sOpid].lpzName);
     PortWrite(lppd,gPSop[sOpid].lpzName,len);
     }
//  return(RC_ok);
    return(len);
    }


/**********************************************************************
*                       PSSendBasicBinary
*
*  Function:  Send a PostScript operator in binary
*
*  Called:     short FAR PASCAL PSSendBasicBinary(LPPDEVICE lppd, short sOpid
*
*  Parameters:   LPPDEVICE  lppd  -- pdevice pointer
*                short      sOpid -- PS operator id
*
*  Returns:    RC_ok -- always
*
**********************************************************************/

short FAR PASCAL PSSendBasicBinary(LPPDEVICE lppd, short sOpid)
{
  WORD BinaryData[2];
  WORD BinaryOperator;
  WORD Number;
  LPASCIIBINPTRS tempptr;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

  //send the PostScript operator, if it is in range...

  if((sOpid >= MIN_PSOP ) && (sOpid <= MAX_PSOP))
  {
     BinaryOperator = gPSop[sOpid].BinCode;
     Number = 2;
     Number = (*tempptr->ConvertToBinary)((LPBYTE)&BinaryOperator,(LPBYTE)&BinaryData,Number);
     PortWrite(lppd,(LP)&BinaryData,Number);
  }
//  return(RC_ok);
  return(Number);
}

/**********************************************************************
*                       PSSendCRLFAscii7
*
*  Function:  Send a Carriage Return,Linefeed in ASCII7 format
*
*  Called:     short FAR PASCAL PSSendCRLFAscii7(LPPDEVICE lppd)
*
*  Parameters:   LPPDEVICE  lppd  -- pdevice pointer
*
*  Returns:    RC_ok -- always
*
**********************************************************************/

short FAR PASCAL PSSendCRLFAscii7(LPPDEVICE lppd)
{
  PSSendFragment(lppd,PSFRAG_crlf);
  return(RC_ok);
}


/**********************************************************************
*                       PSSendCRLFBinary
*
*  Function:  Send a Carriage Return,Linefeed in binary format
*
*  Called:     short FAR PASCAL PSSendCRLFBinary(LPPDEVICE lppd)
*
*  Parameters:   LPPDEVICE  lppd  -- pdevice pointer
*
*  Returns:    RC_ok -- always
*
**********************************************************************/

short FAR PASCAL PSSendCRLFBinary(LPPDEVICE lppd)
{
  PSSendFragment(lppd,PSFRAG_crlf);
  return(RC_ok);
}


/**********************************************************************
*                       PSSendShortBinary
*
*  Function:  Send a short number in binary format
*
*  Called:     short FAR PASCAL PSSendShortBinary(LPPDEVICE lppd)
*
*  Parameters:   LPPDEVICE  lppd  -- pdevice pointer
*                short      sNum
*
*  Returns:    RC_ok -- always
*
**********************************************************************/

short FAR PASCAL PSSendShortBinary(LPPDEVICE lppd, short sNum)
{
  BYTE  Token = 0x87;
  BYTE  BinaryData[4];
  BYTE  Byte[2];
  WORD  Number;
  LPASCIIBINPTRS tempptr;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

  Byte[LOW ]  =  (BYTE) (sNum & 0x00FF);
  Byte[HIGH]  =  (BYTE)((sNum & 0xFF00) >> 8);
  Number      =  2;

  Number = (*tempptr->ConvertToBinary)((LPBYTE)Byte,(LPBYTE)&BinaryData,Number);
  PortWrite(lppd,(LP)&Token,(WORD)1);
  PortWrite(lppd,(LP)&BinaryData,(WORD)Number);

//  return(RC_ok);
  return(Number);
}


/*****************************************************************************
*
*                 PSSendFloatBinary
*
* Function: This function outputs a floating point number to the port.
*
* Called:   short FAR PASCAL PSSendFloatBinary(LPPDEVICE lppd, float num)
*
* Parameters:   LPPDEVICE  lppd     The device context 
*               float      num      The number to output.
* 
* Returns:  short   String length  
*
*****************************************************************************/

short FAR PASCAL PSSendFloatBinary(LPPDEVICE lppd, float Num)
{
typedef  union
 {  float FloatIn;
    DWORD DwordOut;
 } NUMBER;

  NUMBER Value;
  DWORD  IEEEValue;
  BYTE   Token    = 0x8b;
  BYTE   BinaryData[8];  
  BYTE   Byte[4];
  WORD   Number;
  LPASCIIBINPTRS tempptr;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

  Value.FloatIn = Num;
  IEEEValue     = Value.DwordOut;

  Byte[0 ]  =  (BYTE)( IEEEValue & 0x000000FF);
  Byte[1 ]  =  (BYTE)((IEEEValue & 0x0000FF00) >>  8);
  Byte[2 ]  =  (BYTE)((IEEEValue & 0x00FF0000) >> 16);
  Byte[3 ]  =  (BYTE)((IEEEValue & 0xFF000000) >> 24);

  Number    =  4;
  Number = (*tempptr->ConvertToBinary)((LPBYTE)Byte,(LPBYTE)&BinaryData,Number);
  PortWrite(lppd,(LP)&Token,(WORD)1);
  PortWrite(lppd,(LP)&BinaryData,(WORD)Number);

  return( Number );
}

/*****************************************************************************
*
*                 PSSendDSCAscii7
*
* Function: This function outputs a DSC comment to the port in ASCII7 format
*
* Called:   short FAR PASCAL PSSendDSCAscii7(LPPDEVICE lppd, short sDSCid, LPSTR pInfoString)
*
* Parameters:   LPPDEVICE  lppd     The device context 
*               short      sDSCid
*               LPSTR      pInfoString 
* 
* Returns:  short   PS_RC_ok  
*
*****************************************************************************/

short FAR PASCAL PSSendDSCAscii7(LPPDEVICE lppd, short sDSCid, LPSTR pInfoString )
{
  char zTemp[64];
  LPSTR lpzTemp=(LPSTR)zTemp;
  LPASCIIBINPTRS tempptr;
  DWORD dwPSIndex = 0;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

  //first send the basic comment
  //
  if(sDSCid<=DSC_begin || sDSCid>=DSC_end) return(RC_fail);
  if (!lppd->GlobalBuffer.lpStringAscii7)
      return RC_fail;

  if(sDSCid>DSC_null)
  {
//   LoadDrvrString(ghDriverMod,sDSCid,lpzTemp,sizeof(zTemp));
//   PortWrite(lppd,lpzTemp,lstrlen(lpzTemp));
          LoadDrvrString(ghDriverMod,sDSCid,
                         lppd->GlobalBuffer.lpStringAscii7,64);
  }

  // Send the information string if there is one.
  if( pInfoString != NULL )
  {
//      PortWrite(lppd, pInfoString, lstrlen( pInfoString ));
      lstrcat(lppd->GlobalBuffer.lpStringAscii7, pInfoString);
  }
//  (*tempptr->PSSendCRLF)(lppd);

// OEMPLUGI begin
    /* Map the correct index */
    switch (sDSCid)
      {
      case DSC_adobe:
        dwPSIndex = PS_INDEX_PS_ADOBE;
        break;
      case DSC_title:
        dwPSIndex = PS_INDEX_TITLE;
        break;
      case DSC_creator:
        dwPSIndex = PS_INDEX_CREATOR;
        break;
      case DSC_date:
        dwPSIndex = PS_INDEX_CREATION_DATE;
        break;
      case DSC_for:
        dwPSIndex = PS_INDEX_USER;
        break;
      case DSC_pages:
        dwPSIndex = PS_INDEX_PAGES_NUMBER;
        break;
      case DSC_pages_atend:
        dwPSIndex = PS_INDEX_PAGES_AT_END;
        break;
      case DSC_pageorder:
        dwPSIndex = PS_INDEX_PAGE_ORDER;
        break;
/*      case DSC_requirements:
        dwPSIndex = PS_INDEX_REQUIREMENTS;  //no longer use in DSC 3.1
        break;
*/
      case DSC_plus_font:
        dwPSIndex = PS_INDEX_PLUS_FONT;
        break;
// map to DSC 3.1 comments  for now
      case DSC_docneedresfont:
        if (lstrcmp(pInfoString,"(atend)") == 0)            
          dwPSIndex = PS_INDEX_DOCUMENT_NEEDED_RESOURCES_AT_END;
        else
          dwPSIndex = PS_INDEX_DOCUMENT_NEEDED_RESOURCES;
        break;
      case DSC_docsuppresfont:
        if (lstrcmp(pInfoString,"(atend)") == 0)
          dwPSIndex = PS_INDEX_DOCUMENT_SUPPLIED_RESOURCES_AT_END;
        else
          dwPSIndex = PS_INDEX_DOCUMENT_SUPPLIED_RESOURCES;
        break;
//
      case DSC_documentdata:
        dwPSIndex = PS_INDEX_DOCUMENT_DATA;
        break;
      case DSC_languagelevel:
        dwPSIndex = PS_INDEX_LANGUAGE_LEVEL;
        break;
      case DSC_endcomments:
        dwPSIndex = PS_INDEX_END_COMMENTS;
        break;
      case DSC_beginprolog:
        dwPSIndex = PS_INDEX_BEGIN_PROLOG;
        break;
      case DSC_endprolog:
        dwPSIndex = PS_INDEX_END_PROLOG;
        break;
// map to DSC 3.1 comments  for now
      case DSC_beginprocset:
//        dwPSIndex = PS_INDEX_PROCSET;   old 
        dwPSIndex = PS_INDEX_BEGIN_RESOURCES;    // map to PS_INDEX_BEGIN_RESOURCE
        break;
      case DSC_beginsetup:
        dwPSIndex = PS_INDEX_BEGIN_SETUP;
        break;
      case DSC_endsetup:
        dwPSIndex = PS_INDEX_END_SETUP;
        break;
      case DSC_page:
        dwPSIndex = PS_INDEX_PAGE_NUMBER;
        break;
      case DSC_beginpagesetup:
        dwPSIndex = PS_INDEX_BEGIN_PAGE_SETUP;
        break;
      case DSC_endpagesetup:
        dwPSIndex = PS_INDEX_END_PAGE_SETUP;
        break;
      case DSC_pagetrailer:
        dwPSIndex = PS_INDEX_PAGE_TRAILER;
        break;
      case DSC_trailer:
        dwPSIndex = PS_INDEX_TRAILER;
        break;
      case DSC_eof:
        dwPSIndex = PS_INDEX_EOF;
        break;
// map to DSC 3.1 comments  for now
      case DSC_beginfont:
        dwPSIndex = PS_INDEX_BEGIN_RESOURCES;
        break;
      case DSC_endfont:
        dwPSIndex = PS_INDEX_END_RESOURCES;
        break;
      case DSC_includeresfont:
        dwPSIndex = PS_INDEX_INCLUDE_RESOURCES;
        break;
// map to DSC 3.1 comments  for now
      case DSC_begindocument:
        dwPSIndex = PS_INDEX_BEGINUNCOUNTEDDATA;
        break;
      case DSC_enddocument:
        dwPSIndex = PS_INDEX_ENDUNCOUNTEDDATA;
        break;
// map to DSC 3.1 comments  for now
      case DSC_includeprocset:
        dwPSIndex = PS_INDEX_INCLUDE_RESOURCES;
        break;
      case DSC_viewingorientation:
        dwPSIndex = PS_INDEX_VIEWING_ORIENTATION;
        break;
      case DSC_begindefaults:
        dwPSIndex = PS_INDEX_BEGIN_DEFAULTS;
        break;
      case DSC_enddefaults:
        dwPSIndex = PS_INDEX_END_DEFAULTS;
        break;
      case DSC_docneededres:
        if (lstrcmp(pInfoString,"(atend)") == 0)            
           dwPSIndex = PS_INDEX_DOCUMENT_NEEDED_RESOURCES_AT_END;
        else
           dwPSIndex = PS_INDEX_DOCUMENT_NEEDED_RESOURCES;
        break;
      case DSC_docsuppliedres:
        if (lstrcmp(pInfoString,"(atend)") == 0)            
           dwPSIndex = PS_INDEX_DOCUMENT_SUPPLIED_RESOURCES_AT_END;
        else
           dwPSIndex = PS_INDEX_DOCUMENT_SUPPLIED_RESOURCES;
        break;
      case DSC_includeres:
        dwPSIndex = PS_INDEX_INCLUDE_RESOURCES;
        break;
      case DSC_pagebbox:
        dwPSIndex = PS_INDEX_PAGE_BOUNDINGBOX;
        break;
       case DSC_beginuncounteddata:
        dwPSIndex = PS_INDEX_BEGINUNCOUNTEDDATA;
        break;
      case DSC_enduncounteddata:
        dwPSIndex = PS_INDEX_ENDUNCOUNTEDDATA;
        break;

      case DSC_beginresource:
        dwPSIndex = PS_INDEX_BEGIN_RESOURCES;
        break;
      case DSC_endresource:
        dwPSIndex = PS_INDEX_END_RESOURCES;     
        break;
      case DSC_platecolor:
        dwPSIndex = PS_INDEX_PLATECOLOR;     
        break;
      case DSC_documentprocesscolors:
        dwPSIndex = PS_INDEX_DOCUMENTPROCESSCOLORS;     
        break;
      case DSC_documentprocesscolorsatend:
        dwPSIndex = PS_INDEX_DOCUMENTPROCESSCOLORSATEND;     
        break;

      default:
        dwPSIndex = 0L;
        break;
      }

  AdobeOEMSendPSStub(lppd, dwPSIndex,
                    lppd->GlobalBuffer.lpStringAscii7,
                    lstrlen(lppd->GlobalBuffer.lpStringAscii7));
// OEMPLUGI end

  (*tempptr->PSSendCRLF)(lppd);

  return(RC_ok);
}


/*****************************************************************************
*
*                 PSSendDSCBinary
*
* Function: This function does nothing
*
* Called:   short FAR PASCAL PSSendDSCBinary(LPPDEVICE lppd, short sDSCid, LPSTR pInfoString)
*
* Parameters:   LPPDEVICE  lppd     The device context 
*               short      sDSCid
*               LPSTR      pInfoString 
* 
* Returns:  short   PS_RC_ok  
*
*****************************************************************************/

short FAR PASCAL PSSendDSCBinary(LPPDEVICE lppd, short sDSCid, LPSTR pInfoString )
{
  return(RC_ok);
}

/*****************************************************************************
*
*                 PSSendBoxDSCAscii7
*
* Function: This function outputs a rectangle in ascii7 encoding,
*           preceded by a DSC comment, to the port
*
* Called:   short FAR PASCAL PSSendBoxDSCAscii7(LPPDEVICE lppd, FLAG flag)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               short      sDSCid   id f DSC comment
*               LPRECT     lpRect   The rectangle to be output 
* 
* Returns:  short   PS_RC_ok   
*
*****************************************************************************/

short FAR PASCAL PSSendBoxDSCAscii7(LPPDEVICE lppd, short sDSCid, LPRECT pRect )
{
  CHAR zTemp[128];
  int length;
  LPSTR lpzTemp=(LPSTR)zTemp;
  LPASCIIBINPTRS tempptr;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
  //first send the basic comment
  //
  if(sDSCid<=DSC_begin || sDSCid>=DSC_end) return(RC_fail);
  if(sDSCid>DSC_null)
  {
     LoadDrvrString(ghDriverMod,sDSCid,lpzTemp,sizeof(zTemp));
//   PortWrite(lppd,lpzTemp,lstrlen(lpzTemp));
  }

  // Send the rectangle.
  PSSendBBox(lppd,pRect, zTemp);
  length = lstrlen(zTemp);
  LoadDrvrString(ghDriverMod, PSFRAG_crlf, zTemp+length, 128-length);
  length += 2;

  AdobeOEMSendPSStub(lppd, PS_INDEX_BOUNDING_BOX,
                     zTemp, length);
  return(RC_ok);
}

/*****************************************************************************
*
*                 PSSendBoxDSCBinary
*
* Function: This function outputs a rectangle in ascii7 encoding,
*           preceded by a DSC comment, to the port
*
* Called:   short FAR PASCAL PSSendBoxDSCBinary(LPPDEVICE lppd, FLAG flag)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               short      sDSCid
*               LPRECT     lpRect     The rectangle to be output 
* 
* Returns:  short   PS_RC_ok   
*
*****************************************************************************/

short FAR PASCAL PSSendDSCBBoxBinary(LPPDEVICE lppd, short sDSCid, LPRECT pRect )
{
  return(RC_ok);
}


/*****************************************************************************
*
*                 PSSendColor
*
* Function: This function outputs a color 
*
* Called:   short FAR PASCAL PSSendColor(LPPDEVICE lppd, DWORD dColor)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               DWORD      dcolor   The RGB color value
* 
* Returns: fGray
*
*****************************************************************************/

FLAG FAR PASCAL PSSendColor(LPPDEVICE lppd, DWORD dColor)
{
   float RedValue, GreenValue, BlueValue, BlackValue;
   RGBQUAD    Color;
   RGBQUAD    NewColor;
   BYTE  Red, Green, Blue, Black;
   LPASCIIBINPTRS tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   TICMColor(lppd, lppd->graphics.hCMTransform );

// This is NOT a typo - in order to call ICMTranslateRGB the
//   Color components must be in order of COLORREF, which is RGBK,
//  while RGBQUAD bytes go in order BGRK.
//  The ICMTranslateRGB returns colors in KYMC order.
//  Changed  08-Jan-95  -by-  [olegsher]
   Color.rgbBlue = Red   = GetRValue(dColor);
   Color.rgbGreen = Green = GetGValue(dColor);
   Color.rgbRed = Blue  = GetBValue(dColor);
   Color.rgbReserved = Black = (BYTE) (dColor>>24) ;
   // Added ICM support
   //    11-Jan-1994   -by-      [olegs]
   if( lppd->lpGSStack->lpgGState->bColorMode & CM_USE_ICM )
   {
       // ALWAYS_ICM
       // If ICM is on, interpret what is coming in as CMYK color
       // (K is LSB, C is MSB)
       // 

       #if 0
       if( lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT )
       {
           BYTE temp;

           temp = Red; Red = Black; Black = temp;
           temp = Green; Green = Blue; Blue = temp;
       }
       #else
       BOOL       bRet;
       LPICMINFO  lpICMI =
            (LPICMINFO) GlobalLock( (HANDLE) lppd->graphics.hCMTransform);
       bRet   = ICMTranslateRGB(lpICMI->hICMT,
                                 Color, (LPVOID) &NewColor, CMS_FORWARD) ;
       GlobalUnlock((HANDLE) lppd->graphics.hCMTransform);
      // the kodak icm gives CMYK in the opposite order the PS likes it

      if (lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT )
      {
          Red   = NewColor.rgbReserved ;
          Green = NewColor.rgbRed ;
          Blue  = NewColor.rgbGreen ;
          Black = NewColor.rgbBlue ;

          // If output should be in RGB - convert CMYK -> RGB
          // Added  13-Feb-1995  -by-  [olegsher]
          /*
          if( !(lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT ))
          {
              Red   = 255 - min(255, Red + Black);
              Green = 255 - min(255, Green + Black);
              Blue  = 255 - min(255, Blue + Black);
          }
          */
      }
      else
      {
          Red   = NewColor.rgbBlue ;
          Green = NewColor.rgbGreen ;
          Blue  = NewColor.rgbRed ;
      }
      #endif
   }
   RedValue   = (float)(Red      /255.0);
   GreenValue = (float)(Green    /255.0);
   BlueValue  = (float)(Blue     /255.0);

   (*tempptr->PSSendFloat)(lppd,RedValue);
   (*tempptr->PSSendFloat)(lppd,GreenValue);
   (*tempptr->PSSendFloat)(lppd,BlueValue);
   if( lppd->lpGSStack->lpgGState->bColorMode & CM_CMYK_OUT )
   {
       BlackValue = (float)(Black /255.0);
      (*tempptr->PSSendFloat)(lppd,BlackValue);
   }
   lppd->lpGSStack->lpgGState->dColor = dColor;
   return(FALSE);
}

/*****************************************************************************
*
*         PSSendRGBColor
*
* Function: This function outputs an absolute RGB color, no ICM applied
*
* Called:   short FAR PASCAL PSSendRGBColor(LPPDEVICE lppd, DWORD dColor)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               DWORD      dcolor   The RGB color value
* 
* Returns: fGray
*
*****************************************************************************/

FLAG FAR PASCAL PSSendRGBColor(LPPDEVICE lppd, DWORD dColor)
{
   float RedValue, GreenValue, BlueValue;
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   RedValue   = (float)(GetRValue(dColor)    /255.0);
   GreenValue = (float)(GetGValue(dColor)    /255.0);
   BlueValue  = (float)(GetBValue(dColor)    /255.0);
   
   (*tempptr->PSSendFloat)(lppd,RedValue);
   (*tempptr->PSSendFloat)(lppd,GreenValue);
   (*tempptr->PSSendFloat)(lppd,BlueValue);
   return(FALSE);
}

/*****************************************************************************
*
*                 PSSendColorOp
*
* Function: This function outputs a color operator
*
* Called:   short FAR PASCAL PSSendColorOp(LPPDEVICE lppd, FLAG fGray)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               FLAG       fGray
* 
* Returns: Nothing
*
*****************************************************************************/

void FAR PASCAL PSSendColorOP(LPPDEVICE lppd, FLAG fGray)
{
  LPASCIIBINPTRS tempptr;
// Removed gray color emittance - no need for that.
  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
  PSSendFragment(lppd,PSFRAG_setcolor);       // RGB or CMYK color
}

/*****************************************************************************
*
*         PSSendRGBColorOp  dnw
*
* Function: This function outputs a color operator
*
* Called:   short FAR PASCAL PSSendRGBColorOp(LPPDEVICE lppd, FLAG fGray)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               FLAG       fGray
* 
* Returns: Nothing
*
*****************************************************************************/

void FAR PASCAL PSSendRGBColorOP(LPPDEVICE lppd, FLAG fGray)
{
  LPASCIIBINPTRS tempptr;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
  PSSendFragment(lppd,PSFRAG_setrgbcolor);  // RGB color
}

/*****************************************************************************
*
*                 PSSendBGHatch
*
* Function: This function outputs the background hatch or bitmap pattern
*
* Called:   short FAR PASCAL PSSendBGHatch(LPPDEVICE lppd, DWORD dColor, short FillOp)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               DWORD      dColor
*               short      FillOp 
*
* Returns: fGray
*
*****************************************************************************/

FLAG FAR PASCAL PSSendBGHatch(LPPDEVICE lppd, DWORD dColor, short FillOp)
{
   FLAG  fGray;                                   
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   PSSendGSave(lppd);                    // Save the graphics state

   fGray=PSSendColor(lppd,dColor);       // Send gray -or- r g b
   PSSendColorOP(lppd,fGray);            // Send  sg  -or-  sco

   (*tempptr->PSSendBasic)(lppd,FillOp); // FillOp = eofill,fill,stroke

   PSSendGRestore(lppd);                 // Restore the graphics state
   return(fGray);
}

/*****************************************************************************
*
*                 PSSendFGHatch
*
* Function: This function outputs the foreground hatch or bitmap pattern
*
* Called:   short FAR PASCAL PSSendFGHatch(LPPDEVICE lppd, DWORD dColor, int iPat)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               DWORD      dColor
*               int        iPat 
*
* Returns: fGray
*
*****************************************************************************/

FLAG FAR PASCAL PSSendFGHatch(LPPDEVICE lppd, DWORD dColor, int iPat)
{
   FLAG fGray;
   char String[20];
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
      
   fGray = PSSendColor(lppd,dColor);       // Send gray -or- r g b

   wsprintf(String,"PatternOfTheDay%d ",iPat);
   PSSendString(lppd,String);              // Send "PatternOfTheDayN "
 
   (*tempptr->PSSendBoolean)(lppd,fGray);  // Send fGray 
   return(fGray);
}

/*****************************************************************************
*
*                 PSSendPatBrush
*
* Function: This function outputs new pattern brush
*
* Called:   int FAR PASCAL PSSendPatBrush(LPPDEVICE lppd)
*
* Parameters: LPPDEVICE  lppd      The device context to output to.
*
* Returns: pattern number
*
*****************************************************************************/

int FAR PASCAL PSSendPatBrush(LPPDEVICE lppd)
{
   int   i, iPat = -1;                                      
   char  String[20];                             
   LPASCIIBINPTRS tempptr;
   LPPATBRUSHINFO lpPBInfo = lppd->lpPatBrushInfo;
   char *h[] = {"h0 ","h1 ","h2 ","h3 ","h4 ","h5 "};

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   
   for (i=0; i<MAXPATTERN && iPat==-1; i++)
   {
      if (lppd->brush.bStyle == lpPBInfo->brush[i].bStyle)
      {
         if (lppd->brush.bStyle==BRUSHSTYLE_hatched)
         {
            if (lppd->brush.bHatch == lpPBInfo->brush[i].pattern[0]) 
               iPat = i;
         }
         else
         {   LPDWORD PDevicePat0_3,BrushPat0_3;
             LPDWORD PDevicePat4_7,BrushPat4_7;
             BrushPat0_3 = (DWORD FAR *) &(lpPBInfo->brush[i].pattern[0]);
             BrushPat4_7 = (DWORD FAR *) &(lpPBInfo->brush[i].pattern[4]);
             PDevicePat0_3 = (DWORD FAR *) &(lppd->brush.pattern[0]);
             PDevicePat4_7 = (DWORD FAR *) &(lppd->brush.pattern[4]);
             if((*BrushPat0_3==*PDevicePat0_3) && (*BrushPat4_7==*PDevicePat4_7))
                iPat = i;
         }             
      }    
   }
   if (iPat == -1)
   {   
      iPat = lpPBInfo->bBrushIndex++;
      lpPBInfo->brush[iPat].savelevel = lppd->lpProcsetstuff->savelevel;
      lpPBInfo->brush[iPat].bStyle = lppd->brush.bStyle;
      if (lppd->brush.bStyle == BRUSHSTYLE_hatched)
         lpPBInfo->brush[iPat].pattern[0] = lppd->brush.bHatch;
      else if (lppd->brush.bStyle == BRUSHSTYLE_pattern)
      {  
         lpPBInfo->brush[iPat].pattern[0] = lppd->brush.pattern[0];          
         lpPBInfo->brush[iPat].pattern[1] = lppd->brush.pattern[1];          
         lpPBInfo->brush[iPat].pattern[2] = lppd->brush.pattern[2];          
         lpPBInfo->brush[iPat].pattern[3] = lppd->brush.pattern[3];          
         lpPBInfo->brush[iPat].pattern[4] = lppd->brush.pattern[4];          
         lpPBInfo->brush[iPat].pattern[5] = lppd->brush.pattern[5];          
         lpPBInfo->brush[iPat].pattern[6] = lppd->brush.pattern[6];          
         lpPBInfo->brush[iPat].pattern[7] = lppd->brush.pattern[7];          
      }      
      if (lpPBInfo->bBrushIndex == MAXPATTERN)
         lpPBInfo->bBrushIndex = 0;
          
      wsprintf(String,"/PatternOfTheDay%d ",iPat);
      PSSendString(lppd,String);                      // Send "PatternOfTheDayN "

      if (lppd->brush.bStyle == BRUSHSTYLE_hatched)
      {
         // This change is to accomodate a bug in WORD doc, it send out
         // hatched brush with bHatch = 0x3F, actually it is a pattern brush
         // So, we check in here, just give a default value to avoid
         // PostScript error. bug # 267219
 
         if (lppd->brush.bHatch > 5)
              lppd->brush.bHatch = 0;   // backword diagonal as default
         PSSendString(lppd,h[lppd->brush.bHatch]);    // Send hn    where n=0,1,2..5
      } 
      else
      {                           
         PSSendFragment(lppd,PSFRAG_leftcaret);       // Send "<"
         for(i=0;i<8;i++)                             // Send hex pattern
         {
            wsprintf(String,"%2.2X",lppd->brush.pattern[i]);
            PSSendString(lppd,String);
         }
         PSSendFragment(lppd,PSFRAG_rightcaret);      // Send ">"
         PSSendString(lppd,"pfprep ");                // Send "pfprep"
      }   
      (*tempptr->PSSendCRLF)(lppd);
  }
  return( iPat );
}

/*****************************************************************************
*
*                 PSSendBrush
*
* Function: This function outputs the brush pattern
*
* Called:   short FAR PASCAL PSSendBrush(LPPDEVICE lppd,short FillOp,LPSTR HatchOp,
*                                                     LPSTR PatternOp)
*
* Parameters:   LPPDEVICE  lppd      The device context to output to.
*               short      FillOp
*               LPSTR      HatchOp
*                    LPSTR      PatternOp
*
* Returns: RC_ok
*
*****************************************************************************/

short FAR PASCAL PSSendBrush(LPPDEVICE lppd, short FillOp,LPSTR HatchOp,
               LPSTR PatternOp)
{
   DWORD Color;                                  
   int   iPat = -1;                                      
   FLAG  fGray;                                  
   LPASCIIBINPTRS tempptr;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
   lppd->lpGSStack->lpgGState->bBrushStyle=lppd->brush.bStyle;

   // if the new pattern brush is selected, check if we have already 
   //    created it. If not, create it and save it.
   if ((lppd->brush.bStyle==BRUSHSTYLE_hatched) || 
       (lppd->brush.bStyle==BRUSHSTYLE_pattern))
      iPat = PSSendPatBrush(lppd);

   switch(lppd->lpGSStack->lpgGState->bBrushStyle)
   {
     case BRUSHSTYLE_solid  :
        Color = lppd->brush.dFGColor;
        // Performance improvement.  jjia   6/4/96
        if ((Color != lppd->lpGSStack->lpgGState->dColor) ||
            (lppd->lpGSStack->lpgGState->bColorSpaceChanged))
        {
           fGray = PSSendColor(lppd,Color);     // Send gray -or- r g b
           PSSendColorOP(lppd,fGray);           // Send  sg  -or-  sco
           lppd->lpGSStack->lpgGState->bColorSpaceChanged = FALSE;
        }
        break;                                  

     case BRUSHSTYLE_hatched:
        lppd->lpGSStack->lpgGState->bBrushHatch =
               lppd->brush.bHatch;              // Save the state

        if(lppd->graphics.bBackgroundMode==OPAQUE)
        {
           Color = lppd->brush.dBGColor;        
           PSSendBGHatch(lppd,Color,FillOp);    // FillOp = eofill,fill,stroke
        }
        Color = lppd->brush.dFGColor;           // Foreground color
        PSSendFGHatch(lppd,Color,iPat);

        PSSendString(lppd,HatchOp);             // HatchOp = "hf","hs"
        (*tempptr->PSSendCRLF)(lppd);
        break;                                  

     case BRUSHSTYLE_pattern:
        Color = lppd->brush.dBGColor;           // Background color
        PSSendBGHatch(lppd,Color,FillOp);       // FillOp = eofill,fill,stroke

        Color = lppd->brush.dFGColor;           // Foreground color
        PSSendFGHatch(lppd,Color,iPat);

        PSSendString(lppd,PatternOp);           // PatternOp = "pf","ps"
        (*tempptr->PSSendCRLF)(lppd);
        break;                                  
   }

   return(RC_ok);                                
}

/*****************************************************************************
*
*                 PSSendPenWidth
*
* Function: This function outputs the pen width
*
* Called:   short FAR PASCAL PSSendPenWidth(LPPDEVICE lppd, POINT inpen)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               POINT      inpen
*
* Returns: Nothing
*
*****************************************************************************/

VOID FAR PASCAL PSSendPenWidth(LPPDEVICE lppd, POINT inpen)
{
  short penwide;
  LPASCIIBINPTRS tempptr;
  short spread;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
  if ( inpen.x == -1)
     inpen.x = 1;

  if ( inpen.y == -1)
     inpen.y = 1;

  if ((inpen.x != lppd->lpGSStack->lpgGState->ptPen.x) ||
      (inpen.y != lppd->lpGSStack->lpgGState->ptPen.y))
  {
      lppd->lpGSStack->lpgGState->ptPen = inpen; 

      // MGX SET_SPREAD support   
      spread = (*lppd).sSetSpread; // JYW
      penwide = (short)lppd->lpGSStack->lpgGState->ptPen.x + spread;
      if (penwide < 1)
      penwide = 1;
      (*tempptr->PSSendShort)(lppd,penwide);
      (*tempptr->PSSendBasic)(lppd, PSOP_setlinewidth);
  }
}


/*****************************************************************************
*
*                 PSSendPenCap
*
* Function: This function outputs the pen cap
*
* Called:   short FAR PASCAL PSSendPenCap(LPPDEVICE lppd, POINT incap)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               POINT      inpen
*
* Returns: Nothing
*
*****************************************************************************/

VOID FAR PASCAL PSSendPenCap(LPPDEVICE lppd, BYTE incap)
{
  LPASCIIBINPTRS tempptr;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
  
  // If the pen cap style is not defined - use as 1
  // Changed 17-May-1993   -by-   [olegs]
  if( incap == (BYTE)-1 )
    incap = 1;

  if(incap != lppd->lpGSStack->lpgGState->bPenCap)
  {
      lppd->lpGSStack->lpgGState->bPenCap = incap;
      (*tempptr->PSSendShort)(lppd,(short)lppd->lpGSStack->lpgGState->bPenCap);
      (*tempptr->PSSendBasic)(lppd,PSOP_setlinecap);
  }
}
/*****************************************************************************
*
*                 PSSendPenJoin
*
* Function: This function outputs the pen join
*
* Called:   short FAR PASCAL PSSendPenJoin(LPPDEVICE lppd, BYTE inpen)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               BYTE      injoin
*
* Returns: Nothing
*
*****************************************************************************/

VOID FAR PASCAL PSSendPenJoin(LPPDEVICE lppd, BYTE injoin)
{
  LPASCIIBINPTRS tempptr;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
  // If the pen join style is not defined - use as 1
  // Changed 17-May-1993   -by-   [olegs]
  if( injoin == (BYTE) -1 )
    injoin = 1;
  if(injoin != lppd->lpGSStack->lpgGState->bPenJoin)
  {
      lppd->lpGSStack->lpgGState->bPenJoin=injoin;
      (*tempptr->PSSendShort)(lppd,(short)lppd->lpGSStack->lpgGState->bPenJoin);
      (*tempptr->PSSendBasic)(lppd,PSOP_setlinejoin);
  }
}

/*****************************************************************************
*
*                 PSSendPenMiter
*
* Function: This function outputs the pen miter
*
* Called:   short FAR PASCAL PSSendPenMiter(LPPDEVICE lppd, BYTE inmiter)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               BYTE      inmiter
*
* Returns: Nothing
*
*****************************************************************************/

VOID FAR PASCAL PSSendPenMiter(LPPDEVICE lppd, short inmiter)
{
  LPASCIIBINPTRS tempptr;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
  if(inmiter != lppd->lpGSStack->lpgGState->sPenMiter)
  {
      lppd->lpGSStack->lpgGState->sPenMiter=inmiter;
      (*tempptr->PSSendShort)(lppd,(short)lppd->lpGSStack->lpgGState->sPenMiter);  
      PSSendFragment(lppd,PSFRAG_setmiterlimit);      
  }
}

/*****************************************************************************
*
*                 PSSendPenStyle
*
* Function: This function outputs the pen style
*
* Called:   short FAR PASCAL PSSendPenJoin(LPPDEVICE lppd, BYTE instyle, int inwodth)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*               BYTE      instyle
*               int       inwidth
*
* Returns: Nothing
*
*****************************************************************************/

VOID FAR PASCAL PSSendPenStyle(LPPDEVICE lppd, BYTE instyle, int inwidth)
{
  short  DotLength;
  short  DotGap;
  short  DashLength;
  short  DashGap;
  short  sWidth;
  LPASCIIBINPTRS tempptr;
  short one_fiftyeth = lppd->DeviceRes.x_res/50; // 1/50 inch( in pixels)
  short one_twelfth  = lppd->DeviceRes.x_res/12; // 1/12 inch( in pixels)
  short one_eighth   = lppd->DeviceRes.x_res/8;  // 1/8  inch( in pixels)

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

  if( (instyle != lppd->lpGSStack->lpgGState->bPenStyle) ||
      (inwidth != lppd->lpGSStack->lpgGState->nPenStyleWidth))
  {
      lppd->lpGSStack->lpgGState->bPenStyle=instyle;       // Save the state
      lppd->lpGSStack->lpgGState->nPenStyleWidth=inwidth;  // Save the state
      sWidth = MAX( inwidth,1 );   

      DotLength  = MAX(one_fiftyeth - sWidth,0);      // Assume the ROUND=1 case
      DotGap     = 2 * sWidth;                        // or the BUTT =2 case
      DashGap    = 3 * sWidth;
      DashLength = 4 * sWidth;

      if(lppd->pen.bCap == 0 )
      {
      DotLength  = MAX(one_fiftyeth,sWidth);
      DotGap     -= sWidth;                        // or the BUTT =2 case
      DashLength += sWidth;
      DashGap    -= sWidth;
      }

      DotGap     = MAX(DotGap,one_twelfth);
      DashGap    = MAX(DashGap,one_twelfth);
      DashLength = MAX(DashLength,one_eighth);

      switch(lppd->lpGSStack->lpgGState->bPenStyle)
      {
     case LS_SOLID      :
         PSSendFragment(lppd,PSFRAG_solid);        
         break;                               

     case LS_DASHED     :                             // -------
         PSSendFragment(lppd,PSFRAG_leftbracket);  
         (*tempptr->PSSendShort)(lppd, DashLength );        
         (*tempptr->PSSendShort)(lppd, DashGap );           
         PSSendFragment(lppd,PSFRAG_rightbracket);    // Send "]"
         PSSendFragment(lppd,PSFRAG_setdsh);       
         break;                               

     case LS_DOTTED     :                             // .......
         PSSendFragment(lppd,PSFRAG_leftbracket);  
         (*tempptr->PSSendShort)(lppd, DotLength );         
         (*tempptr->PSSendShort)(lppd, DotGap );            
         PSSendFragment(lppd,PSFRAG_rightbracket);    // Send "]"
         PSSendFragment(lppd,PSFRAG_setdsh);       
         break;                               

     case LS_DOTDASHED  :                             // _._._._
         PSSendFragment(lppd,PSFRAG_leftbracket);  
         (*tempptr->PSSendShort)(lppd, DashLength );        
         (*tempptr->PSSendShort)(lppd, DotGap );            
         (*tempptr->PSSendShort)(lppd, DotLength );         
         (*tempptr->PSSendShort)(lppd, DotGap );            
         PSSendFragment(lppd,PSFRAG_rightbracket);    // Send "]"
         PSSendFragment(lppd,PSFRAG_setdsh);       
         break;                               

     case LS_DASHDOTDOT :                             // _.._.._
         PSSendFragment(lppd,PSFRAG_leftbracket);  
         (*tempptr->PSSendShort)(lppd, DashLength );        
         (*tempptr->PSSendShort)(lppd, DotGap );            
         (*tempptr->PSSendShort)(lppd, DotLength );         
         (*tempptr->PSSendShort)(lppd, DotGap );            
         (*tempptr->PSSendShort)(lppd, DotLength );         
         (*tempptr->PSSendShort)(lppd, DotGap );            
         PSSendFragment(lppd, PSFRAG_rightbracket);   // Send "]"
         PSSendFragment(lppd,PSFRAG_setdsh);       
         break;                               

     case LS_NOLINE       :
         break;                               

     case LS_INSIDEFRAME:
         PSSendFragment(lppd, PSFRAG_solid);        
         break;                               
      }                                              // End switch(Style)..
  }                                                   // End if(lpgGState->bPenStyle)
}

/*****************************************************************************
*
*                 PSSendPenBGColor
*
* Function: This function outputs the pen background color
*
* Called:   short FAR PASCAL PSSendPenBGColor(LPPDEVICE lppd)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*
* Returns: Nothing
*
*****************************************************************************/

VOID FAR PASCAL PSSendPenBGColor(LPPDEVICE lppd)
{
  FLAG  fGray,fPaintBack;                        
  LPASCIIBINPTRS tempptr;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

  fPaintBack=(lppd->graphics.bBackgroundMode==OPAQUE);
  fPaintBack &= (lppd->pen.bStyle!=LS_SOLID);   
  // For a solid pen, do not need to send back ground color. jjia  6/11/96
  fPaintBack &= (lppd->pen.bStyle!=LS_INSIDEFRAME);   

  if(fPaintBack)
  {
      PSSendGSave(lppd);       // Save the printer state
      fGray = PSSendColor(lppd,lppd->pen.dBGColor);       // Send gray -or- r g b
      PSSendColorOP(lppd,fGray);       // Send  sg  -or-  sco
      PSSendFragment(lppd,PSFRAG_solid);

     // For non-square resolution printers, adjust CTM scaling factors now to
     //  be EQUAL so that stroked line width is uniform in X, Y directions. See
     //  "setlinewidth" and "rectstroke" operator documentation in the Red Book.

     if (lppd->DeviceRes.x_res != lppd->DeviceRes.y_res)
     {
      float flScaleY =  (float)lppd->DeviceRes.y_res / 
             (float)lppd->DeviceRes.x_res;
     (*tempptr->PSSendBasic)(lppd, PSOP_gsave);   // save graphics state
      PSSendOrientationMatrix(lppd, (float)1.0, 
                  flScaleY);     // emit correction CTM
      PSSendFragment(lppd, PSFRAG_concat);
      (*tempptr->PSSendCRLF)(lppd);
     }
      (*tempptr->PSSendBasic)(lppd,PSOP_stroke);       // Send stroke

     if (lppd->DeviceRes.x_res != lppd->DeviceRes.y_res)
      (*tempptr->PSSendBasic)(lppd, PSOP_grestore);// restore graphics state

      PSSendGRestore(lppd);       // Restore the printer state
  }
}

/*****************************************************************************
*
*                 PSSendPenFGColor
*
* Function: This function outputs the pen foreground color
*
* Called:   short FAR PASCAL PSSendPenFGColor(LPPDEVICE lppd)
*
* Parameters:   LPPDEVICE  lppd     The device context to output to.
*
* Returns: Nothing
*
*****************************************************************************/

VOID FAR PASCAL PSSendPenFGColor(LPPDEVICE lppd)
{
  FLAG fGray;                                    

// Always send FG color because WordPerfect 6.0 passthroughs change the
// pen color, and we are unaware of  this. The extra PostScript is minimal
// and we might as well do it for all apps instead of having an app compat
// flag for WP60.

// Performance improvement.  jjia    5/30/96
  if ((lppd->pen.dFGColor != lppd->lpGSStack->lpgGState->dColor) ||
      (lppd->lpGSStack->lpgGState->bColorSpaceChanged))
  {
      fGray = PSSendColor(lppd,lppd->pen.dFGColor);         // Send gray -or- r g b
      PSSendColorOP(lppd,fGray);                             // Send  sg  -or-  sco
      lppd->lpGSStack->lpgGState->bColorSpaceChanged = FALSE;
  }
}

/******************************************************************************
*                           PSSendGSave
*
*  Function:   This routine sends a gsave(save graphics state) command to the printer.
*              It also pushes a snapshot of the current GSTATE onto the GSTATE stack
*              so that it can be properly restored in response to a grestore command.
*
*  Called:     short FAR PASCAL PSSendGSave(LPPDEVICE lppd)
*
*  Parameters: LPPDEVICE lppd -- pdevice pointer
*
*  Returns:    RC_ok if no error, else RC_fail.
*
******************************************************************************/

short FAR PASCAL PSSendGSave(LPPDEVICE lppd)
{
    LPASCIIBINPTRS tempptr;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    (*tempptr->PSSendBasic)(lppd, PSOP_gsave);
    GSStackPush(lppd);
    return(RC_ok);
}

/******************************************************************************
*                              PSSendGRestore
*  Function:
*       This routine sends a grestore(restore graphics state) command to the
*       printer. It also pops the current GSTATE off the GSTATE stack.
*
*  Called:   short FAR PASCAL PSSendGRestore(LPPDEVICE lppd)
*
*  Parameters:  LPPDEVICE lppd -- pdevice pointer
*
*  Returns:     RC_ok if no error, else RC_fail.
*
******************************************************************************/

short FAR PASCAL PSSendGRestore(LPPDEVICE lppd)
{
    LPASCIIBINPTRS tempptr;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
    (*tempptr->PSSendBasic)(lppd, PSOP_grestore);
    GSStackPop(lppd);
    return(RC_ok);
}

/************************************************************************
*                           PSSendClipRect
*
*  Function: this function sends a cliprect to the printer and stores it in
*            gstate.  It is caller's responsibility to make sure the clip
*            will not be a no-op, and to call gsave beforehand.
*
*  Called:   short FAR PASCAL PSSendClipRect(LPPDEVICE lppd, short v1, short v2,
*                                       short v3, short v4)
*
*  Parameters: LPPDEVICE lppd -- pdevice pointer
*              short v1 -- 1st parameter to "rc"
*             short v2 -- 2nd parameter to "rc"
*             short v3 -- 3rd parameter to "rc"
*             short v4 -- 4th parameter to "rc"
*
*  Returns:   short RC_ok or RC_fail
*
************************************************************************/

short FAR PASCAL PSSendClipRect(LPPDEVICE lppd, short v1, short v2, short v3,
               short v4)
    {
    short retval;
    LPASCIIBINPTRS tempptr;

    tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

    retval = RC_ok;

    (*tempptr->PSSendShort)(lppd,v1);
    (*tempptr->PSSendShort)(lppd,v2);
    (*tempptr->PSSendShort)(lppd,v3);
    (*tempptr->PSSendShort)(lppd,v4);
    PSSendFragment(lppd,PSFRAG_rectclip); //Send the new clipping rectangle.

    lppd->lpGSStack->lpgGState->cliprect[0] = v1;
    lppd->lpGSStack->lpgGState->cliprect[1] = v2;
    lppd->lpGSStack->lpgGState->cliprect[2] = v3;
    lppd->lpGSStack->lpgGState->cliprect[3] = v4;

    lppd->lpGSStack->lpgGState->fClipIsMax = FALSE;


    // The PS Level 1 implementation of PSFRAG_rectclip clears the PostScript
    // interpreter's current point, so we must clear it in our records too.

    PSSetNoCurrentPoint(lppd);  

    return(retval);
    }


/************************************************************************
*
*                          PSStringOutput  
*
* Function:  to output large buffer as PS string.
*            The characters inside the buffer can be in range 0-255,
*            but only "(", ")" and "\" are escaped by \.
*            This function then sends it's output to PSSendBitmapDataLevel1Binary,
*            which in turn encapsulates the data in BCP/TBCP escapes
*
* Called:    VOID FAR PASCAL PSStringOutput( LPPDEVICE lppd, BYTE huge *lpStr, DWORD dwLen)
*
* Parameters: LPPDEVICE lppd
*             BYTE huge *lpStr
*             DWORD      dwLen)
*
* Returns:Nothing
*
************************************************************************/
VOID FAR PASCAL PSStringOutput( LPPDEVICE lppd, BYTE huge *lpStr, DWORD dwLen)
{
   HANDLE  hBuffer = NULL; // Handle to the work buffer
   BYTE huge *lpBuffStart; // Pointer to the beginning of work buffer
   BYTE huge *lpBuff;      // Pointer to the bytes in  buffer
   BYTE    cChar;          // Current char
   DWORD   dwNBytes;       // Number of bytes to output

   if (!lppd->GlobalBuffer.lpStringOutput)
       return;
       
   // Check if Memory Block allocated (and kept track of in PDevice) is sufficient.
   if (lppd->GlobalBuffer.dStringOutput < (dwLen * 2) )
   {
     MGUnlockFree(lppd, lppd->GlobalBuffer.hStringOutput, TRUE);
     lppd->GlobalBuffer.lpStringOutput = 
             (BYTE huge *) MGAllocLock(lppd,
             (LPHANDLE)&lppd->GlobalBuffer.hStringOutput,
             (dwLen * 2), GHND, TRUE);
     lppd->GlobalBuffer.dStringOutput = (dwLen * 2);

     if (lppd->GlobalBuffer.hStringOutput == NULL)
    return;
   }
   lpBuffStart = (BYTE huge *)lppd->GlobalBuffer.lpStringOutput;

   if( !lpBuffStart )
   {
     return;
   }

   lpBuff = lpBuffStart;

   dwNBytes = 0L;
   while( dwLen)
   {
      cChar = *lpStr++;
      if( ( cChar == '('  ) ||        // Escape one
         ( cChar == ')'  ) ||        //
         ( cChar == '\\' )    )      //  of those characters
      {                               //
         *lpBuff++ = '\\' ;          //  by preceding '\'
         dwNBytes++;
      }
      *lpBuff++ = cChar;              // Add the byte itself
      dwNBytes++;
      dwLen-- ;                       // Bump counters
   }

   PSSendBitMapDataLevel1Binary(lppd, lpBuffStart, dwNBytes );
}

/************************************************************************
*
*                           PSSendDirect  
*
* Function:   To send the data without BCP and/or TBCP
*             encapsulation when we are 100% sure that they are printable ASCII
*             in range 32 - 127
*             which in turn encapsulates the data in BCP/TBCP escapes
* Called:     VOID FAR PASCAL PSSendDirect(LPPDEVICE lppd, BYTE huge *buf, DWORD NumBytes)
*
* Parameters: LPPDEVICE lppd
*             BYTE huge *buf
*             DWORD NumBytes
*
* Returns:    Nothing
*
************************************************************************/
VOID FAR PASCAL PSSendDirect(LPPDEVICE lppd, BYTE huge *buf, DWORD NumBytes)
{
   WORD   Number;
   LPBYTE BinaryData;
   LPASCIIBINPTRS tempptr;
   WORD   MaxSize = 0x1000;

   tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;

   if (!lppd->GlobalBuffer.lpDirect)
       return;
       
   // Check if Memory Block allocated (and kept track of in PDevice) is sufficient.
   if (lppd->GlobalBuffer.dDirect < MaxSize)
   {
     MGUnlockFree(lppd, lppd->GlobalBuffer.hDirect, TRUE);
     lppd->GlobalBuffer.lpDirect = 
             (LPBYTE) MGAllocLock(lppd,
             (LPHANDLE)&lppd->GlobalBuffer.hDirect,
             MaxSize,GHND,TRUE);
     lppd->GlobalBuffer.dDirect = MaxSize;

     if (lppd->GlobalBuffer.hDirect == NULL)
    return;
   }

   BinaryData = (LPBYTE)lppd->GlobalBuffer.lpDirect;

   if( BinaryData == NULL )
   {
     return;
   }

   while (NumBytes > MaxSize)
   {
      Number = MaxSize;
      MemCopy( BinaryData, buf,  (DWORD) Number ) ;
      PSSendData(lppd,BinaryData, Number );
      NumBytes -= MaxSize;
      buf      += MaxSize;
   }

   if(NumBytes > 0)
   {
      Number = (WORD) NumBytes;
      MemCopy( BinaryData, buf, (DWORD) Number ) ;
      PSSendData(lppd, BinaryData, Number);
   }
}

/************************************************************************
*
*                          PSSendDSCBBoxAscii7
*
* Function:
*
* Called:    short FAR PASCAL PSSendDSCBBoxAscii7(LPPDEVICE lppd, short sDSCid, 
*                                                           LPRECT pRect )
* Parameters:
*
* Returns:Nothing
*
************************************************************************/
short FAR PASCAL PSSendDSCBBoxAscii7(LPPDEVICE lppd, short sDSCid, LPRECT pRect )
{
  CHAR zTemp[128];
  int length;
  LPSTR lpzTemp=(LPSTR)zTemp;
  LPASCIIBINPTRS tempptr;

  tempptr = (LPASCIIBINPTRS)lppd->lpAsciiBinPtr;
  //first send the basic comment
  //
  if(sDSCid<=DSC_begin || sDSCid>=DSC_end) return(RC_fail);
  if(sDSCid>DSC_null)
  {
     LoadDrvrString(ghDriverMod,sDSCid,lpzTemp,sizeof(zTemp));
//   PortWrite(lppd,lpzTemp,lstrlen(lpzTemp));
  }

  // Send the rectangle.
  PSSendBBox(lppd,pRect, zTemp);
  length = lstrlen(zTemp);
  LoadDrvrString(ghDriverMod, PSFRAG_crlf, zTemp+length, 128-length);
  length += 2;

  AdobeOEMSendPSStub(lppd, PS_INDEX_BOUNDING_BOX,
                     zTemp, length);
  return(RC_ok);
}


LPSPCLPSDATA FAR PASCAL CreateNewSpclPSData(LPPDEVICE lppd)
{
    LPSPCLPSDATA lpSpecialPSData = NULL;
    lpSpecialPSData = GlobalAllocPtr(GHND|GMEM_DDESHARE, PS_SPCLSIZE);
    if (lpSpecialPSData){
       lpSpecialPSData->lpPSData = ((LPBYTE)lpSpecialPSData + sizeof(SPCLPSDATA));
       lpSpecialPSData->dwSize = PS_SPCLSIZE - sizeof(SPCLPSDATA);
       lpSpecialPSData->lpNextPSData = NULL;
       lpSpecialPSData->dwPSCount = 0;
    }
    return lpSpecialPSData;
}
       


// For this function, dwLen must be less than  PS_SPCLSIZE-sizeof(SPCLPSDATA)!!!!
int FAR PASCAL CopySpecialPSData(LPPDEVICE lppd,  LPSPCLPSDATA lpSpecialPSData, LPBYTE lpPSData, DWORD dwLen)
{
 LPBYTE lpTmp;
 DWORD  dwTmp;
   if (lpSpecialPSData==NULL) return 0;  // FAIL: no buffer yet. Please allocate buffer first
   // Check current buffer size:
   if (dwLen < lpSpecialPSData->dwSize - lpSpecialPSData->dwPSCount){
      MemCopy((LP)((LPBYTE)lpSpecialPSData->lpPSData+lpSpecialPSData->dwPSCount), (LP)lpPSData, dwLen);
      lpSpecialPSData->dwPSCount += dwLen;
    }
   else {
      dwTmp = lpSpecialPSData->dwSize - lpSpecialPSData->dwPSCount - 1;
      MemCopy((LP)((LPBYTE)lpSpecialPSData->lpPSData+lpSpecialPSData->dwPSCount), (LP)lpPSData, dwTmp); // copy potion
      lpSpecialPSData->dwPSCount += dwTmp;
      lpTmp = (LPBYTE)lpPSData + dwTmp;
           // no more space left in this block, goto next one: recursive call!!!
      if (lpSpecialPSData->lpNextPSData==NULL){
         // Allocate new buffer:
         lpSpecialPSData->lpNextPSData = CreateNewSpclPSData(lppd);
         }
      CopySpecialPSData(lppd, lpSpecialPSData->lpNextPSData, lpTmp, (dwLen-dwTmp));
     }
    
   return 1; // means success.
}


// Special PS data is freed right after real SatrtDoc() call, (actually inside it).
// A job can only be aborted after StartDoc. So, we don't need to call FreeSpecialPSData()
// anywhere else except in Disable() just in case the job is aborted inside StartDoc(). 
void FAR PASCAL FreeSpecialPSData(LPPDEVICE lppd)
{
   LPSPCLPSDATA lpSpcl = lppd->lpSpecialPSData;
   LPSPCLPSDATA lpTmp;
   
   while (lpSpcl!=NULL){
     lpTmp = lpSpcl->lpNextPSData; 
     // Notice how lpSpcl->lpPSData is allocated in CreateNewSPClPSData()- next call frees them all.
     GlobalFreePtr(lpSpcl);
     lpSpcl = lpTmp;
   }
   lppd->lpSpecialPSData=NULL;
}


void FAR PASCAL TSendSpecialPSData(LPPDEVICE lppd)
{
   LPSPCLPSDATA lpSpcl = lppd->lpSpecialPSData;

   lppd->bCopyToSpecial = 0; // Stop CopyToBuffer first to prevent Infinite Loop !!!!
   
   while (lpSpcl!=NULL){
     PSSendData(lppd, lpSpcl->lpPSData, (WORD)lpSpcl->dwPSCount);
     lpSpcl = lpSpcl->lpNextPSData; 
   }
   FreeSpecialPSData(lppd);  // Free the buffers
}

/*****************************************************************************
*                          CreateNewPSInjectionRecord
* Function: Create PostScript injection data record
*
* Parameters: LPPDEVICE lppd     PDEVICE pointer
* Returns:  LPPSINJECTDATA  record pointer
*****************************************************************************/
LPPSINJECTDATA FAR PASCAL CreateNewPSInjectionRecord(LPPDEVICE lppd)
{
    LPPSINJECTDATA lpPSInjectData = NULL;
    DWORD buffOffset;

    lpPSInjectData = GlobalAllocPtr(GHND|GMEM_DDESHARE, sizeof(PSINJECTDATA));
    if (lpPSInjectData){
       if (lppd->lpCurrentBuffer != NULL)
       {
          buffOffset = PS_SPCLSIZE - lppd->lpPSInjectData->dwbufSize + 1;   
          lpPSInjectData->lpPSData = lppd->lpCurrentBuffer + buffOffset;
          lpPSInjectData->dwbufSize = lppd->lpPSInjectData->dwbufSize;
       }
       else  
       {
          lpPSInjectData->lpPSData = NULL;
          lpPSInjectData->dwbufSize = PS_SPCLSIZE;
       }
       lpPSInjectData->lpNextPSInjectData = NULL;
       lpPSInjectData->bStartBuffer = FALSE;
       lpPSInjectData->dwPSCount = 0;
       lpPSInjectData->iPSInjectID = 0;
       lpPSInjectData->iPageNumber = 0xffff;
       if (lppd->lpPSInjectData)
          lppd->lpPSInjectData->lpNextPSInjectData = lpPSInjectData;         
       else 
       if (lppd->lpPSInjectData == NULL)
       {
          lppd->lpPSInjectData = lppd->lpPSInjectRoot = lpPSInjectData;
       }

    }                                                    
    return lpPSInjectData;
}
/*****************************************************************************
*                          SetupPSInjectionRecord
* Function: Copy PostScript injection data record to the injection record
*
* Parameters: LPPDEVICE lppd     PDEVICE pointer
*         LPPSINJECTDATA     lpPSInjecData
*             LPBYTE             lpPSData
*             DWORD              wLen
* Returns:    void       nothing
*****************************************************************************/
void FAR PASCAL SetupPSInjectionRecord(LPPDEVICE lppd, LPBYTE lpPSData)
{       
   LPPSINJECTBYTE lpTmp = (LPPSINJECTBYTE)lpPSData;
   LPPSINJECTDATA lpPSInject = lppd->lpPSInjectData;

   if (lppd->lpCurrentBuffer == NULL) {
      lppd->lpCurrentBuffer = GlobalAllocPtr(GHND|GMEM_DDESHARE, PS_SPCLSIZE);
      if (lpPSInject)
      {
         lpPSInject->bStartBuffer = TRUE;
         lpPSInject->lpPSData = lppd->lpCurrentBuffer;
      }
   }
   if (lpPSInject)
   {
       lpPSInject->iPSInjectID = lpTmp->PSInjectID;
       lpPSInject->iPageNumber = lpTmp->PageNumber;
   }
//  lppd->lpInjectData point to the current injection data record
// it will be updated when new record is created
}
/*****************************************************************************
*                          CopyPSInjectionData
* Function: Copy Application requested PostScript data record to
*             the injection record
*
*         if (dwLen
* Parameters: LPPDEVICE lppd     PDEVICE pointer
*         LPPSINJECTDATA     lpPSInjecData
*             LPBYTE             lpPSData
*             DWORD              wLen
* Returns:    int        1/0 success/fail
*****************************************************************************/
int FAR PASCAL CopyPSInjectionData(LPPDEVICE lppd,  LPPSINJECTDATA lpPSInjectData, LPBYTE lpPSData, DWORD dwLen)
{
   LPBYTE lpTmp;
   DWORD  dwTmp, dwPart;

   if (lpPSInjectData==NULL) return 0;  // FAIL: no buffer yet. Please allocate buffer first
   // Check current buffer size:
   if (dwLen <= lpPSInjectData->dwbufSize){
      MemCopy((LP)((LPBYTE)lpPSInjectData->lpPSData+lpPSInjectData->dwPSCount), (LP)lpPSData, dwLen);
      lpPSInjectData->dwPSCount += dwLen;
      lpPSInjectData->dwbufSize -= dwLen;
   }
   else {
      dwTmp = dwLen - lpPSInjectData->dwbufSize;
      dwPart = lpPSInjectData->dwbufSize;
      MemCopy((LP)((LPBYTE)lpPSInjectData->lpPSData+lpPSInjectData->dwPSCount), (LP)lpPSData, dwPart); // copy portion
      lpPSInjectData->dwPSCount += dwPart;
      lpPSInjectData->dwbufSize -= dwPart;

        lpTmp = (LPBYTE)lpPSData + dwPart;
      // no more space left in this block, duplicate the current record
      if (lpPSInjectData->lpNextPSInjectData==NULL)
      {   // Allocate new buffer:
         lppd->lpCurrentBuffer = NULL;
         lpPSInjectData->lpNextPSInjectData = CreateNewPSInjectionRecord(lppd);
     //
         lppd->lpCurrentBuffer = GlobalAllocPtr(GHND|GMEM_DDESHARE, PS_SPCLSIZE);
         lpPSInjectData->lpNextPSInjectData->iPSInjectID = lpPSInjectData->iPSInjectID;
         lpPSInjectData->lpNextPSInjectData->iPageNumber = lpPSInjectData->iPageNumber;
         lpPSInjectData->lpNextPSInjectData->bStartBuffer = TRUE;
         lpPSInjectData->lpNextPSInjectData->lpPSData = lppd->lpCurrentBuffer;
         lppd->lpPSInjectData = lpPSInjectData->lpNextPSInjectData;
      }
      CopyPSInjectionData(lppd, lpPSInjectData->lpNextPSInjectData, lpTmp, (dwLen-dwPart));
     }
    
   return 1; // means success.
}

/*****************************************************************************
*                          FreePSInjectionData
* Function: Create PostScript injection data record
*
* Parameters: LPPDEVICE lppd     PDEVICE pointer
* Returns:  nothing
*****************************************************************************/

// PostScript Injection data  record is freed right after real SatrtDoc() call, (actually inside it).
// A job can only be aborted after StartDoc. So, we don't need to call FreePSInjectionData()
// anywhere else except in Disable() just in case the job is aborted inside StartDoc(). 
void FAR PASCAL FreePSInjectionRecord(LPPDEVICE lppd)
{
   LPPSINJECTDATA lpSpcl = lppd->lpPSInjectRoot;
   LPPSINJECTDATA lpTmp;
   
   while (lpSpcl!=NULL){
     // Notice how lpSpcl->lpPSInjectData is allocated in CreateNewPSInjectData()- next call frees them all.
     if (lpSpcl->bStartBuffer)
            GlobalFreePtr(lpSpcl->lpPSData);  // release the data buffer
     lpTmp = lpSpcl->lpNextPSInjectData; 
     GlobalFreePtr(lpSpcl);       // release injection record
     lpSpcl = lpTmp;
   }
   lppd->lpPSInjectRoot = lppd->lpPSInjectData=NULL;
}



// Fix bug (143352), copied from 4.1CJK, 3-21-1996, PPeng.

/*****************************************************************************
*                          PSSendTextCharHex
* Function: To Ouput a string in Hex Format
*
* Parameters: LPPDEVICE lppd     PDEVICE pointer
*             LPSTR     lpz      pointer to string of chars to send
*             int       count    Number of characters to send
* Returns:  RC_ok
*****************************************************************************/
short FAR PASCAL PSSendTextCharHex(LPPDEVICE lppd, LPSTR lpz, int count)
{
   int i;
   BYTE b;
   CHAR  NumString[4];
   int   Length;                                 

   //insert a left Hex-parenthesis
   PortWrite(lppd, (LPSTR)"<", 1);

   // send one-byte at a time:
   for (i=0; i<count; i++){
      b = *((LPBYTE)lpz + i);
      Length = wsprintf(NumString, "%2.2X", b);       // Convert byte to Hex
      PortWrite(lppd, NumString, Length);       // Write to the Port
   }

   //insert a right Hex-parenthesis
   PortWrite(lppd, (LPSTR)">", 1);
   return(RC_ok);                                 
}

/*****************************************************************************
*                          PSSendTextAscii7OrHex
* Function: To Ouput a string in Hex Format or in Ascii7 format
*  - it will call PSSendTextCharHex() or PSSendTextCharAscii7()
*
* Parameters: LPPDEVICE lppd     PDEVICE pointer
*             LPSTR     lpz      pointer to string of chars to send
*             int       count    Number of characters to send
* Returns:  String length
*****************************************************************************/
short FAR PASCAL PSSendTextAscii7OrHex(LPPDEVICE lppd, LPSTR lpz, int count)
{
   int  i;
   LONG aii=0, hex=0;
   BYTE b;
 
   hex = count*2;
   // Check the chars in lpz to decide which way to go: Ascii7 or Hex.
   for (i=0; i<count; i++){
      b = *((LPBYTE)lpz + i);
      if (b<0x20 || b>0x7E) aii += 4; // if sent as Ascii7, need four bytes "\001"
      else aii +=1; 
   }

   if ( hex < aii )
   {
       PSSendTextCharHex(lppd, lpz, count);
       return ((short)(hex + 2));
   }
   else
   {
       PSSendTextCharAscii7(lppd, lpz, count);
       return ((short)(aii + 2));
   }   
}

/*****************************************************************************
*                          LocateInjectPoint
* Function: Locate the injection position on DSC replacement string
*
* Parameters: 
*                       return   3     insert after
* Returns:        PSInjectionPoint   PostScript Injection ID
*****************************************************************************/
LPSTR NEAR PASCAL LocateInjectPoint (LPSTR  *lplpDriverPS)
{

      LPSTR lpTmp, lpPS;
    
      lpPS = lpTmp = *lplpDriverPS;
     while (*lpTmp)
     {
        if (*lpTmp == ':' && *(lpTmp+1) == ' ')
        {
                *(lpTmp+2) = '\0';
             return (lpTmp+2);
        }
        else
                 lpTmp++;
     }
     return lpPS;

}
/*****************************************************************************
*                          GetAPPInjectID
* Function: return matched APP Inject id through map table
*
* Parameters: 
*              psIndex            OEM PSINDEX id
*             LPSTR              address of inject type
*                      return   1       insert before
*                      return   2       replace
*                       return   3     insert after
* Returns:        PSInjectionPoint   PostScript Injection ID
*****************************************************************************/
PSInjectionPoint FAR PASCAL GetAPPInjectID (DWORD PSIndex, int *lpInjectType)
{

   int i, InjectType;
   PSInjectionPoint PSInjectID;
   InjectType = 0;

   for ( i= 0; i < MATCH_ENTRY; i++)

   {
      if (PSIndex == MatchMap[i].psIndex)
      {
         PSInjectID = MatchMap[i].psInjectID;
           
         switch (PSInjectID)
         {
                                          // insert before
         case  IPS_PSADOBE     :
         case  IPS_ENDCOMMENTS :
         case  IPS_ENDPROLOG   :
         case  IPS_ENDSETUP    :
         case  IPS_EOF         :
         case  IPS_ENDDEFAULTS :
         case  IPS_PAGE_ENDSETUP:
//         case  IPS_PAGE_SHOWPAGEN:
         case  IPS_PAGE_SHOWPAGE:
         // new as in NT4/5
         case  IPS_ENDPAGECOMMENTS:  
                                         InjectType = 1;
                                         break;
                                          // replace    
         case  IPS_PAGESATEND  :
         case  IPS_PAGES       :
         case  IPS_PAGEORDER   :
         case  IPS_BOUNDINGBOX :                      
         case  IPS_ORIENTATION :
         case  IPS_PAGE_PAGENUMBER:
         case  IPS_PAGEBOUNDINGBOX:
         // new as in NT4/5
         case IPS_DOCUMENTPROCESSCOLORS:
         case IPS_DOCUMENTPROCESSCOLORSATEND:
         case IPS_PLATECOLOR:
                                         InjectType = 2;
                                         break;

                                          // insert after
         case  IPS_DOCUMENTNEEDEDRESOURCES:
         case  IPS_DOCUMENTSUPPLIEDRESOURCES:
         case  IPS_BEGINDEFAULTS :
//         case  IPS_REQUIREMENTS  :
         case  IPS_BEGINPROLOG  :
         case  IPS_BEGINSETUP   :
         case  IPS_TRAILER     :                       
         case  IPS_PAGE_BEGINSETUP  :
         case  IPS_PAGE_TRAILER :
                                         InjectType = 3;
                                         break;
            }
           *lpInjectType = InjectType;
            return (PSInjectID);

        }
   }
    return 0;
}

/*****************************************************************************
*                          SendPSInjectionData
* Function: To Ouput the PSInjectID PostScript injection data to the output string
*    
*
* Parameters: LPPDEVICE lppd     PDEVICE pointer
*             PSInjectionPoint   PSInjectID
*             LPSTR              lpDriverPS
*         LONG           lLength
* Returns:         none
*****************************************************************************/
void FAR PASCAL SendPSInjectionData(LPPDEVICE lppd, PSInjectionPoint PSInjectID,
                        LPSTR FAR *lplpDriverPS,
                                            unsigned FAR *lpDriverPSLen) 
{
    LPPSINJECTDATA lpInjectData = lppd->lpPSInjectRoot;
    BOOL  bFirstTime = TRUE;

    while(lpInjectData != NULL)
   {
       // process the multiple requests of the same PSInjectID

       if ( (int)lpInjectData->iPSInjectID == PSInjectID)
      {
        switch(PSInjectID)
         {
                                          // insert before
         case  IPS_PAGE_ENDSETUP:
         case  IPS_PAGE_SHOWPAGE:
                   if ((short)lpInjectData->iPageNumber != 0)
                   {    
                  if (((short)lpInjectData->iPageNumber < lppd->lpProcsetstuff->currpagenumber) ||
                     (short)lpInjectData->iPageNumber != lppd->lpProcsetstuff->currpagenumber)
                      break;
                   }
                               PortWrite( lppd, (LP)lpInjectData->lpPSData, (WORD)lpInjectData->dwPSCount);
                 break; 
/*            
         case  IPS_PAGE_SHOWPAGEN:
                   if ((short)lpInjectData->iPageNumber != 0)
                   {    
                  if (((short)lpInjectData->iPageNumber < lppd->lpProcsetstuff->nuppagenumber) ||
                     (short)lpInjectData->iPageNumber != lppd->lpProcsetstuff->nuppagenumber)
                      break;
                   }         
*/
         case  IPS_ENDPAGECOMMENTS:             //new
         case  IPS_PSADOBE     :
         case  IPS_ENDCOMMENTS :
         case  IPS_ENDPROLOG   :
         case  IPS_ENDSETUP    :
         case  IPS_EOF         :
         case  IPS_ENDDEFAULTS :
         case  IPS_BEGINSTREAM :
                               PortWrite( lppd, (LP)lpInjectData->lpPSData, (WORD)lpInjectData->dwPSCount);
                 break;
                                          // replace    
         case  IPS_PAGE_PAGENUMBER:
                   if ((short)lpInjectData->iPageNumber != 0)
                   {    
                  if (((short)lpInjectData->iPageNumber < lppd->lpProcsetstuff->currpagenumber) ||
                     (short)lpInjectData->iPageNumber != lppd->lpProcsetstuff->currpagenumber)
                      break;
                                  // else fall through
                   }         
         case  IPS_DOCUMENTPROCESSCOLORSATEND  :
         case  IPS_DOCUMENTPROCESSCOLORS  :
         case  IPS_PLATECOLOR  :
    
         case  IPS_PAGESATEND  :
         case  IPS_PAGES       :
         case  IPS_PAGEORDER   :
         case  IPS_BOUNDINGBOX :                      
         case  IPS_ORIENTATION :
         case  IPS_PAGEBOUNDINGBOX:
                 // Advance to "%%...: "
                 // return the replacement string to the next level
                *lplpDriverPS = lpInjectData->lpPSData;
              *lpDriverPSLen = (short)lpInjectData->dwPSCount;                   
                   break;

                                          // insert after
         case  IPS_PAGE_BEGINSETUP  :
         case  IPS_PAGE_TRAILER     :

                   if ((short)lpInjectData->iPageNumber != 0)
                   {    
                  if (((short)lpInjectData->iPageNumber < lppd->lpProcsetstuff->currpagenumber) ||
                     (short)lpInjectData->iPageNumber != lppd->lpProcsetstuff->currpagenumber)
                      break;
                   }         
         case  IPS_DOCUMENTNEEDEDRESOURCES:
         case  IPS_DOCUMENTSUPPLIEDRESOURCES:
         case  IPS_BEGINDEFAULTS :
//         case  IPS_REQUIREMENTS  :
         case  IPS_BEGINPROLOG  :
         case  IPS_BEGINSETUP   :
         case  IPS_TRAILER          :                        
         case  IPS_ENDSTREAM     :
               if (bFirstTime)
               {
                   PortWrite( lppd, (LP)"\r\n", 2);
                   bFirstTime = FALSE;
               }
               PortWrite( lppd, (LP)lpInjectData->lpPSData, (WORD)lpInjectData->dwPSCount);
               break;
         } // end switch
       } // end if
    lpInjectData = lpInjectData->lpNextPSInjectData;
    }    // end while
}
