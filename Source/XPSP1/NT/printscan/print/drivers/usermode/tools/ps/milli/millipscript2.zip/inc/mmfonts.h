
// Functions in mmfonts.c
short FAR PASCAL ExistMMFonts(void);
short FAR PASCAL IsMMBaseFont(LPPDEVICE lppd, LPSTR szFontName, int byFamilyName);
short FAR PASCAL IsMMInstanceFont(LPPDEVICE lppd, LPSTR szFontName, LPSTR szBaseFontName, int byFamily);

// Functions in WM.C. I know it is not a good idea to put these prototypes
// her. But it's better than to put them in the C files.
int TRealizeAndSendFont(LPPDEVICE lppd, LPLOGFONT lplfont, LPSTR strText, int nText, BOOL bMinHdr);
void TSendWMPdefn(LPPDEVICE lppd);
void TSendWaterMark(LPPDEVICE lppd);

