/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: ENCODE.H                                                     */
/*                                                                           */
/* Description: This module contains the function prototypes for encode.c    */
/*                                                                           */
/*****************************************************************************/
// Prototype


short FAR PASCAL PSSendBasicAscii7   (LPPDEVICE, short);
short FAR PASCAL PSSendBasicBinary   (LPPDEVICE, short);

short FAR PASCAL PSSendShortAscii7   (LPPDEVICE, short);
short FAR PASCAL PSSendShortBinary   (LPPDEVICE, short);

short FAR PASCAL PSSendFloatAscii7   (LPPDEVICE, float);
short FAR PASCAL PSSendEx6FloatAscii7   (LPPDEVICE, float);
short FAR PASCAL PSSendFloatBinary   (LPPDEVICE, float);

short FAR PASCAL PSSendCRLFAscii7    (LPPDEVICE);
short FAR PASCAL PSSendCRLFBinary    (LPPDEVICE);

short FAR PASCAL PSSendDSCAscii7     (LPPDEVICE, short, LPSTR );
short FAR PASCAL PSSendDSCBinary     (LPPDEVICE, short, LPSTR );
short FAR PASCAL PSSendDSCBBoxAscii7 (LPPDEVICE, short, LPRECT );
short FAR PASCAL PSSendDSCBBoxBinary (LPPDEVICE, short, LPRECT );

short FAR PASCAL PSSendBooleanAscii7 (LPPDEVICE, FLAG);
short FAR PASCAL PSSendBooleanBinary (LPPDEVICE, FLAG);

VOID  FAR PASCAL PSSendBitMapTypeAscii7(LPPDEVICE, short);
VOID  FAR PASCAL PSSendBitMapTypeBinary(LPPDEVICE, short);

VOID  FAR PASCAL PSSendBitMapDataLevel2Ascii7(LPPDEVICE,BYTE huge *,DWORD);
VOID  FAR PASCAL PSSendBitMapDataLevel2Binary(LPPDEVICE,BYTE huge *,DWORD);

VOID  FAR PASCAL PSSendBitMapTerminatorAscii7(LPPDEVICE);
VOID  FAR PASCAL PSSendBitMapTerminatorBinary(LPPDEVICE);

VOID  FAR PASCAL PSSendBitMapDataLevel1Ascii7(LPPDEVICE,BYTE huge *,DWORD);
VOID  FAR PASCAL PSSendBitMapDataLevel1Binary(LPPDEVICE,BYTE huge *,DWORD);

BOOL  NEAR PASCAL PSSendFontType2Binary(LPPDEVICE,int,long,LPSTR,int);
BOOL  NEAR PASCAL PSSendFontType2Ascii (LPPDEVICE,int,long,LPSTR,int);

WORD FAR PASCAL BCPConvertToBinary(BYTE huge * , BYTE huge * , WORD);
WORD FAR PASCAL EBCPConvertToBinary(BYTE huge * ,BYTE huge * , WORD);
WORD FAR PASCAL NOConvertToBinary(BYTE huge *, BYTE huge * , WORD);

LPSTR FAR PASCAL GetByteAddress(LPBITMAP lpDevBitmap, WORD wX, WORD wY);
VOID FAR PASCAL ASCII85Output(LPPDEVICE , BYTE huge *, DWORD, int FAR *);

//typedefs

typedef short (FAR  PASCAL *PSSENDBASIC     )(LPPDEVICE,short);
typedef short (FAR  PASCAL *PSSENDTEXT      )(LPPDEVICE,LPSTR);
typedef short (FAR  PASCAL *PSSENDSHORT     )(LPPDEVICE,short);
typedef short (FAR  PASCAL *PSSENDBOOLEAN   )(LPPDEVICE,FLAG);
typedef short (FAR  PASCAL *PSSENDBBOX      )(LPPDEVICE,LPRECT);
typedef short (FAR  PASCAL *PSSENDSTRING    )(LPPDEVICE,LPSTR);
typedef short (FAR  PASCAL *PSSENDCHAR      )(LPPDEVICE,LPSTR);
typedef short (FAR  PASCAL *PSSENDDATA      )(LPPDEVICE,LP,WORD);
typedef short (FAR  PASCAL *PSSENDFLOAT     )(LPPDEVICE,float);
typedef short (FAR  PASCAL *PSSENDEX6FLOAT     )(LPPDEVICE,float);  // new
typedef short (FAR  PASCAL *PSSENDHEXBYTE   )(LPPDEVICE,BYTE);
typedef short (FAR  PASCAL *PSSENDHEXCOLOR  )(LPPDEVICE,DWORD);
typedef short (FAR  PASCAL *PSSENDFRAGMENT  )(LPPDEVICE,WORD);
typedef short (FAR  PASCAL *PSSENDCRLF      )(LPPDEVICE);
typedef short (FAR  PASCAL *PSSENDDSC       )(LPPDEVICE, short, LPSTR );
typedef short (FAR  PASCAL *PSSENDDSCBBOX   )(LPPDEVICE, short, LPRECT );
typedef VOID  (FAR  PASCAL *PSSENDBITMAPTYPE)(LPPDEVICE, short);
typedef VOID  (FAR  PASCAL *PSSENDBITMAPDATALEVEL2)(LPPDEVICE,BYTE huge *,DWORD);
typedef VOID  (FAR  PASCAL *PSSENDBITMAPDATALEVEL1)(LPPDEVICE,BYTE huge *,DWORD);
typedef VOID  (FAR  PASCAL *PSSENDBITMAPTERMINATOR)(LPPDEVICE);
typedef BOOL  (NEAR PASCAL *PSSENDFONTTYPE2)(LPPDEVICE,int,long,LPSTR,int);
typedef WORD  (FAR PASCAL  *CONVERTTOBINARY)(BYTE huge * , BYTE huge * , WORD);


typedef struct _ASCIIBINPTRS
    {
    PSSENDBASIC            PSSendBasic           ;   // Sends a basic PostScript primitive
    PSSENDTEXT             PSSendText            ;
    PSSENDSHORT            PSSendShort           ;
    PSSENDBOOLEAN          PSSendBoolean         ;
    PSSENDBBOX             PSSendBBox            ;
    PSSENDSTRING           PSSendString          ;
    PSSENDCHAR             PSSendChar            ;
    PSSENDDATA             PSSendData            ;
    PSSENDFLOAT            PSSendFloat           ;
    PSSENDEX6FLOAT         PSSendEx6Float        ;
    PSSENDHEXBYTE          PSSendHexByte         ;
    PSSENDHEXCOLOR         PSSendHexColor        ;
    PSSENDFRAGMENT         PSSendFragment        ;
    PSSENDCRLF             PSSendCRLF            ;
    PSSENDDSC              PSSendDSC             ;
    PSSENDDSCBBOX          PSSendDSCBBox         ;
    PSSENDBITMAPTYPE       PSSendBitMapType      ;
    PSSENDBITMAPDATALEVEL2 PSSendBitMapDataLevel2;
    PSSENDBITMAPDATALEVEL1 PSSendBitMapDataLevel1;
    PSSENDBITMAPTERMINATOR PSSendBitMapTerminator;
    PSSENDFONTTYPE2        PSSendFontType2       ;
    CONVERTTOBINARY        ConvertToBinary       ;
    } ASCIIBINPTRS, FAR * LPASCIIBINPTRS;
