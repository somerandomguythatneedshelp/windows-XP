/* getfaux.c - Get the information for a faux font

              Copyright 1994 -- Adobe Systems, Inc.
            PostScript is a trademark of Adobe Systems, Inc.
NOTICE:  All information contained herein or attendant hereto is, and
remains, the property of Adobe Systems, Inc.  Many of the intellectual
and technical concepts contained herein are proprietary to Adobe Systems,
Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
are protected as trade secrets.  Any dissemination of this information or
reproduction of this material are strictly forbidden unless prior written
permission is obtained from Adobe Systems, Inc.

Original version: Ron Fischer, Tue May 10th, 1994
*/

/* -------------------------------------------------------------------------
     Header Includes
 --------------------------------------------------------------------------- */

#include <ctype.h>
#include <stdio.h>
#include PACKAGE_SPECS
#include ATM

#include PUBLICTYPES
#include FP

#include PARSEGLU
#include STREAMER
#include STREAMER_FAUX
#include "stream.h"


PRIVATE Int32 HexToNum ARGDEF2(Card8 *, hexStr, IntX, count)
{
IntX i;
Int32 hexVal = 0;

for (i = 0; i < count; i++)
   hexVal = hexVal * 16 +(hexStr[i] >= 'A' ? hexStr[i] - 'A' + 10 : hexStr[i] - '0');

return hexVal;
} /* end HexToNum() */

   
/*************************************************************************

Function name:  GetFauxData()

**************************************************************************

Date:           
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        Get the faux font information
Description:    I use an awk script (getfaux.awk) to extract the information
                needed for creating a faux font from the faux font database
                (I use the Mac database accessed from UNIX for my testing).
                The manipulations shown in this routine reflect that fact.
                If your faux data comes from another source you will need 
                to write a routine to put the data into this form.
                
Parameters:     
                
Return Values:  
Notes:          
See also:       

**************************************************************************/

IntX GetFauxData ARGDEF4(Card8 *, fauxName, FauxInfoPointer, fauxInfo, 
       FauxValsPointer *, fauxVals, FauxGlyphsStruct *, fauxGlyphs)
{
FILE *fauxFile, *valsFile;
IntX i;
Card8 tempStr[65], valStr[10], *valsName;
float vector;
Int32 valSize;
Card8 *dataP;
Int16 tempShort;

if ((fauxFile = fopen((char *)fauxName, "r")) == NULL)
 { fprintf(stderr, "The faux font file '%s' does not exist.\n", fauxName);
   exit(1);
 } /* end if */

fscanf(fauxFile, "%s", tempStr);
fauxInfo->FontName = NULL;
if (!MyRealloc((void **)&fauxInfo->FontName, os_strlen((char *)tempStr)+1))
   return ST_OUT_OF_MEM;
os_strcpy((char *)fauxInfo->FontName, (char *)tempStr);
fscanf(fauxFile, "%s", tempStr);
fauxInfo->FullName = NULL;
if (!MyRealloc((void **)&fauxInfo->FullName, os_strlen((char *)tempStr)+1))
   return ST_OUT_OF_MEM;
os_strcpy((char *)fauxInfo->FullName, (char *)tempStr);
fscanf(fauxFile, "%s", tempStr);
fauxInfo->FamilyName = NULL;
if (!MyRealloc((void **)&fauxInfo->FamilyName, os_strlen((char *)tempStr)+1))
   return ST_OUT_OF_MEM;
os_strcpy((char *)fauxInfo->FamilyName, (char *)tempStr);


fauxInfo->IsFixedPitch = 0;
fauxInfo->MMToUse = ADOBESANS;

i = true;
while (i)
 { fscanf(fauxFile, "%s", tempStr);
   if (!os_strcmp((char *)tempStr, "FIXED"))
      fauxInfo->IsFixedPitch = 1;
   else if (!os_strcmp((char *)tempStr, "SERIF"))
      fauxInfo->MMToUse = ADOBESERIF;
   else if (!os_strcmp((char *)tempStr, "STD"))
      i = true; /* do nothing for now... */
   else 
      i = 0;
 } /* end while */

/* Try to match the x heights in the faux font by deterimining the ratio of
   the faux data to the MM data.  The MM data (512.0 and 480.0) was taken 
   from the Mac data base. */
sscanf((char *)tempStr, "%ld", &fauxInfo->LowercaseScale);
if (fauxInfo->MMToUse == ADOBESANS)
   fauxInfo->LowercaseScale = (Fixed)((float)fauxInfo->LowercaseScale * 65536.0 / 512.0);
else /* SERIF case */
   fauxInfo->LowercaseScale = (Fixed)((float)fauxInfo->LowercaseScale * 65536.0 / 480.0);

fscanf(fauxFile, "%hd", &tempShort);
/* this field is already in fixed format */
fauxInfo->ItalicAngle = (Int32)tempShort;
fscanf(fauxFile, "%hd", &tempShort);
fauxInfo->UnderlinePos = (Int32)tempShort*65536;
fscanf(fauxFile, "%hd", &tempShort);
fauxInfo->UnderlineThickness = (Int32)tempShort*65536;
fscanf(fauxFile, "%ld", &fauxInfo->condense);
fscanf(fauxFile, "%ld", &fauxInfo->expand);

i = 0;
while (!feof(fauxFile))
 { fscanf(fauxFile, "%hd", &tempShort);	/* Just skip "encoding value" */
   fscanf(fauxFile, "%s", tempStr);
   fauxGlyphs->name[i] = NULL;

   if (!MyRealloc((void **)&fauxGlyphs->name[i], os_strlen((char *)tempStr)+1))
      return ST_OUT_OF_MEM;

   os_strcpy((char *)fauxGlyphs->name[i], (char *)tempStr);
   if (islower(tempStr[0]))
      fauxGlyphs->isLower[i] = 1;
   else
      fauxGlyphs->isLower[i] = 0;
   fscanf(fauxFile, "%f", &vector);
   fauxGlyphs->designVector[i][0] = (Fixed)(vector * 65536);
   fscanf(fauxFile, "%f", &vector);
   fauxGlyphs->designVector[i][1] = (Fixed)(vector * 65536);
   i++;
 } /* end for */

fauxGlyphs->glyphCount = fauxInfo->glyphCount = i;
fclose(fauxFile);

if (fauxInfo->MMToUse == ADOBESANS)
   valsName = (Card8 *)"sans.hex";
else
   valsName = (Card8 *)"serif.hex";

if ((valsFile = fopen((char *)valsName, "r")) == NULL)
 { fprintf(stderr, "The faux font values file '%s' does not exist.\n", valsName);
   exit(1);
 } /* end if */

fseek(valsFile, 0, SEEK_END);
valSize = ftell(valsFile);
fseek(valsFile, 0, SEEK_SET);
*fauxVals = NULL;
if (!MyRealloc((void **)fauxVals, valSize))
   return ST_OUT_OF_MEM;
dataP = (Card8 *)*fauxVals;

fscanf(valsFile, "%8s", valStr);			/* Skip version */
fscanf(valsFile, "%8s", valStr);			/* Skip flags */
fscanf(valsFile, "%4s", valStr);			/* Get count */
fauxInfo->fauxValsCount = (Card16)HexToNum(valStr, 4);

while (!feof(valsFile))
 { fscanf(valsFile, "%4s", valStr);
   *((Int16 *)dataP) = (Int16)HexToNum(valStr, 4);
   dataP+=2;
 } /* end while */

fclose(valsFile);

return ST_NOERR;
} /* end GetFauxData() */


/*************************************************************************

Function name:  ClearFauxData()

**************************************************************************

Date:           05/31/94
Author:         Ron Fischer (rff)
Prototype in:   stream.h
Summary:        Frees the memory used by the faux font structures.
Description:    
                
Parameters:     
                
Return Values:  
Notes:          Don't check error results because of the way MyRealloc() works.
                If the pointer is zero MyRealloc() returns an error--but some
                systems zero the pointer when you deallocate the memory...
See also:       

**************************************************************************/

PUBLIC IntX ClearFauxData ARGDEF2(FauxInfoPointer, fauxInfo,
                                  FauxValsPointer *, fauxVals)
{
MyRealloc((void **)&fauxInfo->FontName, 0);
MyRealloc((void **)&fauxInfo->FullName, 0);
MyRealloc((void **)&fauxInfo->FamilyName, 0);
MyRealloc((void **)fauxVals, 0);

return ST_NOERR;
} /* end ClearFauxData() */



