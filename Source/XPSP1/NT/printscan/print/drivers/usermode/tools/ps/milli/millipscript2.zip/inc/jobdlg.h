/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Include File Name: JOBDLG.H                                               */
/*                                                                           */
/* Description: This include contains the prototype for                      */
/*                                                                           */
/*****************************************************************************/

// Flags used to identify poscript mode used in SendMode.
#define PS_BCP_MODE		0x01
#define PS_CTRL_D_BEFORE_MODE	0x02
#define PS_CTRL_D_AFTER_MODE	0x04

short FAR PASCAL DoHeaderDownloading(LPDRIVERINFO lpDrvInfo);
short NEAR DIALOGSSEG PASCAL DoSwitchBetweenAsciiAndBinary(HWND hDlg,LPDRIVERINFO lpDrvInfo);
#ifdef Adobe_Driver
short FAR PASCAL DoSwitchBetweenAsciiAndBinaryStub(LPDRIVERINFO lpDrvInfo, WORD wFlag);
#endif
