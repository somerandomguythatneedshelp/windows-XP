/*
 *	Font Translation Library
 *
 *	Copyright (c) 1995 Adobe Systems Inc.
 *	All Rights Reserved
 *
 *	UFLConfig.h
 *
 *		Intel Windows 3.1 version of UFLConfig
 *
 * $Header: $
 */

#ifndef _H_UFLConfig
#define _H_UFLConfig

#define _JBLEN  9  /* bp, di, si, sp, ret addr, ds */

#ifndef _JMP_BUF_DEFINED
typedef  int  jmp_buf[_JBLEN];
#define _JMP_BUF_DEFINED
#endif 

/* ANSI requires setjmp be a macro */

#define setjmp  _setjmp
#define SWAPBITS 1

#define UFLEXPORT _far _pascal _export _loadds 
#define UFLEXPORTPTR _far _pascal
#define UFLCALLBACK _far __cdecl
#define UFLCALLBACKDECL UFLCALLBACK _loadds

#define PTR_PREFIX      __huge
typedef unsigned long DWORD;

#define UFLWIN16 1

#endif
