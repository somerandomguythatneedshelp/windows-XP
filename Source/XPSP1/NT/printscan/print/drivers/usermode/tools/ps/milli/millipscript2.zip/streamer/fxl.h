/* CM_VerSion fxl.h atm05 1.2 10076.eco sum= 26461 */
/* CM_VerSion fxl.h atm04 1.2 04307.eco sum= 48565 */
/*
  fxl.h -- simulated floating point

Copyright (c) 1992 Adobe Systems Incorporated.
All rights reserved.

Patents Pending

NOTICE:  All information contained herein is the property of
Adobe Systems Incorporated.  Many of the intellectual and
technical concepts contained herein are proprietary to Adobe,
are protected as trade secrets, and are made available only to
Adobe licensees for their internal use.  Any reproduction or
dissemination of this software is strictly forbidden unless
prior written permission is obtained from Adobe.

PostScript and Display PostScript are registered trademarks of
Adobe Systems Incorporated.

Original version: Tom Malloy: Feb 5, 1992
Revision History
Paul Sholtz: Feb 12, 1992
Paul Haahr: Mon Apr 6 13:21:42 1992
End Revision History.
*/

#ifndef	FXL_H
#define	FXL_H

typedef struct {
  Frac  mantissa;	/* signed mantissa */
  IntX	exp;            /* number of bits to shift to turn the mantissa
			 * into a 16.16 fixed point number:
			 *     pos => lshift, neg => rshift
			 */
} Fxl;

#define	FxlIsZero(fxl)	((fxl).mantissa == 0)

extern Fixed FxlToFixed ARGDECL1(Fxl, fxl);
extern Frac FxlToFrac ARGDECL1(Fxl, fxl);
extern Fxl FixedToFxl ARGDECL1(Fixed, f);
extern Fxl Int32ToFxl ARGDECL1(Int32, i);
extern Fxl fxlnormalize ARGDECL1(Fxl, fxl);

extern Fxl fxladd ARGDECL2(Fxl, a, Fxl, b);
extern Fxl fxlsub ARGDECL2(Fxl, a, Fxl, b);
extern Fxl fxlmul ARGDECL2(Fxl, a, Fxl, b);
extern Fxl fxldiv ARGDECL2(Fxl, a, Fxl, b);
extern Fxl fxlsqrt ARGDECL1(Fxl, fxl);

#if BCMAIN
extern double FxlToDouble ARGDECL1(Fxl, fxl);
#endif

#endif	/* FXL_H */
