/*
  except.h

Copyright (c) 1984, '85, '86, '87, '88, '91 Adobe Systems Incorporated.
All rights reserved.

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript is a registered trademark of Adobe Systems Incorporated.
Display PostScript is a trademark of Adobe Systems Incorporated.

Original version: 
Edit History:
Craig Rublee: Fri Jul 26 12:07:54 1991
Scott Byer: Mon Jul 16 08:14:39 1990
Ivor Durham: Thu Aug 11 08:45:50 1988
Bill Paxton: Tue Apr 18 14:24:24 1989
End Edit History.
Revision History
  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/EXCEPT.H_V  $
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:07:20   unknown
 *- |Initial revision.
  Revision 6.1  91/10/07  18:22:33  rublee
   
  
  
End Revision History.
*/

#ifndef	EXCEPT_H
#define	EXCEPT_H

#define Assert(c)\
	if (!(c)) {CantHappen();}
/* Tests whether the specified condition is true and aborts the
   entire system if not.
 */

#if STAGE==DEVELOP
#define DebugAssert(condition)  if (! (condition)) CantHappen();
#else /* STAGE==DEVELOP */
#define DebugAssert(condition)
#endif /* STAGE==DEVELOP */
/* Same as assert, but the test is made only if the code is compiled
   in the development configuration (which is never the case for
   those packages not compiled with distinct STAGEs).
 */



#endif	/* EXCEPT_H */
