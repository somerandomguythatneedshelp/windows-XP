/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: LV1FUNCS.H                                                   */
/*                                                                           */
/* Description: This module contains PostScript Level 1 defines and          */
/*              prototype support                                            */
/*                                                                           */
/*****************************************************************************/

//              -----   Pens     -----

short FAR PASCAL TPen           (LPPDEVICE, LPPPEN      );
short FAR PASCAL TPenCap        (LPPDEVICE, BYTE        );
short FAR PASCAL TPenFGColor    (LPPDEVICE, DWORD       );
short FAR PASCAL TPenBGColor    (LPPDEVICE, DWORD       );
short FAR PASCAL TPenJoin       (LPPDEVICE, BYTE        );
short FAR PASCAL TPenMiterLimit (LPPDEVICE, short       );
short FAR PASCAL TPenStyle      (LPPDEVICE, BYTE        );
short FAR PASCAL TPenWidth      (LPPDEVICE, POINT       );


//              -----   Brushes  -----

short FAR PASCAL TBrushBGColor  (LPPDEVICE, DWORD       );
short FAR PASCAL TBrushFGColor  (LPPDEVICE, DWORD       );
short FAR PASCAL TBrushHatch    (LPPDEVICE, BYTE        );
short FAR PASCAL TBrushPattern  (LPPDEVICE, LPPAT       );
short FAR PASCAL TBrushStyle    (LPPDEVICE, BYTE        );


//              -----   Shapes   -----

short FAR PASCAL TArc           (LPPDEVICE, LPRECT ,LPPOINT,LPPOINT            );
short FAR PASCAL TChord         (LPPDEVICE, LPRECT ,FLAG ,FLAG,LPPOINT,LPPOINT );
short FAR PASCAL TEllipse       (LPPDEVICE, LPRECT ,FLAG ,FLAG                 );
short FAR PASCAL TCircle        (LPPDEVICE, LPRECT ,FLAG ,FLAG                 );
short FAR PASCAL TLine          (LPPDEVICE, LPPOINT                            );
short FAR PASCAL TPie           (LPPDEVICE, LPRECT ,FLAG ,FLAG,LPPOINT,LPPOINT );
short FAR PASCAL TPolygon       (LPPDEVICE, LPPOINT,FLAG ,FLAG,FLAG,short      );
short FAR PASCAL TPolyLine      (LPPDEVICE, LPPOINT,short                      );
short FAR PASCAL TPolyBezier      (LPPDEVICE, LPPOINT,short                      );
short FAR PASCAL TRectangle     (LPPDEVICE, LPRECT ,FLAG ,FLAG                 );
short FAR PASCAL TRoundRectangle(LPPDEVICE, LPRECT ,FLAG ,FLAG,LPPOINT         );
short FAR PASCAL TScanLine      (LPPDEVICE, LPPOINT,FLAG ,FLAG,short           );
short FAR PASCAL TScanLineBegin (LPPDEVICE);
short FAR PASCAL TScanLineEnd   (LPPDEVICE);
short FAR PASCAL TPolyMode      (LPPDEVICE, BYTE                               );
short FAR PASCAL TPixel         (LPPDEVICE, short, short, DWORD                );

//              -----   Bitmaps   -----

short FAR PASCAL TBMOpaqueBox     (LPPDEVICE, LPRECT,DWORD              );
short FAR PASCAL TOpaqueBox     (LPPDEVICE, LPRECT,DWORD, WORD          );
short FAR PASCAL TBitmapHeader  (LPPDEVICE, LPRECT ,LPRECT,DWORD        );
short FAR PASCAL TBitmapOperator(LPPDEVICE, DWORD,DWORD,DWORD           );
short FAR PASCAL TBitmapData    (LPPDEVICE, LPBITMAP,LPRECT,SHORT       );
short FAR PASCAL TDIBDataBits   (LPPDEVICE, LPRECT  ,LPSTR ,LPBITMAPINFO);
short FAR PASCAL TDIBHeader	(LPPDEVICE, LPRECT  ,LPRECT,short,BOOL	);
short FAR PASCAL TDIBOperator   (LPPDEVICE, short                       );
short FAR PASCAL TGrayTable     (LPPDEVICE, LPBYTE  ,WORD               );
short FAR PASCAL TColorTable    (LPPDEVICE, LPDWORD ,WORD               );
short FAR PASCAL TICMColor      (LPPDEVICE, DWORD                       );


//              -----   Management  -----

short FAR PASCAL TDriverData    (LPPDEVICE,short              );
short FAR PASCAL TDocumentPageBegin(LPPDEVICE);
short FAR PASCAL TDocumentPageEnd  (LPPDEVICE);
short FAR PASCAL TDocumentAbort (LPPDEVICE);
short FAR PASCAL TDocumentEnd   (LPPDEVICE);
short FAR PASCAL TDocumentFlush (LPPDEVICE);
short FAR PASCAL TDocumentBegin (LPPDEVICE);
short FAR PASCAL TClipRect      (LPPDEVICE, LPRECT, LPRECT, int          );
short FAR PASCAL TClipEnd       (LPPDEVICE);
short FAR PASCAL TJobType       (LPPDEVICE, short                        );
short FAR PASCAL TJobTitle      (LPPDEVICE, LPSTR                        );
short FAR PASCAL TJobCopies     (LPPDEVICE, WORD                         );
short FAR PASCAL TJobDuplex     (LPPDEVICE, WORD                         );
short FAR PASCAL TBackgroundMode(LPPDEVICE, BYTE                         );
short FAR PASCAL TColorBG       (LPPDEVICE, DWORD                        );
short FAR PASCAL TArcDirection  (LPPDEVICE, BYTE                         );
short FAR PASCAL TSetScreenFrequency(LPPDEVICE, short                        );
short FAR PASCAL TSetScreenAngle(LPPDEVICE, short                                );

short FAR PASCAL TSetGDIXForm(LPPDEVICE);
short FAR PASCAL TDownLoadHeader(LPPDEVICE, WORD );

//              ----   Escapes ---------

short FAR PASCAL TRawPrinterStart(LPPDEVICE);
short FAR PASCAL TRawPrinterData (LPPDEVICE, LP,WORD                     );
short FAR PASCAL TRawPrinterEnd  (LPPDEVICE);

//              ----   Text and Fonts ----

short FAR PASCAL TTextBegin(LPPDEVICE, LPPOINT,LPPSFONTINFO,LPTEXTXFORM    );
short FAR PASCAL TTextRun(LPPDEVICE, LPSTR,int, double, double,LPPSFONTINFO,LPTEXTXFORM, LPINT);
short FAR PASCAL TTextEnd(LPPDEVICE, LPPSFONTINFO,LPTEXTXFORM, int);
PSERROR FAR PASCAL TSoftFontLoad(LPPDEVICE, LPPSFONTINFO,LPTEXTXFORM,LPSTR,short);
PSERROR FAR PASCAL TSoftFontLoadMin(LPPDEVICE, LPPSFONTINFO,LPTEXTXFORM,LPSTR,short);
#ifdef ADD_EURO
PSERROR FAR PASCAL TDeviceFontLoad(LPPDEVICE, LPPSFONTINFO,LPTEXTXFORM);
#endif

#ifdef ADOBE_DRIVER
short FAR PASCAL TTextRunWide(LPPDEVICE, LPWORD, int, double, double,LPPSFONTINFO,LPTEXTXFORM, LPINT);
#endif

//              ----   Page Level functions ----
short FAR PASCAL TPageOrientation(LPPDEVICE,  WORD                       );

//              -----   Paper    -----
short FAR PASCAL TPaperSource(LPPDEVICE, LPSTR);
short FAR PASCAL TPaperSize(LPPDEVICE, LPSTR);

void FAR PASCAL TEndPath(LPPDEVICE,LPPATHINFO,LPDRAWMODE);
void FAR PASCAL TClipPath(LPPDEVICE, WORD, WORD);
void FAR PASCAL TCTMTransform(LPPDEVICE, LPDWORD);
void FAR PASCAL TCTMSaveRestore(LPPDEVICE, WORD);
void FAR PASCAL TClipBox(LPPDEVICE, LPRECT);
