/*
    buffglue.c

    This module manages the streamer buffer.  Data is buffered:  To provide
    a more efficient transfer (instead of a byte at a time), to allow
    data to be encrypted, to be able to insert the size of a charstring
    before the charstring.

           Copyright 1994 -- Adobe Systems Incorporated
    PostScript is a registered trademark of Adobe Systems Incorporated.

    NOTICE:  All information contained herein or attendant hereto is, and
    remains, the property of Adobe Systems, Inc.  Many of the intellectual
    and technical concepts contained herein are proprietary to Adobe Systems,
    Inc. and may be covered by U.S. and Foreign Patents or Patents Pending or
    are protected as trade secrets.  Any dissemination of this information or
    reproduction of this material are strictly forbidden unless prior written
    permission is obtained from Adobe Systems, Inc.

*/
#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif
#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES
#include BUILDCH
#include STREAMER
#include PARSE

/* Move this definition into a config file eventually */
#define CAN_SET_TIME	1

#if CAN_SET_TIME
#include <time.h>
#endif

#include "buffglue.h"


#define LINE_END        '\n'
#define LINE_END_DOS    '\r'        /* msdos only - added 6/95 pdb          */

#define EOL_SPACING	62


/* Hexadecimal encryption takes twice the space of the binary data, so if */
/* hex is in use this pointer will be used and the buffer passed in will */
/* be split in half. */
PRIVATE Card8 *hexBuf;                  /* The buffer pointer */
PRIVATE Card8 *bp;                      /* The buffer pointer */
PRIVATE Card8 *bufStart;                /* The start of the buffer */
PRIVATE Card32 bufSize;                 /* The buffer size */
PRIVATE Card32 bufLeft;                 /* Length left in buffer */
/* The buffer is locked when it is being filled with charStrings--I may */
/* have to insert the length before the string, and I can't do that if I */
/* just flushed it... */
PRIVATE Card8  bufLock;			/* Can't flush when locked */
PRIVATE IntX bufError;                  /* Error flag for the buffer */
PRIVATE PutBytesFunc PutBytes;


PRIVATE Card16 eexecKey;
PRIVATE Card8 eexec;
PRIVATE Card8 addEOL = 0;

#if !defined(HC386) || HC386==0
PUBLIC ReallocFunc MemoryRealloc;       /*Realloc routine provided by application */
#endif


/*************************************************************************

Function name:  BufferEncrypt()

**************************************************************************

Date:           03/20/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        eexec encrypt a buffer
Description:    eexec encrypt and possibly hexencode a buffer of lenght
                inLen.  If hexencoding is performed the outBuf will be
                just over twice as long as the inBuf.  For hexencoding
                this function assumes the outBuf is well over 2X the 
                size of the inBuf!!!!  Hexencoding is selected by
                setting eexecOpt = ST_ENCRYPTHEX.
                
Parameters:     inBuf -- the input data
                outBuf -- the output data
                inLen -- the number of bytes of input data
                outLen -- the number of bytes of output data
                KeyP -- the updated eexec key
                eexecOpt -- the type of eexec encryption.  It should
                    be either ST_ENCRYPT or ST_ENCRYPTHEX.
                
Return Values:  none (data is returned in outBuf)
Notes:          
See also:       

**************************************************************************/

PUBLIC void BufferEncrypt ARGDEF6(Card8 *, inBuf, Card8 *, outBuf, 
                Int32, inLen , Int32 *, outLen, Card16 *, KeyP, Card8, eexecOpt)
{
register Card8 Cipher;
register Card8 *PlainSource = inBuf;
register Card8 *CipherDest = outBuf;
register Card16 R = *KeyP;
Int32 totalEOLs = 0;			// Change this value from Char8 to Int32 to avoid overflow. TH 04/11/96

if (eexecOpt == ST_ENCRYPT)
 { *outLen = inLen;

   while (--inLen >= 0) 
    { Cipher = (*PlainSource++ ^ (Card8)(R >> 8));
      R = (Card16)(((Card16)Cipher + R) * 52845 + 22719);
      *CipherDest++ = Cipher;
    } /* end while */
 } /* end if */
else /* if (eexecOpt == ST_ENCRYPTHEX) only other choice! */
 { Card8 t;
   *outLen = (inLen << 1);

   while (--inLen >= 0) 
    { Cipher = (*PlainSource++ ^ (Card8)(R >> 8));
      R = (Card16)(((Card16)Cipher + R) * 52845 + 22719);
      t = (Card8)(((Cipher >> 4) & 0x0F) + 0x30);
      if (t > 0x39)
        t += 7;
      *CipherDest++ = t;
      t = (Card8)((Cipher & 0x0F) + 0x30);
      if (t > 0x39)
        t += 7;
      *CipherDest++ = t;
      addEOL+=2;
      if (addEOL > EOL_SPACING)
       {
#if OS==os_msdos                              /* "/r/n" if under msdos  */
         *CipherDest++ = LINE_END_DOS;
         totalEOLs++;
#endif
         *CipherDest++ = LINE_END;
         totalEOLs++;
         addEOL = 0;
       } /* end if */
    } /* end while */

   *outLen += totalEOLs;
 } /* end else */

*KeyP = R;
} /* end BufferEncrypt() */


PUBLIC void BufferGetEEKey ARGDEF2(Card16 *, currentKey, Card8 *, eexecOpt)
{
*currentKey = eexecKey;
*eexecOpt = eexec;
} /* end BufferGetEEKey() */


/*************************************************************************

Function name:  BufferSetEEKey()

**************************************************************************

Date:           
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        Changes buffer encryption status.
Description:     
                
Parameters:     
                
Return Values:  
Notes:          If the eexec type changes a flush is immediately performed.
                This is because BufferFlush encrypts (or does not encrypt)
                the entire buffer (not part of it).
See also:       

**************************************************************************/

PUBLIC IntX BufferSetEEKey ARGDEF2(Card16, initialKey, Card8, eexecOpt)
{
eexecKey = initialKey;
addEOL = 0;
/* NOTE:  This could cause problems if the buffer is "locked" */
if (eexec != eexecOpt) 		/* Prevent unintended encryption/unencryption */
   BufferFlush();
eexec = eexecOpt;

if ((eexec == ST_ENCRYPTHEX) && (hexBuf == bufStart))
   return ST_CANT_CHANGE_ENCRYPTION;

return ST_NOERR;
} /* end BufferSetEEKey() */


/*************************************************************************

Function name:  BufferResize()

**************************************************************************

Date:           
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        
Description:    
                
Parameters:     
                
Return Values:  
Notes:          
See also:       

**************************************************************************/

PRIVATE IntX BufferResize ARGDEF1(Card32, len)
{ 
/* Try for just a little more mem than the absolute minimum needed */
Card32 newSize = bufSize+(len-bufLeft)+1024; //128;
Card32 offset = bp - bufStart;
Card8 syncHexBuf = false;

if (hexBuf != bufStart)
 { /* Hexbuf needs 2X + a little more space */
   if (!MemoryRealloc((void **)&hexBuf, (newSize*2)+((newSize*2)/EOL_SPACING)))
    { bufError = ST_BUFFER_TOO_SMALL;
      return bufError;
    } /* end if */
 } /* end if */
else 
   syncHexBuf = true;

if (!MemoryRealloc((void **)&bufStart, newSize))
 { bufError = ST_BUFFER_TOO_SMALL;
   return bufError;
 } /* end if */

/* If hex encoding is not used then these pointers should point to the */
/* same place, always.  Since I just changed bufStart I must change hexBuf. */
if (syncHexBuf)
   hexBuf = bufStart;

bp = bufStart + offset;
bufLeft += (newSize - bufSize); /* Old free amount + increase in size */
bufSize = newSize; 		

return ST_NOERR;
} /* end BufferResize() */


/*************************************************************************

Function name:  

**************************************************************************

Date:           
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        
Description:    
                
Parameters:     
                
Return Values:  
Notes:          Only performs ST_ENCRYPT (single encryption, no hexencoding)
See also:       

**************************************************************************/

PUBLIC IntX BufferAndEncrypt ARGDEF3(Card8 *, s, Card32, len, Card16 *, eeKey)
{
Int32 dummyLen;
Card8 *saveBp = bp;                      /* The buffer pointer */
Card8 *saveStart = bufStart;
Card8 saveLock = bufLock;

bufLock = true;				/* Don't allow flushes for this */
BufferChars(s, len);
bufLock = saveLock;			/* Restore lock state */

if (saveStart != bufStart)		/* Must have resized buffer */
   saveBp = (saveBp - saveStart) + bufStart;
   
/* Should encrypt the data in place */
BufferEncrypt(saveBp, saveBp, len, &dummyLen, eeKey, ST_ENCRYPT);

return ST_NOERR;
} /* end BufferAndEncrypt() */



/*************************************************************************

Function name:  BufferFlush()

**************************************************************************

Date:           
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        
Description:    
                
Parameters:     
                
Return Values:  
Notes:          
See also:       

**************************************************************************/

PUBLIC void BufferFlush ARGDEF0()
{
if (bufSize - bufLeft > 0)
 { /*Even if hexBuf is the same as bufStart (when hexencoding is not used) it */
   /* is used as output pointer for encrypted data. */
   if (eexec != ST_NO_ENCRYPTION)         	/* Encrypt data. */
    { Int32 outLen;
      BufferEncrypt(bufStart, hexBuf, bufSize-bufLeft, &outLen, &eexecKey, 
                    eexec);
       if (!PutBytes((char *)hexBuf, (Card32)outLen))
          bufError = ST_CALLBACKFAILED;
    } /* end if */
   else
      PutBytes((char *)bufStart, (Card32)(bufSize - bufLeft));
   
   /* the hexBuf pointer is never changed so it does not need to be reset */
   bp = bufStart;
   bufLeft = bufSize;
 } /* end if */

} /* end BufferFlush() */


PUBLIC void BufferLock ARGDEF1(Card8, lockStatus)
{
bufLock = lockStatus;
} /* end BufferLock() */


/*************************************************************************

Function name:  BufferChars()

**************************************************************************

Date:           03/28/94
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        
Description:    All the buffer functions come through this routine
                before going into the buffer.  This makes it easier to
                manage the buffer.
Parameters:     
                
Return Values:  
Notes:          MemoryRealloc() should preserve any data.  Note that the
                growable buffer idea is left hi&dry by this...
See also:       

**************************************************************************/

PUBLIC IntX BufferChars ARGDEF2(Card8 *,s, Card32, len)
{

if (len == 0)			/* Nothing to do */
   return ST_NOERR;

if (!bufLock)			/* Can't flush when it's locked */
 { if (len > bufLeft)           /* Must flush the buffer */
      BufferFlush();
 } /* end if */

/* Whoa!  Just too big for buffer!  May be able to grow buffer tho... */
/* (Even if it is locked) */
if (len > bufLeft)
   if (BufferResize(len) != ST_NOERR)
      return ST_BUFFER_TOO_SMALL;

#if OS==os_msdos
if (len > 65535)
   return ST_BUFFER_TOO_BIG;
os_memcpy(bp, s, (CardX)len);
#else
os_memcpy(bp, s, len);
#endif /* os_msdos */
bufLeft -= len;
bp += len;

return ST_NOERR;
}  /* end BufferChars() */


PUBLIC IntX BufferChar ARGDEF1(Card8, c)
{
Card8 s[1];
s[0] = c;
return BufferChars(s, 1);
} /* end BufferChar() */


PUBLIC IntX BufferString ARGDEF1(Card8 *,s)
{
return BufferChars(s, os_strlen((char *)s));
} /* end BufferString() */


PUBLIC IntX BufferStringEOL ARGDEF1(Card8 *,s)
{
#if OS != os_msdos
  static Card8 c[1] = { LINE_END };

  BufferChars(s, os_strlen((char *)s));
  return BufferChars(c, 1);

#else
  static Card8 c[2] = { LINE_END_DOS, LINE_END };

  BufferChars(s, os_strlen((char *)s));
  if (eexec == ST_NO_ENCRYPTION) 
    return BufferChars(c, 2);             /* lfcr that the user sees        */
  else 
    return BufferChars(c+1, 1);           /* cr in a hex encrypted portion  */  
#endif
} /* end BufferStringEOL() */


/* But will this format the data correctly?   And do I need different formats */
/* at different times? */
PUBLIC IntX BufferInt ARGDEF1(Card32, i)
{
Card8 is[11]; /* One bigger than format */

os_sprintf((char *)is, "%ld", i);
return BufferChars(is, os_strlen((char *)is));
} /* end BufferInt() */

static long convFract[] =
	{
	65536L,
	6553L,
	655L,
	66L,
	6L
	};

/* Convert a Fixed to a c string */
PRIVATE void Fixed2CString( Fixed f, char* s, short precision )
{
	char u[12];
	char *t;
	short v;
	char sign;
	long fracPrec = (precision <= 4) ? convFract[precision] : 0L;

	if ((sign = f < 0) != 0)
		f = -f;

	/* If f started out as fixedMax or -fixedMax, the precision adjustment puts it
			out of bounds.  Reset it correctly. */
	if (f >= 0x7FFF7FFF)
		f =(Fixed)0x7fffffff;
	else
		f += (fracPrec + 1) >> 1;

	v = (short)(f >> 16);
	f &= 0x0000ffff;
	if (sign && (v || f >= fracPrec))
		*s++ = '-';
		
	t = u;
	do {
		*t++ = v % 10 + '0';
		v /= 10;
	} while (v);
	
	for (; t > u;)
		*s++ = *--t;
		
	if (f >= fracPrec) {
		*s++ = '.';
		for (v = precision; v-- && f;) {
			f = (f << 3) + (f << 1);
			*s++ = (char)((f >> 16) + '0');
			f &= 0x0000ffff;
		}
		for (; *--s == '0';)
			;
		if (*s != '.')
			s++;
	}

	*s = '\0';
}


PUBLIC IntX BufferFixed ARGDEF1(Fixed, f)
{
	char	fs[32];
	Fixed2CString( f, fs, 4 );
	return BufferChars(fs, (Card32)os_strlen((char *)fs));
}

#ifdef OLD
/* But will this format the data correctly?   And do I need different formats */
/* at different times? */
PUBLIC IntX BufferFixed ARGDEF1(Fixed, f)
{
Card8 fs[15],fs2[5]; /* One bigger than format */
long temp;
int sgn = 1;

/*os_sprintf((char *)fs, "%7.2f", (float)f/65536.0);*/
fs[0] = ' ';
if (f < 0){
	sgn = -1;
	f = -f;
}
temp = (long)(((float)f/65536.0)*1000);
if (temp%10 > 5) temp = temp/10 + 1;
else temp /= 10;
os_sprintf((char *)fs+1,"%ld",sgn*temp);
strcpy((char *)fs2, (char *)(fs+strlen((char *)fs)-2));
os_sprintf((char *)(fs+strlen((char *)fs)-2),".%s",fs2);
return BufferChars(fs, (Card32)os_strlen((char *)fs));
} /* end BufferFixed() */
#endif

#if CAN_SET_TIME

PUBLIC IntX BufferTime ARGDEF0()
{
time_t tod;
struct tm *tptr;

if ((int)time(&tod) != -1)
 { tptr = localtime(&tod);
   BufferString((Card8 *)asctime(tptr));
 } /* end if */
else
   BufferString((Card8 *)"unknown");

return ST_NOERR;
} /* end BufferTime() */

#else

PUBLIC IntX BufferTime ARGDEF0()
{
BufferString((Card8 *)"unknown time");

return ST_NOERR;
} /* end BufferTime() */

#endif

/* NEEDS A BETTER WAY OF SPECIFYING, IF I can't just dump it into string.. */
/* Is this the way Shawn handles fracts? */
PUBLIC void FracToString ARGDEF3(Fixed, n, Card16, places, Card8 *, s)
{
   float fracScale = (float) 1073741824.0;  /* i=1, f=30 , range [-2, 2) */

	float f = (float)n;
	f = f / fracScale;
	_gcvt( f, places, s );

#if 0
char ls[20],ls2[20];
float f = (float)n;
long temp;
int sgn = 1;

/*if (places == 2)
  os_sprintf((char *)s, "%8.3f", f / fracScale);
else if (places == 3)
  os_sprintf((char *)s, "%8.3f", f / fracScale);
else if (places == 6)
  os_sprintf((char *)s, "%10.6f", f / fracScale);
else if (places == 8)
  os_sprintf((char *)s, "%10.8f", f / fracScale);
else
  os_sprintf((char *)s, "%8.4f", f / fracScale);
*/
if (f < 0.0){
	f = -f;
	sgn = -1;
}
if (places == 2 || places == 3){
	temp = (long)((f/fracScale)*10000.0);
	if (temp%10 > 5) temp = temp/10 + 1;
	else temp /= 10;
	os_sprintf((char *)ls,"%ld",sgn*temp);
	strcpy(ls2, ls+strlen(ls)-3);
	os_sprintf(ls+strlen(ls)-3,".%s",ls2);
}
else if (places == 6){
	temp = (long)((f/fracScale)*10000000.0);
	if (temp%10 > 5) temp = temp/10 + 1;
	else temp /= 10;
	os_sprintf((char *)ls,"%ld",sgn*temp);
	strcpy(ls2, ls+strlen(ls)-6);
	os_sprintf(ls+strlen(ls)-6,".%s",ls2);
}
else if (places == 8){
	temp = (long)((f/fracScale)*1000000000.0);
	if (temp%10 > 5) temp = temp/10 + 1;
	else temp /= 10;
	os_sprintf((char *)ls,"%ld",sgn*temp);
	strcpy(ls2, ls+strlen(ls)-8);
	os_sprintf(ls+strlen(ls)-8,".%s",ls2);
}
else{
	temp = (long)((f/fracScale)*100000.0);
	if (temp%10 > 5) temp = temp/10 + 1;
	else temp /= 10;
	os_sprintf((char *)ls,"%ld",sgn*temp);
	strcpy(ls2, ls+strlen(ls)-4);
	os_sprintf(ls+strlen(ls)-4,".%s",ls2);
}
strcpy((char *)s, ls);
#endif
} /* end FracToString() */


/*************************************************************************

Function name:  BufferInitialize()

**************************************************************************

Date:           
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        
Description:    If the eexec flag (so->eexec) is set to ST_ENCRYPTHEX two
                buffers must be allocated--one for the data, another for
                the hexencoded data, which is twice as big.  So the buffer
                is divided into thirds with 2 for the hexBuf and 1 for
                the data buf.
Parameters:     
                
Return Values:  
Notes:          BufferSetEEKey() should be called immediately after this
                to set the CURRENT eekey value.
See also:       

**************************************************************************/

PUBLIC IntX BufferInitialize ARGDEF2(Card32, len, 
                                     PStreamerOpts, so)
{
bufError = ST_NOERR;
bufLock = false;

hexBuf = bufStart = NULL;

/* Must split buffer in half because hexencoding takes 2X the space */
if (so->eexec == ST_ENCRYPTHEX) 
 { int totalEOLs;

   bufSize = bufLeft = len / 3;
   /* Leave room for LINE_END characters */
   totalEOLs = (int)((len-bufSize)/EOL_SPACING); 
#ifdef LINE_END_DOS
   totalEOLs *= 2;
#endif
   MemoryRealloc((void **)&bufStart, bufSize);
   if (bufStart == NULL)
    { bufError = ST_BUFFER_TOO_SMALL;
      return bufError;
    } /* end if */
   bp = bufStart;

   /* A little extra room in the hexBuf */
   MemoryRealloc((void **)&hexBuf, (len-bufSize)+totalEOLs+16);
   if (hexBuf == NULL)
    { bufError = ST_BUFFER_TOO_SMALL;
      return bufError;
    } /* end if */
 } /* end if */
else
 { MemoryRealloc((void **)&bufStart, len);
   if (bufStart == NULL)
    { bufError = ST_BUFFER_TOO_SMALL;
      return bufError;
    } /* end if */
   hexBuf = bp = bufStart;
   bufSize = bufLeft = len;
 } /* end if */
PutBytes = so->PutBytes;

return ST_NOERR;
} /* end BufferInitialize() */


/*************************************************************************

Function name:  BufferDeinit()

**************************************************************************

Date:           
Author:         Ron Fischer (rff)
Prototype in:   
Summary:        
Description:    
                
Parameters:     
                
Return Values:  
Notes:          
See also:       

**************************************************************************/

PUBLIC void BufferDeinit ARGDEF1(PStreamerOpts, so)
{
if (so->eexec == ST_ENCRYPTHEX)
 { if (hexBuf != bufStart)/*This should always happen unless user screws up...*/
      MemoryRealloc((void **)&hexBuf, 0);
   MemoryRealloc((void **)&bufStart, 0);
 } /* end if */
else
   MemoryRealloc((void **)&bufStart, 0);

bufSize = bufLeft = 0;
} /* end BufferDeinit() */


/*************************************************************************

Function name:  BufferSave()

**************************************************************************

Date:           03/29/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Save the state of streamer's internal buffers
Description:    Save the buffer's state.  This state should be restored
                before reusing attempting to reuse the buffer. 
                Use of this function and BufferRestore() allow multiple
                fonts to run through streamer approximately concurrently. 
                
Parameters:     b -- points to the storage location
                
Return Values:  none
Notes:          Streamer functions Flush the data from the buffer when
                they exit.
See also:       BufferRestore(), StreamerStart()

**************************************************************************/

PUBLIC void BufferSave ARGDEF1(BufferStatus *, b)
{
b->bufSize = bufSize;
b->bufLeft = bufLeft;
b->hexBuf = hexBuf;
b->bufStart = bufStart;
b->bp = bp;
b->eexecKey = eexecKey;
b->eexec = eexec;
b->addEOL = addEOL;
} /* end BufferSave() */


/*************************************************************************

Function name:  BufferRestore()

**************************************************************************

Date:           03/29/94
Author:         Ron Fischer (rff)
Prototype in:   streamer.h
Summary:        Restore a buffer state.
Description:    Restore a particular buffer's state.
                
Parameters:     b -- Points to the storage location
                
Return Values:  none
Notes:          
See also:       BufferSave()

**************************************************************************/

PUBLIC void BufferRestore ARGDEF1(BufferStatus *, b)
{
bufSize = b->bufSize;
bufLeft = b->bufLeft;
hexBuf = b->hexBuf;
bufStart = b->bufStart;
bp = b->bp;
eexecKey = b->eexecKey;
eexec = b->eexec;
addEOL = b->addEOL;
} /* end BufferRestore() */


PUBLIC IntX BufferError ARGDEF0()
{
return bufError;
} /* end BufferError() */


PUBLIC Card32 BufferSize ARGDEF0()
{
return bufSize - bufLeft;
} /* end bufSize() */


PUBLIC IntX BufferInsert ARGDEF2(Card8 *, buf, Card32, len)
{
register Int32 i;

if (len > 0)
 { if (bufLeft < len)
    { if (BufferResize(len) != ST_NOERR)
         return ST_BUFFER_TOO_SMALL;
    } /* end if */
   for (i = (bufSize-bufLeft)-1; i >= 0; i--)
      *(bufStart+i+len) = *(bufStart+i);
   
#if OS==os_msdos
   if (len > 65535)
      return ST_BUFFER_TOO_BIG;
   os_memcpy(bufStart, buf, (CardX)len);
#else
   os_memcpy(bufStart, buf, len);
#endif /* os_msdos */

   bufLeft -= len;
   bp += len;
 } /* end if */

return ST_NOERR;
} /* end BufferInsert() */

