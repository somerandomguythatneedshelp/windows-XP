/*****************************************************************************/
/*                                                                           */
/* Copyright (C) 1993,1994 Microsoft Corporation. All rights reserved.       */
/*                                                                           */
/* Module Name: PSDLG.C                                                      */
/*                                                                           */
/* Description: This module contains the functions for the PostScript        */
/*              Options Dialog                                               */
/*                                                                           */
/*****************************************************************************/

#include "generic.h"
#include "apd42map.hh"

#pragma code_seg(_DIALOGSSEG)

// This function is defined in TRAN\theader.c:
BOOL FAR PASCAL GetKeyVal(HKEY hv, LPSTR path_key, LPSTR val_key, LPSTR buffer, long *cl);

/*****************************************************************************/
/*                 InitPostScriptDlg                                         */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: BOOL                                                             */
/*****************************************************************************/

VOID NEAR PASCAL InitPostScriptDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;
    DWORD          dwUIFlags = lpDrvInfo->dwUIFlags[DI_POSTSCRIPT];
    int            i, yOffset = 0, y;
    char           strBuff[STR_BUFF_LEN];

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_OUTFMT,
                     ID_TEXT_OUTPUTFMT, ID_OUTPUTFMT, ID_PS_HDR_GROUP);

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_HEADER,
                     ID_PS_HDR_GROUP, ID_DOWNLOAD_HEADER, ID_ERROR_HANDLER);

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_ERRORINFO,
                     ID_ERROR_HANDLER, ID_ERROR_HANDLER, ID_TIMEOUT_GROUP);

    PositionControls(hDlg, NULL, (LPINT)&yOffset,
                     dwUIFlags & (DI_JOBTOUT | DI_WAITTOUT),
                     ID_TIMEOUT_GROUP, ID_TIMEOUT_GROUP, ID_ADVANCED);

    y = yOffset;
    PositionControls(hDlg, NULL, (LPINT)&y, dwUIFlags&DI_JOBTOUT,
                     ID_JOB_TIMEOUT, ID_TEXT_SECONDS1, ID_WAIT_TIMEOUT);

    PositionControls(hDlg, NULL, (LPINT)&y, dwUIFlags&DI_WAITTOUT,
                     ID_WAIT_TIMEOUT, ID_TEXT_SECONDS2, NULL);

    PositionControls(hDlg, NULL, (LPINT)&yOffset, dwUIFlags&DI_ADVANCED,
                     ID_ADVANCED, ID_ADVANCED, NULL);

    /* Initialize the output format */
    if (dwUIFlags & DI_OUTFMT)
    {
        SendDlgItemMessage(hDlg, ID_OUTPUTFMT, CB_RESETCONTENT, 0, 0L);

        for (i=IDS_OUTPUT_SPEED; i<= IDS_OUTPUT_ARCHIVE; i++)
        {
            LoadString(ghDriverMod, i, strBuff, sizeof(strBuff));
            SendDlgItemMessage(hDlg, ID_OUTPUTFMT, CB_ADDSTRING, 0,
                               (LPARAM)(LPSTR)strBuff);
        }

        if (lpPrinterInfo->devcaps.PJLsupport)
        { /* PJL Available */
            LoadString(ghDriverMod, IDS_OUTPUT_PJL_ARCHIVE, strBuff,
                       sizeof(strBuff));
            SendDlgItemMessage(hDlg, ID_OUTPUTFMT, CB_ADDSTRING, 0,
                               (LPARAM)(LPSTR)strBuff);
        }
    }

    /* Set spin range for Job and Wait timeout */

    if (dwUIFlags & DI_JOBTOUT)
    {
        SendDlgItemMessage(hDlg, ID_JOB_TIMEOUT, EM_LIMITTEXT, 4, 0) ;
        SendDlgItemMessage(hDlg, ID_JOB_TIMEOUT_SPN, UDM_SETRANGE, NULL,
                           MAKELPARAM(MAX_JOBTIMEOUT, MIN_JOBTIMEOUT));
    }

    /* Show wait timeout & limit text size. */
    if (dwUIFlags & DI_WAITTOUT)
    {
        SendDlgItemMessage(hDlg, ID_WAIT_TIMEOUT, EM_LIMITTEXT, 4, 0) ;
        SendDlgItemMessage(hDlg, ID_WAIT_TIMEOUT_SPN, UDM_SETRANGE, NULL,
                           MAKELPARAM(MAX_WAITTIMEOUT, MIN_WAITTIMEOUT));
    }

}


/*****************************************************************************/
/*                 ShowPostScriptDlg                                         */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns: BOOL                                                             */
/*****************************************************************************/

VOID NEAR PASCAL ShowPostScriptDlg(HWND hDlg, LPDRIVERINFO lpDrvInfo)
{
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;
    DWORD          dwUIFlags = lpDrvInfo->dwUIFlags[DI_POSTSCRIPT];
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)lpDrvInfo->pDev.lpWPXblock->WPXprinterInfo;

    /* Output format */
    if (dwUIFlags & DI_OUTFMT)
    {
        SendDlgItemMessage(hDlg, ID_OUTPUTFMT, CB_SETCURSEL,
                           lpPSExtDevmode->dm.enumDialect, 0L);
    }

    /* Postscript header */
    if (dwUIFlags & DI_HEADER)
    {
        CheckRadioButton(hDlg, ID_PS_HDR_DOWNLOAD, ID_PS_HDR_ALREADY,
            lpPSExtDevmode->dm2.fHeader?ID_PS_HDR_DOWNLOAD:ID_PS_HDR_ALREADY);
        EnableWindow(GetDlgItem(hDlg,ID_DOWNLOAD_HEADER),
                     lpPSExtDevmode->dm2.fHeader);
    }

    /* Error Handler Check Box */
    if (dwUIFlags & DI_ERRORINFO)
    {
           CheckDlgButton(hDlg,ID_ERROR_HANDLER,lpPSExtDevmode->dm2.bErrHandler);

    }
    if (dwUIFlags & DI_JOBTOUT)
    {

           SendDlgItemMessage(hDlg, ID_JOB_TIMEOUT_SPN, UDM_SETPOS, NULL,
                           MAKELPARAM(lpPSExtDevmode->dm2.iJobTimeout, NULL));
    }

    if (dwUIFlags & DI_WAITTOUT)
    {
           SendDlgItemMessage(hDlg, ID_WAIT_TIMEOUT_SPN, UDM_SETPOS, NULL,
                           MAKELPARAM(lpPSExtDevmode->dm2.iWaitTimeout, NULL));
    }
}


/*****************************************************************************/
/*                 CheckPostScriptDlg                                        */
/* Purpose:                                                                  */
/*   Checks the validity of certain user entered data in the                 */
/*   PostScript features dialog box. The first invalid or out of range entry */
/*   causes failure and the item in question will be highlighted.            */
/*                                                                           */
/* Parameters:                                                               */
/*   LPDRIVERINFO lpDrvInfo -- pointer to DRIVERINFO                         */
/*   HWND hDlg -- Handle to PostScript features dialog                       */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE  => if success, entered values are fine                            */
/*   FALSE => if failure, at least one entered value is invalid              */
/*****************************************************************************/

BOOL NEAR PASCAL CheckPostScriptDlg(LPDRIVERINFO lpDrvInfo, HWND hDlg)
{
    LPPSEXTDEVMODE lpPSExtDevmode=lpDrvInfo->lpDM;
    DWORD          dwUIFlags = lpDrvInfo->dwUIFlags[DI_POSTSCRIPT];
    int            i, ctrl_id ;
    BOOL           ok_flag = TRUE;
    long           maxVal, minVal;

    if (dwUIFlags & DI_JOBTOUT)
    {
        ctrl_id = ID_JOB_TIMEOUT ;
        i = GetDlgItemInt(hDlg, ctrl_id, &ok_flag, FALSE) ;
        if (ok_flag)
        {
            if (i >= MIN_JOBTIMEOUT && i <= MAX_JOBTIMEOUT)
            {
                lpPSExtDevmode->dm2.iJobTimeout = i;
            }
            else
                ok_flag = FALSE;
        }
    }

    if (!ok_flag)
    {
        minVal = MIN_JOBTIMEOUT;
        maxVal = MAX_JOBTIMEOUT;
        goto Errors;
    }

    if (dwUIFlags & DI_WAITTOUT)
    {
        ctrl_id = ID_WAIT_TIMEOUT ;
        i = GetDlgItemInt(hDlg, ctrl_id, &ok_flag, FALSE) ;
        if (ok_flag)
        {
            if (i >= MIN_WAITTIMEOUT && i <= MAX_WAITTIMEOUT)
            {
                lpPSExtDevmode->dm2.iWaitTimeout = i;
            }
            else
                ok_flag = FALSE;
        }
    }

    if (!ok_flag)
    {
        minVal = MIN_WAITTIMEOUT;
        maxVal = MAX_WAITTIMEOUT;
        goto Errors;
    }

    if (dwUIFlags & DI_OUTFMT)
    {
        lpPSExtDevmode->dm.enumDialect =
            LOWORD(SendDlgItemMessage(hDlg,ID_OUTPUTFMT, CB_GETCURSEL, 0, 0L));
    }

    if (dwUIFlags & DI_ERRORINFO)
    {
        lpPSExtDevmode->dm2.bErrHandler =
            IsDlgButtonChecked(hDlg, ID_ERROR_HANDLER);
    }


    if (dwUIFlags & DI_HEADER)
    {
        lpPSExtDevmode->dm2.fHeader =
            IsDlgButtonChecked(hDlg,ID_PS_HDR_DOWNLOAD);
    }

Errors:
    if (!ok_flag)
    {
        ShowErrorValueMessage(hDlg, ctrl_id, minVal, maxVal);
    }

    return (ok_flag);
}


/*****************************************************************************/
/*                 RestorePostScriptDefaults                                 */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/

void FAR PASCAL RestorePostScriptDefaults(LPPSEXTDEVMODE lpPSExtDevmode,
                                          LPWPXBLOCKS lpWPXBlock,
                                          DWORD dwUIFlags)
{
    LPPRINTERINFO  lpPrinterInfo =
        (LPPRINTERINFO)lpWPXBlock->WPXprinterInfo;
    if (dwUIFlags & DI_OUTFMT)
    {
#ifndef ADOBE_DRIVER_42
        if(((LPPRINTERINFO)lpWPXBlock->WPXprinterInfo)->devcaps.DefaultToPortability)
           lpPSExtDevmode->dm.enumDialect = DIA_PORTABLE;
        else
#endif
           lpPSExtDevmode->dm.enumDialect = DIA_SPEED;
    }

    if (dwUIFlags & DI_ERRORINFO)
        if (!lpPrinterInfo->devcaps.PrintPSErrorExist)
           lpPSExtDevmode->dm2.bErrHandler = TRUE;
        else
           lpPSExtDevmode->dm2.bErrHandler = lpPrinterInfo->devcaps.bPrintPSErrors;

    if (dwUIFlags & DI_JOBTOUT)
        if (!lpPrinterInfo->devcaps.JobTimeout)
           lpPSExtDevmode->dm2.iJobTimeout = 0;
        else
           lpPSExtDevmode->dm2.iJobTimeout = lpPrinterInfo->devcaps.JobTimeout;

    if (dwUIFlags & DI_WAITTOUT)
        if (!lpPrinterInfo->devcaps.WaitTimeout)
           lpPSExtDevmode->dm2.iWaitTimeout = DEF_WAITTIMEOUT;
        else
           lpPSExtDevmode->dm2.iWaitTimeout = lpPrinterInfo->devcaps.WaitTimeout;

    if (dwUIFlags & DI_HEADER)
        lpPSExtDevmode->dm2.fHeader = TRUE;
}


/*****************************************************************************/
/*                 GripeAboutEPS                                             */
/* Purpose:                                                                  */
/*                                                                           */
/* Parameters:                                                               */
/*                                                                           */
/* Returns:                                                                  */
/*****************************************************************************/

VOID NEAR PASCAL GripeAboutEPS(HWND hDlg)
{
    char szText[2*STR_BUFF_LEN];
    char szTextFormat[2*STR_BUFF_LEN];
    char szCaption[STR_BUFF_LEN];

    LoadString(ghDriverMod, DLGS_szOptionAvailable, szTextFormat,
        sizeof(szTextFormat));
    LoadString(ghDriverMod, IDS_OUTPUT_EPS, szCaption, sizeof(szCaption));
    wsprintf(szText, szTextFormat, (LPSTR) szCaption) ;
    LoadString(ghDriverMod, ADDPRN_szWarning, szCaption, sizeof(szCaption));
    MessageBox(hDlg, szText, szCaption, MB_OK | MB_ICONEXCLAMATION);
}


/*****************************************************************************/
/*                 CHPostScriptDlg                                           */
/* Purpose:                                                                  */
/*   Dialog Proceedure for the PostScript Features property sheet dialog box.*/
/*                                                                           */
/* Parameters:                                                               */
/*   HWND hDlg -- Handle to the dialog box window                            */
/*   unsigned imsg -- Message                                                */
/*   WORD wParam -- Word parameter                                           */
/*   LONG lParam -- Long parameter                                           */
/*                                                                           */
/* Returns: BOOL                                                             */
/*   TRUE -- If proceedure processes message                                 */
/*   FALSE -- If it does not                                                 */
/*****************************************************************************/

BOOL _loadds FAR PASCAL CHPostScriptDlg(HWND hDlg, unsigned imsg,
                                        WORD wParam, LONG lParam)
{
    LPDRIVERINFO lpDrvInfo;
    BOOL         result = TRUE ;
    BOOL         bChanged = FALSE;
    short        retval;

    char szRegPath[512];
    char szRegPortName[256];
    char szPortName[256];
    long cb;
    BOOL ret;

    if(lpDrvInfo=(LPDRIVERINFO)GetWindowLong(hDlg,DWL_USER))
    {
#ifdef USEHOOKPROC
        /* Process hook function stuff */
        if(DrvProcessHookProc(&(lpDrvInfo->pDev),hDlg,imsg,wParam,lParam,
                              "HookSetup"))
        {
            return TRUE;
        }
#endif
    }

    switch (imsg)
    {
        case WM_INITDIALOG:
#if 0
            if (IsWin40() && UsePropertySheet())
                lpDrvInfo=(LPDRIVERINFO)(((LPPROPSHEETPAGE)lParam)->lParam);
            else
                lpDrvInfo=(LPDRIVERINFO)lParam;
#endif
            lpDrvInfo=(LPDRIVERINFO)(((LPPROPSHEETPAGE)lParam)->lParam);
            SetWindowLong(hDlg,DWL_USER,(LPARAM)lpDrvInfo);
            lpDrvInfo->bPainting = TRUE;

            GetDecimalSeparator(decimalSeparator, sizeof(decimalSeparator));
            InitPostScriptDlg(hDlg, lpDrvInfo);
            ShowPostScriptDlg(hDlg, lpDrvInfo);
            lpDrvInfo->bPainting = FALSE;
            break ;

        case WM_CONTEXTMENU:
            if (wParam != -1)
            {
                WinHelp((HWND)wParam,szHelpFile,HELP_CONTEXTMENU,
                        (DWORD)(LPDWORD)dwHelpMap);
            }
            break;

        case WM_HELP:
            if (((LPHELPINFO) lParam)->hItemHandle != -1)
            {
                WinHelp(((LPHELPINFO) lParam)->hItemHandle,szHelpFile,
                        HELP_WM_HELP,(DWORD)(LPDWORD)dwHelpMap);
            }
            break;


        case WM_NOTIFY:
            switch (NOTIFY_CODE(lParam))
            {
                case PSN_KILLACTIVE:
                    if(!CheckPostScriptDlg(lpDrvInfo,hDlg))
                    {
                        SetWindowLong(hDlg,DWL_MSGRESULT,TRUE);
                        return TRUE;
                    }
                    break;

                case PSN_APPLY:
                    if (lpDrvInfo->bChanged)
                    {
                        // Stuff that only happens for PSN_APPLY, and only if
                        //  the data is valid.
                        UpdateGlobal(lpDrvInfo,TRUE);
                        WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
                        lpDrvInfo->bChanged = FALSE;
                    }
                    break;

                case PSN_RESET:
                    // If canceling, set lpDrvInfo->lpDM back to the
                    // saved devmode
                    lpDrvInfo->lpDM=&(lpDrvInfo->DMSave);
                    WinHelp(hDlg,szHelpFile,HELP_QUIT,NULL);
                    break;
            }
            break;

        case WM_COMMAND:
            switch (wParam)
            {
                case ID_RESTORE_DEFAULTS:
                    RestorePostScriptDefaults(lpDrvInfo->lpDM,
                                             lpDrvInfo->pDev.lpWPXblock,
                                             lpDrvInfo->dwUIFlags[DI_POSTSCRIPT]);
                    ShowPostScriptDlg(hDlg, lpDrvInfo);
                    bChanged = TRUE;
                    break;

                case ID_ABOUT:
                    DialogBoxParam(ghDriverMod,"AB",hDlg,
                                   fnAboutDlg, (LPARAM)lpDrvInfo);
                    break;

                case ID_OUTPUTFMT:    /* Update output dialect. */
                    if((HIWORD(lParam) == CBN_SELCHANGE) &&
                       (LOWORD(SendDlgItemMessage(hDlg,ID_OUTPUTFMT,
                                                  CB_GETCURSEL, 0,
                                                  NULL)) == DIA_EPS) &&
                       !IsFilePort(lpDrvInfo->pDev.szPortName))
                    {
                        GripeAboutEPS(hDlg);
                    }
                    if(HIWORD(lParam) == CBN_SELCHANGE)
                    {
                        bChanged = TRUE;
                    }
                    break ;

                case ID_ADVANCED:
                    if (DialogBoxParam(ghDriverMod,
                                       MAKEINTRESOURCE(CH_ADVANCED),
                                       hDlg, CHAdvancedDlg,
                                       (LPARAM)lpDrvInfo) == IDOK)
                        bChanged = TRUE;
                    break ;

                case ID_PS_HDR_DOWNLOAD:
                case ID_PS_HDR_ALREADY:
                    EnableWindow(GetDlgItem(hDlg,ID_DOWNLOAD_HEADER),
                                 wParam == ID_PS_HDR_DOWNLOAD);
                    bChanged = TRUE;
                    break;

                case ID_DOWNLOAD_HEADER:


                    if (DrvrStringMessageBox(hDlg, DLGS_szDownloadHeaderOK,
                                             DLGS_szDownloadHeader,
                                             MB_OKCANCEL |
                                             MB_ICONQUESTION) == IDOK)
                    {
                     //
                     // make sure to use the latest portname, check the registry to
                     // validate the port name.
                     // This is not the best solution, until we have better way, look into
                     // registry for the current port name
                     //
                         //use szRegPortName temporary to hold a string.
                         LoadString(ghDriverMod, IDS_REGSTR_PRN_PRINTER, szRegPortName, sizeof(szRegPortName));
                         wsprintf(szRegPath, szRegPortName, (LPSTR)lpDrvInfo->pDev.lpPSExtDevmode->dm.dm.dmDeviceName);

                         szRegPortName[0]='\0'; // initialize.
                         cb = sizeof(szRegPortName);
                         lstrcpy(szPortName, "Port");

                         ret = GetKeyVal(HKEY_LOCAL_MACHINE, (LPSTR)szRegPath, (LPSTR)szPortName,
                               (LPSTR)szRegPortName, &cb);
                         if (ret)
                         {
                            if (lstrcmp(lpDrvInfo->pDev.szPortName, szRegPortName))
                            {
                               lstrcpy(lpDrvInfo->pDev.szPortName, szRegPortName);
                            }
                         }


                        /* Download the Header! */
                        if ((retval = DoHeaderDownloading(lpDrvInfo)) == RC_ok)
                        {
                            CheckRadioButton(hDlg, ID_PS_HDR_DOWNLOAD,
                                             ID_PS_HDR_ALREADY,
                                             (WORD) ID_PS_HDR_ALREADY );
                            EnableWindow(GetDlgItem(hDlg,ID_DOWNLOAD_HEADER),
                                         FALSE);
                            bChanged = TRUE;
                        }
                        else
                        {
                            if (retval != RC_userabort)

                                DrvrStringMessageBox(hDlg, DLGS_szDownloadHeaderFailed,
                                                 DLGS_szDownloadHeader,
                                                 MB_OK | MB_ICONHAND);
                        }
                    }
                    break;

                case ID_JOB_TIMEOUT:
                case ID_WAIT_TIMEOUT:
                    if (HIWORD(lParam) == EN_CHANGE)
                        bChanged = TRUE;
                    break;

                case ID_ERROR_HANDLER:
                    if (HIWORD(lParam) == BN_CLICKED)
                        bChanged = TRUE;
                    break;

#ifndef USE_WHATSTHIS_HELP
                case ID_HELP:
                    WinHelp(hDlg, szHelpFile, HELP_CONTEXT,
                            IDH_PSCRIPT_SET_PS_OPTS);
                    break;
#endif

                default:
                    result = FALSE ;
                    break ;

            } /* switch(wParam) */
            break ;

        default:
            result = FALSE ;
            break ;
    } /* switch(imsg) */

    if (bChanged && lpDrvInfo && !lpDrvInfo->bChanged && !lpDrvInfo->bPainting)
    {
        lpDrvInfo->bChanged = TRUE;
        PropSheet_Changed( GetParent(hDlg), hDlg );
    }

    return result ;
}


