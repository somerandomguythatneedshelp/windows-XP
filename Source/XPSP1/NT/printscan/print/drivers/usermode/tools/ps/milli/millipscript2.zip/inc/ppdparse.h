/*  ppdparse.h - header containing info specific to
   ppdparser.
*/


typedef  enum  { NOTREADY, COLON, WHITESPACE, NEWLINE } KEYWORDTERM  ;


// modifier flags for LPKEYENTRY

#define  GROUP_INSTALLABLE_OPTIONS 0x0001   
// statement occurs within OpenGroup: InstallableOptions
#define  JCLKEYWORD  0x0002
// statement occurs within JCLOpenUI/JCLCloseUI




#define  GARBAGE  0xffff  // invalid index


#define _MAX_PATH             260

#define  MAXMAINKEYWORDSTABLESIZ  400  // doubled from what was in 4.1 
                                       // number of unique keywords

#define  NUM_CONSTR   10
// initial allocation blocksize for UI constraints array

#define   NUMKEYENTRY  3000            // hold array of this many KEYENTRY's
                                       // hits 64k limit at 3276
                                       // fixes bug 145400

typedef  enum  {
   PPDVERSION,  // assume first item has value of zero
   MODELNAME,
   NICKNAME,  
   SHORTNICKNAME,
   COLORDEVICE ,
   LANGUAGELEVEL, 
   PROTOCOLSS,   
   FREEVM,
   ORDERDEPENDENCY, 
   PAGESIZE,  
   DEFAULTPAGESIZE,
   Q_PAGESIZE,  
   PAGEREGION, 
   IMAGEABLEAREA,
   PAPERDIMENSION,
   LANDSCAPEORIENTATION,
   CUSTOMPAGESIZE, 
   PARAMCUSTOMPAGESIZE,
   MAXMEDIAWIDTH, 
   HWMARGINS, 
   MEDIATYPE, 
   DEFAULTMEDIATYPE, 
   Q_MEDIATYPE, 
   INPUTSLOT,     
   DEFAULTINPUTSLOT,
   Q_INPUTSLOT,     
   REQUIRESPAGEREGION,
   OUTPUTBIN,  
   DEFAULTOUTPUTBIN,
   Q_OUTPUTBIN,  
   MANUALFEED,
   DUPLEX,    
   DEFAULTDUPLEX,
   Q_DUPLEX,   
   MIRRORPRINT,   // its presence here means it won't appear in device options
//   NEGATIVEPRINT,  its absence here means it will appear in device options
   DEFAULTRESOLUTION,
   RESOLUTION,  
   Q_RESOLUTION,  
   SETRESOLUTION, 
   SCREENFREQ,  
   SCREENANGLE, 
   SCREENFREQRES,  
   SCREENANGLERES, 
   FONT,        
   DEFAULTFONT,
   PASSWORD,    
   EXITSERVER,  
   SYMBOLVALUE, 
   OPENUI,
   OPENGROUP,
   CLOSEGROUP,
   UICONSTRAINT,
   TTRASTERIZER, 
   TRUEIMAGEDEVICE,
   JCLBEGIN,
   JCLTOPS,
   JCLEND,
   JCLOPENUI,
   JCLCLOSEUI,
   DEFAULTJCLRESOLUTION,
   JCLRESOLUTION,  
   Q_JCLRESOLUTION,  
   DEFAULTINSTALLEDMEMORY,  // cause this not to appear 
   INSTALLEDMEMORY,        //  in DeviceOptions
   VMOPTION,
   LANGUAGEENCODING,
   PCFILENAME,
   PRODUCT,
   PSVERSION,
   PATCHFILE,
   JOBPATCHFILE,
#ifdef Adobe_Driver   
   FAXSUPPORT,   
   COLLATE,
   Q_COLLATE,
   DEFAULTCOLLATE,
   OUTPUTORDER,
   DEFAULTOUTPUTORDER,
   Q_OUTPUTORDER,
   ADHASEURO,
//#ifdef ADOBE_WEB
   // Web keyword strings id
   WEBURL,
   WEBSERVER,
   WEBPORT,
   WEBPRINTER,
   WEBPRINTERNAME,
   WEBCOMMPROTOCOL,
   WEBPPD,
   WEBNOTICE,
//#endif
#endif
   FONTCACHESIZE,
   ADDEFAULTPROTOCOL,
// Added for ICM (bug 118385). jjia 10/18/95 
   MANUFACTURER,
// End ICM
   JOBTIMEOUT,
   WAITTIMEOUT,
   PRINTPSERRORS,
   ENDOFLIST      // must be last item on list
} KEYWORD ;


// NEWUIKEYWORDS  temporarily stores info obtained from
// parsing OpenUI statements.  Only keywords introduced (not pre-existing)
// by OpenUI statements are saved.  This data is eventually transferred
// to MAINKEYHDR structures once the memory has been allocated.

typedef  struct  tagNEWUIKEYWORDS
{
   WORD     keyword  ; //  index to MainKeyWordsTable
   HPBYTE     optionTrans  ; //  translation string for new keyword.
   UITYPE   UItype ;
   BOOL     PrntrSticky ;  // this is doc or printer sticky ?
}  NEWUIKEYWORDS , far * LPNEWUIKEYWORDS;



typedef  struct  tagKEYENTRY
{
   WORD  keyword ;
   WORD  flags ;   // modifier flags ie is this within OpenGroup?  QuotedString?
   HPBYTE     option  ; //  pointer to to option keyword if any.
   HPBYTE     optionTrans  ; //  translation string for option keyword.
   HPBYTE     value   ; //  may set NULL for not found.
   BOOL     bValueQuoted ; //  True if value begins with " or ^
   KEYWORDTERM  termination ;   //  type of termination byte.
}  KEYENTRY , far * LPKEYENTRY;

//  note: all keywords begin with * in first column 


extern  LPSTRINGREF  lpMainKeyWordsTable ;

extern  ENCODING    LangEncoding ;  //  Enum of various possible encodings.

extern  WORD     numMainKeyWords ;  // indexes first empty slot in array.

extern  BOOL     bUseSetResolution ,   // which resolution command to scan for
         bAutoSelect ,  //  just specify papersize not tray.
         bManFeed,
         bCustomSize;

extern  LPKEYENTRY  lpKeyEntry;   //  index of all main keyword statments in PPD file
extern  WORD        numKeywords ;
extern  DWORD  ScreenFreq , ScreenAngle ;


extern  LPUI_CONSTRAINTS   lpUI_constraints ;  // points to array of constraints.
extern  WORD   max_constraints ;  // initialized to array size
extern  WORD   curConstraint ;   // initialized to zero.


//  note there is no PPD keyword coresponding to ENDOFFILE, this
//  is just a value returned by keyword scanning routine.





