/* CM_VerSion strtofix.c atm05 1.2 10076.eco sum= 22614 */
/* CM_VerSion strtofix.c atm04 1.5 07518.eco sum= 45554 */
/* 
  strtofix.c -- convert a string to a fixed point number as best we can

Copyright (c) 1989 Adobe Systems Incorporated.
All rights reserved.

NOTICE:  All information contained herein is the property of Adobe Systems
Incorporated.  Many of the intellectual and technical concepts contained
herein are proprietary to Adobe, are protected as trade secrets, and are made
available only to Adobe licensees for their internal use.  Any reproduction
or dissemination of this software is strictly forbidden unless prior written
permission is obtained from Adobe.

PostScript is a registered trademark of Adobe Systems Incorporated.
Display PostScript is a trademark of Adobe Systems Incorporated.

Original version: jvz 20-dec-89
Edit History:
Paul Haahr: Mon Apr 6 11:43:34 1992
End Edit History.

Revision History
  $Log:   L:/PVCS/ADOBE41/PSCRIPT/STREAMER/STRTOFIX.C_V  $
 *- |
 *- |   Rev 1.0   27 Sep 1994 15:07:56   unknown
 *- |Initial revision.
  Revision 6.2  91/11/13  11:10:09  rublee
  Changed include of atm.h to ATM and moved after PACKAGE_SPECS.
  Removed include of sunsyslib.h

  Revision 6.1  91/10/07  18:22:19  rublee



End Revision History.

*/


#ifndef PACKAGE_SPECS
#define PACKAGE_SPECS "package.h"
#endif

#if WINATM
#ifdef CODE32
pragma Off (List);
#endif
#include "atmglue.h"
#endif

#include PACKAGE_SPECS
#include ATM
#include PUBLICTYPES
#include FP
#include "fxl.h"
#include "chartype.h"
#include "strtofix.h"

#if WINATM
#ifdef CODE32
pragma Pop (List);
#endif
#endif


#define	MAXEXP	 4		/* must be >=0 */
#define	MINEXP	-8		/* must be <=0 */


#if GENERATE_TABLE
#include <stdio.h>
static void printfxl ARGDEF1(Fxl, f) {
  printf("  { %ld, %3d },\n", f.mantissa, f.exp);
}
int main ARGDEF0() {
  int i;
  Fxl powersof10, one, ten;
  one = FixedToFxl(FixedOne);
  ten = FixedToFxl(FixInt(10));
  for (i = MINEXP; i < 0; i++) {
    int j;
    for (j = 0, powersof10 = one; j > i; j--)
      powersof10 = fxldiv(powersof10, ten);
    printfxl(powersof10);
  }
  for (i = 0, powersof10 = one; i <= MAXEXP; i++) {
    printfxl(powersof10);
    powersof10 = fxlmul(powersof10, ten);
  }
  return 0;
}
#endif

PRIVATE Fxl powersof10[MAXEXP - MINEXP + 1] = {
  { 1441151880, -27 },
  { 1801439850, -24 },
  { 1125899906, -20 },
  { 1407374883, -17 },
  { 1759218604, -14 },
  { 1099511627, -10 },
  { 1374389534,  -7 },
  { 1717986918,  -4 },
  { 1073741824,   0 },
  { 1342177280,   3 },
  { 1677721600,   6 },
  { 2097152000,   9 },
  { 1310720000,  13 },
};

PRIVATE Fxl fxlpow10 ARGDEF2(Fxl, f, IntX, n) {
  if (n < 0) {
    for (; n < MINEXP; n -= MINEXP)
      f = fxlmul(f, powersof10[0]);
    f = fxlmul(f, powersof10[n - MINEXP]);
  } else if (n > 0) {
    for (; n > MAXEXP; n -= MAXEXP)
      f = fxlmul(f, powersof10[MAXEXP - MINEXP]);
    f = fxlmul(f, powersof10[n - MINEXP]);
  }
  return f;
}

/*
 * strtofxl
 *	convert a PostScript numeric token to a Fxl.  we have to accept
 *	three formats:  (see pslrm 2, pp 27-28)
 *		integers:	[+-]?[0-9]+
 *		reals:		[+-]?[0-9]*('.'[0-9]*)?([eE][+-]?[0-9]+)?
 *		radix numbers:	[0-9]+'#'[0-9a-zA-Z]+
 *	note that this routine is a bit more forgiving than PostScript itself.
 */

PRIVATE Fxl strtofxl ARGDEF1(Card8 *, token) {
  IntX c;
  Card8 *s;
  boolean neg;
  Fxl f;

  c = *token;
  if (c == '-') {
    neg = true;
    token++;
  } else {
    neg = false;
    if (c == '+')
      token++;
  }

  for (c = *(s = token); isdigit(c); c = *++s)
/* SUPPRESS 530 *//* CodeCenter Warning: Empty body for 'for' statement */
    ;

  if (c == '#')
    if (s == token)
      goto INVALID;
    else {
      CardX radix = atoi((char *) token);
      if (radix > 36)
        goto INVALID;
      else {
        char *t;
	Int32 number = strtol((char *) s + 1, &t, radix);
	if (*t != '\0')
	  goto INVALID;
	return Int32ToFxl(neg ? -number : number);
      }
    }

  f = Int32ToFxl(strtol((char *) token, NULL, 10));

  if (c == '.') {
    for (c = *(token = ++s); isdigit(c); c = *++s)
/* SUPPRESS 530 *//* CodeCenter Warning: Empty body for 'for' statement */
      ;
    if (s != token)
      f = fxladd(f, fxlpow10(Int32ToFxl(strtol((char *) token, NULL, 10)), token - s));
  }

  if (c == 'e' || c == 'E') {
    token = ++s;
    c = *s;
    if (c == '+' || c == '-')
      c = *++s;
    for (; isdigit(c); c = *++s)
/* SUPPRESS 530 *//* CodeCenter Warning: Empty body for 'for' statement */
      ;
    f = fxlpow10(f, atoi((char *) token));
  }

  if (neg)
    f.mantissa = -f.mantissa;
  if (c == '\0')
    return f;

INVALID:
  f.mantissa = 1;
  f.exp = 30000;		/* big enough to overflow, always */
  return f;
}

/* ConvertFixed -- takes an ascii token and converts to a 16.16 fixed */
PUBLIC Fixed ConvertFixed ARGDEF1(char *, s) {
  Fxl f;
  f = strtofxl((Card8 *) s);
  return FxlToFixed(f);
}

/* ConvertFrac -- takes an ascii token and converts to a 2.30 frac */
PUBLIC Frac ConvertFrac ARGDEF1(char *, s) {
  Fxl f;
  f = strtofxl((Card8 *) s);
  return FxlToFrac(f);
}

#if TEST
int main ARGDEF2(int, argc, char **, argv) {
  int i;
  for (i = 1; i < argc; i++) {
    Fixed x = ConvertFixed(argv[i]);
    printf("%8lx  %g\n", x, x/65536.0);
  }
  return 0;
}
#endif
